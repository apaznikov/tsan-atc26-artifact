; ModuleID = 'crawler.c'
source_filename = "crawler.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.crawler_module_reg_t = type { ptr, ptr, ptr, ptr, i8, i8 }
%union.pthread_mutex_t = type { %struct.__pthread_mutex_s }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i16, i16, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%union.pthread_cond_t = type { %struct.__pthread_cond_s }
%struct.__pthread_cond_s = type { %union.__atomic_wide_counter, %union.__atomic_wide_counter, [2 x i32], [2 x i32], i32, i32, [2 x i32] }
%union.__atomic_wide_counter = type { i64 }
%struct.settings = type { i64, i32, i32, i32, ptr, i32, i32, i32, ptr, ptr, i32, double, i32, i32, i32, i8, i32, i32, i8, i32, i32, i32, i32, i32, i32, i8, i8, i8, i8, i8, i8, i32, double, i32, i32, i8, i32, i8, i8, ptr, i32, i32, i32, i32, double, double, i32, i8, i32, i32, i32, i32, i32, i8, i8, i8, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, double, double, i8, i32, i32, ptr, i32 }
%struct.stats_state = type { i64, i64, i64, i64, i32, i32, i32, i32, i8, i8, i8, i8 }
%struct._crawler_module_t = type { ptr, %struct.crawler_client_t, ptr, i32 }
%struct.crawler_client_t = type { ptr, i32, i32, i32, ptr }
%struct.stats = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, %struct.timeval, i64, i64 }
%struct.timeval = type { i64, i64 }
%struct.crawler = type { ptr, ptr, ptr, i32, i32, i32, i16, i16, i8, i8, i32, i64, i64, i64 }
%struct.crawlerstats_t = type { [61 x i64], i64, i64, i64, i64, i32, i32, i8 }
%struct.pollfd = type { i32, i16, i16 }

@crawler_expired_mod = dso_local global %struct.crawler_module_reg_t { ptr @crawler_expired_init, ptr @crawler_expired_eval, ptr @crawler_expired_doneclass, ptr @crawler_expired_finalize, i8 1, i8 0 }, align 8, !dbg !0
@crawler_metadump_mod = dso_local global %struct.crawler_module_reg_t { ptr @crawler_metadump_init, ptr @crawler_metadump_eval, ptr null, ptr @crawler_metadump_finalize, i8 0, i8 1 }, align 8, !dbg !681
@crawler_mgdump_mod = dso_local global %struct.crawler_module_reg_t { ptr @crawler_mgdump_init, ptr @crawler_mgdump_eval, ptr null, ptr @crawler_mgdump_finalize, i8 0, i8 1 }, align 8, !dbg !725
@crawler_mod_regs = dso_local local_unnamed_addr global [4 x ptr] [ptr @crawler_expired_mod, ptr @crawler_expired_mod, ptr @crawler_metadump_mod, ptr @crawler_mgdump_mod], align 16, !dbg !727
@lru_crawler_lock = internal global %union.pthread_mutex_t zeroinitializer, align 8, !dbg !844
@do_run_lru_crawler_thread = internal global i32 0, align 4, !dbg !846
@lru_crawler_cond = internal global %union.pthread_cond_t zeroinitializer, align 8, !dbg !849
@item_crawler_tid = internal global i64 0, align 8, !dbg !785
@stderr = external local_unnamed_addr global ptr, align 8
@.str = private unnamed_addr constant [39 x i8] c"Failed to stop LRU crawler thread: %s\0A\00", align 1, !dbg !730
@settings = external local_unnamed_addr global %struct.settings, align 8
@.str.1 = private unnamed_addr constant [37 x i8] c"Can't create LRU crawler thread: %s\0A\00", align 1, !dbg !735
@.str.2 = private unnamed_addr constant [15 x i8] c"mc-itemcrawler\00", align 1, !dbg !740
@lru_crawler_start.block_ae_until = internal unnamed_addr global i32 0, align 4, !dbg !745
@stats_state = external local_unnamed_addr global %struct.stats_state, align 8
@active_crawler_type = dso_local local_unnamed_addr global i32 0, align 4, !dbg !781
@current_time = external global i32, align 4
@active_crawler_mod = dso_local global %struct._crawler_module_t zeroinitializer, align 8, !dbg !779
@crawler_count = internal unnamed_addr global i32 0, align 4, !dbg !895
@stats = external local_unnamed_addr global %struct.stats, align 8
@.str.3 = private unnamed_addr constant [4 x i8] c"all\00", align 1, !dbg !766
@.str.4 = private unnamed_addr constant [5 x i8] c"hash\00", align 1, !dbg !769
@.str.5 = private unnamed_addr constant [2 x i8] c",\00", align 1, !dbg !774
@lru_crawler_initialized = internal unnamed_addr global i1 false, align 4, !dbg !904
@storage = internal unnamed_addr global ptr null, align 8, !dbg !783
@crawlers = internal global [256 x %struct.crawler] zeroinitializer, align 16, !dbg !797
@.str.6 = private unnamed_addr constant [58 x i8] c"LRU crawler found an expired item (flags: %d, slab: %d): \00", align 1, !dbg !787
@.str.9 = private unnamed_addr constant [69 x i8] c"key=%s exp=%ld la=%llu cas=%llu fetch=%s cls=%u size=%lu flags=%llu\0A\00", align 1, !dbg !817
@process_started = external local_unnamed_addr global i64, align 8
@.str.10 = private unnamed_addr constant [4 x i8] c"yes\00", align 1, !dbg !822
@.str.11 = private unnamed_addr constant [3 x i8] c"no\00", align 1, !dbg !824
@.str.12 = private unnamed_addr constant [31 x i8] c"ERROR locked try again later\0D\0A\00", align 1, !dbg !826
@.str.13 = private unnamed_addr constant [6 x i8] c"END\0D\0A\00", align 1, !dbg !831
@.str.14 = private unnamed_addr constant [4 x i8] c"mg \00", align 1, !dbg !836
@.str.18 = private unnamed_addr constant [40 x i8] c"Starting LRU crawler background thread\0A\00", align 1, !dbg !881
@lru_locks = external global [256 x %union.pthread_mutex_t], align 16
@.str.19 = private unnamed_addr constant [30 x i8] c"Nothing left to crawl for %d\0A\00", align 1, !dbg !883
@hash = external local_unnamed_addr global ptr, align 8
@.str.20 = private unnamed_addr constant [29 x i8] c"LRU crawler thread sleeping\0A\00", align 1, !dbg !888
@.str.21 = private unnamed_addr constant [29 x i8] c"LRU crawler thread stopping\0A\00", align 1, !dbg !893
@.str.22 = private unnamed_addr constant [36 x i8] c"Kicking LRU crawler off for LRU %u\0A\00", align 1, !dbg !897
@switch.table.lru_crawler_crawl = private unnamed_addr constant [3 x i32] [i32 4, i32 1, i32 3], align 4
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nounwind sanitize_thread uwtable
define internal range(i32 -1, 1) i32 @crawler_expired_init(ptr nocapture noundef writeonly %cm, ptr noundef %data) #0 !dbg !913 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %cm, metadata !915, metadata !DIExpression()), !dbg !920
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !916, metadata !DIExpression()), !dbg !920
  %cmp.not = icmp eq ptr %data, null, !dbg !921
  br i1 %cmp.not, label %if.else, label %if.then, !dbg !923

if.then:                                          ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !917, metadata !DIExpression()), !dbg !920
  %is_external = getelementptr inbounds i8, ptr %data, i64 137265, !dbg !924
  store i8 1, ptr %is_external, align 1, !dbg !926, !tbaa !927
  br label %if.end7, !dbg !933

if.else:                                          ; preds = %entry
  %call = tail call noalias dereferenceable_or_null(137272) ptr @calloc(i64 noundef 1, i64 noundef 137272) #19, !dbg !934
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !917, metadata !DIExpression()), !dbg !920
  %cmp2 = icmp eq ptr %call, null, !dbg !936
  br i1 %cmp2, label %cleanup, label %if.end, !dbg !938

if.end:                                           ; preds = %if.else
  %call4 = tail call i32 @pthread_mutex_init(ptr noundef nonnull %call, ptr noundef null) #20, !dbg !939
  %is_external5 = getelementptr inbounds i8, ptr %call, i64 137265, !dbg !940
  store i8 0, ptr %is_external5, align 1, !dbg !941, !tbaa !927
  %0 = load volatile i32, ptr @current_time, align 4, !dbg !942, !tbaa !943
  %start_time = getelementptr inbounds i8, ptr %call, i64 137256, !dbg !944
  store i32 %0, ptr %start_time, align 8, !dbg !945, !tbaa !946
  br label %if.end7

if.end7:                                          ; preds = %if.end, %if.then
  %storemerge = phi ptr [ %call, %if.end ], [ %data, %if.then ], !dbg !947
  store ptr %storemerge, ptr %cm, align 8, !dbg !947, !tbaa !948
  tail call void @llvm.dbg.value(metadata ptr %storemerge, metadata !917, metadata !DIExpression()), !dbg !920
  %call9 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %storemerge) #20, !dbg !952
  %crawlerstats = getelementptr inbounds i8, ptr %storemerge, i64 40, !dbg !953
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(137216) %crawlerstats, i8 0, i64 137216, i1 false), !dbg !954
  tail call void @llvm.dbg.value(metadata i32 0, metadata !918, metadata !DIExpression()), !dbg !955
  br label %for.body, !dbg !956

for.cond.cleanup:                                 ; preds = %for.body
  %call17 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %storemerge) #20, !dbg !957
  br label %cleanup, !dbg !958

for.body:                                         ; preds = %for.body, %if.end7
  %indvars.iv = phi i64 [ 0, %if.end7 ], [ %indvars.iv.next.3, %for.body ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !918, metadata !DIExpression()), !dbg !955
  %1 = load volatile i32, ptr @current_time, align 4, !dbg !959, !tbaa !943
  %arrayidx = getelementptr inbounds [256 x %struct.crawlerstats_t], ptr %crawlerstats, i64 0, i64 %indvars.iv, !dbg !962
  %start_time12 = getelementptr inbounds i8, ptr %arrayidx, i64 520, !dbg !963
  store i32 %1, ptr %start_time12, align 8, !dbg !964, !tbaa !965
  %run_complete = getelementptr inbounds i8, ptr %arrayidx, i64 528, !dbg !968
  store i8 0, ptr %run_complete, align 8, !dbg !969, !tbaa !970
  %indvars.iv.next = or disjoint i64 %indvars.iv, 1, !dbg !971
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !918, metadata !DIExpression()), !dbg !955
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !918, metadata !DIExpression()), !dbg !955
  %2 = load volatile i32, ptr @current_time, align 4, !dbg !959, !tbaa !943
  %arrayidx.1 = getelementptr inbounds [256 x %struct.crawlerstats_t], ptr %crawlerstats, i64 0, i64 %indvars.iv.next, !dbg !962
  %start_time12.1 = getelementptr inbounds i8, ptr %arrayidx.1, i64 520, !dbg !963
  store i32 %2, ptr %start_time12.1, align 8, !dbg !964, !tbaa !965
  %run_complete.1 = getelementptr inbounds i8, ptr %arrayidx.1, i64 528, !dbg !968
  store i8 0, ptr %run_complete.1, align 8, !dbg !969, !tbaa !970
  %indvars.iv.next.1 = or disjoint i64 %indvars.iv, 2, !dbg !971
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.1, metadata !918, metadata !DIExpression()), !dbg !955
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.1, metadata !918, metadata !DIExpression()), !dbg !955
  %3 = load volatile i32, ptr @current_time, align 4, !dbg !959, !tbaa !943
  %arrayidx.2 = getelementptr inbounds [256 x %struct.crawlerstats_t], ptr %crawlerstats, i64 0, i64 %indvars.iv.next.1, !dbg !962
  %start_time12.2 = getelementptr inbounds i8, ptr %arrayidx.2, i64 520, !dbg !963
  store i32 %3, ptr %start_time12.2, align 8, !dbg !964, !tbaa !965
  %run_complete.2 = getelementptr inbounds i8, ptr %arrayidx.2, i64 528, !dbg !968
  store i8 0, ptr %run_complete.2, align 8, !dbg !969, !tbaa !970
  %indvars.iv.next.2 = or disjoint i64 %indvars.iv, 3, !dbg !971
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.2, metadata !918, metadata !DIExpression()), !dbg !955
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.2, metadata !918, metadata !DIExpression()), !dbg !955
  %4 = load volatile i32, ptr @current_time, align 4, !dbg !959, !tbaa !943
  %arrayidx.3 = getelementptr inbounds [256 x %struct.crawlerstats_t], ptr %crawlerstats, i64 0, i64 %indvars.iv.next.2, !dbg !962
  %start_time12.3 = getelementptr inbounds i8, ptr %arrayidx.3, i64 520, !dbg !963
  store i32 %4, ptr %start_time12.3, align 8, !dbg !964, !tbaa !965
  %run_complete.3 = getelementptr inbounds i8, ptr %arrayidx.3, i64 528, !dbg !968
  store i8 0, ptr %run_complete.3, align 8, !dbg !969, !tbaa !970
  %indvars.iv.next.3 = add nuw nsw i64 %indvars.iv, 4, !dbg !971
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.3, metadata !918, metadata !DIExpression()), !dbg !955
  %exitcond.not.3 = icmp eq i64 %indvars.iv.next.3, 256, !dbg !972
  br i1 %exitcond.not.3, label %for.cond.cleanup, label %for.body, !dbg !956, !llvm.loop !973

cleanup:                                          ; preds = %if.else, %for.cond.cleanup
  %retval.0 = phi i32 [ 0, %for.cond.cleanup ], [ -1, %if.else ], !dbg !920
  ret i32 %retval.0, !dbg !976
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal void @crawler_expired_eval(ptr nocapture noundef readonly %cm, ptr noundef %search, i32 noundef %hv, i32 noundef %i) #0 !dbg !977 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %cm, metadata !979, metadata !DIExpression()), !dbg !1000
  tail call void @llvm.dbg.value(metadata ptr %search, metadata !980, metadata !DIExpression()), !dbg !1000
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !981, metadata !DIExpression()), !dbg !1000
  tail call void @llvm.dbg.value(metadata i32 %i, metadata !982, metadata !DIExpression()), !dbg !1000
  %0 = load ptr, ptr %cm, align 8, !dbg !1001, !tbaa !948
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !983, metadata !DIExpression()), !dbg !1000
  %call = tail call i32 @pthread_mutex_lock(ptr noundef %0) #20, !dbg !1002
  %crawlerstats = getelementptr inbounds i8, ptr %0, i64 40, !dbg !1003
  %idxprom = sext i32 %i to i64, !dbg !1004
  %arrayidx = getelementptr inbounds [256 x %struct.crawlerstats_t], ptr %crawlerstats, i64 0, i64 %idxprom, !dbg !1004
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !984, metadata !DIExpression()), !dbg !1000
  %call1 = tail call i32 @item_is_flushed(ptr noundef %search) #20, !dbg !1005
  tail call void @llvm.dbg.value(metadata i32 %call1, metadata !986, metadata !DIExpression()), !dbg !1000
  tail call void @llvm.dbg.value(metadata i8 1, metadata !987, metadata !DIExpression()), !dbg !1000
  %it_flags = getelementptr inbounds i8, ptr %search, i64 38, !dbg !1006
  %1 = load i16, ptr %it_flags, align 2, !dbg !1006, !tbaa !1008
  %2 = and i16 %1, 128, !dbg !1010
  %tobool.not = icmp eq i16 %2, 0, !dbg !1010
  br i1 %tobool.not, label %if.end, label %if.then, !dbg !1011

if.then:                                          ; preds = %entry
  %3 = load ptr, ptr @storage, align 8, !dbg !1012, !tbaa !1014
  %call2 = tail call zeroext i1 @storage_validate_item(ptr noundef %3, ptr noundef nonnull %search) #20, !dbg !1015
  tail call void @llvm.dbg.value(metadata i1 %call2, metadata !987, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1000
  %4 = xor i1 %call2, true, !dbg !1016
  br label %if.end, !dbg !1017

if.end:                                           ; preds = %if.then, %entry
  %is_valid.0 = phi i1 [ %4, %if.then ], [ false, %entry ], !dbg !1000
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !987, metadata !DIExpression()), !dbg !1000
  %exptime = getelementptr inbounds i8, ptr %search, i64 28, !dbg !1018
  %5 = load i32, ptr %exptime, align 4, !dbg !1018, !tbaa !943
  %cmp.not = icmp eq i32 %5, 0, !dbg !1019
  br i1 %cmp.not, label %lor.lhs.false, label %land.lhs.true, !dbg !1020

land.lhs.true:                                    ; preds = %if.end
  %6 = load volatile i32, ptr @current_time, align 4, !dbg !1021, !tbaa !943
  %cmp5 = icmp ult i32 %5, %6, !dbg !1022
  %tobool7.not = icmp ne i32 %call1, 0
  %or.cond.not115 = select i1 %cmp5, i1 true, i1 %tobool7.not, !dbg !1016
  %brmerge = select i1 %or.cond.not115, i1 true, i1 %is_valid.0, !dbg !1016
  br i1 %brmerge, label %if.then10, label %if.else55, !dbg !1016

lor.lhs.false:                                    ; preds = %if.end
  %tobool7.not.old = icmp ne i32 %call1, 0, !dbg !1023
  %brmerge108 = select i1 %tobool7.not.old, i1 true, i1 %is_valid.0, !dbg !1024
  br i1 %brmerge108, label %if.then10, label %if.then53, !dbg !1024

if.then10:                                        ; preds = %lor.lhs.false, %land.lhs.true
  %arrayidx12 = getelementptr inbounds [256 x %struct.crawler], ptr @crawlers, i64 0, i64 %idxprom, !dbg !1025
  %reclaimed = getelementptr inbounds i8, ptr %arrayidx12, i64 48, !dbg !1026
  %7 = load i64, ptr %reclaimed, align 8, !dbg !1027, !tbaa !1028
  %inc = add i64 %7, 1, !dbg !1027
  store i64 %inc, ptr %reclaimed, align 8, !dbg !1027, !tbaa !1028
  %reclaimed13 = getelementptr inbounds i8, ptr %arrayidx, i64 504, !dbg !1030
  %8 = load i64, ptr %reclaimed13, align 8, !dbg !1031, !tbaa !1032
  %inc14 = add i64 %8, 1, !dbg !1031
  store i64 %inc14, ptr %reclaimed13, align 8, !dbg !1031, !tbaa !1032
  %9 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1033, !tbaa !1034
  %cmp15 = icmp sgt i32 %9, 1, !dbg !1037
  %.pre120 = load i16, ptr %it_flags, align 2, !dbg !1038, !tbaa !1008
  br i1 %cmp15, label %if.then17, label %if.end36, !dbg !1040

if.then17:                                        ; preds = %if.then10
  %data18 = getelementptr inbounds i8, ptr %search, i64 48, !dbg !1041
  %conv20 = zext i16 %.pre120 to i32, !dbg !1041
  %and21 = shl nuw nsw i32 %conv20, 2, !dbg !1041
  %10 = and i32 %and21, 8, !dbg !1041
  %cond = zext nneg i32 %10 to i64, !dbg !1041
  %add.ptr = getelementptr inbounds i8, ptr %data18, i64 %cond, !dbg !1041
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !993, metadata !DIExpression()), !dbg !1042
  %11 = load ptr, ptr @stderr, align 8, !dbg !1043, !tbaa !1014
  %slabs_clsid = getelementptr inbounds i8, ptr %search, i64 40, !dbg !1044
  %12 = load i8, ptr %slabs_clsid, align 8, !dbg !1044, !tbaa !1045
  %conv25 = zext i8 %12 to i32, !dbg !1046
  %call26 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %11, ptr noundef nonnull @.str.6, i32 noundef %conv20, i32 noundef %conv25) #21, !dbg !1047
  tail call void @llvm.dbg.value(metadata i32 0, metadata !988, metadata !DIExpression()), !dbg !1042
  %nkey = getelementptr inbounds i8, ptr %search, i64 41
  tail call void @llvm.dbg.value(metadata i32 0, metadata !988, metadata !DIExpression()), !dbg !1042
  %13 = load i8, ptr %nkey, align 1, !dbg !1048, !tbaa !1045
  %cmp28117.not = icmp eq i8 %13, 0, !dbg !1051
  br i1 %cmp28117.not, label %for.end, label %for.body, !dbg !1052

for.body:                                         ; preds = %if.then17, %for.body
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.body ], [ 0, %if.then17 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !988, metadata !DIExpression()), !dbg !1042
  %14 = load ptr, ptr @stderr, align 8, !dbg !1053, !tbaa !1014
  %arrayidx31 = getelementptr inbounds i8, ptr %add.ptr, i64 %indvars.iv, !dbg !1055
  %15 = load i8, ptr %arrayidx31, align 1, !dbg !1055, !tbaa !1045
  %conv32 = sext i8 %15 to i32, !dbg !1055
  %fputc106 = tail call i32 @fputc(i32 %conv32, ptr %14), !dbg !1056
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !1057
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !988, metadata !DIExpression()), !dbg !1042
  %16 = load i8, ptr %nkey, align 1, !dbg !1048, !tbaa !1045
  %17 = zext i8 %16 to i64, !dbg !1051
  %cmp28 = icmp ult i64 %indvars.iv.next, %17, !dbg !1051
  br i1 %cmp28, label %for.body, label %for.end, !dbg !1052, !llvm.loop !1058

for.end:                                          ; preds = %for.body, %if.then17
  %18 = load ptr, ptr @stderr, align 8, !dbg !1060, !tbaa !1014
  %fputc = tail call i32 @fputc(i32 10, ptr %18), !dbg !1061
  %.pre = load i16, ptr %it_flags, align 2, !dbg !1038, !tbaa !1008
  br label %if.end36, !dbg !1062

if.end36:                                         ; preds = %for.end, %if.then10
  %19 = phi i16 [ %.pre, %for.end ], [ %.pre120, %if.then10 ], !dbg !1038
  %20 = and i16 %19, 8, !dbg !1063
  %cmp40 = icmp eq i16 %20, 0, !dbg !1064
  %tobool43.not = icmp eq i32 %call1, 0
  %or.cond109 = select i1 %cmp40, i1 %tobool43.not, i1 false, !dbg !1065
  br i1 %or.cond109, label %if.then44, label %do.body, !dbg !1065

if.then44:                                        ; preds = %if.end36
  %unfetched = getelementptr inbounds i8, ptr %arrayidx12, i64 56, !dbg !1066
  %21 = load i64, ptr %unfetched, align 8, !dbg !1068, !tbaa !1069
  %inc47 = add i64 %21, 1, !dbg !1068
  store i64 %inc47, ptr %unfetched, align 8, !dbg !1068, !tbaa !1069
  br label %do.body, !dbg !1070

do.body:                                          ; preds = %if.end36, %if.then44
  %22 = load ptr, ptr @storage, align 8, !dbg !1071, !tbaa !1014
  tail call void @storage_delete(ptr noundef %22, ptr noundef nonnull %search) #20, !dbg !1071
  tail call void @do_item_unlink_nolock(ptr noundef nonnull %search, i32 noundef %hv) #20, !dbg !1073
  tail call void @do_item_remove(ptr noundef nonnull %search) #20, !dbg !1074
  br label %if.end73, !dbg !1075

if.then53:                                        ; preds = %lor.lhs.false
  %seen110 = getelementptr inbounds i8, ptr %arrayidx, i64 512, !dbg !1076
  %23 = load i64, ptr %seen110, align 8, !dbg !1077, !tbaa !1078
  %inc49111 = add i64 %23, 1, !dbg !1077
  store i64 %inc49111, ptr %seen110, align 8, !dbg !1077, !tbaa !1078
  %refcount112 = getelementptr inbounds i8, ptr %search, i64 36, !dbg !1079
  %24 = load i16, ptr %refcount112, align 4, !dbg !1079, !tbaa !1008
  %dec113 = add i16 %24, -1, !dbg !1079
  store i16 %dec113, ptr %refcount112, align 4, !dbg !1079, !tbaa !1008
  %noexp = getelementptr inbounds i8, ptr %arrayidx, i64 496, !dbg !1080
  %25 = load i64, ptr %noexp, align 8, !dbg !1082, !tbaa !1083
  %inc54 = add i64 %25, 1, !dbg !1082
  store i64 %inc54, ptr %noexp, align 8, !dbg !1082, !tbaa !1083
  br label %if.end73, !dbg !1084

if.else55:                                        ; preds = %land.lhs.true
  %seen = getelementptr inbounds i8, ptr %arrayidx, i64 512, !dbg !1076
  %26 = load i64, ptr %seen, align 8, !dbg !1077, !tbaa !1078
  %inc49 = add i64 %26, 1, !dbg !1077
  store i64 %inc49, ptr %seen, align 8, !dbg !1077, !tbaa !1078
  %refcount = getelementptr inbounds i8, ptr %search, i64 36, !dbg !1079
  %27 = load i16, ptr %refcount, align 4, !dbg !1079, !tbaa !1008
  %dec = add i16 %27, -1, !dbg !1079
  store i16 %dec, ptr %refcount, align 4, !dbg !1079, !tbaa !1008
  %28 = load volatile i32, ptr @current_time, align 4, !dbg !1085, !tbaa !943
  %sub = sub i32 %5, %28, !dbg !1086
  %cmp57 = icmp ugt i32 %sub, 3599, !dbg !1087
  br i1 %cmp57, label %if.then59, label %if.else61, !dbg !1088

if.then59:                                        ; preds = %if.else55
  %ttl_hourplus = getelementptr inbounds i8, ptr %arrayidx, i64 488, !dbg !1089
  %29 = load i64, ptr %ttl_hourplus, align 8, !dbg !1091, !tbaa !1092
  %inc60 = add i64 %29, 1, !dbg !1091
  store i64 %inc60, ptr %ttl_hourplus, align 8, !dbg !1091, !tbaa !1092
  br label %if.end73, !dbg !1093

if.else61:                                        ; preds = %if.else55
  %30 = load volatile i32, ptr @current_time, align 4, !dbg !1094, !tbaa !943
  %sub63 = sub i32 %5, %30, !dbg !1095
  tail call void @llvm.dbg.value(metadata i32 %sub63, metadata !994, metadata !DIExpression()), !dbg !1096
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !999, metadata !DIExpression()), !dbg !1096
  %cmp64 = icmp ult i32 %sub63, 3660, !dbg !1097
  br i1 %cmp64, label %if.then66, label %if.end73, !dbg !1099

if.then66:                                        ; preds = %if.else61
  %div.lhs.trunc = trunc nuw i32 %sub63 to i16, !dbg !1100
  %div114 = udiv i16 %div.lhs.trunc, 60, !dbg !1100
  %idxprom67 = zext nneg i16 %div114 to i64
  tail call void @llvm.dbg.value(metadata i64 %idxprom67, metadata !999, metadata !DIExpression()), !dbg !1096
  %arrayidx68 = getelementptr inbounds [61 x i64], ptr %arrayidx, i64 0, i64 %idxprom67, !dbg !1101
  %31 = load i64, ptr %arrayidx68, align 8, !dbg !1103, !tbaa !1104
  %inc69 = add i64 %31, 1, !dbg !1103
  store i64 %inc69, ptr %arrayidx68, align 8, !dbg !1103, !tbaa !1104
  br label %if.end73, !dbg !1105

if.end73:                                         ; preds = %if.else61, %if.then66, %if.then53, %if.then59, %do.body
  %call75 = tail call i32 @pthread_mutex_unlock(ptr noundef %0) #20, !dbg !1106
  ret void, !dbg !1107
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal void @crawler_expired_doneclass(ptr nocapture noundef readonly %cm, i32 noundef %slab_cls) #0 !dbg !1108 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %cm, metadata !1110, metadata !DIExpression()), !dbg !1113
  tail call void @llvm.dbg.value(metadata i32 %slab_cls, metadata !1111, metadata !DIExpression()), !dbg !1113
  %0 = load ptr, ptr %cm, align 8, !dbg !1114, !tbaa !948
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1112, metadata !DIExpression()), !dbg !1113
  %call = tail call i32 @pthread_mutex_lock(ptr noundef %0) #20, !dbg !1115
  %1 = load volatile i32, ptr @current_time, align 4, !dbg !1116, !tbaa !943
  %crawlerstats = getelementptr inbounds i8, ptr %0, i64 40, !dbg !1117
  %idxprom = sext i32 %slab_cls to i64, !dbg !1118
  %arrayidx = getelementptr inbounds [256 x %struct.crawlerstats_t], ptr %crawlerstats, i64 0, i64 %idxprom, !dbg !1118
  %end_time = getelementptr inbounds i8, ptr %arrayidx, i64 524, !dbg !1119
  store i32 %1, ptr %end_time, align 4, !dbg !1120, !tbaa !1121
  %run_complete = getelementptr inbounds i8, ptr %arrayidx, i64 528, !dbg !1122
  store i8 1, ptr %run_complete, align 8, !dbg !1123, !tbaa !970
  %call5 = tail call i32 @pthread_mutex_unlock(ptr noundef %0) #20, !dbg !1124
  ret void, !dbg !1125
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal void @crawler_expired_finalize(ptr nocapture noundef readonly %cm) #0 !dbg !1126 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %cm, metadata !1128, metadata !DIExpression()), !dbg !1130
  %0 = load ptr, ptr %cm, align 8, !dbg !1131, !tbaa !948
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1129, metadata !DIExpression()), !dbg !1130
  %call = tail call i32 @pthread_mutex_lock(ptr noundef %0) #20, !dbg !1132
  %1 = load volatile i32, ptr @current_time, align 4, !dbg !1133, !tbaa !943
  %end_time = getelementptr inbounds i8, ptr %0, i64 137260, !dbg !1134
  store i32 %1, ptr %end_time, align 4, !dbg !1135, !tbaa !1136
  %crawl_complete = getelementptr inbounds i8, ptr %0, i64 137264, !dbg !1137
  store i8 1, ptr %crawl_complete, align 8, !dbg !1138, !tbaa !1139
  %call2 = tail call i32 @pthread_mutex_unlock(ptr noundef %0) #20, !dbg !1140
  %is_external = getelementptr inbounds i8, ptr %0, i64 137265, !dbg !1141
  %2 = load i8, ptr %is_external, align 1, !dbg !1141, !tbaa !927, !range !1143, !noundef !1144
  %tobool = trunc nuw i8 %2 to i1, !dbg !1141
  br i1 %tobool, label %if.end, label %if.then, !dbg !1145

if.then:                                          ; preds = %entry
  tail call void @free(ptr noundef nonnull %0) #20, !dbg !1146
  br label %if.end, !dbg !1148

if.end:                                           ; preds = %if.then, %entry
  ret void, !dbg !1149
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: write) uwtable
define internal noundef i32 @crawler_metadump_init(ptr nocapture noundef writeonly %cm, ptr nocapture readnone %data) #1 !dbg !1150 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %cm, metadata !1152, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1153, metadata !DIExpression()), !dbg !1154
  %status = getelementptr inbounds i8, ptr %cm, i64 48, !dbg !1155
  store i32 0, ptr %status, align 8, !dbg !1156, !tbaa !1157
  ret i32 0, !dbg !1158
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal void @crawler_metadump_eval(ptr nocapture noundef %cm, ptr noundef %it, i32 %hv, i32 %i) #0 !dbg !1159 {
entry:
  %keybuf = alloca [751 x i8], align 16, !DIAssignID !1172
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1165, metadata !DIExpression(), metadata !1172, metadata ptr %keybuf, metadata !DIExpression()), !dbg !1173
  tail call void @llvm.dbg.value(metadata ptr %cm, metadata !1161, metadata !DIExpression()), !dbg !1173
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1162, metadata !DIExpression()), !dbg !1173
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1163, metadata !DIExpression()), !dbg !1173
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1164, metadata !DIExpression()), !dbg !1173
  call void @llvm.lifetime.start.p0(i64 751, ptr nonnull %keybuf) #20, !dbg !1174
  %call = tail call i32 @item_is_flushed(ptr noundef %it) #20, !dbg !1175
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !1169, metadata !DIExpression()), !dbg !1173
  %exptime = getelementptr inbounds i8, ptr %it, i64 28, !dbg !1176
  %0 = load i32, ptr %exptime, align 4, !dbg !1176, !tbaa !943
  %cmp.not = icmp eq i32 %0, 0, !dbg !1178
  br i1 %cmp.not, label %lor.lhs.false, label %land.lhs.true, !dbg !1179

land.lhs.true:                                    ; preds = %entry
  %1 = load volatile i32, ptr @current_time, align 4, !dbg !1180, !tbaa !943
  %cmp2 = icmp uge i32 %0, %1, !dbg !1181
  %tobool.not = icmp eq i32 %call, 0
  %or.cond = select i1 %cmp2, i1 %tobool.not, i1 false, !dbg !1182
  br i1 %or.cond, label %if.end, label %if.then, !dbg !1182

lor.lhs.false:                                    ; preds = %entry
  %tobool.not.old = icmp eq i32 %call, 0, !dbg !1183
  br i1 %tobool.not.old, label %if.end, label %if.then, !dbg !1184

if.then:                                          ; preds = %lor.lhs.false, %land.lhs.true
  %refcount = getelementptr inbounds i8, ptr %it, i64 36, !dbg !1185
  %2 = load i16, ptr %refcount, align 4, !dbg !1185, !tbaa !1008
  %dec = add i16 %2, -1, !dbg !1185
  store i16 %dec, ptr %refcount, align 4, !dbg !1185, !tbaa !1008
  br label %cleanup85, !dbg !1187

if.end:                                           ; preds = %land.lhs.true, %lor.lhs.false
  %it_flags = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1188
  %3 = load i16, ptr %it_flags, align 2, !dbg !1188, !tbaa !1008
  %conv = zext i16 %3 to i32, !dbg !1188
  %and = and i32 %conv, 256, !dbg !1188
  %tobool3.not = icmp eq i32 %and, 0, !dbg !1188
  br i1 %tobool3.not, label %if.end.if.end12_crit_edge, label %if.then4, !dbg !1191

if.end.if.end12_crit_edge:                        ; preds = %if.end
  %nkey20.phi.trans.insert = getelementptr inbounds i8, ptr %it, i64 41
  %.pre = load i8, ptr %nkey20.phi.trans.insert, align 1, !dbg !1192, !tbaa !1045
  %.pre117 = zext i8 %.pre to i64, !dbg !1193
  br label %if.end12, !dbg !1191

if.then4:                                         ; preds = %if.end
  %data = getelementptr inbounds i8, ptr %it, i64 48, !dbg !1194
  %nkey = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1194
  %4 = load i8, ptr %nkey, align 1, !dbg !1194, !tbaa !1045
  %idx.ext = zext i8 %4 to i64
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %idx.ext, !dbg !1194
  %add.ptr6 = getelementptr inbounds i8, ptr %add.ptr, i64 1, !dbg !1194
  %and9 = shl nuw nsw i32 %conv, 2, !dbg !1194
  %5 = and i32 %and9, 8, !dbg !1194
  %cond = zext nneg i32 %5 to i64, !dbg !1194
  %add.ptr11 = getelementptr inbounds i8, ptr %add.ptr6, i64 %cond, !dbg !1194
  %6 = load i32, ptr %add.ptr11, align 4, !dbg !1194, !tbaa !943
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !1170, metadata !DIExpression()), !dbg !1173
  %7 = zext i32 %6 to i64, !dbg !1196
  br label %if.end12, !dbg !1194

if.end12:                                         ; preds = %if.end.if.end12_crit_edge, %if.then4
  %conv21.pre-phi = phi i64 [ %.pre117, %if.end.if.end12_crit_edge ], [ %idx.ext, %if.then4 ], !dbg !1193
  %flags.0 = phi i64 [ 0, %if.end.if.end12_crit_edge ], [ %7, %if.then4 ], !dbg !1188
  tail call void @llvm.dbg.value(metadata i64 %flags.0, metadata !1170, metadata !DIExpression()), !dbg !1173
  %data13 = getelementptr inbounds i8, ptr %it, i64 48, !dbg !1197
  %8 = shl i16 %3, 2, !dbg !1197
  %9 = and i16 %8, 8, !dbg !1197
  %cond18 = zext nneg i16 %9 to i64, !dbg !1197
  %add.ptr19 = getelementptr inbounds i8, ptr %data13, i64 %cond18, !dbg !1197
  %nkey20 = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1192
  %call22 = call zeroext i1 @uriencode(ptr noundef nonnull %add.ptr19, ptr noundef nonnull %keybuf, i64 noundef %conv21.pre-phi, i64 noundef 751) #20, !dbg !1198
  %buf = getelementptr inbounds i8, ptr %cm, i64 32, !dbg !1199
  %10 = load ptr, ptr %buf, align 8, !dbg !1199, !tbaa !1200
  %bufused = getelementptr inbounds i8, ptr %cm, i64 24, !dbg !1201
  %11 = load i32, ptr %bufused, align 8, !dbg !1201, !tbaa !1202
  %idx.ext24 = sext i32 %11 to i64, !dbg !1203
  %add.ptr25 = getelementptr inbounds i8, ptr %10, i64 %idx.ext24, !dbg !1203
  %12 = load i32, ptr %exptime, align 4, !dbg !1204, !tbaa !943
  %cmp28 = icmp eq i32 %12, 0, !dbg !1205
  %.pre116 = load i64, ptr @process_started, align 8, !dbg !1206, !tbaa !1104
  %conv31 = zext i32 %12 to i64, !dbg !1207
  %add = add nsw i64 %.pre116, %conv31, !dbg !1207
  %cond32 = select i1 %cmp28, i64 -1, i64 %add, !dbg !1207
  %time = getelementptr inbounds i8, ptr %it, i64 24, !dbg !1208
  %13 = load i32, ptr %time, align 8, !dbg !1208, !tbaa !943
  %conv33 = zext i32 %13 to i64, !dbg !1209
  %add34 = add nsw i64 %.pre116, %conv33, !dbg !1210
  %14 = load i16, ptr %it_flags, align 2, !dbg !1211, !tbaa !1008
  %15 = and i16 %14, 2, !dbg !1211
  %tobool38.not = icmp eq i16 %15, 0, !dbg !1211
  br i1 %tobool38.not, label %cond.end43, label %cond.true39, !dbg !1211

cond.true39:                                      ; preds = %if.end12
  %16 = load i64, ptr %data13, align 8, !dbg !1211, !tbaa !1045
  br label %cond.end43, !dbg !1211

cond.end43:                                       ; preds = %if.end12, %cond.true39
  %cond44 = phi i64 [ %16, %cond.true39 ], [ 0, %if.end12 ], !dbg !1211
  %conv46 = zext i16 %14 to i32, !dbg !1212
  %and47 = and i32 %conv46, 8, !dbg !1213
  %tobool48.not = icmp eq i32 %and47, 0, !dbg !1214
  %cond49 = select i1 %tobool48.not, ptr @.str.11, ptr @.str.10, !dbg !1214
  %slabs_clsid = getelementptr inbounds i8, ptr %it, i64 40, !dbg !1215
  %17 = load i8, ptr %slabs_clsid, align 8, !dbg !1215, !tbaa !1045
  %18 = and i8 %17, 63, !dbg !1215
  %and51 = zext nneg i8 %18 to i32, !dbg !1215
  %19 = load i8, ptr %nkey20, align 1, !dbg !1216, !tbaa !1045
  %conv53 = zext i8 %19 to i64, !dbg !1216
  %nbytes = getelementptr inbounds i8, ptr %it, i64 32, !dbg !1216
  %20 = load i32, ptr %nbytes, align 8, !dbg !1216, !tbaa !943
  %conv56 = sext i32 %20 to i64, !dbg !1216
  %and60 = lshr i32 %conv46, 6, !dbg !1216
  %21 = and i32 %and60, 4, !dbg !1216
  %and66 = shl nuw nsw i32 %conv46, 2, !dbg !1216
  %22 = and i32 %and66, 8, !dbg !1216
  %23 = or disjoint i32 %21, %22, !dbg !1216
  %add57115 = or disjoint i32 %23, 49, !dbg !1216
  %add57 = zext nneg i32 %add57115 to i64, !dbg !1216
  %add63 = add nuw nsw i64 %add57, %conv53, !dbg !1216
  %add69 = add nsw i64 %add63, %conv56, !dbg !1216
  %call71 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %add.ptr25, i64 noundef 4096, ptr noundef nonnull @.str.9, ptr noundef nonnull %keybuf, i64 noundef %cond32, i64 noundef %add34, i64 noundef %cond44, ptr noundef nonnull %cond49, i32 noundef %and51, i64 noundef %add69, i64 noundef %flags.0) #20, !dbg !1217
  tail call void @llvm.dbg.value(metadata i32 %call71, metadata !1171, metadata !DIExpression()), !dbg !1173
  %refcount72 = getelementptr inbounds i8, ptr %it, i64 36, !dbg !1218
  %24 = load i16, ptr %refcount72, align 4, !dbg !1218, !tbaa !1008
  %dec73 = add i16 %24, -1, !dbg !1218
  store i16 %dec73, ptr %refcount72, align 4, !dbg !1218, !tbaa !1008
  %25 = add i32 %call71, -8191, !dbg !1219
  %or.cond114 = icmp ult i32 %25, -8190, !dbg !1219
  br i1 %or.cond114, label %cleanup85, label %if.end80, !dbg !1219

if.end80:                                         ; preds = %cond.end43
  %26 = load i32, ptr %bufused, align 8, !dbg !1221, !tbaa !1202
  %add83 = add nsw i32 %26, %call71, !dbg !1221
  store i32 %add83, ptr %bufused, align 8, !dbg !1221, !tbaa !1202
  br label %cleanup85, !dbg !1222

cleanup85:                                        ; preds = %if.end80, %cond.end43, %if.then
  call void @llvm.lifetime.end.p0(i64 751, ptr nonnull %keybuf) #20, !dbg !1222
  ret void, !dbg !1222
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal void @crawler_metadump_finalize(ptr nocapture noundef %cm) #0 !dbg !1223 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %cm, metadata !1225, metadata !DIExpression()), !dbg !1236
  %c = getelementptr inbounds i8, ptr %cm, i64 8, !dbg !1237
  %0 = load ptr, ptr %c, align 8, !dbg !1238, !tbaa !1239
  %cmp.not = icmp eq ptr %0, null, !dbg !1240
  br i1 %cmp.not, label %if.end17, label %if.then, !dbg !1241

if.then:                                          ; preds = %entry
  %call = tail call fastcc i32 @lru_crawler_write(ptr noundef nonnull %c), !dbg !1242
  %cmp3 = icmp eq i32 %call, 0, !dbg !1243
  br i1 %cmp3, label %if.then4, label %if.end17, !dbg !1244

if.then4:                                         ; preds = %if.then
  %status = getelementptr inbounds i8, ptr %cm, i64 48, !dbg !1245
  %1 = load i32, ptr %status, align 8, !dbg !1245, !tbaa !1157
  %cmp5.not = icmp eq i32 %1, 0, !dbg !1246
  %buf12 = getelementptr inbounds i8, ptr %cm, i64 32, !dbg !1247
  %2 = load ptr, ptr %buf12, align 8, !dbg !1247, !tbaa !1200
  %bufused14 = getelementptr inbounds i8, ptr %cm, i64 24, !dbg !1247
  br i1 %cmp5.not, label %if.else, label %if.then6, !dbg !1248

if.then6:                                         ; preds = %if.then4
  tail call void @llvm.dbg.value(metadata ptr @.str.12, metadata !1226, metadata !DIExpression()), !dbg !1249
  tail call void @llvm.dbg.value(metadata i64 30, metadata !1235, metadata !DIExpression()), !dbg !1249
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(30) %2, ptr noundef nonnull align 1 dereferenceable(30) @.str.12, i64 30, i1 false), !dbg !1250
  br label %if.end17.sink.split, !dbg !1251

if.else:                                          ; preds = %if.then4
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %2, ptr noundef nonnull align 1 dereferenceable(5) @.str.13, i64 5, i1 false), !dbg !1252
  br label %if.end17.sink.split

if.end17.sink.split:                              ; preds = %if.then6, %if.else
  %.sink26 = phi i32 [ 5, %if.else ], [ 30, %if.then6 ]
  %3 = load i32, ptr %bufused14, align 8, !dbg !1247, !tbaa !1202
  %add15 = add i32 %3, %.sink26, !dbg !1247
  store i32 %add15, ptr %bufused14, align 8, !dbg !1247, !tbaa !1202
  br label %if.end17, !dbg !1254

if.end17:                                         ; preds = %if.end17.sink.split, %if.then, %entry
  ret void, !dbg !1254
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: write) uwtable
define internal noundef i32 @crawler_mgdump_init(ptr nocapture noundef writeonly %cm, ptr nocapture readnone %data) #1 !dbg !1255 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %cm, metadata !1257, metadata !DIExpression()), !dbg !1259
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1258, metadata !DIExpression()), !dbg !1259
  %status = getelementptr inbounds i8, ptr %cm, i64 48, !dbg !1260
  store i32 0, ptr %status, align 8, !dbg !1261, !tbaa !1157
  ret i32 0, !dbg !1262
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal void @crawler_mgdump_eval(ptr nocapture noundef %cm, ptr noundef %it, i32 %hv, i32 %i) #0 !dbg !1263 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %cm, metadata !1265, metadata !DIExpression()), !dbg !1273
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1266, metadata !DIExpression()), !dbg !1273
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1267, metadata !DIExpression()), !dbg !1273
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1268, metadata !DIExpression()), !dbg !1273
  %call = tail call i32 @item_is_flushed(ptr noundef %it) #20, !dbg !1274
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !1269, metadata !DIExpression()), !dbg !1273
  %exptime = getelementptr inbounds i8, ptr %it, i64 28, !dbg !1275
  %0 = load i32, ptr %exptime, align 4, !dbg !1275, !tbaa !943
  %cmp.not = icmp eq i32 %0, 0, !dbg !1277
  br i1 %cmp.not, label %lor.lhs.false, label %land.lhs.true, !dbg !1278

land.lhs.true:                                    ; preds = %entry
  %1 = load volatile i32, ptr @current_time, align 4, !dbg !1279, !tbaa !943
  %cmp2 = icmp uge i32 %0, %1, !dbg !1280
  %tobool.not = icmp eq i32 %call, 0
  %or.cond = select i1 %cmp2, i1 %tobool.not, i1 false, !dbg !1281
  br i1 %or.cond, label %if.end, label %if.then, !dbg !1281

lor.lhs.false:                                    ; preds = %entry
  %tobool.not.old = icmp eq i32 %call, 0, !dbg !1282
  br i1 %tobool.not.old, label %if.end, label %if.then, !dbg !1283

if.then:                                          ; preds = %lor.lhs.false, %land.lhs.true
  %refcount = getelementptr inbounds i8, ptr %it, i64 36, !dbg !1284
  %2 = load i16, ptr %refcount, align 4, !dbg !1284, !tbaa !1008
  %dec = add i16 %2, -1, !dbg !1284
  store i16 %dec, ptr %refcount, align 4, !dbg !1284, !tbaa !1008
  br label %cleanup, !dbg !1286

if.end:                                           ; preds = %land.lhs.true, %lor.lhs.false
  %buf = getelementptr inbounds i8, ptr %cm, i64 32, !dbg !1287
  %3 = load ptr, ptr %buf, align 8, !dbg !1287, !tbaa !1200
  %bufused = getelementptr inbounds i8, ptr %cm, i64 24, !dbg !1288
  %4 = load i32, ptr %bufused, align 8, !dbg !1288, !tbaa !1202
  %idx.ext = sext i32 %4 to i64, !dbg !1289
  %add.ptr = getelementptr inbounds i8, ptr %3, i64 %idx.ext, !dbg !1289
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !1270, metadata !DIExpression()), !dbg !1273
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !1271, metadata !DIExpression()), !dbg !1273
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %add.ptr, ptr noundef nonnull align 1 dereferenceable(3) @.str.14, i64 3, i1 false), !dbg !1290
  %add.ptr4 = getelementptr inbounds i8, ptr %add.ptr, i64 3, !dbg !1291
  tail call void @llvm.dbg.value(metadata ptr %add.ptr4, metadata !1270, metadata !DIExpression()), !dbg !1273
  %it_flags = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1292
  %5 = load i16, ptr %it_flags, align 2, !dbg !1292, !tbaa !1008
  %conv = zext i16 %5 to i32, !dbg !1294
  %and = and i32 %conv, 4096, !dbg !1295
  %tobool5.not = icmp eq i32 %and, 0, !dbg !1295
  %data16 = getelementptr inbounds i8, ptr %it, i64 48, !dbg !1296
  %and19 = shl nuw nsw i32 %conv, 2, !dbg !1296
  %6 = and i32 %and19, 8, !dbg !1296
  %cond21 = zext nneg i32 %6 to i64, !dbg !1296
  %add.ptr22 = getelementptr inbounds i8, ptr %data16, i64 %cond21, !dbg !1296
  %nkey23 = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1296
  %7 = load i8, ptr %nkey23, align 1, !dbg !1296, !tbaa !1045
  %conv24 = zext i8 %7 to i64, !dbg !1296
  br i1 %tobool5.not, label %if.else, label %if.then6, !dbg !1297

if.then6:                                         ; preds = %if.end
  %call13 = tail call i64 @base64_encode(ptr noundef nonnull %add.ptr22, i64 noundef %conv24, ptr noundef nonnull %add.ptr4, i64 noundef 4096) #20, !dbg !1298
  %add.ptr14 = getelementptr inbounds i8, ptr %add.ptr4, i64 %call13, !dbg !1300
  tail call void @llvm.dbg.value(metadata ptr %add.ptr14, metadata !1270, metadata !DIExpression()), !dbg !1273
  store i32 168649248, ptr %add.ptr14, align 1, !dbg !1301
  %add.ptr15 = getelementptr inbounds i8, ptr %add.ptr14, i64 4, !dbg !1302
  tail call void @llvm.dbg.value(metadata ptr %add.ptr15, metadata !1270, metadata !DIExpression()), !dbg !1273
  br label %if.end30, !dbg !1303

if.else:                                          ; preds = %if.end
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr4, ptr nonnull align 1 %add.ptr22, i64 %conv24, i1 false), !dbg !1304
  %8 = load i8, ptr %nkey23, align 1, !dbg !1306, !tbaa !1045
  %idx.ext27 = zext i8 %8 to i64
  %add.ptr28 = getelementptr inbounds i8, ptr %add.ptr4, i64 %idx.ext27, !dbg !1307
  tail call void @llvm.dbg.value(metadata ptr %add.ptr28, metadata !1270, metadata !DIExpression()), !dbg !1273
  store i16 2573, ptr %add.ptr28, align 1, !dbg !1308
  %add.ptr29 = getelementptr inbounds i8, ptr %add.ptr28, i64 2, !dbg !1309
  tail call void @llvm.dbg.value(metadata ptr %add.ptr29, metadata !1270, metadata !DIExpression()), !dbg !1273
  br label %if.end30

if.end30:                                         ; preds = %if.else, %if.then6
  %p.0 = phi ptr [ %add.ptr15, %if.then6 ], [ %add.ptr29, %if.else ], !dbg !1296
  tail call void @llvm.dbg.value(metadata ptr %p.0, metadata !1270, metadata !DIExpression()), !dbg !1273
  %sub.ptr.lhs.cast = ptrtoint ptr %p.0 to i64, !dbg !1310
  %sub.ptr.rhs.cast = ptrtoint ptr %add.ptr to i64, !dbg !1310
  %sub.ptr.sub = sub i64 %sub.ptr.lhs.cast, %sub.ptr.rhs.cast, !dbg !1310
  %conv31 = trunc i64 %sub.ptr.sub to i32, !dbg !1311
  tail call void @llvm.dbg.value(metadata i32 %conv31, metadata !1272, metadata !DIExpression()), !dbg !1273
  %refcount32 = getelementptr inbounds i8, ptr %it, i64 36, !dbg !1312
  %9 = load i16, ptr %refcount32, align 4, !dbg !1312, !tbaa !1008
  %dec33 = add i16 %9, -1, !dbg !1312
  store i16 %dec33, ptr %refcount32, align 4, !dbg !1312, !tbaa !1008
  %10 = load i32, ptr %bufused, align 8, !dbg !1313, !tbaa !1202
  %add = add nsw i32 %10, %conv31, !dbg !1313
  store i32 %add, ptr %bufused, align 8, !dbg !1313, !tbaa !1202
  br label %cleanup, !dbg !1314

cleanup:                                          ; preds = %if.end30, %if.then
  ret void, !dbg !1314
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal void @crawler_mgdump_finalize(ptr nocapture noundef %cm) #0 !dbg !1315 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %cm, metadata !1317, metadata !DIExpression()), !dbg !1326
  %c = getelementptr inbounds i8, ptr %cm, i64 8, !dbg !1327
  %0 = load ptr, ptr %c, align 8, !dbg !1328, !tbaa !1239
  %cmp.not = icmp eq ptr %0, null, !dbg !1329
  br i1 %cmp.not, label %if.end17, label %if.then, !dbg !1330

if.then:                                          ; preds = %entry
  %call = tail call fastcc i32 @lru_crawler_write(ptr noundef nonnull %c), !dbg !1331
  %cmp3 = icmp eq i32 %call, 0, !dbg !1332
  br i1 %cmp3, label %if.then4, label %if.end17, !dbg !1333

if.then4:                                         ; preds = %if.then
  %status = getelementptr inbounds i8, ptr %cm, i64 48, !dbg !1334
  %1 = load i32, ptr %status, align 8, !dbg !1334, !tbaa !1157
  %cmp5.not = icmp eq i32 %1, 0, !dbg !1335
  %buf12 = getelementptr inbounds i8, ptr %cm, i64 32, !dbg !1336
  %2 = load ptr, ptr %buf12, align 8, !dbg !1336, !tbaa !1200
  %bufused14 = getelementptr inbounds i8, ptr %cm, i64 24, !dbg !1336
  br i1 %cmp5.not, label %if.else, label %if.then6, !dbg !1337

if.then6:                                         ; preds = %if.then4
  tail call void @llvm.dbg.value(metadata ptr @.str.12, metadata !1318, metadata !DIExpression()), !dbg !1338
  tail call void @llvm.dbg.value(metadata i64 30, metadata !1325, metadata !DIExpression()), !dbg !1338
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(30) %2, ptr noundef nonnull align 1 dereferenceable(30) @.str.12, i64 30, i1 false), !dbg !1339
  br label %if.end17.sink.split, !dbg !1340

if.else:                                          ; preds = %if.then4
  store i32 168644165, ptr %2, align 1, !dbg !1341
  br label %if.end17.sink.split

if.end17.sink.split:                              ; preds = %if.then6, %if.else
  %.sink26 = phi i32 [ 4, %if.else ], [ 30, %if.then6 ]
  %3 = load i32, ptr %bufused14, align 8, !dbg !1336, !tbaa !1202
  %add15 = add i32 %3, %.sink26, !dbg !1336
  store i32 %add15, ptr %bufused14, align 8, !dbg !1336, !tbaa !1202
  br label %if.end17, !dbg !1343

if.end17:                                         ; preds = %if.end17.sink.split, %if.then, %entry
  ret void, !dbg !1343
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 -1, 1) i32 @stop_item_crawler_thread(i1 noundef zeroext %wait) local_unnamed_addr #0 !dbg !1344 {
entry:
  tail call void @llvm.dbg.value(metadata i1 %wait, metadata !1348, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1350
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1351
  %0 = load volatile i32, ptr @do_run_lru_crawler_thread, align 4, !dbg !1352, !tbaa !943
  %cmp = icmp eq i32 %0, 0, !dbg !1354
  br i1 %cmp, label %if.then, label %if.end, !dbg !1355

if.then:                                          ; preds = %entry
  %call1 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1356
  br label %cleanup, !dbg !1358

if.end:                                           ; preds = %entry
  store volatile i32 0, ptr @do_run_lru_crawler_thread, align 4, !dbg !1359, !tbaa !943
  %call2 = tail call i32 @pthread_cond_signal(ptr noundef nonnull @lru_crawler_cond) #20, !dbg !1360
  %call3 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1361
  br i1 %wait, label %land.lhs.true, label %cleanup, !dbg !1362

land.lhs.true:                                    ; preds = %if.end
  %1 = load i64, ptr @item_crawler_tid, align 8, !dbg !1364, !tbaa !1104
  %call4 = tail call i32 @pthread_join(i64 noundef %1, ptr noundef null) #20, !dbg !1365
  tail call void @llvm.dbg.value(metadata i32 %call4, metadata !1349, metadata !DIExpression()), !dbg !1350
  %cmp5.not = icmp eq i32 %call4, 0, !dbg !1366
  br i1 %cmp5.not, label %cleanup, label %if.then6, !dbg !1367

if.then6:                                         ; preds = %land.lhs.true
  %2 = load ptr, ptr @stderr, align 8, !dbg !1368, !tbaa !1014
  %call7 = tail call ptr @strerror(i32 noundef %call4) #20, !dbg !1370
  %call8 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %2, ptr noundef nonnull @.str, ptr noundef %call7) #21, !dbg !1371
  br label %cleanup, !dbg !1372

cleanup:                                          ; preds = %if.end, %land.lhs.true, %if.then6, %if.then
  %retval.0 = phi i32 [ 0, %if.then ], [ -1, %if.then6 ], [ 0, %land.lhs.true ], [ 0, %if.end ], !dbg !1350
  ret i32 %retval.0, !dbg !1373
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: nounwind
declare !dbg !1374 i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #3

; Function Attrs: nounwind
declare !dbg !1379 i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #3

; Function Attrs: nounwind
declare !dbg !1380 i32 @pthread_cond_signal(ptr noundef) local_unnamed_addr #3

declare !dbg !1384 i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: nofree nounwind
declare !dbg !1388 noundef i32 @fprintf(ptr nocapture noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #5

; Function Attrs: nounwind
declare !dbg !1447 ptr @strerror(i32 noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 -1, 1) i32 @start_item_crawler_thread() local_unnamed_addr #0 !dbg !1451 {
entry:
  %0 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 27), align 2, !dbg !1456, !tbaa !1458, !range !1143, !noundef !1144
  %tobool = trunc nuw i8 %0 to i1, !dbg !1456
  br i1 %tobool, label %cleanup, label %if.end, !dbg !1459

if.end:                                           ; preds = %entry
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1460
  store volatile i32 1, ptr @do_run_lru_crawler_thread, align 4, !dbg !1461, !tbaa !943
  %call1 = tail call i32 @pthread_create(ptr noundef nonnull @item_crawler_tid, ptr noundef null, ptr noundef nonnull @item_crawler_thread, ptr noundef null) #20, !dbg !1462
  tail call void @llvm.dbg.value(metadata i32 %call1, metadata !1455, metadata !DIExpression()), !dbg !1464
  %cmp.not = icmp eq i32 %call1, 0, !dbg !1465
  br i1 %cmp.not, label %if.end6, label %if.then2, !dbg !1466

if.then2:                                         ; preds = %if.end
  %1 = load ptr, ptr @stderr, align 8, !dbg !1467, !tbaa !1014
  %call3 = tail call ptr @strerror(i32 noundef %call1) #20, !dbg !1469
  %call4 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %1, ptr noundef nonnull @.str.1, ptr noundef %call3) #21, !dbg !1470
  br label %cleanup.sink.split, !dbg !1471

if.end6:                                          ; preds = %if.end
  %2 = load i64, ptr @item_crawler_tid, align 8, !dbg !1472, !tbaa !1104
  tail call void @thread_setname(i64 noundef %2, ptr noundef nonnull @.str.2) #20, !dbg !1473
  %call7 = tail call i32 @pthread_cond_wait(ptr noundef nonnull @lru_crawler_cond, ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1474
  br label %cleanup.sink.split, !dbg !1475

cleanup.sink.split:                               ; preds = %if.then2, %if.end6
  %retval.0.ph = phi i32 [ 0, %if.end6 ], [ -1, %if.then2 ]
  %call8 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1464
  br label %cleanup, !dbg !1476

cleanup:                                          ; preds = %cleanup.sink.split, %entry
  %retval.0 = phi i32 [ -1, %entry ], [ %retval.0.ph, %cleanup.sink.split ], !dbg !1464
  ret i32 %retval.0, !dbg !1476
}

; Function Attrs: nounwind
declare !dbg !1477 i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define internal noundef ptr @item_crawler_thread(ptr nocapture readnone %arg) #0 !dbg !1497 {
entry:
  %it.i = alloca ptr, align 8, !DIAssignID !1519
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1499, metadata !DIExpression()), !dbg !1520
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 46), align 8, !dbg !1521, !tbaa !1522
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !1501, metadata !DIExpression()), !dbg !1520
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1523
  %call1 = tail call i32 @pthread_cond_signal(ptr noundef nonnull @lru_crawler_cond) #20, !dbg !1524
  store i8 1, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 27), align 2, !dbg !1525, !tbaa !1458
  %1 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1526, !tbaa !1034
  %cmp = icmp sgt i32 %1, 2, !dbg !1528
  br i1 %cmp, label %if.then, label %if.end, !dbg !1529

if.then:                                          ; preds = %entry
  %2 = load ptr, ptr @stderr, align 8, !dbg !1530, !tbaa !1014
  %3 = tail call i64 @fwrite(ptr nonnull @.str.18, i64 39, i64 1, ptr %2) #22, !dbg !1531
  br label %if.end, !dbg !1531

if.end:                                           ; preds = %if.then, %entry
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !1501, metadata !DIExpression()), !dbg !1520
  %4 = load volatile i32, ptr @do_run_lru_crawler_thread, align 4, !dbg !1532, !tbaa !943
  %tobool.not233 = icmp eq i32 %4, 0, !dbg !1533
  br i1 %tobool.not233, label %while.end149, label %while.body, !dbg !1533

while.body:                                       ; preds = %if.end, %if.end148
  %crawls_persleep.0234 = phi i32 [ %crawls_persleep.6, %if.end148 ], [ %0, %if.end ]
  tail call void @llvm.dbg.value(metadata i32 %crawls_persleep.0234, metadata !1501, metadata !DIExpression()), !dbg !1520
  %call3 = call i32 @pthread_cond_wait(ptr noundef nonnull @lru_crawler_cond, ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1534
  %5 = load i32, ptr @crawler_count, align 4, !dbg !1535, !tbaa !943
  switch i32 %5, label %for.body [
    i32 -1, label %if.then5
    i32 0, label %if.end122
  ], !dbg !1536

if.then5:                                         ; preds = %while.body
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1537, metadata !DIExpression(), metadata !1519, metadata ptr %it.i, metadata !DIExpression()), !dbg !1556
  %call.i = call ptr @assoc_get_iterator() #20, !dbg !1559
  tail call void @llvm.dbg.value(metadata ptr %call.i, metadata !1542, metadata !DIExpression()), !dbg !1556
  %6 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 46), align 8, !dbg !1560, !tbaa !1522
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !1543, metadata !DIExpression()), !dbg !1556
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %it.i) #20, !dbg !1561
  store ptr null, ptr %it.i, align 8, !dbg !1562, !tbaa !1014, !DIAssignID !1563
  tail call void @llvm.dbg.assign(metadata ptr null, metadata !1537, metadata !DIExpression(), metadata !1563, metadata ptr %it.i, metadata !DIExpression()), !dbg !1556
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1544, metadata !DIExpression()), !dbg !1556
  %cmp.i = icmp eq ptr %call.i, null, !dbg !1564
  br i1 %cmp.i, label %if.then.i, label %while.cond.preheader.i, !dbg !1566

while.cond.preheader.i:                           ; preds = %if.then5
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !1543, metadata !DIExpression()), !dbg !1556
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1544, metadata !DIExpression()), !dbg !1556
  %call17071.i = call zeroext i1 @assoc_iterate(ptr noundef nonnull %call.i, ptr noundef nonnull %it.i) #20, !dbg !1567
  br i1 %call17071.i, label %while.body.lr.ph.i, label %while.end.i, !dbg !1568

if.then.i:                                        ; preds = %if.then5
  store i32 1, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 3), align 8, !dbg !1569, !tbaa !1157
  br label %item_crawl_hash.exit, !dbg !1571

while.body.i:                                     ; preds = %if.then32.i, %while.body.lr.ph.i
  %7 = load ptr, ptr %it.i, align 8, !dbg !1572, !tbaa !1014
  %cmp2.i = icmp eq ptr %7, null, !dbg !1573
  br i1 %cmp2.i, label %if.then3.i, label %if.end29.i, !dbg !1574

if.then3.i:                                       ; preds = %while.body.i
  %8 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1), align 8, !dbg !1575, !tbaa !1239
  %cmp4.not.i = icmp eq ptr %8, null, !dbg !1576
  br i1 %cmp4.not.i, label %if.else.i, label %if.then5.i, !dbg !1577

if.then5.i:                                       ; preds = %if.then3.i
  %cmp6.i = icmp sgt i32 %items.0.ph72.i, 16, !dbg !1578
  br i1 %cmp6.i, label %if.then7.i, label %if.end15.i, !dbg !1579

if.then7.i:                                       ; preds = %if.then5.i
  %call8.i = call fastcc i32 @lru_crawler_write(ptr noundef nonnull getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1)), !dbg !1580
  tail call void @llvm.dbg.value(metadata i32 %call8.i, metadata !1545, metadata !DIExpression()), !dbg !1581
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1544, metadata !DIExpression()), !dbg !1556
  %cmp9.not.i = icmp eq i32 %call8.i, 0, !dbg !1582
  br i1 %cmp9.not.i, label %if.end15.i, label %while.end.i

if.else.i:                                        ; preds = %if.then3.i
  %9 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 2), align 8, !dbg !1584, !tbaa !1586
  %needs_client.i = getelementptr inbounds i8, ptr %9, i64 33, !dbg !1587
  %10 = load i8, ptr %needs_client.i, align 1, !dbg !1587, !tbaa !1588, !range !1143, !noundef !1144
  %tobool.i = trunc nuw i8 %10 to i1, !dbg !1587
  br i1 %tobool.i, label %while.end.i, label %if.end15.i, !dbg !1590

if.end15.i:                                       ; preds = %if.else.i, %if.then7.i, %if.then5.i
  %items.1.i = phi i32 [ 0, %if.then7.i ], [ %items.0.ph72.i, %if.then5.i ], [ %items.0.ph72.i, %if.else.i ], !dbg !1556
  tail call void @llvm.dbg.value(metadata i32 %items.1.i, metadata !1544, metadata !DIExpression()), !dbg !1556
  %cmp16.i = icmp slt i32 %crawls_persleep.0.ph73.i, 1, !dbg !1591
  %11 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 40), align 8, !dbg !1593, !tbaa !1594
  %tobool17.not.i = icmp eq i32 %11, 0, !dbg !1593
  br i1 %cmp16.i, label %land.lhs.true.i, label %if.else22.i, !dbg !1595

land.lhs.true.i:                                  ; preds = %if.end15.i
  br i1 %tobool17.not.i, label %if.then24.i, label %if.then18.i, !dbg !1596

if.then18.i:                                      ; preds = %land.lhs.true.i
  %call19.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1597
  %12 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 40), align 8, !dbg !1599, !tbaa !1594
  %call20.i = call i32 @usleep(i32 noundef %12) #20, !dbg !1600
  %call21.i = call i32 @pthread_mutex_lock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1601
  %13 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 46), align 8, !dbg !1602, !tbaa !1522
  tail call void @llvm.dbg.value(metadata i32 %13, metadata !1543, metadata !DIExpression()), !dbg !1556
  br label %while.cond.outer.backedge.i, !dbg !1603

if.else22.i:                                      ; preds = %if.end15.i
  br i1 %tobool17.not.i, label %if.then24.i, label %while.cond.outer.backedge.i, !dbg !1604

if.then24.i:                                      ; preds = %if.else22.i, %land.lhs.true.i
  %call25.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1605
  %call26.i = call i32 @pthread_mutex_lock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1608
  br label %while.cond.outer.backedge.i, !dbg !1609

while.cond.outer.backedge.i:                      ; preds = %if.end50.i, %if.then24.i, %if.else22.i, %if.then18.i
  %items.0.ph.be.i = phi i32 [ %inc52.i, %if.end50.i ], [ %items.1.i, %if.else22.i ], [ %items.1.i, %if.then24.i ], [ %items.1.i, %if.then18.i ]
  %crawls_persleep.0.ph.be.i = phi i32 [ %dec51.i, %if.end50.i ], [ %crawls_persleep.0.ph73.i, %if.else22.i ], [ %crawls_persleep.0.ph73.i, %if.then24.i ], [ %13, %if.then18.i ]
  tail call void @llvm.dbg.value(metadata i32 %crawls_persleep.0.ph.be.i, metadata !1543, metadata !DIExpression()), !dbg !1556
  tail call void @llvm.dbg.value(metadata i32 %items.0.ph.be.i, metadata !1544, metadata !DIExpression()), !dbg !1556
  %call170.i = call zeroext i1 @assoc_iterate(ptr noundef nonnull %call.i, ptr noundef nonnull %it.i) #20, !dbg !1567
  br i1 %call170.i, label %while.body.lr.ph.i, label %while.end.i, !dbg !1568, !llvm.loop !1610

while.body.lr.ph.i:                               ; preds = %while.cond.preheader.i, %while.cond.outer.backedge.i
  %crawls_persleep.0.ph73.i = phi i32 [ %crawls_persleep.0.ph.be.i, %while.cond.outer.backedge.i ], [ %6, %while.cond.preheader.i ]
  %items.0.ph72.i = phi i32 [ %items.0.ph.be.i, %while.cond.outer.backedge.i ], [ 0, %while.cond.preheader.i ]
  tail call void @llvm.dbg.value(metadata i32 %crawls_persleep.0.ph73.i, metadata !1543, metadata !DIExpression()), !dbg !1556
  tail call void @llvm.dbg.value(metadata i32 %items.0.ph72.i, metadata !1544, metadata !DIExpression()), !dbg !1556
  br label %while.body.i, !dbg !1568

if.end29.i:                                       ; preds = %while.body.i
  %refcount.i = getelementptr inbounds i8, ptr %7, i64 36, !dbg !1612
  %14 = load i16, ptr %refcount.i, align 4, !dbg !1612, !tbaa !1008
  %inc.i = add i16 %14, 1, !dbg !1612
  store i16 %inc.i, ptr %refcount.i, align 4, !dbg !1612, !tbaa !1008
  %cmp30.i = icmp ult i16 %inc.i, 2, !dbg !1614
  br i1 %cmp30.i, label %if.then32.i, label %if.end34.i, !dbg !1615

if.then32.i:                                      ; preds = %if.end29.i
  store i16 %14, ptr %refcount.i, align 4, !dbg !1616, !tbaa !1008
  tail call void @llvm.dbg.value(metadata i32 %crawls_persleep.0.ph73.i, metadata !1543, metadata !DIExpression()), !dbg !1556
  tail call void @llvm.dbg.value(metadata i32 %items.0.ph72.i, metadata !1544, metadata !DIExpression()), !dbg !1556
  %call1.i = call zeroext i1 @assoc_iterate(ptr noundef nonnull %call.i, ptr noundef nonnull %it.i) #20, !dbg !1567
  br i1 %call1.i, label %while.body.i, label %while.end.i, !dbg !1568, !llvm.loop !1618

if.end34.i:                                       ; preds = %if.end29.i
  %15 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1), align 8, !dbg !1619, !tbaa !1239
  %cmp35.not.i = icmp eq ptr %15, null, !dbg !1620
  br i1 %cmp35.not.i, label %if.end50.i, label %if.then37.i, !dbg !1621

if.then37.i:                                      ; preds = %if.end34.i
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1553, metadata !DIExpression()), !dbg !1622
  %16 = load i32, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1, i32 2), align 4, !dbg !1623, !tbaa !1625
  %17 = load i32, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1, i32 3), align 8, !dbg !1626, !tbaa !1627
  %sub.i = sub nsw i32 %16, %17, !dbg !1628
  %cmp38.i = icmp slt i32 %sub.i, 8192, !dbg !1629
  br i1 %cmp38.i, label %if.then40.i, label %if.end50.i, !dbg !1630

if.then40.i:                                      ; preds = %if.then37.i
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1631, metadata !DIExpression()), !dbg !1637
  %mul.i.i = shl nsw i32 %16, 1, !dbg !1641
  store i32 %mul.i.i, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1, i32 2), align 4, !dbg !1641, !tbaa !1625
  %18 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1, i32 4), align 8, !dbg !1642, !tbaa !1643
  %conv.i.i = sext i32 %mul.i.i to i64, !dbg !1644
  %call.i.i = call ptr @realloc(ptr noundef %18, i64 noundef %conv.i.i) #23, !dbg !1645
  tail call void @llvm.dbg.value(metadata ptr %call.i.i, metadata !1636, metadata !DIExpression()), !dbg !1637
  %cmp.i.i = icmp eq ptr %call.i.i, null, !dbg !1646
  br i1 %cmp.i.i, label %while.end.i, label %lru_crawler_expand_buf.exit.thread.i, !dbg !1648

lru_crawler_expand_buf.exit.thread.i:             ; preds = %if.then40.i
  store ptr %call.i.i, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1, i32 4), align 8, !dbg !1649, !tbaa !1643
  %.pre.i = load ptr, ptr %it.i, align 8, !dbg !1650, !tbaa !1014
  br label %if.end50.i, !dbg !1651

if.end50.i:                                       ; preds = %lru_crawler_expand_buf.exit.thread.i, %if.then37.i, %if.end34.i
  %19 = phi ptr [ %7, %if.then37.i ], [ %.pre.i, %lru_crawler_expand_buf.exit.thread.i ], [ %7, %if.end34.i ], !dbg !1650
  %20 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 2), align 8, !dbg !1652, !tbaa !1586
  %eval.i = getelementptr inbounds i8, ptr %20, i64 8, !dbg !1653
  %21 = load ptr, ptr %eval.i, align 8, !dbg !1653, !tbaa !1654
  call void %21(ptr noundef nonnull @active_crawler_mod, ptr noundef %19, i32 noundef 0, i32 noundef 0) #20, !dbg !1655
  %dec51.i = add nsw i32 %crawls_persleep.0.ph73.i, -1, !dbg !1656
  tail call void @llvm.dbg.value(metadata i32 %dec51.i, metadata !1543, metadata !DIExpression()), !dbg !1556
  %inc52.i = add nsw i32 %items.0.ph72.i, 1, !dbg !1657
  tail call void @llvm.dbg.value(metadata i32 %inc52.i, metadata !1544, metadata !DIExpression()), !dbg !1556
  br label %while.cond.outer.backedge.i, !dbg !1568

while.end.i:                                      ; preds = %if.then40.i, %while.cond.outer.backedge.i, %if.else.i, %if.then7.i, %if.then32.i, %while.cond.preheader.i
  call void @assoc_iterate_final(ptr noundef nonnull %call.i) #20, !dbg !1658
  br label %item_crawl_hash.exit, !dbg !1659

item_crawl_hash.exit:                             ; preds = %if.then.i, %while.end.i
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %it.i) #20, !dbg !1660
  store i32 0, ptr @crawler_count, align 4, !dbg !1661, !tbaa !943
  br label %if.end122, !dbg !1662

while.cond6thread-pre-split:                      ; preds = %for.inc
  %.pr = load i32, ptr @crawler_count, align 4, !dbg !1663, !tbaa !943
  tail call void @llvm.dbg.value(metadata i32 %crawls_persleep.5, metadata !1501, metadata !DIExpression()), !dbg !1520
  %tobool7.not = icmp eq i32 %.pr, 0, !dbg !1664
  br i1 %tobool7.not, label %if.end122, label %for.body.backedge, !dbg !1664

for.body:                                         ; preds = %while.body, %for.body.backedge
  %indvars.iv = phi i64 [ %indvars.iv.be, %for.body.backedge ], [ 1, %while.body ]
  %crawls_persleep.2227 = phi i32 [ %crawls_persleep.5, %for.body.backedge ], [ %crawls_persleep.0234, %while.body ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1500, metadata !DIExpression()), !dbg !1520
  tail call void @llvm.dbg.value(metadata i32 %crawls_persleep.2227, metadata !1501, metadata !DIExpression()), !dbg !1520
  %arrayidx = getelementptr inbounds [256 x %struct.crawler], ptr @crawlers, i64 0, i64 %indvars.iv, !dbg !1665
  %it_flags = getelementptr inbounds i8, ptr %arrayidx, i64 38, !dbg !1667
  %22 = load i16, ptr %it_flags, align 2, !dbg !1667, !tbaa !1668
  %cmp10.not = icmp eq i16 %22, 1, !dbg !1669
  br i1 %cmp10.not, label %if.end13, label %for.inc, !dbg !1670

if.end13:                                         ; preds = %for.body
  %23 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1), align 8, !dbg !1671, !tbaa !1239
  %cmp14.not = icmp eq ptr %23, null, !dbg !1672
  br i1 %cmp14.not, label %if.else29, label %if.then16, !dbg !1673

if.then16:                                        ; preds = %if.end13
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1508, metadata !DIExpression()), !dbg !1674
  %24 = load i32, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1, i32 2), align 4, !dbg !1675, !tbaa !1625
  %25 = load i32, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1, i32 3), align 8, !dbg !1676, !tbaa !1627
  %sub = sub nsw i32 %24, %25, !dbg !1677
  %cmp17 = icmp slt i32 %sub, 8192, !dbg !1678
  br i1 %cmp17, label %if.then19, label %if.end33, !dbg !1679

if.then19:                                        ; preds = %if.then16
  %call20 = call fastcc i32 @lru_crawler_write(ptr noundef nonnull getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1)), !dbg !1680
  tail call void @llvm.dbg.value(metadata i32 %call20, metadata !1515, metadata !DIExpression()), !dbg !1681
  %cmp21.not = icmp eq i32 %call20, 0, !dbg !1682
  br i1 %cmp21.not, label %if.end33, label %if.then23, !dbg !1684

if.then23:                                        ; preds = %if.then19
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1685, metadata !DIExpression()), !dbg !1690
  store i16 0, ptr %it_flags, align 2, !dbg !1693, !tbaa !1668
  %26 = load i32, ptr @crawler_count, align 4, !dbg !1694, !tbaa !943
  %dec.i = add nsw i32 %26, -1, !dbg !1694
  store i32 %dec.i, ptr @crawler_count, align 4, !dbg !1694, !tbaa !943
  call void @do_item_unlinktail_q(ptr noundef nonnull %arrayidx) #20, !dbg !1695
  %reclaimed.i = getelementptr inbounds i8, ptr %arrayidx, i64 48, !dbg !1696
  %27 = load i64, ptr %reclaimed.i, align 8, !dbg !1696, !tbaa !1028
  %unfetched.i = getelementptr inbounds i8, ptr %arrayidx, i64 56, !dbg !1697
  %28 = load i64, ptr %unfetched.i, align 8, !dbg !1697, !tbaa !1069
  %checked.i = getelementptr inbounds i8, ptr %arrayidx, i64 64, !dbg !1698
  %29 = load i64, ptr %checked.i, align 8, !dbg !1698, !tbaa !1699
  %30 = trunc nuw nsw i64 %indvars.iv to i32, !dbg !1700
  call void @do_item_stats_add_crawl(i32 noundef %30, i64 noundef %27, i64 noundef %28, i64 noundef %29) #20, !dbg !1700
  %arrayidx10.i = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %indvars.iv, !dbg !1701
  %call.i190 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx10.i) #20, !dbg !1702
  %31 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 2), align 8, !dbg !1703, !tbaa !1586
  %doneclass.i = getelementptr inbounds i8, ptr %31, i64 16, !dbg !1705
  %32 = load ptr, ptr %doneclass.i, align 8, !dbg !1705, !tbaa !1706
  %cmp.not.i = icmp eq ptr %32, null, !dbg !1707
  br i1 %cmp.not.i, label %for.inc, label %if.then.i191, !dbg !1708

if.then.i191:                                     ; preds = %if.then23
  call void %32(ptr noundef nonnull @active_crawler_mod, i32 noundef %30) #20, !dbg !1709
  br label %for.inc, !dbg !1709

if.else29:                                        ; preds = %if.end13
  %33 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 2), align 8, !dbg !1710, !tbaa !1586
  %needs_client = getelementptr inbounds i8, ptr %33, i64 33, !dbg !1712
  %34 = load i8, ptr %needs_client, align 1, !dbg !1712, !tbaa !1588, !range !1143, !noundef !1144
  %tobool30 = trunc nuw i8 %34 to i1, !dbg !1712
  br i1 %tobool30, label %if.then31, label %if.end33, !dbg !1713

if.then31:                                        ; preds = %if.else29
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1685, metadata !DIExpression()), !dbg !1714
  store i16 0, ptr %it_flags, align 2, !dbg !1717, !tbaa !1668
  %35 = load i32, ptr @crawler_count, align 4, !dbg !1718, !tbaa !943
  %dec.i195 = add nsw i32 %35, -1, !dbg !1718
  store i32 %dec.i195, ptr @crawler_count, align 4, !dbg !1718, !tbaa !943
  call void @do_item_unlinktail_q(ptr noundef nonnull %arrayidx) #20, !dbg !1719
  %reclaimed.i196 = getelementptr inbounds i8, ptr %arrayidx, i64 48, !dbg !1720
  %36 = load i64, ptr %reclaimed.i196, align 8, !dbg !1720, !tbaa !1028
  %unfetched.i197 = getelementptr inbounds i8, ptr %arrayidx, i64 56, !dbg !1721
  %37 = load i64, ptr %unfetched.i197, align 8, !dbg !1721, !tbaa !1069
  %checked.i198 = getelementptr inbounds i8, ptr %arrayidx, i64 64, !dbg !1722
  %38 = load i64, ptr %checked.i198, align 8, !dbg !1722, !tbaa !1699
  %39 = trunc nuw nsw i64 %indvars.iv to i32, !dbg !1723
  call void @do_item_stats_add_crawl(i32 noundef %39, i64 noundef %36, i64 noundef %37, i64 noundef %38) #20, !dbg !1723
  %arrayidx10.i199 = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %indvars.iv, !dbg !1724
  %call.i200 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx10.i199) #20, !dbg !1725
  %40 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 2), align 8, !dbg !1726, !tbaa !1586
  %doneclass.i201 = getelementptr inbounds i8, ptr %40, i64 16, !dbg !1727
  %41 = load ptr, ptr %doneclass.i201, align 8, !dbg !1727, !tbaa !1706
  %cmp.not.i202 = icmp eq ptr %41, null, !dbg !1728
  br i1 %cmp.not.i202, label %for.inc, label %if.then.i203, !dbg !1729

if.then.i203:                                     ; preds = %if.then31
  call void %41(ptr noundef nonnull @active_crawler_mod, i32 noundef %39) #20, !dbg !1730
  br label %for.inc, !dbg !1730

if.end33:                                         ; preds = %if.then16, %if.then19, %if.else29
  %arrayidx35 = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %indvars.iv, !dbg !1731
  %call36 = call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx35) #20, !dbg !1732
  %call39 = call ptr @do_item_crawl_q(ptr noundef nonnull %arrayidx) #20, !dbg !1733
  tail call void @llvm.dbg.value(metadata ptr %call39, metadata !1502, metadata !DIExpression()), !dbg !1734
  %cmp40 = icmp eq ptr %call39, null, !dbg !1735
  br i1 %cmp40, label %if.then50, label %lor.lhs.false, !dbg !1737

lor.lhs.false:                                    ; preds = %if.end33
  %remaining = getelementptr inbounds i8, ptr %arrayidx, i64 44, !dbg !1738
  %42 = load i32, ptr %remaining, align 4, !dbg !1738, !tbaa !1739
  %tobool44.not = icmp eq i32 %42, 0, !dbg !1740
  br i1 %tobool44.not, label %if.end56, label %land.lhs.true, !dbg !1741

land.lhs.true:                                    ; preds = %lor.lhs.false
  %dec = add i32 %42, -1, !dbg !1742
  store i32 %dec, ptr %remaining, align 4, !dbg !1742, !tbaa !1739
  %cmp48 = icmp eq i32 %dec, 0, !dbg !1743
  br i1 %cmp48, label %if.then50, label %if.end56, !dbg !1744

if.then50:                                        ; preds = %land.lhs.true, %if.end33
  %43 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1745, !tbaa !1034
  %cmp51 = icmp sgt i32 %43, 2, !dbg !1748
  br i1 %cmp51, label %if.then53, label %if.then50.if.end55_crit_edge, !dbg !1749

if.then50.if.end55_crit_edge:                     ; preds = %if.then50
  %.pre240 = trunc nuw nsw i64 %indvars.iv to i32, !dbg !1750
  br label %if.end55, !dbg !1749

if.then53:                                        ; preds = %if.then50
  %44 = load ptr, ptr @stderr, align 8, !dbg !1752, !tbaa !1014
  %45 = trunc nuw nsw i64 %indvars.iv to i32, !dbg !1753
  %call54 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %44, ptr noundef nonnull @.str.19, i32 noundef %45) #21, !dbg !1753
  br label %if.end55, !dbg !1753

if.end55:                                         ; preds = %if.then50.if.end55_crit_edge, %if.then53
  %.pre-phi = phi i32 [ %.pre240, %if.then50.if.end55_crit_edge ], [ %45, %if.then53 ], !dbg !1750
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1685, metadata !DIExpression()), !dbg !1754
  store i16 0, ptr %it_flags, align 2, !dbg !1755, !tbaa !1668
  %46 = load i32, ptr @crawler_count, align 4, !dbg !1756, !tbaa !943
  %dec.i208 = add nsw i32 %46, -1, !dbg !1756
  store i32 %dec.i208, ptr @crawler_count, align 4, !dbg !1756, !tbaa !943
  call void @do_item_unlinktail_q(ptr noundef nonnull %arrayidx) #20, !dbg !1757
  %reclaimed.i209 = getelementptr inbounds i8, ptr %arrayidx, i64 48, !dbg !1758
  %47 = load i64, ptr %reclaimed.i209, align 8, !dbg !1758, !tbaa !1028
  %unfetched.i210 = getelementptr inbounds i8, ptr %arrayidx, i64 56, !dbg !1759
  %48 = load i64, ptr %unfetched.i210, align 8, !dbg !1759, !tbaa !1069
  %checked.i211 = getelementptr inbounds i8, ptr %arrayidx, i64 64, !dbg !1760
  %49 = load i64, ptr %checked.i211, align 8, !dbg !1760, !tbaa !1699
  call void @do_item_stats_add_crawl(i32 noundef %.pre-phi, i64 noundef %47, i64 noundef %48, i64 noundef %49) #20, !dbg !1750
  %call.i213 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx35) #20, !dbg !1761
  %50 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 2), align 8, !dbg !1762, !tbaa !1586
  %doneclass.i214 = getelementptr inbounds i8, ptr %50, i64 16, !dbg !1763
  %51 = load ptr, ptr %doneclass.i214, align 8, !dbg !1763, !tbaa !1706
  %cmp.not.i215 = icmp eq ptr %51, null, !dbg !1764
  br i1 %cmp.not.i215, label %for.inc, label %if.then.i216, !dbg !1765

if.then.i216:                                     ; preds = %if.end55
  call void %51(ptr noundef nonnull @active_crawler_mod, i32 noundef %.pre-phi) #20, !dbg !1766
  br label %for.inc, !dbg !1766

if.end56:                                         ; preds = %land.lhs.true, %lor.lhs.false
  %52 = load ptr, ptr @hash, align 8, !dbg !1767, !tbaa !1014
  %data = getelementptr inbounds i8, ptr %call39, i64 48, !dbg !1768
  %it_flags57 = getelementptr inbounds i8, ptr %call39, i64 38, !dbg !1768
  %53 = load i16, ptr %it_flags57, align 2, !dbg !1768, !tbaa !1008
  %54 = shl i16 %53, 2, !dbg !1768
  %55 = and i16 %54, 8, !dbg !1768
  %cond = zext nneg i16 %55 to i64, !dbg !1768
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %cond, !dbg !1768
  %nkey = getelementptr inbounds i8, ptr %call39, i64 41, !dbg !1769
  %56 = load i8, ptr %nkey, align 1, !dbg !1769, !tbaa !1045
  %conv60 = zext i8 %56 to i64, !dbg !1770
  %call61 = call i32 %52(ptr noundef nonnull %add.ptr, i64 noundef %conv60) #20, !dbg !1767
  tail call void @llvm.dbg.value(metadata i32 %call61, metadata !1518, metadata !DIExpression()), !dbg !1771
  %call62 = call ptr @item_trylock(i32 noundef %call61) #20, !dbg !1772
  tail call void @llvm.dbg.value(metadata ptr %call62, metadata !1507, metadata !DIExpression()), !dbg !1734
  %cmp63 = icmp eq ptr %call62, null, !dbg !1774
  br i1 %cmp63, label %if.then65, label %if.end69, !dbg !1775

if.then65:                                        ; preds = %if.end56
  %call68 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx35) #20, !dbg !1776
  br label %for.inc, !dbg !1778

if.end69:                                         ; preds = %if.end56
  %refcount = getelementptr inbounds i8, ptr %call39, i64 36, !dbg !1779
  %57 = load i16, ptr %refcount, align 4, !dbg !1779, !tbaa !1008
  %inc = add i16 %57, 1, !dbg !1779
  store i16 %inc, ptr %refcount, align 4, !dbg !1779, !tbaa !1008
  %cmp71.not = icmp eq i16 %inc, 2, !dbg !1781
  br i1 %cmp71.not, label %if.end82, label %if.then73, !dbg !1782

if.then73:                                        ; preds = %if.end69
  store i16 %57, ptr %refcount, align 4, !dbg !1783, !tbaa !1008
  call void @item_trylock_unlock(ptr noundef nonnull %call62) #20, !dbg !1785
  %call81 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx35) #20, !dbg !1787
  br label %for.inc, !dbg !1788

if.end82:                                         ; preds = %if.end69
  %checked = getelementptr inbounds i8, ptr %arrayidx, i64 64, !dbg !1789
  %58 = load i64, ptr %checked, align 8, !dbg !1790, !tbaa !1699
  %inc85 = add i64 %58, 1, !dbg !1790
  store i64 %inc85, ptr %checked, align 8, !dbg !1790, !tbaa !1699
  %59 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 2), align 8, !dbg !1791, !tbaa !1586
  %needs_lock = getelementptr inbounds i8, ptr %59, i64 32, !dbg !1793
  %60 = load i8, ptr %needs_lock, align 8, !dbg !1793, !tbaa !1794, !range !1143, !noundef !1144
  %tobool86 = trunc nuw i8 %60 to i1, !dbg !1793
  br i1 %tobool86, label %if.end91, label %if.then87, !dbg !1795

if.then87:                                        ; preds = %if.end82
  %call90 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx35) #20, !dbg !1796
  %.pre = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 2), align 8, !dbg !1798, !tbaa !1586
  br label %if.end91, !dbg !1799

if.end91:                                         ; preds = %if.then87, %if.end82
  %61 = phi ptr [ %.pre, %if.then87 ], [ %59, %if.end82 ], !dbg !1798
  %eval = getelementptr inbounds i8, ptr %61, i64 8, !dbg !1800
  %62 = load ptr, ptr %eval, align 8, !dbg !1800, !tbaa !1654
  %63 = trunc nuw nsw i64 %indvars.iv to i32, !dbg !1801
  call void %62(ptr noundef nonnull @active_crawler_mod, ptr noundef nonnull %call39, i32 noundef %call61, i32 noundef %63) #20, !dbg !1801
  call void @item_trylock_unlock(ptr noundef nonnull %call62) #20, !dbg !1802
  %64 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 2), align 8, !dbg !1804, !tbaa !1586
  %needs_lock95 = getelementptr inbounds i8, ptr %64, i64 32, !dbg !1806
  %65 = load i8, ptr %needs_lock95, align 8, !dbg !1806, !tbaa !1794, !range !1143, !noundef !1144
  %tobool96 = trunc nuw i8 %65 to i1, !dbg !1806
  br i1 %tobool96, label %if.then97, label %if.end101, !dbg !1807

if.then97:                                        ; preds = %if.end91
  %call100 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx35) #20, !dbg !1808
  br label %if.end101, !dbg !1810

if.end101:                                        ; preds = %if.then97, %if.end91
  %dec102 = add nsw i32 %crawls_persleep.2227, -1, !dbg !1811
  tail call void @llvm.dbg.value(metadata i32 %dec102, metadata !1501, metadata !DIExpression()), !dbg !1520
  %cmp103 = icmp slt i32 %crawls_persleep.2227, 1, !dbg !1813
  %66 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 40), align 8, !dbg !1814, !tbaa !1594
  %tobool106.not = icmp eq i32 %66, 0, !dbg !1814
  br i1 %cmp103, label %land.lhs.true105, label %if.else111, !dbg !1815

land.lhs.true105:                                 ; preds = %if.end101
  br i1 %tobool106.not, label %if.then113, label %if.then107, !dbg !1816

if.then107:                                       ; preds = %land.lhs.true105
  %call108 = call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1817
  %67 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 40), align 8, !dbg !1819, !tbaa !1594
  %call109 = call i32 @usleep(i32 noundef %67) #20, !dbg !1820
  %call110 = call i32 @pthread_mutex_lock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1821
  %68 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 46), align 8, !dbg !1822, !tbaa !1522
  tail call void @llvm.dbg.value(metadata i32 %68, metadata !1501, metadata !DIExpression()), !dbg !1520
  br label %for.inc, !dbg !1823

if.else111:                                       ; preds = %if.end101
  br i1 %tobool106.not, label %if.then113, label %for.inc, !dbg !1824

if.then113:                                       ; preds = %land.lhs.true105, %if.else111
  %call114 = call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1825
  %call115 = call i32 @pthread_mutex_lock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1828
  br label %for.inc, !dbg !1829

for.inc:                                          ; preds = %if.then.i216, %if.end55, %if.then.i203, %if.then31, %if.then23, %if.then.i191, %if.then65, %if.then73, %if.else111, %if.then113, %if.then107, %for.body
  %crawls_persleep.5 = phi i32 [ %crawls_persleep.2227, %for.body ], [ %crawls_persleep.2227, %if.then65 ], [ %crawls_persleep.2227, %if.then73 ], [ %68, %if.then107 ], [ %dec102, %if.else111 ], [ %dec102, %if.then113 ], [ %crawls_persleep.2227, %if.then.i191 ], [ %crawls_persleep.2227, %if.then23 ], [ %crawls_persleep.2227, %if.then31 ], [ %crawls_persleep.2227, %if.then.i203 ], [ %crawls_persleep.2227, %if.end55 ], [ %crawls_persleep.2227, %if.then.i216 ], !dbg !1830
  tail call void @llvm.dbg.value(metadata i32 %crawls_persleep.5, metadata !1501, metadata !DIExpression()), !dbg !1520
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !1831
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !1500, metadata !DIExpression()), !dbg !1520
  %exitcond.not = icmp eq i64 %indvars.iv.next, 256, !dbg !1832
  br i1 %exitcond.not, label %while.cond6thread-pre-split, label %for.body.backedge, !dbg !1833

for.body.backedge:                                ; preds = %for.inc, %while.cond6thread-pre-split
  %indvars.iv.be = phi i64 [ %indvars.iv.next, %for.inc ], [ 1, %while.cond6thread-pre-split ]
  br label %for.body, !dbg !1665, !llvm.loop !1834

if.end122:                                        ; preds = %while.cond6thread-pre-split, %while.body, %item_crawl_hash.exit
  %crawls_persleep.6 = phi i32 [ %crawls_persleep.0234, %item_crawl_hash.exit ], [ %crawls_persleep.0234, %while.body ], [ %crawls_persleep.5, %while.cond6thread-pre-split ], !dbg !1830
  tail call void @llvm.dbg.value(metadata i32 %crawls_persleep.6, metadata !1501, metadata !DIExpression()), !dbg !1520
  %69 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 2), align 8, !dbg !1836, !tbaa !1586
  %cmp123.not = icmp eq ptr %69, null, !dbg !1838
  br i1 %cmp123.not, label %if.end143, label %if.then125, !dbg !1839

if.then125:                                       ; preds = %if.end122
  %finalize = getelementptr inbounds i8, ptr %69, i64 24, !dbg !1840
  %70 = load ptr, ptr %finalize, align 8, !dbg !1840, !tbaa !1843
  %cmp126.not = icmp eq ptr %70, null, !dbg !1844
  br i1 %cmp126.not, label %if.end130, label %if.then128, !dbg !1845

if.then128:                                       ; preds = %if.then125
  call void %70(ptr noundef nonnull @active_crawler_mod) #20, !dbg !1846
  br label %if.end130, !dbg !1846

if.end130:                                        ; preds = %if.then128, %if.then125
  %71 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1), align 8, !dbg !1847, !tbaa !1848
  %cmp132.not232 = icmp eq ptr %71, null, !dbg !1849
  br i1 %cmp132.not232, label %if.end142, label %land.rhs.preheader, !dbg !1850

land.rhs.preheader:                               ; preds = %if.end130
  %72 = load i32, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1, i32 3), align 8, !dbg !1851, !tbaa !1202
  %cmp134.not249 = icmp eq i32 %72, 0, !dbg !1852
  br i1 %cmp134.not249, label %if.then141, label %while.body136, !dbg !1853

land.rhs:                                         ; preds = %while.body136
  %73 = load i32, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1, i32 3), align 8, !dbg !1851, !tbaa !1202
  %cmp134.not = icmp eq i32 %73, 0, !dbg !1852
  br i1 %cmp134.not, label %if.then141, label %while.body136, !dbg !1853, !llvm.loop !1854

while.body136:                                    ; preds = %land.rhs.preheader, %land.rhs
  %call137 = call fastcc i32 @lru_crawler_write(ptr noundef nonnull getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1)), !dbg !1856
  %74 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1), align 8, !dbg !1847, !tbaa !1848
  %cmp132.not = icmp eq ptr %74, null, !dbg !1849
  br i1 %cmp132.not, label %if.end142, label %land.rhs, !dbg !1850, !llvm.loop !1854

if.then141:                                       ; preds = %land.rhs, %land.rhs.preheader
  %.lcssa = phi ptr [ %71, %land.rhs.preheader ], [ %74, %land.rhs ]
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1858, metadata !DIExpression()), !dbg !1863
  call void @redispatch_conn(ptr noundef nonnull %.lcssa) #20, !dbg !1867
  store ptr null, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1), align 8, !dbg !1868, !tbaa !1848
  %75 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1, i32 4), align 8, !dbg !1869, !tbaa !1643
  call void @free(ptr noundef %75) #20, !dbg !1870
  store ptr null, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1, i32 4), align 8, !dbg !1871, !tbaa !1643
  br label %if.end142, !dbg !1872

if.end142:                                        ; preds = %while.body136, %if.end130, %if.then141
  store ptr null, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 2), align 8, !dbg !1873, !tbaa !1586
  br label %if.end143, !dbg !1874

if.end143:                                        ; preds = %if.end142, %if.end122
  %76 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1875, !tbaa !1034
  %cmp144 = icmp sgt i32 %76, 2, !dbg !1877
  br i1 %cmp144, label %if.then146, label %if.end148, !dbg !1878

if.then146:                                       ; preds = %if.end143
  %77 = load ptr, ptr @stderr, align 8, !dbg !1879, !tbaa !1014
  %78 = call i64 @fwrite(ptr nonnull @.str.20, i64 28, i64 1, ptr %77) #22, !dbg !1880
  br label %if.end148, !dbg !1880

if.end148:                                        ; preds = %if.then146, %if.end143
  call void @STATS_LOCK() #20, !dbg !1881
  store i8 0, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 11), align 1, !dbg !1882, !tbaa !1883
  call void @STATS_UNLOCK() #20, !dbg !1885
  tail call void @llvm.dbg.value(metadata i32 %crawls_persleep.6, metadata !1501, metadata !DIExpression()), !dbg !1520
  %79 = load volatile i32, ptr @do_run_lru_crawler_thread, align 4, !dbg !1532, !tbaa !943
  %tobool.not = icmp eq i32 %79, 0, !dbg !1533
  br i1 %tobool.not, label %while.end149, label %while.body, !dbg !1533, !llvm.loop !1886

while.end149:                                     ; preds = %if.end148, %if.end
  %call150 = call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1888
  %80 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1889, !tbaa !1034
  %cmp151 = icmp sgt i32 %80, 2, !dbg !1891
  br i1 %cmp151, label %if.then153, label %if.end155, !dbg !1892

if.then153:                                       ; preds = %while.end149
  %81 = load ptr, ptr @stderr, align 8, !dbg !1893, !tbaa !1014
  %82 = call i64 @fwrite(ptr nonnull @.str.21, i64 28, i64 1, ptr %81) #22, !dbg !1894
  br label %if.end155, !dbg !1894

if.end155:                                        ; preds = %if.then153, %while.end149
  store i8 0, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 27), align 2, !dbg !1895, !tbaa !1458
  ret ptr null, !dbg !1896
}

declare !dbg !1897 void @thread_setname(i64 noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !1900 i32 @pthread_cond_wait(ptr noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local i32 @lru_crawler_start(ptr noundef readonly %ids, i32 noundef %remaining, i32 noundef %type, ptr noundef %data, ptr noundef %c, i32 noundef %sfd) local_unnamed_addr #0 !dbg !747 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %ids, metadata !754, metadata !DIExpression()), !dbg !1905
  tail call void @llvm.dbg.value(metadata i32 %remaining, metadata !755, metadata !DIExpression()), !dbg !1905
  tail call void @llvm.dbg.value(metadata i32 %type, metadata !756, metadata !DIExpression()), !dbg !1905
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !757, metadata !DIExpression()), !dbg !1905
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !758, metadata !DIExpression()), !dbg !1905
  tail call void @llvm.dbg.value(metadata i32 %sfd, metadata !759, metadata !DIExpression()), !dbg !1905
  tail call void @llvm.dbg.value(metadata i32 0, metadata !760, metadata !DIExpression()), !dbg !1905
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1906
  tail call void @STATS_LOCK() #20, !dbg !1907
  %0 = load i8, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 11), align 1, !dbg !1908, !tbaa !1883, !range !1143, !noundef !1144
  %tobool = trunc nuw i8 %0 to i1, !dbg !1908
  tail call void @llvm.dbg.value(metadata i1 %tobool, metadata !761, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1905
  tail call void @STATS_UNLOCK() #20, !dbg !1909
  %1 = load volatile i32, ptr @do_run_lru_crawler_thread, align 4, !dbg !1910, !tbaa !943
  %cmp = icmp eq i32 %1, 0, !dbg !1912
  br i1 %cmp, label %if.then, label %if.end, !dbg !1913

if.then:                                          ; preds = %entry
  %call1 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1914
  br label %cleanup, !dbg !1916

if.end:                                           ; preds = %entry
  %cmp3 = icmp eq i32 %type, 0, !dbg !1905
  br i1 %tobool, label %land.lhs.true, label %if.end8, !dbg !1917

land.lhs.true:                                    ; preds = %if.end
  br i1 %cmp3, label %land.lhs.true4, label %if.then6, !dbg !1919

land.lhs.true4:                                   ; preds = %land.lhs.true
  %2 = load i32, ptr @active_crawler_type, align 4, !dbg !1920, !tbaa !943
  %cmp5 = icmp eq i32 %2, 0, !dbg !1921
  br i1 %cmp5, label %land.lhs.true10, label %if.then6, !dbg !1922

if.then6:                                         ; preds = %land.lhs.true4, %land.lhs.true
  %call7 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1923
  %3 = load volatile i32, ptr @current_time, align 4, !dbg !1925, !tbaa !943
  %add = add i32 %3, 60, !dbg !1926
  store i32 %add, ptr @lru_crawler_start.block_ae_until, align 4, !dbg !1927, !tbaa !943
  br label %cleanup, !dbg !1928

if.end8:                                          ; preds = %if.end
  br i1 %cmp3, label %land.lhs.true10, label %if.end14.thread, !dbg !1929

land.lhs.true10:                                  ; preds = %land.lhs.true4, %if.end8
  %4 = load i32, ptr @lru_crawler_start.block_ae_until, align 4, !dbg !1931, !tbaa !943
  %5 = load volatile i32, ptr @current_time, align 4, !dbg !1932, !tbaa !943
  %cmp11 = icmp ugt i32 %4, %5, !dbg !1933
  br i1 %cmp11, label %if.then12, label %if.end14, !dbg !1934

if.then12:                                        ; preds = %land.lhs.true10
  %call13 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1935
  br label %cleanup, !dbg !1937

if.end14:                                         ; preds = %land.lhs.true10
  %cmp15 = icmp eq ptr %ids, null, !dbg !1938
  br i1 %cmp15, label %if.then20, label %if.end22, !dbg !1940

if.end14.thread:                                  ; preds = %if.end8
  %cmp1582 = icmp eq ptr %ids, null, !dbg !1938
  %6 = and i32 %type, -2, !dbg !1940
  %switch85 = icmp ne i32 %6, 2, !dbg !1940
  %or.cond86.not = and i1 %cmp1582, %switch85, !dbg !1940
  br i1 %or.cond86.not, label %if.then20, label %if.then24, !dbg !1940

if.then20:                                        ; preds = %if.end14.thread, %if.end14
  %call21 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1941
  br label %cleanup, !dbg !1943

if.end22:                                         ; preds = %if.end14
  br i1 %tobool, label %for.cond.preheader, label %if.then24, !dbg !1944

if.then24:                                        ; preds = %if.end14.thread, %if.end22
  %cmp158789 = phi i1 [ false, %if.end22 ], [ %cmp1582, %if.end14.thread ]
  %idxprom = zext i32 %type to i64, !dbg !1945
  %arrayidx = getelementptr inbounds [4 x ptr], ptr @crawler_mod_regs, i64 0, i64 %idxprom, !dbg !1945
  %7 = load ptr, ptr %arrayidx, align 8, !dbg !1945, !tbaa !1014
  store ptr %7, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 2), align 8, !dbg !1948, !tbaa !1586
  store i32 %type, ptr @active_crawler_type, align 4, !dbg !1949, !tbaa !943
  %8 = load ptr, ptr %7, align 8, !dbg !1950, !tbaa !1952
  %cmp25.not = icmp eq ptr %8, null, !dbg !1953
  br i1 %cmp25.not, label %if.end29, label %if.then26, !dbg !1954

if.then26:                                        ; preds = %if.then24
  %call28 = tail call i32 %8(ptr noundef nonnull @active_crawler_mod, ptr noundef %data) #20, !dbg !1955
  %.pre = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 2), align 8, !dbg !1957, !tbaa !1586
  br label %if.end29, !dbg !1959

if.end29:                                         ; preds = %if.then26, %if.then24
  %9 = phi ptr [ %.pre, %if.then26 ], [ %7, %if.then24 ], !dbg !1957
  %needs_client = getelementptr inbounds i8, ptr %9, i64 33, !dbg !1960
  %10 = load i8, ptr %needs_client, align 1, !dbg !1960, !tbaa !1588, !range !1143, !noundef !1144
  %tobool30 = trunc nuw i8 %10 to i1, !dbg !1960
  br i1 %tobool30, label %if.then31, label %if.end43, !dbg !1961

if.then31:                                        ; preds = %if.end29
  %cmp32 = icmp eq ptr %c, null, !dbg !1962
  %cmp33 = icmp eq i32 %sfd, 0
  %or.cond78 = or i1 %cmp32, %cmp33, !dbg !1965
  br i1 %or.cond78, label %if.then34, label %if.end36, !dbg !1965

if.then34:                                        ; preds = %if.then31
  %call35 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1966
  br label %cleanup, !dbg !1968

if.end36:                                         ; preds = %if.then31
  tail call void @llvm.dbg.value(metadata ptr @active_crawler_mod, metadata !1969, metadata !DIExpression()), !dbg !1978
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1974, metadata !DIExpression()), !dbg !1978
  tail call void @llvm.dbg.value(metadata i32 %sfd, metadata !1975, metadata !DIExpression()), !dbg !1978
  tail call void @llvm.dbg.value(metadata ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1), metadata !1976, metadata !DIExpression()), !dbg !1978
  %11 = load ptr, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1), align 8, !dbg !1981, !tbaa !1848
  %cmp.not.i = icmp eq ptr %11, null, !dbg !1983
  br i1 %cmp.not.i, label %if.end.i, label %if.then39, !dbg !1984

if.end.i:                                         ; preds = %if.end36
  store ptr %c, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1), align 8, !dbg !1985, !tbaa !1848
  store i32 %sfd, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1, i32 1), align 8, !dbg !1986, !tbaa !1987
  tail call void @llvm.dbg.value(metadata i64 131072, metadata !1977, metadata !DIExpression()), !dbg !1978
  %call.i = tail call noalias dereferenceable_or_null(131072) ptr @malloc(i64 noundef 131072) #24, !dbg !1988
  store ptr %call.i, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1, i32 4), align 8, !dbg !1989, !tbaa !1643
  %cmp6.i = icmp eq ptr %call.i, null, !dbg !1990
  br i1 %cmp6.i, label %if.then39, label %lru_crawler_set_client.exit, !dbg !1992

lru_crawler_set_client.exit:                      ; preds = %if.end.i
  store i32 131072, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1, i32 2), align 4, !dbg !1993, !tbaa !1625
  store i32 0, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 1, i32 3), align 8, !dbg !1994, !tbaa !1627
  br i1 %cmp158789, label %if.end54.thread, label %for.cond.preheader, !dbg !1995

for.cond.preheader:                               ; preds = %if.end22, %if.end43, %lru_crawler_set_client.exit
  tail call void @llvm.dbg.value(metadata i32 1, metadata !762, metadata !DIExpression()), !dbg !1996
  tail call void @llvm.dbg.value(metadata i32 0, metadata !760, metadata !DIExpression()), !dbg !1905
  %cmp21.i = icmp eq i32 %remaining, -1
  br label %for.body, !dbg !1997

if.then39:                                        ; preds = %if.end36, %if.end.i
  %call40 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !1998
  br label %cleanup, !dbg !2000

if.end43:                                         ; preds = %if.end29
  br i1 %cmp158789, label %if.end54.thread, label %for.cond.preheader, !dbg !1995

if.end54.thread:                                  ; preds = %if.end43, %lru_crawler_set_client.exit
  tail call void @llvm.dbg.value(metadata i32 1, metadata !760, metadata !DIExpression()), !dbg !1905
  store i32 -1, ptr @crawler_count, align 4, !dbg !2001, !tbaa !943
  br label %if.then56, !dbg !2003

for.body:                                         ; preds = %for.cond.preheader, %for.inc
  %indvars.iv = phi i64 [ 1, %for.cond.preheader ], [ %indvars.iv.next, %for.inc ]
  %starts.097 = phi i32 [ 0, %for.cond.preheader ], [ %starts.1, %for.inc ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !762, metadata !DIExpression()), !dbg !1996
  tail call void @llvm.dbg.value(metadata i32 %starts.097, metadata !760, metadata !DIExpression()), !dbg !1905
  %arrayidx48 = getelementptr inbounds i8, ptr %ids, i64 %indvars.iv, !dbg !2004
  %12 = load i8, ptr %arrayidx48, align 1, !dbg !2004, !tbaa !1045
  %tobool49.not = icmp eq i8 %12, 0, !dbg !2004
  br i1 %tobool49.not, label %for.inc, label %if.then50, !dbg !2008

if.then50:                                        ; preds = %for.body
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2009, metadata !DIExpression()), !dbg !2017
  tail call void @llvm.dbg.value(metadata i32 %remaining, metadata !2014, metadata !DIExpression()), !dbg !2017
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2015, metadata !DIExpression()), !dbg !2017
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2016, metadata !DIExpression()), !dbg !2017
  %arrayidx.i = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %indvars.iv, !dbg !2019
  %call.i79 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx.i) #20, !dbg !2020
  %arrayidx2.i = getelementptr inbounds [256 x %struct.crawler], ptr @crawlers, i64 0, i64 %indvars.iv, !dbg !2021
  %it_flags.i = getelementptr inbounds i8, ptr %arrayidx2.i, i64 38, !dbg !2023
  %13 = load i16, ptr %it_flags.i, align 2, !dbg !2023, !tbaa !1668
  %cmp.i = icmp eq i16 %13, 0, !dbg !2024
  br i1 %cmp.i, label %if.then.i, label %do_lru_crawler_start.exit, !dbg !2025

if.then.i:                                        ; preds = %if.then50
  %14 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2026, !tbaa !1034
  %cmp4.i = icmp sgt i32 %14, 2, !dbg !2029
  br i1 %cmp4.i, label %if.then6.i, label %if.end.i80, !dbg !2030

if.then6.i:                                       ; preds = %if.then.i
  %15 = load ptr, ptr @stderr, align 8, !dbg !2031, !tbaa !1014
  %16 = trunc nuw nsw i64 %indvars.iv to i32, !dbg !2032
  %call7.i = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %15, ptr noundef nonnull @.str.22, i32 noundef %16) #21, !dbg !2032
  br label %if.end.i80, !dbg !2032

if.end.i80:                                       ; preds = %if.then6.i, %if.then.i
  %nbytes.i = getelementptr inbounds i8, ptr %arrayidx2.i, i64 32, !dbg !2033
  store i32 0, ptr %nbytes.i, align 8, !dbg !2034, !tbaa !2035
  %nkey.i = getelementptr inbounds i8, ptr %arrayidx2.i, i64 41, !dbg !2036
  store i8 0, ptr %nkey.i, align 1, !dbg !2037, !tbaa !2038
  store i16 1, ptr %it_flags.i, align 2, !dbg !2039, !tbaa !1668
  %time.i = getelementptr inbounds i8, ptr %arrayidx2.i, i64 24, !dbg !2040
  store i32 0, ptr %time.i, align 8, !dbg !2041, !tbaa !2042
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %arrayidx2.i, i8 0, i64 16, i1 false), !dbg !2043
  br i1 %cmp21.i, label %if.then23.i, label %if.end25.i, !dbg !2044

if.then23.i:                                      ; preds = %if.end.i80
  %17 = trunc nuw nsw i64 %indvars.iv to i32, !dbg !2045
  %call24.i = tail call i32 @do_get_lru_size(i32 noundef %17) #20, !dbg !2046
  tail call void @llvm.dbg.value(metadata i32 %call24.i, metadata !2014, metadata !DIExpression()), !dbg !2017
  br label %if.end25.i, !dbg !2049

if.end25.i:                                       ; preds = %if.end.i80, %if.then23.i
  %remaining.addr.0.i = phi i32 [ %call24.i, %if.then23.i ], [ %remaining, %if.end.i80 ]
  tail call void @llvm.dbg.value(metadata i32 %remaining.addr.0.i, metadata !2014, metadata !DIExpression()), !dbg !2017
  %tobool.not.i = icmp eq i32 %remaining.addr.0.i, 0, !dbg !2050
  %inc.i = add i32 %remaining.addr.0.i, 1
  %spec.select.i = select i1 %tobool.not.i, i32 0, i32 %inc.i, !dbg !2052
  tail call void @llvm.dbg.value(metadata i32 %spec.select.i, metadata !2014, metadata !DIExpression()), !dbg !2017
  %remaining30.i = getelementptr inbounds i8, ptr %arrayidx2.i, i64 44, !dbg !2053
  store i32 %spec.select.i, ptr %remaining30.i, align 4, !dbg !2054, !tbaa !1739
  %conv31.i = trunc i64 %indvars.iv to i8, !dbg !2055
  %slabs_clsid.i = getelementptr inbounds i8, ptr %arrayidx2.i, i64 40, !dbg !2056
  store i8 %conv31.i, ptr %slabs_clsid.i, align 8, !dbg !2057, !tbaa !2058
  %reclaimed.i = getelementptr inbounds i8, ptr %arrayidx2.i, i64 48, !dbg !2059
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %reclaimed.i, i8 0, i64 24, i1 false), !dbg !2060
  tail call void @do_item_linktail_q(ptr noundef nonnull %arrayidx2.i) #20, !dbg !2061
  %18 = load i32, ptr @crawler_count, align 4, !dbg !2062, !tbaa !943
  %inc42.i = add nsw i32 %18, 1, !dbg !2062
  store i32 %inc42.i, ptr @crawler_count, align 4, !dbg !2062, !tbaa !943
  tail call void @llvm.dbg.value(metadata i32 1, metadata !2016, metadata !DIExpression()), !dbg !2017
  br label %do_lru_crawler_start.exit, !dbg !2063

do_lru_crawler_start.exit:                        ; preds = %if.then50, %if.end25.i
  %starts.0.i = phi i32 [ 1, %if.end25.i ], [ 0, %if.then50 ], !dbg !2017
  tail call void @llvm.dbg.value(metadata i32 %starts.0.i, metadata !2016, metadata !DIExpression()), !dbg !2017
  %call47.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx.i) #20, !dbg !2064
  %add52 = add nsw i32 %starts.0.i, %starts.097, !dbg !2065
  tail call void @llvm.dbg.value(metadata i32 %add52, metadata !760, metadata !DIExpression()), !dbg !1905
  br label %for.inc, !dbg !2066

for.inc:                                          ; preds = %for.body, %do_lru_crawler_start.exit
  %starts.1 = phi i32 [ %add52, %do_lru_crawler_start.exit ], [ %starts.097, %for.body ], !dbg !1905
  tail call void @llvm.dbg.value(metadata i32 %starts.1, metadata !760, metadata !DIExpression()), !dbg !1905
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !2067
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !762, metadata !DIExpression()), !dbg !1996
  %exitcond.not = icmp eq i64 %indvars.iv.next, 256, !dbg !2068
  br i1 %exitcond.not, label %if.end54, label %for.body, !dbg !1997, !llvm.loop !2069

if.end54:                                         ; preds = %for.inc
  tail call void @llvm.dbg.value(metadata i32 %starts.1, metadata !760, metadata !DIExpression()), !dbg !1905
  %tobool55.not = icmp eq i32 %starts.1, 0, !dbg !2071
  br i1 %tobool55.not, label %if.end59, label %if.then56, !dbg !2003

if.then56:                                        ; preds = %if.end54.thread, %if.end54
  %starts.295 = phi i32 [ 1, %if.end54.thread ], [ %starts.1, %if.end54 ]
  tail call void @STATS_LOCK() #20, !dbg !2073
  store i8 1, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 11), align 1, !dbg !2075, !tbaa !1883
  %19 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 12), align 8, !dbg !2076, !tbaa !2077
  %inc57 = add i64 %19, 1, !dbg !2076
  store i64 %inc57, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 12), align 8, !dbg !2076, !tbaa !2077
  tail call void @STATS_UNLOCK() #20, !dbg !2080
  %call58 = tail call i32 @pthread_cond_signal(ptr noundef nonnull @lru_crawler_cond) #20, !dbg !2081
  br label %if.end59, !dbg !2082

if.end59:                                         ; preds = %if.then56, %if.end54
  %starts.296 = phi i32 [ %starts.295, %if.then56 ], [ 0, %if.end54 ]
  %call60 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !2083
  br label %cleanup, !dbg !2084

cleanup:                                          ; preds = %if.end59, %if.then39, %if.then34, %if.then20, %if.then12, %if.then6, %if.then
  %retval.0 = phi i32 [ -2, %if.then ], [ -1, %if.then12 ], [ -2, %if.then20 ], [ %starts.296, %if.end59 ], [ -2, %if.then34 ], [ -2, %if.then39 ], [ -1, %if.then6 ], !dbg !1905
  ret i32 %retval.0, !dbg !2085
}

declare !dbg !2086 void @STATS_LOCK() local_unnamed_addr #4

declare !dbg !2087 void @STATS_UNLOCK() local_unnamed_addr #4

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 0, 5) i32 @lru_crawler_crawl(ptr noundef %slabs, i32 noundef %type, ptr noundef %c, i32 noundef %sfd, i32 noundef %remaining) local_unnamed_addr #0 !dbg !2088 {
entry:
  %b = alloca ptr, align 8, !DIAssignID !2108
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2097, metadata !DIExpression(), metadata !2108, metadata ptr %b, metadata !DIExpression()), !dbg !2109
  %sid = alloca i32, align 4, !DIAssignID !2110
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2098, metadata !DIExpression(), metadata !2110, metadata ptr %sid, metadata !DIExpression()), !dbg !2109
  %tocrawl = alloca [256 x i8], align 16, !DIAssignID !2111
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2100, metadata !DIExpression(), metadata !2111, metadata ptr %tocrawl, metadata !DIExpression()), !dbg !2109
  tail call void @llvm.dbg.value(metadata ptr %slabs, metadata !2092, metadata !DIExpression()), !dbg !2109
  tail call void @llvm.dbg.value(metadata i32 %type, metadata !2093, metadata !DIExpression()), !dbg !2109
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2094, metadata !DIExpression()), !dbg !2109
  tail call void @llvm.dbg.value(metadata i32 %sfd, metadata !2095, metadata !DIExpression()), !dbg !2109
  tail call void @llvm.dbg.value(metadata i32 %remaining, metadata !2096, metadata !DIExpression()), !dbg !2109
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %b) #20, !dbg !2112
  store ptr null, ptr %b, align 8, !dbg !2113, !tbaa !1014, !DIAssignID !2114
  tail call void @llvm.dbg.assign(metadata ptr null, metadata !2097, metadata !DIExpression(), metadata !2114, metadata ptr %b, metadata !DIExpression()), !dbg !2109
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %sid) #20, !dbg !2115
  store i32 0, ptr %sid, align 4, !dbg !2116, !tbaa !943, !DIAssignID !2117
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !2098, metadata !DIExpression(), metadata !2117, metadata ptr %sid, metadata !DIExpression()), !dbg !2109
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2099, metadata !DIExpression()), !dbg !2109
  call void @llvm.lifetime.start.p0(i64 256, ptr nonnull %tocrawl) #20, !dbg !2118
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2102, metadata !DIExpression()), !dbg !2109
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(256) %tocrawl, i8 0, i64 256, i1 false), !dbg !2119, !DIAssignID !2120
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2100, metadata !DIExpression(), metadata !2120, metadata ptr %tocrawl, metadata !DIExpression()), !dbg !2109
  %call = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %slabs, ptr noundef nonnull dereferenceable(4) @.str.3) #25, !dbg !2121
  %cmp = icmp eq i32 %call, 0, !dbg !2122
  br i1 %cmp, label %for.body.preheader, label %if.else, !dbg !2123

for.body.preheader:                               ; preds = %entry
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(256) %tocrawl, i8 1, i64 256, i1 false), !dbg !2124, !tbaa !1045
  tail call void @llvm.dbg.assign(metadata i64 undef, metadata !2098, metadata !DIExpression(), metadata !2129, metadata ptr %sid, metadata !DIExpression()), !dbg !2109
  store i32 256, ptr %sid, align 4, !dbg !2130, !tbaa !943, !DIAssignID !2129
  br label %if.end30, !dbg !2131

if.else:                                          ; preds = %entry
  %call2 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %slabs, ptr noundef nonnull dereferenceable(5) @.str.4) #25, !dbg !2132
  %cmp3 = icmp eq i32 %call2, 0, !dbg !2133
  br i1 %cmp3, label %if.end30, label %if.else5, !dbg !2134

if.else5:                                         ; preds = %if.else
  %call6 = call ptr @strtok_r(ptr noundef %slabs, ptr noundef nonnull @.str.5, ptr noundef nonnull %b) #20, !dbg !2135
  tail call void @llvm.dbg.value(metadata ptr %call6, metadata !2103, metadata !DIExpression()), !dbg !2136
  %cmp8.not55 = icmp eq ptr %call6, null, !dbg !2137
  br i1 %cmp8.not55, label %if.end30, label %for.body9, !dbg !2139

for.body9:                                        ; preds = %if.else5, %if.end
  %p.056 = phi ptr [ %call27, %if.end ], [ %call6, %if.else5 ]
  tail call void @llvm.dbg.value(metadata ptr %p.056, metadata !2103, metadata !DIExpression()), !dbg !2136
  %call10 = call zeroext i1 @safe_strtoul(ptr noundef nonnull %p.056, ptr noundef nonnull %sid) #20, !dbg !2140
  br i1 %call10, label %lor.lhs.false, label %cleanup42, !dbg !2143

lor.lhs.false:                                    ; preds = %for.body9
  %0 = load i32, ptr %sid, align 4, !dbg !2144, !tbaa !943
  %1 = add i32 %0, -64, !dbg !2145
  %or.cond = icmp ult i32 %1, -63, !dbg !2145
  br i1 %or.cond, label %cleanup42, label %if.end, !dbg !2145

if.end:                                           ; preds = %lor.lhs.false
  %or = or disjoint i32 %0, 192, !dbg !2146
  %idxprom15 = zext nneg i32 %or to i64, !dbg !2147
  %arrayidx16 = getelementptr inbounds [256 x i8], ptr %tocrawl, i64 0, i64 %idxprom15, !dbg !2147
  store i8 1, ptr %arrayidx16, align 1, !dbg !2148, !tbaa !1045
  %idxprom18 = zext nneg i32 %0 to i64, !dbg !2149
  %arrayidx19 = getelementptr inbounds [256 x i8], ptr %tocrawl, i64 0, i64 %idxprom18, !dbg !2149
  store i8 1, ptr %arrayidx19, align 1, !dbg !2150, !tbaa !1045
  %or20 = or disjoint i32 %0, 64, !dbg !2151
  %idxprom21 = zext nneg i32 %or20 to i64, !dbg !2152
  %arrayidx22 = getelementptr inbounds [256 x i8], ptr %tocrawl, i64 0, i64 %idxprom21, !dbg !2152
  store i8 1, ptr %arrayidx22, align 1, !dbg !2153, !tbaa !1045
  %or23 = or disjoint i32 %0, 128, !dbg !2154
  %idxprom24 = zext nneg i32 %or23 to i64, !dbg !2155
  %arrayidx25 = getelementptr inbounds [256 x i8], ptr %tocrawl, i64 0, i64 %idxprom24, !dbg !2155
  store i8 1, ptr %arrayidx25, align 1, !dbg !2156, !tbaa !1045
  %call27 = call ptr @strtok_r(ptr noundef null, ptr noundef nonnull @.str.5, ptr noundef nonnull %b) #20, !dbg !2157
  tail call void @llvm.dbg.value(metadata ptr %call27, metadata !2103, metadata !DIExpression()), !dbg !2136
  %cmp8.not = icmp eq ptr %call27, null, !dbg !2137
  br i1 %cmp8.not, label %if.end30, label %for.body9, !dbg !2139, !llvm.loop !2158

if.end30:                                         ; preds = %if.end, %if.else5, %for.body.preheader, %if.else
  %hash_crawl.0 = phi ptr [ null, %if.else ], [ %tocrawl, %for.body.preheader ], [ %tocrawl, %if.else5 ], [ %tocrawl, %if.end ], !dbg !2109
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2102, metadata !DIExpression()), !dbg !2109
  %call32 = call i32 @lru_crawler_start(ptr noundef %hash_crawl.0, i32 noundef %remaining, i32 noundef %type, ptr noundef null, ptr noundef %c, i32 noundef %sfd), !dbg !2131
  tail call void @llvm.dbg.value(metadata i32 %call32, metadata !2099, metadata !DIExpression()), !dbg !2109
  %switch.tableidx = add i32 %call32, 2, !dbg !2160
  %2 = icmp ult i32 %switch.tableidx, 3, !dbg !2160
  br i1 %2, label %switch.lookup, label %cleanup42, !dbg !2160

switch.lookup:                                    ; preds = %if.end30
  %3 = zext nneg i32 %switch.tableidx to i64, !dbg !2160
  %switch.gep = getelementptr inbounds [3 x i32], ptr @switch.table.lru_crawler_crawl, i64 0, i64 %3, !dbg !2160
  %switch.load = load i32, ptr %switch.gep, align 4, !dbg !2160
  br label %cleanup42, !dbg !2160

cleanup42:                                        ; preds = %lor.lhs.false, %for.body9, %if.end30, %switch.lookup
  %retval.1 = phi i32 [ %switch.load, %switch.lookup ], [ 0, %if.end30 ], [ 2, %for.body9 ], [ 2, %lor.lhs.false ], !dbg !2109
  call void @llvm.lifetime.end.p0(i64 256, ptr nonnull %tocrawl) #20, !dbg !2161
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %sid) #20, !dbg !2161
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %b) #20, !dbg !2161
  ret i32 %retval.1, !dbg !2161
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #6

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare !dbg !2162 i32 @strcmp(ptr nocapture noundef, ptr nocapture noundef) local_unnamed_addr #7

; Function Attrs: mustprogress nofree nounwind willreturn
declare !dbg !2165 ptr @strtok_r(ptr noundef, ptr nocapture noundef readonly, ptr noundef) local_unnamed_addr #8

declare !dbg !2171 zeroext i1 @safe_strtoul(ptr noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @lru_crawler_pause() local_unnamed_addr #0 !dbg !2176 {
entry:
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !2177
  ret void, !dbg !2178
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @lru_crawler_resume() local_unnamed_addr #0 !dbg !2179 {
entry:
  %call = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_crawler_lock) #20, !dbg !2180
  ret void, !dbg !2181
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, argmem: none, inaccessiblemem: none) uwtable
define dso_local noundef i32 @init_lru_crawler(ptr noundef %arg) local_unnamed_addr #9 !dbg !2182 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2186, metadata !DIExpression()), !dbg !2187
  %.b = load i1, ptr @lru_crawler_initialized, align 4, !dbg !2188
  br i1 %.b, label %if.end, label %if.then, !dbg !2190

if.then:                                          ; preds = %entry
  store ptr %arg, ptr @storage, align 8, !dbg !2191, !tbaa !1014
  store ptr null, ptr getelementptr inbounds (%struct._crawler_module_t, ptr @active_crawler_mod, i64 0, i32 2), align 8, !dbg !2193, !tbaa !1586
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) @active_crawler_mod, i8 0, i64 16, i1 false), !dbg !2194
  store i1 true, ptr @lru_crawler_initialized, align 4, !dbg !2195
  br label %if.end, !dbg !2196

if.end:                                           ; preds = %if.then, %entry
  ret i32 0, !dbg !2197
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite)
declare !dbg !2198 noalias noundef ptr @calloc(i64 noundef, i64 noundef) local_unnamed_addr #10

; Function Attrs: nounwind
declare !dbg !2202 i32 @pthread_mutex_init(ptr noundef, ptr noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !2212 void @free(ptr allocptr nocapture noundef) local_unnamed_addr #11

declare !dbg !2215 i32 @item_is_flushed(ptr noundef) local_unnamed_addr #4

declare !dbg !2219 zeroext i1 @storage_validate_item(ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !2223 void @storage_delete(ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !2226 void @do_item_unlink_nolock(ptr noundef, i32 noundef) local_unnamed_addr #4

declare !dbg !2230 void @do_item_remove(ptr noundef) local_unnamed_addr #4

declare !dbg !2233 zeroext i1 @uriencode(ptr noundef, ptr noundef, i64 noundef, i64 noundef) local_unnamed_addr #4

; Function Attrs: nofree nounwind
declare !dbg !2237 noundef i32 @snprintf(ptr noalias nocapture noundef writeonly, i64 noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #5

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc noundef i32 @lru_crawler_write(ptr nocapture noundef %c) unnamed_addr #0 !dbg !2240 {
entry:
  %to_poll = alloca [1 x %struct.pollfd], align 4, !DIAssignID !2263
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2245, metadata !DIExpression(), metadata !2263, metadata ptr %to_poll, metadata !DIExpression()), !dbg !2264
  %buf = alloca [1 x i8], align 1, !DIAssignID !2265
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2255, metadata !DIExpression(), metadata !2265, metadata ptr %buf, metadata !DIExpression()), !dbg !2266
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2242, metadata !DIExpression()), !dbg !2264
  %bufused = getelementptr inbounds i8, ptr %c, i64 16, !dbg !2267
  %0 = load i32, ptr %bufused, align 8, !dbg !2267, !tbaa !1627
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !2243, metadata !DIExpression()), !dbg !2264
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2244, metadata !DIExpression()), !dbg !2264
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %to_poll) #20, !dbg !2268
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !2269
  %1 = load i32, ptr %sfd, align 8, !dbg !2269, !tbaa !1987
  store i32 %1, ptr %to_poll, align 4, !dbg !2270, !tbaa !2271, !DIAssignID !2273
  tail call void @llvm.dbg.assign(metadata i32 %1, metadata !2245, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !2273, metadata ptr %to_poll, metadata !DIExpression()), !dbg !2264
  %events = getelementptr inbounds i8, ptr %to_poll, i64 4, !dbg !2274
  store i16 4, ptr %events, align 4, !dbg !2275, !tbaa !2276, !DIAssignID !2277
  tail call void @llvm.dbg.assign(metadata i16 4, metadata !2245, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !2277, metadata ptr %events, metadata !DIExpression()), !dbg !2264
  %2 = load ptr, ptr %c, align 8, !dbg !2278, !tbaa !1848
  %cmp = icmp eq ptr %2, null, !dbg !2280
  br i1 %cmp, label %cleanup80, label %if.end, !dbg !2281

if.end:                                           ; preds = %entry
  %cmp3 = icmp eq i32 %0, 0, !dbg !2282
  br i1 %cmp3, label %cleanup80, label %while.cond.preheader, !dbg !2284

while.cond.preheader:                             ; preds = %if.end
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2244, metadata !DIExpression()), !dbg !2264
  %revents = getelementptr inbounds i8, ptr %to_poll, i64 6
  %buf49 = getelementptr inbounds i8, ptr %c, i64 24
  br label %while.body, !dbg !2285

while.body:                                       ; preds = %while.cond.preheader, %cleanup76
  %sent.0120 = phi i32 [ 0, %while.cond.preheader ], [ %sent.3, %cleanup76 ]
  tail call void @llvm.dbg.value(metadata i32 %sent.0120, metadata !2244, metadata !DIExpression()), !dbg !2264
  %call = call i32 @poll(ptr noundef nonnull %to_poll, i64 noundef 1, i32 noundef 1000) #20, !dbg !2286
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !2253, metadata !DIExpression()), !dbg !2287
  %cmp7 = icmp slt i32 %call, 0, !dbg !2288
  br i1 %cmp7, label %if.then8, label %if.end9, !dbg !2290

if.then8:                                         ; preds = %while.body
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2291, metadata !DIExpression()), !dbg !2294
  %3 = load ptr, ptr %c, align 8, !dbg !2297, !tbaa !1848
  call void @sidethread_conn_close(ptr noundef %3) #20, !dbg !2298
  store ptr null, ptr %c, align 8, !dbg !2299, !tbaa !1848
  %4 = load ptr, ptr %buf49, align 8, !dbg !2300, !tbaa !1643
  call void @free(ptr noundef %4) #20, !dbg !2301
  store ptr null, ptr %buf49, align 8, !dbg !2302, !tbaa !1643
  br label %cleanup80, !dbg !2303

if.end9:                                          ; preds = %while.body
  %cmp10 = icmp eq i32 %call, 0, !dbg !2304
  br i1 %cmp10, label %cleanup80, label %if.end12, !dbg !2306

if.end12:                                         ; preds = %if.end9
  %5 = load i16, ptr %revents, align 2, !dbg !2307, !tbaa !2308
  %6 = and i16 %5, 1, !dbg !2309
  %tobool.not = icmp eq i16 %6, 0, !dbg !2309
  br i1 %tobool.not, label %if.end34, label %if.then14, !dbg !2310

if.then14:                                        ; preds = %if.end12
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %buf) #20, !dbg !2311
  %7 = load ptr, ptr %c, align 8, !dbg !2312, !tbaa !1848
  %read = getelementptr inbounds i8, ptr %7, i64 472, !dbg !2313
  %8 = load ptr, ptr %read, align 8, !dbg !2313, !tbaa !2314
  %call18 = call i64 %8(ptr noundef %7, ptr noundef nonnull %buf, i64 noundef 1) #20, !dbg !2322
  %conv19 = trunc i64 %call18 to i32, !dbg !2322
  tail call void @llvm.dbg.value(metadata i32 %conv19, metadata !2258, metadata !DIExpression()), !dbg !2266
  switch i32 %conv19, label %cleanup.thread [
    i32 0, label %cleanup
    i32 -1, label %land.lhs.true
  ], !dbg !2323

land.lhs.true:                                    ; preds = %if.then14
  %call24 = tail call ptr @__errno_location() #26, !dbg !2325
  %9 = load i32, ptr %call24, align 4, !dbg !2325, !tbaa !943
  %cmp25.not = icmp eq i32 %9, 11, !dbg !2326
  br i1 %cmp25.not, label %cleanup.thread, label %cleanup, !dbg !2327

cleanup.thread:                                   ; preds = %if.then14, %land.lhs.true
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %buf) #20, !dbg !2328
  %.pre = load i16, ptr %revents, align 2, !dbg !2329, !tbaa !2308
  br label %if.end34

cleanup:                                          ; preds = %if.then14, %land.lhs.true
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2291, metadata !DIExpression()), !dbg !2330
  %10 = load ptr, ptr %c, align 8, !dbg !2333, !tbaa !1848
  call void @sidethread_conn_close(ptr noundef %10) #20, !dbg !2334
  store ptr null, ptr %c, align 8, !dbg !2335, !tbaa !1848
  %11 = load ptr, ptr %buf49, align 8, !dbg !2336, !tbaa !1643
  call void @free(ptr noundef %11) #20, !dbg !2337
  store ptr null, ptr %buf49, align 8, !dbg !2338, !tbaa !1643
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %buf) #20, !dbg !2328
  br label %cleanup80

if.end34:                                         ; preds = %cleanup.thread, %if.end12
  %12 = phi i16 [ %.pre, %cleanup.thread ], [ %5, %if.end12 ], !dbg !2329
  %conv37121 = zext i16 %12 to i32, !dbg !2339
  %and38 = and i32 %conv37121, 24, !dbg !2340
  %tobool39.not = icmp eq i32 %and38, 0, !dbg !2340
  br i1 %tobool39.not, label %if.else, label %if.then40, !dbg !2341

if.then40:                                        ; preds = %if.end34
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2291, metadata !DIExpression()), !dbg !2342
  %13 = load ptr, ptr %c, align 8, !dbg !2345, !tbaa !1848
  call void @sidethread_conn_close(ptr noundef %13) #20, !dbg !2346
  store ptr null, ptr %c, align 8, !dbg !2347, !tbaa !1848
  %14 = load ptr, ptr %buf49, align 8, !dbg !2348, !tbaa !1643
  call void @free(ptr noundef %14) #20, !dbg !2349
  store ptr null, ptr %buf49, align 8, !dbg !2350, !tbaa !1643
  br label %cleanup80, !dbg !2351

if.else:                                          ; preds = %if.end34
  %and44 = and i32 %conv37121, 4, !dbg !2352
  %tobool45.not = icmp eq i32 %and44, 0, !dbg !2352
  br i1 %tobool45.not, label %cleanup76, label %if.then46, !dbg !2353

if.then46:                                        ; preds = %if.else
  %15 = load ptr, ptr %c, align 8, !dbg !2354, !tbaa !1848
  %write = getelementptr inbounds i8, ptr %15, i64 488, !dbg !2355
  %16 = load ptr, ptr %write, align 8, !dbg !2355, !tbaa !2356
  %17 = load ptr, ptr %buf49, align 8, !dbg !2357, !tbaa !1643
  %idx.ext = zext i32 %sent.0120 to i64, !dbg !2358
  %add.ptr = getelementptr inbounds i8, ptr %17, i64 %idx.ext, !dbg !2358
  %sub = sub i32 %0, %sent.0120, !dbg !2359
  %conv50 = zext i32 %sub to i64, !dbg !2360
  %call51 = call i64 %16(ptr noundef %15, ptr noundef %add.ptr, i64 noundef %conv50) #20, !dbg !2361
  %conv52 = trunc i64 %call51 to i32, !dbg !2361
  tail call void @llvm.dbg.value(metadata i32 %conv52, metadata !2259, metadata !DIExpression()), !dbg !2362
  switch i32 %conv52, label %if.end70 [
    i32 -1, label %if.then55
    i32 0, label %if.then68
  ], !dbg !2363

if.then55:                                        ; preds = %if.then46
  %call56 = tail call ptr @__errno_location() #26, !dbg !2364
  %18 = load i32, ptr %call56, align 4, !dbg !2364, !tbaa !943
  %cmp57.not = icmp eq i32 %18, 11, !dbg !2368
  br i1 %cmp57.not, label %if.end70, label %if.then63, !dbg !2369

if.then63:                                        ; preds = %if.then55
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2291, metadata !DIExpression()), !dbg !2370
  %19 = load ptr, ptr %c, align 8, !dbg !2373, !tbaa !1848
  call void @sidethread_conn_close(ptr noundef %19) #20, !dbg !2374
  store ptr null, ptr %c, align 8, !dbg !2375, !tbaa !1848
  %20 = load ptr, ptr %buf49, align 8, !dbg !2376, !tbaa !1643
  call void @free(ptr noundef %20) #20, !dbg !2377
  store ptr null, ptr %buf49, align 8, !dbg !2378, !tbaa !1643
  br label %cleanup80, !dbg !2379

if.then68:                                        ; preds = %if.then46
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2291, metadata !DIExpression()), !dbg !2380
  %21 = load ptr, ptr %c, align 8, !dbg !2384, !tbaa !1848
  call void @sidethread_conn_close(ptr noundef %21) #20, !dbg !2385
  store ptr null, ptr %c, align 8, !dbg !2386, !tbaa !1848
  %22 = load ptr, ptr %buf49, align 8, !dbg !2387, !tbaa !1643
  call void @free(ptr noundef %22) #20, !dbg !2388
  store ptr null, ptr %buf49, align 8, !dbg !2389, !tbaa !1643
  br label %cleanup80, !dbg !2390

if.end70:                                         ; preds = %if.then46, %if.then55
  %add = add i32 %sent.0120, %conv52, !dbg !2391
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !2244, metadata !DIExpression()), !dbg !2264
  br label %cleanup76, !dbg !2392

cleanup76:                                        ; preds = %if.end70, %if.else
  %sent.3 = phi i32 [ %sent.0120, %if.else ], [ %add, %if.end70 ], !dbg !2393
  tail call void @llvm.dbg.value(metadata i32 %sent.3, metadata !2244, metadata !DIExpression()), !dbg !2264
  %cmp6 = icmp ult i32 %sent.3, %0, !dbg !2394
  br i1 %cmp6, label %while.body, label %while.end, !dbg !2285, !llvm.loop !2395

while.end:                                        ; preds = %cleanup76
  store i32 0, ptr %bufused, align 8, !dbg !2397, !tbaa !1627
  br label %cleanup80, !dbg !2398

cleanup80:                                        ; preds = %if.end9, %if.then68, %if.then63, %cleanup, %if.then40, %if.then8, %if.end, %entry, %while.end
  %retval.6 = phi i32 [ 0, %while.end ], [ -1, %entry ], [ 0, %if.end ], [ -1, %if.then68 ], [ -1, %if.then63 ], [ -1, %cleanup ], [ -1, %if.then40 ], [ -1, %if.then8 ], [ 0, %if.end9 ], !dbg !2264
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %to_poll) #20, !dbg !2399
  ret i32 %retval.6, !dbg !2399
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #12

declare !dbg !2400 i32 @poll(ptr noundef, i64 noundef, i32 noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nofree nosync nounwind willreturn memory(none)
declare !dbg !2405 ptr @__errno_location() local_unnamed_addr #13

declare !dbg !2410 void @sidethread_conn_close(ptr noundef) local_unnamed_addr #4

declare !dbg !2413 i64 @base64_encode(ptr noundef, i64 noundef, ptr noundef, i64 noundef) local_unnamed_addr #4

declare !dbg !2419 ptr @do_item_crawl_q(ptr noundef) local_unnamed_addr #4

declare !dbg !2422 ptr @item_trylock(i32 noundef) local_unnamed_addr #4

declare !dbg !2425 void @item_trylock_unlock(ptr noundef) local_unnamed_addr #4

declare !dbg !2426 i32 @usleep(i32 noundef) local_unnamed_addr #4

declare !dbg !2431 ptr @assoc_get_iterator() local_unnamed_addr #4

declare !dbg !2435 zeroext i1 @assoc_iterate(ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !2439 void @assoc_iterate_final(ptr noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind willreturn allockind("realloc") allocsize(1) memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !2440 noalias noundef ptr @realloc(ptr allocptr nocapture noundef, i64 noundef) local_unnamed_addr #14

declare !dbg !2443 void @do_item_unlinktail_q(ptr noundef) local_unnamed_addr #4

declare !dbg !2444 void @do_item_stats_add_crawl(i32 noundef, i64 noundef, i64 noundef, i64 noundef) local_unnamed_addr #4

declare !dbg !2448 void @redispatch_conn(ptr noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare !dbg !2449 noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #15

declare !dbg !2452 i32 @do_get_lru_size(i32 noundef) local_unnamed_addr #4

declare !dbg !2455 void @do_item_linktail_q(ptr noundef) local_unnamed_addr #4

; Function Attrs: nofree nounwind
declare noundef i64 @fwrite(ptr nocapture noundef, i64 noundef, i64 noundef, ptr nocapture noundef) local_unnamed_addr #16

; Function Attrs: nofree nounwind
declare noundef i32 @fputc(i32 noundef, ptr nocapture noundef) local_unnamed_addr #16

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #17 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #18

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #18

attributes #0 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: write) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #7 = { mustprogress nofree nounwind willreturn memory(argmem: read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { mustprogress nofree nounwind willreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, argmem: none, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #13 = { mustprogress nofree nosync nounwind willreturn memory(none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { mustprogress nounwind willreturn allockind("realloc") allocsize(1) memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #16 = { nofree nounwind }
attributes #17 = { nounwind uwtable }
attributes #18 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #19 = { nounwind allocsize(0,1) }
attributes #20 = { nounwind }
attributes #21 = { cold nounwind }
attributes #22 = { cold }
attributes #23 = { nounwind allocsize(1) }
attributes #24 = { nounwind allocsize(0) }
attributes #25 = { nobuiltin nounwind willreturn memory(read) }
attributes #26 = { nounwind willreturn memory(none) }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!905, !906, !907, !908, !909, !910, !911}
!llvm.ident = !{!912}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "crawler_expired_mod", scope: !2, file: !3, line: 66, type: !683, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !88, globals: !680, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "crawler.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "26ee97ea421e9ac148c04d922133fd05")
!4 = !{!5, !13, !21, !39, !53, !72, !77, !82}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "crawler_run_type", file: !6, line: 619, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "./memcached.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "a52021954a5d6b153b5bc084e2fbff2b")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12}
!9 = !DIEnumerator(name: "CRAWLER_AUTOEXPIRE", value: 0)
!10 = !DIEnumerator(name: "CRAWLER_EXPIRED", value: 1)
!11 = !DIEnumerator(name: "CRAWLER_METADUMP", value: 2)
!12 = !DIEnumerator(name: "CRAWLER_MGDUMP", value: 3)
!13 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "crawler_result_type", file: !14, line: 27, baseType: !7, size: 32, elements: !15)
!14 = !DIFile(filename: "./crawler.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "4dc9e6e54966538ea20b64490631aef9")
!15 = !{!16, !17, !18, !19, !20}
!16 = !DIEnumerator(name: "CRAWLER_OK", value: 0)
!17 = !DIEnumerator(name: "CRAWLER_RUNNING", value: 1)
!18 = !DIEnumerator(name: "CRAWLER_BADCLASS", value: 2)
!19 = !DIEnumerator(name: "CRAWLER_NOTSTARTED", value: 3)
!20 = !DIEnumerator(name: "CRAWLER_ERROR", value: 4)
!21 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "conn_states", file: !6, line: 204, baseType: !7, size: 32, elements: !22)
!22 = !{!23, !24, !25, !26, !27, !28, !29, !30, !31, !32, !33, !34, !35, !36, !37, !38}
!23 = !DIEnumerator(name: "conn_listening", value: 0)
!24 = !DIEnumerator(name: "conn_new_cmd", value: 1)
!25 = !DIEnumerator(name: "conn_waiting", value: 2)
!26 = !DIEnumerator(name: "conn_read", value: 3)
!27 = !DIEnumerator(name: "conn_parse_cmd", value: 4)
!28 = !DIEnumerator(name: "conn_write", value: 5)
!29 = !DIEnumerator(name: "conn_nread", value: 6)
!30 = !DIEnumerator(name: "conn_swallow", value: 7)
!31 = !DIEnumerator(name: "conn_closing", value: 8)
!32 = !DIEnumerator(name: "conn_mwrite", value: 9)
!33 = !DIEnumerator(name: "conn_closed", value: 10)
!34 = !DIEnumerator(name: "conn_watch", value: 11)
!35 = !DIEnumerator(name: "conn_io_queue", value: 12)
!36 = !DIEnumerator(name: "conn_io_resume", value: 13)
!37 = !DIEnumerator(name: "conn_io_pending", value: 14)
!38 = !DIEnumerator(name: "conn_max_state", value: 15)
!39 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "bin_substates", file: !6, line: 223, baseType: !7, size: 32, elements: !40)
!40 = !{!41, !42, !43, !44, !45, !46, !47, !48, !49, !50, !51, !52}
!41 = !DIEnumerator(name: "bin_no_state", value: 0)
!42 = !DIEnumerator(name: "bin_reading_set_header", value: 1)
!43 = !DIEnumerator(name: "bin_reading_cas_header", value: 2)
!44 = !DIEnumerator(name: "bin_read_set_value", value: 3)
!45 = !DIEnumerator(name: "bin_reading_get_key", value: 4)
!46 = !DIEnumerator(name: "bin_reading_stat", value: 5)
!47 = !DIEnumerator(name: "bin_reading_del_header", value: 6)
!48 = !DIEnumerator(name: "bin_reading_incr_header", value: 7)
!49 = !DIEnumerator(name: "bin_read_flush_exptime", value: 8)
!50 = !DIEnumerator(name: "bin_reading_sasl_auth", value: 9)
!51 = !DIEnumerator(name: "bin_reading_sasl_auth_data", value: 10)
!52 = !DIEnumerator(name: "bin_reading_touch_key", value: 11)
!53 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "log_entry_type", file: !54, line: 16, baseType: !7, size: 32, elements: !55)
!54 = !DIFile(filename: "./logger.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "e743c4228b1e0bc1c91bec9cfd28d5ab")
!55 = !{!56, !57, !58, !59, !60, !61, !62, !63, !64, !65, !66, !67, !68, !69, !70, !71}
!56 = !DIEnumerator(name: "LOGGER_ASCII_CMD", value: 0)
!57 = !DIEnumerator(name: "LOGGER_EVICTION", value: 1)
!58 = !DIEnumerator(name: "LOGGER_ITEM_GET", value: 2)
!59 = !DIEnumerator(name: "LOGGER_ITEM_STORE", value: 3)
!60 = !DIEnumerator(name: "LOGGER_CRAWLER_STATUS", value: 4)
!61 = !DIEnumerator(name: "LOGGER_SLAB_MOVE", value: 5)
!62 = !DIEnumerator(name: "LOGGER_CONNECTION_NEW", value: 6)
!63 = !DIEnumerator(name: "LOGGER_CONNECTION_CLOSE", value: 7)
!64 = !DIEnumerator(name: "LOGGER_DELETIONS", value: 8)
!65 = !DIEnumerator(name: "LOGGER_EXTSTORE_WRITE", value: 9)
!66 = !DIEnumerator(name: "LOGGER_COMPACT_START", value: 10)
!67 = !DIEnumerator(name: "LOGGER_COMPACT_ABORT", value: 11)
!68 = !DIEnumerator(name: "LOGGER_COMPACT_READ_START", value: 12)
!69 = !DIEnumerator(name: "LOGGER_COMPACT_READ_END", value: 13)
!70 = !DIEnumerator(name: "LOGGER_COMPACT_END", value: 14)
!71 = !DIEnumerator(name: "LOGGER_COMPACT_FRAGINFO", value: 15)
!72 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "protocol", file: !6, line: 238, baseType: !7, size: 32, elements: !73)
!73 = !{!74, !75, !76}
!74 = !DIEnumerator(name: "ascii_prot", value: 3)
!75 = !DIEnumerator(name: "binary_prot", value: 4)
!76 = !DIEnumerator(name: "negotiating_prot", value: 5)
!77 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "network_transport", file: !6, line: 247, baseType: !7, size: 32, elements: !78)
!78 = !{!79, !80, !81}
!79 = !DIEnumerator(name: "local_transport", value: 0)
!80 = !DIEnumerator(name: "tcp_transport", value: 1)
!81 = !DIEnumerator(name: "udp_transport", value: 2)
!82 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "close_reasons", file: !6, line: 266, baseType: !7, size: 32, elements: !83)
!83 = !{!84, !85, !86, !87}
!84 = !DIEnumerator(name: "ERROR_CLOSE", value: 0)
!85 = !DIEnumerator(name: "NORMAL_CLOSE", value: 1)
!86 = !DIEnumerator(name: "IDLE_TIMEOUT_CLOSE", value: 2)
!87 = !DIEnumerator(name: "SHUTDOWN_CLOSE", value: 3)
!88 = !{!89, !90, !155, !156, !125, !160, !133, !137, !161, !679, !529}
!89 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!90 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !91, size: 64)
!91 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "crawler_expired_data", file: !14, line: 17, size: 1098176, elements: !92)
!92 = !{!93, !126, !151, !152, !153, !154}
!93 = !DIDerivedType(tag: DW_TAG_member, name: "lock", scope: !91, file: !14, line: 18, baseType: !94, size: 320)
!94 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutex_t", file: !95, line: 72, baseType: !96)
!95 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h", directory: "", checksumkind: CSK_MD5, checksum: "8a5acdbeec491eca11cf81cb1ef77ea7")
!96 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !95, line: 67, size: 320, elements: !97)
!97 = !{!98, !119, !124}
!98 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !96, file: !95, line: 69, baseType: !99, size: 320)
!99 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_mutex_s", file: !100, line: 22, size: 320, elements: !101)
!100 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h", directory: "", checksumkind: CSK_MD5, checksum: "6b075eca9ab0e2d761b2afc4ecfab776")
!101 = !{!102, !104, !105, !106, !107, !108, !110, !111}
!102 = !DIDerivedType(tag: DW_TAG_member, name: "__lock", scope: !99, file: !100, line: 24, baseType: !103, size: 32)
!103 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!104 = !DIDerivedType(tag: DW_TAG_member, name: "__count", scope: !99, file: !100, line: 25, baseType: !7, size: 32, offset: 32)
!105 = !DIDerivedType(tag: DW_TAG_member, name: "__owner", scope: !99, file: !100, line: 26, baseType: !103, size: 32, offset: 64)
!106 = !DIDerivedType(tag: DW_TAG_member, name: "__nusers", scope: !99, file: !100, line: 28, baseType: !7, size: 32, offset: 96)
!107 = !DIDerivedType(tag: DW_TAG_member, name: "__kind", scope: !99, file: !100, line: 32, baseType: !103, size: 32, offset: 128)
!108 = !DIDerivedType(tag: DW_TAG_member, name: "__spins", scope: !99, file: !100, line: 34, baseType: !109, size: 16, offset: 160)
!109 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!110 = !DIDerivedType(tag: DW_TAG_member, name: "__elision", scope: !99, file: !100, line: 35, baseType: !109, size: 16, offset: 176)
!111 = !DIDerivedType(tag: DW_TAG_member, name: "__list", scope: !99, file: !100, line: 36, baseType: !112, size: 128, offset: 192)
!112 = !DIDerivedType(tag: DW_TAG_typedef, name: "__pthread_list_t", file: !113, line: 55, baseType: !114)
!113 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h", directory: "", checksumkind: CSK_MD5, checksum: "b9a7199822bce372686baacd32a9f4f3")
!114 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_internal_list", file: !113, line: 51, size: 128, elements: !115)
!115 = !{!116, !118}
!116 = !DIDerivedType(tag: DW_TAG_member, name: "__prev", scope: !114, file: !113, line: 53, baseType: !117, size: 64)
!117 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !114, size: 64)
!118 = !DIDerivedType(tag: DW_TAG_member, name: "__next", scope: !114, file: !113, line: 54, baseType: !117, size: 64, offset: 64)
!119 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !96, file: !95, line: 70, baseType: !120, size: 320)
!120 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 320, elements: !122)
!121 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!122 = !{!123}
!123 = !DISubrange(count: 40)
!124 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !96, file: !95, line: 71, baseType: !125, size: 64)
!125 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!126 = !DIDerivedType(tag: DW_TAG_member, name: "crawlerstats", scope: !91, file: !14, line: 19, baseType: !127, size: 1097728, offset: 320)
!127 = !DICompositeType(tag: DW_TAG_array_type, baseType: !128, size: 1097728, elements: !149)
!128 = !DIDerivedType(tag: DW_TAG_typedef, name: "crawlerstats_t", file: !14, line: 15, baseType: !129)
!129 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !14, line: 6, size: 4288, elements: !130)
!130 = !{!131, !140, !141, !142, !143, !144, !146, !147}
!131 = !DIDerivedType(tag: DW_TAG_member, name: "histo", scope: !129, file: !14, line: 7, baseType: !132, size: 3904)
!132 = !DICompositeType(tag: DW_TAG_array_type, baseType: !133, size: 3904, elements: !138)
!133 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !134, line: 27, baseType: !135)
!134 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!135 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !136, line: 45, baseType: !137)
!136 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!137 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!138 = !{!139}
!139 = !DISubrange(count: 61)
!140 = !DIDerivedType(tag: DW_TAG_member, name: "ttl_hourplus", scope: !129, file: !14, line: 8, baseType: !133, size: 64, offset: 3904)
!141 = !DIDerivedType(tag: DW_TAG_member, name: "noexp", scope: !129, file: !14, line: 9, baseType: !133, size: 64, offset: 3968)
!142 = !DIDerivedType(tag: DW_TAG_member, name: "reclaimed", scope: !129, file: !14, line: 10, baseType: !133, size: 64, offset: 4032)
!143 = !DIDerivedType(tag: DW_TAG_member, name: "seen", scope: !129, file: !14, line: 11, baseType: !133, size: 64, offset: 4096)
!144 = !DIDerivedType(tag: DW_TAG_member, name: "start_time", scope: !129, file: !14, line: 12, baseType: !145, size: 32, offset: 4160)
!145 = !DIDerivedType(tag: DW_TAG_typedef, name: "rel_time_t", file: !54, line: 14, baseType: !7)
!146 = !DIDerivedType(tag: DW_TAG_member, name: "end_time", scope: !129, file: !14, line: 13, baseType: !145, size: 32, offset: 4192)
!147 = !DIDerivedType(tag: DW_TAG_member, name: "run_complete", scope: !129, file: !14, line: 14, baseType: !148, size: 8, offset: 4224)
!148 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!149 = !{!150}
!150 = !DISubrange(count: 256)
!151 = !DIDerivedType(tag: DW_TAG_member, name: "start_time", scope: !91, file: !14, line: 21, baseType: !145, size: 32, offset: 1098048)
!152 = !DIDerivedType(tag: DW_TAG_member, name: "end_time", scope: !91, file: !14, line: 22, baseType: !145, size: 32, offset: 1098080)
!153 = !DIDerivedType(tag: DW_TAG_member, name: "crawl_complete", scope: !91, file: !14, line: 23, baseType: !148, size: 8, offset: 1098112)
!154 = !DIDerivedType(tag: DW_TAG_member, name: "is_external", scope: !91, file: !14, line: 24, baseType: !148, size: 8, offset: 1098120)
!155 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !121, size: 64)
!156 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !157, size: 64)
!157 = !DIDerivedType(tag: DW_TAG_typedef, name: "client_flags_t", file: !6, line: 99, baseType: !158)
!158 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !134, line: 26, baseType: !159)
!159 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !136, line: 42, baseType: !7)
!160 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!161 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !162, size: 64)
!162 = !DIDerivedType(tag: DW_TAG_typedef, name: "conn", file: !6, line: 813, baseType: !163)
!163 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "conn", file: !6, line: 829, size: 3968, elements: !164)
!164 = !{!165, !169, !170, !171, !172, !173, !174, !175, !176, !177, !178, !179, !180, !265, !266, !267, !268, !269, !270, !271, !602, !603, !604, !605, !606, !607, !608, !610, !611, !612, !613, !614, !615, !616, !617, !618, !624, !645, !646, !647, !648, !649, !650, !651, !652, !656, !663, !678}
!165 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_conn", scope: !163, file: !6, line: 830, baseType: !166, size: 64)
!166 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !167, size: 64)
!167 = !DIDerivedType(tag: DW_TAG_typedef, name: "sasl_conn_t", file: !168, line: 16, baseType: !89)
!168 = !DIFile(filename: "./sasl_defs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "3a8678a43d09d8e311388b26eedc7a3e")
!169 = !DIDerivedType(tag: DW_TAG_member, name: "sfd", scope: !163, file: !6, line: 831, baseType: !103, size: 32, offset: 64)
!170 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_started", scope: !163, file: !6, line: 832, baseType: !148, size: 8, offset: 96)
!171 = !DIDerivedType(tag: DW_TAG_member, name: "authenticated", scope: !163, file: !6, line: 833, baseType: !148, size: 8, offset: 104)
!172 = !DIDerivedType(tag: DW_TAG_member, name: "set_stale", scope: !163, file: !6, line: 834, baseType: !148, size: 8, offset: 112)
!173 = !DIDerivedType(tag: DW_TAG_member, name: "mset_res", scope: !163, file: !6, line: 835, baseType: !148, size: 8, offset: 120)
!174 = !DIDerivedType(tag: DW_TAG_member, name: "close_after_write", scope: !163, file: !6, line: 836, baseType: !148, size: 8, offset: 128)
!175 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_malloced", scope: !163, file: !6, line: 837, baseType: !148, size: 8, offset: 136)
!176 = !DIDerivedType(tag: DW_TAG_member, name: "item_malloced", scope: !163, file: !6, line: 838, baseType: !148, size: 8, offset: 144)
!177 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !163, file: !6, line: 844, baseType: !21, size: 32, offset: 160)
!178 = !DIDerivedType(tag: DW_TAG_member, name: "substate", scope: !163, file: !6, line: 845, baseType: !39, size: 32, offset: 192)
!179 = !DIDerivedType(tag: DW_TAG_member, name: "last_cmd_time", scope: !163, file: !6, line: 846, baseType: !145, size: 32, offset: 224)
!180 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !163, file: !6, line: 847, baseType: !181, size: 1024, offset: 256)
!181 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event", file: !182, line: 123, size: 1024, elements: !183)
!182 = !DIFile(filename: "/usr/include/event2/event_struct.h", directory: "", checksumkind: CSK_MD5, checksum: "005d89b34bed2ed9e30b0cc3160619c1")
!183 = !{!184, !218, !228, !229, !232, !262, !263, !264}
!184 = !DIDerivedType(tag: DW_TAG_member, name: "ev_evcallback", scope: !181, file: !182, line: 124, baseType: !185, size: 320)
!185 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event_callback", file: !182, line: 107, size: 320, elements: !186)
!186 = !{!187, !194, !195, !199, !200, !217}
!187 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_active_next", scope: !185, file: !182, line: 108, baseType: !188, size: 128)
!188 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !185, file: !182, line: 108, size: 128, elements: !189)
!189 = !{!190, !192}
!190 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !188, file: !182, line: 108, baseType: !191, size: 64)
!191 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !185, size: 64)
!192 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !188, file: !182, line: 108, baseType: !193, size: 64, offset: 64)
!193 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !191, size: 64)
!194 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_flags", scope: !185, file: !182, line: 109, baseType: !109, size: 16, offset: 128)
!195 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_pri", scope: !185, file: !182, line: 110, baseType: !196, size: 8, offset: 144)
!196 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !134, line: 24, baseType: !197)
!197 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !136, line: 38, baseType: !198)
!198 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!199 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_closure", scope: !185, file: !182, line: 111, baseType: !196, size: 8, offset: 152)
!200 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cb_union", scope: !185, file: !182, line: 118, baseType: !201, size: 64, offset: 192)
!201 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !185, file: !182, line: 113, size: 64, elements: !202)
!202 = !{!203, !207, !211, !216}
!203 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_callback", scope: !201, file: !182, line: 114, baseType: !204, size: 64)
!204 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !205, size: 64)
!205 = !DISubroutineType(types: !206)
!206 = !{null, !103, !109, !89}
!207 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_selfcb", scope: !201, file: !182, line: 115, baseType: !208, size: 64)
!208 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !209, size: 64)
!209 = !DISubroutineType(types: !210)
!210 = !{null, !191, !89}
!211 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_evfinalize", scope: !201, file: !182, line: 116, baseType: !212, size: 64)
!212 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !213, size: 64)
!213 = !DISubroutineType(types: !214)
!214 = !{null, !215, !89}
!215 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !181, size: 64)
!216 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cbfinalize", scope: !201, file: !182, line: 117, baseType: !208, size: 64)
!217 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_arg", scope: !185, file: !182, line: 119, baseType: !89, size: 64, offset: 256)
!218 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout_pos", scope: !181, file: !182, line: 130, baseType: !219, size: 128, offset: 320)
!219 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !181, file: !182, line: 127, size: 128, elements: !220)
!220 = !{!221, !227}
!221 = !DIDerivedType(tag: DW_TAG_member, name: "ev_next_with_common_timeout", scope: !219, file: !182, line: 128, baseType: !222, size: 128)
!222 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !219, file: !182, line: 128, size: 128, elements: !223)
!223 = !{!224, !225}
!224 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !222, file: !182, line: 128, baseType: !215, size: 64)
!225 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !222, file: !182, line: 128, baseType: !226, size: 64, offset: 64)
!226 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !215, size: 64)
!227 = !DIDerivedType(tag: DW_TAG_member, name: "min_heap_idx", scope: !219, file: !182, line: 129, baseType: !103, size: 32)
!228 = !DIDerivedType(tag: DW_TAG_member, name: "ev_fd", scope: !181, file: !182, line: 131, baseType: !103, size: 32, offset: 448)
!229 = !DIDerivedType(tag: DW_TAG_member, name: "ev_base", scope: !181, file: !182, line: 133, baseType: !230, size: 64, offset: 512)
!230 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !231, size: 64)
!231 = !DICompositeType(tag: DW_TAG_structure_type, name: "event_base", file: !182, line: 122, flags: DIFlagFwdDecl)
!232 = !DIDerivedType(tag: DW_TAG_member, name: "ev_", scope: !181, file: !182, line: 149, baseType: !233, size: 256, offset: 576)
!233 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !181, file: !182, line: 135, size: 256, elements: !234)
!234 = !{!235, !251}
!235 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io", scope: !233, file: !182, line: 140, baseType: !236, size: 256)
!236 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !233, file: !182, line: 137, size: 256, elements: !237)
!237 = !{!238, !243}
!238 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io_next", scope: !236, file: !182, line: 138, baseType: !239, size: 128)
!239 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !236, file: !182, line: 138, size: 128, elements: !240)
!240 = !{!241, !242}
!241 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !239, file: !182, line: 138, baseType: !215, size: 64)
!242 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !239, file: !182, line: 138, baseType: !226, size: 64, offset: 64)
!243 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !236, file: !182, line: 139, baseType: !244, size: 128, offset: 128)
!244 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "timeval", file: !245, line: 8, size: 128, elements: !246)
!245 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h", directory: "", checksumkind: CSK_MD5, checksum: "9b45d950050c215f216850b27bd1e8f3")
!246 = !{!247, !249}
!247 = !DIDerivedType(tag: DW_TAG_member, name: "tv_sec", scope: !244, file: !245, line: 14, baseType: !248, size: 64)
!248 = !DIDerivedType(tag: DW_TAG_typedef, name: "__time_t", file: !136, line: 160, baseType: !125)
!249 = !DIDerivedType(tag: DW_TAG_member, name: "tv_usec", scope: !244, file: !245, line: 15, baseType: !250, size: 64, offset: 64)
!250 = !DIDerivedType(tag: DW_TAG_typedef, name: "__suseconds_t", file: !136, line: 162, baseType: !125)
!251 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal", scope: !233, file: !182, line: 148, baseType: !252, size: 256)
!252 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !233, file: !182, line: 143, size: 256, elements: !253)
!253 = !{!254, !259, !260}
!254 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal_next", scope: !252, file: !182, line: 144, baseType: !255, size: 128)
!255 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !252, file: !182, line: 144, size: 128, elements: !256)
!256 = !{!257, !258}
!257 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !255, file: !182, line: 144, baseType: !215, size: 64)
!258 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !255, file: !182, line: 144, baseType: !226, size: 64, offset: 64)
!259 = !DIDerivedType(tag: DW_TAG_member, name: "ev_ncalls", scope: !252, file: !182, line: 145, baseType: !109, size: 16, offset: 128)
!260 = !DIDerivedType(tag: DW_TAG_member, name: "ev_pncalls", scope: !252, file: !182, line: 147, baseType: !261, size: 64, offset: 192)
!261 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !109, size: 64)
!262 = !DIDerivedType(tag: DW_TAG_member, name: "ev_events", scope: !181, file: !182, line: 151, baseType: !109, size: 16, offset: 832)
!263 = !DIDerivedType(tag: DW_TAG_member, name: "ev_res", scope: !181, file: !182, line: 152, baseType: !109, size: 16, offset: 848)
!264 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !181, file: !182, line: 153, baseType: !244, size: 128, offset: 896)
!265 = !DIDerivedType(tag: DW_TAG_member, name: "ev_flags", scope: !163, file: !6, line: 848, baseType: !109, size: 16, offset: 1280)
!266 = !DIDerivedType(tag: DW_TAG_member, name: "which", scope: !163, file: !6, line: 849, baseType: !109, size: 16, offset: 1296)
!267 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf", scope: !163, file: !6, line: 851, baseType: !155, size: 64, offset: 1344)
!268 = !DIDerivedType(tag: DW_TAG_member, name: "rcurr", scope: !163, file: !6, line: 852, baseType: !155, size: 64, offset: 1408)
!269 = !DIDerivedType(tag: DW_TAG_member, name: "rsize", scope: !163, file: !6, line: 853, baseType: !103, size: 32, offset: 1472)
!270 = !DIDerivedType(tag: DW_TAG_member, name: "rbytes", scope: !163, file: !6, line: 854, baseType: !103, size: 32, offset: 1504)
!271 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !163, file: !6, line: 856, baseType: !272, size: 64, offset: 1536)
!272 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !273, size: 64)
!273 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp", file: !6, line: 801, baseType: !274)
!274 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp", file: !6, line: 771, size: 9472, elements: !275)
!275 = !{!276, !522, !524, !525, !526, !527, !528, !550, !559, !560, !561, !562, !563, !564, !565, !566, !567, !594, !598}
!276 = !DIDerivedType(tag: DW_TAG_member, name: "bundle", scope: !274, file: !6, line: 772, baseType: !277, size: 64)
!277 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !278, size: 64)
!278 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp_bundle", file: !6, line: 720, baseType: !279)
!279 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp_bundle", file: !6, line: 804, size: 256, elements: !280)
!280 = !{!281, !282, !283, !517, !519, !520}
!281 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !279, file: !6, line: 805, baseType: !196, size: 8)
!282 = !DIDerivedType(tag: DW_TAG_member, name: "next_check", scope: !279, file: !6, line: 806, baseType: !196, size: 8, offset: 8)
!283 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !279, file: !6, line: 807, baseType: !284, size: 64, offset: 64)
!284 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !285, size: 64)
!285 = !DIDerivedType(tag: DW_TAG_typedef, name: "LIBEVENT_THREAD", file: !6, line: 765, baseType: !286)
!286 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !6, line: 721, size: 55488, elements: !287)
!287 = !{!288, !290, !291, !296, !297, !298, !328, !329, !330, !383, !405, !408, !436, !437, !438, !439, !515, !516}
!288 = !DIDerivedType(tag: DW_TAG_member, name: "thread_id", scope: !286, file: !6, line: 722, baseType: !289, size: 64)
!289 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_t", file: !95, line: 27, baseType: !137)
!290 = !DIDerivedType(tag: DW_TAG_member, name: "base", scope: !286, file: !6, line: 723, baseType: !230, size: 64, offset: 64)
!291 = !DIDerivedType(tag: DW_TAG_member, name: "n", scope: !286, file: !6, line: 724, baseType: !292, size: 1088, offset: 128)
!292 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_notify", file: !6, line: 710, size: 1088, elements: !293)
!293 = !{!294, !295}
!294 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event", scope: !292, file: !6, line: 711, baseType: !181, size: 1024)
!295 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event_fd", scope: !292, file: !6, line: 713, baseType: !103, size: 32, offset: 1024)
!296 = !DIDerivedType(tag: DW_TAG_member, name: "ion", scope: !286, file: !6, line: 725, baseType: !292, size: 1088, offset: 1216)
!297 = !DIDerivedType(tag: DW_TAG_member, name: "ion_lock", scope: !286, file: !6, line: 726, baseType: !94, size: 320, offset: 2304)
!298 = !DIDerivedType(tag: DW_TAG_member, name: "ion_head", scope: !286, file: !6, line: 727, baseType: !299, size: 128, offset: 2624)
!299 = !DIDerivedType(tag: DW_TAG_typedef, name: "iop_head_t", file: !6, line: 686, baseType: !300)
!300 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iop_head_s", file: !6, line: 686, size: 128, elements: !301)
!301 = !{!302, !326}
!302 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !300, file: !6, line: 686, baseType: !303, size: 64)
!303 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !304, size: 64)
!304 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_io_pending_t", file: !6, line: 815, size: 1408, elements: !305)
!305 = !{!306, !307, !308, !309, !310, !317, !318, !322}
!306 = !DIDerivedType(tag: DW_TAG_member, name: "io_queue_type", scope: !304, file: !6, line: 816, baseType: !103, size: 32)
!307 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !304, file: !6, line: 817, baseType: !284, size: 64, offset: 64)
!308 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !304, file: !6, line: 818, baseType: !161, size: 64, offset: 128)
!309 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !304, file: !6, line: 819, baseType: !272, size: 64, offset: 192)
!310 = !DIDerivedType(tag: DW_TAG_member, name: "return_cb", scope: !304, file: !6, line: 820, baseType: !311, size: 64, offset: 256)
!311 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb", file: !6, line: 690, baseType: !312)
!312 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !313, size: 64)
!313 = !DISubroutineType(types: !314)
!314 = !{null, !315}
!315 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !316, size: 64)
!316 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_pending_t", file: !6, line: 687, baseType: !304)
!317 = !DIDerivedType(tag: DW_TAG_member, name: "finalize_cb", scope: !304, file: !6, line: 821, baseType: !311, size: 64, offset: 320)
!318 = !DIDerivedType(tag: DW_TAG_member, name: "iop_next", scope: !304, file: !6, line: 822, baseType: !319, size: 64, offset: 384)
!319 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !304, file: !6, line: 822, size: 64, elements: !320)
!320 = !{!321}
!321 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !319, file: !6, line: 822, baseType: !303, size: 64)
!322 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !304, file: !6, line: 823, baseType: !323, size: 960, offset: 448)
!323 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 960, elements: !324)
!324 = !{!325}
!325 = !DISubrange(count: 120)
!326 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !300, file: !6, line: 686, baseType: !327, size: 64, offset: 64)
!327 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !303, size: 64)
!328 = !DIDerivedType(tag: DW_TAG_member, name: "cur_sfd", scope: !286, file: !6, line: 728, baseType: !103, size: 32, offset: 2752)
!329 = !DIDerivedType(tag: DW_TAG_member, name: "thread_baseid", scope: !286, file: !6, line: 729, baseType: !103, size: 32, offset: 2784)
!330 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !286, file: !6, line: 730, baseType: !331, size: 51584, offset: 2816)
!331 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_stats", file: !6, line: 372, size: 51584, elements: !332)
!332 = !{!333, !334, !335, !336, !337, !338, !339, !340, !341, !342, !343, !344, !345, !346, !347, !348, !349, !350, !351, !352, !353, !354, !355, !356, !357, !358, !359, !360, !361, !362, !363, !364, !378, !380, !381, !382}
!333 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !331, file: !6, line: 373, baseType: !94, size: 320)
!334 = !DIDerivedType(tag: DW_TAG_member, name: "get_cmds", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 320)
!335 = !DIDerivedType(tag: DW_TAG_member, name: "get_misses", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 384)
!336 = !DIDerivedType(tag: DW_TAG_member, name: "get_expired", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 448)
!337 = !DIDerivedType(tag: DW_TAG_member, name: "get_flushed", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 512)
!338 = !DIDerivedType(tag: DW_TAG_member, name: "touch_cmds", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 576)
!339 = !DIDerivedType(tag: DW_TAG_member, name: "touch_misses", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 640)
!340 = !DIDerivedType(tag: DW_TAG_member, name: "delete_misses", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 704)
!341 = !DIDerivedType(tag: DW_TAG_member, name: "incr_misses", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 768)
!342 = !DIDerivedType(tag: DW_TAG_member, name: "decr_misses", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 832)
!343 = !DIDerivedType(tag: DW_TAG_member, name: "cas_misses", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 896)
!344 = !DIDerivedType(tag: DW_TAG_member, name: "meta_cmds", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 960)
!345 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_read", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 1024)
!346 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_written", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 1088)
!347 = !DIDerivedType(tag: DW_TAG_member, name: "flush_cmds", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 1152)
!348 = !DIDerivedType(tag: DW_TAG_member, name: "conn_yields", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 1216)
!349 = !DIDerivedType(tag: DW_TAG_member, name: "auth_cmds", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 1280)
!350 = !DIDerivedType(tag: DW_TAG_member, name: "auth_errors", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 1344)
!351 = !DIDerivedType(tag: DW_TAG_member, name: "idle_kicks", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 1408)
!352 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_oom", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 1472)
!353 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_count", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 1536)
!354 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_bytes", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 1600)
!355 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_oom", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 1664)
!356 = !DIDerivedType(tag: DW_TAG_member, name: "store_too_large", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 1728)
!357 = !DIDerivedType(tag: DW_TAG_member, name: "store_no_memory", scope: !331, file: !6, line: 375, baseType: !133, size: 64, offset: 1792)
!358 = !DIDerivedType(tag: DW_TAG_member, name: "get_extstore", scope: !331, file: !6, line: 377, baseType: !133, size: 64, offset: 1856)
!359 = !DIDerivedType(tag: DW_TAG_member, name: "get_aborted_extstore", scope: !331, file: !6, line: 377, baseType: !133, size: 64, offset: 1920)
!360 = !DIDerivedType(tag: DW_TAG_member, name: "get_oom_extstore", scope: !331, file: !6, line: 377, baseType: !133, size: 64, offset: 1984)
!361 = !DIDerivedType(tag: DW_TAG_member, name: "recache_from_extstore", scope: !331, file: !6, line: 377, baseType: !133, size: 64, offset: 2048)
!362 = !DIDerivedType(tag: DW_TAG_member, name: "miss_from_extstore", scope: !331, file: !6, line: 377, baseType: !133, size: 64, offset: 2112)
!363 = !DIDerivedType(tag: DW_TAG_member, name: "badcrc_from_extstore", scope: !331, file: !6, line: 377, baseType: !133, size: 64, offset: 2176)
!364 = !DIDerivedType(tag: DW_TAG_member, name: "slab_stats", scope: !331, file: !6, line: 383, baseType: !365, size: 32768, offset: 2240)
!365 = !DICompositeType(tag: DW_TAG_array_type, baseType: !366, size: 32768, elements: !376)
!366 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "slab_stats", file: !6, line: 318, size: 512, elements: !367)
!367 = !{!368, !369, !370, !371, !372, !373, !374, !375}
!368 = !DIDerivedType(tag: DW_TAG_member, name: "set_cmds", scope: !366, file: !6, line: 320, baseType: !133, size: 64)
!369 = !DIDerivedType(tag: DW_TAG_member, name: "get_hits", scope: !366, file: !6, line: 320, baseType: !133, size: 64, offset: 64)
!370 = !DIDerivedType(tag: DW_TAG_member, name: "touch_hits", scope: !366, file: !6, line: 320, baseType: !133, size: 64, offset: 128)
!371 = !DIDerivedType(tag: DW_TAG_member, name: "delete_hits", scope: !366, file: !6, line: 320, baseType: !133, size: 64, offset: 192)
!372 = !DIDerivedType(tag: DW_TAG_member, name: "cas_hits", scope: !366, file: !6, line: 320, baseType: !133, size: 64, offset: 256)
!373 = !DIDerivedType(tag: DW_TAG_member, name: "cas_badval", scope: !366, file: !6, line: 320, baseType: !133, size: 64, offset: 320)
!374 = !DIDerivedType(tag: DW_TAG_member, name: "incr_hits", scope: !366, file: !6, line: 320, baseType: !133, size: 64, offset: 384)
!375 = !DIDerivedType(tag: DW_TAG_member, name: "decr_hits", scope: !366, file: !6, line: 320, baseType: !133, size: 64, offset: 448)
!376 = !{!377}
!377 = !DISubrange(count: 64)
!378 = !DIDerivedType(tag: DW_TAG_member, name: "lru_hits", scope: !331, file: !6, line: 384, baseType: !379, size: 16384, offset: 35008)
!379 = !DICompositeType(tag: DW_TAG_array_type, baseType: !133, size: 16384, elements: !149)
!380 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_count", scope: !331, file: !6, line: 385, baseType: !133, size: 64, offset: 51392)
!381 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes", scope: !331, file: !6, line: 386, baseType: !133, size: 64, offset: 51456)
!382 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes_free", scope: !331, file: !6, line: 387, baseType: !133, size: 64, offset: 51520)
!383 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !286, file: !6, line: 731, baseType: !384, size: 576, offset: 54400)
!384 = !DICompositeType(tag: DW_TAG_array_type, baseType: !385, size: 576, elements: !403)
!385 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb_t", file: !6, line: 708, baseType: !386)
!386 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_cb_s", file: !6, line: 704, size: 192, elements: !387)
!387 = !{!388, !389, !402}
!388 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !386, file: !6, line: 705, baseType: !89, size: 64)
!389 = !DIDerivedType(tag: DW_TAG_member, name: "submit_cb", scope: !386, file: !6, line: 706, baseType: !390, size: 64, offset: 64)
!390 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_stack_cb", file: !6, line: 689, baseType: !391)
!391 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !392, size: 64)
!392 = !DISubroutineType(types: !393)
!393 = !{null, !394}
!394 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !395, size: 64)
!395 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_t", file: !6, line: 688, baseType: !396)
!396 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_s", file: !6, line: 697, size: 192, elements: !397)
!397 = !{!398, !399, !400, !401}
!398 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !396, file: !6, line: 698, baseType: !89, size: 64)
!399 = !DIDerivedType(tag: DW_TAG_member, name: "stack_ctx", scope: !396, file: !6, line: 699, baseType: !89, size: 64, offset: 64)
!400 = !DIDerivedType(tag: DW_TAG_member, name: "count", scope: !396, file: !6, line: 700, baseType: !103, size: 32, offset: 128)
!401 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !396, file: !6, line: 701, baseType: !103, size: 32, offset: 160)
!402 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !386, file: !6, line: 707, baseType: !103, size: 32, offset: 128)
!403 = !{!404}
!404 = !DISubrange(count: 3)
!405 = !DIDerivedType(tag: DW_TAG_member, name: "ev_queue", scope: !286, file: !6, line: 732, baseType: !406, size: 64, offset: 54976)
!406 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !407, size: 64)
!407 = !DICompositeType(tag: DW_TAG_structure_type, name: "conn_queue", file: !6, line: 732, flags: DIFlagFwdDecl)
!408 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_cache", scope: !286, file: !6, line: 733, baseType: !409, size: 64, offset: 55040)
!409 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !410, size: 64)
!410 = !DIDerivedType(tag: DW_TAG_typedef, name: "cache_t", file: !411, line: 39, baseType: !412)
!411 = !DIFile(filename: "./cache.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d97639c8540587a19d8550d7d7156448")
!412 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !411, line: 22, size: 704, elements: !413)
!413 = !{!414, !415, !416, !429, !432, !433, !434, !435}
!414 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !412, file: !411, line: 24, baseType: !94, size: 320)
!415 = !DIDerivedType(tag: DW_TAG_member, name: "name", scope: !412, file: !411, line: 26, baseType: !155, size: 64, offset: 320)
!416 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !412, file: !411, line: 28, baseType: !417, size: 128, offset: 384)
!417 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_head", file: !411, line: 28, size: 128, elements: !418)
!418 = !{!419, !427}
!419 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !417, file: !411, line: 28, baseType: !420, size: 64)
!420 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !421, size: 64)
!421 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_free_s", file: !411, line: 12, size: 64, elements: !422)
!422 = !{!423}
!423 = !DIDerivedType(tag: DW_TAG_member, name: "c_next", scope: !421, file: !411, line: 13, baseType: !424, size: 64)
!424 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !421, file: !411, line: 13, size: 64, elements: !425)
!425 = !{!426}
!426 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !424, file: !411, line: 13, baseType: !420, size: 64)
!427 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !417, file: !411, line: 28, baseType: !428, size: 64, offset: 64)
!428 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !420, size: 64)
!429 = !DIDerivedType(tag: DW_TAG_member, name: "bufsize", scope: !412, file: !411, line: 30, baseType: !430, size: 64, offset: 512)
!430 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !431, line: 18, baseType: !137)
!431 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!432 = !DIDerivedType(tag: DW_TAG_member, name: "freetotal", scope: !412, file: !411, line: 32, baseType: !103, size: 32, offset: 576)
!433 = !DIDerivedType(tag: DW_TAG_member, name: "total", scope: !412, file: !411, line: 34, baseType: !103, size: 32, offset: 608)
!434 = !DIDerivedType(tag: DW_TAG_member, name: "freecurr", scope: !412, file: !411, line: 36, baseType: !103, size: 32, offset: 640)
!435 = !DIDerivedType(tag: DW_TAG_member, name: "limit", scope: !412, file: !411, line: 38, baseType: !103, size: 32, offset: 672)
!436 = !DIDerivedType(tag: DW_TAG_member, name: "open_bundle", scope: !286, file: !6, line: 734, baseType: !277, size: 64, offset: 55104)
!437 = !DIDerivedType(tag: DW_TAG_member, name: "io_cache", scope: !286, file: !6, line: 735, baseType: !409, size: 64, offset: 55168)
!438 = !DIDerivedType(tag: DW_TAG_member, name: "storage", scope: !286, file: !6, line: 737, baseType: !89, size: 64, offset: 55232)
!439 = !DIDerivedType(tag: DW_TAG_member, name: "l", scope: !286, file: !6, line: 739, baseType: !440, size: 64, offset: 55296)
!440 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !441, size: 64)
!441 = !DIDerivedType(tag: DW_TAG_typedef, name: "logger", file: !54, line: 193, baseType: !442)
!442 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logger", file: !54, line: 181, size: 832, elements: !443)
!443 = !{!444, !446, !447, !448, !449, !450, !451, !455, !456, !457, !472}
!444 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !442, file: !54, line: 182, baseType: !445, size: 64)
!445 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !442, size: 64)
!446 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !442, file: !54, line: 183, baseType: !445, size: 64, offset: 64)
!447 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !442, file: !54, line: 184, baseType: !94, size: 320, offset: 128)
!448 = !DIDerivedType(tag: DW_TAG_member, name: "written", scope: !442, file: !54, line: 185, baseType: !133, size: 64, offset: 448)
!449 = !DIDerivedType(tag: DW_TAG_member, name: "dropped", scope: !442, file: !54, line: 186, baseType: !133, size: 64, offset: 512)
!450 = !DIDerivedType(tag: DW_TAG_member, name: "blocked", scope: !442, file: !54, line: 187, baseType: !133, size: 64, offset: 576)
!451 = !DIDerivedType(tag: DW_TAG_member, name: "fetcher_ratio", scope: !442, file: !54, line: 188, baseType: !452, size: 16, offset: 640)
!452 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint16_t", file: !134, line: 25, baseType: !453)
!453 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint16_t", file: !136, line: 40, baseType: !454)
!454 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!455 = !DIDerivedType(tag: DW_TAG_member, name: "mutation_ratio", scope: !442, file: !54, line: 189, baseType: !452, size: 16, offset: 656)
!456 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !442, file: !54, line: 190, baseType: !452, size: 16, offset: 672)
!457 = !DIDerivedType(tag: DW_TAG_member, name: "buf", scope: !442, file: !54, line: 191, baseType: !458, size: 64, offset: 704)
!458 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !459, size: 64)
!459 = !DIDerivedType(tag: DW_TAG_typedef, name: "bipbuf_t", file: !460, line: 18, baseType: !461)
!460 = !DIFile(filename: "./bipbuffer.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "99606bcb8393045e6bc9eef40115066f")
!461 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !460, line: 4, size: 192, elements: !462)
!462 = !{!463, !464, !465, !466, !467, !468}
!463 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !461, file: !460, line: 6, baseType: !137, size: 64)
!464 = !DIDerivedType(tag: DW_TAG_member, name: "a_start", scope: !461, file: !460, line: 9, baseType: !7, size: 32, offset: 64)
!465 = !DIDerivedType(tag: DW_TAG_member, name: "a_end", scope: !461, file: !460, line: 9, baseType: !7, size: 32, offset: 96)
!466 = !DIDerivedType(tag: DW_TAG_member, name: "b_end", scope: !461, file: !460, line: 12, baseType: !7, size: 32, offset: 128)
!467 = !DIDerivedType(tag: DW_TAG_member, name: "b_inuse", scope: !461, file: !460, line: 15, baseType: !103, size: 32, offset: 160)
!468 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !461, file: !460, line: 17, baseType: !469, offset: 192)
!469 = !DICompositeType(tag: DW_TAG_array_type, baseType: !198, elements: !470)
!470 = !{!471}
!471 = !DISubrange(count: -1)
!472 = !DIDerivedType(tag: DW_TAG_member, name: "entry_map", scope: !442, file: !54, line: 192, baseType: !473, size: 64, offset: 768)
!473 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !474, size: 64)
!474 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !475)
!475 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_details", file: !54, line: 58, baseType: !476)
!476 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_entry_details", file: !54, line: 63, size: 256, elements: !477)
!477 = !{!478, !479, !480, !509, !514}
!478 = !DIDerivedType(tag: DW_TAG_member, name: "reqlen", scope: !476, file: !54, line: 64, baseType: !103, size: 32)
!479 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !476, file: !54, line: 65, baseType: !452, size: 16, offset: 32)
!480 = !DIDerivedType(tag: DW_TAG_member, name: "log_cb", scope: !476, file: !54, line: 66, baseType: !481, size: 64, offset: 64)
!481 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_log_cb", file: !54, line: 60, baseType: !482)
!482 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !483, size: 64)
!483 = !DISubroutineType(types: !484)
!484 = !{null, !485, !473, !500, !502}
!485 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !486, size: 64)
!486 = !DIDerivedType(tag: DW_TAG_typedef, name: "logentry", file: !54, line: 57, baseType: !487)
!487 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logentry", file: !54, line: 156, size: 320, elements: !488)
!488 = !{!489, !490, !491, !492, !493, !494, !495}
!489 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !487, file: !54, line: 157, baseType: !53, size: 32)
!490 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !487, file: !54, line: 158, baseType: !196, size: 8, offset: 32)
!491 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !487, file: !54, line: 159, baseType: !452, size: 16, offset: 48)
!492 = !DIDerivedType(tag: DW_TAG_member, name: "gid", scope: !487, file: !54, line: 160, baseType: !133, size: 64, offset: 64)
!493 = !DIDerivedType(tag: DW_TAG_member, name: "tv", scope: !487, file: !54, line: 161, baseType: !244, size: 128, offset: 128)
!494 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !487, file: !54, line: 162, baseType: !103, size: 32, offset: 256)
!495 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !487, file: !54, line: 165, baseType: !496, offset: 288)
!496 = !DICompositeType(tag: DW_TAG_array_type, baseType: !497, elements: !470)
!497 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !487, file: !54, line: 163, size: 8, elements: !498)
!498 = !{!499}
!499 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !497, file: !54, line: 164, baseType: !121, size: 8)
!500 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !501, size: 64)
!501 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!502 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !503, size: 64)
!503 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !504)
!504 = !{!505, !506, !507, !508}
!505 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !503, file: !3, line: 398, baseType: !7, size: 32)
!506 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !503, file: !3, line: 398, baseType: !7, size: 32, offset: 32)
!507 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !503, file: !3, line: 398, baseType: !89, size: 64, offset: 64)
!508 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !503, file: !3, line: 398, baseType: !89, size: 64, offset: 128)
!509 = !DIDerivedType(tag: DW_TAG_member, name: "parse_cb", scope: !476, file: !54, line: 67, baseType: !510, size: 64, offset: 128)
!510 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_parse_cb", file: !54, line: 61, baseType: !511)
!511 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !512, size: 64)
!512 = !DISubroutineType(types: !513)
!513 = !{!103, !485, !155}
!514 = !DIDerivedType(tag: DW_TAG_member, name: "format", scope: !476, file: !54, line: 68, baseType: !155, size: 64, offset: 192)
!515 = !DIDerivedType(tag: DW_TAG_member, name: "lru_bump_buf", scope: !286, file: !6, line: 740, baseType: !89, size: 64, offset: 55360)
!516 = !DIDerivedType(tag: DW_TAG_member, name: "napi_id", scope: !286, file: !6, line: 744, baseType: !103, size: 32, offset: 55424)
!517 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !279, file: !6, line: 808, baseType: !518, size: 64, offset: 128)
!518 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !279, size: 64)
!519 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !279, file: !6, line: 809, baseType: !518, size: 64, offset: 192)
!520 = !DIDerivedType(tag: DW_TAG_member, name: "r", scope: !279, file: !6, line: 810, baseType: !521, offset: 256)
!521 = !DICompositeType(tag: DW_TAG_array_type, baseType: !273, elements: !470)
!522 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !274, file: !6, line: 773, baseType: !523, size: 64, offset: 64)
!523 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !274, size: 64)
!524 = !DIDerivedType(tag: DW_TAG_member, name: "wbytes", scope: !274, file: !6, line: 774, baseType: !103, size: 32, offset: 128)
!525 = !DIDerivedType(tag: DW_TAG_member, name: "tosend", scope: !274, file: !6, line: 775, baseType: !103, size: 32, offset: 160)
!526 = !DIDerivedType(tag: DW_TAG_member, name: "write_and_free", scope: !274, file: !6, line: 776, baseType: !89, size: 64, offset: 192)
!527 = !DIDerivedType(tag: DW_TAG_member, name: "io_pending", scope: !274, file: !6, line: 777, baseType: !315, size: 64, offset: 256)
!528 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !274, file: !6, line: 779, baseType: !529, size: 64, offset: 320)
!529 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !530, size: 64)
!530 = !DIDerivedType(tag: DW_TAG_typedef, name: "item", file: !6, line: 616, baseType: !531)
!531 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_stritem", file: !6, line: 593, size: 384, elements: !532)
!532 = !{!533, !535, !536, !537, !538, !539, !540, !541, !542, !543, !544}
!533 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !531, file: !6, line: 595, baseType: !534, size: 64)
!534 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !531, size: 64)
!535 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !531, file: !6, line: 596, baseType: !534, size: 64, offset: 64)
!536 = !DIDerivedType(tag: DW_TAG_member, name: "h_next", scope: !531, file: !6, line: 598, baseType: !534, size: 64, offset: 128)
!537 = !DIDerivedType(tag: DW_TAG_member, name: "time", scope: !531, file: !6, line: 599, baseType: !145, size: 32, offset: 192)
!538 = !DIDerivedType(tag: DW_TAG_member, name: "exptime", scope: !531, file: !6, line: 600, baseType: !145, size: 32, offset: 224)
!539 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !531, file: !6, line: 601, baseType: !103, size: 32, offset: 256)
!540 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !531, file: !6, line: 602, baseType: !454, size: 16, offset: 288)
!541 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !531, file: !6, line: 603, baseType: !452, size: 16, offset: 304)
!542 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !531, file: !6, line: 604, baseType: !196, size: 8, offset: 320)
!543 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !531, file: !6, line: 605, baseType: !196, size: 8, offset: 328)
!544 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !531, file: !6, line: 611, baseType: !545, offset: 384)
!545 = !DICompositeType(tag: DW_TAG_array_type, baseType: !546, elements: !470)
!546 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !531, file: !6, line: 608, size: 64, elements: !547)
!547 = !{!548, !549}
!548 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !546, file: !6, line: 609, baseType: !133, size: 64)
!549 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !546, file: !6, line: 610, baseType: !121, size: 8)
!550 = !DIDerivedType(tag: DW_TAG_member, name: "iov", scope: !274, file: !6, line: 780, baseType: !551, size: 512, offset: 384)
!551 = !DICompositeType(tag: DW_TAG_array_type, baseType: !552, size: 512, elements: !557)
!552 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iovec", file: !553, line: 26, size: 128, elements: !554)
!553 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_iovec.h", directory: "", checksumkind: CSK_MD5, checksum: "a53f2c2488bb0e21e47850624c16538a")
!554 = !{!555, !556}
!555 = !DIDerivedType(tag: DW_TAG_member, name: "iov_base", scope: !552, file: !553, line: 28, baseType: !89, size: 64)
!556 = !DIDerivedType(tag: DW_TAG_member, name: "iov_len", scope: !552, file: !553, line: 29, baseType: !430, size: 64, offset: 64)
!557 = !{!558}
!558 = !DISubrange(count: 4)
!559 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_total", scope: !274, file: !6, line: 781, baseType: !103, size: 32, offset: 896)
!560 = !DIDerivedType(tag: DW_TAG_member, name: "iovcnt", scope: !274, file: !6, line: 782, baseType: !196, size: 8, offset: 928)
!561 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_data_iov", scope: !274, file: !6, line: 783, baseType: !196, size: 8, offset: 936)
!562 = !DIDerivedType(tag: DW_TAG_member, name: "skip", scope: !274, file: !6, line: 788, baseType: !148, size: 8, offset: 944)
!563 = !DIDerivedType(tag: DW_TAG_member, name: "free", scope: !274, file: !6, line: 789, baseType: !148, size: 8, offset: 952)
!564 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !274, file: !6, line: 794, baseType: !452, size: 16, offset: 960)
!565 = !DIDerivedType(tag: DW_TAG_member, name: "udp_sequence", scope: !274, file: !6, line: 795, baseType: !452, size: 16, offset: 976)
!566 = !DIDerivedType(tag: DW_TAG_member, name: "udp_total", scope: !274, file: !6, line: 796, baseType: !452, size: 16, offset: 992)
!567 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !274, file: !6, line: 797, baseType: !568, size: 224, offset: 1024)
!568 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "sockaddr_in6", file: !569, line: 262, size: 224, elements: !570)
!569 = !DIFile(filename: "/usr/include/netinet/in.h", directory: "", checksumkind: CSK_MD5, checksum: "fbd766480c8cb9a8fe07ee7aa568ee60")
!570 = !{!571, !574, !576, !577, !593}
!571 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_family", scope: !568, file: !569, line: 264, baseType: !572, size: 16)
!572 = !DIDerivedType(tag: DW_TAG_typedef, name: "sa_family_t", file: !573, line: 28, baseType: !454)
!573 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/sockaddr.h", directory: "", checksumkind: CSK_MD5, checksum: "5066b774f0f3cdb5cbbb5467306060db")
!574 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_port", scope: !568, file: !569, line: 265, baseType: !575, size: 16, offset: 16)
!575 = !DIDerivedType(tag: DW_TAG_typedef, name: "in_port_t", file: !569, line: 125, baseType: !452)
!576 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_flowinfo", scope: !568, file: !569, line: 266, baseType: !158, size: 32, offset: 32)
!577 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_addr", scope: !568, file: !569, line: 267, baseType: !578, size: 128, offset: 64)
!578 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "in6_addr", file: !569, line: 221, size: 128, elements: !579)
!579 = !{!580}
!580 = !DIDerivedType(tag: DW_TAG_member, name: "__in6_u", scope: !578, file: !569, line: 228, baseType: !581, size: 128)
!581 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !578, file: !569, line: 223, size: 128, elements: !582)
!582 = !{!583, !587, !591}
!583 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr8", scope: !581, file: !569, line: 225, baseType: !584, size: 128)
!584 = !DICompositeType(tag: DW_TAG_array_type, baseType: !196, size: 128, elements: !585)
!585 = !{!586}
!586 = !DISubrange(count: 16)
!587 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr16", scope: !581, file: !569, line: 226, baseType: !588, size: 128)
!588 = !DICompositeType(tag: DW_TAG_array_type, baseType: !452, size: 128, elements: !589)
!589 = !{!590}
!590 = !DISubrange(count: 8)
!591 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr32", scope: !581, file: !569, line: 227, baseType: !592, size: 128)
!592 = !DICompositeType(tag: DW_TAG_array_type, baseType: !158, size: 128, elements: !557)
!593 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_scope_id", scope: !568, file: !569, line: 268, baseType: !158, size: 32, offset: 192)
!594 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !274, file: !6, line: 798, baseType: !595, size: 32, offset: 1248)
!595 = !DIDerivedType(tag: DW_TAG_typedef, name: "socklen_t", file: !596, line: 33, baseType: !597)
!596 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/socket.h", directory: "", checksumkind: CSK_MD5, checksum: "71a09f67661e8e55cf505c19b5ddbb85")
!597 = !DIDerivedType(tag: DW_TAG_typedef, name: "__socklen_t", file: !136, line: 210, baseType: !7)
!598 = !DIDerivedType(tag: DW_TAG_member, name: "wbuf", scope: !274, file: !6, line: 800, baseType: !599, size: 8192, offset: 1280)
!599 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 8192, elements: !600)
!600 = !{!601}
!601 = !DISubrange(count: 1024)
!602 = !DIDerivedType(tag: DW_TAG_member, name: "resp_head", scope: !163, file: !6, line: 857, baseType: !272, size: 64, offset: 1600)
!603 = !DIDerivedType(tag: DW_TAG_member, name: "ritem", scope: !163, file: !6, line: 858, baseType: !155, size: 64, offset: 1664)
!604 = !DIDerivedType(tag: DW_TAG_member, name: "rlbytes", scope: !163, file: !6, line: 859, baseType: !103, size: 32, offset: 1728)
!605 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !163, file: !6, line: 867, baseType: !89, size: 64, offset: 1792)
!606 = !DIDerivedType(tag: DW_TAG_member, name: "sbytes", scope: !163, file: !6, line: 870, baseType: !103, size: 32, offset: 1856)
!607 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues_submitted", scope: !163, file: !6, line: 872, baseType: !103, size: 32, offset: 1888)
!608 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !163, file: !6, line: 873, baseType: !609, size: 576, offset: 1920)
!609 = !DICompositeType(tag: DW_TAG_array_type, baseType: !395, size: 576, elements: !403)
!610 = !DIDerivedType(tag: DW_TAG_member, name: "recache_counter", scope: !163, file: !6, line: 878, baseType: !7, size: 32, offset: 2496)
!611 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !163, file: !6, line: 880, baseType: !72, size: 32, offset: 2528)
!612 = !DIDerivedType(tag: DW_TAG_member, name: "transport", scope: !163, file: !6, line: 881, baseType: !77, size: 32, offset: 2560)
!613 = !DIDerivedType(tag: DW_TAG_member, name: "close_reason", scope: !163, file: !6, line: 882, baseType: !82, size: 32, offset: 2592)
!614 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !163, file: !6, line: 885, baseType: !103, size: 32, offset: 2624)
!615 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !163, file: !6, line: 886, baseType: !568, size: 224, offset: 2656)
!616 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !163, file: !6, line: 887, baseType: !595, size: 32, offset: 2880)
!617 = !DIDerivedType(tag: DW_TAG_member, name: "noreply", scope: !163, file: !6, line: 889, baseType: !148, size: 8, offset: 2912)
!618 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !163, file: !6, line: 895, baseType: !619, size: 192, offset: 2944)
!619 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !163, file: !6, line: 891, size: 192, elements: !620)
!620 = !{!621, !622, !623}
!621 = !DIDerivedType(tag: DW_TAG_member, name: "buffer", scope: !619, file: !6, line: 892, baseType: !155, size: 64)
!622 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !619, file: !6, line: 893, baseType: !430, size: 64, offset: 64)
!623 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !619, file: !6, line: 894, baseType: !430, size: 64, offset: 128)
!624 = !DIDerivedType(tag: DW_TAG_member, name: "binary_header", scope: !163, file: !6, line: 899, baseType: !625, size: 192, offset: 3136)
!625 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_request_header", file: !626, line: 164, baseType: !627)
!626 = !DIFile(filename: "./protocol_binary.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "7a322a65fa8661e9a597acbeeeb23107")
!627 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !626, line: 151, size: 192, elements: !628)
!628 = !{!629, !641}
!629 = !DIDerivedType(tag: DW_TAG_member, name: "request", scope: !627, file: !626, line: 162, baseType: !630, size: 192)
!630 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !627, file: !626, line: 152, size: 192, elements: !631)
!631 = !{!632, !633, !634, !635, !636, !637, !638, !639, !640}
!632 = !DIDerivedType(tag: DW_TAG_member, name: "magic", scope: !630, file: !626, line: 153, baseType: !196, size: 8)
!633 = !DIDerivedType(tag: DW_TAG_member, name: "opcode", scope: !630, file: !626, line: 154, baseType: !196, size: 8, offset: 8)
!634 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !630, file: !626, line: 155, baseType: !452, size: 16, offset: 16)
!635 = !DIDerivedType(tag: DW_TAG_member, name: "extlen", scope: !630, file: !626, line: 156, baseType: !196, size: 8, offset: 32)
!636 = !DIDerivedType(tag: DW_TAG_member, name: "datatype", scope: !630, file: !626, line: 157, baseType: !196, size: 8, offset: 40)
!637 = !DIDerivedType(tag: DW_TAG_member, name: "reserved", scope: !630, file: !626, line: 158, baseType: !452, size: 16, offset: 48)
!638 = !DIDerivedType(tag: DW_TAG_member, name: "bodylen", scope: !630, file: !626, line: 159, baseType: !158, size: 32, offset: 64)
!639 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !630, file: !626, line: 160, baseType: !158, size: 32, offset: 96)
!640 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !630, file: !626, line: 161, baseType: !133, size: 64, offset: 128)
!641 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !627, file: !626, line: 163, baseType: !642, size: 192)
!642 = !DICompositeType(tag: DW_TAG_array_type, baseType: !196, size: 192, elements: !643)
!643 = !{!644}
!644 = !DISubrange(count: 24)
!645 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !163, file: !6, line: 900, baseType: !133, size: 64, offset: 3328)
!646 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !163, file: !6, line: 901, baseType: !133, size: 64, offset: 3392)
!647 = !DIDerivedType(tag: DW_TAG_member, name: "cmd", scope: !163, file: !6, line: 902, baseType: !109, size: 16, offset: 3456)
!648 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !163, file: !6, line: 903, baseType: !103, size: 32, offset: 3488)
!649 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !163, file: !6, line: 904, baseType: !103, size: 32, offset: 3520)
!650 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !163, file: !6, line: 905, baseType: !161, size: 64, offset: 3584)
!651 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !163, file: !6, line: 906, baseType: !284, size: 64, offset: 3648)
!652 = !DIDerivedType(tag: DW_TAG_member, name: "try_read_command", scope: !163, file: !6, line: 907, baseType: !653, size: 64, offset: 3712)
!653 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !654, size: 64)
!654 = !DISubroutineType(types: !655)
!655 = !{!103, !161}
!656 = !DIDerivedType(tag: DW_TAG_member, name: "read", scope: !163, file: !6, line: 908, baseType: !657, size: 64, offset: 3776)
!657 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !658, size: 64)
!658 = !DISubroutineType(types: !659)
!659 = !{!660, !161, !89, !430}
!660 = !DIDerivedType(tag: DW_TAG_typedef, name: "ssize_t", file: !661, line: 108, baseType: !662)
!661 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/types.h", directory: "", checksumkind: CSK_MD5, checksum: "7fb02a803b0c9b11cb5276b77d21e9d8")
!662 = !DIDerivedType(tag: DW_TAG_typedef, name: "__ssize_t", file: !136, line: 194, baseType: !125)
!663 = !DIDerivedType(tag: DW_TAG_member, name: "sendmsg", scope: !163, file: !6, line: 909, baseType: !664, size: 64, offset: 3840)
!664 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !665, size: 64)
!665 = !DISubroutineType(types: !666)
!666 = !{!660, !161, !667, !103}
!667 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !668, size: 64)
!668 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "msghdr", file: !596, line: 262, size: 448, elements: !669)
!669 = !{!670, !671, !672, !674, !675, !676, !677}
!670 = !DIDerivedType(tag: DW_TAG_member, name: "msg_name", scope: !668, file: !596, line: 264, baseType: !89, size: 64)
!671 = !DIDerivedType(tag: DW_TAG_member, name: "msg_namelen", scope: !668, file: !596, line: 265, baseType: !595, size: 32, offset: 64)
!672 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iov", scope: !668, file: !596, line: 267, baseType: !673, size: 64, offset: 128)
!673 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !552, size: 64)
!674 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iovlen", scope: !668, file: !596, line: 268, baseType: !430, size: 64, offset: 192)
!675 = !DIDerivedType(tag: DW_TAG_member, name: "msg_control", scope: !668, file: !596, line: 270, baseType: !89, size: 64, offset: 256)
!676 = !DIDerivedType(tag: DW_TAG_member, name: "msg_controllen", scope: !668, file: !596, line: 271, baseType: !430, size: 64, offset: 320)
!677 = !DIDerivedType(tag: DW_TAG_member, name: "msg_flags", scope: !668, file: !596, line: 276, baseType: !103, size: 32, offset: 384)
!678 = !DIDerivedType(tag: DW_TAG_member, name: "write", scope: !163, file: !6, line: 910, baseType: !657, size: 64, offset: 3904)
!679 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !198, size: 64)
!680 = !{!0, !681, !725, !727, !730, !735, !740, !745, !766, !769, !774, !779, !781, !783, !785, !787, !792, !795, !797, !817, !822, !824, !826, !831, !836, !838, !840, !842, !844, !846, !849, !881, !883, !888, !893, !895, !897, !902}
!681 = !DIGlobalVariableExpression(var: !682, expr: !DIExpression())
!682 = distinct !DIGlobalVariable(name: "crawler_metadump_mod", scope: !2, file: !3, line: 79, type: !683, isLocal: false, isDefinition: true)
!683 = !DIDerivedType(tag: DW_TAG_typedef, name: "crawler_module_reg_t", file: !3, line: 52, baseType: !684)
!684 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 45, size: 320, elements: !685)
!685 = !{!686, !708, !713, !718, !723, !724}
!686 = !DIDerivedType(tag: DW_TAG_member, name: "init", scope: !684, file: !3, line: 46, baseType: !687, size: 64)
!687 = !DIDerivedType(tag: DW_TAG_typedef, name: "crawler_init_func", file: !3, line: 40, baseType: !688)
!688 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !689, size: 64)
!689 = !DISubroutineType(types: !690)
!690 = !{!103, !691, !89}
!691 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !692, size: 64)
!692 = !DIDerivedType(tag: DW_TAG_typedef, name: "crawler_module_t", file: !3, line: 37, baseType: !693)
!693 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_crawler_module_t", file: !3, line: 54, size: 448, elements: !694)
!694 = !{!695, !696, !705, !707}
!695 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !693, file: !3, line: 55, baseType: !89, size: 64)
!696 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !693, file: !3, line: 56, baseType: !697, size: 256, offset: 64)
!697 = !DIDerivedType(tag: DW_TAG_typedef, name: "crawler_client_t", file: !3, line: 35, baseType: !698)
!698 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 29, size: 256, elements: !699)
!699 = !{!700, !701, !702, !703, !704}
!700 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !698, file: !3, line: 30, baseType: !89, size: 64)
!701 = !DIDerivedType(tag: DW_TAG_member, name: "sfd", scope: !698, file: !3, line: 31, baseType: !103, size: 32, offset: 64)
!702 = !DIDerivedType(tag: DW_TAG_member, name: "buflen", scope: !698, file: !3, line: 32, baseType: !103, size: 32, offset: 96)
!703 = !DIDerivedType(tag: DW_TAG_member, name: "bufused", scope: !698, file: !3, line: 33, baseType: !103, size: 32, offset: 128)
!704 = !DIDerivedType(tag: DW_TAG_member, name: "buf", scope: !698, file: !3, line: 34, baseType: !155, size: 64, offset: 192)
!705 = !DIDerivedType(tag: DW_TAG_member, name: "mod", scope: !693, file: !3, line: 57, baseType: !706, size: 64, offset: 320)
!706 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !683, size: 64)
!707 = !DIDerivedType(tag: DW_TAG_member, name: "status", scope: !693, file: !3, line: 58, baseType: !103, size: 32, offset: 384)
!708 = !DIDerivedType(tag: DW_TAG_member, name: "eval", scope: !684, file: !3, line: 47, baseType: !709, size: 64, offset: 64)
!709 = !DIDerivedType(tag: DW_TAG_typedef, name: "crawler_eval_func", file: !3, line: 39, baseType: !710)
!710 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !711, size: 64)
!711 = !DISubroutineType(types: !712)
!712 = !{null, !691, !529, !158, !103}
!713 = !DIDerivedType(tag: DW_TAG_member, name: "doneclass", scope: !684, file: !3, line: 48, baseType: !714, size: 64, offset: 128)
!714 = !DIDerivedType(tag: DW_TAG_typedef, name: "crawler_doneclass_func", file: !3, line: 42, baseType: !715)
!715 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !716, size: 64)
!716 = !DISubroutineType(types: !717)
!717 = !{null, !691, !103}
!718 = !DIDerivedType(tag: DW_TAG_member, name: "finalize", scope: !684, file: !3, line: 49, baseType: !719, size: 64, offset: 192)
!719 = !DIDerivedType(tag: DW_TAG_typedef, name: "crawler_finalize_func", file: !3, line: 43, baseType: !720)
!720 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !721, size: 64)
!721 = !DISubroutineType(types: !722)
!722 = !{null, !691}
!723 = !DIDerivedType(tag: DW_TAG_member, name: "needs_lock", scope: !684, file: !3, line: 50, baseType: !148, size: 8, offset: 256)
!724 = !DIDerivedType(tag: DW_TAG_member, name: "needs_client", scope: !684, file: !3, line: 51, baseType: !148, size: 8, offset: 264)
!725 = !DIGlobalVariableExpression(var: !726, expr: !DIExpression())
!726 = distinct !DIGlobalVariable(name: "crawler_mgdump_mod", scope: !2, file: !3, line: 92, type: !683, isLocal: false, isDefinition: true)
!727 = !DIGlobalVariableExpression(var: !728, expr: !DIExpression())
!728 = distinct !DIGlobalVariable(name: "crawler_mod_regs", scope: !2, file: !3, line: 101, type: !729, isLocal: false, isDefinition: true)
!729 = !DICompositeType(tag: DW_TAG_array_type, baseType: !706, size: 256, elements: !557)
!730 = !DIGlobalVariableExpression(var: !731, expr: !DIExpression())
!731 = distinct !DIGlobalVariable(scope: null, file: !3, line: 658, type: !732, isLocal: true, isDefinition: true)
!732 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 312, elements: !733)
!733 = !{!734}
!734 = !DISubrange(count: 39)
!735 = !DIGlobalVariableExpression(var: !736, expr: !DIExpression())
!736 = distinct !DIGlobalVariable(scope: null, file: !3, line: 684, type: !737, isLocal: true, isDefinition: true)
!737 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 296, elements: !738)
!738 = !{!739}
!739 = !DISubrange(count: 37)
!740 = !DIGlobalVariableExpression(var: !741, expr: !DIExpression())
!741 = distinct !DIGlobalVariable(scope: null, file: !3, line: 689, type: !742, isLocal: true, isDefinition: true)
!742 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 120, elements: !743)
!743 = !{!744}
!744 = !DISubrange(count: 15)
!745 = !DIGlobalVariableExpression(var: !746, expr: !DIExpression())
!746 = distinct !DIGlobalVariable(name: "block_ae_until", scope: !747, file: !3, line: 762, type: !145, isLocal: true, isDefinition: true)
!747 = distinct !DISubprogram(name: "lru_crawler_start", scope: !3, file: !3, line: 757, type: !748, scopeLine: 759, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !753)
!748 = !DISubroutineType(types: !749)
!749 = !{!103, !750, !158, !751, !89, !89, !752}
!750 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !196, size: 64)
!751 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !5)
!752 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !103)
!753 = !{!754, !755, !756, !757, !758, !759, !760, !761, !762}
!754 = !DILocalVariable(name: "ids", arg: 1, scope: !747, file: !3, line: 757, type: !750)
!755 = !DILocalVariable(name: "remaining", arg: 2, scope: !747, file: !3, line: 757, type: !158)
!756 = !DILocalVariable(name: "type", arg: 3, scope: !747, file: !3, line: 758, type: !751)
!757 = !DILocalVariable(name: "data", arg: 4, scope: !747, file: !3, line: 758, type: !89)
!758 = !DILocalVariable(name: "c", arg: 5, scope: !747, file: !3, line: 759, type: !89)
!759 = !DILocalVariable(name: "sfd", arg: 6, scope: !747, file: !3, line: 759, type: !752)
!760 = !DILocalVariable(name: "starts", scope: !747, file: !3, line: 760, type: !103)
!761 = !DILocalVariable(name: "is_running", scope: !747, file: !3, line: 761, type: !148)
!762 = !DILocalVariable(name: "sid", scope: !763, file: !3, line: 819, type: !103)
!763 = distinct !DILexicalBlock(scope: !764, file: !3, line: 819, column: 9)
!764 = distinct !DILexicalBlock(scope: !765, file: !3, line: 817, column: 12)
!765 = distinct !DILexicalBlock(scope: !747, file: !3, line: 810, column: 9)
!766 = !DIGlobalVariableExpression(var: !767, expr: !DIExpression())
!767 = distinct !DIGlobalVariable(scope: null, file: !3, line: 848, type: !768, isLocal: true, isDefinition: true)
!768 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 32, elements: !557)
!769 = !DIGlobalVariableExpression(var: !770, expr: !DIExpression())
!770 = distinct !DIGlobalVariable(scope: null, file: !3, line: 852, type: !771, isLocal: true, isDefinition: true)
!771 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 40, elements: !772)
!772 = !{!773}
!773 = !DISubrange(count: 5)
!774 = !DIGlobalVariableExpression(var: !775, expr: !DIExpression())
!775 = distinct !DIGlobalVariable(scope: null, file: !3, line: 855, type: !776, isLocal: true, isDefinition: true)
!776 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 16, elements: !777)
!777 = !{!778}
!778 = !DISubrange(count: 2)
!779 = !DIGlobalVariableExpression(var: !780, expr: !DIExpression())
!780 = distinct !DIGlobalVariable(name: "active_crawler_mod", scope: !2, file: !3, line: 109, type: !692, isLocal: false, isDefinition: true)
!781 = !DIGlobalVariableExpression(var: !782, expr: !DIExpression())
!782 = distinct !DIGlobalVariable(name: "active_crawler_type", scope: !2, file: !3, line: 110, type: !5, isLocal: false, isDefinition: true)
!783 = !DIGlobalVariableExpression(var: !784, expr: !DIExpression())
!784 = distinct !DIGlobalVariable(name: "storage", scope: !2, file: !3, line: 121, type: !89, isLocal: true, isDefinition: true)
!785 = !DIGlobalVariableExpression(var: !786, expr: !DIExpression())
!786 = distinct !DIGlobalVariable(name: "item_crawler_tid", scope: !2, file: !3, line: 645, type: !289, isLocal: true, isDefinition: true)
!787 = !DIGlobalVariableExpression(var: !788, expr: !DIExpression())
!788 = distinct !DIGlobalVariable(scope: null, file: !3, line: 232, type: !789, isLocal: true, isDefinition: true)
!789 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 464, elements: !790)
!790 = !{!791}
!791 = !DISubrange(count: 58)
!792 = !DIGlobalVariableExpression(var: !793, expr: !DIExpression())
!793 = distinct !DIGlobalVariable(scope: null, file: !3, line: 235, type: !794, isLocal: true, isDefinition: true)
!794 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 24, elements: !403)
!795 = !DIGlobalVariableExpression(var: !796, expr: !DIExpression())
!796 = distinct !DIGlobalVariable(scope: null, file: !3, line: 237, type: !776, isLocal: true, isDefinition: true)
!797 = !DIGlobalVariableExpression(var: !798, expr: !DIExpression())
!798 = distinct !DIGlobalVariable(name: "crawlers", scope: !2, file: !3, line: 112, type: !799, isLocal: true, isDefinition: true)
!799 = !DICompositeType(tag: DW_TAG_array_type, baseType: !800, size: 147456, elements: !149)
!800 = !DIDerivedType(tag: DW_TAG_typedef, name: "crawler", file: !6, line: 638, baseType: !801)
!801 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !6, line: 623, size: 576, elements: !802)
!802 = !{!803, !804, !805, !806, !807, !808, !809, !810, !811, !812, !813, !814, !815, !816}
!803 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !801, file: !6, line: 624, baseType: !534, size: 64)
!804 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !801, file: !6, line: 625, baseType: !534, size: 64, offset: 64)
!805 = !DIDerivedType(tag: DW_TAG_member, name: "h_next", scope: !801, file: !6, line: 626, baseType: !534, size: 64, offset: 128)
!806 = !DIDerivedType(tag: DW_TAG_member, name: "time", scope: !801, file: !6, line: 627, baseType: !145, size: 32, offset: 192)
!807 = !DIDerivedType(tag: DW_TAG_member, name: "exptime", scope: !801, file: !6, line: 628, baseType: !145, size: 32, offset: 224)
!808 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !801, file: !6, line: 629, baseType: !103, size: 32, offset: 256)
!809 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !801, file: !6, line: 630, baseType: !454, size: 16, offset: 288)
!810 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !801, file: !6, line: 631, baseType: !452, size: 16, offset: 304)
!811 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !801, file: !6, line: 632, baseType: !196, size: 8, offset: 320)
!812 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !801, file: !6, line: 633, baseType: !196, size: 8, offset: 328)
!813 = !DIDerivedType(tag: DW_TAG_member, name: "remaining", scope: !801, file: !6, line: 634, baseType: !158, size: 32, offset: 352)
!814 = !DIDerivedType(tag: DW_TAG_member, name: "reclaimed", scope: !801, file: !6, line: 635, baseType: !133, size: 64, offset: 384)
!815 = !DIDerivedType(tag: DW_TAG_member, name: "unfetched", scope: !801, file: !6, line: 636, baseType: !133, size: 64, offset: 448)
!816 = !DIDerivedType(tag: DW_TAG_member, name: "checked", scope: !801, file: !6, line: 637, baseType: !133, size: 64, offset: 512)
!817 = !DIGlobalVariableExpression(var: !818, expr: !DIExpression())
!818 = distinct !DIGlobalVariable(scope: null, file: !3, line: 284, type: !819, isLocal: true, isDefinition: true)
!819 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 552, elements: !820)
!820 = !{!821}
!821 = !DISubrange(count: 69)
!822 = !DIGlobalVariableExpression(var: !823, expr: !DIExpression())
!823 = distinct !DIGlobalVariable(scope: null, file: !3, line: 289, type: !768, isLocal: true, isDefinition: true)
!824 = !DIGlobalVariableExpression(var: !825, expr: !DIExpression())
!825 = distinct !DIGlobalVariable(scope: null, file: !3, line: 289, type: !794, isLocal: true, isDefinition: true)
!826 = !DIGlobalVariableExpression(var: !827, expr: !DIExpression())
!827 = distinct !DIGlobalVariable(scope: null, file: !3, line: 309, type: !828, isLocal: true, isDefinition: true)
!828 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 248, elements: !829)
!829 = !{!830}
!830 = !DISubrange(count: 31)
!831 = !DIGlobalVariableExpression(var: !832, expr: !DIExpression())
!832 = distinct !DIGlobalVariable(scope: null, file: !3, line: 314, type: !833, isLocal: true, isDefinition: true)
!833 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 48, elements: !834)
!834 = !{!835}
!835 = !DISubrange(count: 6)
!836 = !DIGlobalVariableExpression(var: !837, expr: !DIExpression())
!837 = distinct !DIGlobalVariable(scope: null, file: !3, line: 337, type: !768, isLocal: true, isDefinition: true)
!838 = !DIGlobalVariableExpression(var: !839, expr: !DIExpression())
!839 = distinct !DIGlobalVariable(scope: null, file: !3, line: 341, type: !771, isLocal: true, isDefinition: true)
!840 = !DIGlobalVariableExpression(var: !841, expr: !DIExpression())
!841 = distinct !DIGlobalVariable(scope: null, file: !3, line: 346, type: !794, isLocal: true, isDefinition: true)
!842 = !DIGlobalVariableExpression(var: !843, expr: !DIExpression())
!843 = distinct !DIGlobalVariable(scope: null, file: !3, line: 366, type: !771, isLocal: true, isDefinition: true)
!844 = !DIGlobalVariableExpression(var: !845, expr: !DIExpression())
!845 = distinct !DIGlobalVariable(name: "lru_crawler_lock", scope: !2, file: !3, line: 117, type: !94, isLocal: true, isDefinition: true)
!846 = !DIGlobalVariableExpression(var: !847, expr: !DIExpression())
!847 = distinct !DIGlobalVariable(name: "do_run_lru_crawler_thread", scope: !2, file: !3, line: 115, type: !848, isLocal: true, isDefinition: true)
!848 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !103)
!849 = !DIGlobalVariableExpression(var: !850, expr: !DIExpression())
!850 = distinct !DIGlobalVariable(name: "lru_crawler_cond", scope: !2, file: !3, line: 118, type: !851, isLocal: true, isDefinition: true)
!851 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_cond_t", file: !95, line: 80, baseType: !852)
!852 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !95, line: 75, size: 384, elements: !853)
!853 = !{!854, !875, !879}
!854 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !852, file: !95, line: 77, baseType: !855, size: 384)
!855 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_cond_s", file: !113, line: 94, size: 384, elements: !856)
!856 = !{!857, !868, !869, !871, !872, !873, !874}
!857 = !DIDerivedType(tag: DW_TAG_member, name: "__wseq", scope: !855, file: !113, line: 96, baseType: !858, size: 64)
!858 = !DIDerivedType(tag: DW_TAG_typedef, name: "__atomic_wide_counter", file: !859, line: 33, baseType: !860)
!859 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h", directory: "", checksumkind: CSK_MD5, checksum: "d1ec99b0f6e36c0a42ac284d459cbd38")
!860 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !859, line: 25, size: 64, elements: !861)
!861 = !{!862, !863}
!862 = !DIDerivedType(tag: DW_TAG_member, name: "__value64", scope: !860, file: !859, line: 27, baseType: !160, size: 64)
!863 = !DIDerivedType(tag: DW_TAG_member, name: "__value32", scope: !860, file: !859, line: 32, baseType: !864, size: 64)
!864 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !860, file: !859, line: 28, size: 64, elements: !865)
!865 = !{!866, !867}
!866 = !DIDerivedType(tag: DW_TAG_member, name: "__low", scope: !864, file: !859, line: 30, baseType: !7, size: 32)
!867 = !DIDerivedType(tag: DW_TAG_member, name: "__high", scope: !864, file: !859, line: 31, baseType: !7, size: 32, offset: 32)
!868 = !DIDerivedType(tag: DW_TAG_member, name: "__g1_start", scope: !855, file: !113, line: 97, baseType: !858, size: 64, offset: 64)
!869 = !DIDerivedType(tag: DW_TAG_member, name: "__g_refs", scope: !855, file: !113, line: 98, baseType: !870, size: 64, offset: 128)
!870 = !DICompositeType(tag: DW_TAG_array_type, baseType: !7, size: 64, elements: !777)
!871 = !DIDerivedType(tag: DW_TAG_member, name: "__g_size", scope: !855, file: !113, line: 99, baseType: !870, size: 64, offset: 192)
!872 = !DIDerivedType(tag: DW_TAG_member, name: "__g1_orig_size", scope: !855, file: !113, line: 100, baseType: !7, size: 32, offset: 256)
!873 = !DIDerivedType(tag: DW_TAG_member, name: "__wrefs", scope: !855, file: !113, line: 101, baseType: !7, size: 32, offset: 288)
!874 = !DIDerivedType(tag: DW_TAG_member, name: "__g_signals", scope: !855, file: !113, line: 102, baseType: !870, size: 64, offset: 320)
!875 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !852, file: !95, line: 78, baseType: !876, size: 384)
!876 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 384, elements: !877)
!877 = !{!878}
!878 = !DISubrange(count: 48)
!879 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !852, file: !95, line: 79, baseType: !880, size: 64)
!880 = !DIBasicType(name: "long long", size: 64, encoding: DW_ATE_signed)
!881 = !DIGlobalVariableExpression(var: !882, expr: !DIExpression())
!882 = distinct !DIGlobalVariable(scope: null, file: !3, line: 531, type: !120, isLocal: true, isDefinition: true)
!883 = !DIGlobalVariableExpression(var: !884, expr: !DIExpression())
!884 = distinct !DIGlobalVariable(scope: null, file: !3, line: 566, type: !885, isLocal: true, isDefinition: true)
!885 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 240, elements: !886)
!886 = !{!887}
!887 = !DISubrange(count: 30)
!888 = !DIGlobalVariableExpression(var: !889, expr: !DIExpression())
!889 = distinct !DIGlobalVariable(scope: null, file: !3, line: 631, type: !890, isLocal: true, isDefinition: true)
!890 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 232, elements: !891)
!891 = !{!892}
!892 = !DISubrange(count: 29)
!893 = !DIGlobalVariableExpression(var: !894, expr: !DIExpression())
!894 = distinct !DIGlobalVariable(scope: null, file: !3, line: 639, type: !890, isLocal: true, isDefinition: true)
!895 = !DIGlobalVariableExpression(var: !896, expr: !DIExpression())
!896 = distinct !DIGlobalVariable(name: "crawler_count", scope: !2, file: !3, line: 114, type: !103, isLocal: true, isDefinition: true)
!897 = !DIGlobalVariableExpression(var: !898, expr: !DIExpression())
!898 = distinct !DIGlobalVariable(scope: null, file: !3, line: 707, type: !899, isLocal: true, isDefinition: true)
!899 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 288, elements: !900)
!900 = !{!901}
!901 = !DISubrange(count: 36)
!902 = !DIGlobalVariableExpression(var: !903, expr: !DIExpression())
!903 = distinct !DIGlobalVariable(name: "lru_crawler_initialized", scope: !2, file: !3, line: 116, type: !103, isLocal: true, isDefinition: true)
!904 = !DIGlobalVariableExpression(var: !903, expr: !DIExpression(DW_OP_deref_size, 1, DW_OP_constu, 1, DW_OP_mul, DW_OP_constu, 0, DW_OP_plus, DW_OP_stack_value))
!905 = !{i32 7, !"Dwarf Version", i32 5}
!906 = !{i32 2, !"Debug Info Version", i32 3}
!907 = !{i32 1, !"wchar_size", i32 4}
!908 = !{i32 8, !"PIC Level", i32 2}
!909 = !{i32 7, !"PIE Level", i32 2}
!910 = !{i32 7, !"uwtable", i32 2}
!911 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!912 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!913 = distinct !DISubprogram(name: "crawler_expired_init", scope: !3, file: !3, line: 157, type: !689, scopeLine: 157, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !914)
!914 = !{!915, !916, !917, !918}
!915 = !DILocalVariable(name: "cm", arg: 1, scope: !913, file: !3, line: 157, type: !691)
!916 = !DILocalVariable(name: "data", arg: 2, scope: !913, file: !3, line: 157, type: !89)
!917 = !DILocalVariable(name: "d", scope: !913, file: !3, line: 158, type: !90)
!918 = !DILocalVariable(name: "x", scope: !919, file: !3, line: 178, type: !103)
!919 = distinct !DILexicalBlock(scope: !913, file: !3, line: 178, column: 5)
!920 = !DILocation(line: 0, scope: !913)
!921 = !DILocation(line: 159, column: 14, scope: !922)
!922 = distinct !DILexicalBlock(scope: !913, file: !3, line: 159, column: 9)
!923 = !DILocation(line: 159, column: 9, scope: !913)
!924 = !DILocation(line: 161, column: 12, scope: !925)
!925 = distinct !DILexicalBlock(scope: !922, file: !3, line: 159, column: 23)
!926 = !DILocation(line: 161, column: 24, scope: !925)
!927 = !{!928, !932, i64 137265}
!928 = !{!"crawler_expired_data", !929, i64 0, !929, i64 40, !931, i64 137256, !931, i64 137260, !932, i64 137264, !932, i64 137265}
!929 = !{!"omnipotent char", !930, i64 0}
!930 = !{!"Simple C/C++ TBAA"}
!931 = !{!"int", !929, i64 0}
!932 = !{!"_Bool", !929, i64 0}
!933 = !DILocation(line: 163, column: 5, scope: !925)
!934 = !DILocation(line: 165, column: 13, scope: !935)
!935 = distinct !DILexicalBlock(scope: !922, file: !3, line: 163, column: 12)
!936 = !DILocation(line: 166, column: 15, scope: !937)
!937 = distinct !DILexicalBlock(scope: !935, file: !3, line: 166, column: 13)
!938 = !DILocation(line: 166, column: 13, scope: !935)
!939 = !DILocation(line: 170, column: 9, scope: !935)
!940 = !DILocation(line: 171, column: 12, scope: !935)
!941 = !DILocation(line: 171, column: 24, scope: !935)
!942 = !DILocation(line: 172, column: 25, scope: !935)
!943 = !{!931, !931, i64 0}
!944 = !DILocation(line: 172, column: 12, scope: !935)
!945 = !DILocation(line: 172, column: 23, scope: !935)
!946 = !{!928, !931, i64 137256}
!947 = !DILocation(line: 0, scope: !922)
!948 = !{!949, !950, i64 0}
!949 = !{!"_crawler_module_t", !950, i64 0, !951, i64 8, !950, i64 40, !931, i64 48}
!950 = !{!"any pointer", !929, i64 0}
!951 = !{!"", !950, i64 0, !931, i64 8, !931, i64 12, !931, i64 16, !950, i64 24}
!952 = !DILocation(line: 176, column: 5, scope: !913)
!953 = !DILocation(line: 177, column: 16, scope: !913)
!954 = !DILocation(line: 177, column: 5, scope: !913)
!955 = !DILocation(line: 0, scope: !919)
!956 = !DILocation(line: 178, column: 5, scope: !919)
!957 = !DILocation(line: 182, column: 5, scope: !913)
!958 = !DILocation(line: 183, column: 5, scope: !913)
!959 = !DILocation(line: 179, column: 41, scope: !960)
!960 = distinct !DILexicalBlock(scope: !961, file: !3, line: 178, column: 45)
!961 = distinct !DILexicalBlock(scope: !919, file: !3, line: 178, column: 5)
!962 = !DILocation(line: 179, column: 9, scope: !960)
!963 = !DILocation(line: 179, column: 28, scope: !960)
!964 = !DILocation(line: 179, column: 39, scope: !960)
!965 = !{!966, !931, i64 520}
!966 = !{!"", !929, i64 0, !967, i64 488, !967, i64 496, !967, i64 504, !967, i64 512, !931, i64 520, !931, i64 524, !932, i64 528}
!967 = !{!"long", !929, i64 0}
!968 = !DILocation(line: 180, column: 28, scope: !960)
!969 = !DILocation(line: 180, column: 41, scope: !960)
!970 = !{!966, !932, i64 528}
!971 = !DILocation(line: 178, column: 41, scope: !961)
!972 = !DILocation(line: 178, column: 23, scope: !961)
!973 = distinct !{!973, !956, !974, !975}
!974 = !DILocation(line: 181, column: 5, scope: !919)
!975 = !{!"llvm.loop.mustprogress"}
!976 = !DILocation(line: 184, column: 1, scope: !913)
!977 = distinct !DISubprogram(name: "crawler_expired_eval", scope: !3, file: !3, line: 209, type: !711, scopeLine: 209, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !978)
!978 = !{!979, !980, !981, !982, !983, !984, !986, !987, !988, !993, !994, !999}
!979 = !DILocalVariable(name: "cm", arg: 1, scope: !977, file: !3, line: 209, type: !691)
!980 = !DILocalVariable(name: "search", arg: 2, scope: !977, file: !3, line: 209, type: !529)
!981 = !DILocalVariable(name: "hv", arg: 3, scope: !977, file: !3, line: 209, type: !158)
!982 = !DILocalVariable(name: "i", arg: 4, scope: !977, file: !3, line: 209, type: !103)
!983 = !DILocalVariable(name: "d", scope: !977, file: !3, line: 210, type: !90)
!984 = !DILocalVariable(name: "s", scope: !977, file: !3, line: 212, type: !985)
!985 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !128, size: 64)
!986 = !DILocalVariable(name: "is_flushed", scope: !977, file: !3, line: 213, type: !103)
!987 = !DILocalVariable(name: "is_valid", scope: !977, file: !3, line: 215, type: !148)
!988 = !DILocalVariable(name: "ii", scope: !989, file: !3, line: 230, type: !103)
!989 = distinct !DILexicalBlock(scope: !990, file: !3, line: 229, column: 35)
!990 = distinct !DILexicalBlock(scope: !991, file: !3, line: 229, column: 13)
!991 = distinct !DILexicalBlock(scope: !992, file: !3, line: 225, column: 11)
!992 = distinct !DILexicalBlock(scope: !977, file: !3, line: 220, column: 9)
!993 = !DILocalVariable(name: "key", scope: !989, file: !3, line: 231, type: !155)
!994 = !DILocalVariable(name: "ttl_remain", scope: !995, file: !3, line: 255, type: !145)
!995 = distinct !DILexicalBlock(scope: !996, file: !3, line: 254, column: 16)
!996 = distinct !DILexicalBlock(scope: !997, file: !3, line: 252, column: 20)
!997 = distinct !DILexicalBlock(scope: !998, file: !3, line: 250, column: 13)
!998 = distinct !DILexicalBlock(scope: !992, file: !3, line: 247, column: 12)
!999 = !DILocalVariable(name: "bucket", scope: !995, file: !3, line: 256, type: !103)
!1000 = !DILocation(line: 0, scope: !977)
!1001 = !DILocation(line: 210, column: 74, scope: !977)
!1002 = !DILocation(line: 211, column: 5, scope: !977)
!1003 = !DILocation(line: 212, column: 29, scope: !977)
!1004 = !DILocation(line: 212, column: 26, scope: !977)
!1005 = !DILocation(line: 213, column: 22, scope: !977)
!1006 = !DILocation(line: 216, column: 17, scope: !1007)
!1007 = distinct !DILexicalBlock(scope: !977, file: !3, line: 216, column: 9)
!1008 = !{!1009, !1009, i64 0}
!1009 = !{!"short", !929, i64 0}
!1010 = !DILocation(line: 216, column: 26, scope: !1007)
!1011 = !DILocation(line: 216, column: 9, scope: !977)
!1012 = !DILocation(line: 217, column: 42, scope: !1013)
!1013 = distinct !DILexicalBlock(scope: !1007, file: !3, line: 216, column: 38)
!1014 = !{!950, !950, i64 0}
!1015 = !DILocation(line: 217, column: 20, scope: !1013)
!1016 = !DILocation(line: 221, column: 9, scope: !992)
!1017 = !DILocation(line: 218, column: 5, scope: !1013)
!1018 = !DILocation(line: 220, column: 18, scope: !992)
!1019 = !DILocation(line: 220, column: 26, scope: !992)
!1020 = !DILocation(line: 220, column: 31, scope: !992)
!1021 = !DILocation(line: 220, column: 52, scope: !992)
!1022 = !DILocation(line: 220, column: 50, scope: !992)
!1023 = !DILocation(line: 221, column: 12, scope: !992)
!1024 = !DILocation(line: 223, column: 9, scope: !992)
!1025 = !DILocation(line: 226, column: 9, scope: !991)
!1026 = !DILocation(line: 226, column: 21, scope: !991)
!1027 = !DILocation(line: 226, column: 30, scope: !991)
!1028 = !{!1029, !967, i64 48}
!1029 = !{!"", !950, i64 0, !950, i64 8, !950, i64 16, !931, i64 24, !931, i64 28, !931, i64 32, !1009, i64 36, !1009, i64 38, !929, i64 40, !929, i64 41, !931, i64 44, !967, i64 48, !967, i64 56, !967, i64 64}
!1030 = !DILocation(line: 227, column: 12, scope: !991)
!1031 = !DILocation(line: 227, column: 21, scope: !991)
!1032 = !{!966, !967, i64 504}
!1033 = !DILocation(line: 229, column: 22, scope: !990)
!1034 = !{!1035, !931, i64 32}
!1035 = !{!"settings", !967, i64 0, !931, i64 8, !931, i64 12, !931, i64 16, !950, i64 24, !931, i64 32, !931, i64 36, !931, i64 40, !950, i64 48, !950, i64 56, !931, i64 64, !1036, i64 72, !931, i64 80, !931, i64 84, !931, i64 88, !929, i64 92, !931, i64 96, !931, i64 100, !932, i64 104, !931, i64 108, !931, i64 112, !931, i64 116, !931, i64 120, !931, i64 124, !931, i64 128, !932, i64 132, !932, i64 133, !932, i64 134, !932, i64 135, !932, i64 136, !932, i64 137, !931, i64 140, !1036, i64 144, !931, i64 152, !931, i64 156, !932, i64 160, !931, i64 164, !932, i64 168, !932, i64 169, !950, i64 176, !931, i64 184, !931, i64 188, !931, i64 192, !931, i64 196, !1036, i64 200, !1036, i64 208, !931, i64 216, !932, i64 220, !931, i64 224, !931, i64 228, !931, i64 232, !931, i64 236, !931, i64 240, !932, i64 244, !932, i64 245, !932, i64 246, !931, i64 248, !931, i64 252, !931, i64 256, !931, i64 260, !931, i64 264, !931, i64 268, !931, i64 272, !931, i64 276, !931, i64 280, !931, i64 284, !1036, i64 288, !1036, i64 296, !932, i64 304, !931, i64 308, !931, i64 312, !950, i64 320, !931, i64 328}
!1036 = !{!"double", !929, i64 0}
!1037 = !DILocation(line: 229, column: 30, scope: !990)
!1038 = !DILocation(line: 239, column: 22, scope: !1039)
!1039 = distinct !DILexicalBlock(scope: !991, file: !3, line: 239, column: 13)
!1040 = !DILocation(line: 229, column: 13, scope: !991)
!1041 = !DILocation(line: 231, column: 25, scope: !989)
!1042 = !DILocation(line: 0, scope: !989)
!1043 = !DILocation(line: 232, column: 21, scope: !989)
!1044 = !DILocation(line: 233, column: 43, scope: !989)
!1045 = !{!929, !929, i64 0}
!1046 = !DILocation(line: 233, column: 35, scope: !989)
!1047 = !DILocation(line: 232, column: 13, scope: !989)
!1048 = !DILocation(line: 234, column: 39, scope: !1049)
!1049 = distinct !DILexicalBlock(scope: !1050, file: !3, line: 234, column: 13)
!1050 = distinct !DILexicalBlock(scope: !989, file: !3, line: 234, column: 13)
!1051 = !DILocation(line: 234, column: 29, scope: !1049)
!1052 = !DILocation(line: 234, column: 13, scope: !1050)
!1053 = !DILocation(line: 235, column: 25, scope: !1054)
!1054 = distinct !DILexicalBlock(scope: !1049, file: !3, line: 234, column: 51)
!1055 = !DILocation(line: 235, column: 39, scope: !1054)
!1056 = !DILocation(line: 235, column: 17, scope: !1054)
!1057 = !DILocation(line: 234, column: 45, scope: !1049)
!1058 = distinct !{!1058, !1052, !1059, !975}
!1059 = !DILocation(line: 236, column: 13, scope: !1050)
!1060 = !DILocation(line: 237, column: 21, scope: !989)
!1061 = !DILocation(line: 237, column: 13, scope: !989)
!1062 = !DILocation(line: 238, column: 9, scope: !989)
!1063 = !DILocation(line: 239, column: 31, scope: !1039)
!1064 = !DILocation(line: 239, column: 47, scope: !1039)
!1065 = !DILocation(line: 239, column: 52, scope: !1039)
!1066 = !DILocation(line: 240, column: 25, scope: !1067)
!1067 = distinct !DILexicalBlock(scope: !1039, file: !3, line: 239, column: 68)
!1068 = !DILocation(line: 240, column: 34, scope: !1067)
!1069 = !{!1029, !967, i64 56}
!1070 = !DILocation(line: 241, column: 9, scope: !1067)
!1071 = !DILocation(line: 243, column: 9, scope: !1072)
!1072 = distinct !DILexicalBlock(scope: !991, file: !3, line: 243, column: 9)
!1073 = !DILocation(line: 245, column: 9, scope: !991)
!1074 = !DILocation(line: 246, column: 9, scope: !991)
!1075 = !DILocation(line: 247, column: 5, scope: !991)
!1076 = !DILocation(line: 248, column: 12, scope: !998)
!1077 = !DILocation(line: 248, column: 16, scope: !998)
!1078 = !{!966, !967, i64 512}
!1079 = !DILocation(line: 249, column: 9, scope: !998)
!1080 = !DILocation(line: 251, column: 16, scope: !1081)
!1081 = distinct !DILexicalBlock(scope: !997, file: !3, line: 250, column: 35)
!1082 = !DILocation(line: 251, column: 21, scope: !1081)
!1083 = !{!966, !967, i64 496}
!1084 = !DILocation(line: 252, column: 9, scope: !1081)
!1085 = !DILocation(line: 252, column: 38, scope: !996)
!1086 = !DILocation(line: 252, column: 36, scope: !996)
!1087 = !DILocation(line: 252, column: 51, scope: !996)
!1088 = !DILocation(line: 252, column: 20, scope: !997)
!1089 = !DILocation(line: 253, column: 16, scope: !1090)
!1090 = distinct !DILexicalBlock(scope: !996, file: !3, line: 252, column: 59)
!1091 = !DILocation(line: 253, column: 28, scope: !1090)
!1092 = !{!966, !967, i64 488}
!1093 = !DILocation(line: 254, column: 9, scope: !1090)
!1094 = !DILocation(line: 255, column: 55, scope: !995)
!1095 = !DILocation(line: 255, column: 53, scope: !995)
!1096 = !DILocation(line: 0, scope: !995)
!1097 = !DILocation(line: 257, column: 24, scope: !1098)
!1098 = distinct !DILexicalBlock(scope: !995, file: !3, line: 257, column: 17)
!1099 = !DILocation(line: 257, column: 17, scope: !995)
!1100 = !DILocation(line: 256, column: 37, scope: !995)
!1101 = !DILocation(line: 258, column: 17, scope: !1102)
!1102 = distinct !DILexicalBlock(scope: !1098, file: !3, line: 257, column: 31)
!1103 = !DILocation(line: 258, column: 33, scope: !1102)
!1104 = !{!967, !967, i64 0}
!1105 = !DILocation(line: 259, column: 13, scope: !1102)
!1106 = !DILocation(line: 262, column: 5, scope: !977)
!1107 = !DILocation(line: 263, column: 1, scope: !977)
!1108 = distinct !DISubprogram(name: "crawler_expired_doneclass", scope: !3, file: !3, line: 186, type: !716, scopeLine: 186, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1109)
!1109 = !{!1110, !1111, !1112}
!1110 = !DILocalVariable(name: "cm", arg: 1, scope: !1108, file: !3, line: 186, type: !691)
!1111 = !DILocalVariable(name: "slab_cls", arg: 2, scope: !1108, file: !3, line: 186, type: !103)
!1112 = !DILocalVariable(name: "d", scope: !1108, file: !3, line: 187, type: !90)
!1113 = !DILocation(line: 0, scope: !1108)
!1114 = !DILocation(line: 187, column: 74, scope: !1108)
!1115 = !DILocation(line: 188, column: 5, scope: !1108)
!1116 = !DILocation(line: 189, column: 42, scope: !1108)
!1117 = !DILocation(line: 189, column: 8, scope: !1108)
!1118 = !DILocation(line: 189, column: 5, scope: !1108)
!1119 = !DILocation(line: 189, column: 31, scope: !1108)
!1120 = !DILocation(line: 189, column: 40, scope: !1108)
!1121 = !{!966, !931, i64 524}
!1122 = !DILocation(line: 190, column: 31, scope: !1108)
!1123 = !DILocation(line: 190, column: 44, scope: !1108)
!1124 = !DILocation(line: 191, column: 5, scope: !1108)
!1125 = !DILocation(line: 192, column: 1, scope: !1108)
!1126 = distinct !DISubprogram(name: "crawler_expired_finalize", scope: !3, file: !3, line: 194, type: !721, scopeLine: 194, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1127)
!1127 = !{!1128, !1129}
!1128 = !DILocalVariable(name: "cm", arg: 1, scope: !1126, file: !3, line: 194, type: !691)
!1129 = !DILocalVariable(name: "d", scope: !1126, file: !3, line: 195, type: !90)
!1130 = !DILocation(line: 0, scope: !1126)
!1131 = !DILocation(line: 195, column: 74, scope: !1126)
!1132 = !DILocation(line: 196, column: 5, scope: !1126)
!1133 = !DILocation(line: 197, column: 19, scope: !1126)
!1134 = !DILocation(line: 197, column: 8, scope: !1126)
!1135 = !DILocation(line: 197, column: 17, scope: !1126)
!1136 = !{!928, !931, i64 137260}
!1137 = !DILocation(line: 198, column: 8, scope: !1126)
!1138 = !DILocation(line: 198, column: 23, scope: !1126)
!1139 = !{!928, !932, i64 137264}
!1140 = !DILocation(line: 199, column: 5, scope: !1126)
!1141 = !DILocation(line: 201, column: 13, scope: !1142)
!1142 = distinct !DILexicalBlock(scope: !1126, file: !3, line: 201, column: 9)
!1143 = !{i8 0, i8 2}
!1144 = !{}
!1145 = !DILocation(line: 201, column: 9, scope: !1126)
!1146 = !DILocation(line: 202, column: 9, scope: !1147)
!1147 = distinct !DILexicalBlock(scope: !1142, file: !3, line: 201, column: 26)
!1148 = !DILocation(line: 203, column: 5, scope: !1147)
!1149 = !DILocation(line: 204, column: 1, scope: !1126)
!1150 = distinct !DISubprogram(name: "crawler_metadump_init", scope: !3, file: !3, line: 265, type: !689, scopeLine: 265, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1151)
!1151 = !{!1152, !1153}
!1152 = !DILocalVariable(name: "cm", arg: 1, scope: !1150, file: !3, line: 265, type: !691)
!1153 = !DILocalVariable(name: "data", arg: 2, scope: !1150, file: !3, line: 265, type: !89)
!1154 = !DILocation(line: 0, scope: !1150)
!1155 = !DILocation(line: 266, column: 9, scope: !1150)
!1156 = !DILocation(line: 266, column: 16, scope: !1150)
!1157 = !{!949, !931, i64 48}
!1158 = !DILocation(line: 267, column: 5, scope: !1150)
!1159 = distinct !DISubprogram(name: "crawler_metadump_eval", scope: !3, file: !3, line: 270, type: !711, scopeLine: 270, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1160)
!1160 = !{!1161, !1162, !1163, !1164, !1165, !1169, !1170, !1171}
!1161 = !DILocalVariable(name: "cm", arg: 1, scope: !1159, file: !3, line: 270, type: !691)
!1162 = !DILocalVariable(name: "it", arg: 2, scope: !1159, file: !3, line: 270, type: !529)
!1163 = !DILocalVariable(name: "hv", arg: 3, scope: !1159, file: !3, line: 270, type: !158)
!1164 = !DILocalVariable(name: "i", arg: 4, scope: !1159, file: !3, line: 270, type: !103)
!1165 = !DILocalVariable(name: "keybuf", scope: !1159, file: !3, line: 271, type: !1166)
!1166 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 6008, elements: !1167)
!1167 = !{!1168}
!1168 = !DISubrange(count: 751)
!1169 = !DILocalVariable(name: "is_flushed", scope: !1159, file: !3, line: 272, type: !103)
!1170 = !DILocalVariable(name: "flags", scope: !1159, file: !3, line: 279, type: !157)
!1171 = !DILocalVariable(name: "total", scope: !1159, file: !3, line: 283, type: !103)
!1172 = distinct !DIAssignID()
!1173 = !DILocation(line: 0, scope: !1159)
!1174 = !DILocation(line: 271, column: 5, scope: !1159)
!1175 = !DILocation(line: 272, column: 22, scope: !1159)
!1176 = !DILocation(line: 274, column: 14, scope: !1177)
!1177 = distinct !DILexicalBlock(scope: !1159, file: !3, line: 274, column: 9)
!1178 = !DILocation(line: 274, column: 22, scope: !1177)
!1179 = !DILocation(line: 274, column: 27, scope: !1177)
!1180 = !DILocation(line: 274, column: 44, scope: !1177)
!1181 = !DILocation(line: 274, column: 42, scope: !1177)
!1182 = !DILocation(line: 275, column: 9, scope: !1177)
!1183 = !DILocation(line: 275, column: 12, scope: !1177)
!1184 = !DILocation(line: 274, column: 9, scope: !1159)
!1185 = !DILocation(line: 276, column: 9, scope: !1186)
!1186 = distinct !DILexicalBlock(scope: !1177, file: !3, line: 275, column: 24)
!1187 = !DILocation(line: 277, column: 9, scope: !1186)
!1188 = !DILocation(line: 280, column: 5, scope: !1189)
!1189 = distinct !DILexicalBlock(scope: !1190, file: !3, line: 280, column: 5)
!1190 = distinct !DILexicalBlock(scope: !1159, file: !3, line: 280, column: 5)
!1191 = !DILocation(line: 280, column: 5, scope: !1190)
!1192 = !DILocation(line: 282, column: 41, scope: !1159)
!1193 = !DILocation(line: 282, column: 37, scope: !1159)
!1194 = !DILocation(line: 280, column: 5, scope: !1195)
!1195 = distinct !DILexicalBlock(scope: !1189, file: !3, line: 280, column: 5)
!1196 = !DILocation(line: 292, column: 13, scope: !1159)
!1197 = !DILocation(line: 282, column: 15, scope: !1159)
!1198 = !DILocation(line: 282, column: 5, scope: !1159)
!1199 = !DILocation(line: 283, column: 32, scope: !1159)
!1200 = !{!949, !950, i64 32}
!1201 = !DILocation(line: 283, column: 44, scope: !1159)
!1202 = !{!949, !931, i64 24}
!1203 = !DILocation(line: 283, column: 36, scope: !1159)
!1204 = !DILocation(line: 286, column: 18, scope: !1159)
!1205 = !DILocation(line: 286, column: 26, scope: !1159)
!1206 = !DILocation(line: 287, column: 45, scope: !1159)
!1207 = !DILocation(line: 286, column: 13, scope: !1159)
!1208 = !DILocation(line: 287, column: 38, scope: !1159)
!1209 = !DILocation(line: 287, column: 34, scope: !1159)
!1210 = !DILocation(line: 287, column: 43, scope: !1159)
!1211 = !DILocation(line: 288, column: 33, scope: !1159)
!1212 = !DILocation(line: 289, column: 14, scope: !1159)
!1213 = !DILocation(line: 289, column: 27, scope: !1159)
!1214 = !DILocation(line: 289, column: 13, scope: !1159)
!1215 = !DILocation(line: 290, column: 13, scope: !1159)
!1216 = !DILocation(line: 291, column: 29, scope: !1159)
!1217 = !DILocation(line: 283, column: 17, scope: !1159)
!1218 = !DILocation(line: 293, column: 5, scope: !1159)
!1219 = !DILocation(line: 296, column: 46, scope: !1220)
!1220 = distinct !DILexicalBlock(scope: !1159, file: !3, line: 296, column: 9)
!1221 = !DILocation(line: 300, column: 19, scope: !1159)
!1222 = !DILocation(line: 301, column: 1, scope: !1159)
!1223 = distinct !DISubprogram(name: "crawler_metadump_finalize", scope: !3, file: !3, line: 303, type: !721, scopeLine: 303, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1224)
!1224 = !{!1225, !1226, !1235}
!1225 = !DILocalVariable(name: "cm", arg: 1, scope: !1223, file: !3, line: 303, type: !691)
!1226 = !DILocalVariable(name: "errstr", scope: !1227, file: !3, line: 309, type: !1233)
!1227 = distinct !DILexicalBlock(scope: !1228, file: !3, line: 308, column: 34)
!1228 = distinct !DILexicalBlock(scope: !1229, file: !3, line: 308, column: 17)
!1229 = distinct !DILexicalBlock(scope: !1230, file: !3, line: 306, column: 45)
!1230 = distinct !DILexicalBlock(scope: !1231, file: !3, line: 306, column: 13)
!1231 = distinct !DILexicalBlock(scope: !1232, file: !3, line: 304, column: 26)
!1232 = distinct !DILexicalBlock(scope: !1223, file: !3, line: 304, column: 9)
!1233 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1234, size: 64)
!1234 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !121)
!1235 = !DILocalVariable(name: "errlen", scope: !1227, file: !3, line: 310, type: !430)
!1236 = !DILocation(line: 0, scope: !1223)
!1237 = !DILocation(line: 304, column: 13, scope: !1232)
!1238 = !DILocation(line: 304, column: 15, scope: !1232)
!1239 = !{!949, !950, i64 8}
!1240 = !DILocation(line: 304, column: 17, scope: !1232)
!1241 = !DILocation(line: 304, column: 9, scope: !1223)
!1242 = !DILocation(line: 306, column: 13, scope: !1230)
!1243 = !DILocation(line: 306, column: 39, scope: !1230)
!1244 = !DILocation(line: 306, column: 13, scope: !1231)
!1245 = !DILocation(line: 308, column: 21, scope: !1228)
!1246 = !DILocation(line: 308, column: 28, scope: !1228)
!1247 = !DILocation(line: 0, scope: !1228)
!1248 = !DILocation(line: 308, column: 17, scope: !1229)
!1249 = !DILocation(line: 0, scope: !1227)
!1250 = !DILocation(line: 311, column: 17, scope: !1227)
!1251 = !DILocation(line: 313, column: 13, scope: !1227)
!1252 = !DILocation(line: 314, column: 17, scope: !1253)
!1253 = distinct !DILexicalBlock(scope: !1228, file: !3, line: 313, column: 20)
!1254 = !DILocation(line: 319, column: 1, scope: !1223)
!1255 = distinct !DISubprogram(name: "crawler_mgdump_init", scope: !3, file: !3, line: 321, type: !689, scopeLine: 321, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1256)
!1256 = !{!1257, !1258}
!1257 = !DILocalVariable(name: "cm", arg: 1, scope: !1255, file: !3, line: 321, type: !691)
!1258 = !DILocalVariable(name: "data", arg: 2, scope: !1255, file: !3, line: 321, type: !89)
!1259 = !DILocation(line: 0, scope: !1255)
!1260 = !DILocation(line: 322, column: 9, scope: !1255)
!1261 = !DILocation(line: 322, column: 16, scope: !1255)
!1262 = !DILocation(line: 323, column: 5, scope: !1255)
!1263 = distinct !DISubprogram(name: "crawler_mgdump_eval", scope: !3, file: !3, line: 326, type: !711, scopeLine: 326, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1264)
!1264 = !{!1265, !1266, !1267, !1268, !1269, !1270, !1271, !1272}
!1265 = !DILocalVariable(name: "cm", arg: 1, scope: !1263, file: !3, line: 326, type: !691)
!1266 = !DILocalVariable(name: "it", arg: 2, scope: !1263, file: !3, line: 326, type: !529)
!1267 = !DILocalVariable(name: "hv", arg: 3, scope: !1263, file: !3, line: 326, type: !158)
!1268 = !DILocalVariable(name: "i", arg: 4, scope: !1263, file: !3, line: 326, type: !103)
!1269 = !DILocalVariable(name: "is_flushed", scope: !1263, file: !3, line: 327, type: !103)
!1270 = !DILocalVariable(name: "p", scope: !1263, file: !3, line: 335, type: !155)
!1271 = !DILocalVariable(name: "start", scope: !1263, file: !3, line: 336, type: !155)
!1272 = !DILocalVariable(name: "total", scope: !1263, file: !3, line: 349, type: !103)
!1273 = !DILocation(line: 0, scope: !1263)
!1274 = !DILocation(line: 327, column: 22, scope: !1263)
!1275 = !DILocation(line: 329, column: 14, scope: !1276)
!1276 = distinct !DILexicalBlock(scope: !1263, file: !3, line: 329, column: 9)
!1277 = !DILocation(line: 329, column: 22, scope: !1276)
!1278 = !DILocation(line: 329, column: 27, scope: !1276)
!1279 = !DILocation(line: 329, column: 44, scope: !1276)
!1280 = !DILocation(line: 329, column: 42, scope: !1276)
!1281 = !DILocation(line: 330, column: 9, scope: !1276)
!1282 = !DILocation(line: 330, column: 12, scope: !1276)
!1283 = !DILocation(line: 329, column: 9, scope: !1263)
!1284 = !DILocation(line: 331, column: 9, scope: !1285)
!1285 = distinct !DILexicalBlock(scope: !1276, file: !3, line: 330, column: 24)
!1286 = !DILocation(line: 332, column: 9, scope: !1285)
!1287 = !DILocation(line: 335, column: 21, scope: !1263)
!1288 = !DILocation(line: 335, column: 33, scope: !1263)
!1289 = !DILocation(line: 335, column: 25, scope: !1263)
!1290 = !DILocation(line: 337, column: 5, scope: !1263)
!1291 = !DILocation(line: 338, column: 7, scope: !1263)
!1292 = !DILocation(line: 339, column: 13, scope: !1293)
!1293 = distinct !DILexicalBlock(scope: !1263, file: !3, line: 339, column: 9)
!1294 = !DILocation(line: 339, column: 9, scope: !1293)
!1295 = !DILocation(line: 339, column: 22, scope: !1293)
!1296 = !DILocation(line: 0, scope: !1293)
!1297 = !DILocation(line: 339, column: 9, scope: !1263)
!1298 = !DILocation(line: 340, column: 14, scope: !1299)
!1299 = distinct !DILexicalBlock(scope: !1293, file: !3, line: 339, column: 41)
!1300 = !DILocation(line: 340, column: 11, scope: !1299)
!1301 = !DILocation(line: 341, column: 9, scope: !1299)
!1302 = !DILocation(line: 342, column: 11, scope: !1299)
!1303 = !DILocation(line: 343, column: 5, scope: !1299)
!1304 = !DILocation(line: 344, column: 9, scope: !1305)
!1305 = distinct !DILexicalBlock(scope: !1293, file: !3, line: 343, column: 12)
!1306 = !DILocation(line: 345, column: 18, scope: !1305)
!1307 = !DILocation(line: 345, column: 11, scope: !1305)
!1308 = !DILocation(line: 346, column: 9, scope: !1305)
!1309 = !DILocation(line: 347, column: 11, scope: !1305)
!1310 = !DILocation(line: 349, column: 19, scope: !1263)
!1311 = !DILocation(line: 349, column: 17, scope: !1263)
!1312 = !DILocation(line: 351, column: 5, scope: !1263)
!1313 = !DILocation(line: 352, column: 19, scope: !1263)
!1314 = !DILocation(line: 353, column: 1, scope: !1263)
!1315 = distinct !DISubprogram(name: "crawler_mgdump_finalize", scope: !3, file: !3, line: 355, type: !721, scopeLine: 355, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1316)
!1316 = !{!1317, !1318, !1325}
!1317 = !DILocalVariable(name: "cm", arg: 1, scope: !1315, file: !3, line: 355, type: !691)
!1318 = !DILocalVariable(name: "errstr", scope: !1319, file: !3, line: 361, type: !1233)
!1319 = distinct !DILexicalBlock(scope: !1320, file: !3, line: 360, column: 34)
!1320 = distinct !DILexicalBlock(scope: !1321, file: !3, line: 360, column: 17)
!1321 = distinct !DILexicalBlock(scope: !1322, file: !3, line: 358, column: 45)
!1322 = distinct !DILexicalBlock(scope: !1323, file: !3, line: 358, column: 13)
!1323 = distinct !DILexicalBlock(scope: !1324, file: !3, line: 356, column: 26)
!1324 = distinct !DILexicalBlock(scope: !1315, file: !3, line: 356, column: 9)
!1325 = !DILocalVariable(name: "errlen", scope: !1319, file: !3, line: 362, type: !430)
!1326 = !DILocation(line: 0, scope: !1315)
!1327 = !DILocation(line: 356, column: 13, scope: !1324)
!1328 = !DILocation(line: 356, column: 15, scope: !1324)
!1329 = !DILocation(line: 356, column: 17, scope: !1324)
!1330 = !DILocation(line: 356, column: 9, scope: !1315)
!1331 = !DILocation(line: 358, column: 13, scope: !1322)
!1332 = !DILocation(line: 358, column: 39, scope: !1322)
!1333 = !DILocation(line: 358, column: 13, scope: !1323)
!1334 = !DILocation(line: 360, column: 21, scope: !1320)
!1335 = !DILocation(line: 360, column: 28, scope: !1320)
!1336 = !DILocation(line: 0, scope: !1320)
!1337 = !DILocation(line: 360, column: 17, scope: !1321)
!1338 = !DILocation(line: 0, scope: !1319)
!1339 = !DILocation(line: 363, column: 17, scope: !1319)
!1340 = !DILocation(line: 365, column: 13, scope: !1319)
!1341 = !DILocation(line: 366, column: 17, scope: !1342)
!1342 = distinct !DILexicalBlock(scope: !1320, file: !3, line: 365, column: 20)
!1343 = !DILocation(line: 371, column: 1, scope: !1315)
!1344 = distinct !DISubprogram(name: "stop_item_crawler_thread", scope: !3, file: !3, line: 647, type: !1345, scopeLine: 647, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1347)
!1345 = !DISubroutineType(types: !1346)
!1346 = !{!103, !148}
!1347 = !{!1348, !1349}
!1348 = !DILocalVariable(name: "wait", arg: 1, scope: !1344, file: !3, line: 647, type: !148)
!1349 = !DILocalVariable(name: "ret", scope: !1344, file: !3, line: 648, type: !103)
!1350 = !DILocation(line: 0, scope: !1344)
!1351 = !DILocation(line: 649, column: 5, scope: !1344)
!1352 = !DILocation(line: 650, column: 9, scope: !1353)
!1353 = distinct !DILexicalBlock(scope: !1344, file: !3, line: 650, column: 9)
!1354 = !DILocation(line: 650, column: 35, scope: !1353)
!1355 = !DILocation(line: 650, column: 9, scope: !1344)
!1356 = !DILocation(line: 651, column: 9, scope: !1357)
!1357 = distinct !DILexicalBlock(scope: !1353, file: !3, line: 650, column: 41)
!1358 = !DILocation(line: 652, column: 9, scope: !1357)
!1359 = !DILocation(line: 654, column: 31, scope: !1344)
!1360 = !DILocation(line: 655, column: 5, scope: !1344)
!1361 = !DILocation(line: 656, column: 5, scope: !1344)
!1362 = !DILocation(line: 657, column: 14, scope: !1363)
!1363 = distinct !DILexicalBlock(scope: !1344, file: !3, line: 657, column: 9)
!1364 = !DILocation(line: 657, column: 37, scope: !1363)
!1365 = !DILocation(line: 657, column: 24, scope: !1363)
!1366 = !DILocation(line: 657, column: 62, scope: !1363)
!1367 = !DILocation(line: 657, column: 9, scope: !1344)
!1368 = !DILocation(line: 658, column: 17, scope: !1369)
!1369 = distinct !DILexicalBlock(scope: !1363, file: !3, line: 657, column: 68)
!1370 = !DILocation(line: 658, column: 68, scope: !1369)
!1371 = !DILocation(line: 658, column: 9, scope: !1369)
!1372 = !DILocation(line: 659, column: 9, scope: !1369)
!1373 = !DILocation(line: 662, column: 1, scope: !1344)
!1374 = !DISubprogram(name: "pthread_mutex_lock", scope: !1375, file: !1375, line: 794, type: !1376, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1375 = !DIFile(filename: "/usr/include/pthread.h", directory: "", checksumkind: CSK_MD5, checksum: "cbcd748b3d3ecaa7356dc2925b45d819")
!1376 = !DISubroutineType(types: !1377)
!1377 = !{!103, !1378}
!1378 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !94, size: 64)
!1379 = !DISubprogram(name: "pthread_mutex_unlock", scope: !1375, file: !1375, line: 835, type: !1376, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1380 = !DISubprogram(name: "pthread_cond_signal", scope: !1375, file: !1375, line: 1121, type: !1381, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1381 = !DISubroutineType(types: !1382)
!1382 = !{!103, !1383}
!1383 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !851, size: 64)
!1384 = !DISubprogram(name: "pthread_join", scope: !1375, file: !1375, line: 219, type: !1385, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1385 = !DISubroutineType(types: !1386)
!1386 = !{!103, !289, !1387}
!1387 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !89, size: 64)
!1388 = !DISubprogram(name: "fprintf", scope: !1389, file: !1389, line: 357, type: !1390, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1389 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "1e435c46987a169d9f9186f63a512303")
!1390 = !DISubroutineType(types: !1391)
!1391 = !{!103, !1392, !1446, null}
!1392 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1393)
!1393 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1394, size: 64)
!1394 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !1395, line: 7, baseType: !1396)
!1395 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!1396 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !1397, line: 49, size: 1728, elements: !1398)
!1397 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "7a6d4a00a37ee6b9a40cd04bd01f5d00")
!1398 = !{!1399, !1400, !1401, !1402, !1403, !1404, !1405, !1406, !1407, !1408, !1409, !1410, !1411, !1414, !1416, !1417, !1418, !1420, !1421, !1423, !1427, !1430, !1432, !1435, !1438, !1439, !1440, !1441, !1442}
!1399 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !1396, file: !1397, line: 51, baseType: !103, size: 32)
!1400 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !1396, file: !1397, line: 54, baseType: !155, size: 64, offset: 64)
!1401 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !1396, file: !1397, line: 55, baseType: !155, size: 64, offset: 128)
!1402 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !1396, file: !1397, line: 56, baseType: !155, size: 64, offset: 192)
!1403 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !1396, file: !1397, line: 57, baseType: !155, size: 64, offset: 256)
!1404 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !1396, file: !1397, line: 58, baseType: !155, size: 64, offset: 320)
!1405 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !1396, file: !1397, line: 59, baseType: !155, size: 64, offset: 384)
!1406 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !1396, file: !1397, line: 60, baseType: !155, size: 64, offset: 448)
!1407 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !1396, file: !1397, line: 61, baseType: !155, size: 64, offset: 512)
!1408 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !1396, file: !1397, line: 64, baseType: !155, size: 64, offset: 576)
!1409 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !1396, file: !1397, line: 65, baseType: !155, size: 64, offset: 640)
!1410 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !1396, file: !1397, line: 66, baseType: !155, size: 64, offset: 704)
!1411 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !1396, file: !1397, line: 68, baseType: !1412, size: 64, offset: 768)
!1412 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1413, size: 64)
!1413 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !1397, line: 36, flags: DIFlagFwdDecl)
!1414 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !1396, file: !1397, line: 70, baseType: !1415, size: 64, offset: 832)
!1415 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1396, size: 64)
!1416 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !1396, file: !1397, line: 72, baseType: !103, size: 32, offset: 896)
!1417 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !1396, file: !1397, line: 73, baseType: !103, size: 32, offset: 928)
!1418 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !1396, file: !1397, line: 74, baseType: !1419, size: 64, offset: 960)
!1419 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !136, line: 152, baseType: !125)
!1420 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !1396, file: !1397, line: 77, baseType: !454, size: 16, offset: 1024)
!1421 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !1396, file: !1397, line: 78, baseType: !1422, size: 8, offset: 1040)
!1422 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!1423 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !1396, file: !1397, line: 79, baseType: !1424, size: 8, offset: 1048)
!1424 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 8, elements: !1425)
!1425 = !{!1426}
!1426 = !DISubrange(count: 1)
!1427 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !1396, file: !1397, line: 81, baseType: !1428, size: 64, offset: 1088)
!1428 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1429, size: 64)
!1429 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !1397, line: 43, baseType: null)
!1430 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !1396, file: !1397, line: 89, baseType: !1431, size: 64, offset: 1152)
!1431 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !136, line: 153, baseType: !125)
!1432 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !1396, file: !1397, line: 91, baseType: !1433, size: 64, offset: 1216)
!1433 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1434, size: 64)
!1434 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !1397, line: 37, flags: DIFlagFwdDecl)
!1435 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !1396, file: !1397, line: 92, baseType: !1436, size: 64, offset: 1280)
!1436 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1437, size: 64)
!1437 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !1397, line: 38, flags: DIFlagFwdDecl)
!1438 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !1396, file: !1397, line: 93, baseType: !1415, size: 64, offset: 1344)
!1439 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !1396, file: !1397, line: 94, baseType: !89, size: 64, offset: 1408)
!1440 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !1396, file: !1397, line: 95, baseType: !430, size: 64, offset: 1472)
!1441 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !1396, file: !1397, line: 96, baseType: !103, size: 32, offset: 1536)
!1442 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !1396, file: !1397, line: 98, baseType: !1443, size: 160, offset: 1568)
!1443 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 160, elements: !1444)
!1444 = !{!1445}
!1445 = !DISubrange(count: 20)
!1446 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1233)
!1447 = !DISubprogram(name: "strerror", scope: !1448, file: !1448, line: 419, type: !1449, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1448 = !DIFile(filename: "/usr/include/string.h", directory: "", checksumkind: CSK_MD5, checksum: "165db1185644f68894fa9e0d17055d70")
!1449 = !DISubroutineType(types: !1450)
!1450 = !{!155, !103}
!1451 = distinct !DISubprogram(name: "start_item_crawler_thread", scope: !3, file: !3, line: 675, type: !1452, scopeLine: 675, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1454)
!1452 = !DISubroutineType(types: !1453)
!1453 = !{!103}
!1454 = !{!1455}
!1455 = !DILocalVariable(name: "ret", scope: !1451, file: !3, line: 676, type: !103)
!1456 = !DILocation(line: 678, column: 18, scope: !1457)
!1457 = distinct !DILexicalBlock(scope: !1451, file: !3, line: 678, column: 9)
!1458 = !{!1035, !932, i64 134}
!1459 = !DILocation(line: 678, column: 9, scope: !1451)
!1460 = !DILocation(line: 680, column: 5, scope: !1451)
!1461 = !DILocation(line: 681, column: 31, scope: !1451)
!1462 = !DILocation(line: 682, column: 16, scope: !1463)
!1463 = distinct !DILexicalBlock(scope: !1451, file: !3, line: 682, column: 9)
!1464 = !DILocation(line: 0, scope: !1451)
!1465 = !DILocation(line: 683, column: 37, scope: !1463)
!1466 = !DILocation(line: 682, column: 9, scope: !1451)
!1467 = !DILocation(line: 684, column: 17, scope: !1468)
!1468 = distinct !DILexicalBlock(scope: !1463, file: !3, line: 683, column: 43)
!1469 = !DILocation(line: 685, column: 13, scope: !1468)
!1470 = !DILocation(line: 684, column: 9, scope: !1468)
!1471 = !DILocation(line: 687, column: 9, scope: !1468)
!1472 = !DILocation(line: 689, column: 20, scope: !1451)
!1473 = !DILocation(line: 689, column: 5, scope: !1451)
!1474 = !DILocation(line: 691, column: 5, scope: !1451)
!1475 = !DILocation(line: 694, column: 5, scope: !1451)
!1476 = !DILocation(line: 695, column: 1, scope: !1451)
!1477 = !DISubprogram(name: "pthread_create", scope: !1375, file: !1375, line: 202, type: !1478, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1478 = !DISubroutineType(types: !1479)
!1479 = !{!103, !1480, !1482, !1493, !1496}
!1480 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1481)
!1481 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !289, size: 64)
!1482 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1483)
!1483 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1484, size: 64)
!1484 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !1485)
!1485 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_attr_t", file: !95, line: 62, baseType: !1486)
!1486 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "pthread_attr_t", file: !95, line: 56, size: 448, elements: !1487)
!1487 = !{!1488, !1492}
!1488 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !1486, file: !95, line: 58, baseType: !1489, size: 448)
!1489 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 448, elements: !1490)
!1490 = !{!1491}
!1491 = !DISubrange(count: 56)
!1492 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !1486, file: !95, line: 59, baseType: !125, size: 64)
!1493 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1494, size: 64)
!1494 = !DISubroutineType(types: !1495)
!1495 = !{!89, !89}
!1496 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !89)
!1497 = distinct !DISubprogram(name: "item_crawler_thread", scope: !3, file: !3, line: 523, type: !1494, scopeLine: 523, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1498)
!1498 = !{!1499, !1500, !1501, !1502, !1507, !1508, !1515, !1518}
!1499 = !DILocalVariable(name: "arg", arg: 1, scope: !1497, file: !3, line: 523, type: !89)
!1500 = !DILocalVariable(name: "i", scope: !1497, file: !3, line: 524, type: !103)
!1501 = !DILocalVariable(name: "crawls_persleep", scope: !1497, file: !3, line: 525, type: !103)
!1502 = !DILocalVariable(name: "search", scope: !1503, file: !3, line: 540, type: !529)
!1503 = distinct !DILexicalBlock(scope: !1504, file: !3, line: 539, column: 27)
!1504 = distinct !DILexicalBlock(scope: !1505, file: !3, line: 538, column: 12)
!1505 = distinct !DILexicalBlock(scope: !1506, file: !3, line: 535, column: 9)
!1506 = distinct !DILexicalBlock(scope: !1497, file: !3, line: 532, column: 39)
!1507 = !DILocalVariable(name: "hold_lock", scope: !1503, file: !3, line: 541, type: !89)
!1508 = !DILocalVariable(name: "c", scope: !1509, file: !3, line: 549, type: !1514)
!1509 = distinct !DILexicalBlock(scope: !1510, file: !3, line: 548, column: 49)
!1510 = distinct !DILexicalBlock(scope: !1511, file: !3, line: 548, column: 17)
!1511 = distinct !DILexicalBlock(scope: !1512, file: !3, line: 543, column: 55)
!1512 = distinct !DILexicalBlock(scope: !1513, file: !3, line: 543, column: 9)
!1513 = distinct !DILexicalBlock(scope: !1503, file: !3, line: 543, column: 9)
!1514 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !697, size: 64)
!1515 = !DILocalVariable(name: "ret", scope: !1516, file: !3, line: 551, type: !103)
!1516 = distinct !DILexicalBlock(scope: !1517, file: !3, line: 550, column: 71)
!1517 = distinct !DILexicalBlock(scope: !1509, file: !3, line: 550, column: 21)
!1518 = !DILocalVariable(name: "hv", scope: !1511, file: !3, line: 570, type: !158)
!1519 = distinct !DIAssignID()
!1520 = !DILocation(line: 0, scope: !1497)
!1521 = !DILocation(line: 525, column: 36, scope: !1497)
!1522 = !{!1035, !931, i64 216}
!1523 = !DILocation(line: 527, column: 5, scope: !1497)
!1524 = !DILocation(line: 528, column: 5, scope: !1497)
!1525 = !DILocation(line: 529, column: 26, scope: !1497)
!1526 = !DILocation(line: 530, column: 18, scope: !1527)
!1527 = distinct !DILexicalBlock(scope: !1497, file: !3, line: 530, column: 9)
!1528 = !DILocation(line: 530, column: 26, scope: !1527)
!1529 = !DILocation(line: 530, column: 9, scope: !1497)
!1530 = !DILocation(line: 531, column: 17, scope: !1527)
!1531 = !DILocation(line: 531, column: 9, scope: !1527)
!1532 = !DILocation(line: 532, column: 12, scope: !1497)
!1533 = !DILocation(line: 532, column: 5, scope: !1497)
!1534 = !DILocation(line: 533, column: 5, scope: !1506)
!1535 = !DILocation(line: 535, column: 9, scope: !1505)
!1536 = !DILocation(line: 535, column: 9, scope: !1506)
!1537 = !DILocalVariable(name: "it", scope: !1538, file: !3, line: 449, type: !529)
!1538 = distinct !DISubprogram(name: "item_crawl_hash", scope: !3, file: !3, line: 444, type: !1539, scopeLine: 444, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1541)
!1539 = !DISubroutineType(types: !1540)
!1540 = !{null}
!1541 = !{!1542, !1543, !1537, !1544, !1545, !1553}
!1542 = !DILocalVariable(name: "iter", scope: !1538, file: !3, line: 447, type: !89)
!1543 = !DILocalVariable(name: "crawls_persleep", scope: !1538, file: !3, line: 448, type: !103)
!1544 = !DILocalVariable(name: "items", scope: !1538, file: !3, line: 450, type: !103)
!1545 = !DILocalVariable(name: "ret", scope: !1546, file: !3, line: 467, type: !103)
!1546 = distinct !DILexicalBlock(scope: !1547, file: !3, line: 466, column: 50)
!1547 = distinct !DILexicalBlock(scope: !1548, file: !3, line: 466, column: 21)
!1548 = distinct !DILexicalBlock(scope: !1549, file: !3, line: 465, column: 49)
!1549 = distinct !DILexicalBlock(scope: !1550, file: !3, line: 465, column: 17)
!1550 = distinct !DILexicalBlock(scope: !1551, file: !3, line: 464, column: 25)
!1551 = distinct !DILexicalBlock(scope: !1552, file: !3, line: 464, column: 13)
!1552 = distinct !DILexicalBlock(scope: !1538, file: !3, line: 461, column: 38)
!1553 = !DILocalVariable(name: "c", scope: !1554, file: !3, line: 503, type: !1514)
!1554 = distinct !DILexicalBlock(scope: !1555, file: !3, line: 502, column: 45)
!1555 = distinct !DILexicalBlock(scope: !1552, file: !3, line: 502, column: 13)
!1556 = !DILocation(line: 0, scope: !1538, inlinedAt: !1557)
!1557 = distinct !DILocation(line: 536, column: 9, scope: !1558)
!1558 = distinct !DILexicalBlock(scope: !1505, file: !3, line: 535, column: 30)
!1559 = !DILocation(line: 447, column: 18, scope: !1538, inlinedAt: !1557)
!1560 = !DILocation(line: 448, column: 36, scope: !1538, inlinedAt: !1557)
!1561 = !DILocation(line: 449, column: 5, scope: !1538, inlinedAt: !1557)
!1562 = !DILocation(line: 449, column: 11, scope: !1538, inlinedAt: !1557)
!1563 = distinct !DIAssignID()
!1564 = !DILocation(line: 453, column: 14, scope: !1565, inlinedAt: !1557)
!1565 = distinct !DILexicalBlock(scope: !1538, file: !3, line: 453, column: 9)
!1566 = !DILocation(line: 453, column: 9, scope: !1538, inlinedAt: !1557)
!1567 = !DILocation(line: 461, column: 12, scope: !1538, inlinedAt: !1557)
!1568 = !DILocation(line: 461, column: 5, scope: !1538, inlinedAt: !1557)
!1569 = !DILocation(line: 454, column: 35, scope: !1570, inlinedAt: !1557)
!1570 = distinct !DILexicalBlock(scope: !1565, file: !3, line: 453, column: 23)
!1571 = !DILocation(line: 455, column: 9, scope: !1570, inlinedAt: !1557)
!1572 = !DILocation(line: 464, column: 13, scope: !1551, inlinedAt: !1557)
!1573 = !DILocation(line: 464, column: 16, scope: !1551, inlinedAt: !1557)
!1574 = !DILocation(line: 464, column: 13, scope: !1552, inlinedAt: !1557)
!1575 = !DILocation(line: 465, column: 38, scope: !1549, inlinedAt: !1557)
!1576 = !DILocation(line: 465, column: 40, scope: !1549, inlinedAt: !1557)
!1577 = !DILocation(line: 465, column: 17, scope: !1550, inlinedAt: !1557)
!1578 = !DILocation(line: 466, column: 27, scope: !1547, inlinedAt: !1557)
!1579 = !DILocation(line: 466, column: 21, scope: !1548, inlinedAt: !1557)
!1580 = !DILocation(line: 467, column: 31, scope: !1546, inlinedAt: !1557)
!1581 = !DILocation(line: 0, scope: !1546, inlinedAt: !1557)
!1582 = !DILocation(line: 469, column: 29, scope: !1583, inlinedAt: !1557)
!1583 = distinct !DILexicalBlock(scope: !1546, file: !3, line: 469, column: 25)
!1584 = !DILocation(line: 474, column: 43, scope: !1585, inlinedAt: !1557)
!1585 = distinct !DILexicalBlock(scope: !1549, file: !3, line: 474, column: 24)
!1586 = !{!949, !950, i64 40}
!1587 = !DILocation(line: 474, column: 48, scope: !1585, inlinedAt: !1557)
!1588 = !{!1589, !932, i64 33}
!1589 = !{!"", !950, i64 0, !950, i64 8, !950, i64 16, !950, i64 24, !932, i64 32, !932, i64 33}
!1590 = !DILocation(line: 474, column: 24, scope: !1549, inlinedAt: !1557)
!1591 = !DILocation(line: 480, column: 33, scope: !1592, inlinedAt: !1557)
!1592 = distinct !DILexicalBlock(scope: !1550, file: !3, line: 480, column: 17)
!1593 = !DILocation(line: 0, scope: !1592, inlinedAt: !1557)
!1594 = !{!1035, !931, i64 184}
!1595 = !DILocation(line: 480, column: 38, scope: !1592, inlinedAt: !1557)
!1596 = !DILocation(line: 480, column: 17, scope: !1550, inlinedAt: !1557)
!1597 = !DILocation(line: 481, column: 17, scope: !1598, inlinedAt: !1557)
!1598 = distinct !DILexicalBlock(scope: !1592, file: !3, line: 480, column: 69)
!1599 = !DILocation(line: 482, column: 33, scope: !1598, inlinedAt: !1557)
!1600 = !DILocation(line: 482, column: 17, scope: !1598, inlinedAt: !1557)
!1601 = !DILocation(line: 483, column: 17, scope: !1598, inlinedAt: !1557)
!1602 = !DILocation(line: 484, column: 44, scope: !1598, inlinedAt: !1557)
!1603 = !DILocation(line: 485, column: 13, scope: !1598, inlinedAt: !1557)
!1604 = !DILocation(line: 485, column: 24, scope: !1592, inlinedAt: !1557)
!1605 = !DILocation(line: 487, column: 17, scope: !1606, inlinedAt: !1557)
!1606 = distinct !DILexicalBlock(scope: !1607, file: !3, line: 485, column: 53)
!1607 = distinct !DILexicalBlock(scope: !1592, file: !3, line: 485, column: 24)
!1608 = !DILocation(line: 488, column: 17, scope: !1606, inlinedAt: !1557)
!1609 = !DILocation(line: 489, column: 13, scope: !1606, inlinedAt: !1557)
!1610 = distinct !{!1610, !1568, !1611, !975}
!1611 = !DILocation(line: 516, column: 5, scope: !1538, inlinedAt: !1557)
!1612 = !DILocation(line: 494, column: 13, scope: !1613, inlinedAt: !1557)
!1613 = distinct !DILexicalBlock(scope: !1552, file: !3, line: 494, column: 13)
!1614 = !DILocation(line: 494, column: 31, scope: !1613, inlinedAt: !1557)
!1615 = !DILocation(line: 494, column: 13, scope: !1552, inlinedAt: !1557)
!1616 = !DILocation(line: 495, column: 13, scope: !1617, inlinedAt: !1557)
!1617 = distinct !DILexicalBlock(scope: !1613, file: !3, line: 494, column: 36)
!1618 = distinct !{!1618, !1568, !1611, !975}
!1619 = !DILocation(line: 502, column: 34, scope: !1555, inlinedAt: !1557)
!1620 = !DILocation(line: 502, column: 36, scope: !1555, inlinedAt: !1557)
!1621 = !DILocation(line: 502, column: 13, scope: !1552, inlinedAt: !1557)
!1622 = !DILocation(line: 0, scope: !1554, inlinedAt: !1557)
!1623 = !DILocation(line: 504, column: 20, scope: !1624, inlinedAt: !1557)
!1624 = distinct !DILexicalBlock(scope: !1554, file: !3, line: 504, column: 17)
!1625 = !{!951, !931, i64 12}
!1626 = !DILocation(line: 504, column: 32, scope: !1624, inlinedAt: !1557)
!1627 = !{!951, !931, i64 16}
!1628 = !DILocation(line: 504, column: 27, scope: !1624, inlinedAt: !1557)
!1629 = !DILocation(line: 504, column: 40, scope: !1624, inlinedAt: !1557)
!1630 = !DILocation(line: 504, column: 17, scope: !1554, inlinedAt: !1557)
!1631 = !DILocalVariable(name: "c", arg: 1, scope: !1632, file: !3, line: 147, type: !1514)
!1632 = distinct !DISubprogram(name: "lru_crawler_expand_buf", scope: !3, file: !3, line: 147, type: !1633, scopeLine: 147, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1635)
!1633 = !DISubroutineType(types: !1634)
!1634 = !{!103, !1514}
!1635 = !{!1631, !1636}
!1636 = !DILocalVariable(name: "nb", scope: !1632, file: !3, line: 149, type: !155)
!1637 = !DILocation(line: 0, scope: !1632, inlinedAt: !1638)
!1638 = distinct !DILocation(line: 505, column: 21, scope: !1639, inlinedAt: !1557)
!1639 = distinct !DILexicalBlock(scope: !1640, file: !3, line: 505, column: 21)
!1640 = distinct !DILexicalBlock(scope: !1624, file: !3, line: 504, column: 67)
!1641 = !DILocation(line: 148, column: 15, scope: !1632, inlinedAt: !1638)
!1642 = !DILocation(line: 149, column: 27, scope: !1632, inlinedAt: !1638)
!1643 = !{!951, !950, i64 24}
!1644 = !DILocation(line: 149, column: 32, scope: !1632, inlinedAt: !1638)
!1645 = !DILocation(line: 149, column: 16, scope: !1632, inlinedAt: !1638)
!1646 = !DILocation(line: 150, column: 12, scope: !1647, inlinedAt: !1638)
!1647 = distinct !DILexicalBlock(scope: !1632, file: !3, line: 150, column: 9)
!1648 = !DILocation(line: 150, column: 9, scope: !1632, inlinedAt: !1638)
!1649 = !DILocation(line: 153, column: 12, scope: !1632, inlinedAt: !1638)
!1650 = !DILocation(line: 513, column: 59, scope: !1552, inlinedAt: !1557)
!1651 = !DILocation(line: 505, column: 21, scope: !1640, inlinedAt: !1557)
!1652 = !DILocation(line: 513, column: 28, scope: !1552, inlinedAt: !1557)
!1653 = !DILocation(line: 513, column: 33, scope: !1552, inlinedAt: !1557)
!1654 = !{!1589, !950, i64 8}
!1655 = !DILocation(line: 513, column: 9, scope: !1552, inlinedAt: !1557)
!1656 = !DILocation(line: 514, column: 24, scope: !1552, inlinedAt: !1557)
!1657 = !DILocation(line: 515, column: 14, scope: !1552, inlinedAt: !1557)
!1658 = !DILocation(line: 519, column: 5, scope: !1538, inlinedAt: !1557)
!1659 = !DILocation(line: 520, column: 5, scope: !1538, inlinedAt: !1557)
!1660 = !DILocation(line: 521, column: 1, scope: !1538, inlinedAt: !1557)
!1661 = !DILocation(line: 537, column: 23, scope: !1558)
!1662 = !DILocation(line: 538, column: 5, scope: !1558)
!1663 = !DILocation(line: 539, column: 12, scope: !1504)
!1664 = !DILocation(line: 539, column: 5, scope: !1504)
!1665 = !DILocation(line: 544, column: 17, scope: !1666)
!1666 = distinct !DILexicalBlock(scope: !1511, file: !3, line: 544, column: 17)
!1667 = !DILocation(line: 544, column: 29, scope: !1666)
!1668 = !{!1029, !1009, i64 38}
!1669 = !DILocation(line: 544, column: 38, scope: !1666)
!1670 = !DILocation(line: 544, column: 17, scope: !1511)
!1671 = !DILocation(line: 548, column: 38, scope: !1510)
!1672 = !DILocation(line: 548, column: 40, scope: !1510)
!1673 = !DILocation(line: 548, column: 17, scope: !1511)
!1674 = !DILocation(line: 0, scope: !1509)
!1675 = !DILocation(line: 550, column: 24, scope: !1517)
!1676 = !DILocation(line: 550, column: 36, scope: !1517)
!1677 = !DILocation(line: 550, column: 31, scope: !1517)
!1678 = !DILocation(line: 550, column: 44, scope: !1517)
!1679 = !DILocation(line: 550, column: 21, scope: !1509)
!1680 = !DILocation(line: 551, column: 31, scope: !1516)
!1681 = !DILocation(line: 0, scope: !1516)
!1682 = !DILocation(line: 552, column: 29, scope: !1683)
!1683 = distinct !DILexicalBlock(scope: !1516, file: !3, line: 552, column: 25)
!1684 = !DILocation(line: 552, column: 25, scope: !1516)
!1685 = !DILocalVariable(name: "i", arg: 1, scope: !1686, file: !3, line: 431, type: !103)
!1686 = distinct !DISubprogram(name: "lru_crawler_class_done", scope: !3, file: !3, line: 431, type: !1687, scopeLine: 431, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1689)
!1687 = !DISubroutineType(types: !1688)
!1688 = !{null, !103}
!1689 = !{!1685}
!1690 = !DILocation(line: 0, scope: !1686, inlinedAt: !1691)
!1691 = distinct !DILocation(line: 553, column: 25, scope: !1692)
!1692 = distinct !DILexicalBlock(scope: !1683, file: !3, line: 552, column: 35)
!1693 = !DILocation(line: 432, column: 26, scope: !1686, inlinedAt: !1691)
!1694 = !DILocation(line: 433, column: 18, scope: !1686, inlinedAt: !1691)
!1695 = !DILocation(line: 434, column: 5, scope: !1686, inlinedAt: !1691)
!1696 = !DILocation(line: 435, column: 44, scope: !1686, inlinedAt: !1691)
!1697 = !DILocation(line: 436, column: 25, scope: !1686, inlinedAt: !1691)
!1698 = !DILocation(line: 436, column: 48, scope: !1686, inlinedAt: !1691)
!1699 = !{!1029, !967, i64 64}
!1700 = !DILocation(line: 435, column: 5, scope: !1686, inlinedAt: !1691)
!1701 = !DILocation(line: 437, column: 27, scope: !1686, inlinedAt: !1691)
!1702 = !DILocation(line: 437, column: 5, scope: !1686, inlinedAt: !1691)
!1703 = !DILocation(line: 438, column: 28, scope: !1704, inlinedAt: !1691)
!1704 = distinct !DILexicalBlock(scope: !1686, file: !3, line: 438, column: 9)
!1705 = !DILocation(line: 438, column: 33, scope: !1704, inlinedAt: !1691)
!1706 = !{!1589, !950, i64 16}
!1707 = !DILocation(line: 438, column: 43, scope: !1704, inlinedAt: !1691)
!1708 = !DILocation(line: 438, column: 9, scope: !1686, inlinedAt: !1691)
!1709 = !DILocation(line: 439, column: 9, scope: !1704, inlinedAt: !1691)
!1710 = !DILocation(line: 557, column: 43, scope: !1711)
!1711 = distinct !DILexicalBlock(scope: !1510, file: !3, line: 557, column: 24)
!1712 = !DILocation(line: 557, column: 48, scope: !1711)
!1713 = !DILocation(line: 557, column: 24, scope: !1510)
!1714 = !DILocation(line: 0, scope: !1686, inlinedAt: !1715)
!1715 = distinct !DILocation(line: 558, column: 17, scope: !1716)
!1716 = distinct !DILexicalBlock(scope: !1711, file: !3, line: 557, column: 62)
!1717 = !DILocation(line: 432, column: 26, scope: !1686, inlinedAt: !1715)
!1718 = !DILocation(line: 433, column: 18, scope: !1686, inlinedAt: !1715)
!1719 = !DILocation(line: 434, column: 5, scope: !1686, inlinedAt: !1715)
!1720 = !DILocation(line: 435, column: 44, scope: !1686, inlinedAt: !1715)
!1721 = !DILocation(line: 436, column: 25, scope: !1686, inlinedAt: !1715)
!1722 = !DILocation(line: 436, column: 48, scope: !1686, inlinedAt: !1715)
!1723 = !DILocation(line: 435, column: 5, scope: !1686, inlinedAt: !1715)
!1724 = !DILocation(line: 437, column: 27, scope: !1686, inlinedAt: !1715)
!1725 = !DILocation(line: 437, column: 5, scope: !1686, inlinedAt: !1715)
!1726 = !DILocation(line: 438, column: 28, scope: !1704, inlinedAt: !1715)
!1727 = !DILocation(line: 438, column: 33, scope: !1704, inlinedAt: !1715)
!1728 = !DILocation(line: 438, column: 43, scope: !1704, inlinedAt: !1715)
!1729 = !DILocation(line: 438, column: 9, scope: !1686, inlinedAt: !1715)
!1730 = !DILocation(line: 439, column: 9, scope: !1704, inlinedAt: !1715)
!1731 = !DILocation(line: 561, column: 33, scope: !1511)
!1732 = !DILocation(line: 561, column: 13, scope: !1511)
!1733 = !DILocation(line: 562, column: 22, scope: !1511)
!1734 = !DILocation(line: 0, scope: !1503)
!1735 = !DILocation(line: 563, column: 24, scope: !1736)
!1736 = distinct !DILexicalBlock(scope: !1511, file: !3, line: 563, column: 17)
!1737 = !DILocation(line: 563, column: 32, scope: !1736)
!1738 = !DILocation(line: 564, column: 30, scope: !1736)
!1739 = !{!1029, !931, i64 44}
!1740 = !DILocation(line: 564, column: 18, scope: !1736)
!1741 = !DILocation(line: 564, column: 40, scope: !1736)
!1742 = !DILocation(line: 564, column: 43, scope: !1736)
!1743 = !DILocation(line: 564, column: 67, scope: !1736)
!1744 = !DILocation(line: 563, column: 17, scope: !1511)
!1745 = !DILocation(line: 565, column: 30, scope: !1746)
!1746 = distinct !DILexicalBlock(scope: !1747, file: !3, line: 565, column: 21)
!1747 = distinct !DILexicalBlock(scope: !1736, file: !3, line: 564, column: 73)
!1748 = !DILocation(line: 565, column: 38, scope: !1746)
!1749 = !DILocation(line: 565, column: 21, scope: !1747)
!1750 = !DILocation(line: 435, column: 5, scope: !1686, inlinedAt: !1751)
!1751 = distinct !DILocation(line: 567, column: 17, scope: !1747)
!1752 = !DILocation(line: 566, column: 29, scope: !1746)
!1753 = !DILocation(line: 566, column: 21, scope: !1746)
!1754 = !DILocation(line: 0, scope: !1686, inlinedAt: !1751)
!1755 = !DILocation(line: 432, column: 26, scope: !1686, inlinedAt: !1751)
!1756 = !DILocation(line: 433, column: 18, scope: !1686, inlinedAt: !1751)
!1757 = !DILocation(line: 434, column: 5, scope: !1686, inlinedAt: !1751)
!1758 = !DILocation(line: 435, column: 44, scope: !1686, inlinedAt: !1751)
!1759 = !DILocation(line: 436, column: 25, scope: !1686, inlinedAt: !1751)
!1760 = !DILocation(line: 436, column: 48, scope: !1686, inlinedAt: !1751)
!1761 = !DILocation(line: 437, column: 5, scope: !1686, inlinedAt: !1751)
!1762 = !DILocation(line: 438, column: 28, scope: !1704, inlinedAt: !1751)
!1763 = !DILocation(line: 438, column: 33, scope: !1704, inlinedAt: !1751)
!1764 = !DILocation(line: 438, column: 43, scope: !1704, inlinedAt: !1751)
!1765 = !DILocation(line: 438, column: 9, scope: !1686, inlinedAt: !1751)
!1766 = !DILocation(line: 439, column: 9, scope: !1704, inlinedAt: !1751)
!1767 = !DILocation(line: 570, column: 27, scope: !1511)
!1768 = !DILocation(line: 570, column: 32, scope: !1511)
!1769 = !DILocation(line: 570, column: 58, scope: !1511)
!1770 = !DILocation(line: 570, column: 50, scope: !1511)
!1771 = !DILocation(line: 0, scope: !1511)
!1772 = !DILocation(line: 574, column: 30, scope: !1773)
!1773 = distinct !DILexicalBlock(scope: !1511, file: !3, line: 574, column: 17)
!1774 = !DILocation(line: 574, column: 48, scope: !1773)
!1775 = !DILocation(line: 574, column: 17, scope: !1511)
!1776 = !DILocation(line: 575, column: 17, scope: !1777)
!1777 = distinct !DILexicalBlock(scope: !1773, file: !3, line: 574, column: 57)
!1778 = !DILocation(line: 576, column: 17, scope: !1777)
!1779 = !DILocation(line: 579, column: 17, scope: !1780)
!1780 = distinct !DILexicalBlock(scope: !1511, file: !3, line: 579, column: 17)
!1781 = !DILocation(line: 579, column: 39, scope: !1780)
!1782 = !DILocation(line: 579, column: 17, scope: !1511)
!1783 = !DILocation(line: 580, column: 17, scope: !1784)
!1784 = distinct !DILexicalBlock(scope: !1780, file: !3, line: 579, column: 45)
!1785 = !DILocation(line: 582, column: 21, scope: !1786)
!1786 = distinct !DILexicalBlock(scope: !1784, file: !3, line: 581, column: 21)
!1787 = !DILocation(line: 583, column: 17, scope: !1784)
!1788 = !DILocation(line: 584, column: 17, scope: !1784)
!1789 = !DILocation(line: 587, column: 25, scope: !1511)
!1790 = !DILocation(line: 587, column: 32, scope: !1511)
!1791 = !DILocation(line: 591, column: 37, scope: !1792)
!1792 = distinct !DILexicalBlock(scope: !1511, file: !3, line: 591, column: 17)
!1793 = !DILocation(line: 591, column: 42, scope: !1792)
!1794 = !{!1589, !932, i64 32}
!1795 = !DILocation(line: 591, column: 17, scope: !1511)
!1796 = !DILocation(line: 592, column: 17, scope: !1797)
!1797 = distinct !DILexicalBlock(scope: !1792, file: !3, line: 591, column: 54)
!1798 = !DILocation(line: 595, column: 32, scope: !1511)
!1799 = !DILocation(line: 593, column: 13, scope: !1797)
!1800 = !DILocation(line: 595, column: 37, scope: !1511)
!1801 = !DILocation(line: 595, column: 13, scope: !1511)
!1802 = !DILocation(line: 598, column: 17, scope: !1803)
!1803 = distinct !DILexicalBlock(scope: !1511, file: !3, line: 597, column: 17)
!1804 = !DILocation(line: 599, column: 36, scope: !1805)
!1805 = distinct !DILexicalBlock(scope: !1511, file: !3, line: 599, column: 17)
!1806 = !DILocation(line: 599, column: 41, scope: !1805)
!1807 = !DILocation(line: 599, column: 17, scope: !1511)
!1808 = !DILocation(line: 600, column: 17, scope: !1809)
!1809 = distinct !DILexicalBlock(scope: !1805, file: !3, line: 599, column: 53)
!1810 = !DILocation(line: 601, column: 13, scope: !1809)
!1811 = !DILocation(line: 603, column: 32, scope: !1812)
!1812 = distinct !DILexicalBlock(scope: !1511, file: !3, line: 603, column: 17)
!1813 = !DILocation(line: 603, column: 35, scope: !1812)
!1814 = !DILocation(line: 0, scope: !1812)
!1815 = !DILocation(line: 603, column: 40, scope: !1812)
!1816 = !DILocation(line: 603, column: 17, scope: !1511)
!1817 = !DILocation(line: 604, column: 17, scope: !1818)
!1818 = distinct !DILexicalBlock(scope: !1812, file: !3, line: 603, column: 71)
!1819 = !DILocation(line: 605, column: 33, scope: !1818)
!1820 = !DILocation(line: 605, column: 17, scope: !1818)
!1821 = !DILocation(line: 606, column: 17, scope: !1818)
!1822 = !DILocation(line: 607, column: 44, scope: !1818)
!1823 = !DILocation(line: 608, column: 13, scope: !1818)
!1824 = !DILocation(line: 608, column: 24, scope: !1812)
!1825 = !DILocation(line: 610, column: 17, scope: !1826)
!1826 = distinct !DILexicalBlock(scope: !1827, file: !3, line: 608, column: 53)
!1827 = distinct !DILexicalBlock(scope: !1812, file: !3, line: 608, column: 24)
!1828 = !DILocation(line: 611, column: 17, scope: !1826)
!1829 = !DILocation(line: 612, column: 13, scope: !1826)
!1830 = !DILocation(line: 525, column: 9, scope: !1497)
!1831 = !DILocation(line: 543, column: 51, scope: !1512)
!1832 = !DILocation(line: 543, column: 36, scope: !1512)
!1833 = !DILocation(line: 543, column: 9, scope: !1513)
!1834 = distinct !{!1834, !1833, !1835, !975}
!1835 = !DILocation(line: 613, column: 9, scope: !1513)
!1836 = !DILocation(line: 617, column: 28, scope: !1837)
!1837 = distinct !DILexicalBlock(scope: !1506, file: !3, line: 617, column: 9)
!1838 = !DILocation(line: 617, column: 32, scope: !1837)
!1839 = !DILocation(line: 617, column: 9, scope: !1506)
!1840 = !DILocation(line: 618, column: 37, scope: !1841)
!1841 = distinct !DILexicalBlock(scope: !1842, file: !3, line: 618, column: 13)
!1842 = distinct !DILexicalBlock(scope: !1837, file: !3, line: 617, column: 41)
!1843 = !{!1589, !950, i64 24}
!1844 = !DILocation(line: 618, column: 46, scope: !1841)
!1845 = !DILocation(line: 618, column: 13, scope: !1842)
!1846 = !DILocation(line: 619, column: 13, scope: !1841)
!1847 = !DILocation(line: 620, column: 37, scope: !1842)
!1848 = !{!951, !950, i64 0}
!1849 = !DILocation(line: 620, column: 39, scope: !1842)
!1850 = !DILocation(line: 620, column: 47, scope: !1842)
!1851 = !DILocation(line: 620, column: 71, scope: !1842)
!1852 = !DILocation(line: 620, column: 79, scope: !1842)
!1853 = !DILocation(line: 620, column: 9, scope: !1842)
!1854 = distinct !{!1854, !1853, !1855, !975}
!1855 = !DILocation(line: 622, column: 9, scope: !1842)
!1856 = !DILocation(line: 621, column: 13, scope: !1857)
!1857 = distinct !DILexicalBlock(scope: !1842, file: !3, line: 620, column: 85)
!1858 = !DILocalVariable(name: "c", arg: 1, scope: !1859, file: !3, line: 139, type: !1514)
!1859 = distinct !DISubprogram(name: "lru_crawler_release_client", scope: !3, file: !3, line: 139, type: !1860, scopeLine: 139, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1862)
!1860 = !DISubroutineType(types: !1861)
!1861 = !{null, !1514}
!1862 = !{!1858}
!1863 = !DILocation(line: 0, scope: !1859, inlinedAt: !1864)
!1864 = distinct !DILocation(line: 625, column: 13, scope: !1865)
!1865 = distinct !DILexicalBlock(scope: !1866, file: !3, line: 624, column: 45)
!1866 = distinct !DILexicalBlock(scope: !1842, file: !3, line: 624, column: 13)
!1867 = !DILocation(line: 141, column: 5, scope: !1859, inlinedAt: !1864)
!1868 = !DILocation(line: 142, column: 10, scope: !1859, inlinedAt: !1864)
!1869 = !DILocation(line: 143, column: 13, scope: !1859, inlinedAt: !1864)
!1870 = !DILocation(line: 143, column: 5, scope: !1859, inlinedAt: !1864)
!1871 = !DILocation(line: 144, column: 12, scope: !1859, inlinedAt: !1864)
!1872 = !DILocation(line: 626, column: 9, scope: !1865)
!1873 = !DILocation(line: 627, column: 32, scope: !1842)
!1874 = !DILocation(line: 628, column: 5, scope: !1842)
!1875 = !DILocation(line: 630, column: 18, scope: !1876)
!1876 = distinct !DILexicalBlock(scope: !1506, file: !3, line: 630, column: 9)
!1877 = !DILocation(line: 630, column: 26, scope: !1876)
!1878 = !DILocation(line: 630, column: 9, scope: !1506)
!1879 = !DILocation(line: 631, column: 17, scope: !1876)
!1880 = !DILocation(line: 631, column: 9, scope: !1876)
!1881 = !DILocation(line: 633, column: 5, scope: !1506)
!1882 = !DILocation(line: 634, column: 37, scope: !1506)
!1883 = !{!1884, !932, i64 51}
!1884 = !{!"stats_state", !967, i64 0, !967, i64 8, !967, i64 16, !967, i64 24, !931, i64 32, !931, i64 36, !931, i64 40, !931, i64 44, !932, i64 48, !932, i64 49, !932, i64 50, !932, i64 51}
!1885 = !DILocation(line: 635, column: 5, scope: !1506)
!1886 = distinct !{!1886, !1533, !1887, !975}
!1887 = !DILocation(line: 636, column: 5, scope: !1497)
!1888 = !DILocation(line: 637, column: 5, scope: !1497)
!1889 = !DILocation(line: 638, column: 18, scope: !1890)
!1890 = distinct !DILexicalBlock(scope: !1497, file: !3, line: 638, column: 9)
!1891 = !DILocation(line: 638, column: 26, scope: !1890)
!1892 = !DILocation(line: 638, column: 9, scope: !1497)
!1893 = !DILocation(line: 639, column: 17, scope: !1890)
!1894 = !DILocation(line: 639, column: 9, scope: !1890)
!1895 = !DILocation(line: 640, column: 26, scope: !1497)
!1896 = !DILocation(line: 642, column: 5, scope: !1497)
!1897 = !DISubprogram(name: "thread_setname", scope: !6, file: !6, line: 1033, type: !1898, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1898 = !DISubroutineType(types: !1899)
!1899 = !{null, !289, !1233}
!1900 = !DISubprogram(name: "pthread_cond_wait", scope: !1375, file: !1375, line: 1133, type: !1901, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1901 = !DISubroutineType(types: !1902)
!1902 = !{!103, !1903, !1904}
!1903 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1383)
!1904 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1378)
!1905 = !DILocation(line: 0, scope: !747)
!1906 = !DILocation(line: 763, column: 5, scope: !747)
!1907 = !DILocation(line: 764, column: 5, scope: !747)
!1908 = !DILocation(line: 765, column: 30, scope: !747)
!1909 = !DILocation(line: 766, column: 5, scope: !747)
!1910 = !DILocation(line: 767, column: 9, scope: !1911)
!1911 = distinct !DILexicalBlock(scope: !747, file: !3, line: 767, column: 9)
!1912 = !DILocation(line: 767, column: 35, scope: !1911)
!1913 = !DILocation(line: 767, column: 9, scope: !747)
!1914 = !DILocation(line: 768, column: 9, scope: !1915)
!1915 = distinct !DILexicalBlock(scope: !1911, file: !3, line: 767, column: 41)
!1916 = !DILocation(line: 769, column: 9, scope: !1915)
!1917 = !DILocation(line: 772, column: 20, scope: !1918)
!1918 = distinct !DILexicalBlock(scope: !747, file: !3, line: 772, column: 9)
!1919 = !DILocation(line: 773, column: 42, scope: !1918)
!1920 = !DILocation(line: 773, column: 45, scope: !1918)
!1921 = !DILocation(line: 773, column: 65, scope: !1918)
!1922 = !DILocation(line: 772, column: 9, scope: !747)
!1923 = !DILocation(line: 774, column: 9, scope: !1924)
!1924 = distinct !DILexicalBlock(scope: !1918, file: !3, line: 773, column: 89)
!1925 = !DILocation(line: 775, column: 26, scope: !1924)
!1926 = !DILocation(line: 775, column: 39, scope: !1924)
!1927 = !DILocation(line: 775, column: 24, scope: !1924)
!1928 = !DILocation(line: 776, column: 9, scope: !1924)
!1929 = !DILocation(line: 779, column: 36, scope: !1930)
!1930 = distinct !DILexicalBlock(scope: !747, file: !3, line: 779, column: 9)
!1931 = !DILocation(line: 779, column: 39, scope: !1930)
!1932 = !DILocation(line: 779, column: 56, scope: !1930)
!1933 = !DILocation(line: 779, column: 54, scope: !1930)
!1934 = !DILocation(line: 779, column: 9, scope: !747)
!1935 = !DILocation(line: 780, column: 9, scope: !1936)
!1936 = distinct !DILexicalBlock(scope: !1930, file: !3, line: 779, column: 70)
!1937 = !DILocation(line: 781, column: 9, scope: !1936)
!1938 = !DILocation(line: 785, column: 13, scope: !1939)
!1939 = distinct !DILexicalBlock(scope: !747, file: !3, line: 785, column: 9)
!1940 = !DILocation(line: 785, column: 21, scope: !1939)
!1941 = !DILocation(line: 786, column: 9, scope: !1942)
!1942 = distinct !DILexicalBlock(scope: !1939, file: !3, line: 785, column: 76)
!1943 = !DILocation(line: 787, column: 9, scope: !1942)
!1944 = !DILocation(line: 791, column: 9, scope: !747)
!1945 = !DILocation(line: 793, column: 34, scope: !1946)
!1946 = distinct !DILexicalBlock(scope: !1947, file: !3, line: 791, column: 22)
!1947 = distinct !DILexicalBlock(scope: !747, file: !3, line: 791, column: 9)
!1948 = !DILocation(line: 793, column: 32, scope: !1946)
!1949 = !DILocation(line: 794, column: 29, scope: !1946)
!1950 = !DILocation(line: 795, column: 37, scope: !1951)
!1951 = distinct !DILexicalBlock(scope: !1946, file: !3, line: 795, column: 13)
!1952 = !{!1589, !950, i64 0}
!1953 = !DILocation(line: 795, column: 42, scope: !1951)
!1954 = !DILocation(line: 795, column: 13, scope: !1946)
!1955 = !DILocation(line: 796, column: 13, scope: !1956)
!1956 = distinct !DILexicalBlock(scope: !1951, file: !3, line: 795, column: 51)
!1957 = !DILocation(line: 798, column: 32, scope: !1958)
!1958 = distinct !DILexicalBlock(scope: !1946, file: !3, line: 798, column: 13)
!1959 = !DILocation(line: 797, column: 9, scope: !1956)
!1960 = !DILocation(line: 798, column: 37, scope: !1958)
!1961 = !DILocation(line: 798, column: 13, scope: !1946)
!1962 = !DILocation(line: 799, column: 19, scope: !1963)
!1963 = distinct !DILexicalBlock(scope: !1964, file: !3, line: 799, column: 17)
!1964 = distinct !DILexicalBlock(scope: !1958, file: !3, line: 798, column: 51)
!1965 = !DILocation(line: 799, column: 27, scope: !1963)
!1966 = !DILocation(line: 800, column: 17, scope: !1967)
!1967 = distinct !DILexicalBlock(scope: !1963, file: !3, line: 799, column: 40)
!1968 = !DILocation(line: 801, column: 17, scope: !1967)
!1969 = !DILocalVariable(name: "cm", arg: 1, scope: !1970, file: !3, line: 738, type: !691)
!1970 = distinct !DISubprogram(name: "lru_crawler_set_client", scope: !3, file: !3, line: 738, type: !1971, scopeLine: 738, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1973)
!1971 = !DISubroutineType(types: !1972)
!1972 = !{!103, !691, !89, !752}
!1973 = !{!1969, !1974, !1975, !1976, !1977}
!1974 = !DILocalVariable(name: "c", arg: 2, scope: !1970, file: !3, line: 738, type: !89)
!1975 = !DILocalVariable(name: "sfd", arg: 3, scope: !1970, file: !3, line: 738, type: !752)
!1976 = !DILocalVariable(name: "crawlc", scope: !1970, file: !3, line: 739, type: !1514)
!1977 = !DILocalVariable(name: "size", scope: !1970, file: !3, line: 746, type: !430)
!1978 = !DILocation(line: 0, scope: !1970, inlinedAt: !1979)
!1979 = distinct !DILocation(line: 803, column: 17, scope: !1980)
!1980 = distinct !DILexicalBlock(scope: !1964, file: !3, line: 803, column: 17)
!1981 = !DILocation(line: 740, column: 17, scope: !1982, inlinedAt: !1979)
!1982 = distinct !DILexicalBlock(scope: !1970, file: !3, line: 740, column: 9)
!1983 = !DILocation(line: 740, column: 19, scope: !1982, inlinedAt: !1979)
!1984 = !DILocation(line: 740, column: 9, scope: !1970, inlinedAt: !1979)
!1985 = !DILocation(line: 743, column: 15, scope: !1970, inlinedAt: !1979)
!1986 = !DILocation(line: 744, column: 17, scope: !1970, inlinedAt: !1979)
!1987 = !{!951, !931, i64 8}
!1988 = !DILocation(line: 747, column: 19, scope: !1970, inlinedAt: !1979)
!1989 = !DILocation(line: 747, column: 17, scope: !1970, inlinedAt: !1979)
!1990 = !DILocation(line: 749, column: 21, scope: !1991, inlinedAt: !1979)
!1991 = distinct !DILexicalBlock(scope: !1970, file: !3, line: 749, column: 9)
!1992 = !DILocation(line: 749, column: 9, scope: !1970, inlinedAt: !1979)
!1993 = !DILocation(line: 752, column: 20, scope: !1970, inlinedAt: !1979)
!1994 = !DILocation(line: 753, column: 21, scope: !1970, inlinedAt: !1979)
!1995 = !DILocation(line: 810, column: 9, scope: !747)
!1996 = !DILocation(line: 0, scope: !763)
!1997 = !DILocation(line: 819, column: 9, scope: !763)
!1998 = !DILocation(line: 804, column: 17, scope: !1999)
!1999 = distinct !DILexicalBlock(scope: !1980, file: !3, line: 803, column: 75)
!2000 = !DILocation(line: 805, column: 17, scope: !1999)
!2001 = !DILocation(line: 816, column: 23, scope: !2002)
!2002 = distinct !DILexicalBlock(scope: !765, file: !3, line: 810, column: 22)
!2003 = !DILocation(line: 824, column: 9, scope: !747)
!2004 = !DILocation(line: 820, column: 17, scope: !2005)
!2005 = distinct !DILexicalBlock(scope: !2006, file: !3, line: 820, column: 17)
!2006 = distinct !DILexicalBlock(scope: !2007, file: !3, line: 819, column: 68)
!2007 = distinct !DILexicalBlock(scope: !763, file: !3, line: 819, column: 9)
!2008 = !DILocation(line: 820, column: 17, scope: !2006)
!2009 = !DILocalVariable(name: "id", arg: 1, scope: !2010, file: !3, line: 700, type: !158)
!2010 = distinct !DISubprogram(name: "do_lru_crawler_start", scope: !3, file: !3, line: 700, type: !2011, scopeLine: 700, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2013)
!2011 = !DISubroutineType(types: !2012)
!2012 = !{!103, !158, !158}
!2013 = !{!2009, !2014, !2015, !2016}
!2014 = !DILocalVariable(name: "remaining", arg: 2, scope: !2010, file: !3, line: 700, type: !158)
!2015 = !DILocalVariable(name: "sid", scope: !2010, file: !3, line: 701, type: !158)
!2016 = !DILocalVariable(name: "starts", scope: !2010, file: !3, line: 702, type: !103)
!2017 = !DILocation(line: 0, scope: !2010, inlinedAt: !2018)
!2018 = distinct !DILocation(line: 821, column: 27, scope: !2005)
!2019 = !DILocation(line: 704, column: 25, scope: !2010, inlinedAt: !2018)
!2020 = !DILocation(line: 704, column: 5, scope: !2010, inlinedAt: !2018)
!2021 = !DILocation(line: 705, column: 9, scope: !2022, inlinedAt: !2018)
!2022 = distinct !DILexicalBlock(scope: !2010, file: !3, line: 705, column: 9)
!2023 = !DILocation(line: 705, column: 23, scope: !2022, inlinedAt: !2018)
!2024 = !DILocation(line: 705, column: 32, scope: !2022, inlinedAt: !2018)
!2025 = !DILocation(line: 705, column: 9, scope: !2010, inlinedAt: !2018)
!2026 = !DILocation(line: 706, column: 22, scope: !2027, inlinedAt: !2018)
!2027 = distinct !DILexicalBlock(scope: !2028, file: !3, line: 706, column: 13)
!2028 = distinct !DILexicalBlock(scope: !2022, file: !3, line: 705, column: 38)
!2029 = !DILocation(line: 706, column: 30, scope: !2027, inlinedAt: !2018)
!2030 = !DILocation(line: 706, column: 13, scope: !2028, inlinedAt: !2018)
!2031 = !DILocation(line: 707, column: 21, scope: !2027, inlinedAt: !2018)
!2032 = !DILocation(line: 707, column: 13, scope: !2027, inlinedAt: !2018)
!2033 = !DILocation(line: 708, column: 23, scope: !2028, inlinedAt: !2018)
!2034 = !DILocation(line: 708, column: 30, scope: !2028, inlinedAt: !2018)
!2035 = !{!1029, !931, i64 32}
!2036 = !DILocation(line: 709, column: 23, scope: !2028, inlinedAt: !2018)
!2037 = !DILocation(line: 709, column: 28, scope: !2028, inlinedAt: !2018)
!2038 = !{!1029, !929, i64 41}
!2039 = !DILocation(line: 710, column: 32, scope: !2028, inlinedAt: !2018)
!2040 = !DILocation(line: 713, column: 23, scope: !2028, inlinedAt: !2018)
!2041 = !DILocation(line: 713, column: 28, scope: !2028, inlinedAt: !2018)
!2042 = !{!1029, !931, i64 24}
!2043 = !DILocation(line: 712, column: 28, scope: !2028, inlinedAt: !2018)
!2044 = !DILocation(line: 714, column: 13, scope: !2028, inlinedAt: !2018)
!2045 = !DILocation(line: 0, scope: !2028, inlinedAt: !2018)
!2046 = !DILocation(line: 715, column: 25, scope: !2047, inlinedAt: !2018)
!2047 = distinct !DILexicalBlock(scope: !2048, file: !3, line: 714, column: 53)
!2048 = distinct !DILexicalBlock(scope: !2028, file: !3, line: 714, column: 13)
!2049 = !DILocation(line: 716, column: 9, scope: !2047, inlinedAt: !2018)
!2050 = !DILocation(line: 724, column: 13, scope: !2051, inlinedAt: !2018)
!2051 = distinct !DILexicalBlock(scope: !2028, file: !3, line: 724, column: 13)
!2052 = !DILocation(line: 724, column: 13, scope: !2028, inlinedAt: !2018)
!2053 = !DILocation(line: 725, column: 23, scope: !2028, inlinedAt: !2018)
!2054 = !DILocation(line: 725, column: 33, scope: !2028, inlinedAt: !2018)
!2055 = !DILocation(line: 726, column: 37, scope: !2028, inlinedAt: !2018)
!2056 = !DILocation(line: 726, column: 23, scope: !2028, inlinedAt: !2018)
!2057 = !DILocation(line: 726, column: 35, scope: !2028, inlinedAt: !2018)
!2058 = !{!1029, !929, i64 40}
!2059 = !DILocation(line: 727, column: 23, scope: !2028, inlinedAt: !2018)
!2060 = !DILocation(line: 728, column: 33, scope: !2028, inlinedAt: !2018)
!2061 = !DILocation(line: 730, column: 9, scope: !2028, inlinedAt: !2018)
!2062 = !DILocation(line: 731, column: 22, scope: !2028, inlinedAt: !2018)
!2063 = !DILocation(line: 733, column: 5, scope: !2028, inlinedAt: !2018)
!2064 = !DILocation(line: 734, column: 5, scope: !2010, inlinedAt: !2018)
!2065 = !DILocation(line: 821, column: 24, scope: !2005)
!2066 = !DILocation(line: 821, column: 17, scope: !2005)
!2067 = !DILocation(line: 819, column: 64, scope: !2007)
!2068 = !DILocation(line: 819, column: 44, scope: !2007)
!2069 = distinct !{!2069, !1997, !2070, !975}
!2070 = !DILocation(line: 822, column: 9, scope: !763)
!2071 = !DILocation(line: 824, column: 9, scope: !2072)
!2072 = distinct !DILexicalBlock(scope: !747, file: !3, line: 824, column: 9)
!2073 = !DILocation(line: 825, column: 9, scope: !2074)
!2074 = distinct !DILexicalBlock(scope: !2072, file: !3, line: 824, column: 17)
!2075 = !DILocation(line: 826, column: 41, scope: !2074)
!2076 = !DILocation(line: 827, column: 33, scope: !2074)
!2077 = !{!2078, !967, i64 96}
!2078 = !{!"stats", !967, i64 0, !967, i64 8, !967, i64 16, !967, i64 24, !967, i64 32, !967, i64 40, !967, i64 48, !967, i64 56, !967, i64 64, !967, i64 72, !967, i64 80, !967, i64 88, !967, i64 96, !967, i64 104, !967, i64 112, !967, i64 120, !967, i64 128, !967, i64 136, !967, i64 144, !967, i64 152, !967, i64 160, !967, i64 168, !967, i64 176, !967, i64 184, !2079, i64 192, !967, i64 208, !967, i64 216}
!2079 = !{!"timeval", !967, i64 0, !967, i64 8}
!2080 = !DILocation(line: 828, column: 9, scope: !2074)
!2081 = !DILocation(line: 829, column: 9, scope: !2074)
!2082 = !DILocation(line: 830, column: 5, scope: !2074)
!2083 = !DILocation(line: 831, column: 5, scope: !747)
!2084 = !DILocation(line: 832, column: 5, scope: !747)
!2085 = !DILocation(line: 833, column: 1, scope: !747)
!2086 = !DISubprogram(name: "STATS_LOCK", scope: !6, file: !6, line: 1026, type: !1539, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2087 = !DISubprogram(name: "STATS_UNLOCK", scope: !6, file: !6, line: 1027, type: !1539, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2088 = distinct !DISubprogram(name: "lru_crawler_crawl", scope: !3, file: !3, line: 838, type: !2089, scopeLine: 839, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2091)
!2089 = !DISubroutineType(types: !2090)
!2090 = !{!13, !155, !751, !89, !752, !7}
!2091 = !{!2092, !2093, !2094, !2095, !2096, !2097, !2098, !2099, !2100, !2102, !2103}
!2092 = !DILocalVariable(name: "slabs", arg: 1, scope: !2088, file: !3, line: 838, type: !155)
!2093 = !DILocalVariable(name: "type", arg: 2, scope: !2088, file: !3, line: 838, type: !751)
!2094 = !DILocalVariable(name: "c", arg: 3, scope: !2088, file: !3, line: 839, type: !89)
!2095 = !DILocalVariable(name: "sfd", arg: 4, scope: !2088, file: !3, line: 839, type: !752)
!2096 = !DILocalVariable(name: "remaining", arg: 5, scope: !2088, file: !3, line: 839, type: !7)
!2097 = !DILocalVariable(name: "b", scope: !2088, file: !3, line: 840, type: !155)
!2098 = !DILocalVariable(name: "sid", scope: !2088, file: !3, line: 841, type: !158)
!2099 = !DILocalVariable(name: "starts", scope: !2088, file: !3, line: 842, type: !103)
!2100 = !DILocalVariable(name: "tocrawl", scope: !2088, file: !3, line: 843, type: !2101)
!2101 = !DICompositeType(tag: DW_TAG_array_type, baseType: !196, size: 2048, elements: !149)
!2102 = !DILocalVariable(name: "hash_crawl", scope: !2088, file: !3, line: 844, type: !148)
!2103 = !DILocalVariable(name: "p", scope: !2104, file: !3, line: 855, type: !155)
!2104 = distinct !DILexicalBlock(scope: !2105, file: !3, line: 855, column: 9)
!2105 = distinct !DILexicalBlock(scope: !2106, file: !3, line: 854, column: 12)
!2106 = distinct !DILexicalBlock(scope: !2107, file: !3, line: 852, column: 16)
!2107 = distinct !DILexicalBlock(scope: !2088, file: !3, line: 848, column: 9)
!2108 = distinct !DIAssignID()
!2109 = !DILocation(line: 0, scope: !2088)
!2110 = distinct !DIAssignID()
!2111 = distinct !DIAssignID()
!2112 = !DILocation(line: 840, column: 5, scope: !2088)
!2113 = !DILocation(line: 840, column: 11, scope: !2088)
!2114 = distinct !DIAssignID()
!2115 = !DILocation(line: 841, column: 5, scope: !2088)
!2116 = !DILocation(line: 841, column: 14, scope: !2088)
!2117 = distinct !DIAssignID()
!2118 = !DILocation(line: 843, column: 5, scope: !2088)
!2119 = !DILocation(line: 847, column: 5, scope: !2088)
!2120 = distinct !DIAssignID()
!2121 = !DILocation(line: 848, column: 9, scope: !2107)
!2122 = !DILocation(line: 848, column: 30, scope: !2107)
!2123 = !DILocation(line: 848, column: 9, scope: !2088)
!2124 = !DILocation(line: 850, column: 26, scope: !2125)
!2125 = distinct !DILexicalBlock(scope: !2126, file: !3, line: 849, column: 51)
!2126 = distinct !DILexicalBlock(scope: !2127, file: !3, line: 849, column: 9)
!2127 = distinct !DILexicalBlock(scope: !2128, file: !3, line: 849, column: 9)
!2128 = distinct !DILexicalBlock(scope: !2107, file: !3, line: 848, column: 36)
!2129 = distinct !DIAssignID()
!2130 = !DILocation(line: 849, scope: !2127)
!2131 = !DILocation(line: 870, column: 14, scope: !2088)
!2132 = !DILocation(line: 852, column: 16, scope: !2106)
!2133 = !DILocation(line: 852, column: 38, scope: !2106)
!2134 = !DILocation(line: 852, column: 16, scope: !2107)
!2135 = !DILocation(line: 855, column: 24, scope: !2104)
!2136 = !DILocation(line: 0, scope: !2104)
!2137 = !DILocation(line: 856, column: 16, scope: !2138)
!2138 = distinct !DILexicalBlock(scope: !2104, file: !3, line: 855, column: 9)
!2139 = !DILocation(line: 855, column: 9, scope: !2104)
!2140 = !DILocation(line: 859, column: 18, scope: !2141)
!2141 = distinct !DILexicalBlock(scope: !2142, file: !3, line: 859, column: 17)
!2142 = distinct !DILexicalBlock(scope: !2138, file: !3, line: 857, column: 43)
!2143 = !DILocation(line: 859, column: 40, scope: !2141)
!2144 = !DILocation(line: 859, column: 43, scope: !2141)
!2145 = !DILocation(line: 860, column: 21, scope: !2141)
!2146 = !DILocation(line: 863, column: 25, scope: !2142)
!2147 = !DILocation(line: 863, column: 13, scope: !2142)
!2148 = !DILocation(line: 863, column: 37, scope: !2142)
!2149 = !DILocation(line: 864, column: 13, scope: !2142)
!2150 = !DILocation(line: 864, column: 36, scope: !2142)
!2151 = !DILocation(line: 865, column: 25, scope: !2142)
!2152 = !DILocation(line: 865, column: 13, scope: !2142)
!2153 = !DILocation(line: 865, column: 37, scope: !2142)
!2154 = !DILocation(line: 866, column: 25, scope: !2142)
!2155 = !DILocation(line: 866, column: 13, scope: !2142)
!2156 = !DILocation(line: 866, column: 37, scope: !2142)
!2157 = !DILocation(line: 857, column: 18, scope: !2138)
!2158 = distinct !{!2158, !2139, !2159, !975}
!2159 = !DILocation(line: 867, column: 9, scope: !2104)
!2160 = !DILocation(line: 871, column: 9, scope: !2088)
!2161 = !DILocation(line: 880, column: 1, scope: !2088)
!2162 = !DISubprogram(name: "strcmp", scope: !1448, file: !1448, line: 156, type: !2163, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2163 = !DISubroutineType(types: !2164)
!2164 = !{!103, !1233, !1233}
!2165 = !DISubprogram(name: "strtok_r", scope: !1448, file: !1448, line: 366, type: !2166, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2166 = !DISubroutineType(types: !2167)
!2167 = !{!155, !2168, !1446, !2169}
!2168 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !155)
!2169 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !2170)
!2170 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !155, size: 64)
!2171 = !DISubprogram(name: "safe_strtoul", scope: !2172, file: !2172, line: 19, type: !2173, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2172 = !DIFile(filename: "./util.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d1ef68c688867746f50aae7567be079a")
!2173 = !DISubroutineType(types: !2174)
!2174 = !{!148, !1233, !2175}
!2175 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !158, size: 64)
!2176 = distinct !DISubprogram(name: "lru_crawler_pause", scope: !3, file: !3, line: 883, type: !1539, scopeLine: 883, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!2177 = !DILocation(line: 884, column: 5, scope: !2176)
!2178 = !DILocation(line: 885, column: 1, scope: !2176)
!2179 = distinct !DISubprogram(name: "lru_crawler_resume", scope: !3, file: !3, line: 887, type: !1539, scopeLine: 887, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!2180 = !DILocation(line: 888, column: 5, scope: !2179)
!2181 = !DILocation(line: 889, column: 1, scope: !2179)
!2182 = distinct !DISubprogram(name: "init_lru_crawler", scope: !3, file: !3, line: 891, type: !2183, scopeLine: 891, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2185)
!2183 = !DISubroutineType(types: !2184)
!2184 = !{!103, !89}
!2185 = !{!2186}
!2186 = !DILocalVariable(name: "arg", arg: 1, scope: !2182, file: !3, line: 891, type: !89)
!2187 = !DILocation(line: 0, scope: !2182)
!2188 = !DILocation(line: 892, column: 9, scope: !2189)
!2189 = distinct !DILexicalBlock(scope: !2182, file: !3, line: 892, column: 9)
!2190 = !DILocation(line: 892, column: 9, scope: !2182)
!2191 = !DILocation(line: 894, column: 17, scope: !2192)
!2192 = distinct !DILexicalBlock(scope: !2189, file: !3, line: 892, column: 39)
!2193 = !DILocation(line: 897, column: 32, scope: !2192)
!2194 = !DILocation(line: 898, column: 33, scope: !2192)
!2195 = !DILocation(line: 899, column: 33, scope: !2192)
!2196 = !DILocation(line: 900, column: 5, scope: !2192)
!2197 = !DILocation(line: 901, column: 5, scope: !2182)
!2198 = !DISubprogram(name: "calloc", scope: !2199, file: !2199, line: 675, type: !2200, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2199 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!2200 = !DISubroutineType(types: !2201)
!2201 = !{!89, !430, !430}
!2202 = !DISubprogram(name: "pthread_mutex_init", scope: !1375, file: !1375, line: 781, type: !2203, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2203 = !DISubroutineType(types: !2204)
!2204 = !{!103, !1378, !2205}
!2205 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2206, size: 64)
!2206 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !2207)
!2207 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutexattr_t", file: !95, line: 36, baseType: !2208)
!2208 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !95, line: 32, size: 32, elements: !2209)
!2209 = !{!2210, !2211}
!2210 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !2208, file: !95, line: 34, baseType: !768, size: 32)
!2211 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !2208, file: !95, line: 35, baseType: !103, size: 32)
!2212 = !DISubprogram(name: "free", scope: !2199, file: !2199, line: 687, type: !2213, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2213 = !DISubroutineType(types: !2214)
!2214 = !{null, !89}
!2215 = !DISubprogram(name: "item_is_flushed", scope: !2216, file: !2216, line: 29, type: !2217, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2216 = !DIFile(filename: "./items.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "5548db7354621bc680fd5812e10230ba")
!2217 = !DISubroutineType(types: !2218)
!2218 = !{!103, !529}
!2219 = !DISubprogram(name: "storage_validate_item", scope: !2220, file: !2220, line: 17, type: !2221, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2220 = !DIFile(filename: "./storage.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d18dbd8a1337d7561522237d8930ae7f")
!2221 = !DISubroutineType(types: !2222)
!2222 = !{!148, !89, !529}
!2223 = !DISubprogram(name: "storage_delete", scope: !2220, file: !2220, line: 4, type: !2224, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2224 = !DISubroutineType(types: !2225)
!2225 = !{null, !89, !529}
!2226 = !DISubprogram(name: "do_item_unlink_nolock", scope: !2216, file: !2216, line: 22, type: !2227, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2227 = !DISubroutineType(types: !2228)
!2228 = !{null, !529, !2229}
!2229 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !158)
!2230 = !DISubprogram(name: "do_item_remove", scope: !2216, file: !2216, line: 23, type: !2231, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2231 = !DISubroutineType(types: !2232)
!2232 = !{null, !529}
!2233 = !DISubprogram(name: "uriencode", scope: !2172, file: !2172, line: 5, type: !2234, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2234 = !DISubroutineType(types: !2235)
!2235 = !{!148, !1233, !155, !2236, !2236}
!2236 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !430)
!2237 = !DISubprogram(name: "snprintf", scope: !1389, file: !1389, line: 385, type: !2238, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2238 = !DISubroutineType(types: !2239)
!2239 = !{!103, !2168, !430, !1446, null}
!2240 = distinct !DISubprogram(name: "lru_crawler_write", scope: !3, file: !3, line: 374, type: !1633, scopeLine: 374, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2241)
!2241 = !{!2242, !2243, !2244, !2245, !2253, !2255, !2258, !2259}
!2242 = !DILocalVariable(name: "c", arg: 1, scope: !2240, file: !3, line: 374, type: !1514)
!2243 = !DILocalVariable(name: "data_size", scope: !2240, file: !3, line: 375, type: !7)
!2244 = !DILocalVariable(name: "sent", scope: !2240, file: !3, line: 376, type: !7)
!2245 = !DILocalVariable(name: "to_poll", scope: !2240, file: !3, line: 377, type: !2246)
!2246 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2247, size: 64, elements: !1425)
!2247 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "pollfd", file: !2248, line: 36, size: 64, elements: !2249)
!2248 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/poll.h", directory: "", checksumkind: CSK_MD5, checksum: "1a4eb88ffdcfba173b0f25ae540bbd7b")
!2249 = !{!2250, !2251, !2252}
!2250 = !DIDerivedType(tag: DW_TAG_member, name: "fd", scope: !2247, file: !2248, line: 38, baseType: !103, size: 32)
!2251 = !DIDerivedType(tag: DW_TAG_member, name: "events", scope: !2247, file: !2248, line: 39, baseType: !109, size: 16, offset: 32)
!2252 = !DIDerivedType(tag: DW_TAG_member, name: "revents", scope: !2247, file: !2248, line: 40, baseType: !109, size: 16, offset: 48)
!2253 = !DILocalVariable(name: "ret", scope: !2254, file: !3, line: 385, type: !103)
!2254 = distinct !DILexicalBlock(scope: !2240, file: !3, line: 384, column: 30)
!2255 = !DILocalVariable(name: "buf", scope: !2256, file: !3, line: 397, type: !1424)
!2256 = distinct !DILexicalBlock(scope: !2257, file: !3, line: 396, column: 42)
!2257 = distinct !DILexicalBlock(scope: !2254, file: !3, line: 396, column: 13)
!2258 = !DILocalVariable(name: "res", scope: !2256, file: !3, line: 398, type: !103)
!2259 = !DILocalVariable(name: "total", scope: !2260, file: !3, line: 411, type: !103)
!2260 = distinct !DILexicalBlock(scope: !2261, file: !3, line: 409, column: 50)
!2261 = distinct !DILexicalBlock(scope: !2262, file: !3, line: 409, column: 20)
!2262 = distinct !DILexicalBlock(scope: !2254, file: !3, line: 405, column: 13)
!2263 = distinct !DIAssignID()
!2264 = !DILocation(line: 0, scope: !2240)
!2265 = distinct !DIAssignID()
!2266 = !DILocation(line: 0, scope: !2256)
!2267 = !DILocation(line: 375, column: 33, scope: !2240)
!2268 = !DILocation(line: 377, column: 5, scope: !2240)
!2269 = !DILocation(line: 378, column: 24, scope: !2240)
!2270 = !DILocation(line: 378, column: 19, scope: !2240)
!2271 = !{!2272, !931, i64 0}
!2272 = !{!"pollfd", !931, i64 0, !1009, i64 4, !1009, i64 6}
!2273 = distinct !DIAssignID()
!2274 = !DILocation(line: 379, column: 16, scope: !2240)
!2275 = !DILocation(line: 379, column: 23, scope: !2240)
!2276 = !{!2272, !1009, i64 4}
!2277 = distinct !DIAssignID()
!2278 = !DILocation(line: 381, column: 12, scope: !2279)
!2279 = distinct !DILexicalBlock(scope: !2240, file: !3, line: 381, column: 9)
!2280 = !DILocation(line: 381, column: 14, scope: !2279)
!2281 = !DILocation(line: 381, column: 9, scope: !2240)
!2282 = !DILocation(line: 382, column: 19, scope: !2283)
!2283 = distinct !DILexicalBlock(scope: !2240, file: !3, line: 382, column: 9)
!2284 = !DILocation(line: 382, column: 9, scope: !2240)
!2285 = !DILocation(line: 384, column: 5, scope: !2240)
!2286 = !DILocation(line: 385, column: 19, scope: !2254)
!2287 = !DILocation(line: 0, scope: !2254)
!2288 = !DILocation(line: 387, column: 17, scope: !2289)
!2289 = distinct !DILexicalBlock(scope: !2254, file: !3, line: 387, column: 13)
!2290 = !DILocation(line: 387, column: 13, scope: !2254)
!2291 = !DILocalVariable(name: "c", arg: 1, scope: !2292, file: !3, line: 131, type: !1514)
!2292 = distinct !DISubprogram(name: "lru_crawler_close_client", scope: !3, file: !3, line: 131, type: !1860, scopeLine: 131, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2293)
!2293 = !{!2291}
!2294 = !DILocation(line: 0, scope: !2292, inlinedAt: !2295)
!2295 = distinct !DILocation(line: 389, column: 13, scope: !2296)
!2296 = distinct !DILexicalBlock(scope: !2289, file: !3, line: 387, column: 22)
!2297 = !DILocation(line: 133, column: 30, scope: !2292, inlinedAt: !2295)
!2298 = !DILocation(line: 133, column: 5, scope: !2292, inlinedAt: !2295)
!2299 = !DILocation(line: 134, column: 10, scope: !2292, inlinedAt: !2295)
!2300 = !DILocation(line: 135, column: 13, scope: !2292, inlinedAt: !2295)
!2301 = !DILocation(line: 135, column: 5, scope: !2292, inlinedAt: !2295)
!2302 = !DILocation(line: 136, column: 12, scope: !2292, inlinedAt: !2295)
!2303 = !DILocation(line: 390, column: 13, scope: !2296)
!2304 = !DILocation(line: 393, column: 17, scope: !2305)
!2305 = distinct !DILexicalBlock(scope: !2254, file: !3, line: 393, column: 13)
!2306 = !DILocation(line: 393, column: 13, scope: !2254)
!2307 = !DILocation(line: 396, column: 24, scope: !2257)
!2308 = !{!2272, !1009, i64 6}
!2309 = !DILocation(line: 396, column: 32, scope: !2257)
!2310 = !DILocation(line: 396, column: 13, scope: !2254)
!2311 = !DILocation(line: 397, column: 13, scope: !2256)
!2312 = !DILocation(line: 398, column: 34, scope: !2256)
!2313 = !DILocation(line: 398, column: 38, scope: !2256)
!2314 = !{!2315, !950, i64 472}
!2315 = !{!"conn", !950, i64 0, !931, i64 8, !932, i64 12, !932, i64 13, !932, i64 14, !932, i64 15, !932, i64 16, !932, i64 17, !932, i64 18, !931, i64 20, !931, i64 24, !931, i64 28, !2316, i64 32, !1009, i64 160, !1009, i64 162, !950, i64 168, !950, i64 176, !931, i64 184, !931, i64 188, !950, i64 192, !950, i64 200, !950, i64 208, !931, i64 216, !950, i64 224, !931, i64 232, !931, i64 236, !929, i64 240, !931, i64 312, !931, i64 316, !931, i64 320, !931, i64 324, !931, i64 328, !2319, i64 332, !931, i64 360, !932, i64 364, !2321, i64 368, !929, i64 392, !967, i64 416, !967, i64 424, !1009, i64 432, !931, i64 436, !931, i64 440, !950, i64 448, !950, i64 456, !950, i64 464, !950, i64 472, !950, i64 480, !950, i64 488}
!2316 = !{!"event", !2317, i64 0, !929, i64 40, !931, i64 56, !950, i64 64, !929, i64 72, !1009, i64 104, !1009, i64 106, !2079, i64 112}
!2317 = !{!"event_callback", !2318, i64 0, !1009, i64 16, !929, i64 18, !929, i64 19, !929, i64 24, !950, i64 32}
!2318 = !{!"", !950, i64 0, !950, i64 8}
!2319 = !{!"sockaddr_in6", !1009, i64 0, !1009, i64 2, !931, i64 4, !2320, i64 8, !931, i64 24}
!2320 = !{!"in6_addr", !929, i64 0}
!2321 = !{!"", !950, i64 0, !967, i64 8, !967, i64 16}
!2322 = !DILocation(line: 398, column: 23, scope: !2256)
!2323 = !DILocation(line: 399, column: 26, scope: !2324)
!2324 = distinct !DILexicalBlock(scope: !2256, file: !3, line: 399, column: 17)
!2325 = !DILocation(line: 399, column: 44, scope: !2324)
!2326 = !DILocation(line: 399, column: 50, scope: !2324)
!2327 = !DILocation(line: 399, column: 60, scope: !2324)
!2328 = !DILocation(line: 403, column: 9, scope: !2257)
!2329 = !DILocation(line: 405, column: 24, scope: !2262)
!2330 = !DILocation(line: 0, scope: !2292, inlinedAt: !2331)
!2331 = distinct !DILocation(line: 400, column: 17, scope: !2332)
!2332 = distinct !DILexicalBlock(scope: !2324, file: !3, line: 399, column: 87)
!2333 = !DILocation(line: 133, column: 30, scope: !2292, inlinedAt: !2331)
!2334 = !DILocation(line: 133, column: 5, scope: !2292, inlinedAt: !2331)
!2335 = !DILocation(line: 134, column: 10, scope: !2292, inlinedAt: !2331)
!2336 = !DILocation(line: 135, column: 13, scope: !2292, inlinedAt: !2331)
!2337 = !DILocation(line: 135, column: 5, scope: !2292, inlinedAt: !2331)
!2338 = !DILocation(line: 136, column: 12, scope: !2292, inlinedAt: !2331)
!2339 = !DILocation(line: 405, column: 13, scope: !2262)
!2340 = !DILocation(line: 405, column: 32, scope: !2262)
!2341 = !DILocation(line: 405, column: 13, scope: !2254)
!2342 = !DILocation(line: 0, scope: !2292, inlinedAt: !2343)
!2343 = distinct !DILocation(line: 407, column: 13, scope: !2344)
!2344 = distinct !DILexicalBlock(scope: !2262, file: !3, line: 405, column: 53)
!2345 = !DILocation(line: 133, column: 30, scope: !2292, inlinedAt: !2343)
!2346 = !DILocation(line: 133, column: 5, scope: !2292, inlinedAt: !2343)
!2347 = !DILocation(line: 134, column: 10, scope: !2292, inlinedAt: !2343)
!2348 = !DILocation(line: 135, column: 13, scope: !2292, inlinedAt: !2343)
!2349 = !DILocation(line: 135, column: 5, scope: !2292, inlinedAt: !2343)
!2350 = !DILocation(line: 136, column: 12, scope: !2292, inlinedAt: !2343)
!2351 = !DILocation(line: 408, column: 13, scope: !2344)
!2352 = !DILocation(line: 409, column: 39, scope: !2261)
!2353 = !DILocation(line: 409, column: 20, scope: !2262)
!2354 = !DILocation(line: 411, column: 36, scope: !2260)
!2355 = !DILocation(line: 411, column: 40, scope: !2260)
!2356 = !{!2315, !950, i64 488}
!2357 = !DILocation(line: 411, column: 55, scope: !2260)
!2358 = !DILocation(line: 411, column: 59, scope: !2260)
!2359 = !DILocation(line: 411, column: 77, scope: !2260)
!2360 = !DILocation(line: 411, column: 67, scope: !2260)
!2361 = !DILocation(line: 411, column: 25, scope: !2260)
!2362 = !DILocation(line: 0, scope: !2260)
!2363 = !DILocation(line: 412, column: 17, scope: !2260)
!2364 = !DILocation(line: 413, column: 21, scope: !2365)
!2365 = distinct !DILexicalBlock(scope: !2366, file: !3, line: 413, column: 21)
!2366 = distinct !DILexicalBlock(scope: !2367, file: !3, line: 412, column: 30)
!2367 = distinct !DILexicalBlock(scope: !2260, file: !3, line: 412, column: 17)
!2368 = !DILocation(line: 413, column: 27, scope: !2365)
!2369 = !DILocation(line: 413, column: 37, scope: !2365)
!2370 = !DILocation(line: 0, scope: !2292, inlinedAt: !2371)
!2371 = distinct !DILocation(line: 414, column: 21, scope: !2372)
!2372 = distinct !DILexicalBlock(scope: !2365, file: !3, line: 413, column: 62)
!2373 = !DILocation(line: 133, column: 30, scope: !2292, inlinedAt: !2371)
!2374 = !DILocation(line: 133, column: 5, scope: !2292, inlinedAt: !2371)
!2375 = !DILocation(line: 134, column: 10, scope: !2292, inlinedAt: !2371)
!2376 = !DILocation(line: 135, column: 13, scope: !2292, inlinedAt: !2371)
!2377 = !DILocation(line: 135, column: 5, scope: !2292, inlinedAt: !2371)
!2378 = !DILocation(line: 136, column: 12, scope: !2292, inlinedAt: !2371)
!2379 = !DILocation(line: 415, column: 21, scope: !2372)
!2380 = !DILocation(line: 0, scope: !2292, inlinedAt: !2381)
!2381 = distinct !DILocation(line: 418, column: 17, scope: !2382)
!2382 = distinct !DILexicalBlock(scope: !2383, file: !3, line: 417, column: 36)
!2383 = distinct !DILexicalBlock(scope: !2367, file: !3, line: 417, column: 24)
!2384 = !DILocation(line: 133, column: 30, scope: !2292, inlinedAt: !2381)
!2385 = !DILocation(line: 133, column: 5, scope: !2292, inlinedAt: !2381)
!2386 = !DILocation(line: 134, column: 10, scope: !2292, inlinedAt: !2381)
!2387 = !DILocation(line: 135, column: 13, scope: !2292, inlinedAt: !2381)
!2388 = !DILocation(line: 135, column: 5, scope: !2292, inlinedAt: !2381)
!2389 = !DILocation(line: 136, column: 12, scope: !2292, inlinedAt: !2381)
!2390 = !DILocation(line: 419, column: 17, scope: !2382)
!2391 = !DILocation(line: 421, column: 18, scope: !2260)
!2392 = !DILocation(line: 422, column: 9, scope: !2261)
!2393 = !DILocation(line: 376, column: 18, scope: !2240)
!2394 = !DILocation(line: 384, column: 17, scope: !2240)
!2395 = distinct !{!2395, !2285, !2396, !975}
!2396 = !DILocation(line: 423, column: 5, scope: !2240)
!2397 = !DILocation(line: 426, column: 16, scope: !2240)
!2398 = !DILocation(line: 428, column: 5, scope: !2240)
!2399 = !DILocation(line: 429, column: 1, scope: !2240)
!2400 = !DISubprogram(name: "poll", scope: !2248, file: !2248, line: 54, type: !2401, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2401 = !DISubroutineType(types: !2402)
!2402 = !{!103, !2403, !2404, !103}
!2403 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2247, size: 64)
!2404 = !DIDerivedType(tag: DW_TAG_typedef, name: "nfds_t", file: !2248, line: 33, baseType: !137)
!2405 = !DISubprogram(name: "__errno_location", scope: !2406, file: !2406, line: 37, type: !2407, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2406 = !DIFile(filename: "/usr/include/errno.h", directory: "", checksumkind: CSK_MD5, checksum: "047d5cf117ed2ec1460c1b2e072a4e50")
!2407 = !DISubroutineType(types: !2408)
!2408 = !{!2409}
!2409 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !103, size: 64)
!2410 = !DISubprogram(name: "sidethread_conn_close", scope: !6, file: !6, line: 996, type: !2411, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2411 = !DISubroutineType(types: !2412)
!2412 = !{null, !161}
!2413 = !DISubprogram(name: "base64_encode", scope: !2414, file: !2414, line: 12, type: !2415, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2414 = !DIFile(filename: "./base64.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "df9eb6d1c290d1a122f3ee1ae425ece4")
!2415 = !DISubroutineType(types: !2416)
!2416 = !{!430, !2417, !430, !679, !430}
!2417 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2418, size: 64)
!2418 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !198)
!2419 = !DISubprogram(name: "do_item_crawl_q", scope: !2216, file: !2216, line: 34, type: !2420, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2420 = !DISubroutineType(types: !2421)
!2421 = !{!529, !529}
!2422 = !DISubprogram(name: "item_trylock", scope: !6, file: !6, line: 1018, type: !2423, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2423 = !DISubroutineType(types: !2424)
!2424 = !{!89, !158}
!2425 = !DISubprogram(name: "item_trylock_unlock", scope: !6, file: !6, line: 1019, type: !2213, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2426 = !DISubprogram(name: "usleep", scope: !2427, file: !2427, line: 480, type: !2428, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2427 = !DIFile(filename: "/usr/include/unistd.h", directory: "", checksumkind: CSK_MD5, checksum: "877e832a8bb8424f9180387a13787475")
!2428 = !DISubroutineType(types: !2429)
!2429 = !{!103, !2430}
!2430 = !DIDerivedType(tag: DW_TAG_typedef, name: "__useconds_t", file: !136, line: 161, baseType: !7)
!2431 = !DISubprogram(name: "assoc_get_iterator", scope: !2432, file: !2432, line: 13, type: !2433, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2432 = !DIFile(filename: "./assoc.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "07a03bb93725ff477a16ac4bae114cd2")
!2433 = !DISubroutineType(types: !2434)
!2434 = !{!89}
!2435 = !DISubprogram(name: "assoc_iterate", scope: !2432, file: !2432, line: 14, type: !2436, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2436 = !DISubroutineType(types: !2437)
!2437 = !{!148, !89, !2438}
!2438 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !529, size: 64)
!2439 = !DISubprogram(name: "assoc_iterate_final", scope: !2432, file: !2432, line: 15, type: !2213, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2440 = !DISubprogram(name: "realloc", scope: !2199, file: !2199, line: 683, type: !2441, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2441 = !DISubroutineType(types: !2442)
!2442 = !{!89, !89, !430}
!2443 = !DISubprogram(name: "do_item_unlinktail_q", scope: !2216, file: !2216, line: 33, type: !2231, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2444 = !DISubprogram(name: "do_item_stats_add_crawl", scope: !2216, file: !2216, line: 55, type: !2445, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2445 = !DISubroutineType(types: !2446)
!2446 = !{null, !752, !2447, !2447, !2447}
!2447 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !133)
!2448 = !DISubprogram(name: "redispatch_conn", scope: !6, file: !6, line: 988, type: !2411, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2449 = !DISubprogram(name: "malloc", scope: !2199, file: !2199, line: 672, type: !2450, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2450 = !DISubroutineType(types: !2451)
!2451 = !{!89, !430}
!2452 = !DISubprogram(name: "do_get_lru_size", scope: !2216, file: !2216, line: 30, type: !2453, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2453 = !DISubroutineType(types: !2454)
!2454 = !{!7, !158}
!2455 = !DISubprogram(name: "do_item_linktail_q", scope: !2216, file: !2216, line: 32, type: !2231, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
