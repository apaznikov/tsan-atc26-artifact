; ModuleID = 'itoa_ljust.c'
source_filename = "itoa_ljust.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@lut = internal unnamed_addr constant [201 x i8] c"00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899\00", align 16, !dbg !0
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(write, inaccessiblemem: none) uwtable
define dso_local noundef nonnull ptr @itoa_u32(i32 noundef %u, ptr noundef writeonly %p) local_unnamed_addr #0 !dbg !28 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %u, metadata !33, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata ptr %p, metadata !34, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata i32 0, metadata !35, metadata !DIExpression()), !dbg !38
  %cmp = icmp ugt i32 %u, 99999999, !dbg !39
  br i1 %cmp, label %if.then, label %if.else, !dbg !41

if.then:                                          ; preds = %entry
  tail call void @llvm.dbg.value(metadata i32 %u, metadata !42, metadata !DIExpression()), !dbg !53
  tail call void @llvm.dbg.value(metadata i32 100000000, metadata !49, metadata !DIExpression()), !dbg !53
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !50, metadata !DIExpression()), !dbg !53
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !51, metadata !DIExpression()), !dbg !53
  tail call void @llvm.dbg.value(metadata i32 10, metadata !52, metadata !DIExpression()), !dbg !53
  %cmp.i = icmp ult i32 %u, 1000000000, !dbg !55
  %div.i = udiv i32 %u, 100000000, !dbg !38
  br i1 %cmp.i, label %if.end16.thread70, label %sw.bb.i, !dbg !57

if.end16.thread70:                                ; preds = %if.then
  tail call void @llvm.dbg.value(metadata i32 %div.i, metadata !35, metadata !DIExpression()), !dbg !38
  %0 = trunc nuw nsw i32 %div.i to i8, !dbg !58
  %conv.i = or disjoint i8 %0, 48, !dbg !58
  tail call void @llvm.dbg.value(metadata i8 %conv.i, metadata !60, metadata !DIExpression()), !dbg !66
  tail call void @llvm.dbg.value(metadata ptr %p, metadata !65, metadata !DIExpression()), !dbg !66
  store i8 %conv.i, ptr %p, align 1, !dbg !68
  tail call void @llvm.dbg.value(metadata i32 9, metadata !52, metadata !DIExpression()), !dbg !53
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i, metadata !34, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !37, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata i32 %u, metadata !69, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i, metadata !74, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %div.i, metadata !75, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !76, metadata !DIExpression()), !dbg !77
  br label %sw.bb1.i, !dbg !79

if.else:                                          ; preds = %entry
  %cmp1 = icmp ult i32 %u, 100, !dbg !80
  br i1 %cmp1, label %if.then2, label %if.else4, !dbg !82

if.then2:                                         ; preds = %if.else
  tail call void @llvm.dbg.value(metadata i32 %u, metadata !42, metadata !DIExpression()), !dbg !83
  tail call void @llvm.dbg.value(metadata i32 1, metadata !49, metadata !DIExpression()), !dbg !83
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !50, metadata !DIExpression()), !dbg !83
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !51, metadata !DIExpression()), !dbg !83
  tail call void @llvm.dbg.value(metadata i32 2, metadata !52, metadata !DIExpression()), !dbg !83
  %cmp.i27 = icmp ult i32 %u, 10, !dbg !85
  br i1 %cmp.i27, label %if.end16.thread, label %sw.bb20.i, !dbg !86

if.end16.thread:                                  ; preds = %if.then2
  tail call void @llvm.dbg.value(metadata i32 %u, metadata !35, metadata !DIExpression()), !dbg !38
  %1 = trunc nuw i32 %u to i8, !dbg !87
  %conv.i31 = or disjoint i8 %1, 48, !dbg !87
  tail call void @llvm.dbg.value(metadata i8 %conv.i31, metadata !60, metadata !DIExpression()), !dbg !88
  tail call void @llvm.dbg.value(metadata ptr %p, metadata !65, metadata !DIExpression()), !dbg !88
  store i8 %conv.i31, ptr %p, align 1, !dbg !90
  %add.ptr.i.i32 = getelementptr inbounds i8, ptr %p, i64 1, !dbg !91
  tail call void @llvm.dbg.value(metadata i32 1, metadata !52, metadata !DIExpression()), !dbg !83
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !35, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i32, metadata !34, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !37, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata i32 %u, metadata !69, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i32, metadata !74, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !75, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !76, metadata !DIExpression()), !dbg !77
  br label %itoa.exit, !dbg !79

if.else4:                                         ; preds = %if.else
  %cmp5 = icmp ult i32 %u, 10000, !dbg !92
  br i1 %cmp5, label %if.then6, label %if.else8, !dbg !94

if.then6:                                         ; preds = %if.else4
  tail call void @llvm.dbg.value(metadata i32 %u, metadata !42, metadata !DIExpression()), !dbg !95
  tail call void @llvm.dbg.value(metadata i32 100, metadata !49, metadata !DIExpression()), !dbg !95
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !50, metadata !DIExpression()), !dbg !95
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !51, metadata !DIExpression()), !dbg !95
  tail call void @llvm.dbg.value(metadata i32 4, metadata !52, metadata !DIExpression()), !dbg !95
  %cmp.i34 = icmp ult i32 %u, 1000, !dbg !97
  br i1 %cmp.i34, label %if.end16.thread94, label %sw.bb14.i, !dbg !98

if.end16.thread94:                                ; preds = %if.then6
  %div.i37.lhs.trunc = trunc nuw i32 %u to i16, !dbg !99
  %div.i3798 = udiv i16 %div.i37.lhs.trunc, 100, !dbg !99
  %div.i37.zext = zext nneg i16 %div.i3798 to i32, !dbg !99
  tail call void @llvm.dbg.value(metadata i32 %div.i37.zext, metadata !35, metadata !DIExpression()), !dbg !38
  %2 = trunc nuw i16 %div.i3798 to i8, !dbg !100
  %conv.i38 = or disjoint i8 %2, 48, !dbg !100
  tail call void @llvm.dbg.value(metadata i8 %conv.i38, metadata !60, metadata !DIExpression()), !dbg !101
  tail call void @llvm.dbg.value(metadata ptr %p, metadata !65, metadata !DIExpression()), !dbg !101
  store i8 %conv.i38, ptr %p, align 1, !dbg !103
  %add.ptr.i.i39 = getelementptr inbounds i8, ptr %p, i64 1, !dbg !104
  tail call void @llvm.dbg.value(metadata i32 3, metadata !52, metadata !DIExpression()), !dbg !95
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i39, metadata !34, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !37, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata i32 %u, metadata !69, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i39, metadata !74, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %div.i37.zext, metadata !75, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !76, metadata !DIExpression()), !dbg !77
  br label %sw.bb17.i, !dbg !79

if.else8:                                         ; preds = %if.else4
  %cmp9 = icmp ult i32 %u, 1000000, !dbg !105
  br i1 %cmp9, label %if.then10, label %if.else12, !dbg !107

if.then10:                                        ; preds = %if.else8
  tail call void @llvm.dbg.value(metadata i32 %u, metadata !42, metadata !DIExpression()), !dbg !108
  tail call void @llvm.dbg.value(metadata i32 10000, metadata !49, metadata !DIExpression()), !dbg !108
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !50, metadata !DIExpression()), !dbg !108
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !51, metadata !DIExpression()), !dbg !108
  tail call void @llvm.dbg.value(metadata i32 6, metadata !52, metadata !DIExpression()), !dbg !108
  %cmp.i41 = icmp ult i32 %u, 100000, !dbg !110
  br i1 %cmp.i41, label %if.end16.thread86, label %sw.bb8.i, !dbg !111

if.end16.thread86:                                ; preds = %if.then10
  %div.i44 = udiv i32 %u, 10000, !dbg !112
  tail call void @llvm.dbg.value(metadata i32 %div.i44, metadata !35, metadata !DIExpression()), !dbg !38
  %3 = trunc nuw i32 %div.i44 to i8, !dbg !113
  %conv.i45 = or disjoint i8 %3, 48, !dbg !113
  tail call void @llvm.dbg.value(metadata i8 %conv.i45, metadata !60, metadata !DIExpression()), !dbg !114
  tail call void @llvm.dbg.value(metadata ptr %p, metadata !65, metadata !DIExpression()), !dbg !114
  store i8 %conv.i45, ptr %p, align 1, !dbg !116
  %add.ptr.i.i46 = getelementptr inbounds i8, ptr %p, i64 1, !dbg !117
  tail call void @llvm.dbg.value(metadata i32 5, metadata !52, metadata !DIExpression()), !dbg !108
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i46, metadata !34, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !37, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata i32 %u, metadata !69, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i46, metadata !74, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %div.i44, metadata !75, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !76, metadata !DIExpression()), !dbg !77
  br label %sw.bb11.i, !dbg !79

if.else12:                                        ; preds = %if.else8
  tail call void @llvm.dbg.value(metadata i32 %u, metadata !42, metadata !DIExpression()), !dbg !118
  tail call void @llvm.dbg.value(metadata i32 1000000, metadata !49, metadata !DIExpression()), !dbg !118
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !50, metadata !DIExpression()), !dbg !118
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !51, metadata !DIExpression()), !dbg !118
  tail call void @llvm.dbg.value(metadata i32 8, metadata !52, metadata !DIExpression()), !dbg !118
  %cmp.i48 = icmp ult i32 %u, 10000000, !dbg !120
  br i1 %cmp.i48, label %if.end16.thread78, label %sw.bb2.i, !dbg !121

if.end16.thread78:                                ; preds = %if.else12
  %div.i51 = udiv i32 %u, 1000000, !dbg !122
  tail call void @llvm.dbg.value(metadata i32 %div.i51, metadata !35, metadata !DIExpression()), !dbg !38
  %4 = trunc nuw i32 %div.i51 to i8, !dbg !123
  %conv.i52 = add nuw nsw i8 %4, 48, !dbg !123
  tail call void @llvm.dbg.value(metadata i8 %conv.i52, metadata !60, metadata !DIExpression()), !dbg !124
  tail call void @llvm.dbg.value(metadata ptr %p, metadata !65, metadata !DIExpression()), !dbg !124
  store i8 %conv.i52, ptr %p, align 1, !dbg !126
  %add.ptr.i.i53 = getelementptr inbounds i8, ptr %p, i64 1, !dbg !127
  tail call void @llvm.dbg.value(metadata i32 7, metadata !52, metadata !DIExpression()), !dbg !118
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i53, metadata !34, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !37, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata i32 %u, metadata !69, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i53, metadata !74, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %div.i51, metadata !75, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !76, metadata !DIExpression()), !dbg !77
  br label %sw.bb5.i, !dbg !79

sw.bb.i:                                          ; preds = %if.then
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !35, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata ptr %p, metadata !34, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !37, metadata !DIExpression()), !dbg !38
  tail call void @llvm.dbg.value(metadata i32 %u, metadata !69, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata ptr %p, metadata !74, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !75, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !76, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %div.i, metadata !75, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %div.i, metadata !128, metadata !DIExpression()), !dbg !135
  tail call void @llvm.dbg.value(metadata ptr %p, metadata !134, metadata !DIExpression()), !dbg !135
  %idxprom.i.i = zext nneg i32 %div.i to i64, !dbg !138
  %arrayidx.i.i = getelementptr inbounds i16, ptr @lut, i64 %idxprom.i.i, !dbg !138
  %5 = load i16, ptr %arrayidx.i.i, align 2, !dbg !139
  store i16 %5, ptr %p, align 1, !dbg !139
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i, metadata !74, metadata !DIExpression()), !dbg !77
  br label %sw.bb1.i, !dbg !140

sw.bb1.i:                                         ; preds = %if.end16.thread70, %sw.bb.i
  %.sink = phi i64 [ 1, %if.end16.thread70 ], [ 2, %sw.bb.i ]
  %add.ptr.i.i = getelementptr inbounds i8, ptr %p, i64 %.sink, !dbg !38
  tail call void @llvm.dbg.value(metadata i32 %div.i, metadata !75, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i, metadata !74, metadata !DIExpression()), !dbg !77
  %mul.neg.i = mul i32 %div.i, -100000000, !dbg !141
  %sub.i = add i32 %mul.neg.i, %u, !dbg !142
  tail call void @llvm.dbg.value(metadata i32 %sub.i, metadata !69, metadata !DIExpression()), !dbg !77
  br label %sw.bb2.i, !dbg !143

sw.bb2.i:                                         ; preds = %if.else12, %sw.bb1.i
  %p.addr.1.i = phi ptr [ %add.ptr.i.i, %sw.bb1.i ], [ %p, %if.else12 ]
  %u.addr.0.i = phi i32 [ %sub.i, %sw.bb1.i ], [ %u, %if.else12 ]
  tail call void @llvm.dbg.value(metadata i32 %u.addr.0.i, metadata !69, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata ptr %p.addr.1.i, metadata !74, metadata !DIExpression()), !dbg !77
  %div3.i = udiv i32 %u.addr.0.i, 1000000, !dbg !144
  tail call void @llvm.dbg.value(metadata i32 %div3.i, metadata !75, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %div3.i, metadata !128, metadata !DIExpression()), !dbg !145
  tail call void @llvm.dbg.value(metadata ptr %p.addr.1.i, metadata !134, metadata !DIExpression()), !dbg !145
  %idxprom.i46.i = zext nneg i32 %div3.i to i64, !dbg !147
  %arrayidx.i47.i = getelementptr inbounds i16, ptr @lut, i64 %idxprom.i46.i, !dbg !147
  %6 = load i16, ptr %arrayidx.i47.i, align 2, !dbg !148
  store i16 %6, ptr %p.addr.1.i, align 1, !dbg !148
  %add.ptr.i48.i = getelementptr inbounds i8, ptr %p.addr.1.i, i64 2, !dbg !149
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i48.i, metadata !74, metadata !DIExpression()), !dbg !77
  br label %sw.bb5.i, !dbg !150

sw.bb5.i:                                         ; preds = %if.end16.thread78, %sw.bb2.i
  %p.addr.2.i = phi ptr [ %add.ptr.i48.i, %sw.bb2.i ], [ %add.ptr.i.i53, %if.end16.thread78 ]
  %d.addr.1.i = phi i32 [ %div3.i, %sw.bb2.i ], [ %div.i51, %if.end16.thread78 ]
  %u.addr.1.i = phi i32 [ %u.addr.0.i, %sw.bb2.i ], [ %u, %if.end16.thread78 ]
  tail call void @llvm.dbg.value(metadata i32 %u.addr.1.i, metadata !69, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %d.addr.1.i, metadata !75, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata ptr %p.addr.2.i, metadata !74, metadata !DIExpression()), !dbg !77
  %mul6.neg.i = mul i32 %d.addr.1.i, -1000000, !dbg !151
  %sub7.i = add i32 %mul6.neg.i, %u.addr.1.i, !dbg !152
  tail call void @llvm.dbg.value(metadata i32 %sub7.i, metadata !69, metadata !DIExpression()), !dbg !77
  br label %sw.bb8.i, !dbg !153

sw.bb8.i:                                         ; preds = %if.then10, %sw.bb5.i
  %p.addr.3.i = phi ptr [ %p.addr.2.i, %sw.bb5.i ], [ %p, %if.then10 ]
  %u.addr.2.i = phi i32 [ %sub7.i, %sw.bb5.i ], [ %u, %if.then10 ]
  tail call void @llvm.dbg.value(metadata i32 %u.addr.2.i, metadata !69, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata ptr %p.addr.3.i, metadata !74, metadata !DIExpression()), !dbg !77
  %div9.i = udiv i32 %u.addr.2.i, 10000, !dbg !154
  tail call void @llvm.dbg.value(metadata i32 %div9.i, metadata !75, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %div9.i, metadata !128, metadata !DIExpression()), !dbg !155
  tail call void @llvm.dbg.value(metadata ptr %p.addr.3.i, metadata !134, metadata !DIExpression()), !dbg !155
  %idxprom.i49.i = zext nneg i32 %div9.i to i64, !dbg !157
  %arrayidx.i50.i = getelementptr inbounds i16, ptr @lut, i64 %idxprom.i49.i, !dbg !157
  %7 = load i16, ptr %arrayidx.i50.i, align 2, !dbg !158
  store i16 %7, ptr %p.addr.3.i, align 1, !dbg !158
  %add.ptr.i51.i = getelementptr inbounds i8, ptr %p.addr.3.i, i64 2, !dbg !159
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i51.i, metadata !74, metadata !DIExpression()), !dbg !77
  br label %sw.bb11.i, !dbg !160

sw.bb11.i:                                        ; preds = %if.end16.thread86, %sw.bb8.i
  %p.addr.4.i = phi ptr [ %add.ptr.i51.i, %sw.bb8.i ], [ %add.ptr.i.i46, %if.end16.thread86 ]
  %d.addr.2.i = phi i32 [ %div9.i, %sw.bb8.i ], [ %div.i44, %if.end16.thread86 ]
  %u.addr.3.i = phi i32 [ %u.addr.2.i, %sw.bb8.i ], [ %u, %if.end16.thread86 ]
  tail call void @llvm.dbg.value(metadata i32 %u.addr.3.i, metadata !69, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %d.addr.2.i, metadata !75, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata ptr %p.addr.4.i, metadata !74, metadata !DIExpression()), !dbg !77
  %mul12.neg.i = mul i32 %d.addr.2.i, -10000, !dbg !161
  %sub13.i = add i32 %mul12.neg.i, %u.addr.3.i, !dbg !162
  tail call void @llvm.dbg.value(metadata i32 %sub13.i, metadata !69, metadata !DIExpression()), !dbg !77
  br label %sw.bb14.i, !dbg !163

sw.bb14.i:                                        ; preds = %if.then6, %sw.bb11.i
  %p.addr.5.i = phi ptr [ %p.addr.4.i, %sw.bb11.i ], [ %p, %if.then6 ]
  %u.addr.4.i = phi i32 [ %sub13.i, %sw.bb11.i ], [ %u, %if.then6 ]
  tail call void @llvm.dbg.value(metadata i32 %u.addr.4.i, metadata !69, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata ptr %p.addr.5.i, metadata !74, metadata !DIExpression()), !dbg !77
  %div15.i = udiv i32 %u.addr.4.i, 100, !dbg !164
  tail call void @llvm.dbg.value(metadata i32 %div15.i, metadata !75, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %div15.i, metadata !128, metadata !DIExpression()), !dbg !165
  tail call void @llvm.dbg.value(metadata ptr %p.addr.5.i, metadata !134, metadata !DIExpression()), !dbg !165
  %idxprom.i52.i = zext nneg i32 %div15.i to i64, !dbg !167
  %arrayidx.i53.i = getelementptr inbounds i16, ptr @lut, i64 %idxprom.i52.i, !dbg !167
  %8 = load i16, ptr %arrayidx.i53.i, align 2, !dbg !168
  store i16 %8, ptr %p.addr.5.i, align 1, !dbg !168
  %add.ptr.i54.i = getelementptr inbounds i8, ptr %p.addr.5.i, i64 2, !dbg !169
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i54.i, metadata !74, metadata !DIExpression()), !dbg !77
  br label %sw.bb17.i, !dbg !170

sw.bb17.i:                                        ; preds = %if.end16.thread94, %sw.bb14.i
  %p.addr.6.i = phi ptr [ %add.ptr.i54.i, %sw.bb14.i ], [ %add.ptr.i.i39, %if.end16.thread94 ]
  %d.addr.3.i = phi i32 [ %div15.i, %sw.bb14.i ], [ %div.i37.zext, %if.end16.thread94 ]
  %u.addr.5.i = phi i32 [ %u.addr.4.i, %sw.bb14.i ], [ %u, %if.end16.thread94 ]
  tail call void @llvm.dbg.value(metadata i32 %u.addr.5.i, metadata !69, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %d.addr.3.i, metadata !75, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata ptr %p.addr.6.i, metadata !74, metadata !DIExpression()), !dbg !77
  %mul18.neg.i = mul i32 %d.addr.3.i, -100, !dbg !171
  %sub19.i = add i32 %mul18.neg.i, %u.addr.5.i, !dbg !172
  tail call void @llvm.dbg.value(metadata i32 %sub19.i, metadata !69, metadata !DIExpression()), !dbg !77
  br label %sw.bb20.i, !dbg !173

sw.bb20.i:                                        ; preds = %if.then2, %sw.bb17.i
  %p.addr.7.i = phi ptr [ %p.addr.6.i, %sw.bb17.i ], [ %p, %if.then2 ]
  %u.addr.6.i = phi i32 [ %sub19.i, %sw.bb17.i ], [ %u, %if.then2 ]
  tail call void @llvm.dbg.value(metadata i32 %u.addr.6.i, metadata !69, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata ptr %p.addr.7.i, metadata !74, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %u.addr.6.i, metadata !75, metadata !DIExpression()), !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %u.addr.6.i, metadata !128, metadata !DIExpression()), !dbg !174
  tail call void @llvm.dbg.value(metadata ptr %p.addr.7.i, metadata !134, metadata !DIExpression()), !dbg !174
  %idxprom.i55.i = sext i32 %u.addr.6.i to i64, !dbg !176
  %arrayidx.i56.i = getelementptr inbounds i16, ptr @lut, i64 %idxprom.i55.i, !dbg !176
  %9 = load i16, ptr %arrayidx.i56.i, align 2, !dbg !177
  store i16 %9, ptr %p.addr.7.i, align 1, !dbg !177
  %add.ptr.i57.i = getelementptr inbounds i8, ptr %p.addr.7.i, i64 2, !dbg !178
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i57.i, metadata !74, metadata !DIExpression()), !dbg !77
  br label %itoa.exit, !dbg !179

itoa.exit:                                        ; preds = %if.end16.thread, %sw.bb20.i
  %p.addr.8.i = phi ptr [ %add.ptr.i57.i, %sw.bb20.i ], [ %add.ptr.i.i32, %if.end16.thread ]
  tail call void @llvm.dbg.value(metadata ptr %p.addr.8.i, metadata !74, metadata !DIExpression()), !dbg !77
  store i8 0, ptr %p.addr.8.i, align 1, !dbg !180, !tbaa !181
  ret ptr %p.addr.8.i, !dbg !184
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(write, inaccessiblemem: none) uwtable
define dso_local noundef nonnull ptr @itoa_32(i32 noundef %i, ptr noundef %p) local_unnamed_addr #0 !dbg !185 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %i, metadata !192, metadata !DIExpression()), !dbg !195
  tail call void @llvm.dbg.value(metadata ptr %p, metadata !193, metadata !DIExpression()), !dbg !195
  tail call void @llvm.dbg.value(metadata i32 %i, metadata !194, metadata !DIExpression()), !dbg !195
  %cmp = icmp slt i32 %i, 0, !dbg !196
  br i1 %cmp, label %if.then, label %if.end, !dbg !198

if.then:                                          ; preds = %entry
  %incdec.ptr = getelementptr inbounds i8, ptr %p, i64 1, !dbg !199
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !193, metadata !DIExpression()), !dbg !195
  store i8 45, ptr %p, align 1, !dbg !201, !tbaa !181
  %sub = sub i32 0, %i, !dbg !202
  tail call void @llvm.dbg.value(metadata i32 %sub, metadata !194, metadata !DIExpression()), !dbg !195
  br label %if.end, !dbg !203

if.end:                                           ; preds = %if.then, %entry
  %p.addr.0 = phi ptr [ %incdec.ptr, %if.then ], [ %p, %entry ]
  %u.0 = phi i32 [ %sub, %if.then ], [ %i, %entry ], !dbg !195
  tail call void @llvm.dbg.value(metadata i32 %u.0, metadata !194, metadata !DIExpression()), !dbg !195
  tail call void @llvm.dbg.value(metadata ptr %p.addr.0, metadata !193, metadata !DIExpression()), !dbg !195
  %call = tail call ptr @itoa_u32(i32 noundef %u.0, ptr noundef %p.addr.0), !dbg !204
  ret ptr %call, !dbg !205
}

; Function Attrs: nofree nosync nounwind sanitize_thread memory(write, inaccessiblemem: none) uwtable
define dso_local noundef nonnull ptr @itoa_u64(i64 noundef %u, ptr noundef %p) local_unnamed_addr #1 !dbg !206 {
entry:
  tail call void @llvm.dbg.value(metadata i64 %u, metadata !213, metadata !DIExpression()), !dbg !218
  tail call void @llvm.dbg.value(metadata ptr %p, metadata !214, metadata !DIExpression()), !dbg !218
  tail call void @llvm.dbg.value(metadata i64 %u, metadata !216, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !218
  %cmp = icmp ult i64 %u, 4294967296, !dbg !219
  br i1 %cmp, label %if.then, label %if.end, !dbg !221

if.then:                                          ; preds = %entry
  %conv = trunc nuw i64 %u to i32, !dbg !222
  tail call void @llvm.dbg.value(metadata i32 %conv, metadata !216, metadata !DIExpression()), !dbg !218
  %call = tail call ptr @itoa_u32(i32 noundef %conv, ptr noundef %p), !dbg !223
  br label %common.ret21

common.ret21:                                     ; preds = %if.end, %if.then
  %common.ret21.op = phi ptr [ %call, %if.then ], [ %add.ptr.i57.i, %if.end ]
  ret ptr %common.ret21.op, !dbg !224

if.end:                                           ; preds = %entry
  %div = udiv i64 %u, 1000000000, !dbg !225
  tail call void @llvm.dbg.value(metadata i64 %div, metadata !217, metadata !DIExpression()), !dbg !218
  %call3 = tail call ptr @itoa_u64(i64 noundef %div, ptr noundef %p), !dbg !226
  tail call void @llvm.dbg.value(metadata ptr %call3, metadata !214, metadata !DIExpression()), !dbg !218
  %mul.neg = mul i64 %div, 3294967296, !dbg !227
  %sub = add i64 %mul.neg, %u, !dbg !228
  %conv4 = trunc i64 %sub to i32, !dbg !229
  tail call void @llvm.dbg.value(metadata i32 %conv4, metadata !216, metadata !DIExpression()), !dbg !218
  %div5 = udiv i32 %conv4, 100000000, !dbg !230
  tail call void @llvm.dbg.value(metadata i32 %div5, metadata !215, metadata !DIExpression()), !dbg !218
  %0 = trunc nuw nsw i32 %div5 to i8, !dbg !231
  %conv6 = add nuw nsw i8 %0, 48, !dbg !231
  tail call void @llvm.dbg.value(metadata i8 %conv6, metadata !60, metadata !DIExpression()), !dbg !232
  tail call void @llvm.dbg.value(metadata ptr %call3, metadata !65, metadata !DIExpression()), !dbg !232
  store i8 %conv6, ptr %call3, align 1, !dbg !234
  %add.ptr.i = getelementptr inbounds i8, ptr %call3, i64 1, !dbg !235
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !214, metadata !DIExpression()), !dbg !218
  tail call void @llvm.dbg.value(metadata i32 %conv4, metadata !69, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !74, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %div5, metadata !75, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 9, metadata !76, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %div5, metadata !75, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !74, metadata !DIExpression()), !dbg !236
  %mul.neg.i = mul i32 %div5, -100000000, !dbg !238
  %sub.i = add i32 %mul.neg.i, %conv4, !dbg !239
  tail call void @llvm.dbg.value(metadata i32 %sub.i, metadata !69, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %sub.i, metadata !69, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !74, metadata !DIExpression()), !dbg !236
  %div3.i = udiv i32 %sub.i, 1000000, !dbg !240
  tail call void @llvm.dbg.value(metadata i32 %div3.i, metadata !75, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %div3.i, metadata !128, metadata !DIExpression()), !dbg !241
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !134, metadata !DIExpression()), !dbg !241
  %idxprom.i46.i = zext nneg i32 %div3.i to i64, !dbg !243
  %arrayidx.i47.i = getelementptr inbounds i16, ptr @lut, i64 %idxprom.i46.i, !dbg !243
  %1 = load i16, ptr %arrayidx.i47.i, align 2, !dbg !244
  store i16 %1, ptr %add.ptr.i, align 1, !dbg !244
  %add.ptr.i48.i = getelementptr inbounds i8, ptr %call3, i64 3, !dbg !245
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i48.i, metadata !74, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %sub.i, metadata !69, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %div3.i, metadata !75, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i48.i, metadata !74, metadata !DIExpression()), !dbg !236
  %mul6.neg.i = mul i32 %div3.i, -1000000, !dbg !246
  %sub7.i = add i32 %mul6.neg.i, %sub.i, !dbg !247
  tail call void @llvm.dbg.value(metadata i32 %sub7.i, metadata !69, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %sub7.i, metadata !69, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i48.i, metadata !74, metadata !DIExpression()), !dbg !236
  %div9.i = udiv i32 %sub7.i, 10000, !dbg !248
  tail call void @llvm.dbg.value(metadata i32 %div9.i, metadata !75, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %div9.i, metadata !128, metadata !DIExpression()), !dbg !249
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i48.i, metadata !134, metadata !DIExpression()), !dbg !249
  %idxprom.i49.i = zext nneg i32 %div9.i to i64, !dbg !251
  %arrayidx.i50.i = getelementptr inbounds i16, ptr @lut, i64 %idxprom.i49.i, !dbg !251
  %2 = load i16, ptr %arrayidx.i50.i, align 2, !dbg !252
  store i16 %2, ptr %add.ptr.i48.i, align 1, !dbg !252
  %add.ptr.i51.i = getelementptr inbounds i8, ptr %call3, i64 5, !dbg !253
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i51.i, metadata !74, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %sub7.i, metadata !69, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %div9.i, metadata !75, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i51.i, metadata !74, metadata !DIExpression()), !dbg !236
  %mul12.neg.i = mul i32 %div9.i, -10000, !dbg !254
  %sub13.i = add i32 %mul12.neg.i, %sub7.i, !dbg !255
  tail call void @llvm.dbg.value(metadata i32 %sub13.i, metadata !69, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %sub13.i, metadata !69, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i51.i, metadata !74, metadata !DIExpression()), !dbg !236
  %div15.i = udiv i32 %sub13.i, 100, !dbg !256
  tail call void @llvm.dbg.value(metadata i32 %div15.i, metadata !75, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %div15.i, metadata !128, metadata !DIExpression()), !dbg !257
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i51.i, metadata !134, metadata !DIExpression()), !dbg !257
  %idxprom.i52.i = zext nneg i32 %div15.i to i64, !dbg !259
  %arrayidx.i53.i = getelementptr inbounds i16, ptr @lut, i64 %idxprom.i52.i, !dbg !259
  %3 = load i16, ptr %arrayidx.i53.i, align 2, !dbg !260
  store i16 %3, ptr %add.ptr.i51.i, align 1, !dbg !260
  %add.ptr.i54.i = getelementptr inbounds i8, ptr %call3, i64 7, !dbg !261
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i54.i, metadata !74, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %sub13.i, metadata !69, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %div15.i, metadata !75, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i54.i, metadata !74, metadata !DIExpression()), !dbg !236
  %mul18.neg.i = mul i32 %div15.i, -100, !dbg !262
  %sub19.i = add i32 %mul18.neg.i, %sub13.i, !dbg !263
  tail call void @llvm.dbg.value(metadata i32 %sub19.i, metadata !69, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %sub19.i, metadata !69, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i54.i, metadata !74, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %sub19.i, metadata !75, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata i32 %sub19.i, metadata !128, metadata !DIExpression()), !dbg !264
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i54.i, metadata !134, metadata !DIExpression()), !dbg !264
  %idxprom.i55.i = sext i32 %sub19.i to i64, !dbg !266
  %arrayidx.i56.i = getelementptr inbounds i16, ptr @lut, i64 %idxprom.i55.i, !dbg !266
  %4 = load i16, ptr %arrayidx.i56.i, align 2, !dbg !267
  store i16 %4, ptr %add.ptr.i54.i, align 1, !dbg !267
  %add.ptr.i57.i = getelementptr inbounds i8, ptr %call3, i64 9, !dbg !268
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i57.i, metadata !74, metadata !DIExpression()), !dbg !236
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i57.i, metadata !74, metadata !DIExpression()), !dbg !236
  store i8 0, ptr %add.ptr.i57.i, align 1, !dbg !269, !tbaa !181
  br label %common.ret21
}

; Function Attrs: nofree nosync nounwind sanitize_thread memory(write, inaccessiblemem: none) uwtable
define dso_local noundef nonnull ptr @itoa_64(i64 noundef %i, ptr noundef %p) local_unnamed_addr #1 !dbg !270 {
entry:
  tail call void @llvm.dbg.value(metadata i64 %i, metadata !277, metadata !DIExpression()), !dbg !280
  tail call void @llvm.dbg.value(metadata ptr %p, metadata !278, metadata !DIExpression()), !dbg !280
  tail call void @llvm.dbg.value(metadata i64 %i, metadata !279, metadata !DIExpression()), !dbg !280
  %cmp = icmp slt i64 %i, 0, !dbg !281
  br i1 %cmp, label %if.then, label %if.end, !dbg !283

if.then:                                          ; preds = %entry
  %incdec.ptr = getelementptr inbounds i8, ptr %p, i64 1, !dbg !284
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !278, metadata !DIExpression()), !dbg !280
  store i8 45, ptr %p, align 1, !dbg !286, !tbaa !181
  %sub = sub i64 0, %i, !dbg !287
  tail call void @llvm.dbg.value(metadata i64 %sub, metadata !279, metadata !DIExpression()), !dbg !280
  br label %if.end, !dbg !288

if.end:                                           ; preds = %if.then, %entry
  %p.addr.0 = phi ptr [ %incdec.ptr, %if.then ], [ %p, %entry ]
  %u.0 = phi i64 [ %sub, %if.then ], [ %i, %entry ], !dbg !280
  tail call void @llvm.dbg.value(metadata i64 %u.0, metadata !279, metadata !DIExpression()), !dbg !280
  tail call void @llvm.dbg.value(metadata ptr %p.addr.0, metadata !278, metadata !DIExpression()), !dbg !280
  %call = tail call ptr @itoa_u64(i64 noundef %u.0, ptr noundef %p.addr.0), !dbg !289
  ret ptr %call, !dbg !290
}

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #2 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #3

attributes #0 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(write, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind sanitize_thread memory(write, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nounwind uwtable }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!20, !21, !22, !23, !24, !25, !26}
!llvm.ident = !{!27}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "lut", scope: !2, file: !3, line: 64, type: !15, isLocal: true, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !14, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "itoa_ljust.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "66fbfbcb2a41eb580045e47241c1ceeb")
!4 = !{!5, !10}
!5 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !6, line: 26, baseType: !7)
!6 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!7 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !8, line: 42, baseType: !9)
!8 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!9 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!10 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64)
!11 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint16_t", file: !6, line: 25, baseType: !12)
!12 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint16_t", file: !8, line: 40, baseType: !13)
!13 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!14 = !{!0}
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 1608, elements: !18)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!18 = !{!19}
!19 = !DISubrange(count: 201)
!20 = !{i32 7, !"Dwarf Version", i32 5}
!21 = !{i32 2, !"Debug Info Version", i32 3}
!22 = !{i32 1, !"wchar_size", i32 4}
!23 = !{i32 8, !"PIC Level", i32 2}
!24 = !{i32 7, !"PIE Level", i32 2}
!25 = !{i32 7, !"uwtable", i32 2}
!26 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!27 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!28 = distinct !DISubprogram(name: "itoa_u32", scope: !3, file: !3, line: 109, type: !29, scopeLine: 109, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !32)
!29 = !DISubroutineType(types: !30)
!30 = !{!31, !5, !31}
!31 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !17, size: 64)
!32 = !{!33, !34, !35, !37}
!33 = !DILocalVariable(name: "u", arg: 1, scope: !28, file: !3, line: 109, type: !5)
!34 = !DILocalVariable(name: "p", arg: 2, scope: !28, file: !3, line: 109, type: !31)
!35 = !DILocalVariable(name: "d", scope: !28, file: !3, line: 110, type: !36)
!36 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!37 = !DILocalVariable(name: "n", scope: !28, file: !3, line: 110, type: !36)
!38 = !DILocation(line: 0, scope: !28)
!39 = !DILocation(line: 111, column: 16, scope: !40)
!40 = distinct !DILexicalBlock(scope: !28, file: !3, line: 111, column: 14)
!41 = !DILocation(line: 111, column: 14, scope: !28)
!42 = !DILocalVariable(name: "u", arg: 1, scope: !43, file: !3, line: 83, type: !5)
!43 = distinct !DISubprogram(name: "digits", scope: !3, file: !3, line: 83, type: !44, scopeLine: 83, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !48)
!44 = !DISubroutineType(types: !45)
!45 = !{!36, !5, !9, !46, !47, !36}
!46 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !36, size: 64)
!47 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !31, size: 64)
!48 = !{!42, !49, !50, !51, !52}
!49 = !DILocalVariable(name: "k", arg: 2, scope: !43, file: !3, line: 83, type: !9)
!50 = !DILocalVariable(name: "d", arg: 3, scope: !43, file: !3, line: 83, type: !46)
!51 = !DILocalVariable(name: "p", arg: 4, scope: !43, file: !3, line: 83, type: !47)
!52 = !DILocalVariable(name: "n", arg: 5, scope: !43, file: !3, line: 83, type: !36)
!53 = !DILocation(line: 0, scope: !43, inlinedAt: !54)
!54 = distinct !DILocation(line: 111, column: 33, scope: !40)
!55 = !DILocation(line: 84, column: 11, scope: !56, inlinedAt: !54)
!56 = distinct !DILexicalBlock(scope: !43, file: !3, line: 84, column: 9)
!57 = !DILocation(line: 84, column: 9, scope: !43, inlinedAt: !54)
!58 = !DILocation(line: 86, column: 19, scope: !59, inlinedAt: !54)
!59 = distinct !DILexicalBlock(scope: !56, file: !3, line: 84, column: 19)
!60 = !DILocalVariable(name: "in", arg: 1, scope: !61, file: !3, line: 78, type: !16)
!61 = distinct !DISubprogram(name: "out1", scope: !3, file: !3, line: 78, type: !62, scopeLine: 78, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !64)
!62 = !DISubroutineType(types: !63)
!63 = !{!31, !16, !31}
!64 = !{!60, !65}
!65 = !DILocalVariable(name: "p", arg: 2, scope: !61, file: !3, line: 78, type: !31)
!66 = !DILocation(line: 0, scope: !61, inlinedAt: !67)
!67 = distinct !DILocation(line: 86, column: 14, scope: !59, inlinedAt: !54)
!68 = !DILocation(line: 79, column: 5, scope: !61, inlinedAt: !67)
!69 = !DILocalVariable(name: "u", arg: 1, scope: !70, file: !3, line: 92, type: !5)
!70 = distinct !DISubprogram(name: "itoa", scope: !3, file: !3, line: 92, type: !71, scopeLine: 92, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !73)
!71 = !DISubroutineType(types: !72)
!72 = !{!31, !5, !31, !36, !36}
!73 = !{!69, !74, !75, !76}
!74 = !DILocalVariable(name: "p", arg: 2, scope: !70, file: !3, line: 92, type: !31)
!75 = !DILocalVariable(name: "d", arg: 3, scope: !70, file: !3, line: 92, type: !36)
!76 = !DILocalVariable(name: "n", arg: 4, scope: !70, file: !3, line: 92, type: !36)
!77 = !DILocation(line: 0, scope: !70, inlinedAt: !78)
!78 = distinct !DILocation(line: 116, column: 12, scope: !28)
!79 = !DILocation(line: 93, column: 5, scope: !70, inlinedAt: !78)
!80 = !DILocation(line: 112, column: 16, scope: !81)
!81 = distinct !DILexicalBlock(scope: !40, file: !3, line: 112, column: 14)
!82 = !DILocation(line: 112, column: 14, scope: !40)
!83 = !DILocation(line: 0, scope: !43, inlinedAt: !84)
!84 = distinct !DILocation(line: 112, column: 33, scope: !81)
!85 = !DILocation(line: 84, column: 11, scope: !56, inlinedAt: !84)
!86 = !DILocation(line: 84, column: 9, scope: !43, inlinedAt: !84)
!87 = !DILocation(line: 86, column: 19, scope: !59, inlinedAt: !84)
!88 = !DILocation(line: 0, scope: !61, inlinedAt: !89)
!89 = distinct !DILocation(line: 86, column: 14, scope: !59, inlinedAt: !84)
!90 = !DILocation(line: 79, column: 5, scope: !61, inlinedAt: !89)
!91 = !DILocation(line: 80, column: 14, scope: !61, inlinedAt: !89)
!92 = !DILocation(line: 113, column: 16, scope: !93)
!93 = distinct !DILexicalBlock(scope: !81, file: !3, line: 113, column: 14)
!94 = !DILocation(line: 113, column: 14, scope: !81)
!95 = !DILocation(line: 0, scope: !43, inlinedAt: !96)
!96 = distinct !DILocation(line: 113, column: 33, scope: !93)
!97 = !DILocation(line: 84, column: 11, scope: !56, inlinedAt: !96)
!98 = !DILocation(line: 84, column: 9, scope: !43, inlinedAt: !96)
!99 = !DILocation(line: 85, column: 16, scope: !59, inlinedAt: !96)
!100 = !DILocation(line: 86, column: 19, scope: !59, inlinedAt: !96)
!101 = !DILocation(line: 0, scope: !61, inlinedAt: !102)
!102 = distinct !DILocation(line: 86, column: 14, scope: !59, inlinedAt: !96)
!103 = !DILocation(line: 79, column: 5, scope: !61, inlinedAt: !102)
!104 = !DILocation(line: 80, column: 14, scope: !61, inlinedAt: !102)
!105 = !DILocation(line: 114, column: 16, scope: !106)
!106 = distinct !DILexicalBlock(scope: !93, file: !3, line: 114, column: 14)
!107 = !DILocation(line: 114, column: 14, scope: !93)
!108 = !DILocation(line: 0, scope: !43, inlinedAt: !109)
!109 = distinct !DILocation(line: 114, column: 33, scope: !106)
!110 = !DILocation(line: 84, column: 11, scope: !56, inlinedAt: !109)
!111 = !DILocation(line: 84, column: 9, scope: !43, inlinedAt: !109)
!112 = !DILocation(line: 85, column: 16, scope: !59, inlinedAt: !109)
!113 = !DILocation(line: 86, column: 19, scope: !59, inlinedAt: !109)
!114 = !DILocation(line: 0, scope: !61, inlinedAt: !115)
!115 = distinct !DILocation(line: 86, column: 14, scope: !59, inlinedAt: !109)
!116 = !DILocation(line: 79, column: 5, scope: !61, inlinedAt: !115)
!117 = !DILocation(line: 80, column: 14, scope: !61, inlinedAt: !115)
!118 = !DILocation(line: 0, scope: !43, inlinedAt: !119)
!119 = distinct !DILocation(line: 115, column: 33, scope: !106)
!120 = !DILocation(line: 84, column: 11, scope: !56, inlinedAt: !119)
!121 = !DILocation(line: 84, column: 9, scope: !43, inlinedAt: !119)
!122 = !DILocation(line: 85, column: 16, scope: !59, inlinedAt: !119)
!123 = !DILocation(line: 86, column: 19, scope: !59, inlinedAt: !119)
!124 = !DILocation(line: 0, scope: !61, inlinedAt: !125)
!125 = distinct !DILocation(line: 86, column: 14, scope: !59, inlinedAt: !119)
!126 = !DILocation(line: 79, column: 5, scope: !61, inlinedAt: !125)
!127 = !DILocation(line: 80, column: 14, scope: !61, inlinedAt: !125)
!128 = !DILocalVariable(name: "d", arg: 1, scope: !129, file: !3, line: 73, type: !132)
!129 = distinct !DISubprogram(name: "out2", scope: !3, file: !3, line: 73, type: !130, scopeLine: 73, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !133)
!130 = !DISubroutineType(types: !131)
!131 = !{!31, !132, !31}
!132 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !36)
!133 = !{!128, !134}
!134 = !DILocalVariable(name: "p", arg: 2, scope: !129, file: !3, line: 73, type: !31)
!135 = !DILocation(line: 0, scope: !129, inlinedAt: !136)
!136 = distinct !DILocation(line: 94, column: 38, scope: !137, inlinedAt: !78)
!137 = distinct !DILexicalBlock(scope: !70, file: !3, line: 93, column: 15)
!138 = !DILocation(line: 74, column: 16, scope: !129, inlinedAt: !136)
!139 = !DILocation(line: 74, column: 5, scope: !129, inlinedAt: !136)
!140 = !DILocation(line: 94, column: 34, scope: !137, inlinedAt: !78)
!141 = !DILocation(line: 95, column: 21, scope: !137, inlinedAt: !78)
!142 = !DILocation(line: 95, column: 16, scope: !137, inlinedAt: !78)
!143 = !DILocation(line: 95, column: 14, scope: !137, inlinedAt: !78)
!144 = !DILocation(line: 96, column: 21, scope: !137, inlinedAt: !78)
!145 = !DILocation(line: 0, scope: !129, inlinedAt: !146)
!146 = distinct !DILocation(line: 96, column: 38, scope: !137, inlinedAt: !78)
!147 = !DILocation(line: 74, column: 16, scope: !129, inlinedAt: !146)
!148 = !DILocation(line: 74, column: 5, scope: !129, inlinedAt: !146)
!149 = !DILocation(line: 75, column: 14, scope: !129, inlinedAt: !146)
!150 = !DILocation(line: 96, column: 34, scope: !137, inlinedAt: !78)
!151 = !DILocation(line: 97, column: 21, scope: !137, inlinedAt: !78)
!152 = !DILocation(line: 97, column: 16, scope: !137, inlinedAt: !78)
!153 = !DILocation(line: 97, column: 14, scope: !137, inlinedAt: !78)
!154 = !DILocation(line: 98, column: 21, scope: !137, inlinedAt: !78)
!155 = !DILocation(line: 0, scope: !129, inlinedAt: !156)
!156 = distinct !DILocation(line: 98, column: 38, scope: !137, inlinedAt: !78)
!157 = !DILocation(line: 74, column: 16, scope: !129, inlinedAt: !156)
!158 = !DILocation(line: 74, column: 5, scope: !129, inlinedAt: !156)
!159 = !DILocation(line: 75, column: 14, scope: !129, inlinedAt: !156)
!160 = !DILocation(line: 98, column: 34, scope: !137, inlinedAt: !78)
!161 = !DILocation(line: 99, column: 21, scope: !137, inlinedAt: !78)
!162 = !DILocation(line: 99, column: 16, scope: !137, inlinedAt: !78)
!163 = !DILocation(line: 99, column: 14, scope: !137, inlinedAt: !78)
!164 = !DILocation(line: 100, column: 21, scope: !137, inlinedAt: !78)
!165 = !DILocation(line: 0, scope: !129, inlinedAt: !166)
!166 = distinct !DILocation(line: 100, column: 38, scope: !137, inlinedAt: !78)
!167 = !DILocation(line: 74, column: 16, scope: !129, inlinedAt: !166)
!168 = !DILocation(line: 74, column: 5, scope: !129, inlinedAt: !166)
!169 = !DILocation(line: 75, column: 14, scope: !129, inlinedAt: !166)
!170 = !DILocation(line: 100, column: 34, scope: !137, inlinedAt: !78)
!171 = !DILocation(line: 101, column: 21, scope: !137, inlinedAt: !78)
!172 = !DILocation(line: 101, column: 16, scope: !137, inlinedAt: !78)
!173 = !DILocation(line: 101, column: 14, scope: !137, inlinedAt: !78)
!174 = !DILocation(line: 0, scope: !129, inlinedAt: !175)
!175 = distinct !DILocation(line: 102, column: 38, scope: !137, inlinedAt: !78)
!176 = !DILocation(line: 74, column: 16, scope: !129, inlinedAt: !175)
!177 = !DILocation(line: 74, column: 5, scope: !129, inlinedAt: !175)
!178 = !DILocation(line: 75, column: 14, scope: !129, inlinedAt: !175)
!179 = !DILocation(line: 102, column: 34, scope: !137, inlinedAt: !78)
!180 = !DILocation(line: 105, column: 8, scope: !70, inlinedAt: !78)
!181 = !{!182, !182, i64 0}
!182 = !{!"omnipotent char", !183, i64 0}
!183 = !{!"Simple C/C++ TBAA"}
!184 = !DILocation(line: 116, column: 5, scope: !28)
!185 = distinct !DISubprogram(name: "itoa_32", scope: !3, file: !3, line: 119, type: !186, scopeLine: 119, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !191)
!186 = !DISubroutineType(types: !187)
!187 = !{!31, !188, !31}
!188 = !DIDerivedType(tag: DW_TAG_typedef, name: "int32_t", file: !189, line: 26, baseType: !190)
!189 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h", directory: "", checksumkind: CSK_MD5, checksum: "649b383a60bfa3eb90e85840b2b0be20")
!190 = !DIDerivedType(tag: DW_TAG_typedef, name: "__int32_t", file: !8, line: 41, baseType: !36)
!191 = !{!192, !193, !194}
!192 = !DILocalVariable(name: "i", arg: 1, scope: !185, file: !3, line: 119, type: !188)
!193 = !DILocalVariable(name: "p", arg: 2, scope: !185, file: !3, line: 119, type: !31)
!194 = !DILocalVariable(name: "u", scope: !185, file: !3, line: 120, type: !5)
!195 = !DILocation(line: 0, scope: !185)
!196 = !DILocation(line: 121, column: 11, scope: !197)
!197 = distinct !DILexicalBlock(scope: !185, file: !3, line: 121, column: 9)
!198 = !DILocation(line: 121, column: 9, scope: !185)
!199 = !DILocation(line: 122, column: 11, scope: !200)
!200 = distinct !DILexicalBlock(scope: !197, file: !3, line: 121, column: 16)
!201 = !DILocation(line: 122, column: 14, scope: !200)
!202 = !DILocation(line: 123, column: 13, scope: !200)
!203 = !DILocation(line: 124, column: 5, scope: !200)
!204 = !DILocation(line: 125, column: 12, scope: !185)
!205 = !DILocation(line: 125, column: 5, scope: !185)
!206 = distinct !DISubprogram(name: "itoa_u64", scope: !3, file: !3, line: 128, type: !207, scopeLine: 128, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !212)
!207 = !DISubroutineType(types: !208)
!208 = !{!31, !209, !31}
!209 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !6, line: 27, baseType: !210)
!210 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !8, line: 45, baseType: !211)
!211 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!212 = !{!213, !214, !215, !216, !217}
!213 = !DILocalVariable(name: "u", arg: 1, scope: !206, file: !3, line: 128, type: !209)
!214 = !DILocalVariable(name: "p", arg: 2, scope: !206, file: !3, line: 128, type: !31)
!215 = !DILocalVariable(name: "d", scope: !206, file: !3, line: 129, type: !36)
!216 = !DILocalVariable(name: "lower", scope: !206, file: !3, line: 131, type: !5)
!217 = !DILocalVariable(name: "upper", scope: !206, file: !3, line: 134, type: !209)
!218 = !DILocation(line: 0, scope: !206)
!219 = !DILocation(line: 132, column: 15, scope: !220)
!220 = distinct !DILexicalBlock(scope: !206, file: !3, line: 132, column: 9)
!221 = !DILocation(line: 132, column: 9, scope: !206)
!222 = !DILocation(line: 131, column: 22, scope: !206)
!223 = !DILocation(line: 132, column: 28, scope: !220)
!224 = !DILocation(line: 140, column: 1, scope: !206)
!225 = !DILocation(line: 134, column: 24, scope: !206)
!226 = !DILocation(line: 135, column: 9, scope: !206)
!227 = !DILocation(line: 136, column: 24, scope: !206)
!228 = !DILocation(line: 136, column: 15, scope: !206)
!229 = !DILocation(line: 136, column: 13, scope: !206)
!230 = !DILocation(line: 137, column: 15, scope: !206)
!231 = !DILocation(line: 138, column: 14, scope: !206)
!232 = !DILocation(line: 0, scope: !61, inlinedAt: !233)
!233 = distinct !DILocation(line: 138, column: 9, scope: !206)
!234 = !DILocation(line: 79, column: 5, scope: !61, inlinedAt: !233)
!235 = !DILocation(line: 80, column: 14, scope: !61, inlinedAt: !233)
!236 = !DILocation(line: 0, scope: !70, inlinedAt: !237)
!237 = distinct !DILocation(line: 139, column: 12, scope: !206)
!238 = !DILocation(line: 95, column: 21, scope: !137, inlinedAt: !237)
!239 = !DILocation(line: 95, column: 16, scope: !137, inlinedAt: !237)
!240 = !DILocation(line: 96, column: 21, scope: !137, inlinedAt: !237)
!241 = !DILocation(line: 0, scope: !129, inlinedAt: !242)
!242 = distinct !DILocation(line: 96, column: 38, scope: !137, inlinedAt: !237)
!243 = !DILocation(line: 74, column: 16, scope: !129, inlinedAt: !242)
!244 = !DILocation(line: 74, column: 5, scope: !129, inlinedAt: !242)
!245 = !DILocation(line: 75, column: 14, scope: !129, inlinedAt: !242)
!246 = !DILocation(line: 97, column: 21, scope: !137, inlinedAt: !237)
!247 = !DILocation(line: 97, column: 16, scope: !137, inlinedAt: !237)
!248 = !DILocation(line: 98, column: 21, scope: !137, inlinedAt: !237)
!249 = !DILocation(line: 0, scope: !129, inlinedAt: !250)
!250 = distinct !DILocation(line: 98, column: 38, scope: !137, inlinedAt: !237)
!251 = !DILocation(line: 74, column: 16, scope: !129, inlinedAt: !250)
!252 = !DILocation(line: 74, column: 5, scope: !129, inlinedAt: !250)
!253 = !DILocation(line: 75, column: 14, scope: !129, inlinedAt: !250)
!254 = !DILocation(line: 99, column: 21, scope: !137, inlinedAt: !237)
!255 = !DILocation(line: 99, column: 16, scope: !137, inlinedAt: !237)
!256 = !DILocation(line: 100, column: 21, scope: !137, inlinedAt: !237)
!257 = !DILocation(line: 0, scope: !129, inlinedAt: !258)
!258 = distinct !DILocation(line: 100, column: 38, scope: !137, inlinedAt: !237)
!259 = !DILocation(line: 74, column: 16, scope: !129, inlinedAt: !258)
!260 = !DILocation(line: 74, column: 5, scope: !129, inlinedAt: !258)
!261 = !DILocation(line: 75, column: 14, scope: !129, inlinedAt: !258)
!262 = !DILocation(line: 101, column: 21, scope: !137, inlinedAt: !237)
!263 = !DILocation(line: 101, column: 16, scope: !137, inlinedAt: !237)
!264 = !DILocation(line: 0, scope: !129, inlinedAt: !265)
!265 = distinct !DILocation(line: 102, column: 38, scope: !137, inlinedAt: !237)
!266 = !DILocation(line: 74, column: 16, scope: !129, inlinedAt: !265)
!267 = !DILocation(line: 74, column: 5, scope: !129, inlinedAt: !265)
!268 = !DILocation(line: 75, column: 14, scope: !129, inlinedAt: !265)
!269 = !DILocation(line: 105, column: 8, scope: !70, inlinedAt: !237)
!270 = distinct !DISubprogram(name: "itoa_64", scope: !3, file: !3, line: 142, type: !271, scopeLine: 142, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !276)
!271 = !DISubroutineType(types: !272)
!272 = !{!31, !273, !31}
!273 = !DIDerivedType(tag: DW_TAG_typedef, name: "int64_t", file: !189, line: 27, baseType: !274)
!274 = !DIDerivedType(tag: DW_TAG_typedef, name: "__int64_t", file: !8, line: 44, baseType: !275)
!275 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!276 = !{!277, !278, !279}
!277 = !DILocalVariable(name: "i", arg: 1, scope: !270, file: !3, line: 142, type: !273)
!278 = !DILocalVariable(name: "p", arg: 2, scope: !270, file: !3, line: 142, type: !31)
!279 = !DILocalVariable(name: "u", scope: !270, file: !3, line: 143, type: !209)
!280 = !DILocation(line: 0, scope: !270)
!281 = !DILocation(line: 144, column: 11, scope: !282)
!282 = distinct !DILexicalBlock(scope: !270, file: !3, line: 144, column: 9)
!283 = !DILocation(line: 144, column: 9, scope: !270)
!284 = !DILocation(line: 145, column: 11, scope: !285)
!285 = distinct !DILexicalBlock(scope: !282, file: !3, line: 144, column: 16)
!286 = !DILocation(line: 145, column: 14, scope: !285)
!287 = !DILocation(line: 146, column: 13, scope: !285)
!288 = !DILocation(line: 147, column: 5, scope: !285)
!289 = !DILocation(line: 148, column: 12, scope: !270)
!290 = !DILocation(line: 148, column: 5, scope: !270)
