; ModuleID = 'hash.c'
source_filename = "hash.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.settings = type { i64, i32, i32, i32, ptr, i32, i32, i32, ptr, ptr, i32, double, i32, i32, i32, i8, i32, i32, i8, i32, i32, i32, i32, i32, i32, i8, i8, i8, i8, i8, i8, i32, double, i32, i32, i8, i32, i8, i8, ptr, i32, i32, i32, i32, double, double, i32, i8, i32, i32, i32, i32, i32, i8, i8, i8, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, double, double, i8, i32, i32, ptr, i32 }

@hash = dso_local local_unnamed_addr global ptr null, align 8, !dbg !0
@.str = private unnamed_addr constant [8 x i8] c"jenkins\00", align 1, !dbg !59
@settings = external local_unnamed_addr global %struct.settings, align 8
@.str.1 = private unnamed_addr constant [8 x i8] c"murmur3\00", align 1, !dbg !65
@.str.2 = private unnamed_addr constant [5 x i8] c"xxh3\00", align 1, !dbg !67
@XXH3_kSecret = internal unnamed_addr constant [192 x i8] c"\B8\FEl9#\A4K\BE|\01\81,\F7!\AD\1C\DE\D4m\E9\83\90\97\DBr@\A4\A4\B7\B3g\1F\CBy\E6N\CC\C0\E5x\82Z\D0}\CC\FFr!\B8\08Ft\F7C$\8E\E05\90\E6\81:&L<(R\BB\91\C3\00\CB\88\D0e\8B\1BS.\A3qdH\97\A2\0D\F9N8\19\EFF\A9\DE\AC\D8\A8\FAv?\E3\9C4?\F9\DC\BB\C7\C7\0BO\1D\8AQ\E0K\CD\B4Y1\C8\9F~\C9\D9xsd\EA\C5\AC\834\D3\EB\C3\C5\81\A0\FF\FA\13c\EB\17\0D\DDQ\B7\F0\DAI\D3\16U&)\D4h\9E+\16\BEX}G\A1\FC\8F\F8\B8\D1z\D01\CEE\CB:\8F\95\16\04(\AF\D7\FB\CA\BBK@~", align 64, !dbg !72
@switch.table.hash_init = private unnamed_addr constant [3 x ptr] [ptr @jenkins_hash, ptr @MurmurHash3_x86_32, ptr @XXH3_hash], align 8
@reltable.hash_init = private unnamed_addr constant [3 x i32] [i32 trunc (i64 sub (i64 ptrtoint (ptr @.str to i64), i64 ptrtoint (ptr @reltable.hash_init to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.1 to i64), i64 ptrtoint (ptr @reltable.hash_init to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.2 to i64), i64 ptrtoint (ptr @reltable.hash_init to i64)) to i32)], align 4
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local range(i32 -1, 1) i32 @hash_init(i32 noundef %type) local_unnamed_addr #0 !dbg !93 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %type, metadata !97, metadata !DIExpression()), !dbg !98
  %0 = icmp ult i32 %type, 3, !dbg !99
  br i1 %0, label %switch.lookup, label %return, !dbg !99

switch.lookup:                                    ; preds = %entry
  %1 = zext nneg i32 %type to i64, !dbg !99
  %switch.gep = getelementptr inbounds [3 x ptr], ptr @switch.table.hash_init, i64 0, i64 %1, !dbg !99
  %switch.load = load ptr, ptr %switch.gep, align 8, !dbg !99
  %2 = zext nneg i32 %type to i64, !dbg !99
  %reltable.shift = shl i64 %2, 2, !dbg !99
  %reltable.intrinsic = call ptr @llvm.load.relative.i64(ptr @reltable.hash_init, i64 %reltable.shift), !dbg !99
  store ptr %switch.load, ptr @hash, align 8, !dbg !100, !tbaa !102
  store ptr %reltable.intrinsic, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 39), align 8, !dbg !100, !tbaa !106
  br label %return, !dbg !112

return:                                           ; preds = %entry, %switch.lookup
  %retval.0 = phi i32 [ -1, %entry ], [ 0, %switch.lookup ], !dbg !98
  ret i32 %retval.0, !dbg !112
}

declare i32 @jenkins_hash(ptr noundef, i64 noundef) #1

declare i32 @MurmurHash3_x86_32(ptr noundef, i64 noundef) #1

; Function Attrs: nofree norecurse nosync nounwind sanitize_thread memory(argmem: read, inaccessiblemem: readwrite) uwtable
define internal i32 @XXH3_hash(ptr nocapture noundef readonly %key, i64 noundef %length) #2 !dbg !113 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !115, metadata !DIExpression()), !dbg !117
  tail call void @llvm.dbg.value(metadata i64 %length, metadata !116, metadata !DIExpression()), !dbg !117
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !118, metadata !DIExpression()), !dbg !124
  tail call void @llvm.dbg.value(metadata i64 %length, metadata !123, metadata !DIExpression()), !dbg !124
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !126, metadata !DIExpression()), !dbg !142
  tail call void @llvm.dbg.value(metadata i64 %length, metadata !137, metadata !DIExpression()), !dbg !142
  tail call void @llvm.dbg.value(metadata i64 0, metadata !138, metadata !DIExpression()), !dbg !142
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !139, metadata !DIExpression()), !dbg !142
  tail call void @llvm.dbg.value(metadata i64 192, metadata !140, metadata !DIExpression()), !dbg !142
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !141, metadata !DIExpression()), !dbg !142
  %cmp.i.i = icmp ult i64 %length, 17, !dbg !144
  br i1 %cmp.i.i, label %if.then.i.i, label %if.end.i.i, !dbg !146

if.then.i.i:                                      ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !147, metadata !DIExpression()), !dbg !155
  tail call void @llvm.dbg.value(metadata i64 %length, metadata !152, metadata !DIExpression()), !dbg !155
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !153, metadata !DIExpression()), !dbg !155
  tail call void @llvm.dbg.value(metadata i64 0, metadata !154, metadata !DIExpression()), !dbg !155
  %cmp.i1.i = icmp ugt i64 %length, 8, !dbg !157
  br i1 %cmp.i1.i, label %if.then.i4.i, label %if.end.i2.i, !dbg !160, !prof !161

if.then.i4.i:                                     ; preds = %if.then.i.i
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !162, metadata !DIExpression()), !dbg !175
  tail call void @llvm.dbg.value(metadata i64 %length, metadata !165, metadata !DIExpression()), !dbg !175
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !166, metadata !DIExpression()), !dbg !175
  tail call void @llvm.dbg.value(metadata i64 0, metadata !167, metadata !DIExpression()), !dbg !175
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !182
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !188
  tail call void @llvm.dbg.value(metadata i64 2262974939099578482, metadata !187, metadata !DIExpression()), !dbg !188
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !190
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !192
  tail call void @llvm.dbg.value(metadata i64 8711581037947681227, metadata !187, metadata !DIExpression()), !dbg !192
  tail call void @llvm.dbg.value(metadata i64 7458650908927343033, metadata !168, metadata !DIExpression()), !dbg !194
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !195
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !197
  tail call void @llvm.dbg.value(metadata i64 2410270004345854594, metadata !187, metadata !DIExpression()), !dbg !197
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !199
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !201
  tail call void @llvm.dbg.value(metadata i64 -8204357891075471176, metadata !187, metadata !DIExpression()), !dbg !201
  tail call void @llvm.dbg.value(metadata i64 -5812251307325107654, metadata !171, metadata !DIExpression()), !dbg !194
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !177, metadata !DIExpression()), !dbg !203
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !184, metadata !DIExpression()), !dbg !205
  %val.0.copyload.i.i = load i64, ptr %key, align 1, !dbg !207
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i.i, metadata !187, metadata !DIExpression()), !dbg !205
  %xor9.i.i = xor i64 %val.0.copyload.i.i, 7458650908927343033, !dbg !208
  tail call void @llvm.dbg.value(metadata i64 %xor9.i.i, metadata !172, metadata !DIExpression()), !dbg !194
  %add.ptr10.i.i = getelementptr inbounds i8, ptr %key, i64 %length, !dbg !209
  %add.ptr11.i16.i = getelementptr inbounds i8, ptr %add.ptr10.i.i, i64 -8, !dbg !210
  tail call void @llvm.dbg.value(metadata ptr %add.ptr11.i16.i, metadata !177, metadata !DIExpression()), !dbg !211
  tail call void @llvm.dbg.value(metadata ptr %add.ptr11.i16.i, metadata !184, metadata !DIExpression()), !dbg !213
  %val.0.copyload.i103.i = load i64, ptr %add.ptr11.i16.i, align 1, !dbg !215
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i103.i, metadata !187, metadata !DIExpression()), !dbg !213
  %xor13.i.i = xor i64 %val.0.copyload.i103.i, -5812251307325107654, !dbg !216
  tail call void @llvm.dbg.value(metadata i64 %xor13.i.i, metadata !173, metadata !DIExpression()), !dbg !194
  tail call void @llvm.dbg.value(metadata i64 %xor9.i.i, metadata !217, metadata !DIExpression()), !dbg !222
  %or19.i.i = tail call noundef i64 @llvm.bswap.i64(i64 %xor9.i.i), !dbg !224
  %add15.i.i = add i64 %or19.i.i, %length, !dbg !225
  %add16.i.i = add i64 %add15.i.i, %xor13.i.i, !dbg !226
  tail call void @llvm.dbg.value(metadata i64 %xor9.i.i, metadata !227, metadata !DIExpression()), !dbg !239
  tail call void @llvm.dbg.value(metadata i64 %xor13.i.i, metadata !232, metadata !DIExpression()), !dbg !239
  tail call void @llvm.dbg.value(metadata i64 %xor9.i.i, metadata !241, metadata !DIExpression()), !dbg !250
  tail call void @llvm.dbg.value(metadata i64 %xor13.i.i, metadata !246, metadata !DIExpression()), !dbg !250
  %conv.i.i.i = zext i64 %xor9.i.i to i128, !dbg !252
  %conv1.i.i.i = zext i64 %xor13.i.i to i128, !dbg !253
  %mul.i.i.i = mul nuw i128 %conv1.i.i.i, %conv.i.i.i, !dbg !254
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.i, metadata !247, metadata !DIExpression()), !dbg !250
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !250
  %shr.i.i.i = lshr i128 %mul.i.i.i, 64, !dbg !255
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !250
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !239
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !239
  %xor1.i.i = xor i128 %shr.i.i.i, %mul.i.i.i, !dbg !256
  %xor.i104.i = trunc i128 %xor1.i.i to i64, !dbg !256
  %add18.i.i = add i64 %add16.i.i, %xor.i104.i, !dbg !257
  tail call void @llvm.dbg.value(metadata i64 %add18.i.i, metadata !174, metadata !DIExpression()), !dbg !194
  tail call void @llvm.dbg.value(metadata i64 %add18.i.i, metadata !258, metadata !DIExpression()), !dbg !263
  tail call void @llvm.dbg.value(metadata i64 %add18.i.i, metadata !265, metadata !DIExpression()), !dbg !271
  tail call void @llvm.dbg.value(metadata i32 37, metadata !270, metadata !DIExpression()), !dbg !271
  %shr.i5.i.i = lshr i64 %add18.i.i, 37, !dbg !273
  %xor.i6.i.i = xor i64 %shr.i5.i.i, %add18.i.i, !dbg !274
  tail call void @llvm.dbg.value(metadata i64 %xor.i6.i.i, metadata !258, metadata !DIExpression()), !dbg !263
  %mul.i105.i = mul i64 %xor.i6.i.i, 1609587791953885689, !dbg !275
  tail call void @llvm.dbg.value(metadata i64 %mul.i105.i, metadata !258, metadata !DIExpression()), !dbg !263
  tail call void @llvm.dbg.value(metadata i64 %mul.i105.i, metadata !265, metadata !DIExpression()), !dbg !276
  tail call void @llvm.dbg.value(metadata i32 32, metadata !270, metadata !DIExpression()), !dbg !276
  %shr.i.i106.i = lshr i64 %mul.i105.i, 32, !dbg !278
  %xor.i.i.i = xor i64 %shr.i.i106.i, %mul.i105.i, !dbg !279
  tail call void @llvm.dbg.value(metadata i64 %xor.i.i.i, metadata !258, metadata !DIExpression()), !dbg !263
  br label %XXH_INLINE_XXH3_64bits.exit, !dbg !280

if.end.i2.i:                                      ; preds = %if.then.i.i
  %cmp2.i.i = icmp ugt i64 %length, 3, !dbg !281
  br i1 %cmp2.i.i, label %if.then7.i.i, label %if.end9.i.i, !dbg !283, !prof !161

if.then7.i.i:                                     ; preds = %if.end.i2.i
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !284, metadata !DIExpression()), !dbg !297
  tail call void @llvm.dbg.value(metadata i64 %length, metadata !287, metadata !DIExpression()), !dbg !297
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !288, metadata !DIExpression()), !dbg !297
  tail call void @llvm.dbg.value(metadata i64 0, metadata !289, metadata !DIExpression()), !dbg !297
  tail call void @llvm.dbg.value(metadata i64 0, metadata !289, metadata !DIExpression()), !dbg !297
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !299, metadata !DIExpression()), !dbg !304
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !306, metadata !DIExpression()), !dbg !310
  %val.0.copyload.i107.i = load i32, ptr %key, align 1, !dbg !312
  tail call void @llvm.dbg.value(metadata i32 %val.0.copyload.i107.i, metadata !309, metadata !DIExpression()), !dbg !310
  tail call void @llvm.dbg.value(metadata i32 %val.0.copyload.i107.i, metadata !290, metadata !DIExpression()), !dbg !313
  %add.ptr.i21.i = getelementptr inbounds i8, ptr %key, i64 %length, !dbg !314
  %add.ptr3.i.i = getelementptr inbounds i8, ptr %add.ptr.i21.i, i64 -4, !dbg !315
  tail call void @llvm.dbg.value(metadata ptr %add.ptr3.i.i, metadata !299, metadata !DIExpression()), !dbg !316
  tail call void @llvm.dbg.value(metadata ptr %add.ptr3.i.i, metadata !306, metadata !DIExpression()), !dbg !318
  %val.0.copyload.i108.i = load i32, ptr %add.ptr3.i.i, align 1, !dbg !320
  tail call void @llvm.dbg.value(metadata i32 %val.0.copyload.i108.i, metadata !309, metadata !DIExpression()), !dbg !318
  tail call void @llvm.dbg.value(metadata i32 %val.0.copyload.i108.i, metadata !293, metadata !DIExpression()), !dbg !313
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !321
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !323
  tail call void @llvm.dbg.value(metadata i64 2066345149520216444, metadata !187, metadata !DIExpression()), !dbg !323
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !325
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !327
  tail call void @llvm.dbg.value(metadata i64 -2623469361688619810, metadata !187, metadata !DIExpression()), !dbg !327
  tail call void @llvm.dbg.value(metadata i64 -4090762196417718878, metadata !294, metadata !DIExpression()), !dbg !313
  %conv10.i.i = zext i32 %val.0.copyload.i108.i to i64, !dbg !329
  %conv11.i.i = zext i32 %val.0.copyload.i107.i to i64, !dbg !330
  %shl12.i.i = shl nuw i64 %conv11.i.i, 32, !dbg !331
  %add.i26.i = or disjoint i64 %shl12.i.i, %conv10.i.i, !dbg !332
  tail call void @llvm.dbg.value(metadata i64 %add.i26.i, metadata !295, metadata !DIExpression()), !dbg !313
  %xor13.i27.i = xor i64 %add.i26.i, -4090762196417718878, !dbg !333
  tail call void @llvm.dbg.value(metadata i64 %xor13.i27.i, metadata !296, metadata !DIExpression()), !dbg !313
  tail call void @llvm.dbg.value(metadata i64 %xor13.i27.i, metadata !334, metadata !DIExpression()), !dbg !340
  tail call void @llvm.dbg.value(metadata i64 %length, metadata !339, metadata !DIExpression()), !dbg !340
  %0 = tail call i64 @llvm.fshl.i64(i64 %xor13.i27.i, i64 %xor13.i27.i, i64 49), !dbg !342
  %1 = tail call i64 @llvm.fshl.i64(i64 %xor13.i27.i, i64 %xor13.i27.i, i64 24), !dbg !343
  %2 = xor i64 %1, %0, !dbg !344
  %xor1.i109.i = xor i64 %2, %xor13.i27.i, !dbg !344
  tail call void @llvm.dbg.value(metadata i64 %xor1.i109.i, metadata !334, metadata !DIExpression()), !dbg !340
  %mul.i110.i = mul i64 %xor1.i109.i, -6939452855193903323, !dbg !345
  tail call void @llvm.dbg.value(metadata i64 %mul.i110.i, metadata !334, metadata !DIExpression()), !dbg !340
  %shr.i111.i = lshr i64 %mul.i110.i, 35, !dbg !346
  %add.i112.i = add nuw nsw i64 %shr.i111.i, %length, !dbg !347
  %xor2.i.i = xor i64 %add.i112.i, %mul.i110.i, !dbg !348
  tail call void @llvm.dbg.value(metadata i64 %xor2.i.i, metadata !334, metadata !DIExpression()), !dbg !340
  %mul3.i.i = mul i64 %xor2.i.i, -6939452855193903323, !dbg !349
  tail call void @llvm.dbg.value(metadata i64 %mul3.i.i, metadata !334, metadata !DIExpression()), !dbg !340
  tail call void @llvm.dbg.value(metadata i64 %mul3.i.i, metadata !265, metadata !DIExpression()), !dbg !350
  tail call void @llvm.dbg.value(metadata i32 28, metadata !270, metadata !DIExpression()), !dbg !350
  %shr.i.i113.i = lshr i64 %mul3.i.i, 28, !dbg !352
  %xor.i.i114.i = xor i64 %shr.i.i113.i, %mul3.i.i, !dbg !353
  br label %XXH_INLINE_XXH3_64bits.exit, !dbg !354

if.end9.i.i:                                      ; preds = %if.end.i2.i
  %tobool10.not.i.i = icmp eq i64 %length, 0, !dbg !355
  br i1 %tobool10.not.i.i, label %XXH_INLINE_XXH3_64bits.exit, label %if.then11.i.i, !dbg !357

if.then11.i.i:                                    ; preds = %if.end9.i.i
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !358, metadata !DIExpression()), !dbg !371
  tail call void @llvm.dbg.value(metadata i64 %length, metadata !361, metadata !DIExpression()), !dbg !371
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !362, metadata !DIExpression()), !dbg !371
  tail call void @llvm.dbg.value(metadata i64 0, metadata !363, metadata !DIExpression()), !dbg !371
  %3 = load i8, ptr %key, align 1, !dbg !373, !tbaa !374
  tail call void @llvm.dbg.value(metadata i8 %3, metadata !364, metadata !DIExpression()), !dbg !375
  %shr.i.i = lshr i64 %length, 1, !dbg !376
  %arrayidx1.i.i = getelementptr inbounds i8, ptr %key, i64 %shr.i.i, !dbg !377
  %4 = load i8, ptr %arrayidx1.i.i, align 1, !dbg !377, !tbaa !374
  tail call void @llvm.dbg.value(metadata i8 %4, metadata !366, metadata !DIExpression()), !dbg !375
  %5 = getelementptr i8, ptr %key, i64 %length, !dbg !378
  %arrayidx2.i.i = getelementptr i8, ptr %5, i64 -1, !dbg !378
  %6 = load i8, ptr %arrayidx2.i.i, align 1, !dbg !378, !tbaa !374
  tail call void @llvm.dbg.value(metadata i8 %6, metadata !367, metadata !DIExpression()), !dbg !375
  %conv.i.i = zext i8 %3 to i64, !dbg !379
  %shl.i.i = shl nuw nsw i64 %conv.i.i, 16, !dbg !380
  %conv3.i.i = zext i8 %4 to i64, !dbg !381
  %shl4.i.i = shl nuw nsw i64 %conv3.i.i, 24, !dbg !382
  %or.i.i = or disjoint i64 %shl4.i.i, %shl.i.i, !dbg !383
  %conv5.i.i = zext i8 %6 to i64, !dbg !384
  %or7.i.i = or disjoint i64 %or.i.i, %conv5.i.i, !dbg !385
  %shl9.i.i = shl nuw nsw i64 %length, 8, !dbg !386
  tail call void @llvm.dbg.value(metadata !DIArgList(i8 %3, i64 %length, i8 %6, i8 %4), metadata !368, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 16, DW_OP_shl, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 24, DW_OP_shl, DW_OP_or, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_or, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 8, DW_OP_shl, DW_OP_or, DW_OP_stack_value)), !dbg !375
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !299, metadata !DIExpression()), !dbg !387
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !306, metadata !DIExpression()), !dbg !389
  tail call void @llvm.dbg.value(metadata i32 963444408, metadata !309, metadata !DIExpression()), !dbg !389
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !299, metadata !DIExpression()), !dbg !391
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !306, metadata !DIExpression()), !dbg !393
  tail call void @llvm.dbg.value(metadata i32 -1102339037, metadata !309, metadata !DIExpression()), !dbg !393
  tail call void @llvm.dbg.value(metadata i64 2267503259, metadata !369, metadata !DIExpression()), !dbg !375
  %conv13.i.i = or disjoint i64 %or7.i.i, %shl9.i.i, !dbg !395
  %xor14.i.i = xor i64 %conv13.i.i, 2267503259, !dbg !396
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %or7.i.i, i64 %shl9.i.i), metadata !370, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_constu, 2267503259, DW_OP_xor, DW_OP_stack_value)), !dbg !375
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %or7.i.i, i64 %shl9.i.i), metadata !397, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_constu, 2267503259, DW_OP_xor, DW_OP_stack_value)), !dbg !400
  tail call void @llvm.dbg.value(metadata i64 %xor14.i.i, metadata !397, metadata !DIExpression()), !dbg !400
  %mul.i117.i = mul i64 %xor14.i.i, -4417276706812531889, !dbg !402
  tail call void @llvm.dbg.value(metadata i64 %mul.i117.i, metadata !397, metadata !DIExpression()), !dbg !400
  %shr1.i.i = lshr i64 %mul.i117.i, 29, !dbg !403
  %xor2.i118.i = xor i64 %shr1.i.i, %mul.i117.i, !dbg !404
  tail call void @llvm.dbg.value(metadata i64 %xor2.i118.i, metadata !397, metadata !DIExpression()), !dbg !400
  %mul3.i119.i = mul i64 %xor2.i118.i, 1609587929392839161, !dbg !405
  tail call void @llvm.dbg.value(metadata i64 %mul3.i119.i, metadata !397, metadata !DIExpression()), !dbg !400
  %shr4.i.i = lshr i64 %mul3.i119.i, 32, !dbg !406
  %xor5.i120.i = xor i64 %shr4.i.i, %mul3.i119.i, !dbg !407
  tail call void @llvm.dbg.value(metadata i64 %xor5.i120.i, metadata !397, metadata !DIExpression()), !dbg !400
  br label %XXH_INLINE_XXH3_64bits.exit, !dbg !408

if.end.i.i:                                       ; preds = %entry
  %cmp1.i.i = icmp ult i64 %length, 129, !dbg !409
  br i1 %cmp1.i.i, label %if.then2.i.i, label %if.end4.i.i, !dbg !411

if.then2.i.i:                                     ; preds = %if.end.i.i
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !412, metadata !DIExpression()), !dbg !423
  tail call void @llvm.dbg.value(metadata i64 %length, metadata !417, metadata !DIExpression()), !dbg !423
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !418, metadata !DIExpression()), !dbg !423
  tail call void @llvm.dbg.value(metadata i64 192, metadata !419, metadata !DIExpression()), !dbg !423
  tail call void @llvm.dbg.value(metadata i64 0, metadata !420, metadata !DIExpression()), !dbg !423
  %mul.i.i = mul i64 %length, -7046029288634856825, !dbg !425
  tail call void @llvm.dbg.value(metadata i64 %mul.i.i, metadata !421, metadata !DIExpression()), !dbg !426
  %cmp.i6.i = icmp ugt i64 %length, 32, !dbg !427
  br i1 %cmp.i6.i, label %if.then.i7.i, label %XXH3_len_17to128_64b.exit.i, !dbg !429

if.then.i7.i:                                     ; preds = %if.then2.i.i
  %cmp1.i8.i = icmp ugt i64 %length, 64, !dbg !430
  br i1 %cmp1.i8.i, label %if.then2.i9.i, label %if.end20.i.i, !dbg !433

if.then2.i9.i:                                    ; preds = %if.then.i7.i
  %cmp3.i.i = icmp ugt i64 %length, 96, !dbg !434
  br i1 %cmp3.i.i, label %if.then4.i.i, label %if.end.i10.i, !dbg !437

if.then4.i.i:                                     ; preds = %if.then2.i9.i
  %add.ptr.i.i = getelementptr inbounds i8, ptr %key, i64 48, !dbg !438
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i, metadata !440, metadata !DIExpression()), !dbg !450
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !445, metadata !DIExpression()), !dbg !450
  tail call void @llvm.dbg.value(metadata i64 0, metadata !446, metadata !DIExpression()), !dbg !450
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i, metadata !177, metadata !DIExpression()), !dbg !452
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i, metadata !184, metadata !DIExpression()), !dbg !454
  %val.0.copyload.i129.i = load i64, ptr %add.ptr.i.i, align 1, !dbg !456, !noalias !457
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i129.i, metadata !187, metadata !DIExpression()), !dbg !454
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i129.i, metadata !447, metadata !DIExpression()), !dbg !460
  %add.ptr.i48.i = getelementptr inbounds i8, ptr %key, i64 56, !dbg !461
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i48.i, metadata !177, metadata !DIExpression()), !dbg !462
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i48.i, metadata !184, metadata !DIExpression()), !dbg !464
  %val.0.copyload.i130.i = load i64, ptr %add.ptr.i48.i, align 1, !dbg !466, !noalias !457
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i130.i, metadata !187, metadata !DIExpression()), !dbg !464
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i130.i, metadata !449, metadata !DIExpression()), !dbg !460
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !467
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !469
  tail call void @llvm.dbg.value(metadata i64 4554437623014685352, metadata !187, metadata !DIExpression()), !dbg !469
  %xor.i51.i = xor i64 %val.0.copyload.i129.i, 4554437623014685352, !dbg !471
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !472
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !474
  tail call void @llvm.dbg.value(metadata i64 2111919702937427193, metadata !187, metadata !DIExpression()), !dbg !474
  %xor5.i53.i = xor i64 %val.0.copyload.i130.i, 2111919702937427193, !dbg !476
  tail call void @llvm.dbg.value(metadata i64 %xor.i51.i, metadata !227, metadata !DIExpression()), !dbg !477
  tail call void @llvm.dbg.value(metadata i64 %xor5.i53.i, metadata !232, metadata !DIExpression()), !dbg !477
  tail call void @llvm.dbg.value(metadata i64 %xor.i51.i, metadata !241, metadata !DIExpression()), !dbg !479
  tail call void @llvm.dbg.value(metadata i64 %xor5.i53.i, metadata !246, metadata !DIExpression()), !dbg !479
  %conv.i.i131.i = zext i64 %xor.i51.i to i128, !dbg !481
  %conv1.i.i132.i = zext i64 %xor5.i53.i to i128, !dbg !482
  %mul.i.i133.i = mul nuw i128 %conv1.i.i132.i, %conv.i.i131.i, !dbg !483
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i133.i, metadata !247, metadata !DIExpression()), !dbg !479
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i133.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !479
  %shr.i.i134.i = lshr i128 %mul.i.i133.i, 64, !dbg !484
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i134.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !479
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i133.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !477
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i134.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !477
  %xor1.i135.i = xor i128 %shr.i.i134.i, %mul.i.i133.i, !dbg !485
  %xor.i136.i = trunc i128 %xor1.i135.i to i64, !dbg !485
  %add.i.i = add i64 %mul.i.i, %xor.i136.i, !dbg !486
  tail call void @llvm.dbg.value(metadata i64 %add.i.i, metadata !421, metadata !DIExpression()), !dbg !426
  %add.ptr6.i.i = getelementptr inbounds i8, ptr %key, i64 %length, !dbg !487
  %add.ptr7.i.i = getelementptr inbounds i8, ptr %add.ptr6.i.i, i64 -64, !dbg !488
  tail call void @llvm.dbg.value(metadata ptr %add.ptr7.i.i, metadata !440, metadata !DIExpression()), !dbg !489
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !445, metadata !DIExpression()), !dbg !489
  tail call void @llvm.dbg.value(metadata i64 0, metadata !446, metadata !DIExpression()), !dbg !489
  tail call void @llvm.dbg.value(metadata ptr %add.ptr7.i.i, metadata !177, metadata !DIExpression()), !dbg !491
  tail call void @llvm.dbg.value(metadata ptr %add.ptr7.i.i, metadata !184, metadata !DIExpression()), !dbg !493
  %val.0.copyload.i137.i = load i64, ptr %add.ptr7.i.i, align 1, !dbg !495, !noalias !496
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i137.i, metadata !187, metadata !DIExpression()), !dbg !493
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i137.i, metadata !447, metadata !DIExpression()), !dbg !499
  %add.ptr.i45.i = getelementptr inbounds i8, ptr %add.ptr6.i.i, i64 -56, !dbg !500
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i45.i, metadata !177, metadata !DIExpression()), !dbg !501
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i45.i, metadata !184, metadata !DIExpression()), !dbg !503
  %val.0.copyload.i138.i = load i64, ptr %add.ptr.i45.i, align 1, !dbg !505, !noalias !496
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i138.i, metadata !187, metadata !DIExpression()), !dbg !503
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i138.i, metadata !449, metadata !DIExpression()), !dbg !499
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !506
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !508
  tail call void @llvm.dbg.value(metadata i64 3556072174620004746, metadata !187, metadata !DIExpression()), !dbg !508
  %xor.i46.i = xor i64 %val.0.copyload.i137.i, 3556072174620004746, !dbg !510
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !511
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !513
  tail call void @llvm.dbg.value(metadata i64 7238261902898274248, metadata !187, metadata !DIExpression()), !dbg !513
  %xor5.i.i = xor i64 %val.0.copyload.i138.i, 7238261902898274248, !dbg !515
  tail call void @llvm.dbg.value(metadata i64 %xor.i46.i, metadata !227, metadata !DIExpression()), !dbg !516
  tail call void @llvm.dbg.value(metadata i64 %xor5.i.i, metadata !232, metadata !DIExpression()), !dbg !516
  tail call void @llvm.dbg.value(metadata i64 %xor.i46.i, metadata !241, metadata !DIExpression()), !dbg !518
  tail call void @llvm.dbg.value(metadata i64 %xor5.i.i, metadata !246, metadata !DIExpression()), !dbg !518
  %conv.i.i139.i = zext i64 %xor.i46.i to i128, !dbg !520
  %conv1.i.i140.i = zext i64 %xor5.i.i to i128, !dbg !521
  %mul.i.i141.i = mul nuw i128 %conv1.i.i140.i, %conv.i.i139.i, !dbg !522
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i141.i, metadata !247, metadata !DIExpression()), !dbg !518
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i141.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !518
  %shr.i.i142.i = lshr i128 %mul.i.i141.i, 64, !dbg !523
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i142.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !518
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i141.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !516
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i142.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !516
  %xor1.i143.i = xor i128 %shr.i.i142.i, %mul.i.i141.i, !dbg !524
  %xor.i144.i = trunc i128 %xor1.i143.i to i64, !dbg !524
  %add10.i.i = add i64 %add.i.i, %xor.i144.i, !dbg !525
  tail call void @llvm.dbg.value(metadata i64 %add10.i.i, metadata !421, metadata !DIExpression()), !dbg !426
  br label %if.end.i10.i, !dbg !526

if.end.i10.i:                                     ; preds = %if.then4.i.i, %if.then2.i9.i
  %acc.0.i.i = phi i64 [ %add10.i.i, %if.then4.i.i ], [ %mul.i.i, %if.then2.i9.i ], !dbg !426
  tail call void @llvm.dbg.value(metadata i64 %acc.0.i.i, metadata !421, metadata !DIExpression()), !dbg !426
  %add.ptr11.i.i = getelementptr inbounds i8, ptr %key, i64 32, !dbg !527
  tail call void @llvm.dbg.value(metadata ptr %add.ptr11.i.i, metadata !440, metadata !DIExpression()), !dbg !528
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !445, metadata !DIExpression()), !dbg !528
  tail call void @llvm.dbg.value(metadata i64 0, metadata !446, metadata !DIExpression()), !dbg !528
  tail call void @llvm.dbg.value(metadata ptr %add.ptr11.i.i, metadata !177, metadata !DIExpression()), !dbg !530
  tail call void @llvm.dbg.value(metadata ptr %add.ptr11.i.i, metadata !184, metadata !DIExpression()), !dbg !532
  %val.0.copyload.i145.i = load i64, ptr %add.ptr11.i.i, align 1, !dbg !534, !noalias !535
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i145.i, metadata !187, metadata !DIExpression()), !dbg !532
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i145.i, metadata !447, metadata !DIExpression()), !dbg !538
  %add.ptr.i64.i = getelementptr inbounds i8, ptr %key, i64 40, !dbg !539
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i64.i, metadata !177, metadata !DIExpression()), !dbg !540
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i64.i, metadata !184, metadata !DIExpression()), !dbg !542
  %val.0.copyload.i146.i = load i64, ptr %add.ptr.i64.i, align 1, !dbg !544, !noalias !535
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i146.i, metadata !187, metadata !DIExpression()), !dbg !542
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i146.i, metadata !449, metadata !DIExpression()), !dbg !538
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !545
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !547
  tail call void @llvm.dbg.value(metadata i64 -3818837453329782724, metadata !187, metadata !DIExpression()), !dbg !547
  %xor.i67.i = xor i64 %val.0.copyload.i145.i, -3818837453329782724, !dbg !549
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !550
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !552
  tail call void @llvm.dbg.value(metadata i64 -6688317018830679928, metadata !187, metadata !DIExpression()), !dbg !552
  %xor5.i69.i = xor i64 %val.0.copyload.i146.i, -6688317018830679928, !dbg !554
  tail call void @llvm.dbg.value(metadata i64 %xor.i67.i, metadata !227, metadata !DIExpression()), !dbg !555
  tail call void @llvm.dbg.value(metadata i64 %xor5.i69.i, metadata !232, metadata !DIExpression()), !dbg !555
  tail call void @llvm.dbg.value(metadata i64 %xor.i67.i, metadata !241, metadata !DIExpression()), !dbg !557
  tail call void @llvm.dbg.value(metadata i64 %xor5.i69.i, metadata !246, metadata !DIExpression()), !dbg !557
  %conv.i.i147.i = zext i64 %xor.i67.i to i128, !dbg !559
  %conv1.i.i148.i = zext i64 %xor5.i69.i to i128, !dbg !560
  %mul.i.i149.i = mul nuw i128 %conv1.i.i148.i, %conv.i.i147.i, !dbg !561
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i149.i, metadata !247, metadata !DIExpression()), !dbg !557
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i149.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !557
  %shr.i.i150.i = lshr i128 %mul.i.i149.i, 64, !dbg !562
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i150.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !557
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i149.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !555
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i150.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !555
  %xor1.i151.i = xor i128 %shr.i.i150.i, %mul.i.i149.i, !dbg !563
  %xor.i152.i = trunc i128 %xor1.i151.i to i64, !dbg !563
  %add14.i.i = add i64 %acc.0.i.i, %xor.i152.i, !dbg !564
  tail call void @llvm.dbg.value(metadata i64 %add14.i.i, metadata !421, metadata !DIExpression()), !dbg !426
  %add.ptr15.i.i = getelementptr inbounds i8, ptr %key, i64 %length, !dbg !565
  %add.ptr16.i.i = getelementptr inbounds i8, ptr %add.ptr15.i.i, i64 -48, !dbg !566
  tail call void @llvm.dbg.value(metadata ptr %add.ptr16.i.i, metadata !440, metadata !DIExpression()), !dbg !567
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !445, metadata !DIExpression()), !dbg !567
  tail call void @llvm.dbg.value(metadata i64 0, metadata !446, metadata !DIExpression()), !dbg !567
  tail call void @llvm.dbg.value(metadata ptr %add.ptr16.i.i, metadata !177, metadata !DIExpression()), !dbg !569
  tail call void @llvm.dbg.value(metadata ptr %add.ptr16.i.i, metadata !184, metadata !DIExpression()), !dbg !571
  %val.0.copyload.i153.i = load i64, ptr %add.ptr16.i.i, align 1, !dbg !573, !noalias !574
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i153.i, metadata !187, metadata !DIExpression()), !dbg !571
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i153.i, metadata !447, metadata !DIExpression()), !dbg !577
  %add.ptr.i56.i = getelementptr inbounds i8, ptr %add.ptr15.i.i, i64 -40, !dbg !578
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i56.i, metadata !177, metadata !DIExpression()), !dbg !579
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i56.i, metadata !184, metadata !DIExpression()), !dbg !581
  %val.0.copyload.i154.i = load i64, ptr %add.ptr.i56.i, align 1, !dbg !583, !noalias !574
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i154.i, metadata !187, metadata !DIExpression()), !dbg !581
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i154.i, metadata !449, metadata !DIExpression()), !dbg !577
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !584
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !586
  tail call void @llvm.dbg.value(metadata i64 5690594596133299313, metadata !187, metadata !DIExpression()), !dbg !586
  %xor.i59.i = xor i64 %val.0.copyload.i153.i, 5690594596133299313, !dbg !588
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !589
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !591
  tail call void @llvm.dbg.value(metadata i64 -2833645246901970632, metadata !187, metadata !DIExpression()), !dbg !591
  %xor5.i61.i = xor i64 %val.0.copyload.i154.i, -2833645246901970632, !dbg !593
  tail call void @llvm.dbg.value(metadata i64 %xor.i59.i, metadata !227, metadata !DIExpression()), !dbg !594
  tail call void @llvm.dbg.value(metadata i64 %xor5.i61.i, metadata !232, metadata !DIExpression()), !dbg !594
  tail call void @llvm.dbg.value(metadata i64 %xor.i59.i, metadata !241, metadata !DIExpression()), !dbg !596
  tail call void @llvm.dbg.value(metadata i64 %xor5.i61.i, metadata !246, metadata !DIExpression()), !dbg !596
  %conv.i.i155.i = zext i64 %xor.i59.i to i128, !dbg !598
  %conv1.i.i156.i = zext i64 %xor5.i61.i to i128, !dbg !599
  %mul.i.i157.i = mul nuw i128 %conv1.i.i156.i, %conv.i.i155.i, !dbg !600
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i157.i, metadata !247, metadata !DIExpression()), !dbg !596
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i157.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !596
  %shr.i.i158.i = lshr i128 %mul.i.i157.i, 64, !dbg !601
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i158.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !596
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i157.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !594
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i158.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !594
  %xor1.i159.i = xor i128 %shr.i.i158.i, %mul.i.i157.i, !dbg !602
  %xor.i160.i = trunc i128 %xor1.i159.i to i64, !dbg !602
  %add19.i.i = add i64 %add14.i.i, %xor.i160.i, !dbg !603
  tail call void @llvm.dbg.value(metadata i64 %add19.i.i, metadata !421, metadata !DIExpression()), !dbg !426
  br label %if.end20.i.i, !dbg !604

if.end20.i.i:                                     ; preds = %if.end.i10.i, %if.then.i7.i
  %acc.1.i.i = phi i64 [ %add19.i.i, %if.end.i10.i ], [ %mul.i.i, %if.then.i7.i ], !dbg !426
  tail call void @llvm.dbg.value(metadata i64 %acc.1.i.i, metadata !421, metadata !DIExpression()), !dbg !426
  %add.ptr21.i.i = getelementptr inbounds i8, ptr %key, i64 16, !dbg !605
  tail call void @llvm.dbg.value(metadata ptr %add.ptr21.i.i, metadata !440, metadata !DIExpression()), !dbg !606
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !445, metadata !DIExpression()), !dbg !606
  tail call void @llvm.dbg.value(metadata i64 0, metadata !446, metadata !DIExpression()), !dbg !606
  tail call void @llvm.dbg.value(metadata ptr %add.ptr21.i.i, metadata !177, metadata !DIExpression()), !dbg !608
  tail call void @llvm.dbg.value(metadata ptr %add.ptr21.i.i, metadata !184, metadata !DIExpression()), !dbg !610
  %val.0.copyload.i161.i = load i64, ptr %add.ptr21.i.i, align 1, !dbg !612, !noalias !613
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i161.i, metadata !187, metadata !DIExpression()), !dbg !610
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i161.i, metadata !447, metadata !DIExpression()), !dbg !616
  %add.ptr.i80.i = getelementptr inbounds i8, ptr %key, i64 24, !dbg !617
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i80.i, metadata !177, metadata !DIExpression()), !dbg !618
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i80.i, metadata !184, metadata !DIExpression()), !dbg !620
  %val.0.copyload.i162.i = load i64, ptr %add.ptr.i80.i, align 1, !dbg !622, !noalias !613
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i162.i, metadata !187, metadata !DIExpression()), !dbg !620
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i162.i, metadata !449, metadata !DIExpression()), !dbg !616
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !623
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !625
  tail call void @llvm.dbg.value(metadata i64 8711581037947681227, metadata !187, metadata !DIExpression()), !dbg !625
  %xor.i83.i = xor i64 %val.0.copyload.i161.i, 8711581037947681227, !dbg !627
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !628
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !630
  tail call void @llvm.dbg.value(metadata i64 2410270004345854594, metadata !187, metadata !DIExpression()), !dbg !630
  %xor5.i85.i = xor i64 %val.0.copyload.i162.i, 2410270004345854594, !dbg !632
  tail call void @llvm.dbg.value(metadata i64 %xor.i83.i, metadata !227, metadata !DIExpression()), !dbg !633
  tail call void @llvm.dbg.value(metadata i64 %xor5.i85.i, metadata !232, metadata !DIExpression()), !dbg !633
  tail call void @llvm.dbg.value(metadata i64 %xor.i83.i, metadata !241, metadata !DIExpression()), !dbg !635
  tail call void @llvm.dbg.value(metadata i64 %xor5.i85.i, metadata !246, metadata !DIExpression()), !dbg !635
  %conv.i.i163.i = zext i64 %xor.i83.i to i128, !dbg !637
  %conv1.i.i164.i = zext i64 %xor5.i85.i to i128, !dbg !638
  %mul.i.i165.i = mul nuw i128 %conv1.i.i164.i, %conv.i.i163.i, !dbg !639
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i165.i, metadata !247, metadata !DIExpression()), !dbg !635
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i165.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !635
  %shr.i.i166.i = lshr i128 %mul.i.i165.i, 64, !dbg !640
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i166.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !635
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i165.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !633
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i166.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !633
  %xor1.i167.i = xor i128 %shr.i.i166.i, %mul.i.i165.i, !dbg !641
  %xor.i168.i = trunc i128 %xor1.i167.i to i64, !dbg !641
  %add24.i.i = add i64 %acc.1.i.i, %xor.i168.i, !dbg !642
  tail call void @llvm.dbg.value(metadata i64 %add24.i.i, metadata !421, metadata !DIExpression()), !dbg !426
  %add.ptr25.i.i = getelementptr inbounds i8, ptr %key, i64 %length, !dbg !643
  %add.ptr26.i.i = getelementptr inbounds i8, ptr %add.ptr25.i.i, i64 -32, !dbg !644
  tail call void @llvm.dbg.value(metadata ptr %add.ptr26.i.i, metadata !440, metadata !DIExpression()), !dbg !645
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !445, metadata !DIExpression()), !dbg !645
  tail call void @llvm.dbg.value(metadata i64 0, metadata !446, metadata !DIExpression()), !dbg !645
  tail call void @llvm.dbg.value(metadata ptr %add.ptr26.i.i, metadata !177, metadata !DIExpression()), !dbg !647
  tail call void @llvm.dbg.value(metadata ptr %add.ptr26.i.i, metadata !184, metadata !DIExpression()), !dbg !649
  %val.0.copyload.i169.i = load i64, ptr %add.ptr26.i.i, align 1, !dbg !651, !noalias !652
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i169.i, metadata !187, metadata !DIExpression()), !dbg !649
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i169.i, metadata !447, metadata !DIExpression()), !dbg !655
  %add.ptr.i72.i = getelementptr inbounds i8, ptr %add.ptr25.i.i, i64 -24, !dbg !656
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i72.i, metadata !177, metadata !DIExpression()), !dbg !657
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i72.i, metadata !184, metadata !DIExpression()), !dbg !659
  %val.0.copyload.i170.i = load i64, ptr %add.ptr.i72.i, align 1, !dbg !661, !noalias !652
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i170.i, metadata !187, metadata !DIExpression()), !dbg !659
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i170.i, metadata !449, metadata !DIExpression()), !dbg !655
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !662
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !664
  tail call void @llvm.dbg.value(metadata i64 -8204357891075471176, metadata !187, metadata !DIExpression()), !dbg !664
  %xor.i75.i = xor i64 %val.0.copyload.i169.i, -8204357891075471176, !dbg !666
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !667
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !669
  tail call void @llvm.dbg.value(metadata i64 5487137525590930912, metadata !187, metadata !DIExpression()), !dbg !669
  %xor5.i77.i = xor i64 %val.0.copyload.i170.i, 5487137525590930912, !dbg !671
  tail call void @llvm.dbg.value(metadata i64 %xor.i75.i, metadata !227, metadata !DIExpression()), !dbg !672
  tail call void @llvm.dbg.value(metadata i64 %xor5.i77.i, metadata !232, metadata !DIExpression()), !dbg !672
  tail call void @llvm.dbg.value(metadata i64 %xor.i75.i, metadata !241, metadata !DIExpression()), !dbg !674
  tail call void @llvm.dbg.value(metadata i64 %xor5.i77.i, metadata !246, metadata !DIExpression()), !dbg !674
  %conv.i.i171.i = zext i64 %xor.i75.i to i128, !dbg !676
  %conv1.i.i172.i = zext i64 %xor5.i77.i to i128, !dbg !677
  %mul.i.i173.i = mul nuw i128 %conv1.i.i172.i, %conv.i.i171.i, !dbg !678
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i173.i, metadata !247, metadata !DIExpression()), !dbg !674
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i173.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !674
  %shr.i.i174.i = lshr i128 %mul.i.i173.i, 64, !dbg !679
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i174.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !674
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i173.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !672
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i174.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !672
  %xor1.i175.i = xor i128 %shr.i.i174.i, %mul.i.i173.i, !dbg !680
  %xor.i176.i = trunc i128 %xor1.i175.i to i64, !dbg !680
  %add29.i.i = add i64 %add24.i.i, %xor.i176.i, !dbg !681
  tail call void @llvm.dbg.value(metadata i64 %add29.i.i, metadata !421, metadata !DIExpression()), !dbg !426
  br label %XXH3_len_17to128_64b.exit.i, !dbg !682

XXH3_len_17to128_64b.exit.i:                      ; preds = %if.end20.i.i, %if.then2.i.i
  %acc.2.i.i = phi i64 [ %add29.i.i, %if.end20.i.i ], [ %mul.i.i, %if.then2.i.i ], !dbg !426
  tail call void @llvm.dbg.value(metadata i64 %acc.2.i.i, metadata !421, metadata !DIExpression()), !dbg !426
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !440, metadata !DIExpression()), !dbg !683
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !445, metadata !DIExpression()), !dbg !683
  tail call void @llvm.dbg.value(metadata i64 0, metadata !446, metadata !DIExpression()), !dbg !683
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !177, metadata !DIExpression()), !dbg !685
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !184, metadata !DIExpression()), !dbg !687
  %val.0.copyload.i177.i = load i64, ptr %key, align 1, !dbg !689, !noalias !690
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i177.i, metadata !187, metadata !DIExpression()), !dbg !687
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i177.i, metadata !447, metadata !DIExpression()), !dbg !693
  %add.ptr.i96.i = getelementptr inbounds i8, ptr %key, i64 8, !dbg !694
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i96.i, metadata !177, metadata !DIExpression()), !dbg !695
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i96.i, metadata !184, metadata !DIExpression()), !dbg !697
  %val.0.copyload.i178.i = load i64, ptr %add.ptr.i96.i, align 1, !dbg !699, !noalias !690
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i178.i, metadata !187, metadata !DIExpression()), !dbg !697
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i178.i, metadata !449, metadata !DIExpression()), !dbg !693
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !177, metadata !DIExpression()), !dbg !700
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !184, metadata !DIExpression()), !dbg !702
  tail call void @llvm.dbg.value(metadata i64 -4734510112055689544, metadata !187, metadata !DIExpression()), !dbg !702
  %xor.i99.i = xor i64 %val.0.copyload.i177.i, -4734510112055689544, !dbg !704
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !705
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !707
  tail call void @llvm.dbg.value(metadata i64 2066345149520216444, metadata !187, metadata !DIExpression()), !dbg !707
  %xor5.i101.i = xor i64 %val.0.copyload.i178.i, 2066345149520216444, !dbg !709
  tail call void @llvm.dbg.value(metadata i64 %xor.i99.i, metadata !227, metadata !DIExpression()), !dbg !710
  tail call void @llvm.dbg.value(metadata i64 %xor5.i101.i, metadata !232, metadata !DIExpression()), !dbg !710
  tail call void @llvm.dbg.value(metadata i64 %xor.i99.i, metadata !241, metadata !DIExpression()), !dbg !712
  tail call void @llvm.dbg.value(metadata i64 %xor5.i101.i, metadata !246, metadata !DIExpression()), !dbg !712
  %conv.i.i179.i = zext i64 %xor.i99.i to i128, !dbg !714
  %conv1.i.i180.i = zext i64 %xor5.i101.i to i128, !dbg !715
  %mul.i.i181.i = mul nuw i128 %conv1.i.i180.i, %conv.i.i179.i, !dbg !716
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i181.i, metadata !247, metadata !DIExpression()), !dbg !712
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i181.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !712
  %shr.i.i182.i = lshr i128 %mul.i.i181.i, 64, !dbg !717
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i182.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !712
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i181.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !710
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i182.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !710
  %xor1.i183.i = xor i128 %shr.i.i182.i, %mul.i.i181.i, !dbg !718
  %xor.i184.i = trunc i128 %xor1.i183.i to i64, !dbg !718
  %add34.i.i = add i64 %acc.2.i.i, %xor.i184.i, !dbg !719
  tail call void @llvm.dbg.value(metadata i64 %add34.i.i, metadata !421, metadata !DIExpression()), !dbg !426
  %add.ptr35.i.i = getelementptr inbounds i8, ptr %key, i64 %length, !dbg !720
  %add.ptr36.i.i = getelementptr inbounds i8, ptr %add.ptr35.i.i, i64 -16, !dbg !721
  tail call void @llvm.dbg.value(metadata ptr %add.ptr36.i.i, metadata !440, metadata !DIExpression()), !dbg !722
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !445, metadata !DIExpression()), !dbg !722
  tail call void @llvm.dbg.value(metadata i64 0, metadata !446, metadata !DIExpression()), !dbg !722
  tail call void @llvm.dbg.value(metadata ptr %add.ptr36.i.i, metadata !177, metadata !DIExpression()), !dbg !724
  tail call void @llvm.dbg.value(metadata ptr %add.ptr36.i.i, metadata !184, metadata !DIExpression()), !dbg !726
  %val.0.copyload.i185.i = load i64, ptr %add.ptr36.i.i, align 1, !dbg !728, !noalias !729
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i185.i, metadata !187, metadata !DIExpression()), !dbg !726
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i185.i, metadata !447, metadata !DIExpression()), !dbg !732
  %add.ptr.i88.i = getelementptr inbounds i8, ptr %add.ptr35.i.i, i64 -8, !dbg !733
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i88.i, metadata !177, metadata !DIExpression()), !dbg !734
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i88.i, metadata !184, metadata !DIExpression()), !dbg !736
  %val.0.copyload.i186.i = load i64, ptr %add.ptr.i88.i, align 1, !dbg !738, !noalias !729
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i186.i, metadata !187, metadata !DIExpression()), !dbg !736
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i186.i, metadata !449, metadata !DIExpression()), !dbg !732
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !739
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !741
  tail call void @llvm.dbg.value(metadata i64 -2623469361688619810, metadata !187, metadata !DIExpression()), !dbg !741
  %xor.i91.i = xor i64 %val.0.copyload.i185.i, -2623469361688619810, !dbg !743
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !744
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !746
  tail call void @llvm.dbg.value(metadata i64 2262974939099578482, metadata !187, metadata !DIExpression()), !dbg !746
  %xor5.i93.i = xor i64 %val.0.copyload.i186.i, 2262974939099578482, !dbg !748
  tail call void @llvm.dbg.value(metadata i64 %xor.i91.i, metadata !227, metadata !DIExpression()), !dbg !749
  tail call void @llvm.dbg.value(metadata i64 %xor5.i93.i, metadata !232, metadata !DIExpression()), !dbg !749
  tail call void @llvm.dbg.value(metadata i64 %xor.i91.i, metadata !241, metadata !DIExpression()), !dbg !751
  tail call void @llvm.dbg.value(metadata i64 %xor5.i93.i, metadata !246, metadata !DIExpression()), !dbg !751
  %conv.i.i187.i = zext i64 %xor.i91.i to i128, !dbg !753
  %conv1.i.i188.i = zext i64 %xor5.i93.i to i128, !dbg !754
  %mul.i.i189.i = mul nuw i128 %conv1.i.i188.i, %conv.i.i187.i, !dbg !755
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i189.i, metadata !247, metadata !DIExpression()), !dbg !751
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i189.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !751
  %shr.i.i190.i = lshr i128 %mul.i.i189.i, 64, !dbg !756
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i190.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !751
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i189.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !749
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i190.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !749
  %xor1.i191.i = xor i128 %shr.i.i190.i, %mul.i.i189.i, !dbg !757
  %xor.i192.i = trunc i128 %xor1.i191.i to i64, !dbg !757
  %add39.i.i = add i64 %add34.i.i, %xor.i192.i, !dbg !758
  tail call void @llvm.dbg.value(metadata i64 %add39.i.i, metadata !421, metadata !DIExpression()), !dbg !426
  tail call void @llvm.dbg.value(metadata i64 %add39.i.i, metadata !258, metadata !DIExpression()), !dbg !759
  tail call void @llvm.dbg.value(metadata i64 %add39.i.i, metadata !265, metadata !DIExpression()), !dbg !761
  tail call void @llvm.dbg.value(metadata i32 37, metadata !270, metadata !DIExpression()), !dbg !761
  %shr.i5.i193.i = lshr i64 %add39.i.i, 37, !dbg !763
  %xor.i6.i194.i = xor i64 %shr.i5.i193.i, %add39.i.i, !dbg !764
  tail call void @llvm.dbg.value(metadata i64 %xor.i6.i194.i, metadata !258, metadata !DIExpression()), !dbg !759
  %mul.i195.i = mul i64 %xor.i6.i194.i, 1609587791953885689, !dbg !765
  tail call void @llvm.dbg.value(metadata i64 %mul.i195.i, metadata !258, metadata !DIExpression()), !dbg !759
  tail call void @llvm.dbg.value(metadata i64 %mul.i195.i, metadata !265, metadata !DIExpression()), !dbg !766
  tail call void @llvm.dbg.value(metadata i32 32, metadata !270, metadata !DIExpression()), !dbg !766
  %shr.i.i196.i = lshr i64 %mul.i195.i, 32, !dbg !768
  %xor.i.i197.i = xor i64 %shr.i.i196.i, %mul.i195.i, !dbg !769
  tail call void @llvm.dbg.value(metadata i64 %xor.i.i197.i, metadata !258, metadata !DIExpression()), !dbg !759
  br label %XXH_INLINE_XXH3_64bits.exit, !dbg !770

if.end4.i.i:                                      ; preds = %if.end.i.i
  %cmp5.i.i = icmp ult i64 %length, 241, !dbg !771
  br i1 %cmp5.i.i, label %if.then6.i.i, label %if.end8.i.i, !dbg !773

if.then6.i.i:                                     ; preds = %if.end4.i.i
  %call7.i.i = tail call fastcc i64 @XXH3_len_129to240_64b(ptr noundef readonly %key, i64 noundef %length), !dbg !774
  br label %XXH_INLINE_XXH3_64bits.exit, !dbg !775

if.end8.i.i:                                      ; preds = %if.end4.i.i
  %call9.i.i = tail call fastcc i64 @XXH3_hashLong_64b_default(ptr noundef readonly %key, i64 noundef %length), !dbg !776
  br label %XXH_INLINE_XXH3_64bits.exit, !dbg !777

XXH_INLINE_XXH3_64bits.exit:                      ; preds = %if.then.i4.i, %if.then7.i.i, %if.end9.i.i, %if.then11.i.i, %XXH3_len_17to128_64b.exit.i, %if.then6.i.i, %if.end8.i.i
  %retval.0.i.i = phi i64 [ %xor.i.i197.i, %XXH3_len_17to128_64b.exit.i ], [ %call7.i.i, %if.then6.i.i ], [ %call9.i.i, %if.end8.i.i ], [ %xor.i.i.i, %if.then.i4.i ], [ %xor.i.i114.i, %if.then7.i.i ], [ %xor5.i120.i, %if.then11.i.i ], [ 3244421341483603138, %if.end9.i.i ], !dbg !142
  %conv = trunc i64 %retval.0.i.i to i32, !dbg !778
  ret i32 %conv, !dbg !779
}

; Function Attrs: nofree noinline norecurse nosync nounwind sanitize_thread memory(argmem: read, inaccessiblemem: readwrite) uwtable
define internal fastcc i64 @XXH3_hashLong_64b_default(ptr noalias nocapture noundef readonly %input, i64 noundef %len) unnamed_addr #3 !dbg !780 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %input, metadata !783, metadata !DIExpression()), !dbg !788
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !784, metadata !DIExpression()), !dbg !788
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !785, metadata !DIExpression()), !dbg !788
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !786, metadata !DIExpression()), !dbg !788
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !787, metadata !DIExpression()), !dbg !788
  tail call void @llvm.dbg.value(metadata ptr %input, metadata !789, metadata !DIExpression()), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !804, metadata !DIExpression()), !dbg !811
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !805, metadata !DIExpression()), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 192, metadata !806, metadata !DIExpression()), !dbg !811
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !807, metadata !DIExpression()), !dbg !811
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !808, metadata !DIExpression()), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> <i64 3266489917, i64 -7046029288634856825>, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> <i64 -4417276706812531889, i64 1609587929392839161>, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> <i64 -8796714831421723037, i64 2246822519>, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> <i64 2870177450012600261, i64 2654435761>, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !813, metadata !DIExpression()), !dbg !836
  tail call void @llvm.dbg.value(metadata ptr %input, metadata !820, metadata !DIExpression()), !dbg !836
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !821, metadata !DIExpression()), !dbg !836
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !822, metadata !DIExpression()), !dbg !836
  tail call void @llvm.dbg.value(metadata i64 192, metadata !823, metadata !DIExpression()), !dbg !836
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !824, metadata !DIExpression()), !dbg !836
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !825, metadata !DIExpression()), !dbg !836
  tail call void @llvm.dbg.value(metadata i64 16, metadata !826, metadata !DIExpression()), !dbg !836
  tail call void @llvm.dbg.value(metadata i64 1024, metadata !828, metadata !DIExpression()), !dbg !836
  %sub1.i = add i64 %len, -1, !dbg !838
  tail call void @llvm.dbg.value(metadata i64 %sub1.i, metadata !829, metadata !DIExpression(DW_OP_constu, 10, DW_OP_shr, DW_OP_stack_value)), !dbg !836
  tail call void @llvm.dbg.value(metadata i64 0, metadata !830, metadata !DIExpression()), !dbg !836
  %cmp.i69.not = icmp ult i64 %sub1.i, 1024, !dbg !839
  br i1 %cmp.i69.not, label %for.end.i, label %for.body.i.preheader, !dbg !842

for.body.i.preheader:                             ; preds = %entry
  %div239.i = lshr i64 %sub1.i, 10, !dbg !843
  tail call void @llvm.dbg.value(metadata i64 %div239.i, metadata !829, metadata !DIExpression()), !dbg !836
  br label %for.body.i, !dbg !842

for.body.i:                                       ; preds = %for.body.i.preheader, %XXH3_accumulate.exit
  %acc.i.sroa.33.0 = phi <2 x i64> [ <i64 2870177450012600261, i64 2654435761>, %for.body.i.preheader ], [ %add.i61.3, %XXH3_accumulate.exit ], !dbg !811
  %acc.i.sroa.23.0 = phi <2 x i64> [ <i64 -8796714831421723037, i64 2246822519>, %for.body.i.preheader ], [ %add.i61.2, %XXH3_accumulate.exit ], !dbg !811
  %acc.i.sroa.13.0 = phi <2 x i64> [ <i64 -4417276706812531889, i64 1609587929392839161>, %for.body.i.preheader ], [ %add.i61.1, %XXH3_accumulate.exit ], !dbg !811
  %acc.i.sroa.0.0 = phi <2 x i64> [ <i64 3266489917, i64 -7046029288634856825>, %for.body.i.preheader ], [ %add.i61, %XXH3_accumulate.exit ], !dbg !811
  %n.0.i70 = phi i64 [ 0, %for.body.i.preheader ], [ %inc.i, %XXH3_accumulate.exit ]
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.0.0, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.13.0, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.23.0, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.33.0, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 %n.0.i70, metadata !830, metadata !DIExpression()), !dbg !836
  %mul3.i = shl nuw i64 %n.0.i70, 10, !dbg !844
  %add.ptr.i = getelementptr inbounds i8, ptr %input, i64 %mul3.i, !dbg !846
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !847, metadata !DIExpression()), !dbg !861
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !852, metadata !DIExpression()), !dbg !861
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !853, metadata !DIExpression()), !dbg !861
  tail call void @llvm.dbg.value(metadata i64 16, metadata !854, metadata !DIExpression()), !dbg !861
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !855, metadata !DIExpression()), !dbg !861
  tail call void @llvm.dbg.value(metadata i64 0, metadata !856, metadata !DIExpression()), !dbg !861
  br label %for.body.i5, !dbg !863

for.body.i5:                                      ; preds = %for.body.i, %for.body.i5
  %acc.i.sroa.33.1 = phi <2 x i64> [ %acc.i.sroa.33.0, %for.body.i ], [ %add.i59.3, %for.body.i5 ], !dbg !811
  %acc.i.sroa.23.1 = phi <2 x i64> [ %acc.i.sroa.23.0, %for.body.i ], [ %add.i59.2, %for.body.i5 ], !dbg !811
  %acc.i.sroa.13.1 = phi <2 x i64> [ %acc.i.sroa.13.0, %for.body.i ], [ %add.i59.1, %for.body.i5 ], !dbg !811
  %acc.i.sroa.0.1 = phi <2 x i64> [ %acc.i.sroa.0.0, %for.body.i ], [ %add.i59, %for.body.i5 ], !dbg !811
  %n.0.i267 = phi i64 [ 0, %for.body.i ], [ %inc.i11, %for.body.i5 ]
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.0.1, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.13.1, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.23.1, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.33.1, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 %n.0.i267, metadata !856, metadata !DIExpression()), !dbg !861
  %mul.i6 = shl nuw nsw i64 %n.0.i267, 6, !dbg !864
  %add.ptr.i7 = getelementptr inbounds i8, ptr %add.ptr.i, i64 %mul.i6, !dbg !865
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i7, metadata !857, metadata !DIExpression()), !dbg !866
  %add.ptr1.i = getelementptr inbounds i8, ptr %add.ptr.i7, i64 320, !dbg !867
  tail call void @llvm.prefetch.p0(ptr nonnull %add.ptr1.i, i32 0, i32 3, i32 1), !dbg !867, !noalias !868
  %mul2.i = shl nuw nsw i64 %n.0.i267, 3, !dbg !871
  %add.ptr3.i = getelementptr inbounds i8, ptr @XXH3_kSecret, i64 %mul2.i, !dbg !872
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !873, metadata !DIExpression()), !dbg !897
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i7, metadata !878, metadata !DIExpression()), !dbg !897
  tail call void @llvm.dbg.value(metadata ptr %add.ptr3.i, metadata !879, metadata !DIExpression()), !dbg !897
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !880, metadata !DIExpression()), !dbg !899
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i7, metadata !883, metadata !DIExpression()), !dbg !899
  tail call void @llvm.dbg.value(metadata ptr %add.ptr3.i, metadata !885, metadata !DIExpression()), !dbg !899
  tail call void @llvm.dbg.value(metadata i64 0, metadata !886, metadata !DIExpression()), !dbg !899
  tail call void @llvm.dbg.value(metadata i64 0, metadata !886, metadata !DIExpression()), !dbg !899
  %0 = load <2 x i64>, ptr %add.ptr.i7, align 1, !dbg !900, !tbaa !374, !noalias !901
  tail call void @llvm.dbg.value(metadata <2 x i64> %0, metadata !887, metadata !DIExpression()), !dbg !904
  %1 = load <2 x i64>, ptr %add.ptr3.i, align 8, !dbg !905, !tbaa !374, !noalias !901
  tail call void @llvm.dbg.value(metadata <2 x i64> %1, metadata !891, metadata !DIExpression()), !dbg !904
  %xor.i54 = xor <2 x i64> %1, %0, !dbg !906
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i54, metadata !892, metadata !DIExpression()), !dbg !904
  %2 = bitcast <2 x i64> %xor.i54 to <4 x i32>, !dbg !907
  %permil.i.i18 = shufflevector <4 x i32> %2, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !907
  %3 = bitcast <4 x i32> %permil.i.i18 to <2 x i64>, !dbg !907
  tail call void @llvm.dbg.value(metadata <2 x i64> %3, metadata !893, metadata !DIExpression()), !dbg !904
  %4 = and <2 x i64> %xor.i54, <i64 4294967295, i64 4294967295>, !dbg !908
  %5 = and <2 x i64> %3, <i64 4294967295, i64 4294967295>, !dbg !908
  %6 = mul nuw <2 x i64> %5, %4, !dbg !908
  tail call void @llvm.dbg.value(metadata <2 x i64> %6, metadata !894, metadata !DIExpression()), !dbg !904
  %7 = shufflevector <2 x i64> %0, <2 x i64> poison, <2 x i32> <i32 1, i32 0>, !dbg !909
  tail call void @llvm.dbg.value(metadata <2 x i64> %7, metadata !895, metadata !DIExpression()), !dbg !904
  %add.i60 = add <2 x i64> %acc.i.sroa.0.1, %7, !dbg !910
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i60, metadata !896, metadata !DIExpression()), !dbg !904
  %add.i59 = add <2 x i64> %add.i60, %6, !dbg !911
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i59, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 1, metadata !886, metadata !DIExpression()), !dbg !899
  %add.ptr.i.i13.1 = getelementptr inbounds i8, ptr %add.ptr.i7, i64 16, !dbg !912
  %8 = load <2 x i64>, ptr %add.ptr.i.i13.1, align 1, !dbg !900, !tbaa !374, !noalias !901
  tail call void @llvm.dbg.value(metadata <2 x i64> %8, metadata !887, metadata !DIExpression()), !dbg !904
  %add.ptr1.i.i15.1 = getelementptr inbounds i8, ptr %add.ptr3.i, i64 16, !dbg !913
  %9 = load <2 x i64>, ptr %add.ptr1.i.i15.1, align 8, !dbg !905, !tbaa !374, !noalias !901
  tail call void @llvm.dbg.value(metadata <2 x i64> %9, metadata !891, metadata !DIExpression()), !dbg !904
  %xor.i54.1 = xor <2 x i64> %9, %8, !dbg !906
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i54.1, metadata !892, metadata !DIExpression()), !dbg !904
  %10 = bitcast <2 x i64> %xor.i54.1 to <4 x i32>, !dbg !907
  %permil.i.i18.1 = shufflevector <4 x i32> %10, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !907
  %11 = bitcast <4 x i32> %permil.i.i18.1 to <2 x i64>, !dbg !907
  tail call void @llvm.dbg.value(metadata <2 x i64> %11, metadata !893, metadata !DIExpression()), !dbg !904
  %12 = and <2 x i64> %xor.i54.1, <i64 4294967295, i64 4294967295>, !dbg !908
  %13 = and <2 x i64> %11, <i64 4294967295, i64 4294967295>, !dbg !908
  %14 = mul nuw <2 x i64> %13, %12, !dbg !908
  tail call void @llvm.dbg.value(metadata <2 x i64> %14, metadata !894, metadata !DIExpression()), !dbg !904
  %15 = shufflevector <2 x i64> %8, <2 x i64> poison, <2 x i32> <i32 1, i32 0>, !dbg !909
  tail call void @llvm.dbg.value(metadata <2 x i64> %15, metadata !895, metadata !DIExpression()), !dbg !904
  %add.i60.1 = add <2 x i64> %acc.i.sroa.13.1, %15, !dbg !910
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i60.1, metadata !896, metadata !DIExpression()), !dbg !904
  %add.i59.1 = add <2 x i64> %add.i60.1, %14, !dbg !911
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i59.1, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 2, metadata !886, metadata !DIExpression()), !dbg !899
  %add.ptr.i.i13.2 = getelementptr inbounds i8, ptr %add.ptr.i7, i64 32, !dbg !912
  %16 = load <2 x i64>, ptr %add.ptr.i.i13.2, align 1, !dbg !900, !tbaa !374, !noalias !901
  tail call void @llvm.dbg.value(metadata <2 x i64> %16, metadata !887, metadata !DIExpression()), !dbg !904
  %add.ptr1.i.i15.2 = getelementptr inbounds i8, ptr %add.ptr3.i, i64 32, !dbg !913
  %17 = load <2 x i64>, ptr %add.ptr1.i.i15.2, align 8, !dbg !905, !tbaa !374, !noalias !901
  tail call void @llvm.dbg.value(metadata <2 x i64> %17, metadata !891, metadata !DIExpression()), !dbg !904
  %xor.i54.2 = xor <2 x i64> %17, %16, !dbg !906
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i54.2, metadata !892, metadata !DIExpression()), !dbg !904
  %18 = bitcast <2 x i64> %xor.i54.2 to <4 x i32>, !dbg !907
  %permil.i.i18.2 = shufflevector <4 x i32> %18, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !907
  %19 = bitcast <4 x i32> %permil.i.i18.2 to <2 x i64>, !dbg !907
  tail call void @llvm.dbg.value(metadata <2 x i64> %19, metadata !893, metadata !DIExpression()), !dbg !904
  %20 = and <2 x i64> %xor.i54.2, <i64 4294967295, i64 4294967295>, !dbg !908
  %21 = and <2 x i64> %19, <i64 4294967295, i64 4294967295>, !dbg !908
  %22 = mul nuw <2 x i64> %21, %20, !dbg !908
  tail call void @llvm.dbg.value(metadata <2 x i64> %22, metadata !894, metadata !DIExpression()), !dbg !904
  %23 = shufflevector <2 x i64> %16, <2 x i64> poison, <2 x i32> <i32 1, i32 0>, !dbg !909
  tail call void @llvm.dbg.value(metadata <2 x i64> %23, metadata !895, metadata !DIExpression()), !dbg !904
  %add.i60.2 = add <2 x i64> %acc.i.sroa.23.1, %23, !dbg !910
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i60.2, metadata !896, metadata !DIExpression()), !dbg !904
  %add.i59.2 = add <2 x i64> %add.i60.2, %22, !dbg !911
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i59.2, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 3, metadata !886, metadata !DIExpression()), !dbg !899
  %add.ptr.i.i13.3 = getelementptr inbounds i8, ptr %add.ptr.i7, i64 48, !dbg !912
  %24 = load <2 x i64>, ptr %add.ptr.i.i13.3, align 1, !dbg !900, !tbaa !374, !noalias !901
  tail call void @llvm.dbg.value(metadata <2 x i64> %24, metadata !887, metadata !DIExpression()), !dbg !904
  %add.ptr1.i.i15.3 = getelementptr inbounds i8, ptr %add.ptr3.i, i64 48, !dbg !913
  %25 = load <2 x i64>, ptr %add.ptr1.i.i15.3, align 8, !dbg !905, !tbaa !374, !noalias !901
  tail call void @llvm.dbg.value(metadata <2 x i64> %25, metadata !891, metadata !DIExpression()), !dbg !904
  %xor.i54.3 = xor <2 x i64> %25, %24, !dbg !906
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i54.3, metadata !892, metadata !DIExpression()), !dbg !904
  %26 = bitcast <2 x i64> %xor.i54.3 to <4 x i32>, !dbg !907
  %permil.i.i18.3 = shufflevector <4 x i32> %26, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !907
  %27 = bitcast <4 x i32> %permil.i.i18.3 to <2 x i64>, !dbg !907
  tail call void @llvm.dbg.value(metadata <2 x i64> %27, metadata !893, metadata !DIExpression()), !dbg !904
  %28 = and <2 x i64> %xor.i54.3, <i64 4294967295, i64 4294967295>, !dbg !908
  %29 = and <2 x i64> %27, <i64 4294967295, i64 4294967295>, !dbg !908
  %30 = mul nuw <2 x i64> %29, %28, !dbg !908
  tail call void @llvm.dbg.value(metadata <2 x i64> %30, metadata !894, metadata !DIExpression()), !dbg !904
  %31 = shufflevector <2 x i64> %24, <2 x i64> poison, <2 x i32> <i32 1, i32 0>, !dbg !909
  tail call void @llvm.dbg.value(metadata <2 x i64> %31, metadata !895, metadata !DIExpression()), !dbg !904
  %add.i60.3 = add <2 x i64> %acc.i.sroa.33.1, %31, !dbg !910
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i60.3, metadata !896, metadata !DIExpression()), !dbg !904
  %add.i59.3 = add <2 x i64> %add.i60.3, %30, !dbg !911
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i59.3, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 4, metadata !886, metadata !DIExpression()), !dbg !899
  %inc.i11 = add nuw nsw i64 %n.0.i267, 1, !dbg !914
  tail call void @llvm.dbg.value(metadata i64 %inc.i11, metadata !856, metadata !DIExpression()), !dbg !861
  %exitcond.not = icmp eq i64 %inc.i11, 16, !dbg !915
  br i1 %exitcond.not, label %XXH3_accumulate.exit, label %for.body.i5, !dbg !863, !llvm.loop !916

XXH3_accumulate.exit:                             ; preds = %for.body.i5
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !919, metadata !DIExpression()), !dbg !941
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !924, metadata !DIExpression()), !dbg !941
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !925, metadata !DIExpression()), !dbg !943
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !927, metadata !DIExpression()), !dbg !943
  tail call void @llvm.dbg.value(metadata <2 x i64> <i64 -7046029288227243599, i64 -7046029288227243599>, metadata !928, metadata !DIExpression()), !dbg !943
  tail call void @llvm.dbg.value(metadata i64 0, metadata !929, metadata !DIExpression()), !dbg !943
  tail call void @llvm.dbg.value(metadata i64 0, metadata !929, metadata !DIExpression()), !dbg !943
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i59, metadata !930, metadata !DIExpression()), !dbg !944
  %32 = lshr <2 x i64> %add.i59, <i64 47, i64 47>, !dbg !945
  tail call void @llvm.dbg.value(metadata <2 x i64> %32, metadata !934, metadata !DIExpression()), !dbg !944
  tail call void @llvm.dbg.value(metadata !DIArgList(<2 x i64> %add.i59, <2 x i64> %32), metadata !935, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_xor, DW_OP_stack_value)), !dbg !944
  tail call void @llvm.dbg.value(metadata <2 x i64> <i64 -4329134394285701654, i64 -1485321483350670907>, metadata !936, metadata !DIExpression()), !dbg !944
  %33 = xor <2 x i64> %32, %add.i59, !dbg !946
  %xor.i55 = xor <2 x i64> %33, <i64 -4329134394285701654, i64 -1485321483350670907>, !dbg !946
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i55, metadata !937, metadata !DIExpression()), !dbg !944
  %34 = bitcast <2 x i64> %xor.i55 to <4 x i32>, !dbg !947
  %permil.i51.i = shufflevector <4 x i32> %34, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !947
  %35 = bitcast <4 x i32> %permil.i51.i to <2 x i64>, !dbg !947
  tail call void @llvm.dbg.value(metadata <2 x i64> %35, metadata !938, metadata !DIExpression()), !dbg !944
  %36 = and <2 x i64> %xor.i55, <i64 4294967295, i64 4294967295>, !dbg !948
  %37 = mul nuw <2 x i64> %36, <i64 2654435761, i64 2654435761>, !dbg !948
  tail call void @llvm.dbg.value(metadata <2 x i64> %37, metadata !939, metadata !DIExpression()), !dbg !944
  tail call void @llvm.dbg.value(metadata !DIArgList(<2 x i64> %35, <2 x i64> <i64 2654435761, i64 2654435761>), metadata !940, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_mul, DW_OP_stack_value)), !dbg !944
  %38 = mul <2 x i64> %35, <i64 -7046029290881679360, i64 -7046029290881679360>, !dbg !949
  %add.i61 = add <2 x i64> %38, %37, !dbg !950
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i61, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 1, metadata !929, metadata !DIExpression()), !dbg !943
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i59.1, metadata !930, metadata !DIExpression()), !dbg !944
  %39 = lshr <2 x i64> %add.i59.1, <i64 47, i64 47>, !dbg !945
  tail call void @llvm.dbg.value(metadata <2 x i64> %39, metadata !934, metadata !DIExpression()), !dbg !944
  tail call void @llvm.dbg.value(metadata !DIArgList(<2 x i64> %add.i59.1, <2 x i64> %39), metadata !935, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_xor, DW_OP_stack_value)), !dbg !944
  tail call void @llvm.dbg.value(metadata <2 x i64> <i64 5321830579834785047, i64 -7032137544937171245>, metadata !936, metadata !DIExpression()), !dbg !944
  %40 = xor <2 x i64> %39, %add.i59.1, !dbg !946
  %xor.i55.1 = xor <2 x i64> %40, <i64 5321830579834785047, i64 -7032137544937171245>, !dbg !946
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i55.1, metadata !937, metadata !DIExpression()), !dbg !944
  %41 = bitcast <2 x i64> %xor.i55.1 to <4 x i32>, !dbg !947
  %permil.i51.i.1 = shufflevector <4 x i32> %41, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !947
  %42 = bitcast <4 x i32> %permil.i51.i.1 to <2 x i64>, !dbg !947
  tail call void @llvm.dbg.value(metadata <2 x i64> %42, metadata !938, metadata !DIExpression()), !dbg !944
  %43 = and <2 x i64> %xor.i55.1, <i64 4294967295, i64 4294967295>, !dbg !948
  %44 = mul nuw <2 x i64> %43, <i64 2654435761, i64 2654435761>, !dbg !948
  tail call void @llvm.dbg.value(metadata <2 x i64> %44, metadata !939, metadata !DIExpression()), !dbg !944
  tail call void @llvm.dbg.value(metadata !DIArgList(<2 x i64> %42, <2 x i64> <i64 2654435761, i64 2654435761>), metadata !940, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_mul, DW_OP_stack_value)), !dbg !944
  %45 = mul <2 x i64> %42, <i64 -7046029290881679360, i64 -7046029290881679360>, !dbg !949
  %add.i61.1 = add <2 x i64> %45, %44, !dbg !950
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i61.1, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 2, metadata !929, metadata !DIExpression()), !dbg !943
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i59.2, metadata !930, metadata !DIExpression()), !dbg !944
  %46 = lshr <2 x i64> %add.i59.2, <i64 47, i64 47>, !dbg !945
  tail call void @llvm.dbg.value(metadata <2 x i64> %46, metadata !934, metadata !DIExpression()), !dbg !944
  tail call void @llvm.dbg.value(metadata !DIArgList(<2 x i64> %add.i59.2, <2 x i64> %46), metadata !935, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_xor, DW_OP_stack_value)), !dbg !944
  tail call void @llvm.dbg.value(metadata <2 x i64> <i64 -242834301215959509, i64 -3588858202114426737>, metadata !936, metadata !DIExpression()), !dbg !944
  %47 = xor <2 x i64> %46, %add.i59.2, !dbg !946
  %xor.i55.2 = xor <2 x i64> %47, <i64 -242834301215959509, i64 -3588858202114426737>, !dbg !946
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i55.2, metadata !937, metadata !DIExpression()), !dbg !944
  %48 = bitcast <2 x i64> %xor.i55.2 to <4 x i32>, !dbg !947
  %permil.i51.i.2 = shufflevector <4 x i32> %48, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !947
  %49 = bitcast <4 x i32> %permil.i51.i.2 to <2 x i64>, !dbg !947
  tail call void @llvm.dbg.value(metadata <2 x i64> %49, metadata !938, metadata !DIExpression()), !dbg !944
  %50 = and <2 x i64> %xor.i55.2, <i64 4294967295, i64 4294967295>, !dbg !948
  %51 = mul nuw <2 x i64> %50, <i64 2654435761, i64 2654435761>, !dbg !948
  tail call void @llvm.dbg.value(metadata <2 x i64> %51, metadata !939, metadata !DIExpression()), !dbg !944
  tail call void @llvm.dbg.value(metadata !DIArgList(<2 x i64> %49, <2 x i64> <i64 2654435761, i64 2654435761>), metadata !940, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_mul, DW_OP_stack_value)), !dbg !944
  %52 = mul <2 x i64> %49, <i64 -7046029290881679360, i64 -7046029290881679360>, !dbg !949
  %add.i61.2 = add <2 x i64> %52, %51, !dbg !950
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i61.2, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 3, metadata !929, metadata !DIExpression()), !dbg !943
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i59.3, metadata !930, metadata !DIExpression()), !dbg !944
  %53 = lshr <2 x i64> %add.i59.3, <i64 47, i64 47>, !dbg !945
  tail call void @llvm.dbg.value(metadata <2 x i64> %53, metadata !934, metadata !DIExpression()), !dbg !944
  tail call void @llvm.dbg.value(metadata !DIArgList(<2 x i64> %add.i59.3, <2 x i64> %53), metadata !935, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_xor, DW_OP_stack_value)), !dbg !944
  tail call void @llvm.dbg.value(metadata <2 x i64> <i64 2883454493032893253, i64 9097354517224871855>, metadata !936, metadata !DIExpression()), !dbg !944
  %54 = xor <2 x i64> %53, %add.i59.3, !dbg !946
  %xor.i55.3 = xor <2 x i64> %54, <i64 2883454493032893253, i64 9097354517224871855>, !dbg !946
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i55.3, metadata !937, metadata !DIExpression()), !dbg !944
  %55 = bitcast <2 x i64> %xor.i55.3 to <4 x i32>, !dbg !947
  %permil.i51.i.3 = shufflevector <4 x i32> %55, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !947
  %56 = bitcast <4 x i32> %permil.i51.i.3 to <2 x i64>, !dbg !947
  tail call void @llvm.dbg.value(metadata <2 x i64> %56, metadata !938, metadata !DIExpression()), !dbg !944
  %57 = and <2 x i64> %xor.i55.3, <i64 4294967295, i64 4294967295>, !dbg !948
  %58 = mul nuw <2 x i64> %57, <i64 2654435761, i64 2654435761>, !dbg !948
  tail call void @llvm.dbg.value(metadata <2 x i64> %58, metadata !939, metadata !DIExpression()), !dbg !944
  tail call void @llvm.dbg.value(metadata !DIArgList(<2 x i64> %56, <2 x i64> <i64 2654435761, i64 2654435761>), metadata !940, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_mul, DW_OP_stack_value)), !dbg !944
  %59 = mul <2 x i64> %56, <i64 -7046029290881679360, i64 -7046029290881679360>, !dbg !949
  %add.i61.3 = add <2 x i64> %59, %58, !dbg !950
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i61.3, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 4, metadata !929, metadata !DIExpression()), !dbg !943
  %inc.i = add nuw nsw i64 %n.0.i70, 1, !dbg !951
  tail call void @llvm.dbg.value(metadata i64 %inc.i, metadata !830, metadata !DIExpression()), !dbg !836
  %exitcond76.not = icmp eq i64 %inc.i, %div239.i, !dbg !839
  br i1 %exitcond76.not, label %for.end.i, label %for.body.i, !dbg !842, !llvm.loop !952

for.end.i:                                        ; preds = %XXH3_accumulate.exit, %entry
  %acc.i.sroa.33.2 = phi <2 x i64> [ <i64 2870177450012600261, i64 2654435761>, %entry ], [ %add.i61.3, %XXH3_accumulate.exit ], !dbg !811
  %acc.i.sroa.23.2 = phi <2 x i64> [ <i64 -8796714831421723037, i64 2246822519>, %entry ], [ %add.i61.2, %XXH3_accumulate.exit ], !dbg !811
  %acc.i.sroa.13.2 = phi <2 x i64> [ <i64 -4417276706812531889, i64 1609587929392839161>, %entry ], [ %add.i61.1, %XXH3_accumulate.exit ], !dbg !811
  %acc.i.sroa.0.2 = phi <2 x i64> [ <i64 3266489917, i64 -7046029288634856825>, %entry ], [ %add.i61, %XXH3_accumulate.exit ], !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.0.2, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.13.2, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.23.2, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.33.2, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 128)), !dbg !811
  %mul7.i = and i64 %sub1.i, -1024, !dbg !954
  %sub8.i = lshr i64 %sub1.i, 6, !dbg !955
  %div940.i = and i64 %sub8.i, 15, !dbg !955
  tail call void @llvm.dbg.value(metadata i64 %div940.i, metadata !831, metadata !DIExpression()), !dbg !956
  %add.ptr11.i = getelementptr inbounds i8, ptr %input, i64 %mul7.i, !dbg !957
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !847, metadata !DIExpression()), !dbg !958
  tail call void @llvm.dbg.value(metadata ptr %add.ptr11.i, metadata !852, metadata !DIExpression()), !dbg !958
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !853, metadata !DIExpression()), !dbg !958
  tail call void @llvm.dbg.value(metadata i64 %div940.i, metadata !854, metadata !DIExpression()), !dbg !958
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !855, metadata !DIExpression()), !dbg !958
  tail call void @llvm.dbg.value(metadata i64 0, metadata !856, metadata !DIExpression()), !dbg !958
  %cmp.i2772.not = icmp eq i64 %div940.i, 0, !dbg !960
  br i1 %cmp.i2772.not, label %XXH3_accumulate.exit53, label %for.body.i29, !dbg !961

for.body.i29:                                     ; preds = %for.end.i, %for.body.i29
  %acc.i.sroa.33.3 = phi <2 x i64> [ %add.i.3, %for.body.i29 ], [ %acc.i.sroa.33.2, %for.end.i ], !dbg !811
  %acc.i.sroa.23.3 = phi <2 x i64> [ %add.i.2, %for.body.i29 ], [ %acc.i.sroa.23.2, %for.end.i ], !dbg !811
  %acc.i.sroa.13.3 = phi <2 x i64> [ %add.i.1, %for.body.i29 ], [ %acc.i.sroa.13.2, %for.end.i ], !dbg !811
  %acc.i.sroa.0.3 = phi <2 x i64> [ %add.i, %for.body.i29 ], [ %acc.i.sroa.0.2, %for.end.i ], !dbg !811
  %n.0.i2673 = phi i64 [ %inc.i39, %for.body.i29 ], [ 0, %for.end.i ]
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.0.3, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.13.3, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.23.3, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.33.3, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 %n.0.i2673, metadata !856, metadata !DIExpression()), !dbg !958
  %mul.i30 = shl nuw i64 %n.0.i2673, 6, !dbg !962
  %add.ptr.i31 = getelementptr inbounds i8, ptr %add.ptr11.i, i64 %mul.i30, !dbg !963
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i31, metadata !857, metadata !DIExpression()), !dbg !964
  %add.ptr1.i32 = getelementptr inbounds i8, ptr %add.ptr.i31, i64 320, !dbg !965
  tail call void @llvm.prefetch.p0(ptr nonnull %add.ptr1.i32, i32 0, i32 3, i32 1), !dbg !965, !noalias !966
  %mul2.i33 = shl nuw nsw i64 %n.0.i2673, 3, !dbg !969
  %add.ptr3.i34 = getelementptr inbounds i8, ptr @XXH3_kSecret, i64 %mul2.i33, !dbg !970
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !873, metadata !DIExpression()), !dbg !971
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i31, metadata !878, metadata !DIExpression()), !dbg !971
  tail call void @llvm.dbg.value(metadata ptr %add.ptr3.i34, metadata !879, metadata !DIExpression()), !dbg !971
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !880, metadata !DIExpression()), !dbg !973
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i31, metadata !883, metadata !DIExpression()), !dbg !973
  tail call void @llvm.dbg.value(metadata ptr %add.ptr3.i34, metadata !885, metadata !DIExpression()), !dbg !973
  tail call void @llvm.dbg.value(metadata i64 0, metadata !886, metadata !DIExpression()), !dbg !973
  %60 = load <2 x i64>, ptr %add.ptr.i31, align 1, !dbg !974, !tbaa !374, !noalias !975
  tail call void @llvm.dbg.value(metadata <2 x i64> %60, metadata !887, metadata !DIExpression()), !dbg !978
  %61 = load <2 x i64>, ptr %add.ptr3.i34, align 8, !dbg !979, !tbaa !374, !noalias !975
  tail call void @llvm.dbg.value(metadata <2 x i64> %61, metadata !891, metadata !DIExpression()), !dbg !978
  %xor.i = xor <2 x i64> %61, %60, !dbg !980
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i, metadata !892, metadata !DIExpression()), !dbg !978
  %62 = bitcast <2 x i64> %xor.i to <4 x i32>, !dbg !981
  %permil.i.i46 = shufflevector <4 x i32> %62, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !981
  %63 = bitcast <4 x i32> %permil.i.i46 to <2 x i64>, !dbg !981
  tail call void @llvm.dbg.value(metadata <2 x i64> %63, metadata !893, metadata !DIExpression()), !dbg !978
  %64 = and <2 x i64> %xor.i, <i64 4294967295, i64 4294967295>, !dbg !982
  %65 = and <2 x i64> %63, <i64 4294967295, i64 4294967295>, !dbg !982
  %66 = mul nuw <2 x i64> %65, %64, !dbg !982
  tail call void @llvm.dbg.value(metadata <2 x i64> %66, metadata !894, metadata !DIExpression()), !dbg !978
  %67 = shufflevector <2 x i64> %60, <2 x i64> poison, <2 x i32> <i32 1, i32 0>, !dbg !983
  tail call void @llvm.dbg.value(metadata <2 x i64> %67, metadata !895, metadata !DIExpression()), !dbg !978
  %add.i58 = add <2 x i64> %acc.i.sroa.0.3, %67, !dbg !984
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i58, metadata !896, metadata !DIExpression()), !dbg !978
  %add.i = add <2 x i64> %add.i58, %66, !dbg !985
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 1, metadata !886, metadata !DIExpression()), !dbg !973
  %add.ptr.i.i41.1 = getelementptr inbounds i8, ptr %add.ptr.i31, i64 16, !dbg !986
  %68 = load <2 x i64>, ptr %add.ptr.i.i41.1, align 1, !dbg !974, !tbaa !374, !noalias !975
  tail call void @llvm.dbg.value(metadata <2 x i64> %68, metadata !887, metadata !DIExpression()), !dbg !978
  %add.ptr1.i.i43.1 = getelementptr inbounds i8, ptr %add.ptr3.i34, i64 16, !dbg !987
  %69 = load <2 x i64>, ptr %add.ptr1.i.i43.1, align 8, !dbg !979, !tbaa !374, !noalias !975
  tail call void @llvm.dbg.value(metadata <2 x i64> %69, metadata !891, metadata !DIExpression()), !dbg !978
  %xor.i.1 = xor <2 x i64> %69, %68, !dbg !980
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i.1, metadata !892, metadata !DIExpression()), !dbg !978
  %70 = bitcast <2 x i64> %xor.i.1 to <4 x i32>, !dbg !981
  %permil.i.i46.1 = shufflevector <4 x i32> %70, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !981
  %71 = bitcast <4 x i32> %permil.i.i46.1 to <2 x i64>, !dbg !981
  tail call void @llvm.dbg.value(metadata <2 x i64> %71, metadata !893, metadata !DIExpression()), !dbg !978
  %72 = and <2 x i64> %xor.i.1, <i64 4294967295, i64 4294967295>, !dbg !982
  %73 = and <2 x i64> %71, <i64 4294967295, i64 4294967295>, !dbg !982
  %74 = mul nuw <2 x i64> %73, %72, !dbg !982
  tail call void @llvm.dbg.value(metadata <2 x i64> %74, metadata !894, metadata !DIExpression()), !dbg !978
  %75 = shufflevector <2 x i64> %68, <2 x i64> poison, <2 x i32> <i32 1, i32 0>, !dbg !983
  tail call void @llvm.dbg.value(metadata <2 x i64> %75, metadata !895, metadata !DIExpression()), !dbg !978
  %add.i58.1 = add <2 x i64> %acc.i.sroa.13.3, %75, !dbg !984
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i58.1, metadata !896, metadata !DIExpression()), !dbg !978
  %add.i.1 = add <2 x i64> %add.i58.1, %74, !dbg !985
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i.1, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 2, metadata !886, metadata !DIExpression()), !dbg !973
  %add.ptr.i.i41.2 = getelementptr inbounds i8, ptr %add.ptr.i31, i64 32, !dbg !986
  %76 = load <2 x i64>, ptr %add.ptr.i.i41.2, align 1, !dbg !974, !tbaa !374, !noalias !975
  tail call void @llvm.dbg.value(metadata <2 x i64> %76, metadata !887, metadata !DIExpression()), !dbg !978
  %add.ptr1.i.i43.2 = getelementptr inbounds i8, ptr %add.ptr3.i34, i64 32, !dbg !987
  %77 = load <2 x i64>, ptr %add.ptr1.i.i43.2, align 8, !dbg !979, !tbaa !374, !noalias !975
  tail call void @llvm.dbg.value(metadata <2 x i64> %77, metadata !891, metadata !DIExpression()), !dbg !978
  %xor.i.2 = xor <2 x i64> %77, %76, !dbg !980
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i.2, metadata !892, metadata !DIExpression()), !dbg !978
  %78 = bitcast <2 x i64> %xor.i.2 to <4 x i32>, !dbg !981
  %permil.i.i46.2 = shufflevector <4 x i32> %78, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !981
  %79 = bitcast <4 x i32> %permil.i.i46.2 to <2 x i64>, !dbg !981
  tail call void @llvm.dbg.value(metadata <2 x i64> %79, metadata !893, metadata !DIExpression()), !dbg !978
  %80 = and <2 x i64> %xor.i.2, <i64 4294967295, i64 4294967295>, !dbg !982
  %81 = and <2 x i64> %79, <i64 4294967295, i64 4294967295>, !dbg !982
  %82 = mul nuw <2 x i64> %81, %80, !dbg !982
  tail call void @llvm.dbg.value(metadata <2 x i64> %82, metadata !894, metadata !DIExpression()), !dbg !978
  %83 = shufflevector <2 x i64> %76, <2 x i64> poison, <2 x i32> <i32 1, i32 0>, !dbg !983
  tail call void @llvm.dbg.value(metadata <2 x i64> %83, metadata !895, metadata !DIExpression()), !dbg !978
  %add.i58.2 = add <2 x i64> %acc.i.sroa.23.3, %83, !dbg !984
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i58.2, metadata !896, metadata !DIExpression()), !dbg !978
  %add.i.2 = add <2 x i64> %add.i58.2, %82, !dbg !985
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i.2, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 3, metadata !886, metadata !DIExpression()), !dbg !973
  %add.ptr.i.i41.3 = getelementptr inbounds i8, ptr %add.ptr.i31, i64 48, !dbg !986
  %84 = load <2 x i64>, ptr %add.ptr.i.i41.3, align 1, !dbg !974, !tbaa !374, !noalias !975
  tail call void @llvm.dbg.value(metadata <2 x i64> %84, metadata !887, metadata !DIExpression()), !dbg !978
  %add.ptr1.i.i43.3 = getelementptr inbounds i8, ptr %add.ptr3.i34, i64 48, !dbg !987
  %85 = load <2 x i64>, ptr %add.ptr1.i.i43.3, align 8, !dbg !979, !tbaa !374, !noalias !975
  tail call void @llvm.dbg.value(metadata <2 x i64> %85, metadata !891, metadata !DIExpression()), !dbg !978
  %xor.i.3 = xor <2 x i64> %85, %84, !dbg !980
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i.3, metadata !892, metadata !DIExpression()), !dbg !978
  %86 = bitcast <2 x i64> %xor.i.3 to <4 x i32>, !dbg !981
  %permil.i.i46.3 = shufflevector <4 x i32> %86, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !981
  %87 = bitcast <4 x i32> %permil.i.i46.3 to <2 x i64>, !dbg !981
  tail call void @llvm.dbg.value(metadata <2 x i64> %87, metadata !893, metadata !DIExpression()), !dbg !978
  %88 = and <2 x i64> %xor.i.3, <i64 4294967295, i64 4294967295>, !dbg !982
  %89 = and <2 x i64> %87, <i64 4294967295, i64 4294967295>, !dbg !982
  %90 = mul nuw <2 x i64> %89, %88, !dbg !982
  tail call void @llvm.dbg.value(metadata <2 x i64> %90, metadata !894, metadata !DIExpression()), !dbg !978
  %91 = shufflevector <2 x i64> %84, <2 x i64> poison, <2 x i32> <i32 1, i32 0>, !dbg !983
  tail call void @llvm.dbg.value(metadata <2 x i64> %91, metadata !895, metadata !DIExpression()), !dbg !978
  %add.i58.3 = add <2 x i64> %acc.i.sroa.33.3, %91, !dbg !984
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i58.3, metadata !896, metadata !DIExpression()), !dbg !978
  %add.i.3 = add <2 x i64> %add.i58.3, %90, !dbg !985
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i.3, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 4, metadata !886, metadata !DIExpression()), !dbg !973
  %inc.i39 = add nuw nsw i64 %n.0.i2673, 1, !dbg !988
  tail call void @llvm.dbg.value(metadata i64 %inc.i39, metadata !856, metadata !DIExpression()), !dbg !958
  %exitcond78.not = icmp eq i64 %inc.i39, %div940.i, !dbg !960
  br i1 %exitcond78.not, label %XXH3_accumulate.exit53, label %for.body.i29, !dbg !961, !llvm.loop !989

XXH3_accumulate.exit53:                           ; preds = %for.body.i29, %for.end.i
  %acc.i.sroa.33.4 = phi <2 x i64> [ %acc.i.sroa.33.2, %for.end.i ], [ %add.i.3, %for.body.i29 ], !dbg !811
  %acc.i.sroa.23.4 = phi <2 x i64> [ %acc.i.sroa.23.2, %for.end.i ], [ %add.i.2, %for.body.i29 ], !dbg !811
  %acc.i.sroa.13.4 = phi <2 x i64> [ %acc.i.sroa.13.2, %for.end.i ], [ %add.i.1, %for.body.i29 ], !dbg !811
  %acc.i.sroa.0.4 = phi <2 x i64> [ %acc.i.sroa.0.2, %for.end.i ], [ %add.i, %for.body.i29 ], !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.0.4, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.13.4, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.23.4, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata <2 x i64> %acc.i.sroa.33.4, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 128)), !dbg !811
  %add.ptr12.i = getelementptr inbounds i8, ptr %input, i64 %len, !dbg !991
  %add.ptr13.i = getelementptr inbounds i8, ptr %add.ptr12.i, i64 -64, !dbg !992
  tail call void @llvm.dbg.value(metadata ptr %add.ptr13.i, metadata !833, metadata !DIExpression()), !dbg !993
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !873, metadata !DIExpression()), !dbg !994
  tail call void @llvm.dbg.value(metadata ptr %add.ptr13.i, metadata !878, metadata !DIExpression()), !dbg !994
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !879, metadata !DIExpression()), !dbg !994
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !880, metadata !DIExpression()), !dbg !996
  tail call void @llvm.dbg.value(metadata ptr %add.ptr13.i, metadata !883, metadata !DIExpression()), !dbg !996
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !885, metadata !DIExpression()), !dbg !996
  tail call void @llvm.dbg.value(metadata i64 0, metadata !886, metadata !DIExpression()), !dbg !996
  %92 = load <2 x i64>, ptr %add.ptr13.i, align 1, !dbg !997, !tbaa !374, !noalias !998
  tail call void @llvm.dbg.value(metadata <2 x i64> %92, metadata !887, metadata !DIExpression()), !dbg !1001
  tail call void @llvm.dbg.value(metadata <2 x i64> <i64 -1556992608276218209, i64 -4196251135427498811>, metadata !891, metadata !DIExpression()), !dbg !1001
  %xor.i57 = xor <2 x i64> %92, <i64 -1556992608276218209, i64 -4196251135427498811>, !dbg !1002
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i57, metadata !892, metadata !DIExpression()), !dbg !1001
  %93 = bitcast <2 x i64> %xor.i57 to <4 x i32>, !dbg !1003
  %permil.i.i = shufflevector <4 x i32> %93, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !1003
  %94 = bitcast <4 x i32> %permil.i.i to <2 x i64>, !dbg !1003
  tail call void @llvm.dbg.value(metadata <2 x i64> %94, metadata !893, metadata !DIExpression()), !dbg !1001
  %95 = and <2 x i64> %xor.i57, <i64 4294967295, i64 4294967295>, !dbg !1004
  %96 = and <2 x i64> %94, <i64 4294967295, i64 4294967295>, !dbg !1004
  %97 = mul nuw <2 x i64> %96, %95, !dbg !1004
  tail call void @llvm.dbg.value(metadata <2 x i64> %97, metadata !894, metadata !DIExpression()), !dbg !1001
  %98 = shufflevector <2 x i64> %92, <2 x i64> poison, <2 x i32> <i32 1, i32 0>, !dbg !1005
  tail call void @llvm.dbg.value(metadata <2 x i64> %98, metadata !895, metadata !DIExpression()), !dbg !1001
  %add.i63 = add <2 x i64> %acc.i.sroa.0.4, %98, !dbg !1006
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i63, metadata !896, metadata !DIExpression()), !dbg !1001
  %add.i62 = add <2 x i64> %add.i63, %97, !dbg !1007
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i62, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 1, metadata !886, metadata !DIExpression()), !dbg !996
  %add.ptr.i.i.1 = getelementptr inbounds i8, ptr %add.ptr12.i, i64 -48, !dbg !1008
  %99 = load <2 x i64>, ptr %add.ptr.i.i.1, align 1, !dbg !997, !tbaa !374, !noalias !998
  tail call void @llvm.dbg.value(metadata <2 x i64> %99, metadata !887, metadata !DIExpression()), !dbg !1001
  tail call void @llvm.dbg.value(metadata <2 x i64> <i64 1723580219865931905, i64 -3221803331004277491>, metadata !891, metadata !DIExpression()), !dbg !1001
  %xor.i57.1 = xor <2 x i64> %99, <i64 1723580219865931905, i64 -3221803331004277491>, !dbg !1002
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i57.1, metadata !892, metadata !DIExpression()), !dbg !1001
  %100 = bitcast <2 x i64> %xor.i57.1 to <4 x i32>, !dbg !1003
  %permil.i.i.1 = shufflevector <4 x i32> %100, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !1003
  %101 = bitcast <4 x i32> %permil.i.i.1 to <2 x i64>, !dbg !1003
  tail call void @llvm.dbg.value(metadata <2 x i64> %101, metadata !893, metadata !DIExpression()), !dbg !1001
  %102 = and <2 x i64> %xor.i57.1, <i64 4294967295, i64 4294967295>, !dbg !1004
  %103 = and <2 x i64> %101, <i64 4294967295, i64 4294967295>, !dbg !1004
  %104 = mul nuw <2 x i64> %103, %102, !dbg !1004
  tail call void @llvm.dbg.value(metadata <2 x i64> %104, metadata !894, metadata !DIExpression()), !dbg !1001
  %105 = shufflevector <2 x i64> %99, <2 x i64> poison, <2 x i32> <i32 1, i32 0>, !dbg !1005
  tail call void @llvm.dbg.value(metadata <2 x i64> %105, metadata !895, metadata !DIExpression()), !dbg !1001
  %add.i63.1 = add <2 x i64> %acc.i.sroa.13.4, %105, !dbg !1006
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i63.1, metadata !896, metadata !DIExpression()), !dbg !1001
  %add.i62.1 = add <2 x i64> %add.i63.1, %104, !dbg !1007
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i62.1, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 2, metadata !886, metadata !DIExpression()), !dbg !996
  %add.ptr.i.i.2 = getelementptr inbounds i8, ptr %add.ptr12.i, i64 -32, !dbg !1008
  %106 = load <2 x i64>, ptr %add.ptr.i.i.2, align 1, !dbg !997, !tbaa !374, !noalias !998
  tail call void @llvm.dbg.value(metadata <2 x i64> %106, metadata !887, metadata !DIExpression()), !dbg !1001
  tail call void @llvm.dbg.value(metadata <2 x i64> <i64 3143064850383918358, i64 -8071399103737053674>, metadata !891, metadata !DIExpression()), !dbg !1001
  %xor.i57.2 = xor <2 x i64> %106, <i64 3143064850383918358, i64 -8071399103737053674>, !dbg !1002
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i57.2, metadata !892, metadata !DIExpression()), !dbg !1001
  %107 = bitcast <2 x i64> %xor.i57.2 to <4 x i32>, !dbg !1003
  %permil.i.i.2 = shufflevector <4 x i32> %107, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !1003
  %108 = bitcast <4 x i32> %permil.i.i.2 to <2 x i64>, !dbg !1003
  tail call void @llvm.dbg.value(metadata <2 x i64> %108, metadata !893, metadata !DIExpression()), !dbg !1001
  %109 = and <2 x i64> %xor.i57.2, <i64 4294967295, i64 4294967295>, !dbg !1004
  %110 = and <2 x i64> %108, <i64 4294967295, i64 4294967295>, !dbg !1004
  %111 = mul nuw <2 x i64> %110, %109, !dbg !1004
  tail call void @llvm.dbg.value(metadata <2 x i64> %111, metadata !894, metadata !DIExpression()), !dbg !1001
  %112 = shufflevector <2 x i64> %106, <2 x i64> poison, <2 x i32> <i32 1, i32 0>, !dbg !1005
  tail call void @llvm.dbg.value(metadata <2 x i64> %112, metadata !895, metadata !DIExpression()), !dbg !1001
  %add.i63.2 = add <2 x i64> %acc.i.sroa.23.4, %112, !dbg !1006
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i63.2, metadata !896, metadata !DIExpression()), !dbg !1001
  %add.i62.2 = add <2 x i64> %add.i63.2, %111, !dbg !1007
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i62.2, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 3, metadata !886, metadata !DIExpression()), !dbg !996
  %add.ptr.i.i.3 = getelementptr inbounds i8, ptr %add.ptr12.i, i64 -16, !dbg !1008
  %113 = load <2 x i64>, ptr %add.ptr.i.i.3, align 1, !dbg !997, !tbaa !374, !noalias !998
  tail call void @llvm.dbg.value(metadata <2 x i64> %113, metadata !887, metadata !DIExpression()), !dbg !1001
  tail call void @llvm.dbg.value(metadata <2 x i64> <i64 5030012605302946040, i64 -5825401622958753077>, metadata !891, metadata !DIExpression()), !dbg !1001
  %xor.i57.3 = xor <2 x i64> %113, <i64 5030012605302946040, i64 -5825401622958753077>, !dbg !1002
  tail call void @llvm.dbg.value(metadata <2 x i64> %xor.i57.3, metadata !892, metadata !DIExpression()), !dbg !1001
  %114 = bitcast <2 x i64> %xor.i57.3 to <4 x i32>, !dbg !1003
  %permil.i.i.3 = shufflevector <4 x i32> %114, <4 x i32> poison, <4 x i32> <i32 1, i32 0, i32 3, i32 0>, !dbg !1003
  %115 = bitcast <4 x i32> %permil.i.i.3 to <2 x i64>, !dbg !1003
  tail call void @llvm.dbg.value(metadata <2 x i64> %115, metadata !893, metadata !DIExpression()), !dbg !1001
  %116 = and <2 x i64> %xor.i57.3, <i64 4294967295, i64 4294967295>, !dbg !1004
  %117 = and <2 x i64> %115, <i64 4294967295, i64 4294967295>, !dbg !1004
  %118 = mul nuw <2 x i64> %117, %116, !dbg !1004
  tail call void @llvm.dbg.value(metadata <2 x i64> %118, metadata !894, metadata !DIExpression()), !dbg !1001
  %119 = shufflevector <2 x i64> %113, <2 x i64> poison, <2 x i32> <i32 1, i32 0>, !dbg !1005
  tail call void @llvm.dbg.value(metadata <2 x i64> %119, metadata !895, metadata !DIExpression()), !dbg !1001
  %add.i63.3 = add <2 x i64> %acc.i.sroa.33.4, %119, !dbg !1006
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i63.3, metadata !896, metadata !DIExpression()), !dbg !1001
  %add.i62.3 = add <2 x i64> %add.i63.3, %118, !dbg !1007
  tail call void @llvm.dbg.value(metadata <2 x i64> %add.i62.3, metadata !809, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 128)), !dbg !811
  tail call void @llvm.dbg.value(metadata i64 4, metadata !886, metadata !DIExpression()), !dbg !996
  %mul.i = mul i64 %len, -7046029288634856825, !dbg !1009
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !1010, metadata !DIExpression()), !dbg !1021
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1017, metadata !DIExpression()), !dbg !1021
  tail call void @llvm.dbg.value(metadata i64 %mul.i, metadata !1018, metadata !DIExpression()), !dbg !1021
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1020, metadata !DIExpression()), !dbg !1021
  tail call void @llvm.dbg.value(metadata i64 %mul.i, metadata !1019, metadata !DIExpression()), !dbg !1021
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !1023, metadata !DIExpression()), !dbg !1029
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1028, metadata !DIExpression()), !dbg !1029
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !227, metadata !DIExpression()), !dbg !1034
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !232, metadata !DIExpression()), !dbg !1034
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !241, metadata !DIExpression()), !dbg !1036
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !246, metadata !DIExpression()), !dbg !1036
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !247, metadata !DIExpression()), !dbg !1036
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1036
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1036
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1034
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1034
  tail call void @llvm.dbg.value(metadata i64 1, metadata !1020, metadata !DIExpression()), !dbg !1021
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !1019, metadata !DIExpression()), !dbg !1021
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1028, metadata !DIExpression()), !dbg !1029
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !227, metadata !DIExpression()), !dbg !1034
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !232, metadata !DIExpression()), !dbg !1034
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !241, metadata !DIExpression()), !dbg !1036
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !246, metadata !DIExpression()), !dbg !1036
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !247, metadata !DIExpression()), !dbg !1036
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1036
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1036
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1034
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1034
  tail call void @llvm.dbg.value(metadata i64 2, metadata !1020, metadata !DIExpression()), !dbg !1021
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !1019, metadata !DIExpression()), !dbg !1021
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1028, metadata !DIExpression()), !dbg !1029
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !227, metadata !DIExpression()), !dbg !1034
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !232, metadata !DIExpression()), !dbg !1034
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !241, metadata !DIExpression()), !dbg !1036
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !246, metadata !DIExpression()), !dbg !1036
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !247, metadata !DIExpression()), !dbg !1036
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1036
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1036
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1034
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1034
  tail call void @llvm.dbg.value(metadata i64 3, metadata !1020, metadata !DIExpression()), !dbg !1021
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !1019, metadata !DIExpression()), !dbg !1021
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1028, metadata !DIExpression()), !dbg !1029
  %120 = shufflevector <2 x i64> %add.i62, <2 x i64> %add.i62.1, <2 x i32> <i32 0, i32 2>, !dbg !1038
  %121 = shufflevector <2 x i64> %add.i62.2, <2 x i64> %add.i62.3, <2 x i32> <i32 0, i32 2>, !dbg !1038
  %122 = shufflevector <2 x i64> %120, <2 x i64> %121, <4 x i32> <i32 0, i32 1, i32 2, i32 3>, !dbg !1038
  %123 = xor <4 x i64> %122, <i64 7914194659941938988, i64 -1839215637059881052, i64 5046485836271438973, i64 5920048007935066598>, !dbg !1038
  %124 = shufflevector <2 x i64> %add.i62, <2 x i64> %add.i62.1, <2 x i32> <i32 1, i32 3>, !dbg !1039
  %125 = shufflevector <2 x i64> %add.i62.2, <2 x i64> %add.i62.3, <2 x i32> <i32 1, i32 3>, !dbg !1039
  %126 = shufflevector <2 x i64> %124, <2 x i64> %125, <4 x i32> <i32 0, i32 1, i32 2, i32 3>, !dbg !1039
  %127 = xor <4 x i64> %126, <i64 -6611157965513653271, i64 -3433288310154277810, i64 -8055285457383852172, i64 7336514198459093435>, !dbg !1039
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !227, metadata !DIExpression()), !dbg !1034
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !232, metadata !DIExpression()), !dbg !1034
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !241, metadata !DIExpression()), !dbg !1036
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !246, metadata !DIExpression()), !dbg !1036
  %128 = zext <4 x i64> %123 to <4 x i128>, !dbg !1040
  %129 = zext <4 x i64> %127 to <4 x i128>, !dbg !1041
  %130 = mul nuw <4 x i128> %129, %128, !dbg !1042
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !247, metadata !DIExpression()), !dbg !1036
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1036
  %131 = lshr <4 x i128> %130, <i128 64, i128 64, i128 64, i128 64>, !dbg !1043
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1036
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1034
  tail call void @llvm.dbg.value(metadata i128 undef, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1034
  %132 = xor <4 x i128> %131, %130, !dbg !1044
  %133 = trunc <4 x i128> %132 to <4 x i64>, !dbg !1044
  %134 = tail call i64 @llvm.vector.reduce.add.v4i64(<4 x i64> %133), !dbg !1045
  %op.rdx = add i64 %134, %mul.i, !dbg !1045
  tail call void @llvm.dbg.value(metadata i64 %op.rdx, metadata !1019, metadata !DIExpression()), !dbg !1021
  tail call void @llvm.dbg.value(metadata i64 4, metadata !1020, metadata !DIExpression()), !dbg !1021
  tail call void @llvm.dbg.value(metadata i64 %op.rdx, metadata !258, metadata !DIExpression()), !dbg !1046
  tail call void @llvm.dbg.value(metadata i64 %op.rdx, metadata !265, metadata !DIExpression()), !dbg !1048
  tail call void @llvm.dbg.value(metadata i32 37, metadata !270, metadata !DIExpression()), !dbg !1048
  %shr.i5.i.i = lshr i64 %op.rdx, 37, !dbg !1050
  %xor.i6.i.i = xor i64 %shr.i5.i.i, %op.rdx, !dbg !1051
  tail call void @llvm.dbg.value(metadata i64 %xor.i6.i.i, metadata !258, metadata !DIExpression()), !dbg !1046
  %mul.i.i = mul i64 %xor.i6.i.i, 1609587791953885689, !dbg !1052
  tail call void @llvm.dbg.value(metadata i64 %mul.i.i, metadata !258, metadata !DIExpression()), !dbg !1046
  tail call void @llvm.dbg.value(metadata i64 %mul.i.i, metadata !265, metadata !DIExpression()), !dbg !1053
  tail call void @llvm.dbg.value(metadata i32 32, metadata !270, metadata !DIExpression()), !dbg !1053
  %shr.i.i10.i = lshr i64 %mul.i.i, 32, !dbg !1055
  %xor.i.i.i = xor i64 %shr.i.i10.i, %mul.i.i, !dbg !1056
  tail call void @llvm.dbg.value(metadata i64 %xor.i.i.i, metadata !258, metadata !DIExpression()), !dbg !1046
  ret i64 %xor.i.i.i, !dbg !1057
}

; Function Attrs: nofree noinline norecurse nosync nounwind sanitize_thread memory(argmem: read) uwtable
define internal fastcc i64 @XXH3_len_129to240_64b(ptr noalias nocapture noundef readonly %input, i64 noundef %len) unnamed_addr #4 !dbg !1058 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %input, metadata !1061, metadata !DIExpression()), !dbg !1071
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !1062, metadata !DIExpression()), !dbg !1071
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !1063, metadata !DIExpression()), !dbg !1071
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !1064, metadata !DIExpression()), !dbg !1071
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1065, metadata !DIExpression()), !dbg !1071
  %mul = mul i64 %len, -7046029288634856825, !dbg !1072
  tail call void @llvm.dbg.value(metadata i64 %mul, metadata !1066, metadata !DIExpression()), !dbg !1073
  %conv = trunc i64 %len to i32, !dbg !1074
  tail call void @llvm.dbg.value(metadata i32 %conv, metadata !1068, metadata !DIExpression(DW_OP_constu, 4, DW_OP_shr, DW_OP_stack_value)), !dbg !1073
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1070, metadata !DIExpression()), !dbg !1073
  tail call void @llvm.dbg.value(metadata ptr %input, metadata !440, metadata !DIExpression()), !dbg !1075
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !445, metadata !DIExpression()), !dbg !1075
  tail call void @llvm.dbg.value(metadata i64 0, metadata !446, metadata !DIExpression()), !dbg !1075
  tail call void @llvm.dbg.value(metadata ptr %input, metadata !177, metadata !DIExpression()), !dbg !1080
  tail call void @llvm.dbg.value(metadata ptr %input, metadata !184, metadata !DIExpression()), !dbg !1082
  %val.0.copyload.i = load i64, ptr %input, align 1, !dbg !1084, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i, metadata !187, metadata !DIExpression()), !dbg !1082
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i, metadata !447, metadata !DIExpression()), !dbg !1088
  %add.ptr.i59 = getelementptr inbounds i8, ptr %input, i64 8, !dbg !1089
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59, metadata !177, metadata !DIExpression()), !dbg !1090
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59, metadata !184, metadata !DIExpression()), !dbg !1092
  %val.0.copyload.i67 = load i64, ptr %add.ptr.i59, align 1, !dbg !1094, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67, metadata !187, metadata !DIExpression()), !dbg !1092
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67, metadata !449, metadata !DIExpression()), !dbg !1088
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !177, metadata !DIExpression()), !dbg !1095
  tail call void @llvm.dbg.value(metadata ptr @XXH3_kSecret, metadata !184, metadata !DIExpression()), !dbg !1097
  tail call void @llvm.dbg.value(metadata i64 -4734510112055689544, metadata !187, metadata !DIExpression()), !dbg !1097
  %xor.i62 = xor i64 %val.0.copyload.i, -4734510112055689544, !dbg !1099
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !1100
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !1102
  tail call void @llvm.dbg.value(metadata i64 2066345149520216444, metadata !187, metadata !DIExpression()), !dbg !1102
  %xor5.i65 = xor i64 %val.0.copyload.i67, 2066345149520216444, !dbg !1104
  tail call void @llvm.dbg.value(metadata i64 %xor.i62, metadata !227, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65, metadata !232, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor.i62, metadata !241, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65, metadata !246, metadata !DIExpression()), !dbg !1107
  %conv.i.i = zext i64 %xor.i62 to i128, !dbg !1109
  %conv1.i.i = zext i64 %xor5.i65 to i128, !dbg !1110
  %mul.i.i = mul nuw i128 %conv1.i.i, %conv.i.i, !dbg !1111
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i, metadata !247, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1107
  %shr.i.i = lshr i128 %mul.i.i, 64, !dbg !1112
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1105
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1105
  %xor1.i = xor i128 %shr.i.i, %mul.i.i, !dbg !1113
  %xor.i70 = trunc i128 %xor1.i to i64, !dbg !1113
  %add = add i64 %mul, %xor.i70, !dbg !1114
  tail call void @llvm.dbg.value(metadata i64 1, metadata !1070, metadata !DIExpression()), !dbg !1073
  tail call void @llvm.dbg.value(metadata i64 %add, metadata !1066, metadata !DIExpression()), !dbg !1073
  %add.ptr.1 = getelementptr inbounds i8, ptr %input, i64 16, !dbg !1115
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.1, metadata !440, metadata !DIExpression()), !dbg !1075
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !445, metadata !DIExpression()), !dbg !1075
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.1, metadata !177, metadata !DIExpression()), !dbg !1080
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.1, metadata !184, metadata !DIExpression()), !dbg !1082
  %val.0.copyload.i.1 = load i64, ptr %add.ptr.1, align 1, !dbg !1084, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i.1, metadata !187, metadata !DIExpression()), !dbg !1082
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i.1, metadata !447, metadata !DIExpression()), !dbg !1088
  %add.ptr.i59.1 = getelementptr inbounds i8, ptr %input, i64 24, !dbg !1089
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59.1, metadata !177, metadata !DIExpression()), !dbg !1090
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59.1, metadata !184, metadata !DIExpression()), !dbg !1092
  %val.0.copyload.i67.1 = load i64, ptr %add.ptr.i59.1, align 1, !dbg !1094, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67.1, metadata !187, metadata !DIExpression()), !dbg !1092
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67.1, metadata !449, metadata !DIExpression()), !dbg !1088
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !1095
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !1097
  tail call void @llvm.dbg.value(metadata i64 -2623469361688619810, metadata !187, metadata !DIExpression()), !dbg !1097
  %xor.i62.1 = xor i64 %val.0.copyload.i.1, -2623469361688619810, !dbg !1099
  tail call void @llvm.dbg.value(metadata i64 2262974939099578482, metadata !187, metadata !DIExpression()), !dbg !1102
  %xor5.i65.1 = xor i64 %val.0.copyload.i67.1, 2262974939099578482, !dbg !1104
  tail call void @llvm.dbg.value(metadata i64 %xor.i62.1, metadata !227, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65.1, metadata !232, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor.i62.1, metadata !241, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65.1, metadata !246, metadata !DIExpression()), !dbg !1107
  %conv.i.i.1 = zext i64 %xor.i62.1 to i128, !dbg !1109
  %conv1.i.i.1 = zext i64 %xor5.i65.1 to i128, !dbg !1110
  %mul.i.i.1 = mul nuw i128 %conv1.i.i.1, %conv.i.i.1, !dbg !1111
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.1, metadata !247, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.1, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1107
  %shr.i.i.1 = lshr i128 %mul.i.i.1, 64, !dbg !1112
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.1, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.1, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1105
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.1, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1105
  %xor1.i.1 = xor i128 %shr.i.i.1, %mul.i.i.1, !dbg !1113
  %xor.i70.1 = trunc i128 %xor1.i.1 to i64, !dbg !1113
  %add.1 = add i64 %add, %xor.i70.1, !dbg !1114
  tail call void @llvm.dbg.value(metadata i64 2, metadata !1070, metadata !DIExpression()), !dbg !1073
  tail call void @llvm.dbg.value(metadata i64 %add.1, metadata !1066, metadata !DIExpression()), !dbg !1073
  %add.ptr.2 = getelementptr inbounds i8, ptr %input, i64 32, !dbg !1115
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.2, metadata !440, metadata !DIExpression()), !dbg !1075
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.2, metadata !177, metadata !DIExpression()), !dbg !1080
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.2, metadata !184, metadata !DIExpression()), !dbg !1082
  %val.0.copyload.i.2 = load i64, ptr %add.ptr.2, align 1, !dbg !1084, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i.2, metadata !187, metadata !DIExpression()), !dbg !1082
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i.2, metadata !447, metadata !DIExpression()), !dbg !1088
  %add.ptr.i59.2 = getelementptr inbounds i8, ptr %input, i64 40, !dbg !1089
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59.2, metadata !177, metadata !DIExpression()), !dbg !1090
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59.2, metadata !184, metadata !DIExpression()), !dbg !1092
  %val.0.copyload.i67.2 = load i64, ptr %add.ptr.i59.2, align 1, !dbg !1094, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67.2, metadata !187, metadata !DIExpression()), !dbg !1092
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67.2, metadata !449, metadata !DIExpression()), !dbg !1088
  tail call void @llvm.dbg.value(metadata i64 8711581037947681227, metadata !187, metadata !DIExpression()), !dbg !1097
  %xor.i62.2 = xor i64 %val.0.copyload.i.2, 8711581037947681227, !dbg !1099
  tail call void @llvm.dbg.value(metadata i64 2410270004345854594, metadata !187, metadata !DIExpression()), !dbg !1102
  %xor5.i65.2 = xor i64 %val.0.copyload.i67.2, 2410270004345854594, !dbg !1104
  tail call void @llvm.dbg.value(metadata i64 %xor.i62.2, metadata !227, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65.2, metadata !232, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor.i62.2, metadata !241, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65.2, metadata !246, metadata !DIExpression()), !dbg !1107
  %conv.i.i.2 = zext i64 %xor.i62.2 to i128, !dbg !1109
  %conv1.i.i.2 = zext i64 %xor5.i65.2 to i128, !dbg !1110
  %mul.i.i.2 = mul nuw i128 %conv1.i.i.2, %conv.i.i.2, !dbg !1111
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.2, metadata !247, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.2, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1107
  %shr.i.i.2 = lshr i128 %mul.i.i.2, 64, !dbg !1112
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.2, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.2, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1105
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.2, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1105
  %xor1.i.2 = xor i128 %shr.i.i.2, %mul.i.i.2, !dbg !1113
  %xor.i70.2 = trunc i128 %xor1.i.2 to i64, !dbg !1113
  %add.2 = add i64 %add.1, %xor.i70.2, !dbg !1114
  tail call void @llvm.dbg.value(metadata i64 3, metadata !1070, metadata !DIExpression()), !dbg !1073
  tail call void @llvm.dbg.value(metadata i64 %add.2, metadata !1066, metadata !DIExpression()), !dbg !1073
  %add.ptr.3 = getelementptr inbounds i8, ptr %input, i64 48, !dbg !1115
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.3, metadata !440, metadata !DIExpression()), !dbg !1075
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.3, metadata !177, metadata !DIExpression()), !dbg !1080
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.3, metadata !184, metadata !DIExpression()), !dbg !1082
  %val.0.copyload.i.3 = load i64, ptr %add.ptr.3, align 1, !dbg !1084, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i.3, metadata !187, metadata !DIExpression()), !dbg !1082
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i.3, metadata !447, metadata !DIExpression()), !dbg !1088
  %add.ptr.i59.3 = getelementptr inbounds i8, ptr %input, i64 56, !dbg !1089
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59.3, metadata !177, metadata !DIExpression()), !dbg !1090
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59.3, metadata !184, metadata !DIExpression()), !dbg !1092
  %val.0.copyload.i67.3 = load i64, ptr %add.ptr.i59.3, align 1, !dbg !1094, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67.3, metadata !187, metadata !DIExpression()), !dbg !1092
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67.3, metadata !449, metadata !DIExpression()), !dbg !1088
  tail call void @llvm.dbg.value(metadata i64 -8204357891075471176, metadata !187, metadata !DIExpression()), !dbg !1097
  %xor.i62.3 = xor i64 %val.0.copyload.i.3, -8204357891075471176, !dbg !1099
  tail call void @llvm.dbg.value(metadata i64 5487137525590930912, metadata !187, metadata !DIExpression()), !dbg !1102
  %xor5.i65.3 = xor i64 %val.0.copyload.i67.3, 5487137525590930912, !dbg !1104
  tail call void @llvm.dbg.value(metadata i64 %xor.i62.3, metadata !227, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65.3, metadata !232, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor.i62.3, metadata !241, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65.3, metadata !246, metadata !DIExpression()), !dbg !1107
  %conv.i.i.3 = zext i64 %xor.i62.3 to i128, !dbg !1109
  %conv1.i.i.3 = zext i64 %xor5.i65.3 to i128, !dbg !1110
  %mul.i.i.3 = mul nuw i128 %conv1.i.i.3, %conv.i.i.3, !dbg !1111
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.3, metadata !247, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.3, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1107
  %shr.i.i.3 = lshr i128 %mul.i.i.3, 64, !dbg !1112
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.3, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.3, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1105
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.3, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1105
  %xor1.i.3 = xor i128 %shr.i.i.3, %mul.i.i.3, !dbg !1113
  %xor.i70.3 = trunc i128 %xor1.i.3 to i64, !dbg !1113
  %add.3 = add i64 %add.2, %xor.i70.3, !dbg !1114
  tail call void @llvm.dbg.value(metadata i64 4, metadata !1070, metadata !DIExpression()), !dbg !1073
  tail call void @llvm.dbg.value(metadata i64 %add.3, metadata !1066, metadata !DIExpression()), !dbg !1073
  %add.ptr.4 = getelementptr inbounds i8, ptr %input, i64 64, !dbg !1115
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.4, metadata !440, metadata !DIExpression()), !dbg !1075
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.4, metadata !177, metadata !DIExpression()), !dbg !1080
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.4, metadata !184, metadata !DIExpression()), !dbg !1082
  %val.0.copyload.i.4 = load i64, ptr %add.ptr.4, align 1, !dbg !1084, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i.4, metadata !187, metadata !DIExpression()), !dbg !1082
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i.4, metadata !447, metadata !DIExpression()), !dbg !1088
  %add.ptr.i59.4 = getelementptr inbounds i8, ptr %input, i64 72, !dbg !1089
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59.4, metadata !177, metadata !DIExpression()), !dbg !1090
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59.4, metadata !184, metadata !DIExpression()), !dbg !1092
  %val.0.copyload.i67.4 = load i64, ptr %add.ptr.i59.4, align 1, !dbg !1094, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67.4, metadata !187, metadata !DIExpression()), !dbg !1092
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67.4, metadata !449, metadata !DIExpression()), !dbg !1088
  tail call void @llvm.dbg.value(metadata i64 -3818837453329782724, metadata !187, metadata !DIExpression()), !dbg !1097
  %xor.i62.4 = xor i64 %val.0.copyload.i.4, -3818837453329782724, !dbg !1099
  tail call void @llvm.dbg.value(metadata i64 -6688317018830679928, metadata !187, metadata !DIExpression()), !dbg !1102
  %xor5.i65.4 = xor i64 %val.0.copyload.i67.4, -6688317018830679928, !dbg !1104
  tail call void @llvm.dbg.value(metadata i64 %xor.i62.4, metadata !227, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65.4, metadata !232, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor.i62.4, metadata !241, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65.4, metadata !246, metadata !DIExpression()), !dbg !1107
  %conv.i.i.4 = zext i64 %xor.i62.4 to i128, !dbg !1109
  %conv1.i.i.4 = zext i64 %xor5.i65.4 to i128, !dbg !1110
  %mul.i.i.4 = mul nuw i128 %conv1.i.i.4, %conv.i.i.4, !dbg !1111
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.4, metadata !247, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.4, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1107
  %shr.i.i.4 = lshr i128 %mul.i.i.4, 64, !dbg !1112
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.4, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.4, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1105
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.4, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1105
  %xor1.i.4 = xor i128 %shr.i.i.4, %mul.i.i.4, !dbg !1113
  %xor.i70.4 = trunc i128 %xor1.i.4 to i64, !dbg !1113
  %add.4 = add i64 %add.3, %xor.i70.4, !dbg !1114
  tail call void @llvm.dbg.value(metadata i64 5, metadata !1070, metadata !DIExpression()), !dbg !1073
  tail call void @llvm.dbg.value(metadata i64 %add.4, metadata !1066, metadata !DIExpression()), !dbg !1073
  %add.ptr.5 = getelementptr inbounds i8, ptr %input, i64 80, !dbg !1115
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.5, metadata !440, metadata !DIExpression()), !dbg !1075
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.5, metadata !177, metadata !DIExpression()), !dbg !1080
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.5, metadata !184, metadata !DIExpression()), !dbg !1082
  %val.0.copyload.i.5 = load i64, ptr %add.ptr.5, align 1, !dbg !1084, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i.5, metadata !187, metadata !DIExpression()), !dbg !1082
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i.5, metadata !447, metadata !DIExpression()), !dbg !1088
  %add.ptr.i59.5 = getelementptr inbounds i8, ptr %input, i64 88, !dbg !1089
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59.5, metadata !177, metadata !DIExpression()), !dbg !1090
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59.5, metadata !184, metadata !DIExpression()), !dbg !1092
  %val.0.copyload.i67.5 = load i64, ptr %add.ptr.i59.5, align 1, !dbg !1094, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67.5, metadata !187, metadata !DIExpression()), !dbg !1092
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67.5, metadata !449, metadata !DIExpression()), !dbg !1088
  tail call void @llvm.dbg.value(metadata i64 5690594596133299313, metadata !187, metadata !DIExpression()), !dbg !1097
  %xor.i62.5 = xor i64 %val.0.copyload.i.5, 5690594596133299313, !dbg !1099
  tail call void @llvm.dbg.value(metadata i64 -2833645246901970632, metadata !187, metadata !DIExpression()), !dbg !1102
  %xor5.i65.5 = xor i64 %val.0.copyload.i67.5, -2833645246901970632, !dbg !1104
  tail call void @llvm.dbg.value(metadata i64 %xor.i62.5, metadata !227, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65.5, metadata !232, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor.i62.5, metadata !241, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65.5, metadata !246, metadata !DIExpression()), !dbg !1107
  %conv.i.i.5 = zext i64 %xor.i62.5 to i128, !dbg !1109
  %conv1.i.i.5 = zext i64 %xor5.i65.5 to i128, !dbg !1110
  %mul.i.i.5 = mul nuw i128 %conv1.i.i.5, %conv.i.i.5, !dbg !1111
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.5, metadata !247, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.5, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1107
  %shr.i.i.5 = lshr i128 %mul.i.i.5, 64, !dbg !1112
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.5, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.5, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1105
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.5, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1105
  %xor1.i.5 = xor i128 %shr.i.i.5, %mul.i.i.5, !dbg !1113
  %xor.i70.5 = trunc i128 %xor1.i.5 to i64, !dbg !1113
  %add.5 = add i64 %add.4, %xor.i70.5, !dbg !1114
  tail call void @llvm.dbg.value(metadata i64 6, metadata !1070, metadata !DIExpression()), !dbg !1073
  tail call void @llvm.dbg.value(metadata i64 %add.5, metadata !1066, metadata !DIExpression()), !dbg !1073
  %add.ptr.6 = getelementptr inbounds i8, ptr %input, i64 96, !dbg !1115
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.6, metadata !440, metadata !DIExpression()), !dbg !1075
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.6, metadata !177, metadata !DIExpression()), !dbg !1080
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.6, metadata !184, metadata !DIExpression()), !dbg !1082
  %val.0.copyload.i.6 = load i64, ptr %add.ptr.6, align 1, !dbg !1084, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i.6, metadata !187, metadata !DIExpression()), !dbg !1082
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i.6, metadata !447, metadata !DIExpression()), !dbg !1088
  %add.ptr.i59.6 = getelementptr inbounds i8, ptr %input, i64 104, !dbg !1089
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59.6, metadata !177, metadata !DIExpression()), !dbg !1090
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59.6, metadata !184, metadata !DIExpression()), !dbg !1092
  %val.0.copyload.i67.6 = load i64, ptr %add.ptr.i59.6, align 1, !dbg !1094, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67.6, metadata !187, metadata !DIExpression()), !dbg !1092
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67.6, metadata !449, metadata !DIExpression()), !dbg !1088
  tail call void @llvm.dbg.value(metadata i64 4554437623014685352, metadata !187, metadata !DIExpression()), !dbg !1097
  %xor.i62.6 = xor i64 %val.0.copyload.i.6, 4554437623014685352, !dbg !1099
  tail call void @llvm.dbg.value(metadata i64 2111919702937427193, metadata !187, metadata !DIExpression()), !dbg !1102
  %xor5.i65.6 = xor i64 %val.0.copyload.i67.6, 2111919702937427193, !dbg !1104
  tail call void @llvm.dbg.value(metadata i64 %xor.i62.6, metadata !227, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65.6, metadata !232, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor.i62.6, metadata !241, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65.6, metadata !246, metadata !DIExpression()), !dbg !1107
  %conv.i.i.6 = zext i64 %xor.i62.6 to i128, !dbg !1109
  %conv1.i.i.6 = zext i64 %xor5.i65.6 to i128, !dbg !1110
  %mul.i.i.6 = mul nuw i128 %conv1.i.i.6, %conv.i.i.6, !dbg !1111
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.6, metadata !247, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.6, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1107
  %shr.i.i.6 = lshr i128 %mul.i.i.6, 64, !dbg !1112
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.6, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.6, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1105
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.6, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1105
  %xor1.i.6 = xor i128 %shr.i.i.6, %mul.i.i.6, !dbg !1113
  %xor.i70.6 = trunc i128 %xor1.i.6 to i64, !dbg !1113
  %add.6 = add i64 %add.5, %xor.i70.6, !dbg !1114
  tail call void @llvm.dbg.value(metadata i64 7, metadata !1070, metadata !DIExpression()), !dbg !1073
  tail call void @llvm.dbg.value(metadata i64 %add.6, metadata !1066, metadata !DIExpression()), !dbg !1073
  %add.ptr.7 = getelementptr inbounds i8, ptr %input, i64 112, !dbg !1115
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.7, metadata !440, metadata !DIExpression()), !dbg !1075
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.7, metadata !177, metadata !DIExpression()), !dbg !1080
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.7, metadata !184, metadata !DIExpression()), !dbg !1082
  %val.0.copyload.i.7 = load i64, ptr %add.ptr.7, align 1, !dbg !1084, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i.7, metadata !187, metadata !DIExpression()), !dbg !1082
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i.7, metadata !447, metadata !DIExpression()), !dbg !1088
  %add.ptr.i59.7 = getelementptr inbounds i8, ptr %input, i64 120, !dbg !1089
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59.7, metadata !177, metadata !DIExpression()), !dbg !1090
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i59.7, metadata !184, metadata !DIExpression()), !dbg !1092
  %val.0.copyload.i67.7 = load i64, ptr %add.ptr.i59.7, align 1, !dbg !1094, !noalias !1085
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67.7, metadata !187, metadata !DIExpression()), !dbg !1092
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i67.7, metadata !449, metadata !DIExpression()), !dbg !1088
  tail call void @llvm.dbg.value(metadata i64 3556072174620004746, metadata !187, metadata !DIExpression()), !dbg !1097
  %xor.i62.7 = xor i64 %val.0.copyload.i.7, 3556072174620004746, !dbg !1099
  tail call void @llvm.dbg.value(metadata i64 7238261902898274248, metadata !187, metadata !DIExpression()), !dbg !1102
  %xor5.i65.7 = xor i64 %val.0.copyload.i67.7, 7238261902898274248, !dbg !1104
  tail call void @llvm.dbg.value(metadata i64 %xor.i62.7, metadata !227, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65.7, metadata !232, metadata !DIExpression()), !dbg !1105
  tail call void @llvm.dbg.value(metadata i64 %xor.i62.7, metadata !241, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i64 %xor5.i65.7, metadata !246, metadata !DIExpression()), !dbg !1107
  %conv.i.i.7 = zext i64 %xor.i62.7 to i128, !dbg !1109
  %conv1.i.i.7 = zext i64 %xor5.i65.7 to i128, !dbg !1110
  %mul.i.i.7 = mul nuw i128 %conv1.i.i.7, %conv.i.i.7, !dbg !1111
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.7, metadata !247, metadata !DIExpression()), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.7, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1107
  %shr.i.i.7 = lshr i128 %mul.i.i.7, 64, !dbg !1112
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.7, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1107
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i.7, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1105
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i.7, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1105
  %xor1.i.7 = xor i128 %shr.i.i.7, %mul.i.i.7, !dbg !1113
  %xor.i70.7 = trunc i128 %xor1.i.7 to i64, !dbg !1113
  %add.7 = add i64 %add.6, %xor.i70.7, !dbg !1114
  tail call void @llvm.dbg.value(metadata i64 %add.7, metadata !1066, metadata !DIExpression()), !dbg !1073
  tail call void @llvm.dbg.value(metadata i64 8, metadata !1070, metadata !DIExpression()), !dbg !1073
  tail call void @llvm.dbg.value(metadata i64 %add.7, metadata !258, metadata !DIExpression()), !dbg !1116
  tail call void @llvm.dbg.value(metadata i64 %add.7, metadata !265, metadata !DIExpression()), !dbg !1118
  tail call void @llvm.dbg.value(metadata i32 37, metadata !270, metadata !DIExpression()), !dbg !1118
  %shr.i5.i = lshr i64 %add.7, 37, !dbg !1120
  %xor.i6.i = xor i64 %shr.i5.i, %add.7, !dbg !1121
  tail call void @llvm.dbg.value(metadata i64 %xor.i6.i, metadata !258, metadata !DIExpression()), !dbg !1116
  %mul.i = mul i64 %xor.i6.i, 1609587791953885689, !dbg !1122
  tail call void @llvm.dbg.value(metadata i64 %mul.i, metadata !258, metadata !DIExpression()), !dbg !1116
  tail call void @llvm.dbg.value(metadata i64 %mul.i, metadata !265, metadata !DIExpression()), !dbg !1123
  tail call void @llvm.dbg.value(metadata i32 32, metadata !270, metadata !DIExpression()), !dbg !1123
  %shr.i.i71 = lshr i64 %mul.i, 32, !dbg !1125
  %xor.i.i = xor i64 %shr.i.i71, %mul.i, !dbg !1126
  tail call void @llvm.dbg.value(metadata i64 %xor.i.i, metadata !258, metadata !DIExpression()), !dbg !1116
  tail call void @llvm.dbg.value(metadata i64 %xor.i.i, metadata !1066, metadata !DIExpression()), !dbg !1073
  tail call void @llvm.dbg.value(metadata i32 8, metadata !1070, metadata !DIExpression()), !dbg !1073
  %cmp897 = icmp ugt i32 %conv, 143, !dbg !1127
  br i1 %cmp897, label %for.body10.preheader, label %for.end22, !dbg !1130

for.body10.preheader:                             ; preds = %entry
  %div49 = lshr i64 %len, 4
  %wide.trip.count = and i64 %div49, 268435455, !dbg !1127
  tail call void @llvm.dbg.value(metadata i64 %div49, metadata !1068, metadata !DIExpression()), !dbg !1073
  %0 = add nsw i64 %wide.trip.count, -8, !dbg !1130
  %min.iters.check = icmp ult i64 %0, 2, !dbg !1130
  br i1 %min.iters.check, label %for.body10.preheader5, label %vector.ph, !dbg !1130

vector.ph:                                        ; preds = %for.body10.preheader
  %n.mod.vf = and i64 %div49, 1, !dbg !1130
  %n.vec = sub nsw i64 %0, %n.mod.vf, !dbg !1130
  %ind.end = add nsw i64 %n.vec, 8, !dbg !1130
  %1 = insertelement <2 x i64> <i64 poison, i64 0>, i64 %xor.i.i, i64 0, !dbg !1130
  br label %vector.body, !dbg !1130

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.phi = phi <2 x i64> [ %1, %vector.ph ], [ %14, %vector.body ]
  %offset.idx = shl i64 %index, 4, !dbg !1131
  %2 = add i64 %offset.idx, 128, !dbg !1131
  %3 = getelementptr inbounds i8, ptr %input, i64 %2, !dbg !1133
  %gep = getelementptr i8, ptr getelementptr (i8, ptr @XXH3_kSecret, i64 -125), i64 %2, !dbg !1134
  %wide.vec = load <4 x i64>, ptr %3, align 1, !dbg !1135, !noalias !1139
  %wide.vec2 = load <4 x i64>, ptr %gep, align 1, !dbg !1142
  %4 = xor <4 x i64> %wide.vec2, %wide.vec, !dbg !1145
  %5 = shufflevector <4 x i64> %4, <4 x i64> poison, <2 x i32> <i32 0, i32 2>, !dbg !1145
  %6 = xor <4 x i64> %wide.vec2, %wide.vec, !dbg !1146
  %7 = shufflevector <4 x i64> %6, <4 x i64> poison, <2 x i32> <i32 1, i32 3>, !dbg !1146
  %8 = zext <2 x i64> %5 to <2 x i128>, !dbg !1147
  %9 = zext <2 x i64> %7 to <2 x i128>, !dbg !1150
  %10 = mul nuw <2 x i128> %9, %8, !dbg !1151
  %11 = lshr <2 x i128> %10, <i128 64, i128 64>, !dbg !1152
  %12 = xor <2 x i128> %11, %10, !dbg !1153
  %13 = trunc <2 x i128> %12 to <2 x i64>, !dbg !1153
  %14 = add <2 x i64> %vec.phi, %13, !dbg !1154
  %index.next = add nuw i64 %index, 2
  %15 = icmp eq i64 %index.next, %n.vec
  br i1 %15, label %middle.block, label %vector.body, !llvm.loop !1155

middle.block:                                     ; preds = %vector.body
  %16 = tail call i64 @llvm.vector.reduce.add.v2i64(<2 x i64> %14), !dbg !1130
  %cmp.n = icmp eq i64 %n.mod.vf, 0, !dbg !1130
  br i1 %cmp.n, label %for.end22, label %for.body10.preheader5, !dbg !1130

for.body10.preheader5:                            ; preds = %for.body10.preheader, %middle.block
  %indvars.iv.ph = phi i64 [ 8, %for.body10.preheader ], [ %ind.end, %middle.block ]
  %acc.198.ph = phi i64 [ %xor.i.i, %for.body10.preheader ], [ %16, %middle.block ]
  br label %for.body10, !dbg !1130

for.body10:                                       ; preds = %for.body10.preheader5, %for.body10
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.body10 ], [ %indvars.iv.ph, %for.body10.preheader5 ]
  %acc.198 = phi i64 [ %add19, %for.body10 ], [ %acc.198.ph, %for.body10.preheader5 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1070, metadata !DIExpression()), !dbg !1073
  tail call void @llvm.dbg.value(metadata i64 %acc.198, metadata !1066, metadata !DIExpression()), !dbg !1073
  %17 = shl nsw i64 %indvars.iv, 4, !dbg !1131
  %add.ptr13 = getelementptr inbounds i8, ptr %input, i64 %17, !dbg !1133
  %18 = getelementptr i8, ptr @XXH3_kSecret, i64 %17, !dbg !1159
  %add.ptr17 = getelementptr i8, ptr %18, i64 -125, !dbg !1134
  tail call void @llvm.dbg.value(metadata ptr %add.ptr13, metadata !440, metadata !DIExpression()), !dbg !1160
  tail call void @llvm.dbg.value(metadata ptr %add.ptr17, metadata !445, metadata !DIExpression()), !dbg !1160
  tail call void @llvm.dbg.value(metadata i64 0, metadata !446, metadata !DIExpression()), !dbg !1160
  tail call void @llvm.dbg.value(metadata ptr %add.ptr13, metadata !177, metadata !DIExpression()), !dbg !1161
  tail call void @llvm.dbg.value(metadata ptr %add.ptr13, metadata !184, metadata !DIExpression()), !dbg !1162
  %val.0.copyload.i72 = load i64, ptr %add.ptr13, align 1, !dbg !1135, !noalias !1139
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i72, metadata !187, metadata !DIExpression()), !dbg !1162
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i72, metadata !447, metadata !DIExpression()), !dbg !1163
  %add.ptr.i51 = getelementptr inbounds i8, ptr %add.ptr13, i64 8, !dbg !1164
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i51, metadata !177, metadata !DIExpression()), !dbg !1165
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i51, metadata !184, metadata !DIExpression()), !dbg !1167
  %val.0.copyload.i73 = load i64, ptr %add.ptr.i51, align 1, !dbg !1169, !noalias !1139
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i73, metadata !187, metadata !DIExpression()), !dbg !1167
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i73, metadata !449, metadata !DIExpression()), !dbg !1163
  tail call void @llvm.dbg.value(metadata ptr %add.ptr17, metadata !177, metadata !DIExpression()), !dbg !1170
  tail call void @llvm.dbg.value(metadata ptr %add.ptr17, metadata !184, metadata !DIExpression()), !dbg !1171
  %val.0.copyload.i74 = load i64, ptr %add.ptr17, align 1, !dbg !1142
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i74, metadata !187, metadata !DIExpression()), !dbg !1171
  %xor.i54 = xor i64 %val.0.copyload.i74, %val.0.copyload.i72, !dbg !1145
  %add.ptr3.i = getelementptr i8, ptr %18, i64 -117, !dbg !1172
  tail call void @llvm.dbg.value(metadata ptr %add.ptr3.i, metadata !177, metadata !DIExpression()), !dbg !1173
  tail call void @llvm.dbg.value(metadata ptr %add.ptr3.i, metadata !184, metadata !DIExpression()), !dbg !1175
  %val.0.copyload.i75 = load i64, ptr %add.ptr3.i, align 1, !dbg !1177
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i75, metadata !187, metadata !DIExpression()), !dbg !1175
  %xor5.i56 = xor i64 %val.0.copyload.i75, %val.0.copyload.i73, !dbg !1146
  tail call void @llvm.dbg.value(metadata i64 %xor.i54, metadata !227, metadata !DIExpression()), !dbg !1178
  tail call void @llvm.dbg.value(metadata i64 %xor5.i56, metadata !232, metadata !DIExpression()), !dbg !1178
  tail call void @llvm.dbg.value(metadata i64 %xor.i54, metadata !241, metadata !DIExpression()), !dbg !1179
  tail call void @llvm.dbg.value(metadata i64 %xor5.i56, metadata !246, metadata !DIExpression()), !dbg !1179
  %conv.i.i76 = zext i64 %xor.i54 to i128, !dbg !1147
  %conv1.i.i77 = zext i64 %xor5.i56 to i128, !dbg !1150
  %mul.i.i78 = mul nuw i128 %conv1.i.i77, %conv.i.i76, !dbg !1151
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i78, metadata !247, metadata !DIExpression()), !dbg !1179
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i78, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1179
  %shr.i.i79 = lshr i128 %mul.i.i78, 64, !dbg !1152
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i79, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1179
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i78, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1178
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i79, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1178
  %xor1.i80 = xor i128 %shr.i.i79, %mul.i.i78, !dbg !1153
  %xor.i81 = trunc i128 %xor1.i80 to i64, !dbg !1153
  %add19 = add i64 %acc.198, %xor.i81, !dbg !1154
  tail call void @llvm.dbg.value(metadata i64 %add19, metadata !1066, metadata !DIExpression()), !dbg !1073
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !1180
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !1070, metadata !DIExpression()), !dbg !1073
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count, !dbg !1127
  br i1 %exitcond.not, label %for.end22, label %for.body10, !dbg !1130, !llvm.loop !1181

for.end22:                                        ; preds = %for.body10, %middle.block, %entry
  %acc.1.lcssa = phi i64 [ %xor.i.i, %entry ], [ %16, %middle.block ], [ %add19, %for.body10 ], !dbg !1073
  %add.ptr23 = getelementptr inbounds i8, ptr %input, i64 %len, !dbg !1182
  %add.ptr24 = getelementptr inbounds i8, ptr %add.ptr23, i64 -16, !dbg !1183
  tail call void @llvm.dbg.value(metadata ptr %add.ptr24, metadata !440, metadata !DIExpression()), !dbg !1184
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !445, metadata !DIExpression()), !dbg !1184
  tail call void @llvm.dbg.value(metadata i64 0, metadata !446, metadata !DIExpression()), !dbg !1184
  tail call void @llvm.dbg.value(metadata ptr %add.ptr24, metadata !177, metadata !DIExpression()), !dbg !1186
  tail call void @llvm.dbg.value(metadata ptr %add.ptr24, metadata !184, metadata !DIExpression()), !dbg !1188
  %val.0.copyload.i82 = load i64, ptr %add.ptr24, align 1, !dbg !1190, !noalias !1191
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i82, metadata !187, metadata !DIExpression()), !dbg !1188
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i82, metadata !447, metadata !DIExpression()), !dbg !1194
  %add.ptr.i = getelementptr inbounds i8, ptr %add.ptr23, i64 -8, !dbg !1195
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !177, metadata !DIExpression()), !dbg !1196
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !184, metadata !DIExpression()), !dbg !1198
  %val.0.copyload.i83 = load i64, ptr %add.ptr.i, align 1, !dbg !1200, !noalias !1191
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i83, metadata !187, metadata !DIExpression()), !dbg !1198
  tail call void @llvm.dbg.value(metadata i64 %val.0.copyload.i83, metadata !449, metadata !DIExpression()), !dbg !1194
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !1201
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !1203
  tail call void @llvm.dbg.value(metadata i64 8320639771003045937, metadata !187, metadata !DIExpression()), !dbg !1203
  %xor.i = xor i64 %val.0.copyload.i82, 8320639771003045937, !dbg !1205
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !177, metadata !DIExpression()), !dbg !1206
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !1208
  tail call void @llvm.dbg.value(metadata i64 -1453760514566526364, metadata !187, metadata !DIExpression()), !dbg !1208
  %xor5.i = xor i64 %val.0.copyload.i83, -1453760514566526364, !dbg !1210
  tail call void @llvm.dbg.value(metadata i64 %xor.i, metadata !227, metadata !DIExpression()), !dbg !1211
  tail call void @llvm.dbg.value(metadata i64 %xor5.i, metadata !232, metadata !DIExpression()), !dbg !1211
  tail call void @llvm.dbg.value(metadata i64 %xor.i, metadata !241, metadata !DIExpression()), !dbg !1213
  tail call void @llvm.dbg.value(metadata i64 %xor5.i, metadata !246, metadata !DIExpression()), !dbg !1213
  %conv.i.i84 = zext i64 %xor.i to i128, !dbg !1215
  %conv1.i.i85 = zext i64 %xor5.i to i128, !dbg !1216
  %mul.i.i86 = mul nuw i128 %conv1.i.i85, %conv.i.i84, !dbg !1217
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i86, metadata !247, metadata !DIExpression()), !dbg !1213
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i86, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1213
  %shr.i.i87 = lshr i128 %mul.i.i86, 64, !dbg !1218
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i87, metadata !249, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1213
  tail call void @llvm.dbg.value(metadata i128 %mul.i.i86, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !1211
  tail call void @llvm.dbg.value(metadata i128 %shr.i.i87, metadata !233, metadata !DIExpression(DW_OP_LLVM_convert, 128, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !1211
  %xor1.i88 = xor i128 %shr.i.i87, %mul.i.i86, !dbg !1219
  %xor.i89 = trunc i128 %xor1.i88 to i64, !dbg !1219
  %add28 = add i64 %acc.1.lcssa, %xor.i89, !dbg !1220
  tail call void @llvm.dbg.value(metadata i64 %add28, metadata !1066, metadata !DIExpression()), !dbg !1073
  tail call void @llvm.dbg.value(metadata i64 %add28, metadata !258, metadata !DIExpression()), !dbg !1221
  tail call void @llvm.dbg.value(metadata i64 %add28, metadata !265, metadata !DIExpression()), !dbg !1223
  tail call void @llvm.dbg.value(metadata i32 37, metadata !270, metadata !DIExpression()), !dbg !1223
  %shr.i5.i90 = lshr i64 %add28, 37, !dbg !1225
  %xor.i6.i91 = xor i64 %shr.i5.i90, %add28, !dbg !1226
  tail call void @llvm.dbg.value(metadata i64 %xor.i6.i91, metadata !258, metadata !DIExpression()), !dbg !1221
  %mul.i92 = mul i64 %xor.i6.i91, 1609587791953885689, !dbg !1227
  tail call void @llvm.dbg.value(metadata i64 %mul.i92, metadata !258, metadata !DIExpression()), !dbg !1221
  tail call void @llvm.dbg.value(metadata i64 %mul.i92, metadata !265, metadata !DIExpression()), !dbg !1228
  tail call void @llvm.dbg.value(metadata i32 32, metadata !270, metadata !DIExpression()), !dbg !1228
  %shr.i.i93 = lshr i64 %mul.i92, 32, !dbg !1230
  %xor.i.i94 = xor i64 %shr.i.i93, %mul.i92, !dbg !1231
  tail call void @llvm.dbg.value(metadata i64 %xor.i.i94, metadata !258, metadata !DIExpression()), !dbg !1221
  ret i64 %xor.i.i94, !dbg !1232
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fshl.i64(i64, i64, i64) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @llvm.prefetch.p0(ptr nocapture readonly, i32 immarg, i32 immarg, i32 immarg) #6

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #7

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vector.reduce.add.v4i64(<4 x i64>) #7

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vector.reduce.add.v2i64(<2 x i64>) #7

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #8 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare ptr @llvm.load.relative.i64(ptr, i64) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #7

attributes #0 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree norecurse nosync nounwind sanitize_thread memory(argmem: read, inaccessiblemem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nofree noinline norecurse nosync nounwind sanitize_thread memory(argmem: read, inaccessiblemem: readwrite) uwtable "min-legal-vector-width"="128" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree noinline norecurse nosync nounwind sanitize_thread memory(argmem: read) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) }
attributes #7 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #8 = { nounwind uwtable }
attributes #9 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!85, !86, !87, !88, !89, !90, !91}
!llvm.ident = !{!92}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "hash", scope: !2, file: !3, line: 9, type: !77, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !12, globals: !58, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "hash.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "a416e9d32a6ff5488b0e80d57d2784a0")
!4 = !{!5}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "hashfunc_type", file: !6, line: 7, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "./hash.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "7bf64ed462fb4e5d2a6ceb2b3243c634")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11}
!9 = !DIEnumerator(name: "JENKINS_HASH", value: 0)
!10 = !DIEnumerator(name: "MURMUR3_HASH", value: 1)
!11 = !DIEnumerator(name: "XXH3_HASH", value: 2)
!12 = !{!13, !17, !24, !26, !31, !33, !34, !41, !35, !43, !48, !54, !57}
!13 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !14, line: 26, baseType: !15)
!14 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!15 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !16, line: 42, baseType: !7)
!16 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !19)
!19 = !DIDerivedType(tag: DW_TAG_typedef, name: "xxh_u8", file: !20, line: 1426, baseType: !21)
!20 = !DIFile(filename: "./xxhash.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "573e63a686bcc82fe34b64d32d9185b2")
!21 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !14, line: 24, baseType: !22)
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !16, line: 38, baseType: !23)
!23 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!24 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint128_t", file: !3, baseType: !25)
!25 = !DIBasicType(name: "unsigned __int128", size: 128, encoding: DW_ATE_unsigned)
!26 = !DIDerivedType(tag: DW_TAG_typedef, name: "xxh_u64", file: !20, line: 2141, baseType: !27)
!27 = !DIDerivedType(tag: DW_TAG_typedef, name: "XXH64_hash_t", file: !20, line: 567, baseType: !28)
!28 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !14, line: 27, baseType: !29)
!29 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !16, line: 45, baseType: !30)
!30 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!31 = !DIDerivedType(tag: DW_TAG_typedef, name: "xxh_u32", file: !20, line: 1430, baseType: !32)
!32 = !DIDerivedType(tag: DW_TAG_typedef, name: "XXH32_hash_t", file: !20, line: 304, baseType: !13)
!33 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!34 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !35, size: 64)
!35 = !DIDerivedType(tag: DW_TAG_typedef, name: "__m128i", file: !36, line: 20, baseType: !37, align: 128)
!36 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/emmintrin.h", directory: "", checksumkind: CSK_MD5, checksum: "0223dffbc8120029379128bb08f32db5")
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !38, size: 128, flags: DIFlagVector, elements: !39)
!38 = !DIBasicType(name: "long long", size: 64, encoding: DW_ATE_signed)
!39 = !{!40}
!40 = !DISubrange(count: 2)
!41 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !42, size: 64)
!42 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !35)
!43 = !DIDerivedType(tag: DW_TAG_typedef, name: "__v4si", file: !44, line: 19, baseType: !45)
!44 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/xmmintrin.h", directory: "", checksumkind: CSK_MD5, checksum: "12c2064b0f538df1c02a0eeaf89f12c2")
!45 = !DICompositeType(tag: DW_TAG_array_type, baseType: !33, size: 128, flags: DIFlagVector, elements: !46)
!46 = !{!47}
!47 = !DISubrange(count: 4)
!48 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !49, size: 64)
!49 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !50)
!50 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__loadu_si128", file: !36, line: 3441, size: 128, elements: !51)
!51 = !{!52}
!52 = !DIDerivedType(tag: DW_TAG_member, name: "__v", scope: !50, file: !36, line: 3442, baseType: !53, size: 128, align: 8)
!53 = !DIDerivedType(tag: DW_TAG_typedef, name: "__m128i_u", file: !36, line: 23, baseType: !37, align: 8)
!54 = !DIDerivedType(tag: DW_TAG_typedef, name: "__v2du", file: !36, line: 33, baseType: !55)
!55 = !DICompositeType(tag: DW_TAG_array_type, baseType: !56, size: 128, flags: DIFlagVector, elements: !39)
!56 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!57 = !DIDerivedType(tag: DW_TAG_typedef, name: "__v2di", file: !36, line: 28, baseType: !37)
!58 = !{!59, !65, !67, !0, !72}
!59 = !DIGlobalVariableExpression(var: !60, expr: !DIExpression())
!60 = distinct !DIGlobalVariable(scope: null, file: !3, line: 19, type: !61, isLocal: true, isDefinition: true)
!61 = !DICompositeType(tag: DW_TAG_array_type, baseType: !62, size: 64, elements: !63)
!62 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!63 = !{!64}
!64 = !DISubrange(count: 8)
!65 = !DIGlobalVariableExpression(var: !66, expr: !DIExpression())
!66 = distinct !DIGlobalVariable(scope: null, file: !3, line: 23, type: !61, isLocal: true, isDefinition: true)
!67 = !DIGlobalVariableExpression(var: !68, expr: !DIExpression())
!68 = distinct !DIGlobalVariable(scope: null, file: !3, line: 27, type: !69, isLocal: true, isDefinition: true)
!69 = !DICompositeType(tag: DW_TAG_array_type, baseType: !62, size: 40, elements: !70)
!70 = !{!71}
!71 = !DISubrange(count: 5)
!72 = !DIGlobalVariableExpression(var: !73, expr: !DIExpression())
!73 = distinct !DIGlobalVariable(name: "XXH3_kSecret", scope: !2, file: !20, line: 3042, type: !74, isLocal: true, isDefinition: true, align: 512)
!74 = !DICompositeType(tag: DW_TAG_array_type, baseType: !18, size: 1536, elements: !75)
!75 = !{!76}
!76 = !DISubrange(count: 192)
!77 = !DIDerivedType(tag: DW_TAG_typedef, name: "hash_func", file: !6, line: 4, baseType: !78)
!78 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !79, size: 64)
!79 = !DISubroutineType(types: !80)
!80 = !{!13, !81, !83}
!81 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !82, size: 64)
!82 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!83 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !84, line: 18, baseType: !30)
!84 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!85 = !{i32 7, !"Dwarf Version", i32 5}
!86 = !{i32 2, !"Debug Info Version", i32 3}
!87 = !{i32 1, !"wchar_size", i32 4}
!88 = !{i32 8, !"PIC Level", i32 2}
!89 = !{i32 7, !"PIE Level", i32 2}
!90 = !{i32 7, !"uwtable", i32 2}
!91 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!92 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!93 = distinct !DISubprogram(name: "hash_init", scope: !3, file: !3, line: 15, type: !94, scopeLine: 15, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !96)
!94 = !DISubroutineType(types: !95)
!95 = !{!33, !5}
!96 = !{!97}
!97 = !DILocalVariable(name: "type", arg: 1, scope: !93, file: !3, line: 15, type: !5)
!98 = !DILocation(line: 0, scope: !93)
!99 = !DILocation(line: 16, column: 5, scope: !93)
!100 = !DILocation(line: 0, scope: !101)
!101 = distinct !DILexicalBlock(scope: !93, file: !3, line: 16, column: 18)
!102 = !{!103, !103, i64 0}
!103 = !{!"any pointer", !104, i64 0}
!104 = !{!"omnipotent char", !105, i64 0}
!105 = !{!"Simple C/C++ TBAA"}
!106 = !{!107, !103, i64 176}
!107 = !{!"settings", !108, i64 0, !109, i64 8, !109, i64 12, !109, i64 16, !103, i64 24, !109, i64 32, !109, i64 36, !109, i64 40, !103, i64 48, !103, i64 56, !109, i64 64, !110, i64 72, !109, i64 80, !109, i64 84, !109, i64 88, !104, i64 92, !109, i64 96, !109, i64 100, !111, i64 104, !109, i64 108, !109, i64 112, !109, i64 116, !109, i64 120, !109, i64 124, !109, i64 128, !111, i64 132, !111, i64 133, !111, i64 134, !111, i64 135, !111, i64 136, !111, i64 137, !109, i64 140, !110, i64 144, !109, i64 152, !109, i64 156, !111, i64 160, !109, i64 164, !111, i64 168, !111, i64 169, !103, i64 176, !109, i64 184, !109, i64 188, !109, i64 192, !109, i64 196, !110, i64 200, !110, i64 208, !109, i64 216, !111, i64 220, !109, i64 224, !109, i64 228, !109, i64 232, !109, i64 236, !109, i64 240, !111, i64 244, !111, i64 245, !111, i64 246, !109, i64 248, !109, i64 252, !109, i64 256, !109, i64 260, !109, i64 264, !109, i64 268, !109, i64 272, !109, i64 276, !109, i64 280, !109, i64 284, !110, i64 288, !110, i64 296, !111, i64 304, !109, i64 308, !109, i64 312, !103, i64 320, !109, i64 328}
!108 = !{!"long", !104, i64 0}
!109 = !{!"int", !104, i64 0}
!110 = !{!"double", !104, i64 0}
!111 = !{!"_Bool", !104, i64 0}
!112 = !DILocation(line: 33, column: 1, scope: !93)
!113 = distinct !DISubprogram(name: "XXH3_hash", scope: !3, file: !3, line: 11, type: !79, scopeLine: 11, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !114)
!114 = !{!115, !116}
!115 = !DILocalVariable(name: "key", arg: 1, scope: !113, file: !3, line: 11, type: !81)
!116 = !DILocalVariable(name: "length", arg: 2, scope: !113, file: !3, line: 11, type: !83)
!117 = !DILocation(line: 0, scope: !113)
!118 = !DILocalVariable(name: "input", arg: 1, scope: !119, file: !20, line: 4404, type: !81)
!119 = distinct !DISubprogram(name: "XXH_INLINE_XXH3_64bits", scope: !20, file: !20, line: 4404, type: !120, scopeLine: 4405, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !122)
!120 = !DISubroutineType(types: !121)
!121 = !{!27, !81, !83}
!122 = !{!118, !123}
!123 = !DILocalVariable(name: "len", arg: 2, scope: !119, file: !20, line: 4404, type: !83)
!124 = !DILocation(line: 0, scope: !119, inlinedAt: !125)
!125 = distinct !DILocation(line: 12, column: 22, scope: !113)
!126 = !DILocalVariable(name: "input", arg: 1, scope: !127, file: !20, line: 4379, type: !130)
!127 = distinct !DISubprogram(name: "XXH3_64bits_internal", scope: !20, file: !20, line: 4379, type: !128, scopeLine: 4382, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !136)
!128 = !DISubroutineType(types: !129)
!129 = !{!27, !130, !83, !27, !130, !83, !131}
!130 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !81)
!131 = !DIDerivedType(tag: DW_TAG_typedef, name: "XXH3_hashLong64_f", file: !20, line: 4375, baseType: !132)
!132 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !133, size: 64)
!133 = !DISubroutineType(types: !134)
!134 = !{!27, !130, !83, !27, !135, !83}
!135 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !17)
!136 = !{!126, !137, !138, !139, !140, !141}
!137 = !DILocalVariable(name: "len", arg: 2, scope: !127, file: !20, line: 4379, type: !83)
!138 = !DILocalVariable(name: "seed64", arg: 3, scope: !127, file: !20, line: 4380, type: !27)
!139 = !DILocalVariable(name: "secret", arg: 4, scope: !127, file: !20, line: 4380, type: !130)
!140 = !DILocalVariable(name: "secretLen", arg: 5, scope: !127, file: !20, line: 4380, type: !83)
!141 = !DILocalVariable(name: "f_hashLong", arg: 6, scope: !127, file: !20, line: 4381, type: !131)
!142 = !DILocation(line: 0, scope: !127, inlinedAt: !143)
!143 = distinct !DILocation(line: 4406, column: 12, scope: !119, inlinedAt: !125)
!144 = !DILocation(line: 4391, column: 13, scope: !145, inlinedAt: !143)
!145 = distinct !DILexicalBlock(scope: !127, file: !20, line: 4391, column: 9)
!146 = !DILocation(line: 4391, column: 9, scope: !127, inlinedAt: !143)
!147 = !DILocalVariable(name: "input", arg: 1, scope: !148, file: !20, line: 3357, type: !17)
!148 = distinct !DISubprogram(name: "XXH3_len_0to16_64b", scope: !20, file: !20, line: 3357, type: !149, scopeLine: 3358, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !151)
!149 = !DISubroutineType(types: !150)
!150 = !{!27, !17, !83, !17, !27}
!151 = !{!147, !152, !153, !154}
!152 = !DILocalVariable(name: "len", arg: 2, scope: !148, file: !20, line: 3357, type: !83)
!153 = !DILocalVariable(name: "secret", arg: 3, scope: !148, file: !20, line: 3357, type: !17)
!154 = !DILocalVariable(name: "seed", arg: 4, scope: !148, file: !20, line: 3357, type: !27)
!155 = !DILocation(line: 0, scope: !148, inlinedAt: !156)
!156 = distinct !DILocation(line: 4392, column: 16, scope: !145, inlinedAt: !143)
!157 = !DILocation(line: 3360, column: 13, scope: !158, inlinedAt: !156)
!158 = distinct !DILexicalBlock(scope: !159, file: !20, line: 3360, column: 13)
!159 = distinct !DILexicalBlock(scope: !148, file: !20, line: 3360, column: 5)
!160 = !DILocation(line: 3360, column: 13, scope: !159, inlinedAt: !156)
!161 = !{!"branch_weights", i32 2000, i32 1}
!162 = !DILocalVariable(name: "input", arg: 1, scope: !163, file: !20, line: 3340, type: !17)
!163 = distinct !DISubprogram(name: "XXH3_len_9to16_64b", scope: !20, file: !20, line: 3340, type: !149, scopeLine: 3341, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !164)
!164 = !{!162, !165, !166, !167, !168, !171, !172, !173, !174}
!165 = !DILocalVariable(name: "len", arg: 2, scope: !163, file: !20, line: 3340, type: !83)
!166 = !DILocalVariable(name: "secret", arg: 3, scope: !163, file: !20, line: 3340, type: !17)
!167 = !DILocalVariable(name: "seed", arg: 4, scope: !163, file: !20, line: 3340, type: !27)
!168 = !DILocalVariable(name: "bitflip1", scope: !169, file: !20, line: 3345, type: !170)
!169 = distinct !DILexicalBlock(scope: !163, file: !20, line: 3345, column: 5)
!170 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !26)
!171 = !DILocalVariable(name: "bitflip2", scope: !169, file: !20, line: 3346, type: !170)
!172 = !DILocalVariable(name: "input_lo", scope: !169, file: !20, line: 3347, type: !170)
!173 = !DILocalVariable(name: "input_hi", scope: !169, file: !20, line: 3348, type: !170)
!174 = !DILocalVariable(name: "acc", scope: !169, file: !20, line: 3349, type: !170)
!175 = !DILocation(line: 0, scope: !163, inlinedAt: !176)
!176 = distinct !DILocation(line: 3360, column: 42, scope: !158, inlinedAt: !156)
!177 = !DILocalVariable(name: "ptr", arg: 1, scope: !178, file: !20, line: 2241, type: !81)
!178 = distinct !DISubprogram(name: "XXH_readLE64", scope: !20, file: !20, line: 2241, type: !179, scopeLine: 2242, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !181)
!179 = !DISubroutineType(types: !180)
!180 = !{!26, !81}
!181 = !{!177}
!182 = !DILocation(line: 0, scope: !178, inlinedAt: !183)
!183 = distinct !DILocation(line: 3345, column: 35, scope: !169, inlinedAt: !176)
!184 = !DILocalVariable(name: "memPtr", arg: 1, scope: !185, file: !20, line: 2183, type: !81)
!185 = distinct !DISubprogram(name: "XXH_read64", scope: !20, file: !20, line: 2183, type: !179, scopeLine: 2184, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !186)
!186 = !{!184, !187}
!187 = !DILocalVariable(name: "val", scope: !185, file: !20, line: 2185, type: !26)
!188 = !DILocation(line: 0, scope: !185, inlinedAt: !189)
!189 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !183)
!190 = !DILocation(line: 0, scope: !178, inlinedAt: !191)
!191 = distinct !DILocation(line: 3345, column: 61, scope: !169, inlinedAt: !176)
!192 = !DILocation(line: 0, scope: !185, inlinedAt: !193)
!193 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !191)
!194 = !DILocation(line: 0, scope: !169, inlinedAt: !176)
!195 = !DILocation(line: 0, scope: !178, inlinedAt: !196)
!196 = distinct !DILocation(line: 3346, column: 35, scope: !169, inlinedAt: !176)
!197 = !DILocation(line: 0, scope: !185, inlinedAt: !198)
!198 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !196)
!199 = !DILocation(line: 0, scope: !178, inlinedAt: !200)
!200 = distinct !DILocation(line: 3346, column: 61, scope: !169, inlinedAt: !176)
!201 = !DILocation(line: 0, scope: !185, inlinedAt: !202)
!202 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !200)
!203 = !DILocation(line: 0, scope: !178, inlinedAt: !204)
!204 = distinct !DILocation(line: 3347, column: 34, scope: !169, inlinedAt: !176)
!205 = !DILocation(line: 0, scope: !185, inlinedAt: !206)
!206 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !204)
!207 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !206)
!208 = !DILocation(line: 3347, column: 64, scope: !169, inlinedAt: !176)
!209 = !DILocation(line: 3348, column: 53, scope: !169, inlinedAt: !176)
!210 = !DILocation(line: 3348, column: 59, scope: !169, inlinedAt: !176)
!211 = !DILocation(line: 0, scope: !178, inlinedAt: !212)
!212 = distinct !DILocation(line: 3348, column: 34, scope: !169, inlinedAt: !176)
!213 = !DILocation(line: 0, scope: !185, inlinedAt: !214)
!214 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !212)
!215 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !214)
!216 = !DILocation(line: 3348, column: 64, scope: !169, inlinedAt: !176)
!217 = !DILocalVariable(name: "x", arg: 1, scope: !218, file: !20, line: 2197, type: !26)
!218 = distinct !DISubprogram(name: "XXH_swap64", scope: !20, file: !20, line: 2197, type: !219, scopeLine: 2198, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !221)
!219 = !DISubroutineType(types: !220)
!220 = !{!26, !26}
!221 = !{!217}
!222 = !DILocation(line: 0, scope: !218, inlinedAt: !223)
!223 = distinct !DILocation(line: 3350, column: 29, scope: !169, inlinedAt: !176)
!224 = !DILocation(line: 2205, column: 49, scope: !218, inlinedAt: !223)
!225 = !DILocation(line: 3350, column: 27, scope: !169, inlinedAt: !176)
!226 = !DILocation(line: 3350, column: 50, scope: !169, inlinedAt: !176)
!227 = !DILocalVariable(name: "lhs", arg: 1, scope: !228, file: !20, line: 3227, type: !26)
!228 = distinct !DISubprogram(name: "XXH3_mul128_fold64", scope: !20, file: !20, line: 3227, type: !229, scopeLine: 3228, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !231)
!229 = !DISubroutineType(types: !230)
!230 = !{!26, !26, !26}
!231 = !{!227, !232, !233}
!232 = !DILocalVariable(name: "rhs", arg: 2, scope: !228, file: !20, line: 3227, type: !26)
!233 = !DILocalVariable(name: "product", scope: !228, file: !20, line: 3229, type: !234)
!234 = !DIDerivedType(tag: DW_TAG_typedef, name: "XXH_INLINE_XXH128_hash_t", file: !20, line: 788, baseType: !235)
!235 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !20, line: 785, size: 128, elements: !236)
!236 = !{!237, !238}
!237 = !DIDerivedType(tag: DW_TAG_member, name: "low64", scope: !235, file: !20, line: 786, baseType: !27, size: 64)
!238 = !DIDerivedType(tag: DW_TAG_member, name: "high64", scope: !235, file: !20, line: 787, baseType: !27, size: 64, offset: 64)
!239 = !DILocation(line: 0, scope: !228, inlinedAt: !240)
!240 = distinct !DILocation(line: 3351, column: 29, scope: !169, inlinedAt: !176)
!241 = !DILocalVariable(name: "lhs", arg: 1, scope: !242, file: !20, line: 3108, type: !26)
!242 = distinct !DISubprogram(name: "XXH_mult64to128", scope: !20, file: !20, line: 3108, type: !243, scopeLine: 3109, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !245)
!243 = !DISubroutineType(types: !244)
!244 = !{!234, !26, !26}
!245 = !{!241, !246, !247, !249}
!246 = !DILocalVariable(name: "rhs", arg: 2, scope: !242, file: !20, line: 3108, type: !26)
!247 = !DILocalVariable(name: "product", scope: !242, file: !20, line: 3129, type: !248)
!248 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !24)
!249 = !DILocalVariable(name: "r128", scope: !242, file: !20, line: 3130, type: !234)
!250 = !DILocation(line: 0, scope: !242, inlinedAt: !251)
!251 = distinct !DILocation(line: 3229, column: 29, scope: !228, inlinedAt: !240)
!252 = !DILocation(line: 3129, column: 33, scope: !242, inlinedAt: !251)
!253 = !DILocation(line: 3129, column: 52, scope: !242, inlinedAt: !251)
!254 = !DILocation(line: 3129, column: 50, scope: !242, inlinedAt: !251)
!255 = !DILocation(line: 3132, column: 37, scope: !242, inlinedAt: !251)
!256 = !DILocation(line: 3230, column: 26, scope: !228, inlinedAt: !240)
!257 = !DILocation(line: 3351, column: 27, scope: !169, inlinedAt: !176)
!258 = !DILocalVariable(name: "h64", arg: 1, scope: !259, file: !20, line: 3244, type: !26)
!259 = distinct !DISubprogram(name: "XXH3_avalanche", scope: !20, file: !20, line: 3244, type: !260, scopeLine: 3245, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !262)
!260 = !DISubroutineType(types: !261)
!261 = !{!27, !26}
!262 = !{!258}
!263 = !DILocation(line: 0, scope: !259, inlinedAt: !264)
!264 = distinct !DILocation(line: 3352, column: 16, scope: !169, inlinedAt: !176)
!265 = !DILocalVariable(name: "v64", arg: 1, scope: !266, file: !20, line: 3234, type: !26)
!266 = distinct !DISubprogram(name: "XXH_xorshift64", scope: !20, file: !20, line: 3234, type: !267, scopeLine: 3235, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !269)
!267 = !DISubroutineType(types: !268)
!268 = !{!26, !26, !33}
!269 = !{!265, !270}
!270 = !DILocalVariable(name: "shift", arg: 2, scope: !266, file: !20, line: 3234, type: !33)
!271 = !DILocation(line: 0, scope: !266, inlinedAt: !272)
!272 = distinct !DILocation(line: 3246, column: 11, scope: !259, inlinedAt: !264)
!273 = !DILocation(line: 3237, column: 23, scope: !266, inlinedAt: !272)
!274 = !DILocation(line: 3237, column: 16, scope: !266, inlinedAt: !272)
!275 = !DILocation(line: 3247, column: 9, scope: !259, inlinedAt: !264)
!276 = !DILocation(line: 0, scope: !266, inlinedAt: !277)
!277 = distinct !DILocation(line: 3248, column: 11, scope: !259, inlinedAt: !264)
!278 = !DILocation(line: 3237, column: 23, scope: !266, inlinedAt: !277)
!279 = !DILocation(line: 3237, column: 16, scope: !266, inlinedAt: !277)
!280 = !DILocation(line: 3360, column: 35, scope: !158, inlinedAt: !156)
!281 = !DILocation(line: 3361, column: 13, scope: !282, inlinedAt: !156)
!282 = distinct !DILexicalBlock(scope: !159, file: !20, line: 3361, column: 13)
!283 = !DILocation(line: 3361, column: 13, scope: !159, inlinedAt: !156)
!284 = !DILocalVariable(name: "input", arg: 1, scope: !285, file: !20, line: 3324, type: !17)
!285 = distinct !DISubprogram(name: "XXH3_len_4to8_64b", scope: !20, file: !20, line: 3324, type: !149, scopeLine: 3325, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !286)
!286 = !{!284, !287, !288, !289, !290, !293, !294, !295, !296}
!287 = !DILocalVariable(name: "len", arg: 2, scope: !285, file: !20, line: 3324, type: !83)
!288 = !DILocalVariable(name: "secret", arg: 3, scope: !285, file: !20, line: 3324, type: !17)
!289 = !DILocalVariable(name: "seed", arg: 4, scope: !285, file: !20, line: 3324, type: !27)
!290 = !DILocalVariable(name: "input1", scope: !291, file: !20, line: 3330, type: !292)
!291 = distinct !DILexicalBlock(scope: !285, file: !20, line: 3330, column: 5)
!292 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !31)
!293 = !DILocalVariable(name: "input2", scope: !291, file: !20, line: 3331, type: !292)
!294 = !DILocalVariable(name: "bitflip", scope: !291, file: !20, line: 3332, type: !170)
!295 = !DILocalVariable(name: "input64", scope: !291, file: !20, line: 3333, type: !170)
!296 = !DILocalVariable(name: "keyed", scope: !291, file: !20, line: 3334, type: !170)
!297 = !DILocation(line: 0, scope: !285, inlinedAt: !298)
!298 = distinct !DILocation(line: 3361, column: 42, scope: !282, inlinedAt: !156)
!299 = !DILocalVariable(name: "ptr", arg: 1, scope: !300, file: !20, line: 1689, type: !81)
!300 = distinct !DISubprogram(name: "XXH_readLE32", scope: !20, file: !20, line: 1689, type: !301, scopeLine: 1690, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !303)
!301 = !DISubroutineType(types: !302)
!302 = !{!31, !81}
!303 = !{!299}
!304 = !DILocation(line: 0, scope: !300, inlinedAt: !305)
!305 = distinct !DILocation(line: 3330, column: 32, scope: !291, inlinedAt: !298)
!306 = !DILocalVariable(name: "memPtr", arg: 1, scope: !307, file: !20, line: 1526, type: !81)
!307 = distinct !DISubprogram(name: "XXH_read32", scope: !20, file: !20, line: 1526, type: !301, scopeLine: 1527, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !308)
!308 = !{!306, !309}
!309 = !DILocalVariable(name: "val", scope: !307, file: !20, line: 1528, type: !31)
!310 = !DILocation(line: 0, scope: !307, inlinedAt: !311)
!311 = distinct !DILocation(line: 1691, column: 36, scope: !300, inlinedAt: !305)
!312 = !DILocation(line: 1529, column: 5, scope: !307, inlinedAt: !311)
!313 = !DILocation(line: 0, scope: !291, inlinedAt: !298)
!314 = !DILocation(line: 3331, column: 51, scope: !291, inlinedAt: !298)
!315 = !DILocation(line: 3331, column: 57, scope: !291, inlinedAt: !298)
!316 = !DILocation(line: 0, scope: !300, inlinedAt: !317)
!317 = distinct !DILocation(line: 3331, column: 32, scope: !291, inlinedAt: !298)
!318 = !DILocation(line: 0, scope: !307, inlinedAt: !319)
!319 = distinct !DILocation(line: 1691, column: 36, scope: !300, inlinedAt: !317)
!320 = !DILocation(line: 1529, column: 5, scope: !307, inlinedAt: !319)
!321 = !DILocation(line: 0, scope: !178, inlinedAt: !322)
!322 = distinct !DILocation(line: 3332, column: 34, scope: !291, inlinedAt: !298)
!323 = !DILocation(line: 0, scope: !185, inlinedAt: !324)
!324 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !322)
!325 = !DILocation(line: 0, scope: !178, inlinedAt: !326)
!326 = distinct !DILocation(line: 3332, column: 59, scope: !291, inlinedAt: !298)
!327 = !DILocation(line: 0, scope: !185, inlinedAt: !328)
!328 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !326)
!329 = !DILocation(line: 3333, column: 33, scope: !291, inlinedAt: !298)
!330 = !DILocation(line: 3333, column: 44, scope: !291, inlinedAt: !298)
!331 = !DILocation(line: 3333, column: 61, scope: !291, inlinedAt: !298)
!332 = !DILocation(line: 3333, column: 40, scope: !291, inlinedAt: !298)
!333 = !DILocation(line: 3334, column: 39, scope: !291, inlinedAt: !298)
!334 = !DILocalVariable(name: "h64", arg: 1, scope: !335, file: !20, line: 3257, type: !26)
!335 = distinct !DISubprogram(name: "XXH3_rrmxmx", scope: !20, file: !20, line: 3257, type: !336, scopeLine: 3258, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !338)
!336 = !DISubroutineType(types: !337)
!337 = !{!27, !26, !26}
!338 = !{!334, !339}
!339 = !DILocalVariable(name: "len", arg: 2, scope: !335, file: !20, line: 3257, type: !26)
!340 = !DILocation(line: 0, scope: !335, inlinedAt: !341)
!341 = distinct !DILocation(line: 3335, column: 16, scope: !291, inlinedAt: !298)
!342 = !DILocation(line: 3260, column: 12, scope: !335, inlinedAt: !341)
!343 = !DILocation(line: 3260, column: 34, scope: !335, inlinedAt: !341)
!344 = !DILocation(line: 3260, column: 9, scope: !335, inlinedAt: !341)
!345 = !DILocation(line: 3261, column: 9, scope: !335, inlinedAt: !341)
!346 = !DILocation(line: 3262, column: 17, scope: !335, inlinedAt: !341)
!347 = !DILocation(line: 3262, column: 24, scope: !335, inlinedAt: !341)
!348 = !DILocation(line: 3262, column: 9, scope: !335, inlinedAt: !341)
!349 = !DILocation(line: 3263, column: 9, scope: !335, inlinedAt: !341)
!350 = !DILocation(line: 0, scope: !266, inlinedAt: !351)
!351 = distinct !DILocation(line: 3264, column: 12, scope: !335, inlinedAt: !341)
!352 = !DILocation(line: 3237, column: 23, scope: !266, inlinedAt: !351)
!353 = !DILocation(line: 3237, column: 16, scope: !266, inlinedAt: !351)
!354 = !DILocation(line: 3361, column: 35, scope: !282, inlinedAt: !156)
!355 = !DILocation(line: 3362, column: 13, scope: !356, inlinedAt: !156)
!356 = distinct !DILexicalBlock(scope: !159, file: !20, line: 3362, column: 13)
!357 = !DILocation(line: 3362, column: 13, scope: !159, inlinedAt: !156)
!358 = !DILocalVariable(name: "input", arg: 1, scope: !359, file: !20, line: 3302, type: !17)
!359 = distinct !DISubprogram(name: "XXH3_len_1to3_64b", scope: !20, file: !20, line: 3302, type: !149, scopeLine: 3303, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !360)
!360 = !{!358, !361, !362, !363, !364, !366, !367, !368, !369, !370}
!361 = !DILocalVariable(name: "len", arg: 2, scope: !359, file: !20, line: 3302, type: !83)
!362 = !DILocalVariable(name: "secret", arg: 3, scope: !359, file: !20, line: 3302, type: !17)
!363 = !DILocalVariable(name: "seed", arg: 4, scope: !359, file: !20, line: 3302, type: !27)
!364 = !DILocalVariable(name: "c1", scope: !365, file: !20, line: 3312, type: !18)
!365 = distinct !DILexicalBlock(scope: !359, file: !20, line: 3312, column: 5)
!366 = !DILocalVariable(name: "c2", scope: !365, file: !20, line: 3313, type: !18)
!367 = !DILocalVariable(name: "c3", scope: !365, file: !20, line: 3314, type: !18)
!368 = !DILocalVariable(name: "combined", scope: !365, file: !20, line: 3315, type: !292)
!369 = !DILocalVariable(name: "bitflip", scope: !365, file: !20, line: 3317, type: !170)
!370 = !DILocalVariable(name: "keyed", scope: !365, file: !20, line: 3318, type: !170)
!371 = !DILocation(line: 0, scope: !359, inlinedAt: !372)
!372 = distinct !DILocation(line: 3362, column: 25, scope: !356, inlinedAt: !156)
!373 = !DILocation(line: 3312, column: 28, scope: !365, inlinedAt: !372)
!374 = !{!104, !104, i64 0}
!375 = !DILocation(line: 0, scope: !365, inlinedAt: !372)
!376 = !DILocation(line: 3313, column: 38, scope: !365, inlinedAt: !372)
!377 = !DILocation(line: 3313, column: 28, scope: !365, inlinedAt: !372)
!378 = !DILocation(line: 3314, column: 28, scope: !365, inlinedAt: !372)
!379 = !DILocation(line: 3315, column: 35, scope: !365, inlinedAt: !372)
!380 = !DILocation(line: 3315, column: 47, scope: !365, inlinedAt: !372)
!381 = !DILocation(line: 3315, column: 57, scope: !365, inlinedAt: !372)
!382 = !DILocation(line: 3315, column: 70, scope: !365, inlinedAt: !372)
!383 = !DILocation(line: 3315, column: 54, scope: !365, inlinedAt: !372)
!384 = !DILocation(line: 3316, column: 35, scope: !365, inlinedAt: !372)
!385 = !DILocation(line: 3316, column: 32, scope: !365, inlinedAt: !372)
!386 = !DILocation(line: 3316, column: 70, scope: !365, inlinedAt: !372)
!387 = !DILocation(line: 0, scope: !300, inlinedAt: !388)
!388 = distinct !DILocation(line: 3317, column: 34, scope: !365, inlinedAt: !372)
!389 = !DILocation(line: 0, scope: !307, inlinedAt: !390)
!390 = distinct !DILocation(line: 1691, column: 36, scope: !300, inlinedAt: !388)
!391 = !DILocation(line: 0, scope: !300, inlinedAt: !392)
!392 = distinct !DILocation(line: 3317, column: 57, scope: !365, inlinedAt: !372)
!393 = !DILocation(line: 0, scope: !307, inlinedAt: !394)
!394 = distinct !DILocation(line: 1691, column: 36, scope: !300, inlinedAt: !392)
!395 = !DILocation(line: 3318, column: 31, scope: !365, inlinedAt: !372)
!396 = !DILocation(line: 3318, column: 49, scope: !365, inlinedAt: !372)
!397 = !DILocalVariable(name: "h64", arg: 1, scope: !398, file: !20, line: 2300, type: !26)
!398 = distinct !DISubprogram(name: "XXH64_avalanche", scope: !20, file: !20, line: 2300, type: !219, scopeLine: 2301, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !399)
!399 = !{!397}
!400 = !DILocation(line: 0, scope: !398, inlinedAt: !401)
!401 = distinct !DILocation(line: 3319, column: 16, scope: !365, inlinedAt: !372)
!402 = !DILocation(line: 2303, column: 9, scope: !398, inlinedAt: !401)
!403 = !DILocation(line: 2304, column: 16, scope: !398, inlinedAt: !401)
!404 = !DILocation(line: 2304, column: 9, scope: !398, inlinedAt: !401)
!405 = !DILocation(line: 2305, column: 9, scope: !398, inlinedAt: !401)
!406 = !DILocation(line: 2306, column: 16, scope: !398, inlinedAt: !401)
!407 = !DILocation(line: 2306, column: 9, scope: !398, inlinedAt: !401)
!408 = !DILocation(line: 3362, column: 18, scope: !356, inlinedAt: !156)
!409 = !DILocation(line: 4393, column: 13, scope: !410, inlinedAt: !143)
!410 = distinct !DILexicalBlock(scope: !127, file: !20, line: 4393, column: 9)
!411 = !DILocation(line: 4393, column: 9, scope: !127, inlinedAt: !143)
!412 = !DILocalVariable(name: "input", arg: 1, scope: !413, file: !20, line: 3427, type: !135)
!413 = distinct !DISubprogram(name: "XXH3_len_17to128_64b", scope: !20, file: !20, line: 3427, type: !414, scopeLine: 3430, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !416)
!414 = !DISubroutineType(types: !415)
!415 = !{!27, !135, !83, !135, !83, !27}
!416 = !{!412, !417, !418, !419, !420, !421}
!417 = !DILocalVariable(name: "len", arg: 2, scope: !413, file: !20, line: 3427, type: !83)
!418 = !DILocalVariable(name: "secret", arg: 3, scope: !413, file: !20, line: 3428, type: !135)
!419 = !DILocalVariable(name: "secretSize", arg: 4, scope: !413, file: !20, line: 3428, type: !83)
!420 = !DILocalVariable(name: "seed", arg: 5, scope: !413, file: !20, line: 3429, type: !27)
!421 = !DILocalVariable(name: "acc", scope: !422, file: !20, line: 3434, type: !26)
!422 = distinct !DILexicalBlock(scope: !413, file: !20, line: 3434, column: 5)
!423 = !DILocation(line: 0, scope: !413, inlinedAt: !424)
!424 = distinct !DILocation(line: 4394, column: 16, scope: !410, inlinedAt: !143)
!425 = !DILocation(line: 3434, column: 27, scope: !422, inlinedAt: !424)
!426 = !DILocation(line: 0, scope: !422, inlinedAt: !424)
!427 = !DILocation(line: 3435, column: 17, scope: !428, inlinedAt: !424)
!428 = distinct !DILexicalBlock(scope: !422, file: !20, line: 3435, column: 13)
!429 = !DILocation(line: 3435, column: 13, scope: !422, inlinedAt: !424)
!430 = !DILocation(line: 3436, column: 21, scope: !431, inlinedAt: !424)
!431 = distinct !DILexicalBlock(scope: !432, file: !20, line: 3436, column: 17)
!432 = distinct !DILexicalBlock(scope: !428, file: !20, line: 3435, column: 23)
!433 = !DILocation(line: 3436, column: 17, scope: !432, inlinedAt: !424)
!434 = !DILocation(line: 3437, column: 25, scope: !435, inlinedAt: !424)
!435 = distinct !DILexicalBlock(scope: !436, file: !20, line: 3437, column: 21)
!436 = distinct !DILexicalBlock(scope: !431, file: !20, line: 3436, column: 27)
!437 = !DILocation(line: 3437, column: 21, scope: !436, inlinedAt: !424)
!438 = !DILocation(line: 3438, column: 45, scope: !439, inlinedAt: !424)
!439 = distinct !DILexicalBlock(scope: !435, file: !20, line: 3437, column: 31)
!440 = !DILocalVariable(name: "input", arg: 1, scope: !441, file: !20, line: 3393, type: !135)
!441 = distinct !DISubprogram(name: "XXH3_mix16B", scope: !20, file: !20, line: 3393, type: !442, scopeLine: 3395, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !444)
!442 = !DISubroutineType(types: !443)
!443 = !{!26, !135, !135, !26}
!444 = !{!440, !445, !446, !447, !449}
!445 = !DILocalVariable(name: "secret", arg: 2, scope: !441, file: !20, line: 3394, type: !135)
!446 = !DILocalVariable(name: "seed64", arg: 3, scope: !441, file: !20, line: 3394, type: !26)
!447 = !DILocalVariable(name: "input_lo", scope: !448, file: !20, line: 3416, type: !170)
!448 = distinct !DILexicalBlock(scope: !441, file: !20, line: 3416, column: 5)
!449 = !DILocalVariable(name: "input_hi", scope: !448, file: !20, line: 3417, type: !170)
!450 = !DILocation(line: 0, scope: !441, inlinedAt: !451)
!451 = distinct !DILocation(line: 3438, column: 28, scope: !439, inlinedAt: !424)
!452 = !DILocation(line: 0, scope: !178, inlinedAt: !453)
!453 = distinct !DILocation(line: 3416, column: 34, scope: !448, inlinedAt: !451)
!454 = !DILocation(line: 0, scope: !185, inlinedAt: !455)
!455 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !453)
!456 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !455)
!457 = !{!458}
!458 = distinct !{!458, !459, !"XXH3_mix16B: %secret"}
!459 = distinct !{!459, !"XXH3_mix16B"}
!460 = !DILocation(line: 0, scope: !448, inlinedAt: !451)
!461 = !DILocation(line: 3417, column: 52, scope: !448, inlinedAt: !451)
!462 = !DILocation(line: 0, scope: !178, inlinedAt: !463)
!463 = distinct !DILocation(line: 3417, column: 34, scope: !448, inlinedAt: !451)
!464 = !DILocation(line: 0, scope: !185, inlinedAt: !465)
!465 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !463)
!466 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !465)
!467 = !DILocation(line: 0, scope: !178, inlinedAt: !468)
!468 = distinct !DILocation(line: 3419, column: 25, scope: !448, inlinedAt: !451)
!469 = !DILocation(line: 0, scope: !185, inlinedAt: !470)
!470 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !468)
!471 = !DILocation(line: 3419, column: 22, scope: !448, inlinedAt: !451)
!472 = !DILocation(line: 0, scope: !178, inlinedAt: !473)
!473 = distinct !DILocation(line: 3420, column: 25, scope: !448, inlinedAt: !451)
!474 = !DILocation(line: 0, scope: !185, inlinedAt: !475)
!475 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !473)
!476 = !DILocation(line: 3420, column: 22, scope: !448, inlinedAt: !451)
!477 = !DILocation(line: 0, scope: !228, inlinedAt: !478)
!478 = distinct !DILocation(line: 3418, column: 16, scope: !448, inlinedAt: !451)
!479 = !DILocation(line: 0, scope: !242, inlinedAt: !480)
!480 = distinct !DILocation(line: 3229, column: 29, scope: !228, inlinedAt: !478)
!481 = !DILocation(line: 3129, column: 33, scope: !242, inlinedAt: !480)
!482 = !DILocation(line: 3129, column: 52, scope: !242, inlinedAt: !480)
!483 = !DILocation(line: 3129, column: 50, scope: !242, inlinedAt: !480)
!484 = !DILocation(line: 3132, column: 37, scope: !242, inlinedAt: !480)
!485 = !DILocation(line: 3230, column: 26, scope: !228, inlinedAt: !478)
!486 = !DILocation(line: 3438, column: 25, scope: !439, inlinedAt: !424)
!487 = !DILocation(line: 3439, column: 45, scope: !439, inlinedAt: !424)
!488 = !DILocation(line: 3439, column: 49, scope: !439, inlinedAt: !424)
!489 = !DILocation(line: 0, scope: !441, inlinedAt: !490)
!490 = distinct !DILocation(line: 3439, column: 28, scope: !439, inlinedAt: !424)
!491 = !DILocation(line: 0, scope: !178, inlinedAt: !492)
!492 = distinct !DILocation(line: 3416, column: 34, scope: !448, inlinedAt: !490)
!493 = !DILocation(line: 0, scope: !185, inlinedAt: !494)
!494 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !492)
!495 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !494)
!496 = !{!497}
!497 = distinct !{!497, !498, !"XXH3_mix16B: %secret"}
!498 = distinct !{!498, !"XXH3_mix16B"}
!499 = !DILocation(line: 0, scope: !448, inlinedAt: !490)
!500 = !DILocation(line: 3417, column: 52, scope: !448, inlinedAt: !490)
!501 = !DILocation(line: 0, scope: !178, inlinedAt: !502)
!502 = distinct !DILocation(line: 3417, column: 34, scope: !448, inlinedAt: !490)
!503 = !DILocation(line: 0, scope: !185, inlinedAt: !504)
!504 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !502)
!505 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !504)
!506 = !DILocation(line: 0, scope: !178, inlinedAt: !507)
!507 = distinct !DILocation(line: 3419, column: 25, scope: !448, inlinedAt: !490)
!508 = !DILocation(line: 0, scope: !185, inlinedAt: !509)
!509 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !507)
!510 = !DILocation(line: 3419, column: 22, scope: !448, inlinedAt: !490)
!511 = !DILocation(line: 0, scope: !178, inlinedAt: !512)
!512 = distinct !DILocation(line: 3420, column: 25, scope: !448, inlinedAt: !490)
!513 = !DILocation(line: 0, scope: !185, inlinedAt: !514)
!514 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !512)
!515 = !DILocation(line: 3420, column: 22, scope: !448, inlinedAt: !490)
!516 = !DILocation(line: 0, scope: !228, inlinedAt: !517)
!517 = distinct !DILocation(line: 3418, column: 16, scope: !448, inlinedAt: !490)
!518 = !DILocation(line: 0, scope: !242, inlinedAt: !519)
!519 = distinct !DILocation(line: 3229, column: 29, scope: !228, inlinedAt: !517)
!520 = !DILocation(line: 3129, column: 33, scope: !242, inlinedAt: !519)
!521 = !DILocation(line: 3129, column: 52, scope: !242, inlinedAt: !519)
!522 = !DILocation(line: 3129, column: 50, scope: !242, inlinedAt: !519)
!523 = !DILocation(line: 3132, column: 37, scope: !242, inlinedAt: !519)
!524 = !DILocation(line: 3230, column: 26, scope: !228, inlinedAt: !517)
!525 = !DILocation(line: 3439, column: 25, scope: !439, inlinedAt: !424)
!526 = !DILocation(line: 3440, column: 17, scope: !439, inlinedAt: !424)
!527 = !DILocation(line: 3441, column: 41, scope: !436, inlinedAt: !424)
!528 = !DILocation(line: 0, scope: !441, inlinedAt: !529)
!529 = distinct !DILocation(line: 3441, column: 24, scope: !436, inlinedAt: !424)
!530 = !DILocation(line: 0, scope: !178, inlinedAt: !531)
!531 = distinct !DILocation(line: 3416, column: 34, scope: !448, inlinedAt: !529)
!532 = !DILocation(line: 0, scope: !185, inlinedAt: !533)
!533 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !531)
!534 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !533)
!535 = !{!536}
!536 = distinct !{!536, !537, !"XXH3_mix16B: %secret"}
!537 = distinct !{!537, !"XXH3_mix16B"}
!538 = !DILocation(line: 0, scope: !448, inlinedAt: !529)
!539 = !DILocation(line: 3417, column: 52, scope: !448, inlinedAt: !529)
!540 = !DILocation(line: 0, scope: !178, inlinedAt: !541)
!541 = distinct !DILocation(line: 3417, column: 34, scope: !448, inlinedAt: !529)
!542 = !DILocation(line: 0, scope: !185, inlinedAt: !543)
!543 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !541)
!544 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !543)
!545 = !DILocation(line: 0, scope: !178, inlinedAt: !546)
!546 = distinct !DILocation(line: 3419, column: 25, scope: !448, inlinedAt: !529)
!547 = !DILocation(line: 0, scope: !185, inlinedAt: !548)
!548 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !546)
!549 = !DILocation(line: 3419, column: 22, scope: !448, inlinedAt: !529)
!550 = !DILocation(line: 0, scope: !178, inlinedAt: !551)
!551 = distinct !DILocation(line: 3420, column: 25, scope: !448, inlinedAt: !529)
!552 = !DILocation(line: 0, scope: !185, inlinedAt: !553)
!553 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !551)
!554 = !DILocation(line: 3420, column: 22, scope: !448, inlinedAt: !529)
!555 = !DILocation(line: 0, scope: !228, inlinedAt: !556)
!556 = distinct !DILocation(line: 3418, column: 16, scope: !448, inlinedAt: !529)
!557 = !DILocation(line: 0, scope: !242, inlinedAt: !558)
!558 = distinct !DILocation(line: 3229, column: 29, scope: !228, inlinedAt: !556)
!559 = !DILocation(line: 3129, column: 33, scope: !242, inlinedAt: !558)
!560 = !DILocation(line: 3129, column: 52, scope: !242, inlinedAt: !558)
!561 = !DILocation(line: 3129, column: 50, scope: !242, inlinedAt: !558)
!562 = !DILocation(line: 3132, column: 37, scope: !242, inlinedAt: !558)
!563 = !DILocation(line: 3230, column: 26, scope: !228, inlinedAt: !556)
!564 = !DILocation(line: 3441, column: 21, scope: !436, inlinedAt: !424)
!565 = !DILocation(line: 3442, column: 41, scope: !436, inlinedAt: !424)
!566 = !DILocation(line: 3442, column: 45, scope: !436, inlinedAt: !424)
!567 = !DILocation(line: 0, scope: !441, inlinedAt: !568)
!568 = distinct !DILocation(line: 3442, column: 24, scope: !436, inlinedAt: !424)
!569 = !DILocation(line: 0, scope: !178, inlinedAt: !570)
!570 = distinct !DILocation(line: 3416, column: 34, scope: !448, inlinedAt: !568)
!571 = !DILocation(line: 0, scope: !185, inlinedAt: !572)
!572 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !570)
!573 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !572)
!574 = !{!575}
!575 = distinct !{!575, !576, !"XXH3_mix16B: %secret"}
!576 = distinct !{!576, !"XXH3_mix16B"}
!577 = !DILocation(line: 0, scope: !448, inlinedAt: !568)
!578 = !DILocation(line: 3417, column: 52, scope: !448, inlinedAt: !568)
!579 = !DILocation(line: 0, scope: !178, inlinedAt: !580)
!580 = distinct !DILocation(line: 3417, column: 34, scope: !448, inlinedAt: !568)
!581 = !DILocation(line: 0, scope: !185, inlinedAt: !582)
!582 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !580)
!583 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !582)
!584 = !DILocation(line: 0, scope: !178, inlinedAt: !585)
!585 = distinct !DILocation(line: 3419, column: 25, scope: !448, inlinedAt: !568)
!586 = !DILocation(line: 0, scope: !185, inlinedAt: !587)
!587 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !585)
!588 = !DILocation(line: 3419, column: 22, scope: !448, inlinedAt: !568)
!589 = !DILocation(line: 0, scope: !178, inlinedAt: !590)
!590 = distinct !DILocation(line: 3420, column: 25, scope: !448, inlinedAt: !568)
!591 = !DILocation(line: 0, scope: !185, inlinedAt: !592)
!592 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !590)
!593 = !DILocation(line: 3420, column: 22, scope: !448, inlinedAt: !568)
!594 = !DILocation(line: 0, scope: !228, inlinedAt: !595)
!595 = distinct !DILocation(line: 3418, column: 16, scope: !448, inlinedAt: !568)
!596 = !DILocation(line: 0, scope: !242, inlinedAt: !597)
!597 = distinct !DILocation(line: 3229, column: 29, scope: !228, inlinedAt: !595)
!598 = !DILocation(line: 3129, column: 33, scope: !242, inlinedAt: !597)
!599 = !DILocation(line: 3129, column: 52, scope: !242, inlinedAt: !597)
!600 = !DILocation(line: 3129, column: 50, scope: !242, inlinedAt: !597)
!601 = !DILocation(line: 3132, column: 37, scope: !242, inlinedAt: !597)
!602 = !DILocation(line: 3230, column: 26, scope: !228, inlinedAt: !595)
!603 = !DILocation(line: 3442, column: 21, scope: !436, inlinedAt: !424)
!604 = !DILocation(line: 3443, column: 13, scope: !436, inlinedAt: !424)
!605 = !DILocation(line: 3444, column: 37, scope: !432, inlinedAt: !424)
!606 = !DILocation(line: 0, scope: !441, inlinedAt: !607)
!607 = distinct !DILocation(line: 3444, column: 20, scope: !432, inlinedAt: !424)
!608 = !DILocation(line: 0, scope: !178, inlinedAt: !609)
!609 = distinct !DILocation(line: 3416, column: 34, scope: !448, inlinedAt: !607)
!610 = !DILocation(line: 0, scope: !185, inlinedAt: !611)
!611 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !609)
!612 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !611)
!613 = !{!614}
!614 = distinct !{!614, !615, !"XXH3_mix16B: %secret"}
!615 = distinct !{!615, !"XXH3_mix16B"}
!616 = !DILocation(line: 0, scope: !448, inlinedAt: !607)
!617 = !DILocation(line: 3417, column: 52, scope: !448, inlinedAt: !607)
!618 = !DILocation(line: 0, scope: !178, inlinedAt: !619)
!619 = distinct !DILocation(line: 3417, column: 34, scope: !448, inlinedAt: !607)
!620 = !DILocation(line: 0, scope: !185, inlinedAt: !621)
!621 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !619)
!622 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !621)
!623 = !DILocation(line: 0, scope: !178, inlinedAt: !624)
!624 = distinct !DILocation(line: 3419, column: 25, scope: !448, inlinedAt: !607)
!625 = !DILocation(line: 0, scope: !185, inlinedAt: !626)
!626 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !624)
!627 = !DILocation(line: 3419, column: 22, scope: !448, inlinedAt: !607)
!628 = !DILocation(line: 0, scope: !178, inlinedAt: !629)
!629 = distinct !DILocation(line: 3420, column: 25, scope: !448, inlinedAt: !607)
!630 = !DILocation(line: 0, scope: !185, inlinedAt: !631)
!631 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !629)
!632 = !DILocation(line: 3420, column: 22, scope: !448, inlinedAt: !607)
!633 = !DILocation(line: 0, scope: !228, inlinedAt: !634)
!634 = distinct !DILocation(line: 3418, column: 16, scope: !448, inlinedAt: !607)
!635 = !DILocation(line: 0, scope: !242, inlinedAt: !636)
!636 = distinct !DILocation(line: 3229, column: 29, scope: !228, inlinedAt: !634)
!637 = !DILocation(line: 3129, column: 33, scope: !242, inlinedAt: !636)
!638 = !DILocation(line: 3129, column: 52, scope: !242, inlinedAt: !636)
!639 = !DILocation(line: 3129, column: 50, scope: !242, inlinedAt: !636)
!640 = !DILocation(line: 3132, column: 37, scope: !242, inlinedAt: !636)
!641 = !DILocation(line: 3230, column: 26, scope: !228, inlinedAt: !634)
!642 = !DILocation(line: 3444, column: 17, scope: !432, inlinedAt: !424)
!643 = !DILocation(line: 3445, column: 37, scope: !432, inlinedAt: !424)
!644 = !DILocation(line: 3445, column: 41, scope: !432, inlinedAt: !424)
!645 = !DILocation(line: 0, scope: !441, inlinedAt: !646)
!646 = distinct !DILocation(line: 3445, column: 20, scope: !432, inlinedAt: !424)
!647 = !DILocation(line: 0, scope: !178, inlinedAt: !648)
!648 = distinct !DILocation(line: 3416, column: 34, scope: !448, inlinedAt: !646)
!649 = !DILocation(line: 0, scope: !185, inlinedAt: !650)
!650 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !648)
!651 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !650)
!652 = !{!653}
!653 = distinct !{!653, !654, !"XXH3_mix16B: %secret"}
!654 = distinct !{!654, !"XXH3_mix16B"}
!655 = !DILocation(line: 0, scope: !448, inlinedAt: !646)
!656 = !DILocation(line: 3417, column: 52, scope: !448, inlinedAt: !646)
!657 = !DILocation(line: 0, scope: !178, inlinedAt: !658)
!658 = distinct !DILocation(line: 3417, column: 34, scope: !448, inlinedAt: !646)
!659 = !DILocation(line: 0, scope: !185, inlinedAt: !660)
!660 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !658)
!661 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !660)
!662 = !DILocation(line: 0, scope: !178, inlinedAt: !663)
!663 = distinct !DILocation(line: 3419, column: 25, scope: !448, inlinedAt: !646)
!664 = !DILocation(line: 0, scope: !185, inlinedAt: !665)
!665 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !663)
!666 = !DILocation(line: 3419, column: 22, scope: !448, inlinedAt: !646)
!667 = !DILocation(line: 0, scope: !178, inlinedAt: !668)
!668 = distinct !DILocation(line: 3420, column: 25, scope: !448, inlinedAt: !646)
!669 = !DILocation(line: 0, scope: !185, inlinedAt: !670)
!670 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !668)
!671 = !DILocation(line: 3420, column: 22, scope: !448, inlinedAt: !646)
!672 = !DILocation(line: 0, scope: !228, inlinedAt: !673)
!673 = distinct !DILocation(line: 3418, column: 16, scope: !448, inlinedAt: !646)
!674 = !DILocation(line: 0, scope: !242, inlinedAt: !675)
!675 = distinct !DILocation(line: 3229, column: 29, scope: !228, inlinedAt: !673)
!676 = !DILocation(line: 3129, column: 33, scope: !242, inlinedAt: !675)
!677 = !DILocation(line: 3129, column: 52, scope: !242, inlinedAt: !675)
!678 = !DILocation(line: 3129, column: 50, scope: !242, inlinedAt: !675)
!679 = !DILocation(line: 3132, column: 37, scope: !242, inlinedAt: !675)
!680 = !DILocation(line: 3230, column: 26, scope: !228, inlinedAt: !673)
!681 = !DILocation(line: 3445, column: 17, scope: !432, inlinedAt: !424)
!682 = !DILocation(line: 3446, column: 9, scope: !432, inlinedAt: !424)
!683 = !DILocation(line: 0, scope: !441, inlinedAt: !684)
!684 = distinct !DILocation(line: 3447, column: 16, scope: !422, inlinedAt: !424)
!685 = !DILocation(line: 0, scope: !178, inlinedAt: !686)
!686 = distinct !DILocation(line: 3416, column: 34, scope: !448, inlinedAt: !684)
!687 = !DILocation(line: 0, scope: !185, inlinedAt: !688)
!688 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !686)
!689 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !688)
!690 = !{!691}
!691 = distinct !{!691, !692, !"XXH3_mix16B: %secret"}
!692 = distinct !{!692, !"XXH3_mix16B"}
!693 = !DILocation(line: 0, scope: !448, inlinedAt: !684)
!694 = !DILocation(line: 3417, column: 52, scope: !448, inlinedAt: !684)
!695 = !DILocation(line: 0, scope: !178, inlinedAt: !696)
!696 = distinct !DILocation(line: 3417, column: 34, scope: !448, inlinedAt: !684)
!697 = !DILocation(line: 0, scope: !185, inlinedAt: !698)
!698 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !696)
!699 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !698)
!700 = !DILocation(line: 0, scope: !178, inlinedAt: !701)
!701 = distinct !DILocation(line: 3419, column: 25, scope: !448, inlinedAt: !684)
!702 = !DILocation(line: 0, scope: !185, inlinedAt: !703)
!703 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !701)
!704 = !DILocation(line: 3419, column: 22, scope: !448, inlinedAt: !684)
!705 = !DILocation(line: 0, scope: !178, inlinedAt: !706)
!706 = distinct !DILocation(line: 3420, column: 25, scope: !448, inlinedAt: !684)
!707 = !DILocation(line: 0, scope: !185, inlinedAt: !708)
!708 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !706)
!709 = !DILocation(line: 3420, column: 22, scope: !448, inlinedAt: !684)
!710 = !DILocation(line: 0, scope: !228, inlinedAt: !711)
!711 = distinct !DILocation(line: 3418, column: 16, scope: !448, inlinedAt: !684)
!712 = !DILocation(line: 0, scope: !242, inlinedAt: !713)
!713 = distinct !DILocation(line: 3229, column: 29, scope: !228, inlinedAt: !711)
!714 = !DILocation(line: 3129, column: 33, scope: !242, inlinedAt: !713)
!715 = !DILocation(line: 3129, column: 52, scope: !242, inlinedAt: !713)
!716 = !DILocation(line: 3129, column: 50, scope: !242, inlinedAt: !713)
!717 = !DILocation(line: 3132, column: 37, scope: !242, inlinedAt: !713)
!718 = !DILocation(line: 3230, column: 26, scope: !228, inlinedAt: !711)
!719 = !DILocation(line: 3447, column: 13, scope: !422, inlinedAt: !424)
!720 = !DILocation(line: 3448, column: 33, scope: !422, inlinedAt: !424)
!721 = !DILocation(line: 3448, column: 37, scope: !422, inlinedAt: !424)
!722 = !DILocation(line: 0, scope: !441, inlinedAt: !723)
!723 = distinct !DILocation(line: 3448, column: 16, scope: !422, inlinedAt: !424)
!724 = !DILocation(line: 0, scope: !178, inlinedAt: !725)
!725 = distinct !DILocation(line: 3416, column: 34, scope: !448, inlinedAt: !723)
!726 = !DILocation(line: 0, scope: !185, inlinedAt: !727)
!727 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !725)
!728 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !727)
!729 = !{!730}
!730 = distinct !{!730, !731, !"XXH3_mix16B: %secret"}
!731 = distinct !{!731, !"XXH3_mix16B"}
!732 = !DILocation(line: 0, scope: !448, inlinedAt: !723)
!733 = !DILocation(line: 3417, column: 52, scope: !448, inlinedAt: !723)
!734 = !DILocation(line: 0, scope: !178, inlinedAt: !735)
!735 = distinct !DILocation(line: 3417, column: 34, scope: !448, inlinedAt: !723)
!736 = !DILocation(line: 0, scope: !185, inlinedAt: !737)
!737 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !735)
!738 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !737)
!739 = !DILocation(line: 0, scope: !178, inlinedAt: !740)
!740 = distinct !DILocation(line: 3419, column: 25, scope: !448, inlinedAt: !723)
!741 = !DILocation(line: 0, scope: !185, inlinedAt: !742)
!742 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !740)
!743 = !DILocation(line: 3419, column: 22, scope: !448, inlinedAt: !723)
!744 = !DILocation(line: 0, scope: !178, inlinedAt: !745)
!745 = distinct !DILocation(line: 3420, column: 25, scope: !448, inlinedAt: !723)
!746 = !DILocation(line: 0, scope: !185, inlinedAt: !747)
!747 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !745)
!748 = !DILocation(line: 3420, column: 22, scope: !448, inlinedAt: !723)
!749 = !DILocation(line: 0, scope: !228, inlinedAt: !750)
!750 = distinct !DILocation(line: 3418, column: 16, scope: !448, inlinedAt: !723)
!751 = !DILocation(line: 0, scope: !242, inlinedAt: !752)
!752 = distinct !DILocation(line: 3229, column: 29, scope: !228, inlinedAt: !750)
!753 = !DILocation(line: 3129, column: 33, scope: !242, inlinedAt: !752)
!754 = !DILocation(line: 3129, column: 52, scope: !242, inlinedAt: !752)
!755 = !DILocation(line: 3129, column: 50, scope: !242, inlinedAt: !752)
!756 = !DILocation(line: 3132, column: 37, scope: !242, inlinedAt: !752)
!757 = !DILocation(line: 3230, column: 26, scope: !228, inlinedAt: !750)
!758 = !DILocation(line: 3448, column: 13, scope: !422, inlinedAt: !424)
!759 = !DILocation(line: 0, scope: !259, inlinedAt: !760)
!760 = distinct !DILocation(line: 3450, column: 16, scope: !422, inlinedAt: !424)
!761 = !DILocation(line: 0, scope: !266, inlinedAt: !762)
!762 = distinct !DILocation(line: 3246, column: 11, scope: !259, inlinedAt: !760)
!763 = !DILocation(line: 3237, column: 23, scope: !266, inlinedAt: !762)
!764 = !DILocation(line: 3237, column: 16, scope: !266, inlinedAt: !762)
!765 = !DILocation(line: 3247, column: 9, scope: !259, inlinedAt: !760)
!766 = !DILocation(line: 0, scope: !266, inlinedAt: !767)
!767 = distinct !DILocation(line: 3248, column: 11, scope: !259, inlinedAt: !760)
!768 = !DILocation(line: 3237, column: 23, scope: !266, inlinedAt: !767)
!769 = !DILocation(line: 3237, column: 16, scope: !266, inlinedAt: !767)
!770 = !DILocation(line: 4394, column: 9, scope: !410, inlinedAt: !143)
!771 = !DILocation(line: 4395, column: 13, scope: !772, inlinedAt: !143)
!772 = distinct !DILexicalBlock(scope: !127, file: !20, line: 4395, column: 9)
!773 = !DILocation(line: 4395, column: 9, scope: !127, inlinedAt: !143)
!774 = !DILocation(line: 4396, column: 16, scope: !772, inlinedAt: !143)
!775 = !DILocation(line: 4396, column: 9, scope: !772, inlinedAt: !143)
!776 = !DILocation(line: 4397, column: 12, scope: !127, inlinedAt: !143)
!777 = !DILocation(line: 4397, column: 5, scope: !127, inlinedAt: !143)
!778 = !DILocation(line: 12, column: 12, scope: !113)
!779 = !DILocation(line: 12, column: 5, scope: !113)
!780 = distinct !DISubprogram(name: "XXH3_hashLong_64b_default", scope: !20, file: !20, line: 4326, type: !781, scopeLine: 4328, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !782)
!781 = !DISubroutineType(cc: DW_CC_nocall, types: !134)
!782 = !{!783, !784, !785, !786, !787}
!783 = !DILocalVariable(name: "input", arg: 1, scope: !780, file: !20, line: 4326, type: !130)
!784 = !DILocalVariable(name: "len", arg: 2, scope: !780, file: !20, line: 4326, type: !83)
!785 = !DILocalVariable(name: "seed64", arg: 3, scope: !780, file: !20, line: 4327, type: !27)
!786 = !DILocalVariable(name: "secret", arg: 4, scope: !780, file: !20, line: 4327, type: !135)
!787 = !DILocalVariable(name: "secretLen", arg: 5, scope: !780, file: !20, line: 4327, type: !83)
!788 = !DILocation(line: 0, scope: !780)
!789 = !DILocalVariable(name: "input", arg: 1, scope: !790, file: !20, line: 4290, type: !130)
!790 = distinct !DISubprogram(name: "XXH3_hashLong_64b_internal", scope: !20, file: !20, line: 4290, type: !791, scopeLine: 4294, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !803)
!791 = !DISubroutineType(types: !792)
!792 = !{!27, !130, !83, !130, !83, !793, !799}
!793 = !DIDerivedType(tag: DW_TAG_typedef, name: "XXH3_f_accumulate_512", file: !20, line: 4139, baseType: !794)
!794 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !795, size: 64)
!795 = !DISubroutineType(types: !796)
!796 = !{null, !797, !81, !81}
!797 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !798)
!798 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!799 = !DIDerivedType(tag: DW_TAG_typedef, name: "XXH3_f_scrambleAcc", file: !20, line: 4140, baseType: !800)
!800 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !801, size: 64)
!801 = !DISubroutineType(types: !802)
!802 = !{null, !797, !81}
!803 = !{!789, !804, !805, !806, !807, !808, !809}
!804 = !DILocalVariable(name: "len", arg: 2, scope: !790, file: !20, line: 4290, type: !83)
!805 = !DILocalVariable(name: "secret", arg: 3, scope: !790, file: !20, line: 4291, type: !130)
!806 = !DILocalVariable(name: "secretSize", arg: 4, scope: !790, file: !20, line: 4291, type: !83)
!807 = !DILocalVariable(name: "f_acc512", arg: 5, scope: !790, file: !20, line: 4292, type: !793)
!808 = !DILocalVariable(name: "f_scramble", arg: 6, scope: !790, file: !20, line: 4293, type: !799)
!809 = !DILocalVariable(name: "acc", scope: !790, file: !20, line: 4295, type: !810, align: 128)
!810 = !DICompositeType(tag: DW_TAG_array_type, baseType: !26, size: 512, elements: !63)
!811 = !DILocation(line: 0, scope: !790, inlinedAt: !812)
!812 = distinct !DILocation(line: 4330, column: 12, scope: !780)
!813 = !DILocalVariable(name: "acc", arg: 1, scope: !814, file: !20, line: 4219, type: !817)
!814 = distinct !DISubprogram(name: "XXH3_hashLong_internal_loop", scope: !20, file: !20, line: 4219, type: !815, scopeLine: 4224, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !819)
!815 = !DISubroutineType(types: !816)
!816 = !{null, !817, !135, !83, !135, !83, !793, !799}
!817 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !818)
!818 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !26, size: 64)
!819 = !{!813, !820, !821, !822, !823, !824, !825, !826, !828, !829, !830, !831, !833}
!820 = !DILocalVariable(name: "input", arg: 2, scope: !814, file: !20, line: 4220, type: !135)
!821 = !DILocalVariable(name: "len", arg: 3, scope: !814, file: !20, line: 4220, type: !83)
!822 = !DILocalVariable(name: "secret", arg: 4, scope: !814, file: !20, line: 4221, type: !135)
!823 = !DILocalVariable(name: "secretSize", arg: 5, scope: !814, file: !20, line: 4221, type: !83)
!824 = !DILocalVariable(name: "f_acc512", arg: 6, scope: !814, file: !20, line: 4222, type: !793)
!825 = !DILocalVariable(name: "f_scramble", arg: 7, scope: !814, file: !20, line: 4223, type: !799)
!826 = !DILocalVariable(name: "nbStripesPerBlock", scope: !814, file: !20, line: 4225, type: !827)
!827 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !83)
!828 = !DILocalVariable(name: "block_len", scope: !814, file: !20, line: 4226, type: !827)
!829 = !DILocalVariable(name: "nb_blocks", scope: !814, file: !20, line: 4227, type: !827)
!830 = !DILocalVariable(name: "n", scope: !814, file: !20, line: 4229, type: !83)
!831 = !DILocalVariable(name: "nbStripes", scope: !832, file: !20, line: 4240, type: !827)
!832 = distinct !DILexicalBlock(scope: !814, file: !20, line: 4240, column: 5)
!833 = !DILocalVariable(name: "p", scope: !834, file: !20, line: 4245, type: !835)
!834 = distinct !DILexicalBlock(scope: !832, file: !20, line: 4245, column: 9)
!835 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!836 = !DILocation(line: 0, scope: !814, inlinedAt: !837)
!837 = distinct !DILocation(line: 4297, column: 5, scope: !790, inlinedAt: !812)
!838 = !DILocation(line: 4227, column: 35, scope: !814, inlinedAt: !837)
!839 = !DILocation(line: 4233, column: 19, scope: !840, inlinedAt: !837)
!840 = distinct !DILexicalBlock(scope: !841, file: !20, line: 4233, column: 5)
!841 = distinct !DILexicalBlock(scope: !814, file: !20, line: 4233, column: 5)
!842 = !DILocation(line: 4233, column: 5, scope: !841, inlinedAt: !837)
!843 = !DILocation(line: 4227, column: 40, scope: !814, inlinedAt: !837)
!844 = !DILocation(line: 4234, column: 39, scope: !845, inlinedAt: !837)
!845 = distinct !DILexicalBlock(scope: !840, file: !20, line: 4233, column: 37)
!846 = !DILocation(line: 4234, column: 36, scope: !845, inlinedAt: !837)
!847 = !DILocalVariable(name: "acc", arg: 1, scope: !848, file: !20, line: 4202, type: !817)
!848 = distinct !DISubprogram(name: "XXH3_accumulate", scope: !20, file: !20, line: 4202, type: !849, scopeLine: 4207, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !851)
!849 = !DISubroutineType(types: !850)
!850 = !{null, !817, !135, !135, !83, !793}
!851 = !{!847, !852, !853, !854, !855, !856, !857}
!852 = !DILocalVariable(name: "input", arg: 2, scope: !848, file: !20, line: 4203, type: !135)
!853 = !DILocalVariable(name: "secret", arg: 3, scope: !848, file: !20, line: 4204, type: !135)
!854 = !DILocalVariable(name: "nbStripes", arg: 4, scope: !848, file: !20, line: 4205, type: !83)
!855 = !DILocalVariable(name: "f_acc512", arg: 5, scope: !848, file: !20, line: 4206, type: !793)
!856 = !DILocalVariable(name: "n", scope: !848, file: !20, line: 4208, type: !83)
!857 = !DILocalVariable(name: "in", scope: !858, file: !20, line: 4210, type: !835)
!858 = distinct !DILexicalBlock(scope: !859, file: !20, line: 4209, column: 38)
!859 = distinct !DILexicalBlock(scope: !860, file: !20, line: 4209, column: 5)
!860 = distinct !DILexicalBlock(scope: !848, file: !20, line: 4209, column: 5)
!861 = !DILocation(line: 0, scope: !848, inlinedAt: !862)
!862 = distinct !DILocation(line: 4234, column: 9, scope: !845, inlinedAt: !837)
!863 = !DILocation(line: 4209, column: 5, scope: !860, inlinedAt: !862)
!864 = !DILocation(line: 4210, column: 43, scope: !858, inlinedAt: !862)
!865 = !DILocation(line: 4210, column: 40, scope: !858, inlinedAt: !862)
!866 = !DILocation(line: 0, scope: !858, inlinedAt: !862)
!867 = !DILocation(line: 4211, column: 9, scope: !858, inlinedAt: !862)
!868 = !{!869}
!869 = distinct !{!869, !870, !"XXH3_accumulate: %acc"}
!870 = distinct !{!870, !"XXH3_accumulate"}
!871 = !DILocation(line: 4214, column: 28, scope: !858, inlinedAt: !862)
!872 = !DILocation(line: 4214, column: 25, scope: !858, inlinedAt: !862)
!873 = !DILocalVariable(name: "acc", arg: 1, scope: !874, file: !20, line: 3782, type: !797)
!874 = distinct !DISubprogram(name: "XXH3_accumulate_512_sse2", scope: !20, file: !20, line: 3782, type: !875, scopeLine: 3785, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !877)
!875 = !DISubroutineType(types: !876)
!876 = !{null, !797, !130, !130}
!877 = !{!873, !878, !879, !880, !883, !885, !886, !887, !891, !892, !893, !894, !895, !896}
!878 = !DILocalVariable(name: "input", arg: 2, scope: !874, file: !20, line: 3783, type: !130)
!879 = !DILocalVariable(name: "secret", arg: 3, scope: !874, file: !20, line: 3784, type: !130)
!880 = !DILocalVariable(name: "xacc", scope: !881, file: !20, line: 3788, type: !882, align: 128)
!881 = distinct !DILexicalBlock(scope: !874, file: !20, line: 3788, column: 5)
!882 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !34)
!883 = !DILocalVariable(name: "xinput", scope: !881, file: !20, line: 3791, type: !884)
!884 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !41)
!885 = !DILocalVariable(name: "xsecret", scope: !881, file: !20, line: 3794, type: !884)
!886 = !DILocalVariable(name: "i", scope: !881, file: !20, line: 3796, type: !83)
!887 = !DILocalVariable(name: "data_vec", scope: !888, file: !20, line: 3799, type: !42)
!888 = distinct !DILexicalBlock(scope: !889, file: !20, line: 3797, column: 60)
!889 = distinct !DILexicalBlock(scope: !890, file: !20, line: 3797, column: 9)
!890 = distinct !DILexicalBlock(scope: !881, file: !20, line: 3797, column: 9)
!891 = !DILocalVariable(name: "key_vec", scope: !888, file: !20, line: 3801, type: !42)
!892 = !DILocalVariable(name: "data_key", scope: !888, file: !20, line: 3803, type: !42)
!893 = !DILocalVariable(name: "data_key_lo", scope: !888, file: !20, line: 3805, type: !42)
!894 = !DILocalVariable(name: "product", scope: !888, file: !20, line: 3807, type: !42)
!895 = !DILocalVariable(name: "data_swap", scope: !888, file: !20, line: 3809, type: !42)
!896 = !DILocalVariable(name: "sum", scope: !888, file: !20, line: 3810, type: !42)
!897 = !DILocation(line: 0, scope: !874, inlinedAt: !898)
!898 = distinct !DILocation(line: 4212, column: 9, scope: !858, inlinedAt: !862)
!899 = !DILocation(line: 0, scope: !881, inlinedAt: !898)
!900 = !DILocation(line: 3799, column: 41, scope: !888, inlinedAt: !898)
!901 = !{!902, !869}
!902 = distinct !{!902, !903, !"XXH3_accumulate_512_sse2: %acc"}
!903 = distinct !{!903, !"XXH3_accumulate_512_sse2"}
!904 = !DILocation(line: 0, scope: !888, inlinedAt: !898)
!905 = !DILocation(line: 3801, column: 41, scope: !888, inlinedAt: !898)
!906 = !DILocation(line: 3803, column: 41, scope: !888, inlinedAt: !898)
!907 = !DILocation(line: 3805, column: 41, scope: !888, inlinedAt: !898)
!908 = !DILocation(line: 3807, column: 41, scope: !888, inlinedAt: !898)
!909 = !DILocation(line: 3809, column: 39, scope: !888, inlinedAt: !898)
!910 = !DILocation(line: 3810, column: 39, scope: !888, inlinedAt: !898)
!911 = !DILocation(line: 3812, column: 23, scope: !888, inlinedAt: !898)
!912 = !DILocation(line: 3799, column: 66, scope: !888, inlinedAt: !898)
!913 = !DILocation(line: 3801, column: 67, scope: !888, inlinedAt: !898)
!914 = !DILocation(line: 4209, column: 33, scope: !859, inlinedAt: !862)
!915 = !DILocation(line: 4209, column: 19, scope: !859, inlinedAt: !862)
!916 = distinct !{!916, !863, !917, !918}
!917 = !DILocation(line: 4215, column: 5, scope: !860, inlinedAt: !862)
!918 = !{!"llvm.loop.mustprogress"}
!919 = !DILocalVariable(name: "acc", arg: 1, scope: !920, file: !20, line: 3817, type: !797)
!920 = distinct !DISubprogram(name: "XXH3_scrambleAcc_sse2", scope: !20, file: !20, line: 3817, type: !921, scopeLine: 3818, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !923)
!921 = !DISubroutineType(types: !922)
!922 = !{null, !797, !130}
!923 = !{!919, !924, !925, !927, !928, !929, !930, !934, !935, !936, !937, !938, !939, !940}
!924 = !DILocalVariable(name: "secret", arg: 2, scope: !920, file: !20, line: 3817, type: !130)
!925 = !DILocalVariable(name: "xacc", scope: !926, file: !20, line: 3820, type: !882, align: 128)
!926 = distinct !DILexicalBlock(scope: !920, file: !20, line: 3820, column: 5)
!927 = !DILocalVariable(name: "xsecret", scope: !926, file: !20, line: 3823, type: !884)
!928 = !DILocalVariable(name: "prime32", scope: !926, file: !20, line: 3824, type: !42)
!929 = !DILocalVariable(name: "i", scope: !926, file: !20, line: 3826, type: !83)
!930 = !DILocalVariable(name: "acc_vec", scope: !931, file: !20, line: 3829, type: !42)
!931 = distinct !DILexicalBlock(scope: !932, file: !20, line: 3827, column: 60)
!932 = distinct !DILexicalBlock(scope: !933, file: !20, line: 3827, column: 9)
!933 = distinct !DILexicalBlock(scope: !926, file: !20, line: 3827, column: 9)
!934 = !DILocalVariable(name: "shifted", scope: !931, file: !20, line: 3830, type: !42)
!935 = !DILocalVariable(name: "data_vec", scope: !931, file: !20, line: 3831, type: !42)
!936 = !DILocalVariable(name: "key_vec", scope: !931, file: !20, line: 3833, type: !42)
!937 = !DILocalVariable(name: "data_key", scope: !931, file: !20, line: 3834, type: !42)
!938 = !DILocalVariable(name: "data_key_hi", scope: !931, file: !20, line: 3837, type: !42)
!939 = !DILocalVariable(name: "prod_lo", scope: !931, file: !20, line: 3838, type: !42)
!940 = !DILocalVariable(name: "prod_hi", scope: !931, file: !20, line: 3839, type: !42)
!941 = !DILocation(line: 0, scope: !920, inlinedAt: !942)
!942 = distinct !DILocation(line: 4235, column: 9, scope: !845, inlinedAt: !837)
!943 = !DILocation(line: 0, scope: !926, inlinedAt: !942)
!944 = !DILocation(line: 0, scope: !931, inlinedAt: !942)
!945 = !DILocation(line: 3830, column: 41, scope: !931, inlinedAt: !942)
!946 = !DILocation(line: 3834, column: 41, scope: !931, inlinedAt: !942)
!947 = !DILocation(line: 3837, column: 41, scope: !931, inlinedAt: !942)
!948 = !DILocation(line: 3838, column: 41, scope: !931, inlinedAt: !942)
!949 = !DILocation(line: 3840, column: 46, scope: !931, inlinedAt: !942)
!950 = !DILocation(line: 3840, column: 23, scope: !931, inlinedAt: !942)
!951 = !DILocation(line: 4233, column: 33, scope: !840, inlinedAt: !837)
!952 = distinct !{!952, !842, !953, !918}
!953 = !DILocation(line: 4236, column: 5, scope: !841, inlinedAt: !837)
!954 = !DILocation(line: 4240, column: 58, scope: !832, inlinedAt: !837)
!955 = !DILocation(line: 4240, column: 72, scope: !832, inlinedAt: !837)
!956 = !DILocation(line: 0, scope: !832, inlinedAt: !837)
!957 = !DILocation(line: 4242, column: 36, scope: !832, inlinedAt: !837)
!958 = !DILocation(line: 0, scope: !848, inlinedAt: !959)
!959 = distinct !DILocation(line: 4242, column: 9, scope: !832, inlinedAt: !837)
!960 = !DILocation(line: 4209, column: 19, scope: !859, inlinedAt: !959)
!961 = !DILocation(line: 4209, column: 5, scope: !860, inlinedAt: !959)
!962 = !DILocation(line: 4210, column: 43, scope: !858, inlinedAt: !959)
!963 = !DILocation(line: 4210, column: 40, scope: !858, inlinedAt: !959)
!964 = !DILocation(line: 0, scope: !858, inlinedAt: !959)
!965 = !DILocation(line: 4211, column: 9, scope: !858, inlinedAt: !959)
!966 = !{!967}
!967 = distinct !{!967, !968, !"XXH3_accumulate: %acc"}
!968 = distinct !{!968, !"XXH3_accumulate"}
!969 = !DILocation(line: 4214, column: 28, scope: !858, inlinedAt: !959)
!970 = !DILocation(line: 4214, column: 25, scope: !858, inlinedAt: !959)
!971 = !DILocation(line: 0, scope: !874, inlinedAt: !972)
!972 = distinct !DILocation(line: 4212, column: 9, scope: !858, inlinedAt: !959)
!973 = !DILocation(line: 0, scope: !881, inlinedAt: !972)
!974 = !DILocation(line: 3799, column: 41, scope: !888, inlinedAt: !972)
!975 = !{!976, !967}
!976 = distinct !{!976, !977, !"XXH3_accumulate_512_sse2: %acc"}
!977 = distinct !{!977, !"XXH3_accumulate_512_sse2"}
!978 = !DILocation(line: 0, scope: !888, inlinedAt: !972)
!979 = !DILocation(line: 3801, column: 41, scope: !888, inlinedAt: !972)
!980 = !DILocation(line: 3803, column: 41, scope: !888, inlinedAt: !972)
!981 = !DILocation(line: 3805, column: 41, scope: !888, inlinedAt: !972)
!982 = !DILocation(line: 3807, column: 41, scope: !888, inlinedAt: !972)
!983 = !DILocation(line: 3809, column: 39, scope: !888, inlinedAt: !972)
!984 = !DILocation(line: 3810, column: 39, scope: !888, inlinedAt: !972)
!985 = !DILocation(line: 3812, column: 23, scope: !888, inlinedAt: !972)
!986 = !DILocation(line: 3799, column: 66, scope: !888, inlinedAt: !972)
!987 = !DILocation(line: 3801, column: 67, scope: !888, inlinedAt: !972)
!988 = !DILocation(line: 4209, column: 33, scope: !859, inlinedAt: !959)
!989 = distinct !{!989, !961, !990, !918}
!990 = !DILocation(line: 4215, column: 5, scope: !860, inlinedAt: !959)
!991 = !DILocation(line: 4245, column: 43, scope: !834, inlinedAt: !837)
!992 = !DILocation(line: 4245, column: 49, scope: !834, inlinedAt: !837)
!993 = !DILocation(line: 0, scope: !834, inlinedAt: !837)
!994 = !DILocation(line: 0, scope: !874, inlinedAt: !995)
!995 = distinct !DILocation(line: 4247, column: 13, scope: !834, inlinedAt: !837)
!996 = !DILocation(line: 0, scope: !881, inlinedAt: !995)
!997 = !DILocation(line: 3799, column: 41, scope: !888, inlinedAt: !995)
!998 = !{!999}
!999 = distinct !{!999, !1000, !"XXH3_accumulate_512_sse2: %acc"}
!1000 = distinct !{!1000, !"XXH3_accumulate_512_sse2"}
!1001 = !DILocation(line: 0, scope: !888, inlinedAt: !995)
!1002 = !DILocation(line: 3803, column: 41, scope: !888, inlinedAt: !995)
!1003 = !DILocation(line: 3805, column: 41, scope: !888, inlinedAt: !995)
!1004 = !DILocation(line: 3807, column: 41, scope: !888, inlinedAt: !995)
!1005 = !DILocation(line: 3809, column: 39, scope: !888, inlinedAt: !995)
!1006 = !DILocation(line: 3810, column: 39, scope: !888, inlinedAt: !995)
!1007 = !DILocation(line: 3812, column: 23, scope: !888, inlinedAt: !995)
!1008 = !DILocation(line: 3799, column: 66, scope: !888, inlinedAt: !995)
!1009 = !DILocation(line: 4304, column: 97, scope: !790, inlinedAt: !812)
!1010 = !DILocalVariable(name: "acc", arg: 1, scope: !1011, file: !20, line: 4260, type: !1014)
!1011 = distinct !DISubprogram(name: "XXH3_mergeAccs", scope: !20, file: !20, line: 4260, type: !1012, scopeLine: 4261, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1016)
!1012 = !DISubroutineType(types: !1013)
!1013 = !{!27, !1014, !135, !26}
!1014 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1015)
!1015 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !170, size: 64)
!1016 = !{!1010, !1017, !1018, !1019, !1020}
!1017 = !DILocalVariable(name: "secret", arg: 2, scope: !1011, file: !20, line: 4260, type: !135)
!1018 = !DILocalVariable(name: "start", arg: 3, scope: !1011, file: !20, line: 4260, type: !26)
!1019 = !DILocalVariable(name: "result64", scope: !1011, file: !20, line: 4262, type: !26)
!1020 = !DILocalVariable(name: "i", scope: !1011, file: !20, line: 4263, type: !83)
!1021 = !DILocation(line: 0, scope: !1011, inlinedAt: !1022)
!1022 = distinct !DILocation(line: 4304, column: 12, scope: !790, inlinedAt: !812)
!1023 = !DILocalVariable(name: "acc", arg: 1, scope: !1024, file: !20, line: 4252, type: !1014)
!1024 = distinct !DISubprogram(name: "XXH3_mix2Accs", scope: !20, file: !20, line: 4252, type: !1025, scopeLine: 4253, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1027)
!1025 = !DISubroutineType(types: !1026)
!1026 = !{!26, !1014, !135}
!1027 = !{!1023, !1028}
!1028 = !DILocalVariable(name: "secret", arg: 2, scope: !1024, file: !20, line: 4252, type: !135)
!1029 = !DILocation(line: 0, scope: !1024, inlinedAt: !1030)
!1030 = distinct !DILocation(line: 4266, column: 21, scope: !1031, inlinedAt: !1022)
!1031 = distinct !DILexicalBlock(scope: !1032, file: !20, line: 4265, column: 29)
!1032 = distinct !DILexicalBlock(scope: !1033, file: !20, line: 4265, column: 5)
!1033 = distinct !DILexicalBlock(scope: !1011, file: !20, line: 4265, column: 5)
!1034 = !DILocation(line: 0, scope: !228, inlinedAt: !1035)
!1035 = distinct !DILocation(line: 4254, column: 12, scope: !1024, inlinedAt: !1030)
!1036 = !DILocation(line: 0, scope: !242, inlinedAt: !1037)
!1037 = distinct !DILocation(line: 3229, column: 29, scope: !228, inlinedAt: !1035)
!1038 = !DILocation(line: 4255, column: 23, scope: !1024, inlinedAt: !1030)
!1039 = !DILocation(line: 4256, column: 23, scope: !1024, inlinedAt: !1030)
!1040 = !DILocation(line: 3129, column: 33, scope: !242, inlinedAt: !1037)
!1041 = !DILocation(line: 3129, column: 52, scope: !242, inlinedAt: !1037)
!1042 = !DILocation(line: 3129, column: 50, scope: !242, inlinedAt: !1037)
!1043 = !DILocation(line: 3132, column: 37, scope: !242, inlinedAt: !1037)
!1044 = !DILocation(line: 3230, column: 26, scope: !228, inlinedAt: !1035)
!1045 = !DILocation(line: 4266, column: 18, scope: !1031, inlinedAt: !1022)
!1046 = !DILocation(line: 0, scope: !259, inlinedAt: !1047)
!1047 = distinct !DILocation(line: 4283, column: 12, scope: !1011, inlinedAt: !1022)
!1048 = !DILocation(line: 0, scope: !266, inlinedAt: !1049)
!1049 = distinct !DILocation(line: 3246, column: 11, scope: !259, inlinedAt: !1047)
!1050 = !DILocation(line: 3237, column: 23, scope: !266, inlinedAt: !1049)
!1051 = !DILocation(line: 3237, column: 16, scope: !266, inlinedAt: !1049)
!1052 = !DILocation(line: 3247, column: 9, scope: !259, inlinedAt: !1047)
!1053 = !DILocation(line: 0, scope: !266, inlinedAt: !1054)
!1054 = distinct !DILocation(line: 3248, column: 11, scope: !259, inlinedAt: !1047)
!1055 = !DILocation(line: 3237, column: 23, scope: !266, inlinedAt: !1054)
!1056 = !DILocation(line: 3237, column: 16, scope: !266, inlinedAt: !1054)
!1057 = !DILocation(line: 4330, column: 5, scope: !780)
!1058 = distinct !DISubprogram(name: "XXH3_len_129to240_64b", scope: !20, file: !20, line: 3457, type: !1059, scopeLine: 3460, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1060)
!1059 = !DISubroutineType(cc: DW_CC_nocall, types: !415)
!1060 = !{!1061, !1062, !1063, !1064, !1065, !1066, !1068, !1070}
!1061 = !DILocalVariable(name: "input", arg: 1, scope: !1058, file: !20, line: 3457, type: !135)
!1062 = !DILocalVariable(name: "len", arg: 2, scope: !1058, file: !20, line: 3457, type: !83)
!1063 = !DILocalVariable(name: "secret", arg: 3, scope: !1058, file: !20, line: 3458, type: !135)
!1064 = !DILocalVariable(name: "secretSize", arg: 4, scope: !1058, file: !20, line: 3458, type: !83)
!1065 = !DILocalVariable(name: "seed", arg: 5, scope: !1058, file: !20, line: 3459, type: !27)
!1066 = !DILocalVariable(name: "acc", scope: !1067, file: !20, line: 3467, type: !26)
!1067 = distinct !DILexicalBlock(scope: !1058, file: !20, line: 3467, column: 5)
!1068 = !DILocalVariable(name: "nbRounds", scope: !1067, file: !20, line: 3468, type: !1069)
!1069 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !33)
!1070 = !DILocalVariable(name: "i", scope: !1067, file: !20, line: 3469, type: !33)
!1071 = !DILocation(line: 0, scope: !1058)
!1072 = !DILocation(line: 3467, column: 27, scope: !1067)
!1073 = !DILocation(line: 0, scope: !1067)
!1074 = !DILocation(line: 3468, column: 30, scope: !1067)
!1075 = !DILocation(line: 0, scope: !441, inlinedAt: !1076)
!1076 = distinct !DILocation(line: 3471, column: 20, scope: !1077)
!1077 = distinct !DILexicalBlock(scope: !1078, file: !20, line: 3470, column: 29)
!1078 = distinct !DILexicalBlock(scope: !1079, file: !20, line: 3470, column: 9)
!1079 = distinct !DILexicalBlock(scope: !1067, file: !20, line: 3470, column: 9)
!1080 = !DILocation(line: 0, scope: !178, inlinedAt: !1081)
!1081 = distinct !DILocation(line: 3416, column: 34, scope: !448, inlinedAt: !1076)
!1082 = !DILocation(line: 0, scope: !185, inlinedAt: !1083)
!1083 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !1081)
!1084 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !1083)
!1085 = !{!1086}
!1086 = distinct !{!1086, !1087, !"XXH3_mix16B: %secret"}
!1087 = distinct !{!1087, !"XXH3_mix16B"}
!1088 = !DILocation(line: 0, scope: !448, inlinedAt: !1076)
!1089 = !DILocation(line: 3417, column: 52, scope: !448, inlinedAt: !1076)
!1090 = !DILocation(line: 0, scope: !178, inlinedAt: !1091)
!1091 = distinct !DILocation(line: 3417, column: 34, scope: !448, inlinedAt: !1076)
!1092 = !DILocation(line: 0, scope: !185, inlinedAt: !1093)
!1093 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !1091)
!1094 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !1093)
!1095 = !DILocation(line: 0, scope: !178, inlinedAt: !1096)
!1096 = distinct !DILocation(line: 3419, column: 25, scope: !448, inlinedAt: !1076)
!1097 = !DILocation(line: 0, scope: !185, inlinedAt: !1098)
!1098 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !1096)
!1099 = !DILocation(line: 3419, column: 22, scope: !448, inlinedAt: !1076)
!1100 = !DILocation(line: 0, scope: !178, inlinedAt: !1101)
!1101 = distinct !DILocation(line: 3420, column: 25, scope: !448, inlinedAt: !1076)
!1102 = !DILocation(line: 0, scope: !185, inlinedAt: !1103)
!1103 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !1101)
!1104 = !DILocation(line: 3420, column: 22, scope: !448, inlinedAt: !1076)
!1105 = !DILocation(line: 0, scope: !228, inlinedAt: !1106)
!1106 = distinct !DILocation(line: 3418, column: 16, scope: !448, inlinedAt: !1076)
!1107 = !DILocation(line: 0, scope: !242, inlinedAt: !1108)
!1108 = distinct !DILocation(line: 3229, column: 29, scope: !228, inlinedAt: !1106)
!1109 = !DILocation(line: 3129, column: 33, scope: !242, inlinedAt: !1108)
!1110 = !DILocation(line: 3129, column: 52, scope: !242, inlinedAt: !1108)
!1111 = !DILocation(line: 3129, column: 50, scope: !242, inlinedAt: !1108)
!1112 = !DILocation(line: 3132, column: 37, scope: !242, inlinedAt: !1108)
!1113 = !DILocation(line: 3230, column: 26, scope: !228, inlinedAt: !1106)
!1114 = !DILocation(line: 3471, column: 17, scope: !1077)
!1115 = !DILocation(line: 3471, column: 37, scope: !1077)
!1116 = !DILocation(line: 0, scope: !259, inlinedAt: !1117)
!1117 = distinct !DILocation(line: 3473, column: 15, scope: !1067)
!1118 = !DILocation(line: 0, scope: !266, inlinedAt: !1119)
!1119 = distinct !DILocation(line: 3246, column: 11, scope: !259, inlinedAt: !1117)
!1120 = !DILocation(line: 3237, column: 23, scope: !266, inlinedAt: !1119)
!1121 = !DILocation(line: 3237, column: 16, scope: !266, inlinedAt: !1119)
!1122 = !DILocation(line: 3247, column: 9, scope: !259, inlinedAt: !1117)
!1123 = !DILocation(line: 0, scope: !266, inlinedAt: !1124)
!1124 = distinct !DILocation(line: 3248, column: 11, scope: !259, inlinedAt: !1117)
!1125 = !DILocation(line: 3237, column: 23, scope: !266, inlinedAt: !1124)
!1126 = !DILocation(line: 3237, column: 16, scope: !266, inlinedAt: !1124)
!1127 = !DILocation(line: 3500, column: 22, scope: !1128)
!1128 = distinct !DILexicalBlock(scope: !1129, file: !20, line: 3500, column: 9)
!1129 = distinct !DILexicalBlock(scope: !1067, file: !20, line: 3500, column: 9)
!1130 = !DILocation(line: 3500, column: 9, scope: !1129)
!1131 = !DILocation(line: 3501, column: 41, scope: !1132)
!1132 = distinct !DILexicalBlock(scope: !1128, file: !20, line: 3500, column: 39)
!1133 = !DILocation(line: 3501, column: 37, scope: !1132)
!1134 = !DILocation(line: 3501, column: 64, scope: !1132)
!1135 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !1136)
!1136 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !1137)
!1137 = distinct !DILocation(line: 3416, column: 34, scope: !448, inlinedAt: !1138)
!1138 = distinct !DILocation(line: 3501, column: 20, scope: !1132)
!1139 = !{!1140}
!1140 = distinct !{!1140, !1141, !"XXH3_mix16B: %secret"}
!1141 = distinct !{!1141, !"XXH3_mix16B"}
!1142 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !1143)
!1143 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !1144)
!1144 = distinct !DILocation(line: 3419, column: 25, scope: !448, inlinedAt: !1138)
!1145 = !DILocation(line: 3419, column: 22, scope: !448, inlinedAt: !1138)
!1146 = !DILocation(line: 3420, column: 22, scope: !448, inlinedAt: !1138)
!1147 = !DILocation(line: 3129, column: 33, scope: !242, inlinedAt: !1148)
!1148 = distinct !DILocation(line: 3229, column: 29, scope: !228, inlinedAt: !1149)
!1149 = distinct !DILocation(line: 3418, column: 16, scope: !448, inlinedAt: !1138)
!1150 = !DILocation(line: 3129, column: 52, scope: !242, inlinedAt: !1148)
!1151 = !DILocation(line: 3129, column: 50, scope: !242, inlinedAt: !1148)
!1152 = !DILocation(line: 3132, column: 37, scope: !242, inlinedAt: !1148)
!1153 = !DILocation(line: 3230, column: 26, scope: !228, inlinedAt: !1149)
!1154 = !DILocation(line: 3501, column: 17, scope: !1132)
!1155 = distinct !{!1155, !1130, !1156, !918, !1157, !1158}
!1156 = !DILocation(line: 3502, column: 9, scope: !1129)
!1157 = !{!"llvm.loop.isvectorized", i32 1}
!1158 = !{!"llvm.loop.unroll.runtime.disable"}
!1159 = !DILocation(line: 3501, column: 52, scope: !1132)
!1160 = !DILocation(line: 0, scope: !441, inlinedAt: !1138)
!1161 = !DILocation(line: 0, scope: !178, inlinedAt: !1137)
!1162 = !DILocation(line: 0, scope: !185, inlinedAt: !1136)
!1163 = !DILocation(line: 0, scope: !448, inlinedAt: !1138)
!1164 = !DILocation(line: 3417, column: 52, scope: !448, inlinedAt: !1138)
!1165 = !DILocation(line: 0, scope: !178, inlinedAt: !1166)
!1166 = distinct !DILocation(line: 3417, column: 34, scope: !448, inlinedAt: !1138)
!1167 = !DILocation(line: 0, scope: !185, inlinedAt: !1168)
!1168 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !1166)
!1169 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !1168)
!1170 = !DILocation(line: 0, scope: !178, inlinedAt: !1144)
!1171 = !DILocation(line: 0, scope: !185, inlinedAt: !1143)
!1172 = !DILocation(line: 3420, column: 44, scope: !448, inlinedAt: !1138)
!1173 = !DILocation(line: 0, scope: !178, inlinedAt: !1174)
!1174 = distinct !DILocation(line: 3420, column: 25, scope: !448, inlinedAt: !1138)
!1175 = !DILocation(line: 0, scope: !185, inlinedAt: !1176)
!1176 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !1174)
!1177 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !1176)
!1178 = !DILocation(line: 0, scope: !228, inlinedAt: !1149)
!1179 = !DILocation(line: 0, scope: !242, inlinedAt: !1148)
!1180 = !DILocation(line: 3500, column: 35, scope: !1128)
!1181 = distinct !{!1181, !1130, !1156, !918, !1158, !1157}
!1182 = !DILocation(line: 3504, column: 34, scope: !1067)
!1183 = !DILocation(line: 3504, column: 40, scope: !1067)
!1184 = !DILocation(line: 0, scope: !441, inlinedAt: !1185)
!1185 = distinct !DILocation(line: 3504, column: 16, scope: !1067)
!1186 = !DILocation(line: 0, scope: !178, inlinedAt: !1187)
!1187 = distinct !DILocation(line: 3416, column: 34, scope: !448, inlinedAt: !1185)
!1188 = !DILocation(line: 0, scope: !185, inlinedAt: !1189)
!1189 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !1187)
!1190 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !1189)
!1191 = !{!1192}
!1192 = distinct !{!1192, !1193, !"XXH3_mix16B: %secret"}
!1193 = distinct !{!1193, !"XXH3_mix16B"}
!1194 = !DILocation(line: 0, scope: !448, inlinedAt: !1185)
!1195 = !DILocation(line: 3417, column: 52, scope: !448, inlinedAt: !1185)
!1196 = !DILocation(line: 0, scope: !178, inlinedAt: !1197)
!1197 = distinct !DILocation(line: 3417, column: 34, scope: !448, inlinedAt: !1185)
!1198 = !DILocation(line: 0, scope: !185, inlinedAt: !1199)
!1199 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !1197)
!1200 = !DILocation(line: 2186, column: 5, scope: !185, inlinedAt: !1199)
!1201 = !DILocation(line: 0, scope: !178, inlinedAt: !1202)
!1202 = distinct !DILocation(line: 3419, column: 25, scope: !448, inlinedAt: !1185)
!1203 = !DILocation(line: 0, scope: !185, inlinedAt: !1204)
!1204 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !1202)
!1205 = !DILocation(line: 3419, column: 22, scope: !448, inlinedAt: !1185)
!1206 = !DILocation(line: 0, scope: !178, inlinedAt: !1207)
!1207 = distinct !DILocation(line: 3420, column: 25, scope: !448, inlinedAt: !1185)
!1208 = !DILocation(line: 0, scope: !185, inlinedAt: !1209)
!1209 = distinct !DILocation(line: 2243, column: 36, scope: !178, inlinedAt: !1207)
!1210 = !DILocation(line: 3420, column: 22, scope: !448, inlinedAt: !1185)
!1211 = !DILocation(line: 0, scope: !228, inlinedAt: !1212)
!1212 = distinct !DILocation(line: 3418, column: 16, scope: !448, inlinedAt: !1185)
!1213 = !DILocation(line: 0, scope: !242, inlinedAt: !1214)
!1214 = distinct !DILocation(line: 3229, column: 29, scope: !228, inlinedAt: !1212)
!1215 = !DILocation(line: 3129, column: 33, scope: !242, inlinedAt: !1214)
!1216 = !DILocation(line: 3129, column: 52, scope: !242, inlinedAt: !1214)
!1217 = !DILocation(line: 3129, column: 50, scope: !242, inlinedAt: !1214)
!1218 = !DILocation(line: 3132, column: 37, scope: !242, inlinedAt: !1214)
!1219 = !DILocation(line: 3230, column: 26, scope: !228, inlinedAt: !1212)
!1220 = !DILocation(line: 3504, column: 13, scope: !1067)
!1221 = !DILocation(line: 0, scope: !259, inlinedAt: !1222)
!1222 = distinct !DILocation(line: 3505, column: 16, scope: !1067)
!1223 = !DILocation(line: 0, scope: !266, inlinedAt: !1224)
!1224 = distinct !DILocation(line: 3246, column: 11, scope: !259, inlinedAt: !1222)
!1225 = !DILocation(line: 3237, column: 23, scope: !266, inlinedAt: !1224)
!1226 = !DILocation(line: 3237, column: 16, scope: !266, inlinedAt: !1224)
!1227 = !DILocation(line: 3247, column: 9, scope: !259, inlinedAt: !1222)
!1228 = !DILocation(line: 0, scope: !266, inlinedAt: !1229)
!1229 = distinct !DILocation(line: 3248, column: 11, scope: !259, inlinedAt: !1222)
!1230 = !DILocation(line: 3237, column: 23, scope: !266, inlinedAt: !1229)
!1231 = !DILocation(line: 3237, column: 16, scope: !266, inlinedAt: !1229)
!1232 = !DILocation(line: 3505, column: 9, scope: !1067)
