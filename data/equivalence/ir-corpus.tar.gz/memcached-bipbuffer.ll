; ModuleID = 'bipbuffer.c'
source_filename = "bipbuffer.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: read) uwtable
define dso_local i32 @bipbuf_unused(ptr nocapture noundef readonly %me) local_unnamed_addr #0 !dbg !13 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !35, metadata !DIExpression()), !dbg !36
  %b_inuse = getelementptr inbounds i8, ptr %me, i64 20, !dbg !37
  %0 = load i32, ptr %b_inuse, align 4, !dbg !37, !tbaa !39
  %cmp = icmp eq i32 %0, 1, !dbg !43
  br i1 %cmp, label %if.then, label %if.else, !dbg !44

if.then:                                          ; preds = %entry
  %a_start = getelementptr inbounds i8, ptr %me, i64 8, !dbg !45
  %1 = load i32, ptr %a_start, align 8, !dbg !45, !tbaa !39
  %b_end = getelementptr inbounds i8, ptr %me, i64 16, !dbg !46
  %2 = load i32, ptr %b_end, align 8, !dbg !46, !tbaa !39
  %sub = sub i32 %1, %2, !dbg !47
  br label %return, !dbg !48

if.else:                                          ; preds = %entry
  %3 = load i64, ptr %me, align 8, !dbg !49, !tbaa !50
  %a_end = getelementptr inbounds i8, ptr %me, i64 12, !dbg !52
  %4 = load i32, ptr %a_end, align 4, !dbg !52, !tbaa !39
  %5 = trunc i64 %3 to i32, !dbg !53
  %conv2 = sub i32 %5, %4, !dbg !53
  br label %return, !dbg !54

return:                                           ; preds = %if.else, %if.then
  %retval.0 = phi i32 [ %sub, %if.then ], [ %conv2, %if.else ], !dbg !55
  ret i32 %retval.0, !dbg !56
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: read) uwtable
define dso_local i32 @bipbuf_size(ptr nocapture noundef readonly %me) local_unnamed_addr #0 !dbg !57 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !59, metadata !DIExpression()), !dbg !60
  %0 = load i64, ptr %me, align 8, !dbg !61, !tbaa !50
  %conv = trunc i64 %0 to i32, !dbg !62
  ret i32 %conv, !dbg !63
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: read) uwtable
define dso_local i32 @bipbuf_used(ptr nocapture noundef readonly %me) local_unnamed_addr #0 !dbg !64 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !66, metadata !DIExpression()), !dbg !67
  %a_end = getelementptr inbounds i8, ptr %me, i64 12, !dbg !68
  %0 = load i32, ptr %a_end, align 4, !dbg !68, !tbaa !39
  %a_start = getelementptr inbounds i8, ptr %me, i64 8, !dbg !69
  %1 = load i32, ptr %a_start, align 8, !dbg !69, !tbaa !39
  %sub = sub i32 %0, %1, !dbg !70
  %b_end = getelementptr inbounds i8, ptr %me, i64 16, !dbg !71
  %2 = load i32, ptr %b_end, align 8, !dbg !71, !tbaa !39
  %add = add i32 %sub, %2, !dbg !72
  ret i32 %add, !dbg !73
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: write) uwtable
define dso_local void @bipbuf_init(ptr nocapture noundef writeonly %me, i32 noundef %size) local_unnamed_addr #1 !dbg !74 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !80, metadata !DIExpression()), !dbg !82
  tail call void @llvm.dbg.value(metadata i32 %size, metadata !81, metadata !DIExpression()), !dbg !82
  %a_start = getelementptr inbounds i8, ptr %me, i64 8, !dbg !83
  %conv = zext i32 %size to i64, !dbg !84
  store i64 %conv, ptr %me, align 8, !dbg !85, !tbaa !50
  store <4 x i32> zeroinitializer, ptr %a_start, align 8, !dbg !86, !tbaa !39
  ret void, !dbg !87
}

; Function Attrs: mustprogress nofree nounwind sanitize_thread willreturn memory(write, argmem: none, inaccessiblemem: readwrite) uwtable
define dso_local noalias noundef ptr @bipbuf_new(i32 noundef %size) local_unnamed_addr #2 !dbg !88 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %size, metadata !92, metadata !DIExpression()), !dbg !94
  tail call void @llvm.dbg.value(metadata i32 %size, metadata !95, metadata !DIExpression()), !dbg !102
  %conv.i = zext i32 %size to i64, !dbg !104
  %add.i = add nuw nsw i64 %conv.i, 24, !dbg !105
  %call1 = tail call noalias ptr @malloc(i64 noundef %add.i) #11, !dbg !106
  tail call void @llvm.dbg.value(metadata ptr %call1, metadata !93, metadata !DIExpression()), !dbg !94
  %tobool.not = icmp eq ptr %call1, null, !dbg !107
  br i1 %tobool.not, label %cleanup, label %if.end, !dbg !109

if.end:                                           ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr %call1, metadata !80, metadata !DIExpression()), !dbg !110
  tail call void @llvm.dbg.value(metadata i32 %size, metadata !81, metadata !DIExpression()), !dbg !110
  %a_start.i = getelementptr inbounds i8, ptr %call1, i64 8, !dbg !112
  store i64 %conv.i, ptr %call1, align 8, !dbg !113, !tbaa !50
  store <4 x i32> zeroinitializer, ptr %a_start.i, align 8, !dbg !114, !tbaa !39
  br label %cleanup, !dbg !115

cleanup:                                          ; preds = %entry, %if.end
  ret ptr %call1, !dbg !116
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare !dbg !117 noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nounwind sanitize_thread willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define dso_local void @bipbuf_free(ptr nocapture noundef %me) local_unnamed_addr #4 !dbg !122 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !126, metadata !DIExpression()), !dbg !127
  tail call void @free(ptr noundef %me) #12, !dbg !128
  ret void, !dbg !129
}

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !130 void @free(ptr allocptr nocapture noundef) local_unnamed_addr #5

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: read) uwtable
define dso_local range(i32 0, 2) i32 @bipbuf_is_empty(ptr nocapture noundef readonly %me) local_unnamed_addr #0 !dbg !133 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !135, metadata !DIExpression()), !dbg !136
  %a_start = getelementptr inbounds i8, ptr %me, i64 8, !dbg !137
  %0 = load i32, ptr %a_start, align 8, !dbg !137, !tbaa !39
  %a_end = getelementptr inbounds i8, ptr %me, i64 12, !dbg !138
  %1 = load i32, ptr %a_end, align 4, !dbg !138, !tbaa !39
  %cmp = icmp eq i32 %0, %1, !dbg !139
  %conv = zext i1 %cmp to i32, !dbg !139
  ret i32 %conv, !dbg !140
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: read) uwtable
define dso_local ptr @bipbuf_request(ptr noundef readonly %me, i32 noundef %size) local_unnamed_addr #0 !dbg !141 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !146, metadata !DIExpression()), !dbg !148
  tail call void @llvm.dbg.value(metadata i32 %size, metadata !147, metadata !DIExpression()), !dbg !148
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !35, metadata !DIExpression()), !dbg !149
  %b_inuse.i = getelementptr inbounds i8, ptr %me, i64 20, !dbg !152
  %0 = load i32, ptr %b_inuse.i, align 4, !dbg !152, !tbaa !39
  %cmp.i = icmp eq i32 %0, 1, !dbg !153
  br i1 %cmp.i, label %bipbuf_unused.exit, label %bipbuf_unused.exit.thread, !dbg !154

bipbuf_unused.exit:                               ; preds = %entry
  %a_start.i = getelementptr inbounds i8, ptr %me, i64 8, !dbg !155
  %1 = load i32, ptr %a_start.i, align 8, !dbg !155, !tbaa !39
  %b_end.i = getelementptr inbounds i8, ptr %me, i64 16, !dbg !156
  %2 = load i32, ptr %b_end.i, align 8, !dbg !156, !tbaa !39
  %sub.i = sub i32 %1, %2, !dbg !157
  %cmp = icmp slt i32 %sub.i, %size, !dbg !158
  br i1 %cmp, label %return, label %if.then2, !dbg !159

bipbuf_unused.exit.thread:                        ; preds = %entry
  %3 = load i64, ptr %me, align 8, !dbg !160, !tbaa !50
  %a_end.i = getelementptr inbounds i8, ptr %me, i64 12, !dbg !161
  %4 = load i32, ptr %a_end.i, align 4, !dbg !161, !tbaa !39
  %5 = trunc i64 %3 to i32, !dbg !162
  %conv2.i = sub i32 %5, %4, !dbg !162
  %cmp13 = icmp slt i32 %conv2.i, %size, !dbg !158
  br i1 %cmp13, label %return, label %if.else, !dbg !159

if.then2:                                         ; preds = %bipbuf_unused.exit
  %data = getelementptr inbounds i8, ptr %me, i64 24, !dbg !163
  %idx.ext = zext i32 %2 to i64, !dbg !166
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %idx.ext, !dbg !166
  br label %return, !dbg !167

if.else:                                          ; preds = %bipbuf_unused.exit.thread
  %data3 = getelementptr inbounds i8, ptr %me, i64 24, !dbg !168
  %idx.ext5 = zext i32 %4 to i64, !dbg !170
  %add.ptr6 = getelementptr inbounds i8, ptr %data3, i64 %idx.ext5, !dbg !170
  br label %return, !dbg !171

return:                                           ; preds = %bipbuf_unused.exit.thread, %bipbuf_unused.exit, %if.else, %if.then2
  %retval.0 = phi ptr [ %add.ptr, %if.then2 ], [ %add.ptr6, %if.else ], [ null, %bipbuf_unused.exit ], [ null, %bipbuf_unused.exit.thread ], !dbg !148
  ret ptr %retval.0, !dbg !172
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: readwrite) uwtable
define dso_local noundef i32 @bipbuf_push(ptr nocapture noundef %me, i32 noundef %size) local_unnamed_addr #6 !dbg !173 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !177, metadata !DIExpression()), !dbg !179
  tail call void @llvm.dbg.value(metadata i32 %size, metadata !178, metadata !DIExpression()), !dbg !179
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !35, metadata !DIExpression()), !dbg !180
  %b_inuse.i = getelementptr inbounds i8, ptr %me, i64 20, !dbg !183
  %0 = load i32, ptr %b_inuse.i, align 4, !dbg !183, !tbaa !39
  %cmp.i = icmp eq i32 %0, 1, !dbg !184
  br i1 %cmp.i, label %bipbuf_unused.exit, label %bipbuf_unused.exit.thread, !dbg !185

bipbuf_unused.exit:                               ; preds = %entry
  %a_start.i = getelementptr inbounds i8, ptr %me, i64 8, !dbg !186
  %1 = load i32, ptr %a_start.i, align 8, !dbg !186, !tbaa !39
  %b_end.i = getelementptr inbounds i8, ptr %me, i64 16, !dbg !187
  %2 = load i32, ptr %b_end.i, align 8, !dbg !187, !tbaa !39
  %sub.i = sub i32 %1, %2, !dbg !188
  %cmp = icmp slt i32 %sub.i, %size, !dbg !189
  br i1 %cmp, label %return, label %if.then2, !dbg !190

bipbuf_unused.exit.thread:                        ; preds = %entry
  %3 = load i64, ptr %me, align 8, !dbg !191, !tbaa !50
  %a_end.i = getelementptr inbounds i8, ptr %me, i64 12, !dbg !192
  %4 = load i32, ptr %a_end.i, align 4, !dbg !192, !tbaa !39
  %5 = trunc i64 %3 to i32, !dbg !193
  %conv2.i = sub i32 %5, %4, !dbg !193
  %cmp21 = icmp slt i32 %conv2.i, %size, !dbg !189
  br i1 %cmp21, label %return, label %if.else, !dbg !190

if.then2:                                         ; preds = %bipbuf_unused.exit
  %add = add i32 %2, %size, !dbg !194
  store i32 %add, ptr %b_end.i, align 8, !dbg !194, !tbaa !39
  %.pre = load i64, ptr %me, align 8, !dbg !197, !tbaa !50
  %a_end.i12.phi.trans.insert = getelementptr inbounds i8, ptr %me, i64 12
  %.pre22 = load i32, ptr %a_end.i12.phi.trans.insert, align 4, !dbg !203, !tbaa !39
  br label %if.end4, !dbg !204

if.else:                                          ; preds = %bipbuf_unused.exit.thread
  %add3 = add i32 %4, %size, !dbg !205
  store i32 %add3, ptr %a_end.i, align 4, !dbg !205, !tbaa !39
  %a_start.i14.phi.trans.insert = getelementptr inbounds i8, ptr %me, i64 8
  %.pre23 = load i32, ptr %a_start.i14.phi.trans.insert, align 8, !dbg !207, !tbaa !39
  %b_end.i15.phi.trans.insert = getelementptr inbounds i8, ptr %me, i64 16
  %.pre24 = load i32, ptr %b_end.i15.phi.trans.insert, align 8, !dbg !208, !tbaa !39
  br label %if.end4

if.end4:                                          ; preds = %if.else, %if.then2
  %6 = phi i32 [ %.pre24, %if.else ], [ %add, %if.then2 ], !dbg !208
  %7 = phi i32 [ %.pre23, %if.else ], [ %1, %if.then2 ], !dbg !207
  %8 = phi i32 [ %add3, %if.else ], [ %.pre22, %if.then2 ], !dbg !203
  %9 = phi i64 [ %3, %if.else ], [ %.pre, %if.then2 ], !dbg !197
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !201, metadata !DIExpression()), !dbg !209
  %conv.i = zext i32 %8 to i64, !dbg !210
  %sub.i13 = sub i64 %9, %conv.i, !dbg !211
  %sub1.i = sub i32 %7, %6, !dbg !212
  %conv2.i16 = zext i32 %sub1.i to i64, !dbg !213
  %cmp.i17 = icmp ult i64 %sub.i13, %conv2.i16, !dbg !214
  br i1 %cmp.i17, label %if.then.i18, label %return, !dbg !215

if.then.i18:                                      ; preds = %if.end4
  store i32 1, ptr %b_inuse.i, align 4, !dbg !216, !tbaa !39
  br label %return, !dbg !217

return:                                           ; preds = %if.then.i18, %if.end4, %bipbuf_unused.exit.thread, %bipbuf_unused.exit
  %retval.0 = phi i32 [ 0, %bipbuf_unused.exit ], [ 0, %bipbuf_unused.exit.thread ], [ %size, %if.end4 ], [ %size, %if.then.i18 ], !dbg !179
  ret i32 %retval.0, !dbg !218
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: readwrite) uwtable
define dso_local noundef i32 @bipbuf_offer(ptr nocapture noundef %me, ptr nocapture noundef readonly %data, i32 noundef %size) local_unnamed_addr #6 !dbg !219 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !225, metadata !DIExpression()), !dbg !228
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !226, metadata !DIExpression()), !dbg !228
  tail call void @llvm.dbg.value(metadata i32 %size, metadata !227, metadata !DIExpression()), !dbg !228
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !35, metadata !DIExpression()), !dbg !229
  %b_inuse.i = getelementptr inbounds i8, ptr %me, i64 20, !dbg !232
  %0 = load i32, ptr %b_inuse.i, align 4, !dbg !232, !tbaa !39
  %cmp.i = icmp eq i32 %0, 1, !dbg !233
  br i1 %cmp.i, label %bipbuf_unused.exit, label %bipbuf_unused.exit.thread, !dbg !234

bipbuf_unused.exit:                               ; preds = %entry
  %a_start.i = getelementptr inbounds i8, ptr %me, i64 8, !dbg !235
  %1 = load i32, ptr %a_start.i, align 8, !dbg !235, !tbaa !39
  %b_end.i = getelementptr inbounds i8, ptr %me, i64 16, !dbg !236
  %2 = load i32, ptr %b_end.i, align 8, !dbg !236, !tbaa !39
  %sub.i = sub i32 %1, %2, !dbg !237
  %cmp = icmp slt i32 %sub.i, %size, !dbg !238
  br i1 %cmp, label %return, label %if.then2, !dbg !239

bipbuf_unused.exit.thread:                        ; preds = %entry
  %3 = load i64, ptr %me, align 8, !dbg !240, !tbaa !50
  %a_end.i = getelementptr inbounds i8, ptr %me, i64 12, !dbg !241
  %4 = load i32, ptr %a_end.i, align 4, !dbg !241, !tbaa !39
  %5 = trunc i64 %3 to i32, !dbg !242
  %conv2.i = sub i32 %5, %4, !dbg !242
  %cmp36 = icmp slt i32 %conv2.i, %size, !dbg !238
  br i1 %cmp36, label %return, label %if.else, !dbg !239

if.then2:                                         ; preds = %bipbuf_unused.exit
  %data3 = getelementptr inbounds i8, ptr %me, i64 24, !dbg !243
  %idx.ext = zext i32 %2 to i64, !dbg !246
  %add.ptr = getelementptr inbounds i8, ptr %data3, i64 %idx.ext, !dbg !246
  %conv = sext i32 %size to i64, !dbg !247
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr, ptr align 1 %data, i64 %conv, i1 false), !dbg !248
  %6 = load i32, ptr %b_end.i, align 8, !dbg !249, !tbaa !39
  %add = add i32 %6, %size, !dbg !249
  store i32 %add, ptr %b_end.i, align 8, !dbg !249, !tbaa !39
  %a_end.i27.phi.trans.insert = getelementptr inbounds i8, ptr %me, i64 12
  %.pre = load i32, ptr %a_end.i27.phi.trans.insert, align 4, !dbg !250, !tbaa !39
  br label %if.end12, !dbg !252

if.else:                                          ; preds = %bipbuf_unused.exit.thread
  %data5 = getelementptr inbounds i8, ptr %me, i64 24, !dbg !253
  %idx.ext7 = zext i32 %4 to i64, !dbg !255
  %add.ptr8 = getelementptr inbounds i8, ptr %data5, i64 %idx.ext7, !dbg !255
  %conv9 = sext i32 %size to i64, !dbg !256
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr8, ptr align 1 %data, i64 %conv9, i1 false), !dbg !257
  %7 = load i32, ptr %a_end.i, align 4, !dbg !258, !tbaa !39
  %add11 = add i32 %7, %size, !dbg !258
  store i32 %add11, ptr %a_end.i, align 4, !dbg !258, !tbaa !39
  %b_end.i30.phi.trans.insert = getelementptr inbounds i8, ptr %me, i64 16
  %.pre37 = load i32, ptr %b_end.i30.phi.trans.insert, align 8, !dbg !259, !tbaa !39
  br label %if.end12

if.end12:                                         ; preds = %if.else, %if.then2
  %8 = phi i32 [ %.pre37, %if.else ], [ %add, %if.then2 ], !dbg !259
  %9 = phi i32 [ %add11, %if.else ], [ %.pre, %if.then2 ], !dbg !250
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !201, metadata !DIExpression()), !dbg !260
  %10 = load i64, ptr %me, align 8, !dbg !261, !tbaa !50
  %conv.i = zext i32 %9 to i64, !dbg !262
  %sub.i28 = sub i64 %10, %conv.i, !dbg !263
  %a_start.i29 = getelementptr inbounds i8, ptr %me, i64 8, !dbg !264
  %11 = load i32, ptr %a_start.i29, align 8, !dbg !264, !tbaa !39
  %sub1.i = sub i32 %11, %8, !dbg !265
  %conv2.i31 = zext i32 %sub1.i to i64, !dbg !266
  %cmp.i32 = icmp ult i64 %sub.i28, %conv2.i31, !dbg !267
  br i1 %cmp.i32, label %if.then.i33, label %return, !dbg !268

if.then.i33:                                      ; preds = %if.end12
  store i32 1, ptr %b_inuse.i, align 4, !dbg !269, !tbaa !39
  br label %return, !dbg !270

return:                                           ; preds = %if.then.i33, %if.end12, %bipbuf_unused.exit.thread, %bipbuf_unused.exit
  %retval.0 = phi i32 [ 0, %bipbuf_unused.exit ], [ 0, %bipbuf_unused.exit.thread ], [ %size, %if.end12 ], [ %size, %if.then.i33 ], !dbg !228
  ret i32 %retval.0, !dbg !271
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #7

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: read) uwtable
define dso_local ptr @bipbuf_peek(ptr noundef readonly %me, i32 noundef %size) local_unnamed_addr #0 !dbg !272 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !276, metadata !DIExpression()), !dbg !278
  tail call void @llvm.dbg.value(metadata i32 %size, metadata !277, metadata !DIExpression()), !dbg !278
  %0 = load i64, ptr %me, align 8, !dbg !279, !tbaa !50
  %a_start = getelementptr inbounds i8, ptr %me, i64 8, !dbg !281
  %1 = load i32, ptr %a_start, align 8, !dbg !281, !tbaa !39
  %add = add i32 %1, %size, !dbg !282
  %conv = zext i32 %add to i64, !dbg !283
  %cmp = icmp ult i64 %0, %conv, !dbg !284
  br i1 %cmp, label %return, label %if.end, !dbg !285

if.end:                                           ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !135, metadata !DIExpression()), !dbg !286
  %a_end.i = getelementptr inbounds i8, ptr %me, i64 12, !dbg !289
  %2 = load i32, ptr %a_end.i, align 4, !dbg !289, !tbaa !39
  %cmp.i.not = icmp eq i32 %1, %2, !dbg !290
  br i1 %cmp.i.not, label %return, label %if.end4, !dbg !291

if.end4:                                          ; preds = %if.end
  %data = getelementptr inbounds i8, ptr %me, i64 24, !dbg !292
  %idx.ext = zext i32 %1 to i64, !dbg !293
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %idx.ext, !dbg !293
  br label %return, !dbg !294

return:                                           ; preds = %if.end, %entry, %if.end4
  %retval.0 = phi ptr [ %add.ptr, %if.end4 ], [ null, %entry ], [ null, %if.end ], !dbg !278
  ret ptr %retval.0, !dbg !295
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: readwrite) uwtable
define dso_local ptr @bipbuf_peek_all(ptr noundef readonly %me, ptr nocapture noundef writeonly %size) local_unnamed_addr #6 !dbg !296 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !301, metadata !DIExpression()), !dbg !303
  tail call void @llvm.dbg.value(metadata ptr %size, metadata !302, metadata !DIExpression()), !dbg !303
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !135, metadata !DIExpression()), !dbg !304
  %a_start.i = getelementptr inbounds i8, ptr %me, i64 8, !dbg !307
  %0 = load i32, ptr %a_start.i, align 8, !dbg !307, !tbaa !39
  %a_end.i = getelementptr inbounds i8, ptr %me, i64 12, !dbg !308
  %1 = load i32, ptr %a_end.i, align 4, !dbg !308, !tbaa !39
  %cmp.i.not = icmp eq i32 %0, %1, !dbg !309
  br i1 %cmp.i.not, label %return, label %if.end, !dbg !310

if.end:                                           ; preds = %entry
  %sub = sub i32 %1, %0, !dbg !311
  store i32 %sub, ptr %size, align 4, !dbg !312, !tbaa !39
  %data = getelementptr inbounds i8, ptr %me, i64 24, !dbg !313
  %2 = load i32, ptr %a_start.i, align 8, !dbg !314, !tbaa !39
  %idx.ext = zext i32 %2 to i64, !dbg !315
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %idx.ext, !dbg !315
  br label %return, !dbg !316

return:                                           ; preds = %entry, %if.end
  %retval.0 = phi ptr [ %add.ptr, %if.end ], [ null, %entry ], !dbg !303
  ret ptr %retval.0, !dbg !317
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(write, argmem: readwrite, inaccessiblemem: none) uwtable
define dso_local ptr @bipbuf_poll(ptr noundef %me, i32 noundef %size) local_unnamed_addr #8 !dbg !318 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !322, metadata !DIExpression()), !dbg !325
  tail call void @llvm.dbg.value(metadata i32 %size, metadata !323, metadata !DIExpression()), !dbg !325
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !135, metadata !DIExpression()), !dbg !326
  %a_start.i = getelementptr inbounds i8, ptr %me, i64 8, !dbg !329
  %0 = load i32, ptr %a_start.i, align 8, !dbg !329, !tbaa !39
  %a_end.i = getelementptr inbounds i8, ptr %me, i64 12, !dbg !330
  %1 = load i32, ptr %a_end.i, align 4, !dbg !330, !tbaa !39
  %cmp.i.not = icmp eq i32 %0, %1, !dbg !331
  br i1 %cmp.i.not, label %return, label %if.end, !dbg !332

if.end:                                           ; preds = %entry
  %2 = load i64, ptr %me, align 8, !dbg !333, !tbaa !50
  %add = add i32 %0, %size, !dbg !335
  %conv = zext i32 %add to i64, !dbg !336
  %cmp = icmp ult i64 %2, %conv, !dbg !337
  br i1 %cmp, label %return, label %if.end4, !dbg !338

if.end4:                                          ; preds = %if.end
  %data = getelementptr inbounds i8, ptr %me, i64 24, !dbg !339
  %idx.ext = zext i32 %0 to i64, !dbg !340
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %idx.ext, !dbg !340
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !324, metadata !DIExpression()), !dbg !325
  store i32 %add, ptr %a_start.i, align 8, !dbg !341, !tbaa !39
  %cmp9 = icmp eq i32 %add, %1, !dbg !342
  br i1 %cmp9, label %if.then11, label %if.end22, !dbg !344

if.then11:                                        ; preds = %if.end4
  %b_inuse = getelementptr inbounds i8, ptr %me, i64 20, !dbg !345
  %3 = load i32, ptr %b_inuse, align 4, !dbg !345, !tbaa !39
  %cmp12 = icmp eq i32 %3, 1, !dbg !348
  br i1 %cmp12, label %if.then14, label %if.end22.sink.split, !dbg !349

if.then14:                                        ; preds = %if.then11
  store i32 0, ptr %a_start.i, align 8, !dbg !350, !tbaa !39
  %b_end = getelementptr inbounds i8, ptr %me, i64 16, !dbg !352
  %4 = load i32, ptr %b_end, align 8, !dbg !352, !tbaa !39
  store i32 %4, ptr %a_end.i, align 4, !dbg !353, !tbaa !39
  br label %if.end22.sink.split, !dbg !354

if.end22.sink.split:                              ; preds = %if.then11, %if.then14
  %b_inuse.sink = phi ptr [ %b_inuse, %if.then14 ], [ %a_end.i, %if.then11 ]
  %b_end.sink = phi ptr [ %b_end, %if.then14 ], [ %a_start.i, %if.then11 ]
  %.ph = phi i32 [ %4, %if.then14 ], [ 0, %if.then11 ]
  store i32 0, ptr %b_inuse.sink, align 4, !dbg !355, !tbaa !39
  store i32 0, ptr %b_end.sink, align 8, !dbg !355, !tbaa !39
  br label %if.end22, !dbg !356

if.end22:                                         ; preds = %if.end22.sink.split, %if.end4
  %5 = phi i32 [ %add, %if.end4 ], [ 0, %if.end22.sink.split ], !dbg !358
  %6 = phi i32 [ %1, %if.end4 ], [ %.ph, %if.end22.sink.split ], !dbg !359
  tail call void @llvm.dbg.value(metadata ptr %me, metadata !201, metadata !DIExpression()), !dbg !360
  %conv.i41 = zext i32 %6 to i64, !dbg !356
  %sub.i = sub i64 %2, %conv.i41, !dbg !361
  %b_end.i = getelementptr inbounds i8, ptr %me, i64 16, !dbg !362
  %7 = load i32, ptr %b_end.i, align 8, !dbg !362, !tbaa !39
  %sub1.i = sub i32 %5, %7, !dbg !363
  %conv2.i = zext i32 %sub1.i to i64, !dbg !364
  %cmp.i43 = icmp ult i64 %sub.i, %conv2.i, !dbg !365
  br i1 %cmp.i43, label %if.then.i, label %return, !dbg !366

if.then.i:                                        ; preds = %if.end22
  %b_inuse.i = getelementptr inbounds i8, ptr %me, i64 20, !dbg !367
  store i32 1, ptr %b_inuse.i, align 4, !dbg !368, !tbaa !39
  br label %return, !dbg !369

return:                                           ; preds = %if.then.i, %if.end22, %if.end, %entry
  %retval.0 = phi ptr [ null, %entry ], [ null, %if.end ], [ %add.ptr, %if.end22 ], [ %add.ptr, %if.then.i ], !dbg !325
  ret ptr %retval.0, !dbg !370
}

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #9 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #10

attributes #0 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: read) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: write) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { mustprogress nofree nounwind sanitize_thread willreturn memory(write, argmem: none, inaccessiblemem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { mustprogress nounwind sanitize_thread willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(argmem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(write, argmem: readwrite, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { nounwind uwtable }
attributes #10 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { nounwind allocsize(0) }
attributes #12 = { nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!5, !6, !7, !8, !9, !10, !11}
!llvm.ident = !{!12}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !2, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "bipbuffer.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "9d757a632775992bd4e9047d1de68029")
!2 = !{!3}
!3 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !4, size: 64)
!4 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!5 = !{i32 7, !"Dwarf Version", i32 5}
!6 = !{i32 2, !"Debug Info Version", i32 3}
!7 = !{i32 1, !"wchar_size", i32 4}
!8 = !{i32 8, !"PIC Level", i32 2}
!9 = !{i32 7, !"PIE Level", i32 2}
!10 = !{i32 7, !"uwtable", i32 2}
!11 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!12 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!13 = distinct !DISubprogram(name: "bipbuf_unused", scope: !1, file: !1, line: 23, type: !14, scopeLine: 24, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !34)
!14 = !DISubroutineType(types: !15)
!15 = !{!16, !17}
!16 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !19)
!19 = !DIDerivedType(tag: DW_TAG_typedef, name: "bipbuf_t", file: !20, line: 18, baseType: !21)
!20 = !DIFile(filename: "./bipbuffer.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "99606bcb8393045e6bc9eef40115066f")
!21 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !20, line: 4, size: 192, elements: !22)
!22 = !{!23, !25, !27, !28, !29, !30}
!23 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !21, file: !20, line: 6, baseType: !24, size: 64)
!24 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!25 = !DIDerivedType(tag: DW_TAG_member, name: "a_start", scope: !21, file: !20, line: 9, baseType: !26, size: 32, offset: 64)
!26 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!27 = !DIDerivedType(tag: DW_TAG_member, name: "a_end", scope: !21, file: !20, line: 9, baseType: !26, size: 32, offset: 96)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "b_end", scope: !21, file: !20, line: 12, baseType: !26, size: 32, offset: 128)
!29 = !DIDerivedType(tag: DW_TAG_member, name: "b_inuse", scope: !21, file: !20, line: 15, baseType: !16, size: 32, offset: 160)
!30 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !21, file: !20, line: 17, baseType: !31, offset: 192)
!31 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, elements: !32)
!32 = !{!33}
!33 = !DISubrange(count: -1)
!34 = !{!35}
!35 = !DILocalVariable(name: "me", arg: 1, scope: !13, file: !1, line: 23, type: !17)
!36 = !DILocation(line: 0, scope: !13)
!37 = !DILocation(line: 25, column: 18, scope: !38)
!38 = distinct !DILexicalBlock(scope: !13, file: !1, line: 25, column: 9)
!39 = !{!40, !40, i64 0}
!40 = !{!"int", !41, i64 0}
!41 = !{!"omnipotent char", !42, i64 0}
!42 = !{!"Simple C/C++ TBAA"}
!43 = !DILocation(line: 25, column: 11, scope: !38)
!44 = !DILocation(line: 25, column: 9, scope: !13)
!45 = !DILocation(line: 27, column: 20, scope: !38)
!46 = !DILocation(line: 27, column: 34, scope: !38)
!47 = !DILocation(line: 27, column: 28, scope: !38)
!48 = !DILocation(line: 27, column: 9, scope: !38)
!49 = !DILocation(line: 29, column: 20, scope: !38)
!50 = !{!51, !51, i64 0}
!51 = !{!"long", !41, i64 0}
!52 = !DILocation(line: 29, column: 31, scope: !38)
!53 = !DILocation(line: 29, column: 16, scope: !38)
!54 = !DILocation(line: 29, column: 9, scope: !38)
!55 = !DILocation(line: 0, scope: !38)
!56 = !DILocation(line: 30, column: 1, scope: !13)
!57 = distinct !DISubprogram(name: "bipbuf_size", scope: !1, file: !1, line: 32, type: !14, scopeLine: 33, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !58)
!58 = !{!59}
!59 = !DILocalVariable(name: "me", arg: 1, scope: !57, file: !1, line: 32, type: !17)
!60 = !DILocation(line: 0, scope: !57)
!61 = !DILocation(line: 34, column: 16, scope: !57)
!62 = !DILocation(line: 34, column: 12, scope: !57)
!63 = !DILocation(line: 34, column: 5, scope: !57)
!64 = distinct !DISubprogram(name: "bipbuf_used", scope: !1, file: !1, line: 37, type: !14, scopeLine: 38, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !65)
!65 = !{!66}
!66 = !DILocalVariable(name: "me", arg: 1, scope: !64, file: !1, line: 37, type: !17)
!67 = !DILocation(line: 0, scope: !64)
!68 = !DILocation(line: 39, column: 17, scope: !64)
!69 = !DILocation(line: 39, column: 29, scope: !64)
!70 = !DILocation(line: 39, column: 23, scope: !64)
!71 = !DILocation(line: 39, column: 44, scope: !64)
!72 = !DILocation(line: 39, column: 38, scope: !64)
!73 = !DILocation(line: 39, column: 5, scope: !64)
!74 = distinct !DISubprogram(name: "bipbuf_init", scope: !1, file: !1, line: 42, type: !75, scopeLine: 43, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !79)
!75 = !DISubroutineType(types: !76)
!76 = !{null, !77, !78}
!77 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !19, size: 64)
!78 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !26)
!79 = !{!80, !81}
!80 = !DILocalVariable(name: "me", arg: 1, scope: !74, file: !1, line: 42, type: !77)
!81 = !DILocalVariable(name: "size", arg: 2, scope: !74, file: !1, line: 42, type: !78)
!82 = !DILocation(line: 0, scope: !74)
!83 = !DILocation(line: 44, column: 9, scope: !74)
!84 = !DILocation(line: 45, column: 16, scope: !74)
!85 = !DILocation(line: 45, column: 14, scope: !74)
!86 = !DILocation(line: 44, column: 17, scope: !74)
!87 = !DILocation(line: 47, column: 1, scope: !74)
!88 = distinct !DISubprogram(name: "bipbuf_new", scope: !1, file: !1, line: 49, type: !89, scopeLine: 50, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !91)
!89 = !DISubroutineType(types: !90)
!90 = !{!77, !78}
!91 = !{!92, !93}
!92 = !DILocalVariable(name: "size", arg: 1, scope: !88, file: !1, line: 49, type: !78)
!93 = !DILocalVariable(name: "me", scope: !88, file: !1, line: 51, type: !77)
!94 = !DILocation(line: 0, scope: !88)
!95 = !DILocalVariable(name: "size", arg: 1, scope: !96, file: !1, line: 18, type: !78)
!96 = distinct !DISubprogram(name: "bipbuf_sizeof", scope: !1, file: !1, line: 18, type: !97, scopeLine: 19, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !101)
!97 = !DISubroutineType(types: !98)
!98 = !{!99, !78}
!99 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !100, line: 18, baseType: !24)
!100 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!101 = !{!95}
!102 = !DILocation(line: 0, scope: !96, inlinedAt: !103)
!103 = distinct !DILocation(line: 51, column: 27, scope: !88)
!104 = !DILocation(line: 20, column: 31, scope: !96, inlinedAt: !103)
!105 = !DILocation(line: 20, column: 29, scope: !96, inlinedAt: !103)
!106 = !DILocation(line: 51, column: 20, scope: !88)
!107 = !DILocation(line: 52, column: 10, scope: !108)
!108 = distinct !DILexicalBlock(scope: !88, file: !1, line: 52, column: 9)
!109 = !DILocation(line: 52, column: 9, scope: !88)
!110 = !DILocation(line: 0, scope: !74, inlinedAt: !111)
!111 = distinct !DILocation(line: 54, column: 5, scope: !88)
!112 = !DILocation(line: 44, column: 9, scope: !74, inlinedAt: !111)
!113 = !DILocation(line: 45, column: 14, scope: !74, inlinedAt: !111)
!114 = !DILocation(line: 44, column: 17, scope: !74, inlinedAt: !111)
!115 = !DILocation(line: 55, column: 5, scope: !88)
!116 = !DILocation(line: 56, column: 1, scope: !88)
!117 = !DISubprogram(name: "malloc", scope: !118, file: !118, line: 672, type: !119, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!118 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!119 = !DISubroutineType(types: !120)
!120 = !{!121, !99}
!121 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!122 = distinct !DISubprogram(name: "bipbuf_free", scope: !1, file: !1, line: 58, type: !123, scopeLine: 59, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !125)
!123 = !DISubroutineType(types: !124)
!124 = !{null, !77}
!125 = !{!126}
!126 = !DILocalVariable(name: "me", arg: 1, scope: !122, file: !1, line: 58, type: !77)
!127 = !DILocation(line: 0, scope: !122)
!128 = !DILocation(line: 60, column: 5, scope: !122)
!129 = !DILocation(line: 61, column: 1, scope: !122)
!130 = !DISubprogram(name: "free", scope: !118, file: !118, line: 687, type: !131, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!131 = !DISubroutineType(types: !132)
!132 = !{null, !121}
!133 = distinct !DISubprogram(name: "bipbuf_is_empty", scope: !1, file: !1, line: 63, type: !14, scopeLine: 64, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !134)
!134 = !{!135}
!135 = !DILocalVariable(name: "me", arg: 1, scope: !133, file: !1, line: 63, type: !17)
!136 = !DILocation(line: 0, scope: !133)
!137 = !DILocation(line: 65, column: 16, scope: !133)
!138 = !DILocation(line: 65, column: 31, scope: !133)
!139 = !DILocation(line: 65, column: 24, scope: !133)
!140 = !DILocation(line: 65, column: 5, scope: !133)
!141 = distinct !DISubprogram(name: "bipbuf_request", scope: !1, file: !1, line: 77, type: !142, scopeLine: 78, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !145)
!142 = !DISubroutineType(types: !143)
!143 = !{!3, !77, !144}
!144 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !16)
!145 = !{!146, !147}
!146 = !DILocalVariable(name: "me", arg: 1, scope: !141, file: !1, line: 77, type: !77)
!147 = !DILocalVariable(name: "size", arg: 2, scope: !141, file: !1, line: 77, type: !144)
!148 = !DILocation(line: 0, scope: !141)
!149 = !DILocation(line: 0, scope: !13, inlinedAt: !150)
!150 = distinct !DILocation(line: 79, column: 9, scope: !151)
!151 = distinct !DILexicalBlock(scope: !141, file: !1, line: 79, column: 9)
!152 = !DILocation(line: 25, column: 18, scope: !38, inlinedAt: !150)
!153 = !DILocation(line: 25, column: 11, scope: !38, inlinedAt: !150)
!154 = !DILocation(line: 25, column: 9, scope: !13, inlinedAt: !150)
!155 = !DILocation(line: 27, column: 20, scope: !38, inlinedAt: !150)
!156 = !DILocation(line: 27, column: 34, scope: !38, inlinedAt: !150)
!157 = !DILocation(line: 27, column: 28, scope: !38, inlinedAt: !150)
!158 = !DILocation(line: 79, column: 27, scope: !151)
!159 = !DILocation(line: 79, column: 9, scope: !141)
!160 = !DILocation(line: 29, column: 20, scope: !38, inlinedAt: !150)
!161 = !DILocation(line: 29, column: 31, scope: !38, inlinedAt: !150)
!162 = !DILocation(line: 29, column: 16, scope: !38, inlinedAt: !150)
!163 = !DILocation(line: 83, column: 37, scope: !164)
!164 = distinct !DILexicalBlock(scope: !165, file: !1, line: 82, column: 5)
!165 = distinct !DILexicalBlock(scope: !141, file: !1, line: 81, column: 9)
!166 = !DILocation(line: 83, column: 42, scope: !164)
!167 = !DILocation(line: 83, column: 9, scope: !164)
!168 = !DILocation(line: 87, column: 37, scope: !169)
!169 = distinct !DILexicalBlock(scope: !165, file: !1, line: 86, column: 5)
!170 = !DILocation(line: 87, column: 42, scope: !169)
!171 = !DILocation(line: 87, column: 9, scope: !169)
!172 = !DILocation(line: 89, column: 1, scope: !141)
!173 = distinct !DISubprogram(name: "bipbuf_push", scope: !1, file: !1, line: 91, type: !174, scopeLine: 92, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !176)
!174 = !DISubroutineType(types: !175)
!175 = !{!16, !77, !144}
!176 = !{!177, !178}
!177 = !DILocalVariable(name: "me", arg: 1, scope: !173, file: !1, line: 91, type: !77)
!178 = !DILocalVariable(name: "size", arg: 2, scope: !173, file: !1, line: 91, type: !144)
!179 = !DILocation(line: 0, scope: !173)
!180 = !DILocation(line: 0, scope: !13, inlinedAt: !181)
!181 = distinct !DILocation(line: 93, column: 9, scope: !182)
!182 = distinct !DILexicalBlock(scope: !173, file: !1, line: 93, column: 9)
!183 = !DILocation(line: 25, column: 18, scope: !38, inlinedAt: !181)
!184 = !DILocation(line: 25, column: 11, scope: !38, inlinedAt: !181)
!185 = !DILocation(line: 25, column: 9, scope: !13, inlinedAt: !181)
!186 = !DILocation(line: 27, column: 20, scope: !38, inlinedAt: !181)
!187 = !DILocation(line: 27, column: 34, scope: !38, inlinedAt: !181)
!188 = !DILocation(line: 27, column: 28, scope: !38, inlinedAt: !181)
!189 = !DILocation(line: 93, column: 27, scope: !182)
!190 = !DILocation(line: 93, column: 9, scope: !173)
!191 = !DILocation(line: 29, column: 20, scope: !38, inlinedAt: !181)
!192 = !DILocation(line: 29, column: 31, scope: !38, inlinedAt: !181)
!193 = !DILocation(line: 29, column: 16, scope: !38, inlinedAt: !181)
!194 = !DILocation(line: 98, column: 19, scope: !195)
!195 = distinct !DILexicalBlock(scope: !196, file: !1, line: 97, column: 5)
!196 = distinct !DILexicalBlock(scope: !173, file: !1, line: 96, column: 9)
!197 = !DILocation(line: 72, column: 13, scope: !198, inlinedAt: !202)
!198 = distinct !DILexicalBlock(scope: !199, file: !1, line: 72, column: 9)
!199 = distinct !DISubprogram(name: "__check_for_switch_to_b", scope: !1, file: !1, line: 70, type: !123, scopeLine: 71, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !200)
!200 = !{!201}
!201 = !DILocalVariable(name: "me", arg: 1, scope: !199, file: !1, line: 70, type: !77)
!202 = distinct !DILocation(line: 105, column: 5, scope: !173)
!203 = !DILocation(line: 72, column: 24, scope: !198, inlinedAt: !202)
!204 = !DILocation(line: 99, column: 5, scope: !195)
!205 = !DILocation(line: 102, column: 19, scope: !206)
!206 = distinct !DILexicalBlock(scope: !196, file: !1, line: 101, column: 5)
!207 = !DILocation(line: 72, column: 36, scope: !198, inlinedAt: !202)
!208 = !DILocation(line: 72, column: 50, scope: !198, inlinedAt: !202)
!209 = !DILocation(line: 0, scope: !199, inlinedAt: !202)
!210 = !DILocation(line: 72, column: 20, scope: !198, inlinedAt: !202)
!211 = !DILocation(line: 72, column: 18, scope: !198, inlinedAt: !202)
!212 = !DILocation(line: 72, column: 44, scope: !198, inlinedAt: !202)
!213 = !DILocation(line: 72, column: 32, scope: !198, inlinedAt: !202)
!214 = !DILocation(line: 72, column: 30, scope: !198, inlinedAt: !202)
!215 = !DILocation(line: 72, column: 9, scope: !199, inlinedAt: !202)
!216 = !DILocation(line: 73, column: 21, scope: !198, inlinedAt: !202)
!217 = !DILocation(line: 73, column: 9, scope: !198, inlinedAt: !202)
!218 = !DILocation(line: 107, column: 1, scope: !173)
!219 = distinct !DISubprogram(name: "bipbuf_offer", scope: !1, file: !1, line: 109, type: !220, scopeLine: 110, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !224)
!220 = !DISubroutineType(types: !221)
!221 = !{!16, !77, !222, !144}
!222 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !223, size: 64)
!223 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !4)
!224 = !{!225, !226, !227}
!225 = !DILocalVariable(name: "me", arg: 1, scope: !219, file: !1, line: 109, type: !77)
!226 = !DILocalVariable(name: "data", arg: 2, scope: !219, file: !1, line: 109, type: !222)
!227 = !DILocalVariable(name: "size", arg: 3, scope: !219, file: !1, line: 109, type: !144)
!228 = !DILocation(line: 0, scope: !219)
!229 = !DILocation(line: 0, scope: !13, inlinedAt: !230)
!230 = distinct !DILocation(line: 112, column: 9, scope: !231)
!231 = distinct !DILexicalBlock(scope: !219, file: !1, line: 112, column: 9)
!232 = !DILocation(line: 25, column: 18, scope: !38, inlinedAt: !230)
!233 = !DILocation(line: 25, column: 11, scope: !38, inlinedAt: !230)
!234 = !DILocation(line: 25, column: 9, scope: !13, inlinedAt: !230)
!235 = !DILocation(line: 27, column: 20, scope: !38, inlinedAt: !230)
!236 = !DILocation(line: 27, column: 34, scope: !38, inlinedAt: !230)
!237 = !DILocation(line: 27, column: 28, scope: !38, inlinedAt: !230)
!238 = !DILocation(line: 112, column: 27, scope: !231)
!239 = !DILocation(line: 112, column: 9, scope: !219)
!240 = !DILocation(line: 29, column: 20, scope: !38, inlinedAt: !230)
!241 = !DILocation(line: 29, column: 31, scope: !38, inlinedAt: !230)
!242 = !DILocation(line: 29, column: 16, scope: !38, inlinedAt: !230)
!243 = !DILocation(line: 117, column: 20, scope: !244)
!244 = distinct !DILexicalBlock(scope: !245, file: !1, line: 116, column: 5)
!245 = distinct !DILexicalBlock(scope: !219, file: !1, line: 115, column: 9)
!246 = !DILocation(line: 117, column: 25, scope: !244)
!247 = !DILocation(line: 117, column: 44, scope: !244)
!248 = !DILocation(line: 117, column: 9, scope: !244)
!249 = !DILocation(line: 118, column: 19, scope: !244)
!250 = !DILocation(line: 72, column: 24, scope: !198, inlinedAt: !251)
!251 = distinct !DILocation(line: 126, column: 5, scope: !219)
!252 = !DILocation(line: 119, column: 5, scope: !244)
!253 = !DILocation(line: 122, column: 20, scope: !254)
!254 = distinct !DILexicalBlock(scope: !245, file: !1, line: 121, column: 5)
!255 = !DILocation(line: 122, column: 25, scope: !254)
!256 = !DILocation(line: 122, column: 44, scope: !254)
!257 = !DILocation(line: 122, column: 9, scope: !254)
!258 = !DILocation(line: 123, column: 19, scope: !254)
!259 = !DILocation(line: 72, column: 50, scope: !198, inlinedAt: !251)
!260 = !DILocation(line: 0, scope: !199, inlinedAt: !251)
!261 = !DILocation(line: 72, column: 13, scope: !198, inlinedAt: !251)
!262 = !DILocation(line: 72, column: 20, scope: !198, inlinedAt: !251)
!263 = !DILocation(line: 72, column: 18, scope: !198, inlinedAt: !251)
!264 = !DILocation(line: 72, column: 36, scope: !198, inlinedAt: !251)
!265 = !DILocation(line: 72, column: 44, scope: !198, inlinedAt: !251)
!266 = !DILocation(line: 72, column: 32, scope: !198, inlinedAt: !251)
!267 = !DILocation(line: 72, column: 30, scope: !198, inlinedAt: !251)
!268 = !DILocation(line: 72, column: 9, scope: !199, inlinedAt: !251)
!269 = !DILocation(line: 73, column: 21, scope: !198, inlinedAt: !251)
!270 = !DILocation(line: 73, column: 9, scope: !198, inlinedAt: !251)
!271 = !DILocation(line: 128, column: 1, scope: !219)
!272 = distinct !DISubprogram(name: "bipbuf_peek", scope: !1, file: !1, line: 130, type: !273, scopeLine: 131, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !275)
!273 = !DISubroutineType(types: !274)
!274 = !{!3, !17, !78}
!275 = !{!276, !277}
!276 = !DILocalVariable(name: "me", arg: 1, scope: !272, file: !1, line: 130, type: !17)
!277 = !DILocalVariable(name: "size", arg: 2, scope: !272, file: !1, line: 130, type: !78)
!278 = !DILocation(line: 0, scope: !272)
!279 = !DILocation(line: 133, column: 13, scope: !280)
!280 = distinct !DILexicalBlock(scope: !272, file: !1, line: 133, column: 9)
!281 = !DILocation(line: 133, column: 24, scope: !280)
!282 = !DILocation(line: 133, column: 32, scope: !280)
!283 = !DILocation(line: 133, column: 20, scope: !280)
!284 = !DILocation(line: 133, column: 18, scope: !280)
!285 = !DILocation(line: 133, column: 9, scope: !272)
!286 = !DILocation(line: 0, scope: !133, inlinedAt: !287)
!287 = distinct !DILocation(line: 136, column: 9, scope: !288)
!288 = distinct !DILexicalBlock(scope: !272, file: !1, line: 136, column: 9)
!289 = !DILocation(line: 65, column: 31, scope: !133, inlinedAt: !287)
!290 = !DILocation(line: 65, column: 24, scope: !133, inlinedAt: !287)
!291 = !DILocation(line: 136, column: 9, scope: !272)
!292 = !DILocation(line: 139, column: 33, scope: !272)
!293 = !DILocation(line: 139, column: 38, scope: !272)
!294 = !DILocation(line: 139, column: 5, scope: !272)
!295 = !DILocation(line: 140, column: 1, scope: !272)
!296 = distinct !DISubprogram(name: "bipbuf_peek_all", scope: !1, file: !1, line: 142, type: !297, scopeLine: 143, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !300)
!297 = !DISubroutineType(types: !298)
!298 = !{!3, !17, !299}
!299 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !26, size: 64)
!300 = !{!301, !302}
!301 = !DILocalVariable(name: "me", arg: 1, scope: !296, file: !1, line: 142, type: !17)
!302 = !DILocalVariable(name: "size", arg: 2, scope: !296, file: !1, line: 142, type: !299)
!303 = !DILocation(line: 0, scope: !296)
!304 = !DILocation(line: 0, scope: !133, inlinedAt: !305)
!305 = distinct !DILocation(line: 144, column: 9, scope: !306)
!306 = distinct !DILexicalBlock(scope: !296, file: !1, line: 144, column: 9)
!307 = !DILocation(line: 65, column: 16, scope: !133, inlinedAt: !305)
!308 = !DILocation(line: 65, column: 31, scope: !133, inlinedAt: !305)
!309 = !DILocation(line: 65, column: 24, scope: !133, inlinedAt: !305)
!310 = !DILocation(line: 144, column: 9, scope: !296)
!311 = !DILocation(line: 147, column: 23, scope: !296)
!312 = !DILocation(line: 147, column: 11, scope: !296)
!313 = !DILocation(line: 148, column: 32, scope: !296)
!314 = !DILocation(line: 148, column: 43, scope: !296)
!315 = !DILocation(line: 148, column: 37, scope: !296)
!316 = !DILocation(line: 148, column: 5, scope: !296)
!317 = !DILocation(line: 149, column: 1, scope: !296)
!318 = distinct !DISubprogram(name: "bipbuf_poll", scope: !1, file: !1, line: 151, type: !319, scopeLine: 152, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !321)
!319 = !DISubroutineType(types: !320)
!320 = !{!3, !77, !78}
!321 = !{!322, !323, !324}
!322 = !DILocalVariable(name: "me", arg: 1, scope: !318, file: !1, line: 151, type: !77)
!323 = !DILocalVariable(name: "size", arg: 2, scope: !318, file: !1, line: 151, type: !78)
!324 = !DILocalVariable(name: "end", scope: !318, file: !1, line: 160, type: !121)
!325 = !DILocation(line: 0, scope: !318)
!326 = !DILocation(line: 0, scope: !133, inlinedAt: !327)
!327 = distinct !DILocation(line: 153, column: 9, scope: !328)
!328 = distinct !DILexicalBlock(scope: !318, file: !1, line: 153, column: 9)
!329 = !DILocation(line: 65, column: 16, scope: !133, inlinedAt: !327)
!330 = !DILocation(line: 65, column: 31, scope: !133, inlinedAt: !327)
!331 = !DILocation(line: 65, column: 24, scope: !133, inlinedAt: !327)
!332 = !DILocation(line: 153, column: 9, scope: !318)
!333 = !DILocation(line: 157, column: 13, scope: !334)
!334 = distinct !DILexicalBlock(scope: !318, file: !1, line: 157, column: 9)
!335 = !DILocation(line: 157, column: 32, scope: !334)
!336 = !DILocation(line: 157, column: 20, scope: !334)
!337 = !DILocation(line: 157, column: 18, scope: !334)
!338 = !DILocation(line: 157, column: 9, scope: !318)
!339 = !DILocation(line: 160, column: 21, scope: !318)
!340 = !DILocation(line: 160, column: 26, scope: !318)
!341 = !DILocation(line: 161, column: 17, scope: !318)
!342 = !DILocation(line: 164, column: 21, scope: !343)
!343 = distinct !DILexicalBlock(scope: !318, file: !1, line: 164, column: 9)
!344 = !DILocation(line: 164, column: 9, scope: !318)
!345 = !DILocation(line: 167, column: 22, scope: !346)
!346 = distinct !DILexicalBlock(scope: !347, file: !1, line: 167, column: 13)
!347 = distinct !DILexicalBlock(scope: !343, file: !1, line: 165, column: 5)
!348 = !DILocation(line: 167, column: 15, scope: !346)
!349 = !DILocation(line: 167, column: 13, scope: !347)
!350 = !DILocation(line: 169, column: 25, scope: !351)
!351 = distinct !DILexicalBlock(scope: !346, file: !1, line: 168, column: 9)
!352 = !DILocation(line: 170, column: 29, scope: !351)
!353 = !DILocation(line: 170, column: 23, scope: !351)
!354 = !DILocation(line: 172, column: 9, scope: !351)
!355 = !DILocation(line: 0, scope: !346)
!356 = !DILocation(line: 72, column: 20, scope: !198, inlinedAt: !357)
!357 = distinct !DILocation(line: 178, column: 5, scope: !318)
!358 = !DILocation(line: 72, column: 36, scope: !198, inlinedAt: !357)
!359 = !DILocation(line: 72, column: 24, scope: !198, inlinedAt: !357)
!360 = !DILocation(line: 0, scope: !199, inlinedAt: !357)
!361 = !DILocation(line: 72, column: 18, scope: !198, inlinedAt: !357)
!362 = !DILocation(line: 72, column: 50, scope: !198, inlinedAt: !357)
!363 = !DILocation(line: 72, column: 44, scope: !198, inlinedAt: !357)
!364 = !DILocation(line: 72, column: 32, scope: !198, inlinedAt: !357)
!365 = !DILocation(line: 72, column: 30, scope: !198, inlinedAt: !357)
!366 = !DILocation(line: 72, column: 9, scope: !199, inlinedAt: !357)
!367 = !DILocation(line: 73, column: 13, scope: !198, inlinedAt: !357)
!368 = !DILocation(line: 73, column: 21, scope: !198, inlinedAt: !357)
!369 = !DILocation(line: 73, column: 9, scope: !198, inlinedAt: !357)
!370 = !DILocation(line: 180, column: 1, scope: !318)
