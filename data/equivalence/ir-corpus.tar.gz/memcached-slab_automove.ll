; ModuleID = 'slab_automove.c'
source_filename = "slab_automove.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.item_stats_automove = type { i64, i64, i32 }
%struct.window_data = type { i64, i64, float, i64 }
%struct.slab_stats_automove = type { i32, i32, i64, i64 }

@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef ptr @slab_automove_init(ptr nocapture noundef readonly %settings) local_unnamed_addr #0 !dbg !71 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %settings, metadata !163, metadata !DIExpression()), !dbg !167
  %slab_automove_window = getelementptr inbounds i8, ptr %settings, i64 152, !dbg !168
  %0 = load i32, ptr %slab_automove_window, align 8, !dbg !168, !tbaa !169
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !164, metadata !DIExpression()), !dbg !167
  %slab_automove_ratio = getelementptr inbounds i8, ptr %settings, i64 144, !dbg !178
  %1 = load double, ptr %slab_automove_ratio, align 8, !dbg !178, !tbaa !179
  tail call void @llvm.dbg.value(metadata double %1, metadata !165, metadata !DIExpression()), !dbg !167
  %call = tail call noalias dereferenceable_or_null(6168) ptr @calloc(i64 noundef 1, i64 noundef 6168) #9, !dbg !180
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !166, metadata !DIExpression()), !dbg !167
  %cmp = icmp eq ptr %call, null, !dbg !181
  br i1 %cmp, label %cleanup, label %if.end, !dbg !183

if.end:                                           ; preds = %entry
  %mul = shl i32 %0, 6, !dbg !184
  %conv = zext i32 %mul to i64, !dbg !185
  %call1 = tail call noalias ptr @calloc(i64 noundef %conv, i64 noundef 32) #9, !dbg !186
  store ptr %call1, ptr %call, align 8, !dbg !187, !tbaa !188
  %window_size2 = getelementptr inbounds i8, ptr %call, i64 8, !dbg !190
  store i32 %0, ptr %window_size2, align 8, !dbg !191, !tbaa !192
  %max_age_ratio3 = getelementptr inbounds i8, ptr %call, i64 16, !dbg !193
  store double %1, ptr %max_age_ratio3, align 8, !dbg !194, !tbaa !195
  %cmp5 = icmp eq ptr %call1, null, !dbg !196
  br i1 %cmp5, label %if.then7, label %if.end8, !dbg !198

if.then7:                                         ; preds = %if.end
  tail call void @free(ptr noundef nonnull %call) #10, !dbg !199
  br label %cleanup, !dbg !201

if.end8:                                          ; preds = %if.end
  %iam_before = getelementptr inbounds i8, ptr %call, i64 24, !dbg !202
  tail call void @fill_item_stats_automove(ptr noundef nonnull %iam_before) #10, !dbg !203
  %sam_before = getelementptr inbounds i8, ptr %call, i64 3096, !dbg !204
  tail call void @fill_slab_stats_automove(ptr noundef nonnull %sam_before) #10, !dbg !205
  br label %cleanup, !dbg !206

cleanup:                                          ; preds = %entry, %if.end8, %if.then7
  %retval.0 = phi ptr [ null, %if.then7 ], [ %call, %if.end8 ], [ null, %entry ], !dbg !167
  ret ptr %retval.0, !dbg !207
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite)
declare !dbg !208 noalias noundef ptr @calloc(i64 noundef, i64 noundef) local_unnamed_addr #1

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !212 void @free(ptr allocptr nocapture noundef) local_unnamed_addr #2

declare !dbg !215 void @fill_item_stats_automove(ptr noundef) local_unnamed_addr #3

declare !dbg !219 void @fill_slab_stats_automove(ptr noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nounwind sanitize_thread willreturn uwtable
define dso_local void @slab_automove_free(ptr nocapture noundef %arg) local_unnamed_addr #4 !dbg !223 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !225, metadata !DIExpression()), !dbg !227
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !226, metadata !DIExpression()), !dbg !227
  %0 = load ptr, ptr %arg, align 8, !dbg !228, !tbaa !188
  tail call void @free(ptr noundef %0) #10, !dbg !229
  tail call void @free(ptr noundef %arg) #10, !dbg !230
  ret void, !dbg !231
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @slab_automove_run(ptr noundef %arg, ptr nocapture noundef writeonly %src, ptr nocapture noundef writeonly %dst) local_unnamed_addr #0 !dbg !232 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !237, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata ptr %src, metadata !238, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata ptr %dst, metadata !239, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !240, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !243, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 0, metadata !244, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !245, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 -1, metadata !246, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i8 0, metadata !247, metadata !DIExpression()), !dbg !256
  store i32 -1, ptr %src, align 4, !dbg !257, !tbaa !258
  store i32 -1, ptr %dst, align 4, !dbg !259, !tbaa !258
  %iam_after = getelementptr inbounds i8, ptr %arg, i64 1560, !dbg !260
  tail call void @fill_item_stats_automove(ptr noundef nonnull %iam_after) #10, !dbg !261
  %sam_after = getelementptr inbounds i8, ptr %arg, i64 4632, !dbg !262
  tail call void @fill_slab_stats_automove(ptr noundef nonnull %sam_after) #10, !dbg !263
  tail call void @llvm.dbg.value(metadata i64 0, metadata !248, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i32 1, metadata !241, metadata !DIExpression()), !dbg !256
  %iam_before = getelementptr inbounds i8, ptr %arg, i64 24
  tail call void @llvm.dbg.value(metadata i32 1, metadata !241, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 0, metadata !248, metadata !DIExpression()), !dbg !256
  br label %for.body, !dbg !264

for.body:                                         ; preds = %for.body, %entry
  %indvars.iv = phi i64 [ 1, %entry ], [ %indvars.iv.next.2, %for.body ]
  %evicted_total.0256 = phi i64 [ 0, %entry ], [ %add.2, %for.body ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !241, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %evicted_total.0256, metadata !248, metadata !DIExpression()), !dbg !256
  %arrayidx = getelementptr inbounds [64 x %struct.item_stats_automove], ptr %iam_after, i64 0, i64 %indvars.iv, !dbg !266
  %0 = load i64, ptr %arrayidx, align 8, !dbg !269, !tbaa !270
  %arrayidx4 = getelementptr inbounds [64 x %struct.item_stats_automove], ptr %iam_before, i64 0, i64 %indvars.iv, !dbg !272
  %1 = load i64, ptr %arrayidx4, align 8, !dbg !273, !tbaa !270
  %sub = add i64 %0, %evicted_total.0256, !dbg !274
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %sub, i64 %1), metadata !248, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !256
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !275
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !241, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !241, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %sub, i64 %1), metadata !248, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !256
  %arrayidx.1 = getelementptr inbounds [64 x %struct.item_stats_automove], ptr %iam_after, i64 0, i64 %indvars.iv.next, !dbg !266
  %2 = load i64, ptr %arrayidx.1, align 8, !dbg !269, !tbaa !270
  %arrayidx4.1 = getelementptr inbounds [64 x %struct.item_stats_automove], ptr %iam_before, i64 0, i64 %indvars.iv.next, !dbg !272
  %3 = load i64, ptr %arrayidx4.1, align 8, !dbg !273, !tbaa !270
  %4 = add i64 %sub, %2, !dbg !276
  %5 = add i64 %1, %3, !dbg !276
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %4, i64 %5), metadata !248, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !256
  %indvars.iv.next.1 = add nuw nsw i64 %indvars.iv, 2, !dbg !275
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.1, metadata !241, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.1, metadata !241, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %4, i64 %5), metadata !248, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !256
  %arrayidx.2 = getelementptr inbounds [64 x %struct.item_stats_automove], ptr %iam_after, i64 0, i64 %indvars.iv.next.1, !dbg !266
  %6 = load i64, ptr %arrayidx.2, align 8, !dbg !269, !tbaa !270
  %arrayidx4.2 = getelementptr inbounds [64 x %struct.item_stats_automove], ptr %iam_before, i64 0, i64 %indvars.iv.next.1, !dbg !272
  %7 = load i64, ptr %arrayidx4.2, align 8, !dbg !273, !tbaa !270
  %8 = add i64 %4, %6, !dbg !276
  %9 = add i64 %5, %7, !dbg !276
  %add.2 = sub i64 %8, %9, !dbg !276
  tail call void @llvm.dbg.value(metadata i64 %add.2, metadata !248, metadata !DIExpression()), !dbg !256
  %indvars.iv.next.2 = add nuw nsw i64 %indvars.iv, 3, !dbg !275
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.2, metadata !241, metadata !DIExpression()), !dbg !256
  %exitcond.not.2 = icmp eq i64 %indvars.iv.next.2, 64, !dbg !277
  br i1 %exitcond.not.2, label %for.end, label %for.body, !dbg !264, !llvm.loop !278

for.end:                                          ; preds = %for.body
  %window_cur = getelementptr inbounds i8, ptr %arg, i64 12, !dbg !281
  %10 = load i32, ptr %window_cur, align 4, !dbg !282, !tbaa !283
  %inc6 = add i32 %10, 1, !dbg !282
  store i32 %inc6, ptr %window_cur, align 4, !dbg !282, !tbaa !283
  tail call void @llvm.dbg.value(metadata i32 1, metadata !241, metadata !DIExpression()), !dbg !256
  %window_size = getelementptr inbounds i8, ptr %arg, i64 8
  %sam_before = getelementptr inbounds i8, ptr %arg, i64 3096
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !256
  tail call void @llvm.dbg.value(metadata float poison, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 32)), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !256
  tail call void @llvm.dbg.value(metadata i32 1, metadata !241, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !243, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 0, metadata !244, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !245, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !247, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 -1, metadata !246, metadata !DIExpression()), !dbg !256
  %conv25 = uitofp i64 %add.2 to float
  %.pre = load i32, ptr %window_size, align 8, !dbg !284, !tbaa !192
  %.pre272 = load ptr, ptr %arg, align 8, !dbg !285, !tbaa !188
  br label %for.body9, !dbg !286

for.body9:                                        ; preds = %for.end, %for.inc116
  %11 = phi ptr [ %.pre272, %for.end ], [ %22, %for.inc116 ], !dbg !285
  %12 = phi i32 [ %.pre, %for.end ], [ %23, %for.inc116 ], !dbg !284
  %indvars.iv269 = phi i64 [ 1, %for.end ], [ %indvars.iv.next270, %for.inc116 ]
  %oldest.0262 = phi i32 [ -1, %for.end ], [ %oldest.1, %for.inc116 ]
  %oldest_age.0261 = phi i64 [ 0, %for.end ], [ %oldest_age.1, %for.inc116 ]
  %youngest.0260 = phi i32 [ -1, %for.end ], [ %youngest.2.ph, %for.inc116 ]
  %youngest_evicting.0259 = phi i1 [ false, %for.end ], [ %youngest_evicting.2.ph, %for.inc116 ]
  %youngest_age.0258 = phi i64 [ -1, %for.end ], [ %youngest_age.2.ph, %for.inc116 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv269, metadata !241, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i32 %oldest.0262, metadata !243, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %oldest_age.0261, metadata !244, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i32 %youngest.0260, metadata !245, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %youngest_age.0258, metadata !246, metadata !DIExpression()), !dbg !256
  %13 = trunc nuw nsw i64 %indvars.iv269 to i32, !dbg !287
  %mul = mul i32 %12, %13, !dbg !287
  tail call void @llvm.dbg.value(metadata i32 %mul, metadata !249, metadata !DIExpression()), !dbg !288
  %14 = load i32, ptr %window_cur, align 4, !dbg !289, !tbaa !283
  %rem = urem i32 %14, %12, !dbg !290
  %add12 = add i32 %rem, %mul, !dbg !291
  %idxprom13 = zext i32 %add12 to i64, !dbg !292
  %arrayidx14 = getelementptr inbounds %struct.window_data, ptr %11, i64 %idxprom13, !dbg !292
  tail call void @llvm.dbg.value(metadata ptr %arrayidx14, metadata !253, metadata !DIExpression()), !dbg !288
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %arrayidx14, i8 0, i64 32, i1 false), !dbg !293
  %arrayidx17 = getelementptr inbounds [64 x %struct.item_stats_automove], ptr %iam_after, i64 0, i64 %indvars.iv269, !dbg !294
  %15 = load i64, ptr %arrayidx17, align 8, !dbg !295, !tbaa !270
  %arrayidx21 = getelementptr inbounds [64 x %struct.item_stats_automove], ptr %iam_before, i64 0, i64 %indvars.iv269, !dbg !296
  %16 = load i64, ptr %arrayidx21, align 8, !dbg !297, !tbaa !270
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %15, i64 %16), metadata !254, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !288
  %cmp24.not = icmp ne i64 %15, %16, !dbg !298
  br i1 %cmp24.not, label %if.then, label %if.end, !dbg !300

if.then:                                          ; preds = %for.body9
  %sub23 = sub nsw i64 %15, %16, !dbg !301
  tail call void @llvm.dbg.value(metadata i64 %sub23, metadata !254, metadata !DIExpression()), !dbg !288
  %conv = uitofp i64 %sub23 to float, !dbg !302
  %div = fdiv float %conv, %conv25, !dbg !304
  %evicted_ratio = getelementptr inbounds i8, ptr %arrayidx14, i64 16, !dbg !305
  store float %div, ptr %evicted_ratio, align 8, !dbg !306, !tbaa !307
  %evicted_seen = getelementptr inbounds i8, ptr %arrayidx14, i64 24, !dbg !310
  store i64 1, ptr %evicted_seen, align 8, !dbg !311, !tbaa !312
  %dirty = getelementptr inbounds i8, ptr %arrayidx14, i64 8, !dbg !313
  store i64 1, ptr %dirty, align 8, !dbg !314, !tbaa !315
  br label %if.end, !dbg !316

if.end:                                           ; preds = %if.then, %for.body9
  %outofmemory = getelementptr inbounds i8, ptr %arrayidx17, i64 8, !dbg !317
  %17 = load i64, ptr %outofmemory, align 8, !dbg !317, !tbaa !319
  %outofmemory32 = getelementptr inbounds i8, ptr %arrayidx21, i64 8, !dbg !320
  %18 = load i64, ptr %outofmemory32, align 8, !dbg !320, !tbaa !319
  %cmp34 = icmp sgt i64 %17, %18, !dbg !321
  br i1 %cmp34, label %if.then36, label %if.end38, !dbg !322

if.then36:                                        ; preds = %if.end
  %dirty37 = getelementptr inbounds i8, ptr %arrayidx14, i64 8, !dbg !323
  store i64 1, ptr %dirty37, align 8, !dbg !325, !tbaa !315
  br label %if.end38, !dbg !326

if.end38:                                         ; preds = %if.then36, %if.end
  %arrayidx41 = getelementptr inbounds [64 x %struct.slab_stats_automove], ptr %sam_after, i64 0, i64 %indvars.iv269, !dbg !327
  %total_pages = getelementptr inbounds i8, ptr %arrayidx41, i64 16, !dbg !329
  %19 = load i64, ptr %total_pages, align 8, !dbg !329, !tbaa !330
  %total_pages44 = getelementptr inbounds [64 x %struct.slab_stats_automove], ptr %sam_before, i64 0, i64 %indvars.iv269, i32 3, !dbg !332
  %20 = load i64, ptr %total_pages44, align 8, !dbg !332, !tbaa !330
  %cmp46 = icmp sgt i64 %19, %20, !dbg !333
  br i1 %cmp46, label %if.then48, label %if.end50, !dbg !334

if.then48:                                        ; preds = %if.end38
  %dirty49 = getelementptr inbounds i8, ptr %arrayidx14, i64 8, !dbg !335
  store i64 1, ptr %dirty49, align 8, !dbg !337, !tbaa !315
  br label %if.end50, !dbg !338

if.end50:                                         ; preds = %if.then48, %if.end38
  %age = getelementptr inbounds i8, ptr %arrayidx17, i64 16, !dbg !339
  %21 = load i32, ptr %age, align 8, !dbg !339, !tbaa !340
  %conv54 = zext i32 %21 to i64, !dbg !341
  store i64 %conv54, ptr %arrayidx14, align 8, !dbg !342, !tbaa !343
  tail call void @llvm.dbg.value(metadata i64 0, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 0, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !256
  tail call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 32)), !dbg !256
  tail call void @llvm.dbg.value(metadata i32 0, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 160, 32)), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 0, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !256
  %22 = load ptr, ptr %arg, align 8, !dbg !344, !tbaa !188
  %idxprom57 = sext i32 %mul to i64, !dbg !345
  %arrayidx58 = getelementptr inbounds %struct.window_data, ptr %22, i64 %idxprom57, !dbg !345
  %23 = load i32, ptr %window_size, align 8, !dbg !346, !tbaa !192
  tail call void @llvm.dbg.value(metadata ptr %arrayidx58, metadata !347, metadata !DIExpression()), !dbg !359
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !352, metadata !DIExpression()), !dbg !359
  tail call void @llvm.dbg.value(metadata i32 %23, metadata !353, metadata !DIExpression()), !dbg !359
  tail call void @llvm.dbg.value(metadata i32 0, metadata !354, metadata !DIExpression()), !dbg !359
  %cmp16.not.i = icmp eq i32 %23, 0, !dbg !361
  br i1 %cmp16.not.i, label %window_sum.exit, label %for.body.lr.ph.i, !dbg !362

for.body.lr.ph.i:                                 ; preds = %if.end50
  %wide.trip.count.i = zext i32 %23 to i64, !dbg !361
  %xtraiter = and i64 %wide.trip.count.i, 1, !dbg !362
  %24 = icmp eq i32 %23, 1, !dbg !362
  br i1 %24, label %window_sum.exit.loopexit.unr-lcssa, label %for.body.lr.ph.i.new, !dbg !362

for.body.lr.ph.i.new:                             ; preds = %for.body.lr.ph.i
  %unroll_iter = and i64 %wide.trip.count.i, 4294967294, !dbg !362
  br label %for.body.i, !dbg !362

for.body.i:                                       ; preds = %for.body.i, %for.body.lr.ph.i.new
  %indvars.iv.i = phi i64 [ 0, %for.body.lr.ph.i.new ], [ %indvars.iv.next.i.1, %for.body.i ], !dbg !363
  %25 = phi i64 [ 0, %for.body.lr.ph.i.new ], [ %add7.i.1, %for.body.i ], !dbg !363
  %26 = phi float [ 0.000000e+00, %for.body.lr.ph.i.new ], [ %add5.i.1, %for.body.i ], !dbg !363
  %27 = phi i64 [ 0, %for.body.lr.ph.i.new ], [ %add3.i.1, %for.body.i ], !dbg !363
  %28 = phi i64 [ 0, %for.body.lr.ph.i.new ], [ %add.i.1, %for.body.i ], !dbg !363
  %niter = phi i64 [ 0, %for.body.lr.ph.i.new ], [ %niter.next.1, %for.body.i ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i, metadata !354, metadata !DIExpression()), !dbg !359
  %arrayidx.i = getelementptr inbounds %struct.window_data, ptr %arrayidx58, i64 %indvars.iv.i, !dbg !363
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i, metadata !355, metadata !DIExpression()), !dbg !364
  %29 = load i64, ptr %arrayidx.i, align 8, !dbg !365, !tbaa !343
  %add.i = add i64 %29, %28, !dbg !366
  tail call void @llvm.dbg.value(metadata i64 %add.i, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !256
  %dirty.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 8, !dbg !367
  %30 = load i64, ptr %dirty.i, align 8, !dbg !367, !tbaa !315
  %add3.i = add i64 %30, %27, !dbg !368
  tail call void @llvm.dbg.value(metadata i64 %add3.i, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !256
  %evicted_ratio.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 16, !dbg !369
  %31 = load float, ptr %evicted_ratio.i, align 8, !dbg !369, !tbaa !307
  %add5.i = fadd float %26, %31, !dbg !370
  tail call void @llvm.dbg.value(metadata float %add5.i, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 32)), !dbg !256
  %evicted_seen.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 24, !dbg !371
  %32 = load i64, ptr %evicted_seen.i, align 8, !dbg !371, !tbaa !312
  %add7.i = add i64 %32, %25, !dbg !372
  tail call void @llvm.dbg.value(metadata i64 %add7.i, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !256
  %indvars.iv.next.i = or disjoint i64 %indvars.iv.i, 1, !dbg !373
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !354, metadata !DIExpression()), !dbg !359
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !354, metadata !DIExpression()), !dbg !359
  %arrayidx.i.1 = getelementptr inbounds %struct.window_data, ptr %arrayidx58, i64 %indvars.iv.next.i, !dbg !363
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i.1, metadata !355, metadata !DIExpression()), !dbg !364
  %33 = load i64, ptr %arrayidx.i.1, align 8, !dbg !365, !tbaa !343
  %add.i.1 = add i64 %33, %add.i, !dbg !366
  tail call void @llvm.dbg.value(metadata i64 %add.i.1, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !256
  %dirty.i.1 = getelementptr inbounds i8, ptr %arrayidx.i.1, i64 8, !dbg !367
  %34 = load i64, ptr %dirty.i.1, align 8, !dbg !367, !tbaa !315
  %add3.i.1 = add i64 %34, %add3.i, !dbg !368
  tail call void @llvm.dbg.value(metadata i64 %add3.i.1, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !256
  %evicted_ratio.i.1 = getelementptr inbounds i8, ptr %arrayidx.i.1, i64 16, !dbg !369
  %35 = load float, ptr %evicted_ratio.i.1, align 8, !dbg !369, !tbaa !307
  %add5.i.1 = fadd float %add5.i, %35, !dbg !370
  tail call void @llvm.dbg.value(metadata float %add5.i.1, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 32)), !dbg !256
  %evicted_seen.i.1 = getelementptr inbounds i8, ptr %arrayidx.i.1, i64 24, !dbg !371
  %36 = load i64, ptr %evicted_seen.i.1, align 8, !dbg !371, !tbaa !312
  %add7.i.1 = add i64 %36, %add7.i, !dbg !372
  tail call void @llvm.dbg.value(metadata i64 %add7.i.1, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !256
  %indvars.iv.next.i.1 = add nuw nsw i64 %indvars.iv.i, 2, !dbg !373
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.1, metadata !354, metadata !DIExpression()), !dbg !359
  %niter.next.1 = add i64 %niter, 2, !dbg !362
  %niter.ncmp.1 = icmp eq i64 %niter.next.1, %unroll_iter, !dbg !362
  br i1 %niter.ncmp.1, label %window_sum.exit.loopexit.unr-lcssa, label %for.body.i, !dbg !362, !llvm.loop !374

window_sum.exit.loopexit.unr-lcssa:               ; preds = %for.body.i, %for.body.lr.ph.i
  %add.i.lcssa.ph = phi i64 [ undef, %for.body.lr.ph.i ], [ %add.i.1, %for.body.i ]
  %add3.i.lcssa.ph = phi i64 [ undef, %for.body.lr.ph.i ], [ %add3.i.1, %for.body.i ]
  %add5.i.lcssa.ph = phi float [ undef, %for.body.lr.ph.i ], [ %add5.i.1, %for.body.i ]
  %add7.i.lcssa.ph = phi i64 [ undef, %for.body.lr.ph.i ], [ %add7.i.1, %for.body.i ]
  %indvars.iv.i.unr = phi i64 [ 0, %for.body.lr.ph.i ], [ %indvars.iv.next.i.1, %for.body.i ]
  %.unr = phi i64 [ 0, %for.body.lr.ph.i ], [ %add7.i.1, %for.body.i ]
  %.unr286 = phi float [ 0.000000e+00, %for.body.lr.ph.i ], [ %add5.i.1, %for.body.i ]
  %.unr287 = phi i64 [ 0, %for.body.lr.ph.i ], [ %add3.i.1, %for.body.i ]
  %.unr288 = phi i64 [ 0, %for.body.lr.ph.i ], [ %add.i.1, %for.body.i ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0, !dbg !362
  br i1 %lcmp.mod.not, label %window_sum.exit.loopexit, label %for.body.i.epil, !dbg !362

for.body.i.epil:                                  ; preds = %window_sum.exit.loopexit.unr-lcssa
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i.unr, metadata !354, metadata !DIExpression()), !dbg !359
  %arrayidx.i.epil = getelementptr inbounds %struct.window_data, ptr %arrayidx58, i64 %indvars.iv.i.unr, !dbg !363
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i.epil, metadata !355, metadata !DIExpression()), !dbg !364
  %37 = load i64, ptr %arrayidx.i.epil, align 8, !dbg !365, !tbaa !343
  %add.i.epil = add i64 %37, %.unr288, !dbg !366
  tail call void @llvm.dbg.value(metadata i64 %add.i.epil, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !256
  %dirty.i.epil = getelementptr inbounds i8, ptr %arrayidx.i.epil, i64 8, !dbg !367
  %38 = load i64, ptr %dirty.i.epil, align 8, !dbg !367, !tbaa !315
  %add3.i.epil = add i64 %38, %.unr287, !dbg !368
  tail call void @llvm.dbg.value(metadata i64 %add3.i.epil, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !256
  %evicted_ratio.i.epil = getelementptr inbounds i8, ptr %arrayidx.i.epil, i64 16, !dbg !369
  %39 = load float, ptr %evicted_ratio.i.epil, align 8, !dbg !369, !tbaa !307
  %add5.i.epil = fadd float %.unr286, %39, !dbg !370
  tail call void @llvm.dbg.value(metadata float %add5.i.epil, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 32)), !dbg !256
  %evicted_seen.i.epil = getelementptr inbounds i8, ptr %arrayidx.i.epil, i64 24, !dbg !371
  %40 = load i64, ptr %evicted_seen.i.epil, align 8, !dbg !371, !tbaa !312
  %add7.i.epil = add i64 %40, %.unr, !dbg !372
  tail call void @llvm.dbg.value(metadata i64 %add7.i.epil, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i.unr, metadata !354, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !359
  br label %window_sum.exit.loopexit, !dbg !376

window_sum.exit.loopexit:                         ; preds = %window_sum.exit.loopexit.unr-lcssa, %for.body.i.epil
  %add.i.lcssa = phi i64 [ %add.i.lcssa.ph, %window_sum.exit.loopexit.unr-lcssa ], [ %add.i.epil, %for.body.i.epil ], !dbg !366
  %add3.i.lcssa = phi i64 [ %add3.i.lcssa.ph, %window_sum.exit.loopexit.unr-lcssa ], [ %add3.i.epil, %for.body.i.epil ], !dbg !368
  %add5.i.lcssa = phi float [ %add5.i.lcssa.ph, %window_sum.exit.loopexit.unr-lcssa ], [ %add5.i.epil, %for.body.i.epil ], !dbg !370
  %add7.i.lcssa = phi i64 [ %add7.i.lcssa.ph, %window_sum.exit.loopexit.unr-lcssa ], [ %add7.i.epil, %for.body.i.epil ], !dbg !372
  %41 = udiv i64 %add.i.lcssa, %wide.trip.count.i, !dbg !376
  br label %window_sum.exit, !dbg !376

window_sum.exit:                                  ; preds = %window_sum.exit.loopexit, %if.end50
  %w_sum.sroa.6.1 = phi i64 [ 0, %if.end50 ], [ %add3.i.lcssa, %window_sum.exit.loopexit ], !dbg !288
  %w_sum.sroa.9.1 = phi float [ 0.000000e+00, %if.end50 ], [ %add5.i.lcssa, %window_sum.exit.loopexit ], !dbg !288
  %w_sum.sroa.12230.1 = phi i64 [ 0, %if.end50 ], [ %add7.i.lcssa, %window_sum.exit.loopexit ], !dbg !288
  %div64 = phi i64 [ poison, %if.end50 ], [ %41, %window_sum.exit.loopexit ], !dbg !376
  tail call void @llvm.dbg.value(metadata i64 %w_sum.sroa.12230.1, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !256
  tail call void @llvm.dbg.value(metadata float %w_sum.sroa.9.1, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 32)), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %w_sum.sroa.6.1, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %div64, metadata !255, metadata !DIExpression()), !dbg !288
  %free_chunks = getelementptr inbounds i8, ptr %arrayidx41, i64 8, !dbg !377
  %42 = load i64, ptr %free_chunks, align 8, !dbg !377, !tbaa !379
  %conv68 = sitofp i64 %42 to double, !dbg !380
  %43 = load i32, ptr %arrayidx41, align 8, !dbg !381, !tbaa !382
  %conv72 = uitofp i32 %43 to double, !dbg !383
  %mul73 = fmul double %conv72, 2.500000e+00, !dbg !384
  %cmp74 = fcmp olt double %mul73, %conv68, !dbg !385
  %cmp78 = icmp eq i64 %w_sum.sroa.6.1, 0
  %or.cond246 = select i1 %cmp74, i1 %cmp78, i1 false, !dbg !386
  br i1 %or.cond246, label %cleanup, label %if.end82, !dbg !386

if.end82:                                         ; preds = %window_sum.exit
  %cmp83 = icmp ugt i64 %div64, %oldest_age.0261, !dbg !387
  %cmp89 = icmp sgt i64 %19, 2, !dbg !389
  %44 = tail call i64 @llvm.umax.i64(i64 %div64, i64 %oldest_age.0261), !dbg !389
  %oldest_age.1 = select i1 %cmp89, i64 %44, i64 %oldest_age.0261, !dbg !389
  %45 = and i1 %cmp89, %cmp83, !dbg !389
  %oldest.1 = select i1 %45, i32 %13, i32 %oldest.0262, !dbg !389
  tail call void @llvm.dbg.value(metadata i32 %oldest.1, metadata !243, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %oldest_age.1, metadata !244, metadata !DIExpression()), !dbg !256
  %cmp93 = icmp ult i64 %div64, %youngest_age.0258, !dbg !390
  br i1 %cmp93, label %land.lhs.true95, label %for.inc116, !dbg !392

land.lhs.true95:                                  ; preds = %if.end82
  %div98228 = lshr i32 %23, 1, !dbg !393
  %conv99 = zext nneg i32 %div98228 to i64, !dbg !394
  %cmp100 = icmp ugt i64 %w_sum.sroa.12230.1, %conv99, !dbg !395
  br i1 %cmp100, label %if.then109, label %lor.lhs.false, !dbg !396

lor.lhs.false:                                    ; preds = %land.lhs.true95
  %conv104 = uitofp i32 %23 to float, !dbg !397
  %div105 = fdiv float %w_sum.sroa.9.1, %conv104, !dbg !398
  %cmp107 = fcmp ogt float %div105, 2.500000e-01, !dbg !399
  br i1 %cmp107, label %if.then109, label %for.inc116, !dbg !400

if.then109:                                       ; preds = %lor.lhs.false, %land.lhs.true95
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv269, metadata !245, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %div64, metadata !246, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i8 undef, metadata !247, metadata !DIExpression()), !dbg !256
  br label %for.inc116, !dbg !401

cleanup:                                          ; preds = %window_sum.exit
  store i32 %13, ptr %src, align 4, !dbg !403, !tbaa !258
  store i32 0, ptr %dst, align 4, !dbg !407, !tbaa !258
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !243, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %oldest_age.0261, metadata !244, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !245, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !247, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %youngest_age.0258, metadata !246, metadata !DIExpression()), !dbg !256
  br label %for.end118

for.inc116:                                       ; preds = %if.then109, %lor.lhs.false, %if.end82
  %youngest_age.2.ph = phi i64 [ %youngest_age.0258, %if.end82 ], [ %youngest_age.0258, %lor.lhs.false ], [ %div64, %if.then109 ]
  %youngest_evicting.2.ph = phi i1 [ %youngest_evicting.0259, %if.end82 ], [ %youngest_evicting.0259, %lor.lhs.false ], [ %cmp24.not, %if.then109 ]
  %youngest.2.ph = phi i32 [ %youngest.0260, %if.end82 ], [ %youngest.0260, %lor.lhs.false ], [ %13, %if.then109 ]
  tail call void @llvm.dbg.value(metadata i32 %oldest.1, metadata !243, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %oldest_age.1, metadata !244, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i32 %youngest.2.ph, metadata !245, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !247, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %youngest_age.2.ph, metadata !246, metadata !DIExpression()), !dbg !256
  %indvars.iv.next270 = add nuw nsw i64 %indvars.iv269, 1, !dbg !408
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !256
  tail call void @llvm.dbg.value(metadata float poison, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 32)), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !242, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next270, metadata !241, metadata !DIExpression()), !dbg !256
  %exitcond271.not = icmp eq i64 %indvars.iv.next270, 64, !dbg !409
  br i1 %exitcond271.not, label %for.end118, label %for.body9, !dbg !286, !llvm.loop !410

for.end118:                                       ; preds = %for.inc116, %cleanup
  %youngest_age.0255 = phi i64 [ %youngest_age.0258, %cleanup ], [ %youngest_age.2.ph, %for.inc116 ]
  %youngest_evicting.0253 = phi i1 [ %youngest_evicting.0259, %cleanup ], [ %youngest_evicting.2.ph, %for.inc116 ]
  %oldest_age.0250 = phi i64 [ %oldest_age.0261, %cleanup ], [ %oldest_age.1, %for.inc116 ]
  %youngest.3 = phi i32 [ -1, %cleanup ], [ %youngest.2.ph, %for.inc116 ], !dbg !256
  %oldest.3 = phi i32 [ -1, %cleanup ], [ %oldest.1, %for.inc116 ], !dbg !256
  tail call void @llvm.dbg.value(metadata i32 %oldest.3, metadata !243, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %oldest_age.0250, metadata !244, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i32 %youngest.3, metadata !245, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !247, metadata !DIExpression()), !dbg !256
  tail call void @llvm.dbg.value(metadata i64 %youngest_age.0255, metadata !246, metadata !DIExpression()), !dbg !256
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(1536) %iam_before, ptr noundef nonnull align 8 dereferenceable(1536) %iam_after, i64 1536, i1 false), !dbg !412
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(1536) %sam_before, ptr noundef nonnull align 8 dereferenceable(1536) %sam_after, i64 1536, i1 false), !dbg !413
  %cmp127.not = icmp eq i32 %youngest.3, -1, !dbg !414
  %cmp130.not = icmp eq i32 %oldest.3, -1
  %or.cond = select i1 %cmp127.not, i1 true, i1 %cmp130.not, !dbg !416
  br i1 %or.cond, label %if.end148, label %land.lhs.true132, !dbg !416

land.lhs.true132:                                 ; preds = %for.end118
  %46 = load i32, ptr %window_cur, align 4, !dbg !417, !tbaa !283
  %47 = load i32, ptr %window_size, align 8, !dbg !418, !tbaa !192
  %cmp135 = icmp ugt i32 %46, %47, !dbg !419
  br i1 %cmp135, label %if.then137, label %if.end148, !dbg !420

if.then137:                                       ; preds = %land.lhs.true132
  %conv138 = uitofp i64 %youngest_age.0255 to double, !dbg !421
  %conv139 = uitofp i64 %oldest_age.0250 to double, !dbg !424
  %max_age_ratio = getelementptr inbounds i8, ptr %arg, i64 16, !dbg !425
  %48 = load double, ptr %max_age_ratio, align 8, !dbg !425, !tbaa !195
  %mul140 = fmul double %48, %conv139, !dbg !426
  %cmp141 = fcmp ogt double %mul140, %conv138, !dbg !427
  %brmerge.not = select i1 %cmp141, i1 %youngest_evicting.0253, i1 false, !dbg !428
  br i1 %brmerge.not, label %if.then146, label %if.end148, !dbg !428

if.then146:                                       ; preds = %if.then137
  store i32 %oldest.3, ptr %src, align 4, !dbg !429, !tbaa !258
  store i32 %youngest.3, ptr %dst, align 4, !dbg !431, !tbaa !258
  br label %if.end148, !dbg !432

if.end148:                                        ; preds = %if.then137, %if.then146, %land.lhs.true132, %for.end118
  ret void, !dbg !433
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #6

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umax.i64(i64, i64) #7

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #8 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #7

attributes #0 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { mustprogress nounwind sanitize_thread willreturn uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #6 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #8 = { nounwind uwtable }
attributes #9 = { nounwind allocsize(0,1) }
attributes #10 = { nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!63, !64, !65, !66, !67, !68, !69}
!llvm.ident = !{!70}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !2, retainedTypes: !10, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "slab_automove.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "534035e0cd8b3edc8051650b2b5a19ef")
!2 = !{!3}
!3 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "protocol", file: !4, line: 238, baseType: !5, size: 32, elements: !6)
!4 = !DIFile(filename: "./memcached.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "a52021954a5d6b153b5bc084e2fbff2b")
!5 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!6 = !{!7, !8, !9}
!7 = !DIEnumerator(name: "ascii_prot", value: 3)
!8 = !DIEnumerator(name: "binary_prot", value: 4)
!9 = !DIEnumerator(name: "negotiating_prot", value: 5)
!10 = !{!11, !12, !28, !35}
!11 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!12 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !13, size: 64)
!13 = !DIDerivedType(tag: DW_TAG_typedef, name: "slab_automove", file: !1, line: 32, baseType: !14)
!14 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !1, line: 23, size: 49344, elements: !15)
!15 = !{!16, !30, !33, !34, !36, !51, !52, !62}
!16 = !DIDerivedType(tag: DW_TAG_member, name: "window_data", scope: !14, file: !1, line: 24, baseType: !17, size: 64)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "window_data", file: !1, line: 16, size: 256, elements: !19)
!19 = !{!20, !26, !27, !29}
!20 = !DIDerivedType(tag: DW_TAG_member, name: "age", scope: !18, file: !1, line: 17, baseType: !21, size: 64)
!21 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !22, line: 27, baseType: !23)
!22 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!23 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !24, line: 45, baseType: !25)
!24 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!25 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!26 = !DIDerivedType(tag: DW_TAG_member, name: "dirty", scope: !18, file: !1, line: 18, baseType: !21, size: 64, offset: 64)
!27 = !DIDerivedType(tag: DW_TAG_member, name: "evicted_ratio", scope: !18, file: !1, line: 19, baseType: !28, size: 32, offset: 128)
!28 = !DIBasicType(name: "float", size: 32, encoding: DW_ATE_float)
!29 = !DIDerivedType(tag: DW_TAG_member, name: "evicted_seen", scope: !18, file: !1, line: 20, baseType: !21, size: 64, offset: 192)
!30 = !DIDerivedType(tag: DW_TAG_member, name: "window_size", scope: !14, file: !1, line: 25, baseType: !31, size: 32, offset: 64)
!31 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !22, line: 26, baseType: !32)
!32 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !24, line: 42, baseType: !5)
!33 = !DIDerivedType(tag: DW_TAG_member, name: "window_cur", scope: !14, file: !1, line: 26, baseType: !31, size: 32, offset: 96)
!34 = !DIDerivedType(tag: DW_TAG_member, name: "max_age_ratio", scope: !14, file: !1, line: 27, baseType: !35, size: 64, offset: 128)
!35 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!36 = !DIDerivedType(tag: DW_TAG_member, name: "iam_before", scope: !14, file: !1, line: 28, baseType: !37, size: 12288, offset: 192)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !38, size: 12288, elements: !49)
!38 = !DIDerivedType(tag: DW_TAG_typedef, name: "item_stats_automove", file: !39, line: 70, baseType: !40)
!39 = !DIFile(filename: "./items.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "5548db7354621bc680fd5812e10230ba")
!40 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !39, line: 66, size: 192, elements: !41)
!41 = !{!42, !47, !48}
!42 = !DIDerivedType(tag: DW_TAG_member, name: "evicted", scope: !40, file: !39, line: 67, baseType: !43, size: 64)
!43 = !DIDerivedType(tag: DW_TAG_typedef, name: "int64_t", file: !44, line: 27, baseType: !45)
!44 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h", directory: "", checksumkind: CSK_MD5, checksum: "649b383a60bfa3eb90e85840b2b0be20")
!45 = !DIDerivedType(tag: DW_TAG_typedef, name: "__int64_t", file: !24, line: 44, baseType: !46)
!46 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!47 = !DIDerivedType(tag: DW_TAG_member, name: "outofmemory", scope: !40, file: !39, line: 68, baseType: !43, size: 64, offset: 64)
!48 = !DIDerivedType(tag: DW_TAG_member, name: "age", scope: !40, file: !39, line: 69, baseType: !31, size: 32, offset: 128)
!49 = !{!50}
!50 = !DISubrange(count: 64)
!51 = !DIDerivedType(tag: DW_TAG_member, name: "iam_after", scope: !14, file: !1, line: 29, baseType: !37, size: 12288, offset: 12480)
!52 = !DIDerivedType(tag: DW_TAG_member, name: "sam_before", scope: !14, file: !1, line: 30, baseType: !53, size: 12288, offset: 24768)
!53 = !DICompositeType(tag: DW_TAG_array_type, baseType: !54, size: 12288, elements: !49)
!54 = !DIDerivedType(tag: DW_TAG_typedef, name: "slab_stats_automove", file: !55, line: 39, baseType: !56)
!55 = !DIFile(filename: "./slabs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "28867aba1f41c79140864d76faedcb32")
!56 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !55, line: 34, size: 192, elements: !57)
!57 = !{!58, !59, !60, !61}
!58 = !DIDerivedType(tag: DW_TAG_member, name: "chunks_per_page", scope: !56, file: !55, line: 35, baseType: !5, size: 32)
!59 = !DIDerivedType(tag: DW_TAG_member, name: "chunk_size", scope: !56, file: !55, line: 36, baseType: !5, size: 32, offset: 32)
!60 = !DIDerivedType(tag: DW_TAG_member, name: "free_chunks", scope: !56, file: !55, line: 37, baseType: !46, size: 64, offset: 64)
!61 = !DIDerivedType(tag: DW_TAG_member, name: "total_pages", scope: !56, file: !55, line: 38, baseType: !46, size: 64, offset: 128)
!62 = !DIDerivedType(tag: DW_TAG_member, name: "sam_after", scope: !14, file: !1, line: 31, baseType: !53, size: 12288, offset: 37056)
!63 = !{i32 7, !"Dwarf Version", i32 5}
!64 = !{i32 2, !"Debug Info Version", i32 3}
!65 = !{i32 1, !"wchar_size", i32 4}
!66 = !{i32 8, !"PIC Level", i32 2}
!67 = !{i32 7, !"PIE Level", i32 2}
!68 = !{i32 7, !"uwtable", i32 2}
!69 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!70 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!71 = distinct !DISubprogram(name: "slab_automove_init", scope: !1, file: !1, line: 34, type: !72, scopeLine: 34, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !162)
!72 = !DISubroutineType(types: !73)
!73 = !{!11, !74}
!74 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !75, size: 64)
!75 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "settings", file: !4, line: 454, size: 2688, elements: !76)
!76 = !{!77, !80, !82, !83, !84, !87, !88, !91, !92, !93, !94, !95, !96, !97, !98, !99, !100, !101, !102, !104, !105, !106, !107, !108, !109, !114, !115, !116, !117, !118, !119, !120, !121, !122, !123, !124, !125, !126, !127, !128, !129, !130, !131, !132, !133, !134, !135, !136, !137, !138, !139, !140, !141, !142, !143, !144, !145, !146, !147, !148, !149, !150, !151, !152, !153, !154, !155, !156, !157, !158, !159, !160, !161}
!77 = !DIDerivedType(tag: DW_TAG_member, name: "maxbytes", scope: !75, file: !4, line: 455, baseType: !78, size: 64)
!78 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !79, line: 18, baseType: !25)
!79 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!80 = !DIDerivedType(tag: DW_TAG_member, name: "maxconns", scope: !75, file: !4, line: 456, baseType: !81, size: 32, offset: 64)
!81 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!82 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !75, file: !4, line: 457, baseType: !81, size: 32, offset: 96)
!83 = !DIDerivedType(tag: DW_TAG_member, name: "udpport", scope: !75, file: !4, line: 458, baseType: !81, size: 32, offset: 128)
!84 = !DIDerivedType(tag: DW_TAG_member, name: "inter", scope: !75, file: !4, line: 459, baseType: !85, size: 64, offset: 192)
!85 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !86, size: 64)
!86 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!87 = !DIDerivedType(tag: DW_TAG_member, name: "verbose", scope: !75, file: !4, line: 460, baseType: !81, size: 32, offset: 256)
!88 = !DIDerivedType(tag: DW_TAG_member, name: "oldest_live", scope: !75, file: !4, line: 461, baseType: !89, size: 32, offset: 288)
!89 = !DIDerivedType(tag: DW_TAG_typedef, name: "rel_time_t", file: !90, line: 14, baseType: !5)
!90 = !DIFile(filename: "./logger.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "e743c4228b1e0bc1c91bec9cfd28d5ab")
!91 = !DIDerivedType(tag: DW_TAG_member, name: "evict_to_free", scope: !75, file: !4, line: 462, baseType: !81, size: 32, offset: 320)
!92 = !DIDerivedType(tag: DW_TAG_member, name: "socketpath", scope: !75, file: !4, line: 463, baseType: !85, size: 64, offset: 384)
!93 = !DIDerivedType(tag: DW_TAG_member, name: "auth_file", scope: !75, file: !4, line: 464, baseType: !85, size: 64, offset: 448)
!94 = !DIDerivedType(tag: DW_TAG_member, name: "access", scope: !75, file: !4, line: 465, baseType: !81, size: 32, offset: 512)
!95 = !DIDerivedType(tag: DW_TAG_member, name: "factor", scope: !75, file: !4, line: 466, baseType: !35, size: 64, offset: 576)
!96 = !DIDerivedType(tag: DW_TAG_member, name: "chunk_size", scope: !75, file: !4, line: 467, baseType: !81, size: 32, offset: 640)
!97 = !DIDerivedType(tag: DW_TAG_member, name: "num_threads", scope: !75, file: !4, line: 468, baseType: !81, size: 32, offset: 672)
!98 = !DIDerivedType(tag: DW_TAG_member, name: "num_threads_per_udp", scope: !75, file: !4, line: 469, baseType: !81, size: 32, offset: 704)
!99 = !DIDerivedType(tag: DW_TAG_member, name: "prefix_delimiter", scope: !75, file: !4, line: 470, baseType: !86, size: 8, offset: 736)
!100 = !DIDerivedType(tag: DW_TAG_member, name: "detail_enabled", scope: !75, file: !4, line: 471, baseType: !81, size: 32, offset: 768)
!101 = !DIDerivedType(tag: DW_TAG_member, name: "reqs_per_event", scope: !75, file: !4, line: 472, baseType: !81, size: 32, offset: 800)
!102 = !DIDerivedType(tag: DW_TAG_member, name: "use_cas", scope: !75, file: !4, line: 474, baseType: !103, size: 8, offset: 832)
!103 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!104 = !DIDerivedType(tag: DW_TAG_member, name: "binding_protocol", scope: !75, file: !4, line: 475, baseType: !3, size: 32, offset: 864)
!105 = !DIDerivedType(tag: DW_TAG_member, name: "backlog", scope: !75, file: !4, line: 476, baseType: !81, size: 32, offset: 896)
!106 = !DIDerivedType(tag: DW_TAG_member, name: "item_size_max", scope: !75, file: !4, line: 477, baseType: !81, size: 32, offset: 928)
!107 = !DIDerivedType(tag: DW_TAG_member, name: "slab_chunk_size_max", scope: !75, file: !4, line: 478, baseType: !81, size: 32, offset: 960)
!108 = !DIDerivedType(tag: DW_TAG_member, name: "slab_page_size", scope: !75, file: !4, line: 479, baseType: !81, size: 32, offset: 992)
!109 = !DIDerivedType(tag: DW_TAG_member, name: "sig_hup", scope: !75, file: !4, line: 480, baseType: !110, size: 32, offset: 1024)
!110 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !111)
!111 = !DIDerivedType(tag: DW_TAG_typedef, name: "sig_atomic_t", file: !112, line: 8, baseType: !113)
!112 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/sig_atomic_t.h", directory: "", checksumkind: CSK_MD5, checksum: "d9236f7e3e7f10f53aa9d4cd97f503cf")
!113 = !DIDerivedType(tag: DW_TAG_typedef, name: "__sig_atomic_t", file: !24, line: 215, baseType: !81)
!114 = !DIDerivedType(tag: DW_TAG_member, name: "sasl", scope: !75, file: !4, line: 481, baseType: !103, size: 8, offset: 1056)
!115 = !DIDerivedType(tag: DW_TAG_member, name: "maxconns_fast", scope: !75, file: !4, line: 482, baseType: !103, size: 8, offset: 1064)
!116 = !DIDerivedType(tag: DW_TAG_member, name: "lru_crawler", scope: !75, file: !4, line: 483, baseType: !103, size: 8, offset: 1072)
!117 = !DIDerivedType(tag: DW_TAG_member, name: "lru_maintainer_thread", scope: !75, file: !4, line: 484, baseType: !103, size: 8, offset: 1080)
!118 = !DIDerivedType(tag: DW_TAG_member, name: "lru_segmented", scope: !75, file: !4, line: 485, baseType: !103, size: 8, offset: 1088)
!119 = !DIDerivedType(tag: DW_TAG_member, name: "slab_reassign", scope: !75, file: !4, line: 486, baseType: !103, size: 8, offset: 1096)
!120 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove", scope: !75, file: !4, line: 487, baseType: !81, size: 32, offset: 1120)
!121 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove_ratio", scope: !75, file: !4, line: 488, baseType: !35, size: 64, offset: 1152)
!122 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove_window", scope: !75, file: !4, line: 489, baseType: !5, size: 32, offset: 1216)
!123 = !DIDerivedType(tag: DW_TAG_member, name: "hashpower_init", scope: !75, file: !4, line: 490, baseType: !81, size: 32, offset: 1248)
!124 = !DIDerivedType(tag: DW_TAG_member, name: "shutdown_command", scope: !75, file: !4, line: 491, baseType: !103, size: 8, offset: 1280)
!125 = !DIDerivedType(tag: DW_TAG_member, name: "tail_repair_time", scope: !75, file: !4, line: 492, baseType: !81, size: 32, offset: 1312)
!126 = !DIDerivedType(tag: DW_TAG_member, name: "flush_enabled", scope: !75, file: !4, line: 493, baseType: !103, size: 8, offset: 1344)
!127 = !DIDerivedType(tag: DW_TAG_member, name: "dump_enabled", scope: !75, file: !4, line: 494, baseType: !103, size: 8, offset: 1352)
!128 = !DIDerivedType(tag: DW_TAG_member, name: "hash_algorithm", scope: !75, file: !4, line: 495, baseType: !85, size: 64, offset: 1408)
!129 = !DIDerivedType(tag: DW_TAG_member, name: "lru_crawler_sleep", scope: !75, file: !4, line: 496, baseType: !81, size: 32, offset: 1472)
!130 = !DIDerivedType(tag: DW_TAG_member, name: "lru_crawler_tocrawl", scope: !75, file: !4, line: 497, baseType: !31, size: 32, offset: 1504)
!131 = !DIDerivedType(tag: DW_TAG_member, name: "hot_lru_pct", scope: !75, file: !4, line: 498, baseType: !81, size: 32, offset: 1536)
!132 = !DIDerivedType(tag: DW_TAG_member, name: "warm_lru_pct", scope: !75, file: !4, line: 499, baseType: !81, size: 32, offset: 1568)
!133 = !DIDerivedType(tag: DW_TAG_member, name: "hot_max_factor", scope: !75, file: !4, line: 500, baseType: !35, size: 64, offset: 1600)
!134 = !DIDerivedType(tag: DW_TAG_member, name: "warm_max_factor", scope: !75, file: !4, line: 501, baseType: !35, size: 64, offset: 1664)
!135 = !DIDerivedType(tag: DW_TAG_member, name: "crawls_persleep", scope: !75, file: !4, line: 502, baseType: !81, size: 32, offset: 1728)
!136 = !DIDerivedType(tag: DW_TAG_member, name: "temp_lru", scope: !75, file: !4, line: 503, baseType: !103, size: 8, offset: 1760)
!137 = !DIDerivedType(tag: DW_TAG_member, name: "temporary_ttl", scope: !75, file: !4, line: 504, baseType: !31, size: 32, offset: 1792)
!138 = !DIDerivedType(tag: DW_TAG_member, name: "idle_timeout", scope: !75, file: !4, line: 505, baseType: !81, size: 32, offset: 1824)
!139 = !DIDerivedType(tag: DW_TAG_member, name: "logger_watcher_buf_size", scope: !75, file: !4, line: 506, baseType: !5, size: 32, offset: 1856)
!140 = !DIDerivedType(tag: DW_TAG_member, name: "logger_buf_size", scope: !75, file: !4, line: 507, baseType: !5, size: 32, offset: 1888)
!141 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_mem_limit", scope: !75, file: !4, line: 508, baseType: !5, size: 32, offset: 1920)
!142 = !DIDerivedType(tag: DW_TAG_member, name: "drop_privileges", scope: !75, file: !4, line: 509, baseType: !103, size: 8, offset: 1952)
!143 = !DIDerivedType(tag: DW_TAG_member, name: "watch_enabled", scope: !75, file: !4, line: 510, baseType: !103, size: 8, offset: 1960)
!144 = !DIDerivedType(tag: DW_TAG_member, name: "relaxed_privileges", scope: !75, file: !4, line: 511, baseType: !103, size: 8, offset: 1968)
!145 = !DIDerivedType(tag: DW_TAG_member, name: "ext_io_threadcount", scope: !75, file: !4, line: 513, baseType: !5, size: 32, offset: 1984)
!146 = !DIDerivedType(tag: DW_TAG_member, name: "ext_page_size", scope: !75, file: !4, line: 514, baseType: !5, size: 32, offset: 2016)
!147 = !DIDerivedType(tag: DW_TAG_member, name: "ext_item_size", scope: !75, file: !4, line: 515, baseType: !5, size: 32, offset: 2048)
!148 = !DIDerivedType(tag: DW_TAG_member, name: "ext_item_age", scope: !75, file: !4, line: 516, baseType: !5, size: 32, offset: 2080)
!149 = !DIDerivedType(tag: DW_TAG_member, name: "ext_low_ttl", scope: !75, file: !4, line: 517, baseType: !5, size: 32, offset: 2112)
!150 = !DIDerivedType(tag: DW_TAG_member, name: "ext_recache_rate", scope: !75, file: !4, line: 518, baseType: !5, size: 32, offset: 2144)
!151 = !DIDerivedType(tag: DW_TAG_member, name: "ext_wbuf_size", scope: !75, file: !4, line: 519, baseType: !5, size: 32, offset: 2176)
!152 = !DIDerivedType(tag: DW_TAG_member, name: "ext_compact_under", scope: !75, file: !4, line: 520, baseType: !5, size: 32, offset: 2208)
!153 = !DIDerivedType(tag: DW_TAG_member, name: "ext_drop_under", scope: !75, file: !4, line: 521, baseType: !5, size: 32, offset: 2240)
!154 = !DIDerivedType(tag: DW_TAG_member, name: "ext_max_sleep", scope: !75, file: !4, line: 522, baseType: !5, size: 32, offset: 2272)
!155 = !DIDerivedType(tag: DW_TAG_member, name: "ext_max_frag", scope: !75, file: !4, line: 523, baseType: !35, size: 64, offset: 2304)
!156 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove_freeratio", scope: !75, file: !4, line: 524, baseType: !35, size: 64, offset: 2368)
!157 = !DIDerivedType(tag: DW_TAG_member, name: "ext_drop_unread", scope: !75, file: !4, line: 525, baseType: !103, size: 8, offset: 2432)
!158 = !DIDerivedType(tag: DW_TAG_member, name: "ext_global_pool_min", scope: !75, file: !4, line: 527, baseType: !5, size: 32, offset: 2464)
!159 = !DIDerivedType(tag: DW_TAG_member, name: "num_napi_ids", scope: !75, file: !4, line: 544, baseType: !81, size: 32, offset: 2496)
!160 = !DIDerivedType(tag: DW_TAG_member, name: "memory_file", scope: !75, file: !4, line: 545, baseType: !85, size: 64, offset: 2560)
!161 = !DIDerivedType(tag: DW_TAG_member, name: "sock_cookie_id", scope: !75, file: !4, line: 555, baseType: !31, size: 32, offset: 2624)
!162 = !{!163, !164, !165, !166}
!163 = !DILocalVariable(name: "settings", arg: 1, scope: !71, file: !1, line: 34, type: !74)
!164 = !DILocalVariable(name: "window_size", scope: !71, file: !1, line: 35, type: !31)
!165 = !DILocalVariable(name: "max_age_ratio", scope: !71, file: !1, line: 36, type: !35)
!166 = !DILocalVariable(name: "a", scope: !71, file: !1, line: 37, type: !12)
!167 = !DILocation(line: 0, scope: !71)
!168 = !DILocation(line: 35, column: 38, scope: !71)
!169 = !{!170, !174, i64 152}
!170 = !{!"settings", !171, i64 0, !174, i64 8, !174, i64 12, !174, i64 16, !175, i64 24, !174, i64 32, !174, i64 36, !174, i64 40, !175, i64 48, !175, i64 56, !174, i64 64, !176, i64 72, !174, i64 80, !174, i64 84, !174, i64 88, !172, i64 92, !174, i64 96, !174, i64 100, !177, i64 104, !174, i64 108, !174, i64 112, !174, i64 116, !174, i64 120, !174, i64 124, !174, i64 128, !177, i64 132, !177, i64 133, !177, i64 134, !177, i64 135, !177, i64 136, !177, i64 137, !174, i64 140, !176, i64 144, !174, i64 152, !174, i64 156, !177, i64 160, !174, i64 164, !177, i64 168, !177, i64 169, !175, i64 176, !174, i64 184, !174, i64 188, !174, i64 192, !174, i64 196, !176, i64 200, !176, i64 208, !174, i64 216, !177, i64 220, !174, i64 224, !174, i64 228, !174, i64 232, !174, i64 236, !174, i64 240, !177, i64 244, !177, i64 245, !177, i64 246, !174, i64 248, !174, i64 252, !174, i64 256, !174, i64 260, !174, i64 264, !174, i64 268, !174, i64 272, !174, i64 276, !174, i64 280, !174, i64 284, !176, i64 288, !176, i64 296, !177, i64 304, !174, i64 308, !174, i64 312, !175, i64 320, !174, i64 328}
!171 = !{!"long", !172, i64 0}
!172 = !{!"omnipotent char", !173, i64 0}
!173 = !{!"Simple C/C++ TBAA"}
!174 = !{!"int", !172, i64 0}
!175 = !{!"any pointer", !172, i64 0}
!176 = !{!"double", !172, i64 0}
!177 = !{!"_Bool", !172, i64 0}
!178 = !DILocation(line: 36, column: 38, scope: !71)
!179 = !{!170, !176, i64 144}
!180 = !DILocation(line: 37, column: 24, scope: !71)
!181 = !DILocation(line: 38, column: 11, scope: !182)
!182 = distinct !DILexicalBlock(scope: !71, file: !1, line: 38, column: 9)
!183 = !DILocation(line: 38, column: 9, scope: !71)
!184 = !DILocation(line: 40, column: 41, scope: !71)
!185 = !DILocation(line: 40, column: 29, scope: !71)
!186 = !DILocation(line: 40, column: 22, scope: !71)
!187 = !DILocation(line: 40, column: 20, scope: !71)
!188 = !{!189, !175, i64 0}
!189 = !{!"", !175, i64 0, !174, i64 8, !174, i64 12, !176, i64 16, !172, i64 24, !172, i64 1560, !172, i64 3096, !172, i64 4632}
!190 = !DILocation(line: 41, column: 8, scope: !71)
!191 = !DILocation(line: 41, column: 20, scope: !71)
!192 = !{!189, !174, i64 8}
!193 = !DILocation(line: 42, column: 8, scope: !71)
!194 = !DILocation(line: 42, column: 22, scope: !71)
!195 = !{!189, !176, i64 16}
!196 = !DILocation(line: 43, column: 24, scope: !197)
!197 = distinct !DILexicalBlock(scope: !71, file: !1, line: 43, column: 9)
!198 = !DILocation(line: 43, column: 9, scope: !71)
!199 = !DILocation(line: 44, column: 9, scope: !200)
!200 = distinct !DILexicalBlock(scope: !197, file: !1, line: 43, column: 33)
!201 = !DILocation(line: 45, column: 9, scope: !200)
!202 = !DILocation(line: 49, column: 33, scope: !71)
!203 = !DILocation(line: 49, column: 5, scope: !71)
!204 = !DILocation(line: 50, column: 33, scope: !71)
!205 = !DILocation(line: 50, column: 5, scope: !71)
!206 = !DILocation(line: 52, column: 5, scope: !71)
!207 = !DILocation(line: 53, column: 1, scope: !71)
!208 = !DISubprogram(name: "calloc", scope: !209, file: !209, line: 675, type: !210, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!209 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!210 = !DISubroutineType(types: !211)
!211 = !{!11, !78, !78}
!212 = !DISubprogram(name: "free", scope: !209, file: !209, line: 687, type: !213, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!213 = !DISubroutineType(types: !214)
!214 = !{null, !11}
!215 = !DISubprogram(name: "fill_item_stats_automove", scope: !39, file: !39, line: 71, type: !216, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!216 = !DISubroutineType(types: !217)
!217 = !{null, !218}
!218 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !38, size: 64)
!219 = !DISubprogram(name: "fill_slab_stats_automove", scope: !55, file: !55, line: 40, type: !220, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!220 = !DISubroutineType(types: !221)
!221 = !{null, !222}
!222 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !54, size: 64)
!223 = distinct !DISubprogram(name: "slab_automove_free", scope: !1, file: !1, line: 55, type: !213, scopeLine: 55, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !224)
!224 = !{!225, !226}
!225 = !DILocalVariable(name: "arg", arg: 1, scope: !223, file: !1, line: 55, type: !11)
!226 = !DILocalVariable(name: "a", scope: !223, file: !1, line: 56, type: !12)
!227 = !DILocation(line: 0, scope: !223)
!228 = !DILocation(line: 57, column: 13, scope: !223)
!229 = !DILocation(line: 57, column: 5, scope: !223)
!230 = !DILocation(line: 58, column: 5, scope: !223)
!231 = !DILocation(line: 59, column: 1, scope: !223)
!232 = distinct !DISubprogram(name: "slab_automove_run", scope: !1, file: !1, line: 74, type: !233, scopeLine: 74, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !236)
!233 = !DISubroutineType(types: !234)
!234 = !{null, !11, !235, !235}
!235 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !81, size: 64)
!236 = !{!237, !238, !239, !240, !241, !242, !243, !244, !245, !246, !247, !248, !249, !253, !254, !255}
!237 = !DILocalVariable(name: "arg", arg: 1, scope: !232, file: !1, line: 74, type: !11)
!238 = !DILocalVariable(name: "src", arg: 2, scope: !232, file: !1, line: 74, type: !235)
!239 = !DILocalVariable(name: "dst", arg: 3, scope: !232, file: !1, line: 74, type: !235)
!240 = !DILocalVariable(name: "a", scope: !232, file: !1, line: 75, type: !12)
!241 = !DILocalVariable(name: "n", scope: !232, file: !1, line: 76, type: !81)
!242 = !DILocalVariable(name: "w_sum", scope: !232, file: !1, line: 77, type: !18)
!243 = !DILocalVariable(name: "oldest", scope: !232, file: !1, line: 78, type: !81)
!244 = !DILocalVariable(name: "oldest_age", scope: !232, file: !1, line: 79, type: !21)
!245 = !DILocalVariable(name: "youngest", scope: !232, file: !1, line: 80, type: !81)
!246 = !DILocalVariable(name: "youngest_age", scope: !232, file: !1, line: 81, type: !21)
!247 = !DILocalVariable(name: "youngest_evicting", scope: !232, file: !1, line: 82, type: !103)
!248 = !DILocalVariable(name: "evicted_total", scope: !232, file: !1, line: 90, type: !21)
!249 = !DILocalVariable(name: "w_offset", scope: !250, file: !1, line: 98, type: !81)
!250 = distinct !DILexicalBlock(scope: !251, file: !1, line: 97, column: 67)
!251 = distinct !DILexicalBlock(scope: !252, file: !1, line: 97, column: 5)
!252 = distinct !DILexicalBlock(scope: !232, file: !1, line: 97, column: 5)
!253 = !DILocalVariable(name: "wd", scope: !250, file: !1, line: 99, type: !17)
!254 = !DILocalVariable(name: "evicted_delta", scope: !250, file: !1, line: 104, type: !21)
!255 = !DILocalVariable(name: "age", scope: !250, file: !1, line: 127, type: !21)
!256 = !DILocation(line: 0, scope: !232)
!257 = !DILocation(line: 83, column: 10, scope: !232)
!258 = !{!174, !174, i64 0}
!259 = !DILocation(line: 84, column: 10, scope: !232)
!260 = !DILocation(line: 87, column: 33, scope: !232)
!261 = !DILocation(line: 87, column: 5, scope: !232)
!262 = !DILocation(line: 88, column: 33, scope: !232)
!263 = !DILocation(line: 88, column: 5, scope: !232)
!264 = !DILocation(line: 91, column: 5, scope: !265)
!265 = distinct !DILexicalBlock(scope: !232, file: !1, line: 91, column: 5)
!266 = !DILocation(line: 92, column: 26, scope: !267)
!267 = distinct !DILexicalBlock(scope: !268, file: !1, line: 91, column: 67)
!268 = distinct !DILexicalBlock(scope: !265, file: !1, line: 91, column: 5)
!269 = !DILocation(line: 92, column: 42, scope: !267)
!270 = !{!271, !171, i64 0}
!271 = !{!"", !171, i64 0, !171, i64 8, !174, i64 16}
!272 = !DILocation(line: 92, column: 52, scope: !267)
!273 = !DILocation(line: 92, column: 69, scope: !267)
!274 = !DILocation(line: 92, column: 50, scope: !267)
!275 = !DILocation(line: 91, column: 63, scope: !268)
!276 = !DILocation(line: 92, column: 23, scope: !267)
!277 = !DILocation(line: 91, column: 32, scope: !268)
!278 = distinct !{!278, !264, !279, !280}
!279 = !DILocation(line: 93, column: 5, scope: !265)
!280 = !{!"llvm.loop.mustprogress"}
!281 = !DILocation(line: 94, column: 8, scope: !232)
!282 = !DILocation(line: 94, column: 18, scope: !232)
!283 = !{!189, !174, i64 12}
!284 = !DILocation(line: 98, column: 31, scope: !250)
!285 = !DILocation(line: 99, column: 38, scope: !250)
!286 = !DILocation(line: 97, column: 5, scope: !252)
!287 = !DILocation(line: 98, column: 26, scope: !250)
!288 = !DILocation(line: 0, scope: !250)
!289 = !DILocation(line: 99, column: 65, scope: !250)
!290 = !DILocation(line: 99, column: 76, scope: !250)
!291 = !DILocation(line: 99, column: 59, scope: !250)
!292 = !DILocation(line: 99, column: 35, scope: !250)
!293 = !DILocation(line: 100, column: 9, scope: !250)
!294 = !DILocation(line: 104, column: 34, scope: !250)
!295 = !DILocation(line: 104, column: 50, scope: !250)
!296 = !DILocation(line: 104, column: 60, scope: !250)
!297 = !DILocation(line: 104, column: 77, scope: !250)
!298 = !DILocation(line: 105, column: 27, scope: !299)
!299 = distinct !DILexicalBlock(scope: !250, file: !1, line: 105, column: 13)
!300 = !DILocation(line: 105, column: 13, scope: !250)
!301 = !DILocation(line: 104, column: 58, scope: !250)
!302 = !DILocation(line: 107, column: 33, scope: !303)
!303 = distinct !DILexicalBlock(scope: !299, file: !1, line: 105, column: 32)
!304 = !DILocation(line: 107, column: 55, scope: !303)
!305 = !DILocation(line: 107, column: 17, scope: !303)
!306 = !DILocation(line: 107, column: 31, scope: !303)
!307 = !{!308, !309, i64 16}
!308 = !{!"window_data", !171, i64 0, !171, i64 8, !309, i64 16, !171, i64 24}
!309 = !{!"float", !172, i64 0}
!310 = !DILocation(line: 108, column: 17, scope: !303)
!311 = !DILocation(line: 108, column: 30, scope: !303)
!312 = !{!308, !171, i64 24}
!313 = !DILocation(line: 109, column: 17, scope: !303)
!314 = !DILocation(line: 109, column: 23, scope: !303)
!315 = !{!308, !171, i64 8}
!316 = !DILocation(line: 110, column: 9, scope: !303)
!317 = !DILocation(line: 112, column: 29, scope: !318)
!318 = distinct !DILexicalBlock(scope: !250, file: !1, line: 112, column: 13)
!319 = !{!271, !171, i64 8}
!320 = !DILocation(line: 112, column: 60, scope: !318)
!321 = !DILocation(line: 112, column: 72, scope: !318)
!322 = !DILocation(line: 112, column: 13, scope: !250)
!323 = !DILocation(line: 113, column: 17, scope: !324)
!324 = distinct !DILexicalBlock(scope: !318, file: !1, line: 112, column: 77)
!325 = !DILocation(line: 113, column: 23, scope: !324)
!326 = !DILocation(line: 114, column: 9, scope: !324)
!327 = !DILocation(line: 115, column: 13, scope: !328)
!328 = distinct !DILexicalBlock(scope: !250, file: !1, line: 115, column: 13)
!329 = !DILocation(line: 115, column: 29, scope: !328)
!330 = !{!331, !171, i64 16}
!331 = !{!"", !174, i64 0, !174, i64 4, !171, i64 8, !171, i64 16}
!332 = !DILocation(line: 115, column: 60, scope: !328)
!333 = !DILocation(line: 115, column: 72, scope: !328)
!334 = !DILocation(line: 115, column: 13, scope: !250)
!335 = !DILocation(line: 116, column: 17, scope: !336)
!336 = distinct !DILexicalBlock(scope: !328, file: !1, line: 115, column: 77)
!337 = !DILocation(line: 116, column: 23, scope: !336)
!338 = !DILocation(line: 117, column: 9, scope: !336)
!339 = !DILocation(line: 120, column: 35, scope: !250)
!340 = !{!271, !174, i64 16}
!341 = !DILocation(line: 120, column: 19, scope: !250)
!342 = !DILocation(line: 120, column: 17, scope: !250)
!343 = !{!308, !171, i64 0}
!344 = !DILocation(line: 124, column: 24, scope: !250)
!345 = !DILocation(line: 124, column: 21, scope: !250)
!346 = !DILocation(line: 124, column: 58, scope: !250)
!347 = !DILocalVariable(name: "wd", arg: 1, scope: !348, file: !1, line: 61, type: !17)
!348 = distinct !DISubprogram(name: "window_sum", scope: !1, file: !1, line: 61, type: !349, scopeLine: 61, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !351)
!349 = !DISubroutineType(types: !350)
!350 = !{null, !17, !17, !31}
!351 = !{!347, !352, !353, !354, !355}
!352 = !DILocalVariable(name: "w", arg: 2, scope: !348, file: !1, line: 61, type: !17)
!353 = !DILocalVariable(name: "size", arg: 3, scope: !348, file: !1, line: 61, type: !31)
!354 = !DILocalVariable(name: "x", scope: !348, file: !1, line: 62, type: !81)
!355 = !DILocalVariable(name: "d", scope: !356, file: !1, line: 64, type: !17)
!356 = distinct !DILexicalBlock(scope: !357, file: !1, line: 63, column: 32)
!357 = distinct !DILexicalBlock(scope: !358, file: !1, line: 63, column: 5)
!358 = distinct !DILexicalBlock(scope: !348, file: !1, line: 63, column: 5)
!359 = !DILocation(line: 0, scope: !348, inlinedAt: !360)
!360 = distinct !DILocation(line: 124, column: 9, scope: !250)
!361 = !DILocation(line: 63, column: 19, scope: !357, inlinedAt: !360)
!362 = !DILocation(line: 63, column: 5, scope: !358, inlinedAt: !360)
!363 = !DILocation(line: 64, column: 34, scope: !356, inlinedAt: !360)
!364 = !DILocation(line: 0, scope: !356, inlinedAt: !360)
!365 = !DILocation(line: 65, column: 22, scope: !356, inlinedAt: !360)
!366 = !DILocation(line: 65, column: 16, scope: !356, inlinedAt: !360)
!367 = !DILocation(line: 66, column: 24, scope: !356, inlinedAt: !360)
!368 = !DILocation(line: 66, column: 18, scope: !356, inlinedAt: !360)
!369 = !DILocation(line: 67, column: 32, scope: !356, inlinedAt: !360)
!370 = !DILocation(line: 67, column: 26, scope: !356, inlinedAt: !360)
!371 = !DILocation(line: 68, column: 31, scope: !356, inlinedAt: !360)
!372 = !DILocation(line: 68, column: 25, scope: !356, inlinedAt: !360)
!373 = !DILocation(line: 63, column: 28, scope: !357, inlinedAt: !360)
!374 = distinct !{!374, !362, !375, !280}
!375 = !DILocation(line: 69, column: 5, scope: !358, inlinedAt: !360)
!376 = !DILocation(line: 127, column: 34, scope: !250)
!377 = !DILocation(line: 130, column: 29, scope: !378)
!378 = distinct !DILexicalBlock(scope: !250, file: !1, line: 130, column: 13)
!379 = !{!331, !171, i64 8}
!380 = !DILocation(line: 130, column: 13, scope: !378)
!381 = !DILocation(line: 130, column: 59, scope: !378)
!382 = !{!331, !174, i64 0}
!383 = !DILocation(line: 130, column: 43, scope: !378)
!384 = !DILocation(line: 130, column: 75, scope: !378)
!385 = !DILocation(line: 130, column: 41, scope: !378)
!386 = !DILocation(line: 130, column: 13, scope: !250)
!387 = !DILocation(line: 140, column: 17, scope: !388)
!388 = distinct !DILexicalBlock(scope: !250, file: !1, line: 140, column: 13)
!389 = !DILocation(line: 140, column: 30, scope: !388)
!390 = !DILocation(line: 148, column: 17, scope: !391)
!391 = distinct !DILexicalBlock(scope: !250, file: !1, line: 148, column: 13)
!392 = !DILocation(line: 148, column: 32, scope: !391)
!393 = !DILocation(line: 148, column: 72, scope: !391)
!394 = !DILocation(line: 148, column: 57, scope: !391)
!395 = !DILocation(line: 148, column: 55, scope: !391)
!396 = !DILocation(line: 149, column: 21, scope: !391)
!397 = !DILocation(line: 149, column: 46, scope: !391)
!398 = !DILocation(line: 149, column: 44, scope: !391)
!399 = !DILocation(line: 149, column: 61, scope: !391)
!400 = !DILocation(line: 148, column: 13, scope: !250)
!401 = !DILocation(line: 153, column: 9, scope: !402)
!402 = distinct !DILexicalBlock(scope: !391, file: !1, line: 149, column: 70)
!403 = !DILocation(line: 132, column: 22, scope: !404)
!404 = distinct !DILexicalBlock(scope: !405, file: !1, line: 131, column: 35)
!405 = distinct !DILexicalBlock(scope: !406, file: !1, line: 131, column: 17)
!406 = distinct !DILexicalBlock(scope: !378, file: !1, line: 130, column: 100)
!407 = !DILocation(line: 133, column: 22, scope: !404)
!408 = !DILocation(line: 97, column: 63, scope: !251)
!409 = !DILocation(line: 97, column: 32, scope: !251)
!410 = distinct !{!410, !286, !411, !280}
!411 = !DILocation(line: 154, column: 5, scope: !252)
!412 = !DILocation(line: 156, column: 5, scope: !232)
!413 = !DILocation(line: 158, column: 5, scope: !232)
!414 = !DILocation(line: 162, column: 18, scope: !415)
!415 = distinct !DILexicalBlock(scope: !232, file: !1, line: 162, column: 9)
!416 = !DILocation(line: 162, column: 24, scope: !415)
!417 = !DILocation(line: 162, column: 46, scope: !415)
!418 = !DILocation(line: 162, column: 62, scope: !415)
!419 = !DILocation(line: 162, column: 57, scope: !415)
!420 = !DILocation(line: 162, column: 9, scope: !232)
!421 = !DILocation(line: 163, column: 13, scope: !422)
!422 = distinct !DILexicalBlock(scope: !423, file: !1, line: 163, column: 13)
!423 = distinct !DILexicalBlock(scope: !415, file: !1, line: 162, column: 75)
!424 = !DILocation(line: 163, column: 29, scope: !422)
!425 = !DILocation(line: 163, column: 53, scope: !422)
!426 = !DILocation(line: 163, column: 48, scope: !422)
!427 = !DILocation(line: 163, column: 26, scope: !422)
!428 = !DILocation(line: 163, column: 68, scope: !422)
!429 = !DILocation(line: 164, column: 18, scope: !430)
!430 = distinct !DILexicalBlock(scope: !422, file: !1, line: 163, column: 90)
!431 = !DILocation(line: 165, column: 18, scope: !430)
!432 = !DILocation(line: 166, column: 9, scope: !430)
!433 = !DILocation(line: 169, column: 1, scope: !232)
