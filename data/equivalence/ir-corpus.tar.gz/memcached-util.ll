; ModuleID = 'util.c'
source_filename = "util.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.__va_list_tag = type { i32, i32, ptr, ptr }

@uriencode_str = internal global [768 x i8] zeroinitializer, align 16, !dbg !0
@uriencode_map = internal unnamed_addr global [256 x ptr] zeroinitializer, align 16, !dbg !38
@.str = private unnamed_addr constant [9 x i8] c"%%%02hhX\00", align 1, !dbg !32
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nofree nounwind sanitize_thread uwtable
define dso_local void @uriencode_init() local_unnamed_addr #0 !dbg !55 {
entry:
  tail call void @llvm.dbg.value(metadata ptr @uriencode_str, metadata !60, metadata !DIExpression()), !dbg !61
  tail call void @llvm.dbg.value(metadata i32 0, metadata !59, metadata !DIExpression()), !dbg !61
  %call = tail call ptr @__ctype_b_loc() #16, !dbg !61
  tail call void @llvm.dbg.value(metadata ptr @uriencode_str, metadata !60, metadata !DIExpression()), !dbg !61
  tail call void @llvm.dbg.value(metadata i32 0, metadata !59, metadata !DIExpression()), !dbg !61
  br label %for.body, !dbg !62

for.body:                                         ; preds = %entry, %for.inc
  %indvars.iv = phi i64 [ 0, %entry ], [ %indvars.iv.next, %for.inc ]
  %str.036 = phi ptr [ @uriencode_str, %entry ], [ %str.1, %for.inc ]
  tail call void @llvm.dbg.value(metadata ptr %str.036, metadata !60, metadata !DIExpression()), !dbg !61
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !59, metadata !DIExpression()), !dbg !61
  %0 = load ptr, ptr %call, align 8, !dbg !64, !tbaa !68
  %arrayidx = getelementptr inbounds i16, ptr %0, i64 %indvars.iv, !dbg !64
  %1 = load i16, ptr %arrayidx, align 2, !dbg !64, !tbaa !72
  %.fr33 = freeze i16 %1, !dbg !64
  %2 = and i16 %.fr33, 8, !dbg !64
  %tobool.not.not = icmp eq i16 %2, 0, !dbg !64
  br i1 %tobool.not.not, label %switch.early.test, label %if.then, !dbg !74

switch.early.test:                                ; preds = %for.body
  %trunc = trunc i64 %indvars.iv to i8, !dbg !74
  switch i8 %trunc, label %if.else [
    i8 126, label %if.then
    i8 95, label %if.then
    i8 46, label %if.then
    i8 45, label %if.then
  ], !dbg !74

if.then:                                          ; preds = %switch.early.test, %switch.early.test, %switch.early.test, %switch.early.test, %for.body
  %arrayidx13 = getelementptr inbounds [256 x ptr], ptr @uriencode_map, i64 0, i64 %indvars.iv, !dbg !75
  store ptr null, ptr %arrayidx13, align 8, !dbg !77, !tbaa !68
  br label %for.inc, !dbg !78

if.else:                                          ; preds = %switch.early.test
  %3 = trunc nuw nsw i64 %indvars.iv to i32, !dbg !74
  %call16 = tail call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %str.036, i64 noundef 4, ptr noundef nonnull @.str, i32 noundef %3) #17, !dbg !79
  %arrayidx18 = getelementptr inbounds [256 x ptr], ptr @uriencode_map, i64 0, i64 %indvars.iv, !dbg !81
  store ptr %str.036, ptr %arrayidx18, align 8, !dbg !82, !tbaa !68
  %add.ptr = getelementptr inbounds i8, ptr %str.036, i64 3, !dbg !83
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !60, metadata !DIExpression()), !dbg !61
  br label %for.inc

for.inc:                                          ; preds = %if.then, %if.else
  %str.1 = phi ptr [ %str.036, %if.then ], [ %add.ptr, %if.else ], !dbg !61
  tail call void @llvm.dbg.value(metadata ptr %str.1, metadata !60, metadata !DIExpression()), !dbg !61
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !84
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !59, metadata !DIExpression()), !dbg !61
  %exitcond.not = icmp eq i64 %indvars.iv.next, 256, !dbg !85
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !62, !llvm.loop !86

for.end:                                          ; preds = %for.inc
  ret void, !dbg !89
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nofree nosync nounwind willreturn memory(none)
declare !dbg !90 ptr @__ctype_b_loc() local_unnamed_addr #2

; Function Attrs: nofree nounwind
declare !dbg !96 noundef i32 @snprintf(ptr noalias nocapture noundef writeonly, i64 noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nofree norecurse nosync nounwind sanitize_thread memory(readwrite, inaccessiblemem: none) uwtable
define dso_local zeroext i1 @uriencode(ptr nocapture noundef readonly %src, ptr nocapture noundef writeonly %dst, i64 noundef %srclen, i64 noundef %dstlen) local_unnamed_addr #4 !dbg !107 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %src, metadata !113, metadata !DIExpression()), !dbg !119
  tail call void @llvm.dbg.value(metadata ptr %dst, metadata !114, metadata !DIExpression()), !dbg !119
  tail call void @llvm.dbg.value(metadata i64 %srclen, metadata !115, metadata !DIExpression()), !dbg !119
  tail call void @llvm.dbg.value(metadata i64 %dstlen, metadata !116, metadata !DIExpression()), !dbg !119
  tail call void @llvm.dbg.value(metadata i64 0, metadata !118, metadata !DIExpression()), !dbg !119
  tail call void @llvm.dbg.value(metadata i32 0, metadata !117, metadata !DIExpression()), !dbg !119
  %cmp38 = icmp eq i64 %srclen, 0, !dbg !120
  br i1 %cmp38, label %for.end, label %for.body.preheader, !dbg !123

for.body.preheader:                               ; preds = %entry
  tail call void @llvm.dbg.value(metadata i64 0, metadata !118, metadata !DIExpression()), !dbg !119
  tail call void @llvm.dbg.value(metadata i64 0, metadata !117, metadata !DIExpression()), !dbg !119
  %cmp250 = icmp ult i64 %dstlen, 4, !dbg !124
  br i1 %cmp250, label %cleanup, label %if.end, !dbg !127

for.body:                                         ; preds = %for.inc
  tail call void @llvm.dbg.value(metadata i64 %add14, metadata !118, metadata !DIExpression()), !dbg !119
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !117, metadata !DIExpression()), !dbg !119
  %add = add i64 %add14, 4, !dbg !128
  %cmp2 = icmp ugt i64 %add, %dstlen, !dbg !124
  br i1 %cmp2, label %cleanup.loopexit, label %if.end, !dbg !127, !llvm.loop !129

if.end:                                           ; preds = %for.body.preheader, %for.body
  %d.04052 = phi i64 [ %add14, %for.body ], [ 0, %for.body.preheader ]
  %indvars.iv51 = phi i64 [ %indvars.iv.next, %for.body ], [ 0, %for.body.preheader ]
  tail call void @llvm.dbg.value(metadata i64 %d.04052, metadata !118, metadata !DIExpression()), !dbg !119
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv51, metadata !117, metadata !DIExpression()), !dbg !119
  %arrayidx = getelementptr inbounds i8, ptr %src, i64 %indvars.iv51, !dbg !131
  %0 = load i8, ptr %arrayidx, align 1, !dbg !131, !tbaa !133
  %idxprom4 = zext i8 %0 to i64, !dbg !134
  %arrayidx5 = getelementptr inbounds [256 x ptr], ptr @uriencode_map, i64 0, i64 %idxprom4, !dbg !134
  %1 = load ptr, ptr %arrayidx5, align 8, !dbg !134, !tbaa !68
  %cmp6.not = icmp eq ptr %1, null, !dbg !135
  %arrayidx17 = getelementptr inbounds i8, ptr %dst, i64 %d.04052, !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %add14, metadata !118, metadata !DIExpression()), !dbg !119
  tail call void @llvm.dbg.value(metadata i64 %add14, metadata !118, metadata !DIExpression()), !dbg !119
  br i1 %cmp6.not, label %if.else, label %if.then8, !dbg !137

if.then8:                                         ; preds = %if.end
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %arrayidx17, ptr noundef nonnull align 1 dereferenceable(3) %1, i64 3, i1 false), !dbg !138
  br label %for.inc, !dbg !140

if.else:                                          ; preds = %if.end
  store i8 %0, ptr %arrayidx17, align 1, !dbg !141, !tbaa !133
  br label %for.inc

for.inc:                                          ; preds = %if.then8, %if.else
  %.sink = phi i64 [ 3, %if.then8 ], [ 1, %if.else ]
  %add14 = add i64 %d.04052, %.sink, !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %add14, metadata !118, metadata !DIExpression()), !dbg !119
  %indvars.iv.next = add nuw i64 %indvars.iv51, 1, !dbg !143
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !117, metadata !DIExpression()), !dbg !119
  %exitcond = icmp eq i64 %indvars.iv.next, %srclen, !dbg !120
  br i1 %exitcond, label %for.end, label %for.body, !dbg !123, !llvm.loop !129

for.end:                                          ; preds = %for.inc, %entry
  %d.0.lcssa = phi i64 [ 0, %entry ], [ %add14, %for.inc ], !dbg !119
  %arrayidx20 = getelementptr inbounds i8, ptr %dst, i64 %d.0.lcssa, !dbg !144
  store i8 0, ptr %arrayidx20, align 1, !dbg !145, !tbaa !133
  br label %cleanup, !dbg !146

cleanup.loopexit:                                 ; preds = %for.body
  %cmp.le = icmp uge i64 %indvars.iv.next, %srclen
  br label %cleanup, !dbg !147

cleanup:                                          ; preds = %cleanup.loopexit, %for.body.preheader, %for.end
  %cmp36 = phi i1 [ true, %for.end ], [ false, %for.body.preheader ], [ %cmp.le, %cleanup.loopexit ]
  ret i1 %cmp36, !dbg !147
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #5

; Function Attrs: mustprogress nofree nounwind sanitize_thread willreturn uwtable
define dso_local noundef zeroext i1 @safe_strtoull(ptr noundef %str, ptr nocapture noundef writeonly %out) local_unnamed_addr #6 !dbg !148 {
entry:
  %endptr = alloca ptr, align 8, !DIAssignID !162
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !159, metadata !DIExpression(), metadata !162, metadata ptr %endptr, metadata !DIExpression()), !dbg !163
  tail call void @llvm.dbg.value(metadata ptr %str, metadata !157, metadata !DIExpression()), !dbg !163
  tail call void @llvm.dbg.value(metadata ptr %out, metadata !158, metadata !DIExpression()), !dbg !163
  %call = tail call ptr @__errno_location() #16, !dbg !164
  store i32 0, ptr %call, align 4, !dbg !165, !tbaa !166
  store i64 0, ptr %out, align 8, !dbg !168, !tbaa !169
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %endptr) #17, !dbg !171
  %call1 = call i64 @strtoull(ptr noundef %str, ptr noundef nonnull %endptr, i32 noundef 10) #17, !dbg !172
  tail call void @llvm.dbg.value(metadata i64 %call1, metadata !160, metadata !DIExpression()), !dbg !163
  %0 = load i32, ptr %call, align 4, !dbg !173, !tbaa !166
  %cmp = icmp eq i32 %0, 34, !dbg !175
  br i1 %cmp, label %cleanup, label %lor.lhs.false, !dbg !176

lor.lhs.false:                                    ; preds = %entry
  %1 = load ptr, ptr %endptr, align 8, !dbg !177, !tbaa !68
  %cmp3 = icmp eq ptr %1, %str, !dbg !178
  br i1 %cmp3, label %cleanup, label %if.end, !dbg !179

if.end:                                           ; preds = %lor.lhs.false
  %call4 = tail call ptr @__ctype_b_loc() #16, !dbg !180
  %2 = load ptr, ptr %call4, align 8, !dbg !180, !tbaa !68
  %3 = load i8, ptr %1, align 1, !dbg !180, !tbaa !133
  %idxprom = zext i8 %3 to i64
  %arrayidx = getelementptr inbounds i16, ptr %2, i64 %idxprom, !dbg !180
  %4 = load i16, ptr %arrayidx, align 2, !dbg !180, !tbaa !72
  %5 = and i16 %4, 8192, !dbg !180
  %tobool.not = icmp eq i16 %5, 0, !dbg !180
  %cmp8 = icmp ne i8 %3, 0
  %or.cond = and i1 %cmp8, %tobool.not, !dbg !182
  br i1 %or.cond, label %cleanup, label %if.then12, !dbg !182

if.then12:                                        ; preds = %if.end
  %cmp13 = icmp slt i64 %call1, 0, !dbg !183
  br i1 %cmp13, label %if.then15, label %if.end21, !dbg !186

if.then15:                                        ; preds = %if.then12
  %sub.ptr.lhs.cast = ptrtoint ptr %1 to i64, !dbg !187
  %sub.ptr.rhs.cast = ptrtoint ptr %str to i64, !dbg !187
  %sub.ptr.sub = sub i64 %sub.ptr.lhs.cast, %sub.ptr.rhs.cast, !dbg !187
  %call16 = tail call ptr @memchr(ptr noundef %str, i32 noundef 45, i64 noundef %sub.ptr.sub) #18, !dbg !190
  %cmp17.not = icmp eq ptr %call16, null, !dbg !191
  br i1 %cmp17.not, label %if.end21, label %cleanup, !dbg !192

if.end21:                                         ; preds = %if.then15, %if.then12
  store i64 %call1, ptr %out, align 8, !dbg !193, !tbaa !169
  br label %cleanup, !dbg !194

cleanup:                                          ; preds = %if.end, %if.then15, %entry, %lor.lhs.false, %if.end21
  %retval.0 = phi i1 [ true, %if.end21 ], [ false, %lor.lhs.false ], [ false, %entry ], [ false, %if.then15 ], [ false, %if.end ], !dbg !163
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %endptr) #17, !dbg !195
  ret i1 %retval.0, !dbg !195
}

; Function Attrs: mustprogress nofree nosync nounwind willreturn memory(none)
declare !dbg !196 ptr @__errno_location() local_unnamed_addr #2

; Function Attrs: mustprogress nofree nounwind willreturn
declare !dbg !201 i64 @strtoull(ptr noundef readonly, ptr nocapture noundef, i32 noundef) local_unnamed_addr #7

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare !dbg !207 ptr @memchr(ptr noundef, i32 noundef, i64 noundef) local_unnamed_addr #8

; Function Attrs: mustprogress nofree nounwind sanitize_thread willreturn uwtable
define dso_local noundef zeroext i1 @safe_strtoull_hex(ptr noundef %str, ptr nocapture noundef writeonly %out) local_unnamed_addr #6 !dbg !213 {
entry:
  %endptr = alloca ptr, align 8, !DIAssignID !219
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !217, metadata !DIExpression(), metadata !219, metadata ptr %endptr, metadata !DIExpression()), !dbg !220
  tail call void @llvm.dbg.value(metadata ptr %str, metadata !215, metadata !DIExpression()), !dbg !220
  tail call void @llvm.dbg.value(metadata ptr %out, metadata !216, metadata !DIExpression()), !dbg !220
  %call = tail call ptr @__errno_location() #16, !dbg !221
  store i32 0, ptr %call, align 4, !dbg !222, !tbaa !166
  store i64 0, ptr %out, align 8, !dbg !223, !tbaa !169
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %endptr) #17, !dbg !224
  %call1 = call i64 @strtoull(ptr noundef %str, ptr noundef nonnull %endptr, i32 noundef 16) #17, !dbg !225
  tail call void @llvm.dbg.value(metadata i64 %call1, metadata !218, metadata !DIExpression()), !dbg !220
  %0 = load i32, ptr %call, align 4, !dbg !226, !tbaa !166
  %cmp = icmp eq i32 %0, 34, !dbg !228
  br i1 %cmp, label %cleanup, label %lor.lhs.false, !dbg !229

lor.lhs.false:                                    ; preds = %entry
  %1 = load ptr, ptr %endptr, align 8, !dbg !230, !tbaa !68
  %cmp3 = icmp eq ptr %1, %str, !dbg !231
  br i1 %cmp3, label %cleanup, label %if.end, !dbg !232

if.end:                                           ; preds = %lor.lhs.false
  %call4 = tail call ptr @__ctype_b_loc() #16, !dbg !233
  %2 = load ptr, ptr %call4, align 8, !dbg !233, !tbaa !68
  %3 = load i8, ptr %1, align 1, !dbg !233, !tbaa !133
  %idxprom = zext i8 %3 to i64
  %arrayidx = getelementptr inbounds i16, ptr %2, i64 %idxprom, !dbg !233
  %4 = load i16, ptr %arrayidx, align 2, !dbg !233, !tbaa !72
  %5 = and i16 %4, 8192, !dbg !233
  %tobool.not = icmp eq i16 %5, 0, !dbg !233
  %cmp8 = icmp ne i8 %3, 0
  %or.cond = and i1 %cmp8, %tobool.not, !dbg !235
  br i1 %or.cond, label %cleanup, label %if.then12, !dbg !235

if.then12:                                        ; preds = %if.end
  %cmp13 = icmp slt i64 %call1, 0, !dbg !236
  br i1 %cmp13, label %if.then15, label %if.end21, !dbg !239

if.then15:                                        ; preds = %if.then12
  %sub.ptr.lhs.cast = ptrtoint ptr %1 to i64, !dbg !240
  %sub.ptr.rhs.cast = ptrtoint ptr %str to i64, !dbg !240
  %sub.ptr.sub = sub i64 %sub.ptr.lhs.cast, %sub.ptr.rhs.cast, !dbg !240
  %call16 = tail call ptr @memchr(ptr noundef %str, i32 noundef 45, i64 noundef %sub.ptr.sub) #18, !dbg !243
  %cmp17.not = icmp eq ptr %call16, null, !dbg !244
  br i1 %cmp17.not, label %if.end21, label %cleanup, !dbg !245

if.end21:                                         ; preds = %if.then15, %if.then12
  store i64 %call1, ptr %out, align 8, !dbg !246, !tbaa !169
  br label %cleanup, !dbg !247

cleanup:                                          ; preds = %if.end, %if.then15, %entry, %lor.lhs.false, %if.end21
  %retval.0 = phi i1 [ true, %if.end21 ], [ false, %lor.lhs.false ], [ false, %entry ], [ false, %if.then15 ], [ false, %if.end ], !dbg !220
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %endptr) #17, !dbg !248
  ret i1 %retval.0, !dbg !248
}

; Function Attrs: mustprogress nofree nounwind sanitize_thread willreturn uwtable
define dso_local noundef zeroext i1 @safe_strtoll(ptr noundef %str, ptr nocapture noundef writeonly %out) local_unnamed_addr #6 !dbg !249 {
entry:
  %endptr = alloca ptr, align 8, !DIAssignID !261
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !259, metadata !DIExpression(), metadata !261, metadata ptr %endptr, metadata !DIExpression()), !dbg !262
  tail call void @llvm.dbg.value(metadata ptr %str, metadata !257, metadata !DIExpression()), !dbg !262
  tail call void @llvm.dbg.value(metadata ptr %out, metadata !258, metadata !DIExpression()), !dbg !262
  %call = tail call ptr @__errno_location() #16, !dbg !263
  store i32 0, ptr %call, align 4, !dbg !264, !tbaa !166
  store i64 0, ptr %out, align 8, !dbg !265, !tbaa !169
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %endptr) #17, !dbg !266
  %call1 = call i64 @strtoll(ptr noundef %str, ptr noundef nonnull %endptr, i32 noundef 10) #17, !dbg !267
  tail call void @llvm.dbg.value(metadata i64 %call1, metadata !260, metadata !DIExpression()), !dbg !262
  %0 = load i32, ptr %call, align 4, !dbg !268, !tbaa !166
  %cmp = icmp eq i32 %0, 34, !dbg !270
  br i1 %cmp, label %cleanup, label %lor.lhs.false, !dbg !271

lor.lhs.false:                                    ; preds = %entry
  %1 = load ptr, ptr %endptr, align 8, !dbg !272, !tbaa !68
  %cmp3 = icmp eq ptr %1, %str, !dbg !273
  br i1 %cmp3, label %cleanup, label %if.end, !dbg !274

if.end:                                           ; preds = %lor.lhs.false
  %call4 = tail call ptr @__ctype_b_loc() #16, !dbg !275
  %2 = load ptr, ptr %call4, align 8, !dbg !275, !tbaa !68
  %3 = load i8, ptr %1, align 1, !dbg !275, !tbaa !133
  %idxprom = zext i8 %3 to i64
  %arrayidx = getelementptr inbounds i16, ptr %2, i64 %idxprom, !dbg !275
  %4 = load i16, ptr %arrayidx, align 2, !dbg !275, !tbaa !72
  %5 = and i16 %4, 8192, !dbg !275
  %tobool.not = icmp eq i16 %5, 0, !dbg !275
  %cmp8 = icmp ne i8 %3, 0
  %or.cond = and i1 %cmp8, %tobool.not, !dbg !277
  br i1 %or.cond, label %cleanup, label %if.then12, !dbg !277

if.then12:                                        ; preds = %if.end
  store i64 %call1, ptr %out, align 8, !dbg !278, !tbaa !169
  br label %cleanup, !dbg !280

cleanup:                                          ; preds = %if.end, %entry, %lor.lhs.false, %if.then12
  %retval.0 = phi i1 [ true, %if.then12 ], [ false, %lor.lhs.false ], [ false, %entry ], [ false, %if.end ], !dbg !262
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %endptr) #17, !dbg !281
  ret i1 %retval.0, !dbg !281
}

; Function Attrs: mustprogress nofree nounwind willreturn
declare !dbg !282 i64 @strtoll(ptr noundef readonly, ptr nocapture noundef, i32 noundef) local_unnamed_addr #7

; Function Attrs: mustprogress nofree nounwind sanitize_thread willreturn uwtable
define dso_local noundef zeroext i1 @safe_strtoul(ptr noundef %str, ptr nocapture noundef writeonly %out) local_unnamed_addr #6 !dbg !285 {
entry:
  %endptr = alloca ptr, align 8, !DIAssignID !296
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !294, metadata !DIExpression(), metadata !296, metadata ptr %endptr, metadata !DIExpression()), !dbg !297
  tail call void @llvm.dbg.value(metadata ptr %str, metadata !292, metadata !DIExpression()), !dbg !297
  tail call void @llvm.dbg.value(metadata ptr %out, metadata !293, metadata !DIExpression()), !dbg !297
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %endptr) #17, !dbg !298
  store ptr null, ptr %endptr, align 8, !dbg !299, !tbaa !68, !DIAssignID !300
  tail call void @llvm.dbg.assign(metadata ptr null, metadata !294, metadata !DIExpression(), metadata !300, metadata ptr %endptr, metadata !DIExpression()), !dbg !297
  tail call void @llvm.dbg.value(metadata i64 0, metadata !295, metadata !DIExpression()), !dbg !297
  store i32 0, ptr %out, align 4, !dbg !301, !tbaa !166
  %call = tail call ptr @__errno_location() #16, !dbg !302
  store i32 0, ptr %call, align 4, !dbg !303, !tbaa !166
  %call1 = call i64 @strtoul(ptr noundef %str, ptr noundef nonnull %endptr, i32 noundef 10) #17, !dbg !304
  tail call void @llvm.dbg.value(metadata i64 %call1, metadata !295, metadata !DIExpression()), !dbg !297
  %0 = load i32, ptr %call, align 4, !dbg !305, !tbaa !166
  %cmp = icmp eq i32 %0, 34, !dbg !307
  br i1 %cmp, label %cleanup, label %lor.lhs.false, !dbg !308

lor.lhs.false:                                    ; preds = %entry
  %1 = load ptr, ptr %endptr, align 8, !dbg !309, !tbaa !68
  %cmp3 = icmp eq ptr %1, %str, !dbg !310
  br i1 %cmp3, label %cleanup, label %if.end, !dbg !311

if.end:                                           ; preds = %lor.lhs.false
  %call4 = tail call ptr @__ctype_b_loc() #16, !dbg !312
  %2 = load ptr, ptr %call4, align 8, !dbg !312, !tbaa !68
  %3 = load i8, ptr %1, align 1, !dbg !312, !tbaa !133
  %idxprom = zext i8 %3 to i64
  %arrayidx = getelementptr inbounds i16, ptr %2, i64 %idxprom, !dbg !312
  %4 = load i16, ptr %arrayidx, align 2, !dbg !312, !tbaa !72
  %5 = and i16 %4, 8192, !dbg !312
  %tobool.not = icmp eq i16 %5, 0, !dbg !312
  %cmp8 = icmp ne i8 %3, 0
  %or.cond = and i1 %cmp8, %tobool.not, !dbg !314
  br i1 %or.cond, label %cleanup, label %if.then12, !dbg !314

if.then12:                                        ; preds = %if.end
  %cmp13 = icmp slt i64 %call1, 0, !dbg !315
  br i1 %cmp13, label %if.then15, label %if.end21, !dbg !318

if.then15:                                        ; preds = %if.then12
  %sub.ptr.lhs.cast = ptrtoint ptr %1 to i64, !dbg !319
  %sub.ptr.rhs.cast = ptrtoint ptr %str to i64, !dbg !319
  %sub.ptr.sub = sub i64 %sub.ptr.lhs.cast, %sub.ptr.rhs.cast, !dbg !319
  %call16 = tail call ptr @memchr(ptr noundef %str, i32 noundef 45, i64 noundef %sub.ptr.sub) #18, !dbg !322
  %cmp17.not = icmp eq ptr %call16, null, !dbg !323
  br i1 %cmp17.not, label %if.end21, label %cleanup, !dbg !324

if.end21:                                         ; preds = %if.then15, %if.then12
  %conv22 = trunc i64 %call1 to i32, !dbg !325
  store i32 %conv22, ptr %out, align 4, !dbg !326, !tbaa !166
  br label %cleanup, !dbg !327

cleanup:                                          ; preds = %if.end, %if.then15, %entry, %lor.lhs.false, %if.end21
  %retval.0 = phi i1 [ true, %if.end21 ], [ false, %lor.lhs.false ], [ false, %entry ], [ false, %if.then15 ], [ false, %if.end ], !dbg !297
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %endptr) #17, !dbg !328
  ret i1 %retval.0, !dbg !328
}

; Function Attrs: mustprogress nofree nounwind willreturn
declare !dbg !329 i64 @strtoul(ptr noundef readonly, ptr nocapture noundef, i32 noundef) local_unnamed_addr #7

; Function Attrs: mustprogress nofree nounwind sanitize_thread willreturn uwtable
define dso_local noundef zeroext i1 @safe_strtol(ptr noundef %str, ptr nocapture noundef writeonly %out) local_unnamed_addr #6 !dbg !332 {
entry:
  %endptr = alloca ptr, align 8, !DIAssignID !343
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !341, metadata !DIExpression(), metadata !343, metadata ptr %endptr, metadata !DIExpression()), !dbg !344
  tail call void @llvm.dbg.value(metadata ptr %str, metadata !339, metadata !DIExpression()), !dbg !344
  tail call void @llvm.dbg.value(metadata ptr %out, metadata !340, metadata !DIExpression()), !dbg !344
  %call = tail call ptr @__errno_location() #16, !dbg !345
  store i32 0, ptr %call, align 4, !dbg !346, !tbaa !166
  store i32 0, ptr %out, align 4, !dbg !347, !tbaa !166
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %endptr) #17, !dbg !348
  %call1 = call i64 @strtol(ptr noundef %str, ptr noundef nonnull %endptr, i32 noundef 10) #17, !dbg !349
  tail call void @llvm.dbg.value(metadata i64 %call1, metadata !342, metadata !DIExpression()), !dbg !344
  %0 = load i32, ptr %call, align 4, !dbg !350, !tbaa !166
  %cmp = icmp eq i32 %0, 34, !dbg !352
  br i1 %cmp, label %cleanup, label %lor.lhs.false, !dbg !353

lor.lhs.false:                                    ; preds = %entry
  %1 = load ptr, ptr %endptr, align 8, !dbg !354, !tbaa !68
  %cmp3 = icmp eq ptr %1, %str, !dbg !355
  br i1 %cmp3, label %cleanup, label %if.end, !dbg !356

if.end:                                           ; preds = %lor.lhs.false
  %call4 = tail call ptr @__ctype_b_loc() #16, !dbg !357
  %2 = load ptr, ptr %call4, align 8, !dbg !357, !tbaa !68
  %3 = load i8, ptr %1, align 1, !dbg !357, !tbaa !133
  %idxprom = zext i8 %3 to i64
  %arrayidx = getelementptr inbounds i16, ptr %2, i64 %idxprom, !dbg !357
  %4 = load i16, ptr %arrayidx, align 2, !dbg !357, !tbaa !72
  %5 = and i16 %4, 8192, !dbg !357
  %tobool.not = icmp eq i16 %5, 0, !dbg !357
  %cmp8 = icmp ne i8 %3, 0
  %or.cond = and i1 %cmp8, %tobool.not, !dbg !359
  br i1 %or.cond, label %cleanup, label %if.then12, !dbg !359

if.then12:                                        ; preds = %if.end
  %conv13 = trunc i64 %call1 to i32, !dbg !360
  store i32 %conv13, ptr %out, align 4, !dbg !362, !tbaa !166
  br label %cleanup, !dbg !363

cleanup:                                          ; preds = %if.end, %entry, %lor.lhs.false, %if.then12
  %retval.0 = phi i1 [ true, %if.then12 ], [ false, %lor.lhs.false ], [ false, %entry ], [ false, %if.end ], !dbg !344
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %endptr) #17, !dbg !364
  ret i1 %retval.0, !dbg !364
}

; Function Attrs: mustprogress nofree nounwind willreturn
declare !dbg !365 i64 @strtol(ptr noundef readonly, ptr nocapture noundef, i32 noundef) local_unnamed_addr #7

; Function Attrs: mustprogress nofree nounwind sanitize_thread willreturn uwtable
define dso_local noundef zeroext i1 @safe_strtod(ptr noundef %str, ptr nocapture noundef writeonly %out) local_unnamed_addr #6 !dbg !368 {
entry:
  %endptr = alloca ptr, align 8, !DIAssignID !378
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !376, metadata !DIExpression(), metadata !378, metadata ptr %endptr, metadata !DIExpression()), !dbg !379
  tail call void @llvm.dbg.value(metadata ptr %str, metadata !374, metadata !DIExpression()), !dbg !379
  tail call void @llvm.dbg.value(metadata ptr %out, metadata !375, metadata !DIExpression()), !dbg !379
  %call = tail call ptr @__errno_location() #16, !dbg !380
  store i32 0, ptr %call, align 4, !dbg !381, !tbaa !166
  store double 0.000000e+00, ptr %out, align 8, !dbg !382, !tbaa !383
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %endptr) #17, !dbg !385
  %call1 = call double @strtod(ptr noundef %str, ptr noundef nonnull %endptr) #17, !dbg !386
  tail call void @llvm.dbg.value(metadata double %call1, metadata !377, metadata !DIExpression()), !dbg !379
  %0 = load i32, ptr %call, align 4, !dbg !387, !tbaa !166
  %cmp = icmp eq i32 %0, 34, !dbg !389
  br i1 %cmp, label %cleanup, label %lor.lhs.false, !dbg !390

lor.lhs.false:                                    ; preds = %entry
  %1 = load ptr, ptr %endptr, align 8, !dbg !391, !tbaa !68
  %cmp3 = icmp eq ptr %1, %str, !dbg !392
  br i1 %cmp3, label %cleanup, label %if.end, !dbg !393

if.end:                                           ; preds = %lor.lhs.false
  %call4 = tail call ptr @__ctype_b_loc() #16, !dbg !394
  %2 = load ptr, ptr %call4, align 8, !dbg !394, !tbaa !68
  %3 = load i8, ptr %1, align 1, !dbg !394, !tbaa !133
  %idxprom = zext i8 %3 to i64
  %arrayidx = getelementptr inbounds i16, ptr %2, i64 %idxprom, !dbg !394
  %4 = load i16, ptr %arrayidx, align 2, !dbg !394, !tbaa !72
  %5 = and i16 %4, 8192, !dbg !394
  %tobool.not = icmp eq i16 %5, 0, !dbg !394
  %cmp8 = icmp ne i8 %3, 0
  %or.cond = and i1 %cmp8, %tobool.not, !dbg !396
  br i1 %or.cond, label %cleanup, label %if.then12, !dbg !396

if.then12:                                        ; preds = %if.end
  store double %call1, ptr %out, align 8, !dbg !397, !tbaa !383
  br label %cleanup, !dbg !399

cleanup:                                          ; preds = %if.end, %entry, %lor.lhs.false, %if.then12
  %retval.0 = phi i1 [ true, %if.then12 ], [ false, %lor.lhs.false ], [ false, %entry ], [ false, %if.end ], !dbg !379
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %endptr) #17, !dbg !400
  ret i1 %retval.0, !dbg !400
}

; Function Attrs: mustprogress nofree nounwind willreturn
declare !dbg !401 double @strtod(ptr noundef readonly, ptr nocapture noundef) local_unnamed_addr #7

; Function Attrs: nofree norecurse nosync nounwind sanitize_thread memory(argmem: readwrite) uwtable
define dso_local zeroext i1 @safe_strcpy(ptr nocapture noundef writeonly %dst, ptr nocapture noundef readonly %src, i64 noundef %dstmax) local_unnamed_addr #9 !dbg !404 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %dst, metadata !408, metadata !DIExpression()), !dbg !412
  tail call void @llvm.dbg.value(metadata ptr %src, metadata !409, metadata !DIExpression()), !dbg !412
  tail call void @llvm.dbg.value(metadata i64 %dstmax, metadata !410, metadata !DIExpression()), !dbg !412
  tail call void @llvm.dbg.value(metadata i64 0, metadata !411, metadata !DIExpression()), !dbg !412
  %sub = add i64 %dstmax, -1
  tail call void @llvm.dbg.value(metadata i64 0, metadata !411, metadata !DIExpression()), !dbg !412
  %cmp19.not = icmp eq i64 %sub, 0, !dbg !413
  br i1 %cmp19.not, label %for.end, label %land.rhs, !dbg !416

land.rhs:                                         ; preds = %entry, %for.body
  %x.020 = phi i64 [ %inc, %for.body ], [ 0, %entry ]
  tail call void @llvm.dbg.value(metadata i64 %x.020, metadata !411, metadata !DIExpression()), !dbg !412
  %arrayidx = getelementptr inbounds i8, ptr %src, i64 %x.020, !dbg !417
  %0 = load i8, ptr %arrayidx, align 1, !dbg !417, !tbaa !133
  %cmp1.not = icmp eq i8 %0, 0, !dbg !418
  br i1 %cmp1.not, label %for.end, label %for.body, !dbg !419

for.body:                                         ; preds = %land.rhs
  %arrayidx4 = getelementptr inbounds i8, ptr %dst, i64 %x.020, !dbg !420
  store i8 %0, ptr %arrayidx4, align 1, !dbg !422, !tbaa !133
  %inc = add nuw i64 %x.020, 1, !dbg !423
  tail call void @llvm.dbg.value(metadata i64 %inc, metadata !411, metadata !DIExpression()), !dbg !412
  %exitcond.not = icmp eq i64 %inc, %sub, !dbg !413
  br i1 %exitcond.not, label %for.end, label %land.rhs, !dbg !416, !llvm.loop !424

for.end:                                          ; preds = %land.rhs, %for.body, %entry
  %x.0.lcssa = phi i64 [ 0, %entry ], [ %sub, %for.body ], [ %x.020, %land.rhs ], !dbg !426
  %arrayidx5 = getelementptr inbounds i8, ptr %dst, i64 %x.0.lcssa, !dbg !427
  store i8 0, ptr %arrayidx5, align 1, !dbg !428, !tbaa !133
  %arrayidx6 = getelementptr inbounds i8, ptr %src, i64 %x.0.lcssa, !dbg !429
  %1 = load i8, ptr %arrayidx6, align 1, !dbg !429, !tbaa !133
  %cmp8 = icmp eq i8 %1, 0, !dbg !431
  ret i1 %cmp8, !dbg !432
}

; Function Attrs: nofree norecurse nounwind sanitize_thread memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define dso_local zeroext i1 @safe_memcmp(ptr noundef %a, ptr noundef %b, i64 noundef %len) local_unnamed_addr #10 !dbg !433 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %a, metadata !437, metadata !DIExpression()), !dbg !444
  tail call void @llvm.dbg.value(metadata ptr %b, metadata !438, metadata !DIExpression()), !dbg !444
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !439, metadata !DIExpression()), !dbg !444
  tail call void @llvm.dbg.value(metadata ptr %a, metadata !440, metadata !DIExpression()), !dbg !444
  tail call void @llvm.dbg.value(metadata ptr %b, metadata !441, metadata !DIExpression()), !dbg !444
  tail call void @llvm.dbg.value(metadata i32 0, metadata !442, metadata !DIExpression()), !dbg !444
  tail call void @llvm.dbg.value(metadata i64 0, metadata !443, metadata !DIExpression()), !dbg !444
  %cmp13.not = icmp eq i64 %len, 0, !dbg !445
  br i1 %cmp13.not, label %for.end, label %for.body.preheader, !dbg !448

for.body.preheader:                               ; preds = %entry
  %xtraiter = and i64 %len, 3, !dbg !448
  %0 = icmp ult i64 %len, 4, !dbg !448
  br i1 %0, label %for.end.loopexit.unr-lcssa, label %for.body.preheader.new, !dbg !448

for.body.preheader.new:                           ; preds = %for.body.preheader
  %unroll_iter = and i64 %len, -4, !dbg !448
  br label %for.body, !dbg !448

for.body:                                         ; preds = %for.body, %for.body.preheader.new
  %x.015 = phi i64 [ 0, %for.body.preheader.new ], [ %inc.3, %for.body ]
  %delta.014 = phi i32 [ 0, %for.body.preheader.new ], [ %or.3, %for.body ]
  %niter = phi i64 [ 0, %for.body.preheader.new ], [ %niter.next.3, %for.body ]
  tail call void @llvm.dbg.value(metadata i64 %x.015, metadata !443, metadata !DIExpression()), !dbg !444
  tail call void @llvm.dbg.value(metadata i32 %delta.014, metadata !442, metadata !DIExpression()), !dbg !444
  %arrayidx = getelementptr inbounds i8, ptr %a, i64 %x.015, !dbg !449
  %1 = load volatile i8, ptr %arrayidx, align 1, !dbg !449, !tbaa !133
  %arrayidx1 = getelementptr inbounds i8, ptr %b, i64 %x.015, !dbg !451
  %2 = load volatile i8, ptr %arrayidx1, align 1, !dbg !451, !tbaa !133
  %xor12 = xor i8 %2, %1, !dbg !452
  %xor = zext i8 %xor12 to i32, !dbg !452
  %or = or i32 %delta.014, %xor, !dbg !453
  tail call void @llvm.dbg.value(metadata i32 %or, metadata !442, metadata !DIExpression()), !dbg !444
  %inc = or disjoint i64 %x.015, 1, !dbg !454
  tail call void @llvm.dbg.value(metadata i64 %inc, metadata !443, metadata !DIExpression()), !dbg !444
  tail call void @llvm.dbg.value(metadata i64 %inc, metadata !443, metadata !DIExpression()), !dbg !444
  tail call void @llvm.dbg.value(metadata i32 %or, metadata !442, metadata !DIExpression()), !dbg !444
  %arrayidx.1 = getelementptr inbounds i8, ptr %a, i64 %inc, !dbg !449
  %3 = load volatile i8, ptr %arrayidx.1, align 1, !dbg !449, !tbaa !133
  %arrayidx1.1 = getelementptr inbounds i8, ptr %b, i64 %inc, !dbg !451
  %4 = load volatile i8, ptr %arrayidx1.1, align 1, !dbg !451, !tbaa !133
  %xor12.1 = xor i8 %4, %3, !dbg !452
  %xor.1 = zext i8 %xor12.1 to i32, !dbg !452
  %or.1 = or i32 %or, %xor.1, !dbg !453
  tail call void @llvm.dbg.value(metadata i32 %or.1, metadata !442, metadata !DIExpression()), !dbg !444
  %inc.1 = or disjoint i64 %x.015, 2, !dbg !454
  tail call void @llvm.dbg.value(metadata i64 %inc.1, metadata !443, metadata !DIExpression()), !dbg !444
  tail call void @llvm.dbg.value(metadata i64 %inc.1, metadata !443, metadata !DIExpression()), !dbg !444
  tail call void @llvm.dbg.value(metadata i32 %or.1, metadata !442, metadata !DIExpression()), !dbg !444
  %arrayidx.2 = getelementptr inbounds i8, ptr %a, i64 %inc.1, !dbg !449
  %5 = load volatile i8, ptr %arrayidx.2, align 1, !dbg !449, !tbaa !133
  %arrayidx1.2 = getelementptr inbounds i8, ptr %b, i64 %inc.1, !dbg !451
  %6 = load volatile i8, ptr %arrayidx1.2, align 1, !dbg !451, !tbaa !133
  %xor12.2 = xor i8 %6, %5, !dbg !452
  %xor.2 = zext i8 %xor12.2 to i32, !dbg !452
  %or.2 = or i32 %or.1, %xor.2, !dbg !453
  tail call void @llvm.dbg.value(metadata i32 %or.2, metadata !442, metadata !DIExpression()), !dbg !444
  %inc.2 = or disjoint i64 %x.015, 3, !dbg !454
  tail call void @llvm.dbg.value(metadata i64 %inc.2, metadata !443, metadata !DIExpression()), !dbg !444
  tail call void @llvm.dbg.value(metadata i64 %inc.2, metadata !443, metadata !DIExpression()), !dbg !444
  tail call void @llvm.dbg.value(metadata i32 %or.2, metadata !442, metadata !DIExpression()), !dbg !444
  %arrayidx.3 = getelementptr inbounds i8, ptr %a, i64 %inc.2, !dbg !449
  %7 = load volatile i8, ptr %arrayidx.3, align 1, !dbg !449, !tbaa !133
  %arrayidx1.3 = getelementptr inbounds i8, ptr %b, i64 %inc.2, !dbg !451
  %8 = load volatile i8, ptr %arrayidx1.3, align 1, !dbg !451, !tbaa !133
  %xor12.3 = xor i8 %8, %7, !dbg !452
  %xor.3 = zext i8 %xor12.3 to i32, !dbg !452
  %or.3 = or i32 %or.2, %xor.3, !dbg !453
  tail call void @llvm.dbg.value(metadata i32 %or.3, metadata !442, metadata !DIExpression()), !dbg !444
  %inc.3 = add nuw i64 %x.015, 4, !dbg !454
  tail call void @llvm.dbg.value(metadata i64 %inc.3, metadata !443, metadata !DIExpression()), !dbg !444
  %niter.next.3 = add i64 %niter, 4, !dbg !448
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter, !dbg !448
  br i1 %niter.ncmp.3, label %for.end.loopexit.unr-lcssa, label %for.body, !dbg !448, !llvm.loop !455

for.end.loopexit.unr-lcssa:                       ; preds = %for.body, %for.body.preheader
  %or.lcssa.ph = phi i32 [ undef, %for.body.preheader ], [ %or.3, %for.body ]
  %x.015.unr = phi i64 [ 0, %for.body.preheader ], [ %inc.3, %for.body ]
  %delta.014.unr = phi i32 [ 0, %for.body.preheader ], [ %or.3, %for.body ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0, !dbg !448
  br i1 %lcmp.mod.not, label %for.end.loopexit, label %for.body.epil, !dbg !448

for.body.epil:                                    ; preds = %for.end.loopexit.unr-lcssa, %for.body.epil
  %x.015.epil = phi i64 [ %inc.epil, %for.body.epil ], [ %x.015.unr, %for.end.loopexit.unr-lcssa ]
  %delta.014.epil = phi i32 [ %or.epil, %for.body.epil ], [ %delta.014.unr, %for.end.loopexit.unr-lcssa ]
  %epil.iter = phi i64 [ %epil.iter.next, %for.body.epil ], [ 0, %for.end.loopexit.unr-lcssa ]
  tail call void @llvm.dbg.value(metadata i64 %x.015.epil, metadata !443, metadata !DIExpression()), !dbg !444
  tail call void @llvm.dbg.value(metadata i32 %delta.014.epil, metadata !442, metadata !DIExpression()), !dbg !444
  %arrayidx.epil = getelementptr inbounds i8, ptr %a, i64 %x.015.epil, !dbg !449
  %9 = load volatile i8, ptr %arrayidx.epil, align 1, !dbg !449, !tbaa !133
  %arrayidx1.epil = getelementptr inbounds i8, ptr %b, i64 %x.015.epil, !dbg !451
  %10 = load volatile i8, ptr %arrayidx1.epil, align 1, !dbg !451, !tbaa !133
  %xor12.epil = xor i8 %10, %9, !dbg !452
  %xor.epil = zext i8 %xor12.epil to i32, !dbg !452
  %or.epil = or i32 %delta.014.epil, %xor.epil, !dbg !453
  tail call void @llvm.dbg.value(metadata i32 %or.epil, metadata !442, metadata !DIExpression()), !dbg !444
  %inc.epil = add nuw i64 %x.015.epil, 1, !dbg !454
  tail call void @llvm.dbg.value(metadata i64 %inc.epil, metadata !443, metadata !DIExpression()), !dbg !444
  %epil.iter.next = add i64 %epil.iter, 1, !dbg !448
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter, !dbg !448
  br i1 %epil.iter.cmp.not, label %for.end.loopexit, label %for.body.epil, !dbg !448, !llvm.loop !457

for.end.loopexit:                                 ; preds = %for.body.epil, %for.end.loopexit.unr-lcssa
  %or.lcssa = phi i32 [ %or.lcssa.ph, %for.end.loopexit.unr-lcssa ], [ %or.epil, %for.body.epil ], !dbg !453
  %11 = icmp eq i32 %or.lcssa, 0, !dbg !459
  br label %for.end, !dbg !459

for.end:                                          ; preds = %for.end.loopexit, %entry
  %delta.0.lcssa = phi i1 [ true, %entry ], [ %11, %for.end.loopexit ], !dbg !444
  ret i1 %delta.0.lcssa, !dbg !461
}

; Function Attrs: nofree nounwind sanitize_thread uwtable
define dso_local void @vperror(ptr nocapture noundef readonly %fmt, ...) local_unnamed_addr #0 !dbg !462 {
entry:
  %buf = alloca [1024 x i8], align 16, !DIAssignID !485
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !468, metadata !DIExpression(), metadata !485, metadata ptr %buf, metadata !DIExpression()), !dbg !486
  %ap = alloca [1 x %struct.__va_list_tag], align 16, !DIAssignID !487
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !472, metadata !DIExpression(), metadata !487, metadata ptr %ap, metadata !DIExpression()), !dbg !486
  tail call void @llvm.dbg.value(metadata ptr %fmt, metadata !466, metadata !DIExpression()), !dbg !486
  %call = tail call ptr @__errno_location() #16, !dbg !488
  %0 = load i32, ptr %call, align 4, !dbg !488, !tbaa !166
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !467, metadata !DIExpression()), !dbg !486
  call void @llvm.lifetime.start.p0(i64 1024, ptr nonnull %buf) #17, !dbg !489
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %ap) #17, !dbg !490
  call void @llvm.va_start.p0(ptr nonnull %ap), !dbg !491
  %call3 = call i32 @vsnprintf(ptr noundef nonnull %buf, i64 noundef 1024, ptr noundef %fmt, ptr noundef nonnull %ap) #17, !dbg !492
  %cmp = icmp eq i32 %call3, -1, !dbg !494
  br i1 %cmp, label %if.then, label %if.end, !dbg !495

if.then:                                          ; preds = %entry
  %arrayidx = getelementptr inbounds i8, ptr %buf, i64 1023, !dbg !496
  store i8 0, ptr %arrayidx, align 1, !dbg !498, !tbaa !133, !DIAssignID !499
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !468, metadata !DIExpression(DW_OP_LLVM_fragment, 8184, 8), metadata !499, metadata ptr %arrayidx, metadata !DIExpression()), !dbg !486
  br label %if.end, !dbg !500

if.end:                                           ; preds = %if.then, %entry
  call void @llvm.va_end.p0(ptr nonnull %ap), !dbg !501
  store i32 %0, ptr %call, align 4, !dbg !502, !tbaa !166
  call void @perror(ptr noundef nonnull %buf) #19, !dbg !503
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %ap) #17, !dbg !504
  call void @llvm.lifetime.end.p0(i64 1024, ptr nonnull %buf) #17, !dbg !504
  ret void, !dbg !504
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.va_start.p0(ptr) #11

; Function Attrs: nofree nounwind
declare !dbg !505 noundef i32 @vsnprintf(ptr nocapture noundef, i64 noundef, ptr nocapture noundef readonly, ptr noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.va_end.p0(ptr) #11

; Function Attrs: cold nofree nounwind
declare !dbg !509 void @perror(ptr nocapture noundef readonly) local_unnamed_addr #12

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(none) uwtable
define dso_local noundef i64 @ntohll(i64 noundef %val) local_unnamed_addr #13 !dbg !512 {
entry:
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !516, metadata !DIExpression()), !dbg !517
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 0, metadata !521, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 0, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 0, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 0, metadata !521, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !521, metadata !DIExpression(DW_OP_constu, 255, DW_OP_and, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 16, DW_OP_shr, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 1, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 1, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !521, metadata !DIExpression(DW_OP_constu, 255, DW_OP_and, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 16, DW_OP_shr, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i16 poison, metadata !521, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 16, DW_OP_shr, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 2, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 2, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i16 poison, metadata !521, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 16, DW_OP_shr, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata !DIArgList(i16 poison, i64 poison), metadata !521, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 8, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_constu, 16, DW_OP_shr, DW_OP_constu, 255, DW_OP_and, DW_OP_or, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 3, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 3, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata !DIArgList(i16 poison, i64 poison), metadata !521, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 8, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_constu, 16, DW_OP_shr, DW_OP_constu, 255, DW_OP_and, DW_OP_or, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !521, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 4, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 4, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !521, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i64 poison), metadata !521, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 8, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_constu, 32, DW_OP_shr, DW_OP_constu, 255, DW_OP_and, DW_OP_or, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 48, DW_OP_shr, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 5, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 5, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i64 poison), metadata !521, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 8, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_constu, 32, DW_OP_shr, DW_OP_constu, 255, DW_OP_and, DW_OP_or, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 48, DW_OP_shr, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i48 poison, metadata !521, metadata !DIExpression(DW_OP_LLVM_convert, 48, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 48, DW_OP_shr, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 6, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 6, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i48 poison, metadata !521, metadata !DIExpression(DW_OP_LLVM_convert, 48, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 48, DW_OP_shr, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata !DIArgList(i48 poison, i64 poison), metadata !521, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 48, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 8, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_constu, 48, DW_OP_shr, DW_OP_constu, 255, DW_OP_and, DW_OP_or, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 56, DW_OP_shr, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 7, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 7, metadata !522, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata !DIArgList(i48 poison, i64 poison), metadata !521, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 48, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 8, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_constu, 48, DW_OP_shr, DW_OP_constu, 255, DW_OP_and, DW_OP_or, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 56, DW_OP_shr, DW_OP_stack_value)), !dbg !523
  %or.7.i = tail call noundef i64 @llvm.bswap.i64(i64 %val), !dbg !525
  tail call void @llvm.dbg.value(metadata i64 %or.7.i, metadata !521, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 56, DW_OP_shr, DW_OP_constu, 8, DW_OP_shr, DW_OP_stack_value)), !dbg !523
  tail call void @llvm.dbg.value(metadata i32 8, metadata !522, metadata !DIExpression()), !dbg !523
  ret i64 %or.7.i, !dbg !529
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(none) uwtable
define dso_local noundef i64 @htonll(i64 noundef %val) local_unnamed_addr #13 !dbg !530 {
entry:
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !532, metadata !DIExpression()), !dbg !533
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 0, metadata !521, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 0, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 0, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 0, metadata !521, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !521, metadata !DIExpression(DW_OP_constu, 255, DW_OP_and, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 16, DW_OP_shr, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 1, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 1, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !521, metadata !DIExpression(DW_OP_constu, 255, DW_OP_and, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 16, DW_OP_shr, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i16 poison, metadata !521, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 16, DW_OP_shr, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 2, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 2, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i16 poison, metadata !521, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 16, DW_OP_shr, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata !DIArgList(i16 poison, i64 poison), metadata !521, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 8, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_constu, 16, DW_OP_shr, DW_OP_constu, 255, DW_OP_and, DW_OP_or, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 3, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 3, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata !DIArgList(i16 poison, i64 poison), metadata !521, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 8, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_constu, 16, DW_OP_shr, DW_OP_constu, 255, DW_OP_and, DW_OP_or, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !521, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 4, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 4, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !521, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i64 poison), metadata !521, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 8, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_constu, 32, DW_OP_shr, DW_OP_constu, 255, DW_OP_and, DW_OP_or, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 48, DW_OP_shr, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 5, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 5, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i64 poison), metadata !521, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 8, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_constu, 32, DW_OP_shr, DW_OP_constu, 255, DW_OP_and, DW_OP_or, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 48, DW_OP_shr, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i48 poison, metadata !521, metadata !DIExpression(DW_OP_LLVM_convert, 48, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 48, DW_OP_shr, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 6, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 6, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i48 poison, metadata !521, metadata !DIExpression(DW_OP_LLVM_convert, 48, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 48, DW_OP_shr, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata !DIArgList(i48 poison, i64 poison), metadata !521, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 48, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 8, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_constu, 48, DW_OP_shr, DW_OP_constu, 255, DW_OP_and, DW_OP_or, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 56, DW_OP_shr, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 7, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 7, metadata !522, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata !DIArgList(i48 poison, i64 poison), metadata !521, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 48, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 8, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_constu, 48, DW_OP_shr, DW_OP_constu, 255, DW_OP_and, DW_OP_or, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 56, DW_OP_shr, DW_OP_stack_value)), !dbg !534
  %or.7.i = tail call noundef i64 @llvm.bswap.i64(i64 %val), !dbg !536
  tail call void @llvm.dbg.value(metadata i64 %or.7.i, metadata !521, metadata !DIExpression()), !dbg !534
  tail call void @llvm.dbg.value(metadata i64 %val, metadata !518, metadata !DIExpression(DW_OP_constu, 56, DW_OP_shr, DW_OP_constu, 8, DW_OP_shr, DW_OP_stack_value)), !dbg !534
  tail call void @llvm.dbg.value(metadata i32 8, metadata !522, metadata !DIExpression()), !dbg !534
  ret i64 %or.7.i, !dbg !537
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #14

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #15 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #14

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #14

attributes #0 = { nofree nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nofree nosync nounwind willreturn memory(none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree norecurse nosync nounwind sanitize_thread memory(readwrite, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { mustprogress nofree nounwind sanitize_thread willreturn uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { mustprogress nofree nounwind willreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { mustprogress nofree nounwind willreturn memory(argmem: read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { nofree norecurse nosync nounwind sanitize_thread memory(argmem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { nofree norecurse nounwind sanitize_thread memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { mustprogress nocallback nofree nosync nounwind willreturn }
attributes #12 = { cold nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #15 = { nounwind uwtable }
attributes #16 = { nounwind willreturn memory(none) }
attributes #17 = { nounwind }
attributes #18 = { nobuiltin nounwind willreturn memory(read) }
attributes #19 = { cold }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!47, !48, !49, !50, !51, !52, !53}
!llvm.ident = !{!54}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "uriencode_str", scope: !2, file: !3, line: 12, type: !44, isLocal: true, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !21, globals: !31, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "util.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "6738d68be78105c572550083306914d9")
!4 = !{!5}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !6, line: 46, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "/usr/include/ctype.h", directory: "", checksumkind: CSK_MD5, checksum: "43fd45dcf96e8fb7d8f14700096497c7")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12, !13, !14, !15, !16, !17, !18, !19, !20}
!9 = !DIEnumerator(name: "_ISupper", value: 256)
!10 = !DIEnumerator(name: "_ISlower", value: 512)
!11 = !DIEnumerator(name: "_ISalpha", value: 1024)
!12 = !DIEnumerator(name: "_ISdigit", value: 2048)
!13 = !DIEnumerator(name: "_ISxdigit", value: 4096)
!14 = !DIEnumerator(name: "_ISspace", value: 8192)
!15 = !DIEnumerator(name: "_ISprint", value: 16384)
!16 = !DIEnumerator(name: "_ISgraph", value: 32768)
!17 = !DIEnumerator(name: "_ISblank", value: 1)
!18 = !DIEnumerator(name: "_IScntrl", value: 2)
!19 = !DIEnumerator(name: "_ISpunct", value: 4)
!20 = !DIEnumerator(name: "_ISalnum", value: 8)
!21 = !{!22, !23, !24, !25, !26, !27, !28}
!22 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!23 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!24 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!25 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!26 = !DIBasicType(name: "long long", size: 64, encoding: DW_ATE_signed)
!27 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!28 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !29, size: 64)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !30)
!30 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !24)
!31 = !{!32, !38, !0}
!32 = !DIGlobalVariableExpression(var: !33, expr: !DIExpression())
!33 = distinct !DIGlobalVariable(scope: null, file: !3, line: 21, type: !34, isLocal: true, isDefinition: true)
!34 = !DICompositeType(tag: DW_TAG_array_type, baseType: !35, size: 72, elements: !36)
!35 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!36 = !{!37}
!37 = !DISubrange(count: 9)
!38 = !DIGlobalVariableExpression(var: !39, expr: !DIExpression())
!39 = distinct !DIGlobalVariable(name: "uriencode_map", scope: !2, file: !3, line: 11, type: !40, isLocal: true, isDefinition: true)
!40 = !DICompositeType(tag: DW_TAG_array_type, baseType: !41, size: 16384, elements: !42)
!41 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !35, size: 64)
!42 = !{!43}
!43 = !DISubrange(count: 256)
!44 = !DICompositeType(tag: DW_TAG_array_type, baseType: !35, size: 6144, elements: !45)
!45 = !{!46}
!46 = !DISubrange(count: 768)
!47 = !{i32 7, !"Dwarf Version", i32 5}
!48 = !{i32 2, !"Debug Info Version", i32 3}
!49 = !{i32 1, !"wchar_size", i32 4}
!50 = !{i32 8, !"PIC Level", i32 2}
!51 = !{i32 7, !"PIE Level", i32 2}
!52 = !{i32 7, !"uwtable", i32 2}
!53 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!54 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!55 = distinct !DISubprogram(name: "uriencode_init", scope: !3, file: !3, line: 14, type: !56, scopeLine: 14, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !58)
!56 = !DISubroutineType(types: !57)
!57 = !{null}
!58 = !{!59, !60}
!59 = !DILocalVariable(name: "x", scope: !55, file: !3, line: 15, type: !22)
!60 = !DILocalVariable(name: "str", scope: !55, file: !3, line: 16, type: !41)
!61 = !DILocation(line: 0, scope: !55)
!62 = !DILocation(line: 17, column: 5, scope: !63)
!63 = distinct !DILexicalBlock(scope: !55, file: !3, line: 17, column: 5)
!64 = !DILocation(line: 18, column: 13, scope: !65)
!65 = distinct !DILexicalBlock(scope: !66, file: !3, line: 18, column: 13)
!66 = distinct !DILexicalBlock(scope: !67, file: !3, line: 17, column: 31)
!67 = distinct !DILexicalBlock(scope: !63, file: !3, line: 17, column: 5)
!68 = !{!69, !69, i64 0}
!69 = !{!"any pointer", !70, i64 0}
!70 = !{!"omnipotent char", !71, i64 0}
!71 = !{!"Simple C/C++ TBAA"}
!72 = !{!73, !73, i64 0}
!73 = !{!"short", !70, i64 0}
!74 = !DILocation(line: 18, column: 24, scope: !65)
!75 = !DILocation(line: 19, column: 13, scope: !76)
!76 = distinct !DILexicalBlock(scope: !65, file: !3, line: 18, column: 73)
!77 = !DILocation(line: 19, column: 30, scope: !76)
!78 = !DILocation(line: 20, column: 9, scope: !76)
!79 = !DILocation(line: 21, column: 13, scope: !80)
!80 = distinct !DILexicalBlock(scope: !65, file: !3, line: 20, column: 16)
!81 = !DILocation(line: 22, column: 13, scope: !80)
!82 = !DILocation(line: 22, column: 30, scope: !80)
!83 = !DILocation(line: 23, column: 17, scope: !80)
!84 = !DILocation(line: 17, column: 27, scope: !67)
!85 = !DILocation(line: 17, column: 19, scope: !67)
!86 = distinct !{!86, !62, !87, !88}
!87 = !DILocation(line: 25, column: 5, scope: !63)
!88 = !{!"llvm.loop.mustprogress"}
!89 = !DILocation(line: 26, column: 1, scope: !55)
!90 = !DISubprogram(name: "__ctype_b_loc", scope: !6, file: !6, line: 79, type: !91, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!91 = !DISubroutineType(types: !92)
!92 = !{!93}
!93 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !94, size: 64)
!94 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !95, size: 64)
!95 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !23)
!96 = !DISubprogram(name: "snprintf", scope: !97, file: !97, line: 385, type: !98, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!97 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "1e435c46987a169d9f9186f63a512303")
!98 = !DISubroutineType(types: !99)
!99 = !{!22, !100, !101, !104, null}
!100 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !41)
!101 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !102, line: 18, baseType: !103)
!102 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!103 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!104 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !105)
!105 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !106, size: 64)
!106 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !35)
!107 = distinct !DISubprogram(name: "uriencode", scope: !3, file: !3, line: 28, type: !108, scopeLine: 28, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !112)
!108 = !DISubroutineType(types: !109)
!109 = !{!110, !105, !41, !111, !111}
!110 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!111 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !101)
!112 = !{!113, !114, !115, !116, !117, !118}
!113 = !DILocalVariable(name: "src", arg: 1, scope: !107, file: !3, line: 28, type: !105)
!114 = !DILocalVariable(name: "dst", arg: 2, scope: !107, file: !3, line: 28, type: !41)
!115 = !DILocalVariable(name: "srclen", arg: 3, scope: !107, file: !3, line: 28, type: !111)
!116 = !DILocalVariable(name: "dstlen", arg: 4, scope: !107, file: !3, line: 28, type: !111)
!117 = !DILocalVariable(name: "x", scope: !107, file: !3, line: 29, type: !22)
!118 = !DILocalVariable(name: "d", scope: !107, file: !3, line: 30, type: !101)
!119 = !DILocation(line: 0, scope: !107)
!120 = !DILocation(line: 31, column: 19, scope: !121)
!121 = distinct !DILexicalBlock(scope: !122, file: !3, line: 31, column: 5)
!122 = distinct !DILexicalBlock(scope: !107, file: !3, line: 31, column: 5)
!123 = !DILocation(line: 31, column: 5, scope: !122)
!124 = !DILocation(line: 32, column: 19, scope: !125)
!125 = distinct !DILexicalBlock(scope: !126, file: !3, line: 32, column: 13)
!126 = distinct !DILexicalBlock(scope: !121, file: !3, line: 31, column: 34)
!127 = !DILocation(line: 32, column: 13, scope: !126)
!128 = !DILocation(line: 32, column: 15, scope: !125)
!129 = distinct !{!129, !123, !130, !88}
!130 = !DILocation(line: 41, column: 5, scope: !122)
!131 = !DILocation(line: 34, column: 43, scope: !132)
!132 = distinct !DILexicalBlock(scope: !126, file: !3, line: 34, column: 13)
!133 = !{!70, !70, i64 0}
!134 = !DILocation(line: 34, column: 13, scope: !132)
!135 = !DILocation(line: 34, column: 51, scope: !132)
!136 = !DILocation(line: 0, scope: !132)
!137 = !DILocation(line: 34, column: 13, scope: !126)
!138 = !DILocation(line: 35, column: 13, scope: !139)
!139 = distinct !DILexicalBlock(scope: !132, file: !3, line: 34, column: 60)
!140 = !DILocation(line: 37, column: 9, scope: !139)
!141 = !DILocation(line: 38, column: 20, scope: !142)
!142 = distinct !DILexicalBlock(scope: !132, file: !3, line: 37, column: 16)
!143 = !DILocation(line: 31, column: 30, scope: !121)
!144 = !DILocation(line: 42, column: 5, scope: !107)
!145 = !DILocation(line: 42, column: 12, scope: !107)
!146 = !DILocation(line: 43, column: 5, scope: !107)
!147 = !DILocation(line: 44, column: 1, scope: !107)
!148 = distinct !DISubprogram(name: "safe_strtoull", scope: !3, file: !3, line: 49, type: !149, scopeLine: 49, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !156)
!149 = !DISubroutineType(types: !150)
!150 = !{!110, !105, !151}
!151 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !152, size: 64)
!152 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !153, line: 27, baseType: !154)
!153 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!154 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !155, line: 45, baseType: !103)
!155 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!156 = !{!157, !158, !159, !160}
!157 = !DILocalVariable(name: "str", arg: 1, scope: !148, file: !3, line: 49, type: !105)
!158 = !DILocalVariable(name: "out", arg: 2, scope: !148, file: !3, line: 49, type: !151)
!159 = !DILocalVariable(name: "endptr", scope: !148, file: !3, line: 53, type: !41)
!160 = !DILocalVariable(name: "ull", scope: !148, file: !3, line: 54, type: !161)
!161 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!162 = distinct !DIAssignID()
!163 = !DILocation(line: 0, scope: !148)
!164 = !DILocation(line: 51, column: 5, scope: !148)
!165 = !DILocation(line: 51, column: 11, scope: !148)
!166 = !{!167, !167, i64 0}
!167 = !{!"int", !70, i64 0}
!168 = !DILocation(line: 52, column: 10, scope: !148)
!169 = !{!170, !170, i64 0}
!170 = !{!"long", !70, i64 0}
!171 = !DILocation(line: 53, column: 5, scope: !148)
!172 = !DILocation(line: 54, column: 30, scope: !148)
!173 = !DILocation(line: 55, column: 10, scope: !174)
!174 = distinct !DILexicalBlock(scope: !148, file: !3, line: 55, column: 9)
!175 = !DILocation(line: 55, column: 16, scope: !174)
!176 = !DILocation(line: 55, column: 27, scope: !174)
!177 = !DILocation(line: 55, column: 38, scope: !174)
!178 = !DILocation(line: 55, column: 35, scope: !174)
!179 = !DILocation(line: 55, column: 9, scope: !148)
!180 = !DILocation(line: 59, column: 9, scope: !181)
!181 = distinct !DILexicalBlock(scope: !148, file: !3, line: 59, column: 9)
!182 = !DILocation(line: 59, column: 27, scope: !181)
!183 = !DILocation(line: 60, column: 29, scope: !184)
!184 = distinct !DILexicalBlock(scope: !185, file: !3, line: 60, column: 13)
!185 = distinct !DILexicalBlock(scope: !181, file: !3, line: 59, column: 66)
!186 = !DILocation(line: 60, column: 13, scope: !185)
!187 = !DILocation(line: 64, column: 41, scope: !188)
!188 = distinct !DILexicalBlock(scope: !189, file: !3, line: 64, column: 17)
!189 = distinct !DILexicalBlock(scope: !184, file: !3, line: 60, column: 34)
!190 = !DILocation(line: 64, column: 17, scope: !188)
!191 = !DILocation(line: 64, column: 48, scope: !188)
!192 = !DILocation(line: 64, column: 17, scope: !189)
!193 = !DILocation(line: 68, column: 14, scope: !185)
!194 = !DILocation(line: 69, column: 9, scope: !185)
!195 = !DILocation(line: 72, column: 1, scope: !148)
!196 = !DISubprogram(name: "__errno_location", scope: !197, file: !197, line: 37, type: !198, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!197 = !DIFile(filename: "/usr/include/errno.h", directory: "", checksumkind: CSK_MD5, checksum: "047d5cf117ed2ec1460c1b2e072a4e50")
!198 = !DISubroutineType(types: !199)
!199 = !{!200}
!200 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !22, size: 64)
!201 = !DISubprogram(name: "strtoull", scope: !202, file: !202, line: 206, type: !203, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!202 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!203 = !DISubroutineType(types: !204)
!204 = !{!161, !104, !205, !22}
!205 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !206)
!206 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !41, size: 64)
!207 = !DISubprogram(name: "memchr", scope: !208, file: !208, line: 107, type: !209, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!208 = !DIFile(filename: "/usr/include/string.h", directory: "", checksumkind: CSK_MD5, checksum: "165db1185644f68894fa9e0d17055d70")
!209 = !DISubroutineType(types: !210)
!210 = !{!25, !211, !22, !101}
!211 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !212, size: 64)
!212 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!213 = distinct !DISubprogram(name: "safe_strtoull_hex", scope: !3, file: !3, line: 79, type: !149, scopeLine: 79, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !214)
!214 = !{!215, !216, !217, !218}
!215 = !DILocalVariable(name: "str", arg: 1, scope: !213, file: !3, line: 79, type: !105)
!216 = !DILocalVariable(name: "out", arg: 2, scope: !213, file: !3, line: 79, type: !151)
!217 = !DILocalVariable(name: "endptr", scope: !213, file: !3, line: 83, type: !41)
!218 = !DILocalVariable(name: "ull", scope: !213, file: !3, line: 84, type: !161)
!219 = distinct !DIAssignID()
!220 = !DILocation(line: 0, scope: !213)
!221 = !DILocation(line: 81, column: 5, scope: !213)
!222 = !DILocation(line: 81, column: 11, scope: !213)
!223 = !DILocation(line: 82, column: 10, scope: !213)
!224 = !DILocation(line: 83, column: 5, scope: !213)
!225 = !DILocation(line: 84, column: 30, scope: !213)
!226 = !DILocation(line: 85, column: 10, scope: !227)
!227 = distinct !DILexicalBlock(scope: !213, file: !3, line: 85, column: 9)
!228 = !DILocation(line: 85, column: 16, scope: !227)
!229 = !DILocation(line: 85, column: 27, scope: !227)
!230 = !DILocation(line: 85, column: 38, scope: !227)
!231 = !DILocation(line: 85, column: 35, scope: !227)
!232 = !DILocation(line: 85, column: 9, scope: !213)
!233 = !DILocation(line: 89, column: 9, scope: !234)
!234 = distinct !DILexicalBlock(scope: !213, file: !3, line: 89, column: 9)
!235 = !DILocation(line: 89, column: 27, scope: !234)
!236 = !DILocation(line: 90, column: 29, scope: !237)
!237 = distinct !DILexicalBlock(scope: !238, file: !3, line: 90, column: 13)
!238 = distinct !DILexicalBlock(scope: !234, file: !3, line: 89, column: 66)
!239 = !DILocation(line: 90, column: 13, scope: !238)
!240 = !DILocation(line: 94, column: 41, scope: !241)
!241 = distinct !DILexicalBlock(scope: !242, file: !3, line: 94, column: 17)
!242 = distinct !DILexicalBlock(scope: !237, file: !3, line: 90, column: 34)
!243 = !DILocation(line: 94, column: 17, scope: !241)
!244 = !DILocation(line: 94, column: 48, scope: !241)
!245 = !DILocation(line: 94, column: 17, scope: !242)
!246 = !DILocation(line: 98, column: 14, scope: !238)
!247 = !DILocation(line: 99, column: 9, scope: !238)
!248 = !DILocation(line: 102, column: 1, scope: !213)
!249 = distinct !DISubprogram(name: "safe_strtoll", scope: !3, file: !3, line: 104, type: !250, scopeLine: 104, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !256)
!250 = !DISubroutineType(types: !251)
!251 = !{!110, !105, !252}
!252 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !253, size: 64)
!253 = !DIDerivedType(tag: DW_TAG_typedef, name: "int64_t", file: !254, line: 27, baseType: !255)
!254 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h", directory: "", checksumkind: CSK_MD5, checksum: "649b383a60bfa3eb90e85840b2b0be20")
!255 = !DIDerivedType(tag: DW_TAG_typedef, name: "__int64_t", file: !155, line: 44, baseType: !27)
!256 = !{!257, !258, !259, !260}
!257 = !DILocalVariable(name: "str", arg: 1, scope: !249, file: !3, line: 104, type: !105)
!258 = !DILocalVariable(name: "out", arg: 2, scope: !249, file: !3, line: 104, type: !252)
!259 = !DILocalVariable(name: "endptr", scope: !249, file: !3, line: 108, type: !41)
!260 = !DILocalVariable(name: "ll", scope: !249, file: !3, line: 109, type: !26)
!261 = distinct !DIAssignID()
!262 = !DILocation(line: 0, scope: !249)
!263 = !DILocation(line: 106, column: 5, scope: !249)
!264 = !DILocation(line: 106, column: 11, scope: !249)
!265 = !DILocation(line: 107, column: 10, scope: !249)
!266 = !DILocation(line: 108, column: 5, scope: !249)
!267 = !DILocation(line: 109, column: 20, scope: !249)
!268 = !DILocation(line: 110, column: 10, scope: !269)
!269 = distinct !DILexicalBlock(scope: !249, file: !3, line: 110, column: 9)
!270 = !DILocation(line: 110, column: 16, scope: !269)
!271 = !DILocation(line: 110, column: 27, scope: !269)
!272 = !DILocation(line: 110, column: 38, scope: !269)
!273 = !DILocation(line: 110, column: 35, scope: !269)
!274 = !DILocation(line: 110, column: 9, scope: !249)
!275 = !DILocation(line: 114, column: 9, scope: !276)
!276 = distinct !DILexicalBlock(scope: !249, file: !3, line: 114, column: 9)
!277 = !DILocation(line: 114, column: 27, scope: !276)
!278 = !DILocation(line: 115, column: 14, scope: !279)
!279 = distinct !DILexicalBlock(scope: !276, file: !3, line: 114, column: 66)
!280 = !DILocation(line: 116, column: 9, scope: !279)
!281 = !DILocation(line: 119, column: 1, scope: !249)
!282 = !DISubprogram(name: "strtoll", scope: !202, file: !202, line: 201, type: !283, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!283 = !DISubroutineType(types: !284)
!284 = !{!26, !104, !205, !22}
!285 = distinct !DISubprogram(name: "safe_strtoul", scope: !3, file: !3, line: 121, type: !286, scopeLine: 121, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !291)
!286 = !DISubroutineType(types: !287)
!287 = !{!110, !105, !288}
!288 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !289, size: 64)
!289 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !153, line: 26, baseType: !290)
!290 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !155, line: 42, baseType: !7)
!291 = !{!292, !293, !294, !295}
!292 = !DILocalVariable(name: "str", arg: 1, scope: !285, file: !3, line: 121, type: !105)
!293 = !DILocalVariable(name: "out", arg: 2, scope: !285, file: !3, line: 121, type: !288)
!294 = !DILocalVariable(name: "endptr", scope: !285, file: !3, line: 122, type: !41)
!295 = !DILocalVariable(name: "l", scope: !285, file: !3, line: 123, type: !103)
!296 = distinct !DIAssignID()
!297 = !DILocation(line: 0, scope: !285)
!298 = !DILocation(line: 122, column: 5, scope: !285)
!299 = !DILocation(line: 122, column: 11, scope: !285)
!300 = distinct !DIAssignID()
!301 = !DILocation(line: 126, column: 10, scope: !285)
!302 = !DILocation(line: 127, column: 5, scope: !285)
!303 = !DILocation(line: 127, column: 11, scope: !285)
!304 = !DILocation(line: 129, column: 9, scope: !285)
!305 = !DILocation(line: 130, column: 10, scope: !306)
!306 = distinct !DILexicalBlock(scope: !285, file: !3, line: 130, column: 9)
!307 = !DILocation(line: 130, column: 16, scope: !306)
!308 = !DILocation(line: 130, column: 27, scope: !306)
!309 = !DILocation(line: 130, column: 38, scope: !306)
!310 = !DILocation(line: 130, column: 35, scope: !306)
!311 = !DILocation(line: 130, column: 9, scope: !285)
!312 = !DILocation(line: 134, column: 9, scope: !313)
!313 = distinct !DILexicalBlock(scope: !285, file: !3, line: 134, column: 9)
!314 = !DILocation(line: 134, column: 27, scope: !313)
!315 = !DILocation(line: 135, column: 22, scope: !316)
!316 = distinct !DILexicalBlock(scope: !317, file: !3, line: 135, column: 13)
!317 = distinct !DILexicalBlock(scope: !313, file: !3, line: 134, column: 66)
!318 = !DILocation(line: 135, column: 13, scope: !317)
!319 = !DILocation(line: 139, column: 41, scope: !320)
!320 = distinct !DILexicalBlock(scope: !321, file: !3, line: 139, column: 17)
!321 = distinct !DILexicalBlock(scope: !316, file: !3, line: 135, column: 27)
!322 = !DILocation(line: 139, column: 17, scope: !320)
!323 = !DILocation(line: 139, column: 48, scope: !320)
!324 = !DILocation(line: 139, column: 17, scope: !321)
!325 = !DILocation(line: 143, column: 16, scope: !317)
!326 = !DILocation(line: 143, column: 14, scope: !317)
!327 = !DILocation(line: 144, column: 9, scope: !317)
!328 = !DILocation(line: 148, column: 1, scope: !285)
!329 = !DISubprogram(name: "strtoul", scope: !202, file: !202, line: 181, type: !330, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!330 = !DISubroutineType(types: !331)
!331 = !{!103, !104, !205, !22}
!332 = distinct !DISubprogram(name: "safe_strtol", scope: !3, file: !3, line: 150, type: !333, scopeLine: 150, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !338)
!333 = !DISubroutineType(types: !334)
!334 = !{!110, !105, !335}
!335 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !336, size: 64)
!336 = !DIDerivedType(tag: DW_TAG_typedef, name: "int32_t", file: !254, line: 26, baseType: !337)
!337 = !DIDerivedType(tag: DW_TAG_typedef, name: "__int32_t", file: !155, line: 41, baseType: !22)
!338 = !{!339, !340, !341, !342}
!339 = !DILocalVariable(name: "str", arg: 1, scope: !332, file: !3, line: 150, type: !105)
!340 = !DILocalVariable(name: "out", arg: 2, scope: !332, file: !3, line: 150, type: !335)
!341 = !DILocalVariable(name: "endptr", scope: !332, file: !3, line: 154, type: !41)
!342 = !DILocalVariable(name: "l", scope: !332, file: !3, line: 155, type: !27)
!343 = distinct !DIAssignID()
!344 = !DILocation(line: 0, scope: !332)
!345 = !DILocation(line: 152, column: 5, scope: !332)
!346 = !DILocation(line: 152, column: 11, scope: !332)
!347 = !DILocation(line: 153, column: 10, scope: !332)
!348 = !DILocation(line: 154, column: 5, scope: !332)
!349 = !DILocation(line: 155, column: 14, scope: !332)
!350 = !DILocation(line: 156, column: 10, scope: !351)
!351 = distinct !DILexicalBlock(scope: !332, file: !3, line: 156, column: 9)
!352 = !DILocation(line: 156, column: 16, scope: !351)
!353 = !DILocation(line: 156, column: 27, scope: !351)
!354 = !DILocation(line: 156, column: 38, scope: !351)
!355 = !DILocation(line: 156, column: 35, scope: !351)
!356 = !DILocation(line: 156, column: 9, scope: !332)
!357 = !DILocation(line: 160, column: 9, scope: !358)
!358 = distinct !DILexicalBlock(scope: !332, file: !3, line: 160, column: 9)
!359 = !DILocation(line: 160, column: 27, scope: !358)
!360 = !DILocation(line: 161, column: 16, scope: !361)
!361 = distinct !DILexicalBlock(scope: !358, file: !3, line: 160, column: 66)
!362 = !DILocation(line: 161, column: 14, scope: !361)
!363 = !DILocation(line: 162, column: 9, scope: !361)
!364 = !DILocation(line: 165, column: 1, scope: !332)
!365 = !DISubprogram(name: "strtol", scope: !202, file: !202, line: 177, type: !366, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!366 = !DISubroutineType(types: !367)
!367 = !{!27, !104, !205, !22}
!368 = distinct !DISubprogram(name: "safe_strtod", scope: !3, file: !3, line: 167, type: !369, scopeLine: 167, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !373)
!369 = !DISubroutineType(types: !370)
!370 = !{!110, !105, !371}
!371 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !372, size: 64)
!372 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!373 = !{!374, !375, !376, !377}
!374 = !DILocalVariable(name: "str", arg: 1, scope: !368, file: !3, line: 167, type: !105)
!375 = !DILocalVariable(name: "out", arg: 2, scope: !368, file: !3, line: 167, type: !371)
!376 = !DILocalVariable(name: "endptr", scope: !368, file: !3, line: 171, type: !41)
!377 = !DILocalVariable(name: "d", scope: !368, file: !3, line: 172, type: !372)
!378 = distinct !DIAssignID()
!379 = !DILocation(line: 0, scope: !368)
!380 = !DILocation(line: 169, column: 5, scope: !368)
!381 = !DILocation(line: 169, column: 11, scope: !368)
!382 = !DILocation(line: 170, column: 10, scope: !368)
!383 = !{!384, !384, i64 0}
!384 = !{!"double", !70, i64 0}
!385 = !DILocation(line: 171, column: 5, scope: !368)
!386 = !DILocation(line: 172, column: 16, scope: !368)
!387 = !DILocation(line: 173, column: 10, scope: !388)
!388 = distinct !DILexicalBlock(scope: !368, file: !3, line: 173, column: 9)
!389 = !DILocation(line: 173, column: 16, scope: !388)
!390 = !DILocation(line: 173, column: 27, scope: !388)
!391 = !DILocation(line: 173, column: 38, scope: !388)
!392 = !DILocation(line: 173, column: 35, scope: !388)
!393 = !DILocation(line: 173, column: 9, scope: !368)
!394 = !DILocation(line: 177, column: 9, scope: !395)
!395 = distinct !DILexicalBlock(scope: !368, file: !3, line: 177, column: 9)
!396 = !DILocation(line: 177, column: 27, scope: !395)
!397 = !DILocation(line: 178, column: 14, scope: !398)
!398 = distinct !DILexicalBlock(scope: !395, file: !3, line: 177, column: 66)
!399 = !DILocation(line: 179, column: 9, scope: !398)
!400 = !DILocation(line: 182, column: 1, scope: !368)
!401 = !DISubprogram(name: "strtod", scope: !202, file: !202, line: 118, type: !402, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!402 = !DISubroutineType(types: !403)
!403 = !{!372, !104, !205}
!404 = distinct !DISubprogram(name: "safe_strcpy", scope: !3, file: !3, line: 190, type: !405, scopeLine: 190, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !407)
!405 = !DISubroutineType(types: !406)
!406 = !{!110, !41, !105, !111}
!407 = !{!408, !409, !410, !411}
!408 = !DILocalVariable(name: "dst", arg: 1, scope: !404, file: !3, line: 190, type: !41)
!409 = !DILocalVariable(name: "src", arg: 2, scope: !404, file: !3, line: 190, type: !105)
!410 = !DILocalVariable(name: "dstmax", arg: 3, scope: !404, file: !3, line: 190, type: !111)
!411 = !DILocalVariable(name: "x", scope: !404, file: !3, line: 191, type: !101)
!412 = !DILocation(line: 0, scope: !404)
!413 = !DILocation(line: 193, column: 18, scope: !414)
!414 = distinct !DILexicalBlock(scope: !415, file: !3, line: 193, column: 4)
!415 = distinct !DILexicalBlock(scope: !404, file: !3, line: 193, column: 4)
!416 = !DILocation(line: 193, column: 31, scope: !414)
!417 = !DILocation(line: 193, column: 34, scope: !414)
!418 = !DILocation(line: 193, column: 41, scope: !414)
!419 = !DILocation(line: 193, column: 4, scope: !415)
!420 = !DILocation(line: 194, column: 9, scope: !421)
!421 = distinct !DILexicalBlock(scope: !414, file: !3, line: 193, column: 55)
!422 = !DILocation(line: 194, column: 16, scope: !421)
!423 = !DILocation(line: 193, column: 51, scope: !414)
!424 = distinct !{!424, !419, !425, !88}
!425 = !DILocation(line: 195, column: 4, scope: !415)
!426 = !DILocation(line: 193, scope: !415)
!427 = !DILocation(line: 197, column: 4, scope: !404)
!428 = !DILocation(line: 197, column: 11, scope: !404)
!429 = !DILocation(line: 199, column: 8, scope: !430)
!430 = distinct !DILexicalBlock(scope: !404, file: !3, line: 199, column: 8)
!431 = !DILocation(line: 199, column: 15, scope: !430)
!432 = !DILocation(line: 204, column: 1, scope: !404)
!433 = distinct !DISubprogram(name: "safe_memcmp", scope: !3, file: !3, line: 206, type: !434, scopeLine: 206, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !436)
!434 = !DISubroutineType(types: !435)
!435 = !{!110, !211, !211, !101}
!436 = !{!437, !438, !439, !440, !441, !442, !443}
!437 = !DILocalVariable(name: "a", arg: 1, scope: !433, file: !3, line: 206, type: !211)
!438 = !DILocalVariable(name: "b", arg: 2, scope: !433, file: !3, line: 206, type: !211)
!439 = !DILocalVariable(name: "len", arg: 3, scope: !433, file: !3, line: 206, type: !101)
!440 = !DILocalVariable(name: "ua", scope: !433, file: !3, line: 207, type: !28)
!441 = !DILocalVariable(name: "ub", scope: !433, file: !3, line: 208, type: !28)
!442 = !DILocalVariable(name: "delta", scope: !433, file: !3, line: 209, type: !22)
!443 = !DILocalVariable(name: "x", scope: !433, file: !3, line: 210, type: !101)
!444 = !DILocation(line: 0, scope: !433)
!445 = !DILocation(line: 212, column: 19, scope: !446)
!446 = distinct !DILexicalBlock(scope: !447, file: !3, line: 212, column: 5)
!447 = distinct !DILexicalBlock(scope: !433, file: !3, line: 212, column: 5)
!448 = !DILocation(line: 212, column: 5, scope: !447)
!449 = !DILocation(line: 213, column: 18, scope: !450)
!450 = distinct !DILexicalBlock(scope: !446, file: !3, line: 212, column: 31)
!451 = !DILocation(line: 213, column: 26, scope: !450)
!452 = !DILocation(line: 213, column: 24, scope: !450)
!453 = !DILocation(line: 213, column: 15, scope: !450)
!454 = !DILocation(line: 212, column: 27, scope: !446)
!455 = distinct !{!455, !448, !456, !88}
!456 = !DILocation(line: 214, column: 5, scope: !447)
!457 = distinct !{!457, !458}
!458 = !{!"llvm.loop.unroll.disable"}
!459 = !DILocation(line: 216, column: 15, scope: !460)
!460 = distinct !DILexicalBlock(scope: !433, file: !3, line: 216, column: 9)
!461 = !DILocation(line: 221, column: 1, scope: !433)
!462 = distinct !DISubprogram(name: "vperror", scope: !3, file: !3, line: 223, type: !463, scopeLine: 223, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !465)
!463 = !DISubroutineType(types: !464)
!464 = !{null, !105, null}
!465 = !{!466, !467, !468, !472}
!466 = !DILocalVariable(name: "fmt", arg: 1, scope: !462, file: !3, line: 223, type: !105)
!467 = !DILocalVariable(name: "old_errno", scope: !462, file: !3, line: 224, type: !22)
!468 = !DILocalVariable(name: "buf", scope: !462, file: !3, line: 225, type: !469)
!469 = !DICompositeType(tag: DW_TAG_array_type, baseType: !35, size: 8192, elements: !470)
!470 = !{!471}
!471 = !DISubrange(count: 1024)
!472 = !DILocalVariable(name: "ap", scope: !462, file: !3, line: 226, type: !473)
!473 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !474, line: 12, baseType: !475)
!474 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stdarg_va_list.h", directory: "", checksumkind: CSK_MD5, checksum: "7bd78a282b99fcfe41a9e3c566d14f7d")
!475 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !3, baseType: !476)
!476 = !DICompositeType(tag: DW_TAG_array_type, baseType: !477, size: 192, elements: !483)
!477 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !478)
!478 = !{!479, !480, !481, !482}
!479 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !477, file: !3, line: 226, baseType: !7, size: 32)
!480 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !477, file: !3, line: 226, baseType: !7, size: 32, offset: 32)
!481 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !477, file: !3, line: 226, baseType: !25, size: 64, offset: 64)
!482 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !477, file: !3, line: 226, baseType: !25, size: 64, offset: 128)
!483 = !{!484}
!484 = !DISubrange(count: 1)
!485 = distinct !DIAssignID()
!486 = !DILocation(line: 0, scope: !462)
!487 = distinct !DIAssignID()
!488 = !DILocation(line: 224, column: 21, scope: !462)
!489 = !DILocation(line: 225, column: 5, scope: !462)
!490 = !DILocation(line: 226, column: 5, scope: !462)
!491 = !DILocation(line: 228, column: 5, scope: !462)
!492 = !DILocation(line: 229, column: 9, scope: !493)
!493 = distinct !DILexicalBlock(scope: !462, file: !3, line: 229, column: 9)
!494 = !DILocation(line: 229, column: 46, scope: !493)
!495 = !DILocation(line: 229, column: 9, scope: !462)
!496 = !DILocation(line: 230, column: 9, scope: !497)
!497 = distinct !DILexicalBlock(scope: !493, file: !3, line: 229, column: 53)
!498 = !DILocation(line: 230, column: 30, scope: !497)
!499 = distinct !DIAssignID()
!500 = !DILocation(line: 231, column: 5, scope: !497)
!501 = !DILocation(line: 232, column: 5, scope: !462)
!502 = !DILocation(line: 234, column: 11, scope: !462)
!503 = !DILocation(line: 236, column: 5, scope: !462)
!504 = !DILocation(line: 237, column: 1, scope: !462)
!505 = !DISubprogram(name: "vsnprintf", scope: !97, file: !97, line: 389, type: !506, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!506 = !DISubroutineType(types: !507)
!507 = !{!22, !100, !101, !104, !508}
!508 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !477, size: 64)
!509 = !DISubprogram(name: "perror", scope: !97, file: !97, line: 878, type: !510, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!510 = !DISubroutineType(types: !511)
!511 = !{null, !105}
!512 = distinct !DISubprogram(name: "ntohll", scope: !3, file: !3, line: 257, type: !513, scopeLine: 257, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !515)
!513 = !DISubroutineType(types: !514)
!514 = !{!152, !152}
!515 = !{!516}
!516 = !DILocalVariable(name: "val", arg: 1, scope: !512, file: !3, line: 257, type: !152)
!517 = !DILocation(line: 0, scope: !512)
!518 = !DILocalVariable(name: "in", arg: 1, scope: !519, file: !3, line: 240, type: !152)
!519 = distinct !DISubprogram(name: "mc_swap64", scope: !3, file: !3, line: 240, type: !513, scopeLine: 240, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !520)
!520 = !{!518, !521, !522}
!521 = !DILocalVariable(name: "rv", scope: !519, file: !3, line: 244, type: !253)
!522 = !DILocalVariable(name: "i", scope: !519, file: !3, line: 245, type: !22)
!523 = !DILocation(line: 0, scope: !519, inlinedAt: !524)
!524 = distinct !DILocation(line: 258, column: 11, scope: !512)
!525 = !DILocation(line: 247, column: 24, scope: !526, inlinedAt: !524)
!526 = distinct !DILexicalBlock(scope: !527, file: !3, line: 246, column: 27)
!527 = distinct !DILexicalBlock(scope: !528, file: !3, line: 246, column: 6)
!528 = distinct !DILexicalBlock(scope: !519, file: !3, line: 246, column: 6)
!529 = !DILocation(line: 258, column: 4, scope: !512)
!530 = distinct !DISubprogram(name: "htonll", scope: !3, file: !3, line: 261, type: !513, scopeLine: 261, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !531)
!531 = !{!532}
!532 = !DILocalVariable(name: "val", arg: 1, scope: !530, file: !3, line: 261, type: !152)
!533 = !DILocation(line: 0, scope: !530)
!534 = !DILocation(line: 0, scope: !519, inlinedAt: !535)
!535 = distinct !DILocation(line: 262, column: 11, scope: !530)
!536 = !DILocation(line: 247, column: 24, scope: !526, inlinedAt: !535)
!537 = !DILocation(line: 262, column: 4, scope: !530)
