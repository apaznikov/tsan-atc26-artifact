; ModuleID = 'assoc.c'
source_filename = "assoc.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.stats_state = type { i64, i64, i64, i64, i32, i32, i32, i32, i8, i8, i8, i8 }
%union.pthread_mutex_t = type { %struct.__pthread_mutex_s }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i16, i16, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%union.pthread_cond_t = type { %struct.__pthread_cond_s }
%struct.__pthread_cond_s = type { %union.__atomic_wide_counter, %union.__atomic_wide_counter, [2 x i32], [2 x i32], i32, i32, [2 x i32] }
%union.__atomic_wide_counter = type { i64 }
%struct.settings = type { i64, i32, i32, i32, ptr, i32, i32, i32, ptr, ptr, i32, double, i32, i32, i32, i8, i32, i32, i8, i32, i32, i32, i32, i32, i32, i8, i8, i8, i8, i8, i8, i32, double, i32, i32, i8, i32, i8, i8, ptr, i32, i32, i32, i32, double, double, i32, i8, i32, i32, i32, i32, i32, i8, i8, i8, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, double, double, i8, i32, i32, ptr, i32 }

@hashpower = dso_local local_unnamed_addr global i32 16, align 4, !dbg !0
@primary_hashtable = internal unnamed_addr global ptr null, align 8, !dbg !87
@stderr = external local_unnamed_addr global ptr, align 8
@.str = private unnamed_addr constant [27 x i8] c"Failed to init hashtable.\0A\00", align 1, !dbg !64
@stats_state = external local_unnamed_addr global %struct.stats_state, align 8
@expanding = internal unnamed_addr global i1 false, align 1, !dbg !172
@expand_bucket = internal unnamed_addr global i64 0, align 8, !dbg !92
@old_hashtable = internal unnamed_addr global ptr null, align 8, !dbg !94
@maintenance_lock = internal global %union.pthread_mutex_t zeroinitializer, align 8, !dbg !96
@maintenance_cond = internal global %union.pthread_cond_t zeroinitializer, align 8, !dbg !127
@hash_bulk_move = dso_local local_unnamed_addr global i32 1, align 4, !dbg !69
@.str.1 = private unnamed_addr constant [25 x i8] c"MEMCACHED_HASH_BULK_MOVE\00", align 1, !dbg !71
@maintenance_tid = internal global i64 0, align 8, !dbg !83
@.str.2 = private unnamed_addr constant [25 x i8] c"Can't create thread: %s\0A\00", align 1, !dbg !76
@.str.3 = private unnamed_addr constant [14 x i8] c"mc-assocmaint\00", align 1, !dbg !78
@do_run_maintenance_thread = internal global i32 1, align 4, !dbg !169
@hash = external local_unnamed_addr global ptr, align 8
@settings = external local_unnamed_addr global %struct.settings, align 8
@.str.4 = private unnamed_addr constant [27 x i8] c"Hash table expansion done\0A\00", align 1, !dbg !162
@.str.5 = private unnamed_addr constant [31 x i8] c"Hash table expansion starting\0A\00", align 1, !dbg !164
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @assoc_init(i32 noundef %hashtable_init) local_unnamed_addr #0 !dbg !181 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %hashtable_init, metadata !186, metadata !DIExpression()), !dbg !187
  %tobool.not = icmp eq i32 %hashtable_init, 0, !dbg !188
  br i1 %tobool.not, label %entry.if.end_crit_edge, label %if.then, !dbg !190

entry.if.end_crit_edge:                           ; preds = %entry
  %.pre = load i32, ptr @hashpower, align 4, !dbg !191, !tbaa !192
  br label %if.end, !dbg !190

if.then:                                          ; preds = %entry
  store i32 %hashtable_init, ptr @hashpower, align 4, !dbg !196, !tbaa !192
  br label %if.end, !dbg !198

if.end:                                           ; preds = %entry.if.end_crit_edge, %if.then
  %0 = phi i32 [ %.pre, %entry.if.end_crit_edge ], [ %hashtable_init, %if.then ], !dbg !191
  %sh_prom = zext nneg i32 %0 to i64, !dbg !191
  %shl = shl nuw i64 1, %sh_prom, !dbg !191
  %call = tail call noalias ptr @calloc(i64 noundef %shl, i64 noundef 8) #15, !dbg !199
  store ptr %call, ptr @primary_hashtable, align 8, !dbg !200, !tbaa !201
  %tobool1.not = icmp eq ptr %call, null, !dbg !203
  br i1 %tobool1.not, label %if.then2, label %if.end4, !dbg !205

if.then2:                                         ; preds = %if.end
  %1 = load ptr, ptr @stderr, align 8, !dbg !206, !tbaa !201
  %2 = tail call i64 @fwrite(ptr nonnull @.str, i64 26, i64 1, ptr %1) #16, !dbg !208
  tail call void @exit(i32 noundef 1) #17, !dbg !209
  unreachable, !dbg !209

if.end4:                                          ; preds = %if.end
  tail call void @STATS_LOCK() #18, !dbg !210
  %3 = load i32, ptr @hashpower, align 4, !dbg !211, !tbaa !192
  store i32 %3, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 6), align 8, !dbg !212, !tbaa !213
  %sh_prom5 = zext nneg i32 %3 to i64, !dbg !217
  %mul = shl i64 8, %sh_prom5, !dbg !218
  store i64 %mul, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 3), align 8, !dbg !219, !tbaa !220
  tail call void @STATS_UNLOCK() #18, !dbg !221
  ret void, !dbg !222
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite)
declare !dbg !223 noalias noundef ptr @calloc(i64 noundef, i64 noundef) local_unnamed_addr #1

; Function Attrs: nofree nounwind
declare !dbg !229 noundef i32 @fprintf(ptr nocapture noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #2

; Function Attrs: noreturn nounwind
declare !dbg !290 void @exit(i32 noundef) local_unnamed_addr #3

declare !dbg !293 void @STATS_LOCK() local_unnamed_addr #4

declare !dbg !296 void @STATS_UNLOCK() local_unnamed_addr #4

; Function Attrs: nofree nounwind sanitize_thread memory(read, inaccessiblemem: none) uwtable
define dso_local ptr @assoc_find(ptr nocapture noundef readonly %key, i64 noundef %nkey, i32 noundef %hv) local_unnamed_addr #5 !dbg !297 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !305, metadata !DIExpression()), !dbg !311
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !306, metadata !DIExpression()), !dbg !311
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !307, metadata !DIExpression()), !dbg !311
  %.b29 = load i1, ptr @expanding, align 1, !dbg !312
  %.pre = load i32, ptr @hashpower, align 4, !dbg !314, !tbaa !192
  %conv = zext i32 %hv to i64, !dbg !316
  br i1 %.b29, label %land.lhs.true, label %if.else, !dbg !317

land.lhs.true:                                    ; preds = %entry
  %sub = add i32 %.pre, -1, !dbg !318
  %sh_prom = zext nneg i32 %sub to i64, !dbg !318
  %notmask = shl nsw i64 -1, %sh_prom, !dbg !318
  %sub1 = xor i64 %notmask, -1, !dbg !318
  %and = and i64 %sub1, %conv, !dbg !319
  tail call void @llvm.dbg.value(metadata i64 %and, metadata !309, metadata !DIExpression()), !dbg !311
  %0 = load i64, ptr @expand_bucket, align 8, !dbg !320, !tbaa !321
  %cmp.not = icmp ult i64 %and, %0, !dbg !322
  br i1 %cmp.not, label %if.else, label %if.then, !dbg !323

if.then:                                          ; preds = %land.lhs.true
  %1 = load ptr, ptr @old_hashtable, align 8, !dbg !324, !tbaa !201
  %arrayidx = getelementptr inbounds ptr, ptr %1, i64 %and, !dbg !324
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !308, metadata !DIExpression()), !dbg !311
  br label %if.end, !dbg !326

if.else:                                          ; preds = %entry, %land.lhs.true
  %2 = load ptr, ptr @primary_hashtable, align 8, !dbg !327, !tbaa !201
  %sh_prom4 = zext nneg i32 %.pre to i64, !dbg !314
  %notmask30 = shl nsw i64 -1, %sh_prom4, !dbg !314
  %sub6 = xor i64 %notmask30, -1, !dbg !314
  %and7 = and i64 %conv, %sub6, !dbg !328
  %arrayidx8 = getelementptr inbounds ptr, ptr %2, i64 %and7, !dbg !327
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !308, metadata !DIExpression()), !dbg !311
  br label %if.end

if.end:                                           ; preds = %if.else, %if.then
  %it.0.in = phi ptr [ %arrayidx, %if.then ], [ %arrayidx8, %if.else ]
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !308, metadata !DIExpression()), !dbg !311
  tail call void @llvm.dbg.value(metadata ptr null, metadata !310, metadata !DIExpression()), !dbg !311
  %it.131 = load ptr, ptr %it.0.in, align 8, !dbg !311, !tbaa !201
  %tobool9.not32 = icmp eq ptr %it.131, null, !dbg !329
  br i1 %tobool9.not32, label %while.end, label %while.body, !dbg !329

while.body:                                       ; preds = %if.end, %if.end21
  %it.133 = phi ptr [ %it.1, %if.end21 ], [ %it.131, %if.end ]
  %nkey10 = getelementptr inbounds i8, ptr %it.133, i64 41, !dbg !330
  %3 = load i8, ptr %nkey10, align 1, !dbg !330, !tbaa !333
  %conv11 = zext i8 %3 to i64, !dbg !334
  %cmp12 = icmp eq i64 %conv11, %nkey, !dbg !335
  br i1 %cmp12, label %land.lhs.true14, label %if.end21, !dbg !336

land.lhs.true14:                                  ; preds = %while.body
  %data = getelementptr inbounds i8, ptr %it.133, i64 48, !dbg !337
  %it_flags = getelementptr inbounds i8, ptr %it.133, i64 38, !dbg !337
  %4 = load i16, ptr %it_flags, align 2, !dbg !337, !tbaa !338
  %5 = shl i16 %4, 2, !dbg !337
  %6 = and i16 %5, 8, !dbg !337
  %cond = zext nneg i16 %6 to i64, !dbg !337
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %cond, !dbg !337
  %bcmp = tail call i32 @bcmp(ptr %key, ptr nonnull %add.ptr, i64 %nkey) #19, !dbg !340
  %cmp18 = icmp eq i32 %bcmp, 0, !dbg !341
  br i1 %cmp18, label %while.end, label %if.end21, !dbg !342

if.end21:                                         ; preds = %land.lhs.true14, %while.body
  %h_next = getelementptr inbounds i8, ptr %it.133, i64 16, !dbg !343
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !308, metadata !DIExpression()), !dbg !311
  %it.1 = load ptr, ptr %h_next, align 8, !dbg !311, !tbaa !201
  tail call void @llvm.dbg.value(metadata ptr %it.1, metadata !308, metadata !DIExpression()), !dbg !311
  %tobool9.not = icmp eq ptr %it.1, null, !dbg !329
  br i1 %tobool9.not, label %while.end, label %while.body, !dbg !329, !llvm.loop !344

while.end:                                        ; preds = %if.end21, %land.lhs.true14, %if.end
  %it.1.lcssa = phi ptr [ null, %if.end ], [ %it.133, %land.lhs.true14 ], [ null, %if.end21 ], !dbg !311
  tail call void @llvm.dbg.value(metadata ptr %it.1.lcssa, metadata !310, metadata !DIExpression()), !dbg !311
  ret ptr %it.1.lcssa, !dbg !347
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @assoc_start_expand(i64 noundef %curr_items) local_unnamed_addr #0 !dbg !348 {
entry:
  tail call void @llvm.dbg.value(metadata i64 %curr_items, metadata !352, metadata !DIExpression()), !dbg !353
  %call = tail call i32 @pthread_mutex_trylock(ptr noundef nonnull @maintenance_lock) #18, !dbg !354
  %cmp = icmp eq i32 %call, 0, !dbg !356
  br i1 %cmp, label %if.then, label %if.end6, !dbg !357

if.then:                                          ; preds = %entry
  %0 = load i32, ptr @hashpower, align 4, !dbg !358, !tbaa !192
  %sh_prom = zext nneg i32 %0 to i64, !dbg !358
  %mul7 = shl i64 3, %sh_prom, !dbg !361
  %div8 = lshr i64 %mul7, 1, !dbg !362
  %cmp1 = icmp ult i64 %div8, %curr_items, !dbg !363
  %cmp2 = icmp ult i32 %0, 32
  %or.cond = and i1 %cmp2, %cmp1, !dbg !364
  br i1 %or.cond, label %if.then3, label %if.end, !dbg !364

if.then3:                                         ; preds = %if.then
  %call4 = tail call i32 @pthread_cond_signal(ptr noundef nonnull @maintenance_cond) #18, !dbg !365
  br label %if.end, !dbg !367

if.end:                                           ; preds = %if.then3, %if.then
  %call5 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @maintenance_lock) #18, !dbg !368
  br label %if.end6, !dbg !369

if.end6:                                          ; preds = %if.end, %entry
  ret void, !dbg !370
}

; Function Attrs: nounwind
declare !dbg !371 i32 @pthread_mutex_trylock(ptr noundef) local_unnamed_addr #6

; Function Attrs: nounwind
declare !dbg !376 i32 @pthread_cond_signal(ptr noundef) local_unnamed_addr #6

; Function Attrs: nounwind
declare !dbg !380 i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #6

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, inaccessiblemem: none) uwtable
define dso_local noundef i32 @assoc_insert(ptr noundef %it, i32 noundef %hv) local_unnamed_addr #7 !dbg !381 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !385, metadata !DIExpression()), !dbg !388
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !386, metadata !DIExpression()), !dbg !388
  %.b23 = load i1, ptr @expanding, align 1, !dbg !389
  %.pre = load i32, ptr @hashpower, align 4, !dbg !391, !tbaa !192
  %conv = zext i32 %hv to i64, !dbg !393
  br i1 %.b23, label %land.lhs.true, label %if.else, !dbg !394

land.lhs.true:                                    ; preds = %entry
  %sub = add i32 %.pre, -1, !dbg !395
  %sh_prom = zext nneg i32 %sub to i64, !dbg !395
  %notmask = shl nsw i64 -1, %sh_prom, !dbg !395
  %sub1 = xor i64 %notmask, -1, !dbg !395
  %and = and i64 %sub1, %conv, !dbg !396
  tail call void @llvm.dbg.value(metadata i64 %and, metadata !387, metadata !DIExpression()), !dbg !388
  %0 = load i64, ptr @expand_bucket, align 8, !dbg !397, !tbaa !321
  %cmp.not = icmp ult i64 %and, %0, !dbg !398
  br i1 %cmp.not, label %if.else, label %if.then, !dbg !399

if.then:                                          ; preds = %land.lhs.true
  %1 = load ptr, ptr @old_hashtable, align 8, !dbg !400, !tbaa !201
  %arrayidx = getelementptr inbounds ptr, ptr %1, i64 %and, !dbg !400
  br label %if.end, !dbg !402

if.else:                                          ; preds = %entry, %land.lhs.true
  %2 = load ptr, ptr @primary_hashtable, align 8, !dbg !403, !tbaa !201
  %sh_prom5 = zext nneg i32 %.pre to i64, !dbg !391
  %notmask24 = shl nsw i64 -1, %sh_prom5, !dbg !391
  %sub7 = xor i64 %notmask24, -1, !dbg !391
  %and8 = and i64 %conv, %sub7, !dbg !404
  %arrayidx9 = getelementptr inbounds ptr, ptr %2, i64 %and8, !dbg !403
  br label %if.end

if.end:                                           ; preds = %if.else, %if.then
  %arrayidx9.sink27 = phi ptr [ %arrayidx9, %if.else ], [ %arrayidx, %if.then ]
  %3 = load ptr, ptr %arrayidx9.sink27, align 8, !dbg !393, !tbaa !201
  %h_next10 = getelementptr inbounds i8, ptr %it, i64 16, !dbg !393
  store ptr %3, ptr %h_next10, align 8, !dbg !393, !tbaa !201
  store ptr %it, ptr %arrayidx9.sink27, align 8, !dbg !393, !tbaa !201
  ret i32 1, !dbg !405
}

; Function Attrs: nofree nounwind sanitize_thread memory(readwrite, inaccessiblemem: none) uwtable
define dso_local void @assoc_delete(ptr nocapture noundef readonly %key, i64 noundef %nkey, i32 noundef %hv) local_unnamed_addr #8 !dbg !406 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !410, metadata !DIExpression()), !dbg !417
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !411, metadata !DIExpression()), !dbg !417
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !412, metadata !DIExpression()), !dbg !417
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !418, metadata !DIExpression()), !dbg !427
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !423, metadata !DIExpression()), !dbg !427
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !424, metadata !DIExpression()), !dbg !427
  %.b25.i = load i1, ptr @expanding, align 1, !dbg !429
  %.pre.i = load i32, ptr @hashpower, align 4, !dbg !431, !tbaa !192
  %conv.i = zext i32 %hv to i64, !dbg !433
  br i1 %.b25.i, label %land.lhs.true.i, label %if.else.i, !dbg !434

land.lhs.true.i:                                  ; preds = %entry
  %sub.i = add i32 %.pre.i, -1, !dbg !435
  %sh_prom.i = zext nneg i32 %sub.i to i64, !dbg !435
  %notmask.i = shl nsw i64 -1, %sh_prom.i, !dbg !435
  %sub1.i = xor i64 %notmask.i, -1, !dbg !435
  %and.i = and i64 %sub1.i, %conv.i, !dbg !436
  tail call void @llvm.dbg.value(metadata i64 %and.i, metadata !426, metadata !DIExpression()), !dbg !427
  %0 = load i64, ptr @expand_bucket, align 8, !dbg !437, !tbaa !321
  %cmp.not.i = icmp ult i64 %and.i, %0, !dbg !438
  br i1 %cmp.not.i, label %if.else.i, label %if.then.i, !dbg !439

if.then.i:                                        ; preds = %land.lhs.true.i
  %1 = load ptr, ptr @old_hashtable, align 8, !dbg !440, !tbaa !201
  %arrayidx.i = getelementptr inbounds ptr, ptr %1, i64 %and.i, !dbg !440
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i, metadata !425, metadata !DIExpression()), !dbg !427
  br label %if.end.i, !dbg !442

if.else.i:                                        ; preds = %land.lhs.true.i, %entry
  %2 = load ptr, ptr @primary_hashtable, align 8, !dbg !443, !tbaa !201
  %sh_prom4.i = zext nneg i32 %.pre.i to i64, !dbg !431
  %notmask26.i = shl nsw i64 -1, %sh_prom4.i, !dbg !431
  %sub6.i = xor i64 %notmask26.i, -1, !dbg !431
  %and7.i = and i64 %sub6.i, %conv.i, !dbg !444
  %arrayidx8.i = getelementptr inbounds ptr, ptr %2, i64 %and7.i, !dbg !443
  tail call void @llvm.dbg.value(metadata ptr %arrayidx8.i, metadata !425, metadata !DIExpression()), !dbg !427
  br label %if.end.i

if.end.i:                                         ; preds = %if.else.i, %if.then.i
  %pos.0.i = phi ptr [ %arrayidx.i, %if.then.i ], [ %arrayidx8.i, %if.else.i ], !dbg !433
  tail call void @llvm.dbg.value(metadata ptr %pos.0.i, metadata !425, metadata !DIExpression()), !dbg !427
  %3 = load ptr, ptr %pos.0.i, align 8, !dbg !445, !tbaa !201
  %tobool9.not27.i = icmp eq ptr %3, null, !dbg !445
  br i1 %tobool9.not27.i, label %cleanup, label %land.rhs.i, !dbg !446

land.rhs.i:                                       ; preds = %if.end.i, %while.body.i
  %.pr = phi ptr [ %8, %while.body.i ], [ %3, %if.end.i ]
  %pos.128.i = phi ptr [ %h_next.i, %while.body.i ], [ %pos.0.i, %if.end.i ]
  tail call void @llvm.dbg.value(metadata ptr %pos.128.i, metadata !425, metadata !DIExpression()), !dbg !427
  %nkey10.i = getelementptr inbounds i8, ptr %.pr, i64 41, !dbg !447
  %4 = load i8, ptr %nkey10.i, align 1, !dbg !447, !tbaa !333
  %conv11.i = zext i8 %4 to i64, !dbg !448
  %cmp12.not.i = icmp eq i64 %conv11.i, %nkey, !dbg !449
  br i1 %cmp12.not.i, label %lor.rhs.i, label %while.body.i, !dbg !450

lor.rhs.i:                                        ; preds = %land.rhs.i
  %data.i = getelementptr inbounds i8, ptr %.pr, i64 48, !dbg !451
  %it_flags.i = getelementptr inbounds i8, ptr %.pr, i64 38, !dbg !451
  %5 = load i16, ptr %it_flags.i, align 2, !dbg !451, !tbaa !338
  %6 = shl i16 %5, 2, !dbg !451
  %7 = and i16 %6, 8, !dbg !451
  %cond.i = zext nneg i16 %7 to i64, !dbg !451
  %add.ptr.i = getelementptr inbounds i8, ptr %data.i, i64 %cond.i, !dbg !451
  %bcmp.i = tail call i32 @bcmp(ptr readonly %key, ptr nonnull %add.ptr.i, i64 %nkey) #19, !dbg !452
  %tobool17.not.i = icmp eq i32 %bcmp.i, 0, !dbg !450
  br i1 %tobool17.not.i, label %if.then, label %while.body.i, !dbg !453

while.body.i:                                     ; preds = %lor.rhs.i, %land.rhs.i
  %h_next.i = getelementptr inbounds i8, ptr %.pr, i64 16, !dbg !454
  tail call void @llvm.dbg.value(metadata ptr %h_next.i, metadata !425, metadata !DIExpression()), !dbg !427
  %8 = load ptr, ptr %h_next.i, align 8, !dbg !445, !tbaa !201
  %tobool9.not.i = icmp eq ptr %8, null, !dbg !445
  br i1 %tobool9.not.i, label %cleanup, label %land.rhs.i, !dbg !446, !llvm.loop !456

if.then:                                          ; preds = %lor.rhs.i
  tail call void @llvm.dbg.value(metadata ptr %pos.128.i, metadata !413, metadata !DIExpression()), !dbg !417
  %h_next = getelementptr inbounds i8, ptr %.pr, i64 16, !dbg !458
  %9 = load ptr, ptr %h_next, align 8, !dbg !458, !tbaa !201
  tail call void @llvm.dbg.value(metadata ptr %9, metadata !414, metadata !DIExpression()), !dbg !459
  store ptr null, ptr %h_next, align 8, !dbg !460, !tbaa !201
  store ptr %9, ptr %pos.128.i, align 8, !dbg !461, !tbaa !201
  br label %cleanup

cleanup:                                          ; preds = %while.body.i, %if.end.i, %if.then
  ret void, !dbg !462
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 -1, 1) i32 @start_assoc_maintenance_thread() local_unnamed_addr #0 !dbg !463 {
entry:
  %call = tail call ptr @getenv(ptr noundef nonnull @.str.1) #18, !dbg !469
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !468, metadata !DIExpression()), !dbg !470
  %cmp.not = icmp eq ptr %call, null, !dbg !471
  br i1 %cmp.not, label %if.end4, label %if.then, !dbg !473

if.then:                                          ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !474, metadata !DIExpression()), !dbg !479
  %call.i = tail call i64 @__isoc23_strtol(ptr noundef nonnull %call, ptr noundef null, i32 noundef 10) #18, !dbg !482
  %conv.i = trunc i64 %call.i to i32, !dbg !483
  %spec.store.select = tail call i32 @llvm.umax.i32(i32 %conv.i, i32 1), !dbg !484
  store i32 %spec.store.select, ptr @hash_bulk_move, align 4, !dbg !485
  br label %if.end4, !dbg !486

if.end4:                                          ; preds = %if.then, %entry
  %call5 = tail call i32 @pthread_create(ptr noundef nonnull @maintenance_tid, ptr noundef null, ptr noundef nonnull @assoc_maintenance_thread, ptr noundef null) #18, !dbg !487
  tail call void @llvm.dbg.value(metadata i32 %call5, metadata !467, metadata !DIExpression()), !dbg !470
  %cmp6.not = icmp eq i32 %call5, 0, !dbg !489
  br i1 %cmp6.not, label %if.end10, label %if.then7, !dbg !490

if.then7:                                         ; preds = %if.end4
  %0 = load ptr, ptr @stderr, align 8, !dbg !491, !tbaa !201
  %call8 = tail call ptr @strerror(i32 noundef %call5) #18, !dbg !493
  %call9 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %0, ptr noundef nonnull @.str.2, ptr noundef %call8) #20, !dbg !494
  br label %cleanup, !dbg !495

if.end10:                                         ; preds = %if.end4
  %1 = load i64, ptr @maintenance_tid, align 8, !dbg !496, !tbaa !321
  tail call void @thread_setname(i64 noundef %1, ptr noundef nonnull @.str.3) #18, !dbg !497
  br label %cleanup, !dbg !498

cleanup:                                          ; preds = %if.end10, %if.then7
  %retval.0 = phi i32 [ -1, %if.then7 ], [ 0, %if.end10 ], !dbg !470
  ret i32 %retval.0, !dbg !499
}

; Function Attrs: nofree nounwind memory(read)
declare !dbg !500 noundef ptr @getenv(ptr nocapture noundef) local_unnamed_addr #9

; Function Attrs: nounwind
declare !dbg !503 i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #6

; Function Attrs: nounwind sanitize_thread uwtable
define internal noundef ptr @assoc_maintenance_thread(ptr nocapture readnone %arg) #0 !dbg !523 {
entry:
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !525, metadata !DIExpression()), !dbg !535
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @maintenance_lock) #18, !dbg !536
  %0 = load volatile i32, ptr @do_run_maintenance_thread, align 4, !dbg !537, !tbaa !192
  %tobool.not66 = icmp eq i32 %0, 0, !dbg !538
  br i1 %tobool.not66, label %while.end, label %for.cond.preheader, !dbg !538

for.cond.preheader:                               ; preds = %entry, %if.end47
  tail call void @llvm.dbg.value(metadata i32 0, metadata !526, metadata !DIExpression()), !dbg !539
  %1 = load i32, ptr @hash_bulk_move, align 4, !dbg !540, !tbaa !192
  %cmp64 = icmp sgt i32 %1, 0, !dbg !541
  br i1 %cmp64, label %land.rhs, label %for.end40, !dbg !542

land.rhs:                                         ; preds = %for.cond.preheader, %if.end37
  %ii.065 = phi i32 [ %inc39, %if.end37 ], [ 0, %for.cond.preheader ]
  tail call void @llvm.dbg.value(metadata i32 %ii.065, metadata !526, metadata !DIExpression()), !dbg !539
  %.b5859 = load i1, ptr @expanding, align 1, !dbg !543
  br i1 %.b5859, label %for.body, label %if.then42, !dbg !544

for.body:                                         ; preds = %land.rhs
  tail call void @llvm.dbg.value(metadata ptr null, metadata !534, metadata !DIExpression()), !dbg !545
  %2 = load i64, ptr @expand_bucket, align 8, !dbg !546, !tbaa !321
  %conv = trunc i64 %2 to i32, !dbg !546
  %call2 = tail call ptr @item_trylock(i32 noundef %conv) #18, !dbg !548
  tail call void @llvm.dbg.value(metadata ptr %call2, metadata !534, metadata !DIExpression()), !dbg !545
  %tobool3.not = icmp eq ptr %call2, null, !dbg !549
  br i1 %tobool3.not, label %if.end34.thread, label %if.then, !dbg !550

if.then:                                          ; preds = %for.body
  %3 = load ptr, ptr @old_hashtable, align 8, !dbg !551, !tbaa !201
  %4 = load i64, ptr @expand_bucket, align 8, !dbg !554, !tbaa !321
  %arrayidx = getelementptr inbounds ptr, ptr %3, i64 %4, !dbg !551
  %5 = load ptr, ptr %arrayidx, align 8, !dbg !551, !tbaa !201
  tail call void @llvm.dbg.value(metadata ptr %5, metadata !528, metadata !DIExpression()), !dbg !545
  %cmp5.not62 = icmp eq ptr %5, null, !dbg !555
  br i1 %cmp5.not62, label %if.then.for.end_crit_edge, label %for.body7, !dbg !557

if.then.for.end_crit_edge:                        ; preds = %if.then
  %.pre68 = load i32, ptr @hashpower, align 4, !dbg !558, !tbaa !192
  br label %for.end, !dbg !557

for.body7:                                        ; preds = %if.then, %for.body7
  %it.063 = phi ptr [ %6, %for.body7 ], [ %5, %if.then ]
  tail call void @llvm.dbg.value(metadata ptr %it.063, metadata !528, metadata !DIExpression()), !dbg !545
  %h_next = getelementptr inbounds i8, ptr %it.063, i64 16, !dbg !560
  %6 = load ptr, ptr %h_next, align 8, !dbg !560, !tbaa !201
  tail call void @llvm.dbg.value(metadata ptr %6, metadata !532, metadata !DIExpression()), !dbg !545
  %7 = load ptr, ptr @hash, align 8, !dbg !562, !tbaa !201
  %data = getelementptr inbounds i8, ptr %it.063, i64 48, !dbg !563
  %it_flags = getelementptr inbounds i8, ptr %it.063, i64 38, !dbg !563
  %8 = load i16, ptr %it_flags, align 2, !dbg !563, !tbaa !338
  %9 = shl i16 %8, 2, !dbg !563
  %10 = and i16 %9, 8, !dbg !563
  %cond = zext nneg i16 %10 to i64, !dbg !563
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %cond, !dbg !563
  %nkey = getelementptr inbounds i8, ptr %it.063, i64 41, !dbg !564
  %11 = load i8, ptr %nkey, align 1, !dbg !564, !tbaa !333
  %conv10 = zext i8 %11 to i64, !dbg !565
  %call11 = tail call i32 %7(ptr noundef nonnull %add.ptr, i64 noundef %conv10) #18, !dbg !562
  %conv12 = zext i32 %call11 to i64, !dbg !562
  %12 = load i32, ptr @hashpower, align 4, !dbg !566, !tbaa !192
  %sh_prom = zext nneg i32 %12 to i64, !dbg !566
  %notmask = shl nsw i64 -1, %sh_prom, !dbg !566
  %sub = xor i64 %notmask, -1, !dbg !566
  %and13 = and i64 %sub, %conv12, !dbg !567
  tail call void @llvm.dbg.value(metadata i64 %and13, metadata !533, metadata !DIExpression()), !dbg !545
  %13 = load ptr, ptr @primary_hashtable, align 8, !dbg !568, !tbaa !201
  %arrayidx14 = getelementptr inbounds ptr, ptr %13, i64 %and13, !dbg !568
  %14 = load ptr, ptr %arrayidx14, align 8, !dbg !568, !tbaa !201
  store ptr %14, ptr %h_next, align 8, !dbg !569, !tbaa !201
  store ptr %it.063, ptr %arrayidx14, align 8, !dbg !570, !tbaa !201
  tail call void @llvm.dbg.value(metadata ptr %6, metadata !528, metadata !DIExpression()), !dbg !545
  %cmp5.not = icmp eq ptr %6, null, !dbg !555
  br i1 %cmp5.not, label %for.end.loopexit, label %for.body7, !dbg !557, !llvm.loop !571

for.end.loopexit:                                 ; preds = %for.body7
  %.pre = load ptr, ptr @old_hashtable, align 8, !dbg !573, !tbaa !201
  %.pre67 = load i64, ptr @expand_bucket, align 8, !dbg !574, !tbaa !321
  br label %for.end, !dbg !573

for.end:                                          ; preds = %if.then.for.end_crit_edge, %for.end.loopexit
  %15 = phi i32 [ %12, %for.end.loopexit ], [ %.pre68, %if.then.for.end_crit_edge ], !dbg !558
  %16 = phi i64 [ %.pre67, %for.end.loopexit ], [ %4, %if.then.for.end_crit_edge ], !dbg !574
  %17 = phi ptr [ %.pre, %for.end.loopexit ], [ %3, %if.then.for.end_crit_edge ], !dbg !573
  %arrayidx17 = getelementptr inbounds ptr, ptr %17, i64 %16, !dbg !573
  store ptr null, ptr %arrayidx17, align 8, !dbg !575, !tbaa !201
  %inc = add i64 %16, 1, !dbg !576
  store i64 %inc, ptr @expand_bucket, align 8, !dbg !576, !tbaa !321
  %sub18 = add i32 %15, -1, !dbg !558
  %sh_prom19 = zext nneg i32 %sub18 to i64, !dbg !558
  %shl20 = shl nuw i64 1, %sh_prom19, !dbg !558
  %cmp21 = icmp eq i64 %inc, %shl20, !dbg !577
  br i1 %cmp21, label %if.then23, label %if.end34, !dbg !578

if.then23:                                        ; preds = %for.end
  store i1 false, ptr @expanding, align 1, !dbg !579
  tail call void @free(ptr noundef nonnull %17) #18, !dbg !581
  tail call void @STATS_LOCK() #18, !dbg !582
  %18 = load i32, ptr @hashpower, align 4, !dbg !583, !tbaa !192
  %sub24 = add i32 %18, -1, !dbg !583
  %sh_prom25 = zext nneg i32 %sub24 to i64, !dbg !583
  %mul.neg = shl i64 -8, %sh_prom25, !dbg !584
  %19 = load i64, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 3), align 8, !dbg !585, !tbaa !220
  %sub27 = add i64 %mul.neg, %19, !dbg !585
  store i64 %sub27, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 3), align 8, !dbg !585, !tbaa !220
  store i8 0, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 8), align 8, !dbg !586, !tbaa !587
  tail call void @STATS_UNLOCK() #18, !dbg !588
  %20 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !589, !tbaa !591
  %cmp28 = icmp sgt i32 %20, 1, !dbg !594
  br i1 %cmp28, label %if.then30, label %if.end34, !dbg !595

if.then30:                                        ; preds = %if.then23
  %21 = load ptr, ptr @stderr, align 8, !dbg !596, !tbaa !201
  %22 = tail call i64 @fwrite(ptr nonnull @.str.4, i64 26, i64 1, ptr %21) #16, !dbg !597
  br label %if.end34, !dbg !597

if.end34.thread:                                  ; preds = %for.body
  %call33 = tail call i32 @usleep(i32 noundef 10000) #18, !dbg !598
  br label %if.end37, !dbg !600

if.end34:                                         ; preds = %for.end, %if.then30, %if.then23
  tail call void @item_trylock_unlock(ptr noundef nonnull %call2) #18, !dbg !601
  tail call void @llvm.dbg.value(metadata ptr null, metadata !534, metadata !DIExpression()), !dbg !545
  br label %if.end37, !dbg !604

if.end37:                                         ; preds = %if.end34.thread, %if.end34
  %inc39 = add nuw nsw i32 %ii.065, 1, !dbg !605
  tail call void @llvm.dbg.value(metadata i32 %inc39, metadata !526, metadata !DIExpression()), !dbg !539
  %23 = load i32, ptr @hash_bulk_move, align 4, !dbg !540, !tbaa !192
  %cmp = icmp slt i32 %inc39, %23, !dbg !541
  br i1 %cmp, label %land.rhs, label %for.end40, !dbg !542, !llvm.loop !606

for.end40:                                        ; preds = %if.end37, %for.cond.preheader
  %.b60.pr = load i1, ptr @expanding, align 1, !dbg !608
  br i1 %.b60.pr, label %if.end47, label %if.then42, !dbg !610

if.then42:                                        ; preds = %land.rhs, %for.end40
  %call43 = tail call i32 @pthread_cond_wait(ptr noundef nonnull @maintenance_cond, ptr noundef nonnull @maintenance_lock) #18, !dbg !611
  %24 = load volatile i32, ptr @do_run_maintenance_thread, align 4, !dbg !613, !tbaa !192
  %tobool44.not = icmp eq i32 %24, 0, !dbg !613
  br i1 %tobool44.not, label %if.end47, label %if.then45, !dbg !615

if.then45:                                        ; preds = %if.then42
  tail call void @pause_threads(i32 noundef 1) #18, !dbg !616
  %25 = load ptr, ptr @primary_hashtable, align 8, !dbg !618, !tbaa !201
  store ptr %25, ptr @old_hashtable, align 8, !dbg !621, !tbaa !201
  %26 = load i32, ptr @hashpower, align 4, !dbg !622, !tbaa !192
  %add.i = add i32 %26, 1, !dbg !622
  %sh_prom.i = zext nneg i32 %add.i to i64, !dbg !622
  %shl.i = shl nuw i64 1, %sh_prom.i, !dbg !622
  %call.i = tail call noalias ptr @calloc(i64 noundef %shl.i, i64 noundef 8) #15, !dbg !623
  store ptr %call.i, ptr @primary_hashtable, align 8, !dbg !624, !tbaa !201
  %tobool.not.i = icmp eq ptr %call.i, null, !dbg !625
  br i1 %tobool.not.i, label %if.else.i, label %if.then.i, !dbg !627

if.then.i:                                        ; preds = %if.then45
  %27 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !628, !tbaa !591
  %cmp.i = icmp sgt i32 %27, 1, !dbg !631
  br i1 %cmp.i, label %if.then1.i, label %if.end.i, !dbg !632

if.then1.i:                                       ; preds = %if.then.i
  %28 = load ptr, ptr @stderr, align 8, !dbg !633, !tbaa !201
  %29 = tail call i64 @fwrite(ptr nonnull @.str.5, i64 30, i64 1, ptr %28) #16, !dbg !634
  %.pre.i = load i32, ptr @hashpower, align 4, !dbg !635, !tbaa !192
  %.pre7.i = add i32 %.pre.i, 1, !dbg !635
  br label %if.end.i, !dbg !634

if.end.i:                                         ; preds = %if.then1.i, %if.then.i
  %inc.pre-phi.i = phi i32 [ %.pre7.i, %if.then1.i ], [ %add.i, %if.then.i ], !dbg !635
  store i32 %inc.pre-phi.i, ptr @hashpower, align 4, !dbg !635, !tbaa !192
  store i1 true, ptr @expanding, align 1, !dbg !636
  store i64 0, ptr @expand_bucket, align 8, !dbg !637, !tbaa !321
  tail call void @STATS_LOCK() #18, !dbg !638
  %30 = load i32, ptr @hashpower, align 4, !dbg !639, !tbaa !192
  store i32 %30, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 6), align 8, !dbg !640, !tbaa !213
  %sh_prom3.i = zext nneg i32 %30 to i64, !dbg !641
  %mul.i = shl i64 8, %sh_prom3.i, !dbg !642
  %31 = load i64, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 3), align 8, !dbg !643, !tbaa !220
  %add5.i = add i64 %31, %mul.i, !dbg !643
  store i64 %add5.i, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 3), align 8, !dbg !643, !tbaa !220
  store i8 1, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 8), align 8, !dbg !644, !tbaa !587
  tail call void @STATS_UNLOCK() #18, !dbg !645
  br label %assoc_expand.exit, !dbg !646

if.else.i:                                        ; preds = %if.then45
  store ptr %25, ptr @primary_hashtable, align 8, !dbg !647, !tbaa !201
  br label %assoc_expand.exit

assoc_expand.exit:                                ; preds = %if.end.i, %if.else.i
  tail call void @pause_threads(i32 noundef 2) #18, !dbg !649
  br label %if.end47, !dbg !650

if.end47:                                         ; preds = %if.then42, %assoc_expand.exit, %for.end40
  %32 = load volatile i32, ptr @do_run_maintenance_thread, align 4, !dbg !537, !tbaa !192
  %tobool.not = icmp eq i32 %32, 0, !dbg !538
  br i1 %tobool.not, label %while.end, label %for.cond.preheader, !dbg !538, !llvm.loop !651

while.end:                                        ; preds = %if.end47, %entry
  %call48 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @maintenance_lock) #18, !dbg !653
  ret ptr null, !dbg !654
}

; Function Attrs: nounwind
declare !dbg !655 ptr @strerror(i32 noundef) local_unnamed_addr #6

declare !dbg !659 void @thread_setname(i64 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @stop_assoc_maintenance_thread() local_unnamed_addr #0 !dbg !662 {
entry:
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @maintenance_lock) #18, !dbg !663
  store volatile i32 0, ptr @do_run_maintenance_thread, align 4, !dbg !664, !tbaa !192
  %call1 = tail call i32 @pthread_cond_signal(ptr noundef nonnull @maintenance_cond) #18, !dbg !665
  %call2 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @maintenance_lock) #18, !dbg !666
  %0 = load i64, ptr @maintenance_tid, align 8, !dbg !667, !tbaa !321
  %call3 = tail call i32 @pthread_join(i64 noundef %0, ptr noundef null) #18, !dbg !668
  ret void, !dbg !669
}

; Function Attrs: nounwind
declare !dbg !670 i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #6

declare !dbg !671 i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noalias ptr @assoc_get_iterator() local_unnamed_addr #0 !dbg !675 {
entry:
  %call = tail call noalias dereferenceable_or_null(32) ptr @calloc(i64 noundef 1, i64 noundef 32) #15, !dbg !680
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !679, metadata !DIExpression()), !dbg !681
  %cmp = icmp eq ptr %call, null, !dbg !682
  br i1 %cmp, label %cleanup, label %if.end, !dbg !684

if.end:                                           ; preds = %entry
  %call1 = tail call i32 @pthread_mutex_trylock(ptr noundef nonnull @maintenance_lock) #18, !dbg !685
  %cmp2 = icmp eq i32 %call1, 0, !dbg !687
  %call. = select i1 %cmp2, ptr %call, ptr null, !dbg !688
  br label %cleanup, !dbg !688

cleanup:                                          ; preds = %if.end, %entry
  %retval.0 = phi ptr [ null, %entry ], [ %call., %if.end ], !dbg !681
  ret ptr %retval.0, !dbg !689
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef zeroext i1 @assoc_iterate(ptr nocapture noundef %iterp, ptr nocapture noundef writeonly %it) local_unnamed_addr #0 !dbg !690 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %iterp, metadata !694, metadata !DIExpression()), !dbg !697
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !695, metadata !DIExpression()), !dbg !697
  tail call void @llvm.dbg.value(metadata ptr %iterp, metadata !696, metadata !DIExpression()), !dbg !697
  store ptr null, ptr %it, align 8, !dbg !698, !tbaa !201
  %bucket_locked = getelementptr inbounds i8, ptr %iterp, i64 24, !dbg !699
  %0 = load i8, ptr %bucket_locked, align 8, !dbg !699, !tbaa !701, !range !703, !noundef !704
  %tobool = trunc nuw i8 %0 to i1, !dbg !699
  br i1 %tobool, label %if.then, label %if.end9, !dbg !705

if.then:                                          ; preds = %entry
  %next = getelementptr inbounds i8, ptr %iterp, i64 16, !dbg !706
  %1 = load ptr, ptr %next, align 8, !dbg !706, !tbaa !709
  %cmp.not = icmp eq ptr %1, null, !dbg !710
  br i1 %cmp.not, label %if.else, label %if.then1, !dbg !711

if.then1:                                         ; preds = %if.then
  %it3 = getelementptr inbounds i8, ptr %iterp, i64 8, !dbg !712
  store ptr %1, ptr %it3, align 8, !dbg !714, !tbaa !715
  %h_next = getelementptr inbounds i8, ptr %1, i64 16, !dbg !716
  %2 = load ptr, ptr %h_next, align 8, !dbg !716, !tbaa !201
  store ptr %2, ptr %next, align 8, !dbg !717, !tbaa !709
  br label %if.end, !dbg !718

if.else:                                          ; preds = %if.then
  %3 = load i64, ptr %iterp, align 8, !dbg !719, !tbaa !721
  %conv = trunc i64 %3 to i32, !dbg !722
  tail call void @item_unlock(i32 noundef %conv) #18, !dbg !723
  %4 = load i64, ptr %iterp, align 8, !dbg !724, !tbaa !721
  %inc = add i64 %4, 1, !dbg !724
  store i64 %inc, ptr %iterp, align 8, !dbg !724, !tbaa !721
  store i8 0, ptr %bucket_locked, align 8, !dbg !725, !tbaa !701
  br label %if.end

if.end:                                           ; preds = %if.else, %if.then1
  store ptr %1, ptr %it, align 8, !dbg !726, !tbaa !201
  br label %cleanup, !dbg !727

if.end9:                                          ; preds = %entry
  %5 = load i64, ptr %iterp, align 8, !dbg !728, !tbaa !721
  %6 = load i32, ptr @hashpower, align 4, !dbg !730, !tbaa !192
  %sh_prom = zext nneg i32 %6 to i64, !dbg !730
  %shl = shl nuw i64 1, %sh_prom, !dbg !730
  %cmp11.not = icmp eq i64 %5, %shl, !dbg !731
  br i1 %cmp11.not, label %cleanup, label %if.then13, !dbg !732

if.then13:                                        ; preds = %if.end9
  %conv15 = trunc i64 %5 to i32, !dbg !733
  tail call void @item_lock(i32 noundef %conv15) #18, !dbg !735
  store i8 1, ptr %bucket_locked, align 8, !dbg !736, !tbaa !701
  %7 = load ptr, ptr @primary_hashtable, align 8, !dbg !737, !tbaa !201
  %8 = load i64, ptr %iterp, align 8, !dbg !738, !tbaa !721
  %arrayidx = getelementptr inbounds ptr, ptr %7, i64 %8, !dbg !737
  %9 = load ptr, ptr %arrayidx, align 8, !dbg !737, !tbaa !201
  %it18 = getelementptr inbounds i8, ptr %iterp, i64 8, !dbg !739
  store ptr %9, ptr %it18, align 8, !dbg !740, !tbaa !715
  %cmp20.not = icmp eq ptr %9, null, !dbg !741
  br i1 %cmp20.not, label %if.else27, label %if.then22, !dbg !743

if.then22:                                        ; preds = %if.then13
  %h_next24 = getelementptr inbounds i8, ptr %9, i64 16, !dbg !744
  %10 = load ptr, ptr %h_next24, align 8, !dbg !744, !tbaa !201
  %next25 = getelementptr inbounds i8, ptr %iterp, i64 16, !dbg !746
  store ptr %10, ptr %next25, align 8, !dbg !747, !tbaa !709
  store ptr %9, ptr %it, align 8, !dbg !748, !tbaa !201
  br label %cleanup, !dbg !749

if.else27:                                        ; preds = %if.then13
  %conv29 = trunc i64 %8 to i32, !dbg !750
  tail call void @item_unlock(i32 noundef %conv29) #18, !dbg !752
  store i8 0, ptr %bucket_locked, align 8, !dbg !753, !tbaa !701
  %11 = load i64, ptr %iterp, align 8, !dbg !754, !tbaa !721
  %inc32 = add i64 %11, 1, !dbg !754
  store i64 %inc32, ptr %iterp, align 8, !dbg !754, !tbaa !721
  br label %cleanup

cleanup:                                          ; preds = %if.else27, %if.then22, %if.end9, %if.end
  %retval.0 = phi i1 [ true, %if.end ], [ false, %if.end9 ], [ true, %if.then22 ], [ true, %if.else27 ], !dbg !697
  ret i1 %retval.0, !dbg !755
}

declare !dbg !756 void @item_unlock(i32 noundef) local_unnamed_addr #4

declare !dbg !759 void @item_lock(i32 noundef) local_unnamed_addr #4

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @assoc_iterate_final(ptr nocapture noundef %iterp) local_unnamed_addr #0 !dbg !760 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %iterp, metadata !764, metadata !DIExpression()), !dbg !766
  tail call void @llvm.dbg.value(metadata ptr %iterp, metadata !765, metadata !DIExpression()), !dbg !766
  %bucket_locked = getelementptr inbounds i8, ptr %iterp, i64 24, !dbg !767
  %0 = load i8, ptr %bucket_locked, align 8, !dbg !767, !tbaa !701, !range !703, !noundef !704
  %tobool = trunc nuw i8 %0 to i1, !dbg !767
  br i1 %tobool, label %if.then, label %if.end, !dbg !769

if.then:                                          ; preds = %entry
  %1 = load i64, ptr %iterp, align 8, !dbg !770, !tbaa !721
  %conv = trunc i64 %1 to i32, !dbg !772
  tail call void @item_unlock(i32 noundef %conv) #18, !dbg !773
  br label %if.end, !dbg !774

if.end:                                           ; preds = %if.then, %entry
  %call = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @maintenance_lock) #18, !dbg !775
  tail call void @free(ptr noundef nonnull %iterp) #18, !dbg !776
  ret void, !dbg !777
}

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !778 void @free(ptr allocptr nocapture noundef) local_unnamed_addr #10

; Function Attrs: nounwind
declare !dbg !779 i64 @__isoc23_strtol(ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #6

declare !dbg !783 ptr @item_trylock(i32 noundef) local_unnamed_addr #4

declare !dbg !786 i32 @usleep(i32 noundef) local_unnamed_addr #4

declare !dbg !791 void @item_trylock_unlock(ptr noundef) local_unnamed_addr #4

declare !dbg !792 i32 @pthread_cond_wait(ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !797 void @pause_threads(i32 noundef) local_unnamed_addr #4

; Function Attrs: nofree nounwind
declare noundef i64 @fwrite(ptr nocapture noundef, i64 noundef, i64 noundef, ptr nocapture noundef) local_unnamed_addr #11

; Function Attrs: nofree nounwind willreturn memory(argmem: read)
declare i32 @bcmp(ptr nocapture, ptr nocapture, i64) local_unnamed_addr #12

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #13

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #14 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #13

attributes #0 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nofree nounwind sanitize_thread memory(read, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nofree nounwind sanitize_thread memory(readwrite, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { nofree nounwind memory(read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { nofree nounwind }
attributes #12 = { nofree nounwind willreturn memory(argmem: read) }
attributes #13 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #14 = { nounwind uwtable }
attributes #15 = { nounwind allocsize(0,1) }
attributes #16 = { cold }
attributes #17 = { noreturn nounwind }
attributes #18 = { nounwind }
attributes #19 = { nobuiltin }
attributes #20 = { cold nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!173, !174, !175, !176, !177, !178, !179}
!llvm.ident = !{!180}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "hashpower", scope: !2, file: !3, line: 32, type: !7, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !13, globals: !63, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "assoc.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "ed0f236eb8db18989c3d9732f81a2258")
!4 = !{!5}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "pause_thread_types", file: !6, line: 253, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "./memcached.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "a52021954a5d6b153b5bc084e2fbff2b")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12}
!9 = !DIEnumerator(name: "PAUSE_WORKER_THREADS", value: 0)
!10 = !DIEnumerator(name: "PAUSE_ALL_THREADS", value: 1)
!11 = !DIEnumerator(name: "RESUME_ALL_THREADS", value: 2)
!12 = !DIEnumerator(name: "RESUME_WORKER_THREADS", value: 3)
!13 = !{!14, !19, !21, !22, !40, !62}
!14 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !15, line: 27, baseType: !16)
!15 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!16 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !17, line: 45, baseType: !18)
!17 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!18 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!19 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !20, size: 64)
!20 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!21 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!22 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !23, size: 64)
!23 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "assoc_iterator", file: !3, line: 297, size: 256, elements: !24)
!24 = !{!25, !26, !59, !60}
!25 = !DIDerivedType(tag: DW_TAG_member, name: "bucket", scope: !23, file: !3, line: 298, baseType: !14, size: 64)
!26 = !DIDerivedType(tag: DW_TAG_member, name: "it", scope: !23, file: !3, line: 299, baseType: !27, size: 64, offset: 64)
!27 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !28, size: 64)
!28 = !DIDerivedType(tag: DW_TAG_typedef, name: "item", file: !6, line: 616, baseType: !29)
!29 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_stritem", file: !6, line: 593, size: 384, elements: !30)
!30 = !{!31, !33, !34, !35, !38, !39, !41, !43, !46, !50, !51}
!31 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !29, file: !6, line: 595, baseType: !32, size: 64)
!32 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !29, size: 64)
!33 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !29, file: !6, line: 596, baseType: !32, size: 64, offset: 64)
!34 = !DIDerivedType(tag: DW_TAG_member, name: "h_next", scope: !29, file: !6, line: 598, baseType: !32, size: 64, offset: 128)
!35 = !DIDerivedType(tag: DW_TAG_member, name: "time", scope: !29, file: !6, line: 599, baseType: !36, size: 32, offset: 192)
!36 = !DIDerivedType(tag: DW_TAG_typedef, name: "rel_time_t", file: !37, line: 14, baseType: !7)
!37 = !DIFile(filename: "./logger.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "e743c4228b1e0bc1c91bec9cfd28d5ab")
!38 = !DIDerivedType(tag: DW_TAG_member, name: "exptime", scope: !29, file: !6, line: 600, baseType: !36, size: 32, offset: 224)
!39 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !29, file: !6, line: 601, baseType: !40, size: 32, offset: 256)
!40 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!41 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !29, file: !6, line: 602, baseType: !42, size: 16, offset: 288)
!42 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!43 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !29, file: !6, line: 603, baseType: !44, size: 16, offset: 304)
!44 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint16_t", file: !15, line: 25, baseType: !45)
!45 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint16_t", file: !17, line: 40, baseType: !42)
!46 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !29, file: !6, line: 604, baseType: !47, size: 8, offset: 320)
!47 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !15, line: 24, baseType: !48)
!48 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !17, line: 38, baseType: !49)
!49 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!50 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !29, file: !6, line: 605, baseType: !47, size: 8, offset: 328)
!51 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !29, file: !6, line: 611, baseType: !52, offset: 384)
!52 = !DICompositeType(tag: DW_TAG_array_type, baseType: !53, elements: !57)
!53 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !29, file: !6, line: 608, size: 64, elements: !54)
!54 = !{!55, !56}
!55 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !53, file: !6, line: 609, baseType: !14, size: 64)
!56 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !53, file: !6, line: 610, baseType: !20, size: 8)
!57 = !{!58}
!58 = !DISubrange(count: -1)
!59 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !23, file: !3, line: 300, baseType: !27, size: 64, offset: 128)
!60 = !DIDerivedType(tag: DW_TAG_member, name: "bucket_locked", scope: !23, file: !3, line: 301, baseType: !61, size: 8, offset: 192)
!61 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!62 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !19, size: 64)
!63 = !{!0, !64, !69, !71, !76, !78, !83, !87, !90, !92, !94, !96, !127, !162, !164, !169}
!64 = !DIGlobalVariableExpression(var: !65, expr: !DIExpression())
!65 = distinct !DIGlobalVariable(scope: null, file: !3, line: 61, type: !66, isLocal: true, isDefinition: true)
!66 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 216, elements: !67)
!67 = !{!68}
!68 = !DISubrange(count: 27)
!69 = !DIGlobalVariableExpression(var: !70, expr: !DIExpression())
!70 = distinct !DIGlobalVariable(name: "hash_bulk_move", scope: !2, file: !3, line: 195, type: !40, isLocal: false, isDefinition: true)
!71 = !DIGlobalVariableExpression(var: !72, expr: !DIExpression())
!72 = distinct !DIGlobalVariable(scope: null, file: !3, line: 270, type: !73, isLocal: true, isDefinition: true)
!73 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 200, elements: !74)
!74 = !{!75}
!75 = !DISubrange(count: 25)
!76 = !DIGlobalVariableExpression(var: !77, expr: !DIExpression())
!77 = distinct !DIGlobalVariable(scope: null, file: !3, line: 280, type: !73, isLocal: true, isDefinition: true)
!78 = !DIGlobalVariableExpression(var: !79, expr: !DIExpression())
!79 = distinct !DIGlobalVariable(scope: null, file: !3, line: 283, type: !80, isLocal: true, isDefinition: true)
!80 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 112, elements: !81)
!81 = !{!82}
!82 = !DISubrange(count: 14)
!83 = !DIGlobalVariableExpression(var: !84, expr: !DIExpression())
!84 = distinct !DIGlobalVariable(name: "maintenance_tid", scope: !2, file: !3, line: 266, type: !85, isLocal: true, isDefinition: true)
!85 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_t", file: !86, line: 27, baseType: !18)
!86 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h", directory: "", checksumkind: CSK_MD5, checksum: "8a5acdbeec491eca11cf81cb1ef77ea7")
!87 = !DIGlobalVariableExpression(var: !88, expr: !DIExpression())
!88 = distinct !DIGlobalVariable(name: "primary_hashtable", scope: !2, file: !3, line: 38, type: !89, isLocal: true, isDefinition: true)
!89 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !27, size: 64)
!90 = !DIGlobalVariableExpression(var: !91, expr: !DIExpression())
!91 = distinct !DIGlobalVariable(name: "expanding", scope: !2, file: !3, line: 47, type: !61, isLocal: true, isDefinition: true)
!92 = !DIGlobalVariableExpression(var: !93, expr: !DIExpression())
!93 = distinct !DIGlobalVariable(name: "expand_bucket", scope: !2, file: !3, line: 53, type: !14, isLocal: true, isDefinition: true)
!94 = !DIGlobalVariableExpression(var: !95, expr: !DIExpression())
!95 = distinct !DIGlobalVariable(name: "old_hashtable", scope: !2, file: !3, line: 44, type: !89, isLocal: true, isDefinition: true)
!96 = !DIGlobalVariableExpression(var: !97, expr: !DIExpression())
!97 = distinct !DIGlobalVariable(name: "maintenance_lock", scope: !2, file: !3, line: 29, type: !98, isLocal: true, isDefinition: true)
!98 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutex_t", file: !86, line: 72, baseType: !99)
!99 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !86, line: 67, size: 320, elements: !100)
!100 = !{!101, !121, !125}
!101 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !99, file: !86, line: 69, baseType: !102, size: 320)
!102 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_mutex_s", file: !103, line: 22, size: 320, elements: !104)
!103 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h", directory: "", checksumkind: CSK_MD5, checksum: "6b075eca9ab0e2d761b2afc4ecfab776")
!104 = !{!105, !106, !107, !108, !109, !110, !112, !113}
!105 = !DIDerivedType(tag: DW_TAG_member, name: "__lock", scope: !102, file: !103, line: 24, baseType: !40, size: 32)
!106 = !DIDerivedType(tag: DW_TAG_member, name: "__count", scope: !102, file: !103, line: 25, baseType: !7, size: 32, offset: 32)
!107 = !DIDerivedType(tag: DW_TAG_member, name: "__owner", scope: !102, file: !103, line: 26, baseType: !40, size: 32, offset: 64)
!108 = !DIDerivedType(tag: DW_TAG_member, name: "__nusers", scope: !102, file: !103, line: 28, baseType: !7, size: 32, offset: 96)
!109 = !DIDerivedType(tag: DW_TAG_member, name: "__kind", scope: !102, file: !103, line: 32, baseType: !40, size: 32, offset: 128)
!110 = !DIDerivedType(tag: DW_TAG_member, name: "__spins", scope: !102, file: !103, line: 34, baseType: !111, size: 16, offset: 160)
!111 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!112 = !DIDerivedType(tag: DW_TAG_member, name: "__elision", scope: !102, file: !103, line: 35, baseType: !111, size: 16, offset: 176)
!113 = !DIDerivedType(tag: DW_TAG_member, name: "__list", scope: !102, file: !103, line: 36, baseType: !114, size: 128, offset: 192)
!114 = !DIDerivedType(tag: DW_TAG_typedef, name: "__pthread_list_t", file: !115, line: 55, baseType: !116)
!115 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h", directory: "", checksumkind: CSK_MD5, checksum: "b9a7199822bce372686baacd32a9f4f3")
!116 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_internal_list", file: !115, line: 51, size: 128, elements: !117)
!117 = !{!118, !120}
!118 = !DIDerivedType(tag: DW_TAG_member, name: "__prev", scope: !116, file: !115, line: 53, baseType: !119, size: 64)
!119 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !116, size: 64)
!120 = !DIDerivedType(tag: DW_TAG_member, name: "__next", scope: !116, file: !115, line: 54, baseType: !119, size: 64, offset: 64)
!121 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !99, file: !86, line: 70, baseType: !122, size: 320)
!122 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 320, elements: !123)
!123 = !{!124}
!124 = !DISubrange(count: 40)
!125 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !99, file: !86, line: 71, baseType: !126, size: 64)
!126 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!127 = !DIGlobalVariableExpression(var: !128, expr: !DIExpression())
!128 = distinct !DIGlobalVariable(name: "maintenance_cond", scope: !2, file: !3, line: 28, type: !129, isLocal: true, isDefinition: true)
!129 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_cond_t", file: !86, line: 80, baseType: !130)
!130 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !86, line: 75, size: 384, elements: !131)
!131 = !{!132, !156, !160}
!132 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !130, file: !86, line: 77, baseType: !133, size: 384)
!133 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_cond_s", file: !115, line: 94, size: 384, elements: !134)
!134 = !{!135, !147, !148, !152, !153, !154, !155}
!135 = !DIDerivedType(tag: DW_TAG_member, name: "__wseq", scope: !133, file: !115, line: 96, baseType: !136, size: 64)
!136 = !DIDerivedType(tag: DW_TAG_typedef, name: "__atomic_wide_counter", file: !137, line: 33, baseType: !138)
!137 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h", directory: "", checksumkind: CSK_MD5, checksum: "d1ec99b0f6e36c0a42ac284d459cbd38")
!138 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !137, line: 25, size: 64, elements: !139)
!139 = !{!140, !142}
!140 = !DIDerivedType(tag: DW_TAG_member, name: "__value64", scope: !138, file: !137, line: 27, baseType: !141, size: 64)
!141 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!142 = !DIDerivedType(tag: DW_TAG_member, name: "__value32", scope: !138, file: !137, line: 32, baseType: !143, size: 64)
!143 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !138, file: !137, line: 28, size: 64, elements: !144)
!144 = !{!145, !146}
!145 = !DIDerivedType(tag: DW_TAG_member, name: "__low", scope: !143, file: !137, line: 30, baseType: !7, size: 32)
!146 = !DIDerivedType(tag: DW_TAG_member, name: "__high", scope: !143, file: !137, line: 31, baseType: !7, size: 32, offset: 32)
!147 = !DIDerivedType(tag: DW_TAG_member, name: "__g1_start", scope: !133, file: !115, line: 97, baseType: !136, size: 64, offset: 64)
!148 = !DIDerivedType(tag: DW_TAG_member, name: "__g_refs", scope: !133, file: !115, line: 98, baseType: !149, size: 64, offset: 128)
!149 = !DICompositeType(tag: DW_TAG_array_type, baseType: !7, size: 64, elements: !150)
!150 = !{!151}
!151 = !DISubrange(count: 2)
!152 = !DIDerivedType(tag: DW_TAG_member, name: "__g_size", scope: !133, file: !115, line: 99, baseType: !149, size: 64, offset: 192)
!153 = !DIDerivedType(tag: DW_TAG_member, name: "__g1_orig_size", scope: !133, file: !115, line: 100, baseType: !7, size: 32, offset: 256)
!154 = !DIDerivedType(tag: DW_TAG_member, name: "__wrefs", scope: !133, file: !115, line: 101, baseType: !7, size: 32, offset: 288)
!155 = !DIDerivedType(tag: DW_TAG_member, name: "__g_signals", scope: !133, file: !115, line: 102, baseType: !149, size: 64, offset: 320)
!156 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !130, file: !86, line: 78, baseType: !157, size: 384)
!157 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 384, elements: !158)
!158 = !{!159}
!159 = !DISubrange(count: 48)
!160 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !130, file: !86, line: 79, baseType: !161, size: 64)
!161 = !DIBasicType(name: "long long", size: 64, encoding: DW_ATE_signed)
!162 = !DIGlobalVariableExpression(var: !163, expr: !DIExpression())
!163 = distinct !DIGlobalVariable(scope: null, file: !3, line: 232, type: !66, isLocal: true, isDefinition: true)
!164 = !DIGlobalVariableExpression(var: !165, expr: !DIExpression())
!165 = distinct !DIGlobalVariable(scope: null, file: !3, line: 128, type: !166, isLocal: true, isDefinition: true)
!166 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 248, elements: !167)
!167 = !{!168}
!168 = !DISubrange(count: 31)
!169 = !DIGlobalVariableExpression(var: !170, expr: !DIExpression())
!170 = distinct !DIGlobalVariable(name: "do_run_maintenance_thread", scope: !2, file: !3, line: 192, type: !171, isLocal: true, isDefinition: true)
!171 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !40)
!172 = !DIGlobalVariableExpression(var: !91, expr: !DIExpression(DW_OP_deref_size, 1, DW_OP_constu, 1, DW_OP_mul, DW_OP_constu, 0, DW_OP_plus, DW_OP_stack_value))
!173 = !{i32 7, !"Dwarf Version", i32 5}
!174 = !{i32 2, !"Debug Info Version", i32 3}
!175 = !{i32 1, !"wchar_size", i32 4}
!176 = !{i32 8, !"PIC Level", i32 2}
!177 = !{i32 7, !"PIE Level", i32 2}
!178 = !{i32 7, !"uwtable", i32 2}
!179 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!180 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!181 = distinct !DISubprogram(name: "assoc_init", scope: !3, file: !3, line: 55, type: !182, scopeLine: 55, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !185)
!182 = !DISubroutineType(types: !183)
!183 = !{null, !184}
!184 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !40)
!185 = !{!186}
!186 = !DILocalVariable(name: "hashtable_init", arg: 1, scope: !181, file: !3, line: 55, type: !184)
!187 = !DILocation(line: 0, scope: !181)
!188 = !DILocation(line: 56, column: 9, scope: !189)
!189 = distinct !DILexicalBlock(scope: !181, file: !3, line: 56, column: 9)
!190 = !DILocation(line: 56, column: 9, scope: !181)
!191 = !DILocation(line: 59, column: 32, scope: !181)
!192 = !{!193, !193, i64 0}
!193 = !{!"int", !194, i64 0}
!194 = !{!"omnipotent char", !195, i64 0}
!195 = !{!"Simple C/C++ TBAA"}
!196 = !DILocation(line: 57, column: 19, scope: !197)
!197 = distinct !DILexicalBlock(scope: !189, file: !3, line: 56, column: 25)
!198 = !DILocation(line: 58, column: 5, scope: !197)
!199 = !DILocation(line: 59, column: 25, scope: !181)
!200 = !DILocation(line: 59, column: 23, scope: !181)
!201 = !{!202, !202, i64 0}
!202 = !{!"any pointer", !194, i64 0}
!203 = !DILocation(line: 60, column: 11, scope: !204)
!204 = distinct !DILexicalBlock(scope: !181, file: !3, line: 60, column: 9)
!205 = !DILocation(line: 60, column: 9, scope: !181)
!206 = !DILocation(line: 61, column: 17, scope: !207)
!207 = distinct !DILexicalBlock(scope: !204, file: !3, line: 60, column: 30)
!208 = !DILocation(line: 61, column: 9, scope: !207)
!209 = !DILocation(line: 62, column: 9, scope: !207)
!210 = !DILocation(line: 64, column: 5, scope: !181)
!211 = !DILocation(line: 65, column: 36, scope: !181)
!212 = !DILocation(line: 65, column: 34, scope: !181)
!213 = !{!214, !193, i64 40}
!214 = !{!"stats_state", !215, i64 0, !215, i64 8, !215, i64 16, !215, i64 24, !193, i64 32, !193, i64 36, !193, i64 40, !193, i64 44, !216, i64 48, !216, i64 49, !216, i64 50, !216, i64 51}
!215 = !{!"long", !194, i64 0}
!216 = !{!"_Bool", !194, i64 0}
!217 = !DILocation(line: 66, column: 30, scope: !181)
!218 = !DILocation(line: 66, column: 50, scope: !181)
!219 = !DILocation(line: 66, column: 28, scope: !181)
!220 = !{!214, !215, i64 24}
!221 = !DILocation(line: 67, column: 5, scope: !181)
!222 = !DILocation(line: 68, column: 1, scope: !181)
!223 = !DISubprogram(name: "calloc", scope: !224, file: !224, line: 675, type: !225, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!224 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!225 = !DISubroutineType(types: !226)
!226 = !{!21, !227, !227}
!227 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !228, line: 18, baseType: !18)
!228 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!229 = !DISubprogram(name: "fprintf", scope: !230, file: !230, line: 357, type: !231, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!230 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "1e435c46987a169d9f9186f63a512303")
!231 = !DISubroutineType(types: !232)
!232 = !{!40, !233, !287, null}
!233 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !234)
!234 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !235, size: 64)
!235 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !236, line: 7, baseType: !237)
!236 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!237 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !238, line: 49, size: 1728, elements: !239)
!238 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "7a6d4a00a37ee6b9a40cd04bd01f5d00")
!239 = !{!240, !241, !242, !243, !244, !245, !246, !247, !248, !249, !250, !251, !252, !255, !257, !258, !259, !261, !262, !264, !268, !271, !273, !276, !279, !280, !281, !282, !283}
!240 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !237, file: !238, line: 51, baseType: !40, size: 32)
!241 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !237, file: !238, line: 54, baseType: !19, size: 64, offset: 64)
!242 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !237, file: !238, line: 55, baseType: !19, size: 64, offset: 128)
!243 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !237, file: !238, line: 56, baseType: !19, size: 64, offset: 192)
!244 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !237, file: !238, line: 57, baseType: !19, size: 64, offset: 256)
!245 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !237, file: !238, line: 58, baseType: !19, size: 64, offset: 320)
!246 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !237, file: !238, line: 59, baseType: !19, size: 64, offset: 384)
!247 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !237, file: !238, line: 60, baseType: !19, size: 64, offset: 448)
!248 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !237, file: !238, line: 61, baseType: !19, size: 64, offset: 512)
!249 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !237, file: !238, line: 64, baseType: !19, size: 64, offset: 576)
!250 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !237, file: !238, line: 65, baseType: !19, size: 64, offset: 640)
!251 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !237, file: !238, line: 66, baseType: !19, size: 64, offset: 704)
!252 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !237, file: !238, line: 68, baseType: !253, size: 64, offset: 768)
!253 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !254, size: 64)
!254 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !238, line: 36, flags: DIFlagFwdDecl)
!255 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !237, file: !238, line: 70, baseType: !256, size: 64, offset: 832)
!256 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !237, size: 64)
!257 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !237, file: !238, line: 72, baseType: !40, size: 32, offset: 896)
!258 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !237, file: !238, line: 73, baseType: !40, size: 32, offset: 928)
!259 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !237, file: !238, line: 74, baseType: !260, size: 64, offset: 960)
!260 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !17, line: 152, baseType: !126)
!261 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !237, file: !238, line: 77, baseType: !42, size: 16, offset: 1024)
!262 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !237, file: !238, line: 78, baseType: !263, size: 8, offset: 1040)
!263 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!264 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !237, file: !238, line: 79, baseType: !265, size: 8, offset: 1048)
!265 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 8, elements: !266)
!266 = !{!267}
!267 = !DISubrange(count: 1)
!268 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !237, file: !238, line: 81, baseType: !269, size: 64, offset: 1088)
!269 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !270, size: 64)
!270 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !238, line: 43, baseType: null)
!271 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !237, file: !238, line: 89, baseType: !272, size: 64, offset: 1152)
!272 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !17, line: 153, baseType: !126)
!273 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !237, file: !238, line: 91, baseType: !274, size: 64, offset: 1216)
!274 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !275, size: 64)
!275 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !238, line: 37, flags: DIFlagFwdDecl)
!276 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !237, file: !238, line: 92, baseType: !277, size: 64, offset: 1280)
!277 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !278, size: 64)
!278 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !238, line: 38, flags: DIFlagFwdDecl)
!279 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !237, file: !238, line: 93, baseType: !256, size: 64, offset: 1344)
!280 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !237, file: !238, line: 94, baseType: !21, size: 64, offset: 1408)
!281 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !237, file: !238, line: 95, baseType: !227, size: 64, offset: 1472)
!282 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !237, file: !238, line: 96, baseType: !40, size: 32, offset: 1536)
!283 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !237, file: !238, line: 98, baseType: !284, size: 160, offset: 1568)
!284 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 160, elements: !285)
!285 = !{!286}
!286 = !DISubrange(count: 20)
!287 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !288)
!288 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !289, size: 64)
!289 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!290 = !DISubprogram(name: "exit", scope: !224, file: !224, line: 756, type: !291, flags: DIFlagPrototyped | DIFlagNoReturn, spFlags: DISPFlagOptimized)
!291 = !DISubroutineType(types: !292)
!292 = !{null, !40}
!293 = !DISubprogram(name: "STATS_LOCK", scope: !6, file: !6, line: 1026, type: !294, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!294 = !DISubroutineType(types: !295)
!295 = !{null}
!296 = !DISubprogram(name: "STATS_UNLOCK", scope: !6, file: !6, line: 1027, type: !294, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!297 = distinct !DISubprogram(name: "assoc_find", scope: !3, file: !3, line: 70, type: !298, scopeLine: 70, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !304)
!298 = !DISubroutineType(types: !299)
!299 = !{!27, !288, !300, !301}
!300 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !227)
!301 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !302)
!302 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !15, line: 26, baseType: !303)
!303 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !17, line: 42, baseType: !7)
!304 = !{!305, !306, !307, !308, !309, !310}
!305 = !DILocalVariable(name: "key", arg: 1, scope: !297, file: !3, line: 70, type: !288)
!306 = !DILocalVariable(name: "nkey", arg: 2, scope: !297, file: !3, line: 70, type: !300)
!307 = !DILocalVariable(name: "hv", arg: 3, scope: !297, file: !3, line: 70, type: !301)
!308 = !DILocalVariable(name: "it", scope: !297, file: !3, line: 71, type: !27)
!309 = !DILocalVariable(name: "oldbucket", scope: !297, file: !3, line: 72, type: !14)
!310 = !DILocalVariable(name: "ret", scope: !297, file: !3, line: 82, type: !27)
!311 = !DILocation(line: 0, scope: !297)
!312 = !DILocation(line: 74, column: 9, scope: !313)
!313 = distinct !DILexicalBlock(scope: !297, file: !3, line: 74, column: 9)
!314 = !DILocation(line: 79, column: 37, scope: !315)
!315 = distinct !DILexicalBlock(scope: !313, file: !3, line: 78, column: 12)
!316 = !DILocation(line: 0, scope: !313)
!317 = !DILocation(line: 74, column: 19, scope: !313)
!318 = !DILocation(line: 75, column: 28, scope: !313)
!319 = !DILocation(line: 75, column: 26, scope: !313)
!320 = !DILocation(line: 75, column: 57, scope: !313)
!321 = !{!215, !215, i64 0}
!322 = !DILocation(line: 75, column: 54, scope: !313)
!323 = !DILocation(line: 74, column: 9, scope: !297)
!324 = !DILocation(line: 77, column: 14, scope: !325)
!325 = distinct !DILexicalBlock(scope: !313, file: !3, line: 76, column: 5)
!326 = !DILocation(line: 78, column: 5, scope: !325)
!327 = !DILocation(line: 79, column: 14, scope: !315)
!328 = !DILocation(line: 79, column: 35, scope: !315)
!329 = !DILocation(line: 86, column: 5, scope: !297)
!330 = !DILocation(line: 87, column: 26, scope: !331)
!331 = distinct !DILexicalBlock(scope: !332, file: !3, line: 87, column: 13)
!332 = distinct !DILexicalBlock(scope: !297, file: !3, line: 86, column: 16)
!333 = !{!194, !194, i64 0}
!334 = !DILocation(line: 87, column: 22, scope: !331)
!335 = !DILocation(line: 87, column: 19, scope: !331)
!336 = !DILocation(line: 87, column: 32, scope: !331)
!337 = !DILocation(line: 87, column: 48, scope: !331)
!338 = !{!339, !339, i64 0}
!339 = !{!"short", !194, i64 0}
!340 = !DILocation(line: 87, column: 36, scope: !331)
!341 = !DILocation(line: 87, column: 68, scope: !331)
!342 = !DILocation(line: 87, column: 13, scope: !332)
!343 = !DILocation(line: 91, column: 18, scope: !332)
!344 = distinct !{!344, !329, !345, !346}
!345 = !DILocation(line: 95, column: 5, scope: !297)
!346 = !{!"llvm.loop.mustprogress"}
!347 = !DILocation(line: 97, column: 5, scope: !297)
!348 = distinct !DISubprogram(name: "assoc_start_expand", scope: !3, file: !3, line: 143, type: !349, scopeLine: 143, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !351)
!349 = !DISubroutineType(types: !350)
!350 = !{null, !14}
!351 = !{!352}
!352 = !DILocalVariable(name: "curr_items", arg: 1, scope: !348, file: !3, line: 143, type: !14)
!353 = !DILocation(line: 0, scope: !348)
!354 = !DILocation(line: 144, column: 9, scope: !355)
!355 = distinct !DILexicalBlock(scope: !348, file: !3, line: 144, column: 9)
!356 = !DILocation(line: 144, column: 50, scope: !355)
!357 = !DILocation(line: 144, column: 9, scope: !348)
!358 = !DILocation(line: 145, column: 27, scope: !359)
!359 = distinct !DILexicalBlock(scope: !360, file: !3, line: 145, column: 13)
!360 = distinct !DILexicalBlock(scope: !355, file: !3, line: 144, column: 56)
!361 = !DILocation(line: 145, column: 47, scope: !359)
!362 = !DILocation(line: 145, column: 52, scope: !359)
!363 = !DILocation(line: 145, column: 24, scope: !359)
!364 = !DILocation(line: 145, column: 56, scope: !359)
!365 = !DILocation(line: 146, column: 13, scope: !366)
!366 = distinct !DILexicalBlock(scope: !359, file: !3, line: 145, column: 86)
!367 = !DILocation(line: 147, column: 9, scope: !366)
!368 = !DILocation(line: 148, column: 9, scope: !360)
!369 = !DILocation(line: 149, column: 5, scope: !360)
!370 = !DILocation(line: 150, column: 1, scope: !348)
!371 = !DISubprogram(name: "pthread_mutex_trylock", scope: !372, file: !372, line: 790, type: !373, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!372 = !DIFile(filename: "/usr/include/pthread.h", directory: "", checksumkind: CSK_MD5, checksum: "cbcd748b3d3ecaa7356dc2925b45d819")
!373 = !DISubroutineType(types: !374)
!374 = !{!40, !375}
!375 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !98, size: 64)
!376 = !DISubprogram(name: "pthread_cond_signal", scope: !372, file: !372, line: 1121, type: !377, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!377 = !DISubroutineType(types: !378)
!378 = !{!40, !379}
!379 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !129, size: 64)
!380 = !DISubprogram(name: "pthread_mutex_unlock", scope: !372, file: !372, line: 835, type: !373, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!381 = distinct !DISubprogram(name: "assoc_insert", scope: !3, file: !3, line: 153, type: !382, scopeLine: 153, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !384)
!382 = !DISubroutineType(types: !383)
!383 = !{!40, !27, !301}
!384 = !{!385, !386, !387}
!385 = !DILocalVariable(name: "it", arg: 1, scope: !381, file: !3, line: 153, type: !27)
!386 = !DILocalVariable(name: "hv", arg: 2, scope: !381, file: !3, line: 153, type: !301)
!387 = !DILocalVariable(name: "oldbucket", scope: !381, file: !3, line: 154, type: !14)
!388 = !DILocation(line: 0, scope: !381)
!389 = !DILocation(line: 158, column: 9, scope: !390)
!390 = distinct !DILexicalBlock(scope: !381, file: !3, line: 158, column: 9)
!391 = !DILocation(line: 164, column: 45, scope: !392)
!392 = distinct !DILexicalBlock(scope: !390, file: !3, line: 163, column: 12)
!393 = !DILocation(line: 0, scope: !390)
!394 = !DILocation(line: 158, column: 19, scope: !390)
!395 = !DILocation(line: 159, column: 28, scope: !390)
!396 = !DILocation(line: 159, column: 26, scope: !390)
!397 = !DILocation(line: 159, column: 57, scope: !390)
!398 = !DILocation(line: 159, column: 54, scope: !390)
!399 = !DILocation(line: 158, column: 9, scope: !381)
!400 = !DILocation(line: 161, column: 22, scope: !401)
!401 = distinct !DILexicalBlock(scope: !390, file: !3, line: 160, column: 5)
!402 = !DILocation(line: 163, column: 5, scope: !401)
!403 = !DILocation(line: 164, column: 22, scope: !392)
!404 = !DILocation(line: 164, column: 43, scope: !392)
!405 = !DILocation(line: 169, column: 5, scope: !381)
!406 = distinct !DISubprogram(name: "assoc_delete", scope: !3, file: !3, line: 172, type: !407, scopeLine: 172, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !409)
!407 = !DISubroutineType(types: !408)
!408 = !{null, !288, !300, !301}
!409 = !{!410, !411, !412, !413, !414}
!410 = !DILocalVariable(name: "key", arg: 1, scope: !406, file: !3, line: 172, type: !288)
!411 = !DILocalVariable(name: "nkey", arg: 2, scope: !406, file: !3, line: 172, type: !300)
!412 = !DILocalVariable(name: "hv", arg: 3, scope: !406, file: !3, line: 172, type: !301)
!413 = !DILocalVariable(name: "before", scope: !406, file: !3, line: 173, type: !89)
!414 = !DILocalVariable(name: "nxt", scope: !415, file: !3, line: 176, type: !27)
!415 = distinct !DILexicalBlock(scope: !416, file: !3, line: 175, column: 18)
!416 = distinct !DILexicalBlock(scope: !406, file: !3, line: 175, column: 9)
!417 = !DILocation(line: 0, scope: !406)
!418 = !DILocalVariable(name: "key", arg: 1, scope: !419, file: !3, line: 103, type: !288)
!419 = distinct !DISubprogram(name: "_hashitem_before", scope: !3, file: !3, line: 103, type: !420, scopeLine: 103, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !422)
!420 = !DISubroutineType(types: !421)
!421 = !{!89, !288, !300, !301}
!422 = !{!418, !423, !424, !425, !426}
!423 = !DILocalVariable(name: "nkey", arg: 2, scope: !419, file: !3, line: 103, type: !300)
!424 = !DILocalVariable(name: "hv", arg: 3, scope: !419, file: !3, line: 103, type: !301)
!425 = !DILocalVariable(name: "pos", scope: !419, file: !3, line: 104, type: !89)
!426 = !DILocalVariable(name: "oldbucket", scope: !419, file: !3, line: 105, type: !14)
!427 = !DILocation(line: 0, scope: !419, inlinedAt: !428)
!428 = distinct !DILocation(line: 173, column: 21, scope: !406)
!429 = !DILocation(line: 107, column: 9, scope: !430, inlinedAt: !428)
!430 = distinct !DILexicalBlock(scope: !419, file: !3, line: 107, column: 9)
!431 = !DILocation(line: 112, column: 39, scope: !432, inlinedAt: !428)
!432 = distinct !DILexicalBlock(scope: !430, file: !3, line: 111, column: 12)
!433 = !DILocation(line: 0, scope: !430, inlinedAt: !428)
!434 = !DILocation(line: 107, column: 19, scope: !430, inlinedAt: !428)
!435 = !DILocation(line: 108, column: 28, scope: !430, inlinedAt: !428)
!436 = !DILocation(line: 108, column: 26, scope: !430, inlinedAt: !428)
!437 = !DILocation(line: 108, column: 57, scope: !430, inlinedAt: !428)
!438 = !DILocation(line: 108, column: 54, scope: !430, inlinedAt: !428)
!439 = !DILocation(line: 107, column: 9, scope: !419, inlinedAt: !428)
!440 = !DILocation(line: 110, column: 16, scope: !441, inlinedAt: !428)
!441 = distinct !DILexicalBlock(scope: !430, file: !3, line: 109, column: 5)
!442 = !DILocation(line: 111, column: 5, scope: !441, inlinedAt: !428)
!443 = !DILocation(line: 112, column: 16, scope: !432, inlinedAt: !428)
!444 = !DILocation(line: 112, column: 37, scope: !432, inlinedAt: !428)
!445 = !DILocation(line: 115, column: 12, scope: !419, inlinedAt: !428)
!446 = !DILocation(line: 115, column: 17, scope: !419, inlinedAt: !428)
!447 = !DILocation(line: 115, column: 38, scope: !419, inlinedAt: !428)
!448 = !DILocation(line: 115, column: 30, scope: !419, inlinedAt: !428)
!449 = !DILocation(line: 115, column: 27, scope: !419, inlinedAt: !428)
!450 = !DILocation(line: 115, column: 44, scope: !419, inlinedAt: !428)
!451 = !DILocation(line: 115, column: 59, scope: !419, inlinedAt: !428)
!452 = !DILocation(line: 115, column: 47, scope: !419, inlinedAt: !428)
!453 = !DILocation(line: 115, column: 5, scope: !419, inlinedAt: !428)
!454 = !DILocation(line: 116, column: 24, scope: !455, inlinedAt: !428)
!455 = distinct !DILexicalBlock(scope: !419, file: !3, line: 115, column: 83)
!456 = distinct !{!456, !453, !457, !346}
!457 = !DILocation(line: 117, column: 5, scope: !419, inlinedAt: !428)
!458 = !DILocation(line: 181, column: 26, scope: !415)
!459 = !DILocation(line: 0, scope: !415)
!460 = !DILocation(line: 182, column: 27, scope: !415)
!461 = !DILocation(line: 183, column: 17, scope: !415)
!462 = !DILocation(line: 189, column: 1, scope: !406)
!463 = distinct !DISubprogram(name: "start_assoc_maintenance_thread", scope: !3, file: !3, line: 268, type: !464, scopeLine: 268, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !466)
!464 = !DISubroutineType(types: !465)
!465 = !{!40}
!466 = !{!467, !468}
!467 = !DILocalVariable(name: "ret", scope: !463, file: !3, line: 269, type: !40)
!468 = !DILocalVariable(name: "env", scope: !463, file: !3, line: 270, type: !19)
!469 = !DILocation(line: 270, column: 17, scope: !463)
!470 = !DILocation(line: 0, scope: !463)
!471 = !DILocation(line: 271, column: 13, scope: !472)
!472 = distinct !DILexicalBlock(scope: !463, file: !3, line: 271, column: 9)
!473 = !DILocation(line: 271, column: 9, scope: !463)
!474 = !DILocalVariable(name: "__nptr", arg: 1, scope: !475, file: !224, line: 481, type: !288)
!475 = distinct !DISubprogram(name: "atoi", scope: !224, file: !224, line: 481, type: !476, scopeLine: 482, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !478)
!476 = !DISubroutineType(types: !477)
!477 = !{!40, !288}
!478 = !{!474}
!479 = !DILocation(line: 0, scope: !475, inlinedAt: !480)
!480 = distinct !DILocation(line: 272, column: 26, scope: !481)
!481 = distinct !DILexicalBlock(scope: !472, file: !3, line: 271, column: 22)
!482 = !DILocation(line: 483, column: 16, scope: !475, inlinedAt: !480)
!483 = !DILocation(line: 483, column: 10, scope: !475, inlinedAt: !480)
!484 = !DILocation(line: 273, column: 13, scope: !481)
!485 = !DILocation(line: 0, scope: !481)
!486 = !DILocation(line: 276, column: 5, scope: !481)
!487 = !DILocation(line: 278, column: 16, scope: !488)
!488 = distinct !DILexicalBlock(scope: !463, file: !3, line: 278, column: 9)
!489 = !DILocation(line: 279, column: 64, scope: !488)
!490 = !DILocation(line: 278, column: 9, scope: !463)
!491 = !DILocation(line: 280, column: 17, scope: !492)
!492 = distinct !DILexicalBlock(scope: !488, file: !3, line: 279, column: 70)
!493 = !DILocation(line: 280, column: 54, scope: !492)
!494 = !DILocation(line: 280, column: 9, scope: !492)
!495 = !DILocation(line: 281, column: 9, scope: !492)
!496 = !DILocation(line: 283, column: 20, scope: !463)
!497 = !DILocation(line: 283, column: 5, scope: !463)
!498 = !DILocation(line: 284, column: 5, scope: !463)
!499 = !DILocation(line: 285, column: 1, scope: !463)
!500 = !DISubprogram(name: "getenv", scope: !224, file: !224, line: 773, type: !501, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!501 = !DISubroutineType(types: !502)
!502 = !{!19, !288}
!503 = !DISubprogram(name: "pthread_create", scope: !372, file: !372, line: 202, type: !504, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!504 = !DISubroutineType(types: !505)
!505 = !{!40, !506, !508, !519, !522}
!506 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !507)
!507 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !85, size: 64)
!508 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !509)
!509 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !510, size: 64)
!510 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !511)
!511 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_attr_t", file: !86, line: 62, baseType: !512)
!512 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "pthread_attr_t", file: !86, line: 56, size: 448, elements: !513)
!513 = !{!514, !518}
!514 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !512, file: !86, line: 58, baseType: !515, size: 448)
!515 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 448, elements: !516)
!516 = !{!517}
!517 = !DISubrange(count: 56)
!518 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !512, file: !86, line: 59, baseType: !126, size: 64)
!519 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !520, size: 64)
!520 = !DISubroutineType(types: !521)
!521 = !{!21, !21}
!522 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !21)
!523 = distinct !DISubprogram(name: "assoc_maintenance_thread", scope: !3, file: !3, line: 197, type: !520, scopeLine: 197, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !524)
!524 = !{!525, !526, !528, !532, !533, !534}
!525 = !DILocalVariable(name: "arg", arg: 1, scope: !523, file: !3, line: 197, type: !21)
!526 = !DILocalVariable(name: "ii", scope: !527, file: !3, line: 201, type: !40)
!527 = distinct !DILexicalBlock(scope: !523, file: !3, line: 200, column: 39)
!528 = !DILocalVariable(name: "it", scope: !529, file: !3, line: 205, type: !27)
!529 = distinct !DILexicalBlock(scope: !530, file: !3, line: 204, column: 62)
!530 = distinct !DILexicalBlock(scope: !531, file: !3, line: 204, column: 9)
!531 = distinct !DILexicalBlock(scope: !527, file: !3, line: 204, column: 9)
!532 = !DILocalVariable(name: "next", scope: !529, file: !3, line: 205, type: !27)
!533 = !DILocalVariable(name: "bucket", scope: !529, file: !3, line: 206, type: !14)
!534 = !DILocalVariable(name: "item_lock", scope: !529, file: !3, line: 207, type: !21)
!535 = !DILocation(line: 0, scope: !523)
!536 = !DILocation(line: 199, column: 5, scope: !523)
!537 = !DILocation(line: 200, column: 12, scope: !523)
!538 = !DILocation(line: 200, column: 5, scope: !523)
!539 = !DILocation(line: 0, scope: !527)
!540 = !DILocation(line: 204, column: 27, scope: !530)
!541 = !DILocation(line: 204, column: 25, scope: !530)
!542 = !DILocation(line: 204, column: 42, scope: !530)
!543 = !DILocation(line: 204, column: 45, scope: !530)
!544 = !DILocation(line: 204, column: 9, scope: !531)
!545 = !DILocation(line: 0, scope: !529)
!546 = !DILocation(line: 213, column: 43, scope: !547)
!547 = distinct !DILexicalBlock(scope: !529, file: !3, line: 213, column: 17)
!548 = !DILocation(line: 213, column: 30, scope: !547)
!549 = !DILocation(line: 213, column: 28, scope: !547)
!550 = !DILocation(line: 213, column: 17, scope: !529)
!551 = !DILocation(line: 214, column: 31, scope: !552)
!552 = distinct !DILexicalBlock(scope: !553, file: !3, line: 214, column: 21)
!553 = distinct !DILexicalBlock(scope: !547, file: !3, line: 213, column: 60)
!554 = !DILocation(line: 214, column: 45, scope: !552)
!555 = !DILocation(line: 214, column: 66, scope: !556)
!556 = distinct !DILexicalBlock(scope: !552, file: !3, line: 214, column: 21)
!557 = !DILocation(line: 214, column: 21, scope: !552)
!558 = !DILocation(line: 224, column: 42, scope: !559)
!559 = distinct !DILexicalBlock(scope: !553, file: !3, line: 224, column: 25)
!560 = !DILocation(line: 215, column: 36, scope: !561)
!561 = distinct !DILexicalBlock(scope: !556, file: !3, line: 214, column: 84)
!562 = !DILocation(line: 216, column: 34, scope: !561)
!563 = !DILocation(line: 216, column: 39, scope: !561)
!564 = !DILocation(line: 216, column: 57, scope: !561)
!565 = !DILocation(line: 216, column: 53, scope: !561)
!566 = !DILocation(line: 216, column: 65, scope: !561)
!567 = !DILocation(line: 216, column: 63, scope: !561)
!568 = !DILocation(line: 217, column: 38, scope: !561)
!569 = !DILocation(line: 217, column: 36, scope: !561)
!570 = !DILocation(line: 218, column: 51, scope: !561)
!571 = distinct !{!571, !557, !572, !346}
!572 = !DILocation(line: 219, column: 21, scope: !552)
!573 = !DILocation(line: 221, column: 21, scope: !553)
!574 = !DILocation(line: 221, column: 35, scope: !553)
!575 = !DILocation(line: 221, column: 50, scope: !553)
!576 = !DILocation(line: 223, column: 34, scope: !553)
!577 = !DILocation(line: 224, column: 39, scope: !559)
!578 = !DILocation(line: 224, column: 25, scope: !553)
!579 = !DILocation(line: 225, column: 35, scope: !580)
!580 = distinct !DILexicalBlock(scope: !559, file: !3, line: 224, column: 67)
!581 = !DILocation(line: 226, column: 25, scope: !580)
!582 = !DILocation(line: 227, column: 25, scope: !580)
!583 = !DILocation(line: 228, column: 51, scope: !580)
!584 = !DILocation(line: 228, column: 75, scope: !580)
!585 = !DILocation(line: 228, column: 48, scope: !580)
!586 = !DILocation(line: 229, column: 55, scope: !580)
!587 = !{!214, !216, i64 48}
!588 = !DILocation(line: 230, column: 25, scope: !580)
!589 = !DILocation(line: 231, column: 38, scope: !590)
!590 = distinct !DILexicalBlock(scope: !580, file: !3, line: 231, column: 29)
!591 = !{!592, !193, i64 32}
!592 = !{!"settings", !215, i64 0, !193, i64 8, !193, i64 12, !193, i64 16, !202, i64 24, !193, i64 32, !193, i64 36, !193, i64 40, !202, i64 48, !202, i64 56, !193, i64 64, !593, i64 72, !193, i64 80, !193, i64 84, !193, i64 88, !194, i64 92, !193, i64 96, !193, i64 100, !216, i64 104, !193, i64 108, !193, i64 112, !193, i64 116, !193, i64 120, !193, i64 124, !193, i64 128, !216, i64 132, !216, i64 133, !216, i64 134, !216, i64 135, !216, i64 136, !216, i64 137, !193, i64 140, !593, i64 144, !193, i64 152, !193, i64 156, !216, i64 160, !193, i64 164, !216, i64 168, !216, i64 169, !202, i64 176, !193, i64 184, !193, i64 188, !193, i64 192, !193, i64 196, !593, i64 200, !593, i64 208, !193, i64 216, !216, i64 220, !193, i64 224, !193, i64 228, !193, i64 232, !193, i64 236, !193, i64 240, !216, i64 244, !216, i64 245, !216, i64 246, !193, i64 248, !193, i64 252, !193, i64 256, !193, i64 260, !193, i64 264, !193, i64 268, !193, i64 272, !193, i64 276, !193, i64 280, !193, i64 284, !593, i64 288, !593, i64 296, !216, i64 304, !193, i64 308, !193, i64 312, !202, i64 320, !193, i64 328}
!593 = !{!"double", !194, i64 0}
!594 = !DILocation(line: 231, column: 46, scope: !590)
!595 = !DILocation(line: 231, column: 29, scope: !580)
!596 = !DILocation(line: 232, column: 37, scope: !590)
!597 = !DILocation(line: 232, column: 29, scope: !590)
!598 = !DILocation(line: 236, column: 17, scope: !599)
!599 = distinct !DILexicalBlock(scope: !547, file: !3, line: 235, column: 20)
!600 = !DILocation(line: 239, column: 17, scope: !529)
!601 = !DILocation(line: 240, column: 17, scope: !602)
!602 = distinct !DILexicalBlock(scope: !603, file: !3, line: 239, column: 28)
!603 = distinct !DILexicalBlock(scope: !529, file: !3, line: 239, column: 17)
!604 = !DILocation(line: 242, column: 13, scope: !602)
!605 = !DILocation(line: 204, column: 56, scope: !530)
!606 = distinct !{!606, !544, !607, !346}
!607 = !DILocation(line: 243, column: 9, scope: !531)
!608 = !DILocation(line: 245, column: 14, scope: !609)
!609 = distinct !DILexicalBlock(scope: !527, file: !3, line: 245, column: 13)
!610 = !DILocation(line: 245, column: 13, scope: !527)
!611 = !DILocation(line: 247, column: 13, scope: !612)
!612 = distinct !DILexicalBlock(scope: !609, file: !3, line: 245, column: 25)
!613 = !DILocation(line: 255, column: 17, scope: !614)
!614 = distinct !DILexicalBlock(scope: !612, file: !3, line: 255, column: 17)
!615 = !DILocation(line: 255, column: 17, scope: !612)
!616 = !DILocation(line: 256, column: 17, scope: !617)
!617 = distinct !DILexicalBlock(scope: !614, file: !3, line: 255, column: 44)
!618 = !DILocation(line: 123, column: 21, scope: !619, inlinedAt: !620)
!619 = distinct !DISubprogram(name: "assoc_expand", scope: !3, file: !3, line: 122, type: !294, scopeLine: 122, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!620 = distinct !DILocation(line: 257, column: 17, scope: !617)
!621 = !DILocation(line: 123, column: 19, scope: !619, inlinedAt: !620)
!622 = !DILocation(line: 125, column: 32, scope: !619, inlinedAt: !620)
!623 = !DILocation(line: 125, column: 25, scope: !619, inlinedAt: !620)
!624 = !DILocation(line: 125, column: 23, scope: !619, inlinedAt: !620)
!625 = !DILocation(line: 126, column: 9, scope: !626, inlinedAt: !620)
!626 = distinct !DILexicalBlock(scope: !619, file: !3, line: 126, column: 9)
!627 = !DILocation(line: 126, column: 9, scope: !619, inlinedAt: !620)
!628 = !DILocation(line: 127, column: 22, scope: !629, inlinedAt: !620)
!629 = distinct !DILexicalBlock(scope: !630, file: !3, line: 127, column: 13)
!630 = distinct !DILexicalBlock(scope: !626, file: !3, line: 126, column: 28)
!631 = !DILocation(line: 127, column: 30, scope: !629, inlinedAt: !620)
!632 = !DILocation(line: 127, column: 13, scope: !630, inlinedAt: !620)
!633 = !DILocation(line: 128, column: 21, scope: !629, inlinedAt: !620)
!634 = !DILocation(line: 128, column: 13, scope: !629, inlinedAt: !620)
!635 = !DILocation(line: 129, column: 18, scope: !630, inlinedAt: !620)
!636 = !DILocation(line: 130, column: 19, scope: !630, inlinedAt: !620)
!637 = !DILocation(line: 131, column: 23, scope: !630, inlinedAt: !620)
!638 = !DILocation(line: 132, column: 9, scope: !630, inlinedAt: !620)
!639 = !DILocation(line: 133, column: 40, scope: !630, inlinedAt: !620)
!640 = !DILocation(line: 133, column: 38, scope: !630, inlinedAt: !620)
!641 = !DILocation(line: 134, column: 35, scope: !630, inlinedAt: !620)
!642 = !DILocation(line: 134, column: 55, scope: !630, inlinedAt: !620)
!643 = !DILocation(line: 134, column: 32, scope: !630, inlinedAt: !620)
!644 = !DILocation(line: 135, column: 39, scope: !630, inlinedAt: !620)
!645 = !DILocation(line: 136, column: 9, scope: !630, inlinedAt: !620)
!646 = !DILocation(line: 137, column: 5, scope: !630, inlinedAt: !620)
!647 = !DILocation(line: 138, column: 27, scope: !648, inlinedAt: !620)
!648 = distinct !DILexicalBlock(scope: !626, file: !3, line: 137, column: 12)
!649 = !DILocation(line: 258, column: 17, scope: !617)
!650 = !DILocation(line: 259, column: 13, scope: !617)
!651 = distinct !{!651, !538, !652, !346}
!652 = !DILocation(line: 261, column: 5, scope: !523)
!653 = !DILocation(line: 262, column: 5, scope: !523)
!654 = !DILocation(line: 263, column: 5, scope: !523)
!655 = !DISubprogram(name: "strerror", scope: !656, file: !656, line: 419, type: !657, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!656 = !DIFile(filename: "/usr/include/string.h", directory: "", checksumkind: CSK_MD5, checksum: "165db1185644f68894fa9e0d17055d70")
!657 = !DISubroutineType(types: !658)
!658 = !{!19, !40}
!659 = !DISubprogram(name: "thread_setname", scope: !6, file: !6, line: 1033, type: !660, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!660 = !DISubroutineType(types: !661)
!661 = !{null, !85, !288}
!662 = distinct !DISubprogram(name: "stop_assoc_maintenance_thread", scope: !3, file: !3, line: 287, type: !294, scopeLine: 287, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!663 = !DILocation(line: 288, column: 5, scope: !662)
!664 = !DILocation(line: 289, column: 31, scope: !662)
!665 = !DILocation(line: 290, column: 5, scope: !662)
!666 = !DILocation(line: 291, column: 5, scope: !662)
!667 = !DILocation(line: 294, column: 18, scope: !662)
!668 = !DILocation(line: 294, column: 5, scope: !662)
!669 = !DILocation(line: 295, column: 1, scope: !662)
!670 = !DISubprogram(name: "pthread_mutex_lock", scope: !372, file: !372, line: 794, type: !373, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!671 = !DISubprogram(name: "pthread_join", scope: !372, file: !372, line: 219, type: !672, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!672 = !DISubroutineType(types: !673)
!673 = !{!40, !85, !674}
!674 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !21, size: 64)
!675 = distinct !DISubprogram(name: "assoc_get_iterator", scope: !3, file: !3, line: 304, type: !676, scopeLine: 304, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !678)
!676 = !DISubroutineType(types: !677)
!677 = !{!21}
!678 = !{!679}
!679 = !DILocalVariable(name: "iter", scope: !675, file: !3, line: 305, type: !22)
!680 = !DILocation(line: 305, column: 35, scope: !675)
!681 = !DILocation(line: 0, scope: !675)
!682 = !DILocation(line: 306, column: 14, scope: !683)
!683 = distinct !DILexicalBlock(scope: !675, file: !3, line: 306, column: 9)
!684 = !DILocation(line: 306, column: 9, scope: !675)
!685 = !DILocation(line: 310, column: 9, scope: !686)
!686 = distinct !DILexicalBlock(scope: !675, file: !3, line: 310, column: 9)
!687 = !DILocation(line: 310, column: 42, scope: !686)
!688 = !DILocation(line: 0, scope: !686)
!689 = !DILocation(line: 315, column: 1, scope: !675)
!690 = distinct !DISubprogram(name: "assoc_iterate", scope: !3, file: !3, line: 317, type: !691, scopeLine: 317, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !693)
!691 = !DISubroutineType(types: !692)
!692 = !{!61, !21, !89}
!693 = !{!694, !695, !696}
!694 = !DILocalVariable(name: "iterp", arg: 1, scope: !690, file: !3, line: 317, type: !21)
!695 = !DILocalVariable(name: "it", arg: 2, scope: !690, file: !3, line: 317, type: !89)
!696 = !DILocalVariable(name: "iter", scope: !690, file: !3, line: 318, type: !22)
!697 = !DILocation(line: 0, scope: !690)
!698 = !DILocation(line: 319, column: 9, scope: !690)
!699 = !DILocation(line: 321, column: 15, scope: !700)
!700 = distinct !DILexicalBlock(scope: !690, file: !3, line: 321, column: 9)
!701 = !{!702, !216, i64 24}
!702 = !{!"assoc_iterator", !215, i64 0, !202, i64 8, !202, i64 16, !216, i64 24}
!703 = !{i8 0, i8 2}
!704 = !{}
!705 = !DILocation(line: 321, column: 9, scope: !690)
!706 = !DILocation(line: 322, column: 19, scope: !707)
!707 = distinct !DILexicalBlock(scope: !708, file: !3, line: 322, column: 13)
!708 = distinct !DILexicalBlock(scope: !700, file: !3, line: 321, column: 30)
!709 = !{!702, !202, i64 16}
!710 = !DILocation(line: 322, column: 24, scope: !707)
!711 = !DILocation(line: 322, column: 13, scope: !708)
!712 = !DILocation(line: 323, column: 19, scope: !713)
!713 = distinct !DILexicalBlock(scope: !707, file: !3, line: 322, column: 33)
!714 = !DILocation(line: 323, column: 22, scope: !713)
!715 = !{!702, !202, i64 8}
!716 = !DILocation(line: 324, column: 36, scope: !713)
!717 = !DILocation(line: 324, column: 24, scope: !713)
!718 = !DILocation(line: 326, column: 9, scope: !713)
!719 = !DILocation(line: 328, column: 31, scope: !720)
!720 = distinct !DILexicalBlock(scope: !707, file: !3, line: 326, column: 16)
!721 = !{!702, !215, i64 0}
!722 = !DILocation(line: 328, column: 25, scope: !720)
!723 = !DILocation(line: 328, column: 13, scope: !720)
!724 = !DILocation(line: 330, column: 25, scope: !720)
!725 = !DILocation(line: 331, column: 33, scope: !720)
!726 = !DILocation(line: 0, scope: !707)
!727 = !DILocation(line: 334, column: 9, scope: !708)
!728 = !DILocation(line: 338, column: 15, scope: !729)
!729 = distinct !DILexicalBlock(scope: !690, file: !3, line: 338, column: 9)
!730 = !DILocation(line: 338, column: 25, scope: !729)
!731 = !DILocation(line: 338, column: 22, scope: !729)
!732 = !DILocation(line: 338, column: 9, scope: !690)
!733 = !DILocation(line: 340, column: 19, scope: !734)
!734 = distinct !DILexicalBlock(scope: !729, file: !3, line: 338, column: 46)
!735 = !DILocation(line: 340, column: 9, scope: !734)
!736 = !DILocation(line: 341, column: 29, scope: !734)
!737 = !DILocation(line: 343, column: 20, scope: !734)
!738 = !DILocation(line: 343, column: 44, scope: !734)
!739 = !DILocation(line: 343, column: 15, scope: !734)
!740 = !DILocation(line: 343, column: 18, scope: !734)
!741 = !DILocation(line: 344, column: 22, scope: !742)
!742 = distinct !DILexicalBlock(scope: !734, file: !3, line: 344, column: 13)
!743 = !DILocation(line: 344, column: 13, scope: !734)
!744 = !DILocation(line: 346, column: 36, scope: !745)
!745 = distinct !DILexicalBlock(scope: !742, file: !3, line: 344, column: 31)
!746 = !DILocation(line: 346, column: 19, scope: !745)
!747 = !DILocation(line: 346, column: 24, scope: !745)
!748 = !DILocation(line: 347, column: 17, scope: !745)
!749 = !DILocation(line: 348, column: 9, scope: !745)
!750 = !DILocation(line: 350, column: 25, scope: !751)
!751 = distinct !DILexicalBlock(scope: !742, file: !3, line: 348, column: 16)
!752 = !DILocation(line: 350, column: 13, scope: !751)
!753 = !DILocation(line: 351, column: 33, scope: !751)
!754 = !DILocation(line: 352, column: 25, scope: !751)
!755 = !DILocation(line: 359, column: 1, scope: !690)
!756 = !DISubprogram(name: "item_unlock", scope: !6, file: !6, line: 1020, type: !757, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!757 = !DISubroutineType(types: !758)
!758 = !{null, !302}
!759 = !DISubprogram(name: "item_lock", scope: !6, file: !6, line: 1017, type: !757, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!760 = distinct !DISubprogram(name: "assoc_iterate_final", scope: !3, file: !3, line: 361, type: !761, scopeLine: 361, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !763)
!761 = !DISubroutineType(types: !762)
!762 = !{null, !21}
!763 = !{!764, !765}
!764 = !DILocalVariable(name: "iterp", arg: 1, scope: !760, file: !3, line: 361, type: !21)
!765 = !DILocalVariable(name: "iter", scope: !760, file: !3, line: 362, type: !22)
!766 = !DILocation(line: 0, scope: !760)
!767 = !DILocation(line: 363, column: 15, scope: !768)
!768 = distinct !DILexicalBlock(scope: !760, file: !3, line: 363, column: 9)
!769 = !DILocation(line: 363, column: 9, scope: !760)
!770 = !DILocation(line: 364, column: 27, scope: !771)
!771 = distinct !DILexicalBlock(scope: !768, file: !3, line: 363, column: 30)
!772 = !DILocation(line: 364, column: 21, scope: !771)
!773 = !DILocation(line: 364, column: 9, scope: !771)
!774 = !DILocation(line: 365, column: 5, scope: !771)
!775 = !DILocation(line: 366, column: 5, scope: !760)
!776 = !DILocation(line: 367, column: 5, scope: !760)
!777 = !DILocation(line: 368, column: 1, scope: !760)
!778 = !DISubprogram(name: "free", scope: !224, file: !224, line: 687, type: !761, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!779 = !DISubprogram(name: "strtol", linkageName: "__isoc23_strtol", scope: !224, file: !224, line: 215, type: !780, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!780 = !DISubroutineType(types: !781)
!781 = !{!126, !287, !782, !40}
!782 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !62)
!783 = !DISubprogram(name: "item_trylock", scope: !6, file: !6, line: 1018, type: !784, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!784 = !DISubroutineType(types: !785)
!785 = !{!21, !302}
!786 = !DISubprogram(name: "usleep", scope: !787, file: !787, line: 480, type: !788, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!787 = !DIFile(filename: "/usr/include/unistd.h", directory: "", checksumkind: CSK_MD5, checksum: "877e832a8bb8424f9180387a13787475")
!788 = !DISubroutineType(types: !789)
!789 = !{!40, !790}
!790 = !DIDerivedType(tag: DW_TAG_typedef, name: "__useconds_t", file: !17, line: 161, baseType: !7)
!791 = !DISubprogram(name: "item_trylock_unlock", scope: !6, file: !6, line: 1019, type: !761, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!792 = !DISubprogram(name: "pthread_cond_wait", scope: !372, file: !372, line: 1133, type: !793, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!793 = !DISubroutineType(types: !794)
!794 = !{!40, !795, !796}
!795 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !379)
!796 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !375)
!797 = !DISubprogram(name: "pause_threads", scope: !6, file: !6, line: 1021, type: !798, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!798 = !DISubroutineType(types: !799)
!799 = !{null, !5}
