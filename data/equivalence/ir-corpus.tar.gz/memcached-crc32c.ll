; ModuleID = 'crc32c.c'
source_filename = "crc32c.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@crc32c = dso_local local_unnamed_addr global ptr null, align 8, !dbg !0
@crc32c_once_little = internal global i32 0, align 4, !dbg !60
@crc32c_table_little = internal unnamed_addr global [8 x [256 x i32]] zeroinitializer, align 16, !dbg !36
@crc32c_once_big = internal global i32 0, align 4, !dbg !62
@crc32c_table_big_byte = internal unnamed_addr global [256 x i32] zeroinitializer, align 16, !dbg !42
@crc32c_table_big = internal unnamed_addr global [8 x [256 x i64]] zeroinitializer, align 16, !dbg !46
@crc32c_once_hw = internal global i32 0, align 4, !dbg !49
@crc32c_long = internal global [4 x [256 x i32]] zeroinitializer, align 16, !dbg !53
@crc32c_short = internal global [4 x [256 x i32]] zeroinitializer, align 16, !dbg !58
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nounwind sanitize_thread memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local void @crc32c_init() local_unnamed_addr #0 !dbg !75 {
entry:
  tail call void @llvm.dbg.value(metadata i32 1, metadata !80, metadata !DIExpression()), !dbg !83
  %0 = tail call i32 asm "cpuid", "={cx},{ax},~{ebx},~{edx},~{dirflag},~{fpsr},~{flags}"(i32 1) #11, !dbg !84, !srcloc !85
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !82, metadata !DIExpression()), !dbg !83
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !79, metadata !DIExpression(DW_OP_constu, 20, DW_OP_shr, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !86
  %1 = and i32 %0, 1048576, !dbg !87
  %tobool.not = icmp eq i32 %1, 0, !dbg !87
  %crc32c_sw.crc32c_hw = select i1 %tobool.not, ptr @crc32c_sw, ptr @crc32c_hw
  store ptr %crc32c_sw.crc32c_hw, ptr @crc32c, align 8, !dbg !89, !tbaa !90
  ret void, !dbg !94
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nounwind sanitize_thread uwtable
define internal i32 @crc32c_hw(i32 noundef %crc, ptr noundef %buf, i64 noundef %len) #2 !dbg !95 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %crc, metadata !97, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata ptr %buf, metadata !98, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !99, metadata !DIExpression()), !dbg !116
  %call = tail call i32 @pthread_once(ptr noundef nonnull @crc32c_once_hw, ptr noundef nonnull @crc32c_init_hw) #12, !dbg !117
  %not = xor i32 %crc, -1, !dbg !118
  tail call void @llvm.dbg.value(metadata i32 %not, metadata !97, metadata !DIExpression()), !dbg !116
  %conv = zext i32 %not to i64, !dbg !119
  tail call void @llvm.dbg.value(metadata i64 %conv, metadata !100, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata ptr %buf, metadata !101, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !99, metadata !DIExpression()), !dbg !116
  %tobool.not165 = icmp eq i64 %len, 0, !dbg !120
  %0 = ptrtoint ptr %buf to i64
  %and166 = and i64 %0, 7
  %cmp.not167 = icmp eq i64 %and166, 0
  %or.cond168 = or i1 %tobool.not165, %cmp.not167, !dbg !121
  br i1 %or.cond168, label %while.cond2.preheader, label %while.body, !dbg !121

while.cond2.preheader:                            ; preds = %while.body, %entry
  %next.0.lcssa = phi ptr [ %buf, %entry ], [ %incdec.ptr, %while.body ], !dbg !116
  %crc0.0.lcssa = phi i64 [ %conv, %entry ], [ %1, %while.body ], !dbg !116
  %len.addr.0.lcssa = phi i64 [ %len, %entry ], [ %dec, %while.body ]
  tail call void @llvm.dbg.value(metadata i64 %len.addr.0.lcssa, metadata !99, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata i64 %crc0.0.lcssa, metadata !100, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata ptr %next.0.lcssa, metadata !101, metadata !DIExpression()), !dbg !116
  %cmp3174 = icmp ugt i64 %len.addr.0.lcssa, 24575, !dbg !122
  br i1 %cmp3174, label %do.body.preheader, label %while.cond20.preheader, !dbg !123

while.body:                                       ; preds = %entry, %while.body
  %len.addr.0171 = phi i64 [ %dec, %while.body ], [ %len, %entry ]
  %crc0.0170 = phi i64 [ %1, %while.body ], [ %conv, %entry ]
  %next.0169 = phi ptr [ %incdec.ptr, %while.body ], [ %buf, %entry ]
  tail call void @llvm.dbg.value(metadata i64 %len.addr.0171, metadata !99, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata i64 %crc0.0170, metadata !100, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata ptr %next.0169, metadata !101, metadata !DIExpression()), !dbg !116
  %1 = tail call i64 asm "crc32b\09($1), $0", "=r,r,*m,0,~{dirflag},~{fpsr},~{flags}"(ptr %next.0169, ptr elementtype(i8) %next.0169, i64 %crc0.0170) #13, !dbg !124, !srcloc !126
  tail call void @llvm.dbg.value(metadata i64 %1, metadata !100, metadata !DIExpression()), !dbg !116
  %incdec.ptr = getelementptr inbounds i8, ptr %next.0169, i64 1, !dbg !127
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !101, metadata !DIExpression()), !dbg !116
  %dec = add i64 %len.addr.0171, -1, !dbg !128
  tail call void @llvm.dbg.value(metadata i64 %dec, metadata !99, metadata !DIExpression()), !dbg !116
  %tobool.not = icmp eq i64 %dec, 0, !dbg !120
  %2 = ptrtoint ptr %incdec.ptr to i64
  %and = and i64 %2, 7
  %cmp.not = icmp eq i64 %and, 0
  %or.cond = select i1 %tobool.not, i1 true, i1 %cmp.not, !dbg !121
  br i1 %or.cond, label %while.cond2.preheader, label %while.body, !dbg !121, !llvm.loop !129

do.body.preheader:                                ; preds = %while.cond2.preheader, %do.end
  %len.addr.1177 = phi i64 [ %sub, %do.end ], [ %len.addr.0.lcssa, %while.cond2.preheader ]
  %crc0.1176 = phi i64 [ %xor17, %do.end ], [ %crc0.0.lcssa, %while.cond2.preheader ]
  %next.1175 = phi ptr [ %add.ptr18, %do.end ], [ %next.0.lcssa, %while.cond2.preheader ]
  tail call void @llvm.dbg.value(metadata i64 %len.addr.1177, metadata !99, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata i64 %crc0.1176, metadata !100, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata ptr %next.1175, metadata !101, metadata !DIExpression()), !dbg !116
  br label %do.body, !dbg !133

while.cond20.preheader:                           ; preds = %do.end, %while.cond2.preheader
  %next.1.lcssa = phi ptr [ %next.0.lcssa, %while.cond2.preheader ], [ %add.ptr18, %do.end ], !dbg !116
  %crc0.1.lcssa = phi i64 [ %crc0.0.lcssa, %while.cond2.preheader ], [ %xor17, %do.end ], !dbg !116
  %len.addr.1.lcssa = phi i64 [ %len.addr.0.lcssa, %while.cond2.preheader ], [ %sub, %do.end ]
  tail call void @llvm.dbg.value(metadata i64 %len.addr.1.lcssa, metadata !99, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata i64 %crc0.1.lcssa, metadata !100, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata ptr %next.1.lcssa, metadata !101, metadata !DIExpression()), !dbg !116
  %cmp21181 = icmp ugt i64 %len.addr.1.lcssa, 767, !dbg !134
  br i1 %cmp21181, label %do.body28.preheader, label %while.end47, !dbg !135

do.body:                                          ; preds = %do.body.preheader, %do.body
  %crc1.0 = phi i64 [ %asmresult6, %do.body ], [ 0, %do.body.preheader ], !dbg !136
  %crc2.0 = phi i64 [ %asmresult7, %do.body ], [ 0, %do.body.preheader ], !dbg !136
  %next.2.idx = phi i64 [ %next.2.add, %do.body ], [ 0, %do.body.preheader ]
  %crc0.2 = phi i64 [ %asmresult, %do.body ], [ %crc0.1176, %do.body.preheader ], !dbg !116
  %next.2.ptr = getelementptr inbounds i8, ptr %next.1175, i64 %next.2.idx, !dbg !137
  tail call void @llvm.dbg.value(metadata i64 %crc0.2, metadata !100, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata ptr %next.2.ptr, metadata !101, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata i64 %crc2.0, metadata !107, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %crc1.0, metadata !105, metadata !DIExpression()), !dbg !136
  %3 = tail call { i64, i64, i64 } asm "crc32q\09($3), $0\0A\09crc32q\098192($3), $1\0A\09crc32q\0916384($3), $2", "=r,=r,=r,r,*m,0,1,2,~{dirflag},~{fpsr},~{flags}"(ptr %next.2.ptr, ptr elementtype(i8) %next.2.ptr, i64 %crc0.2, i64 %crc1.0, i64 %crc2.0) #13, !dbg !137, !srcloc !139
  %asmresult = extractvalue { i64, i64, i64 } %3, 0, !dbg !137
  %asmresult6 = extractvalue { i64, i64, i64 } %3, 1, !dbg !137
  %asmresult7 = extractvalue { i64, i64, i64 } %3, 2, !dbg !137
  tail call void @llvm.dbg.value(metadata i64 %asmresult, metadata !100, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata i64 %asmresult6, metadata !105, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %asmresult7, metadata !107, metadata !DIExpression()), !dbg !136
  %next.2.add = add nuw nsw i64 %next.2.idx, 8, !dbg !140
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %next.1175, i64 %next.2.add), metadata !101, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !116
  %cmp9 = icmp ult i64 %next.2.idx, 8184, !dbg !141
  br i1 %cmp9, label %do.body, label %do.end, !dbg !142, !llvm.loop !143

do.end:                                           ; preds = %do.body
  tail call void @llvm.dbg.value(metadata ptr %next.1175, metadata !101, metadata !DIExpression(DW_OP_plus_uconst, 8192, DW_OP_stack_value)), !dbg !116
  tail call void @llvm.dbg.value(metadata ptr @crc32c_long, metadata !145, metadata !DIExpression()), !dbg !152
  tail call void @llvm.dbg.value(metadata i64 %asmresult, metadata !151, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !152
  %and.i = and i64 %asmresult, 255, !dbg !154
  %arrayidx1.i = getelementptr inbounds [256 x i32], ptr @crc32c_long, i64 0, i64 %and.i, !dbg !155
  %4 = load i32, ptr %arrayidx1.i, align 4, !dbg !155, !tbaa !156
  %shr.i = lshr i64 %asmresult, 8, !dbg !158
  %and3.i = and i64 %shr.i, 255, !dbg !159
  %arrayidx5.i = getelementptr inbounds [256 x i32], ptr getelementptr inbounds ([4 x [256 x i32]], ptr @crc32c_long, i64 0, i64 1, i64 0), i64 0, i64 %and3.i, !dbg !160
  %5 = load i32, ptr %arrayidx5.i, align 4, !dbg !160, !tbaa !156
  %shr7.i = lshr i64 %asmresult, 16, !dbg !161
  %and8.i = and i64 %shr7.i, 255, !dbg !162
  %arrayidx10.i = getelementptr inbounds [256 x i32], ptr getelementptr inbounds ([4 x [256 x i32]], ptr @crc32c_long, i64 0, i64 2, i64 0), i64 0, i64 %and8.i, !dbg !163
  %6 = load i32, ptr %arrayidx10.i, align 4, !dbg !163, !tbaa !156
  %shr13.i = lshr i64 %asmresult, 24, !dbg !164
  %idxprom14.i = and i64 %shr13.i, 255, !dbg !165
  %arrayidx15.i = getelementptr inbounds [256 x i32], ptr getelementptr inbounds ([4 x [256 x i32]], ptr @crc32c_long, i64 0, i64 3, i64 0), i64 0, i64 %idxprom14.i, !dbg !165
  %7 = load i32, ptr %arrayidx15.i, align 4, !dbg !165, !tbaa !156
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i32 poison), metadata !100, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_xor, DW_OP_stack_value)), !dbg !116
  %8 = trunc i64 %asmresult6 to i32, !dbg !166
  %xor.i = xor i32 %4, %8, !dbg !167
  %xor11.i = xor i32 %xor.i, %5, !dbg !168
  %xor16.i = xor i32 %xor11.i, %6, !dbg !169
  %conv14 = xor i32 %xor16.i, %7, !dbg !166
  tail call void @llvm.dbg.value(metadata ptr @crc32c_long, metadata !145, metadata !DIExpression()), !dbg !170
  tail call void @llvm.dbg.value(metadata i32 %conv14, metadata !151, metadata !DIExpression()), !dbg !170
  %and.i114 = and i32 %conv14, 255, !dbg !172
  %idxprom.i115 = zext nneg i32 %and.i114 to i64, !dbg !173
  %arrayidx1.i116 = getelementptr inbounds [256 x i32], ptr @crc32c_long, i64 0, i64 %idxprom.i115, !dbg !173
  %9 = load i32, ptr %arrayidx1.i116, align 4, !dbg !173, !tbaa !156
  %shr.i117 = lshr i32 %conv14, 8, !dbg !174
  %and3.i118 = and i32 %shr.i117, 255, !dbg !175
  %idxprom4.i119 = zext nneg i32 %and3.i118 to i64, !dbg !176
  %arrayidx5.i120 = getelementptr inbounds [256 x i32], ptr getelementptr inbounds ([4 x [256 x i32]], ptr @crc32c_long, i64 0, i64 1, i64 0), i64 0, i64 %idxprom4.i119, !dbg !176
  %10 = load i32, ptr %arrayidx5.i120, align 4, !dbg !176, !tbaa !156
  %xor.i121 = xor i32 %10, %9, !dbg !177
  %shr7.i122 = lshr i32 %conv14, 16, !dbg !178
  %and8.i123 = and i32 %shr7.i122, 255, !dbg !179
  %idxprom9.i124 = zext nneg i32 %and8.i123 to i64, !dbg !180
  %arrayidx10.i125 = getelementptr inbounds [256 x i32], ptr getelementptr inbounds ([4 x [256 x i32]], ptr @crc32c_long, i64 0, i64 2, i64 0), i64 0, i64 %idxprom9.i124, !dbg !180
  %11 = load i32, ptr %arrayidx10.i125, align 4, !dbg !180, !tbaa !156
  %xor11.i126 = xor i32 %xor.i121, %11, !dbg !181
  %shr13.i127 = lshr i32 %conv14, 24, !dbg !182
  %idxprom14.i128 = zext nneg i32 %shr13.i127 to i64, !dbg !183
  %arrayidx15.i129 = getelementptr inbounds [256 x i32], ptr getelementptr inbounds ([4 x [256 x i32]], ptr @crc32c_long, i64 0, i64 3, i64 0), i64 0, i64 %idxprom14.i128, !dbg !183
  %12 = load i32, ptr %arrayidx15.i129, align 4, !dbg !183, !tbaa !156
  %xor16.i130 = xor i32 %xor11.i126, %12, !dbg !184
  %conv16 = zext i32 %xor16.i130 to i64, !dbg !185
  %xor17 = xor i64 %asmresult7, %conv16, !dbg !186
  tail call void @llvm.dbg.value(metadata i64 %xor17, metadata !100, metadata !DIExpression()), !dbg !116
  %add.ptr18 = getelementptr inbounds i8, ptr %next.1175, i64 24576, !dbg !187
  tail call void @llvm.dbg.value(metadata ptr %add.ptr18, metadata !101, metadata !DIExpression()), !dbg !116
  %sub = add i64 %len.addr.1177, -24576, !dbg !188
  tail call void @llvm.dbg.value(metadata i64 %sub, metadata !99, metadata !DIExpression()), !dbg !116
  %cmp3 = icmp ugt i64 %sub, 24575, !dbg !122
  br i1 %cmp3, label %do.body.preheader, label %while.cond20.preheader, !dbg !123, !llvm.loop !189

do.body28.preheader:                              ; preds = %while.cond20.preheader, %do.end36
  %len.addr.2184 = phi i64 [ %sub46, %do.end36 ], [ %len.addr.1.lcssa, %while.cond20.preheader ]
  %crc0.3183 = phi i64 [ %xor44, %do.end36 ], [ %crc0.1.lcssa, %while.cond20.preheader ]
  %next.3182 = phi ptr [ %add.ptr45, %do.end36 ], [ %next.1.lcssa, %while.cond20.preheader ]
  tail call void @llvm.dbg.value(metadata i64 %len.addr.2184, metadata !99, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata i64 %crc0.3183, metadata !100, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata ptr %next.3182, metadata !101, metadata !DIExpression()), !dbg !116
  br label %do.body28, !dbg !191

do.body28:                                        ; preds = %do.body28.preheader, %do.body28
  %next.4.idx = phi i64 [ %next.4.add, %do.body28 ], [ 0, %do.body28.preheader ]
  %crc124.0 = phi i64 [ %asmresult30, %do.body28 ], [ 0, %do.body28.preheader ], !dbg !192
  %crc225.0 = phi i64 [ %asmresult31, %do.body28 ], [ 0, %do.body28.preheader ], !dbg !192
  %crc0.4 = phi i64 [ %asmresult29, %do.body28 ], [ %crc0.3183, %do.body28.preheader ], !dbg !116
  %next.4.ptr = getelementptr inbounds i8, ptr %next.3182, i64 %next.4.idx, !dbg !193
  tail call void @llvm.dbg.value(metadata i64 %crc0.4, metadata !100, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata i64 %crc225.0, metadata !112, metadata !DIExpression()), !dbg !192
  tail call void @llvm.dbg.value(metadata i64 %crc124.0, metadata !110, metadata !DIExpression()), !dbg !192
  tail call void @llvm.dbg.value(metadata ptr %next.4.ptr, metadata !101, metadata !DIExpression()), !dbg !116
  %13 = tail call { i64, i64, i64 } asm "crc32q\09($3), $0\0A\09crc32q\09256($3), $1\0A\09crc32q\09512($3), $2", "=r,=r,=r,r,*m,0,1,2,~{dirflag},~{fpsr},~{flags}"(ptr %next.4.ptr, ptr elementtype(i8) %next.4.ptr, i64 %crc0.4, i64 %crc124.0, i64 %crc225.0) #13, !dbg !193, !srcloc !195
  %asmresult29 = extractvalue { i64, i64, i64 } %13, 0, !dbg !193
  %asmresult30 = extractvalue { i64, i64, i64 } %13, 1, !dbg !193
  %asmresult31 = extractvalue { i64, i64, i64 } %13, 2, !dbg !193
  tail call void @llvm.dbg.value(metadata i64 %asmresult29, metadata !100, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata i64 %asmresult30, metadata !110, metadata !DIExpression()), !dbg !192
  tail call void @llvm.dbg.value(metadata i64 %asmresult31, metadata !112, metadata !DIExpression()), !dbg !192
  %next.4.add = add nuw nsw i64 %next.4.idx, 8, !dbg !196
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %next.3182, i64 %next.4.add), metadata !101, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !116
  %cmp34 = icmp ult i64 %next.4.idx, 248, !dbg !197
  br i1 %cmp34, label %do.body28, label %do.end36, !dbg !198, !llvm.loop !199

do.end36:                                         ; preds = %do.body28
  tail call void @llvm.dbg.value(metadata ptr %next.3182, metadata !101, metadata !DIExpression(DW_OP_plus_uconst, 256, DW_OP_stack_value)), !dbg !116
  tail call void @llvm.dbg.value(metadata ptr @crc32c_short, metadata !145, metadata !DIExpression()), !dbg !201
  tail call void @llvm.dbg.value(metadata i64 %asmresult29, metadata !151, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !201
  %and.i131 = and i64 %asmresult29, 255, !dbg !203
  %arrayidx1.i133 = getelementptr inbounds [256 x i32], ptr @crc32c_short, i64 0, i64 %and.i131, !dbg !204
  %14 = load i32, ptr %arrayidx1.i133, align 4, !dbg !204, !tbaa !156
  %shr.i134 = lshr i64 %asmresult29, 8, !dbg !205
  %and3.i135 = and i64 %shr.i134, 255, !dbg !206
  %arrayidx5.i137 = getelementptr inbounds [256 x i32], ptr getelementptr inbounds ([4 x [256 x i32]], ptr @crc32c_short, i64 0, i64 1, i64 0), i64 0, i64 %and3.i135, !dbg !207
  %15 = load i32, ptr %arrayidx5.i137, align 4, !dbg !207, !tbaa !156
  %shr7.i139 = lshr i64 %asmresult29, 16, !dbg !208
  %and8.i140 = and i64 %shr7.i139, 255, !dbg !209
  %arrayidx10.i142 = getelementptr inbounds [256 x i32], ptr getelementptr inbounds ([4 x [256 x i32]], ptr @crc32c_short, i64 0, i64 2, i64 0), i64 0, i64 %and8.i140, !dbg !210
  %16 = load i32, ptr %arrayidx10.i142, align 4, !dbg !210, !tbaa !156
  %shr13.i144 = lshr i64 %asmresult29, 24, !dbg !211
  %idxprom14.i145 = and i64 %shr13.i144, 255, !dbg !212
  %arrayidx15.i146 = getelementptr inbounds [256 x i32], ptr getelementptr inbounds ([4 x [256 x i32]], ptr @crc32c_short, i64 0, i64 3, i64 0), i64 0, i64 %idxprom14.i145, !dbg !212
  %17 = load i32, ptr %arrayidx15.i146, align 4, !dbg !212, !tbaa !156
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i32 poison), metadata !100, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_xor, DW_OP_stack_value)), !dbg !116
  %18 = trunc i64 %asmresult30 to i32, !dbg !213
  %xor.i138 = xor i32 %14, %18, !dbg !214
  %xor11.i143 = xor i32 %xor.i138, %15, !dbg !215
  %xor16.i147 = xor i32 %xor11.i143, %16, !dbg !216
  %conv41 = xor i32 %xor16.i147, %17, !dbg !213
  tail call void @llvm.dbg.value(metadata ptr @crc32c_short, metadata !145, metadata !DIExpression()), !dbg !217
  tail call void @llvm.dbg.value(metadata i32 %conv41, metadata !151, metadata !DIExpression()), !dbg !217
  %and.i148 = and i32 %conv41, 255, !dbg !219
  %idxprom.i149 = zext nneg i32 %and.i148 to i64, !dbg !220
  %arrayidx1.i150 = getelementptr inbounds [256 x i32], ptr @crc32c_short, i64 0, i64 %idxprom.i149, !dbg !220
  %19 = load i32, ptr %arrayidx1.i150, align 4, !dbg !220, !tbaa !156
  %shr.i151 = lshr i32 %conv41, 8, !dbg !221
  %and3.i152 = and i32 %shr.i151, 255, !dbg !222
  %idxprom4.i153 = zext nneg i32 %and3.i152 to i64, !dbg !223
  %arrayidx5.i154 = getelementptr inbounds [256 x i32], ptr getelementptr inbounds ([4 x [256 x i32]], ptr @crc32c_short, i64 0, i64 1, i64 0), i64 0, i64 %idxprom4.i153, !dbg !223
  %20 = load i32, ptr %arrayidx5.i154, align 4, !dbg !223, !tbaa !156
  %xor.i155 = xor i32 %20, %19, !dbg !224
  %shr7.i156 = lshr i32 %conv41, 16, !dbg !225
  %and8.i157 = and i32 %shr7.i156, 255, !dbg !226
  %idxprom9.i158 = zext nneg i32 %and8.i157 to i64, !dbg !227
  %arrayidx10.i159 = getelementptr inbounds [256 x i32], ptr getelementptr inbounds ([4 x [256 x i32]], ptr @crc32c_short, i64 0, i64 2, i64 0), i64 0, i64 %idxprom9.i158, !dbg !227
  %21 = load i32, ptr %arrayidx10.i159, align 4, !dbg !227, !tbaa !156
  %xor11.i160 = xor i32 %xor.i155, %21, !dbg !228
  %shr13.i161 = lshr i32 %conv41, 24, !dbg !229
  %idxprom14.i162 = zext nneg i32 %shr13.i161 to i64, !dbg !230
  %arrayidx15.i163 = getelementptr inbounds [256 x i32], ptr getelementptr inbounds ([4 x [256 x i32]], ptr @crc32c_short, i64 0, i64 3, i64 0), i64 0, i64 %idxprom14.i162, !dbg !230
  %22 = load i32, ptr %arrayidx15.i163, align 4, !dbg !230, !tbaa !156
  %xor16.i164 = xor i32 %xor11.i160, %22, !dbg !231
  %conv43 = zext i32 %xor16.i164 to i64, !dbg !232
  %xor44 = xor i64 %asmresult31, %conv43, !dbg !233
  tail call void @llvm.dbg.value(metadata i64 %xor44, metadata !100, metadata !DIExpression()), !dbg !116
  %add.ptr45 = getelementptr inbounds i8, ptr %next.3182, i64 768, !dbg !234
  tail call void @llvm.dbg.value(metadata ptr %add.ptr45, metadata !101, metadata !DIExpression()), !dbg !116
  %sub46 = add nsw i64 %len.addr.2184, -768, !dbg !235
  tail call void @llvm.dbg.value(metadata i64 %sub46, metadata !99, metadata !DIExpression()), !dbg !116
  %cmp21 = icmp ugt i64 %sub46, 767, !dbg !134
  br i1 %cmp21, label %do.body28.preheader, label %while.end47, !dbg !135, !llvm.loop !236

while.end47:                                      ; preds = %do.end36, %while.cond20.preheader
  %next.3.lcssa = phi ptr [ %next.1.lcssa, %while.cond20.preheader ], [ %add.ptr45, %do.end36 ], !dbg !116
  %crc0.3.lcssa = phi i64 [ %crc0.1.lcssa, %while.cond20.preheader ], [ %xor44, %do.end36 ], !dbg !116
  %len.addr.2.lcssa = phi i64 [ %len.addr.1.lcssa, %while.cond20.preheader ], [ %sub46, %do.end36 ]
  %and49 = and i64 %len.addr.2.lcssa, 7, !dbg !238
  %sub50 = and i64 %len.addr.2.lcssa, 1016, !dbg !239
  %add.ptr51 = getelementptr inbounds i8, ptr %next.3.lcssa, i64 %sub50, !dbg !240
  tail call void @llvm.dbg.value(metadata ptr %add.ptr51, metadata !114, metadata !DIExpression()), !dbg !241
  tail call void @llvm.dbg.value(metadata i64 %crc0.3.lcssa, metadata !100, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata ptr %next.3.lcssa, metadata !101, metadata !DIExpression()), !dbg !116
  %cmp53188.not = icmp eq i64 %sub50, 0, !dbg !242
  br i1 %cmp53188.not, label %while.cond59.preheader, label %while.body55, !dbg !243

while.cond59.preheader:                           ; preds = %while.body55, %while.end47
  %next.5.lcssa = phi ptr [ %next.3.lcssa, %while.end47 ], [ %add.ptr56, %while.body55 ], !dbg !116
  %crc0.5.lcssa = phi i64 [ %crc0.3.lcssa, %while.end47 ], [ %23, %while.body55 ], !dbg !116
  tail call void @llvm.dbg.value(metadata i64 %and49, metadata !99, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata i64 %crc0.5.lcssa, metadata !100, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata ptr %next.5.lcssa, metadata !101, metadata !DIExpression()), !dbg !116
  %tobool60.not193 = icmp eq i64 %and49, 0, !dbg !244
  br i1 %tobool60.not193, label %while.end64, label %while.body61, !dbg !244

while.body55:                                     ; preds = %while.end47, %while.body55
  %crc0.5190 = phi i64 [ %23, %while.body55 ], [ %crc0.3.lcssa, %while.end47 ]
  %next.5189 = phi ptr [ %add.ptr56, %while.body55 ], [ %next.3.lcssa, %while.end47 ]
  tail call void @llvm.dbg.value(metadata i64 %crc0.5190, metadata !100, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata ptr %next.5189, metadata !101, metadata !DIExpression()), !dbg !116
  %23 = tail call i64 asm "crc32q\09($1), $0", "=r,r,*m,0,~{dirflag},~{fpsr},~{flags}"(ptr %next.5189, ptr elementtype(i8) %next.5189, i64 %crc0.5190) #13, !dbg !245, !srcloc !247
  tail call void @llvm.dbg.value(metadata i64 %23, metadata !100, metadata !DIExpression()), !dbg !116
  %add.ptr56 = getelementptr inbounds i8, ptr %next.5189, i64 8, !dbg !248
  tail call void @llvm.dbg.value(metadata ptr %add.ptr56, metadata !101, metadata !DIExpression()), !dbg !116
  %cmp53 = icmp ult ptr %add.ptr56, %add.ptr51, !dbg !242
  br i1 %cmp53, label %while.body55, label %while.cond59.preheader, !dbg !243, !llvm.loop !249

while.body61:                                     ; preds = %while.cond59.preheader, %while.body61
  %len.addr.3196 = phi i64 [ %dec63, %while.body61 ], [ %and49, %while.cond59.preheader ]
  %crc0.6195 = phi i64 [ %24, %while.body61 ], [ %crc0.5.lcssa, %while.cond59.preheader ]
  %next.6194 = phi ptr [ %incdec.ptr62, %while.body61 ], [ %next.5.lcssa, %while.cond59.preheader ]
  tail call void @llvm.dbg.value(metadata i64 %len.addr.3196, metadata !99, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata i64 %crc0.6195, metadata !100, metadata !DIExpression()), !dbg !116
  tail call void @llvm.dbg.value(metadata ptr %next.6194, metadata !101, metadata !DIExpression()), !dbg !116
  %24 = tail call i64 asm "crc32b\09($1), $0", "=r,r,*m,0,~{dirflag},~{fpsr},~{flags}"(ptr %next.6194, ptr elementtype(i8) %next.6194, i64 %crc0.6195) #13, !dbg !251, !srcloc !253
  tail call void @llvm.dbg.value(metadata i64 %24, metadata !100, metadata !DIExpression()), !dbg !116
  %incdec.ptr62 = getelementptr inbounds i8, ptr %next.6194, i64 1, !dbg !254
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr62, metadata !101, metadata !DIExpression()), !dbg !116
  %dec63 = add nsw i64 %len.addr.3196, -1, !dbg !255
  tail call void @llvm.dbg.value(metadata i64 %dec63, metadata !99, metadata !DIExpression()), !dbg !116
  %tobool60.not = icmp eq i64 %dec63, 0, !dbg !244
  br i1 %tobool60.not, label %while.end64, label %while.body61, !dbg !244, !llvm.loop !256

while.end64:                                      ; preds = %while.body61, %while.cond59.preheader
  %crc0.6.lcssa = phi i64 [ %crc0.5.lcssa, %while.cond59.preheader ], [ %24, %while.body61 ], !dbg !116
  %25 = trunc i64 %crc0.6.lcssa to i32, !dbg !258
  %conv66 = xor i32 %25, -1, !dbg !258
  ret i32 %conv66, !dbg !259
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local i32 @crc32c_sw(i32 noundef %crc, ptr noundef %buf, i64 noundef %len) #2 !dbg !20 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %crc, metadata !31, metadata !DIExpression()), !dbg !260
  tail call void @llvm.dbg.value(metadata ptr %buf, metadata !32, metadata !DIExpression()), !dbg !260
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !33, metadata !DIExpression()), !dbg !260
  %call = tail call i32 @crc32c_sw_little(i32 noundef %crc, ptr noundef %buf, i64 noundef %len), !dbg !261
  ret i32 %call, !dbg !263
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local i32 @crc32c_sw_little(i32 noundef %crc, ptr noundef %buf, i64 noundef %len) local_unnamed_addr #2 !dbg !264 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %crc, metadata !266, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata ptr %buf, metadata !267, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !268, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata ptr %buf, metadata !269, metadata !DIExpression()), !dbg !273
  %call = tail call i32 @pthread_once(ptr noundef nonnull @crc32c_once_little, ptr noundef nonnull @crc32c_init_sw_little) #12, !dbg !274
  %not = xor i32 %crc, -1, !dbg !275
  tail call void @llvm.dbg.value(metadata i32 %not, metadata !266, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata ptr %buf, metadata !269, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !268, metadata !DIExpression()), !dbg !273
  %tobool.not79 = icmp eq i64 %len, 0, !dbg !276
  %0 = ptrtoint ptr %buf to i64
  %and80 = and i64 %0, 7
  %cmp.not81 = icmp eq i64 %and80, 0
  %or.cond82 = or i1 %tobool.not79, %cmp.not81, !dbg !277
  br i1 %or.cond82, label %while.end, label %while.body, !dbg !277

while.body:                                       ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr %buf, metadata !269, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !268, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i32 %not, metadata !266, metadata !DIExpression()), !dbg !273
  %incdec.ptr = getelementptr inbounds i8, ptr %buf, i64 1, !dbg !278
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !269, metadata !DIExpression()), !dbg !273
  %1 = load i8, ptr %buf, align 1, !dbg !280, !tbaa !281
  %crc.addr.0.tr = trunc i32 %not to i8, !dbg !282
  %xor.narrow = xor i8 %1, %crc.addr.0.tr, !dbg !282
  %idxprom = zext i8 %xor.narrow to i64, !dbg !283
  %arrayidx = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom, !dbg !283
  %2 = load i32, ptr %arrayidx, align 4, !dbg !283, !tbaa !156
  %shr = lshr i32 %not, 8, !dbg !284
  %xor2 = xor i32 %2, %shr, !dbg !285
  tail call void @llvm.dbg.value(metadata i32 %xor2, metadata !266, metadata !DIExpression()), !dbg !273
  %dec = add i64 %len, -1, !dbg !286
  tail call void @llvm.dbg.value(metadata i64 %dec, metadata !268, metadata !DIExpression()), !dbg !273
  %tobool.not = icmp eq i64 %dec, 0, !dbg !276
  %3 = ptrtoint ptr %incdec.ptr to i64
  %and = and i64 %3, 7
  %cmp.not = icmp eq i64 %and, 0
  %or.cond = select i1 %tobool.not, i1 true, i1 %cmp.not, !dbg !277
  br i1 %or.cond, label %while.end, label %while.body.1, !dbg !277, !llvm.loop !287

while.body.1:                                     ; preds = %while.body
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !269, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %dec, metadata !268, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i32 %xor2, metadata !266, metadata !DIExpression()), !dbg !273
  %incdec.ptr.1 = getelementptr inbounds i8, ptr %buf, i64 2, !dbg !278
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.1, metadata !269, metadata !DIExpression()), !dbg !273
  %4 = load i8, ptr %incdec.ptr, align 1, !dbg !280, !tbaa !281
  %crc.addr.0.tr.1 = trunc i32 %xor2 to i8, !dbg !282
  %xor.narrow.1 = xor i8 %4, %crc.addr.0.tr.1, !dbg !282
  %idxprom.1 = zext i8 %xor.narrow.1 to i64, !dbg !283
  %arrayidx.1 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom.1, !dbg !283
  %5 = load i32, ptr %arrayidx.1, align 4, !dbg !283, !tbaa !156
  %shr.1 = lshr i32 %xor2, 8, !dbg !284
  %xor2.1 = xor i32 %5, %shr.1, !dbg !285
  tail call void @llvm.dbg.value(metadata i32 %xor2.1, metadata !266, metadata !DIExpression()), !dbg !273
  %dec.1 = add i64 %len, -2, !dbg !286
  tail call void @llvm.dbg.value(metadata i64 %dec.1, metadata !268, metadata !DIExpression()), !dbg !273
  %tobool.not.1 = icmp eq i64 %dec.1, 0, !dbg !276
  %6 = ptrtoint ptr %incdec.ptr.1 to i64
  %and.1 = and i64 %6, 7
  %cmp.not.1 = icmp eq i64 %and.1, 0
  %or.cond.1 = select i1 %tobool.not.1, i1 true, i1 %cmp.not.1, !dbg !277
  br i1 %or.cond.1, label %while.end, label %while.body.2, !dbg !277, !llvm.loop !287

while.body.2:                                     ; preds = %while.body.1
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.1, metadata !269, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %dec.1, metadata !268, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i32 %xor2.1, metadata !266, metadata !DIExpression()), !dbg !273
  %incdec.ptr.2 = getelementptr inbounds i8, ptr %buf, i64 3, !dbg !278
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.2, metadata !269, metadata !DIExpression()), !dbg !273
  %7 = load i8, ptr %incdec.ptr.1, align 1, !dbg !280, !tbaa !281
  %crc.addr.0.tr.2 = trunc i32 %xor2.1 to i8, !dbg !282
  %xor.narrow.2 = xor i8 %7, %crc.addr.0.tr.2, !dbg !282
  %idxprom.2 = zext i8 %xor.narrow.2 to i64, !dbg !283
  %arrayidx.2 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom.2, !dbg !283
  %8 = load i32, ptr %arrayidx.2, align 4, !dbg !283, !tbaa !156
  %shr.2 = lshr i32 %xor2.1, 8, !dbg !284
  %xor2.2 = xor i32 %8, %shr.2, !dbg !285
  tail call void @llvm.dbg.value(metadata i32 %xor2.2, metadata !266, metadata !DIExpression()), !dbg !273
  %dec.2 = add i64 %len, -3, !dbg !286
  tail call void @llvm.dbg.value(metadata i64 %dec.2, metadata !268, metadata !DIExpression()), !dbg !273
  %tobool.not.2 = icmp eq i64 %dec.2, 0, !dbg !276
  %9 = ptrtoint ptr %incdec.ptr.2 to i64
  %and.2 = and i64 %9, 7
  %cmp.not.2 = icmp eq i64 %and.2, 0
  %or.cond.2 = select i1 %tobool.not.2, i1 true, i1 %cmp.not.2, !dbg !277
  br i1 %or.cond.2, label %while.end, label %while.body.3, !dbg !277, !llvm.loop !287

while.body.3:                                     ; preds = %while.body.2
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.2, metadata !269, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %dec.2, metadata !268, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i32 %xor2.2, metadata !266, metadata !DIExpression()), !dbg !273
  %incdec.ptr.3 = getelementptr inbounds i8, ptr %buf, i64 4, !dbg !278
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.3, metadata !269, metadata !DIExpression()), !dbg !273
  %10 = load i8, ptr %incdec.ptr.2, align 1, !dbg !280, !tbaa !281
  %crc.addr.0.tr.3 = trunc i32 %xor2.2 to i8, !dbg !282
  %xor.narrow.3 = xor i8 %10, %crc.addr.0.tr.3, !dbg !282
  %idxprom.3 = zext i8 %xor.narrow.3 to i64, !dbg !283
  %arrayidx.3 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom.3, !dbg !283
  %11 = load i32, ptr %arrayidx.3, align 4, !dbg !283, !tbaa !156
  %shr.3 = lshr i32 %xor2.2, 8, !dbg !284
  %xor2.3 = xor i32 %11, %shr.3, !dbg !285
  tail call void @llvm.dbg.value(metadata i32 %xor2.3, metadata !266, metadata !DIExpression()), !dbg !273
  %dec.3 = add i64 %len, -4, !dbg !286
  tail call void @llvm.dbg.value(metadata i64 %dec.3, metadata !268, metadata !DIExpression()), !dbg !273
  %tobool.not.3 = icmp eq i64 %dec.3, 0, !dbg !276
  %12 = ptrtoint ptr %incdec.ptr.3 to i64
  %and.3 = and i64 %12, 7
  %cmp.not.3 = icmp eq i64 %and.3, 0
  %or.cond.3 = select i1 %tobool.not.3, i1 true, i1 %cmp.not.3, !dbg !277
  br i1 %or.cond.3, label %while.end, label %while.body.4, !dbg !277, !llvm.loop !287

while.body.4:                                     ; preds = %while.body.3
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.3, metadata !269, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %dec.3, metadata !268, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i32 %xor2.3, metadata !266, metadata !DIExpression()), !dbg !273
  %incdec.ptr.4 = getelementptr inbounds i8, ptr %buf, i64 5, !dbg !278
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.4, metadata !269, metadata !DIExpression()), !dbg !273
  %13 = load i8, ptr %incdec.ptr.3, align 1, !dbg !280, !tbaa !281
  %crc.addr.0.tr.4 = trunc i32 %xor2.3 to i8, !dbg !282
  %xor.narrow.4 = xor i8 %13, %crc.addr.0.tr.4, !dbg !282
  %idxprom.4 = zext i8 %xor.narrow.4 to i64, !dbg !283
  %arrayidx.4 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom.4, !dbg !283
  %14 = load i32, ptr %arrayidx.4, align 4, !dbg !283, !tbaa !156
  %shr.4 = lshr i32 %xor2.3, 8, !dbg !284
  %xor2.4 = xor i32 %14, %shr.4, !dbg !285
  tail call void @llvm.dbg.value(metadata i32 %xor2.4, metadata !266, metadata !DIExpression()), !dbg !273
  %dec.4 = add i64 %len, -5, !dbg !286
  tail call void @llvm.dbg.value(metadata i64 %dec.4, metadata !268, metadata !DIExpression()), !dbg !273
  %tobool.not.4 = icmp eq i64 %dec.4, 0, !dbg !276
  %15 = ptrtoint ptr %incdec.ptr.4 to i64
  %and.4 = and i64 %15, 7
  %cmp.not.4 = icmp eq i64 %and.4, 0
  %or.cond.4 = select i1 %tobool.not.4, i1 true, i1 %cmp.not.4, !dbg !277
  br i1 %or.cond.4, label %while.end, label %while.body.5, !dbg !277, !llvm.loop !287

while.body.5:                                     ; preds = %while.body.4
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.4, metadata !269, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %dec.4, metadata !268, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i32 %xor2.4, metadata !266, metadata !DIExpression()), !dbg !273
  %incdec.ptr.5 = getelementptr inbounds i8, ptr %buf, i64 6, !dbg !278
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.5, metadata !269, metadata !DIExpression()), !dbg !273
  %16 = load i8, ptr %incdec.ptr.4, align 1, !dbg !280, !tbaa !281
  %crc.addr.0.tr.5 = trunc i32 %xor2.4 to i8, !dbg !282
  %xor.narrow.5 = xor i8 %16, %crc.addr.0.tr.5, !dbg !282
  %idxprom.5 = zext i8 %xor.narrow.5 to i64, !dbg !283
  %arrayidx.5 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom.5, !dbg !283
  %17 = load i32, ptr %arrayidx.5, align 4, !dbg !283, !tbaa !156
  %shr.5 = lshr i32 %xor2.4, 8, !dbg !284
  %xor2.5 = xor i32 %17, %shr.5, !dbg !285
  tail call void @llvm.dbg.value(metadata i32 %xor2.5, metadata !266, metadata !DIExpression()), !dbg !273
  %dec.5 = add i64 %len, -6, !dbg !286
  tail call void @llvm.dbg.value(metadata i64 %dec.5, metadata !268, metadata !DIExpression()), !dbg !273
  %tobool.not.5 = icmp eq i64 %dec.5, 0, !dbg !276
  %18 = ptrtoint ptr %incdec.ptr.5 to i64
  %and.5 = and i64 %18, 7
  %cmp.not.5 = icmp eq i64 %and.5, 0
  %or.cond.5 = select i1 %tobool.not.5, i1 true, i1 %cmp.not.5, !dbg !277
  br i1 %or.cond.5, label %while.end, label %while.body.6, !dbg !277, !llvm.loop !287

while.body.6:                                     ; preds = %while.body.5
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.5, metadata !269, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %dec.5, metadata !268, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i32 %xor2.5, metadata !266, metadata !DIExpression()), !dbg !273
  %incdec.ptr.6 = getelementptr inbounds i8, ptr %buf, i64 7, !dbg !278
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.6, metadata !269, metadata !DIExpression()), !dbg !273
  %19 = load i8, ptr %incdec.ptr.5, align 1, !dbg !280, !tbaa !281
  %crc.addr.0.tr.6 = trunc i32 %xor2.5 to i8, !dbg !282
  %xor.narrow.6 = xor i8 %19, %crc.addr.0.tr.6, !dbg !282
  %idxprom.6 = zext i8 %xor.narrow.6 to i64, !dbg !283
  %arrayidx.6 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom.6, !dbg !283
  %20 = load i32, ptr %arrayidx.6, align 4, !dbg !283, !tbaa !156
  %shr.6 = lshr i32 %xor2.5, 8, !dbg !284
  %xor2.6 = xor i32 %20, %shr.6, !dbg !285
  tail call void @llvm.dbg.value(metadata i32 %xor2.6, metadata !266, metadata !DIExpression()), !dbg !273
  %dec.6 = add i64 %len, -7, !dbg !286
  tail call void @llvm.dbg.value(metadata i64 %dec.6, metadata !268, metadata !DIExpression()), !dbg !273
  %tobool.not.6 = icmp eq i64 %dec.6, 0, !dbg !276
  %21 = ptrtoint ptr %incdec.ptr.6 to i64
  %and.6 = and i64 %21, 7
  %cmp.not.6 = icmp eq i64 %and.6, 0
  %or.cond.6 = select i1 %tobool.not.6, i1 true, i1 %cmp.not.6, !dbg !277
  br i1 %or.cond.6, label %while.end, label %while.body.7, !dbg !277, !llvm.loop !287

while.body.7:                                     ; preds = %while.body.6
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.6, metadata !269, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %dec.6, metadata !268, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i32 %xor2.6, metadata !266, metadata !DIExpression()), !dbg !273
  %incdec.ptr.7 = getelementptr inbounds i8, ptr %buf, i64 8, !dbg !278
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.7, metadata !269, metadata !DIExpression()), !dbg !273
  %22 = load i8, ptr %incdec.ptr.6, align 1, !dbg !280, !tbaa !281
  %crc.addr.0.tr.7 = trunc i32 %xor2.6 to i8, !dbg !282
  %xor.narrow.7 = xor i8 %22, %crc.addr.0.tr.7, !dbg !282
  %idxprom.7 = zext i8 %xor.narrow.7 to i64, !dbg !283
  %arrayidx.7 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom.7, !dbg !283
  %23 = load i32, ptr %arrayidx.7, align 4, !dbg !283, !tbaa !156
  %shr.7 = lshr i32 %xor2.6, 8, !dbg !284
  %xor2.7 = xor i32 %23, %shr.7, !dbg !285
  tail call void @llvm.dbg.value(metadata i32 %xor2.7, metadata !266, metadata !DIExpression()), !dbg !273
  %dec.7 = add i64 %len, -8, !dbg !286
  tail call void @llvm.dbg.value(metadata i64 %dec.7, metadata !268, metadata !DIExpression()), !dbg !273
  br label %while.end

while.end:                                        ; preds = %while.body, %while.body.1, %while.body.2, %while.body.3, %while.body.4, %while.body.5, %while.body.6, %while.body.7, %entry
  %crc.addr.0.lcssa = phi i32 [ %not, %entry ], [ %xor2, %while.body ], [ %xor2.1, %while.body.1 ], [ %xor2.2, %while.body.2 ], [ %xor2.3, %while.body.3 ], [ %xor2.4, %while.body.4 ], [ %xor2.5, %while.body.5 ], [ %xor2.6, %while.body.6 ], [ %xor2.7, %while.body.7 ], !dbg !273
  %len.addr.0.lcssa = phi i64 [ %len, %entry ], [ %dec, %while.body ], [ %dec.1, %while.body.1 ], [ %dec.2, %while.body.2 ], [ %dec.3, %while.body.3 ], [ %dec.4, %while.body.4 ], [ %dec.5, %while.body.5 ], [ %dec.6, %while.body.6 ], [ %dec.7, %while.body.7 ]
  %next.0.lcssa = phi ptr [ %buf, %entry ], [ %incdec.ptr, %while.body ], [ %incdec.ptr.1, %while.body.1 ], [ %incdec.ptr.2, %while.body.2 ], [ %incdec.ptr.3, %while.body.3 ], [ %incdec.ptr.4, %while.body.4 ], [ %incdec.ptr.5, %while.body.5 ], [ %incdec.ptr.6, %while.body.6 ], [ %incdec.ptr.7, %while.body.7 ], !dbg !273
  %cmp3 = icmp ugt i64 %len.addr.0.lcssa, 7, !dbg !290
  br i1 %cmp3, label %do.body, label %if.end, !dbg !291

do.body:                                          ; preds = %while.end, %do.body
  %len.addr.1 = phi i64 [ %sub, %do.body ], [ %len.addr.0.lcssa, %while.end ]
  %next.1 = phi ptr [ %add.ptr, %do.body ], [ %next.0.lcssa, %while.end ], !dbg !273
  %crcw.0.in = phi i32 [ %xor35, %do.body ], [ %crc.addr.0.lcssa, %while.end ]
  %crcw.0 = zext i32 %crcw.0.in to i64, !dbg !292
  tail call void @llvm.dbg.value(metadata i64 %crcw.0, metadata !270, metadata !DIExpression()), !dbg !292
  tail call void @llvm.dbg.value(metadata ptr %next.1, metadata !269, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %len.addr.1, metadata !268, metadata !DIExpression()), !dbg !273
  %24 = load i64, ptr %next.1, align 8, !dbg !293, !tbaa !295
  %xor6 = xor i64 %24, %crcw.0, !dbg !297
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %24, i64 %crcw.0), metadata !270, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_xor, DW_OP_stack_value)), !dbg !292
  %and7 = and i64 %xor6, 255, !dbg !298
  %arrayidx8 = getelementptr inbounds [8 x [256 x i32]], ptr @crc32c_table_little, i64 0, i64 7, i64 %and7, !dbg !299
  %25 = load i32, ptr %arrayidx8, align 4, !dbg !299, !tbaa !156
  %shr9 = lshr i64 %xor6, 8, !dbg !300
  %and10 = and i64 %shr9, 255, !dbg !301
  %arrayidx11 = getelementptr inbounds [8 x [256 x i32]], ptr @crc32c_table_little, i64 0, i64 6, i64 %and10, !dbg !302
  %26 = load i32, ptr %arrayidx11, align 4, !dbg !302, !tbaa !156
  %xor12 = xor i32 %26, %25, !dbg !303
  %shr13 = lshr i64 %xor6, 16, !dbg !304
  %and14 = and i64 %shr13, 255, !dbg !305
  %arrayidx15 = getelementptr inbounds [8 x [256 x i32]], ptr @crc32c_table_little, i64 0, i64 5, i64 %and14, !dbg !306
  %27 = load i32, ptr %arrayidx15, align 4, !dbg !306, !tbaa !156
  %xor16 = xor i32 %xor12, %27, !dbg !307
  %shr17 = lshr i64 %xor6, 24, !dbg !308
  %and18 = and i64 %shr17, 255, !dbg !309
  %arrayidx19 = getelementptr inbounds [8 x [256 x i32]], ptr @crc32c_table_little, i64 0, i64 4, i64 %and18, !dbg !310
  %28 = load i32, ptr %arrayidx19, align 4, !dbg !310, !tbaa !156
  %xor20 = xor i32 %xor16, %28, !dbg !311
  %shr21 = lshr i64 %24, 32, !dbg !312
  %and22 = and i64 %shr21, 255, !dbg !313
  %arrayidx23 = getelementptr inbounds [8 x [256 x i32]], ptr @crc32c_table_little, i64 0, i64 3, i64 %and22, !dbg !314
  %29 = load i32, ptr %arrayidx23, align 4, !dbg !314, !tbaa !156
  %xor24 = xor i32 %xor20, %29, !dbg !315
  %shr25 = lshr i64 %24, 40, !dbg !316
  %and26 = and i64 %shr25, 255, !dbg !317
  %arrayidx27 = getelementptr inbounds [8 x [256 x i32]], ptr @crc32c_table_little, i64 0, i64 2, i64 %and26, !dbg !318
  %30 = load i32, ptr %arrayidx27, align 4, !dbg !318, !tbaa !156
  %xor28 = xor i32 %xor24, %30, !dbg !319
  %shr29 = lshr i64 %24, 48, !dbg !320
  %and30 = and i64 %shr29, 255, !dbg !321
  %arrayidx31 = getelementptr inbounds [8 x [256 x i32]], ptr @crc32c_table_little, i64 0, i64 1, i64 %and30, !dbg !322
  %31 = load i32, ptr %arrayidx31, align 4, !dbg !322, !tbaa !156
  %xor32 = xor i32 %xor28, %31, !dbg !323
  %shr33 = lshr i64 %24, 56, !dbg !324
  %arrayidx34 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %shr33, !dbg !325
  %32 = load i32, ptr %arrayidx34, align 4, !dbg !325, !tbaa !156
  %xor35 = xor i32 %xor32, %32, !dbg !326
  tail call void @llvm.dbg.value(metadata i32 %xor35, metadata !270, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !292
  %add.ptr = getelementptr inbounds i8, ptr %next.1, i64 8, !dbg !327
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !269, metadata !DIExpression()), !dbg !273
  %sub = add i64 %len.addr.1, -8, !dbg !328
  tail call void @llvm.dbg.value(metadata i64 %sub, metadata !268, metadata !DIExpression()), !dbg !273
  %cmp37 = icmp ugt i64 %sub, 7, !dbg !329
  br i1 %cmp37, label %do.body, label %if.end, !dbg !330, !llvm.loop !331

if.end:                                           ; preds = %do.body, %while.end
  %crc.addr.1 = phi i32 [ %crc.addr.0.lcssa, %while.end ], [ %xor35, %do.body ], !dbg !273
  %len.addr.2 = phi i64 [ %len.addr.0.lcssa, %while.end ], [ %sub, %do.body ]
  %next.2 = phi ptr [ %next.0.lcssa, %while.end ], [ %add.ptr, %do.body ], !dbg !273
  tail call void @llvm.dbg.value(metadata ptr %next.2, metadata !269, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %len.addr.2, metadata !268, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i32 %crc.addr.1, metadata !266, metadata !DIExpression()), !dbg !273
  %tobool41.not88 = icmp eq i64 %len.addr.2, 0, !dbg !334
  br i1 %tobool41.not88, label %while.end52, label %while.body42.preheader, !dbg !334

while.body42.preheader:                           ; preds = %if.end
  %xtraiter = and i64 %len.addr.2, 1, !dbg !334
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0, !dbg !334
  br i1 %lcmp.mod.not, label %while.body42.prol.loopexit, label %while.body42.prol, !dbg !334

while.body42.prol:                                ; preds = %while.body42.preheader
  tail call void @llvm.dbg.value(metadata ptr %next.2, metadata !269, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %len.addr.2, metadata !268, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i32 %crc.addr.1, metadata !266, metadata !DIExpression()), !dbg !273
  %incdec.ptr43.prol = getelementptr inbounds i8, ptr %next.2, i64 1, !dbg !335
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr43.prol, metadata !269, metadata !DIExpression()), !dbg !273
  %33 = load i8, ptr %next.2, align 1, !dbg !337, !tbaa !281
  %crc.addr.2.tr.prol = trunc i32 %crc.addr.1 to i8, !dbg !338
  %xor45.narrow.prol = xor i8 %33, %crc.addr.2.tr.prol, !dbg !338
  %idxprom47.prol = zext i8 %xor45.narrow.prol to i64, !dbg !339
  %arrayidx48.prol = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom47.prol, !dbg !339
  %34 = load i32, ptr %arrayidx48.prol, align 4, !dbg !339, !tbaa !156
  %shr49.prol = lshr i32 %crc.addr.1, 8, !dbg !340
  %xor50.prol = xor i32 %34, %shr49.prol, !dbg !341
  tail call void @llvm.dbg.value(metadata i32 %xor50.prol, metadata !266, metadata !DIExpression()), !dbg !273
  %dec51.prol = add nsw i64 %len.addr.2, -1, !dbg !342
  tail call void @llvm.dbg.value(metadata i64 %dec51.prol, metadata !268, metadata !DIExpression()), !dbg !273
  br label %while.body42.prol.loopexit, !dbg !334

while.body42.prol.loopexit:                       ; preds = %while.body42.prol, %while.body42.preheader
  %xor50.lcssa.unr = phi i32 [ undef, %while.body42.preheader ], [ %xor50.prol, %while.body42.prol ]
  %next.391.unr = phi ptr [ %next.2, %while.body42.preheader ], [ %incdec.ptr43.prol, %while.body42.prol ]
  %len.addr.390.unr = phi i64 [ %len.addr.2, %while.body42.preheader ], [ %dec51.prol, %while.body42.prol ]
  %crc.addr.289.unr = phi i32 [ %crc.addr.1, %while.body42.preheader ], [ %xor50.prol, %while.body42.prol ]
  %35 = icmp eq i64 %len.addr.2, 1, !dbg !334
  br i1 %35, label %while.end52, label %while.body42, !dbg !334

while.body42:                                     ; preds = %while.body42.prol.loopexit, %while.body42
  %next.391 = phi ptr [ %incdec.ptr43.1, %while.body42 ], [ %next.391.unr, %while.body42.prol.loopexit ]
  %len.addr.390 = phi i64 [ %dec51.1, %while.body42 ], [ %len.addr.390.unr, %while.body42.prol.loopexit ]
  %crc.addr.289 = phi i32 [ %xor50.1, %while.body42 ], [ %crc.addr.289.unr, %while.body42.prol.loopexit ]
  tail call void @llvm.dbg.value(metadata ptr %next.391, metadata !269, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %len.addr.390, metadata !268, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i32 %crc.addr.289, metadata !266, metadata !DIExpression()), !dbg !273
  %incdec.ptr43 = getelementptr inbounds i8, ptr %next.391, i64 1, !dbg !335
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr43, metadata !269, metadata !DIExpression()), !dbg !273
  %36 = load i8, ptr %next.391, align 1, !dbg !337, !tbaa !281
  %crc.addr.2.tr = trunc i32 %crc.addr.289 to i8, !dbg !338
  %xor45.narrow = xor i8 %36, %crc.addr.2.tr, !dbg !338
  %idxprom47 = zext i8 %xor45.narrow to i64, !dbg !339
  %arrayidx48 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom47, !dbg !339
  %37 = load i32, ptr %arrayidx48, align 4, !dbg !339, !tbaa !156
  %shr49 = lshr i32 %crc.addr.289, 8, !dbg !340
  %xor50 = xor i32 %37, %shr49, !dbg !341
  tail call void @llvm.dbg.value(metadata i32 %xor50, metadata !266, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %len.addr.390, metadata !268, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !273
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr43, metadata !269, metadata !DIExpression()), !dbg !273
  tail call void @llvm.dbg.value(metadata i64 %len.addr.390, metadata !268, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !273
  tail call void @llvm.dbg.value(metadata i32 %xor50, metadata !266, metadata !DIExpression()), !dbg !273
  %incdec.ptr43.1 = getelementptr inbounds i8, ptr %next.391, i64 2, !dbg !335
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr43.1, metadata !269, metadata !DIExpression()), !dbg !273
  %38 = load i8, ptr %incdec.ptr43, align 1, !dbg !337, !tbaa !281
  %crc.addr.2.tr.1 = trunc i32 %xor50 to i8, !dbg !338
  %xor45.narrow.1 = xor i8 %38, %crc.addr.2.tr.1, !dbg !338
  %idxprom47.1 = zext i8 %xor45.narrow.1 to i64, !dbg !339
  %arrayidx48.1 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom47.1, !dbg !339
  %39 = load i32, ptr %arrayidx48.1, align 4, !dbg !339, !tbaa !156
  %shr49.1 = lshr i32 %xor50, 8, !dbg !340
  %xor50.1 = xor i32 %39, %shr49.1, !dbg !341
  tail call void @llvm.dbg.value(metadata i32 %xor50.1, metadata !266, metadata !DIExpression()), !dbg !273
  %dec51.1 = add nsw i64 %len.addr.390, -2, !dbg !342
  tail call void @llvm.dbg.value(metadata i64 %dec51.1, metadata !268, metadata !DIExpression()), !dbg !273
  %tobool41.not.1 = icmp eq i64 %dec51.1, 0, !dbg !334
  br i1 %tobool41.not.1, label %while.end52, label %while.body42, !dbg !334, !llvm.loop !343

while.end52:                                      ; preds = %while.body42.prol.loopexit, %while.body42, %if.end
  %crc.addr.2.lcssa = phi i32 [ %crc.addr.1, %if.end ], [ %xor50.lcssa.unr, %while.body42.prol.loopexit ], [ %xor50.1, %while.body42 ], !dbg !273
  %not53 = xor i32 %crc.addr.2.lcssa, -1, !dbg !345
  ret i32 %not53, !dbg !346
}

declare !dbg !347 i32 @pthread_once(ptr noundef, ptr noundef) local_unnamed_addr #3

; Function Attrs: nofree norecurse nosync nounwind sanitize_thread memory(readwrite, argmem: none, inaccessiblemem: none) uwtable
define internal void @crc32c_init_sw_little() #4 !dbg !353 {
entry:
  tail call void @llvm.dbg.value(metadata i32 0, metadata !355, metadata !DIExpression()), !dbg !367
  br label %vector.body, !dbg !368

vector.body:                                      ; preds = %vector.body, %entry
  %index = phi i64 [ 0, %entry ], [ %index.next, %vector.body ], !dbg !369
  %vec.ind = phi <4 x i32> [ <i32 0, i32 1, i32 2, i32 3>, %entry ], [ %vec.ind.next, %vector.body ], !dbg !370
  %0 = and <4 x i32> %vec.ind, <i32 1, i32 1, i32 1, i32 1>, !dbg !370
  %1 = icmp eq <4 x i32> %0, zeroinitializer, !dbg !370
  %2 = lshr <4 x i32> %vec.ind, <i32 1, i32 1, i32 1, i32 1>, !dbg !371
  %3 = xor <4 x i32> %2, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !371
  %4 = select <4 x i1> %1, <4 x i32> %2, <4 x i32> %3, !dbg !371
  %5 = and <4 x i32> %4, <i32 1, i32 1, i32 1, i32 1>, !dbg !372
  %6 = icmp eq <4 x i32> %5, zeroinitializer, !dbg !372
  %7 = lshr <4 x i32> %4, <i32 1, i32 1, i32 1, i32 1>, !dbg !373
  %8 = xor <4 x i32> %7, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !373
  %9 = select <4 x i1> %6, <4 x i32> %7, <4 x i32> %8, !dbg !373
  %10 = and <4 x i32> %9, <i32 1, i32 1, i32 1, i32 1>, !dbg !374
  %11 = icmp eq <4 x i32> %10, zeroinitializer, !dbg !374
  %12 = lshr <4 x i32> %9, <i32 1, i32 1, i32 1, i32 1>, !dbg !375
  %13 = xor <4 x i32> %12, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !375
  %14 = select <4 x i1> %11, <4 x i32> %12, <4 x i32> %13, !dbg !375
  %15 = and <4 x i32> %14, <i32 1, i32 1, i32 1, i32 1>, !dbg !376
  %16 = icmp eq <4 x i32> %15, zeroinitializer, !dbg !376
  %17 = lshr <4 x i32> %14, <i32 1, i32 1, i32 1, i32 1>, !dbg !377
  %18 = xor <4 x i32> %17, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !377
  %19 = select <4 x i1> %16, <4 x i32> %17, <4 x i32> %18, !dbg !377
  %20 = and <4 x i32> %19, <i32 1, i32 1, i32 1, i32 1>, !dbg !378
  %21 = icmp eq <4 x i32> %20, zeroinitializer, !dbg !378
  %22 = lshr <4 x i32> %19, <i32 1, i32 1, i32 1, i32 1>, !dbg !379
  %23 = xor <4 x i32> %22, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !379
  %24 = select <4 x i1> %21, <4 x i32> %22, <4 x i32> %23, !dbg !379
  %25 = and <4 x i32> %24, <i32 1, i32 1, i32 1, i32 1>, !dbg !380
  %26 = icmp eq <4 x i32> %25, zeroinitializer, !dbg !380
  %27 = lshr <4 x i32> %24, <i32 1, i32 1, i32 1, i32 1>, !dbg !381
  %28 = xor <4 x i32> %27, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !381
  %29 = select <4 x i1> %26, <4 x i32> %27, <4 x i32> %28, !dbg !381
  %30 = and <4 x i32> %29, <i32 1, i32 1, i32 1, i32 1>, !dbg !382
  %31 = icmp eq <4 x i32> %30, zeroinitializer, !dbg !382
  %32 = lshr <4 x i32> %29, <i32 1, i32 1, i32 1, i32 1>, !dbg !383
  %33 = xor <4 x i32> %32, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !383
  %34 = select <4 x i1> %31, <4 x i32> %32, <4 x i32> %33, !dbg !383
  %35 = and <4 x i32> %34, <i32 1, i32 1, i32 1, i32 1>, !dbg !384
  %36 = icmp eq <4 x i32> %35, zeroinitializer, !dbg !384
  %37 = lshr <4 x i32> %34, <i32 1, i32 1, i32 1, i32 1>, !dbg !385
  %38 = xor <4 x i32> %37, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !385
  %39 = select <4 x i1> %36, <4 x i32> %37, <4 x i32> %38, !dbg !385
  %40 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %index, !dbg !386
  store <4 x i32> %39, ptr %40, align 16, !dbg !387, !tbaa !156
  %index.next = add nuw i64 %index, 4, !dbg !369
  %vec.ind.next = add <4 x i32> %vec.ind, <i32 4, i32 4, i32 4, i32 4>, !dbg !370
  %41 = icmp eq i64 %index.next, 256, !dbg !369
  br i1 %41, label %for.body69, label %vector.body, !dbg !369, !llvm.loop !388

for.cond.cleanup68:                               ; preds = %for.body69
  ret void, !dbg !392

for.body69:                                       ; preds = %vector.body, %for.body69
  %indvars.iv135 = phi i64 [ %indvars.iv.next136, %for.body69 ], [ 0, %vector.body ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv135, metadata !360, metadata !DIExpression()), !dbg !393
  %arrayidx72 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %indvars.iv135, !dbg !394
  %42 = load i32, ptr %arrayidx72, align 4, !dbg !394, !tbaa !156
  tail call void @llvm.dbg.value(metadata i64 1, metadata !365, metadata !DIExpression()), !dbg !395
  tail call void @llvm.dbg.value(metadata i32 %42, metadata !362, metadata !DIExpression()), !dbg !396
  %and77 = and i32 %42, 255, !dbg !397
  %idxprom78 = zext nneg i32 %and77 to i64, !dbg !400
  %arrayidx79 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom78, !dbg !400
  %43 = load i32, ptr %arrayidx79, align 4, !dbg !400, !tbaa !156
  %shr80 = lshr i32 %42, 8, !dbg !401
  %xor81 = xor i32 %43, %shr80, !dbg !402
  tail call void @llvm.dbg.value(metadata i32 %xor81, metadata !362, metadata !DIExpression()), !dbg !396
  %arrayidx85 = getelementptr inbounds [8 x [256 x i32]], ptr @crc32c_table_little, i64 0, i64 1, i64 %indvars.iv135, !dbg !403
  store i32 %xor81, ptr %arrayidx85, align 4, !dbg !404, !tbaa !156
  tail call void @llvm.dbg.value(metadata i64 2, metadata !365, metadata !DIExpression()), !dbg !395
  %and77.1 = and i32 %xor81, 255, !dbg !397
  %idxprom78.1 = zext nneg i32 %and77.1 to i64, !dbg !400
  %arrayidx79.1 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom78.1, !dbg !400
  %44 = load i32, ptr %arrayidx79.1, align 4, !dbg !400, !tbaa !156
  %shr80.1 = lshr i32 %xor81, 8, !dbg !401
  %xor81.1 = xor i32 %44, %shr80.1, !dbg !402
  tail call void @llvm.dbg.value(metadata i32 %xor81.1, metadata !362, metadata !DIExpression()), !dbg !396
  %arrayidx85.1 = getelementptr inbounds [8 x [256 x i32]], ptr @crc32c_table_little, i64 0, i64 2, i64 %indvars.iv135, !dbg !403
  store i32 %xor81.1, ptr %arrayidx85.1, align 4, !dbg !404, !tbaa !156
  tail call void @llvm.dbg.value(metadata i64 3, metadata !365, metadata !DIExpression()), !dbg !395
  %and77.2 = and i32 %xor81.1, 255, !dbg !397
  %idxprom78.2 = zext nneg i32 %and77.2 to i64, !dbg !400
  %arrayidx79.2 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom78.2, !dbg !400
  %45 = load i32, ptr %arrayidx79.2, align 4, !dbg !400, !tbaa !156
  %shr80.2 = lshr i32 %xor81.1, 8, !dbg !401
  %xor81.2 = xor i32 %45, %shr80.2, !dbg !402
  tail call void @llvm.dbg.value(metadata i32 %xor81.2, metadata !362, metadata !DIExpression()), !dbg !396
  %arrayidx85.2 = getelementptr inbounds [8 x [256 x i32]], ptr @crc32c_table_little, i64 0, i64 3, i64 %indvars.iv135, !dbg !403
  store i32 %xor81.2, ptr %arrayidx85.2, align 4, !dbg !404, !tbaa !156
  tail call void @llvm.dbg.value(metadata i64 4, metadata !365, metadata !DIExpression()), !dbg !395
  %and77.3 = and i32 %xor81.2, 255, !dbg !397
  %idxprom78.3 = zext nneg i32 %and77.3 to i64, !dbg !400
  %arrayidx79.3 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom78.3, !dbg !400
  %46 = load i32, ptr %arrayidx79.3, align 4, !dbg !400, !tbaa !156
  %shr80.3 = lshr i32 %xor81.2, 8, !dbg !401
  %xor81.3 = xor i32 %46, %shr80.3, !dbg !402
  tail call void @llvm.dbg.value(metadata i32 %xor81.3, metadata !362, metadata !DIExpression()), !dbg !396
  %arrayidx85.3 = getelementptr inbounds [8 x [256 x i32]], ptr @crc32c_table_little, i64 0, i64 4, i64 %indvars.iv135, !dbg !403
  store i32 %xor81.3, ptr %arrayidx85.3, align 4, !dbg !404, !tbaa !156
  tail call void @llvm.dbg.value(metadata i64 5, metadata !365, metadata !DIExpression()), !dbg !395
  %and77.4 = and i32 %xor81.3, 255, !dbg !397
  %idxprom78.4 = zext nneg i32 %and77.4 to i64, !dbg !400
  %arrayidx79.4 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom78.4, !dbg !400
  %47 = load i32, ptr %arrayidx79.4, align 4, !dbg !400, !tbaa !156
  %shr80.4 = lshr i32 %xor81.3, 8, !dbg !401
  %xor81.4 = xor i32 %47, %shr80.4, !dbg !402
  tail call void @llvm.dbg.value(metadata i32 %xor81.4, metadata !362, metadata !DIExpression()), !dbg !396
  %arrayidx85.4 = getelementptr inbounds [8 x [256 x i32]], ptr @crc32c_table_little, i64 0, i64 5, i64 %indvars.iv135, !dbg !403
  store i32 %xor81.4, ptr %arrayidx85.4, align 4, !dbg !404, !tbaa !156
  tail call void @llvm.dbg.value(metadata i64 6, metadata !365, metadata !DIExpression()), !dbg !395
  %and77.5 = and i32 %xor81.4, 255, !dbg !397
  %idxprom78.5 = zext nneg i32 %and77.5 to i64, !dbg !400
  %arrayidx79.5 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom78.5, !dbg !400
  %48 = load i32, ptr %arrayidx79.5, align 4, !dbg !400, !tbaa !156
  %shr80.5 = lshr i32 %xor81.4, 8, !dbg !401
  %xor81.5 = xor i32 %48, %shr80.5, !dbg !402
  tail call void @llvm.dbg.value(metadata i32 %xor81.5, metadata !362, metadata !DIExpression()), !dbg !396
  %arrayidx85.5 = getelementptr inbounds [8 x [256 x i32]], ptr @crc32c_table_little, i64 0, i64 6, i64 %indvars.iv135, !dbg !403
  store i32 %xor81.5, ptr %arrayidx85.5, align 4, !dbg !404, !tbaa !156
  tail call void @llvm.dbg.value(metadata i64 7, metadata !365, metadata !DIExpression()), !dbg !395
  %and77.6 = and i32 %xor81.5, 255, !dbg !397
  %idxprom78.6 = zext nneg i32 %and77.6 to i64, !dbg !400
  %arrayidx79.6 = getelementptr inbounds [256 x i32], ptr @crc32c_table_little, i64 0, i64 %idxprom78.6, !dbg !400
  %49 = load i32, ptr %arrayidx79.6, align 4, !dbg !400, !tbaa !156
  %shr80.6 = lshr i32 %xor81.5, 8, !dbg !401
  %xor81.6 = xor i32 %49, %shr80.6, !dbg !402
  tail call void @llvm.dbg.value(metadata i32 %xor81.6, metadata !362, metadata !DIExpression()), !dbg !396
  %arrayidx85.6 = getelementptr inbounds [8 x [256 x i32]], ptr @crc32c_table_little, i64 0, i64 7, i64 %indvars.iv135, !dbg !403
  store i32 %xor81.6, ptr %arrayidx85.6, align 4, !dbg !404, !tbaa !156
  tail call void @llvm.dbg.value(metadata i64 8, metadata !365, metadata !DIExpression()), !dbg !395
  %indvars.iv.next136 = add nuw nsw i64 %indvars.iv135, 1, !dbg !405
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next136, metadata !360, metadata !DIExpression()), !dbg !393
  %exitcond138.not = icmp eq i64 %indvars.iv.next136, 256, !dbg !406
  br i1 %exitcond138.not, label %for.cond.cleanup68, label %for.body69, !dbg !407, !llvm.loop !408
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local i32 @crc32c_sw_big(i32 noundef %crc, ptr noundef %buf, i64 noundef %len) local_unnamed_addr #2 !dbg !410 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %crc, metadata !412, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata ptr %buf, metadata !413, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !414, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata ptr %buf, metadata !415, metadata !DIExpression()), !dbg !419
  %call = tail call i32 @pthread_once(ptr noundef nonnull @crc32c_once_big, ptr noundef nonnull @crc32c_init_sw_big) #12, !dbg !420
  %not = xor i32 %crc, -1, !dbg !421
  tail call void @llvm.dbg.value(metadata i32 %not, metadata !412, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata ptr %buf, metadata !415, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !414, metadata !DIExpression()), !dbg !419
  %tobool.not78 = icmp eq i64 %len, 0, !dbg !422
  %0 = ptrtoint ptr %buf to i64
  %and79 = and i64 %0, 7
  %cmp.not80 = icmp eq i64 %and79, 0
  %or.cond81 = or i1 %tobool.not78, %cmp.not80, !dbg !423
  br i1 %or.cond81, label %while.end, label %while.body, !dbg !423

while.body:                                       ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr %buf, metadata !415, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !414, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i32 %not, metadata !412, metadata !DIExpression()), !dbg !419
  %incdec.ptr = getelementptr inbounds i8, ptr %buf, i64 1, !dbg !424
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !415, metadata !DIExpression()), !dbg !419
  %1 = load i8, ptr %buf, align 1, !dbg !426, !tbaa !281
  %crc.addr.0.tr = trunc i32 %not to i8, !dbg !427
  %xor.narrow = xor i8 %1, %crc.addr.0.tr, !dbg !427
  %idxprom = zext i8 %xor.narrow to i64, !dbg !428
  %arrayidx = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom, !dbg !428
  %2 = load i32, ptr %arrayidx, align 4, !dbg !428, !tbaa !156
  %shr = lshr i32 %not, 8, !dbg !429
  %xor2 = xor i32 %2, %shr, !dbg !430
  tail call void @llvm.dbg.value(metadata i32 %xor2, metadata !412, metadata !DIExpression()), !dbg !419
  %dec = add i64 %len, -1, !dbg !431
  tail call void @llvm.dbg.value(metadata i64 %dec, metadata !414, metadata !DIExpression()), !dbg !419
  %tobool.not = icmp eq i64 %dec, 0, !dbg !422
  %3 = ptrtoint ptr %incdec.ptr to i64
  %and = and i64 %3, 7
  %cmp.not = icmp eq i64 %and, 0
  %or.cond = select i1 %tobool.not, i1 true, i1 %cmp.not, !dbg !423
  br i1 %or.cond, label %while.end, label %while.body.1, !dbg !423, !llvm.loop !432

while.body.1:                                     ; preds = %while.body
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !415, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %dec, metadata !414, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i32 %xor2, metadata !412, metadata !DIExpression()), !dbg !419
  %incdec.ptr.1 = getelementptr inbounds i8, ptr %buf, i64 2, !dbg !424
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.1, metadata !415, metadata !DIExpression()), !dbg !419
  %4 = load i8, ptr %incdec.ptr, align 1, !dbg !426, !tbaa !281
  %crc.addr.0.tr.1 = trunc i32 %xor2 to i8, !dbg !427
  %xor.narrow.1 = xor i8 %4, %crc.addr.0.tr.1, !dbg !427
  %idxprom.1 = zext i8 %xor.narrow.1 to i64, !dbg !428
  %arrayidx.1 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom.1, !dbg !428
  %5 = load i32, ptr %arrayidx.1, align 4, !dbg !428, !tbaa !156
  %shr.1 = lshr i32 %xor2, 8, !dbg !429
  %xor2.1 = xor i32 %5, %shr.1, !dbg !430
  tail call void @llvm.dbg.value(metadata i32 %xor2.1, metadata !412, metadata !DIExpression()), !dbg !419
  %dec.1 = add i64 %len, -2, !dbg !431
  tail call void @llvm.dbg.value(metadata i64 %dec.1, metadata !414, metadata !DIExpression()), !dbg !419
  %tobool.not.1 = icmp eq i64 %dec.1, 0, !dbg !422
  %6 = ptrtoint ptr %incdec.ptr.1 to i64
  %and.1 = and i64 %6, 7
  %cmp.not.1 = icmp eq i64 %and.1, 0
  %or.cond.1 = select i1 %tobool.not.1, i1 true, i1 %cmp.not.1, !dbg !423
  br i1 %or.cond.1, label %while.end, label %while.body.2, !dbg !423, !llvm.loop !432

while.body.2:                                     ; preds = %while.body.1
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.1, metadata !415, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %dec.1, metadata !414, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i32 %xor2.1, metadata !412, metadata !DIExpression()), !dbg !419
  %incdec.ptr.2 = getelementptr inbounds i8, ptr %buf, i64 3, !dbg !424
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.2, metadata !415, metadata !DIExpression()), !dbg !419
  %7 = load i8, ptr %incdec.ptr.1, align 1, !dbg !426, !tbaa !281
  %crc.addr.0.tr.2 = trunc i32 %xor2.1 to i8, !dbg !427
  %xor.narrow.2 = xor i8 %7, %crc.addr.0.tr.2, !dbg !427
  %idxprom.2 = zext i8 %xor.narrow.2 to i64, !dbg !428
  %arrayidx.2 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom.2, !dbg !428
  %8 = load i32, ptr %arrayidx.2, align 4, !dbg !428, !tbaa !156
  %shr.2 = lshr i32 %xor2.1, 8, !dbg !429
  %xor2.2 = xor i32 %8, %shr.2, !dbg !430
  tail call void @llvm.dbg.value(metadata i32 %xor2.2, metadata !412, metadata !DIExpression()), !dbg !419
  %dec.2 = add i64 %len, -3, !dbg !431
  tail call void @llvm.dbg.value(metadata i64 %dec.2, metadata !414, metadata !DIExpression()), !dbg !419
  %tobool.not.2 = icmp eq i64 %dec.2, 0, !dbg !422
  %9 = ptrtoint ptr %incdec.ptr.2 to i64
  %and.2 = and i64 %9, 7
  %cmp.not.2 = icmp eq i64 %and.2, 0
  %or.cond.2 = select i1 %tobool.not.2, i1 true, i1 %cmp.not.2, !dbg !423
  br i1 %or.cond.2, label %while.end, label %while.body.3, !dbg !423, !llvm.loop !432

while.body.3:                                     ; preds = %while.body.2
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.2, metadata !415, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %dec.2, metadata !414, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i32 %xor2.2, metadata !412, metadata !DIExpression()), !dbg !419
  %incdec.ptr.3 = getelementptr inbounds i8, ptr %buf, i64 4, !dbg !424
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.3, metadata !415, metadata !DIExpression()), !dbg !419
  %10 = load i8, ptr %incdec.ptr.2, align 1, !dbg !426, !tbaa !281
  %crc.addr.0.tr.3 = trunc i32 %xor2.2 to i8, !dbg !427
  %xor.narrow.3 = xor i8 %10, %crc.addr.0.tr.3, !dbg !427
  %idxprom.3 = zext i8 %xor.narrow.3 to i64, !dbg !428
  %arrayidx.3 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom.3, !dbg !428
  %11 = load i32, ptr %arrayidx.3, align 4, !dbg !428, !tbaa !156
  %shr.3 = lshr i32 %xor2.2, 8, !dbg !429
  %xor2.3 = xor i32 %11, %shr.3, !dbg !430
  tail call void @llvm.dbg.value(metadata i32 %xor2.3, metadata !412, metadata !DIExpression()), !dbg !419
  %dec.3 = add i64 %len, -4, !dbg !431
  tail call void @llvm.dbg.value(metadata i64 %dec.3, metadata !414, metadata !DIExpression()), !dbg !419
  %tobool.not.3 = icmp eq i64 %dec.3, 0, !dbg !422
  %12 = ptrtoint ptr %incdec.ptr.3 to i64
  %and.3 = and i64 %12, 7
  %cmp.not.3 = icmp eq i64 %and.3, 0
  %or.cond.3 = select i1 %tobool.not.3, i1 true, i1 %cmp.not.3, !dbg !423
  br i1 %or.cond.3, label %while.end, label %while.body.4, !dbg !423, !llvm.loop !432

while.body.4:                                     ; preds = %while.body.3
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.3, metadata !415, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %dec.3, metadata !414, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i32 %xor2.3, metadata !412, metadata !DIExpression()), !dbg !419
  %incdec.ptr.4 = getelementptr inbounds i8, ptr %buf, i64 5, !dbg !424
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.4, metadata !415, metadata !DIExpression()), !dbg !419
  %13 = load i8, ptr %incdec.ptr.3, align 1, !dbg !426, !tbaa !281
  %crc.addr.0.tr.4 = trunc i32 %xor2.3 to i8, !dbg !427
  %xor.narrow.4 = xor i8 %13, %crc.addr.0.tr.4, !dbg !427
  %idxprom.4 = zext i8 %xor.narrow.4 to i64, !dbg !428
  %arrayidx.4 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom.4, !dbg !428
  %14 = load i32, ptr %arrayidx.4, align 4, !dbg !428, !tbaa !156
  %shr.4 = lshr i32 %xor2.3, 8, !dbg !429
  %xor2.4 = xor i32 %14, %shr.4, !dbg !430
  tail call void @llvm.dbg.value(metadata i32 %xor2.4, metadata !412, metadata !DIExpression()), !dbg !419
  %dec.4 = add i64 %len, -5, !dbg !431
  tail call void @llvm.dbg.value(metadata i64 %dec.4, metadata !414, metadata !DIExpression()), !dbg !419
  %tobool.not.4 = icmp eq i64 %dec.4, 0, !dbg !422
  %15 = ptrtoint ptr %incdec.ptr.4 to i64
  %and.4 = and i64 %15, 7
  %cmp.not.4 = icmp eq i64 %and.4, 0
  %or.cond.4 = select i1 %tobool.not.4, i1 true, i1 %cmp.not.4, !dbg !423
  br i1 %or.cond.4, label %while.end, label %while.body.5, !dbg !423, !llvm.loop !432

while.body.5:                                     ; preds = %while.body.4
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.4, metadata !415, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %dec.4, metadata !414, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i32 %xor2.4, metadata !412, metadata !DIExpression()), !dbg !419
  %incdec.ptr.5 = getelementptr inbounds i8, ptr %buf, i64 6, !dbg !424
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.5, metadata !415, metadata !DIExpression()), !dbg !419
  %16 = load i8, ptr %incdec.ptr.4, align 1, !dbg !426, !tbaa !281
  %crc.addr.0.tr.5 = trunc i32 %xor2.4 to i8, !dbg !427
  %xor.narrow.5 = xor i8 %16, %crc.addr.0.tr.5, !dbg !427
  %idxprom.5 = zext i8 %xor.narrow.5 to i64, !dbg !428
  %arrayidx.5 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom.5, !dbg !428
  %17 = load i32, ptr %arrayidx.5, align 4, !dbg !428, !tbaa !156
  %shr.5 = lshr i32 %xor2.4, 8, !dbg !429
  %xor2.5 = xor i32 %17, %shr.5, !dbg !430
  tail call void @llvm.dbg.value(metadata i32 %xor2.5, metadata !412, metadata !DIExpression()), !dbg !419
  %dec.5 = add i64 %len, -6, !dbg !431
  tail call void @llvm.dbg.value(metadata i64 %dec.5, metadata !414, metadata !DIExpression()), !dbg !419
  %tobool.not.5 = icmp eq i64 %dec.5, 0, !dbg !422
  %18 = ptrtoint ptr %incdec.ptr.5 to i64
  %and.5 = and i64 %18, 7
  %cmp.not.5 = icmp eq i64 %and.5, 0
  %or.cond.5 = select i1 %tobool.not.5, i1 true, i1 %cmp.not.5, !dbg !423
  br i1 %or.cond.5, label %while.end, label %while.body.6, !dbg !423, !llvm.loop !432

while.body.6:                                     ; preds = %while.body.5
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.5, metadata !415, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %dec.5, metadata !414, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i32 %xor2.5, metadata !412, metadata !DIExpression()), !dbg !419
  %incdec.ptr.6 = getelementptr inbounds i8, ptr %buf, i64 7, !dbg !424
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.6, metadata !415, metadata !DIExpression()), !dbg !419
  %19 = load i8, ptr %incdec.ptr.5, align 1, !dbg !426, !tbaa !281
  %crc.addr.0.tr.6 = trunc i32 %xor2.5 to i8, !dbg !427
  %xor.narrow.6 = xor i8 %19, %crc.addr.0.tr.6, !dbg !427
  %idxprom.6 = zext i8 %xor.narrow.6 to i64, !dbg !428
  %arrayidx.6 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom.6, !dbg !428
  %20 = load i32, ptr %arrayidx.6, align 4, !dbg !428, !tbaa !156
  %shr.6 = lshr i32 %xor2.5, 8, !dbg !429
  %xor2.6 = xor i32 %20, %shr.6, !dbg !430
  tail call void @llvm.dbg.value(metadata i32 %xor2.6, metadata !412, metadata !DIExpression()), !dbg !419
  %dec.6 = add i64 %len, -7, !dbg !431
  tail call void @llvm.dbg.value(metadata i64 %dec.6, metadata !414, metadata !DIExpression()), !dbg !419
  %tobool.not.6 = icmp eq i64 %dec.6, 0, !dbg !422
  %21 = ptrtoint ptr %incdec.ptr.6 to i64
  %and.6 = and i64 %21, 7
  %cmp.not.6 = icmp eq i64 %and.6, 0
  %or.cond.6 = select i1 %tobool.not.6, i1 true, i1 %cmp.not.6, !dbg !423
  br i1 %or.cond.6, label %while.end, label %while.body.7, !dbg !423, !llvm.loop !432

while.body.7:                                     ; preds = %while.body.6
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.6, metadata !415, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %dec.6, metadata !414, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i32 %xor2.6, metadata !412, metadata !DIExpression()), !dbg !419
  %incdec.ptr.7 = getelementptr inbounds i8, ptr %buf, i64 8, !dbg !424
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.7, metadata !415, metadata !DIExpression()), !dbg !419
  %22 = load i8, ptr %incdec.ptr.6, align 1, !dbg !426, !tbaa !281
  %crc.addr.0.tr.7 = trunc i32 %xor2.6 to i8, !dbg !427
  %xor.narrow.7 = xor i8 %22, %crc.addr.0.tr.7, !dbg !427
  %idxprom.7 = zext i8 %xor.narrow.7 to i64, !dbg !428
  %arrayidx.7 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom.7, !dbg !428
  %23 = load i32, ptr %arrayidx.7, align 4, !dbg !428, !tbaa !156
  %shr.7 = lshr i32 %xor2.6, 8, !dbg !429
  %xor2.7 = xor i32 %23, %shr.7, !dbg !430
  tail call void @llvm.dbg.value(metadata i32 %xor2.7, metadata !412, metadata !DIExpression()), !dbg !419
  %dec.7 = add i64 %len, -8, !dbg !431
  tail call void @llvm.dbg.value(metadata i64 %dec.7, metadata !414, metadata !DIExpression()), !dbg !419
  br label %while.end

while.end:                                        ; preds = %while.body, %while.body.1, %while.body.2, %while.body.3, %while.body.4, %while.body.5, %while.body.6, %while.body.7, %entry
  %crc.addr.0.lcssa = phi i32 [ %not, %entry ], [ %xor2, %while.body ], [ %xor2.1, %while.body.1 ], [ %xor2.2, %while.body.2 ], [ %xor2.3, %while.body.3 ], [ %xor2.4, %while.body.4 ], [ %xor2.5, %while.body.5 ], [ %xor2.6, %while.body.6 ], [ %xor2.7, %while.body.7 ], !dbg !419
  %len.addr.0.lcssa = phi i64 [ %len, %entry ], [ %dec, %while.body ], [ %dec.1, %while.body.1 ], [ %dec.2, %while.body.2 ], [ %dec.3, %while.body.3 ], [ %dec.4, %while.body.4 ], [ %dec.5, %while.body.5 ], [ %dec.6, %while.body.6 ], [ %dec.7, %while.body.7 ]
  %next.0.lcssa = phi ptr [ %buf, %entry ], [ %incdec.ptr, %while.body ], [ %incdec.ptr.1, %while.body.1 ], [ %incdec.ptr.2, %while.body.2 ], [ %incdec.ptr.3, %while.body.3 ], [ %incdec.ptr.4, %while.body.4 ], [ %incdec.ptr.5, %while.body.5 ], [ %incdec.ptr.6, %while.body.6 ], [ %incdec.ptr.7, %while.body.7 ], !dbg !419
  %cmp3 = icmp ugt i64 %len.addr.0.lcssa, 7, !dbg !435
  br i1 %cmp3, label %if.then, label %if.end, !dbg !436

if.then:                                          ; preds = %while.end
  %conv5 = zext i32 %crc.addr.0.lcssa to i64, !dbg !437
  %24 = tail call i64 @llvm.bswap.i64(i64 %conv5), !dbg !438
  tail call void @llvm.dbg.value(metadata i64 %24, metadata !416, metadata !DIExpression()), !dbg !439
  br label %do.body, !dbg !440

do.body:                                          ; preds = %do.body, %if.then
  %len.addr.1 = phi i64 [ %len.addr.0.lcssa, %if.then ], [ %sub, %do.body ]
  %next.1 = phi ptr [ %next.0.lcssa, %if.then ], [ %add.ptr, %do.body ], !dbg !419
  %crcw.0 = phi i64 [ %24, %if.then ], [ %xor35, %do.body ], !dbg !439
  tail call void @llvm.dbg.value(metadata i64 %crcw.0, metadata !416, metadata !DIExpression()), !dbg !439
  tail call void @llvm.dbg.value(metadata ptr %next.1, metadata !415, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %len.addr.1, metadata !414, metadata !DIExpression()), !dbg !419
  %25 = load i64, ptr %next.1, align 8, !dbg !441, !tbaa !295
  %xor6 = xor i64 %25, %crcw.0, !dbg !443
  tail call void @llvm.dbg.value(metadata i64 %xor6, metadata !416, metadata !DIExpression()), !dbg !439
  %and7 = and i64 %xor6, 255, !dbg !444
  %arrayidx8 = getelementptr inbounds [256 x i64], ptr @crc32c_table_big, i64 0, i64 %and7, !dbg !445
  %26 = load i64, ptr %arrayidx8, align 8, !dbg !445, !tbaa !295
  %shr9 = lshr i64 %xor6, 8, !dbg !446
  %and10 = and i64 %shr9, 255, !dbg !447
  %arrayidx11 = getelementptr inbounds [8 x [256 x i64]], ptr @crc32c_table_big, i64 0, i64 1, i64 %and10, !dbg !448
  %27 = load i64, ptr %arrayidx11, align 8, !dbg !448, !tbaa !295
  %xor12 = xor i64 %27, %26, !dbg !449
  %shr13 = lshr i64 %xor6, 16, !dbg !450
  %and14 = and i64 %shr13, 255, !dbg !451
  %arrayidx15 = getelementptr inbounds [8 x [256 x i64]], ptr @crc32c_table_big, i64 0, i64 2, i64 %and14, !dbg !452
  %28 = load i64, ptr %arrayidx15, align 8, !dbg !452, !tbaa !295
  %xor16 = xor i64 %xor12, %28, !dbg !453
  %shr17 = lshr i64 %xor6, 24, !dbg !454
  %and18 = and i64 %shr17, 255, !dbg !455
  %arrayidx19 = getelementptr inbounds [8 x [256 x i64]], ptr @crc32c_table_big, i64 0, i64 3, i64 %and18, !dbg !456
  %29 = load i64, ptr %arrayidx19, align 8, !dbg !456, !tbaa !295
  %xor20 = xor i64 %xor16, %29, !dbg !457
  %shr21 = lshr i64 %xor6, 32, !dbg !458
  %and22 = and i64 %shr21, 255, !dbg !459
  %arrayidx23 = getelementptr inbounds [8 x [256 x i64]], ptr @crc32c_table_big, i64 0, i64 4, i64 %and22, !dbg !460
  %30 = load i64, ptr %arrayidx23, align 8, !dbg !460, !tbaa !295
  %xor24 = xor i64 %xor20, %30, !dbg !461
  %shr25 = lshr i64 %xor6, 40, !dbg !462
  %and26 = and i64 %shr25, 255, !dbg !463
  %arrayidx27 = getelementptr inbounds [8 x [256 x i64]], ptr @crc32c_table_big, i64 0, i64 5, i64 %and26, !dbg !464
  %31 = load i64, ptr %arrayidx27, align 8, !dbg !464, !tbaa !295
  %xor28 = xor i64 %xor24, %31, !dbg !465
  %shr29 = lshr i64 %xor6, 48, !dbg !466
  %and30 = and i64 %shr29, 255, !dbg !467
  %arrayidx31 = getelementptr inbounds [8 x [256 x i64]], ptr @crc32c_table_big, i64 0, i64 6, i64 %and30, !dbg !468
  %32 = load i64, ptr %arrayidx31, align 8, !dbg !468, !tbaa !295
  %xor32 = xor i64 %xor28, %32, !dbg !469
  %shr33 = lshr i64 %xor6, 56, !dbg !470
  %arrayidx34 = getelementptr inbounds [8 x [256 x i64]], ptr @crc32c_table_big, i64 0, i64 7, i64 %shr33, !dbg !471
  %33 = load i64, ptr %arrayidx34, align 8, !dbg !471, !tbaa !295
  %xor35 = xor i64 %xor32, %33, !dbg !472
  tail call void @llvm.dbg.value(metadata i64 %xor35, metadata !416, metadata !DIExpression()), !dbg !439
  %add.ptr = getelementptr inbounds i8, ptr %next.1, i64 8, !dbg !473
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !415, metadata !DIExpression()), !dbg !419
  %sub = add i64 %len.addr.1, -8, !dbg !474
  tail call void @llvm.dbg.value(metadata i64 %sub, metadata !414, metadata !DIExpression()), !dbg !419
  %cmp36 = icmp ugt i64 %sub, 7, !dbg !475
  br i1 %cmp36, label %do.body, label %do.end, !dbg !476, !llvm.loop !477

do.end:                                           ; preds = %do.body
  %34 = tail call i64 @llvm.bswap.i64(i64 %xor35), !dbg !479
  %conv38 = trunc i64 %34 to i32, !dbg !479
  tail call void @llvm.dbg.value(metadata i32 %conv38, metadata !412, metadata !DIExpression()), !dbg !419
  br label %if.end, !dbg !480

if.end:                                           ; preds = %do.end, %while.end
  %crc.addr.1 = phi i32 [ %conv38, %do.end ], [ %crc.addr.0.lcssa, %while.end ], !dbg !419
  %len.addr.2 = phi i64 [ %sub, %do.end ], [ %len.addr.0.lcssa, %while.end ]
  %next.2 = phi ptr [ %add.ptr, %do.end ], [ %next.0.lcssa, %while.end ], !dbg !419
  tail call void @llvm.dbg.value(metadata ptr %next.2, metadata !415, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %len.addr.2, metadata !414, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i32 %crc.addr.1, metadata !412, metadata !DIExpression()), !dbg !419
  %tobool40.not87 = icmp eq i64 %len.addr.2, 0, !dbg !481
  br i1 %tobool40.not87, label %while.end51, label %while.body41.preheader, !dbg !481

while.body41.preheader:                           ; preds = %if.end
  %xtraiter = and i64 %len.addr.2, 1, !dbg !481
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0, !dbg !481
  br i1 %lcmp.mod.not, label %while.body41.prol.loopexit, label %while.body41.prol, !dbg !481

while.body41.prol:                                ; preds = %while.body41.preheader
  tail call void @llvm.dbg.value(metadata ptr %next.2, metadata !415, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %len.addr.2, metadata !414, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i32 %crc.addr.1, metadata !412, metadata !DIExpression()), !dbg !419
  %incdec.ptr42.prol = getelementptr inbounds i8, ptr %next.2, i64 1, !dbg !482
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr42.prol, metadata !415, metadata !DIExpression()), !dbg !419
  %35 = load i8, ptr %next.2, align 1, !dbg !484, !tbaa !281
  %crc.addr.2.tr.prol = trunc i32 %crc.addr.1 to i8, !dbg !485
  %xor44.narrow.prol = xor i8 %35, %crc.addr.2.tr.prol, !dbg !485
  %idxprom46.prol = zext i8 %xor44.narrow.prol to i64, !dbg !486
  %arrayidx47.prol = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom46.prol, !dbg !486
  %36 = load i32, ptr %arrayidx47.prol, align 4, !dbg !486, !tbaa !156
  %shr48.prol = lshr i32 %crc.addr.1, 8, !dbg !487
  %xor49.prol = xor i32 %36, %shr48.prol, !dbg !488
  tail call void @llvm.dbg.value(metadata i32 %xor49.prol, metadata !412, metadata !DIExpression()), !dbg !419
  %dec50.prol = add nsw i64 %len.addr.2, -1, !dbg !489
  tail call void @llvm.dbg.value(metadata i64 %dec50.prol, metadata !414, metadata !DIExpression()), !dbg !419
  br label %while.body41.prol.loopexit, !dbg !481

while.body41.prol.loopexit:                       ; preds = %while.body41.prol, %while.body41.preheader
  %xor49.lcssa.unr = phi i32 [ undef, %while.body41.preheader ], [ %xor49.prol, %while.body41.prol ]
  %next.390.unr = phi ptr [ %next.2, %while.body41.preheader ], [ %incdec.ptr42.prol, %while.body41.prol ]
  %len.addr.389.unr = phi i64 [ %len.addr.2, %while.body41.preheader ], [ %dec50.prol, %while.body41.prol ]
  %crc.addr.288.unr = phi i32 [ %crc.addr.1, %while.body41.preheader ], [ %xor49.prol, %while.body41.prol ]
  %37 = icmp eq i64 %len.addr.2, 1, !dbg !481
  br i1 %37, label %while.end51, label %while.body41, !dbg !481

while.body41:                                     ; preds = %while.body41.prol.loopexit, %while.body41
  %next.390 = phi ptr [ %incdec.ptr42.1, %while.body41 ], [ %next.390.unr, %while.body41.prol.loopexit ]
  %len.addr.389 = phi i64 [ %dec50.1, %while.body41 ], [ %len.addr.389.unr, %while.body41.prol.loopexit ]
  %crc.addr.288 = phi i32 [ %xor49.1, %while.body41 ], [ %crc.addr.288.unr, %while.body41.prol.loopexit ]
  tail call void @llvm.dbg.value(metadata ptr %next.390, metadata !415, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %len.addr.389, metadata !414, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i32 %crc.addr.288, metadata !412, metadata !DIExpression()), !dbg !419
  %incdec.ptr42 = getelementptr inbounds i8, ptr %next.390, i64 1, !dbg !482
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr42, metadata !415, metadata !DIExpression()), !dbg !419
  %38 = load i8, ptr %next.390, align 1, !dbg !484, !tbaa !281
  %crc.addr.2.tr = trunc i32 %crc.addr.288 to i8, !dbg !485
  %xor44.narrow = xor i8 %38, %crc.addr.2.tr, !dbg !485
  %idxprom46 = zext i8 %xor44.narrow to i64, !dbg !486
  %arrayidx47 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom46, !dbg !486
  %39 = load i32, ptr %arrayidx47, align 4, !dbg !486, !tbaa !156
  %shr48 = lshr i32 %crc.addr.288, 8, !dbg !487
  %xor49 = xor i32 %39, %shr48, !dbg !488
  tail call void @llvm.dbg.value(metadata i32 %xor49, metadata !412, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %len.addr.389, metadata !414, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !419
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr42, metadata !415, metadata !DIExpression()), !dbg !419
  tail call void @llvm.dbg.value(metadata i64 %len.addr.389, metadata !414, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !419
  tail call void @llvm.dbg.value(metadata i32 %xor49, metadata !412, metadata !DIExpression()), !dbg !419
  %incdec.ptr42.1 = getelementptr inbounds i8, ptr %next.390, i64 2, !dbg !482
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr42.1, metadata !415, metadata !DIExpression()), !dbg !419
  %40 = load i8, ptr %incdec.ptr42, align 1, !dbg !484, !tbaa !281
  %crc.addr.2.tr.1 = trunc i32 %xor49 to i8, !dbg !485
  %xor44.narrow.1 = xor i8 %40, %crc.addr.2.tr.1, !dbg !485
  %idxprom46.1 = zext i8 %xor44.narrow.1 to i64, !dbg !486
  %arrayidx47.1 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom46.1, !dbg !486
  %41 = load i32, ptr %arrayidx47.1, align 4, !dbg !486, !tbaa !156
  %shr48.1 = lshr i32 %xor49, 8, !dbg !487
  %xor49.1 = xor i32 %41, %shr48.1, !dbg !488
  tail call void @llvm.dbg.value(metadata i32 %xor49.1, metadata !412, metadata !DIExpression()), !dbg !419
  %dec50.1 = add nsw i64 %len.addr.389, -2, !dbg !489
  tail call void @llvm.dbg.value(metadata i64 %dec50.1, metadata !414, metadata !DIExpression()), !dbg !419
  %tobool40.not.1 = icmp eq i64 %dec50.1, 0, !dbg !481
  br i1 %tobool40.not.1, label %while.end51, label %while.body41, !dbg !481, !llvm.loop !490

while.end51:                                      ; preds = %while.body41.prol.loopexit, %while.body41, %if.end
  %crc.addr.2.lcssa = phi i32 [ %crc.addr.1, %if.end ], [ %xor49.lcssa.unr, %while.body41.prol.loopexit ], [ %xor49.1, %while.body41 ], !dbg !419
  %not52 = xor i32 %crc.addr.2.lcssa, -1, !dbg !492
  ret i32 %not52, !dbg !493
}

; Function Attrs: nofree norecurse nosync nounwind sanitize_thread memory(readwrite, argmem: none, inaccessiblemem: none) uwtable
define internal void @crc32c_init_sw_big() #4 !dbg !494 {
entry:
  tail call void @llvm.dbg.value(metadata i32 0, metadata !496, metadata !DIExpression()), !dbg !508
  br label %vector.body, !dbg !509

vector.body:                                      ; preds = %vector.body, %entry
  %index = phi i64 [ 0, %entry ], [ %index.next, %vector.body ], !dbg !510
  %vec.ind = phi <4 x i32> [ <i32 0, i32 1, i32 2, i32 3>, %entry ], [ %vec.ind.next, %vector.body ], !dbg !511
  %0 = and <4 x i32> %vec.ind, <i32 1, i32 1, i32 1, i32 1>, !dbg !511
  %1 = icmp eq <4 x i32> %0, zeroinitializer, !dbg !511
  %2 = lshr <4 x i32> %vec.ind, <i32 1, i32 1, i32 1, i32 1>, !dbg !512
  %3 = xor <4 x i32> %2, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !512
  %4 = select <4 x i1> %1, <4 x i32> %2, <4 x i32> %3, !dbg !512
  %5 = and <4 x i32> %4, <i32 1, i32 1, i32 1, i32 1>, !dbg !513
  %6 = icmp eq <4 x i32> %5, zeroinitializer, !dbg !513
  %7 = lshr <4 x i32> %4, <i32 1, i32 1, i32 1, i32 1>, !dbg !514
  %8 = xor <4 x i32> %7, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !514
  %9 = select <4 x i1> %6, <4 x i32> %7, <4 x i32> %8, !dbg !514
  %10 = and <4 x i32> %9, <i32 1, i32 1, i32 1, i32 1>, !dbg !515
  %11 = icmp eq <4 x i32> %10, zeroinitializer, !dbg !515
  %12 = lshr <4 x i32> %9, <i32 1, i32 1, i32 1, i32 1>, !dbg !516
  %13 = xor <4 x i32> %12, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !516
  %14 = select <4 x i1> %11, <4 x i32> %12, <4 x i32> %13, !dbg !516
  %15 = and <4 x i32> %14, <i32 1, i32 1, i32 1, i32 1>, !dbg !517
  %16 = icmp eq <4 x i32> %15, zeroinitializer, !dbg !517
  %17 = lshr <4 x i32> %14, <i32 1, i32 1, i32 1, i32 1>, !dbg !518
  %18 = xor <4 x i32> %17, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !518
  %19 = select <4 x i1> %16, <4 x i32> %17, <4 x i32> %18, !dbg !518
  %20 = and <4 x i32> %19, <i32 1, i32 1, i32 1, i32 1>, !dbg !519
  %21 = icmp eq <4 x i32> %20, zeroinitializer, !dbg !519
  %22 = lshr <4 x i32> %19, <i32 1, i32 1, i32 1, i32 1>, !dbg !520
  %23 = xor <4 x i32> %22, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !520
  %24 = select <4 x i1> %21, <4 x i32> %22, <4 x i32> %23, !dbg !520
  %25 = and <4 x i32> %24, <i32 1, i32 1, i32 1, i32 1>, !dbg !521
  %26 = icmp eq <4 x i32> %25, zeroinitializer, !dbg !521
  %27 = lshr <4 x i32> %24, <i32 1, i32 1, i32 1, i32 1>, !dbg !522
  %28 = xor <4 x i32> %27, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !522
  %29 = select <4 x i1> %26, <4 x i32> %27, <4 x i32> %28, !dbg !522
  %30 = and <4 x i32> %29, <i32 1, i32 1, i32 1, i32 1>, !dbg !523
  %31 = icmp eq <4 x i32> %30, zeroinitializer, !dbg !523
  %32 = lshr <4 x i32> %29, <i32 1, i32 1, i32 1, i32 1>, !dbg !524
  %33 = xor <4 x i32> %32, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !524
  %34 = select <4 x i1> %31, <4 x i32> %32, <4 x i32> %33, !dbg !524
  %35 = and <4 x i32> %34, <i32 1, i32 1, i32 1, i32 1>, !dbg !525
  %36 = icmp eq <4 x i32> %35, zeroinitializer, !dbg !525
  %37 = lshr <4 x i32> %34, <i32 1, i32 1, i32 1, i32 1>, !dbg !526
  %38 = xor <4 x i32> %37, <i32 -2097792136, i32 -2097792136, i32 -2097792136, i32 -2097792136>, !dbg !526
  %39 = select <4 x i1> %36, <4 x i32> %37, <4 x i32> %38, !dbg !526
  %40 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %index, !dbg !527
  store <4 x i32> %39, ptr %40, align 16, !dbg !528, !tbaa !156
  %index.next = add nuw i64 %index, 4, !dbg !510
  %vec.ind.next = add <4 x i32> %vec.ind, <i32 4, i32 4, i32 4, i32 4>, !dbg !511
  %41 = icmp eq i64 %index.next, 256, !dbg !510
  br i1 %41, label %for.body69, label %vector.body, !dbg !510, !llvm.loop !529

for.cond.cleanup68:                               ; preds = %for.body69
  ret void, !dbg !531

for.body69:                                       ; preds = %vector.body, %for.body69
  %indvars.iv141 = phi i64 [ %indvars.iv.next142, %for.body69 ], [ 0, %vector.body ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv141, metadata !501, metadata !DIExpression()), !dbg !532
  %arrayidx72 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %indvars.iv141, !dbg !533
  %42 = load i32, ptr %arrayidx72, align 4, !dbg !533, !tbaa !156
  tail call void @llvm.dbg.value(metadata i32 %42, metadata !503, metadata !DIExpression()), !dbg !534
  %conv = zext i32 %42 to i64, !dbg !535
  %43 = tail call i64 @llvm.bswap.i64(i64 %conv), !dbg !536
  %arrayidx74 = getelementptr inbounds [256 x i64], ptr @crc32c_table_big, i64 0, i64 %indvars.iv141, !dbg !537
  store i64 %43, ptr %arrayidx74, align 8, !dbg !538, !tbaa !295
  tail call void @llvm.dbg.value(metadata i64 1, metadata !506, metadata !DIExpression()), !dbg !539
  %and80 = and i32 %42, 255, !dbg !540
  %idxprom81 = zext nneg i32 %and80 to i64, !dbg !543
  %arrayidx82 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom81, !dbg !543
  %44 = load i32, ptr %arrayidx82, align 4, !dbg !543, !tbaa !156
  %shr83 = lshr i32 %42, 8, !dbg !544
  %xor84 = xor i32 %44, %shr83, !dbg !545
  tail call void @llvm.dbg.value(metadata i32 %xor84, metadata !503, metadata !DIExpression()), !dbg !534
  %conv85 = zext i32 %xor84 to i64, !dbg !546
  %45 = tail call i64 @llvm.bswap.i64(i64 %conv85), !dbg !547
  %arrayidx89 = getelementptr inbounds [8 x [256 x i64]], ptr @crc32c_table_big, i64 0, i64 1, i64 %indvars.iv141, !dbg !548
  store i64 %45, ptr %arrayidx89, align 8, !dbg !549, !tbaa !295
  tail call void @llvm.dbg.value(metadata i64 2, metadata !506, metadata !DIExpression()), !dbg !539
  %and80.1 = and i32 %xor84, 255, !dbg !540
  %idxprom81.1 = zext nneg i32 %and80.1 to i64, !dbg !543
  %arrayidx82.1 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom81.1, !dbg !543
  %46 = load i32, ptr %arrayidx82.1, align 4, !dbg !543, !tbaa !156
  %shr83.1 = lshr i32 %xor84, 8, !dbg !544
  %xor84.1 = xor i32 %46, %shr83.1, !dbg !545
  tail call void @llvm.dbg.value(metadata i32 %xor84.1, metadata !503, metadata !DIExpression()), !dbg !534
  %conv85.1 = zext i32 %xor84.1 to i64, !dbg !546
  %47 = tail call i64 @llvm.bswap.i64(i64 %conv85.1), !dbg !547
  %arrayidx89.1 = getelementptr inbounds [8 x [256 x i64]], ptr @crc32c_table_big, i64 0, i64 2, i64 %indvars.iv141, !dbg !548
  store i64 %47, ptr %arrayidx89.1, align 8, !dbg !549, !tbaa !295
  tail call void @llvm.dbg.value(metadata i64 3, metadata !506, metadata !DIExpression()), !dbg !539
  %and80.2 = and i32 %xor84.1, 255, !dbg !540
  %idxprom81.2 = zext nneg i32 %and80.2 to i64, !dbg !543
  %arrayidx82.2 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom81.2, !dbg !543
  %48 = load i32, ptr %arrayidx82.2, align 4, !dbg !543, !tbaa !156
  %shr83.2 = lshr i32 %xor84.1, 8, !dbg !544
  %xor84.2 = xor i32 %48, %shr83.2, !dbg !545
  tail call void @llvm.dbg.value(metadata i32 %xor84.2, metadata !503, metadata !DIExpression()), !dbg !534
  %conv85.2 = zext i32 %xor84.2 to i64, !dbg !546
  %49 = tail call i64 @llvm.bswap.i64(i64 %conv85.2), !dbg !547
  %arrayidx89.2 = getelementptr inbounds [8 x [256 x i64]], ptr @crc32c_table_big, i64 0, i64 3, i64 %indvars.iv141, !dbg !548
  store i64 %49, ptr %arrayidx89.2, align 8, !dbg !549, !tbaa !295
  tail call void @llvm.dbg.value(metadata i64 4, metadata !506, metadata !DIExpression()), !dbg !539
  %and80.3 = and i32 %xor84.2, 255, !dbg !540
  %idxprom81.3 = zext nneg i32 %and80.3 to i64, !dbg !543
  %arrayidx82.3 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom81.3, !dbg !543
  %50 = load i32, ptr %arrayidx82.3, align 4, !dbg !543, !tbaa !156
  %shr83.3 = lshr i32 %xor84.2, 8, !dbg !544
  %xor84.3 = xor i32 %50, %shr83.3, !dbg !545
  tail call void @llvm.dbg.value(metadata i32 %xor84.3, metadata !503, metadata !DIExpression()), !dbg !534
  %conv85.3 = zext i32 %xor84.3 to i64, !dbg !546
  %51 = tail call i64 @llvm.bswap.i64(i64 %conv85.3), !dbg !547
  %arrayidx89.3 = getelementptr inbounds [8 x [256 x i64]], ptr @crc32c_table_big, i64 0, i64 4, i64 %indvars.iv141, !dbg !548
  store i64 %51, ptr %arrayidx89.3, align 8, !dbg !549, !tbaa !295
  tail call void @llvm.dbg.value(metadata i64 5, metadata !506, metadata !DIExpression()), !dbg !539
  %and80.4 = and i32 %xor84.3, 255, !dbg !540
  %idxprom81.4 = zext nneg i32 %and80.4 to i64, !dbg !543
  %arrayidx82.4 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom81.4, !dbg !543
  %52 = load i32, ptr %arrayidx82.4, align 4, !dbg !543, !tbaa !156
  %shr83.4 = lshr i32 %xor84.3, 8, !dbg !544
  %xor84.4 = xor i32 %52, %shr83.4, !dbg !545
  tail call void @llvm.dbg.value(metadata i32 %xor84.4, metadata !503, metadata !DIExpression()), !dbg !534
  %conv85.4 = zext i32 %xor84.4 to i64, !dbg !546
  %53 = tail call i64 @llvm.bswap.i64(i64 %conv85.4), !dbg !547
  %arrayidx89.4 = getelementptr inbounds [8 x [256 x i64]], ptr @crc32c_table_big, i64 0, i64 5, i64 %indvars.iv141, !dbg !548
  store i64 %53, ptr %arrayidx89.4, align 8, !dbg !549, !tbaa !295
  tail call void @llvm.dbg.value(metadata i64 6, metadata !506, metadata !DIExpression()), !dbg !539
  %and80.5 = and i32 %xor84.4, 255, !dbg !540
  %idxprom81.5 = zext nneg i32 %and80.5 to i64, !dbg !543
  %arrayidx82.5 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom81.5, !dbg !543
  %54 = load i32, ptr %arrayidx82.5, align 4, !dbg !543, !tbaa !156
  %shr83.5 = lshr i32 %xor84.4, 8, !dbg !544
  %xor84.5 = xor i32 %54, %shr83.5, !dbg !545
  tail call void @llvm.dbg.value(metadata i32 %xor84.5, metadata !503, metadata !DIExpression()), !dbg !534
  %conv85.5 = zext i32 %xor84.5 to i64, !dbg !546
  %55 = tail call i64 @llvm.bswap.i64(i64 %conv85.5), !dbg !547
  %arrayidx89.5 = getelementptr inbounds [8 x [256 x i64]], ptr @crc32c_table_big, i64 0, i64 6, i64 %indvars.iv141, !dbg !548
  store i64 %55, ptr %arrayidx89.5, align 8, !dbg !549, !tbaa !295
  tail call void @llvm.dbg.value(metadata i64 7, metadata !506, metadata !DIExpression()), !dbg !539
  %and80.6 = and i32 %xor84.5, 255, !dbg !540
  %idxprom81.6 = zext nneg i32 %and80.6 to i64, !dbg !543
  %arrayidx82.6 = getelementptr inbounds [256 x i32], ptr @crc32c_table_big_byte, i64 0, i64 %idxprom81.6, !dbg !543
  %56 = load i32, ptr %arrayidx82.6, align 4, !dbg !543, !tbaa !156
  %shr83.6 = lshr i32 %xor84.5, 8, !dbg !544
  %xor84.6 = xor i32 %56, %shr83.6, !dbg !545
  tail call void @llvm.dbg.value(metadata i32 %xor84.6, metadata !503, metadata !DIExpression()), !dbg !534
  %conv85.6 = zext i32 %xor84.6 to i64, !dbg !546
  %57 = tail call i64 @llvm.bswap.i64(i64 %conv85.6), !dbg !547
  %arrayidx89.6 = getelementptr inbounds [8 x [256 x i64]], ptr @crc32c_table_big, i64 0, i64 7, i64 %indvars.iv141, !dbg !548
  store i64 %57, ptr %arrayidx89.6, align 8, !dbg !549, !tbaa !295
  tail call void @llvm.dbg.value(metadata i64 8, metadata !506, metadata !DIExpression()), !dbg !539
  %indvars.iv.next142 = add nuw nsw i64 %indvars.iv141, 1, !dbg !550
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next142, metadata !501, metadata !DIExpression()), !dbg !532
  %exitcond144.not = icmp eq i64 %indvars.iv.next142, 256, !dbg !551
  br i1 %exitcond144.not, label %for.cond.cleanup68, label %for.body69, !dbg !552, !llvm.loop !553
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #5

; Function Attrs: nofree norecurse nosync nounwind sanitize_thread memory(write, argmem: none, inaccessiblemem: none) uwtable
define internal void @crc32c_init_hw() #6 !dbg !555 {
entry:
  tail call fastcc void @crc32c_zeros(ptr noundef nonnull @crc32c_long, i64 noundef 8192), !dbg !556
  tail call fastcc void @crc32c_zeros(ptr noundef nonnull @crc32c_short, i64 noundef 256), !dbg !557
  ret void, !dbg !558
}

; Function Attrs: nofree norecurse nosync nounwind sanitize_thread memory(argmem: write) uwtable
define internal fastcc void @crc32c_zeros(ptr nocapture noundef writeonly %zeros, i64 noundef %len) unnamed_addr #7 !dbg !559 {
entry:
  %odd.i = alloca [32 x i32], align 16, !DIAssignID !571
  %op = alloca [32 x i32], align 16, !DIAssignID !572
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !565, metadata !DIExpression(), metadata !572, metadata ptr %op, metadata !DIExpression()), !dbg !573
  tail call void @llvm.dbg.value(metadata ptr %zeros, metadata !563, metadata !DIExpression()), !dbg !573
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !564, metadata !DIExpression()), !dbg !573
  call void @llvm.lifetime.start.p0(i64 128, ptr nonnull %op) #12, !dbg !574
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !575, metadata !DIExpression(), metadata !571, metadata ptr %odd.i, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata ptr %op, metadata !581, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !582, metadata !DIExpression()), !dbg !588
  call void @llvm.lifetime.start.p0(i64 128, ptr nonnull %odd.i) #12, !dbg !590
  tail call void @llvm.dbg.assign(metadata i32 -2097792136, metadata !575, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !591, metadata ptr %odd.i, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 1, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 1, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 1, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 1, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 2, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 2, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 2, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 2, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 4, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 3, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 3, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 4, metadata !583, metadata !DIExpression()), !dbg !588
  store <4 x i32> <i32 -2097792136, i32 1, i32 2, i32 4>, ptr %odd.i, align 16, !dbg !593, !tbaa !156, !DIAssignID !591
  tail call void @llvm.dbg.value(metadata i32 8, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 4, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 4, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 8, metadata !583, metadata !DIExpression()), !dbg !588
  %arrayidx1.3.i = getelementptr inbounds i8, ptr %odd.i, i64 16, !dbg !594
  tail call void @llvm.dbg.value(metadata i32 16, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 5, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 5, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 16, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 32, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 6, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 6, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 32, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 64, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 7, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 7, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 64, metadata !583, metadata !DIExpression()), !dbg !588
  store <4 x i32> <i32 8, i32 16, i32 32, i32 64>, ptr %arrayidx1.3.i, align 16, !dbg !597, !tbaa !156
  tail call void @llvm.dbg.value(metadata i32 128, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 8, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 8, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 128, metadata !583, metadata !DIExpression()), !dbg !588
  %arrayidx1.7.i = getelementptr inbounds i8, ptr %odd.i, i64 32, !dbg !594
  tail call void @llvm.dbg.value(metadata i32 256, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 9, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 9, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 256, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 512, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 10, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 10, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 512, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 1024, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 11, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 11, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 1024, metadata !583, metadata !DIExpression()), !dbg !588
  store <4 x i32> <i32 128, i32 256, i32 512, i32 1024>, ptr %arrayidx1.7.i, align 16, !dbg !597, !tbaa !156
  tail call void @llvm.dbg.value(metadata i32 2048, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 12, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 12, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 2048, metadata !583, metadata !DIExpression()), !dbg !588
  %arrayidx1.11.i = getelementptr inbounds i8, ptr %odd.i, i64 48, !dbg !594
  tail call void @llvm.dbg.value(metadata i32 4096, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 13, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 13, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 4096, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 8192, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 14, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 14, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 8192, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 16384, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 15, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 15, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 16384, metadata !583, metadata !DIExpression()), !dbg !588
  store <4 x i32> <i32 2048, i32 4096, i32 8192, i32 16384>, ptr %arrayidx1.11.i, align 16, !dbg !597, !tbaa !156
  tail call void @llvm.dbg.value(metadata i32 32768, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 16, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 16, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 32768, metadata !583, metadata !DIExpression()), !dbg !588
  %arrayidx1.15.i = getelementptr inbounds i8, ptr %odd.i, i64 64, !dbg !594
  tail call void @llvm.dbg.value(metadata i32 65536, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 17, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 17, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 65536, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 131072, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 18, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 18, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 131072, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 262144, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 19, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 19, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 262144, metadata !583, metadata !DIExpression()), !dbg !588
  store <4 x i32> <i32 32768, i32 65536, i32 131072, i32 262144>, ptr %arrayidx1.15.i, align 16, !dbg !597, !tbaa !156
  tail call void @llvm.dbg.value(metadata i32 524288, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 20, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 20, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 524288, metadata !583, metadata !DIExpression()), !dbg !588
  %arrayidx1.19.i = getelementptr inbounds i8, ptr %odd.i, i64 80, !dbg !594
  tail call void @llvm.dbg.value(metadata i32 1048576, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 21, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 21, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 1048576, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 2097152, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 22, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 22, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 2097152, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 4194304, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 23, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 23, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 4194304, metadata !583, metadata !DIExpression()), !dbg !588
  store <4 x i32> <i32 524288, i32 1048576, i32 2097152, i32 4194304>, ptr %arrayidx1.19.i, align 16, !dbg !597, !tbaa !156
  tail call void @llvm.dbg.value(metadata i32 8388608, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 24, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 24, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 8388608, metadata !583, metadata !DIExpression()), !dbg !588
  %arrayidx1.23.i = getelementptr inbounds i8, ptr %odd.i, i64 96, !dbg !594
  tail call void @llvm.dbg.value(metadata i32 16777216, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 25, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 25, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 16777216, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 33554432, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 26, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 26, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 33554432, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 67108864, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 27, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 27, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 67108864, metadata !583, metadata !DIExpression()), !dbg !588
  store <4 x i32> <i32 8388608, i32 16777216, i32 33554432, i32 67108864>, ptr %arrayidx1.23.i, align 16, !dbg !597, !tbaa !156
  tail call void @llvm.dbg.value(metadata i32 134217728, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 28, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 28, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 134217728, metadata !583, metadata !DIExpression()), !dbg !588
  %arrayidx1.27.i = getelementptr inbounds i8, ptr %odd.i, i64 112, !dbg !594
  tail call void @llvm.dbg.value(metadata i32 268435456, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 29, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 29, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 268435456, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 536870912, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 30, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 30, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 536870912, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i32 1073741824, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 31, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 31, metadata !584, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 1073741824, metadata !583, metadata !DIExpression()), !dbg !588
  store <4 x i32> <i32 134217728, i32 268435456, i32 536870912, i32 1073741824>, ptr %arrayidx1.27.i, align 16, !dbg !597, !tbaa !156
  tail call void @llvm.dbg.value(metadata i32 -2147483648, metadata !583, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata i64 32, metadata !584, metadata !DIExpression()), !dbg !592
  br label %for.body.i.i, !dbg !598

for.body.i.i:                                     ; preds = %gf2_matrix_times.exit.i.i, %entry
  %indvars.iv.i.i = phi i64 [ %indvars.iv.next.i.i, %gf2_matrix_times.exit.i.i ], [ 0, %entry ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i.i, metadata !606, metadata !DIExpression()), !dbg !608
  %arrayidx.i.i = getelementptr inbounds i32, ptr %odd.i, i64 %indvars.iv.i.i, !dbg !609
  %0 = load i32, ptr %arrayidx.i.i, align 4, !dbg !609, !tbaa !156
  tail call void @llvm.dbg.value(metadata ptr %odd.i, metadata !611, metadata !DIExpression()), !dbg !618
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !616, metadata !DIExpression()), !dbg !618
  tail call void @llvm.dbg.value(metadata i32 0, metadata !617, metadata !DIExpression()), !dbg !618
  %tobool.not6.i.i.i = icmp eq i32 %0, 0, !dbg !620
  br i1 %tobool.not6.i.i.i, label %gf2_matrix_times.exit.i.i, label %while.body.i.i.i, !dbg !620

while.body.i.i.i:                                 ; preds = %for.body.i.i, %if.end.i.i.i
  %sum.09.i.i.i = phi i32 [ %sum.1.i.i.i, %if.end.i.i.i ], [ 0, %for.body.i.i ]
  %vec.addr.08.i.i.i = phi i32 [ %shr.i.i.i, %if.end.i.i.i ], [ %0, %for.body.i.i ]
  %mat.addr.07.i.i.i = phi ptr [ %incdec.ptr.i.i.i, %if.end.i.i.i ], [ %odd.i, %for.body.i.i ]
  tail call void @llvm.dbg.value(metadata i32 %sum.09.i.i.i, metadata !617, metadata !DIExpression()), !dbg !618
  tail call void @llvm.dbg.value(metadata i32 %vec.addr.08.i.i.i, metadata !616, metadata !DIExpression()), !dbg !618
  tail call void @llvm.dbg.value(metadata ptr %mat.addr.07.i.i.i, metadata !611, metadata !DIExpression()), !dbg !618
  %and.i.i.i = and i32 %vec.addr.08.i.i.i, 1, !dbg !621
  %tobool1.not.i.i.i = icmp eq i32 %and.i.i.i, 0, !dbg !621
  br i1 %tobool1.not.i.i.i, label %if.end.i.i.i, label %if.then.i.i.i, !dbg !624

if.then.i.i.i:                                    ; preds = %while.body.i.i.i
  %1 = load i32, ptr %mat.addr.07.i.i.i, align 4, !dbg !625, !tbaa !156
  %xor.i.i.i = xor i32 %1, %sum.09.i.i.i, !dbg !626
  tail call void @llvm.dbg.value(metadata i32 %xor.i.i.i, metadata !617, metadata !DIExpression()), !dbg !618
  br label %if.end.i.i.i, !dbg !627

if.end.i.i.i:                                     ; preds = %if.then.i.i.i, %while.body.i.i.i
  %sum.1.i.i.i = phi i32 [ %xor.i.i.i, %if.then.i.i.i ], [ %sum.09.i.i.i, %while.body.i.i.i ], !dbg !618
  tail call void @llvm.dbg.value(metadata i32 %sum.1.i.i.i, metadata !617, metadata !DIExpression()), !dbg !618
  %shr.i.i.i = lshr i32 %vec.addr.08.i.i.i, 1, !dbg !628
  tail call void @llvm.dbg.value(metadata i32 %shr.i.i.i, metadata !616, metadata !DIExpression()), !dbg !618
  %incdec.ptr.i.i.i = getelementptr inbounds i8, ptr %mat.addr.07.i.i.i, i64 4, !dbg !629
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i.i.i, metadata !611, metadata !DIExpression()), !dbg !618
  %tobool.not.i.i.i = icmp ult i32 %vec.addr.08.i.i.i, 2, !dbg !620
  br i1 %tobool.not.i.i.i, label %gf2_matrix_times.exit.i.i, label %while.body.i.i.i, !dbg !620, !llvm.loop !630

gf2_matrix_times.exit.i.i:                        ; preds = %if.end.i.i.i, %for.body.i.i
  %sum.0.lcssa.i.i.i = phi i32 [ 0, %for.body.i.i ], [ %sum.1.i.i.i, %if.end.i.i.i ], !dbg !618
  %arrayidx2.i.i = getelementptr inbounds i32, ptr %op, i64 %indvars.iv.i.i, !dbg !632
  store i32 %sum.0.lcssa.i.i.i, ptr %arrayidx2.i.i, align 4, !dbg !633, !tbaa !156
  %indvars.iv.next.i.i = add nuw nsw i64 %indvars.iv.i.i, 1, !dbg !634
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.i, metadata !606, metadata !DIExpression()), !dbg !608
  %exitcond.not.i.i = icmp eq i64 %indvars.iv.next.i.i, 32, !dbg !635
  br i1 %exitcond.not.i.i, label %for.body.i33.i, label %for.body.i.i, !dbg !598, !llvm.loop !636

for.body.i33.i:                                   ; preds = %gf2_matrix_times.exit.i.i, %gf2_matrix_times.exit.i50.i
  %indvars.iv.i34.i = phi i64 [ %indvars.iv.next.i53.i, %gf2_matrix_times.exit.i50.i ], [ 0, %gf2_matrix_times.exit.i.i ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i34.i, metadata !606, metadata !DIExpression()), !dbg !638
  %arrayidx.i35.i = getelementptr inbounds i32, ptr %op, i64 %indvars.iv.i34.i, !dbg !640
  %2 = load i32, ptr %arrayidx.i35.i, align 4, !dbg !640, !tbaa !156
  tail call void @llvm.dbg.value(metadata ptr %op, metadata !611, metadata !DIExpression()), !dbg !641
  tail call void @llvm.dbg.value(metadata i32 %2, metadata !616, metadata !DIExpression()), !dbg !641
  tail call void @llvm.dbg.value(metadata i32 0, metadata !617, metadata !DIExpression()), !dbg !641
  %tobool.not6.i.i36.i = icmp eq i32 %2, 0, !dbg !643
  br i1 %tobool.not6.i.i36.i, label %gf2_matrix_times.exit.i50.i, label %while.body.i.i37.i, !dbg !643

while.body.i.i37.i:                               ; preds = %for.body.i33.i, %if.end.i.i45.i
  %sum.09.i.i38.i = phi i32 [ %sum.1.i.i46.i, %if.end.i.i45.i ], [ 0, %for.body.i33.i ]
  %vec.addr.08.i.i39.i = phi i32 [ %shr.i.i47.i, %if.end.i.i45.i ], [ %2, %for.body.i33.i ]
  %mat.addr.07.i.i40.i = phi ptr [ %incdec.ptr.i.i48.i, %if.end.i.i45.i ], [ %op, %for.body.i33.i ]
  tail call void @llvm.dbg.value(metadata i32 %sum.09.i.i38.i, metadata !617, metadata !DIExpression()), !dbg !641
  tail call void @llvm.dbg.value(metadata i32 %vec.addr.08.i.i39.i, metadata !616, metadata !DIExpression()), !dbg !641
  tail call void @llvm.dbg.value(metadata ptr %mat.addr.07.i.i40.i, metadata !611, metadata !DIExpression()), !dbg !641
  %and.i.i41.i = and i32 %vec.addr.08.i.i39.i, 1, !dbg !644
  %tobool1.not.i.i42.i = icmp eq i32 %and.i.i41.i, 0, !dbg !644
  br i1 %tobool1.not.i.i42.i, label %if.end.i.i45.i, label %if.then.i.i43.i, !dbg !645

if.then.i.i43.i:                                  ; preds = %while.body.i.i37.i
  %3 = load i32, ptr %mat.addr.07.i.i40.i, align 4, !dbg !646, !tbaa !156
  %xor.i.i44.i = xor i32 %3, %sum.09.i.i38.i, !dbg !647
  tail call void @llvm.dbg.value(metadata i32 %xor.i.i44.i, metadata !617, metadata !DIExpression()), !dbg !641
  br label %if.end.i.i45.i, !dbg !648

if.end.i.i45.i:                                   ; preds = %if.then.i.i43.i, %while.body.i.i37.i
  %sum.1.i.i46.i = phi i32 [ %xor.i.i44.i, %if.then.i.i43.i ], [ %sum.09.i.i38.i, %while.body.i.i37.i ], !dbg !641
  tail call void @llvm.dbg.value(metadata i32 %sum.1.i.i46.i, metadata !617, metadata !DIExpression()), !dbg !641
  %shr.i.i47.i = lshr i32 %vec.addr.08.i.i39.i, 1, !dbg !649
  tail call void @llvm.dbg.value(metadata i32 %shr.i.i47.i, metadata !616, metadata !DIExpression()), !dbg !641
  %incdec.ptr.i.i48.i = getelementptr inbounds i8, ptr %mat.addr.07.i.i40.i, i64 4, !dbg !650
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i.i48.i, metadata !611, metadata !DIExpression()), !dbg !641
  %tobool.not.i.i49.i = icmp ult i32 %vec.addr.08.i.i39.i, 2, !dbg !643
  br i1 %tobool.not.i.i49.i, label %gf2_matrix_times.exit.i50.i, label %while.body.i.i37.i, !dbg !643, !llvm.loop !651

gf2_matrix_times.exit.i50.i:                      ; preds = %if.end.i.i45.i, %for.body.i33.i
  %sum.0.lcssa.i.i51.i = phi i32 [ 0, %for.body.i33.i ], [ %sum.1.i.i46.i, %if.end.i.i45.i ], !dbg !641
  %arrayidx2.i52.i = getelementptr inbounds i32, ptr %odd.i, i64 %indvars.iv.i34.i, !dbg !653
  store i32 %sum.0.lcssa.i.i51.i, ptr %arrayidx2.i52.i, align 4, !dbg !654, !tbaa !156
  %indvars.iv.next.i53.i = add nuw nsw i64 %indvars.iv.i34.i, 1, !dbg !655
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i53.i, metadata !606, metadata !DIExpression()), !dbg !638
  %exitcond.not.i54.i = icmp eq i64 %indvars.iv.next.i53.i, 32, !dbg !656
  br i1 %exitcond.not.i54.i, label %do.body.i, label %for.body.i33.i, !dbg !657, !llvm.loop !658

do.body.i:                                        ; preds = %gf2_matrix_times.exit.i50.i, %gf2_matrix_square.exit101.i
  %len.addr.0.i = phi i64 [ %shr.i, %gf2_matrix_square.exit101.i ], [ %len, %gf2_matrix_times.exit.i50.i ]
  tail call void @llvm.dbg.value(metadata i64 %len.addr.0.i, metadata !582, metadata !DIExpression()), !dbg !588
  tail call void @llvm.dbg.value(metadata ptr %op, metadata !604, metadata !DIExpression()), !dbg !660
  tail call void @llvm.dbg.value(metadata ptr %odd.i, metadata !605, metadata !DIExpression()), !dbg !660
  tail call void @llvm.dbg.value(metadata i32 0, metadata !606, metadata !DIExpression()), !dbg !663
  br label %for.body.i56.i, !dbg !664

for.body.i56.i:                                   ; preds = %gf2_matrix_times.exit.i73.i, %do.body.i
  %indvars.iv.i57.i = phi i64 [ 0, %do.body.i ], [ %indvars.iv.next.i76.i, %gf2_matrix_times.exit.i73.i ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i57.i, metadata !606, metadata !DIExpression()), !dbg !663
  %arrayidx.i58.i = getelementptr inbounds i32, ptr %odd.i, i64 %indvars.iv.i57.i, !dbg !665
  %4 = load i32, ptr %arrayidx.i58.i, align 4, !dbg !665, !tbaa !156
  tail call void @llvm.dbg.value(metadata ptr %odd.i, metadata !611, metadata !DIExpression()), !dbg !666
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !616, metadata !DIExpression()), !dbg !666
  tail call void @llvm.dbg.value(metadata i32 0, metadata !617, metadata !DIExpression()), !dbg !666
  %tobool.not6.i.i59.i = icmp eq i32 %4, 0, !dbg !668
  br i1 %tobool.not6.i.i59.i, label %gf2_matrix_times.exit.i73.i, label %while.body.i.i60.i, !dbg !668

while.body.i.i60.i:                               ; preds = %for.body.i56.i, %if.end.i.i68.i
  %sum.09.i.i61.i = phi i32 [ %sum.1.i.i69.i, %if.end.i.i68.i ], [ 0, %for.body.i56.i ]
  %vec.addr.08.i.i62.i = phi i32 [ %shr.i.i70.i, %if.end.i.i68.i ], [ %4, %for.body.i56.i ]
  %mat.addr.07.i.i63.i = phi ptr [ %incdec.ptr.i.i71.i, %if.end.i.i68.i ], [ %odd.i, %for.body.i56.i ]
  tail call void @llvm.dbg.value(metadata i32 %sum.09.i.i61.i, metadata !617, metadata !DIExpression()), !dbg !666
  tail call void @llvm.dbg.value(metadata i32 %vec.addr.08.i.i62.i, metadata !616, metadata !DIExpression()), !dbg !666
  tail call void @llvm.dbg.value(metadata ptr %mat.addr.07.i.i63.i, metadata !611, metadata !DIExpression()), !dbg !666
  %and.i.i64.i = and i32 %vec.addr.08.i.i62.i, 1, !dbg !669
  %tobool1.not.i.i65.i = icmp eq i32 %and.i.i64.i, 0, !dbg !669
  br i1 %tobool1.not.i.i65.i, label %if.end.i.i68.i, label %if.then.i.i66.i, !dbg !670

if.then.i.i66.i:                                  ; preds = %while.body.i.i60.i
  %5 = load i32, ptr %mat.addr.07.i.i63.i, align 4, !dbg !671, !tbaa !156
  %xor.i.i67.i = xor i32 %5, %sum.09.i.i61.i, !dbg !672
  tail call void @llvm.dbg.value(metadata i32 %xor.i.i67.i, metadata !617, metadata !DIExpression()), !dbg !666
  br label %if.end.i.i68.i, !dbg !673

if.end.i.i68.i:                                   ; preds = %if.then.i.i66.i, %while.body.i.i60.i
  %sum.1.i.i69.i = phi i32 [ %xor.i.i67.i, %if.then.i.i66.i ], [ %sum.09.i.i61.i, %while.body.i.i60.i ], !dbg !666
  tail call void @llvm.dbg.value(metadata i32 %sum.1.i.i69.i, metadata !617, metadata !DIExpression()), !dbg !666
  %shr.i.i70.i = lshr i32 %vec.addr.08.i.i62.i, 1, !dbg !674
  tail call void @llvm.dbg.value(metadata i32 %shr.i.i70.i, metadata !616, metadata !DIExpression()), !dbg !666
  %incdec.ptr.i.i71.i = getelementptr inbounds i8, ptr %mat.addr.07.i.i63.i, i64 4, !dbg !675
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i.i71.i, metadata !611, metadata !DIExpression()), !dbg !666
  %tobool.not.i.i72.i = icmp ult i32 %vec.addr.08.i.i62.i, 2, !dbg !668
  br i1 %tobool.not.i.i72.i, label %gf2_matrix_times.exit.i73.i, label %while.body.i.i60.i, !dbg !668, !llvm.loop !676

gf2_matrix_times.exit.i73.i:                      ; preds = %if.end.i.i68.i, %for.body.i56.i
  %sum.0.lcssa.i.i74.i = phi i32 [ 0, %for.body.i56.i ], [ %sum.1.i.i69.i, %if.end.i.i68.i ], !dbg !666
  %arrayidx2.i75.i = getelementptr inbounds i32, ptr %op, i64 %indvars.iv.i57.i, !dbg !678
  store i32 %sum.0.lcssa.i.i74.i, ptr %arrayidx2.i75.i, align 4, !dbg !679, !tbaa !156
  %indvars.iv.next.i76.i = add nuw nsw i64 %indvars.iv.i57.i, 1, !dbg !680
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i76.i, metadata !606, metadata !DIExpression()), !dbg !663
  %exitcond.not.i77.i = icmp eq i64 %indvars.iv.next.i76.i, 32, !dbg !681
  br i1 %exitcond.not.i77.i, label %gf2_matrix_square.exit78.i, label %for.body.i56.i, !dbg !664, !llvm.loop !682

gf2_matrix_square.exit78.i:                       ; preds = %gf2_matrix_times.exit.i73.i
  tail call void @llvm.dbg.value(metadata i64 %len.addr.0.i, metadata !582, metadata !DIExpression(DW_OP_constu, 1, DW_OP_shr, DW_OP_stack_value)), !dbg !588
  %cmp4.i = icmp ult i64 %len.addr.0.i, 2, !dbg !684
  br i1 %cmp4.i, label %crc32c_zeros_op.exit, label %for.body.i79.i, !dbg !686

for.body.i79.i:                                   ; preds = %gf2_matrix_square.exit78.i, %gf2_matrix_times.exit.i96.i
  %indvars.iv.i80.i = phi i64 [ %indvars.iv.next.i99.i, %gf2_matrix_times.exit.i96.i ], [ 0, %gf2_matrix_square.exit78.i ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i80.i, metadata !606, metadata !DIExpression()), !dbg !687
  %arrayidx.i81.i = getelementptr inbounds i32, ptr %op, i64 %indvars.iv.i80.i, !dbg !689
  %6 = load i32, ptr %arrayidx.i81.i, align 4, !dbg !689, !tbaa !156
  tail call void @llvm.dbg.value(metadata ptr %op, metadata !611, metadata !DIExpression()), !dbg !690
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !616, metadata !DIExpression()), !dbg !690
  tail call void @llvm.dbg.value(metadata i32 0, metadata !617, metadata !DIExpression()), !dbg !690
  %tobool.not6.i.i82.i = icmp eq i32 %6, 0, !dbg !692
  br i1 %tobool.not6.i.i82.i, label %gf2_matrix_times.exit.i96.i, label %while.body.i.i83.i, !dbg !692

while.body.i.i83.i:                               ; preds = %for.body.i79.i, %if.end.i.i91.i
  %sum.09.i.i84.i = phi i32 [ %sum.1.i.i92.i, %if.end.i.i91.i ], [ 0, %for.body.i79.i ]
  %vec.addr.08.i.i85.i = phi i32 [ %shr.i.i93.i, %if.end.i.i91.i ], [ %6, %for.body.i79.i ]
  %mat.addr.07.i.i86.i = phi ptr [ %incdec.ptr.i.i94.i, %if.end.i.i91.i ], [ %op, %for.body.i79.i ]
  tail call void @llvm.dbg.value(metadata i32 %sum.09.i.i84.i, metadata !617, metadata !DIExpression()), !dbg !690
  tail call void @llvm.dbg.value(metadata i32 %vec.addr.08.i.i85.i, metadata !616, metadata !DIExpression()), !dbg !690
  tail call void @llvm.dbg.value(metadata ptr %mat.addr.07.i.i86.i, metadata !611, metadata !DIExpression()), !dbg !690
  %and.i.i87.i = and i32 %vec.addr.08.i.i85.i, 1, !dbg !693
  %tobool1.not.i.i88.i = icmp eq i32 %and.i.i87.i, 0, !dbg !693
  br i1 %tobool1.not.i.i88.i, label %if.end.i.i91.i, label %if.then.i.i89.i, !dbg !694

if.then.i.i89.i:                                  ; preds = %while.body.i.i83.i
  %7 = load i32, ptr %mat.addr.07.i.i86.i, align 4, !dbg !695, !tbaa !156
  %xor.i.i90.i = xor i32 %7, %sum.09.i.i84.i, !dbg !696
  tail call void @llvm.dbg.value(metadata i32 %xor.i.i90.i, metadata !617, metadata !DIExpression()), !dbg !690
  br label %if.end.i.i91.i, !dbg !697

if.end.i.i91.i:                                   ; preds = %if.then.i.i89.i, %while.body.i.i83.i
  %sum.1.i.i92.i = phi i32 [ %xor.i.i90.i, %if.then.i.i89.i ], [ %sum.09.i.i84.i, %while.body.i.i83.i ], !dbg !690
  tail call void @llvm.dbg.value(metadata i32 %sum.1.i.i92.i, metadata !617, metadata !DIExpression()), !dbg !690
  %shr.i.i93.i = lshr i32 %vec.addr.08.i.i85.i, 1, !dbg !698
  tail call void @llvm.dbg.value(metadata i32 %shr.i.i93.i, metadata !616, metadata !DIExpression()), !dbg !690
  %incdec.ptr.i.i94.i = getelementptr inbounds i8, ptr %mat.addr.07.i.i86.i, i64 4, !dbg !699
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i.i94.i, metadata !611, metadata !DIExpression()), !dbg !690
  %tobool.not.i.i95.i = icmp ult i32 %vec.addr.08.i.i85.i, 2, !dbg !692
  br i1 %tobool.not.i.i95.i, label %gf2_matrix_times.exit.i96.i, label %while.body.i.i83.i, !dbg !692, !llvm.loop !700

gf2_matrix_times.exit.i96.i:                      ; preds = %if.end.i.i91.i, %for.body.i79.i
  %sum.0.lcssa.i.i97.i = phi i32 [ 0, %for.body.i79.i ], [ %sum.1.i.i92.i, %if.end.i.i91.i ], !dbg !690
  %arrayidx2.i98.i = getelementptr inbounds i32, ptr %odd.i, i64 %indvars.iv.i80.i, !dbg !702
  store i32 %sum.0.lcssa.i.i97.i, ptr %arrayidx2.i98.i, align 4, !dbg !703, !tbaa !156
  %indvars.iv.next.i99.i = add nuw nsw i64 %indvars.iv.i80.i, 1, !dbg !704
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i99.i, metadata !606, metadata !DIExpression()), !dbg !687
  %exitcond.not.i100.i = icmp eq i64 %indvars.iv.next.i99.i, 32, !dbg !705
  br i1 %exitcond.not.i100.i, label %gf2_matrix_square.exit101.i, label %for.body.i79.i, !dbg !706, !llvm.loop !707

gf2_matrix_square.exit101.i:                      ; preds = %gf2_matrix_times.exit.i96.i
  %shr.i = lshr i64 %len.addr.0.i, 2, !dbg !709
  tail call void @llvm.dbg.value(metadata i64 %shr.i, metadata !582, metadata !DIExpression()), !dbg !588
  %tobool.not.i = icmp ult i64 %len.addr.0.i, 4, !dbg !710
  br i1 %tobool.not.i, label %for.body11.preheader.i, label %do.body.i, !dbg !710, !llvm.loop !711

for.body11.preheader.i:                           ; preds = %gf2_matrix_square.exit101.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(128) %op, ptr noundef nonnull align 16 dereferenceable(128) %odd.i, i64 128, i1 false), !dbg !714, !tbaa !156, !DIAssignID !716
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !565, metadata !DIExpression(), metadata !716, metadata ptr %op, metadata !DIExpression()), !dbg !573
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !586, metadata !DIExpression()), !dbg !717
  br label %crc32c_zeros_op.exit, !dbg !718

crc32c_zeros_op.exit:                             ; preds = %gf2_matrix_square.exit78.i, %for.body11.preheader.i
  call void @llvm.lifetime.end.p0(i64 128, ptr nonnull %odd.i) #12, !dbg !718
  tail call void @llvm.dbg.value(metadata i32 0, metadata !569, metadata !DIExpression()), !dbg !719
  %arrayidx17 = getelementptr inbounds i8, ptr %zeros, i64 3072
  %arrayidx5 = getelementptr inbounds i8, ptr %zeros, i64 1024
  %arrayidx11 = getelementptr inbounds i8, ptr %zeros, i64 2048
  br label %for.body, !dbg !720

for.cond.cleanup:                                 ; preds = %gf2_matrix_times.exit81
  call void @llvm.lifetime.end.p0(i64 128, ptr nonnull %op) #12, !dbg !721
  ret void, !dbg !721

for.body:                                         ; preds = %crc32c_zeros_op.exit, %gf2_matrix_times.exit81
  %indvars.iv = phi i64 [ 0, %crc32c_zeros_op.exit ], [ %indvars.iv.next, %gf2_matrix_times.exit81 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !569, metadata !DIExpression()), !dbg !719
  tail call void @llvm.dbg.value(metadata ptr %op, metadata !611, metadata !DIExpression()), !dbg !722
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !616, metadata !DIExpression()), !dbg !722
  tail call void @llvm.dbg.value(metadata i32 0, metadata !617, metadata !DIExpression()), !dbg !722
  %tobool.not6.i = icmp eq i64 %indvars.iv, 0, !dbg !726
  br i1 %tobool.not6.i, label %gf2_matrix_times.exit65.thread, label %while.body.i.preheader, !dbg !726

while.body.i.preheader:                           ; preds = %for.body
  %8 = trunc nuw nsw i64 %indvars.iv to i32, !dbg !726
  br label %while.body.i, !dbg !726

gf2_matrix_times.exit65.thread:                   ; preds = %for.body
  store i32 0, ptr %zeros, align 4, !dbg !727, !tbaa !156
  tail call void @llvm.dbg.value(metadata ptr %op, metadata !611, metadata !DIExpression()), !dbg !728
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !616, metadata !DIExpression(DW_OP_constu, 8, DW_OP_shl, DW_OP_stack_value)), !dbg !728
  tail call void @llvm.dbg.value(metadata i32 0, metadata !617, metadata !DIExpression()), !dbg !728
  store i32 0, ptr %arrayidx5, align 4, !dbg !730, !tbaa !156
  tail call void @llvm.dbg.value(metadata ptr %op, metadata !611, metadata !DIExpression()), !dbg !731
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !616, metadata !DIExpression(DW_OP_constu, 16, DW_OP_shl, DW_OP_stack_value)), !dbg !731
  tail call void @llvm.dbg.value(metadata i32 0, metadata !617, metadata !DIExpression()), !dbg !731
  store i32 0, ptr %arrayidx11, align 4, !dbg !733, !tbaa !156
  tail call void @llvm.dbg.value(metadata ptr %op, metadata !611, metadata !DIExpression()), !dbg !734
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !616, metadata !DIExpression(DW_OP_constu, 24, DW_OP_shl, DW_OP_stack_value)), !dbg !734
  tail call void @llvm.dbg.value(metadata i32 0, metadata !617, metadata !DIExpression()), !dbg !734
  br label %gf2_matrix_times.exit81, !dbg !736

while.body.i:                                     ; preds = %while.body.i.preheader, %if.end.i
  %sum.09.i = phi i32 [ %sum.1.i, %if.end.i ], [ 0, %while.body.i.preheader ]
  %vec.addr.08.i = phi i32 [ %shr.i32, %if.end.i ], [ %8, %while.body.i.preheader ]
  %mat.addr.07.i = phi ptr [ %incdec.ptr.i, %if.end.i ], [ %op, %while.body.i.preheader ]
  tail call void @llvm.dbg.value(metadata i32 %sum.09.i, metadata !617, metadata !DIExpression()), !dbg !722
  tail call void @llvm.dbg.value(metadata i32 %vec.addr.08.i, metadata !616, metadata !DIExpression()), !dbg !722
  tail call void @llvm.dbg.value(metadata ptr %mat.addr.07.i, metadata !611, metadata !DIExpression()), !dbg !722
  %and.i = and i32 %vec.addr.08.i, 1, !dbg !737
  %tobool1.not.i = icmp eq i32 %and.i, 0, !dbg !737
  br i1 %tobool1.not.i, label %if.end.i, label %if.then.i, !dbg !738

if.then.i:                                        ; preds = %while.body.i
  %9 = load i32, ptr %mat.addr.07.i, align 4, !dbg !739, !tbaa !156
  %xor.i = xor i32 %9, %sum.09.i, !dbg !740
  tail call void @llvm.dbg.value(metadata i32 %xor.i, metadata !617, metadata !DIExpression()), !dbg !722
  br label %if.end.i, !dbg !741

if.end.i:                                         ; preds = %if.then.i, %while.body.i
  %sum.1.i = phi i32 [ %xor.i, %if.then.i ], [ %sum.09.i, %while.body.i ], !dbg !722
  tail call void @llvm.dbg.value(metadata i32 %sum.1.i, metadata !617, metadata !DIExpression()), !dbg !722
  %shr.i32 = lshr i32 %vec.addr.08.i, 1, !dbg !742
  tail call void @llvm.dbg.value(metadata i32 %shr.i32, metadata !616, metadata !DIExpression()), !dbg !722
  %incdec.ptr.i = getelementptr inbounds i8, ptr %mat.addr.07.i, i64 4, !dbg !743
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i, metadata !611, metadata !DIExpression()), !dbg !722
  %tobool.not.i33 = icmp ult i32 %vec.addr.08.i, 2, !dbg !726
  br i1 %tobool.not.i33, label %gf2_matrix_times.exit, label %while.body.i, !dbg !726, !llvm.loop !744

gf2_matrix_times.exit:                            ; preds = %if.end.i
  %arrayidx2 = getelementptr inbounds [256 x i32], ptr %zeros, i64 0, i64 %indvars.iv, !dbg !746
  store i32 %sum.1.i, ptr %arrayidx2, align 4, !dbg !727, !tbaa !156
  tail call void @llvm.dbg.value(metadata ptr %op, metadata !611, metadata !DIExpression()), !dbg !728
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !616, metadata !DIExpression(DW_OP_constu, 8, DW_OP_shl, DW_OP_stack_value)), !dbg !728
  tail call void @llvm.dbg.value(metadata i32 0, metadata !617, metadata !DIExpression()), !dbg !728
  %indvars.iv.tr = trunc i64 %indvars.iv to i32, !dbg !747
  %10 = shl i32 %indvars.iv.tr, 8, !dbg !747
  br label %while.body.i35, !dbg !747

while.body.i35:                                   ; preds = %gf2_matrix_times.exit, %if.end.i43
  %sum.09.i36 = phi i32 [ %sum.1.i44, %if.end.i43 ], [ 0, %gf2_matrix_times.exit ]
  %vec.addr.08.i37 = phi i32 [ %shr.i45, %if.end.i43 ], [ %10, %gf2_matrix_times.exit ]
  %mat.addr.07.i38 = phi ptr [ %incdec.ptr.i46, %if.end.i43 ], [ %op, %gf2_matrix_times.exit ]
  tail call void @llvm.dbg.value(metadata i32 %sum.09.i36, metadata !617, metadata !DIExpression()), !dbg !728
  tail call void @llvm.dbg.value(metadata i32 %vec.addr.08.i37, metadata !616, metadata !DIExpression()), !dbg !728
  tail call void @llvm.dbg.value(metadata ptr %mat.addr.07.i38, metadata !611, metadata !DIExpression()), !dbg !728
  %and.i39 = and i32 %vec.addr.08.i37, 1, !dbg !748
  %tobool1.not.i40 = icmp eq i32 %and.i39, 0, !dbg !748
  br i1 %tobool1.not.i40, label %if.end.i43, label %if.then.i41, !dbg !749

if.then.i41:                                      ; preds = %while.body.i35
  %11 = load i32, ptr %mat.addr.07.i38, align 4, !dbg !750, !tbaa !156
  %xor.i42 = xor i32 %11, %sum.09.i36, !dbg !751
  tail call void @llvm.dbg.value(metadata i32 %xor.i42, metadata !617, metadata !DIExpression()), !dbg !728
  br label %if.end.i43, !dbg !752

if.end.i43:                                       ; preds = %if.then.i41, %while.body.i35
  %sum.1.i44 = phi i32 [ %xor.i42, %if.then.i41 ], [ %sum.09.i36, %while.body.i35 ], !dbg !728
  tail call void @llvm.dbg.value(metadata i32 %sum.1.i44, metadata !617, metadata !DIExpression()), !dbg !728
  %shr.i45 = lshr i32 %vec.addr.08.i37, 1, !dbg !753
  tail call void @llvm.dbg.value(metadata i32 %shr.i45, metadata !616, metadata !DIExpression()), !dbg !728
  %incdec.ptr.i46 = getelementptr inbounds i8, ptr %mat.addr.07.i38, i64 4, !dbg !754
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i46, metadata !611, metadata !DIExpression()), !dbg !728
  %tobool.not.i47 = icmp ult i32 %vec.addr.08.i37, 2, !dbg !747
  br i1 %tobool.not.i47, label %gf2_matrix_times.exit49, label %while.body.i35, !dbg !747, !llvm.loop !755

gf2_matrix_times.exit49:                          ; preds = %if.end.i43
  %arrayidx7 = getelementptr inbounds [256 x i32], ptr %arrayidx5, i64 0, i64 %indvars.iv, !dbg !757
  store i32 %sum.1.i44, ptr %arrayidx7, align 4, !dbg !730, !tbaa !156
  tail call void @llvm.dbg.value(metadata ptr %op, metadata !611, metadata !DIExpression()), !dbg !731
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !616, metadata !DIExpression(DW_OP_constu, 16, DW_OP_shl, DW_OP_stack_value)), !dbg !731
  tail call void @llvm.dbg.value(metadata i32 0, metadata !617, metadata !DIExpression()), !dbg !731
  %indvars.iv.tr107 = trunc i64 %indvars.iv to i32, !dbg !758
  %12 = shl i32 %indvars.iv.tr107, 16, !dbg !758
  br label %while.body.i51, !dbg !758

while.body.i51:                                   ; preds = %gf2_matrix_times.exit49, %if.end.i59
  %sum.09.i52 = phi i32 [ %sum.1.i60, %if.end.i59 ], [ 0, %gf2_matrix_times.exit49 ]
  %vec.addr.08.i53 = phi i32 [ %shr.i61, %if.end.i59 ], [ %12, %gf2_matrix_times.exit49 ]
  %mat.addr.07.i54 = phi ptr [ %incdec.ptr.i62, %if.end.i59 ], [ %op, %gf2_matrix_times.exit49 ]
  tail call void @llvm.dbg.value(metadata i32 %sum.09.i52, metadata !617, metadata !DIExpression()), !dbg !731
  tail call void @llvm.dbg.value(metadata i32 %vec.addr.08.i53, metadata !616, metadata !DIExpression()), !dbg !731
  tail call void @llvm.dbg.value(metadata ptr %mat.addr.07.i54, metadata !611, metadata !DIExpression()), !dbg !731
  %and.i55 = and i32 %vec.addr.08.i53, 1, !dbg !759
  %tobool1.not.i56 = icmp eq i32 %and.i55, 0, !dbg !759
  br i1 %tobool1.not.i56, label %if.end.i59, label %if.then.i57, !dbg !760

if.then.i57:                                      ; preds = %while.body.i51
  %13 = load i32, ptr %mat.addr.07.i54, align 4, !dbg !761, !tbaa !156
  %xor.i58 = xor i32 %13, %sum.09.i52, !dbg !762
  tail call void @llvm.dbg.value(metadata i32 %xor.i58, metadata !617, metadata !DIExpression()), !dbg !731
  br label %if.end.i59, !dbg !763

if.end.i59:                                       ; preds = %if.then.i57, %while.body.i51
  %sum.1.i60 = phi i32 [ %xor.i58, %if.then.i57 ], [ %sum.09.i52, %while.body.i51 ], !dbg !731
  tail call void @llvm.dbg.value(metadata i32 %sum.1.i60, metadata !617, metadata !DIExpression()), !dbg !731
  %shr.i61 = lshr i32 %vec.addr.08.i53, 1, !dbg !764
  tail call void @llvm.dbg.value(metadata i32 %shr.i61, metadata !616, metadata !DIExpression()), !dbg !731
  %incdec.ptr.i62 = getelementptr inbounds i8, ptr %mat.addr.07.i54, i64 4, !dbg !765
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i62, metadata !611, metadata !DIExpression()), !dbg !731
  %tobool.not.i63 = icmp ult i32 %vec.addr.08.i53, 2, !dbg !758
  br i1 %tobool.not.i63, label %gf2_matrix_times.exit65, label %while.body.i51, !dbg !758, !llvm.loop !766

gf2_matrix_times.exit65:                          ; preds = %if.end.i59
  %arrayidx13 = getelementptr inbounds [256 x i32], ptr %arrayidx11, i64 0, i64 %indvars.iv, !dbg !768
  store i32 %sum.1.i60, ptr %arrayidx13, align 4, !dbg !733, !tbaa !156
  tail call void @llvm.dbg.value(metadata ptr %op, metadata !611, metadata !DIExpression()), !dbg !734
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !616, metadata !DIExpression(DW_OP_constu, 24, DW_OP_shl, DW_OP_stack_value)), !dbg !734
  tail call void @llvm.dbg.value(metadata i32 0, metadata !617, metadata !DIExpression()), !dbg !734
  %indvars.iv.tr108 = trunc i64 %indvars.iv to i32, !dbg !736
  %14 = shl i32 %indvars.iv.tr108, 24, !dbg !736
  br label %while.body.i67, !dbg !736

while.body.i67:                                   ; preds = %gf2_matrix_times.exit65, %if.end.i75
  %sum.09.i68 = phi i32 [ %sum.1.i76, %if.end.i75 ], [ 0, %gf2_matrix_times.exit65 ]
  %vec.addr.08.i69 = phi i32 [ %shr.i77, %if.end.i75 ], [ %14, %gf2_matrix_times.exit65 ]
  %mat.addr.07.i70 = phi ptr [ %incdec.ptr.i78, %if.end.i75 ], [ %op, %gf2_matrix_times.exit65 ]
  tail call void @llvm.dbg.value(metadata i32 %sum.09.i68, metadata !617, metadata !DIExpression()), !dbg !734
  tail call void @llvm.dbg.value(metadata i32 %vec.addr.08.i69, metadata !616, metadata !DIExpression()), !dbg !734
  tail call void @llvm.dbg.value(metadata ptr %mat.addr.07.i70, metadata !611, metadata !DIExpression()), !dbg !734
  %and.i71 = and i32 %vec.addr.08.i69, 1, !dbg !769
  %tobool1.not.i72 = icmp eq i32 %and.i71, 0, !dbg !769
  br i1 %tobool1.not.i72, label %if.end.i75, label %if.then.i73, !dbg !770

if.then.i73:                                      ; preds = %while.body.i67
  %15 = load i32, ptr %mat.addr.07.i70, align 4, !dbg !771, !tbaa !156
  %xor.i74 = xor i32 %15, %sum.09.i68, !dbg !772
  tail call void @llvm.dbg.value(metadata i32 %xor.i74, metadata !617, metadata !DIExpression()), !dbg !734
  br label %if.end.i75, !dbg !773

if.end.i75:                                       ; preds = %if.then.i73, %while.body.i67
  %sum.1.i76 = phi i32 [ %xor.i74, %if.then.i73 ], [ %sum.09.i68, %while.body.i67 ], !dbg !734
  tail call void @llvm.dbg.value(metadata i32 %sum.1.i76, metadata !617, metadata !DIExpression()), !dbg !734
  %shr.i77 = lshr i32 %vec.addr.08.i69, 1, !dbg !774
  tail call void @llvm.dbg.value(metadata i32 %shr.i77, metadata !616, metadata !DIExpression()), !dbg !734
  %incdec.ptr.i78 = getelementptr inbounds i8, ptr %mat.addr.07.i70, i64 4, !dbg !775
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i78, metadata !611, metadata !DIExpression()), !dbg !734
  %tobool.not.i79 = icmp ult i32 %vec.addr.08.i69, 2, !dbg !736
  br i1 %tobool.not.i79, label %gf2_matrix_times.exit81, label %while.body.i67, !dbg !736, !llvm.loop !776

gf2_matrix_times.exit81:                          ; preds = %if.end.i75, %gf2_matrix_times.exit65.thread
  %sum.0.lcssa.i80 = phi i32 [ 0, %gf2_matrix_times.exit65.thread ], [ %sum.1.i76, %if.end.i75 ], !dbg !734
  %arrayidx19 = getelementptr inbounds [256 x i32], ptr %arrayidx17, i64 0, i64 %indvars.iv, !dbg !778
  store i32 %sum.0.lcssa.i80, ptr %arrayidx19, align 4, !dbg !779, !tbaa !156
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !780
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !569, metadata !DIExpression()), !dbg !719
  %exitcond.not = icmp eq i64 %indvars.iv.next, 256, !dbg !781
  br i1 %exitcond.not, label %for.cond.cleanup, label %for.body, !dbg !720, !llvm.loop !782
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #8

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #9 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #10

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #10

attributes #0 = { nounwind sanitize_thread memory(write, argmem: none, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree norecurse nosync nounwind sanitize_thread memory(readwrite, argmem: none, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { nofree norecurse nosync nounwind sanitize_thread memory(write, argmem: none, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { nofree norecurse nosync nounwind sanitize_thread memory(argmem: write) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #9 = { nounwind uwtable }
attributes #10 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { nounwind memory(none) }
attributes #12 = { nounwind }
attributes #13 = { nounwind memory(read) }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!67, !68, !69, !70, !71, !72, !73}
!llvm.ident = !{!74}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "crc32c", scope: !2, file: !3, line: 47, type: !64, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !17, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "crc32c.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "6996995f1b9022cff7369357711fb1d7")
!4 = !{!5, !8, !14}
!5 = !DIDerivedType(tag: DW_TAG_typedef, name: "uintptr_t", file: !6, line: 79, baseType: !7)
!6 = !DIFile(filename: "/usr/include/stdint.h", directory: "", checksumkind: CSK_MD5, checksum: "bfb03fa9c46a839e35c32b929fbdbb8e")
!7 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!8 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !9, size: 64)
!9 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !10)
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !11, line: 27, baseType: !12)
!11 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!12 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !13, line: 45, baseType: !7)
!13 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!14 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64)
!15 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !16)
!16 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!17 = !{!18, !0, !36, !42, !46, !49, !53, !58, !60, !62}
!18 = !DIGlobalVariableExpression(var: !19, expr: !DIExpression())
!19 = distinct !DIGlobalVariable(name: "little", scope: !20, file: !3, line: 508, type: !34, isLocal: true, isDefinition: true)
!20 = distinct !DISubprogram(name: "crc32c_sw", scope: !3, file: !3, line: 507, type: !21, scopeLine: 507, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !30)
!21 = !DISubroutineType(types: !22)
!22 = !{!23, !23, !26, !28}
!23 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !11, line: 26, baseType: !24)
!24 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !13, line: 42, baseType: !25)
!25 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!26 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !27, size: 64)
!27 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!28 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !29, line: 18, baseType: !7)
!29 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!30 = !{!31, !32, !33}
!31 = !DILocalVariable(name: "crc", arg: 1, scope: !20, file: !3, line: 507, type: !23)
!32 = !DILocalVariable(name: "buf", arg: 2, scope: !20, file: !3, line: 507, type: !26)
!33 = !DILocalVariable(name: "len", arg: 3, scope: !20, file: !3, line: 507, type: !28)
!34 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !35)
!35 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!36 = !DIGlobalVariableExpression(var: !37, expr: !DIExpression())
!37 = distinct !DIGlobalVariable(name: "crc32c_table_little", scope: !2, file: !3, line: 368, type: !38, isLocal: true, isDefinition: true)
!38 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 65536, elements: !39)
!39 = !{!40, !41}
!40 = !DISubrange(count: 8)
!41 = !DISubrange(count: 256)
!42 = !DIGlobalVariableExpression(var: !43, expr: !DIExpression())
!43 = distinct !DIGlobalVariable(name: "crc32c_table_big_byte", scope: !2, file: !3, line: 440, type: !44, isLocal: true, isDefinition: true)
!44 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 8192, elements: !45)
!45 = !{!41}
!46 = !DIGlobalVariableExpression(var: !47, expr: !DIExpression())
!47 = distinct !DIGlobalVariable(name: "crc32c_table_big", scope: !2, file: !3, line: 441, type: !48, isLocal: true, isDefinition: true)
!48 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 131072, elements: !39)
!49 = !DIGlobalVariableExpression(var: !50, expr: !DIExpression())
!50 = distinct !DIGlobalVariable(name: "crc32c_once_hw", scope: !2, file: !3, line: 150, type: !51, isLocal: true, isDefinition: true)
!51 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_once_t", file: !52, line: 53, baseType: !35)
!52 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h", directory: "", checksumkind: CSK_MD5, checksum: "8a5acdbeec491eca11cf81cb1ef77ea7")
!53 = !DIGlobalVariableExpression(var: !54, expr: !DIExpression())
!54 = distinct !DIGlobalVariable(name: "crc32c_long", scope: !2, file: !3, line: 151, type: !55, isLocal: true, isDefinition: true)
!55 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 32768, elements: !56)
!56 = !{!57, !41}
!57 = !DISubrange(count: 4)
!58 = !DIGlobalVariableExpression(var: !59, expr: !DIExpression())
!59 = distinct !DIGlobalVariable(name: "crc32c_short", scope: !2, file: !3, line: 152, type: !55, isLocal: true, isDefinition: true)
!60 = !DIGlobalVariableExpression(var: !61, expr: !DIExpression())
!61 = distinct !DIGlobalVariable(name: "crc32c_once_little", scope: !2, file: !3, line: 367, type: !51, isLocal: true, isDefinition: true)
!62 = !DIGlobalVariableExpression(var: !63, expr: !DIExpression())
!63 = distinct !DIGlobalVariable(name: "crc32c_once_big", scope: !2, file: !3, line: 439, type: !51, isLocal: true, isDefinition: true)
!64 = !DIDerivedType(tag: DW_TAG_typedef, name: "crc_func", file: !65, line: 15, baseType: !66)
!65 = !DIFile(filename: "./crc32c.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "8a48ba9fe4cc0dc3de03e345ef4b0904")
!66 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !21, size: 64)
!67 = !{i32 7, !"Dwarf Version", i32 5}
!68 = !{i32 2, !"Debug Info Version", i32 3}
!69 = !{i32 1, !"wchar_size", i32 4}
!70 = !{i32 8, !"PIC Level", i32 2}
!71 = !{i32 7, !"PIE Level", i32 2}
!72 = !{i32 7, !"uwtable", i32 2}
!73 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!74 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!75 = distinct !DISubprogram(name: "crc32c_init", scope: !3, file: !3, line: 266, type: !76, scopeLine: 266, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !78)
!76 = !DISubroutineType(types: !77)
!77 = !{null}
!78 = !{!79, !80, !82}
!79 = !DILocalVariable(name: "sse42", scope: !75, file: !3, line: 267, type: !35)
!80 = !DILocalVariable(name: "eax", scope: !81, file: !3, line: 269, type: !23)
!81 = distinct !DILexicalBlock(scope: !75, file: !3, line: 269, column: 5)
!82 = !DILocalVariable(name: "ecx", scope: !81, file: !3, line: 269, type: !23)
!83 = !DILocation(line: 0, scope: !81)
!84 = !DILocation(line: 269, column: 5, scope: !81)
!85 = !{i64 2147779296}
!86 = !DILocation(line: 0, scope: !75)
!87 = !DILocation(line: 270, column: 9, scope: !88)
!88 = distinct !DILexicalBlock(scope: !75, file: !3, line: 270, column: 9)
!89 = !DILocation(line: 0, scope: !88)
!90 = !{!91, !91, i64 0}
!91 = !{!"any pointer", !92, i64 0}
!92 = !{!"omnipotent char", !93, i64 0}
!93 = !{!"Simple C/C++ TBAA"}
!94 = !DILocation(line: 275, column: 1, scope: !75)
!95 = distinct !DISubprogram(name: "crc32c_hw", scope: !3, file: !3, line: 161, type: !21, scopeLine: 161, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !96)
!96 = !{!97, !98, !99, !100, !101, !105, !107, !108, !110, !112, !113, !114}
!97 = !DILocalVariable(name: "crc", arg: 1, scope: !95, file: !3, line: 161, type: !23)
!98 = !DILocalVariable(name: "buf", arg: 2, scope: !95, file: !3, line: 161, type: !26)
!99 = !DILocalVariable(name: "len", arg: 3, scope: !95, file: !3, line: 161, type: !28)
!100 = !DILocalVariable(name: "crc0", scope: !95, file: !3, line: 167, type: !10)
!101 = !DILocalVariable(name: "next", scope: !95, file: !3, line: 171, type: !102)
!102 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !103, size: 64)
!103 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !104)
!104 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!105 = !DILocalVariable(name: "crc1", scope: !106, file: !3, line: 185, type: !10)
!106 = distinct !DILexicalBlock(scope: !95, file: !3, line: 184, column: 27)
!107 = !DILocalVariable(name: "crc2", scope: !106, file: !3, line: 186, type: !10)
!108 = !DILocalVariable(name: "end", scope: !106, file: !3, line: 187, type: !109)
!109 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !102)
!110 = !DILocalVariable(name: "crc1", scope: !111, file: !3, line: 205, type: !10)
!111 = distinct !DILexicalBlock(scope: !95, file: !3, line: 204, column: 28)
!112 = !DILocalVariable(name: "crc2", scope: !111, file: !3, line: 206, type: !10)
!113 = !DILocalVariable(name: "end", scope: !111, file: !3, line: 207, type: !109)
!114 = !DILocalVariable(name: "end", scope: !115, file: !3, line: 225, type: !109)
!115 = distinct !DILexicalBlock(scope: !95, file: !3, line: 224, column: 5)
!116 = !DILocation(line: 0, scope: !95)
!117 = !DILocation(line: 163, column: 5, scope: !95)
!118 = !DILocation(line: 166, column: 11, scope: !95)
!119 = !DILocation(line: 167, column: 21, scope: !95)
!120 = !DILocation(line: 172, column: 12, scope: !95)
!121 = !DILocation(line: 172, column: 16, scope: !95)
!122 = !DILocation(line: 184, column: 16, scope: !95)
!123 = !DILocation(line: 184, column: 5, scope: !95)
!124 = !DILocation(line: 173, column: 9, scope: !125)
!125 = distinct !DILexicalBlock(scope: !95, file: !3, line: 172, column: 47)
!126 = !{i64 6456}
!127 = !DILocation(line: 176, column: 13, scope: !125)
!128 = !DILocation(line: 177, column: 12, scope: !125)
!129 = distinct !{!129, !130, !131, !132}
!130 = !DILocation(line: 172, column: 5, scope: !95)
!131 = !DILocation(line: 178, column: 5, scope: !95)
!132 = !{!"llvm.loop.mustprogress"}
!133 = !DILocation(line: 188, column: 9, scope: !106)
!134 = !DILocation(line: 204, column: 16, scope: !95)
!135 = !DILocation(line: 204, column: 5, scope: !95)
!136 = !DILocation(line: 0, scope: !106)
!137 = !DILocation(line: 189, column: 13, scope: !138)
!138 = distinct !DILexicalBlock(scope: !106, file: !3, line: 188, column: 12)
!139 = !{i64 7062, i64 7084, i64 7137}
!140 = !DILocation(line: 194, column: 18, scope: !138)
!141 = !DILocation(line: 195, column: 23, scope: !106)
!142 = !DILocation(line: 195, column: 9, scope: !138)
!143 = distinct !{!143, !133, !144, !132}
!144 = !DILocation(line: 195, column: 28, scope: !106)
!145 = !DILocalVariable(name: "zeros", arg: 1, scope: !146, file: !3, line: 134, type: !149)
!146 = distinct !DISubprogram(name: "crc32c_shift", scope: !3, file: !3, line: 134, type: !147, scopeLine: 134, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !150)
!147 = !DISubroutineType(types: !148)
!148 = !{!23, !149, !23}
!149 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !44, size: 64)
!150 = !{!145, !151}
!151 = !DILocalVariable(name: "crc", arg: 2, scope: !146, file: !3, line: 134, type: !23)
!152 = !DILocation(line: 0, scope: !146, inlinedAt: !153)
!153 = distinct !DILocation(line: 196, column: 16, scope: !106)
!154 = !DILocation(line: 135, column: 25, scope: !146, inlinedAt: !153)
!155 = !DILocation(line: 135, column: 12, scope: !146, inlinedAt: !153)
!156 = !{!157, !157, i64 0}
!157 = !{!"int", !92, i64 0}
!158 = !DILocation(line: 135, column: 49, scope: !146, inlinedAt: !153)
!159 = !DILocation(line: 135, column: 55, scope: !146, inlinedAt: !153)
!160 = !DILocation(line: 135, column: 35, scope: !146, inlinedAt: !153)
!161 = !DILocation(line: 136, column: 26, scope: !146, inlinedAt: !153)
!162 = !DILocation(line: 136, column: 33, scope: !146, inlinedAt: !153)
!163 = !DILocation(line: 136, column: 12, scope: !146, inlinedAt: !153)
!164 = !DILocation(line: 136, column: 56, scope: !146, inlinedAt: !153)
!165 = !DILocation(line: 136, column: 43, scope: !146, inlinedAt: !153)
!166 = !DILocation(line: 197, column: 42, scope: !106)
!167 = !DILocation(line: 135, column: 33, scope: !146, inlinedAt: !153)
!168 = !DILocation(line: 135, column: 63, scope: !146, inlinedAt: !153)
!169 = !DILocation(line: 136, column: 41, scope: !146, inlinedAt: !153)
!170 = !DILocation(line: 0, scope: !146, inlinedAt: !171)
!171 = distinct !DILocation(line: 197, column: 16, scope: !106)
!172 = !DILocation(line: 135, column: 25, scope: !146, inlinedAt: !171)
!173 = !DILocation(line: 135, column: 12, scope: !146, inlinedAt: !171)
!174 = !DILocation(line: 135, column: 49, scope: !146, inlinedAt: !171)
!175 = !DILocation(line: 135, column: 55, scope: !146, inlinedAt: !171)
!176 = !DILocation(line: 135, column: 35, scope: !146, inlinedAt: !171)
!177 = !DILocation(line: 135, column: 33, scope: !146, inlinedAt: !171)
!178 = !DILocation(line: 136, column: 26, scope: !146, inlinedAt: !171)
!179 = !DILocation(line: 136, column: 33, scope: !146, inlinedAt: !171)
!180 = !DILocation(line: 136, column: 12, scope: !146, inlinedAt: !171)
!181 = !DILocation(line: 135, column: 63, scope: !146, inlinedAt: !171)
!182 = !DILocation(line: 136, column: 56, scope: !146, inlinedAt: !171)
!183 = !DILocation(line: 136, column: 43, scope: !146, inlinedAt: !171)
!184 = !DILocation(line: 136, column: 41, scope: !146, inlinedAt: !171)
!185 = !DILocation(line: 197, column: 16, scope: !106)
!186 = !DILocation(line: 197, column: 48, scope: !106)
!187 = !DILocation(line: 198, column: 14, scope: !106)
!188 = !DILocation(line: 199, column: 13, scope: !106)
!189 = distinct !{!189, !123, !190, !132}
!190 = !DILocation(line: 200, column: 5, scope: !95)
!191 = !DILocation(line: 208, column: 9, scope: !111)
!192 = !DILocation(line: 0, scope: !111)
!193 = !DILocation(line: 209, column: 13, scope: !194)
!194 = distinct !DILexicalBlock(scope: !111, file: !3, line: 208, column: 12)
!195 = !{i64 7792, i64 7814, i64 7868}
!196 = !DILocation(line: 214, column: 18, scope: !194)
!197 = !DILocation(line: 215, column: 23, scope: !111)
!198 = !DILocation(line: 215, column: 9, scope: !194)
!199 = distinct !{!199, !191, !200, !132}
!200 = !DILocation(line: 215, column: 28, scope: !111)
!201 = !DILocation(line: 0, scope: !146, inlinedAt: !202)
!202 = distinct !DILocation(line: 216, column: 16, scope: !111)
!203 = !DILocation(line: 135, column: 25, scope: !146, inlinedAt: !202)
!204 = !DILocation(line: 135, column: 12, scope: !146, inlinedAt: !202)
!205 = !DILocation(line: 135, column: 49, scope: !146, inlinedAt: !202)
!206 = !DILocation(line: 135, column: 55, scope: !146, inlinedAt: !202)
!207 = !DILocation(line: 135, column: 35, scope: !146, inlinedAt: !202)
!208 = !DILocation(line: 136, column: 26, scope: !146, inlinedAt: !202)
!209 = !DILocation(line: 136, column: 33, scope: !146, inlinedAt: !202)
!210 = !DILocation(line: 136, column: 12, scope: !146, inlinedAt: !202)
!211 = !DILocation(line: 136, column: 56, scope: !146, inlinedAt: !202)
!212 = !DILocation(line: 136, column: 43, scope: !146, inlinedAt: !202)
!213 = !DILocation(line: 217, column: 43, scope: !111)
!214 = !DILocation(line: 135, column: 33, scope: !146, inlinedAt: !202)
!215 = !DILocation(line: 135, column: 63, scope: !146, inlinedAt: !202)
!216 = !DILocation(line: 136, column: 41, scope: !146, inlinedAt: !202)
!217 = !DILocation(line: 0, scope: !146, inlinedAt: !218)
!218 = distinct !DILocation(line: 217, column: 16, scope: !111)
!219 = !DILocation(line: 135, column: 25, scope: !146, inlinedAt: !218)
!220 = !DILocation(line: 135, column: 12, scope: !146, inlinedAt: !218)
!221 = !DILocation(line: 135, column: 49, scope: !146, inlinedAt: !218)
!222 = !DILocation(line: 135, column: 55, scope: !146, inlinedAt: !218)
!223 = !DILocation(line: 135, column: 35, scope: !146, inlinedAt: !218)
!224 = !DILocation(line: 135, column: 33, scope: !146, inlinedAt: !218)
!225 = !DILocation(line: 136, column: 26, scope: !146, inlinedAt: !218)
!226 = !DILocation(line: 136, column: 33, scope: !146, inlinedAt: !218)
!227 = !DILocation(line: 136, column: 12, scope: !146, inlinedAt: !218)
!228 = !DILocation(line: 135, column: 63, scope: !146, inlinedAt: !218)
!229 = !DILocation(line: 136, column: 56, scope: !146, inlinedAt: !218)
!230 = !DILocation(line: 136, column: 43, scope: !146, inlinedAt: !218)
!231 = !DILocation(line: 136, column: 41, scope: !146, inlinedAt: !218)
!232 = !DILocation(line: 217, column: 16, scope: !111)
!233 = !DILocation(line: 217, column: 49, scope: !111)
!234 = !DILocation(line: 218, column: 14, scope: !111)
!235 = !DILocation(line: 219, column: 13, scope: !111)
!236 = distinct !{!236, !135, !237, !132}
!237 = !DILocation(line: 220, column: 5, scope: !95)
!238 = !DILocation(line: 225, column: 62, scope: !115)
!239 = !DILocation(line: 225, column: 55, scope: !115)
!240 = !DILocation(line: 225, column: 48, scope: !115)
!241 = !DILocation(line: 0, scope: !115)
!242 = !DILocation(line: 226, column: 21, scope: !115)
!243 = !DILocation(line: 226, column: 9, scope: !115)
!244 = !DILocation(line: 236, column: 5, scope: !95)
!245 = !DILocation(line: 227, column: 13, scope: !246)
!246 = distinct !DILexicalBlock(scope: !115, file: !3, line: 226, column: 28)
!247 = !{i64 8462}
!248 = !DILocation(line: 230, column: 18, scope: !246)
!249 = distinct !{!249, !243, !250, !132}
!250 = !DILocation(line: 231, column: 9, scope: !115)
!251 = !DILocation(line: 237, column: 9, scope: !252)
!252 = distinct !DILexicalBlock(scope: !95, file: !3, line: 236, column: 17)
!253 = !{i64 8712}
!254 = !DILocation(line: 240, column: 13, scope: !252)
!255 = !DILocation(line: 241, column: 12, scope: !252)
!256 = distinct !{!256, !244, !257, !132}
!257 = !DILocation(line: 242, column: 5, scope: !95)
!258 = !DILocation(line: 245, column: 12, scope: !95)
!259 = !DILocation(line: 245, column: 5, scope: !95)
!260 = !DILocation(line: 0, scope: !20)
!261 = !DILocation(line: 510, column: 16, scope: !262)
!262 = distinct !DILexicalBlock(scope: !20, file: !3, line: 509, column: 9)
!263 = !DILocation(line: 513, column: 1, scope: !20)
!264 = distinct !DISubprogram(name: "crc32c_sw_little", scope: !3, file: !3, line: 393, type: !21, scopeLine: 393, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !265)
!265 = !{!266, !267, !268, !269, !270}
!266 = !DILocalVariable(name: "crc", arg: 1, scope: !264, file: !3, line: 393, type: !23)
!267 = !DILocalVariable(name: "buf", arg: 2, scope: !264, file: !3, line: 393, type: !26)
!268 = !DILocalVariable(name: "len", arg: 3, scope: !264, file: !3, line: 393, type: !28)
!269 = !DILocalVariable(name: "next", scope: !264, file: !3, line: 394, type: !102)
!270 = !DILocalVariable(name: "crcw", scope: !271, file: !3, line: 403, type: !10)
!271 = distinct !DILexicalBlock(scope: !272, file: !3, line: 402, column: 19)
!272 = distinct !DILexicalBlock(scope: !264, file: !3, line: 402, column: 9)
!273 = !DILocation(line: 0, scope: !264)
!274 = !DILocation(line: 396, column: 5, scope: !264)
!275 = !DILocation(line: 397, column: 11, scope: !264)
!276 = !DILocation(line: 398, column: 12, scope: !264)
!277 = !DILocation(line: 398, column: 16, scope: !264)
!278 = !DILocation(line: 399, column: 50, scope: !279)
!279 = distinct !DILexicalBlock(scope: !264, file: !3, line: 398, column: 47)
!280 = !DILocation(line: 399, column: 45, scope: !279)
!281 = !{!92, !92, i64 0}
!282 = !DILocation(line: 399, column: 54, scope: !279)
!283 = !DILocation(line: 399, column: 15, scope: !279)
!284 = !DILocation(line: 399, column: 69, scope: !279)
!285 = !DILocation(line: 399, column: 62, scope: !279)
!286 = !DILocation(line: 400, column: 12, scope: !279)
!287 = distinct !{!287, !288, !289, !132}
!288 = !DILocation(line: 398, column: 5, scope: !264)
!289 = !DILocation(line: 401, column: 5, scope: !264)
!290 = !DILocation(line: 402, column: 13, scope: !272)
!291 = !DILocation(line: 402, column: 9, scope: !264)
!292 = !DILocation(line: 0, scope: !271)
!293 = !DILocation(line: 405, column: 21, scope: !294)
!294 = distinct !DILexicalBlock(scope: !271, file: !3, line: 404, column: 12)
!295 = !{!296, !296, i64 0}
!296 = !{!"long", !92, i64 0}
!297 = !DILocation(line: 405, column: 18, scope: !294)
!298 = !DILocation(line: 406, column: 48, scope: !294)
!299 = !DILocation(line: 406, column: 20, scope: !294)
!300 = !DILocation(line: 407, column: 49, scope: !294)
!301 = !DILocation(line: 407, column: 55, scope: !294)
!302 = !DILocation(line: 407, column: 20, scope: !294)
!303 = !DILocation(line: 406, column: 56, scope: !294)
!304 = !DILocation(line: 408, column: 49, scope: !294)
!305 = !DILocation(line: 408, column: 56, scope: !294)
!306 = !DILocation(line: 408, column: 20, scope: !294)
!307 = !DILocation(line: 407, column: 63, scope: !294)
!308 = !DILocation(line: 409, column: 49, scope: !294)
!309 = !DILocation(line: 409, column: 56, scope: !294)
!310 = !DILocation(line: 409, column: 20, scope: !294)
!311 = !DILocation(line: 408, column: 64, scope: !294)
!312 = !DILocation(line: 410, column: 49, scope: !294)
!313 = !DILocation(line: 410, column: 56, scope: !294)
!314 = !DILocation(line: 410, column: 20, scope: !294)
!315 = !DILocation(line: 409, column: 64, scope: !294)
!316 = !DILocation(line: 411, column: 49, scope: !294)
!317 = !DILocation(line: 411, column: 56, scope: !294)
!318 = !DILocation(line: 411, column: 20, scope: !294)
!319 = !DILocation(line: 410, column: 64, scope: !294)
!320 = !DILocation(line: 412, column: 49, scope: !294)
!321 = !DILocation(line: 412, column: 56, scope: !294)
!322 = !DILocation(line: 412, column: 20, scope: !294)
!323 = !DILocation(line: 411, column: 64, scope: !294)
!324 = !DILocation(line: 413, column: 48, scope: !294)
!325 = !DILocation(line: 413, column: 20, scope: !294)
!326 = !DILocation(line: 412, column: 64, scope: !294)
!327 = !DILocation(line: 414, column: 18, scope: !294)
!328 = !DILocation(line: 415, column: 17, scope: !294)
!329 = !DILocation(line: 416, column: 22, scope: !271)
!330 = !DILocation(line: 416, column: 9, scope: !294)
!331 = distinct !{!331, !332, !333, !132}
!332 = !DILocation(line: 404, column: 9, scope: !271)
!333 = !DILocation(line: 416, column: 26, scope: !271)
!334 = !DILocation(line: 419, column: 5, scope: !264)
!335 = !DILocation(line: 420, column: 50, scope: !336)
!336 = distinct !DILexicalBlock(scope: !264, file: !3, line: 419, column: 17)
!337 = !DILocation(line: 420, column: 45, scope: !336)
!338 = !DILocation(line: 420, column: 54, scope: !336)
!339 = !DILocation(line: 420, column: 15, scope: !336)
!340 = !DILocation(line: 420, column: 69, scope: !336)
!341 = !DILocation(line: 420, column: 62, scope: !336)
!342 = !DILocation(line: 421, column: 12, scope: !336)
!343 = distinct !{!343, !334, !344, !132}
!344 = !DILocation(line: 422, column: 5, scope: !264)
!345 = !DILocation(line: 423, column: 12, scope: !264)
!346 = !DILocation(line: 423, column: 5, scope: !264)
!347 = !DISubprogram(name: "pthread_once", scope: !348, file: !348, line: 509, type: !349, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!348 = !DIFile(filename: "/usr/include/pthread.h", directory: "", checksumkind: CSK_MD5, checksum: "cbcd748b3d3ecaa7356dc2925b45d819")
!349 = !DISubroutineType(types: !350)
!350 = !{!35, !351, !352}
!351 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !51, size: 64)
!352 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !76, size: 64)
!353 = distinct !DISubprogram(name: "crc32c_init_sw_little", scope: !3, file: !3, line: 369, type: !76, scopeLine: 369, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !354)
!354 = !{!355, !357, !360, !362, !365}
!355 = !DILocalVariable(name: "n", scope: !356, file: !3, line: 370, type: !25)
!356 = distinct !DILexicalBlock(scope: !353, file: !3, line: 370, column: 5)
!357 = !DILocalVariable(name: "crc", scope: !358, file: !3, line: 371, type: !23)
!358 = distinct !DILexicalBlock(scope: !359, file: !3, line: 370, column: 40)
!359 = distinct !DILexicalBlock(scope: !356, file: !3, line: 370, column: 5)
!360 = !DILocalVariable(name: "n", scope: !361, file: !3, line: 382, type: !25)
!361 = distinct !DILexicalBlock(scope: !353, file: !3, line: 382, column: 5)
!362 = !DILocalVariable(name: "crc", scope: !363, file: !3, line: 383, type: !23)
!363 = distinct !DILexicalBlock(scope: !364, file: !3, line: 382, column: 40)
!364 = distinct !DILexicalBlock(scope: !361, file: !3, line: 382, column: 5)
!365 = !DILocalVariable(name: "k", scope: !366, file: !3, line: 384, type: !25)
!366 = distinct !DILexicalBlock(scope: !363, file: !3, line: 384, column: 9)
!367 = !DILocation(line: 0, scope: !356)
!368 = !DILocation(line: 370, column: 5, scope: !356)
!369 = !DILocation(line: 370, column: 36, scope: !359)
!370 = !DILocation(line: 372, column: 19, scope: !358)
!371 = !DILocation(line: 372, column: 15, scope: !358)
!372 = !DILocation(line: 373, column: 19, scope: !358)
!373 = !DILocation(line: 373, column: 15, scope: !358)
!374 = !DILocation(line: 374, column: 19, scope: !358)
!375 = !DILocation(line: 374, column: 15, scope: !358)
!376 = !DILocation(line: 375, column: 19, scope: !358)
!377 = !DILocation(line: 375, column: 15, scope: !358)
!378 = !DILocation(line: 376, column: 19, scope: !358)
!379 = !DILocation(line: 376, column: 15, scope: !358)
!380 = !DILocation(line: 377, column: 19, scope: !358)
!381 = !DILocation(line: 377, column: 15, scope: !358)
!382 = !DILocation(line: 378, column: 19, scope: !358)
!383 = !DILocation(line: 378, column: 15, scope: !358)
!384 = !DILocation(line: 379, column: 19, scope: !358)
!385 = !DILocation(line: 379, column: 15, scope: !358)
!386 = !DILocation(line: 380, column: 9, scope: !358)
!387 = !DILocation(line: 380, column: 35, scope: !358)
!388 = distinct !{!388, !368, !389, !132, !390, !391}
!389 = !DILocation(line: 381, column: 5, scope: !356)
!390 = !{!"llvm.loop.isvectorized", i32 1}
!391 = !{!"llvm.loop.unroll.runtime.disable"}
!392 = !DILocation(line: 389, column: 1, scope: !353)
!393 = !DILocation(line: 0, scope: !361)
!394 = !DILocation(line: 383, column: 24, scope: !363)
!395 = !DILocation(line: 0, scope: !366)
!396 = !DILocation(line: 0, scope: !363)
!397 = !DILocation(line: 385, column: 46, scope: !398)
!398 = distinct !DILexicalBlock(scope: !399, file: !3, line: 384, column: 42)
!399 = distinct !DILexicalBlock(scope: !366, file: !3, line: 384, column: 9)
!400 = !DILocation(line: 385, column: 19, scope: !398)
!401 = !DILocation(line: 385, column: 61, scope: !398)
!402 = !DILocation(line: 385, column: 54, scope: !398)
!403 = !DILocation(line: 386, column: 13, scope: !398)
!404 = !DILocation(line: 386, column: 39, scope: !398)
!405 = !DILocation(line: 382, column: 36, scope: !364)
!406 = !DILocation(line: 382, column: 28, scope: !364)
!407 = !DILocation(line: 382, column: 5, scope: !361)
!408 = distinct !{!408, !407, !409, !132}
!409 = !DILocation(line: 388, column: 5, scope: !361)
!410 = distinct !DISubprogram(name: "crc32c_sw_big", scope: !3, file: !3, line: 467, type: !21, scopeLine: 467, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !411)
!411 = !{!412, !413, !414, !415, !416}
!412 = !DILocalVariable(name: "crc", arg: 1, scope: !410, file: !3, line: 467, type: !23)
!413 = !DILocalVariable(name: "buf", arg: 2, scope: !410, file: !3, line: 467, type: !26)
!414 = !DILocalVariable(name: "len", arg: 3, scope: !410, file: !3, line: 467, type: !28)
!415 = !DILocalVariable(name: "next", scope: !410, file: !3, line: 468, type: !102)
!416 = !DILocalVariable(name: "crcw", scope: !417, file: !3, line: 477, type: !10)
!417 = distinct !DILexicalBlock(scope: !418, file: !3, line: 476, column: 19)
!418 = distinct !DILexicalBlock(scope: !410, file: !3, line: 476, column: 9)
!419 = !DILocation(line: 0, scope: !410)
!420 = !DILocation(line: 470, column: 5, scope: !410)
!421 = !DILocation(line: 471, column: 11, scope: !410)
!422 = !DILocation(line: 472, column: 12, scope: !410)
!423 = !DILocation(line: 472, column: 16, scope: !410)
!424 = !DILocation(line: 473, column: 49, scope: !425)
!425 = distinct !DILexicalBlock(scope: !410, file: !3, line: 472, column: 47)
!426 = !DILocation(line: 473, column: 44, scope: !425)
!427 = !DILocation(line: 473, column: 53, scope: !425)
!428 = !DILocation(line: 473, column: 15, scope: !425)
!429 = !DILocation(line: 473, column: 68, scope: !425)
!430 = !DILocation(line: 473, column: 61, scope: !425)
!431 = !DILocation(line: 474, column: 12, scope: !425)
!432 = distinct !{!432, !433, !434, !132}
!433 = !DILocation(line: 472, column: 5, scope: !410)
!434 = !DILocation(line: 475, column: 5, scope: !410)
!435 = !DILocation(line: 476, column: 13, scope: !418)
!436 = !DILocation(line: 476, column: 9, scope: !410)
!437 = !DILocation(line: 477, column: 30, scope: !417)
!438 = !DILocation(line: 477, column: 25, scope: !417)
!439 = !DILocation(line: 0, scope: !417)
!440 = !DILocation(line: 478, column: 9, scope: !417)
!441 = !DILocation(line: 479, column: 21, scope: !442)
!442 = distinct !DILexicalBlock(scope: !417, file: !3, line: 478, column: 12)
!443 = !DILocation(line: 479, column: 18, scope: !442)
!444 = !DILocation(line: 480, column: 45, scope: !442)
!445 = !DILocation(line: 480, column: 20, scope: !442)
!446 = !DILocation(line: 481, column: 46, scope: !442)
!447 = !DILocation(line: 481, column: 52, scope: !442)
!448 = !DILocation(line: 481, column: 20, scope: !442)
!449 = !DILocation(line: 480, column: 53, scope: !442)
!450 = !DILocation(line: 482, column: 46, scope: !442)
!451 = !DILocation(line: 482, column: 53, scope: !442)
!452 = !DILocation(line: 482, column: 20, scope: !442)
!453 = !DILocation(line: 481, column: 60, scope: !442)
!454 = !DILocation(line: 483, column: 46, scope: !442)
!455 = !DILocation(line: 483, column: 53, scope: !442)
!456 = !DILocation(line: 483, column: 20, scope: !442)
!457 = !DILocation(line: 482, column: 61, scope: !442)
!458 = !DILocation(line: 484, column: 46, scope: !442)
!459 = !DILocation(line: 484, column: 53, scope: !442)
!460 = !DILocation(line: 484, column: 20, scope: !442)
!461 = !DILocation(line: 483, column: 61, scope: !442)
!462 = !DILocation(line: 485, column: 46, scope: !442)
!463 = !DILocation(line: 485, column: 53, scope: !442)
!464 = !DILocation(line: 485, column: 20, scope: !442)
!465 = !DILocation(line: 484, column: 61, scope: !442)
!466 = !DILocation(line: 486, column: 46, scope: !442)
!467 = !DILocation(line: 486, column: 53, scope: !442)
!468 = !DILocation(line: 486, column: 20, scope: !442)
!469 = !DILocation(line: 485, column: 61, scope: !442)
!470 = !DILocation(line: 487, column: 46, scope: !442)
!471 = !DILocation(line: 487, column: 20, scope: !442)
!472 = !DILocation(line: 486, column: 61, scope: !442)
!473 = !DILocation(line: 488, column: 18, scope: !442)
!474 = !DILocation(line: 489, column: 17, scope: !442)
!475 = !DILocation(line: 490, column: 22, scope: !417)
!476 = !DILocation(line: 490, column: 9, scope: !442)
!477 = distinct !{!477, !440, !478, !132}
!478 = !DILocation(line: 490, column: 26, scope: !417)
!479 = !DILocation(line: 491, column: 15, scope: !417)
!480 = !DILocation(line: 492, column: 5, scope: !417)
!481 = !DILocation(line: 493, column: 5, scope: !410)
!482 = !DILocation(line: 494, column: 49, scope: !483)
!483 = distinct !DILexicalBlock(scope: !410, file: !3, line: 493, column: 17)
!484 = !DILocation(line: 494, column: 44, scope: !483)
!485 = !DILocation(line: 494, column: 53, scope: !483)
!486 = !DILocation(line: 494, column: 15, scope: !483)
!487 = !DILocation(line: 494, column: 68, scope: !483)
!488 = !DILocation(line: 494, column: 61, scope: !483)
!489 = !DILocation(line: 495, column: 12, scope: !483)
!490 = distinct !{!490, !481, !491, !132}
!491 = !DILocation(line: 496, column: 5, scope: !410)
!492 = !DILocation(line: 497, column: 12, scope: !410)
!493 = !DILocation(line: 497, column: 5, scope: !410)
!494 = distinct !DISubprogram(name: "crc32c_init_sw_big", scope: !3, file: !3, line: 442, type: !76, scopeLine: 442, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !495)
!495 = !{!496, !498, !501, !503, !506}
!496 = !DILocalVariable(name: "n", scope: !497, file: !3, line: 443, type: !25)
!497 = distinct !DILexicalBlock(scope: !494, file: !3, line: 443, column: 5)
!498 = !DILocalVariable(name: "crc", scope: !499, file: !3, line: 444, type: !23)
!499 = distinct !DILexicalBlock(scope: !500, file: !3, line: 443, column: 40)
!500 = distinct !DILexicalBlock(scope: !497, file: !3, line: 443, column: 5)
!501 = !DILocalVariable(name: "n", scope: !502, file: !3, line: 455, type: !25)
!502 = distinct !DILexicalBlock(scope: !494, file: !3, line: 455, column: 5)
!503 = !DILocalVariable(name: "crc", scope: !504, file: !3, line: 456, type: !23)
!504 = distinct !DILexicalBlock(scope: !505, file: !3, line: 455, column: 40)
!505 = distinct !DILexicalBlock(scope: !502, file: !3, line: 455, column: 5)
!506 = !DILocalVariable(name: "k", scope: !507, file: !3, line: 458, type: !25)
!507 = distinct !DILexicalBlock(scope: !504, file: !3, line: 458, column: 9)
!508 = !DILocation(line: 0, scope: !497)
!509 = !DILocation(line: 443, column: 5, scope: !497)
!510 = !DILocation(line: 443, column: 36, scope: !500)
!511 = !DILocation(line: 445, column: 19, scope: !499)
!512 = !DILocation(line: 445, column: 15, scope: !499)
!513 = !DILocation(line: 446, column: 19, scope: !499)
!514 = !DILocation(line: 446, column: 15, scope: !499)
!515 = !DILocation(line: 447, column: 19, scope: !499)
!516 = !DILocation(line: 447, column: 15, scope: !499)
!517 = !DILocation(line: 448, column: 19, scope: !499)
!518 = !DILocation(line: 448, column: 15, scope: !499)
!519 = !DILocation(line: 449, column: 19, scope: !499)
!520 = !DILocation(line: 449, column: 15, scope: !499)
!521 = !DILocation(line: 450, column: 19, scope: !499)
!522 = !DILocation(line: 450, column: 15, scope: !499)
!523 = !DILocation(line: 451, column: 19, scope: !499)
!524 = !DILocation(line: 451, column: 15, scope: !499)
!525 = !DILocation(line: 452, column: 19, scope: !499)
!526 = !DILocation(line: 452, column: 15, scope: !499)
!527 = !DILocation(line: 453, column: 9, scope: !499)
!528 = !DILocation(line: 453, column: 34, scope: !499)
!529 = distinct !{!529, !509, !530, !132, !390, !391}
!530 = !DILocation(line: 454, column: 5, scope: !497)
!531 = !DILocation(line: 463, column: 1, scope: !494)
!532 = !DILocation(line: 0, scope: !502)
!533 = !DILocation(line: 456, column: 24, scope: !504)
!534 = !DILocation(line: 0, scope: !504)
!535 = !DILocation(line: 457, column: 39, scope: !504)
!536 = !DILocation(line: 457, column: 34, scope: !504)
!537 = !DILocation(line: 457, column: 9, scope: !504)
!538 = !DILocation(line: 457, column: 32, scope: !504)
!539 = !DILocation(line: 0, scope: !507)
!540 = !DILocation(line: 459, column: 45, scope: !541)
!541 = distinct !DILexicalBlock(scope: !542, file: !3, line: 458, column: 42)
!542 = distinct !DILexicalBlock(scope: !507, file: !3, line: 458, column: 9)
!543 = !DILocation(line: 459, column: 19, scope: !541)
!544 = !DILocation(line: 459, column: 60, scope: !541)
!545 = !DILocation(line: 459, column: 53, scope: !541)
!546 = !DILocation(line: 460, column: 43, scope: !541)
!547 = !DILocation(line: 460, column: 38, scope: !541)
!548 = !DILocation(line: 460, column: 13, scope: !541)
!549 = !DILocation(line: 460, column: 36, scope: !541)
!550 = !DILocation(line: 455, column: 36, scope: !505)
!551 = !DILocation(line: 455, column: 28, scope: !505)
!552 = !DILocation(line: 455, column: 5, scope: !502)
!553 = distinct !{!553, !552, !554, !132}
!554 = !DILocation(line: 462, column: 5, scope: !502)
!555 = distinct !DISubprogram(name: "crc32c_init_hw", scope: !3, file: !3, line: 155, type: !76, scopeLine: 155, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!556 = !DILocation(line: 156, column: 5, scope: !555)
!557 = !DILocation(line: 157, column: 5, scope: !555)
!558 = !DILocation(line: 158, column: 1, scope: !555)
!559 = distinct !DISubprogram(name: "crc32c_zeros", scope: !3, file: !3, line: 121, type: !560, scopeLine: 121, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !562)
!560 = !DISubroutineType(types: !561)
!561 = !{null, !149, !28}
!562 = !{!563, !564, !565, !569}
!563 = !DILocalVariable(name: "zeros", arg: 1, scope: !559, file: !3, line: 121, type: !149)
!564 = !DILocalVariable(name: "len", arg: 2, scope: !559, file: !3, line: 121, type: !28)
!565 = !DILocalVariable(name: "op", scope: !559, file: !3, line: 122, type: !566)
!566 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 1024, elements: !567)
!567 = !{!568}
!568 = !DISubrange(count: 32)
!569 = !DILocalVariable(name: "n", scope: !570, file: !3, line: 125, type: !25)
!570 = distinct !DILexicalBlock(scope: !559, file: !3, line: 125, column: 5)
!571 = distinct !DIAssignID()
!572 = distinct !DIAssignID()
!573 = !DILocation(line: 0, scope: !559)
!574 = !DILocation(line: 122, column: 5, scope: !559)
!575 = !DILocalVariable(name: "odd", scope: !576, file: !3, line: 86, type: !566)
!576 = distinct !DISubprogram(name: "crc32c_zeros_op", scope: !3, file: !3, line: 85, type: !577, scopeLine: 85, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !580)
!577 = !DISubroutineType(types: !578)
!578 = !{null, !579, !28}
!579 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !23, size: 64)
!580 = !{!581, !582, !575, !583, !584, !586}
!581 = !DILocalVariable(name: "even", arg: 1, scope: !576, file: !3, line: 85, type: !579)
!582 = !DILocalVariable(name: "len", arg: 2, scope: !576, file: !3, line: 85, type: !28)
!583 = !DILocalVariable(name: "row", scope: !576, file: !3, line: 90, type: !23)
!584 = !DILocalVariable(name: "n", scope: !585, file: !3, line: 91, type: !25)
!585 = distinct !DILexicalBlock(scope: !576, file: !3, line: 91, column: 5)
!586 = !DILocalVariable(name: "n", scope: !587, file: !3, line: 115, type: !25)
!587 = distinct !DILexicalBlock(scope: !576, file: !3, line: 115, column: 5)
!588 = !DILocation(line: 0, scope: !576, inlinedAt: !589)
!589 = distinct !DILocation(line: 124, column: 5, scope: !559)
!590 = !DILocation(line: 86, column: 5, scope: !576, inlinedAt: !589)
!591 = distinct !DIAssignID()
!592 = !DILocation(line: 0, scope: !585, inlinedAt: !589)
!593 = !DILocation(line: 89, column: 12, scope: !576, inlinedAt: !589)
!594 = !DILocation(line: 92, column: 9, scope: !595, inlinedAt: !589)
!595 = distinct !DILexicalBlock(scope: !596, file: !3, line: 91, column: 39)
!596 = distinct !DILexicalBlock(scope: !585, file: !3, line: 91, column: 5)
!597 = !DILocation(line: 92, column: 16, scope: !595, inlinedAt: !589)
!598 = !DILocation(line: 76, column: 5, scope: !599, inlinedAt: !607)
!599 = distinct !DILexicalBlock(scope: !600, file: !3, line: 76, column: 5)
!600 = distinct !DISubprogram(name: "gf2_matrix_square", scope: !3, file: !3, line: 75, type: !601, scopeLine: 75, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !603)
!601 = !DISubroutineType(types: !602)
!602 = !{null, !579, !579}
!603 = !{!604, !605, !606}
!604 = !DILocalVariable(name: "square", arg: 1, scope: !600, file: !3, line: 75, type: !579)
!605 = !DILocalVariable(name: "mat", arg: 2, scope: !600, file: !3, line: 75, type: !579)
!606 = !DILocalVariable(name: "n", scope: !599, file: !3, line: 76, type: !25)
!607 = distinct !DILocation(line: 97, column: 5, scope: !576, inlinedAt: !589)
!608 = !DILocation(line: 0, scope: !599, inlinedAt: !607)
!609 = !DILocation(line: 77, column: 43, scope: !610, inlinedAt: !607)
!610 = distinct !DILexicalBlock(scope: !599, file: !3, line: 76, column: 5)
!611 = !DILocalVariable(name: "mat", arg: 1, scope: !612, file: !3, line: 62, type: !579)
!612 = distinct !DISubprogram(name: "gf2_matrix_times", scope: !3, file: !3, line: 62, type: !613, scopeLine: 62, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !615)
!613 = !DISubroutineType(types: !614)
!614 = !{!23, !579, !23}
!615 = !{!611, !616, !617}
!616 = !DILocalVariable(name: "vec", arg: 2, scope: !612, file: !3, line: 62, type: !23)
!617 = !DILocalVariable(name: "sum", scope: !612, file: !3, line: 63, type: !23)
!618 = !DILocation(line: 0, scope: !612, inlinedAt: !619)
!619 = distinct !DILocation(line: 77, column: 21, scope: !610, inlinedAt: !607)
!620 = !DILocation(line: 64, column: 5, scope: !612, inlinedAt: !619)
!621 = !DILocation(line: 65, column: 17, scope: !622, inlinedAt: !619)
!622 = distinct !DILexicalBlock(scope: !623, file: !3, line: 65, column: 13)
!623 = distinct !DILexicalBlock(scope: !612, file: !3, line: 64, column: 17)
!624 = !DILocation(line: 65, column: 13, scope: !623, inlinedAt: !619)
!625 = !DILocation(line: 66, column: 20, scope: !622, inlinedAt: !619)
!626 = !DILocation(line: 66, column: 17, scope: !622, inlinedAt: !619)
!627 = !DILocation(line: 66, column: 13, scope: !622, inlinedAt: !619)
!628 = !DILocation(line: 67, column: 13, scope: !623, inlinedAt: !619)
!629 = !DILocation(line: 68, column: 12, scope: !623, inlinedAt: !619)
!630 = distinct !{!630, !620, !631, !132}
!631 = !DILocation(line: 69, column: 5, scope: !612, inlinedAt: !619)
!632 = !DILocation(line: 77, column: 9, scope: !610, inlinedAt: !607)
!633 = !DILocation(line: 77, column: 19, scope: !610, inlinedAt: !607)
!634 = !DILocation(line: 76, column: 35, scope: !610, inlinedAt: !607)
!635 = !DILocation(line: 76, column: 28, scope: !610, inlinedAt: !607)
!636 = distinct !{!636, !598, !637, !132}
!637 = !DILocation(line: 77, column: 49, scope: !599, inlinedAt: !607)
!638 = !DILocation(line: 0, scope: !599, inlinedAt: !639)
!639 = distinct !DILocation(line: 100, column: 5, scope: !576, inlinedAt: !589)
!640 = !DILocation(line: 77, column: 43, scope: !610, inlinedAt: !639)
!641 = !DILocation(line: 0, scope: !612, inlinedAt: !642)
!642 = distinct !DILocation(line: 77, column: 21, scope: !610, inlinedAt: !639)
!643 = !DILocation(line: 64, column: 5, scope: !612, inlinedAt: !642)
!644 = !DILocation(line: 65, column: 17, scope: !622, inlinedAt: !642)
!645 = !DILocation(line: 65, column: 13, scope: !623, inlinedAt: !642)
!646 = !DILocation(line: 66, column: 20, scope: !622, inlinedAt: !642)
!647 = !DILocation(line: 66, column: 17, scope: !622, inlinedAt: !642)
!648 = !DILocation(line: 66, column: 13, scope: !622, inlinedAt: !642)
!649 = !DILocation(line: 67, column: 13, scope: !623, inlinedAt: !642)
!650 = !DILocation(line: 68, column: 12, scope: !623, inlinedAt: !642)
!651 = distinct !{!651, !643, !652, !132}
!652 = !DILocation(line: 69, column: 5, scope: !612, inlinedAt: !642)
!653 = !DILocation(line: 77, column: 9, scope: !610, inlinedAt: !639)
!654 = !DILocation(line: 77, column: 19, scope: !610, inlinedAt: !639)
!655 = !DILocation(line: 76, column: 35, scope: !610, inlinedAt: !639)
!656 = !DILocation(line: 76, column: 28, scope: !610, inlinedAt: !639)
!657 = !DILocation(line: 76, column: 5, scope: !599, inlinedAt: !639)
!658 = distinct !{!658, !657, !659, !132}
!659 = !DILocation(line: 77, column: 49, scope: !599, inlinedAt: !639)
!660 = !DILocation(line: 0, scope: !600, inlinedAt: !661)
!661 = distinct !DILocation(line: 106, column: 9, scope: !662, inlinedAt: !589)
!662 = distinct !DILexicalBlock(scope: !576, file: !3, line: 105, column: 8)
!663 = !DILocation(line: 0, scope: !599, inlinedAt: !661)
!664 = !DILocation(line: 76, column: 5, scope: !599, inlinedAt: !661)
!665 = !DILocation(line: 77, column: 43, scope: !610, inlinedAt: !661)
!666 = !DILocation(line: 0, scope: !612, inlinedAt: !667)
!667 = distinct !DILocation(line: 77, column: 21, scope: !610, inlinedAt: !661)
!668 = !DILocation(line: 64, column: 5, scope: !612, inlinedAt: !667)
!669 = !DILocation(line: 65, column: 17, scope: !622, inlinedAt: !667)
!670 = !DILocation(line: 65, column: 13, scope: !623, inlinedAt: !667)
!671 = !DILocation(line: 66, column: 20, scope: !622, inlinedAt: !667)
!672 = !DILocation(line: 66, column: 17, scope: !622, inlinedAt: !667)
!673 = !DILocation(line: 66, column: 13, scope: !622, inlinedAt: !667)
!674 = !DILocation(line: 67, column: 13, scope: !623, inlinedAt: !667)
!675 = !DILocation(line: 68, column: 12, scope: !623, inlinedAt: !667)
!676 = distinct !{!676, !668, !677, !132}
!677 = !DILocation(line: 69, column: 5, scope: !612, inlinedAt: !667)
!678 = !DILocation(line: 77, column: 9, scope: !610, inlinedAt: !661)
!679 = !DILocation(line: 77, column: 19, scope: !610, inlinedAt: !661)
!680 = !DILocation(line: 76, column: 35, scope: !610, inlinedAt: !661)
!681 = !DILocation(line: 76, column: 28, scope: !610, inlinedAt: !661)
!682 = distinct !{!682, !664, !683, !132}
!683 = !DILocation(line: 77, column: 49, scope: !599, inlinedAt: !661)
!684 = !DILocation(line: 108, column: 17, scope: !685, inlinedAt: !589)
!685 = distinct !DILexicalBlock(scope: !662, file: !3, line: 108, column: 13)
!686 = !DILocation(line: 108, column: 13, scope: !662, inlinedAt: !589)
!687 = !DILocation(line: 0, scope: !599, inlinedAt: !688)
!688 = distinct !DILocation(line: 110, column: 9, scope: !662, inlinedAt: !589)
!689 = !DILocation(line: 77, column: 43, scope: !610, inlinedAt: !688)
!690 = !DILocation(line: 0, scope: !612, inlinedAt: !691)
!691 = distinct !DILocation(line: 77, column: 21, scope: !610, inlinedAt: !688)
!692 = !DILocation(line: 64, column: 5, scope: !612, inlinedAt: !691)
!693 = !DILocation(line: 65, column: 17, scope: !622, inlinedAt: !691)
!694 = !DILocation(line: 65, column: 13, scope: !623, inlinedAt: !691)
!695 = !DILocation(line: 66, column: 20, scope: !622, inlinedAt: !691)
!696 = !DILocation(line: 66, column: 17, scope: !622, inlinedAt: !691)
!697 = !DILocation(line: 66, column: 13, scope: !622, inlinedAt: !691)
!698 = !DILocation(line: 67, column: 13, scope: !623, inlinedAt: !691)
!699 = !DILocation(line: 68, column: 12, scope: !623, inlinedAt: !691)
!700 = distinct !{!700, !692, !701, !132}
!701 = !DILocation(line: 69, column: 5, scope: !612, inlinedAt: !691)
!702 = !DILocation(line: 77, column: 9, scope: !610, inlinedAt: !688)
!703 = !DILocation(line: 77, column: 19, scope: !610, inlinedAt: !688)
!704 = !DILocation(line: 76, column: 35, scope: !610, inlinedAt: !688)
!705 = !DILocation(line: 76, column: 28, scope: !610, inlinedAt: !688)
!706 = !DILocation(line: 76, column: 5, scope: !599, inlinedAt: !688)
!707 = distinct !{!707, !706, !708, !132}
!708 = !DILocation(line: 77, column: 49, scope: !599, inlinedAt: !688)
!709 = !DILocation(line: 107, column: 13, scope: !662, inlinedAt: !589)
!710 = !DILocation(line: 112, column: 5, scope: !662, inlinedAt: !589)
!711 = distinct !{!711, !712, !713, !132}
!712 = !DILocation(line: 105, column: 5, scope: !576, inlinedAt: !589)
!713 = !DILocation(line: 112, column: 17, scope: !576, inlinedAt: !589)
!714 = !DILocation(line: 116, column: 17, scope: !715, inlinedAt: !589)
!715 = distinct !DILexicalBlock(scope: !587, file: !3, line: 115, column: 5)
!716 = distinct !DIAssignID()
!717 = !DILocation(line: 0, scope: !587, inlinedAt: !589)
!718 = !DILocation(line: 117, column: 1, scope: !576, inlinedAt: !589)
!719 = !DILocation(line: 0, scope: !570)
!720 = !DILocation(line: 125, column: 5, scope: !570)
!721 = !DILocation(line: 131, column: 1, scope: !559)
!722 = !DILocation(line: 0, scope: !612, inlinedAt: !723)
!723 = distinct !DILocation(line: 126, column: 23, scope: !724)
!724 = distinct !DILexicalBlock(scope: !725, file: !3, line: 125, column: 40)
!725 = distinct !DILexicalBlock(scope: !570, file: !3, line: 125, column: 5)
!726 = !DILocation(line: 64, column: 5, scope: !612, inlinedAt: !723)
!727 = !DILocation(line: 126, column: 21, scope: !724)
!728 = !DILocation(line: 0, scope: !612, inlinedAt: !729)
!729 = distinct !DILocation(line: 127, column: 23, scope: !724)
!730 = !DILocation(line: 127, column: 21, scope: !724)
!731 = !DILocation(line: 0, scope: !612, inlinedAt: !732)
!732 = distinct !DILocation(line: 128, column: 23, scope: !724)
!733 = !DILocation(line: 128, column: 21, scope: !724)
!734 = !DILocation(line: 0, scope: !612, inlinedAt: !735)
!735 = distinct !DILocation(line: 129, column: 23, scope: !724)
!736 = !DILocation(line: 64, column: 5, scope: !612, inlinedAt: !735)
!737 = !DILocation(line: 65, column: 17, scope: !622, inlinedAt: !723)
!738 = !DILocation(line: 65, column: 13, scope: !623, inlinedAt: !723)
!739 = !DILocation(line: 66, column: 20, scope: !622, inlinedAt: !723)
!740 = !DILocation(line: 66, column: 17, scope: !622, inlinedAt: !723)
!741 = !DILocation(line: 66, column: 13, scope: !622, inlinedAt: !723)
!742 = !DILocation(line: 67, column: 13, scope: !623, inlinedAt: !723)
!743 = !DILocation(line: 68, column: 12, scope: !623, inlinedAt: !723)
!744 = distinct !{!744, !726, !745, !132}
!745 = !DILocation(line: 69, column: 5, scope: !612, inlinedAt: !723)
!746 = !DILocation(line: 126, column: 9, scope: !724)
!747 = !DILocation(line: 64, column: 5, scope: !612, inlinedAt: !729)
!748 = !DILocation(line: 65, column: 17, scope: !622, inlinedAt: !729)
!749 = !DILocation(line: 65, column: 13, scope: !623, inlinedAt: !729)
!750 = !DILocation(line: 66, column: 20, scope: !622, inlinedAt: !729)
!751 = !DILocation(line: 66, column: 17, scope: !622, inlinedAt: !729)
!752 = !DILocation(line: 66, column: 13, scope: !622, inlinedAt: !729)
!753 = !DILocation(line: 67, column: 13, scope: !623, inlinedAt: !729)
!754 = !DILocation(line: 68, column: 12, scope: !623, inlinedAt: !729)
!755 = distinct !{!755, !747, !756, !132}
!756 = !DILocation(line: 69, column: 5, scope: !612, inlinedAt: !729)
!757 = !DILocation(line: 127, column: 9, scope: !724)
!758 = !DILocation(line: 64, column: 5, scope: !612, inlinedAt: !732)
!759 = !DILocation(line: 65, column: 17, scope: !622, inlinedAt: !732)
!760 = !DILocation(line: 65, column: 13, scope: !623, inlinedAt: !732)
!761 = !DILocation(line: 66, column: 20, scope: !622, inlinedAt: !732)
!762 = !DILocation(line: 66, column: 17, scope: !622, inlinedAt: !732)
!763 = !DILocation(line: 66, column: 13, scope: !622, inlinedAt: !732)
!764 = !DILocation(line: 67, column: 13, scope: !623, inlinedAt: !732)
!765 = !DILocation(line: 68, column: 12, scope: !623, inlinedAt: !732)
!766 = distinct !{!766, !758, !767, !132}
!767 = !DILocation(line: 69, column: 5, scope: !612, inlinedAt: !732)
!768 = !DILocation(line: 128, column: 9, scope: !724)
!769 = !DILocation(line: 65, column: 17, scope: !622, inlinedAt: !735)
!770 = !DILocation(line: 65, column: 13, scope: !623, inlinedAt: !735)
!771 = !DILocation(line: 66, column: 20, scope: !622, inlinedAt: !735)
!772 = !DILocation(line: 66, column: 17, scope: !622, inlinedAt: !735)
!773 = !DILocation(line: 66, column: 13, scope: !622, inlinedAt: !735)
!774 = !DILocation(line: 67, column: 13, scope: !623, inlinedAt: !735)
!775 = !DILocation(line: 68, column: 12, scope: !623, inlinedAt: !735)
!776 = distinct !{!776, !736, !777, !132}
!777 = !DILocation(line: 69, column: 5, scope: !612, inlinedAt: !735)
!778 = !DILocation(line: 129, column: 9, scope: !724)
!779 = !DILocation(line: 129, column: 21, scope: !724)
!780 = !DILocation(line: 125, column: 36, scope: !725)
!781 = !DILocation(line: 125, column: 28, scope: !725)
!782 = distinct !{!782, !720, !783, !132}
!783 = !DILocation(line: 130, column: 5, scope: !570)
