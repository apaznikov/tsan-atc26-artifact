; ModuleID = 'cache.c'
source_filename = "cache.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef ptr @cache_create(ptr nocapture noundef readonly %name, i64 noundef %bufsize, i64 noundef %align) local_unnamed_addr #0 !dbg !20 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %name, metadata !80, metadata !DIExpression()), !dbg !85
  tail call void @llvm.dbg.value(metadata i64 %bufsize, metadata !81, metadata !DIExpression()), !dbg !85
  tail call void @llvm.dbg.value(metadata i64 %align, metadata !82, metadata !DIExpression()), !dbg !85
  %call = tail call noalias dereferenceable_or_null(88) ptr @calloc(i64 noundef 1, i64 noundef 88) #10, !dbg !86
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !83, metadata !DIExpression()), !dbg !85
  %call1 = tail call noalias ptr @strdup(ptr noundef %name) #11, !dbg !87
  tail call void @llvm.dbg.value(metadata ptr %call1, metadata !84, metadata !DIExpression()), !dbg !85
  %cmp = icmp eq ptr %call, null, !dbg !88
  %cmp2 = icmp eq ptr %call1, null
  %or.cond = select i1 %cmp, i1 true, i1 %cmp2, !dbg !90
  br i1 %or.cond, label %if.then, label %lor.lhs.false3, !dbg !90

lor.lhs.false3:                                   ; preds = %entry
  %call4 = tail call i32 @pthread_mutex_init(ptr noundef nonnull %call, ptr noundef null) #11, !dbg !91
  %cmp5 = icmp eq i32 %call4, -1, !dbg !92
  br i1 %cmp5, label %if.then, label %if.end, !dbg !93

if.then:                                          ; preds = %lor.lhs.false3, %entry
  tail call void @free(ptr noundef %call) #11, !dbg !94
  tail call void @free(ptr noundef %call1) #11, !dbg !96
  br label %cleanup, !dbg !97

if.end:                                           ; preds = %lor.lhs.false3
  %name6 = getelementptr inbounds i8, ptr %call, i64 40, !dbg !98
  store ptr %call1, ptr %name6, align 8, !dbg !99, !tbaa !100
  %head = getelementptr inbounds i8, ptr %call, i64 48, !dbg !108
  store ptr null, ptr %head, align 8, !dbg !108, !tbaa !110
  %stqh_last = getelementptr inbounds i8, ptr %call, i64 56, !dbg !108
  store ptr %head, ptr %stqh_last, align 8, !dbg !108, !tbaa !111
  %bufsize10 = getelementptr inbounds i8, ptr %call, i64 64, !dbg !112
  store i64 %bufsize, ptr %bufsize10, align 8, !dbg !113, !tbaa !114
  br label %cleanup, !dbg !115

cleanup:                                          ; preds = %if.end, %if.then
  %retval.0 = phi ptr [ null, %if.then ], [ %call, %if.end ], !dbg !85
  ret ptr %retval.0, !dbg !116
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite)
declare !dbg !117 noalias noundef ptr @calloc(i64 noundef, i64 noundef) local_unnamed_addr #1

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !121 noalias ptr @strdup(ptr nocapture noundef readonly) local_unnamed_addr #2

; Function Attrs: nounwind
declare !dbg !125 i32 @pthread_mutex_init(ptr noundef, ptr noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !140 void @free(ptr allocptr nocapture noundef) local_unnamed_addr #4

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @cache_set_limit(ptr noundef %cache, i32 noundef %limit) local_unnamed_addr #0 !dbg !143 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %cache, metadata !147, metadata !DIExpression()), !dbg !149
  tail call void @llvm.dbg.value(metadata i32 %limit, metadata !148, metadata !DIExpression()), !dbg !149
  %call = tail call i32 @pthread_mutex_lock(ptr noundef %cache) #11, !dbg !150
  %limit1 = getelementptr inbounds i8, ptr %cache, i64 84, !dbg !151
  store i32 %limit, ptr %limit1, align 4, !dbg !152, !tbaa !153
  %call3 = tail call i32 @pthread_mutex_unlock(ptr noundef %cache) #11, !dbg !154
  ret void, !dbg !155
}

; Function Attrs: nounwind
declare !dbg !156 i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #3

; Function Attrs: nounwind
declare !dbg !159 i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @cache_destroy(ptr noundef %cache) local_unnamed_addr #0 !dbg !160 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %cache, metadata !164, metadata !DIExpression()), !dbg !167
  %head = getelementptr inbounds i8, ptr %cache, i64 48
  %0 = load ptr, ptr %head, align 8, !dbg !168, !tbaa !110
  %cmp.not19 = icmp eq ptr %0, null, !dbg !168
  br i1 %cmp.not19, label %while.end, label %while.body.lr.ph, !dbg !169

while.body.lr.ph:                                 ; preds = %entry
  %stqh_last = getelementptr inbounds i8, ptr %cache, i64 56
  br label %while.body, !dbg !169

while.body:                                       ; preds = %while.body.lr.ph, %do.end
  %1 = phi ptr [ %0, %while.body.lr.ph ], [ %3, %do.end ]
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !165, metadata !DIExpression()), !dbg !170
  %2 = load ptr, ptr %1, align 8, !dbg !171, !tbaa !174
  store ptr %2, ptr %head, align 8, !dbg !171, !tbaa !110
  %cmp7 = icmp eq ptr %2, null, !dbg !171
  br i1 %cmp7, label %if.then, label %do.end, !dbg !177

if.then:                                          ; preds = %while.body
  store ptr %head, ptr %stqh_last, align 8, !dbg !171, !tbaa !111
  br label %do.end, !dbg !171

do.end:                                           ; preds = %if.then, %while.body
  tail call void @free(ptr noundef nonnull %1) #11, !dbg !178
  %3 = load ptr, ptr %head, align 8, !dbg !168, !tbaa !110
  %cmp.not = icmp eq ptr %3, null, !dbg !168
  br i1 %cmp.not, label %while.end, label %while.body, !dbg !169, !llvm.loop !179

while.end:                                        ; preds = %do.end, %entry
  %name = getelementptr inbounds i8, ptr %cache, i64 40, !dbg !182
  %4 = load ptr, ptr %name, align 8, !dbg !182, !tbaa !100
  tail call void @free(ptr noundef %4) #11, !dbg !183
  %call = tail call i32 @pthread_mutex_destroy(ptr noundef nonnull %cache) #11, !dbg !184
  tail call void @free(ptr noundef nonnull %cache) #11, !dbg !185
  ret void, !dbg !186
}

; Function Attrs: nounwind
declare !dbg !187 i32 @pthread_mutex_destroy(ptr noundef) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef ptr @cache_alloc(ptr noundef %cache) local_unnamed_addr #0 !dbg !188 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %cache, metadata !192, metadata !DIExpression()), !dbg !194
  %call = tail call i32 @pthread_mutex_lock(ptr noundef %cache) #11, !dbg !195
  tail call void @llvm.dbg.value(metadata ptr %cache, metadata !196, metadata !DIExpression()), !dbg !201
  %freecurr.i = getelementptr inbounds i8, ptr %cache, i64 80, !dbg !203
  %0 = load i32, ptr %freecurr.i, align 8, !dbg !203, !tbaa !205
  %cmp.i = icmp sgt i32 %0, 0, !dbg !206
  br i1 %cmp.i, label %if.then.i, label %if.else.i, !dbg !207

if.then.i:                                        ; preds = %entry
  %head.i = getelementptr inbounds i8, ptr %cache, i64 48, !dbg !208
  %1 = load ptr, ptr %head.i, align 8, !dbg !208, !tbaa !110
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !199, metadata !DIExpression()), !dbg !201
  %2 = load ptr, ptr %1, align 8, !dbg !210, !tbaa !174
  store ptr %2, ptr %head.i, align 8, !dbg !210, !tbaa !110
  %cmp5.i = icmp eq ptr %2, null, !dbg !210
  br i1 %cmp5.i, label %if.then6.i, label %do.end.i, !dbg !213

if.then6.i:                                       ; preds = %if.then.i
  %stqh_last.i = getelementptr inbounds i8, ptr %cache, i64 56, !dbg !210
  store ptr %head.i, ptr %stqh_last.i, align 8, !dbg !210, !tbaa !111
  br label %do.end.i, !dbg !210

do.end.i:                                         ; preds = %if.then6.i, %if.then.i
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !200, metadata !DIExpression()), !dbg !201
  %dec.i = add nsw i32 %0, -1, !dbg !214
  store i32 %dec.i, ptr %freecurr.i, align 8, !dbg !214, !tbaa !205
  br label %do_cache_alloc.exit, !dbg !215

if.else.i:                                        ; preds = %entry
  %limit.i = getelementptr inbounds i8, ptr %cache, i64 84, !dbg !216
  %3 = load i32, ptr %limit.i, align 4, !dbg !216, !tbaa !153
  %cmp11.i = icmp eq i32 %3, 0, !dbg !218
  br i1 %cmp11.i, label %if.then14.i, label %lor.lhs.false.i, !dbg !219

lor.lhs.false.i:                                  ; preds = %if.else.i
  %total.i = getelementptr inbounds i8, ptr %cache, i64 76, !dbg !220
  %4 = load i32, ptr %total.i, align 4, !dbg !220, !tbaa !221
  %cmp13.i = icmp slt i32 %4, %3, !dbg !222
  br i1 %cmp13.i, label %if.then14.i, label %do_cache_alloc.exit, !dbg !223

if.then14.i:                                      ; preds = %lor.lhs.false.i, %if.else.i
  %bufsize.i = getelementptr inbounds i8, ptr %cache, i64 64, !dbg !224
  %5 = load i64, ptr %bufsize.i, align 8, !dbg !224, !tbaa !114
  %call15.i = tail call noalias ptr @malloc(i64 noundef %5) #12, !dbg !226
  tail call void @llvm.dbg.value(metadata ptr %call15.i, metadata !199, metadata !DIExpression()), !dbg !201
  tail call void @llvm.dbg.value(metadata ptr %call15.i, metadata !200, metadata !DIExpression()), !dbg !201
  %cmp16.not.i = icmp eq ptr %call15.i, null, !dbg !227
  br i1 %cmp16.not.i, label %do_cache_alloc.exit, label %if.then17.i, !dbg !229

if.then17.i:                                      ; preds = %if.then14.i
  tail call void @llvm.dbg.value(metadata ptr %call15.i, metadata !200, metadata !DIExpression()), !dbg !201
  %total19.i = getelementptr inbounds i8, ptr %cache, i64 76, !dbg !230
  %6 = load i32, ptr %total19.i, align 4, !dbg !232, !tbaa !221
  %inc.i = add nsw i32 %6, 1, !dbg !232
  store i32 %inc.i, ptr %total19.i, align 4, !dbg !232, !tbaa !221
  br label %do_cache_alloc.exit, !dbg !233

do_cache_alloc.exit:                              ; preds = %do.end.i, %lor.lhs.false.i, %if.then14.i, %if.then17.i
  %object.0.i = phi ptr [ %1, %do.end.i ], [ %call15.i, %if.then17.i ], [ null, %if.then14.i ], [ null, %lor.lhs.false.i ], !dbg !234
  tail call void @llvm.dbg.value(metadata ptr %object.0.i, metadata !200, metadata !DIExpression()), !dbg !201
  tail call void @llvm.dbg.value(metadata ptr %object.0.i, metadata !193, metadata !DIExpression()), !dbg !194
  %call3 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %cache) #11, !dbg !235
  ret ptr %object.0.i, !dbg !236
}

; Function Attrs: mustprogress nofree nounwind sanitize_thread willreturn memory(read, argmem: readwrite, inaccessiblemem: readwrite) uwtable
define dso_local noundef ptr @do_cache_alloc(ptr noundef %cache) local_unnamed_addr #5 !dbg !197 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %cache, metadata !196, metadata !DIExpression()), !dbg !237
  %freecurr = getelementptr inbounds i8, ptr %cache, i64 80, !dbg !238
  %0 = load i32, ptr %freecurr, align 8, !dbg !238, !tbaa !205
  %cmp = icmp sgt i32 %0, 0, !dbg !239
  br i1 %cmp, label %if.then, label %if.else, !dbg !240

if.then:                                          ; preds = %entry
  %head = getelementptr inbounds i8, ptr %cache, i64 48, !dbg !241
  %1 = load ptr, ptr %head, align 8, !dbg !241, !tbaa !110
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !199, metadata !DIExpression()), !dbg !237
  %2 = load ptr, ptr %1, align 8, !dbg !242, !tbaa !174
  store ptr %2, ptr %head, align 8, !dbg !242, !tbaa !110
  %cmp5 = icmp eq ptr %2, null, !dbg !242
  br i1 %cmp5, label %if.then6, label %do.end, !dbg !243

if.then6:                                         ; preds = %if.then
  %stqh_last = getelementptr inbounds i8, ptr %cache, i64 56, !dbg !242
  store ptr %head, ptr %stqh_last, align 8, !dbg !242, !tbaa !111
  br label %do.end, !dbg !242

do.end:                                           ; preds = %if.then6, %if.then
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !200, metadata !DIExpression()), !dbg !237
  %dec = add nsw i32 %0, -1, !dbg !244
  store i32 %dec, ptr %freecurr, align 8, !dbg !244, !tbaa !205
  br label %if.end23, !dbg !245

if.else:                                          ; preds = %entry
  %limit = getelementptr inbounds i8, ptr %cache, i64 84, !dbg !246
  %3 = load i32, ptr %limit, align 4, !dbg !246, !tbaa !153
  %cmp11 = icmp eq i32 %3, 0, !dbg !247
  br i1 %cmp11, label %if.then14, label %lor.lhs.false, !dbg !248

lor.lhs.false:                                    ; preds = %if.else
  %total = getelementptr inbounds i8, ptr %cache, i64 76, !dbg !249
  %4 = load i32, ptr %total, align 4, !dbg !249, !tbaa !221
  %cmp13 = icmp slt i32 %4, %3, !dbg !250
  br i1 %cmp13, label %if.then14, label %if.end23, !dbg !251

if.then14:                                        ; preds = %lor.lhs.false, %if.else
  %bufsize = getelementptr inbounds i8, ptr %cache, i64 64, !dbg !252
  %5 = load i64, ptr %bufsize, align 8, !dbg !252, !tbaa !114
  %call15 = tail call noalias ptr @malloc(i64 noundef %5) #12, !dbg !253
  tail call void @llvm.dbg.value(metadata ptr %call15, metadata !199, metadata !DIExpression()), !dbg !237
  tail call void @llvm.dbg.value(metadata ptr %call15, metadata !200, metadata !DIExpression()), !dbg !237
  %cmp16.not = icmp eq ptr %call15, null, !dbg !254
  br i1 %cmp16.not, label %if.end23, label %if.then17, !dbg !255

if.then17:                                        ; preds = %if.then14
  tail call void @llvm.dbg.value(metadata ptr %call15, metadata !200, metadata !DIExpression()), !dbg !237
  %total19 = getelementptr inbounds i8, ptr %cache, i64 76, !dbg !256
  %6 = load i32, ptr %total19, align 4, !dbg !257, !tbaa !221
  %inc = add nsw i32 %6, 1, !dbg !257
  store i32 %inc, ptr %total19, align 4, !dbg !257, !tbaa !221
  br label %if.end23, !dbg !258

if.end23:                                         ; preds = %lor.lhs.false, %if.then17, %if.then14, %do.end
  %object.0 = phi ptr [ %1, %do.end ], [ %call15, %if.then17 ], [ null, %if.then14 ], [ null, %lor.lhs.false ], !dbg !259
  tail call void @llvm.dbg.value(metadata ptr %object.0, metadata !200, metadata !DIExpression()), !dbg !237
  ret ptr %object.0, !dbg !260
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare !dbg !261 noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #6

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @cache_free(ptr noundef %cache, ptr noundef %ptr) local_unnamed_addr #0 !dbg !264 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %cache, metadata !268, metadata !DIExpression()), !dbg !270
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !269, metadata !DIExpression()), !dbg !270
  %call = tail call i32 @pthread_mutex_lock(ptr noundef %cache) #11, !dbg !271
  tail call void @llvm.dbg.value(metadata ptr %cache, metadata !272, metadata !DIExpression()), !dbg !276
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !275, metadata !DIExpression()), !dbg !276
  %limit.i = getelementptr inbounds i8, ptr %cache, i64 84, !dbg !278
  %0 = load i32, ptr %limit.i, align 4, !dbg !278, !tbaa !153
  %cmp.not.i = icmp eq i32 %0, 0, !dbg !280
  br i1 %cmp.not.i, label %do.body.i, label %land.lhs.true.i, !dbg !281

land.lhs.true.i:                                  ; preds = %entry
  %total.i = getelementptr inbounds i8, ptr %cache, i64 76, !dbg !282
  %1 = load i32, ptr %total.i, align 4, !dbg !282, !tbaa !221
  %cmp2.i = icmp slt i32 %0, %1, !dbg !283
  br i1 %cmp2.i, label %if.then.i, label %do.body.i, !dbg !284

if.then.i:                                        ; preds = %land.lhs.true.i
  tail call void @free(ptr noundef %ptr) #11, !dbg !285
  %2 = load i32, ptr %total.i, align 4, !dbg !287, !tbaa !221
  %dec.i = add nsw i32 %2, -1, !dbg !287
  store i32 %dec.i, ptr %total.i, align 4, !dbg !287, !tbaa !221
  br label %do_cache_free.exit, !dbg !288

do.body.i:                                        ; preds = %land.lhs.true.i, %entry
  %head.i = getelementptr inbounds i8, ptr %cache, i64 48, !dbg !289
  %3 = load ptr, ptr %head.i, align 8, !dbg !289, !tbaa !110
  store ptr %3, ptr %ptr, align 8, !dbg !289, !tbaa !174
  %cmp4.i = icmp eq ptr %3, null, !dbg !289
  br i1 %cmp4.i, label %if.then5.i, label %if.end.i, !dbg !293

if.then5.i:                                       ; preds = %do.body.i
  %stqh_last.i = getelementptr inbounds i8, ptr %cache, i64 56, !dbg !289
  store ptr %ptr, ptr %stqh_last.i, align 8, !dbg !289, !tbaa !111
  br label %if.end.i, !dbg !289

if.end.i:                                         ; preds = %if.then5.i, %do.body.i
  store ptr %ptr, ptr %head.i, align 8, !dbg !293, !tbaa !110
  %freecurr.i = getelementptr inbounds i8, ptr %cache, i64 80, !dbg !294
  %4 = load i32, ptr %freecurr.i, align 8, !dbg !295, !tbaa !205
  %inc.i = add nsw i32 %4, 1, !dbg !295
  store i32 %inc.i, ptr %freecurr.i, align 8, !dbg !295, !tbaa !205
  br label %do_cache_free.exit

do_cache_free.exit:                               ; preds = %if.then.i, %if.end.i
  %call2 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %cache) #11, !dbg !296
  ret void, !dbg !297
}

; Function Attrs: mustprogress nounwind sanitize_thread willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define dso_local void @do_cache_free(ptr nocapture noundef %cache, ptr noundef %ptr) local_unnamed_addr #7 !dbg !273 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %cache, metadata !272, metadata !DIExpression()), !dbg !298
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !275, metadata !DIExpression()), !dbg !298
  %limit = getelementptr inbounds i8, ptr %cache, i64 84, !dbg !299
  %0 = load i32, ptr %limit, align 4, !dbg !299, !tbaa !153
  %cmp.not = icmp eq i32 %0, 0, !dbg !300
  br i1 %cmp.not, label %do.body, label %land.lhs.true, !dbg !301

land.lhs.true:                                    ; preds = %entry
  %total = getelementptr inbounds i8, ptr %cache, i64 76, !dbg !302
  %1 = load i32, ptr %total, align 4, !dbg !302, !tbaa !221
  %cmp2 = icmp slt i32 %0, %1, !dbg !303
  br i1 %cmp2, label %if.then, label %do.body, !dbg !304

if.then:                                          ; preds = %land.lhs.true
  tail call void @free(ptr noundef %ptr) #11, !dbg !305
  %2 = load i32, ptr %total, align 4, !dbg !306, !tbaa !221
  %dec = add nsw i32 %2, -1, !dbg !306
  store i32 %dec, ptr %total, align 4, !dbg !306, !tbaa !221
  br label %if.end11, !dbg !307

do.body:                                          ; preds = %entry, %land.lhs.true
  %head = getelementptr inbounds i8, ptr %cache, i64 48, !dbg !308
  %3 = load ptr, ptr %head, align 8, !dbg !308, !tbaa !110
  store ptr %3, ptr %ptr, align 8, !dbg !308, !tbaa !174
  %cmp4 = icmp eq ptr %3, null, !dbg !308
  br i1 %cmp4, label %if.then5, label %if.end, !dbg !309

if.then5:                                         ; preds = %do.body
  %stqh_last = getelementptr inbounds i8, ptr %cache, i64 56, !dbg !308
  store ptr %ptr, ptr %stqh_last, align 8, !dbg !308, !tbaa !111
  br label %if.end, !dbg !308

if.end:                                           ; preds = %if.then5, %do.body
  store ptr %ptr, ptr %head, align 8, !dbg !309, !tbaa !110
  %freecurr = getelementptr inbounds i8, ptr %cache, i64 80, !dbg !310
  %4 = load i32, ptr %freecurr, align 8, !dbg !311, !tbaa !205
  %inc = add nsw i32 %4, 1, !dbg !311
  store i32 %inc, ptr %freecurr, align 8, !dbg !311, !tbaa !205
  br label %if.end11

if.end11:                                         ; preds = %if.end, %if.then
  ret void, !dbg !312
}

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #8 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #9

attributes #0 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { mustprogress nofree nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nofree nounwind sanitize_thread willreturn memory(read, argmem: readwrite, inaccessiblemem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { mustprogress nounwind sanitize_thread willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nounwind uwtable }
attributes #9 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { nounwind allocsize(0,1) }
attributes #11 = { nounwind }
attributes #12 = { nounwind allocsize(0) }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!12, !13, !14, !15, !16, !17, !18}
!llvm.ident = !{!19}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !2, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "cache.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "60b1b5f6bc21bd27dd29da4cd54982da")
!2 = !{!3, !4}
!3 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!4 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!5 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_free_s", file: !6, line: 12, size: 64, elements: !7)
!6 = !DIFile(filename: "./cache.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d97639c8540587a19d8550d7d7156448")
!7 = !{!8}
!8 = !DIDerivedType(tag: DW_TAG_member, name: "c_next", scope: !5, file: !6, line: 13, baseType: !9, size: 64)
!9 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !5, file: !6, line: 13, size: 64, elements: !10)
!10 = !{!11}
!11 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !9, file: !6, line: 13, baseType: !4, size: 64)
!12 = !{i32 7, !"Dwarf Version", i32 5}
!13 = !{i32 2, !"Debug Info Version", i32 3}
!14 = !{i32 1, !"wchar_size", i32 4}
!15 = !{i32 8, !"PIC Level", i32 2}
!16 = !{i32 7, !"PIE Level", i32 2}
!17 = !{i32 7, !"uwtable", i32 2}
!18 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!19 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!20 = distinct !DISubprogram(name: "cache_create", scope: !1, file: !1, line: 18, type: !21, scopeLine: 18, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !79)
!21 = !DISubroutineType(types: !22)
!22 = !{!23, !77, !70, !70}
!23 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !24, size: 64)
!24 = !DIDerivedType(tag: DW_TAG_typedef, name: "cache_t", file: !6, line: 39, baseType: !25)
!25 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !6, line: 22, size: 704, elements: !26)
!26 = !{!27, !61, !63, !69, !73, !74, !75, !76}
!27 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !25, file: !6, line: 24, baseType: !28, size: 320)
!28 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutex_t", file: !29, line: 72, baseType: !30)
!29 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h", directory: "", checksumkind: CSK_MD5, checksum: "8a5acdbeec491eca11cf81cb1ef77ea7")
!30 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !29, line: 67, size: 320, elements: !31)
!31 = !{!32, !54, !59}
!32 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !30, file: !29, line: 69, baseType: !33, size: 320)
!33 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_mutex_s", file: !34, line: 22, size: 320, elements: !35)
!34 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h", directory: "", checksumkind: CSK_MD5, checksum: "6b075eca9ab0e2d761b2afc4ecfab776")
!35 = !{!36, !38, !40, !41, !42, !43, !45, !46}
!36 = !DIDerivedType(tag: DW_TAG_member, name: "__lock", scope: !33, file: !34, line: 24, baseType: !37, size: 32)
!37 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!38 = !DIDerivedType(tag: DW_TAG_member, name: "__count", scope: !33, file: !34, line: 25, baseType: !39, size: 32, offset: 32)
!39 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!40 = !DIDerivedType(tag: DW_TAG_member, name: "__owner", scope: !33, file: !34, line: 26, baseType: !37, size: 32, offset: 64)
!41 = !DIDerivedType(tag: DW_TAG_member, name: "__nusers", scope: !33, file: !34, line: 28, baseType: !39, size: 32, offset: 96)
!42 = !DIDerivedType(tag: DW_TAG_member, name: "__kind", scope: !33, file: !34, line: 32, baseType: !37, size: 32, offset: 128)
!43 = !DIDerivedType(tag: DW_TAG_member, name: "__spins", scope: !33, file: !34, line: 34, baseType: !44, size: 16, offset: 160)
!44 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!45 = !DIDerivedType(tag: DW_TAG_member, name: "__elision", scope: !33, file: !34, line: 35, baseType: !44, size: 16, offset: 176)
!46 = !DIDerivedType(tag: DW_TAG_member, name: "__list", scope: !33, file: !34, line: 36, baseType: !47, size: 128, offset: 192)
!47 = !DIDerivedType(tag: DW_TAG_typedef, name: "__pthread_list_t", file: !48, line: 55, baseType: !49)
!48 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h", directory: "", checksumkind: CSK_MD5, checksum: "b9a7199822bce372686baacd32a9f4f3")
!49 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_internal_list", file: !48, line: 51, size: 128, elements: !50)
!50 = !{!51, !53}
!51 = !DIDerivedType(tag: DW_TAG_member, name: "__prev", scope: !49, file: !48, line: 53, baseType: !52, size: 64)
!52 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !49, size: 64)
!53 = !DIDerivedType(tag: DW_TAG_member, name: "__next", scope: !49, file: !48, line: 54, baseType: !52, size: 64, offset: 64)
!54 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !30, file: !29, line: 70, baseType: !55, size: 320)
!55 = !DICompositeType(tag: DW_TAG_array_type, baseType: !56, size: 320, elements: !57)
!56 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!57 = !{!58}
!58 = !DISubrange(count: 40)
!59 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !30, file: !29, line: 71, baseType: !60, size: 64)
!60 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!61 = !DIDerivedType(tag: DW_TAG_member, name: "name", scope: !25, file: !6, line: 26, baseType: !62, size: 64, offset: 320)
!62 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !56, size: 64)
!63 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !25, file: !6, line: 28, baseType: !64, size: 128, offset: 384)
!64 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_head", file: !6, line: 28, size: 128, elements: !65)
!65 = !{!66, !67}
!66 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !64, file: !6, line: 28, baseType: !4, size: 64)
!67 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !64, file: !6, line: 28, baseType: !68, size: 64, offset: 64)
!68 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !4, size: 64)
!69 = !DIDerivedType(tag: DW_TAG_member, name: "bufsize", scope: !25, file: !6, line: 30, baseType: !70, size: 64, offset: 512)
!70 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !71, line: 18, baseType: !72)
!71 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!72 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!73 = !DIDerivedType(tag: DW_TAG_member, name: "freetotal", scope: !25, file: !6, line: 32, baseType: !37, size: 32, offset: 576)
!74 = !DIDerivedType(tag: DW_TAG_member, name: "total", scope: !25, file: !6, line: 34, baseType: !37, size: 32, offset: 608)
!75 = !DIDerivedType(tag: DW_TAG_member, name: "freecurr", scope: !25, file: !6, line: 36, baseType: !37, size: 32, offset: 640)
!76 = !DIDerivedType(tag: DW_TAG_member, name: "limit", scope: !25, file: !6, line: 38, baseType: !37, size: 32, offset: 672)
!77 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !78, size: 64)
!78 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !56)
!79 = !{!80, !81, !82, !83, !84}
!80 = !DILocalVariable(name: "name", arg: 1, scope: !20, file: !1, line: 18, type: !77)
!81 = !DILocalVariable(name: "bufsize", arg: 2, scope: !20, file: !1, line: 18, type: !70)
!82 = !DILocalVariable(name: "align", arg: 3, scope: !20, file: !1, line: 18, type: !70)
!83 = !DILocalVariable(name: "ret", scope: !20, file: !1, line: 19, type: !23)
!84 = !DILocalVariable(name: "nm", scope: !20, file: !1, line: 20, type: !62)
!85 = !DILocation(line: 0, scope: !20)
!86 = !DILocation(line: 19, column: 20, scope: !20)
!87 = !DILocation(line: 20, column: 16, scope: !20)
!88 = !DILocation(line: 21, column: 13, scope: !89)
!89 = distinct !DILexicalBlock(scope: !20, file: !1, line: 21, column: 9)
!90 = !DILocation(line: 21, column: 21, scope: !89)
!91 = !DILocation(line: 22, column: 9, scope: !89)
!92 = !DILocation(line: 22, column: 47, scope: !89)
!93 = !DILocation(line: 21, column: 9, scope: !20)
!94 = !DILocation(line: 23, column: 9, scope: !95)
!95 = distinct !DILexicalBlock(scope: !89, file: !1, line: 22, column: 54)
!96 = !DILocation(line: 24, column: 9, scope: !95)
!97 = !DILocation(line: 25, column: 9, scope: !95)
!98 = !DILocation(line: 28, column: 10, scope: !20)
!99 = !DILocation(line: 28, column: 15, scope: !20)
!100 = !{!101, !104, i64 40}
!101 = !{!"", !102, i64 0, !104, i64 40, !105, i64 48, !106, i64 64, !107, i64 72, !107, i64 76, !107, i64 80, !107, i64 84}
!102 = !{!"omnipotent char", !103, i64 0}
!103 = !{!"Simple C/C++ TBAA"}
!104 = !{!"any pointer", !102, i64 0}
!105 = !{!"cache_head", !104, i64 0, !104, i64 8}
!106 = !{!"long", !102, i64 0}
!107 = !{!"int", !102, i64 0}
!108 = !DILocation(line: 29, column: 5, scope: !109)
!109 = distinct !DILexicalBlock(scope: !20, file: !1, line: 29, column: 5)
!110 = !{!101, !104, i64 48}
!111 = !{!101, !104, i64 56}
!112 = !DILocation(line: 34, column: 10, scope: !20)
!113 = !DILocation(line: 34, column: 18, scope: !20)
!114 = !{!101, !106, i64 64}
!115 = !DILocation(line: 38, column: 5, scope: !20)
!116 = !DILocation(line: 39, column: 1, scope: !20)
!117 = !DISubprogram(name: "calloc", scope: !118, file: !118, line: 675, type: !119, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!118 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!119 = !DISubroutineType(types: !120)
!120 = !{!3, !70, !70}
!121 = !DISubprogram(name: "strdup", scope: !122, file: !122, line: 187, type: !123, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!122 = !DIFile(filename: "/usr/include/string.h", directory: "", checksumkind: CSK_MD5, checksum: "165db1185644f68894fa9e0d17055d70")
!123 = !DISubroutineType(types: !124)
!124 = !{!62, !77}
!125 = !DISubprogram(name: "pthread_mutex_init", scope: !126, file: !126, line: 781, type: !127, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!126 = !DIFile(filename: "/usr/include/pthread.h", directory: "", checksumkind: CSK_MD5, checksum: "cbcd748b3d3ecaa7356dc2925b45d819")
!127 = !DISubroutineType(types: !128)
!128 = !{!37, !129, !130}
!129 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !28, size: 64)
!130 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !131, size: 64)
!131 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !132)
!132 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutexattr_t", file: !29, line: 36, baseType: !133)
!133 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !29, line: 32, size: 32, elements: !134)
!134 = !{!135, !139}
!135 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !133, file: !29, line: 34, baseType: !136, size: 32)
!136 = !DICompositeType(tag: DW_TAG_array_type, baseType: !56, size: 32, elements: !137)
!137 = !{!138}
!138 = !DISubrange(count: 4)
!139 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !133, file: !29, line: 35, baseType: !37, size: 32)
!140 = !DISubprogram(name: "free", scope: !118, file: !118, line: 687, type: !141, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!141 = !DISubroutineType(types: !142)
!142 = !{null, !3}
!143 = distinct !DISubprogram(name: "cache_set_limit", scope: !1, file: !1, line: 41, type: !144, scopeLine: 41, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !146)
!144 = !DISubroutineType(types: !145)
!145 = !{null, !23, !37}
!146 = !{!147, !148}
!147 = !DILocalVariable(name: "cache", arg: 1, scope: !143, file: !1, line: 41, type: !23)
!148 = !DILocalVariable(name: "limit", arg: 2, scope: !143, file: !1, line: 41, type: !37)
!149 = !DILocation(line: 0, scope: !143)
!150 = !DILocation(line: 42, column: 5, scope: !143)
!151 = !DILocation(line: 43, column: 12, scope: !143)
!152 = !DILocation(line: 43, column: 18, scope: !143)
!153 = !{!101, !107, i64 84}
!154 = !DILocation(line: 44, column: 5, scope: !143)
!155 = !DILocation(line: 45, column: 1, scope: !143)
!156 = !DISubprogram(name: "pthread_mutex_lock", scope: !126, file: !126, line: 794, type: !157, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!157 = !DISubroutineType(types: !158)
!158 = !{!37, !129}
!159 = !DISubprogram(name: "pthread_mutex_unlock", scope: !126, file: !126, line: 835, type: !157, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!160 = distinct !DISubprogram(name: "cache_destroy", scope: !1, file: !1, line: 56, type: !161, scopeLine: 56, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !163)
!161 = !DISubroutineType(types: !162)
!162 = !{null, !23}
!163 = !{!164, !165}
!164 = !DILocalVariable(name: "cache", arg: 1, scope: !160, file: !1, line: 56, type: !23)
!165 = !DILocalVariable(name: "o", scope: !166, file: !1, line: 58, type: !4)
!166 = distinct !DILexicalBlock(scope: !160, file: !1, line: 57, column: 41)
!167 = !DILocation(line: 0, scope: !160)
!168 = !DILocation(line: 57, column: 13, scope: !160)
!169 = !DILocation(line: 57, column: 5, scope: !160)
!170 = !DILocation(line: 0, scope: !166)
!171 = !DILocation(line: 59, column: 9, scope: !172)
!172 = distinct !DILexicalBlock(scope: !173, file: !1, line: 59, column: 9)
!173 = distinct !DILexicalBlock(scope: !166, file: !1, line: 59, column: 9)
!174 = !{!175, !104, i64 0}
!175 = !{!"cache_free_s", !176, i64 0}
!176 = !{!"", !104, i64 0}
!177 = !DILocation(line: 59, column: 9, scope: !173)
!178 = !DILocation(line: 60, column: 9, scope: !166)
!179 = distinct !{!179, !169, !180, !181}
!180 = !DILocation(line: 61, column: 5, scope: !160)
!181 = !{!"llvm.loop.mustprogress"}
!182 = !DILocation(line: 62, column: 17, scope: !160)
!183 = !DILocation(line: 62, column: 5, scope: !160)
!184 = !DILocation(line: 63, column: 5, scope: !160)
!185 = !DILocation(line: 64, column: 5, scope: !160)
!186 = !DILocation(line: 65, column: 1, scope: !160)
!187 = !DISubprogram(name: "pthread_mutex_destroy", scope: !126, file: !126, line: 786, type: !157, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!188 = distinct !DISubprogram(name: "cache_alloc", scope: !1, file: !1, line: 67, type: !189, scopeLine: 67, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !191)
!189 = !DISubroutineType(types: !190)
!190 = !{!3, !23}
!191 = !{!192, !193}
!192 = !DILocalVariable(name: "cache", arg: 1, scope: !188, file: !1, line: 67, type: !23)
!193 = !DILocalVariable(name: "ret", scope: !188, file: !1, line: 68, type: !3)
!194 = !DILocation(line: 0, scope: !188)
!195 = !DILocation(line: 69, column: 5, scope: !188)
!196 = !DILocalVariable(name: "cache", arg: 1, scope: !197, file: !1, line: 75, type: !23)
!197 = distinct !DISubprogram(name: "do_cache_alloc", scope: !1, file: !1, line: 75, type: !189, scopeLine: 75, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !198)
!198 = !{!196, !199, !200}
!199 = !DILocalVariable(name: "ret", scope: !197, file: !1, line: 76, type: !3)
!200 = !DILocalVariable(name: "object", scope: !197, file: !1, line: 77, type: !3)
!201 = !DILocation(line: 0, scope: !197, inlinedAt: !202)
!202 = distinct !DILocation(line: 70, column: 11, scope: !188)
!203 = !DILocation(line: 78, column: 16, scope: !204, inlinedAt: !202)
!204 = distinct !DILexicalBlock(scope: !197, file: !1, line: 78, column: 9)
!205 = !{!101, !107, i64 80}
!206 = !DILocation(line: 78, column: 25, scope: !204, inlinedAt: !202)
!207 = !DILocation(line: 78, column: 9, scope: !197, inlinedAt: !202)
!208 = !DILocation(line: 79, column: 15, scope: !209, inlinedAt: !202)
!209 = distinct !DILexicalBlock(scope: !204, file: !1, line: 78, column: 30)
!210 = !DILocation(line: 80, column: 9, scope: !211, inlinedAt: !202)
!211 = distinct !DILexicalBlock(scope: !212, file: !1, line: 80, column: 9)
!212 = distinct !DILexicalBlock(scope: !209, file: !1, line: 80, column: 9)
!213 = !DILocation(line: 80, column: 9, scope: !212, inlinedAt: !202)
!214 = !DILocation(line: 82, column: 24, scope: !209, inlinedAt: !202)
!215 = !DILocation(line: 83, column: 5, scope: !209, inlinedAt: !202)
!216 = !DILocation(line: 83, column: 23, scope: !217, inlinedAt: !202)
!217 = distinct !DILexicalBlock(scope: !204, file: !1, line: 83, column: 16)
!218 = !DILocation(line: 83, column: 29, scope: !217, inlinedAt: !202)
!219 = !DILocation(line: 83, column: 34, scope: !217, inlinedAt: !202)
!220 = !DILocation(line: 83, column: 44, scope: !217, inlinedAt: !202)
!221 = !{!101, !107, i64 76}
!222 = !DILocation(line: 83, column: 50, scope: !217, inlinedAt: !202)
!223 = !DILocation(line: 83, column: 16, scope: !204, inlinedAt: !202)
!224 = !DILocation(line: 84, column: 38, scope: !225, inlinedAt: !202)
!225 = distinct !DILexicalBlock(scope: !217, file: !1, line: 83, column: 66)
!226 = !DILocation(line: 84, column: 24, scope: !225, inlinedAt: !202)
!227 = !DILocation(line: 85, column: 17, scope: !228, inlinedAt: !202)
!228 = distinct !DILexicalBlock(scope: !225, file: !1, line: 85, column: 13)
!229 = !DILocation(line: 85, column: 13, scope: !225, inlinedAt: !202)
!230 = !DILocation(line: 88, column: 20, scope: !231, inlinedAt: !202)
!231 = distinct !DILexicalBlock(scope: !228, file: !1, line: 85, column: 26)
!232 = !DILocation(line: 88, column: 25, scope: !231, inlinedAt: !202)
!233 = !DILocation(line: 89, column: 9, scope: !231, inlinedAt: !202)
!234 = !DILocation(line: 0, scope: !204, inlinedAt: !202)
!235 = !DILocation(line: 71, column: 5, scope: !188)
!236 = !DILocation(line: 72, column: 5, scope: !188)
!237 = !DILocation(line: 0, scope: !197)
!238 = !DILocation(line: 78, column: 16, scope: !204)
!239 = !DILocation(line: 78, column: 25, scope: !204)
!240 = !DILocation(line: 78, column: 9, scope: !197)
!241 = !DILocation(line: 79, column: 15, scope: !209)
!242 = !DILocation(line: 80, column: 9, scope: !211)
!243 = !DILocation(line: 80, column: 9, scope: !212)
!244 = !DILocation(line: 82, column: 24, scope: !209)
!245 = !DILocation(line: 83, column: 5, scope: !209)
!246 = !DILocation(line: 83, column: 23, scope: !217)
!247 = !DILocation(line: 83, column: 29, scope: !217)
!248 = !DILocation(line: 83, column: 34, scope: !217)
!249 = !DILocation(line: 83, column: 44, scope: !217)
!250 = !DILocation(line: 83, column: 50, scope: !217)
!251 = !DILocation(line: 83, column: 16, scope: !204)
!252 = !DILocation(line: 84, column: 38, scope: !225)
!253 = !DILocation(line: 84, column: 24, scope: !225)
!254 = !DILocation(line: 85, column: 17, scope: !228)
!255 = !DILocation(line: 85, column: 13, scope: !225)
!256 = !DILocation(line: 88, column: 20, scope: !231)
!257 = !DILocation(line: 88, column: 25, scope: !231)
!258 = !DILocation(line: 89, column: 9, scope: !231)
!259 = !DILocation(line: 0, scope: !204)
!260 = !DILocation(line: 105, column: 5, scope: !197)
!261 = !DISubprogram(name: "malloc", scope: !118, file: !118, line: 672, type: !262, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!262 = !DISubroutineType(types: !263)
!263 = !{!3, !70}
!264 = distinct !DISubprogram(name: "cache_free", scope: !1, file: !1, line: 108, type: !265, scopeLine: 108, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !267)
!265 = !DISubroutineType(types: !266)
!266 = !{null, !23, !3}
!267 = !{!268, !269}
!268 = !DILocalVariable(name: "cache", arg: 1, scope: !264, file: !1, line: 108, type: !23)
!269 = !DILocalVariable(name: "ptr", arg: 2, scope: !264, file: !1, line: 108, type: !3)
!270 = !DILocation(line: 0, scope: !264)
!271 = !DILocation(line: 109, column: 5, scope: !264)
!272 = !DILocalVariable(name: "cache", arg: 1, scope: !273, file: !1, line: 114, type: !23)
!273 = distinct !DISubprogram(name: "do_cache_free", scope: !1, file: !1, line: 114, type: !265, scopeLine: 114, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !274)
!274 = !{!272, !275}
!275 = !DILocalVariable(name: "ptr", arg: 2, scope: !273, file: !1, line: 114, type: !3)
!276 = !DILocation(line: 0, scope: !273, inlinedAt: !277)
!277 = distinct !DILocation(line: 110, column: 5, scope: !264)
!278 = !DILocation(line: 132, column: 16, scope: !279, inlinedAt: !277)
!279 = distinct !DILexicalBlock(scope: !273, file: !1, line: 132, column: 9)
!280 = !DILocation(line: 132, column: 22, scope: !279, inlinedAt: !277)
!281 = !DILocation(line: 132, column: 27, scope: !279, inlinedAt: !277)
!282 = !DILocation(line: 132, column: 52, scope: !279, inlinedAt: !277)
!283 = !DILocation(line: 132, column: 43, scope: !279, inlinedAt: !277)
!284 = !DILocation(line: 132, column: 9, scope: !273, inlinedAt: !277)
!285 = !DILocation(line: 133, column: 9, scope: !286, inlinedAt: !277)
!286 = distinct !DILexicalBlock(scope: !279, file: !1, line: 132, column: 59)
!287 = !DILocation(line: 134, column: 21, scope: !286, inlinedAt: !277)
!288 = !DILocation(line: 135, column: 5, scope: !286, inlinedAt: !277)
!289 = !DILocation(line: 136, column: 9, scope: !290, inlinedAt: !277)
!290 = distinct !DILexicalBlock(scope: !291, file: !1, line: 136, column: 9)
!291 = distinct !DILexicalBlock(scope: !292, file: !1, line: 136, column: 9)
!292 = distinct !DILexicalBlock(scope: !279, file: !1, line: 135, column: 12)
!293 = !DILocation(line: 136, column: 9, scope: !291, inlinedAt: !277)
!294 = !DILocation(line: 137, column: 16, scope: !292, inlinedAt: !277)
!295 = !DILocation(line: 137, column: 24, scope: !292, inlinedAt: !277)
!296 = !DILocation(line: 111, column: 5, scope: !264)
!297 = !DILocation(line: 112, column: 1, scope: !264)
!298 = !DILocation(line: 0, scope: !273)
!299 = !DILocation(line: 132, column: 16, scope: !279)
!300 = !DILocation(line: 132, column: 22, scope: !279)
!301 = !DILocation(line: 132, column: 27, scope: !279)
!302 = !DILocation(line: 132, column: 52, scope: !279)
!303 = !DILocation(line: 132, column: 43, scope: !279)
!304 = !DILocation(line: 132, column: 9, scope: !273)
!305 = !DILocation(line: 133, column: 9, scope: !286)
!306 = !DILocation(line: 134, column: 21, scope: !286)
!307 = !DILocation(line: 135, column: 5, scope: !286)
!308 = !DILocation(line: 136, column: 9, scope: !290)
!309 = !DILocation(line: 136, column: 9, scope: !291)
!310 = !DILocation(line: 137, column: 16, scope: !292)
!311 = !DILocation(line: 137, column: 24, scope: !292)
!312 = !DILocation(line: 139, column: 1, scope: !273)
