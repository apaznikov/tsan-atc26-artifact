; ModuleID = 'authfile.c'
source_filename = "authfile.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.auth_entry = type { ptr, i64, ptr, i64 }
%struct.stat = type { i64, i64, i64, i32, i32, i32, i32, i64, i64, i64, i64, %struct.timespec, %struct.timespec, %struct.timespec, [3 x i64] }
%struct.timespec = type { i64, i64 }

@entry_cnt = dso_local local_unnamed_addr global i32 0, align 4, !dbg !0
@main_auth_data = dso_local local_unnamed_addr global ptr null, align 8, !dbg !17
@.str = private unnamed_addr constant [2 x i8] c"r\00", align 1, !dbg !21
@main_auth_entries = dso_local local_unnamed_addr global [8 x %struct.auth_entry] zeroinitializer, align 16, !dbg !26
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef i32 @authfile_load(ptr nocapture noundef readonly %file) local_unnamed_addr #0 !dbg !50 {
entry:
  %sb = alloca %struct.stat, align 8, !DIAssignID !161
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !57, metadata !DIExpression(), metadata !161, metadata ptr %sb, metadata !DIExpression()), !dbg !162
  %auth_entries = alloca [8 x %struct.auth_entry], align 16, !DIAssignID !163
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !98, metadata !DIExpression(), metadata !163, metadata ptr %auth_entries, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata ptr %file, metadata !56, metadata !DIExpression()), !dbg !162
  call void @llvm.lifetime.start.p0(i64 144, ptr nonnull %sb) #10, !dbg !164
  tail call void @llvm.dbg.value(metadata ptr null, metadata !97, metadata !DIExpression()), !dbg !162
  call void @llvm.lifetime.start.p0(i64 256, ptr nonnull %auth_entries) #10, !dbg !165
  %call = tail call noalias ptr @fopen(ptr noundef %file, ptr noundef nonnull @.str), !dbg !166
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !99, metadata !DIExpression()), !dbg !162
  %cmp = icmp eq ptr %call, null, !dbg !167
  br i1 %cmp, label %cleanup87, label %if.else, !dbg !169

if.else:                                          ; preds = %entry
  %call1 = tail call i32 @fileno(ptr noundef nonnull %call) #10, !dbg !170
  %call2 = call i32 @fstat(i32 noundef %call1, ptr noundef nonnull %sb) #10, !dbg !172
  %tobool.not = icmp eq i32 %call2, 0, !dbg !172
  br i1 %tobool.not, label %if.end5, label %if.then3, !dbg !173

if.then3:                                         ; preds = %if.else
  %call4 = tail call i32 @fclose(ptr noundef nonnull %call), !dbg !174
  br label %cleanup87, !dbg !176

if.end5:                                          ; preds = %if.else
  %st_size = getelementptr inbounds i8, ptr %sb, i64 48, !dbg !177
  %0 = load i64, ptr %st_size, align 8, !dbg !177, !tbaa !178
  %add = add nsw i64 %0, 1, !dbg !185
  %call6 = tail call noalias ptr @calloc(i64 noundef 1, i64 noundef %add) #11, !dbg !186
  tail call void @llvm.dbg.value(metadata ptr %call6, metadata !97, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata ptr %call6, metadata !153, metadata !DIExpression()), !dbg !162
  %add.ptr = getelementptr inbounds i8, ptr %call6, i64 %0, !dbg !187
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !154, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata ptr %auth_entries, metadata !155, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata i32 0, metadata !157, metadata !DIExpression()), !dbg !162
  %sub.ptr.lhs.cast = ptrtoint ptr %add.ptr to i64
  tail call void @llvm.dbg.value(metadata i32 0, metadata !157, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata ptr %auth_entries, metadata !155, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata ptr %call6, metadata !153, metadata !DIExpression()), !dbg !162
  %spec.select151 = tail call i64 @llvm.smin.i64(i64 %0, i64 256), !dbg !188
  %conv152 = trunc i64 %spec.select151 to i32, !dbg !188
  %call12153 = tail call ptr @fgets(ptr noundef %call6, i32 noundef %conv152, ptr noundef nonnull %call), !dbg !189
  %cmp13.not154 = icmp eq ptr %call12153, null, !dbg !190
  br i1 %cmp13.not154, label %while.end, label %for.cond.preheader, !dbg !191

while.cond:                                       ; preds = %if.end67
  %incdec.ptr = getelementptr inbounds i8, ptr %entry_cur.0156, i64 32, !dbg !192
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !155, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata i32 %inc63, metadata !157, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !155, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata ptr %arrayidx69, metadata !153, metadata !DIExpression()), !dbg !162
  %sub.ptr.rhs.cast = ptrtoint ptr %arrayidx69 to i64, !dbg !193
  %sub.ptr.sub = sub i64 %sub.ptr.lhs.cast, %sub.ptr.rhs.cast, !dbg !193
  %spec.select = tail call i64 @llvm.smin.i64(i64 %sub.ptr.sub, i64 256), !dbg !188
  %conv = trunc i64 %spec.select to i32, !dbg !188
  %call12 = tail call ptr @fgets(ptr noundef nonnull %arrayidx69, i32 noundef %conv, ptr noundef nonnull %call), !dbg !189
  %cmp13.not = icmp eq ptr %call12, null, !dbg !190
  br i1 %cmp13.not, label %while.end, label %for.cond.preheader, !dbg !191

for.cond.preheader:                               ; preds = %if.end5, %while.cond
  %used.0157 = phi i32 [ %inc63, %while.cond ], [ 0, %if.end5 ]
  %entry_cur.0156 = phi ptr [ %incdec.ptr, %while.cond ], [ %auth_entries, %if.end5 ]
  %auth_cur.0155 = phi ptr [ %arrayidx69, %while.cond ], [ %call6, %if.end5 ]
  tail call void @llvm.dbg.value(metadata i32 %used.0157, metadata !157, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata ptr %entry_cur.0156, metadata !155, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata ptr %auth_cur.0155, metadata !153, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata i32 0, metadata !160, metadata !DIExpression()), !dbg !194
  tail call void @llvm.dbg.value(metadata i32 0, metadata !158, metadata !DIExpression()), !dbg !194
  %ulen = getelementptr inbounds i8, ptr %entry_cur.0156, i64 8
  %pass = getelementptr inbounds i8, ptr %entry_cur.0156, i64 16
  br label %for.body, !dbg !195

for.body:                                         ; preds = %for.body.backedge, %for.cond.preheader
  %indvars.iv = phi i64 [ 0, %for.cond.preheader ], [ %indvars.iv.be, %for.body.backedge ]
  %tobool17.not = phi i1 [ true, %for.cond.preheader ], [ %tobool17.not.be, %for.body.backedge ]
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !160, metadata !DIExpression()), !dbg !194
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !158, metadata !DIExpression()), !dbg !194
  %arrayidx = getelementptr inbounds i8, ptr %auth_cur.0155, i64 %indvars.iv, !dbg !197
  %1 = load i8, ptr %arrayidx, align 1, !dbg !197, !tbaa !201
  br i1 %tobool17.not, label %if.then18, label %if.else36, !dbg !202

if.then18:                                        ; preds = %for.body
  switch i8 %1, label %for.inc.thread [
    i8 0, label %cleanup.thread136
    i8 58, label %if.then29
  ], !dbg !203

if.then29:                                        ; preds = %if.then18
  store ptr %auth_cur.0155, ptr %entry_cur.0156, align 8, !dbg !205, !tbaa !209
  store i64 %indvars.iv, ptr %ulen, align 8, !dbg !212, !tbaa !213
  %2 = add nuw nsw i64 %indvars.iv, 1, !dbg !214
  %arrayidx33 = getelementptr inbounds i8, ptr %auth_cur.0155, i64 %2, !dbg !215
  store ptr %arrayidx33, ptr %pass, align 8, !dbg !216, !tbaa !217
  tail call void @llvm.dbg.value(metadata i32 1, metadata !160, metadata !DIExpression()), !dbg !194
  br label %for.inc, !dbg !218

if.else36:                                        ; preds = %for.body
  switch i8 %1, label %for.inc [
    i8 10, label %for.end.thread130
    i8 13, label %for.end.thread130
    i8 0, label %for.end.thread130
  ], !dbg !219

for.end.thread130:                                ; preds = %if.else36, %if.else36, %if.else36
  %3 = load i64, ptr %ulen, align 8, !dbg !222, !tbaa !213
  %add56.neg = xor i64 %3, -1, !dbg !224
  %sub = add i64 %indvars.iv, %add56.neg, !dbg !225
  %plen = getelementptr inbounds i8, ptr %entry_cur.0156, i64 24, !dbg !226
  store i64 %sub, ptr %plen, align 8, !dbg !227, !tbaa !228
  br label %if.end62, !dbg !229

for.inc:                                          ; preds = %if.else36, %if.then29
  tail call void @llvm.dbg.value(metadata i32 1, metadata !160, metadata !DIExpression()), !dbg !194
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !230
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !158, metadata !DIExpression()), !dbg !194
  %exitcond.not = icmp eq i64 %indvars.iv.next, 256, !dbg !231
  br i1 %exitcond.not, label %if.end62, label %for.body.backedge, !dbg !195

for.body.backedge:                                ; preds = %for.inc, %for.inc.thread
  %indvars.iv.be = phi i64 [ %indvars.iv.next, %for.inc ], [ %indvars.iv.next167, %for.inc.thread ]
  %tobool17.not.be = phi i1 [ false, %for.inc ], [ true, %for.inc.thread ]
  br label %for.body, !dbg !197, !llvm.loop !232

for.inc.thread:                                   ; preds = %if.then18
  tail call void @llvm.dbg.value(metadata i32 0, metadata !160, metadata !DIExpression()), !dbg !194
  %indvars.iv.next167 = add nuw nsw i64 %indvars.iv, 1, !dbg !230
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next167, metadata !158, metadata !DIExpression()), !dbg !194
  %exitcond.not168 = icmp eq i64 %indvars.iv.next167, 256, !dbg !231
  br i1 %exitcond.not168, label %cleanup.thread136, label %for.body.backedge, !dbg !195

cleanup.thread136:                                ; preds = %for.inc.thread, %if.then18
  %call61 = tail call i32 @fclose(ptr noundef nonnull %call), !dbg !235
  tail call void @free(ptr noundef %call6) #10, !dbg !238
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !157, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !155, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !153, metadata !DIExpression()), !dbg !162
  br label %cleanup87

if.end62:                                         ; preds = %for.inc, %for.end.thread130
  %x.0146 = phi i64 [ %indvars.iv, %for.end.thread130 ], [ 256, %for.inc ]
  %inc63 = add nuw nsw i32 %used.0157, 1, !dbg !239
  tail call void @llvm.dbg.value(metadata i32 %inc63, metadata !157, metadata !DIExpression()), !dbg !162
  %cmp64 = icmp eq i32 %inc63, 8, !dbg !241
  br i1 %cmp64, label %while.end, label %if.end67, !dbg !242

if.end67:                                         ; preds = %if.end62
  %idxprom68 = and i64 %x.0146, 4294967295, !dbg !243
  %arrayidx69 = getelementptr inbounds i8, ptr %auth_cur.0155, i64 %idxprom68, !dbg !243
  %4 = load i8, ptr %arrayidx69, align 1, !dbg !243, !tbaa !201
  %cmp71 = icmp eq i8 %4, 0, !dbg !245
  tail call void @llvm.dbg.value(metadata ptr %arrayidx69, metadata !153, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata i32 %inc63, metadata !157, metadata !DIExpression()), !dbg !162
  tail call void @llvm.dbg.value(metadata ptr %entry_cur.0156, metadata !155, metadata !DIExpression(DW_OP_plus_uconst, 32, DW_OP_stack_value)), !dbg !162
  br i1 %cmp71, label %while.end, label %while.cond, !dbg !246

while.end:                                        ; preds = %while.cond, %if.end62, %if.end67, %if.end5
  %used.2 = phi i32 [ 0, %if.end5 ], [ %inc63, %if.end67 ], [ 8, %if.end62 ], [ %inc63, %while.cond ], !dbg !162
  tail call void @llvm.dbg.value(metadata i32 %used.2, metadata !157, metadata !DIExpression()), !dbg !162
  %5 = load ptr, ptr @main_auth_data, align 8, !dbg !247, !tbaa !249
  %cmp77.not = icmp eq ptr %5, null, !dbg !250
  br i1 %cmp77.not, label %if.end80, label %if.then79, !dbg !251

if.then79:                                        ; preds = %while.end
  tail call void @free(ptr noundef nonnull %5) #10, !dbg !252
  br label %if.end80, !dbg !254

if.end80:                                         ; preds = %if.then79, %while.end
  store i32 %used.2, ptr @entry_cnt, align 4, !dbg !255, !tbaa !256
  store ptr %call6, ptr @main_auth_data, align 8, !dbg !257, !tbaa !249
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(256) @main_auth_entries, ptr noundef nonnull align 16 dereferenceable(256) %auth_entries, i64 256, i1 false), !dbg !258
  %call82 = tail call i32 @fclose(ptr noundef nonnull %call), !dbg !259
  br label %cleanup87, !dbg !260

cleanup87:                                        ; preds = %cleanup.thread136, %if.end80, %entry, %if.then3
  %retval.3 = phi i32 [ 2, %if.then3 ], [ 3, %entry ], [ 0, %if.end80 ], [ 4, %cleanup.thread136 ]
  call void @llvm.lifetime.end.p0(i64 256, ptr nonnull %auth_entries) #10, !dbg !261
  call void @llvm.lifetime.end.p0(i64 144, ptr nonnull %sb) #10, !dbg !261
  ret i32 %retval.3, !dbg !261
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nofree nounwind
declare !dbg !262 noalias noundef ptr @fopen(ptr nocapture noundef readonly, ptr nocapture noundef readonly) local_unnamed_addr #2

; Function Attrs: nofree nounwind
declare !dbg !267 noundef i32 @fstat(i32 noundef, ptr nocapture noundef) local_unnamed_addr #2

; Function Attrs: nofree nounwind
declare !dbg !272 noundef i32 @fileno(ptr nocapture noundef) local_unnamed_addr #2

; Function Attrs: nofree nounwind
declare !dbg !275 noundef i32 @fclose(ptr nocapture noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite)
declare !dbg !276 noalias noundef ptr @calloc(i64 noundef, i64 noundef) local_unnamed_addr #3

; Function Attrs: nofree nounwind
declare !dbg !280 noundef ptr @fgets(ptr noundef, i32 noundef, ptr nocapture noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !285 void @free(ptr allocptr nocapture noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #5

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef i32 @authfile_check(ptr noundef %user, ptr noundef %pass) local_unnamed_addr #0 !dbg !288 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %user, metadata !292, metadata !DIExpression()), !dbg !301
  tail call void @llvm.dbg.value(metadata ptr %pass, metadata !293, metadata !DIExpression()), !dbg !301
  %call = tail call i64 @strlen(ptr noundef nonnull dereferenceable(1) %user) #12, !dbg !302
  tail call void @llvm.dbg.value(metadata i64 %call, metadata !294, metadata !DIExpression()), !dbg !301
  %call1 = tail call i64 @strlen(ptr noundef nonnull dereferenceable(1) %pass) #12, !dbg !303
  tail call void @llvm.dbg.value(metadata i64 %call1, metadata !295, metadata !DIExpression()), !dbg !301
  tail call void @llvm.dbg.value(metadata i32 0, metadata !296, metadata !DIExpression()), !dbg !304
  %0 = load i32, ptr @entry_cnt, align 4, !dbg !305, !tbaa !256
  %cmp.not29 = icmp sgt i32 %0, 0, !dbg !306
  br i1 %cmp.not29, label %for.body, label %cleanup14, !dbg !307

for.body:                                         ; preds = %entry, %if.end
  %indvars.iv = phi i64 [ %indvars.iv.next, %if.end ], [ 0, %entry ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !296, metadata !DIExpression()), !dbg !304
  %arrayidx = getelementptr inbounds [8 x %struct.auth_entry], ptr @main_auth_entries, i64 0, i64 %indvars.iv, !dbg !308
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !298, metadata !DIExpression()), !dbg !309
  %ulen2 = getelementptr inbounds i8, ptr %arrayidx, i64 8, !dbg !310
  %1 = load i64, ptr %ulen2, align 8, !dbg !310, !tbaa !213
  %cmp3 = icmp eq i64 %call, %1, !dbg !312
  br i1 %cmp3, label %land.lhs.true, label %if.end, !dbg !313

land.lhs.true:                                    ; preds = %for.body
  %plen4 = getelementptr inbounds i8, ptr %arrayidx, i64 24, !dbg !314
  %2 = load i64, ptr %plen4, align 8, !dbg !314, !tbaa !228
  %cmp5 = icmp eq i64 %call1, %2, !dbg !315
  br i1 %cmp5, label %land.lhs.true6, label %if.end, !dbg !316

land.lhs.true6:                                   ; preds = %land.lhs.true
  %3 = load ptr, ptr %arrayidx, align 16, !dbg !317, !tbaa !209
  %call9 = tail call zeroext i1 @safe_memcmp(ptr noundef %user, ptr noundef %3, i64 noundef %call) #10, !dbg !318
  br i1 %call9, label %land.lhs.true10, label %if.end, !dbg !319

land.lhs.true10:                                  ; preds = %land.lhs.true6
  %pass11 = getelementptr inbounds i8, ptr %arrayidx, i64 16, !dbg !320
  %4 = load ptr, ptr %pass11, align 16, !dbg !320, !tbaa !217
  %5 = load i64, ptr %plen4, align 8, !dbg !321, !tbaa !228
  %call13 = tail call zeroext i1 @safe_memcmp(ptr noundef %pass, ptr noundef %4, i64 noundef %5) #10, !dbg !322
  br i1 %call13, label %cleanup14, label %if.end, !dbg !323

if.end:                                           ; preds = %land.lhs.true10, %land.lhs.true6, %land.lhs.true, %for.body
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !324
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !296, metadata !DIExpression()), !dbg !304
  %6 = load i32, ptr @entry_cnt, align 4, !dbg !305, !tbaa !256
  %7 = sext i32 %6 to i64, !dbg !306
  %cmp.not = icmp slt i64 %indvars.iv.next, %7, !dbg !306
  br i1 %cmp.not, label %for.body, label %cleanup14, !dbg !307, !llvm.loop !325

cleanup14:                                        ; preds = %if.end, %land.lhs.true10, %entry
  %cmp.not.lcssa = phi i32 [ 0, %entry ], [ 1, %land.lhs.true10 ], [ 0, %if.end ], !dbg !306
  ret i32 %cmp.not.lcssa, !dbg !327
}

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare !dbg !328 i64 @strlen(ptr nocapture noundef) local_unnamed_addr #6

declare !dbg !332 zeroext i1 @safe_memcmp(ptr noundef, ptr noundef, i64 noundef) local_unnamed_addr #7

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #8

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #9 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #8

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #8

attributes #0 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { mustprogress nofree nounwind willreturn memory(argmem: read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { nounwind uwtable }
attributes #10 = { nounwind }
attributes #11 = { nounwind allocsize(0,1) }
attributes #12 = { nobuiltin nounwind willreturn memory(read) }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!42, !43, !44, !45, !46, !47, !48}
!llvm.ident = !{!49}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "entry_cnt", scope: !2, file: !3, line: 28, type: !41, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !14, globals: !16, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "authfile.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "0862e0458ee628bbb6fbc2f7d2dc38f1")
!4 = !{!5}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "authfile_ret", file: !6, line: 4, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "./authfile.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "0dde135e0a78cac5fa53ca0c0171cf2a")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12, !13}
!9 = !DIEnumerator(name: "AUTHFILE_OK", value: 0)
!10 = !DIEnumerator(name: "AUTHFILE_OOM", value: 1)
!11 = !DIEnumerator(name: "AUTHFILE_STATFAIL", value: 2)
!12 = !DIEnumerator(name: "AUTHFILE_OPENFAIL", value: 3)
!13 = !DIEnumerator(name: "AUTHFILE_MALFORMED", value: 4)
!14 = !{!15}
!15 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!16 = !{!0, !17, !21, !26}
!17 = !DIGlobalVariableExpression(var: !18, expr: !DIExpression())
!18 = distinct !DIGlobalVariable(name: "main_auth_data", scope: !2, file: !3, line: 29, type: !19, isLocal: false, isDefinition: true)
!19 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !20, size: 64)
!20 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!21 = !DIGlobalVariableExpression(var: !22, expr: !DIExpression())
!22 = distinct !DIGlobalVariable(scope: null, file: !3, line: 36, type: !23, isLocal: true, isDefinition: true)
!23 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 16, elements: !24)
!24 = !{!25}
!25 = !DISubrange(count: 2)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "main_auth_entries", scope: !2, file: !3, line: 27, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 2048, elements: !39)
!29 = !DIDerivedType(tag: DW_TAG_typedef, name: "auth_t", file: !3, line: 25, baseType: !30)
!30 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "auth_entry", file: !3, line: 20, size: 256, elements: !31)
!31 = !{!32, !33, !37, !38}
!32 = !DIDerivedType(tag: DW_TAG_member, name: "user", scope: !30, file: !3, line: 21, baseType: !19, size: 64)
!33 = !DIDerivedType(tag: DW_TAG_member, name: "ulen", scope: !30, file: !3, line: 22, baseType: !34, size: 64, offset: 64)
!34 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !35, line: 18, baseType: !36)
!35 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!36 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!37 = !DIDerivedType(tag: DW_TAG_member, name: "pass", scope: !30, file: !3, line: 23, baseType: !19, size: 64, offset: 128)
!38 = !DIDerivedType(tag: DW_TAG_member, name: "plen", scope: !30, file: !3, line: 24, baseType: !34, size: 64, offset: 192)
!39 = !{!40}
!40 = !DISubrange(count: 8)
!41 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!42 = !{i32 7, !"Dwarf Version", i32 5}
!43 = !{i32 2, !"Debug Info Version", i32 3}
!44 = !{i32 1, !"wchar_size", i32 4}
!45 = !{i32 8, !"PIC Level", i32 2}
!46 = !{i32 7, !"PIE Level", i32 2}
!47 = !{i32 7, !"uwtable", i32 2}
!48 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!49 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!50 = distinct !DISubprogram(name: "authfile_load", scope: !3, file: !3, line: 31, type: !51, scopeLine: 31, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !55)
!51 = !DISubroutineType(types: !52)
!52 = !{!5, !53}
!53 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !54, size: 64)
!54 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!55 = !{!56, !57, !97, !98, !99, !153, !154, !155, !157, !158, !160}
!56 = !DILocalVariable(name: "file", arg: 1, scope: !50, file: !3, line: 31, type: !53)
!57 = !DILocalVariable(name: "sb", scope: !50, file: !3, line: 32, type: !58)
!58 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "stat", file: !59, line: 26, size: 1152, elements: !60)
!59 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/struct_stat.h", directory: "", checksumkind: CSK_MD5, checksum: "59591d2af474d06a64835bfc23e4bb5d")
!60 = !{!61, !64, !66, !68, !70, !72, !74, !75, !76, !79, !81, !83, !91, !92, !93}
!61 = !DIDerivedType(tag: DW_TAG_member, name: "st_dev", scope: !58, file: !59, line: 31, baseType: !62, size: 64)
!62 = !DIDerivedType(tag: DW_TAG_typedef, name: "__dev_t", file: !63, line: 145, baseType: !36)
!63 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!64 = !DIDerivedType(tag: DW_TAG_member, name: "st_ino", scope: !58, file: !59, line: 36, baseType: !65, size: 64, offset: 64)
!65 = !DIDerivedType(tag: DW_TAG_typedef, name: "__ino_t", file: !63, line: 148, baseType: !36)
!66 = !DIDerivedType(tag: DW_TAG_member, name: "st_nlink", scope: !58, file: !59, line: 44, baseType: !67, size: 64, offset: 128)
!67 = !DIDerivedType(tag: DW_TAG_typedef, name: "__nlink_t", file: !63, line: 151, baseType: !36)
!68 = !DIDerivedType(tag: DW_TAG_member, name: "st_mode", scope: !58, file: !59, line: 45, baseType: !69, size: 32, offset: 192)
!69 = !DIDerivedType(tag: DW_TAG_typedef, name: "__mode_t", file: !63, line: 150, baseType: !7)
!70 = !DIDerivedType(tag: DW_TAG_member, name: "st_uid", scope: !58, file: !59, line: 47, baseType: !71, size: 32, offset: 224)
!71 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uid_t", file: !63, line: 146, baseType: !7)
!72 = !DIDerivedType(tag: DW_TAG_member, name: "st_gid", scope: !58, file: !59, line: 48, baseType: !73, size: 32, offset: 256)
!73 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gid_t", file: !63, line: 147, baseType: !7)
!74 = !DIDerivedType(tag: DW_TAG_member, name: "__pad0", scope: !58, file: !59, line: 50, baseType: !41, size: 32, offset: 288)
!75 = !DIDerivedType(tag: DW_TAG_member, name: "st_rdev", scope: !58, file: !59, line: 52, baseType: !62, size: 64, offset: 320)
!76 = !DIDerivedType(tag: DW_TAG_member, name: "st_size", scope: !58, file: !59, line: 57, baseType: !77, size: 64, offset: 384)
!77 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !63, line: 152, baseType: !78)
!78 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!79 = !DIDerivedType(tag: DW_TAG_member, name: "st_blksize", scope: !58, file: !59, line: 61, baseType: !80, size: 64, offset: 448)
!80 = !DIDerivedType(tag: DW_TAG_typedef, name: "__blksize_t", file: !63, line: 175, baseType: !78)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "st_blocks", scope: !58, file: !59, line: 63, baseType: !82, size: 64, offset: 512)
!82 = !DIDerivedType(tag: DW_TAG_typedef, name: "__blkcnt_t", file: !63, line: 180, baseType: !78)
!83 = !DIDerivedType(tag: DW_TAG_member, name: "st_atim", scope: !58, file: !59, line: 74, baseType: !84, size: 128, offset: 576)
!84 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "timespec", file: !85, line: 11, size: 128, elements: !86)
!85 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h", directory: "", checksumkind: CSK_MD5, checksum: "55dc154df3f21a5aa944dcafba9b43f6")
!86 = !{!87, !89}
!87 = !DIDerivedType(tag: DW_TAG_member, name: "tv_sec", scope: !84, file: !85, line: 16, baseType: !88, size: 64)
!88 = !DIDerivedType(tag: DW_TAG_typedef, name: "__time_t", file: !63, line: 160, baseType: !78)
!89 = !DIDerivedType(tag: DW_TAG_member, name: "tv_nsec", scope: !84, file: !85, line: 21, baseType: !90, size: 64, offset: 64)
!90 = !DIDerivedType(tag: DW_TAG_typedef, name: "__syscall_slong_t", file: !63, line: 197, baseType: !78)
!91 = !DIDerivedType(tag: DW_TAG_member, name: "st_mtim", scope: !58, file: !59, line: 75, baseType: !84, size: 128, offset: 704)
!92 = !DIDerivedType(tag: DW_TAG_member, name: "st_ctim", scope: !58, file: !59, line: 76, baseType: !84, size: 128, offset: 832)
!93 = !DIDerivedType(tag: DW_TAG_member, name: "__glibc_reserved", scope: !58, file: !59, line: 89, baseType: !94, size: 192, offset: 960)
!94 = !DICompositeType(tag: DW_TAG_array_type, baseType: !90, size: 192, elements: !95)
!95 = !{!96}
!96 = !DISubrange(count: 3)
!97 = !DILocalVariable(name: "auth_data", scope: !50, file: !3, line: 33, type: !19)
!98 = !DILocalVariable(name: "auth_entries", scope: !50, file: !3, line: 34, type: !28)
!99 = !DILocalVariable(name: "pwfile", scope: !50, file: !3, line: 36, type: !100)
!100 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !101, size: 64)
!101 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !102, line: 7, baseType: !103)
!102 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!103 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !104, line: 49, size: 1728, elements: !105)
!104 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "7a6d4a00a37ee6b9a40cd04bd01f5d00")
!105 = !{!106, !107, !108, !109, !110, !111, !112, !113, !114, !115, !116, !117, !118, !121, !123, !124, !125, !126, !128, !130, !134, !137, !139, !142, !145, !146, !147, !148, !149}
!106 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !103, file: !104, line: 51, baseType: !41, size: 32)
!107 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !103, file: !104, line: 54, baseType: !19, size: 64, offset: 64)
!108 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !103, file: !104, line: 55, baseType: !19, size: 64, offset: 128)
!109 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !103, file: !104, line: 56, baseType: !19, size: 64, offset: 192)
!110 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !103, file: !104, line: 57, baseType: !19, size: 64, offset: 256)
!111 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !103, file: !104, line: 58, baseType: !19, size: 64, offset: 320)
!112 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !103, file: !104, line: 59, baseType: !19, size: 64, offset: 384)
!113 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !103, file: !104, line: 60, baseType: !19, size: 64, offset: 448)
!114 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !103, file: !104, line: 61, baseType: !19, size: 64, offset: 512)
!115 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !103, file: !104, line: 64, baseType: !19, size: 64, offset: 576)
!116 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !103, file: !104, line: 65, baseType: !19, size: 64, offset: 640)
!117 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !103, file: !104, line: 66, baseType: !19, size: 64, offset: 704)
!118 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !103, file: !104, line: 68, baseType: !119, size: 64, offset: 768)
!119 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !120, size: 64)
!120 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !104, line: 36, flags: DIFlagFwdDecl)
!121 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !103, file: !104, line: 70, baseType: !122, size: 64, offset: 832)
!122 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !103, size: 64)
!123 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !103, file: !104, line: 72, baseType: !41, size: 32, offset: 896)
!124 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !103, file: !104, line: 73, baseType: !41, size: 32, offset: 928)
!125 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !103, file: !104, line: 74, baseType: !77, size: 64, offset: 960)
!126 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !103, file: !104, line: 77, baseType: !127, size: 16, offset: 1024)
!127 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!128 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !103, file: !104, line: 78, baseType: !129, size: 8, offset: 1040)
!129 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!130 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !103, file: !104, line: 79, baseType: !131, size: 8, offset: 1048)
!131 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 8, elements: !132)
!132 = !{!133}
!133 = !DISubrange(count: 1)
!134 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !103, file: !104, line: 81, baseType: !135, size: 64, offset: 1088)
!135 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !136, size: 64)
!136 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !104, line: 43, baseType: null)
!137 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !103, file: !104, line: 89, baseType: !138, size: 64, offset: 1152)
!138 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !63, line: 153, baseType: !78)
!139 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !103, file: !104, line: 91, baseType: !140, size: 64, offset: 1216)
!140 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !141, size: 64)
!141 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !104, line: 37, flags: DIFlagFwdDecl)
!142 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !103, file: !104, line: 92, baseType: !143, size: 64, offset: 1280)
!143 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !144, size: 64)
!144 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !104, line: 38, flags: DIFlagFwdDecl)
!145 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !103, file: !104, line: 93, baseType: !122, size: 64, offset: 1344)
!146 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !103, file: !104, line: 94, baseType: !15, size: 64, offset: 1408)
!147 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !103, file: !104, line: 95, baseType: !34, size: 64, offset: 1472)
!148 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !103, file: !104, line: 96, baseType: !41, size: 32, offset: 1536)
!149 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !103, file: !104, line: 98, baseType: !150, size: 160, offset: 1568)
!150 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 160, elements: !151)
!151 = !{!152}
!152 = !DISubrange(count: 20)
!153 = !DILocalVariable(name: "auth_cur", scope: !50, file: !3, line: 46, type: !19)
!154 = !DILocalVariable(name: "auth_end", scope: !50, file: !3, line: 47, type: !19)
!155 = !DILocalVariable(name: "entry_cur", scope: !50, file: !3, line: 48, type: !156)
!156 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !29, size: 64)
!157 = !DILocalVariable(name: "used", scope: !50, file: !3, line: 49, type: !41)
!158 = !DILocalVariable(name: "x", scope: !159, file: !3, line: 52, type: !41)
!159 = distinct !DILexicalBlock(scope: !50, file: !3, line: 51, column: 122)
!160 = !DILocalVariable(name: "found", scope: !159, file: !3, line: 53, type: !41)
!161 = distinct !DIAssignID()
!162 = !DILocation(line: 0, scope: !50)
!163 = distinct !DIAssignID()
!164 = !DILocation(line: 32, column: 5, scope: !50)
!165 = !DILocation(line: 34, column: 5, scope: !50)
!166 = !DILocation(line: 36, column: 20, scope: !50)
!167 = !DILocation(line: 37, column: 16, scope: !168)
!168 = distinct !DILexicalBlock(scope: !50, file: !3, line: 37, column: 9)
!169 = !DILocation(line: 37, column: 9, scope: !50)
!170 = !DILocation(line: 39, column: 22, scope: !171)
!171 = distinct !DILexicalBlock(scope: !168, file: !3, line: 39, column: 16)
!172 = !DILocation(line: 39, column: 16, scope: !171)
!173 = !DILocation(line: 39, column: 16, scope: !168)
!174 = !DILocation(line: 40, column: 9, scope: !175)
!175 = distinct !DILexicalBlock(scope: !171, file: !3, line: 39, column: 44)
!176 = !DILocation(line: 41, column: 9, scope: !175)
!177 = !DILocation(line: 44, column: 30, scope: !50)
!178 = !{!179, !180, i64 48}
!179 = !{!"stat", !180, i64 0, !180, i64 8, !180, i64 16, !183, i64 24, !183, i64 28, !183, i64 32, !183, i64 36, !180, i64 40, !180, i64 48, !180, i64 56, !180, i64 64, !184, i64 72, !184, i64 88, !184, i64 104, !181, i64 120}
!180 = !{!"long", !181, i64 0}
!181 = !{!"omnipotent char", !182, i64 0}
!182 = !{!"Simple C/C++ TBAA"}
!183 = !{!"int", !181, i64 0}
!184 = !{!"timespec", !180, i64 0, !180, i64 8}
!185 = !DILocation(line: 44, column: 38, scope: !50)
!186 = !DILocation(line: 44, column: 17, scope: !50)
!187 = !DILocation(line: 47, column: 32, scope: !50)
!188 = !DILocation(line: 51, column: 29, scope: !50)
!189 = !DILocation(line: 51, column: 13, scope: !50)
!190 = !DILocation(line: 51, column: 113, scope: !50)
!191 = !DILocation(line: 51, column: 5, scope: !50)
!192 = !DILocation(line: 93, column: 18, scope: !159)
!193 = !DILocation(line: 51, column: 38, scope: !50)
!194 = !DILocation(line: 0, scope: !159)
!195 = !DILocation(line: 55, column: 9, scope: !196)
!196 = distinct !DILexicalBlock(scope: !159, file: !3, line: 55, column: 9)
!197 = !DILocation(line: 0, scope: !198)
!198 = distinct !DILexicalBlock(scope: !199, file: !3, line: 56, column: 17)
!199 = distinct !DILexicalBlock(scope: !200, file: !3, line: 55, column: 45)
!200 = distinct !DILexicalBlock(scope: !196, file: !3, line: 55, column: 9)
!201 = !{!181, !181, i64 0}
!202 = !DILocation(line: 56, column: 17, scope: !199)
!203 = !DILocation(line: 57, column: 21, scope: !204)
!204 = distinct !DILexicalBlock(scope: !198, file: !3, line: 56, column: 25)
!205 = !DILocation(line: 61, column: 37, scope: !206)
!206 = distinct !DILexicalBlock(scope: !207, file: !3, line: 60, column: 48)
!207 = distinct !DILexicalBlock(scope: !208, file: !3, line: 60, column: 28)
!208 = distinct !DILexicalBlock(scope: !204, file: !3, line: 57, column: 21)
!209 = !{!210, !211, i64 0}
!210 = !{!"auth_entry", !211, i64 0, !180, i64 8, !211, i64 16, !180, i64 24}
!211 = !{!"any pointer", !181, i64 0}
!212 = !DILocation(line: 62, column: 37, scope: !206)
!213 = !{!210, !180, i64 8}
!214 = !DILocation(line: 63, column: 50, scope: !206)
!215 = !DILocation(line: 63, column: 40, scope: !206)
!216 = !DILocation(line: 63, column: 37, scope: !206)
!217 = !{!210, !211, i64 16}
!218 = !DILocation(line: 65, column: 17, scope: !206)
!219 = !DILocation(line: 68, column: 41, scope: !220)
!220 = distinct !DILexicalBlock(scope: !221, file: !3, line: 68, column: 21)
!221 = distinct !DILexicalBlock(scope: !198, file: !3, line: 66, column: 20)
!222 = !DILocation(line: 71, column: 55, scope: !223)
!223 = distinct !DILexicalBlock(scope: !220, file: !3, line: 70, column: 42)
!224 = !DILocation(line: 71, column: 60, scope: !223)
!225 = !DILocation(line: 71, column: 41, scope: !223)
!226 = !DILocation(line: 71, column: 32, scope: !223)
!227 = !DILocation(line: 71, column: 37, scope: !223)
!228 = !{!210, !180, i64 24}
!229 = !DILocation(line: 78, column: 13, scope: !159)
!230 = !DILocation(line: 55, column: 41, scope: !200)
!231 = !DILocation(line: 55, column: 23, scope: !200)
!232 = distinct !{!232, !195, !233, !234}
!233 = !DILocation(line: 75, column: 9, scope: !196)
!234 = !{!"llvm.loop.mustprogress"}
!235 = !DILocation(line: 79, column: 19, scope: !236)
!236 = distinct !DILexicalBlock(scope: !237, file: !3, line: 78, column: 21)
!237 = distinct !DILexicalBlock(scope: !159, file: !3, line: 78, column: 13)
!238 = !DILocation(line: 80, column: 13, scope: !236)
!239 = !DILocation(line: 85, column: 13, scope: !240)
!240 = distinct !DILexicalBlock(scope: !159, file: !3, line: 85, column: 13)
!241 = !DILocation(line: 85, column: 20, scope: !240)
!242 = !DILocation(line: 85, column: 13, scope: !159)
!243 = !DILocation(line: 89, column: 13, scope: !244)
!244 = distinct !DILexicalBlock(scope: !159, file: !3, line: 89, column: 13)
!245 = !DILocation(line: 89, column: 25, scope: !244)
!246 = !DILocation(line: 89, column: 13, scope: !159)
!247 = !DILocation(line: 98, column: 9, scope: !248)
!248 = distinct !DILexicalBlock(scope: !50, file: !3, line: 98, column: 9)
!249 = !{!211, !211, i64 0}
!250 = !DILocation(line: 98, column: 24, scope: !248)
!251 = !DILocation(line: 98, column: 9, scope: !50)
!252 = !DILocation(line: 99, column: 9, scope: !253)
!253 = distinct !DILexicalBlock(scope: !248, file: !3, line: 98, column: 33)
!254 = !DILocation(line: 100, column: 5, scope: !253)
!255 = !DILocation(line: 102, column: 15, scope: !50)
!256 = !{!183, !183, i64 0}
!257 = !DILocation(line: 103, column: 20, scope: !50)
!258 = !DILocation(line: 104, column: 5, scope: !50)
!259 = !DILocation(line: 106, column: 11, scope: !50)
!260 = !DILocation(line: 108, column: 5, scope: !50)
!261 = !DILocation(line: 109, column: 1, scope: !50)
!262 = !DISubprogram(name: "fopen", scope: !263, file: !263, line: 264, type: !264, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!263 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "1e435c46987a169d9f9186f63a512303")
!264 = !DISubroutineType(types: !265)
!265 = !{!100, !266, !266}
!266 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !53)
!267 = !DISubprogram(name: "fstat", scope: !268, file: !268, line: 210, type: !269, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!268 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/stat.h", directory: "", checksumkind: CSK_MD5, checksum: "66c5d94e7b5e54481452c91d42ec16bb")
!269 = !DISubroutineType(types: !270)
!270 = !{!41, !41, !271}
!271 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !58, size: 64)
!272 = !DISubprogram(name: "fileno", scope: !263, file: !263, line: 883, type: !273, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!273 = !DISubroutineType(types: !274)
!274 = !{!41, !100}
!275 = !DISubprogram(name: "fclose", scope: !263, file: !263, line: 184, type: !273, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!276 = !DISubprogram(name: "calloc", scope: !277, file: !277, line: 675, type: !278, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!277 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!278 = !DISubroutineType(types: !279)
!279 = !{!15, !34, !34}
!280 = !DISubprogram(name: "fgets", scope: !263, file: !263, line: 654, type: !281, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!281 = !DISubroutineType(types: !282)
!282 = !{!19, !283, !41, !284}
!283 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !19)
!284 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !100)
!285 = !DISubprogram(name: "free", scope: !277, file: !277, line: 687, type: !286, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!286 = !DISubroutineType(types: !287)
!287 = !{null, !15}
!288 = distinct !DISubprogram(name: "authfile_check", scope: !3, file: !3, line: 112, type: !289, scopeLine: 112, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !291)
!289 = !DISubroutineType(types: !290)
!290 = !{!41, !53, !53}
!291 = !{!292, !293, !294, !295, !296, !298}
!292 = !DILocalVariable(name: "user", arg: 1, scope: !288, file: !3, line: 112, type: !53)
!293 = !DILocalVariable(name: "pass", arg: 2, scope: !288, file: !3, line: 112, type: !53)
!294 = !DILocalVariable(name: "ulen", scope: !288, file: !3, line: 113, type: !34)
!295 = !DILocalVariable(name: "plen", scope: !288, file: !3, line: 114, type: !34)
!296 = !DILocalVariable(name: "x", scope: !297, file: !3, line: 116, type: !41)
!297 = distinct !DILexicalBlock(scope: !288, file: !3, line: 116, column: 5)
!298 = !DILocalVariable(name: "e", scope: !299, file: !3, line: 117, type: !156)
!299 = distinct !DILexicalBlock(scope: !300, file: !3, line: 116, column: 41)
!300 = distinct !DILexicalBlock(scope: !297, file: !3, line: 116, column: 5)
!301 = !DILocation(line: 0, scope: !288)
!302 = !DILocation(line: 113, column: 19, scope: !288)
!303 = !DILocation(line: 114, column: 19, scope: !288)
!304 = !DILocation(line: 0, scope: !297)
!305 = !DILocation(line: 116, column: 25, scope: !300)
!306 = !DILocation(line: 116, column: 23, scope: !300)
!307 = !DILocation(line: 116, column: 5, scope: !297)
!308 = !DILocation(line: 117, column: 22, scope: !299)
!309 = !DILocation(line: 0, scope: !299)
!310 = !DILocation(line: 118, column: 24, scope: !311)
!311 = distinct !DILexicalBlock(scope: !299, file: !3, line: 118, column: 13)
!312 = !DILocation(line: 118, column: 18, scope: !311)
!313 = !DILocation(line: 118, column: 29, scope: !311)
!314 = !DILocation(line: 118, column: 43, scope: !311)
!315 = !DILocation(line: 118, column: 37, scope: !311)
!316 = !DILocation(line: 118, column: 48, scope: !311)
!317 = !DILocation(line: 119, column: 34, scope: !311)
!318 = !DILocation(line: 119, column: 13, scope: !311)
!319 = !DILocation(line: 119, column: 49, scope: !311)
!320 = !DILocation(line: 120, column: 34, scope: !311)
!321 = !DILocation(line: 120, column: 43, scope: !311)
!322 = !DILocation(line: 120, column: 13, scope: !311)
!323 = !DILocation(line: 118, column: 13, scope: !299)
!324 = !DILocation(line: 116, column: 37, scope: !300)
!325 = distinct !{!325, !307, !326, !234}
!326 = !DILocation(line: 123, column: 5, scope: !297)
!327 = !DILocation(line: 126, column: 1, scope: !288)
!328 = !DISubprogram(name: "strlen", scope: !329, file: !329, line: 407, type: !330, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!329 = !DIFile(filename: "/usr/include/string.h", directory: "", checksumkind: CSK_MD5, checksum: "165db1185644f68894fa9e0d17055d70")
!330 = !DISubroutineType(types: !331)
!331 = !{!36, !53}
!332 = !DISubprogram(name: "safe_memcmp", scope: !333, file: !333, line: 23, type: !334, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!333 = !DIFile(filename: "./util.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d1ef68c688867746f50aae7567be079a")
!334 = !DISubroutineType(types: !335)
!335 = !{!336, !337, !337, !34}
!336 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!337 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !338, size: 64)
!338 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
