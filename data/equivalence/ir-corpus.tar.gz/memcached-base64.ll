; ModuleID = 'base64.c'
source_filename = "base64.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@base64_table = internal unnamed_addr constant [65 x i8] c"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/\00", align 16, !dbg !0
@dtable = internal unnamed_addr constant [256 x i8] c"\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80>\80\80\80?456789:;<=\80\80\80\00\80\80\80\00\01\02\03\04\05\06\07\08\09\0A\0B\0C\0D\0E\0F\10\11\12\13\14\15\16\17\18\19\80\80\80\80\80\80\1A\1B\1C\1D\1E\1F !\22#$%&'()*+,-./0123\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80\80", align 16, !dbg !7
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nofree norecurse nosync nounwind sanitize_thread memory(readwrite, inaccessiblemem: none) uwtable
define dso_local noundef i64 @base64_encode(ptr noundef %src, i64 noundef %len, ptr noundef %out, i64 noundef %out_len) local_unnamed_addr #0 !dbg !25 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %src, metadata !34, metadata !DIExpression()), !dbg !42
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !35, metadata !DIExpression()), !dbg !42
  tail call void @llvm.dbg.value(metadata ptr %out, metadata !36, metadata !DIExpression()), !dbg !42
  tail call void @llvm.dbg.value(metadata i64 %out_len, metadata !37, metadata !DIExpression()), !dbg !42
  %mul = shl i64 %len, 2, !dbg !43
  %div = udiv i64 %mul, 3, !dbg !44
  %add = add nuw nsw i64 %div, 4, !dbg !45
  tail call void @llvm.dbg.value(metadata i64 %add, metadata !41, metadata !DIExpression()), !dbg !42
  %div1 = udiv i64 %add, 72, !dbg !46
  %add2 = add nuw nsw i64 %div1, %add, !dbg !47
  tail call void @llvm.dbg.value(metadata i64 %add2, metadata !41, metadata !DIExpression()), !dbg !42
  %inc = add nuw nsw i64 %add2, 1, !dbg !48
  tail call void @llvm.dbg.value(metadata i64 %inc, metadata !41, metadata !DIExpression()), !dbg !42
  %cmp = icmp ult i64 %inc, %len, !dbg !49
  %cmp3.not = icmp uge i64 %add2, %out_len
  %or.cond.not128 = or i1 %cmp3.not, %cmp, !dbg !51
  %cmp6 = icmp eq ptr %out, null
  %or.cond127 = or i1 %cmp6, %or.cond.not128, !dbg !51
  br i1 %or.cond127, label %cleanup, label %if.end8, !dbg !51

if.end8:                                          ; preds = %entry
  %add.ptr = getelementptr inbounds i8, ptr %src, i64 %len, !dbg !52
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !39, metadata !DIExpression()), !dbg !42
  tail call void @llvm.dbg.value(metadata ptr %src, metadata !40, metadata !DIExpression()), !dbg !42
  tail call void @llvm.dbg.value(metadata ptr %out, metadata !38, metadata !DIExpression()), !dbg !42
  %sub.ptr.lhs.cast = ptrtoint ptr %add.ptr to i64
  tail call void @llvm.dbg.value(metadata ptr %src, metadata !40, metadata !DIExpression()), !dbg !42
  tail call void @llvm.dbg.value(metadata ptr %out, metadata !38, metadata !DIExpression()), !dbg !42
  %cmp9131 = icmp ugt i64 %len, 2, !dbg !53
  br i1 %cmp9131, label %while.body, label %while.end, !dbg !54

while.body:                                       ; preds = %if.end8, %while.body
  %in.0133 = phi ptr [ %add.ptr36, %while.body ], [ %src, %if.end8 ]
  %pos.0132 = phi ptr [ %incdec.ptr35, %while.body ], [ %out, %if.end8 ]
  tail call void @llvm.dbg.value(metadata ptr %in.0133, metadata !40, metadata !DIExpression()), !dbg !42
  tail call void @llvm.dbg.value(metadata ptr %pos.0132, metadata !38, metadata !DIExpression()), !dbg !42
  %0 = load i8, ptr %in.0133, align 1, !dbg !55, !tbaa !57
  %1 = lshr i8 %0, 2
  %idxprom = zext nneg i8 %1 to i64, !dbg !60
  %arrayidx10 = getelementptr inbounds [65 x i8], ptr @base64_table, i64 0, i64 %idxprom, !dbg !60
  %2 = load i8, ptr %arrayidx10, align 1, !dbg !60, !tbaa !57
  %incdec.ptr = getelementptr inbounds i8, ptr %pos.0132, i64 1, !dbg !61
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !38, metadata !DIExpression()), !dbg !42
  store i8 %2, ptr %pos.0132, align 1, !dbg !62, !tbaa !57
  %3 = load i8, ptr %in.0133, align 1, !dbg !63, !tbaa !57
  %4 = shl i8 %3, 4, !dbg !64
  %5 = and i8 %4, 48, !dbg !64
  %arrayidx13 = getelementptr inbounds i8, ptr %in.0133, i64 1, !dbg !65
  %6 = load i8, ptr %arrayidx13, align 1, !dbg !65, !tbaa !57
  %7 = lshr i8 %6, 4
  %or125 = or disjoint i8 %5, %7, !dbg !66
  %idxprom16 = zext nneg i8 %or125 to i64
  %arrayidx17 = getelementptr inbounds [65 x i8], ptr @base64_table, i64 0, i64 %idxprom16, !dbg !67
  %8 = load i8, ptr %arrayidx17, align 1, !dbg !67, !tbaa !57
  %incdec.ptr18 = getelementptr inbounds i8, ptr %pos.0132, i64 2, !dbg !68
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr18, metadata !38, metadata !DIExpression()), !dbg !42
  store i8 %8, ptr %incdec.ptr, align 1, !dbg !69, !tbaa !57
  %9 = load i8, ptr %arrayidx13, align 1, !dbg !70, !tbaa !57
  %10 = shl i8 %9, 2, !dbg !71
  %11 = and i8 %10, 60, !dbg !71
  %arrayidx23 = getelementptr inbounds i8, ptr %in.0133, i64 2, !dbg !72
  %12 = load i8, ptr %arrayidx23, align 1, !dbg !72, !tbaa !57
  %13 = lshr i8 %12, 6
  %or26126 = or disjoint i8 %11, %13, !dbg !73
  %idxprom27 = zext nneg i8 %or26126 to i64
  %arrayidx28 = getelementptr inbounds [65 x i8], ptr @base64_table, i64 0, i64 %idxprom27, !dbg !74
  %14 = load i8, ptr %arrayidx28, align 1, !dbg !74, !tbaa !57
  %incdec.ptr29 = getelementptr inbounds i8, ptr %pos.0132, i64 3, !dbg !75
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr29, metadata !38, metadata !DIExpression()), !dbg !42
  store i8 %14, ptr %incdec.ptr18, align 1, !dbg !76, !tbaa !57
  %15 = load i8, ptr %arrayidx23, align 1, !dbg !77, !tbaa !57
  %16 = and i8 %15, 63, !dbg !78
  %idxprom33 = zext nneg i8 %16 to i64
  %arrayidx34 = getelementptr inbounds [65 x i8], ptr @base64_table, i64 0, i64 %idxprom33, !dbg !79
  %17 = load i8, ptr %arrayidx34, align 1, !dbg !79, !tbaa !57
  %incdec.ptr35 = getelementptr inbounds i8, ptr %pos.0132, i64 4, !dbg !80
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr35, metadata !38, metadata !DIExpression()), !dbg !42
  store i8 %17, ptr %incdec.ptr29, align 1, !dbg !81, !tbaa !57
  %add.ptr36 = getelementptr inbounds i8, ptr %in.0133, i64 3, !dbg !82
  tail call void @llvm.dbg.value(metadata ptr %add.ptr36, metadata !40, metadata !DIExpression()), !dbg !42
  %sub.ptr.rhs.cast = ptrtoint ptr %add.ptr36 to i64, !dbg !83
  %sub.ptr.sub = sub i64 %sub.ptr.lhs.cast, %sub.ptr.rhs.cast, !dbg !83
  %cmp9 = icmp sgt i64 %sub.ptr.sub, 2, !dbg !53
  br i1 %cmp9, label %while.body, label %while.end, !dbg !54, !llvm.loop !84

while.end:                                        ; preds = %while.body, %if.end8
  %pos.0.lcssa = phi ptr [ %out, %if.end8 ], [ %incdec.ptr35, %while.body ], !dbg !42
  %in.0.lcssa = phi ptr [ %src, %if.end8 ], [ %add.ptr36, %while.body ], !dbg !42
  %sub.ptr.sub.lcssa = phi i64 [ %len, %if.end8 ], [ %sub.ptr.sub, %while.body ], !dbg !83
  %tobool.not = icmp eq ptr %add.ptr, %in.0.lcssa, !dbg !87
  br i1 %tobool.not, label %if.end81, label %if.then40, !dbg !89

if.then40:                                        ; preds = %while.end
  %18 = load i8, ptr %in.0.lcssa, align 1, !dbg !90, !tbaa !57
  %19 = lshr i8 %18, 2
  %idxprom44 = zext nneg i8 %19 to i64, !dbg !92
  %arrayidx45 = getelementptr inbounds [65 x i8], ptr @base64_table, i64 0, i64 %idxprom44, !dbg !92
  %20 = load i8, ptr %arrayidx45, align 1, !dbg !92, !tbaa !57
  %incdec.ptr46 = getelementptr inbounds i8, ptr %pos.0.lcssa, i64 1, !dbg !93
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr46, metadata !38, metadata !DIExpression()), !dbg !42
  store i8 %20, ptr %pos.0.lcssa, align 1, !dbg !94, !tbaa !57
  %cmp50 = icmp eq i64 %sub.ptr.sub.lcssa, 1, !dbg !95
  %21 = load i8, ptr %in.0.lcssa, align 1, !dbg !97, !tbaa !57
  %22 = shl i8 %21, 4, !dbg !97
  %23 = and i8 %22, 48, !dbg !97
  br i1 %cmp50, label %if.then52, label %if.else, !dbg !98

if.then52:                                        ; preds = %if.then40
  %idxprom57 = zext nneg i8 %23 to i64
  %arrayidx58 = getelementptr inbounds [65 x i8], ptr @base64_table, i64 0, i64 %idxprom57, !dbg !99
  %24 = load i8, ptr %arrayidx58, align 16, !dbg !99, !tbaa !57
  tail call void @llvm.dbg.value(metadata ptr %32, metadata !38, metadata !DIExpression()), !dbg !42
  store i8 %24, ptr %incdec.ptr46, align 1, !dbg !101, !tbaa !57
  tail call void @llvm.dbg.value(metadata ptr %pos.0.lcssa, metadata !38, metadata !DIExpression(DW_OP_plus_uconst, 3, DW_OP_stack_value)), !dbg !42
  br label %if.end79, !dbg !102

if.else:                                          ; preds = %if.then40
  %arrayidx65 = getelementptr inbounds i8, ptr %in.0.lcssa, i64 1, !dbg !103
  %25 = load i8, ptr %arrayidx65, align 1, !dbg !103, !tbaa !57
  %26 = lshr i8 %25, 4
  %or68124 = or disjoint i8 %23, %26, !dbg !105
  %idxprom69 = zext nneg i8 %or68124 to i64
  %arrayidx70 = getelementptr inbounds [65 x i8], ptr @base64_table, i64 0, i64 %idxprom69, !dbg !106
  %27 = load i8, ptr %arrayidx70, align 1, !dbg !106, !tbaa !57
  tail call void @llvm.dbg.value(metadata ptr %32, metadata !38, metadata !DIExpression()), !dbg !42
  store i8 %27, ptr %incdec.ptr46, align 1, !dbg !107, !tbaa !57
  %28 = load i8, ptr %arrayidx65, align 1, !dbg !108, !tbaa !57
  %29 = shl i8 %28, 2, !dbg !109
  %30 = and i8 %29, 60, !dbg !109
  %idxprom76 = zext nneg i8 %30 to i64
  %arrayidx77 = getelementptr inbounds [65 x i8], ptr @base64_table, i64 0, i64 %idxprom76, !dbg !110
  %31 = load i8, ptr %arrayidx77, align 4, !dbg !110, !tbaa !57
  tail call void @llvm.dbg.value(metadata ptr %pos.0.lcssa, metadata !38, metadata !DIExpression(DW_OP_plus_uconst, 3, DW_OP_stack_value)), !dbg !42
  br label %if.end79

if.end79:                                         ; preds = %if.else, %if.then52
  %.sink = phi i8 [ 61, %if.then52 ], [ %31, %if.else ], !dbg !97
  %32 = getelementptr inbounds i8, ptr %pos.0.lcssa, i64 2, !dbg !97
  store i8 %.sink, ptr %32, align 1, !dbg !97
  %pos.1 = getelementptr inbounds i8, ptr %pos.0.lcssa, i64 3, !dbg !97
  tail call void @llvm.dbg.value(metadata ptr %pos.1, metadata !38, metadata !DIExpression()), !dbg !42
  %incdec.ptr80 = getelementptr inbounds i8, ptr %pos.0.lcssa, i64 4, !dbg !111
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr80, metadata !38, metadata !DIExpression()), !dbg !42
  store i8 61, ptr %pos.1, align 1, !dbg !112, !tbaa !57
  br label %if.end81, !dbg !113

if.end81:                                         ; preds = %if.end79, %while.end
  %pos.2 = phi ptr [ %incdec.ptr80, %if.end79 ], [ %pos.0.lcssa, %while.end ], !dbg !42
  tail call void @llvm.dbg.value(metadata ptr %pos.2, metadata !38, metadata !DIExpression()), !dbg !42
  store i8 0, ptr %pos.2, align 1, !dbg !114, !tbaa !57
  %sub.ptr.lhs.cast82 = ptrtoint ptr %pos.2 to i64, !dbg !115
  %sub.ptr.rhs.cast83 = ptrtoint ptr %out to i64, !dbg !115
  %sub.ptr.sub84 = sub i64 %sub.ptr.lhs.cast82, %sub.ptr.rhs.cast83, !dbg !115
  br label %cleanup, !dbg !116

cleanup:                                          ; preds = %entry, %if.end81
  %retval.0 = phi i64 [ %sub.ptr.sub84, %if.end81 ], [ 0, %entry ], !dbg !42
  ret i64 %retval.0, !dbg !117
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nofree norecurse nosync nounwind sanitize_thread memory(write, argmem: readwrite, inaccessiblemem: none) uwtable
define dso_local i64 @base64_decode(ptr nocapture noundef readonly %src, i64 noundef %len, ptr noundef %out, i64 noundef %out_len) local_unnamed_addr #2 !dbg !118 {
entry:
  %block = alloca [4 x i8], align 1, !DIAssignID !135
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !125, metadata !DIExpression(), metadata !135, metadata ptr %block, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata ptr %src, metadata !120, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %len, metadata !121, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata ptr %out, metadata !122, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %out_len, metadata !123, metadata !DIExpression()), !dbg !136
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %block) #5, !dbg !137
  tail call void @llvm.dbg.value(metadata i32 0, metadata !133, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 0, metadata !131, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 0, metadata !130, metadata !DIExpression()), !dbg !136
  %cmp116.not = icmp eq i64 %len, 0, !dbg !138
  br i1 %cmp116.not, label %cleanup, label %for.body.preheader, !dbg !141

for.body.preheader:                               ; preds = %entry
  %xtraiter = and i64 %len, 3, !dbg !141
  %0 = icmp ult i64 %len, 4, !dbg !141
  br i1 %0, label %for.end.unr-lcssa, label %for.body.preheader.new, !dbg !141

for.body.preheader.new:                           ; preds = %for.body.preheader
  %unroll_iter = and i64 %len, -4, !dbg !141
  br label %for.body, !dbg !141

for.body:                                         ; preds = %for.body, %for.body.preheader.new
  %count.0118 = phi i64 [ 0, %for.body.preheader.new ], [ %spec.select.3, %for.body ]
  %i.0117 = phi i64 [ 0, %for.body.preheader.new ], [ %inc4.3, %for.body ]
  %niter = phi i64 [ 0, %for.body.preheader.new ], [ %niter.next.3, %for.body ]
  tail call void @llvm.dbg.value(metadata i64 %count.0118, metadata !131, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %i.0117, metadata !130, metadata !DIExpression()), !dbg !136
  %arrayidx = getelementptr inbounds i8, ptr %src, i64 %i.0117, !dbg !142
  %1 = load i8, ptr %arrayidx, align 1, !dbg !142, !tbaa !57
  %idxprom = zext i8 %1 to i64, !dbg !145
  %arrayidx1 = getelementptr inbounds [256 x i8], ptr @dtable, i64 0, i64 %idxprom, !dbg !145
  %2 = load i8, ptr %arrayidx1, align 1, !dbg !145, !tbaa !57
  %cmp2.not = icmp ne i8 %2, -128, !dbg !146
  %inc = zext i1 %cmp2.not to i64, !dbg !147
  %spec.select = add i64 %count.0118, %inc, !dbg !147
  tail call void @llvm.dbg.value(metadata i64 %spec.select, metadata !131, metadata !DIExpression()), !dbg !136
  %inc4 = or disjoint i64 %i.0117, 1, !dbg !148
  tail call void @llvm.dbg.value(metadata i64 %inc4, metadata !130, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %spec.select, metadata !131, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %inc4, metadata !130, metadata !DIExpression()), !dbg !136
  %arrayidx.1 = getelementptr inbounds i8, ptr %src, i64 %inc4, !dbg !142
  %3 = load i8, ptr %arrayidx.1, align 1, !dbg !142, !tbaa !57
  %idxprom.1 = zext i8 %3 to i64, !dbg !145
  %arrayidx1.1 = getelementptr inbounds [256 x i8], ptr @dtable, i64 0, i64 %idxprom.1, !dbg !145
  %4 = load i8, ptr %arrayidx1.1, align 1, !dbg !145, !tbaa !57
  %cmp2.not.1 = icmp ne i8 %4, -128, !dbg !146
  %inc.1 = zext i1 %cmp2.not.1 to i64, !dbg !147
  %spec.select.1 = add i64 %spec.select, %inc.1, !dbg !147
  tail call void @llvm.dbg.value(metadata i64 %spec.select.1, metadata !131, metadata !DIExpression()), !dbg !136
  %inc4.1 = or disjoint i64 %i.0117, 2, !dbg !148
  tail call void @llvm.dbg.value(metadata i64 %inc4.1, metadata !130, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %spec.select.1, metadata !131, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %inc4.1, metadata !130, metadata !DIExpression()), !dbg !136
  %arrayidx.2 = getelementptr inbounds i8, ptr %src, i64 %inc4.1, !dbg !142
  %5 = load i8, ptr %arrayidx.2, align 1, !dbg !142, !tbaa !57
  %idxprom.2 = zext i8 %5 to i64, !dbg !145
  %arrayidx1.2 = getelementptr inbounds [256 x i8], ptr @dtable, i64 0, i64 %idxprom.2, !dbg !145
  %6 = load i8, ptr %arrayidx1.2, align 1, !dbg !145, !tbaa !57
  %cmp2.not.2 = icmp ne i8 %6, -128, !dbg !146
  %inc.2 = zext i1 %cmp2.not.2 to i64, !dbg !147
  %spec.select.2 = add i64 %spec.select.1, %inc.2, !dbg !147
  tail call void @llvm.dbg.value(metadata i64 %spec.select.2, metadata !131, metadata !DIExpression()), !dbg !136
  %inc4.2 = or disjoint i64 %i.0117, 3, !dbg !148
  tail call void @llvm.dbg.value(metadata i64 %inc4.2, metadata !130, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %spec.select.2, metadata !131, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %inc4.2, metadata !130, metadata !DIExpression()), !dbg !136
  %arrayidx.3 = getelementptr inbounds i8, ptr %src, i64 %inc4.2, !dbg !142
  %7 = load i8, ptr %arrayidx.3, align 1, !dbg !142, !tbaa !57
  %idxprom.3 = zext i8 %7 to i64, !dbg !145
  %arrayidx1.3 = getelementptr inbounds [256 x i8], ptr @dtable, i64 0, i64 %idxprom.3, !dbg !145
  %8 = load i8, ptr %arrayidx1.3, align 1, !dbg !145, !tbaa !57
  %cmp2.not.3 = icmp ne i8 %8, -128, !dbg !146
  %inc.3 = zext i1 %cmp2.not.3 to i64, !dbg !147
  %spec.select.3 = add i64 %spec.select.2, %inc.3, !dbg !147
  tail call void @llvm.dbg.value(metadata i64 %spec.select.3, metadata !131, metadata !DIExpression()), !dbg !136
  %inc4.3 = add nuw i64 %i.0117, 4, !dbg !148
  tail call void @llvm.dbg.value(metadata i64 %inc4.3, metadata !130, metadata !DIExpression()), !dbg !136
  %niter.next.3 = add i64 %niter, 4, !dbg !141
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter, !dbg !141
  br i1 %niter.ncmp.3, label %for.end.unr-lcssa, label %for.body, !dbg !141, !llvm.loop !149

for.end.unr-lcssa:                                ; preds = %for.body, %for.body.preheader
  %spec.select.lcssa.ph = phi i64 [ undef, %for.body.preheader ], [ %spec.select.3, %for.body ]
  %count.0118.unr = phi i64 [ 0, %for.body.preheader ], [ %spec.select.3, %for.body ]
  %i.0117.unr = phi i64 [ 0, %for.body.preheader ], [ %inc4.3, %for.body ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0, !dbg !141
  br i1 %lcmp.mod.not, label %for.end, label %for.body.epil, !dbg !141

for.body.epil:                                    ; preds = %for.end.unr-lcssa, %for.body.epil
  %count.0118.epil = phi i64 [ %spec.select.epil, %for.body.epil ], [ %count.0118.unr, %for.end.unr-lcssa ]
  %i.0117.epil = phi i64 [ %inc4.epil, %for.body.epil ], [ %i.0117.unr, %for.end.unr-lcssa ]
  %epil.iter = phi i64 [ %epil.iter.next, %for.body.epil ], [ 0, %for.end.unr-lcssa ]
  tail call void @llvm.dbg.value(metadata i64 %count.0118.epil, metadata !131, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %i.0117.epil, metadata !130, metadata !DIExpression()), !dbg !136
  %arrayidx.epil = getelementptr inbounds i8, ptr %src, i64 %i.0117.epil, !dbg !142
  %9 = load i8, ptr %arrayidx.epil, align 1, !dbg !142, !tbaa !57
  %idxprom.epil = zext i8 %9 to i64, !dbg !145
  %arrayidx1.epil = getelementptr inbounds [256 x i8], ptr @dtable, i64 0, i64 %idxprom.epil, !dbg !145
  %10 = load i8, ptr %arrayidx1.epil, align 1, !dbg !145, !tbaa !57
  %cmp2.not.epil = icmp ne i8 %10, -128, !dbg !146
  %inc.epil = zext i1 %cmp2.not.epil to i64, !dbg !147
  %spec.select.epil = add i64 %count.0118.epil, %inc.epil, !dbg !147
  tail call void @llvm.dbg.value(metadata i64 %spec.select.epil, metadata !131, metadata !DIExpression()), !dbg !136
  %inc4.epil = add nuw i64 %i.0117.epil, 1, !dbg !148
  tail call void @llvm.dbg.value(metadata i64 %inc4.epil, metadata !130, metadata !DIExpression()), !dbg !136
  %epil.iter.next = add i64 %epil.iter, 1, !dbg !141
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter, !dbg !141
  br i1 %epil.iter.cmp.not, label %for.end, label %for.body.epil, !dbg !141, !llvm.loop !151

for.end:                                          ; preds = %for.body.epil, %for.end.unr-lcssa
  %spec.select.lcssa = phi i64 [ %spec.select.lcssa.ph, %for.end.unr-lcssa ], [ %spec.select.epil, %for.body.epil ], !dbg !147
  %cmp5 = icmp ne i64 %spec.select.lcssa, 0, !dbg !153
  %rem = and i64 %spec.select.lcssa, 3
  %tobool.not = icmp eq i64 %rem, 0
  %or.cond = and i1 %cmp5, %tobool.not, !dbg !155
  br i1 %or.cond, label %if.end8, label %cleanup, !dbg !155

if.end8:                                          ; preds = %for.end
  %div112 = lshr exact i64 %spec.select.lcssa, 2, !dbg !156
  %mul = mul nuw i64 %div112, 3, !dbg !157
  tail call void @llvm.dbg.value(metadata i64 %mul, metadata !132, metadata !DIExpression()), !dbg !136
  %cmp9 = icmp ugt i64 %mul, %out_len, !dbg !158
  tail call void @llvm.dbg.value(metadata ptr %out, metadata !124, metadata !DIExpression()), !dbg !136
  %cmp13 = icmp eq ptr %out, null
  %or.cond114 = or i1 %cmp13, %cmp9, !dbg !160
  br i1 %or.cond114, label %cleanup, label %for.body20.lr.ph, !dbg !160

for.body20.lr.ph:                                 ; preds = %if.end8
  tail call void @llvm.dbg.value(metadata i32 0, metadata !133, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 0, metadata !131, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 0, metadata !130, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata ptr %out, metadata !124, metadata !DIExpression()), !dbg !136
  %arrayidx43 = getelementptr inbounds i8, ptr %block, i64 1
  %arrayidx49 = getelementptr inbounds i8, ptr %block, i64 2
  %arrayidx58 = getelementptr inbounds i8, ptr %block, i64 3
  br label %for.body20, !dbg !161

for.body20:                                       ; preds = %for.body20.lr.ph, %for.inc77
  %pad.0126 = phi i32 [ 0, %for.body20.lr.ph ], [ %pad.2, %for.inc77 ]
  %count.2125 = phi i64 [ 0, %for.body20.lr.ph ], [ %count.3, %for.inc77 ]
  %i.1124 = phi i64 [ 0, %for.body20.lr.ph ], [ %inc78, %for.inc77 ]
  %pos.0123 = phi ptr [ %out, %for.body20.lr.ph ], [ %pos.1, %for.inc77 ]
  tail call void @llvm.dbg.value(metadata i32 %pad.0126, metadata !133, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %count.2125, metadata !131, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %i.1124, metadata !130, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata ptr %pos.0123, metadata !124, metadata !DIExpression()), !dbg !136
  %arrayidx21 = getelementptr inbounds i8, ptr %src, i64 %i.1124, !dbg !163
  %11 = load i8, ptr %arrayidx21, align 1, !dbg !163, !tbaa !57
  %idxprom22 = zext i8 %11 to i64, !dbg !166
  %arrayidx23 = getelementptr inbounds [256 x i8], ptr @dtable, i64 0, i64 %idxprom22, !dbg !166
  %12 = load i8, ptr %arrayidx23, align 1, !dbg !166, !tbaa !57
  tail call void @llvm.dbg.value(metadata i8 %12, metadata !129, metadata !DIExpression()), !dbg !136
  %cmp25 = icmp eq i8 %12, -128, !dbg !167
  br i1 %cmp25, label %for.inc77, label %if.end28, !dbg !169

if.end28:                                         ; preds = %for.body20
  %cmp31 = icmp eq i8 %11, 61, !dbg !170
  %inc34 = zext i1 %cmp31 to i32, !dbg !172
  %spec.select113 = add nsw i32 %pad.0126, %inc34, !dbg !172
  tail call void @llvm.dbg.value(metadata i32 %spec.select113, metadata !133, metadata !DIExpression()), !dbg !136
  %arrayidx36 = getelementptr inbounds [4 x i8], ptr %block, i64 0, i64 %count.2125, !dbg !173
  store i8 %12, ptr %arrayidx36, align 1, !dbg !174, !tbaa !57
  %inc37 = add i64 %count.2125, 1, !dbg !175
  tail call void @llvm.dbg.value(metadata i64 %inc37, metadata !131, metadata !DIExpression()), !dbg !136
  %cmp38 = icmp eq i64 %inc37, 4, !dbg !176
  br i1 %cmp38, label %if.then40, label %for.inc77, !dbg !178

if.then40:                                        ; preds = %if.end28
  %13 = load i8, ptr %block, align 1, !dbg !179, !tbaa !57
  %shl = shl i8 %13, 2, !dbg !181
  %14 = load i8, ptr %arrayidx43, align 1, !dbg !182, !tbaa !57
  %15 = lshr i8 %14, 4
  %or = or i8 %15, %shl, !dbg !183
  %incdec.ptr = getelementptr inbounds i8, ptr %pos.0123, i64 1, !dbg !184
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !124, metadata !DIExpression()), !dbg !136
  store i8 %or, ptr %pos.0123, align 1, !dbg !185, !tbaa !57
  %16 = load i8, ptr %arrayidx43, align 1, !dbg !186, !tbaa !57
  %shl48 = shl i8 %16, 4, !dbg !187
  %17 = load i8, ptr %arrayidx49, align 1, !dbg !188, !tbaa !57
  %18 = lshr i8 %17, 2
  %or52 = or i8 %18, %shl48, !dbg !189
  %incdec.ptr54 = getelementptr inbounds i8, ptr %pos.0123, i64 2, !dbg !190
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr54, metadata !124, metadata !DIExpression()), !dbg !136
  store i8 %or52, ptr %incdec.ptr, align 1, !dbg !191, !tbaa !57
  %19 = load i8, ptr %arrayidx49, align 1, !dbg !192, !tbaa !57
  %shl57 = shl i8 %19, 6, !dbg !193
  %20 = load i8, ptr %arrayidx58, align 1, !dbg !194, !tbaa !57
  %or60 = or i8 %shl57, %20, !dbg !195
  %incdec.ptr62 = getelementptr inbounds i8, ptr %pos.0123, i64 3, !dbg !196
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr62, metadata !124, metadata !DIExpression()), !dbg !136
  store i8 %or60, ptr %incdec.ptr54, align 1, !dbg !197, !tbaa !57
  tail call void @llvm.dbg.value(metadata i64 0, metadata !131, metadata !DIExpression()), !dbg !136
  switch i32 %spec.select113, label %cleanup [
    i32 0, label %for.inc77
    i32 1, label %for.end79.loopexit.split.loop.exit119
    i32 2, label %for.end79.loopexit.split.loop.exit
  ], !dbg !198

for.inc77:                                        ; preds = %if.then40, %if.end28, %for.body20
  %pos.1 = phi ptr [ %pos.0123, %for.body20 ], [ %incdec.ptr62, %if.then40 ], [ %pos.0123, %if.end28 ], !dbg !136
  %count.3 = phi i64 [ %count.2125, %for.body20 ], [ 0, %if.then40 ], [ %inc37, %if.end28 ], !dbg !136
  %pad.2 = phi i32 [ %pad.0126, %for.body20 ], [ %spec.select113, %if.then40 ], [ %spec.select113, %if.end28 ], !dbg !136
  tail call void @llvm.dbg.value(metadata i32 %pad.2, metadata !133, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata i64 %count.3, metadata !131, metadata !DIExpression()), !dbg !136
  tail call void @llvm.dbg.value(metadata ptr %pos.1, metadata !124, metadata !DIExpression()), !dbg !136
  %inc78 = add nuw i64 %i.1124, 1, !dbg !199
  tail call void @llvm.dbg.value(metadata i64 %inc78, metadata !130, metadata !DIExpression()), !dbg !136
  %exitcond131.not = icmp eq i64 %inc78, %len, !dbg !200
  br i1 %exitcond131.not, label %for.end79, label %for.body20, !dbg !161, !llvm.loop !201

for.end79.loopexit.split.loop.exit119:            ; preds = %if.then40
  %incdec.ptr54.le = getelementptr inbounds i8, ptr %pos.0123, i64 2
  br label %for.end79, !dbg !203

for.end79.loopexit.split.loop.exit:               ; preds = %if.then40
  %incdec.ptr.le = getelementptr inbounds i8, ptr %pos.0123, i64 1
  br label %for.end79, !dbg !203

for.end79:                                        ; preds = %for.inc77, %for.end79.loopexit.split.loop.exit, %for.end79.loopexit.split.loop.exit119
  %pos.2 = phi ptr [ %incdec.ptr54.le, %for.end79.loopexit.split.loop.exit119 ], [ %incdec.ptr.le, %for.end79.loopexit.split.loop.exit ], [ %pos.1, %for.inc77 ], !dbg !136
  tail call void @llvm.dbg.value(metadata ptr %pos.2, metadata !124, metadata !DIExpression()), !dbg !136
  %sub.ptr.lhs.cast = ptrtoint ptr %pos.2 to i64, !dbg !203
  %sub.ptr.rhs.cast = ptrtoint ptr %out to i64, !dbg !203
  %sub.ptr.sub = sub i64 %sub.ptr.lhs.cast, %sub.ptr.rhs.cast, !dbg !203
  br label %cleanup, !dbg !204

cleanup:                                          ; preds = %if.then40, %entry, %if.end8, %for.end, %for.end79
  %retval.0 = phi i64 [ %sub.ptr.sub, %for.end79 ], [ 0, %for.end ], [ 0, %if.end8 ], [ 0, %entry ], [ 0, %if.then40 ], !dbg !136
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %block) #5, !dbg !205
  ret i64 %retval.0, !dbg !205
}

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #3 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #4

attributes #0 = { nofree norecurse nosync nounwind sanitize_thread memory(readwrite, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree norecurse nosync nounwind sanitize_thread memory(write, argmem: readwrite, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nounwind uwtable }
attributes #4 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!17, !18, !19, !20, !21, !22, !23}
!llvm.ident = !{!24}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "base64_table", scope: !2, file: !3, line: 53, type: !14, isLocal: true, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !6, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "base64.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "3f97c459458a4a3531b971206ea6ece0")
!4 = !{!5}
!5 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!6 = !{!0, !7}
!7 = !DIGlobalVariableExpression(var: !8, expr: !DIExpression())
!8 = distinct !DIGlobalVariable(name: "dtable", scope: !2, file: !3, line: 59, type: !9, isLocal: true, isDefinition: true)
!9 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 2048, elements: !12)
!10 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !11)
!11 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!12 = !{!13}
!13 = !DISubrange(count: 256)
!14 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 520, elements: !15)
!15 = !{!16}
!16 = !DISubrange(count: 65)
!17 = !{i32 7, !"Dwarf Version", i32 5}
!18 = !{i32 2, !"Debug Info Version", i32 3}
!19 = !{i32 1, !"wchar_size", i32 4}
!20 = !{i32 8, !"PIC Level", i32 2}
!21 = !{i32 7, !"PIE Level", i32 2}
!22 = !{i32 7, !"uwtable", i32 2}
!23 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!24 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!25 = distinct !DISubprogram(name: "base64_encode", scope: !3, file: !3, line: 93, type: !26, scopeLine: 95, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !33)
!26 = !DISubroutineType(types: !27)
!27 = !{!28, !31, !28, !32, !28}
!28 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !29, line: 18, baseType: !30)
!29 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!30 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!31 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !10, size: 64)
!32 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64)
!33 = !{!34, !35, !36, !37, !38, !39, !40, !41}
!34 = !DILocalVariable(name: "src", arg: 1, scope: !25, file: !3, line: 93, type: !31)
!35 = !DILocalVariable(name: "len", arg: 2, scope: !25, file: !3, line: 93, type: !28)
!36 = !DILocalVariable(name: "out", arg: 3, scope: !25, file: !3, line: 94, type: !32)
!37 = !DILocalVariable(name: "out_len", arg: 4, scope: !25, file: !3, line: 94, type: !28)
!38 = !DILocalVariable(name: "pos", scope: !25, file: !3, line: 96, type: !32)
!39 = !DILocalVariable(name: "end", scope: !25, file: !3, line: 97, type: !31)
!40 = !DILocalVariable(name: "in", scope: !25, file: !3, line: 97, type: !31)
!41 = !DILocalVariable(name: "olen", scope: !25, file: !3, line: 98, type: !28)
!42 = !DILocation(line: 0, scope: !25)
!43 = !DILocation(line: 100, column: 16, scope: !25)
!44 = !DILocation(line: 100, column: 20, scope: !25)
!45 = !DILocation(line: 100, column: 24, scope: !25)
!46 = !DILocation(line: 101, column: 18, scope: !25)
!47 = !DILocation(line: 101, column: 10, scope: !25)
!48 = !DILocation(line: 102, column: 9, scope: !25)
!49 = !DILocation(line: 103, column: 14, scope: !50)
!50 = distinct !DILexicalBlock(scope: !25, file: !3, line: 103, column: 9)
!51 = !DILocation(line: 103, column: 9, scope: !25)
!52 = !DILocation(line: 113, column: 15, scope: !25)
!53 = !DILocation(line: 116, column: 21, scope: !25)
!54 = !DILocation(line: 116, column: 5, scope: !25)
!55 = !DILocation(line: 117, column: 31, scope: !56)
!56 = distinct !DILexicalBlock(scope: !25, file: !3, line: 116, column: 27)
!57 = !{!58, !58, i64 0}
!58 = !{!"omnipotent char", !59, i64 0}
!59 = !{!"Simple C/C++ TBAA"}
!60 = !DILocation(line: 117, column: 18, scope: !56)
!61 = !DILocation(line: 117, column: 13, scope: !56)
!62 = !DILocation(line: 117, column: 16, scope: !56)
!63 = !DILocation(line: 118, column: 33, scope: !56)
!64 = !DILocation(line: 118, column: 47, scope: !56)
!65 = !DILocation(line: 118, column: 56, scope: !56)
!66 = !DILocation(line: 118, column: 53, scope: !56)
!67 = !DILocation(line: 118, column: 18, scope: !56)
!68 = !DILocation(line: 118, column: 13, scope: !56)
!69 = !DILocation(line: 118, column: 16, scope: !56)
!70 = !DILocation(line: 119, column: 33, scope: !56)
!71 = !DILocation(line: 119, column: 47, scope: !56)
!72 = !DILocation(line: 119, column: 56, scope: !56)
!73 = !DILocation(line: 119, column: 53, scope: !56)
!74 = !DILocation(line: 119, column: 18, scope: !56)
!75 = !DILocation(line: 119, column: 13, scope: !56)
!76 = !DILocation(line: 119, column: 16, scope: !56)
!77 = !DILocation(line: 120, column: 31, scope: !56)
!78 = !DILocation(line: 120, column: 37, scope: !56)
!79 = !DILocation(line: 120, column: 18, scope: !56)
!80 = !DILocation(line: 120, column: 13, scope: !56)
!81 = !DILocation(line: 120, column: 16, scope: !56)
!82 = !DILocation(line: 121, column: 12, scope: !56)
!83 = !DILocation(line: 116, column: 16, scope: !25)
!84 = distinct !{!84, !54, !85, !86}
!85 = !DILocation(line: 122, column: 5, scope: !25)
!86 = !{!"llvm.loop.mustprogress"}
!87 = !DILocation(line: 124, column: 13, scope: !88)
!88 = distinct !DILexicalBlock(scope: !25, file: !3, line: 124, column: 9)
!89 = !DILocation(line: 124, column: 9, scope: !25)
!90 = !DILocation(line: 125, column: 31, scope: !91)
!91 = distinct !DILexicalBlock(scope: !88, file: !3, line: 124, column: 19)
!92 = !DILocation(line: 125, column: 18, scope: !91)
!93 = !DILocation(line: 125, column: 13, scope: !91)
!94 = !DILocation(line: 125, column: 16, scope: !91)
!95 = !DILocation(line: 126, column: 22, scope: !96)
!96 = distinct !DILexicalBlock(scope: !91, file: !3, line: 126, column: 13)
!97 = !DILocation(line: 0, scope: !96)
!98 = !DILocation(line: 126, column: 13, scope: !91)
!99 = !DILocation(line: 127, column: 22, scope: !100)
!100 = distinct !DILexicalBlock(scope: !96, file: !3, line: 126, column: 28)
!101 = !DILocation(line: 127, column: 20, scope: !100)
!102 = !DILocation(line: 129, column: 9, scope: !100)
!103 = !DILocation(line: 131, column: 28, scope: !104)
!104 = distinct !DILexicalBlock(scope: !96, file: !3, line: 129, column: 16)
!105 = !DILocation(line: 130, column: 57, scope: !104)
!106 = !DILocation(line: 130, column: 22, scope: !104)
!107 = !DILocation(line: 130, column: 20, scope: !104)
!108 = !DILocation(line: 132, column: 36, scope: !104)
!109 = !DILocation(line: 132, column: 50, scope: !104)
!110 = !DILocation(line: 132, column: 22, scope: !104)
!111 = !DILocation(line: 134, column: 13, scope: !91)
!112 = !DILocation(line: 134, column: 16, scope: !91)
!113 = !DILocation(line: 135, column: 5, scope: !91)
!114 = !DILocation(line: 137, column: 10, scope: !25)
!115 = !DILocation(line: 138, column: 16, scope: !25)
!116 = !DILocation(line: 138, column: 5, scope: !25)
!117 = !DILocation(line: 139, column: 1, scope: !25)
!118 = distinct !DISubprogram(name: "base64_decode", scope: !3, file: !3, line: 150, type: !26, scopeLine: 152, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !119)
!119 = !{!120, !121, !122, !123, !124, !125, !129, !130, !131, !132, !133}
!120 = !DILocalVariable(name: "src", arg: 1, scope: !118, file: !3, line: 150, type: !31)
!121 = !DILocalVariable(name: "len", arg: 2, scope: !118, file: !3, line: 150, type: !28)
!122 = !DILocalVariable(name: "out", arg: 3, scope: !118, file: !3, line: 151, type: !32)
!123 = !DILocalVariable(name: "out_len", arg: 4, scope: !118, file: !3, line: 151, type: !28)
!124 = !DILocalVariable(name: "pos", scope: !118, file: !3, line: 153, type: !32)
!125 = !DILocalVariable(name: "block", scope: !118, file: !3, line: 153, type: !126)
!126 = !DICompositeType(tag: DW_TAG_array_type, baseType: !11, size: 32, elements: !127)
!127 = !{!128}
!128 = !DISubrange(count: 4)
!129 = !DILocalVariable(name: "tmp", scope: !118, file: !3, line: 153, type: !11)
!130 = !DILocalVariable(name: "i", scope: !118, file: !3, line: 154, type: !28)
!131 = !DILocalVariable(name: "count", scope: !118, file: !3, line: 154, type: !28)
!132 = !DILocalVariable(name: "olen", scope: !118, file: !3, line: 154, type: !28)
!133 = !DILocalVariable(name: "pad", scope: !118, file: !3, line: 155, type: !134)
!134 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!135 = distinct !DIAssignID()
!136 = !DILocation(line: 0, scope: !118)
!137 = !DILocation(line: 153, column: 5, scope: !118)
!138 = !DILocation(line: 158, column: 19, scope: !139)
!139 = distinct !DILexicalBlock(scope: !140, file: !3, line: 158, column: 5)
!140 = distinct !DILexicalBlock(scope: !118, file: !3, line: 158, column: 5)
!141 = !DILocation(line: 158, column: 5, scope: !140)
!142 = !DILocation(line: 159, column: 20, scope: !143)
!143 = distinct !DILexicalBlock(scope: !144, file: !3, line: 159, column: 13)
!144 = distinct !DILexicalBlock(scope: !139, file: !3, line: 158, column: 31)
!145 = !DILocation(line: 159, column: 13, scope: !143)
!146 = !DILocation(line: 159, column: 28, scope: !143)
!147 = !DILocation(line: 159, column: 13, scope: !144)
!148 = !DILocation(line: 158, column: 27, scope: !139)
!149 = distinct !{!149, !141, !150, !86}
!150 = !DILocation(line: 161, column: 5, scope: !140)
!151 = distinct !{!151, !152}
!152 = !{!"llvm.loop.unroll.disable"}
!153 = !DILocation(line: 163, column: 15, scope: !154)
!154 = distinct !DILexicalBlock(scope: !118, file: !3, line: 163, column: 9)
!155 = !DILocation(line: 163, column: 20, scope: !154)
!156 = !DILocation(line: 166, column: 18, scope: !118)
!157 = !DILocation(line: 166, column: 22, scope: !118)
!158 = !DILocation(line: 167, column: 14, scope: !159)
!159 = distinct !DILexicalBlock(scope: !118, file: !3, line: 167, column: 9)
!160 = !DILocation(line: 167, column: 9, scope: !118)
!161 = !DILocation(line: 176, column: 5, scope: !162)
!162 = distinct !DILexicalBlock(scope: !118, file: !3, line: 176, column: 5)
!163 = !DILocation(line: 177, column: 22, scope: !164)
!164 = distinct !DILexicalBlock(scope: !165, file: !3, line: 176, column: 31)
!165 = distinct !DILexicalBlock(scope: !162, file: !3, line: 176, column: 5)
!166 = !DILocation(line: 177, column: 15, scope: !164)
!167 = !DILocation(line: 178, column: 17, scope: !168)
!168 = distinct !DILexicalBlock(scope: !164, file: !3, line: 178, column: 13)
!169 = !DILocation(line: 178, column: 13, scope: !164)
!170 = !DILocation(line: 181, column: 20, scope: !171)
!171 = distinct !DILexicalBlock(scope: !164, file: !3, line: 181, column: 13)
!172 = !DILocation(line: 181, column: 13, scope: !164)
!173 = !DILocation(line: 183, column: 9, scope: !164)
!174 = !DILocation(line: 183, column: 22, scope: !164)
!175 = !DILocation(line: 184, column: 14, scope: !164)
!176 = !DILocation(line: 185, column: 19, scope: !177)
!177 = distinct !DILexicalBlock(scope: !164, file: !3, line: 185, column: 13)
!178 = !DILocation(line: 185, column: 13, scope: !164)
!179 = !DILocation(line: 186, column: 23, scope: !180)
!180 = distinct !DILexicalBlock(scope: !177, file: !3, line: 185, column: 25)
!181 = !DILocation(line: 186, column: 32, scope: !180)
!182 = !DILocation(line: 186, column: 41, scope: !180)
!183 = !DILocation(line: 186, column: 38, scope: !180)
!184 = !DILocation(line: 186, column: 17, scope: !180)
!185 = !DILocation(line: 186, column: 20, scope: !180)
!186 = !DILocation(line: 187, column: 23, scope: !180)
!187 = !DILocation(line: 187, column: 32, scope: !180)
!188 = !DILocation(line: 187, column: 41, scope: !180)
!189 = !DILocation(line: 187, column: 38, scope: !180)
!190 = !DILocation(line: 187, column: 17, scope: !180)
!191 = !DILocation(line: 187, column: 20, scope: !180)
!192 = !DILocation(line: 188, column: 23, scope: !180)
!193 = !DILocation(line: 188, column: 32, scope: !180)
!194 = !DILocation(line: 188, column: 40, scope: !180)
!195 = !DILocation(line: 188, column: 38, scope: !180)
!196 = !DILocation(line: 188, column: 17, scope: !180)
!197 = !DILocation(line: 188, column: 20, scope: !180)
!198 = !DILocation(line: 190, column: 17, scope: !180)
!199 = !DILocation(line: 176, column: 27, scope: !165)
!200 = !DILocation(line: 176, column: 19, scope: !165)
!201 = distinct !{!201, !161, !202, !86}
!202 = !DILocation(line: 202, column: 5, scope: !162)
!203 = !DILocation(line: 204, column: 16, scope: !118)
!204 = !DILocation(line: 204, column: 5, scope: !118)
!205 = !DILocation(line: 205, column: 1, scope: !118)
