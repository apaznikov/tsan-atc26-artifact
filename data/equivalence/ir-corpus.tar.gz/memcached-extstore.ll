; ModuleID = 'extstore.c'
source_filename = "extstore.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.store_io_thread = type { %union.pthread_mutex_t, %union.pthread_cond_t, ptr, ptr, ptr, i32 }
%union.pthread_mutex_t = type { %struct.__pthread_mutex_s }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i16, i16, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%union.pthread_cond_t = type { %struct.__pthread_cond_s }
%struct.__pthread_cond_s = type { %union.__atomic_wide_counter, %union.__atomic_wide_counter, [2 x i32], [2 x i32], i32, i32, [2 x i32] }
%union.__atomic_wide_counter = type { i64 }
%struct._store_page = type { %union.pthread_mutex_t, i64, i64, i64, i32, i32, i32, i32, i32, i32, i32, i16, i8, i8, i8, ptr, ptr }
%struct.extstore_page_data = type { i64, i64, i32, i32, i8 }
%struct.flock = type { i16, i16, i64, i64, i32 }
%struct.iovec = type { ptr, i64 }
%struct.extstore_stats = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, ptr }

@.str = private unnamed_addr constant [14 x i8] c"unknown error\00", align 1, !dbg !0
@.str.1 = private unnamed_addr constant [41 x i8] c"page_size must be divisible by wbuf_size\00", align 1, !dbg !7
@.str.2 = private unnamed_addr constant [35 x i8] c"wbuf_count must be >= page_buckets\00", align 1, !dbg !12
@.str.3 = private unnamed_addr constant [25 x i8] c"page_buckets must be > 0\00", align 1, !dbg !17
@.str.4 = private unnamed_addr constant [57 x i8] c"page_size and wbuf_size must be divisible by 1024*1024*2\00", align 1, !dbg !22
@.str.5 = private unnamed_addr constant [73 x i8] c"page_count must total to < 65536. Increase page_size or lower path sizes\00", align 1, !dbg !27
@.str.6 = private unnamed_addr constant [25 x i8] c"failed calloc for engine\00", align 1, !dbg !32
@.str.7 = private unnamed_addr constant [20 x i8] c"failed to open file\00", align 1, !dbg !34
@.str.8 = private unnamed_addr constant [10 x i8] c"mc-ext-io\00", align 1, !dbg !39
@.str.9 = private unnamed_addr constant [12 x i8] c"mc-ext-bgio\00", align 1, !dbg !44
@reltable.extstore_err = private unnamed_addr constant [7 x i32] [i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.1 to i64), i64 ptrtoint (ptr @reltable.extstore_err to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.2 to i64), i64 ptrtoint (ptr @reltable.extstore_err to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.3 to i64), i64 ptrtoint (ptr @reltable.extstore_err to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.4 to i64), i64 ptrtoint (ptr @reltable.extstore_err to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.5 to i64), i64 ptrtoint (ptr @reltable.extstore_err to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.6 to i64), i64 ptrtoint (ptr @reltable.extstore_err to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.7 to i64), i64 ptrtoint (ptr @reltable.extstore_err to i64)) to i32)], align 4
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @extstore_get_stats(ptr noundef %ptr, ptr nocapture noundef %st) local_unnamed_addr #0 !dbg !279 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !284, metadata !DIExpression()), !dbg !289
  tail call void @llvm.dbg.value(metadata ptr %st, metadata !285, metadata !DIExpression()), !dbg !289
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !286, metadata !DIExpression()), !dbg !289
  %stats_mutex = getelementptr inbounds i8, ptr %ptr, i64 136, !dbg !290
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats_mutex) #14, !dbg !290
  %stats = getelementptr inbounds i8, ptr %ptr, i64 176, !dbg !291
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(144) %st, ptr noundef nonnull align 8 dereferenceable(144) %stats, i64 144, i1 false), !dbg !292
  %call2 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats_mutex) #14, !dbg !293
  %call3 = tail call i32 @pthread_mutex_lock(ptr noundef %ptr) #14, !dbg !294
  %page_free = getelementptr inbounds i8, ptr %ptr, i64 120, !dbg !295
  %0 = load i32, ptr %page_free, align 8, !dbg !295, !tbaa !296
  %conv = zext i32 %0 to i64, !dbg !305
  %pages_free = getelementptr inbounds i8, ptr %st, i64 40, !dbg !306
  store i64 %conv, ptr %pages_free, align 8, !dbg !307, !tbaa !308
  %page_count = getelementptr inbounds i8, ptr %ptr, i64 116, !dbg !309
  %1 = load i32, ptr %page_count, align 4, !dbg !309, !tbaa !310
  %sub = sub i32 %1, %0, !dbg !311
  %conv5 = zext i32 %sub to i64, !dbg !312
  %pages_used = getelementptr inbounds i8, ptr %st, i64 48, !dbg !313
  store i64 %conv5, ptr %pages_used, align 8, !dbg !314, !tbaa !315
  %call7 = tail call i32 @pthread_mutex_unlock(ptr noundef %ptr) #14, !dbg !316
  %io_queue = getelementptr inbounds i8, ptr %st, i64 128, !dbg !317
  store i64 0, ptr %io_queue, align 8, !dbg !318, !tbaa !319
  tail call void @llvm.dbg.value(metadata i32 0, metadata !287, metadata !DIExpression()), !dbg !320
  %io_threadcount = getelementptr inbounds i8, ptr %ptr, i64 112
  tail call void @llvm.dbg.value(metadata i32 0, metadata !287, metadata !DIExpression()), !dbg !320
  %2 = load i32, ptr %io_threadcount, align 8, !dbg !321, !tbaa !323
  %cmp46.not = icmp eq i32 %2, 0, !dbg !324
  br i1 %cmp46.not, label %for.cond.cleanup, label %for.body.lr.ph, !dbg !325

for.body.lr.ph:                                   ; preds = %entry
  %io_threads = getelementptr inbounds i8, ptr %ptr, i64 64
  br label %for.body, !dbg !325

for.cond.cleanup:                                 ; preds = %for.body, %entry
  %3 = load i64, ptr %pages_used, align 8, !dbg !326, !tbaa !315
  %page_size = getelementptr inbounds i8, ptr %ptr, i64 96, !dbg !327
  %4 = load i64, ptr %page_size, align 8, !dbg !327, !tbaa !328
  %mul = mul i64 %4, %3, !dbg !329
  %bytes_used = getelementptr inbounds i8, ptr %st, i64 112, !dbg !330
  %5 = load i64, ptr %bytes_used, align 8, !dbg !330, !tbaa !331
  %sub22 = sub i64 %mul, %5, !dbg !332
  %bytes_fragmented = getelementptr inbounds i8, ptr %st, i64 120, !dbg !333
  store i64 %sub22, ptr %bytes_fragmented, align 8, !dbg !334, !tbaa !335
  ret void, !dbg !336

for.body:                                         ; preds = %for.body.lr.ph, %for.body
  %indvars.iv = phi i64 [ 0, %for.body.lr.ph ], [ %indvars.iv.next, %for.body ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !287, metadata !DIExpression()), !dbg !320
  %6 = load ptr, ptr %io_threads, align 8, !dbg !337, !tbaa !339
  %arrayidx = getelementptr inbounds %struct.store_io_thread, ptr %6, i64 %indvars.iv, !dbg !340
  %call10 = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx) #14, !dbg !341
  %7 = load ptr, ptr %io_threads, align 8, !dbg !342, !tbaa !339
  %depth = getelementptr inbounds %struct.store_io_thread, ptr %7, i64 %indvars.iv, i32 5, !dbg !343
  %8 = load i32, ptr %depth, align 8, !dbg !343, !tbaa !344
  %conv14 = zext i32 %8 to i64, !dbg !346
  %9 = load i64, ptr %io_queue, align 8, !dbg !347, !tbaa !319
  %add = add i64 %9, %conv14, !dbg !347
  store i64 %add, ptr %io_queue, align 8, !dbg !347, !tbaa !319
  %arrayidx18 = getelementptr inbounds %struct.store_io_thread, ptr %7, i64 %indvars.iv, !dbg !348
  %call20 = tail call i32 @pthread_mutex_unlock(ptr noundef %arrayidx18) #14, !dbg !349
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !350
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !287, metadata !DIExpression()), !dbg !320
  %10 = load i32, ptr %io_threadcount, align 8, !dbg !321, !tbaa !323
  %11 = zext i32 %10 to i64, !dbg !324
  %cmp = icmp ult i64 %indvars.iv.next, %11, !dbg !324
  br i1 %cmp, label %for.body, label %for.cond.cleanup, !dbg !325, !llvm.loop !351
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nounwind
declare !dbg !354 i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #3

; Function Attrs: nounwind
declare !dbg !359 i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @extstore_get_page_data(ptr noundef %ptr, ptr nocapture noundef readonly %st) local_unnamed_addr #0 !dbg !360 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !362, metadata !DIExpression()), !dbg !371
  tail call void @llvm.dbg.value(metadata ptr %st, metadata !363, metadata !DIExpression()), !dbg !371
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !364, metadata !DIExpression()), !dbg !371
  %maint = getelementptr inbounds i8, ptr %ptr, i64 320, !dbg !372
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %maint) #14, !dbg !373
  %page_data = getelementptr inbounds i8, ptr %st, i64 136, !dbg !374
  %0 = load ptr, ptr %page_data, align 8, !dbg !374, !tbaa !375
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !365, metadata !DIExpression()), !dbg !371
  tail call void @llvm.dbg.value(metadata i32 0, metadata !366, metadata !DIExpression()), !dbg !376
  %page_count = getelementptr inbounds i8, ptr %ptr, i64 116
  tail call void @llvm.dbg.value(metadata i32 0, metadata !366, metadata !DIExpression()), !dbg !376
  %1 = load i32, ptr %page_count, align 4, !dbg !377, !tbaa !310
  %cmp84.not = icmp eq i32 %1, 0, !dbg !378
  br i1 %cmp84.not, label %for.cond.cleanup, label %for.body.lr.ph, !dbg !379

for.body.lr.ph:                                   ; preds = %entry
  %pages = getelementptr inbounds i8, ptr %ptr, i64 40
  br label %for.body, !dbg !379

for.cond.cleanup:                                 ; preds = %cleanup, %entry
  %call53 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %maint) #14, !dbg !380
  ret void, !dbg !381

for.body:                                         ; preds = %for.body.lr.ph, %cleanup
  %indvars.iv = phi i64 [ 0, %for.body.lr.ph ], [ %indvars.iv.next, %cleanup ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !366, metadata !DIExpression()), !dbg !376
  %2 = load ptr, ptr %pages, align 8, !dbg !382, !tbaa !383
  %arrayidx = getelementptr inbounds %struct._store_page, ptr %2, i64 %indvars.iv, !dbg !384
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !368, metadata !DIExpression()), !dbg !385
  %call2 = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx) #14, !dbg !386
  %free_bucket = getelementptr inbounds i8, ptr %arrayidx, i64 84, !dbg !387
  %3 = load i32, ptr %free_bucket, align 4, !dbg !387, !tbaa !388
  %id = getelementptr inbounds i8, ptr %arrayidx, i64 92, !dbg !392
  %4 = load i16, ptr %id, align 4, !dbg !392, !tbaa !393
  %idxprom3 = zext i16 %4 to i64, !dbg !394
  %free_bucket5 = getelementptr inbounds %struct.extstore_page_data, ptr %0, i64 %idxprom3, i32 3, !dbg !395
  store i32 %3, ptr %free_bucket5, align 4, !dbg !396, !tbaa !397
  %version = getelementptr inbounds i8, ptr %arrayidx, i64 64, !dbg !399
  %5 = load i32, ptr %version, align 8, !dbg !399, !tbaa !400
  %conv = zext i32 %5 to i64, !dbg !401
  %arrayidx8 = getelementptr inbounds %struct.extstore_page_data, ptr %0, i64 %idxprom3, !dbg !402
  store i64 %conv, ptr %arrayidx8, align 8, !dbg !403, !tbaa !404
  %bytes_used = getelementptr inbounds i8, ptr %arrayidx, i64 48, !dbg !405
  %6 = load i64, ptr %bytes_used, align 8, !dbg !405, !tbaa !406
  %bytes_used13 = getelementptr inbounds %struct.extstore_page_data, ptr %0, i64 %idxprom3, i32 1, !dbg !407
  store i64 %6, ptr %bytes_used13, align 8, !dbg !408, !tbaa !409
  %active = getelementptr inbounds i8, ptr %arrayidx, i64 94, !dbg !410
  %7 = load i8, ptr %active, align 2, !dbg !410, !tbaa !412, !range !413, !noundef !414
  %tobool = trunc nuw i8 %7 to i1, !dbg !410
  br i1 %tobool, label %if.end.thread, label %lor.lhs.false, !dbg !415

if.end.thread:                                    ; preds = %for.body
  %active17 = getelementptr inbounds %struct.extstore_page_data, ptr %0, i64 %idxprom3, i32 4, !dbg !416
  store i8 1, ptr %active17, align 8, !dbg !418, !tbaa !419
  br label %cleanup, !dbg !420

lor.lhs.false:                                    ; preds = %for.body
  %free = getelementptr inbounds i8, ptr %arrayidx, i64 96, !dbg !422
  %8 = load i8, ptr %free, align 8, !dbg !422, !tbaa !423, !range !413, !noundef !414
  %tobool21 = trunc nuw i8 %8 to i1, !dbg !422
  br i1 %tobool21, label %cleanup, label %if.end26, !dbg !424

if.end26:                                         ; preds = %lor.lhs.false
  %obj_count = getelementptr inbounds i8, ptr %arrayidx, i64 40, !dbg !425
  %9 = load i64, ptr %obj_count, align 8, !dbg !425, !tbaa !427
  %cmp27.not = icmp eq i64 %9, 0, !dbg !428
  br i1 %cmp27.not, label %land.lhs.true43, label %land.lhs.true, !dbg !429

land.lhs.true:                                    ; preds = %if.end26
  %closed = getelementptr inbounds i8, ptr %arrayidx, i64 95, !dbg !430
  %10 = load i8, ptr %closed, align 1, !dbg !430, !tbaa !431, !range !413, !noundef !414
  %tobool29 = trunc nuw i8 %10 to i1, !dbg !430
  br i1 %tobool29, label %land.lhs.true43, label %lor.lhs.false39, !dbg !432

lor.lhs.false39:                                  ; preds = %land.lhs.true
  %bucket = getelementptr inbounds i8, ptr %arrayidx, i64 80, !dbg !433
  %11 = load i32, ptr %bucket, align 8, !dbg !433, !tbaa !435
  %bucket34 = getelementptr inbounds %struct.extstore_page_data, ptr %0, i64 %idxprom3, i32 2, !dbg !436
  store i32 %11, ptr %bucket34, align 8, !dbg !437, !tbaa !438
  br label %cleanup

land.lhs.true43:                                  ; preds = %land.lhs.true, %if.end26
  %refcount = getelementptr inbounds i8, ptr %arrayidx, i64 68, !dbg !439
  %12 = load i32, ptr %refcount, align 4, !dbg !439, !tbaa !441
  %cmp44 = icmp eq i32 %12, 0, !dbg !442
  br i1 %cmp44, label %if.then46, label %cleanup, !dbg !443

if.then46:                                        ; preds = %land.lhs.true43
  tail call fastcc void @_free_page(ptr noundef nonnull %ptr, ptr noundef nonnull %arrayidx), !dbg !444
  br label %cleanup, !dbg !446

cleanup:                                          ; preds = %land.lhs.true43, %if.then46, %lor.lhs.false39, %lor.lhs.false, %if.end.thread
  %call49 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #14, !dbg !385
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !447
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !366, metadata !DIExpression()), !dbg !376
  %13 = load i32, ptr %page_count, align 4, !dbg !377, !tbaa !310
  %14 = zext i32 %13 to i64, !dbg !378
  %cmp = icmp ult i64 %indvars.iv.next, %14, !dbg !378
  br i1 %cmp, label %for.body, label %for.cond.cleanup, !dbg !379, !llvm.loop !448
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @_free_page(ptr noundef %e, ptr noundef %p) unnamed_addr #0 !dbg !450 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !454, metadata !DIExpression()), !dbg !458
  tail call void @llvm.dbg.value(metadata ptr %p, metadata !455, metadata !DIExpression()), !dbg !458
  tail call void @llvm.dbg.value(metadata ptr null, metadata !456, metadata !DIExpression()), !dbg !458
  tail call void @llvm.dbg.value(metadata ptr null, metadata !457, metadata !DIExpression()), !dbg !458
  %stats_mutex = getelementptr inbounds i8, ptr %e, i64 136, !dbg !459
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats_mutex) #14, !dbg !459
  %obj_count = getelementptr inbounds i8, ptr %p, i64 40, !dbg !460
  %0 = load i64, ptr %obj_count, align 8, !dbg !460, !tbaa !427
  %objects_used = getelementptr inbounds i8, ptr %e, i64 256, !dbg !461
  %1 = load i64, ptr %objects_used, align 8, !dbg !462, !tbaa !463
  %sub = sub i64 %1, %0, !dbg !462
  store i64 %sub, ptr %objects_used, align 8, !dbg !462, !tbaa !463
  %bytes_used = getelementptr inbounds i8, ptr %p, i64 48, !dbg !464
  %2 = load i64, ptr %bytes_used, align 8, !dbg !464, !tbaa !406
  %bytes_used2 = getelementptr inbounds i8, ptr %e, i64 288, !dbg !465
  %3 = load i64, ptr %bytes_used2, align 8, !dbg !466, !tbaa !467
  %sub3 = sub i64 %3, %2, !dbg !466
  store i64 %sub3, ptr %bytes_used2, align 8, !dbg !466, !tbaa !467
  %page_reclaims = getelementptr inbounds i8, ptr %e, i64 200, !dbg !468
  %4 = load i64, ptr %page_reclaims, align 8, !dbg !469, !tbaa !470
  %inc = add i64 %4, 1, !dbg !469
  store i64 %inc, ptr %page_reclaims, align 8, !dbg !469, !tbaa !470
  %call6 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats_mutex) #14, !dbg !471
  %call7 = tail call i32 @pthread_mutex_lock(ptr noundef %e) #14, !dbg !472
  %page_buckets = getelementptr inbounds i8, ptr %e, i64 80, !dbg !473
  %5 = load ptr, ptr %page_buckets, align 8, !dbg !473, !tbaa !474
  %bucket = getelementptr inbounds i8, ptr %p, i64 80, !dbg !475
  %6 = load i32, ptr %bucket, align 8, !dbg !475, !tbaa !435
  %idxprom = zext i32 %6 to i64, !dbg !476
  %arrayidx = getelementptr inbounds ptr, ptr %5, i64 %idxprom, !dbg !476
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !456, metadata !DIExpression()), !dbg !458
  %tmp.069 = load ptr, ptr %arrayidx, align 8, !dbg !458, !tbaa !477
  %tobool.not70 = icmp eq ptr %tmp.069, null, !dbg !478
  br i1 %tobool.not70, label %while.end, label %while.body.preheader, !dbg !478

while.body.preheader:                             ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr null, metadata !457, metadata !DIExpression()), !dbg !458
  %cmp79 = icmp eq ptr %tmp.069, %p, !dbg !479
  br i1 %cmp79, label %if.then, label %if.end17, !dbg !482

while.body:                                       ; preds = %if.end17
  tail call void @llvm.dbg.value(metadata ptr %tmp.07280, metadata !457, metadata !DIExpression()), !dbg !458
  %cmp = icmp eq ptr %tmp.0, %p, !dbg !479
  br i1 %cmp, label %if.then, label %if.end17, !dbg !482, !llvm.loop !483

if.then:                                          ; preds = %while.body, %while.body.preheader
  %tmp.072.lcssa = phi ptr [ %tmp.069, %while.body.preheader ], [ %tmp.0, %while.body ]
  %prev.071.lcssa = phi ptr [ null, %while.body.preheader ], [ %tmp.07280, %while.body ]
  %tobool8.not = icmp eq ptr %prev.071.lcssa, null, !dbg !485
  %next11 = getelementptr inbounds i8, ptr %tmp.072.lcssa, i64 112, !dbg !488
  %7 = load ptr, ptr %next11, align 8, !dbg !488, !tbaa !489
  %next10 = getelementptr inbounds i8, ptr %prev.071.lcssa, i64 112, !dbg !490
  %arrayidx.sink = select i1 %tobool8.not, ptr %arrayidx, ptr %next10, !dbg !490
  store ptr %7, ptr %arrayidx.sink, align 8, !dbg !488, !tbaa !477
  %next16 = getelementptr inbounds i8, ptr %tmp.072.lcssa, i64 112, !dbg !491
  store ptr null, ptr %next16, align 8, !dbg !492, !tbaa !489
  br label %while.end, !dbg !493

if.end17:                                         ; preds = %while.body.preheader, %while.body
  %tmp.07280 = phi ptr [ %tmp.0, %while.body ], [ %tmp.069, %while.body.preheader ]
  tail call void @llvm.dbg.value(metadata ptr %tmp.07280, metadata !457, metadata !DIExpression()), !dbg !458
  %next18 = getelementptr inbounds i8, ptr %tmp.07280, i64 112, !dbg !494
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !456, metadata !DIExpression()), !dbg !458
  %tmp.0 = load ptr, ptr %next18, align 8, !dbg !458, !tbaa !477
  tail call void @llvm.dbg.value(metadata ptr %tmp.0, metadata !456, metadata !DIExpression()), !dbg !458
  %tobool.not = icmp eq ptr %tmp.0, null, !dbg !478
  br i1 %tobool.not, label %while.end, label %while.body, !dbg !478, !llvm.loop !483

while.end:                                        ; preds = %if.end17, %entry, %if.then
  %version = getelementptr inbounds i8, ptr %p, i64 64, !dbg !495
  store i32 0, ptr %version, align 8, !dbg !496, !tbaa !400
  %allocated = getelementptr inbounds i8, ptr %p, i64 72, !dbg !497
  store i32 0, ptr %allocated, align 8, !dbg !498, !tbaa !499
  %written = getelementptr inbounds i8, ptr %p, i64 76, !dbg !500
  store i32 0, ptr %written, align 4, !dbg !501, !tbaa !502
  store i32 0, ptr %bucket, align 8, !dbg !503, !tbaa !435
  %active = getelementptr inbounds i8, ptr %p, i64 94, !dbg !504
  store i8 0, ptr %active, align 2, !dbg !505, !tbaa !412
  %closed = getelementptr inbounds i8, ptr %p, i64 95, !dbg !506
  store i8 0, ptr %closed, align 1, !dbg !507, !tbaa !431
  %free = getelementptr inbounds i8, ptr %p, i64 96, !dbg !508
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %obj_count, i8 0, i64 16, i1 false), !dbg !509
  store i8 1, ptr %free, align 8, !dbg !510, !tbaa !423
  %free_page_buckets = getelementptr inbounds i8, ptr %e, i64 88, !dbg !511
  %8 = load ptr, ptr %free_page_buckets, align 8, !dbg !511, !tbaa !512
  %free_bucket = getelementptr inbounds i8, ptr %p, i64 84, !dbg !513
  %9 = load i32, ptr %free_bucket, align 4, !dbg !513, !tbaa !388
  %idxprom22 = zext i32 %9 to i64, !dbg !514
  %arrayidx23 = getelementptr inbounds ptr, ptr %8, i64 %idxprom22, !dbg !514
  %10 = load ptr, ptr %arrayidx23, align 8, !dbg !514, !tbaa !477
  %next24 = getelementptr inbounds i8, ptr %p, i64 112, !dbg !515
  store ptr %10, ptr %next24, align 8, !dbg !516, !tbaa !489
  store ptr %p, ptr %arrayidx23, align 8, !dbg !517, !tbaa !477
  %page_free = getelementptr inbounds i8, ptr %e, i64 120, !dbg !518
  %11 = load i32, ptr %page_free, align 8, !dbg !519, !tbaa !296
  %inc29 = add i32 %11, 1, !dbg !519
  store i32 %inc29, ptr %page_free, align 8, !dbg !519, !tbaa !296
  %call31 = tail call i32 @pthread_mutex_unlock(ptr noundef %e) #14, !dbg !520
  ret void, !dbg !521
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(none) uwtable
define dso_local noundef nonnull ptr @extstore_err(i32 noundef %res) local_unnamed_addr #4 !dbg !522 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %res, metadata !528, metadata !DIExpression()), !dbg !530
  tail call void @llvm.dbg.value(metadata ptr @.str, metadata !529, metadata !DIExpression()), !dbg !530
  %switch.tableidx = add i32 %res, -1, !dbg !531
  %0 = icmp ult i32 %switch.tableidx, 7, !dbg !531
  br i1 %0, label %switch.lookup, label %sw.epilog, !dbg !531

switch.lookup:                                    ; preds = %entry
  %1 = zext nneg i32 %switch.tableidx to i64, !dbg !531
  %reltable.shift = shl i64 %1, 2, !dbg !531
  %reltable.intrinsic = call ptr @llvm.load.relative.i64(ptr @reltable.extstore_err, i64 %reltable.shift), !dbg !531
  br label %sw.epilog, !dbg !531

sw.epilog:                                        ; preds = %switch.lookup, %entry
  %rv.0 = phi ptr [ @.str, %entry ], [ %reltable.intrinsic, %switch.lookup ], !dbg !530
  tail call void @llvm.dbg.value(metadata ptr %rv.0, metadata !529, metadata !DIExpression()), !dbg !530
  ret ptr %rv.0, !dbg !532
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef ptr @extstore_init(ptr noundef %fh, ptr nocapture noundef readonly %cf, ptr nocapture noundef writeonly %res) local_unnamed_addr #0 !dbg !533 {
entry:
  %thread = alloca i64, align 8, !DIAssignID !591
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !564, metadata !DIExpression(), metadata !591, metadata ptr %thread, metadata !DIExpression()), !dbg !592
  %lock = alloca %struct.flock, align 8, !DIAssignID !593
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !568, metadata !DIExpression(), metadata !593, metadata ptr %lock, metadata !DIExpression()), !dbg !594
  tail call void @llvm.dbg.value(metadata ptr %fh, metadata !559, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata ptr %cf, metadata !560, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata ptr %res, metadata !561, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata ptr null, metadata !563, metadata !DIExpression()), !dbg !592
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %thread) #14, !dbg !595
  %0 = load i32, ptr %cf, align 4, !dbg !596, !tbaa !598
  %wbuf_size = getelementptr inbounds i8, ptr %cf, i64 16, !dbg !600
  %1 = load i32, ptr %wbuf_size, align 4, !dbg !600, !tbaa !601
  %rem = urem i32 %0, %1, !dbg !602
  %cmp.not = icmp eq i32 %rem, 0, !dbg !603
  br i1 %cmp.not, label %if.end, label %if.then, !dbg !604

if.then:                                          ; preds = %entry
  store i32 1, ptr %res, align 4, !dbg !605, !tbaa !607
  br label %cleanup211, !dbg !608

if.end:                                           ; preds = %entry
  %page_buckets = getelementptr inbounds i8, ptr %cf, i64 8, !dbg !609
  %2 = load i32, ptr %page_buckets, align 4, !dbg !609, !tbaa !611
  %wbuf_count = getelementptr inbounds i8, ptr %cf, i64 20, !dbg !612
  %3 = load i32, ptr %wbuf_count, align 4, !dbg !612, !tbaa !613
  %cmp1 = icmp ugt i32 %2, %3, !dbg !614
  br i1 %cmp1, label %if.then2, label %if.end3, !dbg !615

if.then2:                                         ; preds = %if.end
  store i32 2, ptr %res, align 4, !dbg !616, !tbaa !607
  br label %cleanup211, !dbg !618

if.end3:                                          ; preds = %if.end
  %cmp5 = icmp eq i32 %2, 0, !dbg !619
  br i1 %cmp5, label %if.then6, label %if.end7, !dbg !621

if.then6:                                         ; preds = %if.end3
  store i32 3, ptr %res, align 4, !dbg !622, !tbaa !607
  br label %cleanup211, !dbg !624

if.end7:                                          ; preds = %if.end3
  %4 = or i32 %1, %0, !dbg !625
  %5 = and i32 %4, 2097151, !dbg !625
  %or.cond = icmp eq i32 %5, 0, !dbg !625
  br i1 %or.cond, label %if.end15, label %if.then14, !dbg !625

if.then14:                                        ; preds = %if.end7
  store i32 4, ptr %res, align 4, !dbg !627, !tbaa !607
  br label %cleanup211, !dbg !629

if.end15:                                         ; preds = %if.end7
  %call = tail call noalias dereferenceable_or_null(360) ptr @calloc(i64 noundef 1, i64 noundef 360) #15, !dbg !630
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !566, metadata !DIExpression()), !dbg !592
  %cmp16 = icmp eq ptr %call, null, !dbg !631
  br i1 %cmp16, label %if.then17, label %if.end18, !dbg !633

if.then17:                                        ; preds = %if.end15
  store i32 6, ptr %res, align 4, !dbg !634, !tbaa !607
  br label %cleanup211, !dbg !636

if.end18:                                         ; preds = %if.end15
  %conv = zext i32 %0 to i64, !dbg !637
  %page_size20 = getelementptr inbounds i8, ptr %call, i64 96, !dbg !638
  store i64 %conv, ptr %page_size20, align 8, !dbg !639, !tbaa !328
  tail call void @llvm.dbg.value(metadata i64 0, metadata !567, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata ptr %fh, metadata !563, metadata !DIExpression()), !dbg !592
  %cmp21.not356 = icmp eq ptr %fh, null, !dbg !640
  br i1 %cmp21.not356, label %if.end45, label %for.body.lr.ph, !dbg !641

for.body.lr.ph:                                   ; preds = %if.end18
  %l_start = getelementptr inbounds i8, ptr %lock, i64 8
  %l_whence = getelementptr inbounds i8, ptr %lock, i64 2
  br label %for.body, !dbg !641

for.body:                                         ; preds = %for.body.lr.ph, %for.inc
  %f.0358 = phi ptr [ %fh, %for.body.lr.ph ], [ %9, %for.inc ]
  %temp_page_count.0357 = phi i64 [ 0, %for.body.lr.ph ], [ %add, %for.inc ]
  tail call void @llvm.dbg.value(metadata ptr %f.0358, metadata !563, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i64 %temp_page_count.0357, metadata !567, metadata !DIExpression()), !dbg !592
  %file = getelementptr inbounds i8, ptr %f.0358, i64 8, !dbg !642
  %6 = load ptr, ptr %file, align 8, !dbg !642, !tbaa !643
  %call23 = call i32 (ptr, i32, ...) @open(ptr noundef %6, i32 noundef 66, i32 noundef 420) #14, !dbg !645
  %fd = getelementptr inbounds i8, ptr %f.0358, i64 16, !dbg !646
  store i32 %call23, ptr %fd, align 8, !dbg !647, !tbaa !648
  %cmp25 = icmp slt i32 %call23, 0, !dbg !649
  br i1 %cmp25, label %if.then27, label %if.end28, !dbg !651

if.then27:                                        ; preds = %for.body
  store i32 7, ptr %res, align 4, !dbg !652, !tbaa !607
  call void @free(ptr noundef %call) #14, !dbg !654
  br label %cleanup211, !dbg !655

if.end28:                                         ; preds = %for.body
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %lock) #14, !dbg !656
  store i16 1, ptr %lock, align 8, !dbg !657, !tbaa !658, !DIAssignID !660
  tail call void @llvm.dbg.assign(metadata i16 1, metadata !568, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 16), metadata !660, metadata ptr %lock, metadata !DIExpression()), !dbg !594
  tail call void @llvm.dbg.assign(metadata i64 0, metadata !568, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !661, metadata ptr %l_start, metadata !DIExpression()), !dbg !594
  store i16 0, ptr %l_whence, align 2, !dbg !662, !tbaa !663, !DIAssignID !664
  tail call void @llvm.dbg.assign(metadata i16 0, metadata !568, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !664, metadata ptr %l_whence, metadata !DIExpression()), !dbg !594
  tail call void @llvm.dbg.assign(metadata i64 0, metadata !568, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64), metadata !661, metadata ptr %lock, metadata !DIExpression(DW_OP_plus_uconst, 16)), !dbg !594
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %l_start, i8 0, i64 16, i1 false), !dbg !665, !DIAssignID !661
  %call30 = call i32 (i32, i32, ...) @fcntl(i32 noundef %call23, i32 noundef 6, ptr noundef nonnull %lock) #14, !dbg !666
  %cmp31 = icmp slt i32 %call30, 0, !dbg !668
  br i1 %cmp31, label %cleanup.thread, label %if.end34, !dbg !669

if.end34:                                         ; preds = %if.end28
  %7 = load i32, ptr %fd, align 8, !dbg !670, !tbaa !648
  %call36 = call i32 @ftruncate(i32 noundef %7, i64 noundef 0) #14, !dbg !672
  %cmp37 = icmp slt i32 %call36, 0, !dbg !673
  br i1 %cmp37, label %cleanup.thread, label %for.inc, !dbg !674

cleanup.thread:                                   ; preds = %if.end34, %if.end28
  store i32 7, ptr %res, align 4, !dbg !594, !tbaa !607
  call void @free(ptr noundef %call) #14, !dbg !594
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !567, metadata !DIExpression()), !dbg !592
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %lock) #14, !dbg !675
  br label %cleanup211

for.inc:                                          ; preds = %if.end34
  %8 = load i32, ptr %f.0358, align 8, !dbg !676, !tbaa !677
  %conv41 = zext i32 %8 to i64, !dbg !678
  %add = add i64 %temp_page_count.0357, %conv41, !dbg !679
  tail call void @llvm.dbg.value(metadata i64 %add, metadata !567, metadata !DIExpression()), !dbg !592
  %offset = getelementptr inbounds i8, ptr %f.0358, i64 24, !dbg !680
  store i64 0, ptr %offset, align 8, !dbg !681, !tbaa !682
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %lock) #14, !dbg !675
  %next = getelementptr inbounds i8, ptr %f.0358, i64 40, !dbg !683
  %9 = load ptr, ptr %next, align 8, !dbg !683, !tbaa !684
  tail call void @llvm.dbg.value(metadata ptr %9, metadata !563, metadata !DIExpression()), !dbg !592
  %cmp21.not = icmp eq ptr %9, null, !dbg !640
  br i1 %cmp21.not, label %for.end, label %for.body, !dbg !641, !llvm.loop !685

for.end:                                          ; preds = %for.inc
  %cmp42 = icmp ugt i64 %add, 65534, !dbg !687
  br i1 %cmp42, label %if.then44, label %if.end45, !dbg !689

if.then44:                                        ; preds = %for.end
  store i32 5, ptr %res, align 4, !dbg !690, !tbaa !607
  call void @free(ptr noundef %call) #14, !dbg !692
  br label %cleanup211, !dbg !693

if.end45:                                         ; preds = %if.end18, %for.end
  %temp_page_count.0.lcssa383 = phi i64 [ %add, %for.end ], [ 0, %if.end18 ]
  %conv46 = trunc nuw nsw i64 %temp_page_count.0.lcssa383 to i32, !dbg !694
  %page_count47 = getelementptr inbounds i8, ptr %call, i64 116, !dbg !695
  store i32 %conv46, ptr %page_count47, align 4, !dbg !696, !tbaa !310
  %call50 = call noalias ptr @calloc(i64 noundef %temp_page_count.0.lcssa383, i64 noundef 120) #15, !dbg !697
  %pages = getelementptr inbounds i8, ptr %call, i64 40, !dbg !698
  store ptr %call50, ptr %pages, align 8, !dbg !699, !tbaa !383
  %cmp52 = icmp eq ptr %call50, null, !dbg !700
  br i1 %cmp52, label %if.then54, label %for.cond56.preheader, !dbg !702

for.cond56.preheader:                             ; preds = %if.end45
  tail call void @llvm.dbg.value(metadata i32 0, metadata !562, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata ptr null, metadata !563, metadata !DIExpression()), !dbg !592
  %cmp58359.not = icmp eq i32 %conv46, 0, !dbg !703
  br i1 %cmp58359.not, label %for.end101, label %while.cond.preheader, !dbg !706

if.then54:                                        ; preds = %if.end45
  store i32 6, ptr %res, align 4, !dbg !707, !tbaa !607
  call void @free(ptr noundef nonnull %call) #14, !dbg !709
  br label %cleanup211, !dbg !710

while.cond.preheader:                             ; preds = %for.cond56.preheader, %if.then71
  %10 = phi ptr [ %13, %if.then71 ], [ %call50, %for.cond56.preheader ]
  %indvars.iv = phi i64 [ %indvars.iv.next, %if.then71 ], [ 0, %for.cond56.preheader ]
  %f.1360 = phi ptr [ %f.3, %if.then71 ], [ null, %for.cond56.preheader ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !562, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata ptr %f.1360, metadata !563, metadata !DIExpression()), !dbg !592
  br label %while.cond, !dbg !711

while.cond:                                       ; preds = %while.cond.preheader, %if.end69
  %f.2 = phi ptr [ %f.3, %if.end69 ], [ %f.1360, %while.cond.preheader ], !dbg !592
  tail call void @llvm.dbg.value(metadata ptr %f.2, metadata !563, metadata !DIExpression()), !dbg !592
  %cmp61 = icmp eq ptr %f.2, null, !dbg !713
  br i1 %cmp61, label %if.end69, label %lor.lhs.false63, !dbg !716

lor.lhs.false63:                                  ; preds = %while.cond
  %next64 = getelementptr inbounds i8, ptr %f.2, i64 40, !dbg !717
  %11 = load ptr, ptr %next64, align 8, !dbg !717, !tbaa !684
  %cmp65 = icmp eq ptr %11, null, !dbg !718
  %spec.select = select i1 %cmp65, ptr %fh, ptr %11, !dbg !719
  br label %if.end69, !dbg !719

if.end69:                                         ; preds = %lor.lhs.false63, %while.cond
  %f.3 = phi ptr [ %fh, %while.cond ], [ %spec.select, %lor.lhs.false63 ], !dbg !720
  tail call void @llvm.dbg.value(metadata ptr %f.3, metadata !563, metadata !DIExpression()), !dbg !592
  %12 = load i32, ptr %f.3, align 8, !dbg !721, !tbaa !677
  %tobool.not = icmp eq i32 %12, 0, !dbg !723
  br i1 %tobool.not, label %while.cond, label %if.then71, !dbg !724, !llvm.loop !725

if.then71:                                        ; preds = %if.end69
  %dec = add i32 %12, -1, !dbg !727
  store i32 %dec, ptr %f.3, align 8, !dbg !727, !tbaa !677
  %arrayidx = getelementptr inbounds %struct._store_page, ptr %10, i64 %indvars.iv, !dbg !729
  %call75 = call i32 @pthread_mutex_init(ptr noundef %arrayidx, ptr noundef null) #14, !dbg !730
  %conv76 = trunc i64 %indvars.iv to i16, !dbg !731
  %13 = load ptr, ptr %pages, align 8, !dbg !732, !tbaa !383
  %id = getelementptr inbounds %struct._store_page, ptr %13, i64 %indvars.iv, i32 11, !dbg !733
  store i16 %conv76, ptr %id, align 4, !dbg !734, !tbaa !393
  %fd80 = getelementptr inbounds i8, ptr %f.3, i64 16, !dbg !735
  %14 = load i32, ptr %fd80, align 8, !dbg !735, !tbaa !648
  %fd84 = getelementptr inbounds %struct._store_page, ptr %13, i64 %indvars.iv, i32 10, !dbg !736
  store i32 %14, ptr %fd84, align 8, !dbg !737, !tbaa !738
  %free_bucket = getelementptr inbounds i8, ptr %f.3, i64 36, !dbg !739
  %15 = load i32, ptr %free_bucket, align 4, !dbg !739, !tbaa !740
  %free_bucket88 = getelementptr inbounds %struct._store_page, ptr %13, i64 %indvars.iv, i32 9, !dbg !741
  store i32 %15, ptr %free_bucket88, align 4, !dbg !742, !tbaa !388
  %offset89 = getelementptr inbounds i8, ptr %f.3, i64 24, !dbg !743
  %16 = load i64, ptr %offset89, align 8, !dbg !743, !tbaa !682
  %offset93 = getelementptr inbounds %struct._store_page, ptr %13, i64 %indvars.iv, i32 3, !dbg !744
  store i64 %16, ptr %offset93, align 8, !dbg !745, !tbaa !746
  %free = getelementptr inbounds %struct._store_page, ptr %13, i64 %indvars.iv, i32 14, !dbg !747
  store i8 1, ptr %free, align 8, !dbg !748, !tbaa !423
  %17 = load i64, ptr %page_size20, align 8, !dbg !749, !tbaa !328
  %add99 = add i64 %17, %16, !dbg !750
  store i64 %add99, ptr %offset89, align 8, !dbg !750, !tbaa !682
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !751
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !562, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata ptr %f.3, metadata !563, metadata !DIExpression()), !dbg !592
  %18 = load i32, ptr %page_count47, align 4, !dbg !752, !tbaa !310
  %19 = zext i32 %18 to i64, !dbg !703
  %cmp58 = icmp ult i64 %indvars.iv.next, %19, !dbg !703
  br i1 %cmp58, label %while.cond.preheader, label %for.end101, !dbg !706, !llvm.loop !753

for.end101:                                       ; preds = %if.then71, %for.cond56.preheader
  %20 = phi i64 [ %conv, %for.cond56.preheader ], [ %17, %if.then71 ]
  %21 = phi ptr [ %call50, %for.cond56.preheader ], [ %13, %if.then71 ]
  %.lcssa352 = phi i32 [ 0, %for.cond56.preheader ], [ %18, %if.then71 ], !dbg !752
  %22 = load i32, ptr %page_buckets, align 4, !dbg !755, !tbaa !611
  %conv103 = zext i32 %22 to i64, !dbg !756
  %call104 = call noalias ptr @calloc(i64 noundef %conv103, i64 noundef 8) #15, !dbg !757
  %free_page_buckets = getelementptr inbounds i8, ptr %call, i64 88, !dbg !758
  store ptr %call104, ptr %free_page_buckets, align 8, !dbg !759, !tbaa !512
  %free_page_bucketcount = getelementptr inbounds i8, ptr %call, i64 128, !dbg !760
  store i32 %22, ptr %free_page_bucketcount, align 8, !dbg !761, !tbaa !762
  %page_free = getelementptr inbounds i8, ptr %call, i64 120, !dbg !763
  store i32 %.lcssa352, ptr %page_free, align 8, !dbg !764, !tbaa !296
  tail call void @llvm.dbg.value(metadata i32 %.lcssa352, metadata !562, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !592
  %i.1363 = add i32 %.lcssa352, -1, !dbg !765
  %cmp109364 = icmp sgt i32 %i.1363, -1, !dbg !766
  br i1 %cmp109364, label %for.body111.preheader, label %for.end131, !dbg !767

for.body111.preheader:                            ; preds = %for.end101
  %23 = zext nneg i32 %i.1363 to i64, !dbg !767
  %24 = and i64 %23, 1, !dbg !767
  %lcmp.mod.not.not = icmp eq i64 %24, 0, !dbg !767
  br i1 %lcmp.mod.not.not, label %for.body111.prol, label %for.body111.prol.loopexit, !dbg !767

for.body111.prol:                                 ; preds = %for.body111.preheader
  %arrayidx114.prol = getelementptr inbounds %struct._store_page, ptr %21, i64 %23, !dbg !768
  %free_bucket115.prol = getelementptr inbounds i8, ptr %arrayidx114.prol, i64 84, !dbg !769
  %25 = load i32, ptr %free_bucket115.prol, align 4, !dbg !769, !tbaa !388
  tail call void @llvm.dbg.value(metadata i32 %25, metadata !582, metadata !DIExpression()), !dbg !770
  %idxprom117.prol = sext i32 %25 to i64, !dbg !771
  %arrayidx118.prol = getelementptr inbounds ptr, ptr %call104, i64 %idxprom117.prol, !dbg !771
  %26 = load ptr, ptr %arrayidx118.prol, align 8, !dbg !771, !tbaa !477
  %next122.prol = getelementptr inbounds i8, ptr %arrayidx114.prol, i64 112, !dbg !772
  store ptr %26, ptr %next122.prol, align 8, !dbg !773, !tbaa !489
  store ptr %arrayidx114.prol, ptr %arrayidx118.prol, align 8, !dbg !774, !tbaa !477
  tail call void @llvm.dbg.value(metadata i64 %23, metadata !562, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !592
  %indvars.iv.next376.prol = add nsw i64 %23, -1, !dbg !765
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next376.prol, metadata !562, metadata !DIExpression()), !dbg !592
  br label %for.body111.prol.loopexit, !dbg !767

for.body111.prol.loopexit:                        ; preds = %for.body111.prol, %for.body111.preheader
  %indvars.iv375.unr = phi i64 [ %23, %for.body111.preheader ], [ %indvars.iv.next376.prol, %for.body111.prol ]
  %27 = icmp eq i32 %i.1363, 0, !dbg !767
  br i1 %27, label %for.end131, label %for.body111, !dbg !767

for.body111:                                      ; preds = %for.body111.prol.loopexit, %for.body111
  %indvars.iv375 = phi i64 [ %indvars.iv.next376.1, %for.body111 ], [ %indvars.iv375.unr, %for.body111.prol.loopexit ]
  %arrayidx114 = getelementptr inbounds %struct._store_page, ptr %21, i64 %indvars.iv375, !dbg !768
  %free_bucket115 = getelementptr inbounds i8, ptr %arrayidx114, i64 84, !dbg !769
  %28 = load i32, ptr %free_bucket115, align 4, !dbg !769, !tbaa !388
  tail call void @llvm.dbg.value(metadata i32 %28, metadata !582, metadata !DIExpression()), !dbg !770
  %idxprom117 = sext i32 %28 to i64, !dbg !771
  %arrayidx118 = getelementptr inbounds ptr, ptr %call104, i64 %idxprom117, !dbg !771
  %29 = load ptr, ptr %arrayidx118, align 8, !dbg !771, !tbaa !477
  %next122 = getelementptr inbounds i8, ptr %arrayidx114, i64 112, !dbg !772
  store ptr %29, ptr %next122, align 8, !dbg !773, !tbaa !489
  store ptr %arrayidx114, ptr %arrayidx118, align 8, !dbg !774, !tbaa !477
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv375, metadata !562, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !592
  %indvars.iv.next376 = add nsw i64 %indvars.iv375, -1, !dbg !765
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next376, metadata !562, metadata !DIExpression()), !dbg !592
  %arrayidx114.1 = getelementptr inbounds %struct._store_page, ptr %21, i64 %indvars.iv.next376, !dbg !768
  %free_bucket115.1 = getelementptr inbounds i8, ptr %arrayidx114.1, i64 84, !dbg !769
  %30 = load i32, ptr %free_bucket115.1, align 4, !dbg !769, !tbaa !388
  tail call void @llvm.dbg.value(metadata i32 %30, metadata !582, metadata !DIExpression()), !dbg !770
  %idxprom117.1 = sext i32 %30 to i64, !dbg !771
  %arrayidx118.1 = getelementptr inbounds ptr, ptr %call104, i64 %idxprom117.1, !dbg !771
  %31 = load ptr, ptr %arrayidx118.1, align 8, !dbg !771, !tbaa !477
  %next122.1 = getelementptr inbounds i8, ptr %arrayidx114.1, i64 112, !dbg !772
  store ptr %31, ptr %next122.1, align 8, !dbg !773, !tbaa !489
  store ptr %arrayidx114.1, ptr %arrayidx118.1, align 8, !dbg !774, !tbaa !477
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next376, metadata !562, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !592
  %indvars.iv.next376.1 = add nsw i64 %indvars.iv375, -2, !dbg !765
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next376.1, metadata !562, metadata !DIExpression()), !dbg !592
  %cmp109.not.1 = icmp eq i64 %indvars.iv.next376, 0, !dbg !766
  br i1 %cmp109.not.1, label %for.end131, label %for.body111, !dbg !767, !llvm.loop !775

for.end131:                                       ; preds = %for.body111.prol.loopexit, %for.body111, %for.end101
  %version = getelementptr inbounds i8, ptr %call, i64 104, !dbg !777
  store i32 1, ptr %version, align 8, !dbg !778, !tbaa !779
  %conv133 = zext i32 %.lcssa352 to i64, !dbg !780
  %call134 = call noalias ptr @calloc(i64 noundef %conv133, i64 noundef 32) #15, !dbg !781
  %page_data = getelementptr inbounds i8, ptr %call, i64 312, !dbg !782
  store ptr %call134, ptr %page_data, align 8, !dbg !783, !tbaa !784
  %page_count138 = getelementptr inbounds i8, ptr %call, i64 184, !dbg !785
  store i64 %conv133, ptr %page_count138, align 8, !dbg !786, !tbaa !787
  %page_size141 = getelementptr inbounds i8, ptr %call, i64 208, !dbg !788
  store i64 %20, ptr %page_size141, align 8, !dbg !789, !tbaa !790
  %call144 = call noalias ptr @calloc(i64 noundef %conv103, i64 noundef 8) #15, !dbg !791
  %page_buckets145 = getelementptr inbounds i8, ptr %call, i64 80, !dbg !792
  store ptr %call144, ptr %page_buckets145, align 8, !dbg !793, !tbaa !474
  %page_bucketcount = getelementptr inbounds i8, ptr %call, i64 124, !dbg !794
  store i32 %22, ptr %page_bucketcount, align 4, !dbg !795, !tbaa !796
  tail call void @llvm.dbg.value(metadata i32 0, metadata !562, metadata !DIExpression()), !dbg !592
  %32 = load i32, ptr %wbuf_count, align 4, !tbaa !613
  %cmp149366.not = icmp eq i32 %32, 0, !dbg !797
  br i1 %cmp149366.not, label %for.end162, label %for.body151.lr.ph, !dbg !798

for.body151.lr.ph:                                ; preds = %for.end131
  %33 = load i32, ptr %wbuf_size, align 4, !tbaa !601
  %conv153 = zext i32 %33 to i64
  %wbuf_stack = getelementptr inbounds i8, ptr %call, i64 48
  %io_stack = getelementptr inbounds i8, ptr %call, i64 56
  %wbuf_stack.promoted = load ptr, ptr %wbuf_stack, align 8, !tbaa !799
  %io_stack.promoted = load ptr, ptr %io_stack, align 8, !tbaa !800
  br label %for.body151, !dbg !798

for.body151:                                      ; preds = %for.body151.lr.ph, %wbuf_new.exit
  %34 = phi ptr [ %io_stack.promoted, %for.body151.lr.ph ], [ %call155, %wbuf_new.exit ]
  %35 = phi ptr [ %wbuf_stack.promoted, %for.body151.lr.ph ], [ %retval.0.i, %wbuf_new.exit ]
  %i.2367 = phi i32 [ 0, %for.body151.lr.ph ], [ %inc161, %wbuf_new.exit ]
  tail call void @llvm.dbg.value(metadata i32 %i.2367, metadata !562, metadata !DIExpression()), !dbg !592
  tail call void @llvm.dbg.value(metadata i32 %33, metadata !801, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !807
  %call.i = call noalias dereferenceable_or_null(40) ptr @calloc(i64 noundef 1, i64 noundef 40) #15, !dbg !809
  tail call void @llvm.dbg.value(metadata ptr %call.i, metadata !806, metadata !DIExpression()), !dbg !807
  %cmp.i = icmp eq ptr %call.i, null, !dbg !810
  br i1 %cmp.i, label %wbuf_new.exit, label %if.end.i, !dbg !812

if.end.i:                                         ; preds = %for.body151
  tail call void @llvm.dbg.value(metadata i64 %conv153, metadata !801, metadata !DIExpression()), !dbg !807
  %call1.i = call noalias ptr @calloc(i64 noundef %conv153, i64 noundef 1) #15, !dbg !813
  %buf.i = getelementptr inbounds i8, ptr %call.i, i64 8, !dbg !814
  store ptr %call1.i, ptr %buf.i, align 8, !dbg !815, !tbaa !816
  %cmp3.i = icmp eq ptr %call1.i, null, !dbg !818
  br i1 %cmp3.i, label %if.then4.i, label %if.end5.i, !dbg !820

if.then4.i:                                       ; preds = %if.end.i
  call void @free(ptr noundef nonnull %call.i) #14, !dbg !821
  br label %wbuf_new.exit, !dbg !823

if.end5.i:                                        ; preds = %if.end.i
  %buf_pos.i = getelementptr inbounds i8, ptr %call.i, i64 16, !dbg !824
  store ptr %call1.i, ptr %buf_pos.i, align 8, !dbg !825, !tbaa !826
  %free.i = getelementptr inbounds i8, ptr %call.i, i64 24, !dbg !827
  store i32 %33, ptr %free.i, align 8, !dbg !828, !tbaa !829
  %size8.i = getelementptr inbounds i8, ptr %call.i, i64 28, !dbg !830
  store i32 %33, ptr %size8.i, align 4, !dbg !831, !tbaa !832
  br label %wbuf_new.exit, !dbg !833

wbuf_new.exit:                                    ; preds = %for.body151, %if.then4.i, %if.end5.i
  %retval.0.i = phi ptr [ null, %if.then4.i ], [ %call.i, %if.end5.i ], [ null, %for.body151 ], !dbg !807
  tail call void @llvm.dbg.value(metadata ptr %retval.0.i, metadata !586, metadata !DIExpression()), !dbg !834
  %call155 = call noalias dereferenceable_or_null(64) ptr @calloc(i64 noundef 1, i64 noundef 64) #15, !dbg !835
  tail call void @llvm.dbg.value(metadata ptr %call155, metadata !590, metadata !DIExpression()), !dbg !834
  store ptr %35, ptr %retval.0.i, align 8, !dbg !836, !tbaa !837
  %next158 = getelementptr inbounds i8, ptr %call155, i64 8, !dbg !838
  store ptr %34, ptr %next158, align 8, !dbg !839, !tbaa !840
  %inc161 = add nuw nsw i32 %i.2367, 1, !dbg !842
  tail call void @llvm.dbg.value(metadata i32 %inc161, metadata !562, metadata !DIExpression()), !dbg !592
  %exitcond.not = icmp eq i32 %inc161, %32, !dbg !797
  br i1 %exitcond.not, label %for.cond147.for.end162_crit_edge, label %for.body151, !dbg !798, !llvm.loop !843

for.cond147.for.end162_crit_edge:                 ; preds = %wbuf_new.exit
  store ptr %retval.0.i, ptr %wbuf_stack, align 8, !dbg !834, !tbaa !799
  store ptr %call155, ptr %io_stack, align 8, !dbg !834, !tbaa !800
  br label %for.end162, !dbg !798

for.end162:                                       ; preds = %for.cond147.for.end162_crit_edge, %for.end131
  %call164 = call i32 @pthread_mutex_init(ptr noundef nonnull %call, ptr noundef null) #14, !dbg !845
  %stats_mutex = getelementptr inbounds i8, ptr %call, i64 136, !dbg !846
  %call165 = call i32 @pthread_mutex_init(ptr noundef nonnull %stats_mutex, ptr noundef null) #14, !dbg !847
  %maint = getelementptr inbounds i8, ptr %call, i64 320, !dbg !848
  %call167 = call i32 @pthread_mutex_init(ptr noundef nonnull %maint, ptr noundef null) #14, !dbg !849
  %io_depth = getelementptr inbounds i8, ptr %cf, i64 28, !dbg !850
  %36 = load i32, ptr %io_depth, align 4, !dbg !850, !tbaa !851
  %io_depth168 = getelementptr inbounds i8, ptr %call, i64 132, !dbg !852
  store i32 %36, ptr %io_depth168, align 4, !dbg !853, !tbaa !854
  %io_threadcount = getelementptr inbounds i8, ptr %cf, i64 24, !dbg !855
  %37 = load i32, ptr %io_threadcount, align 4, !dbg !855, !tbaa !856
  %conv169 = zext i32 %37 to i64, !dbg !857
  %call170 = call noalias ptr @calloc(i64 noundef %conv169, i64 noundef 120) #15, !dbg !858
  %io_threads = getelementptr inbounds i8, ptr %call, i64 64, !dbg !859
  store ptr %call170, ptr %io_threads, align 8, !dbg !860, !tbaa !339
  tail call void @llvm.dbg.value(metadata i32 0, metadata !562, metadata !DIExpression()), !dbg !592
  %cmp173368.not = icmp eq i32 %37, 0, !dbg !861
  br i1 %cmp173368.not, label %for.end195, label %for.body175, !dbg !864

for.body175:                                      ; preds = %for.end162, %for.body175
  %indvars.iv378 = phi i64 [ %indvars.iv.next379, %for.body175 ], [ 0, %for.end162 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv378, metadata !562, metadata !DIExpression()), !dbg !592
  %38 = load ptr, ptr %io_threads, align 8, !dbg !865, !tbaa !339
  %arrayidx178 = getelementptr inbounds %struct.store_io_thread, ptr %38, i64 %indvars.iv378, !dbg !867
  %call180 = call i32 @pthread_mutex_init(ptr noundef %arrayidx178, ptr noundef null) #14, !dbg !868
  %39 = load ptr, ptr %io_threads, align 8, !dbg !869, !tbaa !339
  %cond = getelementptr inbounds %struct.store_io_thread, ptr %39, i64 %indvars.iv378, i32 1, !dbg !870
  %call184 = call i32 @pthread_cond_init(ptr noundef nonnull %cond, ptr noundef null) #14, !dbg !871
  %40 = load ptr, ptr %io_threads, align 8, !dbg !872, !tbaa !339
  %e188 = getelementptr inbounds %struct.store_io_thread, ptr %40, i64 %indvars.iv378, i32 4, !dbg !873
  store ptr %call, ptr %e188, align 8, !dbg !874, !tbaa !875
  %arrayidx191 = getelementptr inbounds %struct.store_io_thread, ptr %40, i64 %indvars.iv378, !dbg !876
  %call192 = call i32 @pthread_create(ptr noundef nonnull %thread, ptr noundef null, ptr noundef nonnull @extstore_io_thread, ptr noundef %arrayidx191) #14, !dbg !877
  %41 = load i64, ptr %thread, align 8, !dbg !878, !tbaa !879
  tail call void @llvm.dbg.value(metadata i64 %41, metadata !880, metadata !DIExpression()), !dbg !886
  tail call void @llvm.dbg.value(metadata ptr @.str.8, metadata !885, metadata !DIExpression()), !dbg !886
  %call.i347 = call i32 @pthread_setname_np(i64 noundef %41, ptr noundef nonnull @.str.8) #14, !dbg !888
  %indvars.iv.next379 = add nuw nsw i64 %indvars.iv378, 1, !dbg !889
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next379, metadata !562, metadata !DIExpression()), !dbg !592
  %42 = load i32, ptr %io_threadcount, align 4, !dbg !890, !tbaa !856
  %43 = zext i32 %42 to i64, !dbg !861
  %cmp173 = icmp ult i64 %indvars.iv.next379, %43, !dbg !861
  br i1 %cmp173, label %for.body175, label %for.end195, !dbg !864, !llvm.loop !891

for.end195:                                       ; preds = %for.body175, %for.end162
  %.lcssa = phi i32 [ 0, %for.end162 ], [ %42, %for.body175 ], !dbg !890
  %io_threadcount197 = getelementptr inbounds i8, ptr %call, i64 112, !dbg !893
  store i32 %.lcssa, ptr %io_threadcount197, align 8, !dbg !894, !tbaa !323
  %call198 = call noalias dereferenceable_or_null(120) ptr @calloc(i64 noundef 1, i64 noundef 120) #15, !dbg !895
  %bg_thread = getelementptr inbounds i8, ptr %call, i64 72, !dbg !896
  store ptr %call198, ptr %bg_thread, align 8, !dbg !897, !tbaa !898
  %e200 = getelementptr inbounds i8, ptr %call198, i64 104, !dbg !899
  store ptr %call, ptr %e200, align 8, !dbg !900, !tbaa !875
  %call203 = call i32 @pthread_mutex_init(ptr noundef %call198, ptr noundef null) #14, !dbg !901
  %44 = load ptr, ptr %bg_thread, align 8, !dbg !902, !tbaa !898
  %cond205 = getelementptr inbounds i8, ptr %44, i64 40, !dbg !903
  %call206 = call i32 @pthread_cond_init(ptr noundef nonnull %cond205, ptr noundef null) #14, !dbg !904
  %45 = load ptr, ptr %bg_thread, align 8, !dbg !905, !tbaa !898
  %call208 = call i32 @pthread_create(ptr noundef nonnull %thread, ptr noundef null, ptr noundef nonnull @extstore_io_thread, ptr noundef %45) #14, !dbg !906
  %46 = load i64, ptr %thread, align 8, !dbg !907, !tbaa !879
  tail call void @llvm.dbg.value(metadata i64 %46, metadata !880, metadata !DIExpression()), !dbg !908
  tail call void @llvm.dbg.value(metadata ptr @.str.9, metadata !885, metadata !DIExpression()), !dbg !908
  %call.i348 = call i32 @pthread_setname_np(i64 noundef %46, ptr noundef nonnull @.str.9) #14, !dbg !910
  br label %cleanup211, !dbg !911

cleanup211:                                       ; preds = %cleanup.thread, %if.then17, %for.end195, %if.then54, %if.then44, %if.then27, %if.then14, %if.then6, %if.then2, %if.then
  %retval.4 = phi ptr [ null, %if.then ], [ null, %if.then2 ], [ null, %if.then6 ], [ null, %if.then14 ], [ null, %if.then17 ], [ null, %if.then27 ], [ null, %if.then44 ], [ null, %if.then54 ], [ %call, %for.end195 ], [ null, %cleanup.thread ], !dbg !592
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %thread) #14, !dbg !912
  ret ptr %retval.4, !dbg !912
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite)
declare !dbg !913 noalias noundef ptr @calloc(i64 noundef, i64 noundef) local_unnamed_addr #5

; Function Attrs: nofree
declare !dbg !917 noundef i32 @open(ptr nocapture noundef readonly, i32 noundef, ...) local_unnamed_addr #6

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !921 void @free(ptr allocptr nocapture noundef) local_unnamed_addr #7

declare !dbg !924 i32 @fcntl(i32 noundef, i32 noundef, ...) local_unnamed_addr #8

; Function Attrs: nounwind
declare !dbg !927 i32 @ftruncate(i32 noundef, i64 noundef) local_unnamed_addr #2

; Function Attrs: nounwind
declare !dbg !931 i32 @pthread_mutex_init(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind
declare !dbg !944 i32 @pthread_cond_init(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind
declare !dbg !957 i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: noreturn nounwind sanitize_thread uwtable
define internal noundef ptr @extstore_io_thread(ptr noundef %arg) #9 !dbg !977 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !979, metadata !DIExpression()), !dbg !994
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !980, metadata !DIExpression()), !dbg !994
  %e1 = getelementptr inbounds i8, ptr %arg, i64 104, !dbg !995
  %0 = load ptr, ptr %e1, align 8, !dbg !995, !tbaa !875
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !981, metadata !DIExpression()), !dbg !994
  %queue = getelementptr inbounds i8, ptr %arg, i64 88
  %cond = getelementptr inbounds i8, ptr %arg, i64 40
  %io_depth = getelementptr inbounds i8, ptr %0, i64 132
  %queue_tail = getelementptr inbounds i8, ptr %arg, i64 96
  %depth = getelementptr inbounds i8, ptr %arg, i64 112
  %pages = getelementptr inbounds i8, ptr %0, i64 40
  %stats_mutex = getelementptr inbounds i8, ptr %0, i64 136
  %bytes_read = getelementptr inbounds i8, ptr %0, i64 280
  %objects_read = getelementptr inbounds i8, ptr %0, i64 240
  br label %while.cond, !dbg !996

while.cond.loopexit:                              ; preds = %if.end94, %if.end16.thread
  br label %while.cond, !dbg !996, !llvm.loop !997

while.cond:                                       ; preds = %while.cond.loopexit, %entry
  tail call void @llvm.dbg.value(metadata ptr null, metadata !982, metadata !DIExpression()), !dbg !999
  %call = tail call i32 @pthread_mutex_lock(ptr noundef %arg) #14, !dbg !1000
  %1 = load ptr, ptr %queue, align 8, !dbg !1001, !tbaa !1003
  %cmp = icmp eq ptr %1, null, !dbg !1004
  br i1 %cmp, label %if.end, label %for.cond.preheader, !dbg !1005

if.end:                                           ; preds = %while.cond
  %call3 = tail call i32 @pthread_cond_wait(ptr noundef nonnull %cond, ptr noundef nonnull %arg) #14, !dbg !1006
  %.pr = load ptr, ptr %queue, align 8, !dbg !1008, !tbaa !1003
  %cmp5.not = icmp eq ptr %.pr, null, !dbg !1009
  br i1 %cmp5.not, label %if.end16.thread, label %for.cond.preheader, !dbg !1010

if.end16.thread:                                  ; preds = %if.end
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !982, metadata !DIExpression()), !dbg !999
  %call18182 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arg) #14, !dbg !1011
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !988, metadata !DIExpression()), !dbg !999
  br label %while.cond.loopexit, !dbg !1012

for.cond.preheader:                               ; preds = %while.cond, %if.end
  %2 = phi ptr [ %.pr, %if.end ], [ %1, %while.cond ]
  %3 = load i32, ptr %io_depth, align 4, !tbaa !854
  tail call void @llvm.dbg.value(metadata i32 1, metadata !984, metadata !DIExpression()), !dbg !1013
  tail call void @llvm.dbg.value(metadata ptr %2, metadata !987, metadata !DIExpression()), !dbg !1013
  %cmp8166 = icmp ugt i32 %3, 1, !dbg !1014
  br i1 %cmp8166, label %for.body, label %if.end16, !dbg !1017

for.body:                                         ; preds = %for.cond.preheader, %if.then9
  %i.0168 = phi i32 [ %inc, %if.then9 ], [ 1, %for.cond.preheader ]
  %end.0167 = phi ptr [ %4, %if.then9 ], [ %2, %for.cond.preheader ]
  tail call void @llvm.dbg.value(metadata i32 %i.0168, metadata !984, metadata !DIExpression()), !dbg !1013
  tail call void @llvm.dbg.value(metadata ptr %end.0167, metadata !987, metadata !DIExpression()), !dbg !1013
  %next = getelementptr inbounds i8, ptr %end.0167, i64 8, !dbg !1018
  %4 = load ptr, ptr %next, align 8, !dbg !1018, !tbaa !840
  %tobool.not = icmp eq ptr %4, null, !dbg !1021
  br i1 %tobool.not, label %if.else, label %if.then9, !dbg !1022

if.then9:                                         ; preds = %for.body
  tail call void @llvm.dbg.value(metadata ptr %4, metadata !987, metadata !DIExpression()), !dbg !1013
  %inc = add nuw i32 %i.0168, 1, !dbg !1023
  tail call void @llvm.dbg.value(metadata i32 %inc, metadata !984, metadata !DIExpression()), !dbg !1013
  %exitcond.not = icmp eq i32 %inc, %3, !dbg !1014
  br i1 %exitcond.not, label %if.end16, label %for.body, !dbg !1017, !llvm.loop !1024

if.else:                                          ; preds = %for.body
  store ptr null, ptr %queue_tail, align 8, !dbg !1026, !tbaa !1028
  br label %if.end16, !dbg !1029

if.end16:                                         ; preds = %if.then9, %if.else, %for.cond.preheader
  %end.0165 = phi ptr [ %end.0167, %if.else ], [ %2, %for.cond.preheader ], [ %4, %if.then9 ]
  %i.0163 = phi i32 [ %i.0168, %if.else ], [ 1, %for.cond.preheader ], [ %3, %if.then9 ]
  %5 = load i32, ptr %depth, align 8, !dbg !1030, !tbaa !344
  %sub = sub i32 %5, %i.0163, !dbg !1030
  store i32 %sub, ptr %depth, align 8, !dbg !1030, !tbaa !344
  %next13 = getelementptr inbounds i8, ptr %end.0165, i64 8, !dbg !1031
  %6 = load ptr, ptr %next13, align 8, !dbg !1031, !tbaa !840
  store ptr %6, ptr %queue, align 8, !dbg !1032, !tbaa !1003
  store ptr null, ptr %next13, align 8, !dbg !1033, !tbaa !840
  tail call void @llvm.dbg.value(metadata ptr %2, metadata !982, metadata !DIExpression()), !dbg !999
  %call18 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arg) #14, !dbg !1011
  tail call void @llvm.dbg.value(metadata ptr %2, metadata !988, metadata !DIExpression()), !dbg !999
  br label %while.body21, !dbg !1012

while.body21:                                     ; preds = %if.end16, %if.end94
  %cur_io.0171 = phi ptr [ %7, %if.end94 ], [ %2, %if.end16 ]
  tail call void @llvm.dbg.value(metadata ptr %cur_io.0171, metadata !988, metadata !DIExpression()), !dbg !999
  %next23 = getelementptr inbounds i8, ptr %cur_io.0171, i64 8, !dbg !1034
  %7 = load ptr, ptr %next23, align 8, !dbg !1034, !tbaa !840
  tail call void @llvm.dbg.value(metadata ptr %7, metadata !989, metadata !DIExpression()), !dbg !1035
  tail call void @llvm.dbg.value(metadata i32 0, metadata !991, metadata !DIExpression()), !dbg !1035
  tail call void @llvm.dbg.value(metadata i32 1, metadata !992, metadata !DIExpression()), !dbg !1035
  %8 = load ptr, ptr %pages, align 8, !dbg !1036, !tbaa !383
  %page_id = getelementptr inbounds i8, ptr %cur_io.0171, i64 48, !dbg !1037
  %9 = load i16, ptr %page_id, align 8, !dbg !1037, !tbaa !1038
  %idxprom = zext i16 %9 to i64, !dbg !1039
  %arrayidx = getelementptr inbounds %struct._store_page, ptr %8, i64 %idxprom, !dbg !1039
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !993, metadata !DIExpression()), !dbg !1035
  %mode = getelementptr inbounds i8, ptr %cur_io.0171, i64 52, !dbg !1040
  %10 = load i32, ptr %mode, align 4, !dbg !1040, !tbaa !1041
  switch i32 %10, label %if.then88.critedge [
    i32 0, label %sw.bb
    i32 1, label %sw.bb72
  ], !dbg !1042

sw.bb:                                            ; preds = %while.body21
  %call25 = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx) #14, !dbg !1043
  %free = getelementptr inbounds i8, ptr %arrayidx, i64 96, !dbg !1045
  %11 = load i8, ptr %free, align 8, !dbg !1045, !tbaa !423, !range !413, !noundef !414
  %tobool26 = trunc nuw i8 %11 to i1, !dbg !1045
  br i1 %tobool26, label %if.end45.thread, label %land.lhs.true, !dbg !1047

land.lhs.true:                                    ; preds = %sw.bb
  %closed = getelementptr inbounds i8, ptr %arrayidx, i64 95, !dbg !1048
  %12 = load i8, ptr %closed, align 1, !dbg !1048, !tbaa !431, !range !413, !noundef !414
  %tobool27 = trunc nuw i8 %12 to i1, !dbg !1048
  br i1 %tobool27, label %if.end45.thread, label %land.lhs.true28, !dbg !1049

land.lhs.true28:                                  ; preds = %land.lhs.true
  %version = getelementptr inbounds i8, ptr %arrayidx, i64 64, !dbg !1050
  %13 = load i32, ptr %version, align 8, !dbg !1050, !tbaa !400
  %page_version = getelementptr inbounds i8, ptr %cur_io.0171, i64 36, !dbg !1051
  %14 = load i32, ptr %page_version, align 4, !dbg !1051, !tbaa !1052
  %cmp29 = icmp eq i32 %13, %14, !dbg !1053
  br i1 %cmp29, label %if.then30, label %if.end45.thread, !dbg !1054

if.then30:                                        ; preds = %land.lhs.true28
  %active = getelementptr inbounds i8, ptr %arrayidx, i64 94, !dbg !1055
  %15 = load i8, ptr %active, align 2, !dbg !1055, !tbaa !412, !range !413, !noundef !414
  %tobool31 = trunc nuw i8 %15 to i1, !dbg !1055
  br i1 %tobool31, label %land.lhs.true32, label %if.else36, !dbg !1058

land.lhs.true32:                                  ; preds = %if.then30
  %offset = getelementptr inbounds i8, ptr %cur_io.0171, i64 44, !dbg !1059
  %16 = load i32, ptr %offset, align 4, !dbg !1059, !tbaa !1060
  %written = getelementptr inbounds i8, ptr %arrayidx, i64 76, !dbg !1061
  %17 = load i32, ptr %written, align 4, !dbg !1061, !tbaa !502
  %cmp33.not = icmp ult i32 %16, %17, !dbg !1062
  br i1 %cmp33.not, label %if.else36, label %if.then34, !dbg !1063

if.then34:                                        ; preds = %land.lhs.true32
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !1064, metadata !DIExpression()), !dbg !1079
  tail call void @llvm.dbg.value(metadata ptr %cur_io.0171, metadata !1069, metadata !DIExpression()), !dbg !1079
  %wbuf1.i = getelementptr inbounds i8, ptr %arrayidx, i64 104, !dbg !1082
  %18 = load ptr, ptr %wbuf1.i, align 8, !dbg !1082, !tbaa !1083
  tail call void @llvm.dbg.value(metadata ptr %18, metadata !1070, metadata !DIExpression()), !dbg !1079
  %iov.i = getelementptr inbounds i8, ptr %cur_io.0171, i64 24, !dbg !1084
  %19 = load ptr, ptr %iov.i, align 8, !dbg !1084, !tbaa !1085
  %cmp.i = icmp eq ptr %19, null, !dbg !1086
  br i1 %cmp.i, label %if.then.i, label %if.else.i, !dbg !1087

if.then.i:                                        ; preds = %if.then34
  %buf.i = getelementptr inbounds i8, ptr %cur_io.0171, i64 16, !dbg !1088
  %20 = load ptr, ptr %buf.i, align 8, !dbg !1088, !tbaa !1090
  %buf2.i = getelementptr inbounds i8, ptr %18, i64 8, !dbg !1091
  %21 = load ptr, ptr %buf2.i, align 8, !dbg !1091, !tbaa !816
  %offset3.i = getelementptr inbounds i8, ptr %18, i64 32, !dbg !1092
  %22 = load i32, ptr %offset3.i, align 8, !dbg !1092, !tbaa !1093
  %sub.i = sub i32 %16, %22, !dbg !1094
  %idx.ext.i = zext i32 %sub.i to i64, !dbg !1095
  %add.ptr.i = getelementptr inbounds i8, ptr %21, i64 %idx.ext.i, !dbg !1095
  %len.i = getelementptr inbounds i8, ptr %cur_io.0171, i64 40, !dbg !1096
  %23 = load i32, ptr %len.i, align 8, !dbg !1096, !tbaa !1097
  %conv.i = zext i32 %23 to i64, !dbg !1098
  tail call void @llvm.memcpy.p0.p0.i64(ptr align 1 %20, ptr align 1 %add.ptr.i, i64 %conv.i, i1 false), !dbg !1099
  br label %_read_from_wbuf.exit, !dbg !1100

if.else.i:                                        ; preds = %if.then34
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !1074, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !1101
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1071, metadata !DIExpression()), !dbg !1101
  %iovcnt.i = getelementptr inbounds i8, ptr %cur_io.0171, i64 32
  %24 = load i32, ptr %iovcnt.i, align 8, !dbg !1102, !tbaa !1103
  %cmp733.not.i = icmp eq i32 %24, 0, !dbg !1104
  br i1 %cmp733.not.i, label %_read_from_wbuf.exit, label %for.body.lr.ph.i, !dbg !1105

for.body.lr.ph.i:                                 ; preds = %if.else.i
  %offset5.i = getelementptr inbounds i8, ptr %18, i64 32, !dbg !1106
  %25 = load i32, ptr %offset5.i, align 8, !dbg !1106, !tbaa !1093
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %16, i32 %25), metadata !1074, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !1101
  %sub6.i = sub i32 %16, %25, !dbg !1107
  tail call void @llvm.dbg.value(metadata i32 %sub6.i, metadata !1074, metadata !DIExpression()), !dbg !1101
  %buf11.i = getelementptr inbounds i8, ptr %18, i64 8
  br label %for.body.i, !dbg !1105

for.body.i:                                       ; preds = %for.body.i, %for.body.lr.ph.i
  %indvars.iv.i = phi i64 [ 0, %for.body.lr.ph.i ], [ %indvars.iv.next.i, %for.body.i ]
  %off.034.i = phi i32 [ %sub6.i, %for.body.lr.ph.i ], [ %conv16.i, %for.body.i ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i, metadata !1071, metadata !DIExpression()), !dbg !1101
  tail call void @llvm.dbg.value(metadata i32 %off.034.i, metadata !1074, metadata !DIExpression()), !dbg !1101
  %26 = load ptr, ptr %iov.i, align 8, !dbg !1108, !tbaa !1085
  %arrayidx.i = getelementptr inbounds %struct.iovec, ptr %26, i64 %indvars.iv.i, !dbg !1109
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i, metadata !1075, metadata !DIExpression()), !dbg !1110
  %27 = load ptr, ptr %arrayidx.i, align 8, !dbg !1111, !tbaa !1112
  %28 = load ptr, ptr %buf11.i, align 8, !dbg !1114, !tbaa !816
  %idx.ext12.i = zext i32 %off.034.i to i64, !dbg !1115
  %add.ptr13.i = getelementptr inbounds i8, ptr %28, i64 %idx.ext12.i, !dbg !1115
  %iov_len.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 8, !dbg !1116
  %29 = load i64, ptr %iov_len.i, align 8, !dbg !1116, !tbaa !1117
  tail call void @llvm.memcpy.p0.p0.i64(ptr align 1 %27, ptr align 1 %add.ptr13.i, i64 %29, i1 false), !dbg !1118
  %30 = load i64, ptr %iov_len.i, align 8, !dbg !1119, !tbaa !1117
  %31 = trunc i64 %30 to i32, !dbg !1120
  %conv16.i = add i32 %off.034.i, %31, !dbg !1120
  tail call void @llvm.dbg.value(metadata i32 %conv16.i, metadata !1074, metadata !DIExpression()), !dbg !1101
  %indvars.iv.next.i = add nuw nsw i64 %indvars.iv.i, 1, !dbg !1121
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !1071, metadata !DIExpression()), !dbg !1101
  %32 = load i32, ptr %iovcnt.i, align 8, !dbg !1102, !tbaa !1103
  %33 = zext i32 %32 to i64, !dbg !1104
  %cmp7.i = icmp ult i64 %indvars.iv.next.i, %33, !dbg !1104
  br i1 %cmp7.i, label %for.body.i, label %_read_from_wbuf.exit, !dbg !1105, !llvm.loop !1122

_read_from_wbuf.exit:                             ; preds = %for.body.i, %if.then.i, %if.else.i
  %len17.i = getelementptr inbounds i8, ptr %cur_io.0171, i64 40, !dbg !1124
  %34 = load i32, ptr %len17.i, align 8, !dbg !1124, !tbaa !1097
  tail call void @llvm.dbg.value(metadata i32 %34, metadata !991, metadata !DIExpression()), !dbg !1035
  tail call void @llvm.dbg.value(metadata i32 0, metadata !992, metadata !DIExpression()), !dbg !1035
  br label %if.end45, !dbg !1125

if.else36:                                        ; preds = %land.lhs.true32, %if.then30
  %refcount = getelementptr inbounds i8, ptr %arrayidx, i64 68, !dbg !1126
  %35 = load i32, ptr %refcount, align 4, !dbg !1128, !tbaa !441
  %inc37 = add i32 %35, 1, !dbg !1128
  store i32 %inc37, ptr %refcount, align 4, !dbg !1128, !tbaa !441
  br label %if.end45

if.end45.thread:                                  ; preds = %land.lhs.true28, %land.lhs.true, %sw.bb
  tail call void @llvm.dbg.value(metadata i32 0, metadata !992, metadata !DIExpression()), !dbg !1035
  tail call void @llvm.dbg.value(metadata i32 -2, metadata !991, metadata !DIExpression()), !dbg !1035
  %call47160 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #14, !dbg !1129
  br label %sw.epilog, !dbg !1130

if.end45:                                         ; preds = %_read_from_wbuf.exit, %if.else36
  %ret.0 = phi i32 [ %34, %_read_from_wbuf.exit ], [ 0, %if.else36 ], !dbg !1035
  %tobool48.not = phi i1 [ true, %_read_from_wbuf.exit ], [ false, %if.else36 ], !dbg !1035
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !992, metadata !DIExpression()), !dbg !1035
  tail call void @llvm.dbg.value(metadata i32 %ret.0, metadata !991, metadata !DIExpression()), !dbg !1035
  %call39 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats_mutex) #14, !dbg !1131
  %len = getelementptr inbounds i8, ptr %cur_io.0171, i64 40, !dbg !1132
  %36 = load i32, ptr %len, align 8, !dbg !1132, !tbaa !1097
  %conv = zext i32 %36 to i64, !dbg !1133
  %37 = load i64, ptr %bytes_read, align 8, !dbg !1134, !tbaa !1135
  %add = add i64 %37, %conv, !dbg !1134
  store i64 %add, ptr %bytes_read, align 8, !dbg !1134, !tbaa !1135
  %38 = load i64, ptr %objects_read, align 8, !dbg !1136, !tbaa !1137
  %inc41 = add i64 %38, 1, !dbg !1136
  store i64 %inc41, ptr %objects_read, align 8, !dbg !1136, !tbaa !1137
  %call43 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats_mutex) #14, !dbg !1138
  %call47 = tail call i32 @pthread_mutex_unlock(ptr noundef %arrayidx) #14, !dbg !1129
  br i1 %tobool48.not, label %sw.epilog, label %if.then49, !dbg !1130

if.then49:                                        ; preds = %if.end45
  %iov = getelementptr inbounds i8, ptr %cur_io.0171, i64 24, !dbg !1139
  %39 = load ptr, ptr %iov, align 8, !dbg !1139, !tbaa !1085
  %cmp50 = icmp eq ptr %39, null, !dbg !1143
  %fd = getelementptr inbounds i8, ptr %arrayidx, i64 88, !dbg !1144
  %40 = load i32, ptr %fd, align 8, !dbg !1144, !tbaa !738
  br i1 %cmp50, label %if.then52, label %if.else61, !dbg !1145

if.then52:                                        ; preds = %if.then49
  %buf = getelementptr inbounds i8, ptr %cur_io.0171, i64 16, !dbg !1146
  %41 = load ptr, ptr %buf, align 8, !dbg !1146, !tbaa !1090
  %42 = load i32, ptr %len, align 8, !dbg !1148, !tbaa !1097
  %conv54 = zext i32 %42 to i64, !dbg !1149
  %offset55 = getelementptr inbounds i8, ptr %arrayidx, i64 56, !dbg !1150
  %43 = load i64, ptr %offset55, align 8, !dbg !1150, !tbaa !746
  %offset56 = getelementptr inbounds i8, ptr %cur_io.0171, i64 44, !dbg !1151
  %44 = load i32, ptr %offset56, align 4, !dbg !1151, !tbaa !1060
  %conv57 = zext i32 %44 to i64, !dbg !1152
  %add58 = add i64 %43, %conv57, !dbg !1153
  %call59 = tail call i64 @pread(i32 noundef %40, ptr noundef %41, i64 noundef %conv54, i64 noundef %add58) #14, !dbg !1154
  %conv60 = trunc i64 %call59 to i32, !dbg !1154
  tail call void @llvm.dbg.value(metadata i32 %conv60, metadata !991, metadata !DIExpression()), !dbg !1035
  br label %if.then88.critedge, !dbg !1155

if.else61:                                        ; preds = %if.then49
  %iovcnt = getelementptr inbounds i8, ptr %cur_io.0171, i64 32, !dbg !1156
  %45 = load i32, ptr %iovcnt, align 8, !dbg !1156, !tbaa !1103
  %offset64 = getelementptr inbounds i8, ptr %arrayidx, i64 56, !dbg !1158
  %46 = load i64, ptr %offset64, align 8, !dbg !1158, !tbaa !746
  %offset65 = getelementptr inbounds i8, ptr %cur_io.0171, i64 44, !dbg !1159
  %47 = load i32, ptr %offset65, align 4, !dbg !1159, !tbaa !1060
  %conv66 = zext i32 %47 to i64, !dbg !1160
  %add67 = add i64 %46, %conv66, !dbg !1161
  %call68 = tail call i64 @preadv(i32 noundef %40, ptr noundef nonnull %39, i32 noundef %45, i64 noundef %add67) #14, !dbg !1162
  %conv69 = trunc i64 %call68 to i32, !dbg !1162
  tail call void @llvm.dbg.value(metadata i32 %conv69, metadata !991, metadata !DIExpression()), !dbg !1035
  br label %if.then88.critedge

sw.bb72:                                          ; preds = %while.body21
  tail call void @llvm.dbg.value(metadata i32 0, metadata !992, metadata !DIExpression()), !dbg !1035
  %fd73 = getelementptr inbounds i8, ptr %arrayidx, i64 88, !dbg !1163
  %48 = load i32, ptr %fd73, align 8, !dbg !1163, !tbaa !738
  %buf74 = getelementptr inbounds i8, ptr %cur_io.0171, i64 16, !dbg !1164
  %49 = load ptr, ptr %buf74, align 8, !dbg !1164, !tbaa !1090
  %len75 = getelementptr inbounds i8, ptr %cur_io.0171, i64 40, !dbg !1165
  %50 = load i32, ptr %len75, align 8, !dbg !1165, !tbaa !1097
  %conv76 = zext i32 %50 to i64, !dbg !1166
  %offset77 = getelementptr inbounds i8, ptr %arrayidx, i64 56, !dbg !1167
  %51 = load i64, ptr %offset77, align 8, !dbg !1167, !tbaa !746
  %offset78 = getelementptr inbounds i8, ptr %cur_io.0171, i64 44, !dbg !1168
  %52 = load i32, ptr %offset78, align 4, !dbg !1168, !tbaa !1060
  %conv79 = zext i32 %52 to i64, !dbg !1169
  %add80 = add i64 %51, %conv79, !dbg !1170
  %call81 = tail call i64 @pwrite(i32 noundef %48, ptr noundef %49, i64 noundef %conv76, i64 noundef %add80) #14, !dbg !1171
  %conv82 = trunc i64 %call81 to i32, !dbg !1171
  tail call void @llvm.dbg.value(metadata i32 %conv82, metadata !991, metadata !DIExpression()), !dbg !1035
  br label %sw.epilog, !dbg !1172

sw.epilog:                                        ; preds = %if.end45.thread, %if.end45, %sw.bb72
  %ret.2 = phi i32 [ %conv82, %sw.bb72 ], [ %ret.0, %if.end45 ], [ -2, %if.end45.thread ], !dbg !1035
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !992, metadata !DIExpression()), !dbg !1035
  tail call void @llvm.dbg.value(metadata i32 %ret.2, metadata !991, metadata !DIExpression()), !dbg !1035
  %cb = getelementptr inbounds i8, ptr %cur_io.0171, i64 56, !dbg !1173
  %53 = load ptr, ptr %cb, align 8, !dbg !1173, !tbaa !1174
  tail call void %53(ptr noundef nonnull %0, ptr noundef nonnull %cur_io.0171, i32 noundef %ret.2) #14, !dbg !1175
  br label %if.end94, !dbg !1176

if.then88.critedge:                               ; preds = %if.else61, %if.then52, %while.body21
  %ret.2.ph = phi i32 [ %conv69, %if.else61 ], [ %conv60, %if.then52 ], [ 0, %while.body21 ]
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !992, metadata !DIExpression()), !dbg !1035
  tail call void @llvm.dbg.value(metadata i32 %ret.2, metadata !991, metadata !DIExpression()), !dbg !1035
  %cb.c = getelementptr inbounds i8, ptr %cur_io.0171, i64 56, !dbg !1173
  %54 = load ptr, ptr %cb.c, align 8, !dbg !1173, !tbaa !1174
  tail call void %54(ptr noundef nonnull %0, ptr noundef nonnull %cur_io.0171, i32 noundef %ret.2.ph) #14, !dbg !1175
  %call90 = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx) #14, !dbg !1177
  %refcount91 = getelementptr inbounds i8, ptr %arrayidx, i64 68, !dbg !1180
  %55 = load i32, ptr %refcount91, align 4, !dbg !1181, !tbaa !441
  %dec = add i32 %55, -1, !dbg !1181
  store i32 %dec, ptr %refcount91, align 4, !dbg !1181, !tbaa !441
  %call93 = tail call i32 @pthread_mutex_unlock(ptr noundef %arrayidx) #14, !dbg !1182
  br label %if.end94, !dbg !1183

if.end94:                                         ; preds = %sw.epilog, %if.then88.critedge
  tail call void @llvm.dbg.value(metadata ptr %7, metadata !988, metadata !DIExpression()), !dbg !999
  %tobool20.not = icmp eq ptr %7, null, !dbg !1012
  br i1 %tobool20.not, label %while.cond.loopexit, label %while.body21, !dbg !1012, !llvm.loop !1184
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 -1, 1) i32 @extstore_write_request(ptr noundef %ptr, i32 noundef %bucket, i32 noundef %free_bucket, ptr nocapture noundef %io) local_unnamed_addr #0 !dbg !1186 {
entry:
  %st.i156 = alloca %struct.extstore_stats, align 8, !DIAssignID !1200
  %st.i = alloca %struct.extstore_stats, align 8, !DIAssignID !1201
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1190, metadata !DIExpression()), !dbg !1202
  tail call void @llvm.dbg.value(metadata i32 %bucket, metadata !1191, metadata !DIExpression()), !dbg !1202
  tail call void @llvm.dbg.value(metadata i32 %free_bucket, metadata !1192, metadata !DIExpression()), !dbg !1202
  tail call void @llvm.dbg.value(metadata ptr %io, metadata !1193, metadata !DIExpression()), !dbg !1202
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1194, metadata !DIExpression()), !dbg !1202
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !1196, metadata !DIExpression()), !dbg !1202
  %page_bucketcount = getelementptr inbounds i8, ptr %ptr, i64 124, !dbg !1203
  %0 = load i32, ptr %page_bucketcount, align 4, !dbg !1203, !tbaa !796
  %cmp.not = icmp ugt i32 %0, %bucket, !dbg !1205
  br i1 %cmp.not, label %if.end, label %cleanup, !dbg !1206

if.end:                                           ; preds = %entry
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %ptr) #14, !dbg !1207
  %page_buckets = getelementptr inbounds i8, ptr %ptr, i64 80, !dbg !1208
  %1 = load ptr, ptr %page_buckets, align 8, !dbg !1208, !tbaa !474
  %idxprom = zext i32 %bucket to i64, !dbg !1209
  %arrayidx = getelementptr inbounds ptr, ptr %1, i64 %idxprom, !dbg !1209
  %2 = load ptr, ptr %arrayidx, align 8, !dbg !1209, !tbaa !477
  tail call void @llvm.dbg.value(metadata ptr %2, metadata !1195, metadata !DIExpression()), !dbg !1202
  %tobool.not = icmp eq ptr %2, null, !dbg !1210
  br i1 %tobool.not, label %if.then1, label %if.end8, !dbg !1212

if.then1:                                         ; preds = %if.end
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1213, metadata !DIExpression()), !dbg !1221
  tail call void @llvm.dbg.value(metadata i32 %bucket, metadata !1218, metadata !DIExpression()), !dbg !1221
  tail call void @llvm.dbg.value(metadata i32 %free_bucket, metadata !1219, metadata !DIExpression()), !dbg !1221
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1220, metadata !DIExpression()), !dbg !1221
  %free_page_buckets.i = getelementptr inbounds i8, ptr %ptr, i64 88, !dbg !1224
  %3 = load ptr, ptr %free_page_buckets.i, align 8, !dbg !1224, !tbaa !512
  %idxprom.i = zext i32 %free_bucket to i64, !dbg !1226
  %arrayidx.i = getelementptr inbounds ptr, ptr %3, i64 %idxprom.i, !dbg !1226
  %4 = load ptr, ptr %arrayidx.i, align 8, !dbg !1226, !tbaa !477
  %cmp.not.i = icmp eq ptr %4, null, !dbg !1227
  br i1 %cmp.not.i, label %if.else.i, label %if.then18.i, !dbg !1228

if.else.i:                                        ; preds = %if.then1
  %5 = load ptr, ptr %3, align 8, !dbg !1229, !tbaa !477
  %cmp9.not.i = icmp eq ptr %5, null, !dbg !1231
  br i1 %cmp9.not.i, label %if.then7, label %if.then18.i, !dbg !1232

if.then18.i:                                      ; preds = %if.else.i, %if.then1
  %.sink.i = phi ptr [ %4, %if.then1 ], [ %5, %if.else.i ]
  %arrayidx.sink.i = phi ptr [ %arrayidx.i, %if.then1 ], [ %3, %if.else.i ]
  %next.i = getelementptr inbounds i8, ptr %.sink.i, i64 112, !dbg !1233
  %6 = load ptr, ptr %next.i, align 8, !dbg !1233, !tbaa !489
  store ptr %6, ptr %arrayidx.sink.i, align 8, !dbg !1233, !tbaa !477
  tail call void @llvm.dbg.value(metadata ptr %.sink.i, metadata !1220, metadata !DIExpression()), !dbg !1221
  %7 = load ptr, ptr %page_buckets, align 8, !dbg !1234, !tbaa !474
  %arrayidx20.i = getelementptr inbounds ptr, ptr %7, i64 %idxprom, !dbg !1237
  %8 = load ptr, ptr %arrayidx20.i, align 8, !dbg !1237, !tbaa !477
  store ptr %8, ptr %next.i, align 8, !dbg !1238, !tbaa !489
  store ptr %.sink.i, ptr %arrayidx20.i, align 8, !dbg !1239, !tbaa !477
  %active.i = getelementptr inbounds i8, ptr %.sink.i, i64 94, !dbg !1240
  store i8 1, ptr %active.i, align 2, !dbg !1241, !tbaa !412
  %free.i = getelementptr inbounds i8, ptr %.sink.i, i64 96, !dbg !1242
  store i8 0, ptr %free.i, align 8, !dbg !1243, !tbaa !423
  %closed.i = getelementptr inbounds i8, ptr %.sink.i, i64 95, !dbg !1244
  store i8 0, ptr %closed.i, align 1, !dbg !1245, !tbaa !431
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1246, metadata !DIExpression()), !dbg !1251
  %version.i.i = getelementptr inbounds i8, ptr %ptr, i64 104, !dbg !1253
  %9 = load i32, ptr %version.i.i, align 8, !dbg !1254, !tbaa !779
  %inc.i.i = add i32 %9, 1, !dbg !1254
  store i32 %inc.i.i, ptr %version.i.i, align 8, !dbg !1254, !tbaa !779
  %version.i = getelementptr inbounds i8, ptr %.sink.i, i64 64, !dbg !1255
  store i32 %9, ptr %version.i, align 8, !dbg !1256, !tbaa !400
  %bucket25.i = getelementptr inbounds i8, ptr %.sink.i, i64 80, !dbg !1257
  store i32 %bucket, ptr %bucket25.i, align 8, !dbg !1258, !tbaa !435
  %page_free.i = getelementptr inbounds i8, ptr %ptr, i64 120, !dbg !1259
  %10 = load i32, ptr %page_free.i, align 8, !dbg !1260, !tbaa !296
  %dec.i = add i32 %10, -1, !dbg !1260
  store i32 %dec.i, ptr %page_free.i, align 8, !dbg !1260, !tbaa !296
  %stats_mutex.i = getelementptr inbounds i8, ptr %ptr, i64 136, !dbg !1261
  %call26.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats_mutex.i) #14, !dbg !1261
  %stats.i = getelementptr inbounds i8, ptr %ptr, i64 176, !dbg !1261
  %11 = load i64, ptr %stats.i, align 8, !dbg !1261, !tbaa !1263
  %add.i = add i64 %11, 1, !dbg !1261
  store i64 %add.i, ptr %stats.i, align 8, !dbg !1261, !tbaa !1263
  %call28.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats_mutex.i) #14, !dbg !1261
  br label %if.end8, !dbg !1264

if.then7:                                         ; preds = %if.else.i
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1195, metadata !DIExpression()), !dbg !1202
  %call5 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %ptr) #14, !dbg !1265
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1266, metadata !DIExpression(), metadata !1201, metadata ptr %st.i, metadata !DIExpression()), !dbg !1278
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1271, metadata !DIExpression()), !dbg !1278
  tail call void @llvm.dbg.value(metadata i32 %bucket, metadata !1272, metadata !DIExpression()), !dbg !1278
  tail call void @llvm.dbg.value(metadata i32 %free_bucket, metadata !1273, metadata !DIExpression()), !dbg !1278
  call void @llvm.lifetime.start.p0(i64 144, ptr nonnull %st.i) #14, !dbg !1282
  %page_count.i = getelementptr inbounds i8, ptr %ptr, i64 116, !dbg !1283
  %12 = load i32, ptr %page_count.i, align 4, !dbg !1283, !tbaa !310
  %conv.i = zext i32 %12 to i64, !dbg !1284
  %call.i = tail call noalias ptr @calloc(i64 noundef %conv.i, i64 noundef 32) #15, !dbg !1285
  %page_data.i = getelementptr inbounds i8, ptr %st.i, i64 136, !dbg !1286
  store ptr %call.i, ptr %page_data.i, align 8, !dbg !1287, !tbaa !375, !DIAssignID !1288
  tail call void @llvm.dbg.assign(metadata ptr %call.i, metadata !1266, metadata !DIExpression(DW_OP_LLVM_fragment, 1088, 64), metadata !1288, metadata ptr %page_data.i, metadata !DIExpression()), !dbg !1278
  call void @extstore_get_page_data(ptr noundef nonnull %ptr, ptr noundef nonnull %st.i), !dbg !1289
  tail call void @llvm.dbg.value(metadata i64 -1, metadata !1274, metadata !DIExpression()), !dbg !1278
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1275, metadata !DIExpression()), !dbg !1278
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1276, metadata !DIExpression()), !dbg !1290
  %13 = load i32, ptr %page_count.i, align 4, !tbaa !310
  %cmp59.not.i = icmp eq i32 %13, 0, !dbg !1291
  br i1 %cmp59.not.i, label %_evict_page.exit, label %for.body.preheader.i, !dbg !1293

for.body.preheader.i:                             ; preds = %if.then7
  %wide.trip.count.i = zext i32 %13 to i64, !dbg !1291
  br label %for.body.i, !dbg !1293

for.body.i:                                       ; preds = %for.inc.i, %for.body.preheader.i
  %indvars.iv.i = phi i64 [ 0, %for.body.preheader.i ], [ %indvars.iv.next.i, %for.inc.i ]
  %low_page.061.i = phi i32 [ 0, %for.body.preheader.i ], [ %low_page.1.i, %for.inc.i ]
  %low_version.060.i = phi i64 [ -1, %for.body.preheader.i ], [ %low_version.1.i, %for.inc.i ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i, metadata !1276, metadata !DIExpression()), !dbg !1290
  tail call void @llvm.dbg.value(metadata i32 %low_page.061.i, metadata !1275, metadata !DIExpression()), !dbg !1278
  tail call void @llvm.dbg.value(metadata i64 %low_version.060.i, metadata !1274, metadata !DIExpression()), !dbg !1278
  %free_bucket4.i = getelementptr inbounds %struct.extstore_page_data, ptr %call.i, i64 %indvars.iv.i, i32 3, !dbg !1294
  %14 = load i32, ptr %free_bucket4.i, align 4, !dbg !1294, !tbaa !397
  %tobool.not.i = icmp eq i32 %14, 0, !dbg !1297
  %cmp9.not.i124 = icmp eq i32 %14, %free_bucket
  %or.cond.i = or i1 %tobool.not.i, %cmp9.not.i124, !dbg !1298
  br i1 %or.cond.i, label %if.end.i, label %for.inc.i, !dbg !1298

if.end.i:                                         ; preds = %for.body.i
  %arrayidx13.i = getelementptr inbounds %struct.extstore_page_data, ptr %call.i, i64 %indvars.iv.i, !dbg !1299
  %15 = load i64, ptr %arrayidx13.i, align 8, !dbg !1301, !tbaa !404
  %cmp14.i = icmp eq i64 %15, 0, !dbg !1302
  br i1 %cmp14.i, label %_evict_page.exit, label %if.end17.i, !dbg !1303

if.end17.i:                                       ; preds = %if.end.i
  %active.i125 = getelementptr inbounds i8, ptr %arrayidx13.i, i64 24, !dbg !1304
  %16 = load i8, ptr %active.i125, align 8, !dbg !1304, !tbaa !419, !range !413, !noundef !414
  %tobool21.i = trunc nuw i8 %16 to i1, !dbg !1304
  %cmp27.i = icmp uge i64 %15, %low_version.060.i
  %or.cond53.not.i = select i1 %tobool21.i, i1 true, i1 %cmp27.i, !dbg !1306
  %spec.select.i = select i1 %or.cond53.not.i, i64 %low_version.060.i, i64 %15, !dbg !1306
  %17 = trunc nuw nsw i64 %indvars.iv.i to i32, !dbg !1306
  %spec.select54.i = select i1 %or.cond53.not.i, i32 %low_page.061.i, i32 %17, !dbg !1306
  br label %for.inc.i, !dbg !1306

for.inc.i:                                        ; preds = %if.end17.i, %for.body.i
  %low_version.1.i = phi i64 [ %low_version.060.i, %for.body.i ], [ %spec.select.i, %if.end17.i ], !dbg !1278
  %low_page.1.i = phi i32 [ %low_page.061.i, %for.body.i ], [ %spec.select54.i, %if.end17.i ], !dbg !1278
  tail call void @llvm.dbg.value(metadata i32 %low_page.1.i, metadata !1275, metadata !DIExpression()), !dbg !1278
  tail call void @llvm.dbg.value(metadata i64 %low_version.1.i, metadata !1274, metadata !DIExpression()), !dbg !1278
  %indvars.iv.next.i = add nuw nsw i64 %indvars.iv.i, 1, !dbg !1307
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !1276, metadata !DIExpression()), !dbg !1290
  %exitcond.not.i = icmp eq i64 %indvars.iv.next.i, %wide.trip.count.i, !dbg !1291
  br i1 %exitcond.not.i, label %cleanup.i, label %for.body.i, !dbg !1293, !llvm.loop !1308

cleanup.i:                                        ; preds = %for.inc.i
  tail call void @llvm.dbg.value(metadata i64 %low_version.1.i, metadata !1274, metadata !DIExpression()), !dbg !1278
  %cmp35.not.i = icmp eq i64 %low_version.1.i, -1, !dbg !1310
  br i1 %cmp35.not.i, label %_evict_page.exit, label %if.then37.i, !dbg !1312

if.then37.i:                                      ; preds = %cleanup.i
  tail call void @extstore_evict_page(ptr noundef nonnull %ptr, i32 noundef %low_page.1.i, i64 noundef %low_version.1.i), !dbg !1313
  br label %_evict_page.exit, !dbg !1315

_evict_page.exit:                                 ; preds = %if.end.i, %if.then7, %cleanup.i, %if.then37.i
  call void @llvm.lifetime.end.p0(i64 144, ptr nonnull %st.i) #14, !dbg !1316
  br label %cleanup, !dbg !1317

if.end8:                                          ; preds = %if.end, %if.then18.i
  %p.0.ph = phi ptr [ %.sink.i, %if.then18.i ], [ %2, %if.end ]
  tail call void @llvm.dbg.value(metadata ptr %p.0.ph, metadata !1195, metadata !DIExpression()), !dbg !1202
  %call5192 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %ptr) #14, !dbg !1265
  %call10 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %p.0.ph) #14, !dbg !1318
  %active = getelementptr inbounds i8, ptr %p.0.ph, i64 94, !dbg !1319
  %18 = load i8, ptr %active, align 2, !dbg !1319, !tbaa !412, !range !413, !noundef !414
  %tobool11 = trunc nuw i8 %18 to i1, !dbg !1319
  br i1 %tobool11, label %lor.lhs.false, label %if.then18, !dbg !1320

lor.lhs.false:                                    ; preds = %if.end8
  %wbuf = getelementptr inbounds i8, ptr %p.0.ph, i64 104, !dbg !1321
  %19 = load ptr, ptr %wbuf, align 8, !dbg !1321, !tbaa !1083
  %tobool12.not = icmp eq ptr %19, null, !dbg !1322
  br i1 %tobool12.not, label %land.lhs.true, label %lor.lhs.false13, !dbg !1323

lor.lhs.false13:                                  ; preds = %lor.lhs.false
  %full = getelementptr inbounds i8, ptr %19, i64 36, !dbg !1324
  %20 = load i8, ptr %full, align 4, !dbg !1324, !tbaa !1325, !range !413, !noundef !414
  %tobool15 = trunc nuw i8 %20 to i1, !dbg !1324
  br i1 %tobool15, label %land.lhs.true.thread, label %land.lhs.true32.thread, !dbg !1326

land.lhs.true:                                    ; preds = %lor.lhs.false
  %allocated = getelementptr inbounds i8, ptr %p.0.ph, i64 72, !dbg !1327
  %21 = load i32, ptr %allocated, align 8, !dbg !1327, !tbaa !499
  %conv = zext i32 %21 to i64, !dbg !1328
  %page_size = getelementptr inbounds i8, ptr %ptr, i64 96, !dbg !1329
  %22 = load i64, ptr %page_size, align 8, !dbg !1329, !tbaa !328
  %cmp16.not = icmp ugt i64 %22, %conv, !dbg !1330
  br i1 %cmp16.not, label %land.lhs.true46, label %if.then18, !dbg !1331

land.lhs.true.thread:                             ; preds = %lor.lhs.false13
  %allocated198 = getelementptr inbounds i8, ptr %p.0.ph, i64 72, !dbg !1327
  %23 = load i32, ptr %allocated198, align 8, !dbg !1327, !tbaa !499
  %conv199 = zext i32 %23 to i64, !dbg !1328
  %page_size200 = getelementptr inbounds i8, ptr %ptr, i64 96, !dbg !1329
  %24 = load i64, ptr %page_size200, align 8, !dbg !1329, !tbaa !328
  %cmp16.not201 = icmp ugt i64 %24, %conv199, !dbg !1330
  br i1 %cmp16.not201, label %land.lhs.true56, label %if.then18, !dbg !1331

if.then18:                                        ; preds = %land.lhs.true.thread, %land.lhs.true, %if.end8
  %call20 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %p.0.ph) #14, !dbg !1332
  %call22 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %ptr) #14, !dbg !1333
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1213, metadata !DIExpression()), !dbg !1334
  tail call void @llvm.dbg.value(metadata i32 %bucket, metadata !1218, metadata !DIExpression()), !dbg !1334
  tail call void @llvm.dbg.value(metadata i32 %free_bucket, metadata !1219, metadata !DIExpression()), !dbg !1334
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1220, metadata !DIExpression()), !dbg !1334
  %free_page_buckets.i126 = getelementptr inbounds i8, ptr %ptr, i64 88, !dbg !1336
  %25 = load ptr, ptr %free_page_buckets.i126, align 8, !dbg !1336, !tbaa !512
  %idxprom.i127 = zext i32 %free_bucket to i64, !dbg !1337
  %arrayidx.i128 = getelementptr inbounds ptr, ptr %25, i64 %idxprom.i127, !dbg !1337
  %26 = load ptr, ptr %arrayidx.i128, align 8, !dbg !1337, !tbaa !477
  %cmp.not.i129 = icmp eq ptr %26, null, !dbg !1338
  br i1 %cmp.not.i129, label %if.else.i153, label %_allocate_page.exit155, !dbg !1339

if.else.i153:                                     ; preds = %if.then18
  %27 = load ptr, ptr %25, align 8, !dbg !1340, !tbaa !477
  %cmp9.not.i154 = icmp eq ptr %27, null, !dbg !1341
  br i1 %cmp9.not.i154, label %if.then27, label %_allocate_page.exit155, !dbg !1342

_allocate_page.exit155:                           ; preds = %if.then18, %if.else.i153
  %.sink.i131 = phi ptr [ %26, %if.then18 ], [ %27, %if.else.i153 ]
  %arrayidx.sink.i132 = phi ptr [ %arrayidx.i128, %if.then18 ], [ %25, %if.else.i153 ]
  %next.i133 = getelementptr inbounds i8, ptr %.sink.i131, i64 112, !dbg !1343
  %28 = load ptr, ptr %next.i133, align 8, !dbg !1343, !tbaa !489
  store ptr %28, ptr %arrayidx.sink.i132, align 8, !dbg !1343, !tbaa !477
  tail call void @llvm.dbg.value(metadata ptr %.sink.i131, metadata !1220, metadata !DIExpression()), !dbg !1334
  %29 = load ptr, ptr %page_buckets, align 8, !dbg !1344, !tbaa !474
  %arrayidx20.i136 = getelementptr inbounds ptr, ptr %29, i64 %idxprom, !dbg !1345
  %30 = load ptr, ptr %arrayidx20.i136, align 8, !dbg !1345, !tbaa !477
  store ptr %30, ptr %next.i133, align 8, !dbg !1346, !tbaa !489
  store ptr %.sink.i131, ptr %arrayidx20.i136, align 8, !dbg !1347, !tbaa !477
  %active.i138 = getelementptr inbounds i8, ptr %.sink.i131, i64 94, !dbg !1348
  store i8 1, ptr %active.i138, align 2, !dbg !1349, !tbaa !412
  %free.i139 = getelementptr inbounds i8, ptr %.sink.i131, i64 96, !dbg !1350
  store i8 0, ptr %free.i139, align 8, !dbg !1351, !tbaa !423
  %closed.i140 = getelementptr inbounds i8, ptr %.sink.i131, i64 95, !dbg !1352
  store i8 0, ptr %closed.i140, align 1, !dbg !1353, !tbaa !431
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1246, metadata !DIExpression()), !dbg !1354
  %version.i.i141 = getelementptr inbounds i8, ptr %ptr, i64 104, !dbg !1356
  %31 = load i32, ptr %version.i.i141, align 8, !dbg !1357, !tbaa !779
  %inc.i.i142 = add i32 %31, 1, !dbg !1357
  store i32 %inc.i.i142, ptr %version.i.i141, align 8, !dbg !1357, !tbaa !779
  %version.i143 = getelementptr inbounds i8, ptr %.sink.i131, i64 64, !dbg !1358
  store i32 %31, ptr %version.i143, align 8, !dbg !1359, !tbaa !400
  %bucket25.i144 = getelementptr inbounds i8, ptr %.sink.i131, i64 80, !dbg !1360
  store i32 %bucket, ptr %bucket25.i144, align 8, !dbg !1361, !tbaa !435
  %page_free.i145 = getelementptr inbounds i8, ptr %ptr, i64 120, !dbg !1362
  %32 = load i32, ptr %page_free.i145, align 8, !dbg !1363, !tbaa !296
  %dec.i146 = add i32 %32, -1, !dbg !1363
  store i32 %dec.i146, ptr %page_free.i145, align 8, !dbg !1363, !tbaa !296
  %stats_mutex.i147 = getelementptr inbounds i8, ptr %ptr, i64 136, !dbg !1364
  %call26.i148 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats_mutex.i147) #14, !dbg !1364
  %stats.i149 = getelementptr inbounds i8, ptr %ptr, i64 176, !dbg !1364
  %33 = load i64, ptr %stats.i149, align 8, !dbg !1364, !tbaa !1263
  %add.i150 = add i64 %33, 1, !dbg !1364
  store i64 %add.i150, ptr %stats.i149, align 8, !dbg !1364, !tbaa !1263
  %call28.i151 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats_mutex.i147) #14, !dbg !1364
  tail call void @llvm.dbg.value(metadata ptr %.sink.i131, metadata !1197, metadata !DIExpression()), !dbg !1365
  %call25 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %ptr) #14, !dbg !1366
  br label %cleanup, !dbg !1367

if.then27:                                        ; preds = %if.else.i153
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1197, metadata !DIExpression()), !dbg !1365
  %call25196 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %ptr) #14, !dbg !1366
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1266, metadata !DIExpression(), metadata !1200, metadata ptr %st.i156, metadata !DIExpression()), !dbg !1368
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1271, metadata !DIExpression()), !dbg !1368
  tail call void @llvm.dbg.value(metadata i32 %bucket, metadata !1272, metadata !DIExpression()), !dbg !1368
  tail call void @llvm.dbg.value(metadata i32 %free_bucket, metadata !1273, metadata !DIExpression()), !dbg !1368
  call void @llvm.lifetime.start.p0(i64 144, ptr nonnull %st.i156) #14, !dbg !1372
  %page_count.i157 = getelementptr inbounds i8, ptr %ptr, i64 116, !dbg !1373
  %34 = load i32, ptr %page_count.i157, align 4, !dbg !1373, !tbaa !310
  %conv.i158 = zext i32 %34 to i64, !dbg !1374
  %call.i159 = tail call noalias ptr @calloc(i64 noundef %conv.i158, i64 noundef 32) #15, !dbg !1375
  %page_data.i160 = getelementptr inbounds i8, ptr %st.i156, i64 136, !dbg !1376
  store ptr %call.i159, ptr %page_data.i160, align 8, !dbg !1377, !tbaa !375, !DIAssignID !1378
  tail call void @llvm.dbg.assign(metadata ptr %call.i159, metadata !1266, metadata !DIExpression(DW_OP_LLVM_fragment, 1088, 64), metadata !1378, metadata ptr %page_data.i160, metadata !DIExpression()), !dbg !1368
  call void @extstore_get_page_data(ptr noundef nonnull %ptr, ptr noundef nonnull %st.i156), !dbg !1379
  tail call void @llvm.dbg.value(metadata i64 -1, metadata !1274, metadata !DIExpression()), !dbg !1368
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1275, metadata !DIExpression()), !dbg !1368
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1276, metadata !DIExpression()), !dbg !1380
  %35 = load i32, ptr %page_count.i157, align 4, !tbaa !310
  %cmp59.not.i161 = icmp eq i32 %35, 0, !dbg !1381
  br i1 %cmp59.not.i161, label %_evict_page.exit190, label %for.body.preheader.i162, !dbg !1382

for.body.preheader.i162:                          ; preds = %if.then27
  %wide.trip.count.i163 = zext i32 %35 to i64, !dbg !1381
  br label %for.body.i164, !dbg !1382

for.body.i164:                                    ; preds = %for.inc.i172, %for.body.preheader.i162
  %indvars.iv.i165 = phi i64 [ 0, %for.body.preheader.i162 ], [ %indvars.iv.next.i175, %for.inc.i172 ]
  %low_page.061.i166 = phi i32 [ 0, %for.body.preheader.i162 ], [ %low_page.1.i174, %for.inc.i172 ]
  %low_version.060.i167 = phi i64 [ -1, %for.body.preheader.i162 ], [ %low_version.1.i173, %for.inc.i172 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i165, metadata !1276, metadata !DIExpression()), !dbg !1380
  tail call void @llvm.dbg.value(metadata i32 %low_page.061.i166, metadata !1275, metadata !DIExpression()), !dbg !1368
  tail call void @llvm.dbg.value(metadata i64 %low_version.060.i167, metadata !1274, metadata !DIExpression()), !dbg !1368
  %free_bucket4.i168 = getelementptr inbounds %struct.extstore_page_data, ptr %call.i159, i64 %indvars.iv.i165, i32 3, !dbg !1383
  %36 = load i32, ptr %free_bucket4.i168, align 4, !dbg !1383, !tbaa !397
  %tobool.not.i169 = icmp eq i32 %36, 0, !dbg !1384
  %cmp9.not.i170 = icmp eq i32 %36, %free_bucket
  %or.cond.i171 = or i1 %tobool.not.i169, %cmp9.not.i170, !dbg !1385
  br i1 %or.cond.i171, label %if.end.i180, label %for.inc.i172, !dbg !1385

if.end.i180:                                      ; preds = %for.body.i164
  %arrayidx13.i181 = getelementptr inbounds %struct.extstore_page_data, ptr %call.i159, i64 %indvars.iv.i165, !dbg !1386
  %37 = load i64, ptr %arrayidx13.i181, align 8, !dbg !1387, !tbaa !404
  %cmp14.i182 = icmp eq i64 %37, 0, !dbg !1388
  br i1 %cmp14.i182, label %_evict_page.exit190, label %if.end17.i183, !dbg !1389

if.end17.i183:                                    ; preds = %if.end.i180
  %active.i184 = getelementptr inbounds i8, ptr %arrayidx13.i181, i64 24, !dbg !1390
  %38 = load i8, ptr %active.i184, align 8, !dbg !1390, !tbaa !419, !range !413, !noundef !414
  %tobool21.i185 = trunc nuw i8 %38 to i1, !dbg !1390
  %cmp27.i186 = icmp uge i64 %37, %low_version.060.i167
  %or.cond53.not.i187 = select i1 %tobool21.i185, i1 true, i1 %cmp27.i186, !dbg !1391
  %spec.select.i188 = select i1 %or.cond53.not.i187, i64 %low_version.060.i167, i64 %37, !dbg !1391
  %39 = trunc nuw nsw i64 %indvars.iv.i165 to i32, !dbg !1391
  %spec.select54.i189 = select i1 %or.cond53.not.i187, i32 %low_page.061.i166, i32 %39, !dbg !1391
  br label %for.inc.i172, !dbg !1391

for.inc.i172:                                     ; preds = %if.end17.i183, %for.body.i164
  %low_version.1.i173 = phi i64 [ %low_version.060.i167, %for.body.i164 ], [ %spec.select.i188, %if.end17.i183 ], !dbg !1368
  %low_page.1.i174 = phi i32 [ %low_page.061.i166, %for.body.i164 ], [ %spec.select54.i189, %if.end17.i183 ], !dbg !1368
  tail call void @llvm.dbg.value(metadata i32 %low_page.1.i174, metadata !1275, metadata !DIExpression()), !dbg !1368
  tail call void @llvm.dbg.value(metadata i64 %low_version.1.i173, metadata !1274, metadata !DIExpression()), !dbg !1368
  %indvars.iv.next.i175 = add nuw nsw i64 %indvars.iv.i165, 1, !dbg !1392
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i175, metadata !1276, metadata !DIExpression()), !dbg !1380
  %exitcond.not.i176 = icmp eq i64 %indvars.iv.next.i175, %wide.trip.count.i163, !dbg !1381
  br i1 %exitcond.not.i176, label %cleanup.i177, label %for.body.i164, !dbg !1382, !llvm.loop !1393

cleanup.i177:                                     ; preds = %for.inc.i172
  tail call void @llvm.dbg.value(metadata i64 %low_version.1.i173, metadata !1274, metadata !DIExpression()), !dbg !1368
  %cmp35.not.i178 = icmp eq i64 %low_version.1.i173, -1, !dbg !1395
  br i1 %cmp35.not.i178, label %_evict_page.exit190, label %if.then37.i179, !dbg !1396

if.then37.i179:                                   ; preds = %cleanup.i177
  tail call void @extstore_evict_page(ptr noundef nonnull %ptr, i32 noundef %low_page.1.i174, i64 noundef %low_version.1.i173), !dbg !1397
  br label %_evict_page.exit190, !dbg !1398

_evict_page.exit190:                              ; preds = %if.end.i180, %if.then27, %cleanup.i177, %if.then37.i179
  call void @llvm.lifetime.end.p0(i64 144, ptr nonnull %st.i156) #14, !dbg !1399
  br label %cleanup, !dbg !1400

land.lhs.true32.thread:                           ; preds = %lor.lhs.false13
  %free209 = getelementptr inbounds i8, ptr %19, i64 24, !dbg !1401
  %40 = load i32, ptr %free209, align 8, !dbg !1401, !tbaa !829
  %len210 = getelementptr inbounds i8, ptr %io, i64 40, !dbg !1403
  %41 = load i32, ptr %len210, align 8, !dbg !1403, !tbaa !1097
  %cmp34211 = icmp ult i32 %40, %41, !dbg !1404
  br i1 %cmp34211, label %if.end53.thread206, label %land.lhs.true56, !dbg !1405

if.end53.thread206:                               ; preds = %land.lhs.true32.thread
  tail call fastcc void @_submit_wbuf(ptr noundef nonnull %ptr, ptr noundef nonnull %p.0.ph), !dbg !1406
  %42 = load ptr, ptr %wbuf, align 8, !dbg !1408, !tbaa !1083
  %full42 = getelementptr inbounds i8, ptr %42, i64 36, !dbg !1409
  store i8 1, ptr %full42, align 4, !dbg !1410, !tbaa !1325
  br label %land.lhs.true56, !dbg !1411

land.lhs.true46:                                  ; preds = %land.lhs.true
  %allocated47 = getelementptr inbounds i8, ptr %p.0.ph, i64 72, !dbg !1413
  %43 = load i32, ptr %allocated47, align 8, !dbg !1413, !tbaa !499
  %conv48 = zext i32 %43 to i64, !dbg !1415
  %page_size49 = getelementptr inbounds i8, ptr %ptr, i64 96, !dbg !1416
  %44 = load i64, ptr %page_size49, align 8, !dbg !1416, !tbaa !328
  %cmp50 = icmp ugt i64 %44, %conv48, !dbg !1417
  br i1 %cmp50, label %if.end53, label %if.end68, !dbg !1418

if.end53:                                         ; preds = %land.lhs.true46
  tail call fastcc void @_allocate_wbuf(ptr noundef nonnull %ptr, ptr noundef nonnull %p.0.ph), !dbg !1419
  %.pr204.pre = load ptr, ptr %wbuf, align 8, !dbg !1421, !tbaa !1083
  %tobool55.not = icmp eq ptr %.pr204.pre, null, !dbg !1422
  br i1 %tobool55.not, label %if.end68, label %land.lhs.true56, !dbg !1411

land.lhs.true56:                                  ; preds = %land.lhs.true.thread, %land.lhs.true32.thread, %if.end53.thread206, %if.end53
  %45 = phi ptr [ %.pr204.pre, %if.end53 ], [ %42, %if.end53.thread206 ], [ %19, %land.lhs.true32.thread ], [ %19, %land.lhs.true.thread ]
  %full58 = getelementptr inbounds i8, ptr %45, i64 36, !dbg !1423
  %46 = load i8, ptr %full58, align 4, !dbg !1423, !tbaa !1325, !range !413, !noundef !414
  %tobool59 = trunc nuw i8 %46 to i1, !dbg !1423
  br i1 %tobool59, label %if.end68, label %land.lhs.true60, !dbg !1424

land.lhs.true60:                                  ; preds = %land.lhs.true56
  %free62 = getelementptr inbounds i8, ptr %45, i64 24, !dbg !1425
  %47 = load i32, ptr %free62, align 8, !dbg !1425, !tbaa !829
  %len63 = getelementptr inbounds i8, ptr %io, i64 40, !dbg !1426
  %48 = load i32, ptr %len63, align 8, !dbg !1426, !tbaa !1097
  %cmp64.not = icmp ult i32 %47, %48, !dbg !1427
  br i1 %cmp64.not, label %if.end68, label %if.then66, !dbg !1428

if.then66:                                        ; preds = %land.lhs.true60
  %buf_pos = getelementptr inbounds i8, ptr %45, i64 16, !dbg !1429
  %49 = load ptr, ptr %buf_pos, align 8, !dbg !1429, !tbaa !826
  %buf = getelementptr inbounds i8, ptr %io, i64 16, !dbg !1431
  store ptr %49, ptr %buf, align 8, !dbg !1432, !tbaa !1090
  %id = getelementptr inbounds i8, ptr %p.0.ph, i64 92, !dbg !1433
  %50 = load i16, ptr %id, align 4, !dbg !1433, !tbaa !393
  %page_id = getelementptr inbounds i8, ptr %io, i64 48, !dbg !1434
  store i16 %50, ptr %page_id, align 8, !dbg !1435, !tbaa !1038
  br label %cleanup, !dbg !1436

if.end68:                                         ; preds = %land.lhs.true46, %land.lhs.true60, %land.lhs.true56, %if.end53
  %call70 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %p.0.ph) #14, !dbg !1437
  br label %cleanup, !dbg !1438

cleanup:                                          ; preds = %_allocate_page.exit155, %_evict_page.exit190, %entry, %if.end68, %if.then66, %_evict_page.exit
  %retval.0 = phi i32 [ -1, %if.end68 ], [ 0, %if.then66 ], [ -1, %_evict_page.exit ], [ -1, %entry ], [ -1, %_evict_page.exit190 ], [ -1, %_allocate_page.exit155 ], !dbg !1202
  ret i32 %retval.0, !dbg !1439
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @_submit_wbuf(ptr noundef %e, ptr nocapture noundef readonly %p) unnamed_addr #0 !dbg !1440 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !1442, metadata !DIExpression()), !dbg !1446
  tail call void @llvm.dbg.value(metadata ptr %p, metadata !1443, metadata !DIExpression()), !dbg !1446
  %call = tail call i32 @pthread_mutex_lock(ptr noundef %e) #14, !dbg !1447
  %io_stack = getelementptr inbounds i8, ptr %e, i64 56, !dbg !1448
  %0 = load ptr, ptr %io_stack, align 8, !dbg !1448, !tbaa !800
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1445, metadata !DIExpression()), !dbg !1446
  %next = getelementptr inbounds i8, ptr %0, i64 8, !dbg !1449
  %1 = load ptr, ptr %next, align 8, !dbg !1449, !tbaa !840
  store ptr %1, ptr %io_stack, align 8, !dbg !1450, !tbaa !800
  %call3 = tail call i32 @pthread_mutex_unlock(ptr noundef %e) #14, !dbg !1451
  %wbuf = getelementptr inbounds i8, ptr %p, i64 104, !dbg !1452
  %2 = load ptr, ptr %wbuf, align 8, !dbg !1452, !tbaa !1083
  tail call void @llvm.dbg.value(metadata ptr %2, metadata !1444, metadata !DIExpression()), !dbg !1446
  %buf = getelementptr inbounds i8, ptr %2, i64 8, !dbg !1453
  %3 = load ptr, ptr %buf, align 8, !dbg !1453, !tbaa !816
  %size = getelementptr inbounds i8, ptr %2, i64 28, !dbg !1454
  %4 = load i32, ptr %size, align 4, !dbg !1454, !tbaa !832
  %free = getelementptr inbounds i8, ptr %2, i64 24, !dbg !1455
  %5 = load i32, ptr %free, align 8, !dbg !1455, !tbaa !829
  %sub = sub i32 %4, %5, !dbg !1456
  %idx.ext = zext i32 %sub to i64, !dbg !1457
  %add.ptr = getelementptr inbounds i8, ptr %3, i64 %idx.ext, !dbg !1457
  %conv = zext i32 %5 to i64, !dbg !1458
  tail call void @llvm.memset.p0.i64(ptr align 1 %add.ptr, i8 0, i64 %conv, i1 false), !dbg !1459
  store ptr null, ptr %next, align 8, !dbg !1460, !tbaa !840
  %mode = getelementptr inbounds i8, ptr %0, i64 52, !dbg !1461
  store i32 1, ptr %mode, align 4, !dbg !1462, !tbaa !1041
  %id = getelementptr inbounds i8, ptr %p, i64 92, !dbg !1463
  %6 = load i16, ptr %id, align 4, !dbg !1463, !tbaa !393
  %page_id = getelementptr inbounds i8, ptr %0, i64 48, !dbg !1464
  store i16 %6, ptr %page_id, align 8, !dbg !1465, !tbaa !1038
  store ptr %2, ptr %0, align 8, !dbg !1466, !tbaa !1467
  %len = getelementptr inbounds i8, ptr %0, i64 40, !dbg !1468
  %7 = load <2 x i32>, ptr %size, align 4, !dbg !1469, !tbaa !607
  store <2 x i32> %7, ptr %len, align 8, !dbg !1470, !tbaa !607
  %8 = load ptr, ptr %buf, align 8, !dbg !1471, !tbaa !816
  %buf9 = getelementptr inbounds i8, ptr %0, i64 16, !dbg !1472
  store ptr %8, ptr %buf9, align 8, !dbg !1473, !tbaa !1090
  %cb = getelementptr inbounds i8, ptr %0, i64 56, !dbg !1474
  store ptr @_wbuf_cb, ptr %cb, align 8, !dbg !1475, !tbaa !1174
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !1476, metadata !DIExpression()), !dbg !1484
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1481, metadata !DIExpression()), !dbg !1484
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !1482, metadata !DIExpression()), !dbg !1484
  %bg_thread.i = getelementptr inbounds i8, ptr %e, i64 72, !dbg !1486
  %9 = load ptr, ptr %bg_thread.i, align 8, !dbg !1486, !tbaa !898
  tail call void @llvm.dbg.value(metadata ptr %9, metadata !1483, metadata !DIExpression()), !dbg !1484
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !1487, metadata !DIExpression()), !dbg !1497
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1492, metadata !DIExpression()), !dbg !1497
  tail call void @llvm.dbg.value(metadata ptr %9, metadata !1493, metadata !DIExpression()), !dbg !1497
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1494, metadata !DIExpression()), !dbg !1497
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1495, metadata !DIExpression()), !dbg !1497
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1496, metadata !DIExpression()), !dbg !1497
  br label %while.body.i.i, !dbg !1499

while.body.i.i:                                   ; preds = %entry, %while.body.i.i
  %tio.026.i.i = phi ptr [ %10, %while.body.i.i ], [ %0, %entry ]
  %depth.025.i.i = phi i32 [ %inc.i.i, %while.body.i.i ], [ 0, %entry ]
  tail call void @llvm.dbg.value(metadata ptr %tio.026.i.i, metadata !1495, metadata !DIExpression()), !dbg !1497
  tail call void @llvm.dbg.value(metadata i32 %depth.025.i.i, metadata !1494, metadata !DIExpression()), !dbg !1497
  tail call void @llvm.dbg.value(metadata ptr %tio.026.i.i, metadata !1496, metadata !DIExpression()), !dbg !1497
  %inc.i.i = add i32 %depth.025.i.i, 1, !dbg !1500
  tail call void @llvm.dbg.value(metadata i32 %inc.i.i, metadata !1494, metadata !DIExpression()), !dbg !1497
  %next.i.i = getelementptr inbounds i8, ptr %tio.026.i.i, i64 8, !dbg !1502
  %10 = load ptr, ptr %next.i.i, align 8, !dbg !1502, !tbaa !840
  tail call void @llvm.dbg.value(metadata ptr %10, metadata !1495, metadata !DIExpression()), !dbg !1497
  %cmp.not.i.i = icmp eq ptr %10, null, !dbg !1503
  br i1 %cmp.not.i.i, label %while.end.i.i, label %while.body.i.i, !dbg !1499, !llvm.loop !1504

while.end.i.i:                                    ; preds = %while.body.i.i
  %call.i.i = tail call i32 @pthread_mutex_lock(ptr noundef %9) #14, !dbg !1506
  %depth1.i.i = getelementptr inbounds i8, ptr %9, i64 112, !dbg !1507
  %11 = load i32, ptr %depth1.i.i, align 8, !dbg !1508, !tbaa !344
  %add.i.i = add i32 %11, %inc.i.i, !dbg !1508
  store i32 %add.i.i, ptr %depth1.i.i, align 8, !dbg !1508, !tbaa !344
  %queue.i.i = getelementptr inbounds i8, ptr %9, i64 88, !dbg !1509
  %12 = load ptr, ptr %queue.i.i, align 8, !dbg !1509, !tbaa !1003
  %cmp2.i.i = icmp eq ptr %12, null, !dbg !1511
  br i1 %cmp2.i.i, label %if.then.i.i, label %if.else.i.i, !dbg !1512

if.then.i.i:                                      ; preds = %while.end.i.i
  store ptr %0, ptr %queue.i.i, align 8, !dbg !1513, !tbaa !1003
  %queue_tail.i.i = getelementptr inbounds i8, ptr %9, i64 96, !dbg !1515
  br label %extstore_submit_bg.exit, !dbg !1516

if.else.i.i:                                      ; preds = %while.end.i.i
  %queue_tail4.i.i = getelementptr inbounds i8, ptr %9, i64 96, !dbg !1517
  %13 = load ptr, ptr %queue_tail4.i.i, align 8, !dbg !1517, !tbaa !1028
  %next5.i.i = getelementptr inbounds i8, ptr %13, i64 8, !dbg !1519
  store ptr %0, ptr %next5.i.i, align 8, !dbg !1520, !tbaa !840
  br label %extstore_submit_bg.exit

extstore_submit_bg.exit:                          ; preds = %if.then.i.i, %if.else.i.i
  %queue_tail4.sink.i.i = phi ptr [ %queue_tail4.i.i, %if.else.i.i ], [ %queue_tail.i.i, %if.then.i.i ]
  store ptr %tio.026.i.i, ptr %queue_tail4.sink.i.i, align 8, !dbg !1521, !tbaa !1028
  %call8.i.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %9) #14, !dbg !1522
  %cond.i.i = getelementptr inbounds i8, ptr %9, i64 40, !dbg !1523
  %call9.i.i = tail call i32 @pthread_cond_signal(ptr noundef nonnull %cond.i.i) #14, !dbg !1524
  ret void, !dbg !1525
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @_allocate_wbuf(ptr noundef %e, ptr nocapture noundef %p) unnamed_addr #0 !dbg !1526 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !1528, metadata !DIExpression()), !dbg !1531
  tail call void @llvm.dbg.value(metadata ptr %p, metadata !1529, metadata !DIExpression()), !dbg !1531
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1530, metadata !DIExpression()), !dbg !1531
  %call = tail call i32 @pthread_mutex_lock(ptr noundef %e) #14, !dbg !1532
  %wbuf_stack = getelementptr inbounds i8, ptr %e, i64 48, !dbg !1533
  %0 = load ptr, ptr %wbuf_stack, align 8, !dbg !1533, !tbaa !799
  %tobool.not = icmp eq ptr %0, null, !dbg !1535
  br i1 %tobool.not, label %if.end.thread, label %if.then7, !dbg !1536

if.end.thread:                                    ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1530, metadata !DIExpression()), !dbg !1531
  %call530 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %e) #14, !dbg !1537
  br label %if.end11, !dbg !1538

if.then7:                                         ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1530, metadata !DIExpression()), !dbg !1531
  %1 = load ptr, ptr %0, align 8, !dbg !1539, !tbaa !837
  store ptr %1, ptr %wbuf_stack, align 8, !dbg !1541, !tbaa !799
  store ptr null, ptr %0, align 8, !dbg !1542, !tbaa !837
  %call5 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %e) #14, !dbg !1537
  %allocated = getelementptr inbounds i8, ptr %p, i64 72, !dbg !1543
  %2 = load i32, ptr %allocated, align 8, !dbg !1543, !tbaa !499
  %offset = getelementptr inbounds i8, ptr %0, i64 32, !dbg !1546
  store i32 %2, ptr %offset, align 8, !dbg !1547, !tbaa !1093
  %size = getelementptr inbounds i8, ptr %0, i64 28, !dbg !1548
  %3 = load i32, ptr %size, align 4, !dbg !1548, !tbaa !832
  %add = add i32 %3, %2, !dbg !1549
  store i32 %add, ptr %allocated, align 8, !dbg !1549, !tbaa !499
  %free = getelementptr inbounds i8, ptr %0, i64 24, !dbg !1550
  store i32 %3, ptr %free, align 8, !dbg !1551, !tbaa !829
  %buf = getelementptr inbounds i8, ptr %0, i64 8, !dbg !1552
  %4 = load ptr, ptr %buf, align 8, !dbg !1552, !tbaa !816
  %buf_pos = getelementptr inbounds i8, ptr %0, i64 16, !dbg !1553
  store ptr %4, ptr %buf_pos, align 8, !dbg !1554, !tbaa !826
  %full = getelementptr inbounds i8, ptr %0, i64 36, !dbg !1555
  store i8 0, ptr %full, align 4, !dbg !1556, !tbaa !1325
  %flushed = getelementptr inbounds i8, ptr %0, i64 37, !dbg !1557
  store i8 0, ptr %flushed, align 1, !dbg !1558, !tbaa !1559
  %wbuf10 = getelementptr inbounds i8, ptr %p, i64 104, !dbg !1560
  store ptr %0, ptr %wbuf10, align 8, !dbg !1561, !tbaa !1083
  br label %if.end11, !dbg !1562

if.end11:                                         ; preds = %if.end.thread, %if.then7
  ret void, !dbg !1563
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @extstore_write(ptr noundef %ptr, ptr nocapture noundef %io) local_unnamed_addr #0 !dbg !1564 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1568, metadata !DIExpression()), !dbg !1572
  tail call void @llvm.dbg.value(metadata ptr %io, metadata !1569, metadata !DIExpression()), !dbg !1572
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1570, metadata !DIExpression()), !dbg !1572
  %pages = getelementptr inbounds i8, ptr %ptr, i64 40, !dbg !1573
  %0 = load ptr, ptr %pages, align 8, !dbg !1573, !tbaa !383
  %page_id = getelementptr inbounds i8, ptr %io, i64 48, !dbg !1574
  %1 = load i16, ptr %page_id, align 8, !dbg !1574, !tbaa !1038
  %idxprom = zext i16 %1 to i64, !dbg !1575
  %arrayidx = getelementptr inbounds %struct._store_page, ptr %0, i64 %idxprom, !dbg !1575
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !1571, metadata !DIExpression()), !dbg !1572
  %wbuf = getelementptr inbounds i8, ptr %arrayidx, i64 104, !dbg !1576
  %2 = load ptr, ptr %wbuf, align 8, !dbg !1576, !tbaa !1083
  %offset = getelementptr inbounds i8, ptr %2, i64 32, !dbg !1577
  %3 = load i32, ptr %offset, align 8, !dbg !1577, !tbaa !1093
  %size = getelementptr inbounds i8, ptr %2, i64 28, !dbg !1578
  %4 = load i32, ptr %size, align 4, !dbg !1578, !tbaa !832
  %free = getelementptr inbounds i8, ptr %2, i64 24, !dbg !1579
  %5 = load i32, ptr %free, align 8, !dbg !1579, !tbaa !829
  %sub = add i32 %4, %3, !dbg !1580
  %add = sub i32 %sub, %5, !dbg !1581
  %offset3 = getelementptr inbounds i8, ptr %io, i64 44, !dbg !1582
  store i32 %add, ptr %offset3, align 4, !dbg !1583, !tbaa !1060
  %version = getelementptr inbounds i8, ptr %arrayidx, i64 64, !dbg !1584
  %6 = load i32, ptr %version, align 8, !dbg !1584, !tbaa !400
  %page_version = getelementptr inbounds i8, ptr %io, i64 36, !dbg !1585
  store i32 %6, ptr %page_version, align 4, !dbg !1586, !tbaa !1052
  %len = getelementptr inbounds i8, ptr %io, i64 40, !dbg !1587
  %7 = load i32, ptr %len, align 8, !dbg !1587, !tbaa !1097
  %buf_pos = getelementptr inbounds i8, ptr %2, i64 16, !dbg !1588
  %8 = load ptr, ptr %buf_pos, align 8, !dbg !1589, !tbaa !826
  %idx.ext = zext i32 %7 to i64, !dbg !1589
  %add.ptr = getelementptr inbounds i8, ptr %8, i64 %idx.ext, !dbg !1589
  store ptr %add.ptr, ptr %buf_pos, align 8, !dbg !1589, !tbaa !826
  %sub8 = sub i32 %5, %7, !dbg !1590
  store i32 %sub8, ptr %free, align 8, !dbg !1590, !tbaa !829
  %obj_count = getelementptr inbounds i8, ptr %arrayidx, i64 40, !dbg !1591
  %9 = load <2 x i64>, ptr %obj_count, align 8, !dbg !1592, !tbaa !879
  %10 = insertelement <2 x i64> <i64 1, i64 poison>, i64 %idx.ext, i64 1, !dbg !1592
  %11 = add <2 x i64> %9, %10, !dbg !1592
  store <2 x i64> %11, ptr %obj_count, align 8, !dbg !1592, !tbaa !879
  %stats_mutex = getelementptr inbounds i8, ptr %ptr, i64 136, !dbg !1593
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats_mutex) #14, !dbg !1593
  %12 = load i32, ptr %len, align 8, !dbg !1594, !tbaa !1097
  %conv12 = zext i32 %12 to i64, !dbg !1595
  %bytes_written = getelementptr inbounds i8, ptr %ptr, i64 272, !dbg !1596
  %13 = load i64, ptr %bytes_written, align 8, !dbg !1597, !tbaa !1598
  %add13 = add i64 %13, %conv12, !dbg !1597
  store i64 %add13, ptr %bytes_written, align 8, !dbg !1597, !tbaa !1598
  %bytes_used17 = getelementptr inbounds i8, ptr %ptr, i64 288, !dbg !1599
  %14 = load i64, ptr %bytes_used17, align 8, !dbg !1600, !tbaa !467
  %add18 = add i64 %14, %conv12, !dbg !1600
  store i64 %add18, ptr %bytes_used17, align 8, !dbg !1600, !tbaa !467
  %objects_written = getelementptr inbounds i8, ptr %ptr, i64 248, !dbg !1601
  %15 = load <2 x i64>, ptr %objects_written, align 8, !dbg !1602, !tbaa !879
  %16 = add <2 x i64> %15, <i64 1, i64 1>, !dbg !1602
  store <2 x i64> %16, ptr %objects_written, align 8, !dbg !1602, !tbaa !879
  %call24 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats_mutex) #14, !dbg !1603
  %call25 = tail call i32 @pthread_mutex_unlock(ptr noundef %arrayidx) #14, !dbg !1604
  ret void, !dbg !1605
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef i32 @extstore_submit(ptr noundef %ptr, ptr noundef %io) local_unnamed_addr #0 !dbg !1606 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1608, metadata !DIExpression()), !dbg !1612
  tail call void @llvm.dbg.value(metadata ptr %io, metadata !1609, metadata !DIExpression()), !dbg !1612
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1610, metadata !DIExpression()), !dbg !1612
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1613, metadata !DIExpression()), !dbg !1622
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !1618, metadata !DIExpression()), !dbg !1622
  tail call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1619, metadata !DIExpression()), !dbg !1622
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef %ptr) #14, !dbg !1624
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1620, metadata !DIExpression()), !dbg !1625
  %io_threadcount.i = getelementptr inbounds i8, ptr %ptr, i64 112
  %0 = load i32, ptr %io_threadcount.i, align 8, !tbaa !323
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1620, metadata !DIExpression()), !dbg !1625
  tail call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1619, metadata !DIExpression()), !dbg !1622
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !1618, metadata !DIExpression()), !dbg !1622
  %cmp35.not.i = icmp eq i32 %0, 0, !dbg !1626
  br i1 %cmp35.not.i, label %_get_io_thread.exit, label %for.body.lr.ph.i, !dbg !1628

for.body.lr.ph.i:                                 ; preds = %entry
  %io_threads.i = getelementptr inbounds i8, ptr %ptr, i64 64, !dbg !1629
  %1 = load ptr, ptr %io_threads.i, align 8, !tbaa !339
  %wide.trip.count.i = zext i32 %0 to i64, !dbg !1626
  br label %for.body.i, !dbg !1628

for.body.i:                                       ; preds = %if.else.i, %for.body.lr.ph.i
  %indvars.iv.i = phi i64 [ 0, %for.body.lr.ph.i ], [ %indvars.iv.next.i, %if.else.i ]
  %low.037.i = phi i64 [ 9223372036854775807, %for.body.lr.ph.i ], [ %spec.select34.i, %if.else.i ]
  %tid.036.i = phi i32 [ -1, %for.body.lr.ph.i ], [ %spec.select.i, %if.else.i ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i, metadata !1620, metadata !DIExpression()), !dbg !1625
  tail call void @llvm.dbg.value(metadata i64 %low.037.i, metadata !1619, metadata !DIExpression()), !dbg !1622
  tail call void @llvm.dbg.value(metadata i32 %tid.036.i, metadata !1618, metadata !DIExpression()), !dbg !1622
  %depth.i = getelementptr inbounds %struct.store_io_thread, ptr %1, i64 %indvars.iv.i, i32 5, !dbg !1632
  %2 = load i32, ptr %depth.i, align 8, !dbg !1632, !tbaa !344
  %cmp1.i = icmp eq i32 %2, 0, !dbg !1633
  %3 = trunc nuw nsw i64 %indvars.iv.i to i32, !dbg !1634
  br i1 %cmp1.i, label %cleanup.loopexit.i, label %if.else.i, !dbg !1634

if.else.i:                                        ; preds = %for.body.i
  %conv.i = zext i32 %2 to i64, !dbg !1635
  %cmp6.i = icmp sgt i64 %low.037.i, %conv.i, !dbg !1637
  %spec.select.i = select i1 %cmp6.i, i32 %3, i32 %tid.036.i, !dbg !1638
  %spec.select34.i = tail call i64 @llvm.smin.i64(i64 %low.037.i, i64 %conv.i), !dbg !1638
  tail call void @llvm.dbg.value(metadata i64 %spec.select34.i, metadata !1619, metadata !DIExpression()), !dbg !1622
  tail call void @llvm.dbg.value(metadata i32 %spec.select.i, metadata !1618, metadata !DIExpression()), !dbg !1622
  %indvars.iv.next.i = add nuw nsw i64 %indvars.iv.i, 1, !dbg !1639
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !1620, metadata !DIExpression()), !dbg !1625
  %exitcond.not.i = icmp eq i64 %indvars.iv.next.i, %wide.trip.count.i, !dbg !1626
  br i1 %exitcond.not.i, label %cleanup.loopexit.i, label %for.body.i, !dbg !1628, !llvm.loop !1640

cleanup.loopexit.i:                               ; preds = %if.else.i, %for.body.i
  %tid.2.ph.i = phi i32 [ %spec.select.i, %if.else.i ], [ %3, %for.body.i ]
  %4 = sext i32 %tid.2.ph.i to i64, !dbg !1642
  br label %_get_io_thread.exit, !dbg !1643

_get_io_thread.exit:                              ; preds = %entry, %cleanup.loopexit.i
  %tid.2.i = phi i64 [ -1, %entry ], [ %4, %cleanup.loopexit.i ], !dbg !1622
  tail call void @llvm.dbg.value(metadata i64 %tid.2.i, metadata !1618, metadata !DIExpression()), !dbg !1622
  %call16.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %ptr) #14, !dbg !1643
  %io_threads17.i = getelementptr inbounds i8, ptr %ptr, i64 64, !dbg !1644
  %5 = load ptr, ptr %io_threads17.i, align 8, !dbg !1644, !tbaa !339
  %arrayidx19.i = getelementptr inbounds %struct.store_io_thread, ptr %5, i64 %tid.2.i, !dbg !1642
  tail call void @llvm.dbg.value(metadata ptr %arrayidx19.i, metadata !1611, metadata !DIExpression()), !dbg !1612
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1487, metadata !DIExpression()), !dbg !1645
  tail call void @llvm.dbg.value(metadata ptr %io, metadata !1492, metadata !DIExpression()), !dbg !1645
  tail call void @llvm.dbg.value(metadata ptr %arrayidx19.i, metadata !1493, metadata !DIExpression()), !dbg !1645
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1494, metadata !DIExpression()), !dbg !1645
  tail call void @llvm.dbg.value(metadata ptr %io, metadata !1495, metadata !DIExpression()), !dbg !1645
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1496, metadata !DIExpression()), !dbg !1645
  %cmp.not24.i = icmp eq ptr %io, null, !dbg !1647
  br i1 %cmp.not24.i, label %while.end.i, label %while.body.i, !dbg !1648

while.body.i:                                     ; preds = %_get_io_thread.exit, %while.body.i
  %tio.026.i = phi ptr [ %6, %while.body.i ], [ %io, %_get_io_thread.exit ]
  %depth.025.i = phi i32 [ %inc.i, %while.body.i ], [ 0, %_get_io_thread.exit ]
  tail call void @llvm.dbg.value(metadata ptr %tio.026.i, metadata !1495, metadata !DIExpression()), !dbg !1645
  tail call void @llvm.dbg.value(metadata i32 %depth.025.i, metadata !1494, metadata !DIExpression()), !dbg !1645
  tail call void @llvm.dbg.value(metadata ptr %tio.026.i, metadata !1496, metadata !DIExpression()), !dbg !1645
  %inc.i = add i32 %depth.025.i, 1, !dbg !1649
  tail call void @llvm.dbg.value(metadata i32 %inc.i, metadata !1494, metadata !DIExpression()), !dbg !1645
  %next.i = getelementptr inbounds i8, ptr %tio.026.i, i64 8, !dbg !1650
  %6 = load ptr, ptr %next.i, align 8, !dbg !1650, !tbaa !840
  tail call void @llvm.dbg.value(metadata ptr %6, metadata !1495, metadata !DIExpression()), !dbg !1645
  %cmp.not.i = icmp eq ptr %6, null, !dbg !1647
  br i1 %cmp.not.i, label %while.end.i, label %while.body.i, !dbg !1648, !llvm.loop !1651

while.end.i:                                      ; preds = %while.body.i, %_get_io_thread.exit
  %depth.0.lcssa.i = phi i32 [ 0, %_get_io_thread.exit ], [ %inc.i, %while.body.i ], !dbg !1645
  %tail.0.lcssa.i = phi ptr [ null, %_get_io_thread.exit ], [ %tio.026.i, %while.body.i ], !dbg !1645
  %call.i3 = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx19.i) #14, !dbg !1653
  %depth1.i = getelementptr inbounds i8, ptr %arrayidx19.i, i64 112, !dbg !1654
  %7 = load i32, ptr %depth1.i, align 8, !dbg !1655, !tbaa !344
  %add.i = add i32 %7, %depth.0.lcssa.i, !dbg !1655
  store i32 %add.i, ptr %depth1.i, align 8, !dbg !1655, !tbaa !344
  %queue.i = getelementptr inbounds i8, ptr %arrayidx19.i, i64 88, !dbg !1656
  %8 = load ptr, ptr %queue.i, align 8, !dbg !1656, !tbaa !1003
  %cmp2.i = icmp eq ptr %8, null, !dbg !1657
  br i1 %cmp2.i, label %if.then.i, label %if.else.i4, !dbg !1658

if.then.i:                                        ; preds = %while.end.i
  store ptr %io, ptr %queue.i, align 8, !dbg !1659, !tbaa !1003
  %queue_tail.i = getelementptr inbounds i8, ptr %arrayidx19.i, i64 96, !dbg !1660
  br label %_extstore_submit.exit, !dbg !1661

if.else.i4:                                       ; preds = %while.end.i
  %queue_tail4.i = getelementptr inbounds i8, ptr %arrayidx19.i, i64 96, !dbg !1662
  %9 = load ptr, ptr %queue_tail4.i, align 8, !dbg !1662, !tbaa !1028
  %next5.i = getelementptr inbounds i8, ptr %9, i64 8, !dbg !1663
  store ptr %io, ptr %next5.i, align 8, !dbg !1664, !tbaa !840
  br label %_extstore_submit.exit

_extstore_submit.exit:                            ; preds = %if.then.i, %if.else.i4
  %queue_tail4.sink.i = phi ptr [ %queue_tail4.i, %if.else.i4 ], [ %queue_tail.i, %if.then.i ]
  store ptr %tail.0.lcssa.i, ptr %queue_tail4.sink.i, align 8, !dbg !1665, !tbaa !1028
  %call8.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx19.i) #14, !dbg !1666
  %cond.i = getelementptr inbounds i8, ptr %arrayidx19.i, i64 40, !dbg !1667
  %call9.i = tail call i32 @pthread_cond_signal(ptr noundef nonnull %cond.i) #14, !dbg !1668
  ret i32 0, !dbg !1669
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef i32 @extstore_submit_bg(ptr nocapture noundef readonly %ptr, ptr noundef %io) local_unnamed_addr #0 !dbg !1477 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1476, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata ptr %io, metadata !1481, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1482, metadata !DIExpression()), !dbg !1670
  %bg_thread = getelementptr inbounds i8, ptr %ptr, i64 72, !dbg !1671
  %0 = load ptr, ptr %bg_thread, align 8, !dbg !1671, !tbaa !898
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1483, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1487, metadata !DIExpression()), !dbg !1672
  tail call void @llvm.dbg.value(metadata ptr %io, metadata !1492, metadata !DIExpression()), !dbg !1672
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1493, metadata !DIExpression()), !dbg !1672
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1494, metadata !DIExpression()), !dbg !1672
  tail call void @llvm.dbg.value(metadata ptr %io, metadata !1495, metadata !DIExpression()), !dbg !1672
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1496, metadata !DIExpression()), !dbg !1672
  %cmp.not24.i = icmp eq ptr %io, null, !dbg !1674
  br i1 %cmp.not24.i, label %while.end.i, label %while.body.i, !dbg !1675

while.body.i:                                     ; preds = %entry, %while.body.i
  %tio.026.i = phi ptr [ %1, %while.body.i ], [ %io, %entry ]
  %depth.025.i = phi i32 [ %inc.i, %while.body.i ], [ 0, %entry ]
  tail call void @llvm.dbg.value(metadata ptr %tio.026.i, metadata !1495, metadata !DIExpression()), !dbg !1672
  tail call void @llvm.dbg.value(metadata i32 %depth.025.i, metadata !1494, metadata !DIExpression()), !dbg !1672
  tail call void @llvm.dbg.value(metadata ptr %tio.026.i, metadata !1496, metadata !DIExpression()), !dbg !1672
  %inc.i = add i32 %depth.025.i, 1, !dbg !1676
  tail call void @llvm.dbg.value(metadata i32 %inc.i, metadata !1494, metadata !DIExpression()), !dbg !1672
  %next.i = getelementptr inbounds i8, ptr %tio.026.i, i64 8, !dbg !1677
  %1 = load ptr, ptr %next.i, align 8, !dbg !1677, !tbaa !840
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !1495, metadata !DIExpression()), !dbg !1672
  %cmp.not.i = icmp eq ptr %1, null, !dbg !1674
  br i1 %cmp.not.i, label %while.end.i, label %while.body.i, !dbg !1675, !llvm.loop !1678

while.end.i:                                      ; preds = %while.body.i, %entry
  %depth.0.lcssa.i = phi i32 [ 0, %entry ], [ %inc.i, %while.body.i ], !dbg !1672
  %tail.0.lcssa.i = phi ptr [ null, %entry ], [ %tio.026.i, %while.body.i ], !dbg !1672
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef %0) #14, !dbg !1680
  %depth1.i = getelementptr inbounds i8, ptr %0, i64 112, !dbg !1681
  %2 = load i32, ptr %depth1.i, align 8, !dbg !1682, !tbaa !344
  %add.i = add i32 %2, %depth.0.lcssa.i, !dbg !1682
  store i32 %add.i, ptr %depth1.i, align 8, !dbg !1682, !tbaa !344
  %queue.i = getelementptr inbounds i8, ptr %0, i64 88, !dbg !1683
  %3 = load ptr, ptr %queue.i, align 8, !dbg !1683, !tbaa !1003
  %cmp2.i = icmp eq ptr %3, null, !dbg !1684
  br i1 %cmp2.i, label %if.then.i, label %if.else.i, !dbg !1685

if.then.i:                                        ; preds = %while.end.i
  store ptr %io, ptr %queue.i, align 8, !dbg !1686, !tbaa !1003
  %queue_tail.i = getelementptr inbounds i8, ptr %0, i64 96, !dbg !1687
  br label %_extstore_submit.exit, !dbg !1688

if.else.i:                                        ; preds = %while.end.i
  %queue_tail4.i = getelementptr inbounds i8, ptr %0, i64 96, !dbg !1689
  %4 = load ptr, ptr %queue_tail4.i, align 8, !dbg !1689, !tbaa !1028
  %next5.i = getelementptr inbounds i8, ptr %4, i64 8, !dbg !1690
  store ptr %io, ptr %next5.i, align 8, !dbg !1691, !tbaa !840
  br label %_extstore_submit.exit

_extstore_submit.exit:                            ; preds = %if.then.i, %if.else.i
  %queue_tail4.sink.i = phi ptr [ %queue_tail4.i, %if.else.i ], [ %queue_tail.i, %if.then.i ]
  store ptr %tail.0.lcssa.i, ptr %queue_tail4.sink.i, align 8, !dbg !1692, !tbaa !1028
  %call8.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %0) #14, !dbg !1693
  %cond.i = getelementptr inbounds i8, ptr %0, i64 40, !dbg !1694
  %call9.i = tail call i32 @pthread_cond_signal(ptr noundef nonnull %cond.i) #14, !dbg !1695
  ret i32 0, !dbg !1696
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 -1, 1) i32 @extstore_delete(ptr noundef %ptr, i32 noundef %page_id, i64 noundef %page_version, i32 noundef %count, i32 noundef %bytes) local_unnamed_addr #0 !dbg !1697 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1701, metadata !DIExpression()), !dbg !1709
  tail call void @llvm.dbg.value(metadata i32 %page_id, metadata !1702, metadata !DIExpression()), !dbg !1709
  tail call void @llvm.dbg.value(metadata i64 %page_version, metadata !1703, metadata !DIExpression()), !dbg !1709
  tail call void @llvm.dbg.value(metadata i32 %count, metadata !1704, metadata !DIExpression()), !dbg !1709
  tail call void @llvm.dbg.value(metadata i32 %bytes, metadata !1705, metadata !DIExpression()), !dbg !1709
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1706, metadata !DIExpression()), !dbg !1709
  %pages = getelementptr inbounds i8, ptr %ptr, i64 40, !dbg !1710
  %0 = load ptr, ptr %pages, align 8, !dbg !1710, !tbaa !383
  %idxprom = zext i32 %page_id to i64, !dbg !1711
  %arrayidx = getelementptr inbounds %struct._store_page, ptr %0, i64 %idxprom, !dbg !1711
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !1707, metadata !DIExpression()), !dbg !1709
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1708, metadata !DIExpression()), !dbg !1709
  %call = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx) #14, !dbg !1712
  %closed = getelementptr inbounds i8, ptr %arrayidx, i64 95, !dbg !1713
  %1 = load i8, ptr %closed, align 1, !dbg !1713, !tbaa !431, !range !413, !noundef !414
  %tobool = trunc nuw i8 %1 to i1, !dbg !1713
  br i1 %tobool, label %if.end39, label %land.lhs.true, !dbg !1715

land.lhs.true:                                    ; preds = %entry
  %version = getelementptr inbounds i8, ptr %arrayidx, i64 64, !dbg !1716
  %2 = load i32, ptr %version, align 8, !dbg !1716, !tbaa !400
  %conv = zext i32 %2 to i64, !dbg !1717
  %cmp = icmp eq i64 %conv, %page_version, !dbg !1718
  br i1 %cmp, label %if.then, label %if.end39, !dbg !1719

if.then:                                          ; preds = %land.lhs.true
  %bytes_used = getelementptr inbounds i8, ptr %arrayidx, i64 48, !dbg !1720
  %3 = load i64, ptr %bytes_used, align 8, !dbg !1720, !tbaa !406
  %conv2 = zext i32 %bytes to i64, !dbg !1723
  %storemerge = tail call i64 @llvm.usub.sat.i64(i64 %3, i64 %conv2), !dbg !1724
  store i64 %storemerge, ptr %bytes_used, align 8, !dbg !1725, !tbaa !406
  %obj_count = getelementptr inbounds i8, ptr %arrayidx, i64 40, !dbg !1726
  %4 = load i64, ptr %obj_count, align 8, !dbg !1726, !tbaa !427
  %conv9 = zext i32 %count to i64, !dbg !1728
  %storemerge65 = tail call i64 @llvm.usub.sat.i64(i64 %4, i64 %conv9), !dbg !1729
  store i64 %storemerge65, ptr %obj_count, align 8, !dbg !1730, !tbaa !427
  %stats_mutex = getelementptr inbounds i8, ptr %ptr, i64 136, !dbg !1731
  %call19 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats_mutex) #14, !dbg !1731
  %bytes_used21 = getelementptr inbounds i8, ptr %ptr, i64 288, !dbg !1732
  %5 = load i64, ptr %bytes_used21, align 8, !dbg !1733, !tbaa !467
  %sub22 = sub i64 %5, %conv2, !dbg !1733
  store i64 %sub22, ptr %bytes_used21, align 8, !dbg !1733, !tbaa !467
  %objects_used = getelementptr inbounds i8, ptr %ptr, i64 256, !dbg !1734
  %6 = load i64, ptr %objects_used, align 8, !dbg !1735, !tbaa !463
  %sub25 = sub i64 %6, %conv9, !dbg !1735
  store i64 %sub25, ptr %objects_used, align 8, !dbg !1735, !tbaa !463
  %call27 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats_mutex) #14, !dbg !1736
  %7 = load i64, ptr %obj_count, align 8, !dbg !1737, !tbaa !427
  %cmp29 = icmp eq i64 %7, 0, !dbg !1739
  br i1 %cmp29, label %land.lhs.true31, label %if.end39, !dbg !1740

land.lhs.true31:                                  ; preds = %if.then
  %refcount = getelementptr inbounds i8, ptr %arrayidx, i64 68, !dbg !1741
  %8 = load i32, ptr %refcount, align 4, !dbg !1741, !tbaa !441
  %cmp32 = icmp eq i32 %8, 0, !dbg !1742
  br i1 %cmp32, label %land.lhs.true34, label %if.end39, !dbg !1743

land.lhs.true34:                                  ; preds = %land.lhs.true31
  %active = getelementptr inbounds i8, ptr %arrayidx, i64 94, !dbg !1744
  %9 = load i8, ptr %active, align 2, !dbg !1744, !tbaa !412, !range !413, !noundef !414
  %tobool35 = trunc nuw i8 %9 to i1, !dbg !1744
  br i1 %tobool35, label %if.end39, label %if.then36, !dbg !1745

if.then36:                                        ; preds = %land.lhs.true34
  tail call fastcc void @_free_page(ptr noundef nonnull %ptr, ptr noundef nonnull %arrayidx), !dbg !1746
  br label %if.end39, !dbg !1748

if.end39:                                         ; preds = %entry, %land.lhs.true, %if.then, %land.lhs.true31, %land.lhs.true34, %if.then36
  %ret.0 = phi i32 [ 0, %land.lhs.true34 ], [ 0, %if.then36 ], [ 0, %land.lhs.true31 ], [ 0, %if.then ], [ -1, %land.lhs.true ], [ -1, %entry ], !dbg !1709
  tail call void @llvm.dbg.value(metadata i32 %ret.0, metadata !1708, metadata !DIExpression()), !dbg !1709
  %call41 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #14, !dbg !1749
  ret i32 %ret.0, !dbg !1750
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 -1, 1) i32 @extstore_check(ptr nocapture noundef readonly %ptr, i32 noundef %page_id, i64 noundef %page_version) local_unnamed_addr #0 !dbg !1751 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1755, metadata !DIExpression()), !dbg !1761
  tail call void @llvm.dbg.value(metadata i32 %page_id, metadata !1756, metadata !DIExpression()), !dbg !1761
  tail call void @llvm.dbg.value(metadata i64 %page_version, metadata !1757, metadata !DIExpression()), !dbg !1761
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1758, metadata !DIExpression()), !dbg !1761
  %pages = getelementptr inbounds i8, ptr %ptr, i64 40, !dbg !1762
  %0 = load ptr, ptr %pages, align 8, !dbg !1762, !tbaa !383
  %idxprom = zext i32 %page_id to i64, !dbg !1763
  %arrayidx = getelementptr inbounds %struct._store_page, ptr %0, i64 %idxprom, !dbg !1763
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !1759, metadata !DIExpression()), !dbg !1761
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1760, metadata !DIExpression()), !dbg !1761
  %call = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx) #14, !dbg !1764
  %version = getelementptr inbounds i8, ptr %arrayidx, i64 64, !dbg !1765
  %1 = load i32, ptr %version, align 8, !dbg !1765, !tbaa !400
  %conv = zext i32 %1 to i64, !dbg !1767
  %cmp.not = icmp ne i64 %conv, %page_version, !dbg !1768
  %spec.select = sext i1 %cmp.not to i32, !dbg !1769
  tail call void @llvm.dbg.value(metadata i32 %spec.select, metadata !1760, metadata !DIExpression()), !dbg !1761
  %call3 = tail call i32 @pthread_mutex_unlock(ptr noundef %arrayidx) #14, !dbg !1770
  ret i32 %spec.select, !dbg !1771
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @extstore_close_page(ptr noundef %ptr, i32 noundef %page_id, i64 noundef %page_version) local_unnamed_addr #0 !dbg !1772 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1776, metadata !DIExpression()), !dbg !1781
  tail call void @llvm.dbg.value(metadata i32 %page_id, metadata !1777, metadata !DIExpression()), !dbg !1781
  tail call void @llvm.dbg.value(metadata i64 %page_version, metadata !1778, metadata !DIExpression()), !dbg !1781
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1779, metadata !DIExpression()), !dbg !1781
  %pages = getelementptr inbounds i8, ptr %ptr, i64 40, !dbg !1782
  %0 = load ptr, ptr %pages, align 8, !dbg !1782, !tbaa !383
  %idxprom = zext i32 %page_id to i64, !dbg !1783
  %arrayidx = getelementptr inbounds %struct._store_page, ptr %0, i64 %idxprom, !dbg !1783
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !1780, metadata !DIExpression()), !dbg !1781
  %call = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx) #14, !dbg !1784
  %closed = getelementptr inbounds i8, ptr %arrayidx, i64 95, !dbg !1785
  %1 = load i8, ptr %closed, align 1, !dbg !1785, !tbaa !431, !range !413, !noundef !414
  %tobool = trunc nuw i8 %1 to i1, !dbg !1785
  br i1 %tobool, label %if.end8, label %land.lhs.true, !dbg !1787

land.lhs.true:                                    ; preds = %entry
  %active = getelementptr inbounds i8, ptr %arrayidx, i64 94, !dbg !1788
  %2 = load i8, ptr %active, align 2, !dbg !1788, !tbaa !412, !range !413, !noundef !414
  %tobool1 = trunc nuw i8 %2 to i1, !dbg !1788
  br i1 %tobool1, label %if.end8, label %land.lhs.true2, !dbg !1789

land.lhs.true2:                                   ; preds = %land.lhs.true
  %version = getelementptr inbounds i8, ptr %arrayidx, i64 64, !dbg !1790
  %3 = load i32, ptr %version, align 8, !dbg !1790, !tbaa !400
  %conv = zext i32 %3 to i64, !dbg !1791
  %cmp = icmp eq i64 %conv, %page_version, !dbg !1792
  br i1 %cmp, label %if.then, label %if.end8, !dbg !1793

if.then:                                          ; preds = %land.lhs.true2
  store i8 1, ptr %closed, align 1, !dbg !1794, !tbaa !431
  %refcount = getelementptr inbounds i8, ptr %arrayidx, i64 68, !dbg !1796
  %4 = load i32, ptr %refcount, align 4, !dbg !1796, !tbaa !441
  %cmp5 = icmp eq i32 %4, 0, !dbg !1798
  br i1 %cmp5, label %if.then7, label %if.end8, !dbg !1799

if.then7:                                         ; preds = %if.then
  tail call fastcc void @_free_page(ptr noundef nonnull %ptr, ptr noundef nonnull %arrayidx), !dbg !1800
  br label %if.end8, !dbg !1802

if.end8:                                          ; preds = %if.then, %if.then7, %land.lhs.true2, %land.lhs.true, %entry
  %call10 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #14, !dbg !1803
  ret void, !dbg !1804
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @extstore_evict_page(ptr noundef %ptr, i32 noundef %page_id, i64 noundef %page_version) local_unnamed_addr #0 !dbg !1805 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1807, metadata !DIExpression()), !dbg !1812
  tail call void @llvm.dbg.value(metadata i32 %page_id, metadata !1808, metadata !DIExpression()), !dbg !1812
  tail call void @llvm.dbg.value(metadata i64 %page_version, metadata !1809, metadata !DIExpression()), !dbg !1812
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1810, metadata !DIExpression()), !dbg !1812
  %pages = getelementptr inbounds i8, ptr %ptr, i64 40, !dbg !1813
  %0 = load ptr, ptr %pages, align 8, !dbg !1813, !tbaa !383
  %idxprom = zext i32 %page_id to i64, !dbg !1814
  %arrayidx = getelementptr inbounds %struct._store_page, ptr %0, i64 %idxprom, !dbg !1814
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !1811, metadata !DIExpression()), !dbg !1812
  %call = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx) #14, !dbg !1815
  %closed = getelementptr inbounds i8, ptr %arrayidx, i64 95, !dbg !1816
  %1 = load i8, ptr %closed, align 1, !dbg !1816, !tbaa !431, !range !413, !noundef !414
  %tobool = trunc nuw i8 %1 to i1, !dbg !1816
  br i1 %tobool, label %if.end14, label %land.lhs.true, !dbg !1818

land.lhs.true:                                    ; preds = %entry
  %active = getelementptr inbounds i8, ptr %arrayidx, i64 94, !dbg !1819
  %2 = load i8, ptr %active, align 2, !dbg !1819, !tbaa !412, !range !413, !noundef !414
  %tobool1 = trunc nuw i8 %2 to i1, !dbg !1819
  br i1 %tobool1, label %if.end14, label %land.lhs.true2, !dbg !1820

land.lhs.true2:                                   ; preds = %land.lhs.true
  %version = getelementptr inbounds i8, ptr %arrayidx, i64 64, !dbg !1821
  %3 = load i32, ptr %version, align 8, !dbg !1821, !tbaa !400
  %conv = zext i32 %3 to i64, !dbg !1822
  %cmp = icmp eq i64 %conv, %page_version, !dbg !1823
  br i1 %cmp, label %if.then, label %if.end14, !dbg !1824

if.then:                                          ; preds = %land.lhs.true2
  store i8 1, ptr %closed, align 1, !dbg !1825, !tbaa !431
  %stats_mutex = getelementptr inbounds i8, ptr %ptr, i64 136, !dbg !1827
  %call5 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats_mutex) #14, !dbg !1827
  %page_evictions = getelementptr inbounds i8, ptr %ptr, i64 192, !dbg !1828
  %4 = load i64, ptr %page_evictions, align 8, !dbg !1829, !tbaa !1830
  %inc = add i64 %4, 1, !dbg !1829
  store i64 %inc, ptr %page_evictions, align 8, !dbg !1829, !tbaa !1830
  %obj_count = getelementptr inbounds i8, ptr %arrayidx, i64 40, !dbg !1831
  %5 = load i64, ptr %obj_count, align 8, !dbg !1831, !tbaa !427
  %objects_evicted = getelementptr inbounds i8, ptr %ptr, i64 232, !dbg !1832
  %6 = load i64, ptr %objects_evicted, align 8, !dbg !1833, !tbaa !1834
  %add = add i64 %6, %5, !dbg !1833
  store i64 %add, ptr %objects_evicted, align 8, !dbg !1833, !tbaa !1834
  %bytes_used = getelementptr inbounds i8, ptr %arrayidx, i64 48, !dbg !1835
  %7 = load i64, ptr %bytes_used, align 8, !dbg !1835, !tbaa !406
  %bytes_evicted = getelementptr inbounds i8, ptr %ptr, i64 264, !dbg !1836
  %8 = load i64, ptr %bytes_evicted, align 8, !dbg !1837, !tbaa !1838
  %add8 = add i64 %8, %7, !dbg !1837
  store i64 %add8, ptr %bytes_evicted, align 8, !dbg !1837, !tbaa !1838
  %call10 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats_mutex) #14, !dbg !1839
  %refcount = getelementptr inbounds i8, ptr %arrayidx, i64 68, !dbg !1840
  %9 = load i32, ptr %refcount, align 4, !dbg !1840, !tbaa !441
  %cmp11 = icmp eq i32 %9, 0, !dbg !1842
  br i1 %cmp11, label %if.then13, label %if.end14, !dbg !1843

if.then13:                                        ; preds = %if.then
  tail call fastcc void @_free_page(ptr noundef nonnull %ptr, ptr noundef nonnull %arrayidx), !dbg !1844
  br label %if.end14, !dbg !1846

if.end14:                                         ; preds = %if.then, %if.then13, %land.lhs.true2, %land.lhs.true, %entry
  %call16 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #14, !dbg !1847
  ret void, !dbg !1848
}

; Function Attrs: nounwind
declare !dbg !1849 i32 @pthread_setname_np(i64 noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #10

; Function Attrs: nounwind sanitize_thread uwtable
define internal void @_wbuf_cb(ptr noundef %ep, ptr noundef %io, i32 %ret) #0 !dbg !1852 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %ep, metadata !1854, metadata !DIExpression()), !dbg !1860
  tail call void @llvm.dbg.value(metadata ptr %io, metadata !1855, metadata !DIExpression()), !dbg !1860
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1856, metadata !DIExpression()), !dbg !1860
  tail call void @llvm.dbg.value(metadata ptr %ep, metadata !1857, metadata !DIExpression()), !dbg !1860
  %pages = getelementptr inbounds i8, ptr %ep, i64 40, !dbg !1861
  %0 = load ptr, ptr %pages, align 8, !dbg !1861, !tbaa !383
  %page_id = getelementptr inbounds i8, ptr %io, i64 48, !dbg !1862
  %1 = load i16, ptr %page_id, align 8, !dbg !1862, !tbaa !1038
  %idxprom = zext i16 %1 to i64, !dbg !1863
  %arrayidx = getelementptr inbounds %struct._store_page, ptr %0, i64 %idxprom, !dbg !1863
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !1858, metadata !DIExpression()), !dbg !1860
  %2 = load ptr, ptr %io, align 8, !dbg !1864, !tbaa !1467
  tail call void @llvm.dbg.value(metadata ptr %2, metadata !1859, metadata !DIExpression()), !dbg !1860
  %flushed = getelementptr inbounds i8, ptr %2, i64 37, !dbg !1865
  store i8 1, ptr %flushed, align 1, !dbg !1866, !tbaa !1559
  %call = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx) #14, !dbg !1867
  %size = getelementptr inbounds i8, ptr %2, i64 28, !dbg !1868
  %3 = load i32, ptr %size, align 4, !dbg !1868, !tbaa !832
  %written = getelementptr inbounds i8, ptr %arrayidx, i64 76, !dbg !1869
  %4 = load i32, ptr %written, align 4, !dbg !1870, !tbaa !502
  %add = add i32 %4, %3, !dbg !1870
  store i32 %add, ptr %written, align 4, !dbg !1870, !tbaa !502
  %wbuf = getelementptr inbounds i8, ptr %arrayidx, i64 104, !dbg !1871
  store ptr null, ptr %wbuf, align 8, !dbg !1872, !tbaa !1083
  %conv = zext i32 %add to i64, !dbg !1873
  %page_size = getelementptr inbounds i8, ptr %ep, i64 96, !dbg !1875
  %5 = load i64, ptr %page_size, align 8, !dbg !1875, !tbaa !328
  %cmp = icmp eq i64 %5, %conv, !dbg !1876
  br i1 %cmp, label %if.then, label %if.end, !dbg !1877

if.then:                                          ; preds = %entry
  %active = getelementptr inbounds i8, ptr %arrayidx, i64 94, !dbg !1878
  store i8 0, ptr %active, align 2, !dbg !1879, !tbaa !412
  br label %if.end, !dbg !1880

if.end:                                           ; preds = %if.then, %entry
  %call4 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %ep) #14, !dbg !1881
  %wbuf_stack = getelementptr inbounds i8, ptr %ep, i64 48, !dbg !1882
  %6 = load ptr, ptr %wbuf_stack, align 8, !dbg !1882, !tbaa !799
  store ptr %6, ptr %2, align 8, !dbg !1883, !tbaa !837
  store ptr %2, ptr %wbuf_stack, align 8, !dbg !1884, !tbaa !799
  %io_stack = getelementptr inbounds i8, ptr %ep, i64 56, !dbg !1885
  %7 = load ptr, ptr %io_stack, align 8, !dbg !1885, !tbaa !800
  %next6 = getelementptr inbounds i8, ptr %io, i64 8, !dbg !1886
  store ptr %7, ptr %next6, align 8, !dbg !1887, !tbaa !840
  store ptr %io, ptr %io_stack, align 8, !dbg !1888, !tbaa !800
  %call9 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %ep) #14, !dbg !1889
  %call11 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #14, !dbg !1890
  ret void, !dbg !1891
}

; Function Attrs: nounwind
declare !dbg !1892 i32 @pthread_cond_signal(ptr noundef) local_unnamed_addr #2

declare !dbg !1895 i32 @pthread_cond_wait(ptr noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: nofree
declare !dbg !1899 noundef i64 @pread(i32 noundef, ptr nocapture noundef, i64 noundef, i64 noundef) local_unnamed_addr #6

declare !dbg !1905 i64 @preadv(i32 noundef, ptr noundef, i32 noundef, i64 noundef) local_unnamed_addr #8

; Function Attrs: nofree
declare !dbg !1911 noundef i64 @pwrite(i32 noundef, ptr nocapture noundef readonly, i64 noundef, i64 noundef) local_unnamed_addr #6

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #11

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.usub.sat.i64(i64, i64) #11

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #12 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare ptr @llvm.load.relative.i64(ptr, i64) #13

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #11

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #11

attributes #0 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nofree "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { noreturn nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #11 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { nounwind uwtable }
attributes #13 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #14 = { nounwind }
attributes #15 = { nounwind allocsize(0,1) }

!llvm.dbg.cu = !{!49}
!llvm.module.flags = !{!271, !272, !273, !274, !275, !276, !277}
!llvm.ident = !{!278}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(scope: null, file: !2, line: 227, type: !3, isLocal: true, isDefinition: true)
!2 = !DIFile(filename: "extstore.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "fd2a56f114d92cd45958de529e3a289b")
!3 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 112, elements: !5)
!4 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!5 = !{!6}
!6 = !DISubrange(count: 14)
!7 = !DIGlobalVariableExpression(var: !8, expr: !DIExpression())
!8 = distinct !DIGlobalVariable(scope: null, file: !2, line: 230, type: !9, isLocal: true, isDefinition: true)
!9 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 328, elements: !10)
!10 = !{!11}
!11 = !DISubrange(count: 41)
!12 = !DIGlobalVariableExpression(var: !13, expr: !DIExpression())
!13 = distinct !DIGlobalVariable(scope: null, file: !2, line: 233, type: !14, isLocal: true, isDefinition: true)
!14 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 280, elements: !15)
!15 = !{!16}
!16 = !DISubrange(count: 35)
!17 = !DIGlobalVariableExpression(var: !18, expr: !DIExpression())
!18 = distinct !DIGlobalVariable(scope: null, file: !2, line: 236, type: !19, isLocal: true, isDefinition: true)
!19 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 200, elements: !20)
!20 = !{!21}
!21 = !DISubrange(count: 25)
!22 = !DIGlobalVariableExpression(var: !23, expr: !DIExpression())
!23 = distinct !DIGlobalVariable(scope: null, file: !2, line: 239, type: !24, isLocal: true, isDefinition: true)
!24 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 456, elements: !25)
!25 = !{!26}
!26 = !DISubrange(count: 57)
!27 = !DIGlobalVariableExpression(var: !28, expr: !DIExpression())
!28 = distinct !DIGlobalVariable(scope: null, file: !2, line: 242, type: !29, isLocal: true, isDefinition: true)
!29 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 584, elements: !30)
!30 = !{!31}
!31 = !DISubrange(count: 73)
!32 = !DIGlobalVariableExpression(var: !33, expr: !DIExpression())
!33 = distinct !DIGlobalVariable(scope: null, file: !2, line: 245, type: !19, isLocal: true, isDefinition: true)
!34 = !DIGlobalVariableExpression(var: !35, expr: !DIExpression())
!35 = distinct !DIGlobalVariable(scope: null, file: !2, line: 248, type: !36, isLocal: true, isDefinition: true)
!36 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 160, elements: !37)
!37 = !{!38}
!38 = !DISubrange(count: 20)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(scope: null, file: !2, line: 413, type: !41, isLocal: true, isDefinition: true)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 80, elements: !42)
!42 = !{!43}
!43 = !DISubrange(count: 10)
!44 = !DIGlobalVariableExpression(var: !45, expr: !DIExpression())
!45 = distinct !DIGlobalVariable(scope: null, file: !2, line: 423, type: !46, isLocal: true, isDefinition: true)
!46 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 96, elements: !47)
!47 = !{!48}
!48 = !DISubrange(count: 12)
!49 = distinct !DICompileUnit(language: DW_LANG_C11, file: !2, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !50, retainedTypes: !67, globals: !270, splitDebugInlining: false, nameTableKind: None)
!50 = !{!51, !57}
!51 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "obj_io_mode", file: !52, line: 66, baseType: !53, size: 32, elements: !54)
!52 = !DIFile(filename: "./extstore.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "848685d924a1d79d44595af1ab890a1f")
!53 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!54 = !{!55, !56}
!55 = !DIEnumerator(name: "OBJ_IO_READ", value: 0)
!56 = !DIEnumerator(name: "OBJ_IO_WRITE", value: 1)
!57 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "extstore_res", file: !52, line: 93, baseType: !53, size: 32, elements: !58)
!58 = !{!59, !60, !61, !62, !63, !64, !65, !66}
!59 = !DIEnumerator(name: "EXTSTORE_INIT_BAD_WBUF_SIZE", value: 1)
!60 = !DIEnumerator(name: "EXTSTORE_INIT_NEED_MORE_WBUF", value: 2)
!61 = !DIEnumerator(name: "EXTSTORE_INIT_NEED_MORE_BUCKETS", value: 3)
!62 = !DIEnumerator(name: "EXTSTORE_INIT_PAGE_WBUF_ALIGNMENT", value: 4)
!63 = !DIEnumerator(name: "EXTSTORE_INIT_TOO_MANY_PAGES", value: 5)
!64 = !DIEnumerator(name: "EXTSTORE_INIT_OOM", value: 6)
!65 = !DIEnumerator(name: "EXTSTORE_INIT_OPEN_FAIL", value: 7)
!66 = !DIEnumerator(name: "EXTSTORE_INIT_THREAD_FAIL", value: 8)
!67 = !{!68, !155, !132, !180}
!68 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !69, size: 64)
!69 = !DIDerivedType(tag: DW_TAG_typedef, name: "store_engine", file: !2, line: 76, baseType: !70)
!70 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "store_engine", file: !2, line: 91, size: 2880, elements: !71)
!71 = !{!72, !104, !148, !149, !179, !223, !224, !226, !227, !228, !229, !230, !231, !232, !233, !234, !235, !236, !237, !266}
!72 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !70, file: !2, line: 92, baseType: !73, size: 320)
!73 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutex_t", file: !74, line: 72, baseType: !75)
!74 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h", directory: "", checksumkind: CSK_MD5, checksum: "8a5acdbeec491eca11cf81cb1ef77ea7")
!75 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !74, line: 67, size: 320, elements: !76)
!76 = !{!77, !98, !102}
!77 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !75, file: !74, line: 69, baseType: !78, size: 320)
!78 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_mutex_s", file: !79, line: 22, size: 320, elements: !80)
!79 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h", directory: "", checksumkind: CSK_MD5, checksum: "6b075eca9ab0e2d761b2afc4ecfab776")
!80 = !{!81, !83, !84, !85, !86, !87, !89, !90}
!81 = !DIDerivedType(tag: DW_TAG_member, name: "__lock", scope: !78, file: !79, line: 24, baseType: !82, size: 32)
!82 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!83 = !DIDerivedType(tag: DW_TAG_member, name: "__count", scope: !78, file: !79, line: 25, baseType: !53, size: 32, offset: 32)
!84 = !DIDerivedType(tag: DW_TAG_member, name: "__owner", scope: !78, file: !79, line: 26, baseType: !82, size: 32, offset: 64)
!85 = !DIDerivedType(tag: DW_TAG_member, name: "__nusers", scope: !78, file: !79, line: 28, baseType: !53, size: 32, offset: 96)
!86 = !DIDerivedType(tag: DW_TAG_member, name: "__kind", scope: !78, file: !79, line: 32, baseType: !82, size: 32, offset: 128)
!87 = !DIDerivedType(tag: DW_TAG_member, name: "__spins", scope: !78, file: !79, line: 34, baseType: !88, size: 16, offset: 160)
!88 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!89 = !DIDerivedType(tag: DW_TAG_member, name: "__elision", scope: !78, file: !79, line: 35, baseType: !88, size: 16, offset: 176)
!90 = !DIDerivedType(tag: DW_TAG_member, name: "__list", scope: !78, file: !79, line: 36, baseType: !91, size: 128, offset: 192)
!91 = !DIDerivedType(tag: DW_TAG_typedef, name: "__pthread_list_t", file: !92, line: 55, baseType: !93)
!92 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h", directory: "", checksumkind: CSK_MD5, checksum: "b9a7199822bce372686baacd32a9f4f3")
!93 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_internal_list", file: !92, line: 51, size: 128, elements: !94)
!94 = !{!95, !97}
!95 = !DIDerivedType(tag: DW_TAG_member, name: "__prev", scope: !93, file: !92, line: 53, baseType: !96, size: 64)
!96 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !93, size: 64)
!97 = !DIDerivedType(tag: DW_TAG_member, name: "__next", scope: !93, file: !92, line: 54, baseType: !96, size: 64, offset: 64)
!98 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !75, file: !74, line: 70, baseType: !99, size: 320)
!99 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 320, elements: !100)
!100 = !{!101}
!101 = !DISubrange(count: 40)
!102 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !75, file: !74, line: 71, baseType: !103, size: 64)
!103 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!104 = !DIDerivedType(tag: DW_TAG_member, name: "pages", scope: !70, file: !2, line: 93, baseType: !105, size: 64, offset: 320)
!105 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !106, size: 64)
!106 = !DIDerivedType(tag: DW_TAG_typedef, name: "store_page", file: !2, line: 74, baseType: !107)
!107 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_store_page", file: !2, line: 56, size: 960, elements: !108)
!108 = !{!109, !110, !116, !117, !118, !119, !120, !121, !122, !123, !124, !125, !127, !129, !130, !131, !146}
!109 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !107, file: !2, line: 57, baseType: !73, size: 320)
!110 = !DIDerivedType(tag: DW_TAG_member, name: "obj_count", scope: !107, file: !2, line: 58, baseType: !111, size: 64, offset: 320)
!111 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !112, line: 27, baseType: !113)
!112 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!113 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !114, line: 45, baseType: !115)
!114 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!115 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!116 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_used", scope: !107, file: !2, line: 59, baseType: !111, size: 64, offset: 384)
!117 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !107, file: !2, line: 60, baseType: !111, size: 64, offset: 448)
!118 = !DIDerivedType(tag: DW_TAG_member, name: "version", scope: !107, file: !2, line: 61, baseType: !53, size: 32, offset: 512)
!119 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !107, file: !2, line: 62, baseType: !53, size: 32, offset: 544)
!120 = !DIDerivedType(tag: DW_TAG_member, name: "allocated", scope: !107, file: !2, line: 63, baseType: !53, size: 32, offset: 576)
!121 = !DIDerivedType(tag: DW_TAG_member, name: "written", scope: !107, file: !2, line: 64, baseType: !53, size: 32, offset: 608)
!122 = !DIDerivedType(tag: DW_TAG_member, name: "bucket", scope: !107, file: !2, line: 65, baseType: !53, size: 32, offset: 640)
!123 = !DIDerivedType(tag: DW_TAG_member, name: "free_bucket", scope: !107, file: !2, line: 66, baseType: !53, size: 32, offset: 672)
!124 = !DIDerivedType(tag: DW_TAG_member, name: "fd", scope: !107, file: !2, line: 67, baseType: !82, size: 32, offset: 704)
!125 = !DIDerivedType(tag: DW_TAG_member, name: "id", scope: !107, file: !2, line: 68, baseType: !126, size: 16, offset: 736)
!126 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!127 = !DIDerivedType(tag: DW_TAG_member, name: "active", scope: !107, file: !2, line: 69, baseType: !128, size: 8, offset: 752)
!128 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!129 = !DIDerivedType(tag: DW_TAG_member, name: "closed", scope: !107, file: !2, line: 70, baseType: !128, size: 8, offset: 760)
!130 = !DIDerivedType(tag: DW_TAG_member, name: "free", scope: !107, file: !2, line: 71, baseType: !128, size: 8, offset: 768)
!131 = !DIDerivedType(tag: DW_TAG_member, name: "wbuf", scope: !107, file: !2, line: 72, baseType: !132, size: 64, offset: 832)
!132 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !133, size: 64)
!133 = !DIDerivedType(tag: DW_TAG_typedef, name: "_store_wbuf", file: !2, line: 54, baseType: !134)
!134 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__store_wbuf", file: !2, line: 45, size: 320, elements: !135)
!135 = !{!136, !138, !140, !141, !142, !143, !144, !145}
!136 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !134, file: !2, line: 46, baseType: !137, size: 64)
!137 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !134, size: 64)
!138 = !DIDerivedType(tag: DW_TAG_member, name: "buf", scope: !134, file: !2, line: 47, baseType: !139, size: 64, offset: 64)
!139 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !4, size: 64)
!140 = !DIDerivedType(tag: DW_TAG_member, name: "buf_pos", scope: !134, file: !2, line: 48, baseType: !139, size: 64, offset: 128)
!141 = !DIDerivedType(tag: DW_TAG_member, name: "free", scope: !134, file: !2, line: 49, baseType: !53, size: 32, offset: 192)
!142 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !134, file: !2, line: 50, baseType: !53, size: 32, offset: 224)
!143 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !134, file: !2, line: 51, baseType: !53, size: 32, offset: 256)
!144 = !DIDerivedType(tag: DW_TAG_member, name: "full", scope: !134, file: !2, line: 52, baseType: !128, size: 8, offset: 288)
!145 = !DIDerivedType(tag: DW_TAG_member, name: "flushed", scope: !134, file: !2, line: 53, baseType: !128, size: 8, offset: 296)
!146 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !107, file: !2, line: 73, baseType: !147, size: 64, offset: 896)
!147 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !107, size: 64)
!148 = !DIDerivedType(tag: DW_TAG_member, name: "wbuf_stack", scope: !70, file: !2, line: 94, baseType: !132, size: 64, offset: 384)
!149 = !DIDerivedType(tag: DW_TAG_member, name: "io_stack", scope: !70, file: !2, line: 95, baseType: !150, size: 64, offset: 448)
!150 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !151, size: 64)
!151 = !DIDerivedType(tag: DW_TAG_typedef, name: "obj_io", file: !52, line: 71, baseType: !152)
!152 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_obj_io", file: !52, line: 78, size: 512, elements: !153)
!153 = !{!154, !156, !158, !159, !168, !169, !170, !171, !172, !173, !174}
!154 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !152, file: !52, line: 79, baseType: !155, size: 64)
!155 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!156 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !152, file: !52, line: 80, baseType: !157, size: 64, offset: 64)
!157 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !152, size: 64)
!158 = !DIDerivedType(tag: DW_TAG_member, name: "buf", scope: !152, file: !52, line: 81, baseType: !139, size: 64, offset: 128)
!159 = !DIDerivedType(tag: DW_TAG_member, name: "iov", scope: !152, file: !52, line: 82, baseType: !160, size: 64, offset: 192)
!160 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !161, size: 64)
!161 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iovec", file: !162, line: 26, size: 128, elements: !163)
!162 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_iovec.h", directory: "", checksumkind: CSK_MD5, checksum: "a53f2c2488bb0e21e47850624c16538a")
!163 = !{!164, !165}
!164 = !DIDerivedType(tag: DW_TAG_member, name: "iov_base", scope: !161, file: !162, line: 28, baseType: !155, size: 64)
!165 = !DIDerivedType(tag: DW_TAG_member, name: "iov_len", scope: !161, file: !162, line: 29, baseType: !166, size: 64, offset: 64)
!166 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !167, line: 18, baseType: !115)
!167 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!168 = !DIDerivedType(tag: DW_TAG_member, name: "iovcnt", scope: !152, file: !52, line: 83, baseType: !53, size: 32, offset: 256)
!169 = !DIDerivedType(tag: DW_TAG_member, name: "page_version", scope: !152, file: !52, line: 84, baseType: !53, size: 32, offset: 288)
!170 = !DIDerivedType(tag: DW_TAG_member, name: "len", scope: !152, file: !52, line: 85, baseType: !53, size: 32, offset: 320)
!171 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !152, file: !52, line: 86, baseType: !53, size: 32, offset: 352)
!172 = !DIDerivedType(tag: DW_TAG_member, name: "page_id", scope: !152, file: !52, line: 87, baseType: !126, size: 16, offset: 384)
!173 = !DIDerivedType(tag: DW_TAG_member, name: "mode", scope: !152, file: !52, line: 88, baseType: !51, size: 32, offset: 416)
!174 = !DIDerivedType(tag: DW_TAG_member, name: "cb", scope: !152, file: !52, line: 90, baseType: !175, size: 64, offset: 448)
!175 = !DIDerivedType(tag: DW_TAG_typedef, name: "obj_io_cb", file: !52, line: 72, baseType: !176)
!176 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !177, size: 64)
!177 = !DISubroutineType(types: !178)
!178 = !{null, !155, !150, !82}
!179 = !DIDerivedType(tag: DW_TAG_member, name: "io_threads", scope: !70, file: !2, line: 96, baseType: !180, size: 64, offset: 512)
!180 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !181, size: 64)
!181 = !DIDerivedType(tag: DW_TAG_typedef, name: "store_io_thread", file: !2, line: 84, baseType: !182)
!182 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !2, line: 77, size: 960, elements: !183)
!183 = !{!184, !185, !219, !220, !221, !222}
!184 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !182, file: !2, line: 78, baseType: !73, size: 320)
!185 = !DIDerivedType(tag: DW_TAG_member, name: "cond", scope: !182, file: !2, line: 79, baseType: !186, size: 384, offset: 320)
!186 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_cond_t", file: !74, line: 80, baseType: !187)
!187 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !74, line: 75, size: 384, elements: !188)
!188 = !{!189, !213, !217}
!189 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !187, file: !74, line: 77, baseType: !190, size: 384)
!190 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_cond_s", file: !92, line: 94, size: 384, elements: !191)
!191 = !{!192, !204, !205, !209, !210, !211, !212}
!192 = !DIDerivedType(tag: DW_TAG_member, name: "__wseq", scope: !190, file: !92, line: 96, baseType: !193, size: 64)
!193 = !DIDerivedType(tag: DW_TAG_typedef, name: "__atomic_wide_counter", file: !194, line: 33, baseType: !195)
!194 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h", directory: "", checksumkind: CSK_MD5, checksum: "d1ec99b0f6e36c0a42ac284d459cbd38")
!195 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !194, line: 25, size: 64, elements: !196)
!196 = !{!197, !199}
!197 = !DIDerivedType(tag: DW_TAG_member, name: "__value64", scope: !195, file: !194, line: 27, baseType: !198, size: 64)
!198 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!199 = !DIDerivedType(tag: DW_TAG_member, name: "__value32", scope: !195, file: !194, line: 32, baseType: !200, size: 64)
!200 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !195, file: !194, line: 28, size: 64, elements: !201)
!201 = !{!202, !203}
!202 = !DIDerivedType(tag: DW_TAG_member, name: "__low", scope: !200, file: !194, line: 30, baseType: !53, size: 32)
!203 = !DIDerivedType(tag: DW_TAG_member, name: "__high", scope: !200, file: !194, line: 31, baseType: !53, size: 32, offset: 32)
!204 = !DIDerivedType(tag: DW_TAG_member, name: "__g1_start", scope: !190, file: !92, line: 97, baseType: !193, size: 64, offset: 64)
!205 = !DIDerivedType(tag: DW_TAG_member, name: "__g_refs", scope: !190, file: !92, line: 98, baseType: !206, size: 64, offset: 128)
!206 = !DICompositeType(tag: DW_TAG_array_type, baseType: !53, size: 64, elements: !207)
!207 = !{!208}
!208 = !DISubrange(count: 2)
!209 = !DIDerivedType(tag: DW_TAG_member, name: "__g_size", scope: !190, file: !92, line: 99, baseType: !206, size: 64, offset: 192)
!210 = !DIDerivedType(tag: DW_TAG_member, name: "__g1_orig_size", scope: !190, file: !92, line: 100, baseType: !53, size: 32, offset: 256)
!211 = !DIDerivedType(tag: DW_TAG_member, name: "__wrefs", scope: !190, file: !92, line: 101, baseType: !53, size: 32, offset: 288)
!212 = !DIDerivedType(tag: DW_TAG_member, name: "__g_signals", scope: !190, file: !92, line: 102, baseType: !206, size: 64, offset: 320)
!213 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !187, file: !74, line: 78, baseType: !214, size: 384)
!214 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 384, elements: !215)
!215 = !{!216}
!216 = !DISubrange(count: 48)
!217 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !187, file: !74, line: 79, baseType: !218, size: 64)
!218 = !DIBasicType(name: "long long", size: 64, encoding: DW_ATE_signed)
!219 = !DIDerivedType(tag: DW_TAG_member, name: "queue", scope: !182, file: !2, line: 80, baseType: !150, size: 64, offset: 704)
!220 = !DIDerivedType(tag: DW_TAG_member, name: "queue_tail", scope: !182, file: !2, line: 81, baseType: !150, size: 64, offset: 768)
!221 = !DIDerivedType(tag: DW_TAG_member, name: "e", scope: !182, file: !2, line: 82, baseType: !68, size: 64, offset: 832)
!222 = !DIDerivedType(tag: DW_TAG_member, name: "depth", scope: !182, file: !2, line: 83, baseType: !53, size: 32, offset: 896)
!223 = !DIDerivedType(tag: DW_TAG_member, name: "bg_thread", scope: !70, file: !2, line: 97, baseType: !180, size: 64, offset: 576)
!224 = !DIDerivedType(tag: DW_TAG_member, name: "page_buckets", scope: !70, file: !2, line: 98, baseType: !225, size: 64, offset: 640)
!225 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !105, size: 64)
!226 = !DIDerivedType(tag: DW_TAG_member, name: "free_page_buckets", scope: !70, file: !2, line: 99, baseType: !225, size: 64, offset: 704)
!227 = !DIDerivedType(tag: DW_TAG_member, name: "page_size", scope: !70, file: !2, line: 100, baseType: !166, size: 64, offset: 768)
!228 = !DIDerivedType(tag: DW_TAG_member, name: "version", scope: !70, file: !2, line: 101, baseType: !53, size: 32, offset: 832)
!229 = !DIDerivedType(tag: DW_TAG_member, name: "last_io_thread", scope: !70, file: !2, line: 102, baseType: !53, size: 32, offset: 864)
!230 = !DIDerivedType(tag: DW_TAG_member, name: "io_threadcount", scope: !70, file: !2, line: 103, baseType: !53, size: 32, offset: 896)
!231 = !DIDerivedType(tag: DW_TAG_member, name: "page_count", scope: !70, file: !2, line: 104, baseType: !53, size: 32, offset: 928)
!232 = !DIDerivedType(tag: DW_TAG_member, name: "page_free", scope: !70, file: !2, line: 105, baseType: !53, size: 32, offset: 960)
!233 = !DIDerivedType(tag: DW_TAG_member, name: "page_bucketcount", scope: !70, file: !2, line: 106, baseType: !53, size: 32, offset: 992)
!234 = !DIDerivedType(tag: DW_TAG_member, name: "free_page_bucketcount", scope: !70, file: !2, line: 107, baseType: !53, size: 32, offset: 1024)
!235 = !DIDerivedType(tag: DW_TAG_member, name: "io_depth", scope: !70, file: !2, line: 108, baseType: !53, size: 32, offset: 1056)
!236 = !DIDerivedType(tag: DW_TAG_member, name: "stats_mutex", scope: !70, file: !2, line: 109, baseType: !73, size: 320, offset: 1088)
!237 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !70, file: !2, line: 110, baseType: !238, size: 1152, offset: 1408)
!238 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "extstore_stats", file: !52, line: 21, size: 1152, elements: !239)
!239 = !{!240, !241, !242, !243, !244, !245, !246, !247, !248, !249, !250, !251, !252, !253, !254, !255, !256, !257}
!240 = !DIDerivedType(tag: DW_TAG_member, name: "page_allocs", scope: !238, file: !52, line: 22, baseType: !111, size: 64)
!241 = !DIDerivedType(tag: DW_TAG_member, name: "page_count", scope: !238, file: !52, line: 23, baseType: !111, size: 64, offset: 64)
!242 = !DIDerivedType(tag: DW_TAG_member, name: "page_evictions", scope: !238, file: !52, line: 24, baseType: !111, size: 64, offset: 128)
!243 = !DIDerivedType(tag: DW_TAG_member, name: "page_reclaims", scope: !238, file: !52, line: 25, baseType: !111, size: 64, offset: 192)
!244 = !DIDerivedType(tag: DW_TAG_member, name: "page_size", scope: !238, file: !52, line: 26, baseType: !111, size: 64, offset: 256)
!245 = !DIDerivedType(tag: DW_TAG_member, name: "pages_free", scope: !238, file: !52, line: 27, baseType: !111, size: 64, offset: 320)
!246 = !DIDerivedType(tag: DW_TAG_member, name: "pages_used", scope: !238, file: !52, line: 28, baseType: !111, size: 64, offset: 384)
!247 = !DIDerivedType(tag: DW_TAG_member, name: "objects_evicted", scope: !238, file: !52, line: 29, baseType: !111, size: 64, offset: 448)
!248 = !DIDerivedType(tag: DW_TAG_member, name: "objects_read", scope: !238, file: !52, line: 30, baseType: !111, size: 64, offset: 512)
!249 = !DIDerivedType(tag: DW_TAG_member, name: "objects_written", scope: !238, file: !52, line: 31, baseType: !111, size: 64, offset: 576)
!250 = !DIDerivedType(tag: DW_TAG_member, name: "objects_used", scope: !238, file: !52, line: 32, baseType: !111, size: 64, offset: 640)
!251 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_evicted", scope: !238, file: !52, line: 33, baseType: !111, size: 64, offset: 704)
!252 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_written", scope: !238, file: !52, line: 34, baseType: !111, size: 64, offset: 768)
!253 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_read", scope: !238, file: !52, line: 35, baseType: !111, size: 64, offset: 832)
!254 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_used", scope: !238, file: !52, line: 36, baseType: !111, size: 64, offset: 896)
!255 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_fragmented", scope: !238, file: !52, line: 37, baseType: !111, size: 64, offset: 960)
!256 = !DIDerivedType(tag: DW_TAG_member, name: "io_queue", scope: !238, file: !52, line: 38, baseType: !111, size: 64, offset: 1024)
!257 = !DIDerivedType(tag: DW_TAG_member, name: "page_data", scope: !238, file: !52, line: 39, baseType: !258, size: 64, offset: 1088)
!258 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !259, size: 64)
!259 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "extstore_page_data", file: !52, line: 7, size: 256, elements: !260)
!260 = !{!261, !262, !263, !264, !265}
!261 = !DIDerivedType(tag: DW_TAG_member, name: "version", scope: !259, file: !52, line: 8, baseType: !111, size: 64)
!262 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_used", scope: !259, file: !52, line: 9, baseType: !111, size: 64, offset: 64)
!263 = !DIDerivedType(tag: DW_TAG_member, name: "bucket", scope: !259, file: !52, line: 10, baseType: !53, size: 32, offset: 128)
!264 = !DIDerivedType(tag: DW_TAG_member, name: "free_bucket", scope: !259, file: !52, line: 11, baseType: !53, size: 32, offset: 160)
!265 = !DIDerivedType(tag: DW_TAG_member, name: "active", scope: !259, file: !52, line: 12, baseType: !128, size: 8, offset: 192)
!266 = !DIDerivedType(tag: DW_TAG_member, name: "maint", scope: !70, file: !2, line: 111, baseType: !267, size: 320, offset: 2560)
!267 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "store_maint", file: !2, line: 87, size: 320, elements: !268)
!268 = !{!269}
!269 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !267, file: !2, line: 88, baseType: !73, size: 320)
!270 = !{!0, !7, !12, !17, !22, !27, !32, !34, !39, !44}
!271 = !{i32 7, !"Dwarf Version", i32 5}
!272 = !{i32 2, !"Debug Info Version", i32 3}
!273 = !{i32 1, !"wchar_size", i32 4}
!274 = !{i32 8, !"PIC Level", i32 2}
!275 = !{i32 7, !"PIE Level", i32 2}
!276 = !{i32 7, !"uwtable", i32 2}
!277 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!278 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!279 = distinct !DISubprogram(name: "extstore_get_stats", scope: !2, file: !2, line: 172, type: !280, scopeLine: 172, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !283)
!280 = !DISubroutineType(types: !281)
!281 = !{null, !155, !282}
!282 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !238, size: 64)
!283 = !{!284, !285, !286, !287}
!284 = !DILocalVariable(name: "ptr", arg: 1, scope: !279, file: !2, line: 172, type: !155)
!285 = !DILocalVariable(name: "st", arg: 2, scope: !279, file: !2, line: 172, type: !282)
!286 = !DILocalVariable(name: "e", scope: !279, file: !2, line: 173, type: !68)
!287 = !DILocalVariable(name: "x", scope: !288, file: !2, line: 184, type: !82)
!288 = distinct !DILexicalBlock(scope: !279, file: !2, line: 184, column: 5)
!289 = !DILocation(line: 0, scope: !279)
!290 = !DILocation(line: 174, column: 5, scope: !279)
!291 = !DILocation(line: 175, column: 20, scope: !279)
!292 = !DILocation(line: 175, column: 5, scope: !279)
!293 = !DILocation(line: 176, column: 5, scope: !279)
!294 = !DILocation(line: 179, column: 5, scope: !279)
!295 = !DILocation(line: 180, column: 25, scope: !279)
!296 = !{!297, !302, i64 120}
!297 = !{!"store_engine", !298, i64 0, !300, i64 40, !300, i64 48, !300, i64 56, !300, i64 64, !300, i64 72, !300, i64 80, !300, i64 88, !301, i64 96, !302, i64 104, !302, i64 108, !302, i64 112, !302, i64 116, !302, i64 120, !302, i64 124, !302, i64 128, !302, i64 132, !298, i64 136, !303, i64 176, !304, i64 320}
!298 = !{!"omnipotent char", !299, i64 0}
!299 = !{!"Simple C/C++ TBAA"}
!300 = !{!"any pointer", !298, i64 0}
!301 = !{!"long", !298, i64 0}
!302 = !{!"int", !298, i64 0}
!303 = !{!"extstore_stats", !301, i64 0, !301, i64 8, !301, i64 16, !301, i64 24, !301, i64 32, !301, i64 40, !301, i64 48, !301, i64 56, !301, i64 64, !301, i64 72, !301, i64 80, !301, i64 88, !301, i64 96, !301, i64 104, !301, i64 112, !301, i64 120, !301, i64 128, !300, i64 136}
!304 = !{!"store_maint", !298, i64 0}
!305 = !DILocation(line: 180, column: 22, scope: !279)
!306 = !DILocation(line: 180, column: 9, scope: !279)
!307 = !DILocation(line: 180, column: 20, scope: !279)
!308 = !{!303, !301, i64 40}
!309 = !DILocation(line: 181, column: 25, scope: !279)
!310 = !{!297, !302, i64 116}
!311 = !DILocation(line: 181, column: 36, scope: !279)
!312 = !DILocation(line: 181, column: 22, scope: !279)
!313 = !DILocation(line: 181, column: 9, scope: !279)
!314 = !DILocation(line: 181, column: 20, scope: !279)
!315 = !{!303, !301, i64 48}
!316 = !DILocation(line: 182, column: 5, scope: !279)
!317 = !DILocation(line: 183, column: 9, scope: !279)
!318 = !DILocation(line: 183, column: 18, scope: !279)
!319 = !{!303, !301, i64 128}
!320 = !DILocation(line: 0, scope: !288)
!321 = !DILocation(line: 184, column: 28, scope: !322)
!322 = distinct !DILexicalBlock(scope: !288, file: !2, line: 184, column: 5)
!323 = !{!297, !302, i64 112}
!324 = !DILocation(line: 184, column: 23, scope: !322)
!325 = !DILocation(line: 184, column: 5, scope: !288)
!326 = !DILocation(line: 191, column: 32, scope: !279)
!327 = !DILocation(line: 191, column: 48, scope: !279)
!328 = !{!297, !301, i64 96}
!329 = !DILocation(line: 191, column: 43, scope: !279)
!330 = !DILocation(line: 192, column: 13, scope: !279)
!331 = !{!303, !301, i64 112}
!332 = !DILocation(line: 191, column: 58, scope: !279)
!333 = !DILocation(line: 191, column: 9, scope: !279)
!334 = !DILocation(line: 191, column: 26, scope: !279)
!335 = !{!303, !301, i64 120}
!336 = !DILocation(line: 193, column: 1, scope: !279)
!337 = !DILocation(line: 185, column: 32, scope: !338)
!338 = distinct !DILexicalBlock(scope: !322, file: !2, line: 184, column: 49)
!339 = !{!297, !300, i64 64}
!340 = !DILocation(line: 185, column: 29, scope: !338)
!341 = !DILocation(line: 185, column: 9, scope: !338)
!342 = !DILocation(line: 186, column: 28, scope: !338)
!343 = !DILocation(line: 186, column: 42, scope: !338)
!344 = !{!345, !302, i64 112}
!345 = !{!"", !298, i64 0, !298, i64 40, !300, i64 88, !300, i64 96, !300, i64 104, !302, i64 112}
!346 = !DILocation(line: 186, column: 25, scope: !338)
!347 = !DILocation(line: 186, column: 22, scope: !338)
!348 = !DILocation(line: 187, column: 31, scope: !338)
!349 = !DILocation(line: 187, column: 9, scope: !338)
!350 = !DILocation(line: 184, column: 45, scope: !322)
!351 = distinct !{!351, !325, !352, !353}
!352 = !DILocation(line: 188, column: 5, scope: !288)
!353 = !{!"llvm.loop.mustprogress"}
!354 = !DISubprogram(name: "pthread_mutex_lock", scope: !355, file: !355, line: 794, type: !356, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!355 = !DIFile(filename: "/usr/include/pthread.h", directory: "", checksumkind: CSK_MD5, checksum: "cbcd748b3d3ecaa7356dc2925b45d819")
!356 = !DISubroutineType(types: !357)
!357 = !{!82, !358}
!358 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !73, size: 64)
!359 = !DISubprogram(name: "pthread_mutex_unlock", scope: !355, file: !355, line: 835, type: !356, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!360 = distinct !DISubprogram(name: "extstore_get_page_data", scope: !2, file: !2, line: 195, type: !280, scopeLine: 195, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !361)
!361 = !{!362, !363, !364, !365, !366, !368}
!362 = !DILocalVariable(name: "ptr", arg: 1, scope: !360, file: !2, line: 195, type: !155)
!363 = !DILocalVariable(name: "st", arg: 2, scope: !360, file: !2, line: 195, type: !282)
!364 = !DILocalVariable(name: "e", scope: !360, file: !2, line: 196, type: !68)
!365 = !DILocalVariable(name: "pd", scope: !360, file: !2, line: 198, type: !258)
!366 = !DILocalVariable(name: "i", scope: !367, file: !2, line: 200, type: !82)
!367 = distinct !DILexicalBlock(scope: !360, file: !2, line: 200, column: 5)
!368 = !DILocalVariable(name: "p", scope: !369, file: !2, line: 201, type: !105)
!369 = distinct !DILexicalBlock(scope: !370, file: !2, line: 200, column: 45)
!370 = distinct !DILexicalBlock(scope: !367, file: !2, line: 200, column: 5)
!371 = !DILocation(line: 0, scope: !360)
!372 = !DILocation(line: 197, column: 28, scope: !360)
!373 = !DILocation(line: 197, column: 5, scope: !360)
!374 = !DILocation(line: 198, column: 41, scope: !360)
!375 = !{!303, !300, i64 136}
!376 = !DILocation(line: 0, scope: !367)
!377 = !DILocation(line: 200, column: 28, scope: !370)
!378 = !DILocation(line: 200, column: 23, scope: !370)
!379 = !DILocation(line: 200, column: 5, scope: !367)
!380 = !DILocation(line: 223, column: 5, scope: !360)
!381 = !DILocation(line: 224, column: 1, scope: !360)
!382 = !DILocation(line: 201, column: 29, scope: !369)
!383 = !{!297, !300, i64 40}
!384 = !DILocation(line: 201, column: 26, scope: !369)
!385 = !DILocation(line: 0, scope: !369)
!386 = !DILocation(line: 202, column: 9, scope: !369)
!387 = !DILocation(line: 204, column: 36, scope: !369)
!388 = !{!389, !302, i64 84}
!389 = !{!"_store_page", !298, i64 0, !301, i64 40, !301, i64 48, !301, i64 56, !302, i64 64, !302, i64 68, !302, i64 72, !302, i64 76, !302, i64 80, !302, i64 84, !302, i64 88, !390, i64 92, !391, i64 94, !391, i64 95, !391, i64 96, !300, i64 104, !300, i64 112}
!390 = !{!"short", !298, i64 0}
!391 = !{!"_Bool", !298, i64 0}
!392 = !DILocation(line: 204, column: 15, scope: !369)
!393 = !{!389, !390, i64 92}
!394 = !DILocation(line: 204, column: 9, scope: !369)
!395 = !DILocation(line: 204, column: 19, scope: !369)
!396 = !DILocation(line: 204, column: 31, scope: !369)
!397 = !{!398, !302, i64 20}
!398 = !{!"extstore_page_data", !301, i64 0, !301, i64 8, !302, i64 16, !302, i64 20, !391, i64 24}
!399 = !DILocation(line: 205, column: 32, scope: !369)
!400 = !{!389, !302, i64 64}
!401 = !DILocation(line: 205, column: 29, scope: !369)
!402 = !DILocation(line: 205, column: 9, scope: !369)
!403 = !DILocation(line: 205, column: 27, scope: !369)
!404 = !{!398, !301, i64 0}
!405 = !DILocation(line: 206, column: 35, scope: !369)
!406 = !{!389, !301, i64 48}
!407 = !DILocation(line: 206, column: 19, scope: !369)
!408 = !DILocation(line: 206, column: 30, scope: !369)
!409 = !{!398, !301, i64 8}
!410 = !DILocation(line: 207, column: 16, scope: !411)
!411 = distinct !DILexicalBlock(scope: !369, file: !2, line: 207, column: 13)
!412 = !{!389, !391, i64 94}
!413 = !{i8 0, i8 2}
!414 = !{}
!415 = !DILocation(line: 207, column: 13, scope: !369)
!416 = !DILocation(line: 208, column: 23, scope: !417)
!417 = distinct !DILexicalBlock(scope: !411, file: !2, line: 207, column: 24)
!418 = !DILocation(line: 208, column: 30, scope: !417)
!419 = !{!398, !391, i64 24}
!420 = !DILocation(line: 210, column: 23, scope: !421)
!421 = distinct !DILexicalBlock(scope: !369, file: !2, line: 210, column: 13)
!422 = !DILocation(line: 210, column: 29, scope: !421)
!423 = !{!389, !391, i64 96}
!424 = !DILocation(line: 210, column: 13, scope: !369)
!425 = !DILocation(line: 214, column: 16, scope: !426)
!426 = distinct !DILexicalBlock(scope: !369, file: !2, line: 214, column: 13)
!427 = !{!389, !301, i64 40}
!428 = !DILocation(line: 214, column: 26, scope: !426)
!429 = !DILocation(line: 214, column: 30, scope: !426)
!430 = !DILocation(line: 214, column: 37, scope: !426)
!431 = !{!389, !391, i64 95}
!432 = !DILocation(line: 214, column: 13, scope: !369)
!433 = !DILocation(line: 215, column: 35, scope: !434)
!434 = distinct !DILexicalBlock(scope: !426, file: !2, line: 214, column: 45)
!435 = !{!389, !302, i64 80}
!436 = !DILocation(line: 215, column: 23, scope: !434)
!437 = !DILocation(line: 215, column: 30, scope: !434)
!438 = !{!398, !302, i64 16}
!439 = !DILocation(line: 217, column: 52, scope: !440)
!440 = distinct !DILexicalBlock(scope: !369, file: !2, line: 217, column: 13)
!441 = !{!389, !302, i64 68}
!442 = !DILocation(line: 217, column: 61, scope: !440)
!443 = !DILocation(line: 217, column: 13, scope: !369)
!444 = !DILocation(line: 218, column: 13, scope: !445)
!445 = distinct !DILexicalBlock(scope: !440, file: !2, line: 217, column: 67)
!446 = !DILocation(line: 219, column: 9, scope: !445)
!447 = !DILocation(line: 200, column: 41, scope: !370)
!448 = distinct !{!448, !379, !449, !353}
!449 = !DILocation(line: 221, column: 5, scope: !367)
!450 = distinct !DISubprogram(name: "_free_page", scope: !2, file: !2, line: 951, type: !451, scopeLine: 951, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !453)
!451 = !DISubroutineType(types: !452)
!452 = !{null, !68, !105}
!453 = !{!454, !455, !456, !457}
!454 = !DILocalVariable(name: "e", arg: 1, scope: !450, file: !2, line: 951, type: !68)
!455 = !DILocalVariable(name: "p", arg: 2, scope: !450, file: !2, line: 951, type: !105)
!456 = !DILocalVariable(name: "tmp", scope: !450, file: !2, line: 952, type: !105)
!457 = !DILocalVariable(name: "prev", scope: !450, file: !2, line: 953, type: !105)
!458 = !DILocation(line: 0, scope: !450)
!459 = !DILocation(line: 955, column: 5, scope: !450)
!460 = !DILocation(line: 956, column: 33, scope: !450)
!461 = !DILocation(line: 956, column: 14, scope: !450)
!462 = !DILocation(line: 956, column: 27, scope: !450)
!463 = !{!297, !301, i64 256}
!464 = !DILocation(line: 957, column: 31, scope: !450)
!465 = !DILocation(line: 957, column: 14, scope: !450)
!466 = !DILocation(line: 957, column: 25, scope: !450)
!467 = !{!297, !301, i64 288}
!468 = !DILocation(line: 958, column: 14, scope: !450)
!469 = !DILocation(line: 958, column: 27, scope: !450)
!470 = !{!297, !301, i64 200}
!471 = !DILocation(line: 959, column: 5, scope: !450)
!472 = !DILocation(line: 960, column: 5, scope: !450)
!473 = !DILocation(line: 962, column: 14, scope: !450)
!474 = !{!297, !300, i64 80}
!475 = !DILocation(line: 962, column: 30, scope: !450)
!476 = !DILocation(line: 962, column: 11, scope: !450)
!477 = !{!300, !300, i64 0}
!478 = !DILocation(line: 963, column: 5, scope: !450)
!479 = !DILocation(line: 964, column: 17, scope: !480)
!480 = distinct !DILexicalBlock(scope: !481, file: !2, line: 964, column: 13)
!481 = distinct !DILexicalBlock(scope: !450, file: !2, line: 963, column: 17)
!482 = !DILocation(line: 964, column: 13, scope: !481)
!483 = distinct !{!483, !478, !484, !353}
!484 = !DILocation(line: 975, column: 5, scope: !450)
!485 = !DILocation(line: 965, column: 17, scope: !486)
!486 = distinct !DILexicalBlock(scope: !487, file: !2, line: 965, column: 17)
!487 = distinct !DILexicalBlock(scope: !480, file: !2, line: 964, column: 23)
!488 = !DILocation(line: 0, scope: !486)
!489 = !{!389, !300, i64 112}
!490 = !DILocation(line: 965, column: 17, scope: !487)
!491 = !DILocation(line: 970, column: 18, scope: !487)
!492 = !DILocation(line: 970, column: 23, scope: !487)
!493 = !DILocation(line: 971, column: 13, scope: !487)
!494 = !DILocation(line: 974, column: 20, scope: !481)
!495 = !DILocation(line: 977, column: 8, scope: !450)
!496 = !DILocation(line: 977, column: 16, scope: !450)
!497 = !DILocation(line: 980, column: 8, scope: !450)
!498 = !DILocation(line: 980, column: 18, scope: !450)
!499 = !{!389, !302, i64 72}
!500 = !DILocation(line: 981, column: 8, scope: !450)
!501 = !DILocation(line: 981, column: 16, scope: !450)
!502 = !{!389, !302, i64 76}
!503 = !DILocation(line: 982, column: 15, scope: !450)
!504 = !DILocation(line: 983, column: 8, scope: !450)
!505 = !DILocation(line: 983, column: 15, scope: !450)
!506 = !DILocation(line: 984, column: 8, scope: !450)
!507 = !DILocation(line: 984, column: 15, scope: !450)
!508 = !DILocation(line: 985, column: 8, scope: !450)
!509 = !DILocation(line: 978, column: 18, scope: !450)
!510 = !DILocation(line: 985, column: 13, scope: !450)
!511 = !DILocation(line: 987, column: 18, scope: !450)
!512 = !{!297, !300, i64 88}
!513 = !DILocation(line: 987, column: 39, scope: !450)
!514 = !DILocation(line: 987, column: 15, scope: !450)
!515 = !DILocation(line: 987, column: 8, scope: !450)
!516 = !DILocation(line: 987, column: 13, scope: !450)
!517 = !DILocation(line: 988, column: 42, scope: !450)
!518 = !DILocation(line: 989, column: 8, scope: !450)
!519 = !DILocation(line: 989, column: 17, scope: !450)
!520 = !DILocation(line: 991, column: 5, scope: !450)
!521 = !DILocation(line: 992, column: 1, scope: !450)
!522 = distinct !DISubprogram(name: "extstore_err", scope: !2, file: !2, line: 226, type: !523, scopeLine: 226, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !527)
!523 = !DISubroutineType(types: !524)
!524 = !{!525, !57}
!525 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !526, size: 64)
!526 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !4)
!527 = !{!528, !529}
!528 = !DILocalVariable(name: "res", arg: 1, scope: !522, file: !2, line: 226, type: !57)
!529 = !DILocalVariable(name: "rv", scope: !522, file: !2, line: 227, type: !525)
!530 = !DILocation(line: 0, scope: !522)
!531 = !DILocation(line: 228, column: 5, scope: !522)
!532 = !DILocation(line: 253, column: 5, scope: !522)
!533 = distinct !DISubprogram(name: "extstore_init", scope: !2, file: !2, line: 257, type: !534, scopeLine: 258, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !558)
!534 = !DISubroutineType(types: !535)
!535 = !{!155, !536, !546, !557}
!536 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !537, size: 64)
!537 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "extstore_conf_file", file: !52, line: 56, size: 384, elements: !538)
!538 = !{!539, !540, !541, !542, !543, !544, !545}
!539 = !DIDerivedType(tag: DW_TAG_member, name: "page_count", scope: !537, file: !52, line: 57, baseType: !53, size: 32)
!540 = !DIDerivedType(tag: DW_TAG_member, name: "file", scope: !537, file: !52, line: 58, baseType: !139, size: 64, offset: 64)
!541 = !DIDerivedType(tag: DW_TAG_member, name: "fd", scope: !537, file: !52, line: 59, baseType: !82, size: 32, offset: 128)
!542 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !537, file: !52, line: 60, baseType: !111, size: 64, offset: 192)
!543 = !DIDerivedType(tag: DW_TAG_member, name: "bucket", scope: !537, file: !52, line: 61, baseType: !53, size: 32, offset: 256)
!544 = !DIDerivedType(tag: DW_TAG_member, name: "free_bucket", scope: !537, file: !52, line: 62, baseType: !53, size: 32, offset: 288)
!545 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !537, file: !52, line: 63, baseType: !536, size: 64, offset: 320)
!546 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !547, size: 64)
!547 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "extstore_conf", file: !52, line: 45, size: 256, elements: !548)
!548 = !{!549, !550, !551, !552, !553, !554, !555, !556}
!549 = !DIDerivedType(tag: DW_TAG_member, name: "page_size", scope: !547, file: !52, line: 46, baseType: !53, size: 32)
!550 = !DIDerivedType(tag: DW_TAG_member, name: "page_count", scope: !547, file: !52, line: 47, baseType: !53, size: 32, offset: 32)
!551 = !DIDerivedType(tag: DW_TAG_member, name: "page_buckets", scope: !547, file: !52, line: 48, baseType: !53, size: 32, offset: 64)
!552 = !DIDerivedType(tag: DW_TAG_member, name: "free_page_buckets", scope: !547, file: !52, line: 49, baseType: !53, size: 32, offset: 96)
!553 = !DIDerivedType(tag: DW_TAG_member, name: "wbuf_size", scope: !547, file: !52, line: 50, baseType: !53, size: 32, offset: 128)
!554 = !DIDerivedType(tag: DW_TAG_member, name: "wbuf_count", scope: !547, file: !52, line: 51, baseType: !53, size: 32, offset: 160)
!555 = !DIDerivedType(tag: DW_TAG_member, name: "io_threadcount", scope: !547, file: !52, line: 52, baseType: !53, size: 32, offset: 192)
!556 = !DIDerivedType(tag: DW_TAG_member, name: "io_depth", scope: !547, file: !52, line: 53, baseType: !53, size: 32, offset: 224)
!557 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !57, size: 64)
!558 = !{!559, !560, !561, !562, !563, !564, !566, !567, !568, !582, !586, !590}
!559 = !DILocalVariable(name: "fh", arg: 1, scope: !533, file: !2, line: 257, type: !536)
!560 = !DILocalVariable(name: "cf", arg: 2, scope: !533, file: !2, line: 257, type: !546)
!561 = !DILocalVariable(name: "res", arg: 3, scope: !533, file: !2, line: 258, type: !557)
!562 = !DILocalVariable(name: "i", scope: !533, file: !2, line: 259, type: !82)
!563 = !DILocalVariable(name: "f", scope: !533, file: !2, line: 260, type: !536)
!564 = !DILocalVariable(name: "thread", scope: !533, file: !2, line: 261, type: !565)
!565 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_t", file: !74, line: 27, baseType: !115)
!566 = !DILocalVariable(name: "e", scope: !533, file: !2, line: 284, type: !68)
!567 = !DILocalVariable(name: "temp_page_count", scope: !533, file: !2, line: 291, type: !111)
!568 = !DILocalVariable(name: "lock", scope: !569, file: !2, line: 303, type: !572)
!569 = distinct !DILexicalBlock(scope: !570, file: !2, line: 292, column: 42)
!570 = distinct !DILexicalBlock(scope: !571, file: !2, line: 292, column: 5)
!571 = distinct !DILexicalBlock(scope: !533, file: !2, line: 292, column: 5)
!572 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "flock", file: !573, line: 35, size: 256, elements: !574)
!573 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/fcntl.h", directory: "", checksumkind: CSK_MD5, checksum: "2ed35c963a7c3a401d84a19ac23e0326")
!574 = !{!575, !576, !577, !579, !580}
!575 = !DIDerivedType(tag: DW_TAG_member, name: "l_type", scope: !572, file: !573, line: 37, baseType: !88, size: 16)
!576 = !DIDerivedType(tag: DW_TAG_member, name: "l_whence", scope: !572, file: !573, line: 38, baseType: !88, size: 16, offset: 16)
!577 = !DIDerivedType(tag: DW_TAG_member, name: "l_start", scope: !572, file: !573, line: 40, baseType: !578, size: 64, offset: 64)
!578 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !114, line: 152, baseType: !103)
!579 = !DIDerivedType(tag: DW_TAG_member, name: "l_len", scope: !572, file: !573, line: 41, baseType: !578, size: 64, offset: 128)
!580 = !DIDerivedType(tag: DW_TAG_member, name: "l_pid", scope: !572, file: !573, line: 46, baseType: !581, size: 32, offset: 192)
!581 = !DIDerivedType(tag: DW_TAG_typedef, name: "__pid_t", file: !114, line: 154, baseType: !82)
!582 = !DILocalVariable(name: "fb", scope: !583, file: !2, line: 369, type: !82)
!583 = distinct !DILexicalBlock(scope: !584, file: !2, line: 368, column: 44)
!584 = distinct !DILexicalBlock(scope: !585, file: !2, line: 368, column: 5)
!585 = distinct !DILexicalBlock(scope: !533, file: !2, line: 368, column: 5)
!586 = !DILocalVariable(name: "w", scope: !587, file: !2, line: 390, type: !132)
!587 = distinct !DILexicalBlock(scope: !588, file: !2, line: 389, column: 42)
!588 = distinct !DILexicalBlock(scope: !589, file: !2, line: 389, column: 5)
!589 = distinct !DILexicalBlock(scope: !533, file: !2, line: 389, column: 5)
!590 = !DILocalVariable(name: "io", scope: !587, file: !2, line: 391, type: !150)
!591 = distinct !DIAssignID()
!592 = !DILocation(line: 0, scope: !533)
!593 = distinct !DIAssignID()
!594 = !DILocation(line: 0, scope: !569)
!595 = !DILocation(line: 261, column: 5, scope: !533)
!596 = !DILocation(line: 263, column: 13, scope: !597)
!597 = distinct !DILexicalBlock(scope: !533, file: !2, line: 263, column: 9)
!598 = !{!599, !302, i64 0}
!599 = !{!"extstore_conf", !302, i64 0, !302, i64 4, !302, i64 8, !302, i64 12, !302, i64 16, !302, i64 20, !302, i64 24, !302, i64 28}
!600 = !DILocation(line: 263, column: 29, scope: !597)
!601 = !{!599, !302, i64 16}
!602 = !DILocation(line: 263, column: 23, scope: !597)
!603 = !DILocation(line: 263, column: 39, scope: !597)
!604 = !DILocation(line: 263, column: 9, scope: !533)
!605 = !DILocation(line: 264, column: 14, scope: !606)
!606 = distinct !DILexicalBlock(scope: !597, file: !2, line: 263, column: 45)
!607 = !{!302, !302, i64 0}
!608 = !DILocation(line: 265, column: 9, scope: !606)
!609 = !DILocation(line: 268, column: 13, scope: !610)
!610 = distinct !DILexicalBlock(scope: !533, file: !2, line: 268, column: 9)
!611 = !{!599, !302, i64 8}
!612 = !DILocation(line: 268, column: 32, scope: !610)
!613 = !{!599, !302, i64 20}
!614 = !DILocation(line: 268, column: 26, scope: !610)
!615 = !DILocation(line: 268, column: 9, scope: !533)
!616 = !DILocation(line: 269, column: 14, scope: !617)
!617 = distinct !DILexicalBlock(scope: !610, file: !2, line: 268, column: 44)
!618 = !DILocation(line: 270, column: 9, scope: !617)
!619 = !DILocation(line: 272, column: 26, scope: !620)
!620 = distinct !DILexicalBlock(scope: !533, file: !2, line: 272, column: 9)
!621 = !DILocation(line: 272, column: 9, scope: !533)
!622 = !DILocation(line: 273, column: 14, scope: !623)
!623 = distinct !DILexicalBlock(scope: !620, file: !2, line: 272, column: 31)
!624 = !DILocation(line: 274, column: 9, scope: !623)
!625 = !DILocation(line: 278, column: 48, scope: !626)
!626 = distinct !DILexicalBlock(scope: !533, file: !2, line: 278, column: 9)
!627 = !DILocation(line: 280, column: 14, scope: !628)
!628 = distinct !DILexicalBlock(scope: !626, file: !2, line: 279, column: 49)
!629 = !DILocation(line: 281, column: 9, scope: !628)
!630 = !DILocation(line: 284, column: 23, scope: !533)
!631 = !DILocation(line: 285, column: 11, scope: !632)
!632 = distinct !DILexicalBlock(scope: !533, file: !2, line: 285, column: 9)
!633 = !DILocation(line: 285, column: 9, scope: !533)
!634 = !DILocation(line: 286, column: 14, scope: !635)
!635 = distinct !DILexicalBlock(scope: !632, file: !2, line: 285, column: 20)
!636 = !DILocation(line: 287, column: 9, scope: !635)
!637 = !DILocation(line: 290, column: 20, scope: !533)
!638 = !DILocation(line: 290, column: 8, scope: !533)
!639 = !DILocation(line: 290, column: 18, scope: !533)
!640 = !DILocation(line: 292, column: 20, scope: !570)
!641 = !DILocation(line: 292, column: 5, scope: !571)
!642 = !DILocation(line: 293, column: 25, scope: !569)
!643 = !{!644, !300, i64 8}
!644 = !{!"extstore_conf_file", !302, i64 0, !300, i64 8, !302, i64 16, !301, i64 24, !302, i64 32, !302, i64 36, !300, i64 40}
!645 = !DILocation(line: 293, column: 17, scope: !569)
!646 = !DILocation(line: 293, column: 12, scope: !569)
!647 = !DILocation(line: 293, column: 15, scope: !569)
!648 = !{!644, !302, i64 16}
!649 = !DILocation(line: 294, column: 19, scope: !650)
!650 = distinct !DILexicalBlock(scope: !569, file: !2, line: 294, column: 13)
!651 = !DILocation(line: 294, column: 13, scope: !569)
!652 = !DILocation(line: 295, column: 18, scope: !653)
!653 = distinct !DILexicalBlock(scope: !650, file: !2, line: 294, column: 24)
!654 = !DILocation(line: 299, column: 13, scope: !653)
!655 = !DILocation(line: 300, column: 13, scope: !653)
!656 = !DILocation(line: 303, column: 9, scope: !569)
!657 = !DILocation(line: 304, column: 21, scope: !569)
!658 = !{!659, !390, i64 0}
!659 = !{!"flock", !390, i64 0, !390, i64 2, !301, i64 8, !301, i64 16, !302, i64 24}
!660 = distinct !DIAssignID()
!661 = distinct !DIAssignID()
!662 = !DILocation(line: 306, column: 23, scope: !569)
!663 = !{!659, !390, i64 2}
!664 = distinct !DIAssignID()
!665 = !DILocation(line: 307, column: 20, scope: !569)
!666 = !DILocation(line: 308, column: 13, scope: !667)
!667 = distinct !DILexicalBlock(scope: !569, file: !2, line: 308, column: 13)
!668 = !DILocation(line: 308, column: 42, scope: !667)
!669 = !DILocation(line: 308, column: 13, scope: !569)
!670 = !DILocation(line: 313, column: 26, scope: !671)
!671 = distinct !DILexicalBlock(scope: !569, file: !2, line: 313, column: 13)
!672 = !DILocation(line: 313, column: 13, scope: !671)
!673 = !DILocation(line: 313, column: 33, scope: !671)
!674 = !DILocation(line: 313, column: 13, scope: !569)
!675 = !DILocation(line: 321, column: 5, scope: !570)
!676 = !DILocation(line: 319, column: 31, scope: !569)
!677 = !{!644, !302, i64 0}
!678 = !DILocation(line: 319, column: 28, scope: !569)
!679 = !DILocation(line: 319, column: 25, scope: !569)
!680 = !DILocation(line: 320, column: 12, scope: !569)
!681 = !DILocation(line: 320, column: 19, scope: !569)
!682 = !{!644, !301, i64 24}
!683 = !DILocation(line: 292, column: 36, scope: !570)
!684 = !{!644, !300, i64 40}
!685 = distinct !{!685, !641, !686, !353}
!686 = !DILocation(line: 321, column: 5, scope: !571)
!687 = !DILocation(line: 323, column: 25, scope: !688)
!688 = distinct !DILexicalBlock(scope: !533, file: !2, line: 323, column: 9)
!689 = !DILocation(line: 323, column: 9, scope: !533)
!690 = !DILocation(line: 324, column: 14, scope: !691)
!691 = distinct !DILexicalBlock(scope: !688, file: !2, line: 323, column: 40)
!692 = !DILocation(line: 325, column: 9, scope: !691)
!693 = !DILocation(line: 326, column: 9, scope: !691)
!694 = !DILocation(line: 328, column: 21, scope: !533)
!695 = !DILocation(line: 328, column: 8, scope: !533)
!696 = !DILocation(line: 328, column: 19, scope: !533)
!697 = !DILocation(line: 330, column: 16, scope: !533)
!698 = !DILocation(line: 330, column: 8, scope: !533)
!699 = !DILocation(line: 330, column: 14, scope: !533)
!700 = !DILocation(line: 331, column: 18, scope: !701)
!701 = distinct !DILexicalBlock(scope: !533, file: !2, line: 331, column: 9)
!702 = !DILocation(line: 331, column: 9, scope: !533)
!703 = !DILocation(line: 340, column: 19, scope: !704)
!704 = distinct !DILexicalBlock(scope: !705, file: !2, line: 340, column: 5)
!705 = distinct !DILexicalBlock(scope: !533, file: !2, line: 340, column: 5)
!706 = !DILocation(line: 340, column: 5, scope: !705)
!707 = !DILocation(line: 332, column: 14, scope: !708)
!708 = distinct !DILexicalBlock(scope: !701, file: !2, line: 331, column: 27)
!709 = !DILocation(line: 334, column: 9, scope: !708)
!710 = !DILocation(line: 335, column: 9, scope: !708)
!711 = !DILocation(line: 342, column: 9, scope: !712)
!712 = distinct !DILexicalBlock(scope: !704, file: !2, line: 340, column: 41)
!713 = !DILocation(line: 344, column: 19, scope: !714)
!714 = distinct !DILexicalBlock(scope: !715, file: !2, line: 344, column: 17)
!715 = distinct !DILexicalBlock(scope: !712, file: !2, line: 342, column: 19)
!716 = !DILocation(line: 344, column: 27, scope: !714)
!717 = !DILocation(line: 344, column: 33, scope: !714)
!718 = !DILocation(line: 344, column: 38, scope: !714)
!719 = !DILocation(line: 344, column: 17, scope: !715)
!720 = !DILocation(line: 0, scope: !714)
!721 = !DILocation(line: 349, column: 20, scope: !722)
!722 = distinct !DILexicalBlock(scope: !715, file: !2, line: 349, column: 17)
!723 = !DILocation(line: 349, column: 17, scope: !722)
!724 = !DILocation(line: 349, column: 17, scope: !715)
!725 = distinct !{!725, !711, !726}
!726 = !DILocation(line: 353, column: 9, scope: !712)
!727 = !DILocation(line: 350, column: 30, scope: !728)
!728 = distinct !DILexicalBlock(scope: !722, file: !2, line: 349, column: 32)
!729 = !DILocation(line: 354, column: 29, scope: !712)
!730 = !DILocation(line: 354, column: 9, scope: !712)
!731 = !DILocation(line: 355, column: 26, scope: !712)
!732 = !DILocation(line: 355, column: 12, scope: !712)
!733 = !DILocation(line: 355, column: 21, scope: !712)
!734 = !DILocation(line: 355, column: 24, scope: !712)
!735 = !DILocation(line: 356, column: 29, scope: !712)
!736 = !DILocation(line: 356, column: 21, scope: !712)
!737 = !DILocation(line: 356, column: 24, scope: !712)
!738 = !{!389, !302, i64 88}
!739 = !DILocation(line: 357, column: 38, scope: !712)
!740 = !{!644, !302, i64 36}
!741 = !DILocation(line: 357, column: 21, scope: !712)
!742 = !DILocation(line: 357, column: 33, scope: !712)
!743 = !DILocation(line: 358, column: 33, scope: !712)
!744 = !DILocation(line: 358, column: 21, scope: !712)
!745 = !DILocation(line: 358, column: 28, scope: !712)
!746 = !{!389, !301, i64 56}
!747 = !DILocation(line: 359, column: 21, scope: !712)
!748 = !DILocation(line: 359, column: 26, scope: !712)
!749 = !DILocation(line: 360, column: 25, scope: !712)
!750 = !DILocation(line: 360, column: 19, scope: !712)
!751 = !DILocation(line: 340, column: 37, scope: !704)
!752 = !DILocation(line: 340, column: 24, scope: !704)
!753 = distinct !{!753, !706, !754, !353}
!754 = !DILocation(line: 361, column: 5, scope: !705)
!755 = !DILocation(line: 364, column: 39, scope: !533)
!756 = !DILocation(line: 364, column: 35, scope: !533)
!757 = !DILocation(line: 364, column: 28, scope: !533)
!758 = !DILocation(line: 364, column: 8, scope: !533)
!759 = !DILocation(line: 364, column: 26, scope: !533)
!760 = !DILocation(line: 365, column: 8, scope: !533)
!761 = !DILocation(line: 365, column: 30, scope: !533)
!762 = !{!297, !302, i64 128}
!763 = !DILocation(line: 367, column: 8, scope: !533)
!764 = !DILocation(line: 367, column: 18, scope: !533)
!765 = !DILocation(line: 368, scope: !585)
!766 = !DILocation(line: 368, column: 33, scope: !584)
!767 = !DILocation(line: 368, column: 5, scope: !585)
!768 = !DILocation(line: 369, column: 18, scope: !583)
!769 = !DILocation(line: 369, column: 30, scope: !583)
!770 = !DILocation(line: 0, scope: !583)
!771 = !DILocation(line: 370, column: 28, scope: !583)
!772 = !DILocation(line: 370, column: 21, scope: !583)
!773 = !DILocation(line: 370, column: 26, scope: !583)
!774 = !DILocation(line: 371, column: 34, scope: !583)
!775 = distinct !{!775, !767, !776, !353}
!776 = !DILocation(line: 372, column: 5, scope: !585)
!777 = !DILocation(line: 375, column: 8, scope: !533)
!778 = !DILocation(line: 375, column: 16, scope: !533)
!779 = !{!297, !302, i64 104}
!780 = !DILocation(line: 379, column: 16, scope: !533)
!781 = !DILocation(line: 379, column: 9, scope: !533)
!782 = !DILocation(line: 378, column: 14, scope: !533)
!783 = !DILocation(line: 378, column: 24, scope: !533)
!784 = !{!297, !300, i64 312}
!785 = !DILocation(line: 380, column: 14, scope: !533)
!786 = !DILocation(line: 380, column: 25, scope: !533)
!787 = !{!297, !301, i64 184}
!788 = !DILocation(line: 381, column: 14, scope: !533)
!789 = !DILocation(line: 381, column: 24, scope: !533)
!790 = !{!297, !301, i64 208}
!791 = !DILocation(line: 384, column: 23, scope: !533)
!792 = !DILocation(line: 384, column: 8, scope: !533)
!793 = !DILocation(line: 384, column: 21, scope: !533)
!794 = !DILocation(line: 385, column: 8, scope: !533)
!795 = !DILocation(line: 385, column: 25, scope: !533)
!796 = !{!297, !302, i64 124}
!797 = !DILocation(line: 389, column: 19, scope: !588)
!798 = !DILocation(line: 389, column: 5, scope: !589)
!799 = !{!297, !300, i64 48}
!800 = !{!297, !300, i64 56}
!801 = !DILocalVariable(name: "size", arg: 1, scope: !802, file: !2, line: 127, type: !166)
!802 = distinct !DISubprogram(name: "wbuf_new", scope: !2, file: !2, line: 127, type: !803, scopeLine: 127, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !805)
!803 = !DISubroutineType(types: !804)
!804 = !{!132, !166}
!805 = !{!801, !806}
!806 = !DILocalVariable(name: "b", scope: !802, file: !2, line: 128, type: !132)
!807 = !DILocation(line: 0, scope: !802, inlinedAt: !808)
!808 = distinct !DILocation(line: 390, column: 26, scope: !587)
!809 = !DILocation(line: 128, column: 22, scope: !802, inlinedAt: !808)
!810 = !DILocation(line: 129, column: 11, scope: !811, inlinedAt: !808)
!811 = distinct !DILexicalBlock(scope: !802, file: !2, line: 129, column: 9)
!812 = !DILocation(line: 129, column: 9, scope: !802, inlinedAt: !808)
!813 = !DILocation(line: 131, column: 14, scope: !802, inlinedAt: !808)
!814 = !DILocation(line: 131, column: 8, scope: !802, inlinedAt: !808)
!815 = !DILocation(line: 131, column: 12, scope: !802, inlinedAt: !808)
!816 = !{!817, !300, i64 8}
!817 = !{!"__store_wbuf", !300, i64 0, !300, i64 8, !300, i64 16, !302, i64 24, !302, i64 28, !302, i64 32, !391, i64 36, !391, i64 37}
!818 = !DILocation(line: 132, column: 16, scope: !819, inlinedAt: !808)
!819 = distinct !DILexicalBlock(scope: !802, file: !2, line: 132, column: 9)
!820 = !DILocation(line: 132, column: 9, scope: !802, inlinedAt: !808)
!821 = !DILocation(line: 133, column: 9, scope: !822, inlinedAt: !808)
!822 = distinct !DILexicalBlock(scope: !819, file: !2, line: 132, column: 25)
!823 = !DILocation(line: 134, column: 9, scope: !822, inlinedAt: !808)
!824 = !DILocation(line: 136, column: 8, scope: !802, inlinedAt: !808)
!825 = !DILocation(line: 136, column: 16, scope: !802, inlinedAt: !808)
!826 = !{!817, !300, i64 16}
!827 = !DILocation(line: 137, column: 8, scope: !802, inlinedAt: !808)
!828 = !DILocation(line: 137, column: 13, scope: !802, inlinedAt: !808)
!829 = !{!817, !302, i64 24}
!830 = !DILocation(line: 138, column: 8, scope: !802, inlinedAt: !808)
!831 = !DILocation(line: 138, column: 13, scope: !802, inlinedAt: !808)
!832 = !{!817, !302, i64 28}
!833 = !DILocation(line: 139, column: 5, scope: !802, inlinedAt: !808)
!834 = !DILocation(line: 0, scope: !587)
!835 = !DILocation(line: 391, column: 22, scope: !587)
!836 = !DILocation(line: 393, column: 17, scope: !587)
!837 = !{!817, !300, i64 0}
!838 = !DILocation(line: 395, column: 13, scope: !587)
!839 = !DILocation(line: 395, column: 18, scope: !587)
!840 = !{!841, !300, i64 8}
!841 = !{!"_obj_io", !300, i64 0, !300, i64 8, !300, i64 16, !300, i64 24, !302, i64 32, !302, i64 36, !302, i64 40, !302, i64 44, !390, i64 48, !302, i64 52, !300, i64 56}
!842 = !DILocation(line: 389, column: 38, scope: !588)
!843 = distinct !{!843, !798, !844, !353}
!844 = !DILocation(line: 397, column: 5, scope: !589)
!845 = !DILocation(line: 399, column: 5, scope: !533)
!846 = !DILocation(line: 400, column: 28, scope: !533)
!847 = !DILocation(line: 400, column: 5, scope: !533)
!848 = !DILocation(line: 401, column: 28, scope: !533)
!849 = !DILocation(line: 401, column: 5, scope: !533)
!850 = !DILocation(line: 403, column: 23, scope: !533)
!851 = !{!599, !302, i64 28}
!852 = !DILocation(line: 403, column: 8, scope: !533)
!853 = !DILocation(line: 403, column: 17, scope: !533)
!854 = !{!297, !302, i64 132}
!855 = !DILocation(line: 406, column: 32, scope: !533)
!856 = !{!599, !302, i64 24}
!857 = !DILocation(line: 406, column: 28, scope: !533)
!858 = !DILocation(line: 406, column: 21, scope: !533)
!859 = !DILocation(line: 406, column: 8, scope: !533)
!860 = !DILocation(line: 406, column: 19, scope: !533)
!861 = !DILocation(line: 407, column: 19, scope: !862)
!862 = distinct !DILexicalBlock(scope: !863, file: !2, line: 407, column: 5)
!863 = distinct !DILexicalBlock(scope: !533, file: !2, line: 407, column: 5)
!864 = !DILocation(line: 407, column: 5, scope: !863)
!865 = !DILocation(line: 408, column: 32, scope: !866)
!866 = distinct !DILexicalBlock(scope: !862, file: !2, line: 407, column: 46)
!867 = !DILocation(line: 408, column: 29, scope: !866)
!868 = !DILocation(line: 408, column: 9, scope: !866)
!869 = !DILocation(line: 409, column: 31, scope: !866)
!870 = !DILocation(line: 409, column: 45, scope: !866)
!871 = !DILocation(line: 409, column: 9, scope: !866)
!872 = !DILocation(line: 410, column: 12, scope: !866)
!873 = !DILocation(line: 410, column: 26, scope: !866)
!874 = !DILocation(line: 410, column: 28, scope: !866)
!875 = !{!345, !300, i64 104}
!876 = !DILocation(line: 412, column: 60, scope: !866)
!877 = !DILocation(line: 412, column: 9, scope: !866)
!878 = !DILocation(line: 413, column: 24, scope: !866)
!879 = !{!301, !301, i64 0}
!880 = !DILocalVariable(name: "thread", arg: 1, scope: !881, file: !2, line: 119, type: !565)
!881 = distinct !DISubprogram(name: "thread_setname", scope: !2, file: !2, line: 119, type: !882, scopeLine: 119, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !884)
!882 = !DISubroutineType(types: !883)
!883 = !{null, !565, !525}
!884 = !{!880, !885}
!885 = !DILocalVariable(name: "name", arg: 2, scope: !881, file: !2, line: 119, type: !525)
!886 = !DILocation(line: 0, scope: !881, inlinedAt: !887)
!887 = distinct !DILocation(line: 413, column: 9, scope: !866)
!888 = !DILocation(line: 122, column: 1, scope: !881, inlinedAt: !887)
!889 = !DILocation(line: 407, column: 42, scope: !862)
!890 = !DILocation(line: 407, column: 25, scope: !862)
!891 = distinct !{!891, !864, !892, !353}
!892 = !DILocation(line: 414, column: 5, scope: !863)
!893 = !DILocation(line: 415, column: 8, scope: !533)
!894 = !DILocation(line: 415, column: 23, scope: !533)
!895 = !DILocation(line: 418, column: 20, scope: !533)
!896 = !DILocation(line: 418, column: 8, scope: !533)
!897 = !DILocation(line: 418, column: 18, scope: !533)
!898 = !{!297, !300, i64 72}
!899 = !DILocation(line: 419, column: 19, scope: !533)
!900 = !DILocation(line: 419, column: 21, scope: !533)
!901 = !DILocation(line: 420, column: 5, scope: !533)
!902 = !DILocation(line: 421, column: 27, scope: !533)
!903 = !DILocation(line: 421, column: 38, scope: !533)
!904 = !DILocation(line: 421, column: 5, scope: !533)
!905 = !DILocation(line: 422, column: 58, scope: !533)
!906 = !DILocation(line: 422, column: 5, scope: !533)
!907 = !DILocation(line: 423, column: 20, scope: !533)
!908 = !DILocation(line: 0, scope: !881, inlinedAt: !909)
!909 = distinct !DILocation(line: 423, column: 5, scope: !533)
!910 = !DILocation(line: 122, column: 1, scope: !881, inlinedAt: !909)
!911 = !DILocation(line: 425, column: 5, scope: !533)
!912 = !DILocation(line: 426, column: 1, scope: !533)
!913 = !DISubprogram(name: "calloc", scope: !914, file: !914, line: 675, type: !915, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!914 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!915 = !DISubroutineType(types: !916)
!916 = !{!155, !166, !166}
!917 = !DISubprogram(name: "open", scope: !918, file: !918, line: 209, type: !919, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!918 = !DIFile(filename: "/usr/include/fcntl.h", directory: "", checksumkind: CSK_MD5, checksum: "aa7b606679f16283f5b29fcd37124425")
!919 = !DISubroutineType(types: !920)
!920 = !{!82, !525, !82, null}
!921 = !DISubprogram(name: "free", scope: !914, file: !914, line: 687, type: !922, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!922 = !DISubroutineType(types: !923)
!923 = !{null, !155}
!924 = !DISubprogram(name: "fcntl", scope: !918, file: !918, line: 177, type: !925, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!925 = !DISubroutineType(types: !926)
!926 = !{!82, !82, !82, null}
!927 = !DISubprogram(name: "ftruncate", scope: !928, file: !928, line: 1049, type: !929, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!928 = !DIFile(filename: "/usr/include/unistd.h", directory: "", checksumkind: CSK_MD5, checksum: "877e832a8bb8424f9180387a13787475")
!929 = !DISubroutineType(types: !930)
!930 = !{!82, !82, !578}
!931 = !DISubprogram(name: "pthread_mutex_init", scope: !355, file: !355, line: 781, type: !932, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!932 = !DISubroutineType(types: !933)
!933 = !{!82, !358, !934}
!934 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !935, size: 64)
!935 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !936)
!936 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutexattr_t", file: !74, line: 36, baseType: !937)
!937 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !74, line: 32, size: 32, elements: !938)
!938 = !{!939, !943}
!939 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !937, file: !74, line: 34, baseType: !940, size: 32)
!940 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 32, elements: !941)
!941 = !{!942}
!942 = !DISubrange(count: 4)
!943 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !937, file: !74, line: 35, baseType: !82, size: 32)
!944 = !DISubprogram(name: "pthread_cond_init", scope: !355, file: !355, line: 1112, type: !945, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!945 = !DISubroutineType(types: !946)
!946 = !{!82, !947, !949}
!947 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !948)
!948 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !186, size: 64)
!949 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !950)
!950 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !951, size: 64)
!951 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !952)
!952 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_condattr_t", file: !74, line: 45, baseType: !953)
!953 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !74, line: 41, size: 32, elements: !954)
!954 = !{!955, !956}
!955 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !953, file: !74, line: 43, baseType: !940, size: 32)
!956 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !953, file: !74, line: 44, baseType: !82, size: 32)
!957 = !DISubprogram(name: "pthread_create", scope: !355, file: !355, line: 202, type: !958, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!958 = !DISubroutineType(types: !959)
!959 = !{!82, !960, !962, !973, !976}
!960 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !961)
!961 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !565, size: 64)
!962 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !963)
!963 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !964, size: 64)
!964 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !965)
!965 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_attr_t", file: !74, line: 62, baseType: !966)
!966 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "pthread_attr_t", file: !74, line: 56, size: 448, elements: !967)
!967 = !{!968, !972}
!968 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !966, file: !74, line: 58, baseType: !969, size: 448)
!969 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 448, elements: !970)
!970 = !{!971}
!971 = !DISubrange(count: 56)
!972 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !966, file: !74, line: 59, baseType: !103, size: 64)
!973 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !974, size: 64)
!974 = !DISubroutineType(types: !975)
!975 = !{!155, !155}
!976 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !155)
!977 = distinct !DISubprogram(name: "extstore_io_thread", scope: !2, file: !2, line: 838, type: !974, scopeLine: 838, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !978)
!978 = !{!979, !980, !981, !982, !984, !987, !988, !989, !991, !992, !993}
!979 = !DILocalVariable(name: "arg", arg: 1, scope: !977, file: !2, line: 838, type: !155)
!980 = !DILocalVariable(name: "me", scope: !977, file: !2, line: 839, type: !180)
!981 = !DILocalVariable(name: "e", scope: !977, file: !2, line: 840, type: !68)
!982 = !DILocalVariable(name: "io_stack", scope: !983, file: !2, line: 842, type: !150)
!983 = distinct !DILexicalBlock(scope: !977, file: !2, line: 841, column: 15)
!984 = !DILocalVariable(name: "i", scope: !985, file: !2, line: 853, type: !82)
!985 = distinct !DILexicalBlock(scope: !986, file: !2, line: 852, column: 32)
!986 = distinct !DILexicalBlock(scope: !983, file: !2, line: 852, column: 13)
!987 = !DILocalVariable(name: "end", scope: !985, file: !2, line: 854, type: !150)
!988 = !DILocalVariable(name: "cur_io", scope: !983, file: !2, line: 871, type: !150)
!989 = !DILocalVariable(name: "next", scope: !990, file: !2, line: 875, type: !150)
!990 = distinct !DILexicalBlock(scope: !983, file: !2, line: 872, column: 24)
!991 = !DILocalVariable(name: "ret", scope: !990, file: !2, line: 876, type: !82)
!992 = !DILocalVariable(name: "do_op", scope: !990, file: !2, line: 877, type: !82)
!993 = !DILocalVariable(name: "p", scope: !990, file: !2, line: 878, type: !105)
!994 = !DILocation(line: 0, scope: !977)
!995 = !DILocation(line: 840, column: 27, scope: !977)
!996 = !DILocation(line: 841, column: 5, scope: !977)
!997 = distinct !{!997, !996, !998}
!998 = !DILocation(line: 945, column: 5, scope: !977)
!999 = !DILocation(line: 0, scope: !983)
!1000 = !DILocation(line: 843, column: 9, scope: !983)
!1001 = !DILocation(line: 844, column: 17, scope: !1002)
!1002 = distinct !DILexicalBlock(scope: !983, file: !2, line: 844, column: 13)
!1003 = !{!345, !300, i64 88}
!1004 = !DILocation(line: 844, column: 23, scope: !1002)
!1005 = !DILocation(line: 844, column: 13, scope: !983)
!1006 = !DILocation(line: 845, column: 13, scope: !1007)
!1007 = distinct !DILexicalBlock(scope: !1002, file: !2, line: 844, column: 32)
!1008 = !DILocation(line: 852, column: 17, scope: !986)
!1009 = !DILocation(line: 852, column: 23, scope: !986)
!1010 = !DILocation(line: 852, column: 13, scope: !983)
!1011 = !DILocation(line: 869, column: 9, scope: !983)
!1012 = !DILocation(line: 872, column: 9, scope: !983)
!1013 = !DILocation(line: 0, scope: !985)
!1014 = !DILocation(line: 857, column: 27, scope: !1015)
!1015 = distinct !DILexicalBlock(scope: !1016, file: !2, line: 857, column: 13)
!1016 = distinct !DILexicalBlock(scope: !985, file: !2, line: 857, column: 13)
!1017 = !DILocation(line: 857, column: 13, scope: !1016)
!1018 = !DILocation(line: 858, column: 26, scope: !1019)
!1019 = distinct !DILexicalBlock(scope: !1020, file: !2, line: 858, column: 21)
!1020 = distinct !DILexicalBlock(scope: !1015, file: !2, line: 857, column: 47)
!1021 = !DILocation(line: 858, column: 21, scope: !1019)
!1022 = !DILocation(line: 858, column: 21, scope: !1020)
!1023 = !DILocation(line: 857, column: 43, scope: !1015)
!1024 = distinct !{!1024, !1017, !1025, !353}
!1025 = !DILocation(line: 864, column: 13, scope: !1016)
!1026 = !DILocation(line: 861, column: 36, scope: !1027)
!1027 = distinct !DILexicalBlock(scope: !1019, file: !2, line: 860, column: 24)
!1028 = !{!345, !300, i64 96}
!1029 = !DILocation(line: 862, column: 21, scope: !1027)
!1030 = !DILocation(line: 865, column: 23, scope: !985)
!1031 = !DILocation(line: 866, column: 30, scope: !985)
!1032 = !DILocation(line: 866, column: 23, scope: !985)
!1033 = !DILocation(line: 867, column: 23, scope: !985)
!1034 = !DILocation(line: 875, column: 36, scope: !990)
!1035 = !DILocation(line: 0, scope: !990)
!1036 = !DILocation(line: 878, column: 33, scope: !990)
!1037 = !DILocation(line: 878, column: 47, scope: !990)
!1038 = !{!841, !390, i64 48}
!1039 = !DILocation(line: 878, column: 30, scope: !990)
!1040 = !DILocation(line: 880, column: 29, scope: !990)
!1041 = !{!841, !302, i64 52}
!1042 = !DILocation(line: 880, column: 13, scope: !990)
!1043 = !DILocation(line: 883, column: 21, scope: !1044)
!1044 = distinct !DILexicalBlock(scope: !990, file: !2, line: 880, column: 35)
!1045 = !DILocation(line: 884, column: 29, scope: !1046)
!1046 = distinct !DILexicalBlock(scope: !1044, file: !2, line: 884, column: 25)
!1047 = !DILocation(line: 884, column: 34, scope: !1046)
!1048 = !DILocation(line: 884, column: 41, scope: !1046)
!1049 = !DILocation(line: 884, column: 48, scope: !1046)
!1050 = !DILocation(line: 884, column: 54, scope: !1046)
!1051 = !DILocation(line: 884, column: 73, scope: !1046)
!1052 = !{!841, !302, i64 36}
!1053 = !DILocation(line: 884, column: 62, scope: !1046)
!1054 = !DILocation(line: 884, column: 25, scope: !1044)
!1055 = !DILocation(line: 885, column: 32, scope: !1056)
!1056 = distinct !DILexicalBlock(scope: !1057, file: !2, line: 885, column: 29)
!1057 = distinct !DILexicalBlock(scope: !1046, file: !2, line: 884, column: 87)
!1058 = !DILocation(line: 885, column: 39, scope: !1056)
!1059 = !DILocation(line: 885, column: 50, scope: !1056)
!1060 = !{!841, !302, i64 44}
!1061 = !DILocation(line: 885, column: 63, scope: !1056)
!1062 = !DILocation(line: 885, column: 57, scope: !1056)
!1063 = !DILocation(line: 885, column: 29, scope: !1057)
!1064 = !DILocalVariable(name: "p", arg: 1, scope: !1065, file: !2, line: 814, type: !105)
!1065 = distinct !DISubprogram(name: "_read_from_wbuf", scope: !2, file: !2, line: 814, type: !1066, scopeLine: 814, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1068)
!1066 = !DISubroutineType(types: !1067)
!1067 = !{!82, !105, !150}
!1068 = !{!1064, !1069, !1070, !1071, !1074, !1075}
!1069 = !DILocalVariable(name: "io", arg: 2, scope: !1065, file: !2, line: 814, type: !150)
!1070 = !DILocalVariable(name: "wbuf", scope: !1065, file: !2, line: 815, type: !132)
!1071 = !DILocalVariable(name: "x", scope: !1072, file: !2, line: 821, type: !82)
!1072 = distinct !DILexicalBlock(scope: !1073, file: !2, line: 820, column: 12)
!1073 = distinct !DILexicalBlock(scope: !1065, file: !2, line: 818, column: 9)
!1074 = !DILocalVariable(name: "off", scope: !1072, file: !2, line: 822, type: !53)
!1075 = !DILocalVariable(name: "iov", scope: !1076, file: !2, line: 825, type: !160)
!1076 = distinct !DILexicalBlock(scope: !1077, file: !2, line: 824, column: 42)
!1077 = distinct !DILexicalBlock(scope: !1078, file: !2, line: 824, column: 9)
!1078 = distinct !DILexicalBlock(scope: !1072, file: !2, line: 824, column: 9)
!1079 = !DILocation(line: 0, scope: !1065, inlinedAt: !1080)
!1080 = distinct !DILocation(line: 886, column: 35, scope: !1081)
!1081 = distinct !DILexicalBlock(scope: !1056, file: !2, line: 885, column: 72)
!1082 = !DILocation(line: 815, column: 28, scope: !1065, inlinedAt: !1080)
!1083 = !{!389, !300, i64 104}
!1084 = !DILocation(line: 818, column: 13, scope: !1073, inlinedAt: !1080)
!1085 = !{!841, !300, i64 24}
!1086 = !DILocation(line: 818, column: 17, scope: !1073, inlinedAt: !1080)
!1087 = !DILocation(line: 818, column: 9, scope: !1065, inlinedAt: !1080)
!1088 = !DILocation(line: 819, column: 20, scope: !1089, inlinedAt: !1080)
!1089 = distinct !DILexicalBlock(scope: !1073, file: !2, line: 818, column: 26)
!1090 = !{!841, !300, i64 16}
!1091 = !DILocation(line: 819, column: 31, scope: !1089, inlinedAt: !1080)
!1092 = !DILocation(line: 819, column: 57, scope: !1089, inlinedAt: !1080)
!1093 = !{!817, !302, i64 32}
!1094 = !DILocation(line: 819, column: 49, scope: !1089, inlinedAt: !1080)
!1095 = !DILocation(line: 819, column: 35, scope: !1089, inlinedAt: !1080)
!1096 = !DILocation(line: 819, column: 70, scope: !1089, inlinedAt: !1080)
!1097 = !{!841, !302, i64 40}
!1098 = !DILocation(line: 819, column: 66, scope: !1089, inlinedAt: !1080)
!1099 = !DILocation(line: 819, column: 9, scope: !1089, inlinedAt: !1080)
!1100 = !DILocation(line: 820, column: 5, scope: !1089, inlinedAt: !1080)
!1101 = !DILocation(line: 0, scope: !1072, inlinedAt: !1080)
!1102 = !DILocation(line: 824, column: 29, scope: !1077, inlinedAt: !1080)
!1103 = !{!841, !302, i64 32}
!1104 = !DILocation(line: 824, column: 23, scope: !1077, inlinedAt: !1080)
!1105 = !DILocation(line: 824, column: 9, scope: !1078, inlinedAt: !1080)
!1106 = !DILocation(line: 822, column: 47, scope: !1072, inlinedAt: !1080)
!1107 = !DILocation(line: 822, column: 39, scope: !1072, inlinedAt: !1080)
!1108 = !DILocation(line: 825, column: 38, scope: !1076, inlinedAt: !1080)
!1109 = !DILocation(line: 825, column: 34, scope: !1076, inlinedAt: !1080)
!1110 = !DILocation(line: 0, scope: !1076, inlinedAt: !1080)
!1111 = !DILocation(line: 826, column: 25, scope: !1076, inlinedAt: !1080)
!1112 = !{!1113, !300, i64 0}
!1113 = !{!"iovec", !300, i64 0, !301, i64 8}
!1114 = !DILocation(line: 826, column: 41, scope: !1076, inlinedAt: !1080)
!1115 = !DILocation(line: 826, column: 45, scope: !1076, inlinedAt: !1080)
!1116 = !DILocation(line: 826, column: 57, scope: !1076, inlinedAt: !1080)
!1117 = !{!1113, !301, i64 8}
!1118 = !DILocation(line: 826, column: 13, scope: !1076, inlinedAt: !1080)
!1119 = !DILocation(line: 827, column: 25, scope: !1076, inlinedAt: !1080)
!1120 = !DILocation(line: 827, column: 17, scope: !1076, inlinedAt: !1080)
!1121 = !DILocation(line: 824, column: 38, scope: !1077, inlinedAt: !1080)
!1122 = distinct !{!1122, !1105, !1123, !353}
!1123 = !DILocation(line: 828, column: 9, scope: !1078, inlinedAt: !1080)
!1124 = !DILocation(line: 830, column: 16, scope: !1065, inlinedAt: !1080)
!1125 = !DILocation(line: 888, column: 25, scope: !1081)
!1126 = !DILocation(line: 889, column: 32, scope: !1127)
!1127 = distinct !DILexicalBlock(scope: !1056, file: !2, line: 888, column: 32)
!1128 = !DILocation(line: 889, column: 40, scope: !1127)
!1129 = !DILocation(line: 899, column: 21, scope: !1044)
!1130 = !DILocation(line: 900, column: 25, scope: !1044)
!1131 = !DILocation(line: 891, column: 25, scope: !1057)
!1132 = !DILocation(line: 892, column: 56, scope: !1057)
!1133 = !DILocation(line: 892, column: 48, scope: !1057)
!1134 = !DILocation(line: 892, column: 45, scope: !1057)
!1135 = !{!297, !301, i64 280}
!1136 = !DILocation(line: 893, column: 46, scope: !1057)
!1137 = !{!297, !301, i64 240}
!1138 = !DILocation(line: 894, column: 25, scope: !1057)
!1139 = !DILocation(line: 913, column: 37, scope: !1140)
!1140 = distinct !DILexicalBlock(scope: !1141, file: !2, line: 913, column: 29)
!1141 = distinct !DILexicalBlock(scope: !1142, file: !2, line: 900, column: 32)
!1142 = distinct !DILexicalBlock(scope: !1044, file: !2, line: 900, column: 25)
!1143 = !DILocation(line: 913, column: 41, scope: !1140)
!1144 = !DILocation(line: 0, scope: !1140)
!1145 = !DILocation(line: 913, column: 29, scope: !1141)
!1146 = !DILocation(line: 914, column: 56, scope: !1147)
!1147 = distinct !DILexicalBlock(scope: !1140, file: !2, line: 913, column: 50)
!1148 = !DILocation(line: 914, column: 69, scope: !1147)
!1149 = !DILocation(line: 914, column: 61, scope: !1147)
!1150 = !DILocation(line: 914, column: 77, scope: !1147)
!1151 = !DILocation(line: 914, column: 94, scope: !1147)
!1152 = !DILocation(line: 914, column: 86, scope: !1147)
!1153 = !DILocation(line: 914, column: 84, scope: !1147)
!1154 = !DILocation(line: 914, column: 35, scope: !1147)
!1155 = !DILocation(line: 915, column: 25, scope: !1147)
!1156 = !DILocation(line: 916, column: 70, scope: !1157)
!1157 = distinct !DILexicalBlock(scope: !1140, file: !2, line: 915, column: 32)
!1158 = !DILocation(line: 916, column: 81, scope: !1157)
!1159 = !DILocation(line: 916, column: 98, scope: !1157)
!1160 = !DILocation(line: 916, column: 90, scope: !1157)
!1161 = !DILocation(line: 916, column: 88, scope: !1157)
!1162 = !DILocation(line: 916, column: 35, scope: !1157)
!1163 = !DILocation(line: 925, column: 37, scope: !1044)
!1164 = !DILocation(line: 925, column: 49, scope: !1044)
!1165 = !DILocation(line: 925, column: 62, scope: !1044)
!1166 = !DILocation(line: 925, column: 54, scope: !1044)
!1167 = !DILocation(line: 925, column: 70, scope: !1044)
!1168 = !DILocation(line: 925, column: 87, scope: !1044)
!1169 = !DILocation(line: 925, column: 79, scope: !1044)
!1170 = !DILocation(line: 925, column: 77, scope: !1044)
!1171 = !DILocation(line: 925, column: 27, scope: !1044)
!1172 = !DILocation(line: 926, column: 21, scope: !1044)
!1173 = !DILocation(line: 937, column: 21, scope: !990)
!1174 = !{!841, !300, i64 56}
!1175 = !DILocation(line: 937, column: 13, scope: !990)
!1176 = !DILocation(line: 938, column: 17, scope: !990)
!1177 = !DILocation(line: 939, column: 17, scope: !1178)
!1178 = distinct !DILexicalBlock(scope: !1179, file: !2, line: 938, column: 24)
!1179 = distinct !DILexicalBlock(scope: !990, file: !2, line: 938, column: 17)
!1180 = !DILocation(line: 940, column: 20, scope: !1178)
!1181 = !DILocation(line: 940, column: 28, scope: !1178)
!1182 = !DILocation(line: 941, column: 17, scope: !1178)
!1183 = !DILocation(line: 942, column: 13, scope: !1178)
!1184 = distinct !{!1184, !1012, !1185, !353}
!1185 = !DILocation(line: 944, column: 9, scope: !983)
!1186 = distinct !DISubprogram(name: "extstore_write_request", scope: !2, file: !2, line: 590, type: !1187, scopeLine: 591, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1189)
!1187 = !DISubroutineType(types: !1188)
!1188 = !{!82, !155, !53, !53, !150}
!1189 = !{!1190, !1191, !1192, !1193, !1194, !1195, !1196, !1197}
!1190 = !DILocalVariable(name: "ptr", arg: 1, scope: !1186, file: !2, line: 590, type: !155)
!1191 = !DILocalVariable(name: "bucket", arg: 2, scope: !1186, file: !2, line: 590, type: !53)
!1192 = !DILocalVariable(name: "free_bucket", arg: 3, scope: !1186, file: !2, line: 591, type: !53)
!1193 = !DILocalVariable(name: "io", arg: 4, scope: !1186, file: !2, line: 591, type: !150)
!1194 = !DILocalVariable(name: "e", scope: !1186, file: !2, line: 592, type: !68)
!1195 = !DILocalVariable(name: "p", scope: !1186, file: !2, line: 593, type: !105)
!1196 = !DILocalVariable(name: "ret", scope: !1186, file: !2, line: 594, type: !82)
!1197 = !DILocalVariable(name: "temp_p", scope: !1198, file: !2, line: 617, type: !105)
!1198 = distinct !DILexicalBlock(scope: !1199, file: !2, line: 614, column: 76)
!1199 = distinct !DILexicalBlock(scope: !1186, file: !2, line: 613, column: 9)
!1200 = distinct !DIAssignID()
!1201 = distinct !DIAssignID()
!1202 = !DILocation(line: 0, scope: !1186)
!1203 = !DILocation(line: 595, column: 22, scope: !1204)
!1204 = distinct !DILexicalBlock(scope: !1186, file: !2, line: 595, column: 9)
!1205 = !DILocation(line: 595, column: 16, scope: !1204)
!1206 = !DILocation(line: 595, column: 9, scope: !1186)
!1207 = !DILocation(line: 598, column: 5, scope: !1186)
!1208 = !DILocation(line: 599, column: 12, scope: !1186)
!1209 = !DILocation(line: 599, column: 9, scope: !1186)
!1210 = !DILocation(line: 600, column: 10, scope: !1211)
!1211 = distinct !DILexicalBlock(scope: !1186, file: !2, line: 600, column: 9)
!1212 = !DILocation(line: 600, column: 9, scope: !1186)
!1213 = !DILocalVariable(name: "e", arg: 1, scope: !1214, file: !2, line: 466, type: !68)
!1214 = distinct !DISubprogram(name: "_allocate_page", scope: !2, file: !2, line: 466, type: !1215, scopeLine: 467, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1217)
!1215 = !DISubroutineType(types: !1216)
!1216 = !{!105, !68, !53, !53}
!1217 = !{!1213, !1218, !1219, !1220}
!1218 = !DILocalVariable(name: "bucket", arg: 2, scope: !1214, file: !2, line: 466, type: !53)
!1219 = !DILocalVariable(name: "free_bucket", arg: 3, scope: !1214, file: !2, line: 467, type: !53)
!1220 = !DILocalVariable(name: "tmp", scope: !1214, file: !2, line: 470, type: !105)
!1221 = !DILocation(line: 0, scope: !1214, inlinedAt: !1222)
!1222 = distinct !DILocation(line: 601, column: 13, scope: !1223)
!1223 = distinct !DILexicalBlock(scope: !1211, file: !2, line: 600, column: 13)
!1224 = !DILocation(line: 471, column: 12, scope: !1225, inlinedAt: !1222)
!1225 = distinct !DILexicalBlock(scope: !1214, file: !2, line: 471, column: 9)
!1226 = !DILocation(line: 471, column: 9, scope: !1225, inlinedAt: !1222)
!1227 = !DILocation(line: 471, column: 43, scope: !1225, inlinedAt: !1222)
!1228 = !DILocation(line: 471, column: 9, scope: !1214, inlinedAt: !1222)
!1229 = !DILocation(line: 475, column: 16, scope: !1230, inlinedAt: !1222)
!1230 = distinct !DILexicalBlock(scope: !1225, file: !2, line: 475, column: 16)
!1231 = !DILocation(line: 475, column: 40, scope: !1230, inlinedAt: !1222)
!1232 = !DILocation(line: 475, column: 16, scope: !1225, inlinedAt: !1222)
!1233 = !DILocation(line: 0, scope: !1225, inlinedAt: !1222)
!1234 = !DILocation(line: 482, column: 24, scope: !1235, inlinedAt: !1222)
!1235 = distinct !DILexicalBlock(scope: !1236, file: !2, line: 481, column: 22)
!1236 = distinct !DILexicalBlock(scope: !1214, file: !2, line: 481, column: 9)
!1237 = !DILocation(line: 482, column: 21, scope: !1235, inlinedAt: !1222)
!1238 = !DILocation(line: 482, column: 19, scope: !1235, inlinedAt: !1222)
!1239 = !DILocation(line: 483, column: 33, scope: !1235, inlinedAt: !1222)
!1240 = !DILocation(line: 484, column: 14, scope: !1235, inlinedAt: !1222)
!1241 = !DILocation(line: 484, column: 21, scope: !1235, inlinedAt: !1222)
!1242 = !DILocation(line: 485, column: 14, scope: !1235, inlinedAt: !1222)
!1243 = !DILocation(line: 485, column: 19, scope: !1235, inlinedAt: !1222)
!1244 = !DILocation(line: 486, column: 14, scope: !1235, inlinedAt: !1222)
!1245 = !DILocation(line: 486, column: 21, scope: !1235, inlinedAt: !1222)
!1246 = !DILocalVariable(name: "e", arg: 1, scope: !1247, file: !2, line: 163, type: !68)
!1247 = distinct !DISubprogram(name: "_next_version", scope: !2, file: !2, line: 163, type: !1248, scopeLine: 163, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1250)
!1248 = !DISubroutineType(types: !1249)
!1249 = !{!111, !68}
!1250 = !{!1246}
!1251 = !DILocation(line: 0, scope: !1247, inlinedAt: !1252)
!1252 = distinct !DILocation(line: 487, column: 24, scope: !1235, inlinedAt: !1222)
!1253 = !DILocation(line: 164, column: 15, scope: !1247, inlinedAt: !1252)
!1254 = !DILocation(line: 164, column: 22, scope: !1247, inlinedAt: !1252)
!1255 = !DILocation(line: 487, column: 14, scope: !1235, inlinedAt: !1222)
!1256 = !DILocation(line: 487, column: 22, scope: !1235, inlinedAt: !1222)
!1257 = !DILocation(line: 488, column: 14, scope: !1235, inlinedAt: !1222)
!1258 = !DILocation(line: 488, column: 21, scope: !1235, inlinedAt: !1222)
!1259 = !DILocation(line: 489, column: 12, scope: !1235, inlinedAt: !1222)
!1260 = !DILocation(line: 489, column: 21, scope: !1235, inlinedAt: !1222)
!1261 = !DILocation(line: 490, column: 9, scope: !1262, inlinedAt: !1222)
!1262 = distinct !DILexicalBlock(scope: !1235, file: !2, line: 490, column: 9)
!1263 = !{!297, !301, i64 176}
!1264 = !DILocation(line: 491, column: 5, scope: !1235, inlinedAt: !1222)
!1265 = !DILocation(line: 603, column: 5, scope: !1186)
!1266 = !DILocalVariable(name: "st", scope: !1267, file: !2, line: 431, type: !238)
!1267 = distinct !DISubprogram(name: "_evict_page", scope: !2, file: !2, line: 429, type: !1268, scopeLine: 430, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1270)
!1268 = !DISubroutineType(types: !1269)
!1269 = !{null, !68, !53, !53}
!1270 = !{!1271, !1272, !1273, !1266, !1274, !1275, !1276}
!1271 = !DILocalVariable(name: "e", arg: 1, scope: !1267, file: !2, line: 429, type: !68)
!1272 = !DILocalVariable(name: "bucket", arg: 2, scope: !1267, file: !2, line: 429, type: !53)
!1273 = !DILocalVariable(name: "free_bucket", arg: 3, scope: !1267, file: !2, line: 430, type: !53)
!1274 = !DILocalVariable(name: "low_version", scope: !1267, file: !2, line: 434, type: !111)
!1275 = !DILocalVariable(name: "low_page", scope: !1267, file: !2, line: 435, type: !53)
!1276 = !DILocalVariable(name: "i", scope: !1277, file: !2, line: 439, type: !82)
!1277 = distinct !DILexicalBlock(scope: !1267, file: !2, line: 439, column: 5)
!1278 = !DILocation(line: 0, scope: !1267, inlinedAt: !1279)
!1279 = distinct !DILocation(line: 605, column: 9, scope: !1280)
!1280 = distinct !DILexicalBlock(scope: !1281, file: !2, line: 604, column: 13)
!1281 = distinct !DILexicalBlock(scope: !1186, file: !2, line: 604, column: 9)
!1282 = !DILocation(line: 431, column: 5, scope: !1267, inlinedAt: !1279)
!1283 = !DILocation(line: 432, column: 30, scope: !1267, inlinedAt: !1279)
!1284 = !DILocation(line: 432, column: 27, scope: !1267, inlinedAt: !1279)
!1285 = !DILocation(line: 432, column: 20, scope: !1267, inlinedAt: !1279)
!1286 = !DILocation(line: 432, column: 8, scope: !1267, inlinedAt: !1279)
!1287 = !DILocation(line: 432, column: 18, scope: !1267, inlinedAt: !1279)
!1288 = distinct !DIAssignID()
!1289 = !DILocation(line: 433, column: 5, scope: !1267, inlinedAt: !1279)
!1290 = !DILocation(line: 0, scope: !1277, inlinedAt: !1279)
!1291 = !DILocation(line: 439, column: 23, scope: !1292, inlinedAt: !1279)
!1292 = distinct !DILexicalBlock(scope: !1277, file: !2, line: 439, column: 5)
!1293 = !DILocation(line: 439, column: 5, scope: !1277, inlinedAt: !1279)
!1294 = !DILocation(line: 441, column: 29, scope: !1295, inlinedAt: !1279)
!1295 = distinct !DILexicalBlock(scope: !1296, file: !2, line: 441, column: 13)
!1296 = distinct !DILexicalBlock(scope: !1292, file: !2, line: 439, column: 45)
!1297 = !DILocation(line: 441, column: 13, scope: !1295, inlinedAt: !1279)
!1298 = !DILocation(line: 441, column: 41, scope: !1295, inlinedAt: !1279)
!1299 = !DILocation(line: 447, column: 13, scope: !1300, inlinedAt: !1279)
!1300 = distinct !DILexicalBlock(scope: !1296, file: !2, line: 447, column: 13)
!1301 = !DILocation(line: 447, column: 29, scope: !1300, inlinedAt: !1279)
!1302 = !DILocation(line: 447, column: 37, scope: !1300, inlinedAt: !1279)
!1303 = !DILocation(line: 447, column: 13, scope: !1296, inlinedAt: !1279)
!1304 = !DILocation(line: 453, column: 30, scope: !1305, inlinedAt: !1279)
!1305 = distinct !DILexicalBlock(scope: !1296, file: !2, line: 453, column: 13)
!1306 = !DILocation(line: 453, column: 37, scope: !1305, inlinedAt: !1279)
!1307 = !DILocation(line: 439, column: 41, scope: !1292, inlinedAt: !1279)
!1308 = distinct !{!1308, !1293, !1309, !353}
!1309 = !DILocation(line: 458, column: 5, scope: !1277, inlinedAt: !1279)
!1310 = !DILocation(line: 460, column: 21, scope: !1311, inlinedAt: !1279)
!1311 = distinct !DILexicalBlock(scope: !1267, file: !2, line: 460, column: 9)
!1312 = !DILocation(line: 460, column: 9, scope: !1267, inlinedAt: !1279)
!1313 = !DILocation(line: 461, column: 9, scope: !1314, inlinedAt: !1279)
!1314 = distinct !DILexicalBlock(scope: !1311, file: !2, line: 460, column: 36)
!1315 = !DILocation(line: 462, column: 5, scope: !1314, inlinedAt: !1279)
!1316 = !DILocation(line: 463, column: 1, scope: !1267, inlinedAt: !1279)
!1317 = !DILocation(line: 606, column: 9, scope: !1280)
!1318 = !DILocation(line: 609, column: 5, scope: !1186)
!1319 = !DILocation(line: 613, column: 13, scope: !1199)
!1320 = !DILocation(line: 613, column: 20, scope: !1199)
!1321 = !DILocation(line: 614, column: 19, scope: !1199)
!1322 = !DILocation(line: 614, column: 16, scope: !1199)
!1323 = !DILocation(line: 614, column: 24, scope: !1199)
!1324 = !DILocation(line: 614, column: 36, scope: !1199)
!1325 = !{!817, !391, i64 36}
!1326 = !DILocation(line: 614, column: 42, scope: !1199)
!1327 = !DILocation(line: 614, column: 48, scope: !1199)
!1328 = !DILocation(line: 614, column: 45, scope: !1199)
!1329 = !DILocation(line: 614, column: 64, scope: !1199)
!1330 = !DILocation(line: 614, column: 58, scope: !1199)
!1331 = !DILocation(line: 613, column: 9, scope: !1186)
!1332 = !DILocation(line: 615, column: 9, scope: !1198)
!1333 = !DILocation(line: 616, column: 9, scope: !1198)
!1334 = !DILocation(line: 0, scope: !1214, inlinedAt: !1335)
!1335 = distinct !DILocation(line: 617, column: 30, scope: !1198)
!1336 = !DILocation(line: 471, column: 12, scope: !1225, inlinedAt: !1335)
!1337 = !DILocation(line: 471, column: 9, scope: !1225, inlinedAt: !1335)
!1338 = !DILocation(line: 471, column: 43, scope: !1225, inlinedAt: !1335)
!1339 = !DILocation(line: 471, column: 9, scope: !1214, inlinedAt: !1335)
!1340 = !DILocation(line: 475, column: 16, scope: !1230, inlinedAt: !1335)
!1341 = !DILocation(line: 475, column: 40, scope: !1230, inlinedAt: !1335)
!1342 = !DILocation(line: 475, column: 16, scope: !1225, inlinedAt: !1335)
!1343 = !DILocation(line: 0, scope: !1225, inlinedAt: !1335)
!1344 = !DILocation(line: 482, column: 24, scope: !1235, inlinedAt: !1335)
!1345 = !DILocation(line: 482, column: 21, scope: !1235, inlinedAt: !1335)
!1346 = !DILocation(line: 482, column: 19, scope: !1235, inlinedAt: !1335)
!1347 = !DILocation(line: 483, column: 33, scope: !1235, inlinedAt: !1335)
!1348 = !DILocation(line: 484, column: 14, scope: !1235, inlinedAt: !1335)
!1349 = !DILocation(line: 484, column: 21, scope: !1235, inlinedAt: !1335)
!1350 = !DILocation(line: 485, column: 14, scope: !1235, inlinedAt: !1335)
!1351 = !DILocation(line: 485, column: 19, scope: !1235, inlinedAt: !1335)
!1352 = !DILocation(line: 486, column: 14, scope: !1235, inlinedAt: !1335)
!1353 = !DILocation(line: 486, column: 21, scope: !1235, inlinedAt: !1335)
!1354 = !DILocation(line: 0, scope: !1247, inlinedAt: !1355)
!1355 = distinct !DILocation(line: 487, column: 24, scope: !1235, inlinedAt: !1335)
!1356 = !DILocation(line: 164, column: 15, scope: !1247, inlinedAt: !1355)
!1357 = !DILocation(line: 164, column: 22, scope: !1247, inlinedAt: !1355)
!1358 = !DILocation(line: 487, column: 14, scope: !1235, inlinedAt: !1335)
!1359 = !DILocation(line: 487, column: 22, scope: !1235, inlinedAt: !1335)
!1360 = !DILocation(line: 488, column: 14, scope: !1235, inlinedAt: !1335)
!1361 = !DILocation(line: 488, column: 21, scope: !1235, inlinedAt: !1335)
!1362 = !DILocation(line: 489, column: 12, scope: !1235, inlinedAt: !1335)
!1363 = !DILocation(line: 489, column: 21, scope: !1235, inlinedAt: !1335)
!1364 = !DILocation(line: 490, column: 9, scope: !1262, inlinedAt: !1335)
!1365 = !DILocation(line: 0, scope: !1198)
!1366 = !DILocation(line: 618, column: 9, scope: !1198)
!1367 = !DILocation(line: 619, column: 13, scope: !1198)
!1368 = !DILocation(line: 0, scope: !1267, inlinedAt: !1369)
!1369 = distinct !DILocation(line: 620, column: 13, scope: !1370)
!1370 = distinct !DILexicalBlock(scope: !1371, file: !2, line: 619, column: 22)
!1371 = distinct !DILexicalBlock(scope: !1198, file: !2, line: 619, column: 13)
!1372 = !DILocation(line: 431, column: 5, scope: !1267, inlinedAt: !1369)
!1373 = !DILocation(line: 432, column: 30, scope: !1267, inlinedAt: !1369)
!1374 = !DILocation(line: 432, column: 27, scope: !1267, inlinedAt: !1369)
!1375 = !DILocation(line: 432, column: 20, scope: !1267, inlinedAt: !1369)
!1376 = !DILocation(line: 432, column: 8, scope: !1267, inlinedAt: !1369)
!1377 = !DILocation(line: 432, column: 18, scope: !1267, inlinedAt: !1369)
!1378 = distinct !DIAssignID()
!1379 = !DILocation(line: 433, column: 5, scope: !1267, inlinedAt: !1369)
!1380 = !DILocation(line: 0, scope: !1277, inlinedAt: !1369)
!1381 = !DILocation(line: 439, column: 23, scope: !1292, inlinedAt: !1369)
!1382 = !DILocation(line: 439, column: 5, scope: !1277, inlinedAt: !1369)
!1383 = !DILocation(line: 441, column: 29, scope: !1295, inlinedAt: !1369)
!1384 = !DILocation(line: 441, column: 13, scope: !1295, inlinedAt: !1369)
!1385 = !DILocation(line: 441, column: 41, scope: !1295, inlinedAt: !1369)
!1386 = !DILocation(line: 447, column: 13, scope: !1300, inlinedAt: !1369)
!1387 = !DILocation(line: 447, column: 29, scope: !1300, inlinedAt: !1369)
!1388 = !DILocation(line: 447, column: 37, scope: !1300, inlinedAt: !1369)
!1389 = !DILocation(line: 447, column: 13, scope: !1296, inlinedAt: !1369)
!1390 = !DILocation(line: 453, column: 30, scope: !1305, inlinedAt: !1369)
!1391 = !DILocation(line: 453, column: 37, scope: !1305, inlinedAt: !1369)
!1392 = !DILocation(line: 439, column: 41, scope: !1292, inlinedAt: !1369)
!1393 = distinct !{!1393, !1382, !1394, !353}
!1394 = !DILocation(line: 458, column: 5, scope: !1277, inlinedAt: !1369)
!1395 = !DILocation(line: 460, column: 21, scope: !1311, inlinedAt: !1369)
!1396 = !DILocation(line: 460, column: 9, scope: !1267, inlinedAt: !1369)
!1397 = !DILocation(line: 461, column: 9, scope: !1314, inlinedAt: !1369)
!1398 = !DILocation(line: 462, column: 5, scope: !1314, inlinedAt: !1369)
!1399 = !DILocation(line: 463, column: 1, scope: !1267, inlinedAt: !1369)
!1400 = !DILocation(line: 621, column: 9, scope: !1370)
!1401 = !DILocation(line: 626, column: 29, scope: !1402)
!1402 = distinct !DILexicalBlock(scope: !1186, file: !2, line: 626, column: 9)
!1403 = !DILocation(line: 626, column: 40, scope: !1402)
!1404 = !DILocation(line: 626, column: 34, scope: !1402)
!1405 = !DILocation(line: 626, column: 44, scope: !1402)
!1406 = !DILocation(line: 627, column: 9, scope: !1407)
!1407 = distinct !DILexicalBlock(scope: !1402, file: !2, line: 626, column: 63)
!1408 = !DILocation(line: 628, column: 12, scope: !1407)
!1409 = !DILocation(line: 628, column: 18, scope: !1407)
!1410 = !DILocation(line: 628, column: 23, scope: !1407)
!1411 = !DILocation(line: 637, column: 17, scope: !1412)
!1412 = distinct !DILexicalBlock(scope: !1186, file: !2, line: 637, column: 9)
!1413 = !DILocation(line: 631, column: 24, scope: !1414)
!1414 = distinct !DILexicalBlock(scope: !1186, file: !2, line: 631, column: 9)
!1415 = !DILocation(line: 631, column: 21, scope: !1414)
!1416 = !DILocation(line: 631, column: 39, scope: !1414)
!1417 = !DILocation(line: 631, column: 34, scope: !1414)
!1418 = !DILocation(line: 631, column: 9, scope: !1186)
!1419 = !DILocation(line: 632, column: 9, scope: !1420)
!1420 = distinct !DILexicalBlock(scope: !1414, file: !2, line: 631, column: 50)
!1421 = !DILocation(line: 637, column: 12, scope: !1412)
!1422 = !DILocation(line: 637, column: 9, scope: !1412)
!1423 = !DILocation(line: 637, column: 30, scope: !1412)
!1424 = !DILocation(line: 637, column: 35, scope: !1412)
!1425 = !DILocation(line: 637, column: 47, scope: !1412)
!1426 = !DILocation(line: 637, column: 59, scope: !1412)
!1427 = !DILocation(line: 637, column: 52, scope: !1412)
!1428 = !DILocation(line: 637, column: 9, scope: !1186)
!1429 = !DILocation(line: 638, column: 28, scope: !1430)
!1430 = distinct !DILexicalBlock(scope: !1412, file: !2, line: 637, column: 64)
!1431 = !DILocation(line: 638, column: 13, scope: !1430)
!1432 = !DILocation(line: 638, column: 17, scope: !1430)
!1433 = !DILocation(line: 639, column: 26, scope: !1430)
!1434 = !DILocation(line: 639, column: 13, scope: !1430)
!1435 = !DILocation(line: 639, column: 21, scope: !1430)
!1436 = !DILocation(line: 640, column: 9, scope: !1430)
!1437 = !DILocation(line: 643, column: 5, scope: !1186)
!1438 = !DILocation(line: 645, column: 5, scope: !1186)
!1439 = !DILocation(line: 646, column: 1, scope: !1186)
!1440 = distinct !DISubprogram(name: "_submit_wbuf", scope: !2, file: !2, line: 558, type: !451, scopeLine: 558, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1441)
!1441 = !{!1442, !1443, !1444, !1445}
!1442 = !DILocalVariable(name: "e", arg: 1, scope: !1440, file: !2, line: 558, type: !68)
!1443 = !DILocalVariable(name: "p", arg: 2, scope: !1440, file: !2, line: 558, type: !105)
!1444 = !DILocalVariable(name: "w", scope: !1440, file: !2, line: 559, type: !132)
!1445 = !DILocalVariable(name: "io", scope: !1440, file: !2, line: 561, type: !150)
!1446 = !DILocation(line: 0, scope: !1440)
!1447 = !DILocation(line: 560, column: 5, scope: !1440)
!1448 = !DILocation(line: 561, column: 21, scope: !1440)
!1449 = !DILocation(line: 562, column: 23, scope: !1440)
!1450 = !DILocation(line: 562, column: 17, scope: !1440)
!1451 = !DILocation(line: 563, column: 5, scope: !1440)
!1452 = !DILocation(line: 564, column: 12, scope: !1440)
!1453 = !DILocation(line: 567, column: 15, scope: !1440)
!1454 = !DILocation(line: 567, column: 25, scope: !1440)
!1455 = !DILocation(line: 567, column: 35, scope: !1440)
!1456 = !DILocation(line: 567, column: 30, scope: !1440)
!1457 = !DILocation(line: 567, column: 19, scope: !1440)
!1458 = !DILocation(line: 567, column: 45, scope: !1440)
!1459 = !DILocation(line: 567, column: 5, scope: !1440)
!1460 = !DILocation(line: 569, column: 14, scope: !1440)
!1461 = !DILocation(line: 570, column: 9, scope: !1440)
!1462 = !DILocation(line: 570, column: 14, scope: !1440)
!1463 = !DILocation(line: 571, column: 22, scope: !1440)
!1464 = !DILocation(line: 571, column: 9, scope: !1440)
!1465 = !DILocation(line: 571, column: 17, scope: !1440)
!1466 = !DILocation(line: 572, column: 14, scope: !1440)
!1467 = !{!841, !300, i64 0}
!1468 = !DILocation(line: 574, column: 9, scope: !1440)
!1469 = !DILocation(line: 574, column: 18, scope: !1440)
!1470 = !DILocation(line: 574, column: 13, scope: !1440)
!1471 = !DILocation(line: 575, column: 18, scope: !1440)
!1472 = !DILocation(line: 575, column: 9, scope: !1440)
!1473 = !DILocation(line: 575, column: 13, scope: !1440)
!1474 = !DILocation(line: 576, column: 9, scope: !1440)
!1475 = !DILocation(line: 576, column: 12, scope: !1440)
!1476 = !DILocalVariable(name: "ptr", arg: 1, scope: !1477, file: !2, line: 714, type: !155)
!1477 = distinct !DISubprogram(name: "extstore_submit_bg", scope: !2, file: !2, line: 714, type: !1478, scopeLine: 714, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1480)
!1478 = !DISubroutineType(types: !1479)
!1479 = !{!82, !155, !150}
!1480 = !{!1476, !1481, !1482, !1483}
!1481 = !DILocalVariable(name: "io", arg: 2, scope: !1477, file: !2, line: 714, type: !150)
!1482 = !DILocalVariable(name: "e", scope: !1477, file: !2, line: 715, type: !68)
!1483 = !DILocalVariable(name: "t", scope: !1477, file: !2, line: 716, type: !180)
!1484 = !DILocation(line: 0, scope: !1477, inlinedAt: !1485)
!1485 = distinct !DILocation(line: 578, column: 5, scope: !1440)
!1486 = !DILocation(line: 716, column: 29, scope: !1477, inlinedAt: !1485)
!1487 = !DILocalVariable(name: "ptr", arg: 1, scope: !1488, file: !2, line: 676, type: !155)
!1488 = distinct !DISubprogram(name: "_extstore_submit", scope: !2, file: !2, line: 676, type: !1489, scopeLine: 676, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1491)
!1489 = !DISubroutineType(types: !1490)
!1490 = !{!82, !155, !150, !180}
!1491 = !{!1487, !1492, !1493, !1494, !1495, !1496}
!1492 = !DILocalVariable(name: "io", arg: 2, scope: !1488, file: !2, line: 676, type: !150)
!1493 = !DILocalVariable(name: "t", arg: 3, scope: !1488, file: !2, line: 676, type: !180)
!1494 = !DILocalVariable(name: "depth", scope: !1488, file: !2, line: 677, type: !53)
!1495 = !DILocalVariable(name: "tio", scope: !1488, file: !2, line: 678, type: !150)
!1496 = !DILocalVariable(name: "tail", scope: !1488, file: !2, line: 679, type: !150)
!1497 = !DILocation(line: 0, scope: !1488, inlinedAt: !1498)
!1498 = distinct !DILocation(line: 717, column: 12, scope: !1477, inlinedAt: !1485)
!1499 = !DILocation(line: 680, column: 5, scope: !1488, inlinedAt: !1498)
!1500 = !DILocation(line: 682, column: 14, scope: !1501, inlinedAt: !1498)
!1501 = distinct !DILexicalBlock(scope: !1488, file: !2, line: 680, column: 25)
!1502 = !DILocation(line: 683, column: 20, scope: !1501, inlinedAt: !1498)
!1503 = !DILocation(line: 680, column: 16, scope: !1488, inlinedAt: !1498)
!1504 = distinct !{!1504, !1499, !1505, !353}
!1505 = !DILocation(line: 684, column: 5, scope: !1488, inlinedAt: !1498)
!1506 = !DILocation(line: 686, column: 5, scope: !1488, inlinedAt: !1498)
!1507 = !DILocation(line: 688, column: 8, scope: !1488, inlinedAt: !1498)
!1508 = !DILocation(line: 688, column: 14, scope: !1488, inlinedAt: !1498)
!1509 = !DILocation(line: 689, column: 12, scope: !1510, inlinedAt: !1498)
!1510 = distinct !DILexicalBlock(scope: !1488, file: !2, line: 689, column: 9)
!1511 = !DILocation(line: 689, column: 18, scope: !1510, inlinedAt: !1498)
!1512 = !DILocation(line: 689, column: 9, scope: !1488, inlinedAt: !1498)
!1513 = !DILocation(line: 690, column: 18, scope: !1514, inlinedAt: !1498)
!1514 = distinct !DILexicalBlock(scope: !1510, file: !2, line: 689, column: 27)
!1515 = !DILocation(line: 691, column: 12, scope: !1514, inlinedAt: !1498)
!1516 = !DILocation(line: 692, column: 5, scope: !1514, inlinedAt: !1498)
!1517 = !DILocation(line: 696, column: 12, scope: !1518, inlinedAt: !1498)
!1518 = distinct !DILexicalBlock(scope: !1510, file: !2, line: 692, column: 12)
!1519 = !DILocation(line: 696, column: 24, scope: !1518, inlinedAt: !1498)
!1520 = !DILocation(line: 696, column: 29, scope: !1518, inlinedAt: !1498)
!1521 = !DILocation(line: 0, scope: !1510, inlinedAt: !1498)
!1522 = !DILocation(line: 700, column: 5, scope: !1488, inlinedAt: !1498)
!1523 = !DILocation(line: 703, column: 29, scope: !1488, inlinedAt: !1498)
!1524 = !DILocation(line: 703, column: 5, scope: !1488, inlinedAt: !1498)
!1525 = !DILocation(line: 579, column: 1, scope: !1440)
!1526 = distinct !DISubprogram(name: "_allocate_wbuf", scope: !2, file: !2, line: 499, type: !451, scopeLine: 499, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1527)
!1527 = !{!1528, !1529, !1530}
!1528 = !DILocalVariable(name: "e", arg: 1, scope: !1526, file: !2, line: 499, type: !68)
!1529 = !DILocalVariable(name: "p", arg: 2, scope: !1526, file: !2, line: 499, type: !105)
!1530 = !DILocalVariable(name: "wbuf", scope: !1526, file: !2, line: 500, type: !132)
!1531 = !DILocation(line: 0, scope: !1526)
!1532 = !DILocation(line: 502, column: 5, scope: !1526)
!1533 = !DILocation(line: 503, column: 12, scope: !1534)
!1534 = distinct !DILexicalBlock(scope: !1526, file: !2, line: 503, column: 9)
!1535 = !DILocation(line: 503, column: 9, scope: !1534)
!1536 = !DILocation(line: 503, column: 9, scope: !1526)
!1537 = !DILocation(line: 508, column: 5, scope: !1526)
!1538 = !DILocation(line: 509, column: 9, scope: !1526)
!1539 = !DILocation(line: 505, column: 31, scope: !1540)
!1540 = distinct !DILexicalBlock(scope: !1534, file: !2, line: 503, column: 24)
!1541 = !DILocation(line: 505, column: 23, scope: !1540)
!1542 = !DILocation(line: 506, column: 20, scope: !1540)
!1543 = !DILocation(line: 510, column: 27, scope: !1544)
!1544 = distinct !DILexicalBlock(scope: !1545, file: !2, line: 509, column: 15)
!1545 = distinct !DILexicalBlock(scope: !1526, file: !2, line: 509, column: 9)
!1546 = !DILocation(line: 510, column: 15, scope: !1544)
!1547 = !DILocation(line: 510, column: 22, scope: !1544)
!1548 = !DILocation(line: 511, column: 31, scope: !1544)
!1549 = !DILocation(line: 511, column: 22, scope: !1544)
!1550 = !DILocation(line: 512, column: 15, scope: !1544)
!1551 = !DILocation(line: 512, column: 20, scope: !1544)
!1552 = !DILocation(line: 513, column: 31, scope: !1544)
!1553 = !DILocation(line: 513, column: 15, scope: !1544)
!1554 = !DILocation(line: 513, column: 23, scope: !1544)
!1555 = !DILocation(line: 514, column: 15, scope: !1544)
!1556 = !DILocation(line: 514, column: 20, scope: !1544)
!1557 = !DILocation(line: 515, column: 15, scope: !1544)
!1558 = !DILocation(line: 515, column: 23, scope: !1544)
!1559 = !{!817, !391, i64 37}
!1560 = !DILocation(line: 517, column: 12, scope: !1544)
!1561 = !DILocation(line: 517, column: 17, scope: !1544)
!1562 = !DILocation(line: 518, column: 5, scope: !1544)
!1563 = !DILocation(line: 519, column: 1, scope: !1526)
!1564 = distinct !DISubprogram(name: "extstore_write", scope: !2, file: !2, line: 651, type: !1565, scopeLine: 651, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1567)
!1565 = !DISubroutineType(types: !1566)
!1566 = !{null, !155, !150}
!1567 = !{!1568, !1569, !1570, !1571}
!1568 = !DILocalVariable(name: "ptr", arg: 1, scope: !1564, file: !2, line: 651, type: !155)
!1569 = !DILocalVariable(name: "io", arg: 2, scope: !1564, file: !2, line: 651, type: !150)
!1570 = !DILocalVariable(name: "e", scope: !1564, file: !2, line: 652, type: !68)
!1571 = !DILocalVariable(name: "p", scope: !1564, file: !2, line: 653, type: !105)
!1572 = !DILocation(line: 0, scope: !1564)
!1573 = !DILocation(line: 653, column: 25, scope: !1564)
!1574 = !DILocation(line: 653, column: 35, scope: !1564)
!1575 = !DILocation(line: 653, column: 22, scope: !1564)
!1576 = !DILocation(line: 655, column: 21, scope: !1564)
!1577 = !DILocation(line: 655, column: 27, scope: !1564)
!1578 = !DILocation(line: 655, column: 46, scope: !1564)
!1579 = !DILocation(line: 655, column: 62, scope: !1564)
!1580 = !DILocation(line: 655, column: 51, scope: !1564)
!1581 = !DILocation(line: 655, column: 34, scope: !1564)
!1582 = !DILocation(line: 655, column: 9, scope: !1564)
!1583 = !DILocation(line: 655, column: 16, scope: !1564)
!1584 = !DILocation(line: 656, column: 27, scope: !1564)
!1585 = !DILocation(line: 656, column: 9, scope: !1564)
!1586 = !DILocation(line: 656, column: 22, scope: !1564)
!1587 = !DILocation(line: 657, column: 29, scope: !1564)
!1588 = !DILocation(line: 657, column: 14, scope: !1564)
!1589 = !DILocation(line: 657, column: 22, scope: !1564)
!1590 = !DILocation(line: 658, column: 19, scope: !1564)
!1591 = !DILocation(line: 660, column: 8, scope: !1564)
!1592 = !DILocation(line: 660, column: 17, scope: !1564)
!1593 = !DILocation(line: 661, column: 5, scope: !1564)
!1594 = !DILocation(line: 662, column: 35, scope: !1564)
!1595 = !DILocation(line: 662, column: 31, scope: !1564)
!1596 = !DILocation(line: 662, column: 14, scope: !1564)
!1597 = !DILocation(line: 662, column: 28, scope: !1564)
!1598 = !{!297, !301, i64 272}
!1599 = !DILocation(line: 663, column: 14, scope: !1564)
!1600 = !DILocation(line: 663, column: 25, scope: !1564)
!1601 = !DILocation(line: 664, column: 14, scope: !1564)
!1602 = !DILocation(line: 664, column: 29, scope: !1564)
!1603 = !DILocation(line: 666, column: 5, scope: !1564)
!1604 = !DILocation(line: 668, column: 5, scope: !1564)
!1605 = !DILocation(line: 669, column: 1, scope: !1564)
!1606 = distinct !DISubprogram(name: "extstore_submit", scope: !2, file: !2, line: 708, type: !1478, scopeLine: 708, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1607)
!1607 = !{!1608, !1609, !1610, !1611}
!1608 = !DILocalVariable(name: "ptr", arg: 1, scope: !1606, file: !2, line: 708, type: !155)
!1609 = !DILocalVariable(name: "io", arg: 2, scope: !1606, file: !2, line: 708, type: !150)
!1610 = !DILocalVariable(name: "e", scope: !1606, file: !2, line: 709, type: !68)
!1611 = !DILocalVariable(name: "t", scope: !1606, file: !2, line: 710, type: !180)
!1612 = !DILocation(line: 0, scope: !1606)
!1613 = !DILocalVariable(name: "e", arg: 1, scope: !1614, file: !2, line: 142, type: !68)
!1614 = distinct !DISubprogram(name: "_get_io_thread", scope: !2, file: !2, line: 142, type: !1615, scopeLine: 142, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1617)
!1615 = !DISubroutineType(types: !1616)
!1616 = !{!180, !68}
!1617 = !{!1613, !1618, !1619, !1620}
!1618 = !DILocalVariable(name: "tid", scope: !1614, file: !2, line: 143, type: !82)
!1619 = !DILocalVariable(name: "low", scope: !1614, file: !2, line: 144, type: !218)
!1620 = !DILocalVariable(name: "x", scope: !1621, file: !2, line: 149, type: !82)
!1621 = distinct !DILexicalBlock(scope: !1614, file: !2, line: 149, column: 5)
!1622 = !DILocation(line: 0, scope: !1614, inlinedAt: !1623)
!1623 = distinct !DILocation(line: 710, column: 26, scope: !1606)
!1624 = !DILocation(line: 145, column: 5, scope: !1614, inlinedAt: !1623)
!1625 = !DILocation(line: 0, scope: !1621, inlinedAt: !1623)
!1626 = !DILocation(line: 149, column: 23, scope: !1627, inlinedAt: !1623)
!1627 = distinct !DILexicalBlock(scope: !1621, file: !2, line: 149, column: 5)
!1628 = !DILocation(line: 149, column: 5, scope: !1621, inlinedAt: !1623)
!1629 = !DILocation(line: 150, column: 16, scope: !1630, inlinedAt: !1623)
!1630 = distinct !DILexicalBlock(scope: !1631, file: !2, line: 150, column: 13)
!1631 = distinct !DILexicalBlock(scope: !1627, file: !2, line: 149, column: 49)
!1632 = !DILocation(line: 150, column: 30, scope: !1630, inlinedAt: !1623)
!1633 = !DILocation(line: 150, column: 36, scope: !1630, inlinedAt: !1623)
!1634 = !DILocation(line: 150, column: 13, scope: !1631, inlinedAt: !1623)
!1635 = !DILocation(line: 153, column: 20, scope: !1636, inlinedAt: !1623)
!1636 = distinct !DILexicalBlock(scope: !1630, file: !2, line: 153, column: 20)
!1637 = !DILocation(line: 153, column: 43, scope: !1636, inlinedAt: !1623)
!1638 = !DILocation(line: 153, column: 20, scope: !1630, inlinedAt: !1623)
!1639 = !DILocation(line: 149, column: 45, scope: !1627, inlinedAt: !1623)
!1640 = distinct !{!1640, !1628, !1641, !353}
!1641 = !DILocation(line: 157, column: 5, scope: !1621, inlinedAt: !1623)
!1642 = !DILocation(line: 160, column: 13, scope: !1614, inlinedAt: !1623)
!1643 = !DILocation(line: 158, column: 5, scope: !1614, inlinedAt: !1623)
!1644 = !DILocation(line: 160, column: 16, scope: !1614, inlinedAt: !1623)
!1645 = !DILocation(line: 0, scope: !1488, inlinedAt: !1646)
!1646 = distinct !DILocation(line: 711, column: 12, scope: !1606)
!1647 = !DILocation(line: 680, column: 16, scope: !1488, inlinedAt: !1646)
!1648 = !DILocation(line: 680, column: 5, scope: !1488, inlinedAt: !1646)
!1649 = !DILocation(line: 682, column: 14, scope: !1501, inlinedAt: !1646)
!1650 = !DILocation(line: 683, column: 20, scope: !1501, inlinedAt: !1646)
!1651 = distinct !{!1651, !1648, !1652, !353}
!1652 = !DILocation(line: 684, column: 5, scope: !1488, inlinedAt: !1646)
!1653 = !DILocation(line: 686, column: 5, scope: !1488, inlinedAt: !1646)
!1654 = !DILocation(line: 688, column: 8, scope: !1488, inlinedAt: !1646)
!1655 = !DILocation(line: 688, column: 14, scope: !1488, inlinedAt: !1646)
!1656 = !DILocation(line: 689, column: 12, scope: !1510, inlinedAt: !1646)
!1657 = !DILocation(line: 689, column: 18, scope: !1510, inlinedAt: !1646)
!1658 = !DILocation(line: 689, column: 9, scope: !1488, inlinedAt: !1646)
!1659 = !DILocation(line: 690, column: 18, scope: !1514, inlinedAt: !1646)
!1660 = !DILocation(line: 691, column: 12, scope: !1514, inlinedAt: !1646)
!1661 = !DILocation(line: 692, column: 5, scope: !1514, inlinedAt: !1646)
!1662 = !DILocation(line: 696, column: 12, scope: !1518, inlinedAt: !1646)
!1663 = !DILocation(line: 696, column: 24, scope: !1518, inlinedAt: !1646)
!1664 = !DILocation(line: 696, column: 29, scope: !1518, inlinedAt: !1646)
!1665 = !DILocation(line: 0, scope: !1510, inlinedAt: !1646)
!1666 = !DILocation(line: 700, column: 5, scope: !1488, inlinedAt: !1646)
!1667 = !DILocation(line: 703, column: 29, scope: !1488, inlinedAt: !1646)
!1668 = !DILocation(line: 703, column: 5, scope: !1488, inlinedAt: !1646)
!1669 = !DILocation(line: 711, column: 5, scope: !1606)
!1670 = !DILocation(line: 0, scope: !1477)
!1671 = !DILocation(line: 716, column: 29, scope: !1477)
!1672 = !DILocation(line: 0, scope: !1488, inlinedAt: !1673)
!1673 = distinct !DILocation(line: 717, column: 12, scope: !1477)
!1674 = !DILocation(line: 680, column: 16, scope: !1488, inlinedAt: !1673)
!1675 = !DILocation(line: 680, column: 5, scope: !1488, inlinedAt: !1673)
!1676 = !DILocation(line: 682, column: 14, scope: !1501, inlinedAt: !1673)
!1677 = !DILocation(line: 683, column: 20, scope: !1501, inlinedAt: !1673)
!1678 = distinct !{!1678, !1675, !1679, !353}
!1679 = !DILocation(line: 684, column: 5, scope: !1488, inlinedAt: !1673)
!1680 = !DILocation(line: 686, column: 5, scope: !1488, inlinedAt: !1673)
!1681 = !DILocation(line: 688, column: 8, scope: !1488, inlinedAt: !1673)
!1682 = !DILocation(line: 688, column: 14, scope: !1488, inlinedAt: !1673)
!1683 = !DILocation(line: 689, column: 12, scope: !1510, inlinedAt: !1673)
!1684 = !DILocation(line: 689, column: 18, scope: !1510, inlinedAt: !1673)
!1685 = !DILocation(line: 689, column: 9, scope: !1488, inlinedAt: !1673)
!1686 = !DILocation(line: 690, column: 18, scope: !1514, inlinedAt: !1673)
!1687 = !DILocation(line: 691, column: 12, scope: !1514, inlinedAt: !1673)
!1688 = !DILocation(line: 692, column: 5, scope: !1514, inlinedAt: !1673)
!1689 = !DILocation(line: 696, column: 12, scope: !1518, inlinedAt: !1673)
!1690 = !DILocation(line: 696, column: 24, scope: !1518, inlinedAt: !1673)
!1691 = !DILocation(line: 696, column: 29, scope: !1518, inlinedAt: !1673)
!1692 = !DILocation(line: 0, scope: !1510, inlinedAt: !1673)
!1693 = !DILocation(line: 700, column: 5, scope: !1488, inlinedAt: !1673)
!1694 = !DILocation(line: 703, column: 29, scope: !1488, inlinedAt: !1673)
!1695 = !DILocation(line: 703, column: 5, scope: !1488, inlinedAt: !1673)
!1696 = !DILocation(line: 717, column: 5, scope: !1477)
!1697 = distinct !DISubprogram(name: "extstore_delete", scope: !2, file: !2, line: 723, type: !1698, scopeLine: 724, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1700)
!1698 = !DISubroutineType(types: !1699)
!1699 = !{!82, !155, !53, !111, !53, !53}
!1700 = !{!1701, !1702, !1703, !1704, !1705, !1706, !1707, !1708}
!1701 = !DILocalVariable(name: "ptr", arg: 1, scope: !1697, file: !2, line: 723, type: !155)
!1702 = !DILocalVariable(name: "page_id", arg: 2, scope: !1697, file: !2, line: 723, type: !53)
!1703 = !DILocalVariable(name: "page_version", arg: 3, scope: !1697, file: !2, line: 723, type: !111)
!1704 = !DILocalVariable(name: "count", arg: 4, scope: !1697, file: !2, line: 724, type: !53)
!1705 = !DILocalVariable(name: "bytes", arg: 5, scope: !1697, file: !2, line: 724, type: !53)
!1706 = !DILocalVariable(name: "e", scope: !1697, file: !2, line: 725, type: !68)
!1707 = !DILocalVariable(name: "p", scope: !1697, file: !2, line: 727, type: !105)
!1708 = !DILocalVariable(name: "ret", scope: !1697, file: !2, line: 728, type: !82)
!1709 = !DILocation(line: 0, scope: !1697)
!1710 = !DILocation(line: 727, column: 25, scope: !1697)
!1711 = !DILocation(line: 727, column: 22, scope: !1697)
!1712 = !DILocation(line: 730, column: 5, scope: !1697)
!1713 = !DILocation(line: 731, column: 13, scope: !1714)
!1714 = distinct !DILexicalBlock(scope: !1697, file: !2, line: 731, column: 9)
!1715 = !DILocation(line: 731, column: 20, scope: !1714)
!1716 = !DILocation(line: 731, column: 26, scope: !1714)
!1717 = !DILocation(line: 731, column: 23, scope: !1714)
!1718 = !DILocation(line: 731, column: 34, scope: !1714)
!1719 = !DILocation(line: 731, column: 9, scope: !1697)
!1720 = !DILocation(line: 732, column: 16, scope: !1721)
!1721 = distinct !DILexicalBlock(scope: !1722, file: !2, line: 732, column: 13)
!1722 = distinct !DILexicalBlock(scope: !1714, file: !2, line: 731, column: 51)
!1723 = !DILocation(line: 732, column: 30, scope: !1721)
!1724 = !DILocation(line: 732, column: 13, scope: !1722)
!1725 = !DILocation(line: 0, scope: !1721)
!1726 = !DILocation(line: 738, column: 16, scope: !1727)
!1727 = distinct !DILexicalBlock(scope: !1722, file: !2, line: 738, column: 13)
!1728 = !DILocation(line: 738, column: 29, scope: !1727)
!1729 = !DILocation(line: 738, column: 13, scope: !1722)
!1730 = !DILocation(line: 0, scope: !1727)
!1731 = !DILocation(line: 743, column: 9, scope: !1722)
!1732 = !DILocation(line: 744, column: 18, scope: !1722)
!1733 = !DILocation(line: 744, column: 29, scope: !1722)
!1734 = !DILocation(line: 745, column: 18, scope: !1722)
!1735 = !DILocation(line: 745, column: 31, scope: !1722)
!1736 = !DILocation(line: 746, column: 9, scope: !1722)
!1737 = !DILocation(line: 748, column: 16, scope: !1738)
!1738 = distinct !DILexicalBlock(scope: !1722, file: !2, line: 748, column: 13)
!1739 = !DILocation(line: 748, column: 26, scope: !1738)
!1740 = !DILocation(line: 748, column: 31, scope: !1738)
!1741 = !DILocation(line: 748, column: 37, scope: !1738)
!1742 = !DILocation(line: 748, column: 46, scope: !1738)
!1743 = !DILocation(line: 748, column: 51, scope: !1738)
!1744 = !DILocation(line: 748, column: 58, scope: !1738)
!1745 = !DILocation(line: 748, column: 13, scope: !1722)
!1746 = !DILocation(line: 749, column: 13, scope: !1747)
!1747 = distinct !DILexicalBlock(scope: !1738, file: !2, line: 748, column: 66)
!1748 = !DILocation(line: 750, column: 9, scope: !1747)
!1749 = !DILocation(line: 754, column: 5, scope: !1697)
!1750 = !DILocation(line: 755, column: 5, scope: !1697)
!1751 = distinct !DISubprogram(name: "extstore_check", scope: !2, file: !2, line: 758, type: !1752, scopeLine: 758, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1754)
!1752 = !DISubroutineType(types: !1753)
!1753 = !{!82, !155, !53, !111}
!1754 = !{!1755, !1756, !1757, !1758, !1759, !1760}
!1755 = !DILocalVariable(name: "ptr", arg: 1, scope: !1751, file: !2, line: 758, type: !155)
!1756 = !DILocalVariable(name: "page_id", arg: 2, scope: !1751, file: !2, line: 758, type: !53)
!1757 = !DILocalVariable(name: "page_version", arg: 3, scope: !1751, file: !2, line: 758, type: !111)
!1758 = !DILocalVariable(name: "e", scope: !1751, file: !2, line: 759, type: !68)
!1759 = !DILocalVariable(name: "p", scope: !1751, file: !2, line: 760, type: !105)
!1760 = !DILocalVariable(name: "ret", scope: !1751, file: !2, line: 761, type: !82)
!1761 = !DILocation(line: 0, scope: !1751)
!1762 = !DILocation(line: 760, column: 25, scope: !1751)
!1763 = !DILocation(line: 760, column: 22, scope: !1751)
!1764 = !DILocation(line: 763, column: 5, scope: !1751)
!1765 = !DILocation(line: 764, column: 12, scope: !1766)
!1766 = distinct !DILexicalBlock(scope: !1751, file: !2, line: 764, column: 9)
!1767 = !DILocation(line: 764, column: 9, scope: !1766)
!1768 = !DILocation(line: 764, column: 20, scope: !1766)
!1769 = !DILocation(line: 764, column: 9, scope: !1751)
!1770 = !DILocation(line: 766, column: 5, scope: !1751)
!1771 = !DILocation(line: 767, column: 5, scope: !1751)
!1772 = distinct !DISubprogram(name: "extstore_close_page", scope: !2, file: !2, line: 771, type: !1773, scopeLine: 771, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1775)
!1773 = !DISubroutineType(types: !1774)
!1774 = !{null, !155, !53, !111}
!1775 = !{!1776, !1777, !1778, !1779, !1780}
!1776 = !DILocalVariable(name: "ptr", arg: 1, scope: !1772, file: !2, line: 771, type: !155)
!1777 = !DILocalVariable(name: "page_id", arg: 2, scope: !1772, file: !2, line: 771, type: !53)
!1778 = !DILocalVariable(name: "page_version", arg: 3, scope: !1772, file: !2, line: 771, type: !111)
!1779 = !DILocalVariable(name: "e", scope: !1772, file: !2, line: 772, type: !68)
!1780 = !DILocalVariable(name: "p", scope: !1772, file: !2, line: 773, type: !105)
!1781 = !DILocation(line: 0, scope: !1772)
!1782 = !DILocation(line: 773, column: 25, scope: !1772)
!1783 = !DILocation(line: 773, column: 22, scope: !1772)
!1784 = !DILocation(line: 775, column: 5, scope: !1772)
!1785 = !DILocation(line: 776, column: 13, scope: !1786)
!1786 = distinct !DILexicalBlock(scope: !1772, file: !2, line: 776, column: 9)
!1787 = !DILocation(line: 776, column: 20, scope: !1786)
!1788 = !DILocation(line: 776, column: 27, scope: !1786)
!1789 = !DILocation(line: 776, column: 34, scope: !1786)
!1790 = !DILocation(line: 776, column: 40, scope: !1786)
!1791 = !DILocation(line: 776, column: 37, scope: !1786)
!1792 = !DILocation(line: 776, column: 48, scope: !1786)
!1793 = !DILocation(line: 776, column: 9, scope: !1772)
!1794 = !DILocation(line: 777, column: 19, scope: !1795)
!1795 = distinct !DILexicalBlock(scope: !1786, file: !2, line: 776, column: 65)
!1796 = !DILocation(line: 778, column: 16, scope: !1797)
!1797 = distinct !DILexicalBlock(scope: !1795, file: !2, line: 778, column: 13)
!1798 = !DILocation(line: 778, column: 25, scope: !1797)
!1799 = !DILocation(line: 778, column: 13, scope: !1795)
!1800 = !DILocation(line: 779, column: 13, scope: !1801)
!1801 = distinct !DILexicalBlock(scope: !1797, file: !2, line: 778, column: 31)
!1802 = !DILocation(line: 780, column: 9, scope: !1801)
!1803 = !DILocation(line: 782, column: 5, scope: !1772)
!1804 = !DILocation(line: 783, column: 1, scope: !1772)
!1805 = distinct !DISubprogram(name: "extstore_evict_page", scope: !2, file: !2, line: 786, type: !1773, scopeLine: 786, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1806)
!1806 = !{!1807, !1808, !1809, !1810, !1811}
!1807 = !DILocalVariable(name: "ptr", arg: 1, scope: !1805, file: !2, line: 786, type: !155)
!1808 = !DILocalVariable(name: "page_id", arg: 2, scope: !1805, file: !2, line: 786, type: !53)
!1809 = !DILocalVariable(name: "page_version", arg: 3, scope: !1805, file: !2, line: 786, type: !111)
!1810 = !DILocalVariable(name: "e", scope: !1805, file: !2, line: 787, type: !68)
!1811 = !DILocalVariable(name: "p", scope: !1805, file: !2, line: 788, type: !105)
!1812 = !DILocation(line: 0, scope: !1805)
!1813 = !DILocation(line: 788, column: 25, scope: !1805)
!1814 = !DILocation(line: 788, column: 22, scope: !1805)
!1815 = !DILocation(line: 790, column: 5, scope: !1805)
!1816 = !DILocation(line: 791, column: 13, scope: !1817)
!1817 = distinct !DILexicalBlock(scope: !1805, file: !2, line: 791, column: 9)
!1818 = !DILocation(line: 791, column: 20, scope: !1817)
!1819 = !DILocation(line: 791, column: 27, scope: !1817)
!1820 = !DILocation(line: 791, column: 34, scope: !1817)
!1821 = !DILocation(line: 791, column: 40, scope: !1817)
!1822 = !DILocation(line: 791, column: 37, scope: !1817)
!1823 = !DILocation(line: 791, column: 48, scope: !1817)
!1824 = !DILocation(line: 791, column: 9, scope: !1805)
!1825 = !DILocation(line: 795, column: 19, scope: !1826)
!1826 = distinct !DILexicalBlock(scope: !1817, file: !2, line: 791, column: 65)
!1827 = !DILocation(line: 796, column: 9, scope: !1826)
!1828 = !DILocation(line: 797, column: 18, scope: !1826)
!1829 = !DILocation(line: 797, column: 32, scope: !1826)
!1830 = !{!297, !301, i64 192}
!1831 = !DILocation(line: 798, column: 40, scope: !1826)
!1832 = !DILocation(line: 798, column: 18, scope: !1826)
!1833 = !DILocation(line: 798, column: 34, scope: !1826)
!1834 = !{!297, !301, i64 232}
!1835 = !DILocation(line: 799, column: 38, scope: !1826)
!1836 = !DILocation(line: 799, column: 18, scope: !1826)
!1837 = !DILocation(line: 799, column: 32, scope: !1826)
!1838 = !{!297, !301, i64 264}
!1839 = !DILocation(line: 800, column: 9, scope: !1826)
!1840 = !DILocation(line: 801, column: 16, scope: !1841)
!1841 = distinct !DILexicalBlock(scope: !1826, file: !2, line: 801, column: 13)
!1842 = !DILocation(line: 801, column: 25, scope: !1841)
!1843 = !DILocation(line: 801, column: 13, scope: !1826)
!1844 = !DILocation(line: 802, column: 13, scope: !1845)
!1845 = distinct !DILexicalBlock(scope: !1841, file: !2, line: 801, column: 31)
!1846 = !DILocation(line: 803, column: 9, scope: !1845)
!1847 = !DILocation(line: 805, column: 5, scope: !1805)
!1848 = !DILocation(line: 806, column: 1, scope: !1805)
!1849 = !DISubprogram(name: "pthread_setname_np", scope: !355, file: !355, line: 463, type: !1850, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1850 = !DISubroutineType(types: !1851)
!1851 = !{!82, !565, !525}
!1852 = distinct !DISubprogram(name: "_wbuf_cb", scope: !2, file: !2, line: 527, type: !177, scopeLine: 527, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !49, retainedNodes: !1853)
!1853 = !{!1854, !1855, !1856, !1857, !1858, !1859}
!1854 = !DILocalVariable(name: "ep", arg: 1, scope: !1852, file: !2, line: 527, type: !155)
!1855 = !DILocalVariable(name: "io", arg: 2, scope: !1852, file: !2, line: 527, type: !150)
!1856 = !DILocalVariable(name: "ret", arg: 3, scope: !1852, file: !2, line: 527, type: !82)
!1857 = !DILocalVariable(name: "e", scope: !1852, file: !2, line: 528, type: !68)
!1858 = !DILocalVariable(name: "p", scope: !1852, file: !2, line: 529, type: !105)
!1859 = !DILocalVariable(name: "w", scope: !1852, file: !2, line: 530, type: !132)
!1860 = !DILocation(line: 0, scope: !1852)
!1861 = !DILocation(line: 529, column: 25, scope: !1852)
!1862 = !DILocation(line: 529, column: 35, scope: !1852)
!1863 = !DILocation(line: 529, column: 22, scope: !1852)
!1864 = !DILocation(line: 530, column: 42, scope: !1852)
!1865 = !DILocation(line: 534, column: 8, scope: !1852)
!1866 = !DILocation(line: 534, column: 16, scope: !1852)
!1867 = !DILocation(line: 535, column: 5, scope: !1852)
!1868 = !DILocation(line: 538, column: 22, scope: !1852)
!1869 = !DILocation(line: 538, column: 8, scope: !1852)
!1870 = !DILocation(line: 538, column: 16, scope: !1852)
!1871 = !DILocation(line: 539, column: 8, scope: !1852)
!1872 = !DILocation(line: 539, column: 13, scope: !1852)
!1873 = !DILocation(line: 541, column: 9, scope: !1874)
!1874 = distinct !DILexicalBlock(scope: !1852, file: !2, line: 541, column: 9)
!1875 = !DILocation(line: 541, column: 26, scope: !1874)
!1876 = !DILocation(line: 541, column: 20, scope: !1874)
!1877 = !DILocation(line: 541, column: 9, scope: !1852)
!1878 = !DILocation(line: 542, column: 12, scope: !1874)
!1879 = !DILocation(line: 542, column: 19, scope: !1874)
!1880 = !DILocation(line: 542, column: 9, scope: !1874)
!1881 = !DILocation(line: 545, column: 5, scope: !1852)
!1882 = !DILocation(line: 546, column: 18, scope: !1852)
!1883 = !DILocation(line: 546, column: 13, scope: !1852)
!1884 = !DILocation(line: 547, column: 19, scope: !1852)
!1885 = !DILocation(line: 549, column: 19, scope: !1852)
!1886 = !DILocation(line: 549, column: 9, scope: !1852)
!1887 = !DILocation(line: 549, column: 14, scope: !1852)
!1888 = !DILocation(line: 550, column: 17, scope: !1852)
!1889 = !DILocation(line: 551, column: 5, scope: !1852)
!1890 = !DILocation(line: 552, column: 5, scope: !1852)
!1891 = !DILocation(line: 553, column: 1, scope: !1852)
!1892 = !DISubprogram(name: "pthread_cond_signal", scope: !355, file: !355, line: 1121, type: !1893, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1893 = !DISubroutineType(types: !1894)
!1894 = !{!82, !948}
!1895 = !DISubprogram(name: "pthread_cond_wait", scope: !355, file: !355, line: 1133, type: !1896, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1896 = !DISubroutineType(types: !1897)
!1897 = !{!82, !947, !1898}
!1898 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !358)
!1899 = !DISubprogram(name: "pread", scope: !928, file: !928, line: 389, type: !1900, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1900 = !DISubroutineType(types: !1901)
!1901 = !{!1902, !82, !155, !166, !578}
!1902 = !DIDerivedType(tag: DW_TAG_typedef, name: "ssize_t", file: !1903, line: 108, baseType: !1904)
!1903 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/types.h", directory: "", checksumkind: CSK_MD5, checksum: "7fb02a803b0c9b11cb5276b77d21e9d8")
!1904 = !DIDerivedType(tag: DW_TAG_typedef, name: "__ssize_t", file: !114, line: 194, baseType: !103)
!1905 = !DISubprogram(name: "preadv", scope: !1906, file: !1906, line: 67, type: !1907, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1906 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/uio.h", directory: "", checksumkind: CSK_MD5, checksum: "b31a0c0023822d6eae1890cf0efee73e")
!1907 = !DISubroutineType(types: !1908)
!1908 = !{!1902, !82, !1909, !82, !578}
!1909 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1910, size: 64)
!1910 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !161)
!1911 = !DISubprogram(name: "pwrite", scope: !928, file: !928, line: 398, type: !1912, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1912 = !DISubroutineType(types: !1913)
!1913 = !{!1902, !82, !1914, !166, !578}
!1914 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1915, size: 64)
!1915 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
