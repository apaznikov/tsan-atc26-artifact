; ModuleID = 'proto_bin.c'
source_filename = "proto_bin.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.settings = type { i64, i32, i32, i32, ptr, i32, i32, i32, ptr, ptr, i32, double, i32, i32, i32, i8, i32, i32, i8, i32, i32, i32, i32, i32, i32, i8, i8, i8, i8, i8, i8, i32, double, i32, i32, i8, i32, i8, i8, ptr, i32, i32, i32, i32, double, double, i32, i8, i32, i32, i32, i32, i32, i8, i8, i8, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, double, double, i8, i32, i32, ptr, i32 }
%struct.slab_stats = type { i64, i64, i64, i64, i64, i64, i64, i64 }

@stderr = external local_unnamed_addr global ptr, align 8
@.str = private unnamed_addr constant [26 x i8] c"Not handling substate %d\0A\00", align 1, !dbg !0
@settings = external local_unnamed_addr global %struct.settings, align 8
@.str.1 = private unnamed_addr constant [31 x i8] c"<%d Read binary protocol data:\00", align 1, !dbg !7
@.str.2 = private unnamed_addr constant [8 x i8] c"\0A<%d   \00", align 1, !dbg !12
@.str.3 = private unnamed_addr constant [8 x i8] c" 0x%02x\00", align 1, !dbg !17
@.str.5 = private unnamed_addr constant [20 x i8] c"Invalid magic:  %x\0A\00", align 1, !dbg !19
@current_time = external global i32, align 4
@.str.6 = private unnamed_addr constant [14 x i8] c"Out of memory\00", align 1, !dbg !24
@.str.7 = private unnamed_addr constant [16 x i8] c"Unknown command\00", align 1, !dbg !29
@.str.8 = private unnamed_addr constant [10 x i8] c"Not found\00", align 1, !dbg !34
@.str.9 = private unnamed_addr constant [18 x i8] c"Invalid arguments\00", align 1, !dbg !39
@.str.10 = private unnamed_addr constant [21 x i8] c"Data exists for key.\00", align 1, !dbg !44
@.str.11 = private unnamed_addr constant [11 x i8] c"Too large.\00", align 1, !dbg !49
@.str.12 = private unnamed_addr constant [47 x i8] c"Non-numeric server-side value for incr or decr\00", align 1, !dbg !54
@.str.13 = private unnamed_addr constant [12 x i8] c"Not stored.\00", align 1, !dbg !59
@.str.14 = private unnamed_addr constant [14 x i8] c"Auth failure.\00", align 1, !dbg !64
@.str.15 = private unnamed_addr constant [16 x i8] c"UNHANDLED ERROR\00", align 1, !dbg !66
@.str.16 = private unnamed_addr constant [25 x i8] c">%d UNHANDLED ERROR: %d\0A\00", align 1, !dbg !68
@.str.17 = private unnamed_addr constant [26 x i8] c">%d Writing an error: %s\0A\00", align 1, !dbg !73
@.str.18 = private unnamed_addr constant [26 x i8] c">%d Writing bin response:\00", align 1, !dbg !75
@.str.19 = private unnamed_addr constant [7 x i8] c"\0A>%d  \00", align 1, !dbg !77
@.str.20 = private unnamed_addr constant [37 x i8] c"mech:  ``%s'' with %d bytes of data\0A\00", align 1, !dbg !82
@.str.21 = private unnamed_addr constant [76 x i8] c"%d: SASL_STEP called but sasl_server_start not called for this connection!\0A\00", align 1, !dbg !87
@.str.22 = private unnamed_addr constant [40 x i8] c"Unhandled command %d with challenge %s\0A\00", align 1, !dbg !92
@.str.23 = private unnamed_addr constant [23 x i8] c"sasl result code:  %d\0A\00", align 1, !dbg !97
@.str.25 = private unnamed_addr constant [28 x i8] c"Unknown sasl response:  %d\0A\00", align 1, !dbg !102
@.str.26 = private unnamed_addr constant [33 x i8] c"Failed to initialize SASL conn.\0A\00", align 1, !dbg !107
@.str.27 = private unnamed_addr constant [7 x i8] c"1.6.29\00", align 1, !dbg !112
@.str.28 = private unnamed_addr constant [37 x i8] c"authenticated() in cmd 0x%02x is %s\0A\00", align 1, !dbg !114
@.str.29 = private unnamed_addr constant [5 x i8] c"true\00", align 1, !dbg !116
@.str.30 = private unnamed_addr constant [6 x i8] c"false\00", align 1, !dbg !121
@.str.31 = private unnamed_addr constant [51 x i8] c"Protocol error (opcode %02x), close connection %d\0A\00", align 1, !dbg !126
@.str.32 = private unnamed_addr constant [9 x i8] c"<%d ADD \00", align 1, !dbg !131
@.str.33 = private unnamed_addr constant [9 x i8] c"<%d SET \00", align 1, !dbg !136
@.str.34 = private unnamed_addr constant [13 x i8] c"<%d REPLACE \00", align 1, !dbg !138
@.str.36 = private unnamed_addr constant [17 x i8] c" Value len is %d\00", align 1, !dbg !143
@.str.37 = private unnamed_addr constant [43 x i8] c"SERVER_ERROR Out of memory allocating item\00", align 1, !dbg !148
@logger_key = external local_unnamed_addr global i32, align 4
@.str.38 = private unnamed_addr constant [8 x i8] c"<%d %s \00", align 1, !dbg !153
@.str.39 = private unnamed_addr constant [6 x i8] c"TOUCH\00", align 1, !dbg !155
@.str.40 = private unnamed_addr constant [4 x i8] c"GET\00", align 1, !dbg !157
@.str.41 = private unnamed_addr constant [10 x i8] c"Deleting \00", align 1, !dbg !162
@.str.42 = private unnamed_addr constant [6 x i8] c"incr \00", align 1, !dbg !164
@.str.43 = private unnamed_addr constant [17 x i8] c" %lld, %llu, %d\0A\00", align 1, !dbg !166
@.str.44 = private unnamed_addr constant [46 x i8] c"SERVER_ERROR Out of memory incrementing value\00", align 1, !dbg !168
@.str.45 = private unnamed_addr constant [5 x i8] c"%llu\00", align 1, !dbg !173
@.str.47 = private unnamed_addr constant [47 x i8] c"SERVER_ERROR Out of memory allocating new item\00", align 1, !dbg !175
@.str.48 = private unnamed_addr constant [17 x i8] c"Value len is %d\0A\00", align 1, !dbg !177
@.str.49 = private unnamed_addr constant [11 x i8] c"<%d STATS \00", align 1, !dbg !179
@.str.50 = private unnamed_addr constant [6 x i8] c"reset\00", align 1, !dbg !181
@.str.51 = private unnamed_addr constant [9 x i8] c"settings\00", align 1, !dbg !183
@.str.52 = private unnamed_addr constant [7 x i8] c"detail\00", align 1, !dbg !185
@.str.53 = private unnamed_addr constant [6 x i8] c" dump\00", align 1, !dbg !187
@.str.54 = private unnamed_addr constant [44 x i8] c"SERVER_ERROR Out of memory generating stats\00", align 1, !dbg !189
@.str.55 = private unnamed_addr constant [9 x i8] c"detailed\00", align 1, !dbg !194
@.str.57 = private unnamed_addr constant [5 x i8] c" off\00", align 1, !dbg !196
@.str.58 = private unnamed_addr constant [51 x i8] c"SERVER_ERROR Out of memory preparing to send stats\00", align 1, !dbg !198
@.str.59 = private unnamed_addr constant [33 x i8] c"Failed to list SASL mechanisms.\0A\00", align 1, !dbg !200
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @complete_nread_binary(ptr noundef %c) local_unnamed_addr #0 !dbg !605 {
entry:
  %cas.i = alloca i64, align 8, !DIAssignID !1013
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1012, metadata !DIExpression()), !dbg !1014
  %substate = getelementptr inbounds i8, ptr %c, i64 24, !dbg !1015
  %0 = load i32, ptr %substate, align 8, !dbg !1015, !tbaa !1016
  switch i32 %0, label %sw.default [
    i32 3, label %sw.bb
    i32 10, label %sw.bb1
  ], !dbg !1032

sw.bb:                                            ; preds = %entry
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1033, metadata !DIExpression(), metadata !1013, metadata ptr %cas.i, metadata !DIExpression()), !dbg !1044
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1036, metadata !DIExpression()), !dbg !1044
  tail call void @llvm.dbg.value(metadata i32 4, metadata !1037, metadata !DIExpression()), !dbg !1044
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1039, metadata !DIExpression()), !dbg !1044
  %item.i = getelementptr inbounds i8, ptr %c, i64 224, !dbg !1047
  %1 = load ptr, ptr %item.i, align 8, !dbg !1047, !tbaa !1048
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !1040, metadata !DIExpression()), !dbg !1044
  %thread.i = getelementptr inbounds i8, ptr %c, i64 456, !dbg !1049
  %2 = load ptr, ptr %thread.i, align 8, !dbg !1049, !tbaa !1050
  %stats.i = getelementptr inbounds i8, ptr %2, i64 352, !dbg !1051
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats.i) #11, !dbg !1052
  %3 = load ptr, ptr %thread.i, align 8, !dbg !1053, !tbaa !1050
  %slab_stats.i = getelementptr inbounds i8, ptr %3, i64 632, !dbg !1054
  %slabs_clsid.i = getelementptr inbounds i8, ptr %1, i64 40, !dbg !1055
  %4 = load i8, ptr %slabs_clsid.i, align 8, !dbg !1055, !tbaa !1056
  %5 = and i8 %4, 63, !dbg !1055
  %idxprom.i = zext nneg i8 %5 to i64
  %arrayidx.i = getelementptr inbounds [64 x %struct.slab_stats], ptr %slab_stats.i, i64 0, i64 %idxprom.i, !dbg !1057
  %6 = load i64, ptr %arrayidx.i, align 8, !dbg !1058, !tbaa !1059
  %inc.i = add i64 %6, 1, !dbg !1058
  store i64 %inc.i, ptr %arrayidx.i, align 8, !dbg !1058, !tbaa !1059
  %stats4.i = getelementptr inbounds i8, ptr %3, i64 352, !dbg !1061
  %call6.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats4.i) #11, !dbg !1062
  %it_flags.i = getelementptr inbounds i8, ptr %1, i64 38, !dbg !1063
  %7 = load i16, ptr %it_flags.i, align 2, !dbg !1063, !tbaa !1064
  %conv7.i = zext i16 %7 to i32, !dbg !1065
  %and8.i = and i32 %conv7.i, 32, !dbg !1066
  %cmp.i = icmp eq i32 %and8.i, 0, !dbg !1067
  br i1 %cmp.i, label %if.then.i, label %if.else.i, !dbg !1068

if.then.i:                                        ; preds = %sw.bb
  %data.i = getelementptr inbounds i8, ptr %1, i64 48, !dbg !1069
  %nkey.i = getelementptr inbounds i8, ptr %1, i64 41, !dbg !1069
  %8 = load i8, ptr %nkey.i, align 1, !dbg !1069, !tbaa !1056
  %idx.ext.i = zext i8 %8 to i64
  %add.ptr.i = getelementptr inbounds i8, ptr %data.i, i64 %idx.ext.i, !dbg !1069
  %add.ptr11.i = getelementptr inbounds i8, ptr %add.ptr.i, i64 1, !dbg !1069
  %and14.i = lshr i32 %conv7.i, 6, !dbg !1069
  %9 = and i32 %and14.i, 4, !dbg !1069
  %cond.i = zext nneg i32 %9 to i64, !dbg !1069
  %add.ptr15.i = getelementptr inbounds i8, ptr %add.ptr11.i, i64 %cond.i, !dbg !1069
  %and18.i = shl nuw nsw i32 %conv7.i, 2, !dbg !1069
  %10 = and i32 %and18.i, 8, !dbg !1069
  %cond20.i = zext nneg i32 %10 to i64, !dbg !1069
  %add.ptr21.i = getelementptr inbounds i8, ptr %add.ptr15.i, i64 %cond20.i, !dbg !1069
  %nbytes.i = getelementptr inbounds i8, ptr %1, i64 32, !dbg !1071
  %11 = load i32, ptr %nbytes.i, align 8, !dbg !1071, !tbaa !1072
  %idx.ext22.i = sext i32 %11 to i64, !dbg !1073
  %add.ptr23.i = getelementptr inbounds i8, ptr %add.ptr21.i, i64 %idx.ext22.i, !dbg !1073
  %add.ptr24.i = getelementptr inbounds i8, ptr %add.ptr23.i, i64 -2, !dbg !1074
  store i8 13, ptr %add.ptr24.i, align 1, !dbg !1075, !tbaa !1056
  %12 = load i8, ptr %nkey.i, align 1, !dbg !1076, !tbaa !1056
  %idx.ext28.i = zext i8 %12 to i64
  %add.ptr29.i = getelementptr inbounds i8, ptr %data.i, i64 %idx.ext28.i, !dbg !1076
  %add.ptr30.i = getelementptr inbounds i8, ptr %add.ptr29.i, i64 1, !dbg !1076
  %13 = load i16, ptr %it_flags.i, align 2, !dbg !1076, !tbaa !1064
  %conv32.i = zext i16 %13 to i32, !dbg !1076
  %and33.i = lshr i32 %conv32.i, 6, !dbg !1076
  %14 = and i32 %and33.i, 4, !dbg !1076
  %cond35.i = zext nneg i32 %14 to i64, !dbg !1076
  %add.ptr36.i = getelementptr inbounds i8, ptr %add.ptr30.i, i64 %cond35.i, !dbg !1076
  %and39.i = shl nuw nsw i32 %conv32.i, 2, !dbg !1076
  %15 = and i32 %and39.i, 8, !dbg !1076
  %cond41.i = zext nneg i32 %15 to i64, !dbg !1076
  %add.ptr42.i = getelementptr inbounds i8, ptr %add.ptr36.i, i64 %cond41.i, !dbg !1076
  %16 = load i32, ptr %nbytes.i, align 8, !dbg !1077, !tbaa !1072
  %idx.ext44.i = sext i32 %16 to i64, !dbg !1078
  %add.ptr45.i = getelementptr inbounds i8, ptr %add.ptr42.i, i64 %idx.ext44.i, !dbg !1078
  %add.ptr46.i = getelementptr inbounds i8, ptr %add.ptr45.i, i64 -1, !dbg !1079
  store i8 10, ptr %add.ptr46.i, align 1, !dbg !1080, !tbaa !1056
  br label %if.end60.i, !dbg !1081

if.else.i:                                        ; preds = %sw.bb
  %ritem.i = getelementptr inbounds i8, ptr %c, i64 208, !dbg !1082
  %17 = load ptr, ptr %ritem.i, align 8, !dbg !1082, !tbaa !1083
  tail call void @llvm.dbg.value(metadata ptr %17, metadata !1041, metadata !DIExpression()), !dbg !1084
  %size.i = getelementptr inbounds i8, ptr %17, i64 24, !dbg !1085
  %18 = load i32, ptr %size.i, align 8, !dbg !1085, !tbaa !1072
  %used.i = getelementptr inbounds i8, ptr %17, i64 28, !dbg !1087
  %19 = load i32, ptr %used.i, align 4, !dbg !1087, !tbaa !1072
  %cmp47.i = icmp eq i32 %18, %19, !dbg !1088
  br i1 %cmp47.i, label %if.then49.i, label %if.end.i, !dbg !1089

if.then49.i:                                      ; preds = %if.else.i
  %20 = load ptr, ptr %17, align 8, !dbg !1090, !tbaa !1091
  tail call void @llvm.dbg.value(metadata ptr %20, metadata !1041, metadata !DIExpression()), !dbg !1084
  %used51.phi.trans.insert.i = getelementptr inbounds i8, ptr %20, i64 28
  %.pre.i = load i32, ptr %used51.phi.trans.insert.i, align 4, !dbg !1092, !tbaa !1072
  br label %if.end.i, !dbg !1093

if.end.i:                                         ; preds = %if.then49.i, %if.else.i
  %21 = phi i32 [ %.pre.i, %if.then49.i ], [ %19, %if.else.i ], !dbg !1092
  %ch.0.i = phi ptr [ %20, %if.then49.i ], [ %17, %if.else.i ], !dbg !1084
  tail call void @llvm.dbg.value(metadata ptr %ch.0.i, metadata !1041, metadata !DIExpression()), !dbg !1084
  %data50.i = getelementptr inbounds i8, ptr %ch.0.i, i64 42, !dbg !1094
  %used51.i = getelementptr inbounds i8, ptr %ch.0.i, i64 28, !dbg !1092
  %idxprom52.i = sext i32 %21 to i64, !dbg !1095
  %arrayidx53.i = getelementptr inbounds [0 x i8], ptr %data50.i, i64 0, i64 %idxprom52.i, !dbg !1095
  store i8 13, ptr %arrayidx53.i, align 1, !dbg !1096, !tbaa !1056
  %22 = load i32, ptr %used51.i, align 4, !dbg !1097, !tbaa !1072
  %add.i = add nsw i32 %22, 1, !dbg !1098
  %idxprom56.i = sext i32 %add.i to i64, !dbg !1099
  %arrayidx57.i = getelementptr inbounds [0 x i8], ptr %data50.i, i64 0, i64 %idxprom56.i, !dbg !1099
  store i8 10, ptr %arrayidx57.i, align 1, !dbg !1100, !tbaa !1056
  %23 = load i32, ptr %used51.i, align 4, !dbg !1101, !tbaa !1072
  %add59.i = add nsw i32 %23, 2, !dbg !1101
  store i32 %add59.i, ptr %used51.i, align 4, !dbg !1101, !tbaa !1072
  br label %if.end60.i

if.end60.i:                                       ; preds = %if.end.i, %if.then.i
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %cas.i) #11, !dbg !1102
  store i64 0, ptr %cas.i, align 8, !dbg !1103, !tbaa !1104, !DIAssignID !1105
  tail call void @llvm.dbg.assign(metadata i64 0, metadata !1033, metadata !DIExpression(), metadata !1105, metadata ptr %cas.i, metadata !DIExpression()), !dbg !1044
  %sfd.i = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1106
  %24 = load i32, ptr %sfd.i, align 8, !dbg !1106, !tbaa !1107
  %25 = load ptr, ptr %thread.i, align 8, !dbg !1108, !tbaa !1050
  %cur_sfd.i = getelementptr inbounds i8, ptr %25, i64 344, !dbg !1109
  store i32 %24, ptr %cur_sfd.i, align 8, !dbg !1110, !tbaa !1111
  %cmd.i = getelementptr inbounds i8, ptr %c, i64 432, !dbg !1116
  %26 = load i16, ptr %cmd.i, align 8, !dbg !1116, !tbaa !1117
  %conv62.i = sext i16 %26 to i32, !dbg !1118
  %27 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 18), align 8, !dbg !1119, !tbaa !1120, !range !1123, !noundef !1124
  %tobool64.i = trunc nuw i8 %27 to i1, !dbg !1119
  br i1 %tobool64.i, label %cond.true.i, label %cond.end.i, !dbg !1125

cond.true.i:                                      ; preds = %if.end60.i
  %call66.i = tail call i64 @get_cas_id() #11, !dbg !1126
  br label %cond.end.i, !dbg !1125

cond.end.i:                                       ; preds = %cond.true.i, %if.end60.i
  %cond67.i = phi i64 [ %call66.i, %cond.true.i ], [ 0, %if.end60.i ], !dbg !1125
  %call68.i = call i32 @store_item(ptr noundef nonnull %1, i32 noundef %conv62.i, ptr noundef nonnull %25, ptr noundef null, ptr noundef nonnull %cas.i, i64 noundef %cond67.i, i1 noundef zeroext false) #11, !dbg !1127
  tail call void @llvm.dbg.value(metadata i32 %call68.i, metadata !1039, metadata !DIExpression()), !dbg !1044
  %28 = load i64, ptr %cas.i, align 8, !dbg !1128, !tbaa !1104
  %cas69.i = getelementptr inbounds i8, ptr %c, i64 416, !dbg !1129
  store i64 %28, ptr %cas69.i, align 8, !dbg !1130, !tbaa !1131
  switch i32 %call68.i, label %complete_update_bin.exit [
    i32 1, label %sw.bb.i
    i32 2, label %sw.bb70.i
    i32 3, label %sw.bb71.i
    i32 0, label %sw.bb72.i
    i32 4, label %sw.bb72.i
    i32 5, label %sw.bb72.i
  ], !dbg !1132

sw.bb.i:                                          ; preds = %cond.end.i
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1133, metadata !DIExpression()), !dbg !1145
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1138, metadata !DIExpression()), !dbg !1145
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1139, metadata !DIExpression()), !dbg !1145
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1140, metadata !DIExpression()), !dbg !1145
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1141, metadata !DIExpression()), !dbg !1145
  %noreply.i.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !1148
  %29 = load i8, ptr %noreply.i.i, align 4, !dbg !1148, !tbaa !1149, !range !1123, !noundef !1124
  %tobool.i.i = trunc nuw i8 %29 to i1, !dbg !1148
  br i1 %tobool.i.i, label %lor.lhs.false.i.i, label %if.then.i.i, !dbg !1150

lor.lhs.false.i.i:                                ; preds = %sw.bb.i
  %30 = load i16, ptr %cmd.i, align 8, !dbg !1151, !tbaa !1117
  switch i16 %30, label %write_bin_response.exit.i [
    i16 0, label %if.then.i.i
    i16 12, label %if.then.i.i
  ], !dbg !1152

if.then.i.i:                                      ; preds = %lor.lhs.false.i.i, %lor.lhs.false.i.i, %sw.bb.i
  call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 0, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 0), !dbg !1153
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1142, metadata !DIExpression()), !dbg !1154
  br label %write_bin_response.exit.i

write_bin_response.exit.i:                        ; preds = %if.then.i.i, %lor.lhs.false.i.i
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 1) #11, !dbg !1155
  br label %complete_update_bin.exit, !dbg !1156

sw.bb70.i:                                        ; preds = %cond.end.i
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !1168
  tail call void @llvm.dbg.value(metadata i32 2, metadata !1164, metadata !DIExpression()), !dbg !1168
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1165, metadata !DIExpression()), !dbg !1168
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !1168
  tail call void @llvm.dbg.value(metadata ptr @.str.10, metadata !1165, metadata !DIExpression()), !dbg !1168
  tail call void @llvm.dbg.value(metadata ptr @.str.10, metadata !1165, metadata !DIExpression()), !dbg !1168
  %31 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1170, !tbaa !1172
  %cmp.i.i = icmp sgt i32 %31, 1, !dbg !1173
  br i1 %cmp.i.i, label %if.then9.i.i, label %if.end12.i.i, !dbg !1174

if.then9.i.i:                                     ; preds = %sw.bb70.i
  %32 = load ptr, ptr @stderr, align 8, !dbg !1175, !tbaa !1091
  %33 = load i32, ptr %sfd.i, align 8, !dbg !1177, !tbaa !1107
  %call11.i.i = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %32, ptr noundef nonnull @.str.17, i32 noundef %33, ptr noundef nonnull @.str.10) #12, !dbg !1178
  br label %if.end12.i.i, !dbg !1179

if.end12.i.i:                                     ; preds = %if.then9.i.i, %sw.bb70.i
  tail call void @llvm.dbg.value(metadata i64 20, metadata !1167, metadata !DIExpression()), !dbg !1168
  call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 2, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 20), !dbg !1180
  %resp.i.i = getelementptr inbounds i8, ptr %c, i64 192, !dbg !1181
  %34 = load ptr, ptr %resp.i.i, align 8, !dbg !1181, !tbaa !1184
  call void @resp_add_iov(ptr noundef %34, ptr noundef nonnull @.str.10, i32 noundef 20) #11, !dbg !1185
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 9) #11, !dbg !1186
  br label %complete_update_bin.exit, !dbg !1188

sw.bb71.i:                                        ; preds = %cond.end.i
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !1189
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1164, metadata !DIExpression()), !dbg !1189
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1165, metadata !DIExpression()), !dbg !1189
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !1189
  tail call void @llvm.dbg.value(metadata ptr @.str.8, metadata !1165, metadata !DIExpression()), !dbg !1189
  tail call void @llvm.dbg.value(metadata ptr @.str.8, metadata !1165, metadata !DIExpression()), !dbg !1189
  %35 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1191, !tbaa !1172
  %cmp.i129.i = icmp sgt i32 %35, 1, !dbg !1192
  br i1 %cmp.i129.i, label %if.then9.i136.i, label %if.end12.i130.i, !dbg !1193

if.then9.i136.i:                                  ; preds = %sw.bb71.i
  %36 = load ptr, ptr @stderr, align 8, !dbg !1194, !tbaa !1091
  %37 = load i32, ptr %sfd.i, align 8, !dbg !1195, !tbaa !1107
  %call11.i138.i = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %36, ptr noundef nonnull @.str.17, i32 noundef %37, ptr noundef nonnull @.str.8) #12, !dbg !1196
  br label %if.end12.i130.i, !dbg !1197

if.end12.i130.i:                                  ; preds = %if.then9.i136.i, %sw.bb71.i
  tail call void @llvm.dbg.value(metadata i64 9, metadata !1167, metadata !DIExpression()), !dbg !1189
  call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 1, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 9), !dbg !1198
  %resp.i135.i = getelementptr inbounds i8, ptr %c, i64 192, !dbg !1199
  %38 = load ptr, ptr %resp.i135.i, align 8, !dbg !1199, !tbaa !1184
  call void @resp_add_iov(ptr noundef %38, ptr noundef nonnull @.str.8, i32 noundef 9) #11, !dbg !1200
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 9) #11, !dbg !1201
  br label %complete_update_bin.exit, !dbg !1202

sw.bb72.i:                                        ; preds = %cond.end.i, %cond.end.i, %cond.end.i
  %39 = load i16, ptr %cmd.i, align 8, !dbg !1203, !tbaa !1117
  %switch.selectcmp.i = icmp eq i16 %39, 3, !dbg !1205
  %switch.select.i = select i1 %switch.selectcmp.i, i32 1, i32 5, !dbg !1205
  %switch.selectcmp125.i = icmp eq i16 %39, 1, !dbg !1205
  %switch.select126.i = select i1 %switch.selectcmp125.i, i32 2, i32 %switch.select.i, !dbg !1205
  tail call void @llvm.dbg.value(metadata i32 %switch.select126.i, metadata !1037, metadata !DIExpression()), !dbg !1044
  call void @write_bin_error(ptr noundef nonnull %c, i32 noundef %switch.select126.i, ptr noundef null, i32 noundef 0), !dbg !1206
  br label %complete_update_bin.exit, !dbg !1207

complete_update_bin.exit:                         ; preds = %cond.end.i, %write_bin_response.exit.i, %if.end12.i.i, %if.end12.i130.i, %sw.bb72.i
  %40 = load ptr, ptr %item.i, align 8, !dbg !1208, !tbaa !1048
  call void @item_remove(ptr noundef %40) #11, !dbg !1209
  store ptr null, ptr %item.i, align 8, !dbg !1210, !tbaa !1048
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %cas.i) #11, !dbg !1211
  br label %sw.epilog, !dbg !1212

sw.bb1:                                           ; preds = %entry
  tail call fastcc void @process_bin_complete_sasl_auth(ptr noundef nonnull %c), !dbg !1213
  %item = getelementptr inbounds i8, ptr %c, i64 224, !dbg !1214
  %41 = load ptr, ptr %item, align 8, !dbg !1214, !tbaa !1048
  %tobool.not = icmp eq ptr %41, null, !dbg !1216
  br i1 %tobool.not, label %sw.epilog, label %if.then, !dbg !1217

if.then:                                          ; preds = %sw.bb1
  tail call void @do_item_remove(ptr noundef nonnull %41) #11, !dbg !1218
  store ptr null, ptr %item, align 8, !dbg !1220, !tbaa !1048
  br label %sw.epilog, !dbg !1221

sw.default:                                       ; preds = %entry
  %42 = load ptr, ptr @stderr, align 8, !dbg !1222, !tbaa !1091
  %call = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %42, ptr noundef nonnull @.str, i32 noundef %0) #12, !dbg !1223
  br label %sw.epilog, !dbg !1224

sw.epilog:                                        ; preds = %sw.bb1, %if.then, %sw.default, %complete_update_bin.exit
  ret void, !dbg !1225
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_bin_complete_sasl_auth(ptr noundef %c) unnamed_addr #0 !dbg !1226 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1228, metadata !DIExpression()), !dbg !1240
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1229, metadata !DIExpression()), !dbg !1240
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1230, metadata !DIExpression()), !dbg !1240
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1241, metadata !DIExpression()), !dbg !1247
  %0 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 25), align 4, !dbg !1249, !tbaa !1251, !range !1123, !noundef !1124
  %tobool.i = trunc nuw i8 %0 to i1, !dbg !1249
  br i1 %tobool.i, label %if.end.i, label %init_sasl_conn.exit, !dbg !1252

if.end.i:                                         ; preds = %entry
  %authenticated.i = getelementptr inbounds i8, ptr %c, i64 13, !dbg !1253
  store i8 0, ptr %authenticated.i, align 1, !dbg !1254, !tbaa !1255
  %1 = load ptr, ptr %c, align 8, !dbg !1256, !tbaa !1257
  %tobool1.not.i = icmp eq ptr %1, null, !dbg !1258
  br i1 %tobool1.not.i, label %if.then3.i, label %init_sasl_conn.exit, !dbg !1259

if.then3.i:                                       ; preds = %if.end.i
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1244, metadata !DIExpression()), !dbg !1260
  %2 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1261, !tbaa !1172
  %tobool4.not.i = icmp eq i32 %2, 0, !dbg !1265
  br i1 %tobool4.not.i, label %if.end6.i, label %if.then5.i, !dbg !1266

if.then5.i:                                       ; preds = %if.then3.i
  %3 = load ptr, ptr @stderr, align 8, !dbg !1267, !tbaa !1091
  %4 = tail call i64 @fwrite(ptr nonnull @.str.26, i64 32, i64 1, ptr %3) #13, !dbg !1269
  br label %if.end6.i, !dbg !1270

if.end6.i:                                        ; preds = %if.then5.i, %if.then3.i
  store ptr null, ptr %c, align 8, !dbg !1271, !tbaa !1257
  br label %init_sasl_conn.exit, !dbg !1272

init_sasl_conn.exit:                              ; preds = %entry, %if.end.i, %if.end6.i
  %keylen = getelementptr inbounds i8, ptr %c, i64 394, !dbg !1273
  %5 = load i16, ptr %keylen, align 2, !dbg !1273, !tbaa !1056
  tail call void @llvm.dbg.value(metadata i16 %5, metadata !1231, metadata !DIExpression()), !dbg !1240
  %bodylen = getelementptr inbounds i8, ptr %c, i64 400, !dbg !1274
  %6 = load i32, ptr %bodylen, align 8, !dbg !1274, !tbaa !1056
  %conv = zext i16 %5 to i32, !dbg !1275
  %sub = sub i32 %6, %conv, !dbg !1276
  tail call void @llvm.dbg.value(metadata i32 %sub, metadata !1232, metadata !DIExpression()), !dbg !1240
  %item = getelementptr inbounds i8, ptr %c, i64 224, !dbg !1277
  %7 = load ptr, ptr %item, align 8, !dbg !1277, !tbaa !1048
  %nkey3 = getelementptr inbounds i8, ptr %7, i64 41, !dbg !1279
  %8 = load i8, ptr %nkey3, align 1, !dbg !1279, !tbaa !1056
  %9 = zext i8 %8 to i16, !dbg !1280
  %cmp = icmp ugt i16 %5, %9, !dbg !1280
  br i1 %cmp, label %if.then, label %if.end, !dbg !1281

if.then:                                          ; preds = %init_sasl_conn.exit
  tail call void @write_bin_error(ptr noundef nonnull %c, i32 noundef 4, ptr noundef null, i32 noundef %sub), !dbg !1282
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 7) #11, !dbg !1284
  br label %cleanup102, !dbg !1285

if.end:                                           ; preds = %init_sasl_conn.exit
  %add = add nuw nsw i32 %conv, 1, !dbg !1286
  %10 = zext nneg i32 %add to i64, !dbg !1287
  %11 = tail call ptr @llvm.stacksave.p0(), !dbg !1287
  %vla = alloca i8, i64 %10, align 16, !dbg !1287
  tail call void @llvm.dbg.value(metadata i64 %10, metadata !1233, metadata !DIExpression()), !dbg !1240
  tail call void @llvm.dbg.declare(metadata ptr %vla, metadata !1234, metadata !DIExpression()), !dbg !1288
  %12 = load ptr, ptr %item, align 8, !dbg !1289, !tbaa !1048
  %data = getelementptr inbounds i8, ptr %12, i64 48, !dbg !1289
  %it_flags = getelementptr inbounds i8, ptr %12, i64 38, !dbg !1289
  %13 = load i16, ptr %it_flags, align 2, !dbg !1289, !tbaa !1064
  %14 = shl i16 %13, 2, !dbg !1289
  %15 = and i16 %14, 8, !dbg !1289
  %cond = zext nneg i16 %15 to i64, !dbg !1289
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %cond, !dbg !1289
  %conv10 = zext nneg i16 %5 to i64, !dbg !1290
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 16 %vla, ptr nonnull align 1 %add.ptr, i64 %conv10, i1 false), !dbg !1291
  %arrayidx = getelementptr inbounds i8, ptr %vla, i64 %conv10, !dbg !1292
  store i8 0, ptr %arrayidx, align 1, !dbg !1293, !tbaa !1056
  %16 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1294, !tbaa !1172
  %tobool11.not = icmp eq i32 %16, 0, !dbg !1296
  br i1 %tobool11.not, label %if.end13, label %if.then12, !dbg !1297

if.then12:                                        ; preds = %if.end
  %17 = load ptr, ptr @stderr, align 8, !dbg !1298, !tbaa !1091
  %call = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %17, ptr noundef nonnull @.str.20, ptr noundef nonnull %vla, i32 noundef %sub) #12, !dbg !1299
  %.pre.pre = load ptr, ptr %item, align 8, !dbg !1300, !tbaa !1048
  br label %if.end13, !dbg !1299

if.end13:                                         ; preds = %if.then12, %if.end
  %.pre = phi ptr [ %.pre.pre, %if.then12 ], [ %12, %if.end ], !dbg !1300
  %cmp14 = icmp eq i32 %6, %conv, !dbg !1302
  br i1 %cmp14, label %cond.end, label %cond.false, !dbg !1303

cond.false:                                       ; preds = %if.end13
  %data17 = getelementptr inbounds i8, ptr %.pre, i64 48, !dbg !1304
  %nkey19 = getelementptr inbounds i8, ptr %.pre, i64 41, !dbg !1304
  %18 = load i8, ptr %nkey19, align 1, !dbg !1304, !tbaa !1056
  %idx.ext = zext i8 %18 to i64
  %add.ptr21 = getelementptr inbounds i8, ptr %data17, i64 %idx.ext, !dbg !1304
  %add.ptr22 = getelementptr inbounds i8, ptr %add.ptr21, i64 1, !dbg !1304
  %it_flags24 = getelementptr inbounds i8, ptr %.pre, i64 38, !dbg !1304
  %19 = load i16, ptr %it_flags24, align 2, !dbg !1304, !tbaa !1064
  %conv25 = zext i16 %19 to i32, !dbg !1304
  %and26 = lshr i32 %conv25, 6, !dbg !1304
  %20 = and i32 %and26, 4, !dbg !1304
  %cond28 = zext nneg i32 %20 to i64, !dbg !1304
  %add.ptr29 = getelementptr inbounds i8, ptr %add.ptr22, i64 %cond28, !dbg !1304
  %and33 = shl nuw nsw i32 %conv25, 2, !dbg !1304
  %21 = and i32 %and33, 8, !dbg !1304
  %cond35 = zext nneg i32 %21 to i64, !dbg !1304
  %add.ptr36 = getelementptr inbounds i8, ptr %add.ptr29, i64 %cond35, !dbg !1304
  br label %cond.end, !dbg !1303

cond.end:                                         ; preds = %if.end13, %cond.false
  %cond37 = phi ptr [ %add.ptr36, %cond.false ], [ null, %if.end13 ], !dbg !1303
  tail call void @llvm.dbg.value(metadata ptr %cond37, metadata !1238, metadata !DIExpression()), !dbg !1240
  %nbytes = getelementptr inbounds i8, ptr %.pre, i64 32, !dbg !1305
  %22 = load i32, ptr %nbytes, align 8, !dbg !1305, !tbaa !1072
  %cmp39 = icmp sgt i32 %sub, %22, !dbg !1306
  br i1 %cmp39, label %if.then41, label %if.end42, !dbg !1307

if.then41:                                        ; preds = %cond.end
  call void @write_bin_error(ptr noundef nonnull %c, i32 noundef 4, ptr noundef null, i32 noundef %sub), !dbg !1308
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 7) #11, !dbg !1310
  br label %cleanup, !dbg !1311

if.end42:                                         ; preds = %cond.end
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !1239, metadata !DIExpression()), !dbg !1240
  %cmd = getelementptr inbounds i8, ptr %c, i64 432, !dbg !1312
  %23 = load i16, ptr %cmd, align 8, !dbg !1312, !tbaa !1117
  %conv43 = sext i16 %23 to i32, !dbg !1313
  switch i16 %23, label %sw.default [
    i16 33, label %lor.end
    i16 34, label %sw.bb48
  ], !dbg !1314

lor.end:                                          ; preds = %if.end42
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1239, metadata !DIExpression()), !dbg !1240
  %sasl_started = getelementptr inbounds i8, ptr %c, i64 12, !dbg !1315
  store i8 0, ptr %sasl_started, align 4, !dbg !1317, !tbaa !1318
  br label %sw.epilog, !dbg !1319

sw.bb48:                                          ; preds = %if.end42
  %sasl_started49 = getelementptr inbounds i8, ptr %c, i64 12, !dbg !1320
  %24 = load i8, ptr %sasl_started49, align 4, !dbg !1320, !tbaa !1318, !range !1123, !noundef !1124
  %tobool50 = trunc nuw i8 %24 to i1, !dbg !1320
  br i1 %tobool50, label %sw.epilog, label %if.then51, !dbg !1322

if.then51:                                        ; preds = %sw.bb48
  %25 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1323, !tbaa !1172
  %tobool52.not = icmp eq i32 %25, 0, !dbg !1326
  br i1 %tobool52.not, label %sw.bb75, label %if.then53, !dbg !1327

if.then53:                                        ; preds = %if.then51
  %26 = load ptr, ptr @stderr, align 8, !dbg !1328, !tbaa !1091
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1330
  %27 = load i32, ptr %sfd, align 8, !dbg !1330, !tbaa !1107
  %call54 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %26, ptr noundef nonnull @.str.21, i32 noundef %27) #12, !dbg !1331
  br label %sw.epilog, !dbg !1332

sw.default:                                       ; preds = %if.end42
  %28 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1333, !tbaa !1172
  %tobool57.not = icmp eq i32 %28, 0, !dbg !1335
  br i1 %tobool57.not, label %sw.bb75, label %if.then58, !dbg !1336

if.then58:                                        ; preds = %sw.default
  %29 = load ptr, ptr @stderr, align 8, !dbg !1337, !tbaa !1091
  %call61 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %29, ptr noundef nonnull @.str.22, i32 noundef %conv43, ptr noundef %cond37) #12, !dbg !1339
  br label %sw.epilog, !dbg !1340

sw.epilog:                                        ; preds = %sw.bb48, %if.then58, %if.then53, %lor.end
  %cond152 = phi i1 [ false, %sw.bb48 ], [ false, %lor.end ], [ true, %if.then53 ], [ true, %if.then58 ]
  %result.0.ph = phi i32 [ 1, %sw.bb48 ], [ 1, %lor.end ], [ -1, %if.then53 ], [ -1, %if.then58 ]
  %.pr = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1341, !tbaa !1172
  tail call void @llvm.dbg.value(metadata i32 %result.0.ph, metadata !1239, metadata !DIExpression()), !dbg !1240
  %tobool63.not = icmp eq i32 %.pr, 0, !dbg !1343
  br i1 %tobool63.not, label %if.end66, label %if.then64, !dbg !1344

if.then64:                                        ; preds = %sw.epilog
  %30 = load ptr, ptr @stderr, align 8, !dbg !1345, !tbaa !1091
  %call65 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %30, ptr noundef nonnull @.str.23, i32 noundef %result.0.ph) #12, !dbg !1347
  br label %if.end66, !dbg !1348

if.end66:                                         ; preds = %if.then64, %sw.epilog
  br i1 %cond152, label %sw.bb75, label %sw.default80, !dbg !1349

sw.bb75:                                          ; preds = %sw.default, %if.then51, %if.end66
  call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 33, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 0), !dbg !1350
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 9) #11, !dbg !1352
  br label %cleanup, !dbg !1353

sw.default80:                                     ; preds = %if.end66
  %31 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1354, !tbaa !1172
  %tobool81.not = icmp eq i32 %31, 0, !dbg !1356
  br i1 %tobool81.not, label %if.end12.i, label %if.end84, !dbg !1357

if.end84:                                         ; preds = %sw.default80
  %32 = load ptr, ptr @stderr, align 8, !dbg !1358, !tbaa !1091
  %call83 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %32, ptr noundef nonnull @.str.25, i32 noundef %result.0.ph) #12, !dbg !1359
  %.pr159 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1360, !tbaa !1172
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !1362
  tail call void @llvm.dbg.value(metadata i32 32, metadata !1164, metadata !DIExpression()), !dbg !1362
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !1362
  tail call void @llvm.dbg.value(metadata ptr @.str.14, metadata !1165, metadata !DIExpression()), !dbg !1362
  %cmp.i = icmp sgt i32 %.pr159, 1, !dbg !1363
  br i1 %cmp.i, label %if.then9.i, label %if.end12.i, !dbg !1364

if.then9.i:                                       ; preds = %if.end84
  %33 = load ptr, ptr @stderr, align 8, !dbg !1365, !tbaa !1091
  %sfd10.i = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1366
  %34 = load i32, ptr %sfd10.i, align 8, !dbg !1366, !tbaa !1107
  %call11.i = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %33, ptr noundef nonnull @.str.17, i32 noundef %34, ptr noundef nonnull @.str.14) #12, !dbg !1367
  br label %if.end12.i, !dbg !1368

if.end12.i:                                       ; preds = %sw.default80, %if.then9.i, %if.end84
  tail call void @llvm.dbg.value(metadata i64 13, metadata !1167, metadata !DIExpression()), !dbg !1362
  call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 32, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 13), !dbg !1369
  %resp.i = getelementptr inbounds i8, ptr %c, i64 192, !dbg !1370
  %35 = load ptr, ptr %resp.i, align 8, !dbg !1370, !tbaa !1184
  call void @resp_add_iov(ptr noundef %35, ptr noundef nonnull @.str.14, i32 noundef 13) #11, !dbg !1371
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 9) #11, !dbg !1372
  %thread85 = getelementptr inbounds i8, ptr %c, i64 456, !dbg !1373
  %36 = load ptr, ptr %thread85, align 8, !dbg !1373, !tbaa !1050
  %stats86 = getelementptr inbounds i8, ptr %36, i64 352, !dbg !1374
  %call88 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats86) #11, !dbg !1375
  %37 = load ptr, ptr %thread85, align 8, !dbg !1376, !tbaa !1050
  %auth_cmds91 = getelementptr inbounds i8, ptr %37, i64 512, !dbg !1377
  %38 = load <2 x i64>, ptr %auth_cmds91, align 8, !dbg !1378, !tbaa !1104
  %39 = add <2 x i64> %38, <i64 1, i64 1>, !dbg !1378
  store <2 x i64> %39, ptr %auth_cmds91, align 8, !dbg !1378, !tbaa !1104
  %stats97 = getelementptr inbounds i8, ptr %37, i64 352, !dbg !1379
  %call99 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats97) #11, !dbg !1380
  br label %cleanup, !dbg !1381

cleanup:                                          ; preds = %sw.bb75, %if.end12.i, %if.then41
  call void @llvm.stackrestore.p0(ptr %11), !dbg !1382
  br label %cleanup102

cleanup102:                                       ; preds = %cleanup, %if.then
  ret void, !dbg !1382
}

declare !dbg !1383 void @do_item_remove(ptr noundef) local_unnamed_addr #1

; Function Attrs: nofree nounwind
declare !dbg !1387 noundef i32 @fprintf(ptr nocapture noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #2

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef i32 @try_read_command_binary(ptr noundef %c) local_unnamed_addr #0 !dbg !1443 {
entry:
  %extbuf = alloca [48 x i8], align 16, !DIAssignID !1459
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1455, metadata !DIExpression(), metadata !1459, metadata ptr %extbuf, metadata !DIExpression()), !dbg !1460
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1445, metadata !DIExpression()), !dbg !1461
  %rbytes = getelementptr inbounds i8, ptr %c, i64 188, !dbg !1462
  %0 = load i32, ptr %rbytes, align 4, !dbg !1462, !tbaa !1463
  %cmp = icmp ult i32 %0, 24, !dbg !1464
  br i1 %cmp, label %return, label %if.else, !dbg !1465

if.else:                                          ; preds = %entry
  %binary_header = getelementptr inbounds i8, ptr %c, i64 392, !dbg !1466
  %rcurr = getelementptr inbounds i8, ptr %c, i64 176, !dbg !1467
  %1 = load ptr, ptr %rcurr, align 8, !dbg !1467, !tbaa !1468
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %binary_header, ptr noundef nonnull align 1 dereferenceable(24) %1, i64 24, i1 false), !dbg !1469
  tail call void @llvm.dbg.value(metadata ptr %binary_header, metadata !1446, metadata !DIExpression()), !dbg !1460
  %2 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1470, !tbaa !1172
  %cmp3 = icmp sgt i32 %2, 1, !dbg !1471
  br i1 %cmp3, label %if.then5, label %if.end17, !dbg !1472

if.then5:                                         ; preds = %if.else
  %3 = load ptr, ptr @stderr, align 8, !dbg !1473, !tbaa !1091
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1474
  %4 = load i32, ptr %sfd, align 8, !dbg !1474, !tbaa !1107
  %call = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %3, ptr noundef nonnull @.str.1, i32 noundef %4) #12, !dbg !1475
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1450, metadata !DIExpression()), !dbg !1476
  br label %for.body, !dbg !1477

for.body:                                         ; preds = %if.then5, %if.end
  %indvars.iv = phi i64 [ 0, %if.then5 ], [ %indvars.iv.next, %if.end ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1450, metadata !DIExpression()), !dbg !1476
  %rem141 = and i64 %indvars.iv, 3, !dbg !1479
  %cmp9 = icmp eq i64 %rem141, 0, !dbg !1479
  br i1 %cmp9, label %if.then11, label %if.end, !dbg !1483

if.then11:                                        ; preds = %for.body
  %5 = load ptr, ptr @stderr, align 8, !dbg !1484, !tbaa !1091
  %6 = load i32, ptr %sfd, align 8, !dbg !1486, !tbaa !1107
  %call13 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %5, ptr noundef nonnull @.str.2, i32 noundef %6) #12, !dbg !1487
  br label %if.end, !dbg !1488

if.end:                                           ; preds = %if.then11, %for.body
  %7 = load ptr, ptr @stderr, align 8, !dbg !1489, !tbaa !1091
  %arrayidx = getelementptr inbounds [24 x i8], ptr %binary_header, i64 0, i64 %indvars.iv, !dbg !1490
  %8 = load i8, ptr %arrayidx, align 1, !dbg !1490, !tbaa !1056
  %conv14 = zext i8 %8 to i32, !dbg !1490
  %call15 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %7, ptr noundef nonnull @.str.3, i32 noundef %conv14) #12, !dbg !1491
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !1492
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !1450, metadata !DIExpression()), !dbg !1476
  %exitcond.not = icmp eq i64 %indvars.iv.next, 24, !dbg !1493
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !1477, !llvm.loop !1494

for.end:                                          ; preds = %if.end
  %9 = load ptr, ptr @stderr, align 8, !dbg !1497, !tbaa !1091
  %fputc = tail call i32 @fputc(i32 10, ptr %9), !dbg !1498
  br label %if.end17, !dbg !1499

if.end17:                                         ; preds = %for.end, %if.else
  %keylen = getelementptr inbounds i8, ptr %c, i64 394, !dbg !1500
  %10 = load i16, ptr %keylen, align 2, !dbg !1500, !tbaa !1056
  %rev.i = tail call noundef i16 @llvm.bswap.i16(i16 %10)
  store i16 %rev.i, ptr %keylen, align 2, !dbg !1501, !tbaa !1056
  %bodylen = getelementptr inbounds i8, ptr %c, i64 400, !dbg !1502
  %11 = load i32, ptr %bodylen, align 8, !dbg !1502, !tbaa !1056
  tail call void @llvm.dbg.value(metadata i32 %11, metadata !1503, metadata !DIExpression()), !dbg !1509
  %or7.i = tail call noundef i32 @llvm.bswap.i32(i32 %11), !dbg !1511
  store i32 %or7.i, ptr %bodylen, align 8, !dbg !1512, !tbaa !1056
  %cas = getelementptr inbounds i8, ptr %c, i64 408, !dbg !1513
  %12 = load i64, ptr %cas, align 8, !dbg !1513, !tbaa !1056
  %call25 = tail call i64 @ntohll(i64 noundef %12) #11, !dbg !1514
  store i64 %call25, ptr %cas, align 8, !dbg !1515, !tbaa !1056
  %13 = load i8, ptr %binary_header, align 8, !dbg !1516, !tbaa !1056
  %conv29 = zext i8 %13 to i32, !dbg !1518
  %cmp30.not = icmp eq i8 %13, -128, !dbg !1519
  br i1 %cmp30.not, label %if.end39, label %if.then32, !dbg !1520

if.then32:                                        ; preds = %if.end17
  %14 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1521, !tbaa !1172
  %tobool.not = icmp eq i32 %14, 0, !dbg !1524
  br i1 %tobool.not, label %if.end38, label %if.then33, !dbg !1525

if.then33:                                        ; preds = %if.then32
  %15 = load ptr, ptr @stderr, align 8, !dbg !1526, !tbaa !1091
  %call37 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %15, ptr noundef nonnull @.str.5, i32 noundef %conv29) #12, !dbg !1528
  br label %if.end38, !dbg !1529

if.end38:                                         ; preds = %if.then33, %if.then32
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 8) #11, !dbg !1530
  br label %return, !dbg !1531

if.end39:                                         ; preds = %if.end17
  %extlen41 = getelementptr inbounds i8, ptr %c, i64 396, !dbg !1532
  %16 = load i8, ptr %extlen41, align 4, !dbg !1532, !tbaa !1056
  tail call void @llvm.dbg.value(metadata i8 %16, metadata !1453, metadata !DIExpression()), !dbg !1460
  %17 = load i16, ptr %keylen, align 2, !dbg !1533, !tbaa !1056
  tail call void @llvm.dbg.value(metadata i16 %17, metadata !1454, metadata !DIExpression()), !dbg !1460
  %18 = load i32, ptr %rbytes, align 4, !dbg !1534, !tbaa !1463
  %conv47 = zext i16 %17 to i32, !dbg !1536
  %conv48 = zext i8 %16 to i32, !dbg !1537
  %add = add nuw nsw i32 %conv48, 24, !dbg !1538
  %narrow = add nuw nsw i32 %add, %conv47, !dbg !1539
  %cmp51 = icmp ult i32 %18, %narrow, !dbg !1540
  br i1 %cmp51, label %return, label %if.end54, !dbg !1541

if.end54:                                         ; preds = %if.end39
  %call55 = tail call zeroext i1 @resp_start(ptr noundef nonnull %c) #11, !dbg !1542
  br i1 %call55, label %if.end57, label %if.then56, !dbg !1544

if.then56:                                        ; preds = %if.end54
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 8) #11, !dbg !1545
  br label %return, !dbg !1547

if.end57:                                         ; preds = %if.end54
  %opcode = getelementptr inbounds i8, ptr %c, i64 393, !dbg !1548
  %19 = load i8, ptr %opcode, align 1, !dbg !1548, !tbaa !1056
  %conv59 = zext i8 %19 to i16, !dbg !1549
  %cmd = getelementptr inbounds i8, ptr %c, i64 432, !dbg !1550
  store i16 %conv59, ptr %cmd, align 8, !dbg !1551, !tbaa !1117
  %20 = load i16, ptr %keylen, align 2, !dbg !1552, !tbaa !1056
  %conv62 = zext i16 %20 to i32, !dbg !1553
  %keylen63 = getelementptr inbounds i8, ptr %c, i64 440, !dbg !1554
  store i32 %conv62, ptr %keylen63, align 8, !dbg !1555, !tbaa !1556
  %opaque = getelementptr inbounds i8, ptr %c, i64 404, !dbg !1557
  %21 = load i32, ptr %opaque, align 4, !dbg !1557, !tbaa !1056
  %opaque65 = getelementptr inbounds i8, ptr %c, i64 436, !dbg !1558
  store i32 %21, ptr %opaque65, align 4, !dbg !1559, !tbaa !1560
  %cas66 = getelementptr inbounds i8, ptr %c, i64 416, !dbg !1561
  store i64 0, ptr %cas66, align 8, !dbg !1562, !tbaa !1131
  %22 = load volatile i32, ptr @current_time, align 4, !dbg !1563, !tbaa !1072
  %last_cmd_time = getelementptr inbounds i8, ptr %c, i64 28, !dbg !1564
  store i32 %22, ptr %last_cmd_time, align 4, !dbg !1565, !tbaa !1566
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %extbuf) #11, !dbg !1567
  %add.ptr = getelementptr inbounds i8, ptr %extbuf, i64 24, !dbg !1568
  %23 = load ptr, ptr %rcurr, align 8, !dbg !1569, !tbaa !1468
  %add.ptr68 = getelementptr inbounds i8, ptr %23, i64 24, !dbg !1570
  %24 = zext i8 %16 to i64
  %spec.select137 = tail call i8 @llvm.umin.i8(i8 %16, i8 20), !dbg !1571
  %spec.select = zext nneg i8 %spec.select137 to i64, !dbg !1571
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %add.ptr, ptr nonnull align 1 %add.ptr68, i64 %spec.select, i1 false), !dbg !1572
  %add75 = add nuw nsw i64 %24, 24, !dbg !1573
  %conv76 = zext i16 %17 to i64, !dbg !1574
  %add77 = add nuw nsw i64 %add75, %conv76, !dbg !1575
  %25 = load i32, ptr %rbytes, align 4, !dbg !1576, !tbaa !1463
  %26 = trunc nuw nsw i64 %add77 to i32, !dbg !1576
  %conv80 = sub i32 %25, %26, !dbg !1576
  store i32 %conv80, ptr %rbytes, align 4, !dbg !1576, !tbaa !1463
  %add.ptr86 = getelementptr inbounds i8, ptr %23, i64 %add77, !dbg !1577
  store ptr %add.ptr86, ptr %rcurr, align 8, !dbg !1577, !tbaa !1468
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1578, metadata !DIExpression()), !dbg !1588
  tail call void @llvm.dbg.value(metadata ptr %extbuf, metadata !1583, metadata !DIExpression()), !dbg !1588
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1584, metadata !DIExpression()), !dbg !1588
  %27 = load i8, ptr %extlen41, align 4, !dbg !1590, !tbaa !1056
  tail call void @llvm.dbg.value(metadata i8 %27, metadata !1585, metadata !DIExpression()), !dbg !1588
  tail call void @llvm.dbg.value(metadata i16 %20, metadata !1586, metadata !DIExpression()), !dbg !1588
  %28 = load i32, ptr %bodylen, align 8, !dbg !1591, !tbaa !1056
  tail call void @llvm.dbg.value(metadata i32 %28, metadata !1587, metadata !DIExpression()), !dbg !1588
  %sfd.i = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1592
  %29 = load i32, ptr %sfd.i, align 8, !dbg !1592, !tbaa !1107
  %thread.i = getelementptr inbounds i8, ptr %c, i64 456, !dbg !1593
  %30 = load ptr, ptr %thread.i, align 8, !dbg !1593, !tbaa !1050
  %cur_sfd.i = getelementptr inbounds i8, ptr %30, i64 344, !dbg !1594
  store i32 %29, ptr %cur_sfd.i, align 8, !dbg !1595, !tbaa !1111
  %cmp.i = icmp ult i32 %28, %conv62, !dbg !1596
  br i1 %cmp.i, label %if.then.i, label %lor.lhs.false.i, !dbg !1598

lor.lhs.false.i:                                  ; preds = %if.end57
  %conv8.i = zext i8 %27 to i32, !dbg !1599
  %add.i = add nuw nsw i32 %conv8.i, %conv62, !dbg !1600
  %cmp9.i = icmp ugt i32 %add.i, %28, !dbg !1601
  br i1 %cmp9.i, label %if.then.i, label %if.end.i, !dbg !1602

if.then.i:                                        ; preds = %lor.lhs.false.i, %if.end57
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !1603
  tail call void @llvm.dbg.value(metadata i32 129, metadata !1164, metadata !DIExpression()), !dbg !1603
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1165, metadata !DIExpression()), !dbg !1603
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !1603
  tail call void @llvm.dbg.value(metadata ptr @.str.7, metadata !1165, metadata !DIExpression()), !dbg !1603
  tail call void @llvm.dbg.value(metadata ptr @.str.7, metadata !1165, metadata !DIExpression()), !dbg !1603
  %31 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1606, !tbaa !1172
  %cmp.i.i = icmp sgt i32 %31, 1, !dbg !1607
  br i1 %cmp.i.i, label %if.then9.i.i, label %if.end12.i.i, !dbg !1608

if.then9.i.i:                                     ; preds = %if.then.i
  %32 = load ptr, ptr @stderr, align 8, !dbg !1609, !tbaa !1091
  %call11.i.i = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %32, ptr noundef nonnull @.str.17, i32 noundef %29, ptr noundef nonnull @.str.7) #12, !dbg !1610
  br label %if.end12.i.i, !dbg !1611

if.end12.i.i:                                     ; preds = %if.then9.i.i, %if.then.i
  tail call void @llvm.dbg.value(metadata i64 15, metadata !1167, metadata !DIExpression()), !dbg !1603
  tail call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 129, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 15), !dbg !1612
  %resp.i.i = getelementptr inbounds i8, ptr %c, i64 192, !dbg !1613
  %33 = load ptr, ptr %resp.i.i, align 8, !dbg !1613, !tbaa !1184
  tail call void @resp_add_iov(ptr noundef %33, ptr noundef nonnull @.str.7, i32 noundef 15) #11, !dbg !1614
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 9) #11, !dbg !1615
  %close_after_write.i = getelementptr inbounds i8, ptr %c, i64 16, !dbg !1616
  store i8 1, ptr %close_after_write.i, align 8, !dbg !1617, !tbaa !1618
  br label %45, !dbg !1619

if.end.i:                                         ; preds = %lor.lhs.false.i
  %34 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 25), align 4, !dbg !1620, !tbaa !1251, !range !1123, !noundef !1124
  %tobool.i = trunc nuw i8 %34 to i1, !dbg !1620
  br i1 %tobool.i, label %land.lhs.true.i, label %if.end14.i, !dbg !1622

land.lhs.true.i:                                  ; preds = %if.end.i
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1623, metadata !DIExpression()), !dbg !1629
  tail call void @llvm.dbg.value(metadata i8 0, metadata !1628, metadata !DIExpression()), !dbg !1629
  %switch.tableidx = add i8 %19, -11, !dbg !1631
  %35 = icmp ult i8 %switch.tableidx, 24, !dbg !1631
  br i1 %35, label %switch.hole_check, label %sw.default.i.i, !dbg !1631

sw.default.i.i:                                   ; preds = %switch.hole_check, %land.lhs.true.i
  %authenticated.i.i = getelementptr inbounds i8, ptr %c, i64 13, !dbg !1632
  %36 = load i8, ptr %authenticated.i.i, align 1, !dbg !1632, !tbaa !1255, !range !1123, !noundef !1124
  tail call void @llvm.dbg.value(metadata i8 %36, metadata !1628, metadata !DIExpression()), !dbg !1629
  %37 = trunc nuw i8 %36 to i1, !dbg !1634
  br label %sw.epilog.i.i, !dbg !1637

switch.hole_check:                                ; preds = %land.lhs.true.i
  %switch.maskindex = zext nneg i8 %switch.tableidx to i32, !dbg !1631
  %switch.shifted = lshr i32 14680065, %switch.maskindex, !dbg !1631
  %switch.lobit = trunc i32 %switch.shifted to i1, !dbg !1631
  br i1 %switch.lobit, label %sw.epilog.i.i, label %sw.default.i.i, !dbg !1631

sw.epilog.i.i:                                    ; preds = %switch.hole_check, %sw.default.i.i
  %rv.0.i.i = phi i1 [ %37, %sw.default.i.i ], [ true, %switch.hole_check ], !dbg !1638
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !1628, metadata !DIExpression()), !dbg !1629
  %38 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1639, !tbaa !1172
  %cmp.i352.i = icmp sgt i32 %38, 1, !dbg !1640
  br i1 %cmp.i352.i, label %if.then.i.i, label %authenticated.exit.i, !dbg !1641

if.then.i.i:                                      ; preds = %sw.epilog.i.i
  %39 = load ptr, ptr @stderr, align 8, !dbg !1642, !tbaa !1091
  %conv3.i.i = zext i8 %19 to i32, !dbg !1643
  %cond.i.i = select i1 %rv.0.i.i, ptr @.str.29, ptr @.str.30, !dbg !1634
  %call.i.i = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %39, ptr noundef nonnull @.str.28, i32 noundef %conv3.i.i, ptr noundef nonnull %cond.i.i) #12, !dbg !1644
  br label %authenticated.exit.i, !dbg !1645

authenticated.exit.i:                             ; preds = %if.then.i.i, %sw.epilog.i.i
  br i1 %rv.0.i.i, label %if.end14.i, label %if.then12.i, !dbg !1646

if.then12.i:                                      ; preds = %authenticated.exit.i
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !1647
  tail call void @llvm.dbg.value(metadata i32 32, metadata !1164, metadata !DIExpression()), !dbg !1647
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1165, metadata !DIExpression()), !dbg !1647
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !1647
  tail call void @llvm.dbg.value(metadata ptr @.str.14, metadata !1165, metadata !DIExpression()), !dbg !1647
  tail call void @llvm.dbg.value(metadata ptr @.str.14, metadata !1165, metadata !DIExpression()), !dbg !1647
  %40 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1650, !tbaa !1172
  %cmp.i354.i = icmp sgt i32 %40, 1, !dbg !1651
  br i1 %cmp.i354.i, label %if.then9.i361.i, label %if.end12.i355.i, !dbg !1652

if.then9.i361.i:                                  ; preds = %if.then12.i
  %41 = load ptr, ptr @stderr, align 8, !dbg !1653, !tbaa !1091
  %42 = load i32, ptr %sfd.i, align 8, !dbg !1654, !tbaa !1107
  %call11.i363.i = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %41, ptr noundef nonnull @.str.17, i32 noundef %42, ptr noundef nonnull @.str.14) #12, !dbg !1655
  br label %if.end12.i355.i, !dbg !1656

if.end12.i355.i:                                  ; preds = %if.then9.i361.i, %if.then12.i
  tail call void @llvm.dbg.value(metadata i64 13, metadata !1167, metadata !DIExpression()), !dbg !1647
  tail call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 32, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 13), !dbg !1657
  %resp.i360.i = getelementptr inbounds i8, ptr %c, i64 192, !dbg !1658
  %43 = load ptr, ptr %resp.i360.i, align 8, !dbg !1658, !tbaa !1184
  tail call void @resp_add_iov(ptr noundef %43, ptr noundef nonnull @.str.14, i32 noundef 13) #11, !dbg !1659
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 9) #11, !dbg !1660
  %close_after_write13.i = getelementptr inbounds i8, ptr %c, i64 16, !dbg !1661
  store i8 1, ptr %close_after_write13.i, align 8, !dbg !1662, !tbaa !1618
  br label %45, !dbg !1663

if.end14.i:                                       ; preds = %authenticated.exit.i, %if.end.i
  %noreply.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !1664
  store i8 1, ptr %noreply.i, align 4, !dbg !1665, !tbaa !1149
  %cmp16.i = icmp ugt i16 %20, 250, !dbg !1666
  br i1 %cmp16.i, label %if.then18.i, label %if.end19.i, !dbg !1668

if.then18.i:                                      ; preds = %if.end14.i
  tail call fastcc void @handle_binary_protocol_error(ptr noundef nonnull %c), !dbg !1669
  br label %45, !dbg !1671

if.end19.i:                                       ; preds = %if.end14.i
  %44 = load i16, ptr %cmd, align 8, !dbg !1672, !tbaa !1117
  switch i16 %44, label %sw.epilog.i [
    i16 17, label %sw.bb97.sink.split.i
    i16 18, label %sw.bb22.i
    i16 19, label %sw.bb24.i
    i16 20, label %sw.epilog.thread374.i
    i16 21, label %sw.bb143.sink.split.i
    i16 22, label %sw.bb30.i
    i16 23, label %sw.epilog.thread375.i
    i16 24, label %sw.epilog.thread373.i
    i16 25, label %sw.bb160.sink.split.i
    i16 26, label %sw.bb38.i
    i16 9, label %sw.bb113.sink.split.i
    i16 13, label %sw.bb42.i
    i16 30, label %sw.bb218.sink.split.i
    i16 36, label %sw.bb46.i
  ], !dbg !1673

sw.bb22.i:                                        ; preds = %if.end19.i
  br label %sw.bb97.sink.split.i, !dbg !1674

sw.bb24.i:                                        ; preds = %if.end19.i
  br label %sw.bb97.sink.split.i, !dbg !1676

sw.epilog.thread374.i:                            ; preds = %if.end19.i
  store i16 4, ptr %cmd, align 8, !dbg !1677, !tbaa !1117
  br label %sw.bb128.i, !dbg !1678

sw.bb30.i:                                        ; preds = %if.end19.i
  br label %sw.bb143.sink.split.i, !dbg !1679

sw.epilog.thread375.i:                            ; preds = %if.end19.i
  store i16 7, ptr %cmd, align 8, !dbg !1680, !tbaa !1117
  br label %sw.bb178.i, !dbg !1678

sw.epilog.thread373.i:                            ; preds = %if.end19.i
  store i16 8, ptr %cmd, align 8, !dbg !1681, !tbaa !1117
  br label %sw.bb64.i, !dbg !1678

sw.bb38.i:                                        ; preds = %if.end19.i
  br label %sw.bb160.sink.split.i, !dbg !1682

sw.bb42.i:                                        ; preds = %if.end19.i
  br label %sw.bb113.sink.split.i, !dbg !1683

sw.bb46.i:                                        ; preds = %if.end19.i
  br label %sw.bb218.sink.split.i, !dbg !1684

sw.epilog.i:                                      ; preds = %if.end19.i
  store i8 0, ptr %noreply.i, align 4, !dbg !1685, !tbaa !1149
  switch i16 %44, label %sw.default229.i [
    i16 11, label %sw.bb51.i
    i16 8, label %sw.bb64.i
    i16 10, label %sw.bb83.i
    i16 1, label %sw.bb97.i
    i16 2, label %sw.bb97.i
    i16 3, label %sw.bb97.i
    i16 29, label %sw.bb218.i
    i16 0, label %sw.bb113.i
    i16 35, label %sw.bb218.i
    i16 12, label %sw.bb113.i
    i16 4, label %sw.bb128.i
    i16 5, label %sw.bb143.i
    i16 6, label %sw.bb143.i
    i16 14, label %sw.bb160.i
    i16 15, label %sw.bb160.i
    i16 16, label %sw.bb171.i
    i16 7, label %sw.bb178.i
    i16 32, label %sw.bb193.i
    i16 33, label %sw.bb207.i
    i16 34, label %sw.bb207.i
    i16 28, label %sw.bb218.i
  ], !dbg !1678

sw.bb51.i:                                        ; preds = %sw.epilog.i
  %cmp53.i = icmp eq i8 %27, 0, !dbg !1686
  %cmp57.i = icmp eq i16 %20, 0
  %or.cond.i = and i1 %cmp57.i, %cmp53.i, !dbg !1689
  %cmp60.i = icmp eq i32 %28, 0
  %or.cond333.i = and i1 %or.cond.i, %cmp60.i, !dbg !1689
  br i1 %or.cond333.i, label %if.then62.i, label %if.then232.i, !dbg !1689

if.then62.i:                                      ; preds = %sw.bb51.i
  tail call fastcc void @write_bin_response(ptr noundef nonnull %c, ptr noundef nonnull @.str.27, i32 noundef 6), !dbg !1690
  br label %45, !dbg !1692

sw.bb64.i:                                        ; preds = %sw.epilog.i, %sw.epilog.thread373.i
  %cmp70.i = icmp eq i32 %28, %conv8.i
  br i1 %cmp70.i, label %land.lhs.true72.i, label %if.then232.i, !dbg !1693

land.lhs.true72.i:                                ; preds = %sw.bb64.i
  switch i8 %27, label %if.then232.i [
    i8 0, label %if.then80.i
    i8 4, label %if.then80.i
  ], !dbg !1695

if.then80.i:                                      ; preds = %land.lhs.true72.i, %land.lhs.true72.i
  call fastcc void @process_bin_flush(ptr noundef nonnull %c, ptr noundef nonnull %extbuf), !dbg !1696
  br label %45, !dbg !1698

sw.bb83.i:                                        ; preds = %sw.epilog.i
  %cmp85.i = icmp eq i8 %27, 0, !dbg !1699
  %cmp89.i = icmp eq i16 %20, 0
  %or.cond335.i = and i1 %cmp89.i, %cmp85.i, !dbg !1701
  %cmp92.i = icmp eq i32 %28, 0
  %or.cond336.i = and i1 %or.cond335.i, %cmp92.i, !dbg !1701
  br i1 %or.cond336.i, label %if.then94.i, label %if.then232.i, !dbg !1701

if.then94.i:                                      ; preds = %sw.bb83.i
  tail call fastcc void @write_bin_response(ptr noundef nonnull %c, ptr noundef null, i32 noundef 0), !dbg !1702
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 9) #11, !dbg !1704
  br label %45, !dbg !1705

sw.bb97.sink.split.i:                             ; preds = %sw.bb24.i, %sw.bb22.i, %if.end19.i
  %.sink.i = phi i16 [ 2, %sw.bb22.i ], [ 3, %sw.bb24.i ], [ 1, %if.end19.i ]
  store i16 %.sink.i, ptr %cmd, align 8, !dbg !1706, !tbaa !1117
  br label %sw.bb97.i, !dbg !1707

sw.bb97.i:                                        ; preds = %sw.bb97.sink.split.i, %sw.epilog.i, %sw.epilog.i, %sw.epilog.i
  %cmp99.i = icmp ne i8 %27, 8, !dbg !1707
  %cmp103.not.i = icmp eq i16 %20, 0
  %or.cond337.i = or i1 %cmp103.not.i, %cmp99.i, !dbg !1709
  %add107.i = add nuw nsw i32 %conv62, 8
  %cmp108.not.i = icmp ult i32 %28, %add107.i
  %or.cond338.i = select i1 %or.cond337.i, i1 true, i1 %cmp108.not.i, !dbg !1709
  br i1 %or.cond338.i, label %if.then232.i, label %if.then110.i, !dbg !1709

if.then110.i:                                     ; preds = %sw.bb97.i
  call fastcc void @process_bin_update(ptr noundef nonnull %c, ptr noundef nonnull %extbuf), !dbg !1710
  br label %45, !dbg !1712

sw.bb113.sink.split.i:                            ; preds = %sw.bb42.i, %if.end19.i
  %.sink377.i = phi i16 [ 12, %sw.bb42.i ], [ 0, %if.end19.i ]
  store i16 %.sink377.i, ptr %cmd, align 8, !dbg !1706, !tbaa !1117
  br label %sw.bb113.i

sw.bb113.i:                                       ; preds = %sw.bb113.sink.split.i, %sw.epilog.i, %sw.epilog.i
  %cmp119.i = icmp ne i32 %28, %conv62
  %cmp123.not.i = icmp eq i16 %20, 0
  %or.cond340.i = or i1 %cmp123.not.i, %cmp119.i, !dbg !1713
  br i1 %or.cond340.i, label %if.then232.i, label %if.then125.i, !dbg !1713

if.then125.i:                                     ; preds = %sw.bb113.i
  call fastcc void @process_bin_get_or_touch(ptr noundef nonnull %c, ptr noundef nonnull %extbuf), !dbg !1715
  br label %45, !dbg !1717

sw.bb128.i:                                       ; preds = %sw.epilog.i, %sw.epilog.thread374.i
  %cmp130.not.i = icmp ne i16 %20, 0, !dbg !1718
  %cmp134.i = icmp eq i8 %27, 0
  %or.cond341.i = select i1 %cmp130.not.i, i1 %cmp134.i, i1 false, !dbg !1720
  %cmp138.i = icmp eq i32 %28, %conv62
  %or.cond342.i = and i1 %or.cond341.i, %cmp138.i, !dbg !1720
  br i1 %or.cond342.i, label %if.then140.i, label %if.then232.i, !dbg !1720

if.then140.i:                                     ; preds = %sw.bb128.i
  tail call fastcc void @process_bin_delete(ptr noundef nonnull %c), !dbg !1721
  br label %45, !dbg !1723

sw.bb143.sink.split.i:                            ; preds = %sw.bb30.i, %if.end19.i
  %.sink378.i = phi i16 [ 6, %sw.bb30.i ], [ 5, %if.end19.i ]
  store i16 %.sink378.i, ptr %cmd, align 8, !dbg !1706, !tbaa !1117
  br label %sw.bb143.i, !dbg !1724

sw.bb143.i:                                       ; preds = %sw.bb143.sink.split.i, %sw.epilog.i, %sw.epilog.i
  %cmp145.not.i = icmp ne i16 %20, 0, !dbg !1724
  %cmp149.i = icmp eq i8 %27, 20
  %or.cond343.i = select i1 %cmp145.not.i, i1 %cmp149.i, i1 false, !dbg !1726
  %cmp155.i = icmp eq i32 %28, %add.i
  %or.cond344.i = and i1 %or.cond343.i, %cmp155.i, !dbg !1726
  br i1 %or.cond344.i, label %if.then157.i, label %if.then232.i, !dbg !1726

if.then157.i:                                     ; preds = %sw.bb143.i
  call fastcc void @complete_incr_bin(ptr noundef nonnull %c, ptr noundef nonnull %extbuf), !dbg !1727
  br label %45, !dbg !1729

sw.bb160.sink.split.i:                            ; preds = %sw.bb38.i, %if.end19.i
  %.sink379.i = phi i16 [ 15, %sw.bb38.i ], [ 14, %if.end19.i ]
  store i16 %.sink379.i, ptr %cmd, align 8, !dbg !1706, !tbaa !1117
  br label %sw.bb160.i, !dbg !1730

sw.bb160.i:                                       ; preds = %sw.bb160.sink.split.i, %sw.epilog.i, %sw.epilog.i
  %cmp162.not.i = icmp ne i16 %20, 0, !dbg !1730
  %cmp166.i = icmp eq i8 %27, 0
  %or.cond345.i = select i1 %cmp162.not.i, i1 %cmp166.i, i1 false, !dbg !1732
  br i1 %or.cond345.i, label %if.then168.i, label %if.then232.i, !dbg !1732

if.then168.i:                                     ; preds = %sw.bb160.i
  tail call fastcc void @process_bin_append_prepend(ptr noundef nonnull %c), !dbg !1733
  br label %45, !dbg !1735

sw.bb171.i:                                       ; preds = %sw.epilog.i
  %cmp173.i = icmp eq i8 %27, 0, !dbg !1736
  br i1 %cmp173.i, label %if.then175.i, label %if.then232.i, !dbg !1738

if.then175.i:                                     ; preds = %sw.bb171.i
  tail call fastcc void @process_bin_stat(ptr noundef nonnull %c), !dbg !1739
  br label %45, !dbg !1741

sw.bb178.i:                                       ; preds = %sw.epilog.i, %sw.epilog.thread375.i
  %cmp180.i = icmp eq i16 %20, 0, !dbg !1742
  %cmp184.i = icmp eq i8 %27, 0
  %or.cond346.i = select i1 %cmp180.i, i1 %cmp184.i, i1 false, !dbg !1744
  %cmp187.i = icmp eq i32 %28, 0
  %or.cond347.i = and i1 %or.cond346.i, %cmp187.i, !dbg !1744
  br i1 %or.cond347.i, label %if.then189.i, label %if.then232.i, !dbg !1744

if.then189.i:                                     ; preds = %sw.bb178.i
  tail call fastcc void @write_bin_response(ptr noundef nonnull %c, ptr noundef null, i32 noundef 0), !dbg !1745
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 9) #11, !dbg !1747
  %close_after_write190.i = getelementptr inbounds i8, ptr %c, i64 16, !dbg !1748
  store i8 1, ptr %close_after_write190.i, align 8, !dbg !1749, !tbaa !1618
  %close_reason.i = getelementptr inbounds i8, ptr %c, i64 324, !dbg !1750
  store i32 1, ptr %close_reason.i, align 4, !dbg !1751, !tbaa !1752
  br label %45, !dbg !1753

sw.bb193.i:                                       ; preds = %sw.epilog.i
  %cmp195.i = icmp eq i8 %27, 0, !dbg !1754
  %cmp199.i = icmp eq i16 %20, 0
  %or.cond348.i = and i1 %cmp199.i, %cmp195.i, !dbg !1756
  %cmp202.i = icmp eq i32 %28, 0
  %or.cond349.i = and i1 %or.cond348.i, %cmp202.i, !dbg !1756
  br i1 %or.cond349.i, label %if.then204.i, label %if.then232.i, !dbg !1756

if.then204.i:                                     ; preds = %sw.bb193.i
  tail call fastcc void @bin_list_sasl_mechs(ptr noundef nonnull %c), !dbg !1757
  br label %45, !dbg !1759

sw.bb207.i:                                       ; preds = %sw.epilog.i, %sw.epilog.i
  %cmp209.i = icmp ne i8 %27, 0, !dbg !1760
  %cmp213.not.i = icmp eq i16 %20, 0
  %or.cond350.i = or i1 %cmp213.not.i, %cmp209.i, !dbg !1762
  br i1 %or.cond350.i, label %if.then232.i, label %if.then215.i, !dbg !1762

if.then215.i:                                     ; preds = %sw.bb207.i
  tail call fastcc void @process_bin_sasl_auth(ptr noundef nonnull %c), !dbg !1763
  br label %45, !dbg !1765

sw.bb218.sink.split.i:                            ; preds = %sw.bb46.i, %if.end19.i
  %.sink380.i = phi i16 [ 35, %sw.bb46.i ], [ 29, %if.end19.i ]
  store i16 %.sink380.i, ptr %cmd, align 8, !dbg !1706, !tbaa !1117
  br label %sw.bb218.i, !dbg !1766

sw.bb218.i:                                       ; preds = %sw.bb218.sink.split.i, %sw.epilog.i, %sw.epilog.i, %sw.epilog.i
  %cmp220.i = icmp ne i8 %27, 4, !dbg !1766
  %cmp224.not.i = icmp eq i16 %20, 0
  %or.cond351.i = or i1 %cmp224.not.i, %cmp220.i, !dbg !1768
  br i1 %or.cond351.i, label %if.then232.i, label %if.then226.i, !dbg !1768

if.then226.i:                                     ; preds = %sw.bb218.i
  call fastcc void @process_bin_get_or_touch(ptr noundef nonnull %c, ptr noundef nonnull %extbuf), !dbg !1769
  br label %45, !dbg !1771

sw.default229.i:                                  ; preds = %sw.epilog.i
  tail call void @write_bin_error(ptr noundef nonnull %c, i32 noundef 129, ptr noundef null, i32 noundef %28), !dbg !1772
  br label %45, !dbg !1773

if.then232.i:                                     ; preds = %sw.bb218.i, %sw.bb207.i, %sw.bb193.i, %sw.bb178.i, %sw.bb171.i, %sw.bb160.i, %sw.bb143.i, %sw.bb128.i, %sw.bb113.i, %sw.bb97.i, %sw.bb83.i, %land.lhs.true72.i, %sw.bb64.i, %sw.bb51.i
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1584, metadata !DIExpression()), !dbg !1588
  tail call fastcc void @handle_binary_protocol_error(ptr noundef nonnull %c), !dbg !1774
  br label %45, !dbg !1774

45:                                               ; preds = %if.end12.i.i, %if.end12.i355.i, %if.then18.i, %if.then62.i, %if.then80.i, %if.then94.i, %if.then110.i, %if.then125.i, %if.then140.i, %if.then157.i, %if.then168.i, %if.then175.i, %if.then189.i, %if.then204.i, %if.then215.i, %if.then226.i, %sw.default229.i, %if.then232.i
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %extbuf) #11, !dbg !1776
  br label %return

return:                                           ; preds = %if.end39, %if.then56, %if.end38, %45, %entry
  %retval.2 = phi i32 [ 0, %entry ], [ 1, %45 ], [ 0, %if.end39 ], [ -1, %if.then56 ], [ -1, %if.end38 ], !dbg !1461
  ret i32 %retval.2, !dbg !1777
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #4

declare !dbg !1778 i64 @ntohll(i64 noundef) local_unnamed_addr #1

declare !dbg !1782 void @conn_set_state(ptr noundef, i32 noundef) local_unnamed_addr #1

declare !dbg !1785 zeroext i1 @resp_start(ptr noundef) local_unnamed_addr #1

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @write_bin_error(ptr noundef %c, i32 noundef %err, ptr noundef %errstr, i32 noundef %swallow) local_unnamed_addr #0 !dbg !1158 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !1786
  tail call void @llvm.dbg.value(metadata i32 %err, metadata !1164, metadata !DIExpression()), !dbg !1786
  tail call void @llvm.dbg.value(metadata ptr %errstr, metadata !1165, metadata !DIExpression()), !dbg !1786
  tail call void @llvm.dbg.value(metadata i32 %swallow, metadata !1166, metadata !DIExpression()), !dbg !1786
  %tobool.not = icmp eq ptr %errstr, null, !dbg !1787
  br i1 %tobool.not, label %if.then, label %if.end, !dbg !1789

if.then:                                          ; preds = %entry
  switch i32 %err, label %sw.default [
    i32 130, label %if.end
    i32 129, label %sw.bb1
    i32 1, label %sw.bb2
    i32 4, label %sw.bb3
    i32 2, label %sw.bb4
    i32 3, label %sw.bb5
    i32 6, label %sw.bb6
    i32 5, label %sw.bb7
    i32 32, label %sw.bb8
  ], !dbg !1790

sw.bb1:                                           ; preds = %if.then
  tail call void @llvm.dbg.value(metadata ptr @.str.7, metadata !1165, metadata !DIExpression()), !dbg !1786
  br label %if.end, !dbg !1792

sw.bb2:                                           ; preds = %if.then
  tail call void @llvm.dbg.value(metadata ptr @.str.8, metadata !1165, metadata !DIExpression()), !dbg !1786
  br label %if.end, !dbg !1794

sw.bb3:                                           ; preds = %if.then
  tail call void @llvm.dbg.value(metadata ptr @.str.9, metadata !1165, metadata !DIExpression()), !dbg !1786
  br label %if.end, !dbg !1795

sw.bb4:                                           ; preds = %if.then
  tail call void @llvm.dbg.value(metadata ptr @.str.10, metadata !1165, metadata !DIExpression()), !dbg !1786
  br label %if.end, !dbg !1796

sw.bb5:                                           ; preds = %if.then
  tail call void @llvm.dbg.value(metadata ptr @.str.11, metadata !1165, metadata !DIExpression()), !dbg !1786
  br label %if.end, !dbg !1797

sw.bb6:                                           ; preds = %if.then
  tail call void @llvm.dbg.value(metadata ptr @.str.12, metadata !1165, metadata !DIExpression()), !dbg !1786
  br label %if.end, !dbg !1798

sw.bb7:                                           ; preds = %if.then
  tail call void @llvm.dbg.value(metadata ptr @.str.13, metadata !1165, metadata !DIExpression()), !dbg !1786
  br label %if.end, !dbg !1799

sw.bb8:                                           ; preds = %if.then
  tail call void @llvm.dbg.value(metadata ptr @.str.14, metadata !1165, metadata !DIExpression()), !dbg !1786
  br label %if.end, !dbg !1800

sw.default:                                       ; preds = %if.then
  tail call void @llvm.dbg.value(metadata ptr @.str.15, metadata !1165, metadata !DIExpression()), !dbg !1786
  %0 = load ptr, ptr @stderr, align 8, !dbg !1801, !tbaa !1091
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1802
  %1 = load i32, ptr %sfd, align 8, !dbg !1802, !tbaa !1107
  %call = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %0, ptr noundef nonnull @.str.16, i32 noundef %1, i32 noundef %err) #12, !dbg !1803
  br label %if.end, !dbg !1804

if.end:                                           ; preds = %if.then, %sw.bb1, %sw.bb2, %sw.bb3, %sw.bb4, %sw.bb5, %sw.bb6, %sw.bb7, %sw.bb8, %sw.default, %entry
  %errstr.addr.0 = phi ptr [ %errstr, %entry ], [ @.str.15, %sw.default ], [ @.str.14, %sw.bb8 ], [ @.str.13, %sw.bb7 ], [ @.str.12, %sw.bb6 ], [ @.str.11, %sw.bb5 ], [ @.str.10, %sw.bb4 ], [ @.str.9, %sw.bb3 ], [ @.str.8, %sw.bb2 ], [ @.str.7, %sw.bb1 ], [ @.str.6, %if.then ]
  tail call void @llvm.dbg.value(metadata ptr %errstr.addr.0, metadata !1165, metadata !DIExpression()), !dbg !1786
  %2 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1805, !tbaa !1172
  %cmp = icmp sgt i32 %2, 1, !dbg !1806
  br i1 %cmp, label %if.then9, label %if.end12, !dbg !1807

if.then9:                                         ; preds = %if.end
  %3 = load ptr, ptr @stderr, align 8, !dbg !1808, !tbaa !1091
  %sfd10 = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1809
  %4 = load i32, ptr %sfd10, align 8, !dbg !1809, !tbaa !1107
  %call11 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %3, ptr noundef nonnull @.str.17, i32 noundef %4, ptr noundef nonnull %errstr.addr.0) #12, !dbg !1810
  br label %if.end12, !dbg !1811

if.end12:                                         ; preds = %if.then9, %if.end
  %call13 = tail call i64 @strlen(ptr noundef nonnull dereferenceable(1) %errstr.addr.0) #14, !dbg !1812
  tail call void @llvm.dbg.value(metadata i64 %call13, metadata !1167, metadata !DIExpression()), !dbg !1786
  %conv = trunc i32 %err to i16, !dbg !1813
  %conv14 = trunc i64 %call13 to i32, !dbg !1814
  tail call fastcc void @add_bin_header(ptr noundef %c, i16 noundef zeroext %conv, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef %conv14), !dbg !1815
  %cmp15.not = icmp eq i64 %call13, 0, !dbg !1816
  br i1 %cmp15.not, label %if.end19, label %if.then17, !dbg !1817

if.then17:                                        ; preds = %if.end12
  %resp = getelementptr inbounds i8, ptr %c, i64 192, !dbg !1818
  %5 = load ptr, ptr %resp, align 8, !dbg !1818, !tbaa !1184
  tail call void @resp_add_iov(ptr noundef %5, ptr noundef nonnull %errstr.addr.0, i32 noundef %conv14) #11, !dbg !1819
  br label %if.end19, !dbg !1820

if.end19:                                         ; preds = %if.then17, %if.end12
  %cmp20 = icmp sgt i32 %swallow, 0, !dbg !1821
  br i1 %cmp20, label %if.then22, label %if.end23, !dbg !1822

if.then22:                                        ; preds = %if.end19
  %sbytes = getelementptr inbounds i8, ptr %c, i64 232, !dbg !1823
  store i32 %swallow, ptr %sbytes, align 8, !dbg !1825, !tbaa !1826
  br label %if.end23, !dbg !1827

if.end23:                                         ; preds = %if.end19, %if.then22
  %.sink = phi i32 [ 7, %if.then22 ], [ 9, %if.end19 ]
  tail call void @conn_set_state(ptr noundef %c, i32 noundef %.sink) #11, !dbg !1828
  ret void, !dbg !1829
}

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare !dbg !1830 i64 @strlen(ptr nocapture noundef) local_unnamed_addr #5

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @add_bin_header(ptr nocapture noundef readonly %c, i16 noundef zeroext %err, i8 noundef zeroext %hdr_len, i16 noundef zeroext %key_len, i32 noundef %body_len) unnamed_addr #0 !dbg !1834 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1838, metadata !DIExpression()), !dbg !1848
  tail call void @llvm.dbg.value(metadata i16 %err, metadata !1839, metadata !DIExpression()), !dbg !1848
  tail call void @llvm.dbg.value(metadata i8 %hdr_len, metadata !1840, metadata !DIExpression()), !dbg !1848
  tail call void @llvm.dbg.value(metadata i16 %key_len, metadata !1841, metadata !DIExpression()), !dbg !1848
  tail call void @llvm.dbg.value(metadata i32 %body_len, metadata !1842, metadata !DIExpression()), !dbg !1848
  %resp1 = getelementptr inbounds i8, ptr %c, i64 192, !dbg !1849
  %0 = load ptr, ptr %resp1, align 8, !dbg !1849, !tbaa !1184
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1844, metadata !DIExpression()), !dbg !1848
  tail call void @resp_reset(ptr noundef %0) #11, !dbg !1850
  %wbuf = getelementptr inbounds i8, ptr %0, i64 160, !dbg !1851
  tail call void @llvm.dbg.value(metadata ptr %wbuf, metadata !1843, metadata !DIExpression()), !dbg !1848
  store i8 -127, ptr %wbuf, align 8, !dbg !1852, !tbaa !1056
  %opcode = getelementptr inbounds i8, ptr %c, i64 393, !dbg !1853
  %1 = load i8, ptr %opcode, align 1, !dbg !1853, !tbaa !1056
  %opcode2 = getelementptr inbounds i8, ptr %0, i64 161, !dbg !1854
  store i8 %1, ptr %opcode2, align 1, !dbg !1855, !tbaa !1056
  %rev.i = tail call noundef i16 @llvm.bswap.i16(i16 %key_len)
  %keylen = getelementptr inbounds i8, ptr %0, i64 162, !dbg !1856
  store i16 %rev.i, ptr %keylen, align 2, !dbg !1857, !tbaa !1056
  %extlen = getelementptr inbounds i8, ptr %0, i64 164, !dbg !1858
  store i8 %hdr_len, ptr %extlen, align 4, !dbg !1859, !tbaa !1056
  %datatype = getelementptr inbounds i8, ptr %0, i64 165, !dbg !1860
  store i8 0, ptr %datatype, align 1, !dbg !1861, !tbaa !1056
  %rev.i45 = tail call noundef i16 @llvm.bswap.i16(i16 %err)
  %status = getelementptr inbounds i8, ptr %0, i64 166, !dbg !1862
  store i16 %rev.i45, ptr %status, align 2, !dbg !1863, !tbaa !1056
  tail call void @llvm.dbg.value(metadata i32 %body_len, metadata !1503, metadata !DIExpression()), !dbg !1864
  %or7.i = tail call noundef i32 @llvm.bswap.i32(i32 %body_len), !dbg !1866
  %bodylen = getelementptr inbounds i8, ptr %0, i64 168, !dbg !1867
  store i32 %or7.i, ptr %bodylen, align 8, !dbg !1868, !tbaa !1056
  %opaque = getelementptr inbounds i8, ptr %c, i64 436, !dbg !1869
  %2 = load i32, ptr %opaque, align 4, !dbg !1869, !tbaa !1560
  %opaque5 = getelementptr inbounds i8, ptr %0, i64 172, !dbg !1870
  store i32 %2, ptr %opaque5, align 4, !dbg !1871, !tbaa !1056
  %cas = getelementptr inbounds i8, ptr %c, i64 416, !dbg !1872
  %3 = load i64, ptr %cas, align 8, !dbg !1872, !tbaa !1131
  %call6 = tail call i64 @htonll(i64 noundef %3) #11, !dbg !1873
  %cas7 = getelementptr inbounds i8, ptr %0, i64 176, !dbg !1874
  store i64 %call6, ptr %cas7, align 8, !dbg !1875, !tbaa !1056
  %4 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1876, !tbaa !1172
  %cmp = icmp sgt i32 %4, 1, !dbg !1877
  br i1 %cmp, label %if.then, label %if.end19, !dbg !1878

if.then:                                          ; preds = %entry
  %5 = load ptr, ptr @stderr, align 8, !dbg !1879, !tbaa !1091
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1880
  %6 = load i32, ptr %sfd, align 8, !dbg !1880, !tbaa !1107
  %call8 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %5, ptr noundef nonnull @.str.18, i32 noundef %6) #12, !dbg !1881
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1845, metadata !DIExpression()), !dbg !1882
  br label %for.body, !dbg !1883

for.body:                                         ; preds = %if.then, %if.end
  %indvars.iv = phi i64 [ 0, %if.then ], [ %indvars.iv.next, %if.end ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1845, metadata !DIExpression()), !dbg !1882
  %rem49 = and i64 %indvars.iv, 3, !dbg !1885
  %cmp11 = icmp eq i64 %rem49, 0, !dbg !1885
  br i1 %cmp11, label %if.then13, label %if.end, !dbg !1889

if.then13:                                        ; preds = %for.body
  %7 = load ptr, ptr @stderr, align 8, !dbg !1890, !tbaa !1091
  %8 = load i32, ptr %sfd, align 8, !dbg !1892, !tbaa !1107
  %call15 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %7, ptr noundef nonnull @.str.19, i32 noundef %8) #12, !dbg !1893
  br label %if.end, !dbg !1894

if.end:                                           ; preds = %if.then13, %for.body
  %9 = load ptr, ptr @stderr, align 8, !dbg !1895, !tbaa !1091
  %arrayidx = getelementptr inbounds [24 x i8], ptr %wbuf, i64 0, i64 %indvars.iv, !dbg !1896
  %10 = load i8, ptr %arrayidx, align 1, !dbg !1896, !tbaa !1056
  %conv16 = zext i8 %10 to i32, !dbg !1896
  %call17 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %9, ptr noundef nonnull @.str.3, i32 noundef %conv16) #12, !dbg !1897
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !1898
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !1845, metadata !DIExpression()), !dbg !1882
  %exitcond.not = icmp eq i64 %indvars.iv.next, 24, !dbg !1899
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !1883, !llvm.loop !1900

for.end:                                          ; preds = %if.end
  %11 = load ptr, ptr @stderr, align 8, !dbg !1902, !tbaa !1091
  %fputc = tail call i32 @fputc(i32 10, ptr %11), !dbg !1903
  br label %if.end19, !dbg !1904

if.end19:                                         ; preds = %for.end, %entry
  %wbytes = getelementptr inbounds i8, ptr %0, i64 16, !dbg !1905
  store i32 24, ptr %wbytes, align 8, !dbg !1906, !tbaa !1907
  tail call void @resp_add_iov(ptr noundef nonnull %0, ptr noundef nonnull %wbuf, i32 noundef 24) #11, !dbg !1909
  ret void, !dbg !1910
}

declare !dbg !1911 void @resp_add_iov(ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #1

declare !dbg !1914 void @resp_reset(ptr noundef) local_unnamed_addr #1

declare !dbg !1917 i64 @htonll(i64 noundef) local_unnamed_addr #1

; Function Attrs: nounwind
declare !dbg !1918 i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #6

; Function Attrs: nounwind
declare !dbg !1923 i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #6

declare !dbg !1924 i32 @store_item(ptr noundef, i32 noundef, ptr noundef, ptr noundef, ptr noundef, i64 noundef, i1 noundef zeroext) local_unnamed_addr #1

declare !dbg !1930 i64 @get_cas_id() local_unnamed_addr #1

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @write_bin_response(ptr noundef %c, ptr noundef %d, i32 noundef %dlen) unnamed_addr #0 !dbg !1134 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1133, metadata !DIExpression()), !dbg !1933
  tail call void @llvm.dbg.value(metadata ptr %d, metadata !1138, metadata !DIExpression()), !dbg !1933
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1139, metadata !DIExpression()), !dbg !1933
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1140, metadata !DIExpression()), !dbg !1933
  tail call void @llvm.dbg.value(metadata i32 %dlen, metadata !1141, metadata !DIExpression()), !dbg !1933
  %noreply = getelementptr inbounds i8, ptr %c, i64 364, !dbg !1934
  %0 = load i8, ptr %noreply, align 4, !dbg !1934, !tbaa !1149, !range !1123, !noundef !1124
  %tobool = trunc nuw i8 %0 to i1, !dbg !1934
  br i1 %tobool, label %lor.lhs.false, label %if.then, !dbg !1935

lor.lhs.false:                                    ; preds = %entry
  %cmd = getelementptr inbounds i8, ptr %c, i64 432, !dbg !1936
  %1 = load i16, ptr %cmd, align 8, !dbg !1936, !tbaa !1117
  switch i16 %1, label %if.end13 [
    i16 0, label %if.then
    i16 12, label %if.then
  ], !dbg !1937

if.then:                                          ; preds = %lor.lhs.false, %lor.lhs.false, %entry
  tail call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 0, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef %dlen), !dbg !1938
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1142, metadata !DIExpression()), !dbg !1939
  %cmp10 = icmp sgt i32 %dlen, 0, !dbg !1940
  br i1 %cmp10, label %if.then12, label %if.end13, !dbg !1942

if.then12:                                        ; preds = %if.then
  %resp9 = getelementptr inbounds i8, ptr %c, i64 192, !dbg !1943
  %2 = load ptr, ptr %resp9, align 8, !dbg !1943, !tbaa !1184
  tail call void @llvm.dbg.value(metadata ptr %2, metadata !1142, metadata !DIExpression()), !dbg !1939
  tail call void @resp_add_iov(ptr noundef %2, ptr noundef %d, i32 noundef %dlen) #11, !dbg !1944
  br label %if.end13, !dbg !1946

if.end13:                                         ; preds = %if.then, %if.then12, %lor.lhs.false
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 1) #11, !dbg !1947
  ret void, !dbg !1948
}

declare !dbg !1949 void @item_remove(ptr noundef) local_unnamed_addr #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #7

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #7

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @handle_binary_protocol_error(ptr noundef %c) unnamed_addr #0 !dbg !1950 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1952, metadata !DIExpression()), !dbg !1953
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !1954
  tail call void @llvm.dbg.value(metadata i32 4, metadata !1164, metadata !DIExpression()), !dbg !1954
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1165, metadata !DIExpression()), !dbg !1954
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !1954
  tail call void @llvm.dbg.value(metadata ptr @.str.9, metadata !1165, metadata !DIExpression()), !dbg !1954
  tail call void @llvm.dbg.value(metadata ptr @.str.9, metadata !1165, metadata !DIExpression()), !dbg !1954
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1956, !tbaa !1172
  %cmp.i = icmp sgt i32 %0, 1, !dbg !1957
  br i1 %cmp.i, label %if.then9.i, label %if.end12.i, !dbg !1958

if.then9.i:                                       ; preds = %entry
  %1 = load ptr, ptr @stderr, align 8, !dbg !1959, !tbaa !1091
  %sfd10.i = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1960
  %2 = load i32, ptr %sfd10.i, align 8, !dbg !1960, !tbaa !1107
  %call11.i = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %1, ptr noundef nonnull @.str.17, i32 noundef %2, ptr noundef nonnull @.str.9) #12, !dbg !1961
  br label %if.end12.i, !dbg !1962

if.end12.i:                                       ; preds = %if.then9.i, %entry
  tail call void @llvm.dbg.value(metadata i64 17, metadata !1167, metadata !DIExpression()), !dbg !1954
  tail call fastcc void @add_bin_header(ptr noundef %c, i16 noundef zeroext 4, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 17), !dbg !1963
  %resp.i = getelementptr inbounds i8, ptr %c, i64 192, !dbg !1964
  %3 = load ptr, ptr %resp.i, align 8, !dbg !1964, !tbaa !1184
  tail call void @resp_add_iov(ptr noundef %3, ptr noundef nonnull @.str.9, i32 noundef 17) #11, !dbg !1965
  tail call void @conn_set_state(ptr noundef %c, i32 noundef 9) #11, !dbg !1966
  %4 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1967, !tbaa !1172
  %tobool.not = icmp eq i32 %4, 0, !dbg !1969
  br i1 %tobool.not, label %if.end, label %if.then, !dbg !1970

if.then:                                          ; preds = %if.end12.i
  %5 = load ptr, ptr @stderr, align 8, !dbg !1971, !tbaa !1091
  %opcode = getelementptr inbounds i8, ptr %c, i64 393, !dbg !1973
  %6 = load i8, ptr %opcode, align 1, !dbg !1973, !tbaa !1056
  %conv = zext i8 %6 to i32, !dbg !1974
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1975
  %7 = load i32, ptr %sfd, align 8, !dbg !1975, !tbaa !1107
  %call = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %5, ptr noundef nonnull @.str.31, i32 noundef %conv, i32 noundef %7) #12, !dbg !1976
  br label %if.end, !dbg !1977

if.end:                                           ; preds = %if.then, %if.end12.i
  %close_after_write = getelementptr inbounds i8, ptr %c, i64 16, !dbg !1978
  store i8 1, ptr %close_after_write, align 8, !dbg !1979, !tbaa !1618
  ret void, !dbg !1980
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_bin_flush(ptr noundef %c, ptr nocapture noundef readonly %extbuf) unnamed_addr #0 !dbg !1981 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1983, metadata !DIExpression()), !dbg !2003
  tail call void @llvm.dbg.value(metadata ptr %extbuf, metadata !1984, metadata !DIExpression()), !dbg !2003
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1985, metadata !DIExpression()), !dbg !2003
  tail call void @llvm.dbg.value(metadata ptr %extbuf, metadata !1988, metadata !DIExpression()), !dbg !2003
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2002, metadata !DIExpression()), !dbg !2003
  %0 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 37), align 8, !dbg !2004, !tbaa !2006, !range !1123, !noundef !1124
  %tobool = trunc nuw i8 %0 to i1, !dbg !2004
  br i1 %tobool, label %if.end, label %if.then, !dbg !2007

if.then:                                          ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !2008
  tail call void @llvm.dbg.value(metadata i32 32, metadata !1164, metadata !DIExpression()), !dbg !2008
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1165, metadata !DIExpression()), !dbg !2008
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !2008
  tail call void @llvm.dbg.value(metadata ptr @.str.14, metadata !1165, metadata !DIExpression()), !dbg !2008
  tail call void @llvm.dbg.value(metadata ptr @.str.14, metadata !1165, metadata !DIExpression()), !dbg !2008
  %1 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2011, !tbaa !1172
  %cmp.i = icmp sgt i32 %1, 1, !dbg !2012
  br i1 %cmp.i, label %if.then9.i, label %if.end12.i, !dbg !2013

if.then9.i:                                       ; preds = %if.then
  %2 = load ptr, ptr @stderr, align 8, !dbg !2014, !tbaa !1091
  %sfd10.i = getelementptr inbounds i8, ptr %c, i64 8, !dbg !2015
  %3 = load i32, ptr %sfd10.i, align 8, !dbg !2015, !tbaa !1107
  %call11.i = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %2, ptr noundef nonnull @.str.17, i32 noundef %3, ptr noundef nonnull @.str.14) #12, !dbg !2016
  br label %if.end12.i, !dbg !2017

if.end12.i:                                       ; preds = %if.then9.i, %if.then
  tail call void @llvm.dbg.value(metadata i64 13, metadata !1167, metadata !DIExpression()), !dbg !2008
  tail call fastcc void @add_bin_header(ptr noundef %c, i16 noundef zeroext 32, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 13), !dbg !2018
  %resp.i = getelementptr inbounds i8, ptr %c, i64 192, !dbg !2019
  %4 = load ptr, ptr %resp.i, align 8, !dbg !2019, !tbaa !1184
  tail call void @resp_add_iov(ptr noundef %4, ptr noundef nonnull @.str.14, i32 noundef 13) #11, !dbg !2020
  tail call void @conn_set_state(ptr noundef %c, i32 noundef 9) #11, !dbg !2021
  br label %cleanup, !dbg !2022

if.end:                                           ; preds = %entry
  %extlen = getelementptr inbounds i8, ptr %c, i64 396, !dbg !2023
  %5 = load i8, ptr %extlen, align 4, !dbg !2023, !tbaa !1056
  %cmp = icmp eq i8 %5, 4, !dbg !2025
  br i1 %cmp, label %if.end4, label %if.else, !dbg !2026

if.end4:                                          ; preds = %if.end
  %body = getelementptr inbounds i8, ptr %extbuf, i64 24, !dbg !2027
  %6 = load i32, ptr %body, align 8, !dbg !2027, !tbaa !1056
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !1503, metadata !DIExpression()), !dbg !2029
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1985, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2003
  %cmp5.not = icmp eq i32 %6, 0, !dbg !2031
  br i1 %cmp5.not, label %if.else, label %if.then7, !dbg !2033

if.then7:                                         ; preds = %if.end4
  %or7.i = tail call noundef i32 @llvm.bswap.i32(i32 %6), !dbg !2034
  tail call void @llvm.dbg.value(metadata i32 %or7.i, metadata !1985, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2003
  %conv3 = zext i32 %or7.i to i64, !dbg !2027
  tail call void @llvm.dbg.value(metadata i64 %conv3, metadata !1985, metadata !DIExpression()), !dbg !2003
  %call8 = tail call i32 @realtime(i64 noundef %conv3) #11, !dbg !2035
  tail call void @llvm.dbg.value(metadata i32 %call8, metadata !2002, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !2003
  br label %if.end10, !dbg !2037

if.else:                                          ; preds = %if.end, %if.end4
  %7 = load volatile i32, ptr @current_time, align 4, !dbg !2038, !tbaa !1072
  tail call void @llvm.dbg.value(metadata i32 %7, metadata !2002, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !2003
  br label %if.end10

if.end10:                                         ; preds = %if.else, %if.then7
  %new_oldest.0.in = phi i32 [ %call8, %if.then7 ], [ %7, %if.else ]
  %new_oldest.0 = add i32 %new_oldest.0.in, -1, !dbg !2040
  tail call void @llvm.dbg.value(metadata i32 %new_oldest.0, metadata !2002, metadata !DIExpression()), !dbg !2003
  store i32 %new_oldest.0, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 6), align 4, !dbg !2041, !tbaa !2042
  tail call void @item_flush_expired() #11, !dbg !2043
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !2044
  %8 = load ptr, ptr %thread, align 8, !dbg !2044, !tbaa !1050
  %stats = getelementptr inbounds i8, ptr %8, i64 352, !dbg !2045
  %call11 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #11, !dbg !2046
  %9 = load ptr, ptr %thread, align 8, !dbg !2047, !tbaa !1050
  %flush_cmds = getelementptr inbounds i8, ptr %9, i64 496, !dbg !2048
  %10 = load i64, ptr %flush_cmds, align 8, !dbg !2049, !tbaa !2050
  %inc = add i64 %10, 1, !dbg !2049
  store i64 %inc, ptr %flush_cmds, align 8, !dbg !2049, !tbaa !2050
  %stats15 = getelementptr inbounds i8, ptr %9, i64 352, !dbg !2051
  %call17 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats15) #11, !dbg !2052
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1133, metadata !DIExpression()), !dbg !2053
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1138, metadata !DIExpression()), !dbg !2053
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1139, metadata !DIExpression()), !dbg !2053
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1140, metadata !DIExpression()), !dbg !2053
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1141, metadata !DIExpression()), !dbg !2053
  %noreply.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !2055
  %11 = load i8, ptr %noreply.i, align 4, !dbg !2055, !tbaa !1149, !range !1123, !noundef !1124
  %tobool.i = trunc nuw i8 %11 to i1, !dbg !2055
  br i1 %tobool.i, label %lor.lhs.false.i, label %if.then.i, !dbg !2056

lor.lhs.false.i:                                  ; preds = %if.end10
  %cmd.i = getelementptr inbounds i8, ptr %c, i64 432, !dbg !2057
  %12 = load i16, ptr %cmd.i, align 8, !dbg !2057, !tbaa !1117
  switch i16 %12, label %write_bin_response.exit [
    i16 0, label %if.then.i
    i16 12, label %if.then.i
  ], !dbg !2058

if.then.i:                                        ; preds = %lor.lhs.false.i, %lor.lhs.false.i, %if.end10
  tail call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 0, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 0), !dbg !2059
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1142, metadata !DIExpression()), !dbg !2060
  br label %write_bin_response.exit

write_bin_response.exit:                          ; preds = %lor.lhs.false.i, %if.then.i
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 1) #11, !dbg !2061
  br label %cleanup, !dbg !2062

cleanup:                                          ; preds = %write_bin_response.exit, %if.end12.i
  ret void, !dbg !2062
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_bin_update(ptr noundef %c, ptr nocapture noundef %extbuf) unnamed_addr #0 !dbg !2063 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2065, metadata !DIExpression()), !dbg !2094
  tail call void @llvm.dbg.value(metadata ptr %extbuf, metadata !2066, metadata !DIExpression()), !dbg !2094
  tail call void @llvm.dbg.value(metadata ptr %extbuf, metadata !2071, metadata !DIExpression()), !dbg !2094
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2095, metadata !DIExpression()), !dbg !2100
  %rcurr.i = getelementptr inbounds i8, ptr %c, i64 176, !dbg !2102
  %0 = load ptr, ptr %rcurr.i, align 8, !dbg !2102, !tbaa !1468
  %keylen.i = getelementptr inbounds i8, ptr %c, i64 394, !dbg !2103
  %1 = load i16, ptr %keylen.i, align 2, !dbg !2103, !tbaa !1056
  %idx.ext.i = zext i16 %1 to i64
  %idx.neg.i = sub nsw i64 0, %idx.ext.i, !dbg !2104
  %add.ptr.i = getelementptr inbounds i8, ptr %0, i64 %idx.neg.i, !dbg !2104
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !2067, metadata !DIExpression()), !dbg !2094
  tail call void @llvm.dbg.value(metadata i16 %1, metadata !2068, metadata !DIExpression()), !dbg !2094
  %body = getelementptr inbounds i8, ptr %extbuf, i64 24, !dbg !2105
  %2 = load i32, ptr %body, align 8, !dbg !2105, !tbaa !1056
  tail call void @llvm.dbg.value(metadata i32 %2, metadata !1503, metadata !DIExpression()), !dbg !2106
  %or7.i = tail call noundef i32 @llvm.bswap.i32(i32 %2), !dbg !2108
  store i32 %or7.i, ptr %body, align 8, !dbg !2109, !tbaa !1056
  %expiration = getelementptr inbounds i8, ptr %extbuf, i64 28, !dbg !2110
  %3 = load i32, ptr %expiration, align 4, !dbg !2110, !tbaa !1056
  tail call void @llvm.dbg.value(metadata i32 %3, metadata !1503, metadata !DIExpression()), !dbg !2111
  %or7.i207 = tail call noundef i32 @llvm.bswap.i32(i32 %3), !dbg !2113
  store i32 %or7.i207, ptr %expiration, align 4, !dbg !2114, !tbaa !1056
  %bodylen = getelementptr inbounds i8, ptr %c, i64 400, !dbg !2115
  %4 = load i32, ptr %bodylen, align 8, !dbg !2115, !tbaa !1056
  %conv = zext i16 %1 to i32, !dbg !2116
  %extlen = getelementptr inbounds i8, ptr %c, i64 396, !dbg !2117
  %5 = load i8, ptr %extlen, align 4, !dbg !2117, !tbaa !1056
  %conv10 = zext i8 %5 to i32, !dbg !2118
  %6 = add nuw nsw i32 %conv, %conv10, !dbg !2119
  %sub = sub i32 %4, %6, !dbg !2119
  tail call void @llvm.dbg.value(metadata i32 %sub, metadata !2069, metadata !DIExpression()), !dbg !2094
  %7 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2120, !tbaa !1172
  %cmp = icmp sgt i32 %7, 1, !dbg !2121
  br i1 %cmp, label %if.then, label %if.end35, !dbg !2122

if.then:                                          ; preds = %entry
  %cmd = getelementptr inbounds i8, ptr %c, i64 432, !dbg !2123
  %8 = load i16, ptr %cmd, align 8, !dbg !2123, !tbaa !1117
  %9 = load ptr, ptr @stderr, align 8, !dbg !2125, !tbaa !1091
  %sfd25 = getelementptr inbounds i8, ptr %c, i64 8, !dbg !2125
  %10 = load i32, ptr %sfd25, align 8, !dbg !2125, !tbaa !1107
  %switch.selectcmp = icmp eq i16 %8, 1, !dbg !2126
  %switch.select = select i1 %switch.selectcmp, ptr @.str.33, ptr @.str.34, !dbg !2126
  %switch.selectcmp211 = icmp eq i16 %8, 2, !dbg !2126
  %switch.select212 = select i1 %switch.selectcmp211, ptr @.str.32, ptr %switch.select, !dbg !2126
  %call23 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %9, ptr noundef nonnull %switch.select212, i32 noundef %10) #12, !dbg !2125
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2086, metadata !DIExpression()), !dbg !2127
  %cmp29208.not = icmp eq i16 %1, 0, !dbg !2128
  br i1 %cmp29208.not, label %for.end, label %for.body.preheader, !dbg !2131

for.body.preheader:                               ; preds = %if.then
  %wide.trip.count = zext i16 %1 to i64, !dbg !2128
  br label %for.body, !dbg !2131

for.body:                                         ; preds = %for.body.preheader, %for.body
  %indvars.iv = phi i64 [ 0, %for.body.preheader ], [ %indvars.iv.next, %for.body ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2086, metadata !DIExpression()), !dbg !2127
  %11 = load ptr, ptr @stderr, align 8, !dbg !2132, !tbaa !1091
  %arrayidx = getelementptr inbounds i8, ptr %add.ptr.i, i64 %indvars.iv, !dbg !2134
  %12 = load i8, ptr %arrayidx, align 1, !dbg !2134, !tbaa !1056
  %conv31 = sext i8 %12 to i32, !dbg !2134
  %fputc206 = tail call i32 @fputc(i32 %conv31, ptr %11), !dbg !2135
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !2136
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !2086, metadata !DIExpression()), !dbg !2127
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count, !dbg !2128
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !2131, !llvm.loop !2137

for.end:                                          ; preds = %for.body, %if.then
  %13 = load ptr, ptr @stderr, align 8, !dbg !2139, !tbaa !1091
  %call33 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %13, ptr noundef nonnull @.str.36, i32 noundef %sub) #12, !dbg !2140
  %14 = load ptr, ptr @stderr, align 8, !dbg !2141, !tbaa !1091
  %fputc = tail call i32 @fputc(i32 10, ptr %14), !dbg !2142
  br label %if.end35, !dbg !2143

if.end35:                                         ; preds = %for.end, %entry
  %15 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 16), align 8, !dbg !2144, !tbaa !2146
  %tobool.not = icmp eq i32 %15, 0, !dbg !2147
  br i1 %tobool.not, label %if.end38, label %if.then36, !dbg !2148

if.then36:                                        ; preds = %if.end35
  tail call void @stats_prefix_record_set(ptr noundef %add.ptr.i, i64 noundef %idx.ext.i) #11, !dbg !2149
  br label %if.end38, !dbg !2151

if.end38:                                         ; preds = %if.then36, %if.end35
  %16 = load i32, ptr %body, align 8, !dbg !2152, !tbaa !1056
  %17 = load i32, ptr %expiration, align 4, !dbg !2153, !tbaa !1056
  %conv44 = zext i32 %17 to i64, !dbg !2154
  %call45 = tail call i32 @realtime(i64 noundef %conv44) #11, !dbg !2155
  %add46 = add nsw i32 %sub, 2, !dbg !2156
  %call47 = tail call ptr @item_alloc(ptr noundef %add.ptr.i, i64 noundef %idx.ext.i, i32 noundef %16, i32 noundef %call45, i32 noundef %add46) #11, !dbg !2157
  tail call void @llvm.dbg.value(metadata ptr %call47, metadata !2070, metadata !DIExpression()), !dbg !2094
  %cmp48 = icmp eq ptr %call47, null, !dbg !2158
  br i1 %cmp48, label %if.then50, label %if.end93, !dbg !2159

if.then50:                                        ; preds = %if.end38
  %18 = load i32, ptr %body, align 8, !dbg !2160, !tbaa !1056
  %call55 = tail call zeroext i1 @item_size_ok(i64 noundef %idx.ext.i, i32 noundef %18, i32 noundef %add46) #11, !dbg !2162
  br i1 %call55, label %if.else57, label %if.then56, !dbg !2163

if.then56:                                        ; preds = %if.then50
  tail call void @write_bin_error(ptr noundef %c, i32 noundef 3, ptr noundef null, i32 noundef %sub), !dbg !2164
  tail call void @llvm.dbg.value(metadata i32 4, metadata !2089, metadata !DIExpression()), !dbg !2166
  br label %do.body, !dbg !2167

if.else57:                                        ; preds = %if.then50
  tail call void @out_of_memory(ptr noundef %c, ptr noundef nonnull @.str.37) #11, !dbg !2168
  %sbytes = getelementptr inbounds i8, ptr %c, i64 232, !dbg !2170
  store i32 %sub, ptr %sbytes, align 8, !dbg !2171, !tbaa !1826
  tail call void @llvm.dbg.value(metadata i32 5, metadata !2089, metadata !DIExpression()), !dbg !2166
  br label %do.body

do.body:                                          ; preds = %if.then56, %if.else57
  %status.0 = phi i32 [ 5, %if.else57 ], [ 4, %if.then56 ], !dbg !2172
  tail call void @llvm.dbg.value(metadata i32 %status.0, metadata !2089, metadata !DIExpression()), !dbg !2166
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !2173
  %19 = load ptr, ptr %thread, align 8, !dbg !2173, !tbaa !1050
  %l = getelementptr inbounds i8, ptr %19, i64 6912, !dbg !2173
  %20 = load ptr, ptr %l, align 8, !dbg !2173, !tbaa !2174
  tail call void @llvm.dbg.value(metadata ptr %20, metadata !2092, metadata !DIExpression()), !dbg !2175
  %cmp61 = icmp eq ptr %20, null, !dbg !2176
  br i1 %cmp61, label %if.then63, label %if.end65, !dbg !2173

if.then63:                                        ; preds = %do.body
  %21 = load i32, ptr @logger_key, align 4, !dbg !2176, !tbaa !1072
  %call64 = tail call ptr @pthread_getspecific(i32 noundef %21) #11, !dbg !2176
  tail call void @llvm.dbg.value(metadata ptr %call64, metadata !2092, metadata !DIExpression()), !dbg !2175
  br label %if.end65, !dbg !2176

if.end65:                                         ; preds = %if.then63, %do.body
  %myl.0 = phi ptr [ %call64, %if.then63 ], [ %20, %do.body ], !dbg !2173
  tail call void @llvm.dbg.value(metadata ptr %myl.0, metadata !2092, metadata !DIExpression()), !dbg !2175
  %eflags = getelementptr inbounds i8, ptr %myl.0, i64 84, !dbg !2178
  %22 = load i16, ptr %eflags, align 4, !dbg !2178, !tbaa !2180
  %23 = and i16 %22, 8, !dbg !2178
  %tobool67.not = icmp eq i16 %23, 0, !dbg !2178
  br i1 %tobool67.not, label %if.end76, label %if.then68, !dbg !2173

if.then68:                                        ; preds = %if.end65
  %24 = load i32, ptr %expiration, align 4, !dbg !2178, !tbaa !1056
  %25 = load i8, ptr inttoptr (i64 40 to ptr), align 8, !dbg !2178, !tbaa !1056
  %26 = and i8 %25, 63, !dbg !2178
  %and73 = zext nneg i8 %26 to i32, !dbg !2178
  %sfd74 = getelementptr inbounds i8, ptr %c, i64 8, !dbg !2178
  %27 = load i32, ptr %sfd74, align 8, !dbg !2178, !tbaa !1107
  %call75 = tail call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %myl.0, i32 noundef 3, ptr noundef null, i32 noundef %status.0, i32 noundef 0, ptr noundef %add.ptr.i, i32 noundef %conv, i32 noundef %24, i32 noundef %and73, i32 noundef %27) #11, !dbg !2178
  br label %if.end76, !dbg !2178

if.end76:                                         ; preds = %if.then68, %if.end65
  %cmd77 = getelementptr inbounds i8, ptr %c, i64 432, !dbg !2182
  %28 = load i16, ptr %cmd77, align 8, !dbg !2182, !tbaa !1117
  %cmp79 = icmp eq i16 %28, 1, !dbg !2184
  br i1 %cmp79, label %if.then81, label %if.end92, !dbg !2185

if.then81:                                        ; preds = %if.end76
  %29 = load ptr, ptr %thread, align 8, !dbg !2186, !tbaa !1050
  %call84 = tail call ptr @item_get(ptr noundef %add.ptr.i, i64 noundef %idx.ext.i, ptr noundef %29, i1 noundef zeroext false) #11, !dbg !2188
  tail call void @llvm.dbg.value(metadata ptr %call84, metadata !2070, metadata !DIExpression()), !dbg !2094
  %tobool85.not = icmp eq ptr %call84, null, !dbg !2189
  br i1 %tobool85.not, label %if.end92, label %if.then86, !dbg !2191

if.then86:                                        ; preds = %if.then81
  tail call void @item_unlink(ptr noundef nonnull %call84) #11, !dbg !2192
  %30 = load ptr, ptr %thread, align 8, !dbg !2194, !tbaa !1050
  %storage = getelementptr inbounds i8, ptr %30, i64 6904, !dbg !2194
  %31 = load ptr, ptr %storage, align 8, !dbg !2194, !tbaa !2196
  tail call void @storage_delete(ptr noundef %31, ptr noundef nonnull %call84) #11, !dbg !2194
  tail call void @item_remove(ptr noundef nonnull %call84) #11, !dbg !2197
  br label %if.end92, !dbg !2198

if.end92:                                         ; preds = %if.then81, %if.then86, %if.end76
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 7) #11, !dbg !2199
  br label %cleanup

if.end93:                                         ; preds = %if.end38
  %it_flags = getelementptr inbounds i8, ptr %call47, i64 38, !dbg !2200
  %32 = load i16, ptr %it_flags, align 2, !dbg !2200, !tbaa !1064
  %33 = and i16 %32, 2, !dbg !2200
  %tobool96.not = icmp eq i16 %33, 0, !dbg !2200
  br i1 %tobool96.not, label %if.end99, label %if.then97, !dbg !2203

if.then97:                                        ; preds = %if.end93
  %cas = getelementptr inbounds i8, ptr %c, i64 408, !dbg !2204
  %34 = load i64, ptr %cas, align 8, !dbg !2204, !tbaa !1056
  %data = getelementptr inbounds i8, ptr %call47, i64 48, !dbg !2204
  store i64 %34, ptr %data, align 8, !dbg !2204, !tbaa !1056
  br label %if.end99, !dbg !2204

if.end99:                                         ; preds = %if.then97, %if.end93
  %cmd100 = getelementptr inbounds i8, ptr %c, i64 432, !dbg !2206
  %35 = load i16, ptr %cmd100, align 8, !dbg !2206, !tbaa !1117
  %switch.tableidx = add i16 %35, -1, !dbg !2207
  %36 = icmp ult i16 %switch.tableidx, 3, !dbg !2207
  br i1 %36, label %switch.lookup, label %sw.epilog, !dbg !2207

switch.lookup:                                    ; preds = %if.end99
  %37 = shl nuw nsw i16 %switch.tableidx, 4, !dbg !2207
  %switch.shiftamt = zext nneg i16 %37 to i48, !dbg !2207
  %switch.downshift = lshr i48 12884967426, %switch.shiftamt, !dbg !2207
  %switch.masked = trunc i48 %switch.downshift to i16, !dbg !2207
  store i16 %switch.masked, ptr %cmd100, align 8, !dbg !2208, !tbaa !1117
  br label %sw.epilog, !dbg !2210

sw.epilog:                                        ; preds = %if.end99, %switch.lookup
  %38 = load i16, ptr %it_flags, align 2, !dbg !2210, !tbaa !1064
  %39 = and i16 %38, 2, !dbg !2210
  %tobool110.not = icmp eq i16 %39, 0, !dbg !2210
  br i1 %tobool110.not, label %if.end117, label %cond.true, !dbg !2210

cond.true:                                        ; preds = %sw.epilog
  %data111 = getelementptr inbounds i8, ptr %call47, i64 48, !dbg !2210
  %40 = load i64, ptr %data111, align 8, !dbg !2210, !tbaa !1056
  %41 = icmp eq i64 %40, 0, !dbg !2212
  br i1 %41, label %if.end117, label %if.then115, !dbg !2213

if.then115:                                       ; preds = %cond.true
  store i16 6, ptr %cmd100, align 8, !dbg !2214, !tbaa !1117
  %.pre = load i16, ptr %it_flags, align 2, !dbg !2216, !tbaa !1064
  br label %if.end117, !dbg !2217

if.end117:                                        ; preds = %sw.epilog, %if.then115, %cond.true
  %42 = phi i16 [ %38, %sw.epilog ], [ %.pre, %if.then115 ], [ %38, %cond.true ], !dbg !2216
  %item = getelementptr inbounds i8, ptr %c, i64 224, !dbg !2218
  store ptr %call47, ptr %item, align 8, !dbg !2219, !tbaa !1048
  %data118 = getelementptr inbounds i8, ptr %call47, i64 48, !dbg !2216
  %nkey119 = getelementptr inbounds i8, ptr %call47, i64 41, !dbg !2216
  %43 = load i8, ptr %nkey119, align 1, !dbg !2216, !tbaa !1056
  %idx.ext = zext i8 %43 to i64
  %add.ptr = getelementptr inbounds i8, ptr %data118, i64 %idx.ext, !dbg !2216
  %add.ptr121 = getelementptr inbounds i8, ptr %add.ptr, i64 1, !dbg !2216
  %conv123 = zext i16 %42 to i32, !dbg !2216
  %and124 = lshr i32 %conv123, 6, !dbg !2216
  %44 = and i32 %and124, 4, !dbg !2216
  %cond126 = zext nneg i32 %44 to i64, !dbg !2216
  %add.ptr127 = getelementptr inbounds i8, ptr %add.ptr121, i64 %cond126, !dbg !2216
  %and130 = shl nuw nsw i32 %conv123, 2, !dbg !2216
  %45 = and i32 %and130, 8, !dbg !2216
  %cond132 = zext nneg i32 %45 to i64, !dbg !2216
  %add.ptr133 = getelementptr inbounds i8, ptr %add.ptr127, i64 %cond132, !dbg !2216
  %ritem = getelementptr inbounds i8, ptr %c, i64 208, !dbg !2220
  store ptr %add.ptr133, ptr %ritem, align 8, !dbg !2221, !tbaa !1083
  %rlbytes = getelementptr inbounds i8, ptr %c, i64 216, !dbg !2222
  store i32 %sub, ptr %rlbytes, align 8, !dbg !2223, !tbaa !2224
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 6) #11, !dbg !2225
  %substate = getelementptr inbounds i8, ptr %c, i64 24, !dbg !2226
  store i32 3, ptr %substate, align 8, !dbg !2227, !tbaa !1016
  br label %cleanup, !dbg !2228

cleanup:                                          ; preds = %if.end117, %if.end92
  ret void, !dbg !2228
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_bin_get_or_touch(ptr noundef %c, ptr nocapture noundef readonly %extbuf) unnamed_addr #0 !dbg !2229 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2231, metadata !DIExpression()), !dbg !2262
  tail call void @llvm.dbg.value(metadata ptr %extbuf, metadata !2232, metadata !DIExpression()), !dbg !2262
  %resp = getelementptr inbounds i8, ptr %c, i64 192, !dbg !2263
  %0 = load ptr, ptr %resp, align 8, !dbg !2263, !tbaa !1184
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2234, metadata !DIExpression(DW_OP_plus_uconst, 160, DW_OP_stack_value)), !dbg !2262
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2095, metadata !DIExpression()), !dbg !2264
  %rcurr.i = getelementptr inbounds i8, ptr %c, i64 176, !dbg !2266
  %1 = load ptr, ptr %rcurr.i, align 8, !dbg !2266, !tbaa !1468
  %keylen.i = getelementptr inbounds i8, ptr %c, i64 394, !dbg !2267
  %2 = load i16, ptr %keylen.i, align 2, !dbg !2267, !tbaa !1056
  %idx.ext.i = zext i16 %2 to i64
  %idx.neg.i = sub nsw i64 0, %idx.ext.i, !dbg !2268
  %add.ptr.i = getelementptr inbounds i8, ptr %1, i64 %idx.neg.i, !dbg !2268
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !2235, metadata !DIExpression()), !dbg !2262
  tail call void @llvm.dbg.value(metadata i64 %idx.ext.i, metadata !2236, metadata !DIExpression()), !dbg !2262
  %cmd = getelementptr inbounds i8, ptr %c, i64 432, !dbg !2269
  %3 = load i16, ptr %cmd, align 8, !dbg !2269, !tbaa !1117
  %4 = icmp ult i16 %3, 36, !dbg !2270
  %switch.cast = zext nneg i16 %3 to i36, !dbg !2270
  %switch.downshift = lshr i36 -33554432000, %switch.cast, !dbg !2270
  %switch.masked = trunc i36 %switch.downshift to i1, !dbg !2270
  %5 = select i1 %4, i1 %switch.masked, i1 false, !dbg !2270
  tail call void @llvm.dbg.value(metadata i1 %5, metadata !2237, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2262
  tail call void @llvm.dbg.value(metadata i1 poison, metadata !2238, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2262
  %cmp24.not = icmp eq i16 %3, 28, !dbg !2271
  tail call void @llvm.dbg.value(metadata i1 %cmp24.not, metadata !2239, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2262
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2240, metadata !DIExpression()), !dbg !2262
  %6 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2272, !tbaa !1172
  %cmp26 = icmp sgt i32 %6, 1, !dbg !2274
  br i1 %cmp26, label %if.then, label %if.end33, !dbg !2275

if.then:                                          ; preds = %entry
  %7 = load ptr, ptr @stderr, align 8, !dbg !2276, !tbaa !1091
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !2278
  %8 = load i32, ptr %sfd, align 8, !dbg !2278, !tbaa !1107
  %cond = select i1 %5, ptr @.str.39, ptr @.str.40, !dbg !2279
  %call28 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %7, ptr noundef nonnull @.str.38, i32 noundef %8, ptr noundef nonnull %cond) #12, !dbg !2280
  %9 = load ptr, ptr @stderr, align 8, !dbg !2281, !tbaa !1091
  %call29 = tail call i64 @fwrite(ptr noundef %add.ptr.i, i64 noundef 1, i64 noundef %idx.ext.i, ptr noundef %9) #13, !dbg !2283
  %10 = load ptr, ptr @stderr, align 8, !dbg !2284, !tbaa !1091
  %call32 = tail call i32 @fputc(i32 noundef 10, ptr noundef %10), !dbg !2285
  br label %if.end33, !dbg !2286

if.end33:                                         ; preds = %if.then, %entry
  br i1 %5, label %if.then35, label %if.else, !dbg !2287

if.then35:                                        ; preds = %if.end33
  tail call void @llvm.dbg.value(metadata ptr %extbuf, metadata !2241, metadata !DIExpression()), !dbg !2288
  %body = getelementptr inbounds i8, ptr %extbuf, i64 24, !dbg !2289
  %11 = load i32, ptr %body, align 8, !dbg !2289, !tbaa !1056
  tail call void @llvm.dbg.value(metadata i32 %11, metadata !1503, metadata !DIExpression()), !dbg !2290
  %or7.i = tail call noundef i32 @llvm.bswap.i32(i32 %11), !dbg !2292
  %conv37 = zext i32 %or7.i to i64, !dbg !2289
  tail call void @llvm.dbg.value(metadata i64 %conv37, metadata !2257, metadata !DIExpression()), !dbg !2288
  %call38 = tail call i32 @realtime(i64 noundef %conv37) #11, !dbg !2293
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !2294
  %12 = load ptr, ptr %thread, align 8, !dbg !2294, !tbaa !1050
  %call39 = tail call ptr @item_touch(ptr noundef %add.ptr.i, i64 noundef %idx.ext.i, i32 noundef %call38, ptr noundef %12) #11, !dbg !2295
  tail call void @llvm.dbg.value(metadata ptr %call39, metadata !2233, metadata !DIExpression()), !dbg !2262
  br label %if.end42, !dbg !2296

if.else:                                          ; preds = %if.end33
  %thread40 = getelementptr inbounds i8, ptr %c, i64 456, !dbg !2297
  %13 = load ptr, ptr %thread40, align 8, !dbg !2297, !tbaa !1050
  %call41 = tail call ptr @item_get(ptr noundef %add.ptr.i, i64 noundef %idx.ext.i, ptr noundef %13, i1 noundef zeroext true) #11, !dbg !2299
  tail call void @llvm.dbg.value(metadata ptr %call41, metadata !2233, metadata !DIExpression()), !dbg !2262
  br label %if.end42

if.end42:                                         ; preds = %if.else, %if.then35
  %it.0 = phi ptr [ %call39, %if.then35 ], [ %call41, %if.else ], !dbg !2300
  tail call void @llvm.dbg.value(metadata ptr %it.0, metadata !2233, metadata !DIExpression()), !dbg !2262
  %tobool43 = icmp ne ptr %it.0, null, !dbg !2301
  br i1 %tobool43, label %if.then44, label %if.then217, !dbg !2302

if.then44:                                        ; preds = %if.end42
  tail call void @llvm.dbg.value(metadata i16 0, metadata !2258, metadata !DIExpression()), !dbg !2303
  %nbytes = getelementptr inbounds i8, ptr %it.0, i64 32, !dbg !2304
  %14 = load i32, ptr %nbytes, align 8, !dbg !2304, !tbaa !1072
  %add = add i32 %14, 2, !dbg !2305
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !2261, metadata !DIExpression()), !dbg !2303
  %thread48 = getelementptr inbounds i8, ptr %c, i64 456, !dbg !2306
  %15 = load ptr, ptr %thread48, align 8, !dbg !2306, !tbaa !1050
  %stats = getelementptr inbounds i8, ptr %15, i64 352, !dbg !2307
  %call49 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #11, !dbg !2308
  %16 = load ptr, ptr %thread48, align 8, !dbg !2309, !tbaa !1050
  %slabs_clsid = getelementptr inbounds i8, ptr %it.0, i64 40, !dbg !2309
  br i1 %5, label %if.then51, label %if.else58, !dbg !2311

if.then51:                                        ; preds = %if.then44
  %touch_cmds = getelementptr inbounds i8, ptr %16, i64 424, !dbg !2312
  %17 = load i64, ptr %touch_cmds, align 8, !dbg !2314, !tbaa !2315
  %inc = add i64 %17, 1, !dbg !2314
  store i64 %inc, ptr %touch_cmds, align 8, !dbg !2314, !tbaa !2315
  %slab_stats = getelementptr inbounds i8, ptr %16, i64 632, !dbg !2316
  %18 = load i8, ptr %slabs_clsid, align 8, !dbg !2317, !tbaa !1056
  %19 = and i8 %18, 63, !dbg !2317
  %idxprom = zext nneg i8 %19 to i64
  %touch_hits = getelementptr inbounds [64 x %struct.slab_stats], ptr %slab_stats, i64 0, i64 %idxprom, i32 2, !dbg !2318
  br label %if.end68, !dbg !2319

if.else58:                                        ; preds = %if.then44
  %get_cmds = getelementptr inbounds i8, ptr %16, i64 392, !dbg !2320
  %20 = load i64, ptr %get_cmds, align 8, !dbg !2322, !tbaa !2323
  %inc61 = add i64 %20, 1, !dbg !2322
  store i64 %inc61, ptr %get_cmds, align 8, !dbg !2322, !tbaa !2323
  %lru_hits = getelementptr inbounds i8, ptr %16, i64 4728, !dbg !2324
  %21 = load i8, ptr %slabs_clsid, align 8, !dbg !2325, !tbaa !1056
  %idxprom65 = zext i8 %21 to i64, !dbg !2326
  %arrayidx66 = getelementptr inbounds [256 x i64], ptr %lru_hits, i64 0, i64 %idxprom65, !dbg !2326
  br label %if.end68

if.end68:                                         ; preds = %if.else58, %if.then51
  %arrayidx66.sink360 = phi ptr [ %arrayidx66, %if.else58 ], [ %touch_hits, %if.then51 ]
  %22 = load i64, ptr %arrayidx66.sink360, align 8, !dbg !2309, !tbaa !1104
  %inc67 = add i64 %22, 1, !dbg !2309
  store i64 %inc67, ptr %arrayidx66.sink360, align 8, !dbg !2309, !tbaa !1104
  %stats70 = getelementptr inbounds i8, ptr %16, i64 352, !dbg !2327
  %call72 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats70) #11, !dbg !2328
  %23 = load i16, ptr %cmd, align 8, !dbg !2329, !tbaa !1117
  %cmp79 = icmp eq i16 %23, 28, !dbg !2331
  br i1 %cmp79, label %if.then81, label %if.else85, !dbg !2332

if.then81:                                        ; preds = %if.end68
  %24 = load i32, ptr %nbytes, align 8, !dbg !2333, !tbaa !1072
  %sub83.neg = add i32 %14, 4, !dbg !2335
  %sub84 = sub i32 %sub83.neg, %24, !dbg !2336
  tail call void @llvm.dbg.value(metadata i32 %sub84, metadata !2261, metadata !DIExpression()), !dbg !2303
  br label %if.end93, !dbg !2337

if.else85:                                        ; preds = %if.end68
  switch i16 %3, label %if.end93 [
    i16 35, label %if.then87
    i16 12, label %if.then87
  ], !dbg !2338

if.then87:                                        ; preds = %if.else85, %if.else85
  %25 = zext i16 %2 to i32, !dbg !2339
  %conv90 = add i32 %add, %25, !dbg !2339
  tail call void @llvm.dbg.value(metadata i32 %conv90, metadata !2261, metadata !DIExpression()), !dbg !2303
  tail call void @llvm.dbg.value(metadata i16 %2, metadata !2258, metadata !DIExpression()), !dbg !2303
  br label %if.end93, !dbg !2342

if.end93:                                         ; preds = %if.else85, %if.then87, %if.then81
  %keylen45.0 = phi i16 [ 0, %if.then81 ], [ %2, %if.then87 ], [ 0, %if.else85 ], !dbg !2303
  %bodylen.0 = phi i32 [ %sub84, %if.then81 ], [ %conv90, %if.then87 ], [ %add, %if.else85 ], !dbg !2303
  tail call void @llvm.dbg.value(metadata i32 %bodylen.0, metadata !2261, metadata !DIExpression()), !dbg !2303
  tail call void @llvm.dbg.value(metadata i16 %keylen45.0, metadata !2258, metadata !DIExpression()), !dbg !2303
  tail call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 0, i8 noundef zeroext 4, i16 noundef zeroext %keylen45.0, i32 noundef %bodylen.0), !dbg !2343
  %it_flags = getelementptr inbounds i8, ptr %it.0, i64 38, !dbg !2344
  %26 = load i16, ptr %it_flags, align 2, !dbg !2344, !tbaa !1064
  %27 = and i16 %26, 2, !dbg !2344
  %tobool96.not = icmp eq i16 %27, 0, !dbg !2344
  br i1 %tobool96.not, label %cond.end, label %cond.true, !dbg !2344

cond.true:                                        ; preds = %if.end93
  %data = getelementptr inbounds i8, ptr %it.0, i64 48, !dbg !2344
  %28 = load i64, ptr %data, align 8, !dbg !2344, !tbaa !1056
  br label %cond.end, !dbg !2344

cond.end:                                         ; preds = %if.end93, %cond.true
  %cond98 = phi i64 [ %28, %cond.true ], [ 0, %if.end93 ], !dbg !2344
  %call99 = tail call i64 @htonll(i64 noundef %cond98) #11, !dbg !2345
  %cas = getelementptr inbounds i8, ptr %0, i64 176, !dbg !2346
  store i64 %call99, ptr %cas, align 8, !dbg !2347, !tbaa !1056
  %29 = load i16, ptr %it_flags, align 2, !dbg !2348, !tbaa !1064
  %conv101 = zext i16 %29 to i32, !dbg !2348
  %and102 = and i32 %conv101, 256, !dbg !2348
  %tobool103.not = icmp eq i32 %and102, 0, !dbg !2348
  br i1 %tobool103.not, label %if.end119, label %if.then104, !dbg !2351

if.then104:                                       ; preds = %cond.end
  %data105 = getelementptr inbounds i8, ptr %it.0, i64 48, !dbg !2352
  %nkey106 = getelementptr inbounds i8, ptr %it.0, i64 41, !dbg !2352
  %30 = load i8, ptr %nkey106, align 1, !dbg !2352, !tbaa !1056
  %idx.ext = zext i8 %30 to i64
  %add.ptr = getelementptr inbounds i8, ptr %data105, i64 %idx.ext, !dbg !2352
  %add.ptr108 = getelementptr inbounds i8, ptr %add.ptr, i64 1, !dbg !2352
  %and111 = shl nuw nsw i32 %conv101, 2, !dbg !2352
  %31 = and i32 %and111, 8, !dbg !2352
  %cond113 = zext nneg i32 %31 to i64, !dbg !2352
  %add.ptr114 = getelementptr inbounds i8, ptr %add.ptr108, i64 %cond113, !dbg !2352
  %32 = load i32, ptr %add.ptr114, align 4, !dbg !2352, !tbaa !1072
  br label %if.end119, !dbg !2352

if.end119:                                        ; preds = %cond.end, %if.then104
  %.sink = phi i32 [ %32, %if.then104 ], [ 0, %cond.end ], !dbg !2348
  %33 = getelementptr inbounds i8, ptr %0, i64 184, !dbg !2348
  tail call void @llvm.dbg.value(metadata i32 %.sink, metadata !1503, metadata !DIExpression()), !dbg !2354
  %or7.i354 = tail call noundef i32 @llvm.bswap.i32(i32 %.sink), !dbg !2356
  store i32 %or7.i354, ptr %33, align 8, !dbg !2357, !tbaa !1056
  %34 = load ptr, ptr %resp, align 8, !dbg !2358, !tbaa !1184
  tail call void @resp_add_iov(ptr noundef %34, ptr noundef nonnull %33, i32 noundef 4) #11, !dbg !2359
  switch i16 %3, label %if.end138 [
    i16 35, label %if.then128
    i16 12, label %if.then128
  ], !dbg !2360

if.then128:                                       ; preds = %if.end119, %if.end119
  %35 = load ptr, ptr %resp, align 8, !dbg !2361, !tbaa !1184
  %data130 = getelementptr inbounds i8, ptr %it.0, i64 48, !dbg !2364
  %36 = load i16, ptr %it_flags, align 2, !dbg !2364, !tbaa !1064
  %37 = shl i16 %36, 2, !dbg !2364
  %38 = and i16 %37, 8, !dbg !2364
  %cond135 = zext nneg i16 %38 to i64, !dbg !2364
  %add.ptr136 = getelementptr inbounds i8, ptr %data130, i64 %cond135, !dbg !2364
  %conv137 = zext i16 %2 to i32, !dbg !2365
  tail call void @resp_add_iov(ptr noundef %35, ptr noundef nonnull %add.ptr136, i32 noundef %conv137) #11, !dbg !2366
  br label %if.end138, !dbg !2367

if.end138:                                        ; preds = %if.end119, %if.then128
  br i1 %cmp24.not, label %if.then199, label %if.then140, !dbg !2368

if.then140:                                       ; preds = %if.end138
  %39 = load i16, ptr %it_flags, align 2, !dbg !2369, !tbaa !1064
  %conv142 = zext i16 %39 to i32, !dbg !2373
  %and143 = and i32 %conv142, 128, !dbg !2374
  %tobool144.not = icmp eq i32 %and143, 0, !dbg !2374
  br i1 %tobool144.not, label %if.else163, label %if.then145, !dbg !2375

if.then145:                                       ; preds = %if.then140
  %40 = load ptr, ptr %resp, align 8, !dbg !2376, !tbaa !1184
  %call147 = tail call i32 @storage_get_item(ptr noundef nonnull %c, ptr noundef nonnull %it.0, ptr noundef %40) #11, !dbg !2379
  %cmp148.not = icmp eq i32 %call147, 0, !dbg !2380
  br i1 %cmp148.not, label %if.then199, label %if.end215, !dbg !2381

if.else163:                                       ; preds = %if.then140
  %and166 = and i32 %conv142, 32, !dbg !2382
  %cmp167 = icmp eq i32 %and166, 0, !dbg !2384
  %41 = load ptr, ptr %resp, align 8, !dbg !2385, !tbaa !1184
  br i1 %cmp167, label %if.then169, label %if.else191, !dbg !2386

if.then169:                                       ; preds = %if.else163
  %data171 = getelementptr inbounds i8, ptr %it.0, i64 48, !dbg !2387
  %nkey172 = getelementptr inbounds i8, ptr %it.0, i64 41, !dbg !2387
  %42 = load i8, ptr %nkey172, align 1, !dbg !2387, !tbaa !1056
  %idx.ext174 = zext i8 %42 to i64
  %add.ptr175 = getelementptr inbounds i8, ptr %data171, i64 %idx.ext174, !dbg !2387
  %add.ptr176 = getelementptr inbounds i8, ptr %add.ptr175, i64 1, !dbg !2387
  %and179 = lshr i32 %conv142, 6, !dbg !2387
  %43 = and i32 %and179, 4, !dbg !2387
  %cond181 = zext nneg i32 %43 to i64, !dbg !2387
  %add.ptr182 = getelementptr inbounds i8, ptr %add.ptr176, i64 %cond181, !dbg !2387
  %and185 = shl nuw nsw i32 %conv142, 2, !dbg !2387
  %44 = and i32 %and185, 8, !dbg !2387
  %cond187 = zext nneg i32 %44 to i64, !dbg !2387
  %add.ptr188 = getelementptr inbounds i8, ptr %add.ptr182, i64 %cond187, !dbg !2387
  %45 = load i32, ptr %nbytes, align 8, !dbg !2389, !tbaa !1072
  %sub190 = add nsw i32 %45, -2, !dbg !2390
  tail call void @resp_add_iov(ptr noundef %41, ptr noundef nonnull %add.ptr188, i32 noundef %sub190) #11, !dbg !2391
  br label %if.then199, !dbg !2392

if.else191:                                       ; preds = %if.else163
  %46 = load i32, ptr %nbytes, align 8, !dbg !2393, !tbaa !1072
  %sub194 = add nsw i32 %46, -2, !dbg !2395
  tail call void @resp_add_chunked_iov(ptr noundef %41, ptr noundef nonnull %it.0, i32 noundef %sub194) #11, !dbg !2396
  br label %if.then199

if.then199:                                       ; preds = %if.then145, %if.then169, %if.else191, %if.end138
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2240, metadata !DIExpression()), !dbg !2262
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 1) #11, !dbg !2397
  %47 = load i16, ptr %it_flags, align 2, !dbg !2400, !tbaa !1064
  %48 = and i16 %47, 128, !dbg !2402
  %cmp203.not = icmp eq i16 %48, 0, !dbg !2403
  %brmerge = or i1 %cmp24.not, %cmp203.not, !dbg !2404
  %49 = load ptr, ptr %resp, align 8, !dbg !2405, !tbaa !1184
  %item210 = getelementptr inbounds i8, ptr %49, i64 40, !dbg !2405
  br i1 %brmerge, label %if.else208, label %if.then206, !dbg !2404

if.then206:                                       ; preds = %if.then199
  store ptr null, ptr %item210, align 8, !dbg !2406, !tbaa !2408
  br label %if.end256, !dbg !2409

if.else208:                                       ; preds = %if.then199
  store ptr %it.0, ptr %item210, align 8, !dbg !2410, !tbaa !2408
  br label %if.end256

if.end215:                                        ; preds = %if.then145
  %50 = load ptr, ptr %thread48, align 8, !dbg !2412, !tbaa !1050
  %stats152 = getelementptr inbounds i8, ptr %50, i64 352, !dbg !2414
  %call154 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats152) #11, !dbg !2415
  %51 = load ptr, ptr %thread48, align 8, !dbg !2416, !tbaa !1050
  %get_oom_extstore = getelementptr inbounds i8, ptr %51, i64 600, !dbg !2417
  %52 = load i64, ptr %get_oom_extstore, align 8, !dbg !2418, !tbaa !2419
  %inc157 = add i64 %52, 1, !dbg !2418
  store i64 %inc157, ptr %get_oom_extstore, align 8, !dbg !2418, !tbaa !2419
  %stats159 = getelementptr inbounds i8, ptr %51, i64 352, !dbg !2420
  %call161 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats159) #11, !dbg !2421
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2240, metadata !DIExpression()), !dbg !2262
  tail call void @item_remove(ptr noundef nonnull %it.0) #11, !dbg !2422
  br label %if.then217, !dbg !2424

if.then217:                                       ; preds = %if.end215, %if.end42
  %thread218 = getelementptr inbounds i8, ptr %c, i64 456, !dbg !2425
  %53 = load ptr, ptr %thread218, align 8, !dbg !2425, !tbaa !1050
  %stats219 = getelementptr inbounds i8, ptr %53, i64 352, !dbg !2428
  %call221 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats219) #11, !dbg !2429
  %54 = load ptr, ptr %thread218, align 8, !dbg !2430, !tbaa !1050
  %. = select i1 %5, i64 424, i64 392
  %.367 = select i1 %5, i64 432, i64 400
  %get_cmds234 = getelementptr inbounds i8, ptr %54, i64 %., !dbg !2430
  %55 = load i64, ptr %get_cmds234, align 8, !dbg !2430, !tbaa !1104
  %inc235 = add i64 %55, 1, !dbg !2430
  store i64 %inc235, ptr %get_cmds234, align 8, !dbg !2430, !tbaa !1104
  %get_misses = getelementptr inbounds i8, ptr %54, i64 %.367, !dbg !2430
  %56 = load i64, ptr %get_misses, align 8, !dbg !2430, !tbaa !1104
  %inc238 = add i64 %56, 1, !dbg !2430
  store i64 %inc238, ptr %get_misses, align 8, !dbg !2430, !tbaa !1104
  %stats241 = getelementptr inbounds i8, ptr %54, i64 352, !dbg !2432
  %call243 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats241) #11, !dbg !2433
  %noreply = getelementptr inbounds i8, ptr %c, i64 364, !dbg !2434
  %57 = load i8, ptr %noreply, align 4, !dbg !2434, !tbaa !1149, !range !1123, !noundef !1124
  %tobool248 = trunc nuw i8 %57 to i1, !dbg !2434
  br i1 %tobool248, label %if.then249, label %if.else250, !dbg !2436

if.then249:                                       ; preds = %if.then217
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 1) #11, !dbg !2437
  br label %if.end256, !dbg !2439

if.else250:                                       ; preds = %if.then217
  switch i16 %3, label %if.else253 [
    i16 35, label %if.then252
    i16 12, label %if.then252
  ], !dbg !2440

if.then252:                                       ; preds = %if.else250, %if.else250
  tail call fastcc void @write_bin_miss_response(ptr noundef nonnull %c, ptr noundef %add.ptr.i, i64 noundef %idx.ext.i), !dbg !2442
  br label %if.end256, !dbg !2445

if.else253:                                       ; preds = %if.else250
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2446, metadata !DIExpression()), !dbg !2456
  tail call void @llvm.dbg.value(metadata ptr null, metadata !2451, metadata !DIExpression()), !dbg !2456
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2452, metadata !DIExpression()), !dbg !2456
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !2459
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1164, metadata !DIExpression()), !dbg !2459
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !2459
  tail call void @llvm.dbg.value(metadata ptr @.str.8, metadata !1165, metadata !DIExpression()), !dbg !2459
  %58 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2462, !tbaa !1172
  %cmp.i.i = icmp sgt i32 %58, 1, !dbg !2463
  br i1 %cmp.i.i, label %if.then9.i.i, label %write_bin_miss_response.exit, !dbg !2464

if.then9.i.i:                                     ; preds = %if.else253
  %59 = load ptr, ptr @stderr, align 8, !dbg !2465, !tbaa !1091
  %sfd10.i.i = getelementptr inbounds i8, ptr %c, i64 8, !dbg !2466
  %60 = load i32, ptr %sfd10.i.i, align 8, !dbg !2466, !tbaa !1107
  %call11.i.i = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %59, ptr noundef nonnull @.str.17, i32 noundef %60, ptr noundef nonnull @.str.8) #12, !dbg !2467
  br label %write_bin_miss_response.exit, !dbg !2468

write_bin_miss_response.exit:                     ; preds = %if.else253, %if.then9.i.i
  tail call void @llvm.dbg.value(metadata i64 9, metadata !1167, metadata !DIExpression()), !dbg !2459
  tail call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 1, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 9), !dbg !2469
  %61 = load ptr, ptr %resp, align 8, !dbg !2470, !tbaa !1184
  tail call void @resp_add_iov(ptr noundef %61, ptr noundef nonnull @.str.8, i32 noundef 9) #11, !dbg !2471
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 9) #11, !dbg !2472
  br label %if.end256

if.end256:                                        ; preds = %if.then206, %if.else208, %if.then249, %write_bin_miss_response.exit, %if.then252
  %62 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 16), align 8, !dbg !2473, !tbaa !2146
  %tobool257.not = icmp eq i32 %62, 0, !dbg !2475
  br i1 %tobool257.not, label %if.end261, label %if.then258, !dbg !2476

if.then258:                                       ; preds = %if.end256
  tail call void @stats_prefix_record_get(ptr noundef %add.ptr.i, i64 noundef %idx.ext.i, i1 noundef zeroext %tobool43) #11, !dbg !2477
  br label %if.end261, !dbg !2479

if.end261:                                        ; preds = %if.then258, %if.end256
  ret void, !dbg !2480
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_bin_delete(ptr noundef %c) unnamed_addr #0 !dbg !2481 {
entry:
  %hv = alloca i32, align 4, !DIAssignID !2494
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2485, metadata !DIExpression(), metadata !2494, metadata ptr %hv, metadata !DIExpression()), !dbg !2495
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2483, metadata !DIExpression()), !dbg !2495
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %hv) #11, !dbg !2496
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2095, metadata !DIExpression()), !dbg !2497
  %rcurr.i = getelementptr inbounds i8, ptr %c, i64 176, !dbg !2499
  %0 = load ptr, ptr %rcurr.i, align 8, !dbg !2499, !tbaa !1468
  %keylen.i = getelementptr inbounds i8, ptr %c, i64 394, !dbg !2500
  %1 = load i16, ptr %keylen.i, align 2, !dbg !2500, !tbaa !1056
  %idx.ext.i = zext i16 %1 to i64
  %idx.neg.i = sub nsw i64 0, %idx.ext.i, !dbg !2501
  %add.ptr.i = getelementptr inbounds i8, ptr %0, i64 %idx.neg.i, !dbg !2501
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !2486, metadata !DIExpression()), !dbg !2495
  tail call void @llvm.dbg.value(metadata i64 %idx.ext.i, metadata !2487, metadata !DIExpression()), !dbg !2495
  %2 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2502, !tbaa !1172
  %cmp = icmp sgt i32 %2, 1, !dbg !2503
  br i1 %cmp, label %if.then, label %if.end, !dbg !2504

if.then:                                          ; preds = %entry
  %3 = load ptr, ptr @stderr, align 8, !dbg !2505, !tbaa !1091
  %4 = tail call i64 @fwrite(ptr nonnull @.str.41, i64 9, i64 1, ptr %3) #13, !dbg !2506
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2488, metadata !DIExpression()), !dbg !2507
  %cmp493.not = icmp eq i16 %1, 0, !dbg !2508
  br i1 %cmp493.not, label %for.end, label %for.body, !dbg !2511

for.body:                                         ; preds = %if.then, %for.body
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.body ], [ 0, %if.then ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2488, metadata !DIExpression()), !dbg !2507
  %5 = load ptr, ptr @stderr, align 8, !dbg !2512, !tbaa !1091
  %arrayidx = getelementptr inbounds i8, ptr %add.ptr.i, i64 %indvars.iv, !dbg !2514
  %6 = load i8, ptr %arrayidx, align 1, !dbg !2514, !tbaa !1056
  %conv6 = sext i8 %6 to i32, !dbg !2514
  %fputc77 = tail call i32 @fputc(i32 %conv6, ptr %5), !dbg !2515
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !2516
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !2488, metadata !DIExpression()), !dbg !2507
  %exitcond.not = icmp eq i64 %indvars.iv.next, %idx.ext.i, !dbg !2508
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !2511, !llvm.loop !2517

for.end:                                          ; preds = %for.body, %if.then
  %7 = load ptr, ptr @stderr, align 8, !dbg !2519, !tbaa !1091
  %fputc = tail call i32 @fputc(i32 10, ptr %7), !dbg !2520
  br label %if.end, !dbg !2521

if.end:                                           ; preds = %for.end, %entry
  %8 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 16), align 8, !dbg !2522, !tbaa !2146
  %tobool.not = icmp eq i32 %8, 0, !dbg !2524
  br i1 %tobool.not, label %if.end10, label %if.then9, !dbg !2525

if.then9:                                         ; preds = %if.end
  tail call void @stats_prefix_record_delete(ptr noundef %add.ptr.i, i64 noundef %idx.ext.i) #11, !dbg !2526
  br label %if.end10, !dbg !2528

if.end10:                                         ; preds = %if.then9, %if.end
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !2529
  %9 = load ptr, ptr %thread, align 8, !dbg !2529, !tbaa !1050
  %call11 = call ptr @item_get_locked(ptr noundef %add.ptr.i, i64 noundef %idx.ext.i, ptr noundef %9, i1 noundef zeroext false, ptr noundef nonnull %hv) #11, !dbg !2530
  tail call void @llvm.dbg.value(metadata ptr %call11, metadata !2484, metadata !DIExpression()), !dbg !2495
  %tobool12.not = icmp eq ptr %call11, null, !dbg !2531
  br i1 %tobool12.not, label %if.else38, label %if.then13, !dbg !2532

if.then13:                                        ; preds = %if.end10
  %cas15 = getelementptr inbounds i8, ptr %c, i64 408, !dbg !2533
  %10 = load i64, ptr %cas15, align 8, !dbg !2533, !tbaa !1056
  tail call void @llvm.dbg.value(metadata i64 %10, metadata !2491, metadata !DIExpression()), !dbg !2534
  %cmp16 = icmp eq i64 %10, 0, !dbg !2535
  br i1 %cmp16, label %if.then22, label %lor.lhs.false, !dbg !2537

lor.lhs.false:                                    ; preds = %if.then13
  %it_flags = getelementptr inbounds i8, ptr %call11, i64 38, !dbg !2538
  %11 = load i16, ptr %it_flags, align 2, !dbg !2538, !tbaa !1064
  %12 = and i16 %11, 2, !dbg !2538
  %tobool19.not = icmp eq i16 %12, 0, !dbg !2538
  br i1 %tobool19.not, label %if.else, label %cond.end, !dbg !2538

cond.end:                                         ; preds = %lor.lhs.false
  %data = getelementptr inbounds i8, ptr %call11, i64 48, !dbg !2538
  %13 = load i64, ptr %data, align 8, !dbg !2538, !tbaa !1056
  %cmp20 = icmp eq i64 %10, %13, !dbg !2539
  br i1 %cmp20, label %if.then22, label %if.else, !dbg !2540

if.then22:                                        ; preds = %cond.end, %if.then13
  %14 = load ptr, ptr %thread, align 8, !dbg !2541, !tbaa !1050
  %stats = getelementptr inbounds i8, ptr %14, i64 352, !dbg !2543
  %call24 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #11, !dbg !2544
  %15 = load ptr, ptr %thread, align 8, !dbg !2545, !tbaa !1050
  %slab_stats = getelementptr inbounds i8, ptr %15, i64 632, !dbg !2546
  %slabs_clsid = getelementptr inbounds i8, ptr %call11, i64 40, !dbg !2547
  %16 = load i8, ptr %slabs_clsid, align 8, !dbg !2547, !tbaa !1056
  %17 = and i8 %16, 63, !dbg !2547
  %idxprom29 = zext nneg i8 %17 to i64
  %delete_hits = getelementptr inbounds [64 x %struct.slab_stats], ptr %slab_stats, i64 0, i64 %idxprom29, i32 3, !dbg !2548
  %18 = load i64, ptr %delete_hits, align 8, !dbg !2549, !tbaa !2550
  %inc31 = add i64 %18, 1, !dbg !2549
  store i64 %inc31, ptr %delete_hits, align 8, !dbg !2549, !tbaa !2550
  %stats33 = getelementptr inbounds i8, ptr %15, i64 352, !dbg !2551
  %call35 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats33) #11, !dbg !2552
  %19 = load i32, ptr %hv, align 4, !dbg !2553, !tbaa !1072
  call void @do_item_unlink(ptr noundef nonnull %call11, i32 noundef %19) #11, !dbg !2554
  %20 = load ptr, ptr %thread, align 8, !dbg !2555, !tbaa !1050
  %storage = getelementptr inbounds i8, ptr %20, i64 6904, !dbg !2555
  %21 = load ptr, ptr %storage, align 8, !dbg !2555, !tbaa !2196
  call void @storage_delete(ptr noundef %21, ptr noundef nonnull %call11) #11, !dbg !2555
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1133, metadata !DIExpression()), !dbg !2557
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1138, metadata !DIExpression()), !dbg !2557
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1139, metadata !DIExpression()), !dbg !2557
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1140, metadata !DIExpression()), !dbg !2557
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1141, metadata !DIExpression()), !dbg !2557
  %noreply.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !2559
  %22 = load i8, ptr %noreply.i, align 4, !dbg !2559, !tbaa !1149, !range !1123, !noundef !1124
  %tobool.i = trunc nuw i8 %22 to i1, !dbg !2559
  br i1 %tobool.i, label %lor.lhs.false.i, label %if.then.i, !dbg !2560

lor.lhs.false.i:                                  ; preds = %if.then22
  %cmd.i = getelementptr inbounds i8, ptr %c, i64 432, !dbg !2561
  %23 = load i16, ptr %cmd.i, align 8, !dbg !2561, !tbaa !1117
  switch i16 %23, label %if.end37 [
    i16 0, label %if.then.i
    i16 12, label %if.then.i
  ], !dbg !2562

if.then.i:                                        ; preds = %lor.lhs.false.i, %lor.lhs.false.i, %if.then22
  call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 0, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 0), !dbg !2563
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1142, metadata !DIExpression()), !dbg !2564
  br label %if.end37

if.else:                                          ; preds = %lor.lhs.false, %cond.end
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !2565
  tail call void @llvm.dbg.value(metadata i32 2, metadata !1164, metadata !DIExpression()), !dbg !2565
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !2565
  tail call void @llvm.dbg.value(metadata ptr @.str.10, metadata !1165, metadata !DIExpression()), !dbg !2565
  %24 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2568, !tbaa !1172
  %cmp.i = icmp sgt i32 %24, 1, !dbg !2569
  br i1 %cmp.i, label %if.then9.i, label %if.end12.i, !dbg !2570

if.then9.i:                                       ; preds = %if.else
  %25 = load ptr, ptr @stderr, align 8, !dbg !2571, !tbaa !1091
  %sfd10.i = getelementptr inbounds i8, ptr %c, i64 8, !dbg !2572
  %26 = load i32, ptr %sfd10.i, align 8, !dbg !2572, !tbaa !1107
  %call11.i = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %25, ptr noundef nonnull @.str.17, i32 noundef %26, ptr noundef nonnull @.str.10) #12, !dbg !2573
  br label %if.end12.i, !dbg !2574

if.end12.i:                                       ; preds = %if.then9.i, %if.else
  tail call void @llvm.dbg.value(metadata i64 20, metadata !1167, metadata !DIExpression()), !dbg !2565
  call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 2, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 20), !dbg !2575
  %resp.i = getelementptr inbounds i8, ptr %c, i64 192, !dbg !2576
  %27 = load ptr, ptr %resp.i, align 8, !dbg !2576, !tbaa !1184
  call void @resp_add_iov(ptr noundef %27, ptr noundef nonnull @.str.10, i32 noundef 20) #11, !dbg !2577
  br label %if.end37

if.end37:                                         ; preds = %if.then.i, %lor.lhs.false.i, %if.end12.i
  %.sink = phi i32 [ 9, %if.end12.i ], [ 1, %lor.lhs.false.i ], [ 1, %if.then.i ]
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef %.sink) #11, !dbg !2578
  call void @do_item_remove(ptr noundef nonnull %call11) #11, !dbg !2579
  br label %if.end50, !dbg !2580

if.else38:                                        ; preds = %if.end10
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !2581
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1164, metadata !DIExpression()), !dbg !2581
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !2581
  tail call void @llvm.dbg.value(metadata ptr @.str.8, metadata !1165, metadata !DIExpression()), !dbg !2581
  %28 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2584, !tbaa !1172
  %cmp.i80 = icmp sgt i32 %28, 1, !dbg !2585
  br i1 %cmp.i80, label %if.then9.i87, label %if.end12.i81, !dbg !2586

if.then9.i87:                                     ; preds = %if.else38
  %29 = load ptr, ptr @stderr, align 8, !dbg !2587, !tbaa !1091
  %sfd10.i88 = getelementptr inbounds i8, ptr %c, i64 8, !dbg !2588
  %30 = load i32, ptr %sfd10.i88, align 8, !dbg !2588, !tbaa !1107
  %call11.i89 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %29, ptr noundef nonnull @.str.17, i32 noundef %30, ptr noundef nonnull @.str.8) #12, !dbg !2589
  br label %if.end12.i81, !dbg !2590

if.end12.i81:                                     ; preds = %if.then9.i87, %if.else38
  tail call void @llvm.dbg.value(metadata i64 9, metadata !1167, metadata !DIExpression()), !dbg !2581
  call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 1, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 9), !dbg !2591
  %resp.i86 = getelementptr inbounds i8, ptr %c, i64 192, !dbg !2592
  %31 = load ptr, ptr %resp.i86, align 8, !dbg !2592, !tbaa !1184
  call void @resp_add_iov(ptr noundef %31, ptr noundef nonnull @.str.8, i32 noundef 9) #11, !dbg !2593
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 9) #11, !dbg !2594
  %32 = load ptr, ptr %thread, align 8, !dbg !2595, !tbaa !1050
  %stats40 = getelementptr inbounds i8, ptr %32, i64 352, !dbg !2596
  %call42 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats40) #11, !dbg !2597
  %33 = load ptr, ptr %thread, align 8, !dbg !2598, !tbaa !1050
  %delete_misses = getelementptr inbounds i8, ptr %33, i64 440, !dbg !2599
  %34 = load i64, ptr %delete_misses, align 8, !dbg !2600, !tbaa !2601
  %inc45 = add i64 %34, 1, !dbg !2600
  store i64 %inc45, ptr %delete_misses, align 8, !dbg !2600, !tbaa !2601
  %stats47 = getelementptr inbounds i8, ptr %33, i64 352, !dbg !2602
  %call49 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats47) #11, !dbg !2603
  br label %if.end50

if.end50:                                         ; preds = %if.end12.i81, %if.end37
  %35 = load i32, ptr %hv, align 4, !dbg !2604, !tbaa !1072
  call void @item_unlock(i32 noundef %35) #11, !dbg !2605
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %hv) #11, !dbg !2606
  ret void, !dbg !2606
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @complete_incr_bin(ptr noundef %c, ptr nocapture noundef %extbuf) unnamed_addr #0 !dbg !2607 {
entry:
  %tmpbuf = alloca [24 x i8], align 16, !DIAssignID !2645
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2614, metadata !DIExpression(), metadata !2645, metadata ptr %tmpbuf, metadata !DIExpression()), !dbg !2646
  %cas = alloca i64, align 8, !DIAssignID !2647
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2616, metadata !DIExpression(), metadata !2647, metadata ptr %cas, metadata !DIExpression()), !dbg !2646
  %cas77 = alloca i64, align 8, !DIAssignID !2648
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2642, metadata !DIExpression(), metadata !2648, metadata ptr %cas77, metadata !DIExpression()), !dbg !2649
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2609, metadata !DIExpression()), !dbg !2646
  tail call void @llvm.dbg.value(metadata ptr %extbuf, metadata !2610, metadata !DIExpression()), !dbg !2646
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %tmpbuf) #11, !dbg !2650
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %cas) #11, !dbg !2651
  store i64 0, ptr %cas, align 8, !dbg !2652, !tbaa !1104, !DIAssignID !2653
  tail call void @llvm.dbg.assign(metadata i64 0, metadata !2616, metadata !DIExpression(), metadata !2653, metadata ptr %cas, metadata !DIExpression()), !dbg !2646
  %resp = getelementptr inbounds i8, ptr %c, i64 192, !dbg !2654
  %0 = load ptr, ptr %resp, align 8, !dbg !2654, !tbaa !1184
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2617, metadata !DIExpression(DW_OP_plus_uconst, 160, DW_OP_stack_value)), !dbg !2646
  tail call void @llvm.dbg.value(metadata ptr %extbuf, metadata !2618, metadata !DIExpression()), !dbg !2646
  %body = getelementptr inbounds i8, ptr %extbuf, i64 24, !dbg !2655
  %1 = load i64, ptr %body, align 8, !dbg !2656, !tbaa !1056
  %call = tail call i64 @ntohll(i64 noundef %1) #11, !dbg !2657
  store i64 %call, ptr %body, align 8, !dbg !2658, !tbaa !1056
  %initial = getelementptr inbounds i8, ptr %extbuf, i64 32, !dbg !2659
  %2 = load i64, ptr %initial, align 8, !dbg !2659, !tbaa !1056
  %call4 = tail call i64 @ntohll(i64 noundef %2) #11, !dbg !2660
  store i64 %call4, ptr %initial, align 8, !dbg !2661, !tbaa !1056
  %expiration = getelementptr inbounds i8, ptr %extbuf, i64 40, !dbg !2662
  %3 = load i32, ptr %expiration, align 8, !dbg !2662, !tbaa !1056
  tail call void @llvm.dbg.value(metadata i32 %3, metadata !1503, metadata !DIExpression()), !dbg !2663
  %or7.i = tail call noundef i32 @llvm.bswap.i32(i32 %3), !dbg !2665
  store i32 %or7.i, ptr %expiration, align 8, !dbg !2666, !tbaa !1056
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2095, metadata !DIExpression()), !dbg !2667
  %rcurr.i = getelementptr inbounds i8, ptr %c, i64 176, !dbg !2669
  %4 = load ptr, ptr %rcurr.i, align 8, !dbg !2669, !tbaa !1468
  %keylen.i = getelementptr inbounds i8, ptr %c, i64 394, !dbg !2670
  %5 = load i16, ptr %keylen.i, align 2, !dbg !2670, !tbaa !1056
  %idx.ext.i = zext i16 %5 to i64
  %idx.neg.i = sub nsw i64 0, %idx.ext.i, !dbg !2671
  %add.ptr.i = getelementptr inbounds i8, ptr %4, i64 %idx.neg.i, !dbg !2671
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !2612, metadata !DIExpression()), !dbg !2646
  tail call void @llvm.dbg.value(metadata i64 %idx.ext.i, metadata !2613, metadata !DIExpression()), !dbg !2646
  %6 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2672, !tbaa !1172
  %cmp = icmp sgt i32 %6, 1, !dbg !2673
  br i1 %cmp, label %if.then, label %if.end, !dbg !2674

if.then:                                          ; preds = %entry
  %7 = load ptr, ptr @stderr, align 8, !dbg !2675, !tbaa !1091
  %8 = tail call i64 @fwrite(ptr nonnull @.str.42, i64 5, i64 1, ptr %7) #13, !dbg !2676
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2635, metadata !DIExpression()), !dbg !2677
  %cmp15251.not = icmp eq i16 %5, 0, !dbg !2678
  br i1 %cmp15251.not, label %for.end, label %for.body, !dbg !2681

for.body:                                         ; preds = %if.then, %for.body
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.body ], [ 0, %if.then ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2635, metadata !DIExpression()), !dbg !2677
  %9 = load ptr, ptr @stderr, align 8, !dbg !2682, !tbaa !1091
  %arrayidx = getelementptr inbounds i8, ptr %add.ptr.i, i64 %indvars.iv, !dbg !2684
  %10 = load i8, ptr %arrayidx, align 1, !dbg !2684, !tbaa !1056
  %conv17 = sext i8 %10 to i32, !dbg !2684
  %fputc = tail call i32 @fputc(i32 %conv17, ptr %9), !dbg !2685
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !2686
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !2635, metadata !DIExpression()), !dbg !2677
  %exitcond.not = icmp eq i64 %indvars.iv.next, %idx.ext.i, !dbg !2678
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !2681, !llvm.loop !2687

for.end:                                          ; preds = %for.body, %if.then
  %11 = load ptr, ptr @stderr, align 8, !dbg !2689, !tbaa !1091
  %12 = load i64, ptr %body, align 8, !dbg !2690, !tbaa !1056
  %13 = load i64, ptr %initial, align 8, !dbg !2691, !tbaa !1056
  %14 = load i32, ptr %expiration, align 8, !dbg !2692, !tbaa !1056
  %call25 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %11, ptr noundef nonnull @.str.43, i64 noundef %12, i64 noundef %13, i32 noundef %14) #12, !dbg !2693
  br label %if.end, !dbg !2694

if.end:                                           ; preds = %for.end, %entry
  %cas27 = getelementptr inbounds i8, ptr %c, i64 408, !dbg !2695
  %15 = load i64, ptr %cas27, align 8, !dbg !2695, !tbaa !1056
  %cmp28.not = icmp eq i64 %15, 0, !dbg !2697
  br i1 %cmp28.not, label %if.end33, label %if.then30, !dbg !2698

if.then30:                                        ; preds = %if.end
  store i64 %15, ptr %cas, align 8, !dbg !2699, !tbaa !1104, !DIAssignID !2701
  tail call void @llvm.dbg.assign(metadata i64 %15, metadata !2616, metadata !DIExpression(), metadata !2701, metadata ptr %cas, metadata !DIExpression()), !dbg !2646
  br label %if.end33, !dbg !2702

if.end33:                                         ; preds = %if.then30, %if.end
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !2703
  %16 = load ptr, ptr %thread, align 8, !dbg !2703, !tbaa !1050
  %cmd = getelementptr inbounds i8, ptr %c, i64 432, !dbg !2704
  %17 = load i16, ptr %cmd, align 8, !dbg !2704, !tbaa !1117
  %cmp35 = icmp eq i16 %17, 5, !dbg !2705
  %18 = load i64, ptr %body, align 8, !dbg !2706, !tbaa !1056
  %call40 = call i32 @add_delta(ptr noundef %16, ptr noundef %add.ptr.i, i64 noundef %idx.ext.i, i1 noundef zeroext %cmp35, i64 noundef %18, ptr noundef nonnull %tmpbuf, ptr noundef nonnull %cas) #11, !dbg !2707
  switch i32 %call40, label %sw.epilog [
    i32 0, label %sw.bb
    i32 1, label %sw.bb49
    i32 2, label %sw.bb50
    i32 3, label %sw.bb51
    i32 4, label %sw.bb147
  ], !dbg !2708

sw.bb:                                            ; preds = %if.end33
  %call42 = call i64 @__isoc23_strtoull(ptr noundef nonnull %tmpbuf, ptr noundef null, i32 noundef 10) #11, !dbg !2709
  %call43 = call i64 @htonll(i64 noundef %call42) #11, !dbg !2710
  %body44 = getelementptr inbounds i8, ptr %0, i64 184, !dbg !2711
  store i64 %call43, ptr %body44, align 8, !dbg !2712, !tbaa !1056
  %19 = load i64, ptr %cas, align 8, !dbg !2713, !tbaa !1104
  %tobool.not = icmp eq i64 %19, 0, !dbg !2713
  br i1 %tobool.not, label %if.end47, label %if.then45, !dbg !2715

if.then45:                                        ; preds = %sw.bb
  %cas46 = getelementptr inbounds i8, ptr %c, i64 416, !dbg !2716
  store i64 %19, ptr %cas46, align 8, !dbg !2718, !tbaa !1131
  br label %if.end47, !dbg !2719

if.end47:                                         ; preds = %if.then45, %sw.bb
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1133, metadata !DIExpression()), !dbg !2720
  tail call void @llvm.dbg.value(metadata ptr %body44, metadata !1138, metadata !DIExpression()), !dbg !2720
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1139, metadata !DIExpression()), !dbg !2720
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1140, metadata !DIExpression()), !dbg !2720
  tail call void @llvm.dbg.value(metadata i32 8, metadata !1141, metadata !DIExpression()), !dbg !2720
  %noreply.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !2722
  %20 = load i8, ptr %noreply.i, align 4, !dbg !2722, !tbaa !1149, !range !1123, !noundef !1124
  %tobool.i = trunc nuw i8 %20 to i1, !dbg !2722
  br i1 %tobool.i, label %lor.lhs.false.i, label %if.then.i, !dbg !2723

lor.lhs.false.i:                                  ; preds = %if.end47
  %21 = load i16, ptr %cmd, align 8, !dbg !2724, !tbaa !1117
  switch i16 %21, label %write_bin_response.exit [
    i16 0, label %if.then.i
    i16 12, label %if.then.i
  ], !dbg !2725

if.then.i:                                        ; preds = %lor.lhs.false.i, %lor.lhs.false.i, %if.end47
  call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 0, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 8), !dbg !2726
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1142, metadata !DIExpression()), !dbg !2727
  %22 = load ptr, ptr %resp, align 8, !dbg !2728, !tbaa !1184
  tail call void @llvm.dbg.value(metadata ptr %22, metadata !1142, metadata !DIExpression()), !dbg !2727
  call void @resp_add_iov(ptr noundef %22, ptr noundef nonnull %body44, i32 noundef 8) #11, !dbg !2729
  br label %write_bin_response.exit, !dbg !2730

write_bin_response.exit:                          ; preds = %lor.lhs.false.i, %if.then.i
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 1) #11, !dbg !2731
  br label %sw.epilog, !dbg !2732

sw.bb49:                                          ; preds = %if.end33
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !2733
  tail call void @llvm.dbg.value(metadata i32 6, metadata !1164, metadata !DIExpression()), !dbg !2733
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !2733
  tail call void @llvm.dbg.value(metadata ptr @.str.12, metadata !1165, metadata !DIExpression()), !dbg !2733
  %23 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2735, !tbaa !1172
  %cmp.i = icmp sgt i32 %23, 1, !dbg !2736
  br i1 %cmp.i, label %if.then9.i, label %if.end12.i, !dbg !2737

if.then9.i:                                       ; preds = %sw.bb49
  %24 = load ptr, ptr @stderr, align 8, !dbg !2738, !tbaa !1091
  %sfd10.i = getelementptr inbounds i8, ptr %c, i64 8, !dbg !2739
  %25 = load i32, ptr %sfd10.i, align 8, !dbg !2739, !tbaa !1107
  %call11.i = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %24, ptr noundef nonnull @.str.17, i32 noundef %25, ptr noundef nonnull @.str.12) #12, !dbg !2740
  br label %if.end12.i, !dbg !2741

if.end12.i:                                       ; preds = %if.then9.i, %sw.bb49
  tail call void @llvm.dbg.value(metadata i64 46, metadata !1167, metadata !DIExpression()), !dbg !2733
  call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 6, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 46), !dbg !2742
  %26 = load ptr, ptr %resp, align 8, !dbg !2743, !tbaa !1184
  call void @resp_add_iov(ptr noundef %26, ptr noundef nonnull @.str.12, i32 noundef 46) #11, !dbg !2744
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 9) #11, !dbg !2745
  br label %sw.epilog, !dbg !2746

sw.bb50:                                          ; preds = %if.end33
  call void @out_of_memory(ptr noundef nonnull %c, ptr noundef nonnull @.str.44) #11, !dbg !2747
  br label %sw.epilog, !dbg !2748

sw.bb51:                                          ; preds = %if.end33
  %27 = load i32, ptr %expiration, align 8, !dbg !2749, !tbaa !1056
  %cmp54.not = icmp eq i32 %27, -1, !dbg !2750
  br i1 %cmp54.not, label %if.else126, label %if.then56, !dbg !2751

if.then56:                                        ; preds = %sw.bb51
  %28 = load i64, ptr %initial, align 8, !dbg !2752, !tbaa !1056
  %call59 = call i64 @htonll(i64 noundef %28) #11, !dbg !2753
  %body60 = getelementptr inbounds i8, ptr %0, i64 184, !dbg !2754
  store i64 %call59, ptr %body60, align 8, !dbg !2755, !tbaa !1056
  %29 = load i64, ptr %initial, align 8, !dbg !2756, !tbaa !1056
  %call65 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %tmpbuf, i64 noundef 24, ptr noundef nonnull @.str.45, i64 noundef %29) #11, !dbg !2757
  %call67 = call i64 @strlen(ptr noundef nonnull dereferenceable(1) %tmpbuf) #14, !dbg !2758
  %conv68 = trunc i64 %call67 to i32, !dbg !2758
  tail call void @llvm.dbg.value(metadata i32 %conv68, metadata !2638, metadata !DIExpression()), !dbg !2759
  %30 = load i32, ptr %expiration, align 8, !dbg !2760, !tbaa !1056
  %conv71 = zext i32 %30 to i64, !dbg !2761
  %call72 = call i32 @realtime(i64 noundef %conv71) #11, !dbg !2762
  %add = add nsw i32 %conv68, 2, !dbg !2763
  %call73 = call ptr @item_alloc(ptr noundef %add.ptr.i, i64 noundef %idx.ext.i, i32 noundef 0, i32 noundef %call72, i32 noundef %add) #11, !dbg !2764
  tail call void @llvm.dbg.value(metadata ptr %call73, metadata !2611, metadata !DIExpression()), !dbg !2646
  %cmp74.not = icmp eq ptr %call73, null, !dbg !2765
  br i1 %cmp74.not, label %if.else124, label %if.then76, !dbg !2766

if.then76:                                        ; preds = %if.then56
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %cas77) #11, !dbg !2767
  store i64 0, ptr %cas77, align 8, !dbg !2768, !tbaa !1104, !DIAssignID !2769
  tail call void @llvm.dbg.assign(metadata i64 0, metadata !2642, metadata !DIExpression(), metadata !2769, metadata ptr %cas77, metadata !DIExpression()), !dbg !2649
  %data = getelementptr inbounds i8, ptr %call73, i64 48, !dbg !2770
  %nkey78 = getelementptr inbounds i8, ptr %call73, i64 41, !dbg !2770
  %31 = load i8, ptr %nkey78, align 1, !dbg !2770, !tbaa !1056
  %idx.ext = zext i8 %31 to i64
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %idx.ext, !dbg !2770
  %add.ptr80 = getelementptr inbounds i8, ptr %add.ptr, i64 1, !dbg !2770
  %it_flags = getelementptr inbounds i8, ptr %call73, i64 38, !dbg !2770
  %32 = load i16, ptr %it_flags, align 2, !dbg !2770, !tbaa !1064
  %conv81 = zext i16 %32 to i32, !dbg !2770
  %and = lshr i32 %conv81, 6, !dbg !2770
  %33 = and i32 %and, 4, !dbg !2770
  %cond = zext nneg i32 %33 to i64, !dbg !2770
  %add.ptr83 = getelementptr inbounds i8, ptr %add.ptr80, i64 %cond, !dbg !2770
  %and86 = shl nuw nsw i32 %conv81, 2, !dbg !2770
  %34 = and i32 %and86, 8, !dbg !2770
  %cond88 = zext nneg i32 %34 to i64, !dbg !2770
  %add.ptr89 = getelementptr inbounds i8, ptr %add.ptr83, i64 %cond88, !dbg !2770
  %sext = shl i64 %call67, 32, !dbg !2771
  %conv91 = ashr exact i64 %sext, 32, !dbg !2771
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr89, ptr nonnull align 16 %tmpbuf, i64 %conv91, i1 false), !dbg !2772
  %35 = load i8, ptr %nkey78, align 1, !dbg !2773, !tbaa !1056
  %idx.ext95 = zext i8 %35 to i64
  %add.ptr96 = getelementptr inbounds i8, ptr %data, i64 %idx.ext95, !dbg !2773
  %add.ptr97 = getelementptr inbounds i8, ptr %add.ptr96, i64 1, !dbg !2773
  %36 = load i16, ptr %it_flags, align 2, !dbg !2773, !tbaa !1064
  %conv99 = zext i16 %36 to i32, !dbg !2773
  %and100 = lshr i32 %conv99, 6, !dbg !2773
  %37 = and i32 %and100, 4, !dbg !2773
  %cond102 = zext nneg i32 %37 to i64, !dbg !2773
  %add.ptr103 = getelementptr inbounds i8, ptr %add.ptr97, i64 %cond102, !dbg !2773
  %and106 = shl nuw nsw i32 %conv99, 2, !dbg !2773
  %38 = and i32 %and106, 8, !dbg !2773
  %cond108 = zext nneg i32 %38 to i64, !dbg !2773
  %add.ptr109 = getelementptr inbounds i8, ptr %add.ptr103, i64 %cond108, !dbg !2773
  %add.ptr111 = getelementptr inbounds i8, ptr %add.ptr109, i64 %conv91, !dbg !2774
  store i16 2573, ptr %add.ptr111, align 1, !dbg !2775
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !2776
  %39 = load i32, ptr %sfd, align 8, !dbg !2776, !tbaa !1107
  %40 = load ptr, ptr %thread, align 8, !dbg !2777, !tbaa !1050
  %cur_sfd = getelementptr inbounds i8, ptr %40, i64 344, !dbg !2778
  store i32 %39, ptr %cur_sfd, align 8, !dbg !2779, !tbaa !1111
  %41 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 18), align 8, !dbg !2780, !tbaa !1120, !range !1123, !noundef !1124
  %tobool114 = trunc nuw i8 %41 to i1, !dbg !2780
  br i1 %tobool114, label %cond.true, label %cond.end, !dbg !2782

cond.true:                                        ; preds = %if.then76
  %call116 = call i64 @get_cas_id() #11, !dbg !2783
  br label %cond.end, !dbg !2782

cond.end:                                         ; preds = %if.then76, %cond.true
  %cond117 = phi i64 [ %call116, %cond.true ], [ 0, %if.then76 ], !dbg !2782
  %call118 = call i32 @store_item(ptr noundef nonnull %call73, i32 noundef 1, ptr noundef nonnull %40, ptr noundef null, ptr noundef nonnull %cas77, i64 noundef %cond117, i1 noundef zeroext false) #11, !dbg !2784
  %tobool119.not = icmp eq i32 %call118, 0, !dbg !2784
  br i1 %tobool119.not, label %if.else, label %if.then120, !dbg !2785

if.then120:                                       ; preds = %cond.end
  %42 = load i64, ptr %cas77, align 8, !dbg !2786, !tbaa !1104
  %cas121 = getelementptr inbounds i8, ptr %c, i64 416, !dbg !2788
  store i64 %42, ptr %cas121, align 8, !dbg !2789, !tbaa !1131
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1133, metadata !DIExpression()), !dbg !2790
  tail call void @llvm.dbg.value(metadata ptr %body60, metadata !1138, metadata !DIExpression()), !dbg !2790
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1139, metadata !DIExpression()), !dbg !2790
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1140, metadata !DIExpression()), !dbg !2790
  tail call void @llvm.dbg.value(metadata i32 8, metadata !1141, metadata !DIExpression()), !dbg !2790
  %noreply.i208 = getelementptr inbounds i8, ptr %c, i64 364, !dbg !2792
  %43 = load i8, ptr %noreply.i208, align 4, !dbg !2792, !tbaa !1149, !range !1123, !noundef !1124
  %tobool.i209 = trunc nuw i8 %43 to i1, !dbg !2792
  br i1 %tobool.i209, label %lor.lhs.false.i212, label %if.then.i210, !dbg !2793

lor.lhs.false.i212:                               ; preds = %if.then120
  %44 = load i16, ptr %cmd, align 8, !dbg !2794, !tbaa !1117
  switch i16 %44, label %if.end123 [
    i16 0, label %if.then.i210
    i16 12, label %if.then.i210
  ], !dbg !2795

if.then.i210:                                     ; preds = %lor.lhs.false.i212, %lor.lhs.false.i212, %if.then120
  call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 0, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 8), !dbg !2796
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1142, metadata !DIExpression()), !dbg !2797
  %45 = load ptr, ptr %resp, align 8, !dbg !2798, !tbaa !1184
  tail call void @llvm.dbg.value(metadata ptr %45, metadata !1142, metadata !DIExpression()), !dbg !2797
  call void @resp_add_iov(ptr noundef %45, ptr noundef nonnull %body60, i32 noundef 8) #11, !dbg !2799
  br label %if.end123, !dbg !2800

if.else:                                          ; preds = %cond.end
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !2801
  tail call void @llvm.dbg.value(metadata i32 5, metadata !1164, metadata !DIExpression()), !dbg !2801
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !2801
  tail call void @llvm.dbg.value(metadata ptr @.str.13, metadata !1165, metadata !DIExpression()), !dbg !2801
  %46 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2804, !tbaa !1172
  %cmp.i216 = icmp sgt i32 %46, 1, !dbg !2805
  br i1 %cmp.i216, label %if.then9.i223, label %if.end12.i217, !dbg !2806

if.then9.i223:                                    ; preds = %if.else
  %47 = load ptr, ptr @stderr, align 8, !dbg !2807, !tbaa !1091
  %48 = load i32, ptr %sfd, align 8, !dbg !2808, !tbaa !1107
  %call11.i225 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %47, ptr noundef nonnull @.str.17, i32 noundef %48, ptr noundef nonnull @.str.13) #12, !dbg !2809
  br label %if.end12.i217, !dbg !2810

if.end12.i217:                                    ; preds = %if.then9.i223, %if.else
  tail call void @llvm.dbg.value(metadata i64 11, metadata !1167, metadata !DIExpression()), !dbg !2801
  call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 5, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 11), !dbg !2811
  %49 = load ptr, ptr %resp, align 8, !dbg !2812, !tbaa !1184
  call void @resp_add_iov(ptr noundef %49, ptr noundef nonnull @.str.13, i32 noundef 11) #11, !dbg !2813
  br label %if.end123

if.end123:                                        ; preds = %if.then.i210, %lor.lhs.false.i212, %if.end12.i217
  %.sink = phi i32 [ 9, %if.end12.i217 ], [ 1, %lor.lhs.false.i212 ], [ 1, %if.then.i210 ]
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef %.sink) #11, !dbg !2814
  call void @item_remove(ptr noundef nonnull %call73) #11, !dbg !2815
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %cas77) #11, !dbg !2816
  br label %sw.epilog, !dbg !2817

if.else124:                                       ; preds = %if.then56
  call void @out_of_memory(ptr noundef nonnull %c, ptr noundef nonnull @.str.47) #11, !dbg !2818
  br label %sw.epilog

if.else126:                                       ; preds = %sw.bb51
  %50 = load ptr, ptr %thread, align 8, !dbg !2820, !tbaa !1050
  %stats = getelementptr inbounds i8, ptr %50, i64 352, !dbg !2822
  %call128 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #11, !dbg !2823
  %51 = load i16, ptr %cmd, align 8, !dbg !2824, !tbaa !1117
  %cmp131 = icmp eq i16 %51, 5, !dbg !2826
  %52 = load ptr, ptr %thread, align 8, !dbg !2827, !tbaa !1050
  %. = select i1 %cmp131, i64 448, i64 456
  %decr_misses = getelementptr inbounds i8, ptr %52, i64 %., !dbg !2827
  %53 = load i64, ptr %decr_misses, align 8, !dbg !2827, !tbaa !1104
  %inc140 = add i64 %53, 1, !dbg !2827
  store i64 %inc140, ptr %decr_misses, align 8, !dbg !2827, !tbaa !1104
  %stats143 = getelementptr inbounds i8, ptr %52, i64 352, !dbg !2828
  %call145 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats143) #11, !dbg !2829
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !2830
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1164, metadata !DIExpression()), !dbg !2830
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !2830
  tail call void @llvm.dbg.value(metadata ptr @.str.8, metadata !1165, metadata !DIExpression()), !dbg !2830
  %54 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2832, !tbaa !1172
  %cmp.i228 = icmp sgt i32 %54, 1, !dbg !2833
  br i1 %cmp.i228, label %if.then9.i235, label %if.end12.i229, !dbg !2834

if.then9.i235:                                    ; preds = %if.else126
  %55 = load ptr, ptr @stderr, align 8, !dbg !2835, !tbaa !1091
  %sfd10.i236 = getelementptr inbounds i8, ptr %c, i64 8, !dbg !2836
  %56 = load i32, ptr %sfd10.i236, align 8, !dbg !2836, !tbaa !1107
  %call11.i237 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %55, ptr noundef nonnull @.str.17, i32 noundef %56, ptr noundef nonnull @.str.8) #12, !dbg !2837
  br label %if.end12.i229, !dbg !2838

if.end12.i229:                                    ; preds = %if.then9.i235, %if.else126
  tail call void @llvm.dbg.value(metadata i64 9, metadata !1167, metadata !DIExpression()), !dbg !2830
  call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 1, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 9), !dbg !2839
  %57 = load ptr, ptr %resp, align 8, !dbg !2840, !tbaa !1184
  call void @resp_add_iov(ptr noundef %57, ptr noundef nonnull @.str.8, i32 noundef 9) #11, !dbg !2841
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 9) #11, !dbg !2842
  br label %sw.epilog

sw.bb147:                                         ; preds = %if.end33
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !2843
  tail call void @llvm.dbg.value(metadata i32 2, metadata !1164, metadata !DIExpression()), !dbg !2843
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !2843
  tail call void @llvm.dbg.value(metadata ptr @.str.10, metadata !1165, metadata !DIExpression()), !dbg !2843
  %58 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2845, !tbaa !1172
  %cmp.i240 = icmp sgt i32 %58, 1, !dbg !2846
  br i1 %cmp.i240, label %if.then9.i247, label %if.end12.i241, !dbg !2847

if.then9.i247:                                    ; preds = %sw.bb147
  %59 = load ptr, ptr @stderr, align 8, !dbg !2848, !tbaa !1091
  %sfd10.i248 = getelementptr inbounds i8, ptr %c, i64 8, !dbg !2849
  %60 = load i32, ptr %sfd10.i248, align 8, !dbg !2849, !tbaa !1107
  %call11.i249 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %59, ptr noundef nonnull @.str.17, i32 noundef %60, ptr noundef nonnull @.str.10) #12, !dbg !2850
  br label %if.end12.i241, !dbg !2851

if.end12.i241:                                    ; preds = %if.then9.i247, %sw.bb147
  tail call void @llvm.dbg.value(metadata i64 20, metadata !1167, metadata !DIExpression()), !dbg !2843
  call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 2, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 20), !dbg !2852
  %61 = load ptr, ptr %resp, align 8, !dbg !2853, !tbaa !1184
  call void @resp_add_iov(ptr noundef %61, ptr noundef nonnull @.str.10, i32 noundef 20) #11, !dbg !2854
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 9) #11, !dbg !2855
  br label %sw.epilog, !dbg !2856

sw.epilog:                                        ; preds = %if.end123, %if.else124, %if.end12.i229, %if.end33, %if.end12.i241, %sw.bb50, %if.end12.i, %write_bin_response.exit
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %cas) #11, !dbg !2857
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %tmpbuf) #11, !dbg !2857
  ret void, !dbg !2857
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_bin_append_prepend(ptr noundef %c) unnamed_addr #0 !dbg !2858 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2860, metadata !DIExpression()), !dbg !2865
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2095, metadata !DIExpression()), !dbg !2866
  %rcurr.i = getelementptr inbounds i8, ptr %c, i64 176, !dbg !2868
  %0 = load ptr, ptr %rcurr.i, align 8, !dbg !2868, !tbaa !1468
  %keylen.i = getelementptr inbounds i8, ptr %c, i64 394, !dbg !2869
  %1 = load i16, ptr %keylen.i, align 2, !dbg !2869, !tbaa !1056
  %idx.ext.i = zext i16 %1 to i64
  %idx.neg.i = sub nsw i64 0, %idx.ext.i, !dbg !2870
  %add.ptr.i = getelementptr inbounds i8, ptr %0, i64 %idx.neg.i, !dbg !2870
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !2861, metadata !DIExpression()), !dbg !2865
  tail call void @llvm.dbg.value(metadata i16 %1, metadata !2862, metadata !DIExpression()), !dbg !2865
  %bodylen = getelementptr inbounds i8, ptr %c, i64 400, !dbg !2871
  %2 = load i32, ptr %bodylen, align 8, !dbg !2871, !tbaa !1056
  %conv = zext i16 %1 to i32, !dbg !2872
  %sub = sub i32 %2, %conv, !dbg !2873
  tail call void @llvm.dbg.value(metadata i32 %sub, metadata !2863, metadata !DIExpression()), !dbg !2865
  %3 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2874, !tbaa !1172
  %cmp = icmp sgt i32 %3, 1, !dbg !2876
  br i1 %cmp, label %if.then, label %if.end, !dbg !2877

if.then:                                          ; preds = %entry
  %4 = load ptr, ptr @stderr, align 8, !dbg !2878, !tbaa !1091
  %call3 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %4, ptr noundef nonnull @.str.48, i32 noundef %sub) #12, !dbg !2880
  br label %if.end, !dbg !2881

if.end:                                           ; preds = %if.then, %entry
  %5 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 16), align 8, !dbg !2882, !tbaa !2146
  %tobool.not = icmp eq i32 %5, 0, !dbg !2884
  br i1 %tobool.not, label %if.end6, label %if.then4, !dbg !2885

if.then4:                                         ; preds = %if.end
  tail call void @stats_prefix_record_set(ptr noundef %add.ptr.i, i64 noundef %idx.ext.i) #11, !dbg !2886
  br label %if.end6, !dbg !2888

if.end6:                                          ; preds = %if.then4, %if.end
  %add = add nsw i32 %sub, 2, !dbg !2889
  %call8 = tail call ptr @item_alloc(ptr noundef %add.ptr.i, i64 noundef %idx.ext.i, i32 noundef 0, i32 noundef 0, i32 noundef %add) #11, !dbg !2890
  tail call void @llvm.dbg.value(metadata ptr %call8, metadata !2864, metadata !DIExpression()), !dbg !2865
  %cmp9 = icmp eq ptr %call8, null, !dbg !2891
  br i1 %cmp9, label %if.then11, label %if.end17, !dbg !2893

if.then11:                                        ; preds = %if.end6
  %call14 = tail call zeroext i1 @item_size_ok(i64 noundef %idx.ext.i, i32 noundef 0, i32 noundef %add) #11, !dbg !2894
  br i1 %call14, label %if.else, label %if.then15, !dbg !2897

if.then15:                                        ; preds = %if.then11
  tail call void @write_bin_error(ptr noundef nonnull %c, i32 noundef 3, ptr noundef null, i32 noundef %sub), !dbg !2898
  br label %if.end16, !dbg !2900

if.else:                                          ; preds = %if.then11
  tail call void @out_of_memory(ptr noundef nonnull %c, ptr noundef nonnull @.str.37) #11, !dbg !2901
  %sbytes = getelementptr inbounds i8, ptr %c, i64 232, !dbg !2903
  store i32 %sub, ptr %sbytes, align 8, !dbg !2904, !tbaa !1826
  br label %if.end16

if.end16:                                         ; preds = %if.else, %if.then15
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 7) #11, !dbg !2905
  br label %cleanup, !dbg !2906

if.end17:                                         ; preds = %if.end6
  %it_flags = getelementptr inbounds i8, ptr %call8, i64 38, !dbg !2907
  %6 = load i16, ptr %it_flags, align 2, !dbg !2907, !tbaa !1064
  %7 = and i16 %6, 2, !dbg !2907
  %tobool19.not = icmp eq i16 %7, 0, !dbg !2907
  br i1 %tobool19.not, label %if.end22, label %if.then20, !dbg !2910

if.then20:                                        ; preds = %if.end17
  %cas = getelementptr inbounds i8, ptr %c, i64 408, !dbg !2911
  %8 = load i64, ptr %cas, align 8, !dbg !2911, !tbaa !1056
  %data = getelementptr inbounds i8, ptr %call8, i64 48, !dbg !2911
  store i64 %8, ptr %data, align 8, !dbg !2911, !tbaa !1056
  br label %if.end22, !dbg !2911

if.end22:                                         ; preds = %if.then20, %if.end17
  %cmd = getelementptr inbounds i8, ptr %c, i64 432, !dbg !2913
  %9 = load i16, ptr %cmd, align 8, !dbg !2913, !tbaa !1117
  switch i16 %9, label %sw.epilog [
    i16 14, label %sw.epilog.sink.split
    i16 15, label %sw.bb25
  ], !dbg !2914

sw.bb25:                                          ; preds = %if.end22
  br label %sw.epilog.sink.split, !dbg !2915

sw.epilog.sink.split:                             ; preds = %if.end22, %sw.bb25
  %.sink = phi i16 [ 5, %sw.bb25 ], [ 4, %if.end22 ]
  store i16 %.sink, ptr %cmd, align 8, !dbg !2917, !tbaa !1117
  br label %sw.epilog, !dbg !2918

sw.epilog:                                        ; preds = %sw.epilog.sink.split, %if.end22
  %item = getelementptr inbounds i8, ptr %c, i64 224, !dbg !2918
  store ptr %call8, ptr %item, align 8, !dbg !2919, !tbaa !1048
  %data27 = getelementptr inbounds i8, ptr %call8, i64 48, !dbg !2920
  %nkey28 = getelementptr inbounds i8, ptr %call8, i64 41, !dbg !2920
  %10 = load i8, ptr %nkey28, align 1, !dbg !2920, !tbaa !1056
  %idx.ext = zext i8 %10 to i64
  %add.ptr = getelementptr inbounds i8, ptr %data27, i64 %idx.ext, !dbg !2920
  %add.ptr30 = getelementptr inbounds i8, ptr %add.ptr, i64 1, !dbg !2920
  %11 = load i16, ptr %it_flags, align 2, !dbg !2920, !tbaa !1064
  %conv32 = zext i16 %11 to i32, !dbg !2920
  %and33 = lshr i32 %conv32, 6, !dbg !2920
  %12 = and i32 %and33, 4, !dbg !2920
  %cond = zext nneg i32 %12 to i64, !dbg !2920
  %add.ptr35 = getelementptr inbounds i8, ptr %add.ptr30, i64 %cond, !dbg !2920
  %and38 = shl nuw nsw i32 %conv32, 2, !dbg !2920
  %13 = and i32 %and38, 8, !dbg !2920
  %cond40 = zext nneg i32 %13 to i64, !dbg !2920
  %add.ptr41 = getelementptr inbounds i8, ptr %add.ptr35, i64 %cond40, !dbg !2920
  %ritem = getelementptr inbounds i8, ptr %c, i64 208, !dbg !2921
  store ptr %add.ptr41, ptr %ritem, align 8, !dbg !2922, !tbaa !1083
  %rlbytes = getelementptr inbounds i8, ptr %c, i64 216, !dbg !2923
  store i32 %sub, ptr %rlbytes, align 8, !dbg !2924, !tbaa !2224
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 6) #11, !dbg !2925
  %substate = getelementptr inbounds i8, ptr %c, i64 24, !dbg !2926
  store i32 3, ptr %substate, align 8, !dbg !2927, !tbaa !1016
  br label %cleanup, !dbg !2928

cleanup:                                          ; preds = %sw.epilog, %if.end16
  ret void, !dbg !2928
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_bin_stat(ptr noundef %c) unnamed_addr #0 !dbg !2929 {
entry:
  %len = alloca i32, align 4, !DIAssignID !2947
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2943, metadata !DIExpression(), metadata !2947, metadata ptr %len, metadata !DIExpression()), !dbg !2948
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2931, metadata !DIExpression()), !dbg !2949
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2095, metadata !DIExpression()), !dbg !2950
  %rcurr.i = getelementptr inbounds i8, ptr %c, i64 176, !dbg !2952
  %0 = load ptr, ptr %rcurr.i, align 8, !dbg !2952, !tbaa !1468
  %keylen.i = getelementptr inbounds i8, ptr %c, i64 394, !dbg !2953
  %1 = load i16, ptr %keylen.i, align 2, !dbg !2953, !tbaa !1056
  %idx.ext.i = zext i16 %1 to i64
  %idx.neg.i = sub nsw i64 0, %idx.ext.i, !dbg !2954
  %add.ptr.i = getelementptr inbounds i8, ptr %0, i64 %idx.neg.i, !dbg !2954
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !2932, metadata !DIExpression()), !dbg !2949
  tail call void @llvm.dbg.value(metadata i16 %1, metadata !2933, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2949
  %2 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2955, !tbaa !1172
  %cmp = icmp sgt i32 %2, 1, !dbg !2956
  br i1 %cmp, label %if.then, label %if.end, !dbg !2957

if.then:                                          ; preds = %entry
  %3 = load ptr, ptr @stderr, align 8, !dbg !2958, !tbaa !1091
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !2959
  %4 = load i32, ptr %sfd, align 8, !dbg !2959, !tbaa !1107
  %call2 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %3, ptr noundef nonnull @.str.49, i32 noundef %4) #12, !dbg !2960
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2934, metadata !DIExpression()), !dbg !2961
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2934, metadata !DIExpression()), !dbg !2961
  %cmp4154.not = icmp eq i16 %1, 0, !dbg !2962
  br i1 %cmp4154.not, label %for.end, label %for.body.preheader, !dbg !2965

for.body.preheader:                               ; preds = %if.then
  %wide.trip.count = zext i16 %1 to i64, !dbg !2962
  br label %for.body, !dbg !2965

for.body:                                         ; preds = %for.body.preheader, %for.body
  %indvars.iv = phi i64 [ 0, %for.body.preheader ], [ %indvars.iv.next, %for.body ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2934, metadata !DIExpression()), !dbg !2961
  %5 = load ptr, ptr @stderr, align 8, !dbg !2966, !tbaa !1091
  %arrayidx = getelementptr inbounds i8, ptr %add.ptr.i, i64 %indvars.iv, !dbg !2968
  %6 = load i8, ptr %arrayidx, align 1, !dbg !2968, !tbaa !1056
  %conv6 = sext i8 %6 to i32, !dbg !2968
  %fputc142 = tail call i32 @fputc(i32 %conv6, ptr %5), !dbg !2969
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !2970
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !2934, metadata !DIExpression()), !dbg !2961
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count, !dbg !2962
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !2965, !llvm.loop !2971

for.end:                                          ; preds = %for.body, %if.then
  %7 = load ptr, ptr @stderr, align 8, !dbg !2973, !tbaa !1091
  %fputc = tail call i32 @fputc(i32 10, ptr %7), !dbg !2974
  br label %if.end, !dbg !2975

if.end:                                           ; preds = %for.end, %entry
  %cmp9 = icmp eq i16 %1, 0, !dbg !2976
  br i1 %cmp9, label %if.then11, label %if.else, !dbg !2977

if.then11:                                        ; preds = %if.end
  tail call void @server_stats(ptr noundef nonnull @append_stats, ptr noundef %c) #11, !dbg !2978
  %call12 = tail call zeroext i1 @get_stats(ptr noundef null, i32 noundef 0, ptr noundef nonnull @append_stats, ptr noundef %c) #11, !dbg !2980
  br label %if.end81, !dbg !2981

if.else:                                          ; preds = %if.end
  %call13 = tail call i32 @strncmp(ptr noundef nonnull dereferenceable(1) %add.ptr.i, ptr noundef nonnull dereferenceable(6) @.str.50, i64 noundef 5) #15, !dbg !2982
  %cmp14 = icmp eq i32 %call13, 0, !dbg !2983
  br i1 %cmp14, label %if.then16, label %if.else17, !dbg !2984

if.then16:                                        ; preds = %if.else
  tail call void @stats_reset() #11, !dbg !2985
  br label %if.end81, !dbg !2987

if.else17:                                        ; preds = %if.else
  %call18 = tail call i32 @strncmp(ptr noundef nonnull dereferenceable(1) %add.ptr.i, ptr noundef nonnull dereferenceable(9) @.str.51, i64 noundef 8) #15, !dbg !2988
  %cmp19 = icmp eq i32 %call18, 0, !dbg !2989
  br i1 %cmp19, label %if.then21, label %if.else22, !dbg !2990

if.then21:                                        ; preds = %if.else17
  tail call void @process_stat_settings(ptr noundef nonnull @append_stats, ptr noundef %c) #11, !dbg !2991
  br label %if.end81, !dbg !2993

if.else22:                                        ; preds = %if.else17
  %call23 = tail call i32 @strncmp(ptr noundef nonnull dereferenceable(1) %add.ptr.i, ptr noundef nonnull dereferenceable(7) @.str.52, i64 noundef 6) #15, !dbg !2994
  %cmp24 = icmp eq i32 %call23, 0, !dbg !2995
  br i1 %cmp24, label %if.then26, label %if.else61, !dbg !2996

if.then26:                                        ; preds = %if.else22
  %add.ptr = getelementptr inbounds i8, ptr %add.ptr.i, i64 6, !dbg !2997
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !2937, metadata !DIExpression()), !dbg !2998
  %call27 = tail call i32 @strncmp(ptr noundef nonnull dereferenceable(1) %add.ptr, ptr noundef nonnull dereferenceable(6) @.str.53, i64 noundef 5) #15, !dbg !2999
  %cmp28 = icmp eq i32 %call27, 0, !dbg !3000
  br i1 %cmp28, label %if.then30, label %sub_0, !dbg !3001

if.then30:                                        ; preds = %if.then26
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %len) #11, !dbg !3002
  %call31 = call ptr @stats_prefix_dump(ptr noundef nonnull %len) #11, !dbg !3003
  tail call void @llvm.dbg.value(metadata ptr %call31, metadata !2946, metadata !DIExpression()), !dbg !2948
  %cmp32 = icmp eq ptr %call31, null, !dbg !3004
  br i1 %cmp32, label %if.then36.thread, label %lor.lhs.false, !dbg !3006

if.then36.thread:                                 ; preds = %if.then30
  call void @out_of_memory(ptr noundef %c, ptr noundef nonnull @.str.54) #11, !dbg !3007
  br label %cleanup, !dbg !3009

lor.lhs.false:                                    ; preds = %if.then30
  %8 = load i32, ptr %len, align 4, !dbg !3010, !tbaa !1072
  %cmp34 = icmp slt i32 %8, 1, !dbg !3011
  br i1 %cmp34, label %if.then39, label %if.else41, !dbg !3012

if.then39:                                        ; preds = %lor.lhs.false
  call void @out_of_memory(ptr noundef %c, ptr noundef nonnull @.str.54) #11, !dbg !3007
  call void @free(ptr noundef nonnull %call31) #11, !dbg !3013
  br label %cleanup, !dbg !3013

if.else41:                                        ; preds = %lor.lhs.false
  call void @append_stats(ptr noundef nonnull @.str.55, i16 noundef zeroext 8, ptr noundef nonnull %call31, i32 noundef %8, ptr noundef %c) #11, !dbg !3015
  call void @free(ptr noundef nonnull %call31) #11, !dbg !3017
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %len) #11, !dbg !3018
  br label %if.end81

cleanup:                                          ; preds = %if.then36.thread, %if.then39
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %len) #11, !dbg !3018
  br label %cleanup96

sub_0:                                            ; preds = %if.then26
  %9 = load i8, ptr %add.ptr, align 1
  %.not = icmp eq i8 %9, 32
  br i1 %.not, label %sub_1, label %if.else49

sub_1:                                            ; preds = %sub_0
  %10 = getelementptr inbounds i8, ptr %add.ptr.i, i64 7
  %11 = load i8, ptr %10, align 1
  %.not156 = icmp eq i8 %11, 111
  br i1 %.not156, label %if.else44.tail, label %if.else49

if.else44.tail:                                   ; preds = %sub_1
  %12 = getelementptr inbounds i8, ptr %add.ptr.i, i64 8
  %13 = load i8, ptr %12, align 1
  %14 = icmp eq i8 %13, 110, !dbg !3019
  br i1 %14, label %if.then48, label %if.else49, !dbg !3021

if.then48:                                        ; preds = %if.else44.tail
  store i32 1, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 16), align 8, !dbg !3022, !tbaa !2146
  br label %if.end81, !dbg !3024

if.else49:                                        ; preds = %sub_1, %sub_0, %if.else44.tail
  %call50 = tail call i32 @strncmp(ptr noundef nonnull dereferenceable(1) %add.ptr, ptr noundef nonnull dereferenceable(5) @.str.57, i64 noundef 4) #15, !dbg !3025
  %cmp51 = icmp eq i32 %call50, 0, !dbg !3027
  br i1 %cmp51, label %if.then53, label %if.else54, !dbg !3028

if.then53:                                        ; preds = %if.else49
  store i32 0, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 16), align 8, !dbg !3029, !tbaa !2146
  br label %if.end81

if.else54:                                        ; preds = %if.else49
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !3031
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1164, metadata !DIExpression()), !dbg !3031
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !3031
  tail call void @llvm.dbg.value(metadata ptr @.str.8, metadata !1165, metadata !DIExpression()), !dbg !3031
  %15 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !3034, !tbaa !1172
  %cmp.i = icmp sgt i32 %15, 1, !dbg !3035
  br i1 %cmp.i, label %if.then9.i, label %if.end12.i, !dbg !3036

if.then9.i:                                       ; preds = %if.else54
  %16 = load ptr, ptr @stderr, align 8, !dbg !3037, !tbaa !1091
  %sfd10.i = getelementptr inbounds i8, ptr %c, i64 8, !dbg !3038
  %17 = load i32, ptr %sfd10.i, align 8, !dbg !3038, !tbaa !1107
  %call11.i = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %16, ptr noundef nonnull @.str.17, i32 noundef %17, ptr noundef nonnull @.str.8) #12, !dbg !3039
  br label %if.end12.i, !dbg !3040

if.end12.i:                                       ; preds = %if.then9.i, %if.else54
  tail call void @llvm.dbg.value(metadata i64 9, metadata !1167, metadata !DIExpression()), !dbg !3031
  tail call fastcc void @add_bin_header(ptr noundef %c, i16 noundef zeroext 1, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 9), !dbg !3041
  %resp.i = getelementptr inbounds i8, ptr %c, i64 192, !dbg !3042
  %18 = load ptr, ptr %resp.i, align 8, !dbg !3042, !tbaa !1184
  tail call void @resp_add_iov(ptr noundef %18, ptr noundef nonnull @.str.8, i32 noundef 9) #11, !dbg !3043
  tail call void @conn_set_state(ptr noundef %c, i32 noundef 9) #11, !dbg !3044
  br label %cleanup96, !dbg !3045

if.else61:                                        ; preds = %if.else22
  %conv62 = zext i16 %1 to i32, !dbg !3046
  %call63 = tail call zeroext i1 @get_stats(ptr noundef nonnull %add.ptr.i, i32 noundef %conv62, ptr noundef nonnull @append_stats, ptr noundef %c) #11, !dbg !3049
  br i1 %call63, label %if.then64, label %if.else76, !dbg !3050

if.then64:                                        ; preds = %if.else61
  %stats = getelementptr inbounds i8, ptr %c, i64 368, !dbg !3051
  %19 = load ptr, ptr %stats, align 8, !dbg !3054, !tbaa !3055
  %cmp65 = icmp eq ptr %19, null, !dbg !3056
  br i1 %cmp65, label %if.then67, label %if.else68, !dbg !3057

if.then67:                                        ; preds = %if.then64
  tail call void @out_of_memory(ptr noundef nonnull %c, ptr noundef nonnull @.str.54) #11, !dbg !3058
  br label %cleanup96, !dbg !3060

if.else68:                                        ; preds = %if.then64
  %offset = getelementptr inbounds i8, ptr %c, i64 384, !dbg !3061
  %20 = load i64, ptr %offset, align 8, !dbg !3061, !tbaa !3063
  %conv72 = trunc i64 %20 to i32, !dbg !3064
  tail call void @write_and_free(ptr noundef nonnull %c, ptr noundef nonnull %19, i32 noundef %conv72) #11, !dbg !3065
  store ptr null, ptr %stats, align 8, !dbg !3066, !tbaa !3055
  br label %cleanup96

if.else76:                                        ; preds = %if.else61
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !3067
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1164, metadata !DIExpression()), !dbg !3067
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !3067
  tail call void @llvm.dbg.value(metadata ptr @.str.8, metadata !1165, metadata !DIExpression()), !dbg !3067
  %21 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !3070, !tbaa !1172
  %cmp.i143 = icmp sgt i32 %21, 1, !dbg !3071
  br i1 %cmp.i143, label %if.then9.i150, label %if.end12.i144, !dbg !3072

if.then9.i150:                                    ; preds = %if.else76
  %22 = load ptr, ptr @stderr, align 8, !dbg !3073, !tbaa !1091
  %sfd10.i151 = getelementptr inbounds i8, ptr %c, i64 8, !dbg !3074
  %23 = load i32, ptr %sfd10.i151, align 8, !dbg !3074, !tbaa !1107
  %call11.i152 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %22, ptr noundef nonnull @.str.17, i32 noundef %23, ptr noundef nonnull @.str.8) #12, !dbg !3075
  br label %if.end12.i144, !dbg !3076

if.end12.i144:                                    ; preds = %if.then9.i150, %if.else76
  tail call void @llvm.dbg.value(metadata i64 9, metadata !1167, metadata !DIExpression()), !dbg !3067
  tail call fastcc void @add_bin_header(ptr noundef %c, i16 noundef zeroext 1, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 9), !dbg !3077
  %resp.i149 = getelementptr inbounds i8, ptr %c, i64 192, !dbg !3078
  %24 = load ptr, ptr %resp.i149, align 8, !dbg !3078, !tbaa !1184
  tail call void @resp_add_iov(ptr noundef %24, ptr noundef nonnull @.str.8, i32 noundef 9) #11, !dbg !3079
  tail call void @conn_set_state(ptr noundef %c, i32 noundef 9) #11, !dbg !3080
  br label %cleanup96

if.end81:                                         ; preds = %if.else41, %if.then48, %if.then53, %if.then16, %if.then21, %if.then11
  call void @append_stats(ptr noundef null, i16 noundef zeroext 0, ptr noundef null, i32 noundef 0, ptr noundef %c) #11, !dbg !3081
  %stats82 = getelementptr inbounds i8, ptr %c, i64 368, !dbg !3082
  %25 = load ptr, ptr %stats82, align 8, !dbg !3084, !tbaa !3055
  %cmp84 = icmp eq ptr %25, null, !dbg !3085
  br i1 %cmp84, label %if.then86, label %if.else87, !dbg !3086

if.then86:                                        ; preds = %if.end81
  call void @out_of_memory(ptr noundef nonnull %c, ptr noundef nonnull @.str.58) #11, !dbg !3087
  br label %cleanup96, !dbg !3089

if.else87:                                        ; preds = %if.end81
  %offset91 = getelementptr inbounds i8, ptr %c, i64 384, !dbg !3090
  %26 = load i64, ptr %offset91, align 8, !dbg !3090, !tbaa !3063
  %conv92 = trunc i64 %26 to i32, !dbg !3092
  call void @write_and_free(ptr noundef nonnull %c, ptr noundef nonnull %25, i32 noundef %conv92) #11, !dbg !3093
  store ptr null, ptr %stats82, align 8, !dbg !3094, !tbaa !3055
  br label %cleanup96

cleanup96:                                        ; preds = %cleanup, %if.end12.i, %if.then86, %if.else87, %if.end12.i144, %if.else68, %if.then67
  ret void, !dbg !3095
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @bin_list_sasl_mechs(ptr noundef %c) unnamed_addr #0 !dbg !3096 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !3098, metadata !DIExpression()), !dbg !3102
  %0 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 25), align 4, !dbg !3103, !tbaa !1251, !range !1123, !noundef !1124
  %tobool = trunc nuw i8 %0 to i1, !dbg !3103
  br i1 %tobool, label %if.end.i, label %if.then, !dbg !3105

if.then:                                          ; preds = %entry
  %bodylen = getelementptr inbounds i8, ptr %c, i64 400, !dbg !3106
  %1 = load i32, ptr %bodylen, align 8, !dbg !3106, !tbaa !1056
  %keylen = getelementptr inbounds i8, ptr %c, i64 394, !dbg !3108
  %2 = load i16, ptr %keylen, align 2, !dbg !3108, !tbaa !1056
  %conv = zext i16 %2 to i32, !dbg !3109
  %sub = sub i32 %1, %conv, !dbg !3110
  tail call void @write_bin_error(ptr noundef %c, i32 noundef 129, ptr noundef null, i32 noundef %sub), !dbg !3111
  br label %cleanup.cont, !dbg !3112

if.end.i:                                         ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1241, metadata !DIExpression()), !dbg !3113
  %authenticated.i = getelementptr inbounds i8, ptr %c, i64 13, !dbg !3115
  store i8 0, ptr %authenticated.i, align 1, !dbg !3116, !tbaa !1255
  %3 = load ptr, ptr %c, align 8, !dbg !3117, !tbaa !1257
  %tobool1.not.i = icmp eq ptr %3, null, !dbg !3118
  %.pre17 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !3119, !tbaa !1172
  br i1 %tobool1.not.i, label %if.then3.i, label %init_sasl_conn.exit, !dbg !3123

if.then3.i:                                       ; preds = %if.end.i
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1244, metadata !DIExpression()), !dbg !3124
  %tobool4.not.i = icmp eq i32 %.pre17, 0, !dbg !3125
  br i1 %tobool4.not.i, label %if.end6.i, label %if.then5.i, !dbg !3126

if.then5.i:                                       ; preds = %if.then3.i
  %4 = load ptr, ptr @stderr, align 8, !dbg !3127, !tbaa !1091
  %5 = tail call i64 @fwrite(ptr nonnull @.str.26, i64 32, i64 1, ptr %4) #13, !dbg !3128
  %.pre.pre = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !3119, !tbaa !1172
  br label %if.end6.i, !dbg !3129

if.end6.i:                                        ; preds = %if.then5.i, %if.then3.i
  %.pre = phi i32 [ %.pre.pre, %if.then5.i ], [ 0, %if.then3.i ], !dbg !3119
  store ptr null, ptr %c, align 8, !dbg !3130, !tbaa !1257
  br label %init_sasl_conn.exit, !dbg !3131

init_sasl_conn.exit:                              ; preds = %if.end.i, %if.end6.i
  %6 = phi i32 [ %.pre17, %if.end.i ], [ %.pre, %if.end6.i ], !dbg !3119
  tail call void @llvm.dbg.value(metadata ptr null, metadata !3099, metadata !DIExpression()), !dbg !3102
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3100, metadata !DIExpression()), !dbg !3102
  tail call void @llvm.dbg.value(metadata i32 1, metadata !3101, metadata !DIExpression()), !dbg !3102
  %tobool4.not = icmp eq i32 %6, 0, !dbg !3132
  br i1 %tobool4.not, label %if.end12.i, label %if.end6, !dbg !3133

if.end6:                                          ; preds = %init_sasl_conn.exit
  %7 = load ptr, ptr @stderr, align 8, !dbg !3134, !tbaa !1091
  %8 = tail call i64 @fwrite(ptr nonnull @.str.59, i64 32, i64 1, ptr %7) #13, !dbg !3136
  %.pr = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !3137, !tbaa !1172
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !3139
  tail call void @llvm.dbg.value(metadata i32 32, metadata !1164, metadata !DIExpression()), !dbg !3139
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !3139
  tail call void @llvm.dbg.value(metadata ptr @.str.14, metadata !1165, metadata !DIExpression()), !dbg !3139
  %cmp.i = icmp sgt i32 %.pr, 1, !dbg !3140
  br i1 %cmp.i, label %if.then9.i, label %if.end12.i, !dbg !3141

if.then9.i:                                       ; preds = %if.end6
  %9 = load ptr, ptr @stderr, align 8, !dbg !3142, !tbaa !1091
  %sfd10.i = getelementptr inbounds i8, ptr %c, i64 8, !dbg !3143
  %10 = load i32, ptr %sfd10.i, align 8, !dbg !3143, !tbaa !1107
  %call11.i = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %9, ptr noundef nonnull @.str.17, i32 noundef %10, ptr noundef nonnull @.str.14) #12, !dbg !3144
  br label %if.end12.i, !dbg !3145

if.end12.i:                                       ; preds = %init_sasl_conn.exit, %if.then9.i, %if.end6
  tail call void @llvm.dbg.value(metadata i64 13, metadata !1167, metadata !DIExpression()), !dbg !3139
  tail call fastcc void @add_bin_header(ptr noundef nonnull %c, i16 noundef zeroext 32, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 13), !dbg !3146
  %resp.i = getelementptr inbounds i8, ptr %c, i64 192, !dbg !3147
  %11 = load ptr, ptr %resp.i, align 8, !dbg !3147, !tbaa !1184
  tail call void @resp_add_iov(ptr noundef %11, ptr noundef nonnull @.str.14, i32 noundef 13) #11, !dbg !3148
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 9) #11, !dbg !3149
  br label %cleanup.cont

cleanup.cont:                                     ; preds = %if.end12.i, %if.then
  ret void, !dbg !3150
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_bin_sasl_auth(ptr noundef %c) unnamed_addr #0 !dbg !3151 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !3153, metadata !DIExpression()), !dbg !3158
  %0 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 25), align 4, !dbg !3159, !tbaa !1251, !range !1123, !noundef !1124
  %tobool = trunc nuw i8 %0 to i1, !dbg !3159
  br i1 %tobool, label %if.end, label %if.then, !dbg !3161

if.then:                                          ; preds = %entry
  %bodylen = getelementptr inbounds i8, ptr %c, i64 400, !dbg !3162
  %1 = load i32, ptr %bodylen, align 8, !dbg !3162, !tbaa !1056
  %keylen = getelementptr inbounds i8, ptr %c, i64 394, !dbg !3164
  %2 = load i16, ptr %keylen, align 2, !dbg !3164, !tbaa !1056
  %conv = zext i16 %2 to i32, !dbg !3165
  %sub = sub i32 %1, %conv, !dbg !3166
  tail call void @write_bin_error(ptr noundef %c, i32 noundef 129, ptr noundef null, i32 noundef %sub), !dbg !3167
  br label %cleanup.cont, !dbg !3168

if.end:                                           ; preds = %entry
  %keylen3 = getelementptr inbounds i8, ptr %c, i64 394, !dbg !3169
  %3 = load i16, ptr %keylen3, align 2, !dbg !3169, !tbaa !1056
  tail call void @llvm.dbg.value(metadata i16 %3, metadata !3154, metadata !DIExpression()), !dbg !3158
  %bodylen5 = getelementptr inbounds i8, ptr %c, i64 400, !dbg !3170
  %4 = load i32, ptr %bodylen5, align 8, !dbg !3170, !tbaa !1056
  %conv6 = zext i16 %3 to i32, !dbg !3171
  %sub7 = sub i32 %4, %conv6, !dbg !3172
  tail call void @llvm.dbg.value(metadata i32 %sub7, metadata !3155, metadata !DIExpression()), !dbg !3158
  %cmp = icmp ugt i16 %3, 32, !dbg !3173
  br i1 %cmp, label %if.then10, label %if.end11, !dbg !3175

if.then10:                                        ; preds = %if.end
  tail call void @write_bin_error(ptr noundef nonnull %c, i32 noundef 4, ptr noundef null, i32 noundef %sub7), !dbg !3176
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 7) #11, !dbg !3178
  br label %cleanup.cont, !dbg !3179

if.end11:                                         ; preds = %if.end
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2095, metadata !DIExpression()), !dbg !3180
  %rcurr.i = getelementptr inbounds i8, ptr %c, i64 176, !dbg !3182
  %5 = load ptr, ptr %rcurr.i, align 8, !dbg !3182, !tbaa !1468
  %idx.ext.i = zext nneg i16 %3 to i64
  %idx.neg.i = sub nsw i64 0, %idx.ext.i, !dbg !3183
  %add.ptr.i = getelementptr inbounds i8, ptr %5, i64 %idx.neg.i, !dbg !3183
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !3156, metadata !DIExpression()), !dbg !3158
  %add = add nsw i32 %sub7, 2, !dbg !3184
  %call13 = tail call ptr @item_alloc(ptr noundef %add.ptr.i, i64 noundef %idx.ext.i, i32 noundef 0, i32 noundef 0, i32 noundef %add) #11, !dbg !3185
  tail call void @llvm.dbg.value(metadata ptr %call13, metadata !3157, metadata !DIExpression()), !dbg !3158
  %cmp14 = icmp eq ptr %call13, null, !dbg !3186
  br i1 %cmp14, label %cleanup.cont.critedge, label %lor.lhs.false, !dbg !3188

lor.lhs.false:                                    ; preds = %if.end11
  %it_flags = getelementptr inbounds i8, ptr %call13, i64 38, !dbg !3189
  %6 = load i16, ptr %it_flags, align 2, !dbg !3189, !tbaa !1064
  %7 = and i16 %6, 32, !dbg !3190
  %tobool17.not = icmp eq i16 %7, 0, !dbg !3190
  br i1 %tobool17.not, label %if.end22, label %if.then18, !dbg !3191

if.then18:                                        ; preds = %lor.lhs.false
  tail call void @write_bin_error(ptr noundef nonnull %c, i32 noundef 130, ptr noundef null, i32 noundef %sub7), !dbg !3192
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 7) #11, !dbg !3194
  tail call void @do_item_remove(ptr noundef nonnull %call13) #11, !dbg !3195
  br label %cleanup.cont, !dbg !3198

if.end22:                                         ; preds = %lor.lhs.false
  %item = getelementptr inbounds i8, ptr %c, i64 224, !dbg !3199
  store ptr %call13, ptr %item, align 8, !dbg !3200, !tbaa !1048
  %data = getelementptr inbounds i8, ptr %call13, i64 48, !dbg !3201
  %nkey23 = getelementptr inbounds i8, ptr %call13, i64 41, !dbg !3201
  %8 = load i8, ptr %nkey23, align 1, !dbg !3201, !tbaa !1056
  %idx.ext = zext i8 %8 to i64
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %idx.ext, !dbg !3201
  %add.ptr25 = getelementptr inbounds i8, ptr %add.ptr, i64 1, !dbg !3201
  %conv27 = zext i16 %6 to i32, !dbg !3201
  %and28 = lshr i32 %conv27, 6, !dbg !3201
  %9 = and i32 %and28, 4, !dbg !3201
  %cond = zext nneg i32 %9 to i64, !dbg !3201
  %add.ptr30 = getelementptr inbounds i8, ptr %add.ptr25, i64 %cond, !dbg !3201
  %and33 = shl nuw nsw i32 %conv27, 2, !dbg !3201
  %10 = and i32 %and33, 8, !dbg !3201
  %cond35 = zext nneg i32 %10 to i64, !dbg !3201
  %add.ptr36 = getelementptr inbounds i8, ptr %add.ptr30, i64 %cond35, !dbg !3201
  %ritem = getelementptr inbounds i8, ptr %c, i64 208, !dbg !3202
  store ptr %add.ptr36, ptr %ritem, align 8, !dbg !3203, !tbaa !1083
  %rlbytes = getelementptr inbounds i8, ptr %c, i64 216, !dbg !3204
  store i32 %sub7, ptr %rlbytes, align 8, !dbg !3205, !tbaa !2224
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 6) #11, !dbg !3206
  %substate = getelementptr inbounds i8, ptr %c, i64 24, !dbg !3207
  store i32 10, ptr %substate, align 8, !dbg !3208, !tbaa !1016
  br label %cleanup.cont, !dbg !3209

cleanup.cont.critedge:                            ; preds = %if.end11
  tail call void @write_bin_error(ptr noundef nonnull %c, i32 noundef 130, ptr noundef null, i32 noundef %sub7), !dbg !3192
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 7) #11, !dbg !3194
  br label %cleanup.cont, !dbg !3210

cleanup.cont:                                     ; preds = %cleanup.cont.critedge, %if.then10, %if.then18, %if.end22, %if.then
  ret void, !dbg !3209
}

declare !dbg !3211 i32 @realtime(i64 noundef) local_unnamed_addr #1

declare !dbg !3215 void @item_flush_expired() local_unnamed_addr #1

declare !dbg !3218 void @stats_prefix_record_set(ptr noundef, i64 noundef) local_unnamed_addr #1

declare !dbg !3223 ptr @item_alloc(ptr noundef, i64 noundef, i32 noundef, i32 noundef, i32 noundef) local_unnamed_addr #1

declare !dbg !3226 zeroext i1 @item_size_ok(i64 noundef, i32 noundef, i32 noundef) local_unnamed_addr #1

declare !dbg !3231 void @out_of_memory(ptr noundef, ptr noundef) local_unnamed_addr #1

; Function Attrs: nounwind
declare !dbg !3232 ptr @pthread_getspecific(i32 noundef) local_unnamed_addr #6

declare !dbg !3236 i32 @logger_log(ptr noundef, i32 noundef, ptr noundef, ...) local_unnamed_addr #1

declare !dbg !3240 ptr @item_get(ptr noundef, i64 noundef, ptr noundef, i1 noundef zeroext) local_unnamed_addr #1

declare !dbg !3244 void @item_unlink(ptr noundef) local_unnamed_addr #1

declare !dbg !3245 void @storage_delete(ptr noundef, ptr noundef) local_unnamed_addr #1

; Function Attrs: nofree nounwind
declare !dbg !3249 noundef i64 @fwrite(ptr nocapture noundef, i64 noundef, i64 noundef, ptr nocapture noundef) local_unnamed_addr #2

; Function Attrs: nofree nounwind
declare !dbg !3253 noundef i32 @fputc(i32 noundef, ptr nocapture noundef) local_unnamed_addr #2

declare !dbg !3256 ptr @item_touch(ptr noundef, i64 noundef, i32 noundef, ptr noundef) local_unnamed_addr #1

declare !dbg !3259 i32 @storage_get_item(ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

declare !dbg !3262 void @resp_add_chunked_iov(ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #1

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @write_bin_miss_response(ptr noundef %c, ptr nocapture noundef readonly %key, i64 noundef %nkey) unnamed_addr #0 !dbg !2447 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2446, metadata !DIExpression()), !dbg !3263
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !2451, metadata !DIExpression()), !dbg !3263
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !2452, metadata !DIExpression()), !dbg !3263
  %tobool.not = icmp eq i64 %nkey, 0, !dbg !3264
  br i1 %tobool.not, label %if.else, label %if.then, !dbg !3265

if.then:                                          ; preds = %entry
  %conv = trunc nuw i64 %nkey to i16, !dbg !3266
  %conv1 = trunc nuw nsw i64 %nkey to i32, !dbg !3267
  tail call fastcc void @add_bin_header(ptr noundef %c, i16 noundef zeroext 1, i8 noundef zeroext 0, i16 noundef zeroext %conv, i32 noundef %conv1), !dbg !3268
  %resp = getelementptr inbounds i8, ptr %c, i64 192, !dbg !3269
  %0 = load ptr, ptr %resp, align 8, !dbg !3269, !tbaa !1184
  %add.ptr = getelementptr inbounds i8, ptr %0, i64 184, !dbg !3270
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !2453, metadata !DIExpression()), !dbg !3271
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr, ptr align 1 %key, i64 %nkey, i1 false), !dbg !3272
  %1 = load ptr, ptr %resp, align 8, !dbg !3273, !tbaa !1184
  tail call void @resp_add_iov(ptr noundef %1, ptr noundef nonnull %add.ptr, i32 noundef %conv1) #11, !dbg !3274
  br label %if.end, !dbg !3275

if.else:                                          ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1157, metadata !DIExpression()), !dbg !3276
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1164, metadata !DIExpression()), !dbg !3276
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1165, metadata !DIExpression()), !dbg !3276
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1166, metadata !DIExpression()), !dbg !3276
  tail call void @llvm.dbg.value(metadata ptr @.str.8, metadata !1165, metadata !DIExpression()), !dbg !3276
  tail call void @llvm.dbg.value(metadata ptr @.str.8, metadata !1165, metadata !DIExpression()), !dbg !3276
  %2 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !3278, !tbaa !1172
  %cmp.i = icmp sgt i32 %2, 1, !dbg !3279
  br i1 %cmp.i, label %if.then9.i, label %if.end12.i, !dbg !3280

if.then9.i:                                       ; preds = %if.else
  %3 = load ptr, ptr @stderr, align 8, !dbg !3281, !tbaa !1091
  %sfd10.i = getelementptr inbounds i8, ptr %c, i64 8, !dbg !3282
  %4 = load i32, ptr %sfd10.i, align 8, !dbg !3282, !tbaa !1107
  %call11.i = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %3, ptr noundef nonnull @.str.17, i32 noundef %4, ptr noundef nonnull @.str.8) #12, !dbg !3283
  br label %if.end12.i, !dbg !3284

if.end12.i:                                       ; preds = %if.then9.i, %if.else
  tail call void @llvm.dbg.value(metadata i64 9, metadata !1167, metadata !DIExpression()), !dbg !3276
  tail call fastcc void @add_bin_header(ptr noundef %c, i16 noundef zeroext 1, i8 noundef zeroext 0, i16 noundef zeroext 0, i32 noundef 9), !dbg !3285
  %resp.i = getelementptr inbounds i8, ptr %c, i64 192, !dbg !3286
  %5 = load ptr, ptr %resp.i, align 8, !dbg !3286, !tbaa !1184
  tail call void @resp_add_iov(ptr noundef %5, ptr noundef nonnull @.str.8, i32 noundef 9) #11, !dbg !3287
  br label %if.end

if.end:                                           ; preds = %if.end12.i, %if.then
  %.sink = phi i32 [ 9, %if.end12.i ], [ 1, %if.then ]
  tail call void @conn_set_state(ptr noundef %c, i32 noundef %.sink) #11, !dbg !3288
  ret void, !dbg !3289
}

declare !dbg !3290 void @stats_prefix_record_get(ptr noundef, i64 noundef, i1 noundef zeroext) local_unnamed_addr #1

declare !dbg !3293 void @stats_prefix_record_delete(ptr noundef, i64 noundef) local_unnamed_addr #1

declare !dbg !3294 ptr @item_get_locked(ptr noundef, i64 noundef, ptr noundef, i1 noundef zeroext, ptr noundef) local_unnamed_addr #1

declare !dbg !3298 void @do_item_unlink(ptr noundef, i32 noundef) local_unnamed_addr #1

declare !dbg !3302 void @item_unlock(i32 noundef) local_unnamed_addr #1

declare !dbg !3305 i32 @add_delta(ptr noundef, ptr noundef, i64 noundef, i1 noundef zeroext, i64 noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

; Function Attrs: nounwind
declare !dbg !3312 i64 @__isoc23_strtoull(ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #6

; Function Attrs: nofree nounwind
declare !dbg !3318 noundef i32 @snprintf(ptr noalias nocapture noundef writeonly, i64 noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #2

declare !dbg !3322 void @server_stats(ptr noundef, ptr noundef) local_unnamed_addr #1

declare !dbg !3330 void @append_stats(ptr noundef, i16 noundef zeroext, ptr noundef, i32 noundef, ptr noundef) #1

declare !dbg !3331 zeroext i1 @get_stats(ptr noundef, i32 noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare !dbg !3334 i32 @strncmp(ptr nocapture noundef, ptr nocapture noundef, i64 noundef) local_unnamed_addr #5

declare !dbg !3337 void @stats_reset() local_unnamed_addr #1

declare !dbg !3338 void @process_stat_settings(ptr noundef, ptr noundef) local_unnamed_addr #1

declare !dbg !3339 ptr @stats_prefix_dump(ptr noundef) local_unnamed_addr #1

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !3342 void @free(ptr allocptr nocapture noundef) local_unnamed_addr #8

declare !dbg !3345 void @write_and_free(ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.umin.i8(i8, i8) #9

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #10 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.declare(metadata, metadata, metadata) #9

attributes #0 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { mustprogress nofree nounwind willreturn memory(argmem: read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { mustprogress nocallback nofree nosync nounwind willreturn }
attributes #8 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { nounwind uwtable }
attributes #11 = { nounwind }
attributes #12 = { cold nounwind }
attributes #13 = { cold }
attributes #14 = { nobuiltin nounwind willreturn memory(read) }
attributes #15 = { nounwind willreturn memory(read) }

!llvm.dbg.cu = !{!202}
!llvm.module.flags = !{!597, !598, !599, !600, !601, !602, !603}
!llvm.ident = !{!604}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(scope: null, file: !2, line: 47, type: !3, isLocal: true, isDefinition: true)
!2 = !DIFile(filename: "proto_bin.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "3f11f45be64c48c0a4a947baa6941e48")
!3 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 208, elements: !5)
!4 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!5 = !{!6}
!6 = !DISubrange(count: 26)
!7 = !DIGlobalVariableExpression(var: !8, expr: !DIExpression())
!8 = distinct !DIGlobalVariable(scope: null, file: !2, line: 65, type: !9, isLocal: true, isDefinition: true)
!9 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 248, elements: !10)
!10 = !{!11}
!11 = !DISubrange(count: 31)
!12 = !DIGlobalVariableExpression(var: !13, expr: !DIExpression())
!13 = distinct !DIGlobalVariable(scope: null, file: !2, line: 68, type: !14, isLocal: true, isDefinition: true)
!14 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 64, elements: !15)
!15 = !{!16}
!16 = !DISubrange(count: 8)
!17 = !DIGlobalVariableExpression(var: !18, expr: !DIExpression())
!18 = distinct !DIGlobalVariable(scope: null, file: !2, line: 70, type: !14, isLocal: true, isDefinition: true)
!19 = !DIGlobalVariableExpression(var: !20, expr: !DIExpression())
!20 = distinct !DIGlobalVariable(scope: null, file: !2, line: 82, type: !21, isLocal: true, isDefinition: true)
!21 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 160, elements: !22)
!22 = !{!23}
!23 = !DISubrange(count: 20)
!24 = !DIGlobalVariableExpression(var: !25, expr: !DIExpression())
!25 = distinct !DIGlobalVariable(scope: null, file: !2, line: 186, type: !26, isLocal: true, isDefinition: true)
!26 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 112, elements: !27)
!27 = !{!28}
!28 = !DISubrange(count: 14)
!29 = !DIGlobalVariableExpression(var: !30, expr: !DIExpression())
!30 = distinct !DIGlobalVariable(scope: null, file: !2, line: 189, type: !31, isLocal: true, isDefinition: true)
!31 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 128, elements: !32)
!32 = !{!33}
!33 = !DISubrange(count: 16)
!34 = !DIGlobalVariableExpression(var: !35, expr: !DIExpression())
!35 = distinct !DIGlobalVariable(scope: null, file: !2, line: 192, type: !36, isLocal: true, isDefinition: true)
!36 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 80, elements: !37)
!37 = !{!38}
!38 = !DISubrange(count: 10)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(scope: null, file: !2, line: 195, type: !41, isLocal: true, isDefinition: true)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 144, elements: !42)
!42 = !{!43}
!43 = !DISubrange(count: 18)
!44 = !DIGlobalVariableExpression(var: !45, expr: !DIExpression())
!45 = distinct !DIGlobalVariable(scope: null, file: !2, line: 198, type: !46, isLocal: true, isDefinition: true)
!46 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 168, elements: !47)
!47 = !{!48}
!48 = !DISubrange(count: 21)
!49 = !DIGlobalVariableExpression(var: !50, expr: !DIExpression())
!50 = distinct !DIGlobalVariable(scope: null, file: !2, line: 201, type: !51, isLocal: true, isDefinition: true)
!51 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 88, elements: !52)
!52 = !{!53}
!53 = !DISubrange(count: 11)
!54 = !DIGlobalVariableExpression(var: !55, expr: !DIExpression())
!55 = distinct !DIGlobalVariable(scope: null, file: !2, line: 204, type: !56, isLocal: true, isDefinition: true)
!56 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 376, elements: !57)
!57 = !{!58}
!58 = !DISubrange(count: 47)
!59 = !DIGlobalVariableExpression(var: !60, expr: !DIExpression())
!60 = distinct !DIGlobalVariable(scope: null, file: !2, line: 207, type: !61, isLocal: true, isDefinition: true)
!61 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 96, elements: !62)
!62 = !{!63}
!63 = !DISubrange(count: 12)
!64 = !DIGlobalVariableExpression(var: !65, expr: !DIExpression())
!65 = distinct !DIGlobalVariable(scope: null, file: !2, line: 210, type: !26, isLocal: true, isDefinition: true)
!66 = !DIGlobalVariableExpression(var: !67, expr: !DIExpression())
!67 = distinct !DIGlobalVariable(scope: null, file: !2, line: 214, type: !31, isLocal: true, isDefinition: true)
!68 = !DIGlobalVariableExpression(var: !69, expr: !DIExpression())
!69 = distinct !DIGlobalVariable(scope: null, file: !2, line: 215, type: !70, isLocal: true, isDefinition: true)
!70 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 200, elements: !71)
!71 = !{!72}
!72 = !DISubrange(count: 25)
!73 = !DIGlobalVariableExpression(var: !74, expr: !DIExpression())
!74 = distinct !DIGlobalVariable(scope: null, file: !2, line: 220, type: !3, isLocal: true, isDefinition: true)
!75 = !DIGlobalVariableExpression(var: !76, expr: !DIExpression())
!76 = distinct !DIGlobalVariable(scope: null, file: !2, line: 159, type: !3, isLocal: true, isDefinition: true)
!77 = !DIGlobalVariableExpression(var: !78, expr: !DIExpression())
!78 = distinct !DIGlobalVariable(scope: null, file: !2, line: 162, type: !79, isLocal: true, isDefinition: true)
!79 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 56, elements: !80)
!80 = !{!81}
!81 = !DISubrange(count: 7)
!82 = !DIGlobalVariableExpression(var: !83, expr: !DIExpression())
!83 = distinct !DIGlobalVariable(scope: null, file: !2, line: 793, type: !84, isLocal: true, isDefinition: true)
!84 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 296, elements: !85)
!85 = !{!86}
!86 = !DISubrange(count: 37)
!87 = !DIGlobalVariableExpression(var: !88, expr: !DIExpression())
!88 = distinct !DIGlobalVariable(scope: null, file: !2, line: 815, type: !89, isLocal: true, isDefinition: true)
!89 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 608, elements: !90)
!90 = !{!91}
!91 = !DISubrange(count: 76)
!92 = !DIGlobalVariableExpression(var: !93, expr: !DIExpression())
!93 = distinct !DIGlobalVariable(scope: null, file: !2, line: 829, type: !94, isLocal: true, isDefinition: true)
!94 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 320, elements: !95)
!95 = !{!96}
!96 = !DISubrange(count: 40)
!97 = !DIGlobalVariableExpression(var: !98, expr: !DIExpression())
!98 = distinct !DIGlobalVariable(scope: null, file: !2, line: 836, type: !99, isLocal: true, isDefinition: true)
!99 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 184, elements: !100)
!100 = !{!101}
!101 = !DISubrange(count: 23)
!102 = !DIGlobalVariableExpression(var: !103, expr: !DIExpression())
!103 = distinct !DIGlobalVariable(scope: null, file: !2, line: 857, type: !104, isLocal: true, isDefinition: true)
!104 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 224, elements: !105)
!105 = !{!106}
!106 = !DISubrange(count: 28)
!107 = !DIGlobalVariableExpression(var: !108, expr: !DIExpression())
!108 = distinct !DIGlobalVariable(scope: null, file: !2, line: 693, type: !109, isLocal: true, isDefinition: true)
!109 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 264, elements: !110)
!110 = !{!111}
!111 = !DISubrange(count: 33)
!112 = !DIGlobalVariableExpression(var: !113, expr: !DIExpression())
!113 = distinct !DIGlobalVariable(scope: null, file: !2, line: 968, type: !79, isLocal: true, isDefinition: true)
!114 = !DIGlobalVariableExpression(var: !115, expr: !DIExpression())
!115 = distinct !DIGlobalVariable(scope: null, file: !2, line: 882, type: !84, isLocal: true, isDefinition: true)
!116 = !DIGlobalVariableExpression(var: !117, expr: !DIExpression())
!117 = distinct !DIGlobalVariable(scope: null, file: !2, line: 883, type: !118, isLocal: true, isDefinition: true)
!118 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 40, elements: !119)
!119 = !{!120}
!120 = !DISubrange(count: 5)
!121 = !DIGlobalVariableExpression(var: !122, expr: !DIExpression())
!122 = distinct !DIGlobalVariable(scope: null, file: !2, line: 883, type: !123, isLocal: true, isDefinition: true)
!123 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 48, elements: !124)
!124 = !{!125}
!125 = !DISubrange(count: 6)
!126 = !DIGlobalVariableExpression(var: !127, expr: !DIExpression())
!127 = distinct !DIGlobalVariable(scope: null, file: !2, line: 240, type: !128, isLocal: true, isDefinition: true)
!128 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 408, elements: !129)
!129 = !{!130}
!130 = !DISubrange(count: 51)
!131 = !DIGlobalVariableExpression(var: !132, expr: !DIExpression())
!132 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1104, type: !133, isLocal: true, isDefinition: true)
!133 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 72, elements: !134)
!134 = !{!135}
!135 = !DISubrange(count: 9)
!136 = !DIGlobalVariableExpression(var: !137, expr: !DIExpression())
!137 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1106, type: !133, isLocal: true, isDefinition: true)
!138 = !DIGlobalVariableExpression(var: !139, expr: !DIExpression())
!139 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1108, type: !140, isLocal: true, isDefinition: true)
!140 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 104, elements: !141)
!141 = !{!142}
!142 = !DISubrange(count: 13)
!143 = !DIGlobalVariableExpression(var: !144, expr: !DIExpression())
!144 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1114, type: !145, isLocal: true, isDefinition: true)
!145 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 136, elements: !146)
!146 = !{!147}
!147 = !DISubrange(count: 17)
!148 = !DIGlobalVariableExpression(var: !149, expr: !DIExpression())
!149 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1131, type: !150, isLocal: true, isDefinition: true)
!150 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 344, elements: !151)
!151 = !{!152}
!152 = !DISubrange(count: 43)
!153 = !DIGlobalVariableExpression(var: !154, expr: !DIExpression())
!154 = distinct !DIGlobalVariable(scope: null, file: !2, line: 474, type: !14, isLocal: true, isDefinition: true)
!155 = !DIGlobalVariableExpression(var: !156, expr: !DIExpression())
!156 = distinct !DIGlobalVariable(scope: null, file: !2, line: 474, type: !123, isLocal: true, isDefinition: true)
!157 = !DIGlobalVariableExpression(var: !158, expr: !DIExpression())
!158 = distinct !DIGlobalVariable(scope: null, file: !2, line: 474, type: !159, isLocal: true, isDefinition: true)
!159 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 32, elements: !160)
!160 = !{!161}
!161 = !DISubrange(count: 4)
!162 = !DIGlobalVariableExpression(var: !163, expr: !DIExpression())
!163 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1295, type: !36, isLocal: true, isDefinition: true)
!164 = !DIGlobalVariableExpression(var: !165, expr: !DIExpression())
!165 = distinct !DIGlobalVariable(scope: null, file: !2, line: 283, type: !123, isLocal: true, isDefinition: true)
!166 = !DIGlobalVariableExpression(var: !167, expr: !DIExpression())
!167 = distinct !DIGlobalVariable(scope: null, file: !2, line: 288, type: !145, isLocal: true, isDefinition: true)
!168 = !DIGlobalVariableExpression(var: !169, expr: !DIExpression())
!169 = distinct !DIGlobalVariable(scope: null, file: !2, line: 312, type: !170, isLocal: true, isDefinition: true)
!170 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 368, elements: !171)
!171 = !{!172}
!172 = !DISubrange(count: 46)
!173 = !DIGlobalVariableExpression(var: !174, expr: !DIExpression())
!174 = distinct !DIGlobalVariable(scope: null, file: !2, line: 319, type: !118, isLocal: true, isDefinition: true)
!175 = !DIGlobalVariableExpression(var: !176, expr: !DIExpression())
!176 = distinct !DIGlobalVariable(scope: null, file: !2, line: 341, type: !56, isLocal: true, isDefinition: true)
!177 = !DIGlobalVariableExpression(var: !178, expr: !DIExpression())
!178 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1205, type: !145, isLocal: true, isDefinition: true)
!179 = !DIGlobalVariableExpression(var: !180, expr: !DIExpression())
!180 = distinct !DIGlobalVariable(scope: null, file: !2, line: 615, type: !51, isLocal: true, isDefinition: true)
!181 = !DIGlobalVariableExpression(var: !182, expr: !DIExpression())
!182 = distinct !DIGlobalVariable(scope: null, file: !2, line: 626, type: !123, isLocal: true, isDefinition: true)
!183 = !DIGlobalVariableExpression(var: !184, expr: !DIExpression())
!184 = distinct !DIGlobalVariable(scope: null, file: !2, line: 628, type: !133, isLocal: true, isDefinition: true)
!185 = !DIGlobalVariableExpression(var: !186, expr: !DIExpression())
!186 = distinct !DIGlobalVariable(scope: null, file: !2, line: 630, type: !79, isLocal: true, isDefinition: true)
!187 = !DIGlobalVariableExpression(var: !188, expr: !DIExpression())
!188 = distinct !DIGlobalVariable(scope: null, file: !2, line: 632, type: !123, isLocal: true, isDefinition: true)
!189 = !DIGlobalVariableExpression(var: !190, expr: !DIExpression())
!190 = distinct !DIGlobalVariable(scope: null, file: !2, line: 636, type: !191, isLocal: true, isDefinition: true)
!191 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 352, elements: !192)
!192 = !{!193}
!193 = !DISubrange(count: 44)
!194 = !DIGlobalVariableExpression(var: !195, expr: !DIExpression())
!195 = distinct !DIGlobalVariable(scope: null, file: !2, line: 641, type: !133, isLocal: true, isDefinition: true)
!196 = !DIGlobalVariableExpression(var: !197, expr: !DIExpression())
!197 = distinct !DIGlobalVariable(scope: null, file: !2, line: 646, type: !118, isLocal: true, isDefinition: true)
!198 = !DIGlobalVariableExpression(var: !199, expr: !DIExpression())
!199 = distinct !DIGlobalVariable(scope: null, file: !2, line: 670, type: !128, isLocal: true, isDefinition: true)
!200 = !DIGlobalVariableExpression(var: !201, expr: !DIExpression())
!201 = distinct !DIGlobalVariable(scope: null, file: !2, line: 721, type: !109, isLocal: true, isDefinition: true)
!202 = distinct !DICompileUnit(language: DW_LANG_C11, file: !2, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !203, retainedTypes: !364, globals: !580, splitDebugInlining: false, nameTableKind: None)
!203 = !{!204, !224, !238, !257, !262, !267, !273, !278, !291, !294, !302, !352, !357}
!204 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "conn_states", file: !205, line: 204, baseType: !206, size: 32, elements: !207)
!205 = !DIFile(filename: "./memcached.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "a52021954a5d6b153b5bc084e2fbff2b")
!206 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!207 = !{!208, !209, !210, !211, !212, !213, !214, !215, !216, !217, !218, !219, !220, !221, !222, !223}
!208 = !DIEnumerator(name: "conn_listening", value: 0)
!209 = !DIEnumerator(name: "conn_new_cmd", value: 1)
!210 = !DIEnumerator(name: "conn_waiting", value: 2)
!211 = !DIEnumerator(name: "conn_read", value: 3)
!212 = !DIEnumerator(name: "conn_parse_cmd", value: 4)
!213 = !DIEnumerator(name: "conn_write", value: 5)
!214 = !DIEnumerator(name: "conn_nread", value: 6)
!215 = !DIEnumerator(name: "conn_swallow", value: 7)
!216 = !DIEnumerator(name: "conn_closing", value: 8)
!217 = !DIEnumerator(name: "conn_mwrite", value: 9)
!218 = !DIEnumerator(name: "conn_closed", value: 10)
!219 = !DIEnumerator(name: "conn_watch", value: 11)
!220 = !DIEnumerator(name: "conn_io_queue", value: 12)
!221 = !DIEnumerator(name: "conn_io_resume", value: 13)
!222 = !DIEnumerator(name: "conn_io_pending", value: 14)
!223 = !DIEnumerator(name: "conn_max_state", value: 15)
!224 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "bin_substates", file: !205, line: 223, baseType: !206, size: 32, elements: !225)
!225 = !{!226, !227, !228, !229, !230, !231, !232, !233, !234, !235, !236, !237}
!226 = !DIEnumerator(name: "bin_no_state", value: 0)
!227 = !DIEnumerator(name: "bin_reading_set_header", value: 1)
!228 = !DIEnumerator(name: "bin_reading_cas_header", value: 2)
!229 = !DIEnumerator(name: "bin_read_set_value", value: 3)
!230 = !DIEnumerator(name: "bin_reading_get_key", value: 4)
!231 = !DIEnumerator(name: "bin_reading_stat", value: 5)
!232 = !DIEnumerator(name: "bin_reading_del_header", value: 6)
!233 = !DIEnumerator(name: "bin_reading_incr_header", value: 7)
!234 = !DIEnumerator(name: "bin_read_flush_exptime", value: 8)
!235 = !DIEnumerator(name: "bin_reading_sasl_auth", value: 9)
!236 = !DIEnumerator(name: "bin_reading_sasl_auth_data", value: 10)
!237 = !DIEnumerator(name: "bin_reading_touch_key", value: 11)
!238 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "log_entry_type", file: !239, line: 16, baseType: !206, size: 32, elements: !240)
!239 = !DIFile(filename: "./logger.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "e743c4228b1e0bc1c91bec9cfd28d5ab")
!240 = !{!241, !242, !243, !244, !245, !246, !247, !248, !249, !250, !251, !252, !253, !254, !255, !256}
!241 = !DIEnumerator(name: "LOGGER_ASCII_CMD", value: 0)
!242 = !DIEnumerator(name: "LOGGER_EVICTION", value: 1)
!243 = !DIEnumerator(name: "LOGGER_ITEM_GET", value: 2)
!244 = !DIEnumerator(name: "LOGGER_ITEM_STORE", value: 3)
!245 = !DIEnumerator(name: "LOGGER_CRAWLER_STATUS", value: 4)
!246 = !DIEnumerator(name: "LOGGER_SLAB_MOVE", value: 5)
!247 = !DIEnumerator(name: "LOGGER_CONNECTION_NEW", value: 6)
!248 = !DIEnumerator(name: "LOGGER_CONNECTION_CLOSE", value: 7)
!249 = !DIEnumerator(name: "LOGGER_DELETIONS", value: 8)
!250 = !DIEnumerator(name: "LOGGER_EXTSTORE_WRITE", value: 9)
!251 = !DIEnumerator(name: "LOGGER_COMPACT_START", value: 10)
!252 = !DIEnumerator(name: "LOGGER_COMPACT_ABORT", value: 11)
!253 = !DIEnumerator(name: "LOGGER_COMPACT_READ_START", value: 12)
!254 = !DIEnumerator(name: "LOGGER_COMPACT_READ_END", value: 13)
!255 = !DIEnumerator(name: "LOGGER_COMPACT_END", value: 14)
!256 = !DIEnumerator(name: "LOGGER_COMPACT_FRAGINFO", value: 15)
!257 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "protocol", file: !205, line: 238, baseType: !206, size: 32, elements: !258)
!258 = !{!259, !260, !261}
!259 = !DIEnumerator(name: "ascii_prot", value: 3)
!260 = !DIEnumerator(name: "binary_prot", value: 4)
!261 = !DIEnumerator(name: "negotiating_prot", value: 5)
!262 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "network_transport", file: !205, line: 247, baseType: !206, size: 32, elements: !263)
!263 = !{!264, !265, !266}
!264 = !DIEnumerator(name: "local_transport", value: 0)
!265 = !DIEnumerator(name: "tcp_transport", value: 1)
!266 = !DIEnumerator(name: "udp_transport", value: 2)
!267 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "close_reasons", file: !205, line: 266, baseType: !206, size: 32, elements: !268)
!268 = !{!269, !270, !271, !272}
!269 = !DIEnumerator(name: "ERROR_CLOSE", value: 0)
!270 = !DIEnumerator(name: "NORMAL_CLOSE", value: 1)
!271 = !DIEnumerator(name: "IDLE_TIMEOUT_CLOSE", value: 2)
!272 = !DIEnumerator(name: "SHUTDOWN_CLOSE", value: 3)
!273 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !274, line: 53, baseType: !206, size: 32, elements: !275)
!274 = !DIFile(filename: "./protocol_binary.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "7a322a65fa8661e9a597acbeeeb23107")
!275 = !{!276, !277}
!276 = !DIEnumerator(name: "PROTOCOL_BINARY_REQ", value: 128)
!277 = !DIEnumerator(name: "PROTOCOL_BINARY_RES", value: 129)
!278 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !274, line: 62, baseType: !206, size: 32, elements: !279)
!279 = !{!280, !281, !282, !283, !284, !285, !286, !287, !288, !289, !290}
!280 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_SUCCESS", value: 0)
!281 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_KEY_ENOENT", value: 1)
!282 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_KEY_EEXISTS", value: 2)
!283 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_E2BIG", value: 3)
!284 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_EINVAL", value: 4)
!285 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_NOT_STORED", value: 5)
!286 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_DELTA_BADVAL", value: 6)
!287 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_AUTH_ERROR", value: 32)
!288 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_AUTH_CONTINUE", value: 33)
!289 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_UNKNOWN_COMMAND", value: 129)
!290 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_ENOMEM", value: 130)
!291 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !274, line: 143, baseType: !206, size: 32, elements: !292)
!292 = !{!293}
!293 = !DIEnumerator(name: "PROTOCOL_BINARY_RAW_BYTES", value: 0)
!294 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "store_item_type", file: !205, line: 291, baseType: !206, size: 32, elements: !295)
!295 = !{!296, !297, !298, !299, !300, !301}
!296 = !DIEnumerator(name: "NOT_STORED", value: 0)
!297 = !DIEnumerator(name: "STORED", value: 1)
!298 = !DIEnumerator(name: "EXISTS", value: 2)
!299 = !DIEnumerator(name: "NOT_FOUND", value: 3)
!300 = !DIEnumerator(name: "TOO_LARGE", value: 4)
!301 = !DIEnumerator(name: "NO_MEMORY", value: 5)
!302 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !274, line: 80, baseType: !206, size: 32, elements: !303)
!303 = !{!304, !305, !306, !307, !308, !309, !310, !311, !312, !313, !314, !315, !316, !317, !318, !319, !320, !321, !322, !323, !324, !325, !326, !327, !328, !329, !330, !331, !332, !333, !334, !335, !336, !337, !338, !339, !340, !341, !342, !343, !344, !345, !346, !347, !348, !349, !350, !351}
!304 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_GET", value: 0)
!305 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_SET", value: 1)
!306 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_ADD", value: 2)
!307 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_REPLACE", value: 3)
!308 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_DELETE", value: 4)
!309 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_INCREMENT", value: 5)
!310 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_DECREMENT", value: 6)
!311 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_QUIT", value: 7)
!312 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_FLUSH", value: 8)
!313 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_GETQ", value: 9)
!314 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_NOOP", value: 10)
!315 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_VERSION", value: 11)
!316 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_GETK", value: 12)
!317 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_GETKQ", value: 13)
!318 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_APPEND", value: 14)
!319 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_PREPEND", value: 15)
!320 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_STAT", value: 16)
!321 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_SETQ", value: 17)
!322 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_ADDQ", value: 18)
!323 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_REPLACEQ", value: 19)
!324 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_DELETEQ", value: 20)
!325 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_INCREMENTQ", value: 21)
!326 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_DECREMENTQ", value: 22)
!327 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_QUITQ", value: 23)
!328 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_FLUSHQ", value: 24)
!329 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_APPENDQ", value: 25)
!330 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_PREPENDQ", value: 26)
!331 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_TOUCH", value: 28)
!332 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_GAT", value: 29)
!333 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_GATQ", value: 30)
!334 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_GATK", value: 35)
!335 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_GATKQ", value: 36)
!336 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_SASL_LIST_MECHS", value: 32)
!337 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_SASL_AUTH", value: 33)
!338 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_SASL_STEP", value: 34)
!339 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_RGET", value: 48)
!340 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_RSET", value: 49)
!341 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_RSETQ", value: 50)
!342 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_RAPPEND", value: 51)
!343 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_RAPPENDQ", value: 52)
!344 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_RPREPEND", value: 53)
!345 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_RPREPENDQ", value: 54)
!346 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_RDELETE", value: 55)
!347 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_RDELETEQ", value: 56)
!348 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_RINCR", value: 57)
!349 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_RINCRQ", value: 58)
!350 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_RDECR", value: 59)
!351 = !DIEnumerator(name: "PROTOCOL_BINARY_CMD_RDECRQ", value: 60)
!352 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "logger_ret_type", file: !239, line: 45, baseType: !206, size: 32, elements: !353)
!353 = !{!354, !355, !356}
!354 = !DIEnumerator(name: "LOGGER_RET_OK", value: 0)
!355 = !DIEnumerator(name: "LOGGER_RET_NOSPACE", value: 1)
!356 = !DIEnumerator(name: "LOGGER_RET_ERR", value: 2)
!357 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "delta_result_type", file: !205, line: 295, baseType: !206, size: 32, elements: !358)
!358 = !{!359, !360, !361, !362, !363}
!359 = !DIEnumerator(name: "OK", value: 0)
!360 = !DIEnumerator(name: "NON_NUMERIC", value: 1)
!361 = !DIEnumerator(name: "EOM", value: 2)
!362 = !DIEnumerator(name: "DELTA_ITEM_NOT_FOUND", value: 3)
!363 = !DIEnumerator(name: "DELTA_ITEM_CAS_MISMATCH", value: 4)
!364 = !{!365, !366, !369, !377, !383, !399, !400, !440, !442, !392, !546, !560, !562, !578, !579}
!365 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!366 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint16_t", file: !367, line: 40, baseType: !368)
!367 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!368 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!369 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !370, size: 64)
!370 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_response_header", file: !274, line: 183, baseType: !371)
!371 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !274, line: 170, size: 192, elements: !372)
!372 = !{!373, !395}
!373 = !DIDerivedType(tag: DW_TAG_member, name: "response", scope: !371, file: !274, line: 181, baseType: !374, size: 192)
!374 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !371, file: !274, line: 171, size: 192, elements: !375)
!375 = !{!376, !381, !382, !384, !385, !386, !387, !390, !391}
!376 = !DIDerivedType(tag: DW_TAG_member, name: "magic", scope: !374, file: !274, line: 172, baseType: !377, size: 8)
!377 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !378, line: 24, baseType: !379)
!378 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!379 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !367, line: 38, baseType: !380)
!380 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!381 = !DIDerivedType(tag: DW_TAG_member, name: "opcode", scope: !374, file: !274, line: 173, baseType: !377, size: 8, offset: 8)
!382 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !374, file: !274, line: 174, baseType: !383, size: 16, offset: 16)
!383 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint16_t", file: !378, line: 25, baseType: !366)
!384 = !DIDerivedType(tag: DW_TAG_member, name: "extlen", scope: !374, file: !274, line: 175, baseType: !377, size: 8, offset: 32)
!385 = !DIDerivedType(tag: DW_TAG_member, name: "datatype", scope: !374, file: !274, line: 176, baseType: !377, size: 8, offset: 40)
!386 = !DIDerivedType(tag: DW_TAG_member, name: "status", scope: !374, file: !274, line: 177, baseType: !383, size: 16, offset: 48)
!387 = !DIDerivedType(tag: DW_TAG_member, name: "bodylen", scope: !374, file: !274, line: 178, baseType: !388, size: 32, offset: 64)
!388 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !378, line: 26, baseType: !389)
!389 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !367, line: 42, baseType: !206)
!390 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !374, file: !274, line: 179, baseType: !388, size: 32, offset: 96)
!391 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !374, file: !274, line: 180, baseType: !392, size: 64, offset: 128)
!392 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !378, line: 27, baseType: !393)
!393 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !367, line: 45, baseType: !394)
!394 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!395 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !371, file: !274, line: 182, baseType: !396, size: 192)
!396 = !DICompositeType(tag: DW_TAG_array_type, baseType: !377, size: 192, elements: !397)
!397 = !{!398}
!398 = !DISubrange(count: 24)
!399 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !4, size: 64)
!400 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !401, size: 64)
!401 = !DIDerivedType(tag: DW_TAG_typedef, name: "item_chunk", file: !205, line: 653, baseType: !402)
!402 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_strchunk", file: !205, line: 641, size: 384, elements: !403)
!403 = !{!404, !406, !407, !431, !432, !433, !434, !435, !436, !437, !438}
!404 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !402, file: !205, line: 642, baseType: !405, size: 64)
!405 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !402, size: 64)
!406 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !402, file: !205, line: 643, baseType: !405, size: 64, offset: 64)
!407 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !402, file: !205, line: 644, baseType: !408, size: 64, offset: 128)
!408 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !409, size: 64)
!409 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_stritem", file: !205, line: 593, size: 384, elements: !410)
!410 = !{!411, !412, !413, !414, !416, !417, !419, !420, !421, !422, !423}
!411 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !409, file: !205, line: 595, baseType: !408, size: 64)
!412 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !409, file: !205, line: 596, baseType: !408, size: 64, offset: 64)
!413 = !DIDerivedType(tag: DW_TAG_member, name: "h_next", scope: !409, file: !205, line: 598, baseType: !408, size: 64, offset: 128)
!414 = !DIDerivedType(tag: DW_TAG_member, name: "time", scope: !409, file: !205, line: 599, baseType: !415, size: 32, offset: 192)
!415 = !DIDerivedType(tag: DW_TAG_typedef, name: "rel_time_t", file: !239, line: 14, baseType: !206)
!416 = !DIDerivedType(tag: DW_TAG_member, name: "exptime", scope: !409, file: !205, line: 600, baseType: !415, size: 32, offset: 224)
!417 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !409, file: !205, line: 601, baseType: !418, size: 32, offset: 256)
!418 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!419 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !409, file: !205, line: 602, baseType: !368, size: 16, offset: 288)
!420 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !409, file: !205, line: 603, baseType: !383, size: 16, offset: 304)
!421 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !409, file: !205, line: 604, baseType: !377, size: 8, offset: 320)
!422 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !409, file: !205, line: 605, baseType: !377, size: 8, offset: 328)
!423 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !409, file: !205, line: 611, baseType: !424, offset: 384)
!424 = !DICompositeType(tag: DW_TAG_array_type, baseType: !425, elements: !429)
!425 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !409, file: !205, line: 608, size: 64, elements: !426)
!426 = !{!427, !428}
!427 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !425, file: !205, line: 609, baseType: !392, size: 64)
!428 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !425, file: !205, line: 610, baseType: !4, size: 8)
!429 = !{!430}
!430 = !DISubrange(count: -1)
!431 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !402, file: !205, line: 645, baseType: !418, size: 32, offset: 192)
!432 = !DIDerivedType(tag: DW_TAG_member, name: "used", scope: !402, file: !205, line: 646, baseType: !418, size: 32, offset: 224)
!433 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !402, file: !205, line: 647, baseType: !418, size: 32, offset: 256)
!434 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !402, file: !205, line: 648, baseType: !368, size: 16, offset: 288)
!435 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !402, file: !205, line: 649, baseType: !383, size: 16, offset: 304)
!436 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !402, file: !205, line: 650, baseType: !377, size: 8, offset: 320)
!437 = !DIDerivedType(tag: DW_TAG_member, name: "orig_clsid", scope: !402, file: !205, line: 651, baseType: !377, size: 8, offset: 328)
!438 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !402, file: !205, line: 652, baseType: !439, offset: 336)
!439 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, elements: !429)
!440 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !441, size: 64)
!441 = !DIDerivedType(tag: DW_TAG_typedef, name: "item", file: !205, line: 616, baseType: !409)
!442 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !443, size: 64)
!443 = !DIDerivedType(tag: DW_TAG_typedef, name: "logger", file: !239, line: 193, baseType: !444)
!444 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logger", file: !239, line: 181, size: 832, elements: !445)
!445 = !{!446, !448, !449, !477, !478, !479, !480, !481, !482, !483, !496}
!446 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !444, file: !239, line: 182, baseType: !447, size: 64)
!447 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !444, size: 64)
!448 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !444, file: !239, line: 183, baseType: !447, size: 64, offset: 64)
!449 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !444, file: !239, line: 184, baseType: !450, size: 320, offset: 128)
!450 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutex_t", file: !451, line: 72, baseType: !452)
!451 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h", directory: "", checksumkind: CSK_MD5, checksum: "8a5acdbeec491eca11cf81cb1ef77ea7")
!452 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !451, line: 67, size: 320, elements: !453)
!453 = !{!454, !474, !475}
!454 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !452, file: !451, line: 69, baseType: !455, size: 320)
!455 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_mutex_s", file: !456, line: 22, size: 320, elements: !457)
!456 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h", directory: "", checksumkind: CSK_MD5, checksum: "6b075eca9ab0e2d761b2afc4ecfab776")
!457 = !{!458, !459, !460, !461, !462, !463, !465, !466}
!458 = !DIDerivedType(tag: DW_TAG_member, name: "__lock", scope: !455, file: !456, line: 24, baseType: !418, size: 32)
!459 = !DIDerivedType(tag: DW_TAG_member, name: "__count", scope: !455, file: !456, line: 25, baseType: !206, size: 32, offset: 32)
!460 = !DIDerivedType(tag: DW_TAG_member, name: "__owner", scope: !455, file: !456, line: 26, baseType: !418, size: 32, offset: 64)
!461 = !DIDerivedType(tag: DW_TAG_member, name: "__nusers", scope: !455, file: !456, line: 28, baseType: !206, size: 32, offset: 96)
!462 = !DIDerivedType(tag: DW_TAG_member, name: "__kind", scope: !455, file: !456, line: 32, baseType: !418, size: 32, offset: 128)
!463 = !DIDerivedType(tag: DW_TAG_member, name: "__spins", scope: !455, file: !456, line: 34, baseType: !464, size: 16, offset: 160)
!464 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!465 = !DIDerivedType(tag: DW_TAG_member, name: "__elision", scope: !455, file: !456, line: 35, baseType: !464, size: 16, offset: 176)
!466 = !DIDerivedType(tag: DW_TAG_member, name: "__list", scope: !455, file: !456, line: 36, baseType: !467, size: 128, offset: 192)
!467 = !DIDerivedType(tag: DW_TAG_typedef, name: "__pthread_list_t", file: !468, line: 55, baseType: !469)
!468 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h", directory: "", checksumkind: CSK_MD5, checksum: "b9a7199822bce372686baacd32a9f4f3")
!469 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_internal_list", file: !468, line: 51, size: 128, elements: !470)
!470 = !{!471, !473}
!471 = !DIDerivedType(tag: DW_TAG_member, name: "__prev", scope: !469, file: !468, line: 53, baseType: !472, size: 64)
!472 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !469, size: 64)
!473 = !DIDerivedType(tag: DW_TAG_member, name: "__next", scope: !469, file: !468, line: 54, baseType: !472, size: 64, offset: 64)
!474 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !452, file: !451, line: 70, baseType: !94, size: 320)
!475 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !452, file: !451, line: 71, baseType: !476, size: 64)
!476 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!477 = !DIDerivedType(tag: DW_TAG_member, name: "written", scope: !444, file: !239, line: 185, baseType: !392, size: 64, offset: 448)
!478 = !DIDerivedType(tag: DW_TAG_member, name: "dropped", scope: !444, file: !239, line: 186, baseType: !392, size: 64, offset: 512)
!479 = !DIDerivedType(tag: DW_TAG_member, name: "blocked", scope: !444, file: !239, line: 187, baseType: !392, size: 64, offset: 576)
!480 = !DIDerivedType(tag: DW_TAG_member, name: "fetcher_ratio", scope: !444, file: !239, line: 188, baseType: !383, size: 16, offset: 640)
!481 = !DIDerivedType(tag: DW_TAG_member, name: "mutation_ratio", scope: !444, file: !239, line: 189, baseType: !383, size: 16, offset: 656)
!482 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !444, file: !239, line: 190, baseType: !383, size: 16, offset: 672)
!483 = !DIDerivedType(tag: DW_TAG_member, name: "buf", scope: !444, file: !239, line: 191, baseType: !484, size: 64, offset: 704)
!484 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !485, size: 64)
!485 = !DIDerivedType(tag: DW_TAG_typedef, name: "bipbuf_t", file: !486, line: 18, baseType: !487)
!486 = !DIFile(filename: "./bipbuffer.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "99606bcb8393045e6bc9eef40115066f")
!487 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !486, line: 4, size: 192, elements: !488)
!488 = !{!489, !490, !491, !492, !493, !494}
!489 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !487, file: !486, line: 6, baseType: !394, size: 64)
!490 = !DIDerivedType(tag: DW_TAG_member, name: "a_start", scope: !487, file: !486, line: 9, baseType: !206, size: 32, offset: 64)
!491 = !DIDerivedType(tag: DW_TAG_member, name: "a_end", scope: !487, file: !486, line: 9, baseType: !206, size: 32, offset: 96)
!492 = !DIDerivedType(tag: DW_TAG_member, name: "b_end", scope: !487, file: !486, line: 12, baseType: !206, size: 32, offset: 128)
!493 = !DIDerivedType(tag: DW_TAG_member, name: "b_inuse", scope: !487, file: !486, line: 15, baseType: !418, size: 32, offset: 160)
!494 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !487, file: !486, line: 17, baseType: !495, offset: 192)
!495 = !DICompositeType(tag: DW_TAG_array_type, baseType: !380, elements: !429)
!496 = !DIDerivedType(tag: DW_TAG_member, name: "entry_map", scope: !444, file: !239, line: 192, baseType: !497, size: 64, offset: 768)
!497 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !498, size: 64)
!498 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !499)
!499 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_details", file: !239, line: 58, baseType: !500)
!500 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_entry_details", file: !239, line: 63, size: 256, elements: !501)
!501 = !{!502, !503, !504, !540, !545}
!502 = !DIDerivedType(tag: DW_TAG_member, name: "reqlen", scope: !500, file: !239, line: 64, baseType: !418, size: 32)
!503 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !500, file: !239, line: 65, baseType: !383, size: 16, offset: 32)
!504 = !DIDerivedType(tag: DW_TAG_member, name: "log_cb", scope: !500, file: !239, line: 66, baseType: !505, size: 64, offset: 64)
!505 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_log_cb", file: !239, line: 60, baseType: !506)
!506 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !507, size: 64)
!507 = !DISubroutineType(types: !508)
!508 = !{null, !509, !497, !531, !533}
!509 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !510, size: 64)
!510 = !DIDerivedType(tag: DW_TAG_typedef, name: "logentry", file: !239, line: 57, baseType: !511)
!511 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logentry", file: !239, line: 156, size: 320, elements: !512)
!512 = !{!513, !514, !515, !516, !517, !525, !526}
!513 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !511, file: !239, line: 157, baseType: !238, size: 32)
!514 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !511, file: !239, line: 158, baseType: !377, size: 8, offset: 32)
!515 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !511, file: !239, line: 159, baseType: !383, size: 16, offset: 48)
!516 = !DIDerivedType(tag: DW_TAG_member, name: "gid", scope: !511, file: !239, line: 160, baseType: !392, size: 64, offset: 64)
!517 = !DIDerivedType(tag: DW_TAG_member, name: "tv", scope: !511, file: !239, line: 161, baseType: !518, size: 128, offset: 128)
!518 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "timeval", file: !519, line: 8, size: 128, elements: !520)
!519 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h", directory: "", checksumkind: CSK_MD5, checksum: "9b45d950050c215f216850b27bd1e8f3")
!520 = !{!521, !523}
!521 = !DIDerivedType(tag: DW_TAG_member, name: "tv_sec", scope: !518, file: !519, line: 14, baseType: !522, size: 64)
!522 = !DIDerivedType(tag: DW_TAG_typedef, name: "__time_t", file: !367, line: 160, baseType: !476)
!523 = !DIDerivedType(tag: DW_TAG_member, name: "tv_usec", scope: !518, file: !519, line: 15, baseType: !524, size: 64, offset: 64)
!524 = !DIDerivedType(tag: DW_TAG_typedef, name: "__suseconds_t", file: !367, line: 162, baseType: !476)
!525 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !511, file: !239, line: 162, baseType: !418, size: 32, offset: 256)
!526 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !511, file: !239, line: 165, baseType: !527, offset: 288)
!527 = !DICompositeType(tag: DW_TAG_array_type, baseType: !528, elements: !429)
!528 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !511, file: !239, line: 163, size: 8, elements: !529)
!529 = !{!530}
!530 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !528, file: !239, line: 164, baseType: !4, size: 8)
!531 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !532, size: 64)
!532 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!533 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !534, size: 64)
!534 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !535)
!535 = !{!536, !537, !538, !539}
!536 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !534, file: !2, baseType: !206, size: 32)
!537 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !534, file: !2, baseType: !206, size: 32, offset: 32)
!538 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !534, file: !2, baseType: !365, size: 64, offset: 64)
!539 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !534, file: !2, baseType: !365, size: 64, offset: 128)
!540 = !DIDerivedType(tag: DW_TAG_member, name: "parse_cb", scope: !500, file: !239, line: 67, baseType: !541, size: 64, offset: 128)
!541 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_parse_cb", file: !239, line: 61, baseType: !542)
!542 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !543, size: 64)
!543 = !DISubroutineType(types: !544)
!544 = !{!418, !509, !399}
!545 = !DIDerivedType(tag: DW_TAG_member, name: "format", scope: !500, file: !239, line: 68, baseType: !399, size: 64, offset: 192)
!546 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !547, size: 64)
!547 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_response_get", file: !274, line: 227, baseType: !548)
!548 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !274, line: 219, size: 256, elements: !549)
!549 = !{!550, !558}
!550 = !DIDerivedType(tag: DW_TAG_member, name: "message", scope: !548, file: !274, line: 225, baseType: !551, size: 256)
!551 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !548, file: !274, line: 220, size: 256, elements: !552)
!552 = !{!553, !554}
!553 = !DIDerivedType(tag: DW_TAG_member, name: "header", scope: !551, file: !274, line: 221, baseType: !370, size: 192)
!554 = !DIDerivedType(tag: DW_TAG_member, name: "body", scope: !551, file: !274, line: 224, baseType: !555, size: 32, offset: 192)
!555 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !551, file: !274, line: 222, size: 32, elements: !556)
!556 = !{!557}
!557 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !555, file: !274, line: 223, baseType: !388, size: 32)
!558 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !548, file: !274, line: 226, baseType: !559, size: 224)
!559 = !DICompositeType(tag: DW_TAG_array_type, baseType: !377, size: 224, elements: !105)
!560 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !561, size: 64)
!561 = !DIDerivedType(tag: DW_TAG_typedef, name: "client_flags_t", file: !205, line: 99, baseType: !388)
!562 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !563, size: 64)
!563 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_response_incr", file: !274, line: 335, baseType: !564)
!564 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !274, line: 327, size: 256, elements: !565)
!565 = !{!566, !574}
!566 = !DIDerivedType(tag: DW_TAG_member, name: "message", scope: !564, file: !274, line: 333, baseType: !567, size: 256)
!567 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !564, file: !274, line: 328, size: 256, elements: !568)
!568 = !{!569, !570}
!569 = !DIDerivedType(tag: DW_TAG_member, name: "header", scope: !567, file: !274, line: 329, baseType: !370, size: 192)
!570 = !DIDerivedType(tag: DW_TAG_member, name: "body", scope: !567, file: !274, line: 332, baseType: !571, size: 64, offset: 192)
!571 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !567, file: !274, line: 330, size: 64, elements: !572)
!572 = !{!573}
!573 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !571, file: !274, line: 331, baseType: !392, size: 64)
!574 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !564, file: !274, line: 334, baseType: !575, size: 256)
!575 = !DICompositeType(tag: DW_TAG_array_type, baseType: !377, size: 256, elements: !576)
!576 = !{!577}
!577 = !DISubrange(count: 32)
!578 = !DIBasicType(name: "long long", size: 64, encoding: DW_ATE_signed)
!579 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!580 = !{!0, !7, !12, !17, !581, !19, !24, !29, !34, !39, !44, !49, !54, !59, !64, !66, !68, !73, !75, !77, !82, !87, !92, !97, !586, !102, !107, !112, !114, !116, !121, !126, !131, !136, !138, !588, !143, !148, !153, !155, !157, !162, !164, !166, !168, !173, !593, !175, !177, !179, !181, !183, !185, !187, !189, !194, !595, !196, !198, !200}
!581 = !DIGlobalVariableExpression(var: !582, expr: !DIExpression())
!582 = distinct !DIGlobalVariable(scope: null, file: !2, line: 72, type: !583, isLocal: true, isDefinition: true)
!583 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 16, elements: !584)
!584 = !{!585}
!585 = !DISubrange(count: 2)
!586 = !DIGlobalVariableExpression(var: !587, expr: !DIExpression())
!587 = distinct !DIGlobalVariable(scope: null, file: !2, line: 842, type: !26, isLocal: true, isDefinition: true)
!588 = !DIGlobalVariableExpression(var: !589, expr: !DIExpression())
!589 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1111, type: !590, isLocal: true, isDefinition: true)
!590 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 24, elements: !591)
!591 = !{!592}
!592 = !DISubrange(count: 3)
!593 = !DIGlobalVariableExpression(var: !594, expr: !DIExpression())
!594 = distinct !DIGlobalVariable(scope: null, file: !2, line: 328, type: !590, isLocal: true, isDefinition: true)
!595 = !DIGlobalVariableExpression(var: !596, expr: !DIExpression())
!596 = distinct !DIGlobalVariable(scope: null, file: !2, line: 644, type: !159, isLocal: true, isDefinition: true)
!597 = !{i32 7, !"Dwarf Version", i32 5}
!598 = !{i32 2, !"Debug Info Version", i32 3}
!599 = !{i32 1, !"wchar_size", i32 4}
!600 = !{i32 8, !"PIC Level", i32 2}
!601 = !{i32 7, !"PIE Level", i32 2}
!602 = !{i32 7, !"uwtable", i32 2}
!603 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!604 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!605 = distinct !DISubprogram(name: "complete_nread_binary", scope: !2, file: !2, line: 31, type: !606, scopeLine: 31, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !1011)
!606 = !DISubroutineType(types: !607)
!607 = !{null, !608}
!608 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !609, size: 64)
!609 = !DIDerivedType(tag: DW_TAG_typedef, name: "conn", file: !205, line: 813, baseType: !610)
!610 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "conn", file: !205, line: 829, size: 3968, elements: !611)
!611 = !{!612, !616, !617, !619, !620, !621, !622, !623, !624, !625, !626, !627, !628, !703, !704, !705, !706, !707, !708, !709, !938, !939, !940, !941, !942, !943, !944, !946, !947, !948, !949, !950, !951, !952, !953, !954, !960, !977, !978, !979, !980, !981, !982, !983, !984, !988, !995, !1010}
!612 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_conn", scope: !610, file: !205, line: 830, baseType: !613, size: 64)
!613 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !614, size: 64)
!614 = !DIDerivedType(tag: DW_TAG_typedef, name: "sasl_conn_t", file: !615, line: 16, baseType: !365)
!615 = !DIFile(filename: "./sasl_defs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "3a8678a43d09d8e311388b26eedc7a3e")
!616 = !DIDerivedType(tag: DW_TAG_member, name: "sfd", scope: !610, file: !205, line: 831, baseType: !418, size: 32, offset: 64)
!617 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_started", scope: !610, file: !205, line: 832, baseType: !618, size: 8, offset: 96)
!618 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!619 = !DIDerivedType(tag: DW_TAG_member, name: "authenticated", scope: !610, file: !205, line: 833, baseType: !618, size: 8, offset: 104)
!620 = !DIDerivedType(tag: DW_TAG_member, name: "set_stale", scope: !610, file: !205, line: 834, baseType: !618, size: 8, offset: 112)
!621 = !DIDerivedType(tag: DW_TAG_member, name: "mset_res", scope: !610, file: !205, line: 835, baseType: !618, size: 8, offset: 120)
!622 = !DIDerivedType(tag: DW_TAG_member, name: "close_after_write", scope: !610, file: !205, line: 836, baseType: !618, size: 8, offset: 128)
!623 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_malloced", scope: !610, file: !205, line: 837, baseType: !618, size: 8, offset: 136)
!624 = !DIDerivedType(tag: DW_TAG_member, name: "item_malloced", scope: !610, file: !205, line: 838, baseType: !618, size: 8, offset: 144)
!625 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !610, file: !205, line: 844, baseType: !204, size: 32, offset: 160)
!626 = !DIDerivedType(tag: DW_TAG_member, name: "substate", scope: !610, file: !205, line: 845, baseType: !224, size: 32, offset: 192)
!627 = !DIDerivedType(tag: DW_TAG_member, name: "last_cmd_time", scope: !610, file: !205, line: 846, baseType: !415, size: 32, offset: 224)
!628 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !610, file: !205, line: 847, baseType: !629, size: 1024, offset: 256)
!629 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event", file: !630, line: 123, size: 1024, elements: !631)
!630 = !DIFile(filename: "/usr/include/event2/event_struct.h", directory: "", checksumkind: CSK_MD5, checksum: "005d89b34bed2ed9e30b0cc3160619c1")
!631 = !{!632, !663, !673, !674, !677, !700, !701, !702}
!632 = !DIDerivedType(tag: DW_TAG_member, name: "ev_evcallback", scope: !629, file: !630, line: 124, baseType: !633, size: 320)
!633 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event_callback", file: !630, line: 107, size: 320, elements: !634)
!634 = !{!635, !642, !643, !644, !645, !662}
!635 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_active_next", scope: !633, file: !630, line: 108, baseType: !636, size: 128)
!636 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !633, file: !630, line: 108, size: 128, elements: !637)
!637 = !{!638, !640}
!638 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !636, file: !630, line: 108, baseType: !639, size: 64)
!639 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !633, size: 64)
!640 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !636, file: !630, line: 108, baseType: !641, size: 64, offset: 64)
!641 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !639, size: 64)
!642 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_flags", scope: !633, file: !630, line: 109, baseType: !464, size: 16, offset: 128)
!643 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_pri", scope: !633, file: !630, line: 110, baseType: !377, size: 8, offset: 144)
!644 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_closure", scope: !633, file: !630, line: 111, baseType: !377, size: 8, offset: 152)
!645 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cb_union", scope: !633, file: !630, line: 118, baseType: !646, size: 64, offset: 192)
!646 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !633, file: !630, line: 113, size: 64, elements: !647)
!647 = !{!648, !652, !656, !661}
!648 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_callback", scope: !646, file: !630, line: 114, baseType: !649, size: 64)
!649 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !650, size: 64)
!650 = !DISubroutineType(types: !651)
!651 = !{null, !418, !464, !365}
!652 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_selfcb", scope: !646, file: !630, line: 115, baseType: !653, size: 64)
!653 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !654, size: 64)
!654 = !DISubroutineType(types: !655)
!655 = !{null, !639, !365}
!656 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_evfinalize", scope: !646, file: !630, line: 116, baseType: !657, size: 64)
!657 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !658, size: 64)
!658 = !DISubroutineType(types: !659)
!659 = !{null, !660, !365}
!660 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !629, size: 64)
!661 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cbfinalize", scope: !646, file: !630, line: 117, baseType: !653, size: 64)
!662 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_arg", scope: !633, file: !630, line: 119, baseType: !365, size: 64, offset: 256)
!663 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout_pos", scope: !629, file: !630, line: 130, baseType: !664, size: 128, offset: 320)
!664 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !629, file: !630, line: 127, size: 128, elements: !665)
!665 = !{!666, !672}
!666 = !DIDerivedType(tag: DW_TAG_member, name: "ev_next_with_common_timeout", scope: !664, file: !630, line: 128, baseType: !667, size: 128)
!667 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !664, file: !630, line: 128, size: 128, elements: !668)
!668 = !{!669, !670}
!669 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !667, file: !630, line: 128, baseType: !660, size: 64)
!670 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !667, file: !630, line: 128, baseType: !671, size: 64, offset: 64)
!671 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !660, size: 64)
!672 = !DIDerivedType(tag: DW_TAG_member, name: "min_heap_idx", scope: !664, file: !630, line: 129, baseType: !418, size: 32)
!673 = !DIDerivedType(tag: DW_TAG_member, name: "ev_fd", scope: !629, file: !630, line: 131, baseType: !418, size: 32, offset: 448)
!674 = !DIDerivedType(tag: DW_TAG_member, name: "ev_base", scope: !629, file: !630, line: 133, baseType: !675, size: 64, offset: 512)
!675 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !676, size: 64)
!676 = !DICompositeType(tag: DW_TAG_structure_type, name: "event_base", file: !630, line: 122, flags: DIFlagFwdDecl)
!677 = !DIDerivedType(tag: DW_TAG_member, name: "ev_", scope: !629, file: !630, line: 149, baseType: !678, size: 256, offset: 576)
!678 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !629, file: !630, line: 135, size: 256, elements: !679)
!679 = !{!680, !689}
!680 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io", scope: !678, file: !630, line: 140, baseType: !681, size: 256)
!681 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !678, file: !630, line: 137, size: 256, elements: !682)
!682 = !{!683, !688}
!683 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io_next", scope: !681, file: !630, line: 138, baseType: !684, size: 128)
!684 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !681, file: !630, line: 138, size: 128, elements: !685)
!685 = !{!686, !687}
!686 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !684, file: !630, line: 138, baseType: !660, size: 64)
!687 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !684, file: !630, line: 138, baseType: !671, size: 64, offset: 64)
!688 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !681, file: !630, line: 139, baseType: !518, size: 128, offset: 128)
!689 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal", scope: !678, file: !630, line: 148, baseType: !690, size: 256)
!690 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !678, file: !630, line: 143, size: 256, elements: !691)
!691 = !{!692, !697, !698}
!692 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal_next", scope: !690, file: !630, line: 144, baseType: !693, size: 128)
!693 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !690, file: !630, line: 144, size: 128, elements: !694)
!694 = !{!695, !696}
!695 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !693, file: !630, line: 144, baseType: !660, size: 64)
!696 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !693, file: !630, line: 144, baseType: !671, size: 64, offset: 64)
!697 = !DIDerivedType(tag: DW_TAG_member, name: "ev_ncalls", scope: !690, file: !630, line: 145, baseType: !464, size: 16, offset: 128)
!698 = !DIDerivedType(tag: DW_TAG_member, name: "ev_pncalls", scope: !690, file: !630, line: 147, baseType: !699, size: 64, offset: 192)
!699 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !464, size: 64)
!700 = !DIDerivedType(tag: DW_TAG_member, name: "ev_events", scope: !629, file: !630, line: 151, baseType: !464, size: 16, offset: 832)
!701 = !DIDerivedType(tag: DW_TAG_member, name: "ev_res", scope: !629, file: !630, line: 152, baseType: !464, size: 16, offset: 848)
!702 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !629, file: !630, line: 153, baseType: !518, size: 128, offset: 896)
!703 = !DIDerivedType(tag: DW_TAG_member, name: "ev_flags", scope: !610, file: !205, line: 848, baseType: !464, size: 16, offset: 1280)
!704 = !DIDerivedType(tag: DW_TAG_member, name: "which", scope: !610, file: !205, line: 849, baseType: !464, size: 16, offset: 1296)
!705 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf", scope: !610, file: !205, line: 851, baseType: !399, size: 64, offset: 1344)
!706 = !DIDerivedType(tag: DW_TAG_member, name: "rcurr", scope: !610, file: !205, line: 852, baseType: !399, size: 64, offset: 1408)
!707 = !DIDerivedType(tag: DW_TAG_member, name: "rsize", scope: !610, file: !205, line: 853, baseType: !418, size: 32, offset: 1472)
!708 = !DIDerivedType(tag: DW_TAG_member, name: "rbytes", scope: !610, file: !205, line: 854, baseType: !418, size: 32, offset: 1504)
!709 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !610, file: !205, line: 856, baseType: !710, size: 64, offset: 1536)
!710 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !711, size: 64)
!711 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp", file: !205, line: 801, baseType: !712)
!712 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp", file: !205, line: 771, size: 9472, elements: !713)
!713 = !{!714, !885, !887, !888, !889, !890, !891, !892, !899, !900, !901, !902, !903, !904, !905, !906, !907, !930, !934}
!714 = !DIDerivedType(tag: DW_TAG_member, name: "bundle", scope: !712, file: !205, line: 772, baseType: !715, size: 64)
!715 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !716, size: 64)
!716 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp_bundle", file: !205, line: 720, baseType: !717)
!717 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp_bundle", file: !205, line: 804, size: 256, elements: !718)
!718 = !{!719, !720, !721, !880, !882, !883}
!719 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !717, file: !205, line: 805, baseType: !377, size: 8)
!720 = !DIDerivedType(tag: DW_TAG_member, name: "next_check", scope: !717, file: !205, line: 806, baseType: !377, size: 8, offset: 8)
!721 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !717, file: !205, line: 807, baseType: !722, size: 64, offset: 64)
!722 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !723, size: 64)
!723 = !DIDerivedType(tag: DW_TAG_typedef, name: "LIBEVENT_THREAD", file: !205, line: 765, baseType: !724)
!724 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !205, line: 721, size: 55488, elements: !725)
!725 = !{!726, !728, !729, !734, !735, !736, !766, !767, !768, !823, !843, !846, !874, !875, !876, !877, !878, !879}
!726 = !DIDerivedType(tag: DW_TAG_member, name: "thread_id", scope: !724, file: !205, line: 722, baseType: !727, size: 64)
!727 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_t", file: !451, line: 27, baseType: !394)
!728 = !DIDerivedType(tag: DW_TAG_member, name: "base", scope: !724, file: !205, line: 723, baseType: !675, size: 64, offset: 64)
!729 = !DIDerivedType(tag: DW_TAG_member, name: "n", scope: !724, file: !205, line: 724, baseType: !730, size: 1088, offset: 128)
!730 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_notify", file: !205, line: 710, size: 1088, elements: !731)
!731 = !{!732, !733}
!732 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event", scope: !730, file: !205, line: 711, baseType: !629, size: 1024)
!733 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event_fd", scope: !730, file: !205, line: 713, baseType: !418, size: 32, offset: 1024)
!734 = !DIDerivedType(tag: DW_TAG_member, name: "ion", scope: !724, file: !205, line: 725, baseType: !730, size: 1088, offset: 1216)
!735 = !DIDerivedType(tag: DW_TAG_member, name: "ion_lock", scope: !724, file: !205, line: 726, baseType: !450, size: 320, offset: 2304)
!736 = !DIDerivedType(tag: DW_TAG_member, name: "ion_head", scope: !724, file: !205, line: 727, baseType: !737, size: 128, offset: 2624)
!737 = !DIDerivedType(tag: DW_TAG_typedef, name: "iop_head_t", file: !205, line: 686, baseType: !738)
!738 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iop_head_s", file: !205, line: 686, size: 128, elements: !739)
!739 = !{!740, !764}
!740 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !738, file: !205, line: 686, baseType: !741, size: 64)
!741 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !742, size: 64)
!742 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_io_pending_t", file: !205, line: 815, size: 1408, elements: !743)
!743 = !{!744, !745, !746, !747, !748, !755, !756, !760}
!744 = !DIDerivedType(tag: DW_TAG_member, name: "io_queue_type", scope: !742, file: !205, line: 816, baseType: !418, size: 32)
!745 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !742, file: !205, line: 817, baseType: !722, size: 64, offset: 64)
!746 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !742, file: !205, line: 818, baseType: !608, size: 64, offset: 128)
!747 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !742, file: !205, line: 819, baseType: !710, size: 64, offset: 192)
!748 = !DIDerivedType(tag: DW_TAG_member, name: "return_cb", scope: !742, file: !205, line: 820, baseType: !749, size: 64, offset: 256)
!749 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb", file: !205, line: 690, baseType: !750)
!750 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !751, size: 64)
!751 = !DISubroutineType(types: !752)
!752 = !{null, !753}
!753 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !754, size: 64)
!754 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_pending_t", file: !205, line: 687, baseType: !742)
!755 = !DIDerivedType(tag: DW_TAG_member, name: "finalize_cb", scope: !742, file: !205, line: 821, baseType: !749, size: 64, offset: 320)
!756 = !DIDerivedType(tag: DW_TAG_member, name: "iop_next", scope: !742, file: !205, line: 822, baseType: !757, size: 64, offset: 384)
!757 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !742, file: !205, line: 822, size: 64, elements: !758)
!758 = !{!759}
!759 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !757, file: !205, line: 822, baseType: !741, size: 64)
!760 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !742, file: !205, line: 823, baseType: !761, size: 960, offset: 448)
!761 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 960, elements: !762)
!762 = !{!763}
!763 = !DISubrange(count: 120)
!764 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !738, file: !205, line: 686, baseType: !765, size: 64, offset: 64)
!765 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !741, size: 64)
!766 = !DIDerivedType(tag: DW_TAG_member, name: "cur_sfd", scope: !724, file: !205, line: 728, baseType: !418, size: 32, offset: 2752)
!767 = !DIDerivedType(tag: DW_TAG_member, name: "thread_baseid", scope: !724, file: !205, line: 729, baseType: !418, size: 32, offset: 2784)
!768 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !724, file: !205, line: 730, baseType: !769, size: 51584, offset: 2816)
!769 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_stats", file: !205, line: 372, size: 51584, elements: !770)
!770 = !{!771, !772, !773, !774, !775, !776, !777, !778, !779, !780, !781, !782, !783, !784, !785, !786, !787, !788, !789, !790, !791, !792, !793, !794, !795, !796, !797, !798, !799, !800, !801, !802, !816, !820, !821, !822}
!771 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !769, file: !205, line: 373, baseType: !450, size: 320)
!772 = !DIDerivedType(tag: DW_TAG_member, name: "get_cmds", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 320)
!773 = !DIDerivedType(tag: DW_TAG_member, name: "get_misses", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 384)
!774 = !DIDerivedType(tag: DW_TAG_member, name: "get_expired", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 448)
!775 = !DIDerivedType(tag: DW_TAG_member, name: "get_flushed", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 512)
!776 = !DIDerivedType(tag: DW_TAG_member, name: "touch_cmds", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 576)
!777 = !DIDerivedType(tag: DW_TAG_member, name: "touch_misses", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 640)
!778 = !DIDerivedType(tag: DW_TAG_member, name: "delete_misses", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 704)
!779 = !DIDerivedType(tag: DW_TAG_member, name: "incr_misses", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 768)
!780 = !DIDerivedType(tag: DW_TAG_member, name: "decr_misses", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 832)
!781 = !DIDerivedType(tag: DW_TAG_member, name: "cas_misses", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 896)
!782 = !DIDerivedType(tag: DW_TAG_member, name: "meta_cmds", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 960)
!783 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_read", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 1024)
!784 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_written", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 1088)
!785 = !DIDerivedType(tag: DW_TAG_member, name: "flush_cmds", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 1152)
!786 = !DIDerivedType(tag: DW_TAG_member, name: "conn_yields", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 1216)
!787 = !DIDerivedType(tag: DW_TAG_member, name: "auth_cmds", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 1280)
!788 = !DIDerivedType(tag: DW_TAG_member, name: "auth_errors", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 1344)
!789 = !DIDerivedType(tag: DW_TAG_member, name: "idle_kicks", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 1408)
!790 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_oom", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 1472)
!791 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_count", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 1536)
!792 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_bytes", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 1600)
!793 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_oom", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 1664)
!794 = !DIDerivedType(tag: DW_TAG_member, name: "store_too_large", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 1728)
!795 = !DIDerivedType(tag: DW_TAG_member, name: "store_no_memory", scope: !769, file: !205, line: 375, baseType: !392, size: 64, offset: 1792)
!796 = !DIDerivedType(tag: DW_TAG_member, name: "get_extstore", scope: !769, file: !205, line: 377, baseType: !392, size: 64, offset: 1856)
!797 = !DIDerivedType(tag: DW_TAG_member, name: "get_aborted_extstore", scope: !769, file: !205, line: 377, baseType: !392, size: 64, offset: 1920)
!798 = !DIDerivedType(tag: DW_TAG_member, name: "get_oom_extstore", scope: !769, file: !205, line: 377, baseType: !392, size: 64, offset: 1984)
!799 = !DIDerivedType(tag: DW_TAG_member, name: "recache_from_extstore", scope: !769, file: !205, line: 377, baseType: !392, size: 64, offset: 2048)
!800 = !DIDerivedType(tag: DW_TAG_member, name: "miss_from_extstore", scope: !769, file: !205, line: 377, baseType: !392, size: 64, offset: 2112)
!801 = !DIDerivedType(tag: DW_TAG_member, name: "badcrc_from_extstore", scope: !769, file: !205, line: 377, baseType: !392, size: 64, offset: 2176)
!802 = !DIDerivedType(tag: DW_TAG_member, name: "slab_stats", scope: !769, file: !205, line: 383, baseType: !803, size: 32768, offset: 2240)
!803 = !DICompositeType(tag: DW_TAG_array_type, baseType: !804, size: 32768, elements: !814)
!804 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "slab_stats", file: !205, line: 318, size: 512, elements: !805)
!805 = !{!806, !807, !808, !809, !810, !811, !812, !813}
!806 = !DIDerivedType(tag: DW_TAG_member, name: "set_cmds", scope: !804, file: !205, line: 320, baseType: !392, size: 64)
!807 = !DIDerivedType(tag: DW_TAG_member, name: "get_hits", scope: !804, file: !205, line: 320, baseType: !392, size: 64, offset: 64)
!808 = !DIDerivedType(tag: DW_TAG_member, name: "touch_hits", scope: !804, file: !205, line: 320, baseType: !392, size: 64, offset: 128)
!809 = !DIDerivedType(tag: DW_TAG_member, name: "delete_hits", scope: !804, file: !205, line: 320, baseType: !392, size: 64, offset: 192)
!810 = !DIDerivedType(tag: DW_TAG_member, name: "cas_hits", scope: !804, file: !205, line: 320, baseType: !392, size: 64, offset: 256)
!811 = !DIDerivedType(tag: DW_TAG_member, name: "cas_badval", scope: !804, file: !205, line: 320, baseType: !392, size: 64, offset: 320)
!812 = !DIDerivedType(tag: DW_TAG_member, name: "incr_hits", scope: !804, file: !205, line: 320, baseType: !392, size: 64, offset: 384)
!813 = !DIDerivedType(tag: DW_TAG_member, name: "decr_hits", scope: !804, file: !205, line: 320, baseType: !392, size: 64, offset: 448)
!814 = !{!815}
!815 = !DISubrange(count: 64)
!816 = !DIDerivedType(tag: DW_TAG_member, name: "lru_hits", scope: !769, file: !205, line: 384, baseType: !817, size: 16384, offset: 35008)
!817 = !DICompositeType(tag: DW_TAG_array_type, baseType: !392, size: 16384, elements: !818)
!818 = !{!819}
!819 = !DISubrange(count: 256)
!820 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_count", scope: !769, file: !205, line: 385, baseType: !392, size: 64, offset: 51392)
!821 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes", scope: !769, file: !205, line: 386, baseType: !392, size: 64, offset: 51456)
!822 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes_free", scope: !769, file: !205, line: 387, baseType: !392, size: 64, offset: 51520)
!823 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !724, file: !205, line: 731, baseType: !824, size: 576, offset: 54400)
!824 = !DICompositeType(tag: DW_TAG_array_type, baseType: !825, size: 576, elements: !591)
!825 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb_t", file: !205, line: 708, baseType: !826)
!826 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_cb_s", file: !205, line: 704, size: 192, elements: !827)
!827 = !{!828, !829, !842}
!828 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !826, file: !205, line: 705, baseType: !365, size: 64)
!829 = !DIDerivedType(tag: DW_TAG_member, name: "submit_cb", scope: !826, file: !205, line: 706, baseType: !830, size: 64, offset: 64)
!830 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_stack_cb", file: !205, line: 689, baseType: !831)
!831 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !832, size: 64)
!832 = !DISubroutineType(types: !833)
!833 = !{null, !834}
!834 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !835, size: 64)
!835 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_t", file: !205, line: 688, baseType: !836)
!836 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_s", file: !205, line: 697, size: 192, elements: !837)
!837 = !{!838, !839, !840, !841}
!838 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !836, file: !205, line: 698, baseType: !365, size: 64)
!839 = !DIDerivedType(tag: DW_TAG_member, name: "stack_ctx", scope: !836, file: !205, line: 699, baseType: !365, size: 64, offset: 64)
!840 = !DIDerivedType(tag: DW_TAG_member, name: "count", scope: !836, file: !205, line: 700, baseType: !418, size: 32, offset: 128)
!841 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !836, file: !205, line: 701, baseType: !418, size: 32, offset: 160)
!842 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !826, file: !205, line: 707, baseType: !418, size: 32, offset: 128)
!843 = !DIDerivedType(tag: DW_TAG_member, name: "ev_queue", scope: !724, file: !205, line: 732, baseType: !844, size: 64, offset: 54976)
!844 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !845, size: 64)
!845 = !DICompositeType(tag: DW_TAG_structure_type, name: "conn_queue", file: !205, line: 732, flags: DIFlagFwdDecl)
!846 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_cache", scope: !724, file: !205, line: 733, baseType: !847, size: 64, offset: 55040)
!847 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !848, size: 64)
!848 = !DIDerivedType(tag: DW_TAG_typedef, name: "cache_t", file: !849, line: 39, baseType: !850)
!849 = !DIFile(filename: "./cache.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d97639c8540587a19d8550d7d7156448")
!850 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !849, line: 22, size: 704, elements: !851)
!851 = !{!852, !853, !854, !867, !870, !871, !872, !873}
!852 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !850, file: !849, line: 24, baseType: !450, size: 320)
!853 = !DIDerivedType(tag: DW_TAG_member, name: "name", scope: !850, file: !849, line: 26, baseType: !399, size: 64, offset: 320)
!854 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !850, file: !849, line: 28, baseType: !855, size: 128, offset: 384)
!855 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_head", file: !849, line: 28, size: 128, elements: !856)
!856 = !{!857, !865}
!857 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !855, file: !849, line: 28, baseType: !858, size: 64)
!858 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !859, size: 64)
!859 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_free_s", file: !849, line: 12, size: 64, elements: !860)
!860 = !{!861}
!861 = !DIDerivedType(tag: DW_TAG_member, name: "c_next", scope: !859, file: !849, line: 13, baseType: !862, size: 64)
!862 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !859, file: !849, line: 13, size: 64, elements: !863)
!863 = !{!864}
!864 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !862, file: !849, line: 13, baseType: !858, size: 64)
!865 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !855, file: !849, line: 28, baseType: !866, size: 64, offset: 64)
!866 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !858, size: 64)
!867 = !DIDerivedType(tag: DW_TAG_member, name: "bufsize", scope: !850, file: !849, line: 30, baseType: !868, size: 64, offset: 512)
!868 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !869, line: 18, baseType: !394)
!869 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!870 = !DIDerivedType(tag: DW_TAG_member, name: "freetotal", scope: !850, file: !849, line: 32, baseType: !418, size: 32, offset: 576)
!871 = !DIDerivedType(tag: DW_TAG_member, name: "total", scope: !850, file: !849, line: 34, baseType: !418, size: 32, offset: 608)
!872 = !DIDerivedType(tag: DW_TAG_member, name: "freecurr", scope: !850, file: !849, line: 36, baseType: !418, size: 32, offset: 640)
!873 = !DIDerivedType(tag: DW_TAG_member, name: "limit", scope: !850, file: !849, line: 38, baseType: !418, size: 32, offset: 672)
!874 = !DIDerivedType(tag: DW_TAG_member, name: "open_bundle", scope: !724, file: !205, line: 734, baseType: !715, size: 64, offset: 55104)
!875 = !DIDerivedType(tag: DW_TAG_member, name: "io_cache", scope: !724, file: !205, line: 735, baseType: !847, size: 64, offset: 55168)
!876 = !DIDerivedType(tag: DW_TAG_member, name: "storage", scope: !724, file: !205, line: 737, baseType: !365, size: 64, offset: 55232)
!877 = !DIDerivedType(tag: DW_TAG_member, name: "l", scope: !724, file: !205, line: 739, baseType: !442, size: 64, offset: 55296)
!878 = !DIDerivedType(tag: DW_TAG_member, name: "lru_bump_buf", scope: !724, file: !205, line: 740, baseType: !365, size: 64, offset: 55360)
!879 = !DIDerivedType(tag: DW_TAG_member, name: "napi_id", scope: !724, file: !205, line: 744, baseType: !418, size: 32, offset: 55424)
!880 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !717, file: !205, line: 808, baseType: !881, size: 64, offset: 128)
!881 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !717, size: 64)
!882 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !717, file: !205, line: 809, baseType: !881, size: 64, offset: 192)
!883 = !DIDerivedType(tag: DW_TAG_member, name: "r", scope: !717, file: !205, line: 810, baseType: !884, offset: 256)
!884 = !DICompositeType(tag: DW_TAG_array_type, baseType: !711, elements: !429)
!885 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !712, file: !205, line: 773, baseType: !886, size: 64, offset: 64)
!886 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !712, size: 64)
!887 = !DIDerivedType(tag: DW_TAG_member, name: "wbytes", scope: !712, file: !205, line: 774, baseType: !418, size: 32, offset: 128)
!888 = !DIDerivedType(tag: DW_TAG_member, name: "tosend", scope: !712, file: !205, line: 775, baseType: !418, size: 32, offset: 160)
!889 = !DIDerivedType(tag: DW_TAG_member, name: "write_and_free", scope: !712, file: !205, line: 776, baseType: !365, size: 64, offset: 192)
!890 = !DIDerivedType(tag: DW_TAG_member, name: "io_pending", scope: !712, file: !205, line: 777, baseType: !753, size: 64, offset: 256)
!891 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !712, file: !205, line: 779, baseType: !440, size: 64, offset: 320)
!892 = !DIDerivedType(tag: DW_TAG_member, name: "iov", scope: !712, file: !205, line: 780, baseType: !893, size: 512, offset: 384)
!893 = !DICompositeType(tag: DW_TAG_array_type, baseType: !894, size: 512, elements: !160)
!894 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iovec", file: !895, line: 26, size: 128, elements: !896)
!895 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_iovec.h", directory: "", checksumkind: CSK_MD5, checksum: "a53f2c2488bb0e21e47850624c16538a")
!896 = !{!897, !898}
!897 = !DIDerivedType(tag: DW_TAG_member, name: "iov_base", scope: !894, file: !895, line: 28, baseType: !365, size: 64)
!898 = !DIDerivedType(tag: DW_TAG_member, name: "iov_len", scope: !894, file: !895, line: 29, baseType: !868, size: 64, offset: 64)
!899 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_total", scope: !712, file: !205, line: 781, baseType: !418, size: 32, offset: 896)
!900 = !DIDerivedType(tag: DW_TAG_member, name: "iovcnt", scope: !712, file: !205, line: 782, baseType: !377, size: 8, offset: 928)
!901 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_data_iov", scope: !712, file: !205, line: 783, baseType: !377, size: 8, offset: 936)
!902 = !DIDerivedType(tag: DW_TAG_member, name: "skip", scope: !712, file: !205, line: 788, baseType: !618, size: 8, offset: 944)
!903 = !DIDerivedType(tag: DW_TAG_member, name: "free", scope: !712, file: !205, line: 789, baseType: !618, size: 8, offset: 952)
!904 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !712, file: !205, line: 794, baseType: !383, size: 16, offset: 960)
!905 = !DIDerivedType(tag: DW_TAG_member, name: "udp_sequence", scope: !712, file: !205, line: 795, baseType: !383, size: 16, offset: 976)
!906 = !DIDerivedType(tag: DW_TAG_member, name: "udp_total", scope: !712, file: !205, line: 796, baseType: !383, size: 16, offset: 992)
!907 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !712, file: !205, line: 797, baseType: !908, size: 224, offset: 1024)
!908 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "sockaddr_in6", file: !909, line: 262, size: 224, elements: !910)
!909 = !DIFile(filename: "/usr/include/netinet/in.h", directory: "", checksumkind: CSK_MD5, checksum: "fbd766480c8cb9a8fe07ee7aa568ee60")
!910 = !{!911, !914, !916, !917, !929}
!911 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_family", scope: !908, file: !909, line: 264, baseType: !912, size: 16)
!912 = !DIDerivedType(tag: DW_TAG_typedef, name: "sa_family_t", file: !913, line: 28, baseType: !368)
!913 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/sockaddr.h", directory: "", checksumkind: CSK_MD5, checksum: "5066b774f0f3cdb5cbbb5467306060db")
!914 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_port", scope: !908, file: !909, line: 265, baseType: !915, size: 16, offset: 16)
!915 = !DIDerivedType(tag: DW_TAG_typedef, name: "in_port_t", file: !909, line: 125, baseType: !383)
!916 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_flowinfo", scope: !908, file: !909, line: 266, baseType: !388, size: 32, offset: 32)
!917 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_addr", scope: !908, file: !909, line: 267, baseType: !918, size: 128, offset: 64)
!918 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "in6_addr", file: !909, line: 221, size: 128, elements: !919)
!919 = !{!920}
!920 = !DIDerivedType(tag: DW_TAG_member, name: "__in6_u", scope: !918, file: !909, line: 228, baseType: !921, size: 128)
!921 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !918, file: !909, line: 223, size: 128, elements: !922)
!922 = !{!923, !925, !927}
!923 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr8", scope: !921, file: !909, line: 225, baseType: !924, size: 128)
!924 = !DICompositeType(tag: DW_TAG_array_type, baseType: !377, size: 128, elements: !32)
!925 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr16", scope: !921, file: !909, line: 226, baseType: !926, size: 128)
!926 = !DICompositeType(tag: DW_TAG_array_type, baseType: !383, size: 128, elements: !15)
!927 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr32", scope: !921, file: !909, line: 227, baseType: !928, size: 128)
!928 = !DICompositeType(tag: DW_TAG_array_type, baseType: !388, size: 128, elements: !160)
!929 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_scope_id", scope: !908, file: !909, line: 268, baseType: !388, size: 32, offset: 192)
!930 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !712, file: !205, line: 798, baseType: !931, size: 32, offset: 1248)
!931 = !DIDerivedType(tag: DW_TAG_typedef, name: "socklen_t", file: !932, line: 33, baseType: !933)
!932 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/socket.h", directory: "", checksumkind: CSK_MD5, checksum: "71a09f67661e8e55cf505c19b5ddbb85")
!933 = !DIDerivedType(tag: DW_TAG_typedef, name: "__socklen_t", file: !367, line: 210, baseType: !206)
!934 = !DIDerivedType(tag: DW_TAG_member, name: "wbuf", scope: !712, file: !205, line: 800, baseType: !935, size: 8192, offset: 1280)
!935 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 8192, elements: !936)
!936 = !{!937}
!937 = !DISubrange(count: 1024)
!938 = !DIDerivedType(tag: DW_TAG_member, name: "resp_head", scope: !610, file: !205, line: 857, baseType: !710, size: 64, offset: 1600)
!939 = !DIDerivedType(tag: DW_TAG_member, name: "ritem", scope: !610, file: !205, line: 858, baseType: !399, size: 64, offset: 1664)
!940 = !DIDerivedType(tag: DW_TAG_member, name: "rlbytes", scope: !610, file: !205, line: 859, baseType: !418, size: 32, offset: 1728)
!941 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !610, file: !205, line: 867, baseType: !365, size: 64, offset: 1792)
!942 = !DIDerivedType(tag: DW_TAG_member, name: "sbytes", scope: !610, file: !205, line: 870, baseType: !418, size: 32, offset: 1856)
!943 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues_submitted", scope: !610, file: !205, line: 872, baseType: !418, size: 32, offset: 1888)
!944 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !610, file: !205, line: 873, baseType: !945, size: 576, offset: 1920)
!945 = !DICompositeType(tag: DW_TAG_array_type, baseType: !835, size: 576, elements: !591)
!946 = !DIDerivedType(tag: DW_TAG_member, name: "recache_counter", scope: !610, file: !205, line: 878, baseType: !206, size: 32, offset: 2496)
!947 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !610, file: !205, line: 880, baseType: !257, size: 32, offset: 2528)
!948 = !DIDerivedType(tag: DW_TAG_member, name: "transport", scope: !610, file: !205, line: 881, baseType: !262, size: 32, offset: 2560)
!949 = !DIDerivedType(tag: DW_TAG_member, name: "close_reason", scope: !610, file: !205, line: 882, baseType: !267, size: 32, offset: 2592)
!950 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !610, file: !205, line: 885, baseType: !418, size: 32, offset: 2624)
!951 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !610, file: !205, line: 886, baseType: !908, size: 224, offset: 2656)
!952 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !610, file: !205, line: 887, baseType: !931, size: 32, offset: 2880)
!953 = !DIDerivedType(tag: DW_TAG_member, name: "noreply", scope: !610, file: !205, line: 889, baseType: !618, size: 8, offset: 2912)
!954 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !610, file: !205, line: 895, baseType: !955, size: 192, offset: 2944)
!955 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !610, file: !205, line: 891, size: 192, elements: !956)
!956 = !{!957, !958, !959}
!957 = !DIDerivedType(tag: DW_TAG_member, name: "buffer", scope: !955, file: !205, line: 892, baseType: !399, size: 64)
!958 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !955, file: !205, line: 893, baseType: !868, size: 64, offset: 64)
!959 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !955, file: !205, line: 894, baseType: !868, size: 64, offset: 128)
!960 = !DIDerivedType(tag: DW_TAG_member, name: "binary_header", scope: !610, file: !205, line: 899, baseType: !961, size: 192, offset: 3136)
!961 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_request_header", file: !274, line: 164, baseType: !962)
!962 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !274, line: 151, size: 192, elements: !963)
!963 = !{!964, !976}
!964 = !DIDerivedType(tag: DW_TAG_member, name: "request", scope: !962, file: !274, line: 162, baseType: !965, size: 192)
!965 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !962, file: !274, line: 152, size: 192, elements: !966)
!966 = !{!967, !968, !969, !970, !971, !972, !973, !974, !975}
!967 = !DIDerivedType(tag: DW_TAG_member, name: "magic", scope: !965, file: !274, line: 153, baseType: !377, size: 8)
!968 = !DIDerivedType(tag: DW_TAG_member, name: "opcode", scope: !965, file: !274, line: 154, baseType: !377, size: 8, offset: 8)
!969 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !965, file: !274, line: 155, baseType: !383, size: 16, offset: 16)
!970 = !DIDerivedType(tag: DW_TAG_member, name: "extlen", scope: !965, file: !274, line: 156, baseType: !377, size: 8, offset: 32)
!971 = !DIDerivedType(tag: DW_TAG_member, name: "datatype", scope: !965, file: !274, line: 157, baseType: !377, size: 8, offset: 40)
!972 = !DIDerivedType(tag: DW_TAG_member, name: "reserved", scope: !965, file: !274, line: 158, baseType: !383, size: 16, offset: 48)
!973 = !DIDerivedType(tag: DW_TAG_member, name: "bodylen", scope: !965, file: !274, line: 159, baseType: !388, size: 32, offset: 64)
!974 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !965, file: !274, line: 160, baseType: !388, size: 32, offset: 96)
!975 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !965, file: !274, line: 161, baseType: !392, size: 64, offset: 128)
!976 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !962, file: !274, line: 163, baseType: !396, size: 192)
!977 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !610, file: !205, line: 900, baseType: !392, size: 64, offset: 3328)
!978 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !610, file: !205, line: 901, baseType: !392, size: 64, offset: 3392)
!979 = !DIDerivedType(tag: DW_TAG_member, name: "cmd", scope: !610, file: !205, line: 902, baseType: !464, size: 16, offset: 3456)
!980 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !610, file: !205, line: 903, baseType: !418, size: 32, offset: 3488)
!981 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !610, file: !205, line: 904, baseType: !418, size: 32, offset: 3520)
!982 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !610, file: !205, line: 905, baseType: !608, size: 64, offset: 3584)
!983 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !610, file: !205, line: 906, baseType: !722, size: 64, offset: 3648)
!984 = !DIDerivedType(tag: DW_TAG_member, name: "try_read_command", scope: !610, file: !205, line: 907, baseType: !985, size: 64, offset: 3712)
!985 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !986, size: 64)
!986 = !DISubroutineType(types: !987)
!987 = !{!418, !608}
!988 = !DIDerivedType(tag: DW_TAG_member, name: "read", scope: !610, file: !205, line: 908, baseType: !989, size: 64, offset: 3776)
!989 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !990, size: 64)
!990 = !DISubroutineType(types: !991)
!991 = !{!992, !608, !365, !868}
!992 = !DIDerivedType(tag: DW_TAG_typedef, name: "ssize_t", file: !993, line: 108, baseType: !994)
!993 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/types.h", directory: "", checksumkind: CSK_MD5, checksum: "7fb02a803b0c9b11cb5276b77d21e9d8")
!994 = !DIDerivedType(tag: DW_TAG_typedef, name: "__ssize_t", file: !367, line: 194, baseType: !476)
!995 = !DIDerivedType(tag: DW_TAG_member, name: "sendmsg", scope: !610, file: !205, line: 909, baseType: !996, size: 64, offset: 3840)
!996 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !997, size: 64)
!997 = !DISubroutineType(types: !998)
!998 = !{!992, !608, !999, !418}
!999 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1000, size: 64)
!1000 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "msghdr", file: !932, line: 262, size: 448, elements: !1001)
!1001 = !{!1002, !1003, !1004, !1006, !1007, !1008, !1009}
!1002 = !DIDerivedType(tag: DW_TAG_member, name: "msg_name", scope: !1000, file: !932, line: 264, baseType: !365, size: 64)
!1003 = !DIDerivedType(tag: DW_TAG_member, name: "msg_namelen", scope: !1000, file: !932, line: 265, baseType: !931, size: 32, offset: 64)
!1004 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iov", scope: !1000, file: !932, line: 267, baseType: !1005, size: 64, offset: 128)
!1005 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !894, size: 64)
!1006 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iovlen", scope: !1000, file: !932, line: 268, baseType: !868, size: 64, offset: 192)
!1007 = !DIDerivedType(tag: DW_TAG_member, name: "msg_control", scope: !1000, file: !932, line: 270, baseType: !365, size: 64, offset: 256)
!1008 = !DIDerivedType(tag: DW_TAG_member, name: "msg_controllen", scope: !1000, file: !932, line: 271, baseType: !868, size: 64, offset: 320)
!1009 = !DIDerivedType(tag: DW_TAG_member, name: "msg_flags", scope: !1000, file: !932, line: 276, baseType: !418, size: 32, offset: 384)
!1010 = !DIDerivedType(tag: DW_TAG_member, name: "write", scope: !610, file: !205, line: 910, baseType: !989, size: 64, offset: 3904)
!1011 = !{!1012}
!1012 = !DILocalVariable(name: "c", arg: 1, scope: !605, file: !2, line: 31, type: !608)
!1013 = distinct !DIAssignID()
!1014 = !DILocation(line: 0, scope: !605)
!1015 = !DILocation(line: 35, column: 15, scope: !605)
!1016 = !{!1017, !1021, i64 24}
!1017 = !{!"conn", !1018, i64 0, !1021, i64 8, !1022, i64 12, !1022, i64 13, !1022, i64 14, !1022, i64 15, !1022, i64 16, !1022, i64 17, !1022, i64 18, !1021, i64 20, !1021, i64 24, !1021, i64 28, !1023, i64 32, !1026, i64 160, !1026, i64 162, !1018, i64 168, !1018, i64 176, !1021, i64 184, !1021, i64 188, !1018, i64 192, !1018, i64 200, !1018, i64 208, !1021, i64 216, !1018, i64 224, !1021, i64 232, !1021, i64 236, !1019, i64 240, !1021, i64 312, !1021, i64 316, !1021, i64 320, !1021, i64 324, !1021, i64 328, !1029, i64 332, !1021, i64 360, !1022, i64 364, !1031, i64 368, !1019, i64 392, !1028, i64 416, !1028, i64 424, !1026, i64 432, !1021, i64 436, !1021, i64 440, !1018, i64 448, !1018, i64 456, !1018, i64 464, !1018, i64 472, !1018, i64 480, !1018, i64 488}
!1018 = !{!"any pointer", !1019, i64 0}
!1019 = !{!"omnipotent char", !1020, i64 0}
!1020 = !{!"Simple C/C++ TBAA"}
!1021 = !{!"int", !1019, i64 0}
!1022 = !{!"_Bool", !1019, i64 0}
!1023 = !{!"event", !1024, i64 0, !1019, i64 40, !1021, i64 56, !1018, i64 64, !1019, i64 72, !1026, i64 104, !1026, i64 106, !1027, i64 112}
!1024 = !{!"event_callback", !1025, i64 0, !1026, i64 16, !1019, i64 18, !1019, i64 19, !1019, i64 24, !1018, i64 32}
!1025 = !{!"", !1018, i64 0, !1018, i64 8}
!1026 = !{!"short", !1019, i64 0}
!1027 = !{!"timeval", !1028, i64 0, !1028, i64 8}
!1028 = !{!"long", !1019, i64 0}
!1029 = !{!"sockaddr_in6", !1026, i64 0, !1026, i64 2, !1021, i64 4, !1030, i64 8, !1021, i64 24}
!1030 = !{!"in6_addr", !1019, i64 0}
!1031 = !{!"", !1018, i64 0, !1028, i64 8, !1028, i64 16}
!1032 = !DILocation(line: 35, column: 5, scope: !605)
!1033 = !DILocalVariable(name: "cas", scope: !1034, file: !2, line: 387, type: !392)
!1034 = distinct !DISubprogram(name: "complete_update_bin", scope: !2, file: !2, line: 361, type: !606, scopeLine: 361, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !1035)
!1035 = !{!1036, !1037, !1039, !1040, !1041, !1033}
!1036 = !DILocalVariable(name: "c", arg: 1, scope: !1034, file: !2, line: 361, type: !608)
!1037 = !DILocalVariable(name: "eno", scope: !1034, file: !2, line: 362, type: !1038)
!1038 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_response_status", file: !274, line: 74, baseType: !278)
!1039 = !DILocalVariable(name: "ret", scope: !1034, file: !2, line: 363, type: !294)
!1040 = !DILocalVariable(name: "it", scope: !1034, file: !2, line: 366, type: !440)
!1041 = !DILocalVariable(name: "ch", scope: !1042, file: !2, line: 378, type: !400)
!1042 = distinct !DILexicalBlock(scope: !1043, file: !2, line: 376, column: 12)
!1043 = distinct !DILexicalBlock(scope: !1034, file: !2, line: 373, column: 9)
!1044 = !DILocation(line: 0, scope: !1034, inlinedAt: !1045)
!1045 = distinct !DILocation(line: 37, column: 9, scope: !1046)
!1046 = distinct !DILexicalBlock(scope: !605, file: !2, line: 35, column: 25)
!1047 = !DILocation(line: 366, column: 19, scope: !1034, inlinedAt: !1045)
!1048 = !{!1017, !1018, i64 224}
!1049 = !DILocation(line: 367, column: 28, scope: !1034, inlinedAt: !1045)
!1050 = !{!1017, !1018, i64 456}
!1051 = !DILocation(line: 367, column: 36, scope: !1034, inlinedAt: !1045)
!1052 = !DILocation(line: 367, column: 5, scope: !1034, inlinedAt: !1045)
!1053 = !DILocation(line: 368, column: 8, scope: !1034, inlinedAt: !1045)
!1054 = !DILocation(line: 368, column: 22, scope: !1034, inlinedAt: !1045)
!1055 = !DILocation(line: 368, column: 33, scope: !1034, inlinedAt: !1045)
!1056 = !{!1019, !1019, i64 0}
!1057 = !DILocation(line: 368, column: 5, scope: !1034, inlinedAt: !1045)
!1058 = !DILocation(line: 368, column: 57, scope: !1034, inlinedAt: !1045)
!1059 = !{!1060, !1028, i64 0}
!1060 = !{!"slab_stats", !1028, i64 0, !1028, i64 8, !1028, i64 16, !1028, i64 24, !1028, i64 32, !1028, i64 40, !1028, i64 48, !1028, i64 56}
!1061 = !DILocation(line: 369, column: 38, scope: !1034, inlinedAt: !1045)
!1062 = !DILocation(line: 369, column: 5, scope: !1034, inlinedAt: !1045)
!1063 = !DILocation(line: 373, column: 14, scope: !1043, inlinedAt: !1045)
!1064 = !{!1026, !1026, i64 0}
!1065 = !DILocation(line: 373, column: 10, scope: !1043, inlinedAt: !1045)
!1066 = !DILocation(line: 373, column: 23, scope: !1043, inlinedAt: !1045)
!1067 = !DILocation(line: 373, column: 39, scope: !1043, inlinedAt: !1045)
!1068 = !DILocation(line: 373, column: 9, scope: !1034, inlinedAt: !1045)
!1069 = !DILocation(line: 374, column: 11, scope: !1070, inlinedAt: !1045)
!1070 = distinct !DILexicalBlock(scope: !1043, file: !2, line: 373, column: 45)
!1071 = !DILocation(line: 374, column: 31, scope: !1070, inlinedAt: !1045)
!1072 = !{!1021, !1021, i64 0}
!1073 = !DILocation(line: 374, column: 25, scope: !1070, inlinedAt: !1045)
!1074 = !DILocation(line: 374, column: 38, scope: !1070, inlinedAt: !1045)
!1075 = !DILocation(line: 374, column: 43, scope: !1070, inlinedAt: !1045)
!1076 = !DILocation(line: 375, column: 11, scope: !1070, inlinedAt: !1045)
!1077 = !DILocation(line: 375, column: 31, scope: !1070, inlinedAt: !1045)
!1078 = !DILocation(line: 375, column: 25, scope: !1070, inlinedAt: !1045)
!1079 = !DILocation(line: 375, column: 38, scope: !1070, inlinedAt: !1045)
!1080 = !DILocation(line: 375, column: 43, scope: !1070, inlinedAt: !1045)
!1081 = !DILocation(line: 376, column: 5, scope: !1070, inlinedAt: !1045)
!1082 = !DILocation(line: 378, column: 44, scope: !1042, inlinedAt: !1045)
!1083 = !{!1017, !1018, i64 208}
!1084 = !DILocation(line: 0, scope: !1042, inlinedAt: !1045)
!1085 = !DILocation(line: 379, column: 17, scope: !1086, inlinedAt: !1045)
!1086 = distinct !DILexicalBlock(scope: !1042, file: !2, line: 379, column: 13)
!1087 = !DILocation(line: 379, column: 29, scope: !1086, inlinedAt: !1045)
!1088 = !DILocation(line: 379, column: 22, scope: !1086, inlinedAt: !1045)
!1089 = !DILocation(line: 379, column: 13, scope: !1042, inlinedAt: !1045)
!1090 = !DILocation(line: 380, column: 22, scope: !1086, inlinedAt: !1045)
!1091 = !{!1018, !1018, i64 0}
!1092 = !DILocation(line: 382, column: 22, scope: !1042, inlinedAt: !1045)
!1093 = !DILocation(line: 380, column: 13, scope: !1086, inlinedAt: !1045)
!1094 = !DILocation(line: 382, column: 13, scope: !1042, inlinedAt: !1045)
!1095 = !DILocation(line: 382, column: 9, scope: !1042, inlinedAt: !1045)
!1096 = !DILocation(line: 382, column: 28, scope: !1042, inlinedAt: !1045)
!1097 = !DILocation(line: 383, column: 22, scope: !1042, inlinedAt: !1045)
!1098 = !DILocation(line: 383, column: 27, scope: !1042, inlinedAt: !1045)
!1099 = !DILocation(line: 383, column: 9, scope: !1042, inlinedAt: !1045)
!1100 = !DILocation(line: 383, column: 32, scope: !1042, inlinedAt: !1045)
!1101 = !DILocation(line: 384, column: 18, scope: !1042, inlinedAt: !1045)
!1102 = !DILocation(line: 387, column: 5, scope: !1034, inlinedAt: !1045)
!1103 = !DILocation(line: 387, column: 14, scope: !1034, inlinedAt: !1045)
!1104 = !{!1028, !1028, i64 0}
!1105 = distinct !DIAssignID()
!1106 = !DILocation(line: 388, column: 29, scope: !1034, inlinedAt: !1045)
!1107 = !{!1017, !1021, i64 8}
!1108 = !DILocation(line: 388, column: 8, scope: !1034, inlinedAt: !1045)
!1109 = !DILocation(line: 388, column: 16, scope: !1034, inlinedAt: !1045)
!1110 = !DILocation(line: 388, column: 24, scope: !1034, inlinedAt: !1045)
!1111 = !{!1112, !1021, i64 344}
!1112 = !{!"", !1028, i64 0, !1018, i64 8, !1113, i64 16, !1113, i64 152, !1019, i64 288, !1114, i64 328, !1021, i64 344, !1021, i64 348, !1115, i64 352, !1019, i64 6800, !1018, i64 6872, !1018, i64 6880, !1018, i64 6888, !1018, i64 6896, !1018, i64 6904, !1018, i64 6912, !1018, i64 6920, !1021, i64 6928}
!1113 = !{!"thread_notify", !1023, i64 0, !1021, i64 128}
!1114 = !{!"iop_head_s", !1018, i64 0, !1018, i64 8}
!1115 = !{!"thread_stats", !1019, i64 0, !1028, i64 40, !1028, i64 48, !1028, i64 56, !1028, i64 64, !1028, i64 72, !1028, i64 80, !1028, i64 88, !1028, i64 96, !1028, i64 104, !1028, i64 112, !1028, i64 120, !1028, i64 128, !1028, i64 136, !1028, i64 144, !1028, i64 152, !1028, i64 160, !1028, i64 168, !1028, i64 176, !1028, i64 184, !1028, i64 192, !1028, i64 200, !1028, i64 208, !1028, i64 216, !1028, i64 224, !1028, i64 232, !1028, i64 240, !1028, i64 248, !1028, i64 256, !1028, i64 264, !1028, i64 272, !1019, i64 280, !1019, i64 4376, !1028, i64 6424, !1028, i64 6432, !1028, i64 6440}
!1116 = !DILocation(line: 389, column: 29, scope: !1034, inlinedAt: !1045)
!1117 = !{!1017, !1026, i64 432}
!1118 = !DILocation(line: 389, column: 26, scope: !1034, inlinedAt: !1045)
!1119 = !DILocation(line: 389, column: 67, scope: !1034, inlinedAt: !1045)
!1120 = !{!1121, !1022, i64 104}
!1121 = !{!"settings", !1028, i64 0, !1021, i64 8, !1021, i64 12, !1021, i64 16, !1018, i64 24, !1021, i64 32, !1021, i64 36, !1021, i64 40, !1018, i64 48, !1018, i64 56, !1021, i64 64, !1122, i64 72, !1021, i64 80, !1021, i64 84, !1021, i64 88, !1019, i64 92, !1021, i64 96, !1021, i64 100, !1022, i64 104, !1021, i64 108, !1021, i64 112, !1021, i64 116, !1021, i64 120, !1021, i64 124, !1021, i64 128, !1022, i64 132, !1022, i64 133, !1022, i64 134, !1022, i64 135, !1022, i64 136, !1022, i64 137, !1021, i64 140, !1122, i64 144, !1021, i64 152, !1021, i64 156, !1022, i64 160, !1021, i64 164, !1022, i64 168, !1022, i64 169, !1018, i64 176, !1021, i64 184, !1021, i64 188, !1021, i64 192, !1021, i64 196, !1122, i64 200, !1122, i64 208, !1021, i64 216, !1022, i64 220, !1021, i64 224, !1021, i64 228, !1021, i64 232, !1021, i64 236, !1021, i64 240, !1022, i64 244, !1022, i64 245, !1022, i64 246, !1021, i64 248, !1021, i64 252, !1021, i64 256, !1021, i64 260, !1021, i64 264, !1021, i64 268, !1021, i64 272, !1021, i64 276, !1021, i64 280, !1021, i64 284, !1122, i64 288, !1122, i64 296, !1022, i64 304, !1021, i64 308, !1021, i64 312, !1018, i64 320, !1021, i64 328}
!1122 = !{!"double", !1019, i64 0}
!1123 = !{i8 0, i8 2}
!1124 = !{}
!1125 = !DILocation(line: 389, column: 57, scope: !1034, inlinedAt: !1045)
!1126 = !DILocation(line: 389, column: 78, scope: !1034, inlinedAt: !1045)
!1127 = !DILocation(line: 389, column: 11, scope: !1034, inlinedAt: !1045)
!1128 = !DILocation(line: 390, column: 14, scope: !1034, inlinedAt: !1045)
!1129 = !DILocation(line: 390, column: 8, scope: !1034, inlinedAt: !1045)
!1130 = !DILocation(line: 390, column: 12, scope: !1034, inlinedAt: !1045)
!1131 = !{!1017, !1028, i64 416}
!1132 = !DILocation(line: 417, column: 5, scope: !1034, inlinedAt: !1045)
!1133 = !DILocalVariable(name: "c", arg: 1, scope: !1134, file: !2, line: 247, type: !608)
!1134 = distinct !DISubprogram(name: "write_bin_response", scope: !2, file: !2, line: 247, type: !1135, scopeLine: 247, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !1137)
!1135 = !DISubroutineType(cc: DW_CC_nocall, types: !1136)
!1136 = !{null, !608, !365, !418, !418, !418}
!1137 = !{!1133, !1138, !1139, !1140, !1141, !1142}
!1138 = !DILocalVariable(name: "d", arg: 2, scope: !1134, file: !2, line: 247, type: !365)
!1139 = !DILocalVariable(name: "hlen", arg: 3, scope: !1134, file: !2, line: 247, type: !418)
!1140 = !DILocalVariable(name: "keylen", arg: 4, scope: !1134, file: !2, line: 247, type: !418)
!1141 = !DILocalVariable(name: "dlen", arg: 5, scope: !1134, file: !2, line: 247, type: !418)
!1142 = !DILocalVariable(name: "resp", scope: !1143, file: !2, line: 251, type: !710)
!1143 = distinct !DILexicalBlock(scope: !1144, file: !2, line: 249, column: 45)
!1144 = distinct !DILexicalBlock(scope: !1134, file: !2, line: 248, column: 9)
!1145 = !DILocation(line: 0, scope: !1134, inlinedAt: !1146)
!1146 = distinct !DILocation(line: 420, column: 9, scope: !1147, inlinedAt: !1045)
!1147 = distinct !DILexicalBlock(scope: !1034, file: !2, line: 417, column: 18)
!1148 = !DILocation(line: 248, column: 13, scope: !1144, inlinedAt: !1146)
!1149 = !{!1017, !1022, i64 364}
!1150 = !DILocation(line: 248, column: 21, scope: !1144, inlinedAt: !1146)
!1151 = !DILocation(line: 248, column: 27, scope: !1144, inlinedAt: !1146)
!1152 = !DILocation(line: 248, column: 58, scope: !1144, inlinedAt: !1146)
!1153 = !DILocation(line: 250, column: 9, scope: !1143, inlinedAt: !1146)
!1154 = !DILocation(line: 0, scope: !1143, inlinedAt: !1146)
!1155 = !DILocation(line: 257, column: 5, scope: !1134, inlinedAt: !1146)
!1156 = !DILocation(line: 421, column: 9, scope: !1147, inlinedAt: !1045)
!1157 = !DILocalVariable(name: "c", arg: 1, scope: !1158, file: !2, line: 179, type: !608)
!1158 = distinct !DISubprogram(name: "write_bin_error", scope: !2, file: !2, line: 179, type: !1159, scopeLine: 180, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !1163)
!1159 = !DISubroutineType(types: !1160)
!1160 = !{null, !608, !1038, !1161, !418}
!1161 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1162, size: 64)
!1162 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !4)
!1163 = !{!1157, !1164, !1165, !1166, !1167}
!1164 = !DILocalVariable(name: "err", arg: 2, scope: !1158, file: !2, line: 179, type: !1038)
!1165 = !DILocalVariable(name: "errstr", arg: 3, scope: !1158, file: !2, line: 180, type: !1161)
!1166 = !DILocalVariable(name: "swallow", arg: 4, scope: !1158, file: !2, line: 180, type: !418)
!1167 = !DILocalVariable(name: "len", scope: !1158, file: !2, line: 181, type: !868)
!1168 = !DILocation(line: 0, scope: !1158, inlinedAt: !1169)
!1169 = distinct !DILocation(line: 423, column: 9, scope: !1147, inlinedAt: !1045)
!1170 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !1169)
!1171 = distinct !DILexicalBlock(scope: !1158, file: !2, line: 219, column: 9)
!1172 = !{!1121, !1021, i64 32}
!1173 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !1169)
!1174 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !1169)
!1175 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !1169)
!1176 = distinct !DILexicalBlock(scope: !1171, file: !2, line: 219, column: 31)
!1177 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !1169)
!1178 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !1169)
!1179 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !1169)
!1180 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !1169)
!1181 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !1169)
!1182 = distinct !DILexicalBlock(scope: !1183, file: !2, line: 225, column: 18)
!1183 = distinct !DILexicalBlock(scope: !1158, file: !2, line: 225, column: 9)
!1184 = !{!1017, !1018, i64 192}
!1185 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !1169)
!1186 = !DILocation(line: 0, scope: !1187, inlinedAt: !1169)
!1187 = distinct !DILexicalBlock(scope: !1158, file: !2, line: 228, column: 9)
!1188 = !DILocation(line: 424, column: 9, scope: !1147, inlinedAt: !1045)
!1189 = !DILocation(line: 0, scope: !1158, inlinedAt: !1190)
!1190 = distinct !DILocation(line: 426, column: 9, scope: !1147, inlinedAt: !1045)
!1191 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !1190)
!1192 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !1190)
!1193 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !1190)
!1194 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !1190)
!1195 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !1190)
!1196 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !1190)
!1197 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !1190)
!1198 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !1190)
!1199 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !1190)
!1200 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !1190)
!1201 = !DILocation(line: 0, scope: !1187, inlinedAt: !1190)
!1202 = !DILocation(line: 427, column: 9, scope: !1147, inlinedAt: !1045)
!1203 = !DILocation(line: 431, column: 16, scope: !1204, inlinedAt: !1045)
!1204 = distinct !DILexicalBlock(scope: !1147, file: !2, line: 431, column: 13)
!1205 = !DILocation(line: 431, column: 13, scope: !1147, inlinedAt: !1045)
!1206 = !DILocation(line: 438, column: 9, scope: !1147, inlinedAt: !1045)
!1207 = !DILocation(line: 439, column: 5, scope: !1147, inlinedAt: !1045)
!1208 = !DILocation(line: 441, column: 20, scope: !1034, inlinedAt: !1045)
!1209 = !DILocation(line: 441, column: 5, scope: !1034, inlinedAt: !1045)
!1210 = !DILocation(line: 442, column: 13, scope: !1034, inlinedAt: !1045)
!1211 = !DILocation(line: 443, column: 1, scope: !1034, inlinedAt: !1045)
!1212 = !DILocation(line: 38, column: 9, scope: !1046)
!1213 = !DILocation(line: 40, column: 9, scope: !1046)
!1214 = !DILocation(line: 41, column: 16, scope: !1215)
!1215 = distinct !DILexicalBlock(scope: !1046, file: !2, line: 41, column: 13)
!1216 = !DILocation(line: 41, column: 13, scope: !1215)
!1217 = !DILocation(line: 41, column: 13, scope: !1046)
!1218 = !DILocation(line: 42, column: 13, scope: !1219)
!1219 = distinct !DILexicalBlock(scope: !1215, file: !2, line: 41, column: 22)
!1220 = !DILocation(line: 43, column: 21, scope: !1219)
!1221 = !DILocation(line: 44, column: 9, scope: !1219)
!1222 = !DILocation(line: 47, column: 17, scope: !1046)
!1223 = !DILocation(line: 47, column: 9, scope: !1046)
!1224 = !DILocation(line: 49, column: 5, scope: !1046)
!1225 = !DILocation(line: 50, column: 1, scope: !605)
!1226 = distinct !DISubprogram(name: "process_bin_complete_sasl_auth", scope: !2, file: !2, line: 771, type: !606, scopeLine: 771, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !1227)
!1227 = !{!1228, !1229, !1230, !1231, !1232, !1233, !1234, !1238, !1239}
!1228 = !DILocalVariable(name: "c", arg: 1, scope: !1226, file: !2, line: 771, type: !608)
!1229 = !DILocalVariable(name: "out", scope: !1226, file: !2, line: 773, type: !1161)
!1230 = !DILocalVariable(name: "outlen", scope: !1226, file: !2, line: 774, type: !206)
!1231 = !DILocalVariable(name: "nkey", scope: !1226, file: !2, line: 779, type: !383)
!1232 = !DILocalVariable(name: "vlen", scope: !1226, file: !2, line: 780, type: !418)
!1233 = !DILocalVariable(name: "__vla_expr0", scope: !1226, type: !394, flags: DIFlagArtificial)
!1234 = !DILocalVariable(name: "mech", scope: !1226, file: !2, line: 788, type: !1235)
!1235 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, elements: !1236)
!1236 = !{!1237}
!1237 = !DISubrange(count: !1233)
!1238 = !DILocalVariable(name: "challenge", scope: !1226, file: !2, line: 795, type: !1161)
!1239 = !DILocalVariable(name: "result", scope: !1226, file: !2, line: 803, type: !418)
!1240 = !DILocation(line: 0, scope: !1226)
!1241 = !DILocalVariable(name: "c", arg: 1, scope: !1242, file: !2, line: 677, type: !608)
!1242 = distinct !DISubprogram(name: "init_sasl_conn", scope: !2, file: !2, line: 677, type: !606, scopeLine: 677, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !1243)
!1243 = !{!1241, !1244}
!1244 = !DILocalVariable(name: "result", scope: !1245, file: !2, line: 686, type: !418)
!1245 = distinct !DILexicalBlock(scope: !1246, file: !2, line: 685, column: 24)
!1246 = distinct !DILexicalBlock(scope: !1242, file: !2, line: 685, column: 9)
!1247 = !DILocation(line: 0, scope: !1242, inlinedAt: !1248)
!1248 = distinct !DILocation(line: 777, column: 5, scope: !1226)
!1249 = !DILocation(line: 680, column: 19, scope: !1250, inlinedAt: !1248)
!1250 = distinct !DILexicalBlock(scope: !1242, file: !2, line: 680, column: 9)
!1251 = !{!1121, !1022, i64 132}
!1252 = !DILocation(line: 680, column: 9, scope: !1242, inlinedAt: !1248)
!1253 = !DILocation(line: 683, column: 8, scope: !1242, inlinedAt: !1248)
!1254 = !DILocation(line: 683, column: 22, scope: !1242, inlinedAt: !1248)
!1255 = !{!1017, !1022, i64 13}
!1256 = !DILocation(line: 685, column: 13, scope: !1246, inlinedAt: !1248)
!1257 = !{!1017, !1018, i64 0}
!1258 = !DILocation(line: 685, column: 10, scope: !1246, inlinedAt: !1248)
!1259 = !DILocation(line: 685, column: 9, scope: !1242, inlinedAt: !1248)
!1260 = !DILocation(line: 0, scope: !1245, inlinedAt: !1248)
!1261 = !DILocation(line: 692, column: 26, scope: !1262, inlinedAt: !1248)
!1262 = distinct !DILexicalBlock(scope: !1263, file: !2, line: 692, column: 17)
!1263 = distinct !DILexicalBlock(scope: !1264, file: !2, line: 691, column: 32)
!1264 = distinct !DILexicalBlock(scope: !1245, file: !2, line: 691, column: 13)
!1265 = !DILocation(line: 692, column: 17, scope: !1262, inlinedAt: !1248)
!1266 = !DILocation(line: 692, column: 17, scope: !1263, inlinedAt: !1248)
!1267 = !DILocation(line: 693, column: 25, scope: !1268, inlinedAt: !1248)
!1268 = distinct !DILexicalBlock(scope: !1262, file: !2, line: 692, column: 35)
!1269 = !DILocation(line: 693, column: 17, scope: !1268, inlinedAt: !1248)
!1270 = !DILocation(line: 694, column: 13, scope: !1268, inlinedAt: !1248)
!1271 = !DILocation(line: 695, column: 26, scope: !1263, inlinedAt: !1248)
!1272 = !DILocation(line: 697, column: 5, scope: !1245, inlinedAt: !1248)
!1273 = !DILocation(line: 779, column: 46, scope: !1226)
!1274 = !DILocation(line: 780, column: 41, scope: !1226)
!1275 = !DILocation(line: 780, column: 51, scope: !1226)
!1276 = !DILocation(line: 780, column: 49, scope: !1226)
!1277 = !DILocation(line: 782, column: 28, scope: !1278)
!1278 = distinct !DILexicalBlock(scope: !1226, file: !2, line: 782, column: 9)
!1279 = !DILocation(line: 782, column: 35, scope: !1278)
!1280 = !DILocation(line: 782, column: 14, scope: !1278)
!1281 = !DILocation(line: 782, column: 9, scope: !1226)
!1282 = !DILocation(line: 783, column: 9, scope: !1283)
!1283 = distinct !DILexicalBlock(scope: !1278, file: !2, line: 782, column: 41)
!1284 = !DILocation(line: 784, column: 9, scope: !1283)
!1285 = !DILocation(line: 785, column: 9, scope: !1283)
!1286 = !DILocation(line: 788, column: 19, scope: !1226)
!1287 = !DILocation(line: 788, column: 5, scope: !1226)
!1288 = !DILocation(line: 788, column: 10, scope: !1226)
!1289 = !DILocation(line: 789, column: 18, scope: !1226)
!1290 = !DILocation(line: 789, column: 44, scope: !1226)
!1291 = !DILocation(line: 789, column: 5, scope: !1226)
!1292 = !DILocation(line: 790, column: 5, scope: !1226)
!1293 = !DILocation(line: 790, column: 16, scope: !1226)
!1294 = !DILocation(line: 792, column: 18, scope: !1295)
!1295 = distinct !DILexicalBlock(scope: !1226, file: !2, line: 792, column: 9)
!1296 = !DILocation(line: 792, column: 9, scope: !1295)
!1297 = !DILocation(line: 792, column: 9, scope: !1226)
!1298 = !DILocation(line: 793, column: 17, scope: !1295)
!1299 = !DILocation(line: 793, column: 9, scope: !1295)
!1300 = !DILocation(line: 797, column: 28, scope: !1301)
!1301 = distinct !DILexicalBlock(scope: !1226, file: !2, line: 797, column: 9)
!1302 = !DILocation(line: 795, column: 34, scope: !1226)
!1303 = !DILocation(line: 795, column: 29, scope: !1226)
!1304 = !DILocation(line: 795, column: 48, scope: !1226)
!1305 = !DILocation(line: 797, column: 35, scope: !1301)
!1306 = !DILocation(line: 797, column: 14, scope: !1301)
!1307 = !DILocation(line: 797, column: 9, scope: !1226)
!1308 = !DILocation(line: 798, column: 9, scope: !1309)
!1309 = distinct !DILexicalBlock(scope: !1301, file: !2, line: 797, column: 43)
!1310 = !DILocation(line: 799, column: 9, scope: !1309)
!1311 = !DILocation(line: 800, column: 9, scope: !1309)
!1312 = !DILocation(line: 805, column: 16, scope: !1226)
!1313 = !DILocation(line: 805, column: 13, scope: !1226)
!1314 = !DILocation(line: 805, column: 5, scope: !1226)
!1315 = !DILocation(line: 810, column: 12, scope: !1316)
!1316 = distinct !DILexicalBlock(scope: !1226, file: !2, line: 805, column: 21)
!1317 = !DILocation(line: 810, column: 25, scope: !1316)
!1318 = !{!1017, !1022, i64 12}
!1319 = !DILocation(line: 811, column: 9, scope: !1316)
!1320 = !DILocation(line: 813, column: 17, scope: !1321)
!1321 = distinct !DILexicalBlock(scope: !1316, file: !2, line: 813, column: 13)
!1322 = !DILocation(line: 813, column: 13, scope: !1316)
!1323 = !DILocation(line: 814, column: 26, scope: !1324)
!1324 = distinct !DILexicalBlock(scope: !1325, file: !2, line: 814, column: 17)
!1325 = distinct !DILexicalBlock(scope: !1321, file: !2, line: 813, column: 31)
!1326 = !DILocation(line: 814, column: 17, scope: !1324)
!1327 = !DILocation(line: 814, column: 17, scope: !1325)
!1328 = !DILocation(line: 815, column: 25, scope: !1329)
!1329 = distinct !DILexicalBlock(scope: !1324, file: !2, line: 814, column: 35)
!1330 = !DILocation(line: 816, column: 65, scope: !1329)
!1331 = !DILocation(line: 815, column: 17, scope: !1329)
!1332 = !DILocation(line: 817, column: 13, scope: !1329)
!1333 = !DILocation(line: 828, column: 22, scope: !1334)
!1334 = distinct !DILexicalBlock(scope: !1316, file: !2, line: 828, column: 13)
!1335 = !DILocation(line: 828, column: 13, scope: !1334)
!1336 = !DILocation(line: 828, column: 13, scope: !1316)
!1337 = !DILocation(line: 829, column: 21, scope: !1338)
!1338 = distinct !DILexicalBlock(scope: !1334, file: !2, line: 828, column: 31)
!1339 = !DILocation(line: 829, column: 13, scope: !1338)
!1340 = !DILocation(line: 831, column: 9, scope: !1338)
!1341 = !DILocation(line: 835, column: 18, scope: !1342)
!1342 = distinct !DILexicalBlock(scope: !1226, file: !2, line: 835, column: 9)
!1343 = !DILocation(line: 835, column: 9, scope: !1342)
!1344 = !DILocation(line: 835, column: 9, scope: !1226)
!1345 = !DILocation(line: 836, column: 17, scope: !1346)
!1346 = distinct !DILexicalBlock(scope: !1342, file: !2, line: 835, column: 27)
!1347 = !DILocation(line: 836, column: 9, scope: !1346)
!1348 = !DILocation(line: 837, column: 5, scope: !1346)
!1349 = !DILocation(line: 839, column: 5, scope: !1226)
!1350 = !DILocation(line: 848, column: 9, scope: !1351)
!1351 = distinct !DILexicalBlock(scope: !1226, file: !2, line: 839, column: 20)
!1352 = !DILocation(line: 853, column: 9, scope: !1351)
!1353 = !DILocation(line: 854, column: 9, scope: !1351)
!1354 = !DILocation(line: 856, column: 22, scope: !1355)
!1355 = distinct !DILexicalBlock(scope: !1351, file: !2, line: 856, column: 13)
!1356 = !DILocation(line: 856, column: 13, scope: !1355)
!1357 = !DILocation(line: 856, column: 13, scope: !1351)
!1358 = !DILocation(line: 857, column: 21, scope: !1355)
!1359 = !DILocation(line: 857, column: 13, scope: !1355)
!1360 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !1361)
!1361 = distinct !DILocation(line: 858, column: 9, scope: !1351)
!1362 = !DILocation(line: 0, scope: !1158, inlinedAt: !1361)
!1363 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !1361)
!1364 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !1361)
!1365 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !1361)
!1366 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !1361)
!1367 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !1361)
!1368 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !1361)
!1369 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !1361)
!1370 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !1361)
!1371 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !1361)
!1372 = !DILocation(line: 0, scope: !1187, inlinedAt: !1361)
!1373 = !DILocation(line: 859, column: 32, scope: !1351)
!1374 = !DILocation(line: 859, column: 40, scope: !1351)
!1375 = !DILocation(line: 859, column: 9, scope: !1351)
!1376 = !DILocation(line: 860, column: 12, scope: !1351)
!1377 = !DILocation(line: 860, column: 26, scope: !1351)
!1378 = !DILocation(line: 860, column: 35, scope: !1351)
!1379 = !DILocation(line: 862, column: 42, scope: !1351)
!1380 = !DILocation(line: 862, column: 9, scope: !1351)
!1381 = !DILocation(line: 863, column: 5, scope: !1351)
!1382 = !DILocation(line: 864, column: 1, scope: !1226)
!1383 = !DISubprogram(name: "do_item_remove", scope: !1384, file: !1384, line: 23, type: !1385, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1384 = !DIFile(filename: "./items.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "5548db7354621bc680fd5812e10230ba")
!1385 = !DISubroutineType(types: !1386)
!1386 = !{null, !440}
!1387 = !DISubprogram(name: "fprintf", scope: !1388, file: !1388, line: 357, type: !1389, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1388 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "1e435c46987a169d9f9186f63a512303")
!1389 = !DISubroutineType(types: !1390)
!1390 = !{!418, !1391, !1442, null}
!1391 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1392)
!1392 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1393, size: 64)
!1393 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !1394, line: 7, baseType: !1395)
!1394 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!1395 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !1396, line: 49, size: 1728, elements: !1397)
!1396 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "7a6d4a00a37ee6b9a40cd04bd01f5d00")
!1397 = !{!1398, !1399, !1400, !1401, !1402, !1403, !1404, !1405, !1406, !1407, !1408, !1409, !1410, !1413, !1415, !1416, !1417, !1419, !1420, !1422, !1426, !1429, !1431, !1434, !1437, !1438, !1439, !1440, !1441}
!1398 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !1395, file: !1396, line: 51, baseType: !418, size: 32)
!1399 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !1395, file: !1396, line: 54, baseType: !399, size: 64, offset: 64)
!1400 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !1395, file: !1396, line: 55, baseType: !399, size: 64, offset: 128)
!1401 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !1395, file: !1396, line: 56, baseType: !399, size: 64, offset: 192)
!1402 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !1395, file: !1396, line: 57, baseType: !399, size: 64, offset: 256)
!1403 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !1395, file: !1396, line: 58, baseType: !399, size: 64, offset: 320)
!1404 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !1395, file: !1396, line: 59, baseType: !399, size: 64, offset: 384)
!1405 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !1395, file: !1396, line: 60, baseType: !399, size: 64, offset: 448)
!1406 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !1395, file: !1396, line: 61, baseType: !399, size: 64, offset: 512)
!1407 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !1395, file: !1396, line: 64, baseType: !399, size: 64, offset: 576)
!1408 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !1395, file: !1396, line: 65, baseType: !399, size: 64, offset: 640)
!1409 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !1395, file: !1396, line: 66, baseType: !399, size: 64, offset: 704)
!1410 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !1395, file: !1396, line: 68, baseType: !1411, size: 64, offset: 768)
!1411 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1412, size: 64)
!1412 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !1396, line: 36, flags: DIFlagFwdDecl)
!1413 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !1395, file: !1396, line: 70, baseType: !1414, size: 64, offset: 832)
!1414 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1395, size: 64)
!1415 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !1395, file: !1396, line: 72, baseType: !418, size: 32, offset: 896)
!1416 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !1395, file: !1396, line: 73, baseType: !418, size: 32, offset: 928)
!1417 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !1395, file: !1396, line: 74, baseType: !1418, size: 64, offset: 960)
!1418 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !367, line: 152, baseType: !476)
!1419 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !1395, file: !1396, line: 77, baseType: !368, size: 16, offset: 1024)
!1420 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !1395, file: !1396, line: 78, baseType: !1421, size: 8, offset: 1040)
!1421 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!1422 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !1395, file: !1396, line: 79, baseType: !1423, size: 8, offset: 1048)
!1423 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 8, elements: !1424)
!1424 = !{!1425}
!1425 = !DISubrange(count: 1)
!1426 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !1395, file: !1396, line: 81, baseType: !1427, size: 64, offset: 1088)
!1427 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1428, size: 64)
!1428 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !1396, line: 43, baseType: null)
!1429 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !1395, file: !1396, line: 89, baseType: !1430, size: 64, offset: 1152)
!1430 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !367, line: 153, baseType: !476)
!1431 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !1395, file: !1396, line: 91, baseType: !1432, size: 64, offset: 1216)
!1432 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1433, size: 64)
!1433 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !1396, line: 37, flags: DIFlagFwdDecl)
!1434 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !1395, file: !1396, line: 92, baseType: !1435, size: 64, offset: 1280)
!1435 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1436, size: 64)
!1436 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !1396, line: 38, flags: DIFlagFwdDecl)
!1437 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !1395, file: !1396, line: 93, baseType: !1414, size: 64, offset: 1344)
!1438 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !1395, file: !1396, line: 94, baseType: !365, size: 64, offset: 1408)
!1439 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !1395, file: !1396, line: 95, baseType: !868, size: 64, offset: 1472)
!1440 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !1395, file: !1396, line: 96, baseType: !418, size: 32, offset: 1536)
!1441 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !1395, file: !1396, line: 98, baseType: !21, size: 160, offset: 1568)
!1442 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1161)
!1443 = distinct !DISubprogram(name: "try_read_command_binary", scope: !2, file: !2, line: 52, type: !986, scopeLine: 52, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !1444)
!1444 = !{!1445, !1446, !1450, !1453, !1454, !1455}
!1445 = !DILocalVariable(name: "c", arg: 1, scope: !1443, file: !2, line: 52, type: !608)
!1446 = !DILocalVariable(name: "req", scope: !1447, file: !2, line: 59, type: !1449)
!1447 = distinct !DILexicalBlock(scope: !1448, file: !2, line: 57, column: 12)
!1448 = distinct !DILexicalBlock(scope: !1443, file: !2, line: 54, column: 9)
!1449 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !961, size: 64)
!1450 = !DILocalVariable(name: "ii", scope: !1451, file: !2, line: 64, type: !418)
!1451 = distinct !DILexicalBlock(scope: !1452, file: !2, line: 62, column: 35)
!1452 = distinct !DILexicalBlock(scope: !1447, file: !2, line: 62, column: 13)
!1453 = !DILocalVariable(name: "extlen", scope: !1447, file: !2, line: 89, type: !377)
!1454 = !DILocalVariable(name: "keylen", scope: !1447, file: !2, line: 90, type: !383)
!1455 = !DILocalVariable(name: "extbuf", scope: !1447, file: !2, line: 116, type: !1456)
!1456 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 384, elements: !1457)
!1457 = !{!1458}
!1458 = !DISubrange(count: 48)
!1459 = distinct !DIAssignID()
!1460 = !DILocation(line: 0, scope: !1447)
!1461 = !DILocation(line: 0, scope: !1443)
!1462 = !DILocation(line: 54, column: 12, scope: !1448)
!1463 = !{!1017, !1021, i64 188}
!1464 = !DILocation(line: 54, column: 19, scope: !1448)
!1465 = !DILocation(line: 54, column: 9, scope: !1443)
!1466 = !DILocation(line: 58, column: 20, scope: !1447)
!1467 = !DILocation(line: 58, column: 38, scope: !1447)
!1468 = !{!1017, !1018, i64 176}
!1469 = !DILocation(line: 58, column: 9, scope: !1447)
!1470 = !DILocation(line: 62, column: 22, scope: !1452)
!1471 = !DILocation(line: 62, column: 30, scope: !1452)
!1472 = !DILocation(line: 62, column: 13, scope: !1447)
!1473 = !DILocation(line: 65, column: 21, scope: !1451)
!1474 = !DILocation(line: 65, column: 66, scope: !1451)
!1475 = !DILocation(line: 65, column: 13, scope: !1451)
!1476 = !DILocation(line: 0, scope: !1451)
!1477 = !DILocation(line: 66, column: 13, scope: !1478)
!1478 = distinct !DILexicalBlock(scope: !1451, file: !2, line: 66, column: 13)
!1479 = !DILocation(line: 67, column: 28, scope: !1480)
!1480 = distinct !DILexicalBlock(scope: !1481, file: !2, line: 67, column: 21)
!1481 = distinct !DILexicalBlock(scope: !1482, file: !2, line: 66, column: 57)
!1482 = distinct !DILexicalBlock(scope: !1478, file: !2, line: 66, column: 13)
!1483 = !DILocation(line: 67, column: 21, scope: !1481)
!1484 = !DILocation(line: 68, column: 29, scope: !1485)
!1485 = distinct !DILexicalBlock(scope: !1480, file: !2, line: 67, column: 34)
!1486 = !DILocation(line: 68, column: 52, scope: !1485)
!1487 = !DILocation(line: 68, column: 21, scope: !1485)
!1488 = !DILocation(line: 69, column: 17, scope: !1485)
!1489 = !DILocation(line: 70, column: 25, scope: !1481)
!1490 = !DILocation(line: 70, column: 44, scope: !1481)
!1491 = !DILocation(line: 70, column: 17, scope: !1481)
!1492 = !DILocation(line: 66, column: 51, scope: !1482)
!1493 = !DILocation(line: 66, column: 29, scope: !1482)
!1494 = distinct !{!1494, !1477, !1495, !1496}
!1495 = !DILocation(line: 71, column: 13, scope: !1478)
!1496 = !{!"llvm.loop.mustprogress"}
!1497 = !DILocation(line: 72, column: 21, scope: !1451)
!1498 = !DILocation(line: 72, column: 13, scope: !1451)
!1499 = !DILocation(line: 73, column: 9, scope: !1451)
!1500 = !DILocation(line: 76, column: 43, scope: !1447)
!1501 = !DILocation(line: 76, column: 41, scope: !1447)
!1502 = !DILocation(line: 77, column: 44, scope: !1447)
!1503 = !DILocalVariable(name: "__bsx", arg: 1, scope: !1504, file: !1505, line: 49, type: !389)
!1504 = distinct !DISubprogram(name: "__bswap_32", scope: !1505, file: !1505, line: 49, type: !1506, scopeLine: 50, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !1508)
!1505 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/byteswap.h", directory: "", checksumkind: CSK_MD5, checksum: "913dc950710c6a0e67c840bea7ac0f08")
!1506 = !DISubroutineType(types: !1507)
!1507 = !{!389, !389}
!1508 = !{!1503}
!1509 = !DILocation(line: 0, scope: !1504, inlinedAt: !1510)
!1510 = distinct !DILocation(line: 77, column: 44, scope: !1447)
!1511 = !DILocation(line: 54, column: 10, scope: !1504, inlinedAt: !1510)
!1512 = !DILocation(line: 77, column: 42, scope: !1447)
!1513 = !DILocation(line: 78, column: 60, scope: !1447)
!1514 = !DILocation(line: 78, column: 40, scope: !1447)
!1515 = !DILocation(line: 78, column: 38, scope: !1447)
!1516 = !DILocation(line: 80, column: 38, scope: !1517)
!1517 = distinct !DILexicalBlock(scope: !1447, file: !2, line: 80, column: 13)
!1518 = !DILocation(line: 80, column: 13, scope: !1517)
!1519 = !DILocation(line: 80, column: 44, scope: !1517)
!1520 = !DILocation(line: 80, column: 13, scope: !1447)
!1521 = !DILocation(line: 81, column: 26, scope: !1522)
!1522 = distinct !DILexicalBlock(scope: !1523, file: !2, line: 81, column: 17)
!1523 = distinct !DILexicalBlock(scope: !1517, file: !2, line: 80, column: 68)
!1524 = !DILocation(line: 81, column: 17, scope: !1522)
!1525 = !DILocation(line: 81, column: 17, scope: !1523)
!1526 = !DILocation(line: 82, column: 25, scope: !1527)
!1527 = distinct !DILexicalBlock(scope: !1522, file: !2, line: 81, column: 35)
!1528 = !DILocation(line: 82, column: 17, scope: !1527)
!1529 = !DILocation(line: 84, column: 13, scope: !1527)
!1530 = !DILocation(line: 85, column: 13, scope: !1523)
!1531 = !DILocation(line: 86, column: 13, scope: !1523)
!1532 = !DILocation(line: 89, column: 51, scope: !1447)
!1533 = !DILocation(line: 90, column: 52, scope: !1447)
!1534 = !DILocation(line: 91, column: 16, scope: !1535)
!1535 = distinct !DILexicalBlock(scope: !1447, file: !2, line: 91, column: 13)
!1536 = !DILocation(line: 91, column: 25, scope: !1535)
!1537 = !DILocation(line: 91, column: 34, scope: !1535)
!1538 = !DILocation(line: 91, column: 32, scope: !1535)
!1539 = !DILocation(line: 91, column: 41, scope: !1535)
!1540 = !DILocation(line: 91, column: 23, scope: !1535)
!1541 = !DILocation(line: 91, column: 13, scope: !1447)
!1542 = !DILocation(line: 97, column: 14, scope: !1543)
!1543 = distinct !DILexicalBlock(scope: !1447, file: !2, line: 97, column: 13)
!1544 = !DILocation(line: 97, column: 13, scope: !1447)
!1545 = !DILocation(line: 98, column: 13, scope: !1546)
!1546 = distinct !DILexicalBlock(scope: !1543, file: !2, line: 97, column: 29)
!1547 = !DILocation(line: 99, column: 13, scope: !1546)
!1548 = !DILocation(line: 102, column: 43, scope: !1447)
!1549 = !DILocation(line: 102, column: 18, scope: !1447)
!1550 = !DILocation(line: 102, column: 12, scope: !1447)
!1551 = !DILocation(line: 102, column: 16, scope: !1447)
!1552 = !DILocation(line: 103, column: 46, scope: !1447)
!1553 = !DILocation(line: 103, column: 21, scope: !1447)
!1554 = !DILocation(line: 103, column: 12, scope: !1447)
!1555 = !DILocation(line: 103, column: 19, scope: !1447)
!1556 = !{!1017, !1021, i64 440}
!1557 = !DILocation(line: 104, column: 46, scope: !1447)
!1558 = !DILocation(line: 104, column: 12, scope: !1447)
!1559 = !DILocation(line: 104, column: 19, scope: !1447)
!1560 = !{!1017, !1021, i64 436}
!1561 = !DILocation(line: 106, column: 12, scope: !1447)
!1562 = !DILocation(line: 106, column: 16, scope: !1447)
!1563 = !DILocation(line: 108, column: 28, scope: !1447)
!1564 = !DILocation(line: 108, column: 12, scope: !1447)
!1565 = !DILocation(line: 108, column: 26, scope: !1447)
!1566 = !{!1017, !1021, i64 28}
!1567 = !DILocation(line: 116, column: 9, scope: !1447)
!1568 = !DILocation(line: 117, column: 23, scope: !1447)
!1569 = !DILocation(line: 117, column: 54, scope: !1447)
!1570 = !DILocation(line: 117, column: 60, scope: !1447)
!1571 = !DILocation(line: 118, column: 17, scope: !1447)
!1572 = !DILocation(line: 117, column: 9, scope: !1447)
!1573 = !DILocation(line: 119, column: 47, scope: !1447)
!1574 = !DILocation(line: 119, column: 58, scope: !1447)
!1575 = !DILocation(line: 119, column: 56, scope: !1447)
!1576 = !DILocation(line: 119, column: 19, scope: !1447)
!1577 = !DILocation(line: 120, column: 18, scope: !1447)
!1578 = !DILocalVariable(name: "c", arg: 1, scope: !1579, file: !2, line: 889, type: !608)
!1579 = distinct !DISubprogram(name: "dispatch_bin_command", scope: !2, file: !2, line: 889, type: !1580, scopeLine: 889, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !1582)
!1580 = !DISubroutineType(types: !1581)
!1581 = !{null, !608, !399}
!1582 = !{!1578, !1583, !1584, !1585, !1586, !1587}
!1583 = !DILocalVariable(name: "extbuf", arg: 2, scope: !1579, file: !2, line: 889, type: !399)
!1584 = !DILocalVariable(name: "protocol_error", scope: !1579, file: !2, line: 890, type: !418)
!1585 = !DILocalVariable(name: "extlen", scope: !1579, file: !2, line: 892, type: !377)
!1586 = !DILocalVariable(name: "keylen", scope: !1579, file: !2, line: 893, type: !383)
!1587 = !DILocalVariable(name: "bodylen", scope: !1579, file: !2, line: 894, type: !388)
!1588 = !DILocation(line: 0, scope: !1579, inlinedAt: !1589)
!1589 = distinct !DILocation(line: 122, column: 9, scope: !1447)
!1590 = !DILocation(line: 892, column: 47, scope: !1579, inlinedAt: !1589)
!1591 = !DILocation(line: 894, column: 49, scope: !1579, inlinedAt: !1589)
!1592 = !DILocation(line: 895, column: 29, scope: !1579, inlinedAt: !1589)
!1593 = !DILocation(line: 895, column: 8, scope: !1579, inlinedAt: !1589)
!1594 = !DILocation(line: 895, column: 16, scope: !1579, inlinedAt: !1589)
!1595 = !DILocation(line: 895, column: 24, scope: !1579, inlinedAt: !1589)
!1596 = !DILocation(line: 897, column: 16, scope: !1597, inlinedAt: !1589)
!1597 = distinct !DILexicalBlock(scope: !1579, file: !2, line: 897, column: 9)
!1598 = !DILocation(line: 897, column: 26, scope: !1597, inlinedAt: !1589)
!1599 = !DILocation(line: 897, column: 38, scope: !1597, inlinedAt: !1589)
!1600 = !DILocation(line: 897, column: 36, scope: !1597, inlinedAt: !1589)
!1601 = !DILocation(line: 897, column: 45, scope: !1597, inlinedAt: !1589)
!1602 = !DILocation(line: 897, column: 9, scope: !1579, inlinedAt: !1589)
!1603 = !DILocation(line: 0, scope: !1158, inlinedAt: !1604)
!1604 = distinct !DILocation(line: 898, column: 9, scope: !1605, inlinedAt: !1589)
!1605 = distinct !DILexicalBlock(scope: !1597, file: !2, line: 897, column: 56)
!1606 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !1604)
!1607 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !1604)
!1608 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !1604)
!1609 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !1604)
!1610 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !1604)
!1611 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !1604)
!1612 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !1604)
!1613 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !1604)
!1614 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !1604)
!1615 = !DILocation(line: 0, scope: !1187, inlinedAt: !1604)
!1616 = !DILocation(line: 899, column: 12, scope: !1605, inlinedAt: !1589)
!1617 = !DILocation(line: 899, column: 30, scope: !1605, inlinedAt: !1589)
!1618 = !{!1017, !1022, i64 16}
!1619 = !DILocation(line: 900, column: 9, scope: !1605, inlinedAt: !1589)
!1620 = !DILocation(line: 903, column: 18, scope: !1621, inlinedAt: !1589)
!1621 = distinct !DILexicalBlock(scope: !1579, file: !2, line: 903, column: 9)
!1622 = !DILocation(line: 903, column: 23, scope: !1621, inlinedAt: !1589)
!1623 = !DILocalVariable(name: "c", arg: 1, scope: !1624, file: !2, line: 866, type: !608)
!1624 = distinct !DISubprogram(name: "authenticated", scope: !2, file: !2, line: 866, type: !1625, scopeLine: 866, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !1627)
!1625 = !DISubroutineType(types: !1626)
!1626 = !{!618, !608}
!1627 = !{!1623, !1628}
!1628 = !DILocalVariable(name: "rv", scope: !1624, file: !2, line: 868, type: !618)
!1629 = !DILocation(line: 0, scope: !1624, inlinedAt: !1630)
!1630 = distinct !DILocation(line: 903, column: 27, scope: !1621, inlinedAt: !1589)
!1631 = !DILocation(line: 870, column: 5, scope: !1624, inlinedAt: !1630)
!1632 = !DILocation(line: 878, column: 17, scope: !1633, inlinedAt: !1630)
!1633 = distinct !DILexicalBlock(scope: !1624, file: !2, line: 870, column: 21)
!1634 = !DILocation(line: 883, column: 25, scope: !1635, inlinedAt: !1630)
!1635 = distinct !DILexicalBlock(scope: !1636, file: !2, line: 881, column: 31)
!1636 = distinct !DILexicalBlock(scope: !1624, file: !2, line: 881, column: 9)
!1637 = !DILocation(line: 879, column: 5, scope: !1633, inlinedAt: !1630)
!1638 = !DILocation(line: 0, scope: !1633, inlinedAt: !1630)
!1639 = !DILocation(line: 881, column: 18, scope: !1636, inlinedAt: !1630)
!1640 = !DILocation(line: 881, column: 26, scope: !1636, inlinedAt: !1630)
!1641 = !DILocation(line: 881, column: 9, scope: !1624, inlinedAt: !1630)
!1642 = !DILocation(line: 882, column: 17, scope: !1635, inlinedAt: !1630)
!1643 = !DILocation(line: 883, column: 17, scope: !1635, inlinedAt: !1630)
!1644 = !DILocation(line: 882, column: 9, scope: !1635, inlinedAt: !1630)
!1645 = !DILocation(line: 884, column: 5, scope: !1635, inlinedAt: !1630)
!1646 = !DILocation(line: 903, column: 9, scope: !1579, inlinedAt: !1589)
!1647 = !DILocation(line: 0, scope: !1158, inlinedAt: !1648)
!1648 = distinct !DILocation(line: 904, column: 9, scope: !1649, inlinedAt: !1589)
!1649 = distinct !DILexicalBlock(scope: !1621, file: !2, line: 903, column: 45)
!1650 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !1648)
!1651 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !1648)
!1652 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !1648)
!1653 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !1648)
!1654 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !1648)
!1655 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !1648)
!1656 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !1648)
!1657 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !1648)
!1658 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !1648)
!1659 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !1648)
!1660 = !DILocation(line: 0, scope: !1187, inlinedAt: !1648)
!1661 = !DILocation(line: 905, column: 12, scope: !1649, inlinedAt: !1589)
!1662 = !DILocation(line: 905, column: 30, scope: !1649, inlinedAt: !1589)
!1663 = !DILocation(line: 906, column: 9, scope: !1649, inlinedAt: !1589)
!1664 = !DILocation(line: 910, column: 8, scope: !1579, inlinedAt: !1589)
!1665 = !DILocation(line: 910, column: 16, scope: !1579, inlinedAt: !1589)
!1666 = !DILocation(line: 913, column: 16, scope: !1667, inlinedAt: !1589)
!1667 = distinct !DILexicalBlock(scope: !1579, file: !2, line: 913, column: 9)
!1668 = !DILocation(line: 913, column: 9, scope: !1579, inlinedAt: !1589)
!1669 = !DILocation(line: 914, column: 9, scope: !1670, inlinedAt: !1589)
!1670 = distinct !DILexicalBlock(scope: !1667, file: !2, line: 913, column: 34)
!1671 = !DILocation(line: 915, column: 9, scope: !1670, inlinedAt: !1589)
!1672 = !DILocation(line: 918, column: 16, scope: !1579, inlinedAt: !1589)
!1673 = !DILocation(line: 918, column: 5, scope: !1579, inlinedAt: !1589)
!1674 = !DILocation(line: 924, column: 9, scope: !1675, inlinedAt: !1589)
!1675 = distinct !DILexicalBlock(scope: !1579, file: !2, line: 918, column: 21)
!1676 = !DILocation(line: 927, column: 9, scope: !1675, inlinedAt: !1589)
!1677 = !DILocation(line: 929, column: 16, scope: !1675, inlinedAt: !1589)
!1678 = !DILocation(line: 965, column: 5, scope: !1579, inlinedAt: !1589)
!1679 = !DILocation(line: 936, column: 9, scope: !1675, inlinedAt: !1589)
!1680 = !DILocation(line: 938, column: 16, scope: !1675, inlinedAt: !1589)
!1681 = !DILocation(line: 941, column: 16, scope: !1675, inlinedAt: !1589)
!1682 = !DILocation(line: 948, column: 9, scope: !1675, inlinedAt: !1589)
!1683 = !DILocation(line: 954, column: 9, scope: !1675, inlinedAt: !1589)
!1684 = !DILocation(line: 960, column: 9, scope: !1675, inlinedAt: !1589)
!1685 = !DILocation(line: 962, column: 20, scope: !1675, inlinedAt: !1589)
!1686 = !DILocation(line: 967, column: 24, scope: !1687, inlinedAt: !1589)
!1687 = distinct !DILexicalBlock(scope: !1688, file: !2, line: 967, column: 17)
!1688 = distinct !DILexicalBlock(scope: !1579, file: !2, line: 965, column: 21)
!1689 = !DILocation(line: 967, column: 29, scope: !1687, inlinedAt: !1589)
!1690 = !DILocation(line: 968, column: 17, scope: !1691, inlinedAt: !1589)
!1691 = distinct !DILexicalBlock(scope: !1687, file: !2, line: 967, column: 61)
!1692 = !DILocation(line: 969, column: 13, scope: !1691, inlinedAt: !1589)
!1693 = !DILocation(line: 974, column: 29, scope: !1694, inlinedAt: !1589)
!1694 = distinct !DILexicalBlock(scope: !1688, file: !2, line: 974, column: 17)
!1695 = !DILocation(line: 974, column: 66, scope: !1694, inlinedAt: !1589)
!1696 = !DILocation(line: 975, column: 17, scope: !1697, inlinedAt: !1589)
!1697 = distinct !DILexicalBlock(scope: !1694, file: !2, line: 974, column: 83)
!1698 = !DILocation(line: 976, column: 13, scope: !1697, inlinedAt: !1589)
!1699 = !DILocation(line: 981, column: 24, scope: !1700, inlinedAt: !1589)
!1700 = distinct !DILexicalBlock(scope: !1688, file: !2, line: 981, column: 17)
!1701 = !DILocation(line: 981, column: 29, scope: !1700, inlinedAt: !1589)
!1702 = !DILocation(line: 982, column: 17, scope: !1703, inlinedAt: !1589)
!1703 = distinct !DILexicalBlock(scope: !1700, file: !2, line: 981, column: 61)
!1704 = !DILocation(line: 984, column: 17, scope: !1703, inlinedAt: !1589)
!1705 = !DILocation(line: 985, column: 13, scope: !1703, inlinedAt: !1589)
!1706 = !DILocation(line: 0, scope: !1675, inlinedAt: !1589)
!1707 = !DILocation(line: 992, column: 24, scope: !1708, inlinedAt: !1589)
!1708 = distinct !DILexicalBlock(scope: !1688, file: !2, line: 992, column: 17)
!1709 = !DILocation(line: 992, column: 29, scope: !1708, inlinedAt: !1589)
!1710 = !DILocation(line: 993, column: 17, scope: !1711, inlinedAt: !1589)
!1711 = distinct !DILexicalBlock(scope: !1708, file: !2, line: 992, column: 72)
!1712 = !DILocation(line: 994, column: 13, scope: !1711, inlinedAt: !1589)
!1713 = !DILocation(line: 1002, column: 29, scope: !1714, inlinedAt: !1589)
!1714 = distinct !DILexicalBlock(scope: !1688, file: !2, line: 1002, column: 17)
!1715 = !DILocation(line: 1003, column: 17, scope: !1716, inlinedAt: !1589)
!1716 = distinct !DILexicalBlock(scope: !1714, file: !2, line: 1002, column: 65)
!1717 = !DILocation(line: 1004, column: 13, scope: !1716, inlinedAt: !1589)
!1718 = !DILocation(line: 1009, column: 24, scope: !1719, inlinedAt: !1589)
!1719 = distinct !DILexicalBlock(scope: !1688, file: !2, line: 1009, column: 17)
!1720 = !DILocation(line: 1009, column: 28, scope: !1719, inlinedAt: !1589)
!1721 = !DILocation(line: 1010, column: 17, scope: !1722, inlinedAt: !1589)
!1722 = distinct !DILexicalBlock(scope: !1719, file: !2, line: 1009, column: 65)
!1723 = !DILocation(line: 1011, column: 13, scope: !1722, inlinedAt: !1589)
!1724 = !DILocation(line: 1017, column: 24, scope: !1725, inlinedAt: !1589)
!1725 = distinct !DILexicalBlock(scope: !1688, file: !2, line: 1017, column: 17)
!1726 = !DILocation(line: 1017, column: 28, scope: !1725, inlinedAt: !1589)
!1727 = !DILocation(line: 1018, column: 17, scope: !1728, inlinedAt: !1589)
!1728 = distinct !DILexicalBlock(scope: !1725, file: !2, line: 1017, column: 77)
!1729 = !DILocation(line: 1019, column: 13, scope: !1728, inlinedAt: !1589)
!1730 = !DILocation(line: 1025, column: 24, scope: !1731, inlinedAt: !1589)
!1731 = distinct !DILexicalBlock(scope: !1688, file: !2, line: 1025, column: 17)
!1732 = !DILocation(line: 1025, column: 28, scope: !1731, inlinedAt: !1589)
!1733 = !DILocation(line: 1026, column: 17, scope: !1734, inlinedAt: !1589)
!1734 = distinct !DILexicalBlock(scope: !1731, file: !2, line: 1025, column: 44)
!1735 = !DILocation(line: 1027, column: 13, scope: !1734, inlinedAt: !1589)
!1736 = !DILocation(line: 1032, column: 24, scope: !1737, inlinedAt: !1589)
!1737 = distinct !DILexicalBlock(scope: !1688, file: !2, line: 1032, column: 17)
!1738 = !DILocation(line: 1032, column: 17, scope: !1688, inlinedAt: !1589)
!1739 = !DILocation(line: 1033, column: 17, scope: !1740, inlinedAt: !1589)
!1740 = distinct !DILexicalBlock(scope: !1737, file: !2, line: 1032, column: 30)
!1741 = !DILocation(line: 1034, column: 13, scope: !1740, inlinedAt: !1589)
!1742 = !DILocation(line: 1039, column: 24, scope: !1743, inlinedAt: !1589)
!1743 = distinct !DILexicalBlock(scope: !1688, file: !2, line: 1039, column: 17)
!1744 = !DILocation(line: 1039, column: 29, scope: !1743, inlinedAt: !1589)
!1745 = !DILocation(line: 1040, column: 17, scope: !1746, inlinedAt: !1589)
!1746 = distinct !DILexicalBlock(scope: !1743, file: !2, line: 1039, column: 61)
!1747 = !DILocation(line: 1041, column: 17, scope: !1746, inlinedAt: !1589)
!1748 = !DILocation(line: 1042, column: 20, scope: !1746, inlinedAt: !1589)
!1749 = !DILocation(line: 1042, column: 38, scope: !1746, inlinedAt: !1589)
!1750 = !DILocation(line: 1043, column: 20, scope: !1746, inlinedAt: !1589)
!1751 = !DILocation(line: 1043, column: 33, scope: !1746, inlinedAt: !1589)
!1752 = !{!1017, !1021, i64 324}
!1753 = !DILocation(line: 1044, column: 13, scope: !1746, inlinedAt: !1589)
!1754 = !DILocation(line: 1049, column: 24, scope: !1755, inlinedAt: !1589)
!1755 = distinct !DILexicalBlock(scope: !1688, file: !2, line: 1049, column: 17)
!1756 = !DILocation(line: 1049, column: 29, scope: !1755, inlinedAt: !1589)
!1757 = !DILocation(line: 1050, column: 17, scope: !1758, inlinedAt: !1589)
!1758 = distinct !DILexicalBlock(scope: !1755, file: !2, line: 1049, column: 61)
!1759 = !DILocation(line: 1051, column: 13, scope: !1758, inlinedAt: !1589)
!1760 = !DILocation(line: 1057, column: 24, scope: !1761, inlinedAt: !1589)
!1761 = distinct !DILexicalBlock(scope: !1688, file: !2, line: 1057, column: 17)
!1762 = !DILocation(line: 1057, column: 29, scope: !1761, inlinedAt: !1589)
!1763 = !DILocation(line: 1058, column: 17, scope: !1764, inlinedAt: !1589)
!1764 = distinct !DILexicalBlock(scope: !1761, file: !2, line: 1057, column: 45)
!1765 = !DILocation(line: 1059, column: 13, scope: !1764, inlinedAt: !1589)
!1766 = !DILocation(line: 1068, column: 24, scope: !1767, inlinedAt: !1589)
!1767 = distinct !DILexicalBlock(scope: !1688, file: !2, line: 1068, column: 17)
!1768 = !DILocation(line: 1068, column: 29, scope: !1767, inlinedAt: !1589)
!1769 = !DILocation(line: 1069, column: 17, scope: !1770, inlinedAt: !1589)
!1770 = distinct !DILexicalBlock(scope: !1767, file: !2, line: 1068, column: 45)
!1771 = !DILocation(line: 1070, column: 13, scope: !1770, inlinedAt: !1589)
!1772 = !DILocation(line: 1075, column: 13, scope: !1688, inlinedAt: !1589)
!1773 = !DILocation(line: 1077, column: 5, scope: !1688, inlinedAt: !1589)
!1774 = !DILocation(line: 1080, column: 9, scope: !1775, inlinedAt: !1589)
!1775 = distinct !DILexicalBlock(scope: !1579, file: !2, line: 1079, column: 9)
!1776 = !DILocation(line: 123, column: 5, scope: !1448)
!1777 = !DILocation(line: 126, column: 1, scope: !1443)
!1778 = !DISubprogram(name: "ntohll", scope: !1779, file: !1779, line: 27, type: !1780, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1779 = !DIFile(filename: "./util.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d1ef68c688867746f50aae7567be079a")
!1780 = !DISubroutineType(types: !1781)
!1781 = !{!392, !392}
!1782 = !DISubprogram(name: "conn_set_state", scope: !205, file: !205, line: 1064, type: !1783, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1783 = !DISubroutineType(types: !1784)
!1784 = !{null, !608, !204}
!1785 = !DISubprogram(name: "resp_start", scope: !205, file: !205, line: 1057, type: !1625, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1786 = !DILocation(line: 0, scope: !1158)
!1787 = !DILocation(line: 183, column: 10, scope: !1788)
!1788 = distinct !DILexicalBlock(scope: !1158, file: !2, line: 183, column: 9)
!1789 = !DILocation(line: 183, column: 9, scope: !1158)
!1790 = !DILocation(line: 184, column: 9, scope: !1791)
!1791 = distinct !DILexicalBlock(scope: !1788, file: !2, line: 183, column: 18)
!1792 = !DILocation(line: 190, column: 13, scope: !1793)
!1793 = distinct !DILexicalBlock(scope: !1791, file: !2, line: 184, column: 22)
!1794 = !DILocation(line: 193, column: 13, scope: !1793)
!1795 = !DILocation(line: 196, column: 13, scope: !1793)
!1796 = !DILocation(line: 199, column: 13, scope: !1793)
!1797 = !DILocation(line: 202, column: 13, scope: !1793)
!1798 = !DILocation(line: 205, column: 13, scope: !1793)
!1799 = !DILocation(line: 208, column: 13, scope: !1793)
!1800 = !DILocation(line: 211, column: 13, scope: !1793)
!1801 = !DILocation(line: 215, column: 21, scope: !1793)
!1802 = !DILocation(line: 215, column: 61, scope: !1793)
!1803 = !DILocation(line: 215, column: 13, scope: !1793)
!1804 = !DILocation(line: 216, column: 9, scope: !1793)
!1805 = !DILocation(line: 219, column: 18, scope: !1171)
!1806 = !DILocation(line: 219, column: 26, scope: !1171)
!1807 = !DILocation(line: 219, column: 9, scope: !1158)
!1808 = !DILocation(line: 220, column: 17, scope: !1176)
!1809 = !DILocation(line: 220, column: 58, scope: !1176)
!1810 = !DILocation(line: 220, column: 9, scope: !1176)
!1811 = !DILocation(line: 221, column: 5, scope: !1176)
!1812 = !DILocation(line: 223, column: 11, scope: !1158)
!1813 = !DILocation(line: 224, column: 23, scope: !1158)
!1814 = !DILocation(line: 224, column: 34, scope: !1158)
!1815 = !DILocation(line: 224, column: 5, scope: !1158)
!1816 = !DILocation(line: 225, column: 13, scope: !1183)
!1817 = !DILocation(line: 225, column: 9, scope: !1158)
!1818 = !DILocation(line: 226, column: 25, scope: !1182)
!1819 = !DILocation(line: 226, column: 9, scope: !1182)
!1820 = !DILocation(line: 227, column: 5, scope: !1182)
!1821 = !DILocation(line: 228, column: 17, scope: !1187)
!1822 = !DILocation(line: 228, column: 9, scope: !1158)
!1823 = !DILocation(line: 229, column: 12, scope: !1824)
!1824 = distinct !DILexicalBlock(scope: !1187, file: !2, line: 228, column: 22)
!1825 = !DILocation(line: 229, column: 19, scope: !1824)
!1826 = !{!1017, !1021, i64 232}
!1827 = !DILocation(line: 231, column: 5, scope: !1824)
!1828 = !DILocation(line: 0, scope: !1187)
!1829 = !DILocation(line: 234, column: 1, scope: !1158)
!1830 = !DISubprogram(name: "strlen", scope: !1831, file: !1831, line: 407, type: !1832, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1831 = !DIFile(filename: "/usr/include/string.h", directory: "", checksumkind: CSK_MD5, checksum: "165db1185644f68894fa9e0d17055d70")
!1832 = !DISubroutineType(types: !1833)
!1833 = !{!394, !1161}
!1834 = distinct !DISubprogram(name: "add_bin_header", scope: !2, file: !2, line: 135, type: !1835, scopeLine: 135, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !1837)
!1835 = !DISubroutineType(types: !1836)
!1836 = !{null, !608, !383, !377, !383, !388}
!1837 = !{!1838, !1839, !1840, !1841, !1842, !1843, !1844, !1845}
!1838 = !DILocalVariable(name: "c", arg: 1, scope: !1834, file: !2, line: 135, type: !608)
!1839 = !DILocalVariable(name: "err", arg: 2, scope: !1834, file: !2, line: 135, type: !383)
!1840 = !DILocalVariable(name: "hdr_len", arg: 3, scope: !1834, file: !2, line: 135, type: !377)
!1841 = !DILocalVariable(name: "key_len", arg: 4, scope: !1834, file: !2, line: 135, type: !383)
!1842 = !DILocalVariable(name: "body_len", arg: 5, scope: !1834, file: !2, line: 135, type: !388)
!1843 = !DILocalVariable(name: "header", scope: !1834, file: !2, line: 136, type: !369)
!1844 = !DILocalVariable(name: "resp", scope: !1834, file: !2, line: 137, type: !710)
!1845 = !DILocalVariable(name: "ii", scope: !1846, file: !2, line: 158, type: !418)
!1846 = distinct !DILexicalBlock(scope: !1847, file: !2, line: 157, column: 31)
!1847 = distinct !DILexicalBlock(scope: !1834, file: !2, line: 157, column: 9)
!1848 = !DILocation(line: 0, scope: !1834)
!1849 = !DILocation(line: 137, column: 24, scope: !1834)
!1850 = !DILocation(line: 141, column: 5, scope: !1834)
!1851 = !DILocation(line: 143, column: 55, scope: !1834)
!1852 = !DILocation(line: 145, column: 28, scope: !1834)
!1853 = !DILocation(line: 146, column: 56, scope: !1834)
!1854 = !DILocation(line: 146, column: 22, scope: !1834)
!1855 = !DILocation(line: 146, column: 29, scope: !1834)
!1856 = !DILocation(line: 147, column: 22, scope: !1834)
!1857 = !DILocation(line: 147, column: 29, scope: !1834)
!1858 = !DILocation(line: 149, column: 22, scope: !1834)
!1859 = !DILocation(line: 149, column: 29, scope: !1834)
!1860 = !DILocation(line: 150, column: 22, scope: !1834)
!1861 = !DILocation(line: 150, column: 31, scope: !1834)
!1862 = !DILocation(line: 151, column: 22, scope: !1834)
!1863 = !DILocation(line: 151, column: 29, scope: !1834)
!1864 = !DILocation(line: 0, scope: !1504, inlinedAt: !1865)
!1865 = distinct !DILocation(line: 153, column: 32, scope: !1834)
!1866 = !DILocation(line: 54, column: 10, scope: !1504, inlinedAt: !1865)
!1867 = !DILocation(line: 153, column: 22, scope: !1834)
!1868 = !DILocation(line: 153, column: 30, scope: !1834)
!1869 = !DILocation(line: 154, column: 34, scope: !1834)
!1870 = !DILocation(line: 154, column: 22, scope: !1834)
!1871 = !DILocation(line: 154, column: 29, scope: !1834)
!1872 = !DILocation(line: 155, column: 38, scope: !1834)
!1873 = !DILocation(line: 155, column: 28, scope: !1834)
!1874 = !DILocation(line: 155, column: 22, scope: !1834)
!1875 = !DILocation(line: 155, column: 26, scope: !1834)
!1876 = !DILocation(line: 157, column: 18, scope: !1847)
!1877 = !DILocation(line: 157, column: 26, scope: !1847)
!1878 = !DILocation(line: 157, column: 9, scope: !1834)
!1879 = !DILocation(line: 159, column: 17, scope: !1846)
!1880 = !DILocation(line: 159, column: 57, scope: !1846)
!1881 = !DILocation(line: 159, column: 9, scope: !1846)
!1882 = !DILocation(line: 0, scope: !1846)
!1883 = !DILocation(line: 160, column: 9, scope: !1884)
!1884 = distinct !DILexicalBlock(scope: !1846, file: !2, line: 160, column: 9)
!1885 = !DILocation(line: 161, column: 24, scope: !1886)
!1886 = distinct !DILexicalBlock(scope: !1887, file: !2, line: 161, column: 17)
!1887 = distinct !DILexicalBlock(scope: !1888, file: !2, line: 160, column: 56)
!1888 = distinct !DILexicalBlock(scope: !1884, file: !2, line: 160, column: 9)
!1889 = !DILocation(line: 161, column: 17, scope: !1887)
!1890 = !DILocation(line: 162, column: 25, scope: !1891)
!1891 = distinct !DILexicalBlock(scope: !1886, file: !2, line: 161, column: 30)
!1892 = !DILocation(line: 162, column: 47, scope: !1891)
!1893 = !DILocation(line: 162, column: 17, scope: !1891)
!1894 = !DILocation(line: 163, column: 13, scope: !1891)
!1895 = !DILocation(line: 164, column: 21, scope: !1887)
!1896 = !DILocation(line: 164, column: 40, scope: !1887)
!1897 = !DILocation(line: 164, column: 13, scope: !1887)
!1898 = !DILocation(line: 160, column: 50, scope: !1888)
!1899 = !DILocation(line: 160, column: 25, scope: !1888)
!1900 = distinct !{!1900, !1883, !1901, !1496}
!1901 = !DILocation(line: 165, column: 9, scope: !1884)
!1902 = !DILocation(line: 166, column: 17, scope: !1846)
!1903 = !DILocation(line: 166, column: 9, scope: !1846)
!1904 = !DILocation(line: 167, column: 5, scope: !1846)
!1905 = !DILocation(line: 169, column: 11, scope: !1834)
!1906 = !DILocation(line: 169, column: 18, scope: !1834)
!1907 = !{!1908, !1021, i64 16}
!1908 = !{!"_mc_resp", !1018, i64 0, !1018, i64 8, !1021, i64 16, !1021, i64 20, !1018, i64 24, !1018, i64 32, !1018, i64 40, !1019, i64 48, !1021, i64 112, !1019, i64 116, !1019, i64 117, !1022, i64 118, !1022, i64 119, !1026, i64 120, !1026, i64 122, !1026, i64 124, !1029, i64 128, !1021, i64 156, !1019, i64 160}
!1909 = !DILocation(line: 170, column: 5, scope: !1834)
!1910 = !DILocation(line: 171, column: 1, scope: !1834)
!1911 = !DISubprogram(name: "resp_add_iov", scope: !205, file: !205, line: 1055, type: !1912, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1912 = !DISubroutineType(types: !1913)
!1913 = !{null, !710, !531, !418}
!1914 = !DISubprogram(name: "resp_reset", scope: !205, file: !205, line: 1054, type: !1915, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1915 = !DISubroutineType(types: !1916)
!1916 = !{null, !710}
!1917 = !DISubprogram(name: "htonll", scope: !1779, file: !1779, line: 26, type: !1780, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1918 = !DISubprogram(name: "pthread_mutex_lock", scope: !1919, file: !1919, line: 794, type: !1920, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1919 = !DIFile(filename: "/usr/include/pthread.h", directory: "", checksumkind: CSK_MD5, checksum: "cbcd748b3d3ecaa7356dc2925b45d819")
!1920 = !DISubroutineType(types: !1921)
!1921 = !{!418, !1922}
!1922 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !450, size: 64)
!1923 = !DISubprogram(name: "pthread_mutex_unlock", scope: !1919, file: !1919, line: 835, type: !1920, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1924 = !DISubprogram(name: "store_item", scope: !205, file: !205, line: 1040, type: !1925, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1925 = !DISubroutineType(types: !1926)
!1926 = !{!294, !440, !418, !722, !1927, !1928, !1929, !618}
!1927 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !418, size: 64)
!1928 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !392, size: 64)
!1929 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !392)
!1930 = !DISubprogram(name: "get_cas_id", scope: !1384, file: !1384, line: 10, type: !1931, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1931 = !DISubroutineType(types: !1932)
!1932 = !{!392}
!1933 = !DILocation(line: 0, scope: !1134)
!1934 = !DILocation(line: 248, column: 13, scope: !1144)
!1935 = !DILocation(line: 248, column: 21, scope: !1144)
!1936 = !DILocation(line: 248, column: 27, scope: !1144)
!1937 = !DILocation(line: 248, column: 58, scope: !1144)
!1938 = !DILocation(line: 250, column: 9, scope: !1143)
!1939 = !DILocation(line: 0, scope: !1143)
!1940 = !DILocation(line: 252, column: 18, scope: !1941)
!1941 = distinct !DILexicalBlock(scope: !1143, file: !2, line: 252, column: 13)
!1942 = !DILocation(line: 252, column: 13, scope: !1143)
!1943 = !DILocation(line: 251, column: 28, scope: !1143)
!1944 = !DILocation(line: 253, column: 13, scope: !1945)
!1945 = distinct !DILexicalBlock(scope: !1941, file: !2, line: 252, column: 23)
!1946 = !DILocation(line: 254, column: 9, scope: !1945)
!1947 = !DILocation(line: 257, column: 5, scope: !1134)
!1948 = !DILocation(line: 258, column: 1, scope: !1134)
!1949 = !DISubprogram(name: "item_remove", scope: !205, file: !205, line: 1013, type: !1385, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1950 = distinct !DISubprogram(name: "handle_binary_protocol_error", scope: !2, file: !2, line: 237, type: !606, scopeLine: 237, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !1951)
!1951 = !{!1952}
!1952 = !DILocalVariable(name: "c", arg: 1, scope: !1950, file: !2, line: 237, type: !608)
!1953 = !DILocation(line: 0, scope: !1950)
!1954 = !DILocation(line: 0, scope: !1158, inlinedAt: !1955)
!1955 = distinct !DILocation(line: 238, column: 5, scope: !1950)
!1956 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !1955)
!1957 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !1955)
!1958 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !1955)
!1959 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !1955)
!1960 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !1955)
!1961 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !1955)
!1962 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !1955)
!1963 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !1955)
!1964 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !1955)
!1965 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !1955)
!1966 = !DILocation(line: 0, scope: !1187, inlinedAt: !1955)
!1967 = !DILocation(line: 239, column: 18, scope: !1968)
!1968 = distinct !DILexicalBlock(scope: !1950, file: !2, line: 239, column: 9)
!1969 = !DILocation(line: 239, column: 9, scope: !1968)
!1970 = !DILocation(line: 239, column: 9, scope: !1950)
!1971 = !DILocation(line: 240, column: 17, scope: !1972)
!1972 = distinct !DILexicalBlock(scope: !1968, file: !2, line: 239, column: 27)
!1973 = !DILocation(line: 241, column: 42, scope: !1972)
!1974 = !DILocation(line: 241, column: 17, scope: !1972)
!1975 = !DILocation(line: 241, column: 53, scope: !1972)
!1976 = !DILocation(line: 240, column: 9, scope: !1972)
!1977 = !DILocation(line: 242, column: 5, scope: !1972)
!1978 = !DILocation(line: 243, column: 8, scope: !1950)
!1979 = !DILocation(line: 243, column: 26, scope: !1950)
!1980 = !DILocation(line: 244, column: 1, scope: !1950)
!1981 = distinct !DISubprogram(name: "process_bin_flush", scope: !2, file: !2, line: 1255, type: !1580, scopeLine: 1255, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !1982)
!1982 = !{!1983, !1984, !1985, !1988, !2002}
!1983 = !DILocalVariable(name: "c", arg: 1, scope: !1981, file: !2, line: 1255, type: !608)
!1984 = !DILocalVariable(name: "extbuf", arg: 2, scope: !1981, file: !2, line: 1255, type: !399)
!1985 = !DILocalVariable(name: "exptime", scope: !1981, file: !2, line: 1256, type: !1986)
!1986 = !DIDerivedType(tag: DW_TAG_typedef, name: "time_t", file: !1987, line: 10, baseType: !522)
!1987 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/time_t.h", directory: "", checksumkind: CSK_MD5, checksum: "5c299a4954617c88bb03645c7864e1b1")
!1988 = !DILocalVariable(name: "req", scope: !1981, file: !2, line: 1257, type: !1989)
!1989 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1990, size: 64)
!1990 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_request_flush", file: !274, line: 259, baseType: !1991)
!1991 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !274, line: 251, size: 256, elements: !1992)
!1992 = !{!1993, !2001}
!1993 = !DIDerivedType(tag: DW_TAG_member, name: "message", scope: !1991, file: !274, line: 257, baseType: !1994, size: 256)
!1994 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !1991, file: !274, line: 252, size: 256, elements: !1995)
!1995 = !{!1996, !1997}
!1996 = !DIDerivedType(tag: DW_TAG_member, name: "header", scope: !1994, file: !274, line: 253, baseType: !961, size: 192)
!1997 = !DIDerivedType(tag: DW_TAG_member, name: "body", scope: !1994, file: !274, line: 256, baseType: !1998, size: 32, offset: 192)
!1998 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !1994, file: !274, line: 254, size: 32, elements: !1999)
!1999 = !{!2000}
!2000 = !DIDerivedType(tag: DW_TAG_member, name: "expiration", scope: !1998, file: !274, line: 255, baseType: !388, size: 32)
!2001 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !1991, file: !274, line: 258, baseType: !559, size: 224)
!2002 = !DILocalVariable(name: "new_oldest", scope: !1981, file: !2, line: 1258, type: !415)
!2003 = !DILocation(line: 0, scope: !1981)
!2004 = !DILocation(line: 1260, column: 19, scope: !2005)
!2005 = distinct !DILexicalBlock(scope: !1981, file: !2, line: 1260, column: 9)
!2006 = !{!1121, !1022, i64 168}
!2007 = !DILocation(line: 1260, column: 9, scope: !1981)
!2008 = !DILocation(line: 0, scope: !1158, inlinedAt: !2009)
!2009 = distinct !DILocation(line: 1262, column: 7, scope: !2010)
!2010 = distinct !DILexicalBlock(scope: !2005, file: !2, line: 1260, column: 34)
!2011 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !2009)
!2012 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !2009)
!2013 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !2009)
!2014 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !2009)
!2015 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !2009)
!2016 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !2009)
!2017 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !2009)
!2018 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !2009)
!2019 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !2009)
!2020 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !2009)
!2021 = !DILocation(line: 0, scope: !1187, inlinedAt: !2009)
!2022 = !DILocation(line: 1263, column: 7, scope: !2010)
!2023 = !DILocation(line: 1266, column: 34, scope: !2024)
!2024 = distinct !DILexicalBlock(scope: !1981, file: !2, line: 1266, column: 9)
!2025 = !DILocation(line: 1266, column: 41, scope: !2024)
!2026 = !DILocation(line: 1266, column: 9, scope: !1981)
!2027 = !DILocation(line: 1267, column: 19, scope: !2028)
!2028 = distinct !DILexicalBlock(scope: !2024, file: !2, line: 1266, column: 71)
!2029 = !DILocation(line: 0, scope: !1504, inlinedAt: !2030)
!2030 = distinct !DILocation(line: 1267, column: 19, scope: !2028)
!2031 = !DILocation(line: 1270, column: 17, scope: !2032)
!2032 = distinct !DILexicalBlock(scope: !1981, file: !2, line: 1270, column: 9)
!2033 = !DILocation(line: 1270, column: 9, scope: !1981)
!2034 = !DILocation(line: 54, column: 10, scope: !1504, inlinedAt: !2030)
!2035 = !DILocation(line: 1271, column: 22, scope: !2036)
!2036 = distinct !DILexicalBlock(scope: !2032, file: !2, line: 1270, column: 22)
!2037 = !DILocation(line: 1272, column: 5, scope: !2036)
!2038 = !DILocation(line: 1273, column: 22, scope: !2039)
!2039 = distinct !DILexicalBlock(scope: !2032, file: !2, line: 1272, column: 12)
!2040 = !DILocation(line: 0, scope: !2032)
!2041 = !DILocation(line: 1275, column: 26, scope: !1981)
!2042 = !{!1121, !1021, i64 36}
!2043 = !DILocation(line: 1276, column: 5, scope: !1981)
!2044 = !DILocation(line: 1278, column: 28, scope: !1981)
!2045 = !DILocation(line: 1278, column: 36, scope: !1981)
!2046 = !DILocation(line: 1278, column: 5, scope: !1981)
!2047 = !DILocation(line: 1279, column: 8, scope: !1981)
!2048 = !DILocation(line: 1279, column: 22, scope: !1981)
!2049 = !DILocation(line: 1279, column: 32, scope: !1981)
!2050 = !{!1112, !1028, i64 496}
!2051 = !DILocation(line: 1280, column: 38, scope: !1981)
!2052 = !DILocation(line: 1280, column: 5, scope: !1981)
!2053 = !DILocation(line: 0, scope: !1134, inlinedAt: !2054)
!2054 = distinct !DILocation(line: 1282, column: 5, scope: !1981)
!2055 = !DILocation(line: 248, column: 13, scope: !1144, inlinedAt: !2054)
!2056 = !DILocation(line: 248, column: 21, scope: !1144, inlinedAt: !2054)
!2057 = !DILocation(line: 248, column: 27, scope: !1144, inlinedAt: !2054)
!2058 = !DILocation(line: 248, column: 58, scope: !1144, inlinedAt: !2054)
!2059 = !DILocation(line: 250, column: 9, scope: !1143, inlinedAt: !2054)
!2060 = !DILocation(line: 0, scope: !1143, inlinedAt: !2054)
!2061 = !DILocation(line: 257, column: 5, scope: !1134, inlinedAt: !2054)
!2062 = !DILocation(line: 1283, column: 1, scope: !1981)
!2063 = distinct !DISubprogram(name: "process_bin_update", scope: !2, file: !2, line: 1083, type: !1580, scopeLine: 1083, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !2064)
!2064 = !{!2065, !2066, !2067, !2068, !2069, !2070, !2071, !2086, !2089, !2092}
!2065 = !DILocalVariable(name: "c", arg: 1, scope: !2063, file: !2, line: 1083, type: !608)
!2066 = !DILocalVariable(name: "extbuf", arg: 2, scope: !2063, file: !2, line: 1083, type: !399)
!2067 = !DILocalVariable(name: "key", scope: !2063, file: !2, line: 1084, type: !399)
!2068 = !DILocalVariable(name: "nkey", scope: !2063, file: !2, line: 1085, type: !383)
!2069 = !DILocalVariable(name: "vlen", scope: !2063, file: !2, line: 1086, type: !418)
!2070 = !DILocalVariable(name: "it", scope: !2063, file: !2, line: 1087, type: !440)
!2071 = !DILocalVariable(name: "req", scope: !2063, file: !2, line: 1088, type: !2072)
!2072 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2073, size: 64)
!2073 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_request_set", file: !274, line: 280, baseType: !2074)
!2074 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !274, line: 271, size: 256, elements: !2075)
!2075 = !{!2076, !2085}
!2076 = !DIDerivedType(tag: DW_TAG_member, name: "message", scope: !2074, file: !274, line: 278, baseType: !2077, size: 256)
!2077 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2074, file: !274, line: 272, size: 256, elements: !2078)
!2078 = !{!2079, !2080}
!2079 = !DIDerivedType(tag: DW_TAG_member, name: "header", scope: !2077, file: !274, line: 273, baseType: !961, size: 192)
!2080 = !DIDerivedType(tag: DW_TAG_member, name: "body", scope: !2077, file: !274, line: 277, baseType: !2081, size: 64, offset: 192)
!2081 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2077, file: !274, line: 274, size: 64, elements: !2082)
!2082 = !{!2083, !2084}
!2083 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !2081, file: !274, line: 275, baseType: !388, size: 32)
!2084 = !DIDerivedType(tag: DW_TAG_member, name: "expiration", scope: !2081, file: !274, line: 276, baseType: !388, size: 32, offset: 32)
!2085 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !2074, file: !274, line: 279, baseType: !575, size: 256)
!2086 = !DILocalVariable(name: "ii", scope: !2087, file: !2, line: 1102, type: !418)
!2087 = distinct !DILexicalBlock(scope: !2088, file: !2, line: 1101, column: 31)
!2088 = distinct !DILexicalBlock(scope: !2063, file: !2, line: 1101, column: 9)
!2089 = !DILocalVariable(name: "status", scope: !2090, file: !2, line: 1126, type: !294)
!2090 = distinct !DILexicalBlock(scope: !2091, file: !2, line: 1125, column: 18)
!2091 = distinct !DILexicalBlock(scope: !2063, file: !2, line: 1125, column: 9)
!2092 = !DILocalVariable(name: "myl", scope: !2093, file: !2, line: 1137, type: !442)
!2093 = distinct !DILexicalBlock(scope: !2090, file: !2, line: 1137, column: 9)
!2094 = !DILocation(line: 0, scope: !2063)
!2095 = !DILocalVariable(name: "c", arg: 1, scope: !2096, file: !2, line: 131, type: !608)
!2096 = distinct !DISubprogram(name: "binary_get_key", scope: !2, file: !2, line: 131, type: !2097, scopeLine: 131, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !2099)
!2097 = !DISubroutineType(types: !2098)
!2098 = !{!399, !608}
!2099 = !{!2095}
!2100 = !DILocation(line: 0, scope: !2096, inlinedAt: !2101)
!2101 = distinct !DILocation(line: 1092, column: 11, scope: !2063)
!2102 = !DILocation(line: 132, column: 15, scope: !2096, inlinedAt: !2101)
!2103 = !DILocation(line: 132, column: 49, scope: !2096, inlinedAt: !2101)
!2104 = !DILocation(line: 132, column: 21, scope: !2096, inlinedAt: !2101)
!2105 = !DILocation(line: 1096, column: 31, scope: !2063)
!2106 = !DILocation(line: 0, scope: !1504, inlinedAt: !2107)
!2107 = distinct !DILocation(line: 1096, column: 31, scope: !2063)
!2108 = !DILocation(line: 54, column: 10, scope: !1504, inlinedAt: !2107)
!2109 = !DILocation(line: 1096, column: 29, scope: !2063)
!2110 = !DILocation(line: 1097, column: 36, scope: !2063)
!2111 = !DILocation(line: 0, scope: !1504, inlinedAt: !2112)
!2112 = distinct !DILocation(line: 1097, column: 36, scope: !2063)
!2113 = !DILocation(line: 54, column: 10, scope: !1504, inlinedAt: !2112)
!2114 = !DILocation(line: 1097, column: 34, scope: !2063)
!2115 = !DILocation(line: 1099, column: 37, scope: !2063)
!2116 = !DILocation(line: 1099, column: 48, scope: !2063)
!2117 = !DILocation(line: 1099, column: 80, scope: !2063)
!2118 = !DILocation(line: 1099, column: 55, scope: !2063)
!2119 = !DILocation(line: 1099, column: 45, scope: !2063)
!2120 = !DILocation(line: 1101, column: 18, scope: !2088)
!2121 = !DILocation(line: 1101, column: 26, scope: !2088)
!2122 = !DILocation(line: 1101, column: 9, scope: !2063)
!2123 = !DILocation(line: 1103, column: 16, scope: !2124)
!2124 = distinct !DILexicalBlock(scope: !2087, file: !2, line: 1103, column: 13)
!2125 = !DILocation(line: 0, scope: !2124)
!2126 = !DILocation(line: 1103, column: 13, scope: !2087)
!2127 = !DILocation(line: 0, scope: !2087)
!2128 = !DILocation(line: 1110, column: 25, scope: !2129)
!2129 = distinct !DILexicalBlock(scope: !2130, file: !2, line: 1110, column: 9)
!2130 = distinct !DILexicalBlock(scope: !2087, file: !2, line: 1110, column: 9)
!2131 = !DILocation(line: 1110, column: 9, scope: !2130)
!2132 = !DILocation(line: 1111, column: 21, scope: !2133)
!2133 = distinct !DILexicalBlock(scope: !2129, file: !2, line: 1110, column: 39)
!2134 = !DILocation(line: 1111, column: 35, scope: !2133)
!2135 = !DILocation(line: 1111, column: 13, scope: !2133)
!2136 = !DILocation(line: 1110, column: 33, scope: !2129)
!2137 = distinct !{!2137, !2131, !2138, !1496}
!2138 = !DILocation(line: 1112, column: 9, scope: !2130)
!2139 = !DILocation(line: 1114, column: 17, scope: !2087)
!2140 = !DILocation(line: 1114, column: 9, scope: !2087)
!2141 = !DILocation(line: 1115, column: 17, scope: !2087)
!2142 = !DILocation(line: 1115, column: 9, scope: !2087)
!2143 = !DILocation(line: 1116, column: 5, scope: !2087)
!2144 = !DILocation(line: 1118, column: 18, scope: !2145)
!2145 = distinct !DILexicalBlock(scope: !2063, file: !2, line: 1118, column: 9)
!2146 = !{!1121, !1021, i64 96}
!2147 = !DILocation(line: 1118, column: 9, scope: !2145)
!2148 = !DILocation(line: 1118, column: 9, scope: !2063)
!2149 = !DILocation(line: 1119, column: 9, scope: !2150)
!2150 = distinct !DILexicalBlock(scope: !2145, file: !2, line: 1118, column: 34)
!2151 = !DILocation(line: 1120, column: 5, scope: !2150)
!2152 = !DILocation(line: 1122, column: 50, scope: !2063)
!2153 = !DILocation(line: 1123, column: 40, scope: !2063)
!2154 = !DILocation(line: 1123, column: 22, scope: !2063)
!2155 = !DILocation(line: 1123, column: 13, scope: !2063)
!2156 = !DILocation(line: 1123, column: 57, scope: !2063)
!2157 = !DILocation(line: 1122, column: 10, scope: !2063)
!2158 = !DILocation(line: 1125, column: 12, scope: !2091)
!2159 = !DILocation(line: 1125, column: 9, scope: !2063)
!2160 = !DILocation(line: 1127, column: 52, scope: !2161)
!2161 = distinct !DILexicalBlock(scope: !2090, file: !2, line: 1127, column: 13)
!2162 = !DILocation(line: 1127, column: 15, scope: !2161)
!2163 = !DILocation(line: 1127, column: 13, scope: !2090)
!2164 = !DILocation(line: 1128, column: 13, scope: !2165)
!2165 = distinct !DILexicalBlock(scope: !2161, file: !2, line: 1127, column: 70)
!2166 = !DILocation(line: 0, scope: !2090)
!2167 = !DILocation(line: 1130, column: 9, scope: !2165)
!2168 = !DILocation(line: 1131, column: 13, scope: !2169)
!2169 = distinct !DILexicalBlock(scope: !2161, file: !2, line: 1130, column: 16)
!2170 = !DILocation(line: 1133, column: 16, scope: !2169)
!2171 = !DILocation(line: 1133, column: 23, scope: !2169)
!2172 = !DILocation(line: 0, scope: !2161)
!2173 = !DILocation(line: 1137, column: 9, scope: !2093)
!2174 = !{!1112, !1018, i64 6912}
!2175 = !DILocation(line: 0, scope: !2093)
!2176 = !DILocation(line: 1137, column: 9, scope: !2177)
!2177 = distinct !DILexicalBlock(scope: !2093, file: !2, line: 1137, column: 9)
!2178 = !DILocation(line: 1137, column: 9, scope: !2179)
!2179 = distinct !DILexicalBlock(scope: !2093, file: !2, line: 1137, column: 9)
!2180 = !{!2181, !1026, i64 84}
!2181 = !{!"_logger", !1018, i64 0, !1018, i64 8, !1019, i64 16, !1028, i64 56, !1028, i64 64, !1028, i64 72, !1026, i64 80, !1026, i64 82, !1026, i64 84, !1018, i64 88, !1018, i64 96}
!2182 = !DILocation(line: 1143, column: 16, scope: !2183)
!2183 = distinct !DILexicalBlock(scope: !2090, file: !2, line: 1143, column: 13)
!2184 = !DILocation(line: 1143, column: 20, scope: !2183)
!2185 = !DILocation(line: 1143, column: 13, scope: !2090)
!2186 = !DILocation(line: 1144, column: 41, scope: !2187)
!2187 = distinct !DILexicalBlock(scope: !2183, file: !2, line: 1143, column: 48)
!2188 = !DILocation(line: 1144, column: 18, scope: !2187)
!2189 = !DILocation(line: 1145, column: 17, scope: !2190)
!2190 = distinct !DILexicalBlock(scope: !2187, file: !2, line: 1145, column: 17)
!2191 = !DILocation(line: 1145, column: 17, scope: !2187)
!2192 = !DILocation(line: 1146, column: 17, scope: !2193)
!2193 = distinct !DILexicalBlock(scope: !2190, file: !2, line: 1145, column: 21)
!2194 = !DILocation(line: 1147, column: 17, scope: !2195)
!2195 = distinct !DILexicalBlock(scope: !2193, file: !2, line: 1147, column: 17)
!2196 = !{!1112, !1018, i64 6904}
!2197 = !DILocation(line: 1148, column: 17, scope: !2193)
!2198 = !DILocation(line: 1149, column: 13, scope: !2193)
!2199 = !DILocation(line: 1153, column: 9, scope: !2090)
!2200 = !DILocation(line: 1157, column: 5, scope: !2201)
!2201 = distinct !DILexicalBlock(scope: !2202, file: !2, line: 1157, column: 5)
!2202 = distinct !DILexicalBlock(scope: !2063, file: !2, line: 1157, column: 5)
!2203 = !DILocation(line: 1157, column: 5, scope: !2202)
!2204 = !DILocation(line: 1157, column: 5, scope: !2205)
!2205 = distinct !DILexicalBlock(scope: !2201, file: !2, line: 1157, column: 5)
!2206 = !DILocation(line: 1159, column: 16, scope: !2063)
!2207 = !DILocation(line: 1159, column: 5, scope: !2063)
!2208 = !DILocation(line: 0, scope: !2209)
!2209 = distinct !DILexicalBlock(scope: !2063, file: !2, line: 1159, column: 21)
!2210 = !DILocation(line: 1173, column: 9, scope: !2211)
!2211 = distinct !DILexicalBlock(scope: !2063, file: !2, line: 1173, column: 9)
!2212 = !DILocation(line: 1173, column: 26, scope: !2211)
!2213 = !DILocation(line: 1173, column: 9, scope: !2063)
!2214 = !DILocation(line: 1174, column: 16, scope: !2215)
!2215 = distinct !DILexicalBlock(scope: !2211, file: !2, line: 1173, column: 32)
!2216 = !DILocation(line: 1185, column: 16, scope: !2063)
!2217 = !DILocation(line: 1175, column: 5, scope: !2215)
!2218 = !DILocation(line: 1177, column: 8, scope: !2063)
!2219 = !DILocation(line: 1177, column: 13, scope: !2063)
!2220 = !DILocation(line: 1185, column: 8, scope: !2063)
!2221 = !DILocation(line: 1185, column: 14, scope: !2063)
!2222 = !DILocation(line: 1187, column: 8, scope: !2063)
!2223 = !DILocation(line: 1187, column: 16, scope: !2063)
!2224 = !{!1017, !1021, i64 216}
!2225 = !DILocation(line: 1188, column: 5, scope: !2063)
!2226 = !DILocation(line: 1189, column: 8, scope: !2063)
!2227 = !DILocation(line: 1189, column: 17, scope: !2063)
!2228 = !DILocation(line: 1190, column: 1, scope: !2063)
!2229 = distinct !DISubprogram(name: "process_bin_get_or_touch", scope: !2, file: !2, line: 459, type: !1580, scopeLine: 459, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !2230)
!2230 = !{!2231, !2232, !2233, !2234, !2235, !2236, !2237, !2238, !2239, !2240, !2241, !2257, !2258, !2261}
!2231 = !DILocalVariable(name: "c", arg: 1, scope: !2229, file: !2, line: 459, type: !608)
!2232 = !DILocalVariable(name: "extbuf", arg: 2, scope: !2229, file: !2, line: 459, type: !399)
!2233 = !DILocalVariable(name: "it", scope: !2229, file: !2, line: 460, type: !440)
!2234 = !DILocalVariable(name: "rsp", scope: !2229, file: !2, line: 462, type: !546)
!2235 = !DILocalVariable(name: "key", scope: !2229, file: !2, line: 463, type: !399)
!2236 = !DILocalVariable(name: "nkey", scope: !2229, file: !2, line: 464, type: !868)
!2237 = !DILocalVariable(name: "should_touch", scope: !2229, file: !2, line: 465, type: !418)
!2238 = !DILocalVariable(name: "should_return_key", scope: !2229, file: !2, line: 468, type: !418)
!2239 = !DILocalVariable(name: "should_return_value", scope: !2229, file: !2, line: 470, type: !418)
!2240 = !DILocalVariable(name: "failed", scope: !2229, file: !2, line: 471, type: !618)
!2241 = !DILocalVariable(name: "t", scope: !2242, file: !2, line: 480, type: !2244)
!2242 = distinct !DILexicalBlock(scope: !2243, file: !2, line: 479, column: 23)
!2243 = distinct !DILexicalBlock(scope: !2229, file: !2, line: 479, column: 9)
!2244 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2245, size: 64)
!2245 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_request_touch", file: !274, line: 400, baseType: !2246)
!2246 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !274, line: 392, size: 256, elements: !2247)
!2247 = !{!2248, !2256}
!2248 = !DIDerivedType(tag: DW_TAG_member, name: "message", scope: !2246, file: !274, line: 398, baseType: !2249, size: 256)
!2249 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2246, file: !274, line: 393, size: 256, elements: !2250)
!2250 = !{!2251, !2252}
!2251 = !DIDerivedType(tag: DW_TAG_member, name: "header", scope: !2249, file: !274, line: 394, baseType: !961, size: 192)
!2252 = !DIDerivedType(tag: DW_TAG_member, name: "body", scope: !2249, file: !274, line: 397, baseType: !2253, size: 32, offset: 192)
!2253 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2249, file: !274, line: 395, size: 32, elements: !2254)
!2254 = !{!2255}
!2255 = !DIDerivedType(tag: DW_TAG_member, name: "expiration", scope: !2253, file: !274, line: 396, baseType: !388, size: 32)
!2256 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !2246, file: !274, line: 399, baseType: !559, size: 224)
!2257 = !DILocalVariable(name: "exptime", scope: !2242, file: !2, line: 481, type: !1986)
!2258 = !DILocalVariable(name: "keylen", scope: !2259, file: !2, line: 490, type: !383)
!2259 = distinct !DILexicalBlock(scope: !2260, file: !2, line: 488, column: 13)
!2260 = distinct !DILexicalBlock(scope: !2229, file: !2, line: 488, column: 9)
!2261 = !DILocalVariable(name: "bodylen", scope: !2259, file: !2, line: 491, type: !388)
!2262 = !DILocation(line: 0, scope: !2229)
!2263 = !DILocation(line: 462, column: 75, scope: !2229)
!2264 = !DILocation(line: 0, scope: !2096, inlinedAt: !2265)
!2265 = distinct !DILocation(line: 463, column: 17, scope: !2229)
!2266 = !DILocation(line: 132, column: 15, scope: !2096, inlinedAt: !2265)
!2267 = !DILocation(line: 132, column: 49, scope: !2096, inlinedAt: !2265)
!2268 = !DILocation(line: 132, column: 21, scope: !2096, inlinedAt: !2265)
!2269 = !DILocation(line: 465, column: 28, scope: !2229)
!2270 = !DILocation(line: 465, column: 61, scope: !2229)
!2271 = !DILocation(line: 470, column: 39, scope: !2229)
!2272 = !DILocation(line: 473, column: 18, scope: !2273)
!2273 = distinct !DILexicalBlock(scope: !2229, file: !2, line: 473, column: 9)
!2274 = !DILocation(line: 473, column: 26, scope: !2273)
!2275 = !DILocation(line: 473, column: 9, scope: !2229)
!2276 = !DILocation(line: 474, column: 17, scope: !2277)
!2277 = distinct !DILexicalBlock(scope: !2273, file: !2, line: 473, column: 31)
!2278 = !DILocation(line: 474, column: 39, scope: !2277)
!2279 = !DILocation(line: 474, column: 44, scope: !2277)
!2280 = !DILocation(line: 474, column: 9, scope: !2277)
!2281 = !DILocation(line: 475, column: 34, scope: !2282)
!2282 = distinct !DILexicalBlock(scope: !2277, file: !2, line: 475, column: 13)
!2283 = !DILocation(line: 475, column: 13, scope: !2282)
!2284 = !DILocation(line: 476, column: 21, scope: !2277)
!2285 = !DILocation(line: 476, column: 9, scope: !2277)
!2286 = !DILocation(line: 477, column: 5, scope: !2277)
!2287 = !DILocation(line: 479, column: 9, scope: !2229)
!2288 = !DILocation(line: 0, scope: !2242)
!2289 = !DILocation(line: 481, column: 26, scope: !2242)
!2290 = !DILocation(line: 0, scope: !1504, inlinedAt: !2291)
!2291 = distinct !DILocation(line: 481, column: 26, scope: !2242)
!2292 = !DILocation(line: 54, column: 10, scope: !1504, inlinedAt: !2291)
!2293 = !DILocation(line: 483, column: 36, scope: !2242)
!2294 = !DILocation(line: 483, column: 58, scope: !2242)
!2295 = !DILocation(line: 483, column: 14, scope: !2242)
!2296 = !DILocation(line: 484, column: 5, scope: !2242)
!2297 = !DILocation(line: 485, column: 37, scope: !2298)
!2298 = distinct !DILexicalBlock(scope: !2243, file: !2, line: 484, column: 12)
!2299 = !DILocation(line: 485, column: 14, scope: !2298)
!2300 = !DILocation(line: 0, scope: !2243)
!2301 = !DILocation(line: 488, column: 9, scope: !2260)
!2302 = !DILocation(line: 488, column: 9, scope: !2229)
!2303 = !DILocation(line: 0, scope: !2259)
!2304 = !DILocation(line: 491, column: 61, scope: !2259)
!2305 = !DILocation(line: 491, column: 54, scope: !2259)
!2306 = !DILocation(line: 493, column: 32, scope: !2259)
!2307 = !DILocation(line: 493, column: 40, scope: !2259)
!2308 = !DILocation(line: 493, column: 9, scope: !2259)
!2309 = !DILocation(line: 0, scope: !2310)
!2310 = distinct !DILexicalBlock(scope: !2259, file: !2, line: 494, column: 13)
!2311 = !DILocation(line: 494, column: 13, scope: !2259)
!2312 = !DILocation(line: 495, column: 30, scope: !2313)
!2313 = distinct !DILexicalBlock(scope: !2310, file: !2, line: 494, column: 27)
!2314 = !DILocation(line: 495, column: 40, scope: !2313)
!2315 = !{!1112, !1028, i64 424}
!2316 = !DILocation(line: 496, column: 30, scope: !2313)
!2317 = !DILocation(line: 496, column: 41, scope: !2313)
!2318 = !DILocation(line: 496, column: 57, scope: !2313)
!2319 = !DILocation(line: 497, column: 9, scope: !2313)
!2320 = !DILocation(line: 498, column: 30, scope: !2321)
!2321 = distinct !DILexicalBlock(scope: !2310, file: !2, line: 497, column: 16)
!2322 = !DILocation(line: 498, column: 38, scope: !2321)
!2323 = !{!1112, !1028, i64 392}
!2324 = !DILocation(line: 499, column: 30, scope: !2321)
!2325 = !DILocation(line: 499, column: 43, scope: !2321)
!2326 = !DILocation(line: 499, column: 13, scope: !2321)
!2327 = !DILocation(line: 501, column: 42, scope: !2259)
!2328 = !DILocation(line: 501, column: 9, scope: !2259)
!2329 = !DILocation(line: 511, column: 16, scope: !2330)
!2330 = distinct !DILexicalBlock(scope: !2259, file: !2, line: 511, column: 13)
!2331 = !DILocation(line: 511, column: 20, scope: !2330)
!2332 = !DILocation(line: 511, column: 13, scope: !2259)
!2333 = !DILocation(line: 512, column: 28, scope: !2334)
!2334 = distinct !DILexicalBlock(scope: !2330, file: !2, line: 511, column: 50)
!2335 = !DILocation(line: 512, column: 35, scope: !2334)
!2336 = !DILocation(line: 512, column: 21, scope: !2334)
!2337 = !DILocation(line: 513, column: 9, scope: !2334)
!2338 = !DILocation(line: 513, column: 20, scope: !2330)
!2339 = !DILocation(line: 514, column: 21, scope: !2340)
!2340 = distinct !DILexicalBlock(scope: !2341, file: !2, line: 513, column: 39)
!2341 = distinct !DILexicalBlock(scope: !2330, file: !2, line: 513, column: 20)
!2342 = !DILocation(line: 516, column: 9, scope: !2340)
!2343 = !DILocation(line: 518, column: 9, scope: !2259)
!2344 = !DILocation(line: 519, column: 51, scope: !2259)
!2345 = !DILocation(line: 519, column: 44, scope: !2259)
!2346 = !DILocation(line: 519, column: 38, scope: !2259)
!2347 = !DILocation(line: 519, column: 42, scope: !2259)
!2348 = !DILocation(line: 522, column: 9, scope: !2349)
!2349 = distinct !DILexicalBlock(scope: !2350, file: !2, line: 522, column: 9)
!2350 = distinct !DILexicalBlock(scope: !2259, file: !2, line: 522, column: 9)
!2351 = !DILocation(line: 522, column: 9, scope: !2350)
!2352 = !DILocation(line: 522, column: 9, scope: !2353)
!2353 = distinct !DILexicalBlock(scope: !2349, file: !2, line: 522, column: 9)
!2354 = !DILocation(line: 0, scope: !1504, inlinedAt: !2355)
!2355 = distinct !DILocation(line: 523, column: 35, scope: !2259)
!2356 = !DILocation(line: 54, column: 10, scope: !1504, inlinedAt: !2355)
!2357 = !DILocation(line: 523, column: 33, scope: !2259)
!2358 = !DILocation(line: 524, column: 25, scope: !2259)
!2359 = !DILocation(line: 524, column: 9, scope: !2259)
!2360 = !DILocation(line: 526, column: 13, scope: !2259)
!2361 = !DILocation(line: 527, column: 29, scope: !2362)
!2362 = distinct !DILexicalBlock(scope: !2363, file: !2, line: 526, column: 32)
!2363 = distinct !DILexicalBlock(scope: !2259, file: !2, line: 526, column: 13)
!2364 = !DILocation(line: 527, column: 35, scope: !2362)
!2365 = !DILocation(line: 527, column: 49, scope: !2362)
!2366 = !DILocation(line: 527, column: 13, scope: !2362)
!2367 = !DILocation(line: 528, column: 9, scope: !2362)
!2368 = !DILocation(line: 530, column: 13, scope: !2259)
!2369 = !DILocation(line: 533, column: 21, scope: !2370)
!2370 = distinct !DILexicalBlock(scope: !2371, file: !2, line: 533, column: 17)
!2371 = distinct !DILexicalBlock(scope: !2372, file: !2, line: 530, column: 34)
!2372 = distinct !DILexicalBlock(scope: !2259, file: !2, line: 530, column: 13)
!2373 = !DILocation(line: 533, column: 17, scope: !2370)
!2374 = !DILocation(line: 533, column: 30, scope: !2370)
!2375 = !DILocation(line: 533, column: 17, scope: !2371)
!2376 = !DILocation(line: 534, column: 48, scope: !2377)
!2377 = distinct !DILexicalBlock(scope: !2378, file: !2, line: 534, column: 21)
!2378 = distinct !DILexicalBlock(scope: !2370, file: !2, line: 533, column: 42)
!2379 = !DILocation(line: 534, column: 21, scope: !2377)
!2380 = !DILocation(line: 534, column: 54, scope: !2377)
!2381 = !DILocation(line: 534, column: 21, scope: !2378)
!2382 = !DILocation(line: 541, column: 38, scope: !2383)
!2383 = distinct !DILexicalBlock(scope: !2370, file: !2, line: 541, column: 24)
!2384 = !DILocation(line: 541, column: 54, scope: !2383)
!2385 = !DILocation(line: 0, scope: !2383)
!2386 = !DILocation(line: 541, column: 24, scope: !2370)
!2387 = !DILocation(line: 542, column: 39, scope: !2388)
!2388 = distinct !DILexicalBlock(scope: !2383, file: !2, line: 541, column: 60)
!2389 = !DILocation(line: 542, column: 58, scope: !2388)
!2390 = !DILocation(line: 542, column: 65, scope: !2388)
!2391 = !DILocation(line: 542, column: 17, scope: !2388)
!2392 = !DILocation(line: 543, column: 13, scope: !2388)
!2393 = !DILocation(line: 545, column: 55, scope: !2394)
!2394 = distinct !DILexicalBlock(scope: !2383, file: !2, line: 543, column: 20)
!2395 = !DILocation(line: 545, column: 62, scope: !2394)
!2396 = !DILocation(line: 545, column: 17, scope: !2394)
!2397 = !DILocation(line: 557, column: 13, scope: !2398)
!2398 = distinct !DILexicalBlock(scope: !2399, file: !2, line: 556, column: 22)
!2399 = distinct !DILexicalBlock(scope: !2259, file: !2, line: 556, column: 13)
!2400 = !DILocation(line: 560, column: 22, scope: !2401)
!2401 = distinct !DILexicalBlock(scope: !2398, file: !2, line: 560, column: 17)
!2402 = !DILocation(line: 560, column: 31, scope: !2401)
!2403 = !DILocation(line: 560, column: 43, scope: !2401)
!2404 = !DILocation(line: 560, column: 48, scope: !2401)
!2405 = !DILocation(line: 0, scope: !2401)
!2406 = !DILocation(line: 562, column: 31, scope: !2407)
!2407 = distinct !DILexicalBlock(scope: !2401, file: !2, line: 560, column: 72)
!2408 = !{!1908, !1018, i64 40}
!2409 = !DILocation(line: 563, column: 13, scope: !2407)
!2410 = !DILocation(line: 564, column: 31, scope: !2411)
!2411 = distinct !DILexicalBlock(scope: !2401, file: !2, line: 563, column: 20)
!2412 = !DILocation(line: 535, column: 44, scope: !2413)
!2413 = distinct !DILexicalBlock(scope: !2377, file: !2, line: 534, column: 60)
!2414 = !DILocation(line: 535, column: 52, scope: !2413)
!2415 = !DILocation(line: 535, column: 21, scope: !2413)
!2416 = !DILocation(line: 536, column: 24, scope: !2413)
!2417 = !DILocation(line: 536, column: 38, scope: !2413)
!2418 = !DILocation(line: 536, column: 54, scope: !2413)
!2419 = !{!1112, !1028, i64 600}
!2420 = !DILocation(line: 537, column: 54, scope: !2413)
!2421 = !DILocation(line: 537, column: 21, scope: !2413)
!2422 = !DILocation(line: 570, column: 13, scope: !2423)
!2423 = distinct !DILexicalBlock(scope: !2399, file: !2, line: 569, column: 16)
!2424 = !DILocation(line: 576, column: 9, scope: !2229)
!2425 = !DILocation(line: 577, column: 32, scope: !2426)
!2426 = distinct !DILexicalBlock(scope: !2427, file: !2, line: 576, column: 17)
!2427 = distinct !DILexicalBlock(scope: !2229, file: !2, line: 576, column: 9)
!2428 = !DILocation(line: 577, column: 40, scope: !2426)
!2429 = !DILocation(line: 577, column: 9, scope: !2426)
!2430 = !DILocation(line: 0, scope: !2431)
!2431 = distinct !DILexicalBlock(scope: !2426, file: !2, line: 578, column: 13)
!2432 = !DILocation(line: 585, column: 42, scope: !2426)
!2433 = !DILocation(line: 585, column: 9, scope: !2426)
!2434 = !DILocation(line: 593, column: 16, scope: !2435)
!2435 = distinct !DILexicalBlock(scope: !2426, file: !2, line: 593, column: 13)
!2436 = !DILocation(line: 593, column: 13, scope: !2426)
!2437 = !DILocation(line: 594, column: 13, scope: !2438)
!2438 = distinct !DILexicalBlock(scope: !2435, file: !2, line: 593, column: 25)
!2439 = !DILocation(line: 595, column: 9, scope: !2438)
!2440 = !DILocation(line: 596, column: 17, scope: !2441)
!2441 = distinct !DILexicalBlock(scope: !2435, file: !2, line: 595, column: 16)
!2442 = !DILocation(line: 597, column: 17, scope: !2443)
!2443 = distinct !DILexicalBlock(scope: !2444, file: !2, line: 596, column: 36)
!2444 = distinct !DILexicalBlock(scope: !2441, file: !2, line: 596, column: 17)
!2445 = !DILocation(line: 598, column: 13, scope: !2443)
!2446 = !DILocalVariable(name: "c", arg: 1, scope: !2447, file: !2, line: 445, type: !608)
!2447 = distinct !DISubprogram(name: "write_bin_miss_response", scope: !2, file: !2, line: 445, type: !2448, scopeLine: 445, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !2450)
!2448 = !DISubroutineType(types: !2449)
!2449 = !{null, !608, !399, !868}
!2450 = !{!2446, !2451, !2452, !2453}
!2451 = !DILocalVariable(name: "key", arg: 2, scope: !2447, file: !2, line: 445, type: !399)
!2452 = !DILocalVariable(name: "nkey", arg: 3, scope: !2447, file: !2, line: 445, type: !868)
!2453 = !DILocalVariable(name: "ofs", scope: !2454, file: !2, line: 449, type: !399)
!2454 = distinct !DILexicalBlock(scope: !2455, file: !2, line: 446, column: 15)
!2455 = distinct !DILexicalBlock(scope: !2447, file: !2, line: 446, column: 9)
!2456 = !DILocation(line: 0, scope: !2447, inlinedAt: !2457)
!2457 = distinct !DILocation(line: 599, column: 17, scope: !2458)
!2458 = distinct !DILexicalBlock(scope: !2444, file: !2, line: 598, column: 20)
!2459 = !DILocation(line: 0, scope: !1158, inlinedAt: !2460)
!2460 = distinct !DILocation(line: 454, column: 9, scope: !2461, inlinedAt: !2457)
!2461 = distinct !DILexicalBlock(scope: !2455, file: !2, line: 453, column: 12)
!2462 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !2460)
!2463 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !2460)
!2464 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !2460)
!2465 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !2460)
!2466 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !2460)
!2467 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !2460)
!2468 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !2460)
!2469 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !2460)
!2470 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !2460)
!2471 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !2460)
!2472 = !DILocation(line: 0, scope: !2455, inlinedAt: !2457)
!2473 = !DILocation(line: 604, column: 18, scope: !2474)
!2474 = distinct !DILexicalBlock(scope: !2229, file: !2, line: 604, column: 9)
!2475 = !DILocation(line: 604, column: 9, scope: !2474)
!2476 = !DILocation(line: 604, column: 9, scope: !2229)
!2477 = !DILocation(line: 605, column: 9, scope: !2478)
!2478 = distinct !DILexicalBlock(scope: !2474, file: !2, line: 604, column: 34)
!2479 = !DILocation(line: 606, column: 5, scope: !2478)
!2480 = !DILocation(line: 607, column: 1, scope: !2229)
!2481 = distinct !DISubprogram(name: "process_bin_delete", scope: !2, file: !2, line: 1285, type: !606, scopeLine: 1285, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !2482)
!2482 = !{!2483, !2484, !2485, !2486, !2487, !2488, !2491}
!2483 = !DILocalVariable(name: "c", arg: 1, scope: !2481, file: !2, line: 1285, type: !608)
!2484 = !DILocalVariable(name: "it", scope: !2481, file: !2, line: 1286, type: !440)
!2485 = !DILocalVariable(name: "hv", scope: !2481, file: !2, line: 1287, type: !388)
!2486 = !DILocalVariable(name: "key", scope: !2481, file: !2, line: 1290, type: !399)
!2487 = !DILocalVariable(name: "nkey", scope: !2481, file: !2, line: 1291, type: !868)
!2488 = !DILocalVariable(name: "ii", scope: !2489, file: !2, line: 1294, type: !418)
!2489 = distinct !DILexicalBlock(scope: !2490, file: !2, line: 1293, column: 31)
!2490 = distinct !DILexicalBlock(scope: !2481, file: !2, line: 1293, column: 9)
!2491 = !DILocalVariable(name: "cas", scope: !2492, file: !2, line: 1308, type: !392)
!2492 = distinct !DILexicalBlock(scope: !2493, file: !2, line: 1307, column: 13)
!2493 = distinct !DILexicalBlock(scope: !2481, file: !2, line: 1307, column: 9)
!2494 = distinct !DIAssignID()
!2495 = !DILocation(line: 0, scope: !2481)
!2496 = !DILocation(line: 1287, column: 5, scope: !2481)
!2497 = !DILocation(line: 0, scope: !2096, inlinedAt: !2498)
!2498 = distinct !DILocation(line: 1290, column: 17, scope: !2481)
!2499 = !DILocation(line: 132, column: 15, scope: !2096, inlinedAt: !2498)
!2500 = !DILocation(line: 132, column: 49, scope: !2096, inlinedAt: !2498)
!2501 = !DILocation(line: 132, column: 21, scope: !2096, inlinedAt: !2498)
!2502 = !DILocation(line: 1293, column: 18, scope: !2490)
!2503 = !DILocation(line: 1293, column: 26, scope: !2490)
!2504 = !DILocation(line: 1293, column: 9, scope: !2481)
!2505 = !DILocation(line: 1295, column: 17, scope: !2489)
!2506 = !DILocation(line: 1295, column: 9, scope: !2489)
!2507 = !DILocation(line: 0, scope: !2489)
!2508 = !DILocation(line: 1296, column: 25, scope: !2509)
!2509 = distinct !DILexicalBlock(scope: !2510, file: !2, line: 1296, column: 9)
!2510 = distinct !DILexicalBlock(scope: !2489, file: !2, line: 1296, column: 9)
!2511 = !DILocation(line: 1296, column: 9, scope: !2510)
!2512 = !DILocation(line: 1297, column: 21, scope: !2513)
!2513 = distinct !DILexicalBlock(scope: !2509, file: !2, line: 1296, column: 39)
!2514 = !DILocation(line: 1297, column: 35, scope: !2513)
!2515 = !DILocation(line: 1297, column: 13, scope: !2513)
!2516 = !DILocation(line: 1296, column: 33, scope: !2509)
!2517 = distinct !{!2517, !2511, !2518, !1496}
!2518 = !DILocation(line: 1298, column: 9, scope: !2510)
!2519 = !DILocation(line: 1299, column: 17, scope: !2489)
!2520 = !DILocation(line: 1299, column: 9, scope: !2489)
!2521 = !DILocation(line: 1300, column: 5, scope: !2489)
!2522 = !DILocation(line: 1302, column: 18, scope: !2523)
!2523 = distinct !DILexicalBlock(scope: !2481, file: !2, line: 1302, column: 9)
!2524 = !DILocation(line: 1302, column: 9, scope: !2523)
!2525 = !DILocation(line: 1302, column: 9, scope: !2481)
!2526 = !DILocation(line: 1303, column: 9, scope: !2527)
!2527 = distinct !DILexicalBlock(scope: !2523, file: !2, line: 1302, column: 34)
!2528 = !DILocation(line: 1304, column: 5, scope: !2527)
!2529 = !DILocation(line: 1306, column: 40, scope: !2481)
!2530 = !DILocation(line: 1306, column: 10, scope: !2481)
!2531 = !DILocation(line: 1307, column: 9, scope: !2493)
!2532 = !DILocation(line: 1307, column: 9, scope: !2481)
!2533 = !DILocation(line: 1308, column: 49, scope: !2492)
!2534 = !DILocation(line: 0, scope: !2492)
!2535 = !DILocation(line: 1309, column: 17, scope: !2536)
!2536 = distinct !DILexicalBlock(scope: !2492, file: !2, line: 1309, column: 13)
!2537 = !DILocation(line: 1309, column: 22, scope: !2536)
!2538 = !DILocation(line: 1309, column: 32, scope: !2536)
!2539 = !DILocation(line: 1309, column: 29, scope: !2536)
!2540 = !DILocation(line: 1309, column: 13, scope: !2492)
!2541 = !DILocation(line: 1311, column: 36, scope: !2542)
!2542 = distinct !DILexicalBlock(scope: !2536, file: !2, line: 1309, column: 50)
!2543 = !DILocation(line: 1311, column: 44, scope: !2542)
!2544 = !DILocation(line: 1311, column: 13, scope: !2542)
!2545 = !DILocation(line: 1312, column: 16, scope: !2542)
!2546 = !DILocation(line: 1312, column: 30, scope: !2542)
!2547 = !DILocation(line: 1312, column: 41, scope: !2542)
!2548 = !DILocation(line: 1312, column: 57, scope: !2542)
!2549 = !DILocation(line: 1312, column: 68, scope: !2542)
!2550 = !{!1060, !1028, i64 24}
!2551 = !DILocation(line: 1313, column: 46, scope: !2542)
!2552 = !DILocation(line: 1313, column: 13, scope: !2542)
!2553 = !DILocation(line: 1314, column: 32, scope: !2542)
!2554 = !DILocation(line: 1314, column: 13, scope: !2542)
!2555 = !DILocation(line: 1315, column: 13, scope: !2556)
!2556 = distinct !DILexicalBlock(scope: !2542, file: !2, line: 1315, column: 13)
!2557 = !DILocation(line: 0, scope: !1134, inlinedAt: !2558)
!2558 = distinct !DILocation(line: 1316, column: 13, scope: !2542)
!2559 = !DILocation(line: 248, column: 13, scope: !1144, inlinedAt: !2558)
!2560 = !DILocation(line: 248, column: 21, scope: !1144, inlinedAt: !2558)
!2561 = !DILocation(line: 248, column: 27, scope: !1144, inlinedAt: !2558)
!2562 = !DILocation(line: 248, column: 58, scope: !1144, inlinedAt: !2558)
!2563 = !DILocation(line: 250, column: 9, scope: !1143, inlinedAt: !2558)
!2564 = !DILocation(line: 0, scope: !1143, inlinedAt: !2558)
!2565 = !DILocation(line: 0, scope: !1158, inlinedAt: !2566)
!2566 = distinct !DILocation(line: 1318, column: 13, scope: !2567)
!2567 = distinct !DILexicalBlock(scope: !2536, file: !2, line: 1317, column: 16)
!2568 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !2566)
!2569 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !2566)
!2570 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !2566)
!2571 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !2566)
!2572 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !2566)
!2573 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !2566)
!2574 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !2566)
!2575 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !2566)
!2576 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !2566)
!2577 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !2566)
!2578 = !DILocation(line: 0, scope: !2536)
!2579 = !DILocation(line: 1320, column: 9, scope: !2492)
!2580 = !DILocation(line: 1321, column: 5, scope: !2492)
!2581 = !DILocation(line: 0, scope: !1158, inlinedAt: !2582)
!2582 = distinct !DILocation(line: 1322, column: 9, scope: !2583)
!2583 = distinct !DILexicalBlock(scope: !2493, file: !2, line: 1321, column: 12)
!2584 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !2582)
!2585 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !2582)
!2586 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !2582)
!2587 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !2582)
!2588 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !2582)
!2589 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !2582)
!2590 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !2582)
!2591 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !2582)
!2592 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !2582)
!2593 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !2582)
!2594 = !DILocation(line: 0, scope: !1187, inlinedAt: !2582)
!2595 = !DILocation(line: 1323, column: 32, scope: !2583)
!2596 = !DILocation(line: 1323, column: 40, scope: !2583)
!2597 = !DILocation(line: 1323, column: 9, scope: !2583)
!2598 = !DILocation(line: 1324, column: 12, scope: !2583)
!2599 = !DILocation(line: 1324, column: 26, scope: !2583)
!2600 = !DILocation(line: 1324, column: 39, scope: !2583)
!2601 = !{!1112, !1028, i64 440}
!2602 = !DILocation(line: 1325, column: 42, scope: !2583)
!2603 = !DILocation(line: 1325, column: 9, scope: !2583)
!2604 = !DILocation(line: 1327, column: 17, scope: !2481)
!2605 = !DILocation(line: 1327, column: 5, scope: !2481)
!2606 = !DILocation(line: 1328, column: 1, scope: !2481)
!2607 = distinct !DISubprogram(name: "complete_incr_bin", scope: !2, file: !2, line: 260, type: !1580, scopeLine: 260, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !2608)
!2608 = !{!2609, !2610, !2611, !2612, !2613, !2614, !2616, !2617, !2618, !2635, !2638, !2642}
!2609 = !DILocalVariable(name: "c", arg: 1, scope: !2607, file: !2, line: 260, type: !608)
!2610 = !DILocalVariable(name: "extbuf", arg: 2, scope: !2607, file: !2, line: 260, type: !399)
!2611 = !DILocalVariable(name: "it", scope: !2607, file: !2, line: 261, type: !440)
!2612 = !DILocalVariable(name: "key", scope: !2607, file: !2, line: 262, type: !399)
!2613 = !DILocalVariable(name: "nkey", scope: !2607, file: !2, line: 263, type: !868)
!2614 = !DILocalVariable(name: "tmpbuf", scope: !2607, file: !2, line: 265, type: !2615)
!2615 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 192, elements: !397)
!2616 = !DILocalVariable(name: "cas", scope: !2607, file: !2, line: 266, type: !392)
!2617 = !DILocalVariable(name: "rsp", scope: !2607, file: !2, line: 269, type: !562)
!2618 = !DILocalVariable(name: "req", scope: !2607, file: !2, line: 270, type: !2619)
!2619 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2620, size: 64)
!2620 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_request_incr", file: !274, line: 319, baseType: !2621)
!2621 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !274, line: 309, size: 384, elements: !2622)
!2622 = !{!2623, !2633}
!2623 = !DIDerivedType(tag: DW_TAG_member, name: "message", scope: !2621, file: !274, line: 317, baseType: !2624, size: 384)
!2624 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2621, file: !274, line: 310, size: 384, elements: !2625)
!2625 = !{!2626, !2627}
!2626 = !DIDerivedType(tag: DW_TAG_member, name: "header", scope: !2624, file: !274, line: 311, baseType: !961, size: 192)
!2627 = !DIDerivedType(tag: DW_TAG_member, name: "body", scope: !2624, file: !274, line: 316, baseType: !2628, size: 192, offset: 192)
!2628 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2624, file: !274, line: 312, size: 192, elements: !2629)
!2629 = !{!2630, !2631, !2632}
!2630 = !DIDerivedType(tag: DW_TAG_member, name: "delta", scope: !2628, file: !274, line: 313, baseType: !392, size: 64)
!2631 = !DIDerivedType(tag: DW_TAG_member, name: "initial", scope: !2628, file: !274, line: 314, baseType: !392, size: 64, offset: 64)
!2632 = !DIDerivedType(tag: DW_TAG_member, name: "expiration", scope: !2628, file: !274, line: 315, baseType: !388, size: 32, offset: 128)
!2633 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !2621, file: !274, line: 318, baseType: !2634, size: 352)
!2634 = !DICompositeType(tag: DW_TAG_array_type, baseType: !377, size: 352, elements: !192)
!2635 = !DILocalVariable(name: "i", scope: !2636, file: !2, line: 282, type: !418)
!2636 = distinct !DILexicalBlock(scope: !2637, file: !2, line: 281, column: 31)
!2637 = distinct !DILexicalBlock(scope: !2607, file: !2, line: 281, column: 9)
!2638 = !DILocalVariable(name: "res", scope: !2639, file: !2, line: 321, type: !418)
!2639 = distinct !DILexicalBlock(scope: !2640, file: !2, line: 315, column: 57)
!2640 = distinct !DILexicalBlock(scope: !2641, file: !2, line: 315, column: 13)
!2641 = distinct !DILexicalBlock(scope: !2607, file: !2, line: 299, column: 29)
!2642 = !DILocalVariable(name: "cas", scope: !2643, file: !2, line: 326, type: !392)
!2643 = distinct !DILexicalBlock(scope: !2644, file: !2, line: 325, column: 29)
!2644 = distinct !DILexicalBlock(scope: !2639, file: !2, line: 325, column: 17)
!2645 = distinct !DIAssignID()
!2646 = !DILocation(line: 0, scope: !2607)
!2647 = distinct !DIAssignID()
!2648 = distinct !DIAssignID()
!2649 = !DILocation(line: 0, scope: !2643)
!2650 = !DILocation(line: 265, column: 5, scope: !2607)
!2651 = !DILocation(line: 266, column: 5, scope: !2607)
!2652 = !DILocation(line: 266, column: 14, scope: !2607)
!2653 = distinct !DIAssignID()
!2654 = !DILocation(line: 269, column: 77, scope: !2607)
!2655 = !DILocation(line: 275, column: 51, scope: !2607)
!2656 = !DILocation(line: 275, column: 56, scope: !2607)
!2657 = !DILocation(line: 275, column: 31, scope: !2607)
!2658 = !DILocation(line: 275, column: 29, scope: !2607)
!2659 = !DILocation(line: 276, column: 58, scope: !2607)
!2660 = !DILocation(line: 276, column: 33, scope: !2607)
!2661 = !DILocation(line: 276, column: 31, scope: !2607)
!2662 = !DILocation(line: 277, column: 36, scope: !2607)
!2663 = !DILocation(line: 0, scope: !1504, inlinedAt: !2664)
!2664 = distinct !DILocation(line: 277, column: 36, scope: !2607)
!2665 = !DILocation(line: 54, column: 10, scope: !1504, inlinedAt: !2664)
!2666 = !DILocation(line: 277, column: 34, scope: !2607)
!2667 = !DILocation(line: 0, scope: !2096, inlinedAt: !2668)
!2668 = distinct !DILocation(line: 278, column: 11, scope: !2607)
!2669 = !DILocation(line: 132, column: 15, scope: !2096, inlinedAt: !2668)
!2670 = !DILocation(line: 132, column: 49, scope: !2096, inlinedAt: !2668)
!2671 = !DILocation(line: 132, column: 21, scope: !2096, inlinedAt: !2668)
!2672 = !DILocation(line: 281, column: 18, scope: !2637)
!2673 = !DILocation(line: 281, column: 26, scope: !2637)
!2674 = !DILocation(line: 281, column: 9, scope: !2607)
!2675 = !DILocation(line: 283, column: 17, scope: !2636)
!2676 = !DILocation(line: 283, column: 9, scope: !2636)
!2677 = !DILocation(line: 0, scope: !2636)
!2678 = !DILocation(line: 285, column: 23, scope: !2679)
!2679 = distinct !DILexicalBlock(scope: !2680, file: !2, line: 285, column: 9)
!2680 = distinct !DILexicalBlock(scope: !2636, file: !2, line: 285, column: 9)
!2681 = !DILocation(line: 285, column: 9, scope: !2680)
!2682 = !DILocation(line: 286, column: 21, scope: !2683)
!2683 = distinct !DILexicalBlock(scope: !2679, file: !2, line: 285, column: 36)
!2684 = !DILocation(line: 286, column: 35, scope: !2683)
!2685 = !DILocation(line: 286, column: 13, scope: !2683)
!2686 = !DILocation(line: 285, column: 32, scope: !2679)
!2687 = distinct !{!2687, !2681, !2688, !1496}
!2688 = !DILocation(line: 287, column: 9, scope: !2680)
!2689 = !DILocation(line: 288, column: 17, scope: !2636)
!2690 = !DILocation(line: 289, column: 46, scope: !2636)
!2691 = !DILocation(line: 290, column: 46, scope: !2636)
!2692 = !DILocation(line: 291, column: 35, scope: !2636)
!2693 = !DILocation(line: 288, column: 9, scope: !2636)
!2694 = !DILocation(line: 292, column: 5, scope: !2636)
!2695 = !DILocation(line: 294, column: 34, scope: !2696)
!2696 = distinct !DILexicalBlock(scope: !2607, file: !2, line: 294, column: 9)
!2697 = !DILocation(line: 294, column: 38, scope: !2696)
!2698 = !DILocation(line: 294, column: 9, scope: !2607)
!2699 = !DILocation(line: 295, column: 13, scope: !2700)
!2700 = distinct !DILexicalBlock(scope: !2696, file: !2, line: 294, column: 44)
!2701 = distinct !DIAssignID()
!2702 = !DILocation(line: 296, column: 5, scope: !2700)
!2703 = !DILocation(line: 297, column: 25, scope: !2607)
!2704 = !DILocation(line: 297, column: 47, scope: !2607)
!2705 = !DILocation(line: 297, column: 51, scope: !2607)
!2706 = !DILocation(line: 298, column: 40, scope: !2607)
!2707 = !DILocation(line: 297, column: 12, scope: !2607)
!2708 = !DILocation(line: 297, column: 5, scope: !2607)
!2709 = !DILocation(line: 301, column: 42, scope: !2641)
!2710 = !DILocation(line: 301, column: 35, scope: !2641)
!2711 = !DILocation(line: 301, column: 22, scope: !2641)
!2712 = !DILocation(line: 301, column: 33, scope: !2641)
!2713 = !DILocation(line: 302, column: 13, scope: !2714)
!2714 = distinct !DILexicalBlock(scope: !2641, file: !2, line: 302, column: 13)
!2715 = !DILocation(line: 302, column: 13, scope: !2641)
!2716 = !DILocation(line: 303, column: 16, scope: !2717)
!2717 = distinct !DILexicalBlock(scope: !2714, file: !2, line: 302, column: 18)
!2718 = !DILocation(line: 303, column: 20, scope: !2717)
!2719 = !DILocation(line: 304, column: 9, scope: !2717)
!2720 = !DILocation(line: 0, scope: !1134, inlinedAt: !2721)
!2721 = distinct !DILocation(line: 305, column: 9, scope: !2641)
!2722 = !DILocation(line: 248, column: 13, scope: !1144, inlinedAt: !2721)
!2723 = !DILocation(line: 248, column: 21, scope: !1144, inlinedAt: !2721)
!2724 = !DILocation(line: 248, column: 27, scope: !1144, inlinedAt: !2721)
!2725 = !DILocation(line: 248, column: 58, scope: !1144, inlinedAt: !2721)
!2726 = !DILocation(line: 250, column: 9, scope: !1143, inlinedAt: !2721)
!2727 = !DILocation(line: 0, scope: !1143, inlinedAt: !2721)
!2728 = !DILocation(line: 251, column: 28, scope: !1143, inlinedAt: !2721)
!2729 = !DILocation(line: 253, column: 13, scope: !1945, inlinedAt: !2721)
!2730 = !DILocation(line: 254, column: 9, scope: !1945, inlinedAt: !2721)
!2731 = !DILocation(line: 257, column: 5, scope: !1134, inlinedAt: !2721)
!2732 = !DILocation(line: 307, column: 9, scope: !2641)
!2733 = !DILocation(line: 0, scope: !1158, inlinedAt: !2734)
!2734 = distinct !DILocation(line: 309, column: 9, scope: !2641)
!2735 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !2734)
!2736 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !2734)
!2737 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !2734)
!2738 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !2734)
!2739 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !2734)
!2740 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !2734)
!2741 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !2734)
!2742 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !2734)
!2743 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !2734)
!2744 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !2734)
!2745 = !DILocation(line: 0, scope: !1187, inlinedAt: !2734)
!2746 = !DILocation(line: 310, column: 9, scope: !2641)
!2747 = !DILocation(line: 312, column: 9, scope: !2641)
!2748 = !DILocation(line: 313, column: 9, scope: !2641)
!2749 = !DILocation(line: 315, column: 31, scope: !2640)
!2750 = !DILocation(line: 315, column: 42, scope: !2640)
!2751 = !DILocation(line: 315, column: 13, scope: !2641)
!2752 = !DILocation(line: 317, column: 64, scope: !2639)
!2753 = !DILocation(line: 317, column: 39, scope: !2639)
!2754 = !DILocation(line: 317, column: 26, scope: !2639)
!2755 = !DILocation(line: 317, column: 37, scope: !2639)
!2756 = !DILocation(line: 320, column: 55, scope: !2639)
!2757 = !DILocation(line: 319, column: 13, scope: !2639)
!2758 = !DILocation(line: 321, column: 23, scope: !2639)
!2759 = !DILocation(line: 0, scope: !2639)
!2760 = !DILocation(line: 322, column: 70, scope: !2639)
!2761 = !DILocation(line: 322, column: 52, scope: !2639)
!2762 = !DILocation(line: 322, column: 43, scope: !2639)
!2763 = !DILocation(line: 323, column: 33, scope: !2639)
!2764 = !DILocation(line: 322, column: 18, scope: !2639)
!2765 = !DILocation(line: 325, column: 20, scope: !2644)
!2766 = !DILocation(line: 325, column: 17, scope: !2639)
!2767 = !DILocation(line: 326, column: 17, scope: !2643)
!2768 = !DILocation(line: 326, column: 26, scope: !2643)
!2769 = distinct !DIAssignID()
!2770 = !DILocation(line: 327, column: 24, scope: !2643)
!2771 = !DILocation(line: 327, column: 47, scope: !2643)
!2772 = !DILocation(line: 327, column: 17, scope: !2643)
!2773 = !DILocation(line: 328, column: 24, scope: !2643)
!2774 = !DILocation(line: 328, column: 38, scope: !2643)
!2775 = !DILocation(line: 328, column: 17, scope: !2643)
!2776 = !DILocation(line: 329, column: 41, scope: !2643)
!2777 = !DILocation(line: 329, column: 20, scope: !2643)
!2778 = !DILocation(line: 329, column: 28, scope: !2643)
!2779 = !DILocation(line: 329, column: 36, scope: !2643)
!2780 = !DILocation(line: 331, column: 80, scope: !2781)
!2781 = distinct !DILexicalBlock(scope: !2643, file: !2, line: 331, column: 21)
!2782 = !DILocation(line: 331, column: 70, scope: !2781)
!2783 = !DILocation(line: 331, column: 91, scope: !2781)
!2784 = !DILocation(line: 331, column: 21, scope: !2781)
!2785 = !DILocation(line: 331, column: 21, scope: !2643)
!2786 = !DILocation(line: 332, column: 30, scope: !2787)
!2787 = distinct !DILexicalBlock(scope: !2781, file: !2, line: 331, column: 124)
!2788 = !DILocation(line: 332, column: 24, scope: !2787)
!2789 = !DILocation(line: 332, column: 28, scope: !2787)
!2790 = !DILocation(line: 0, scope: !1134, inlinedAt: !2791)
!2791 = distinct !DILocation(line: 333, column: 21, scope: !2787)
!2792 = !DILocation(line: 248, column: 13, scope: !1144, inlinedAt: !2791)
!2793 = !DILocation(line: 248, column: 21, scope: !1144, inlinedAt: !2791)
!2794 = !DILocation(line: 248, column: 27, scope: !1144, inlinedAt: !2791)
!2795 = !DILocation(line: 248, column: 58, scope: !1144, inlinedAt: !2791)
!2796 = !DILocation(line: 250, column: 9, scope: !1143, inlinedAt: !2791)
!2797 = !DILocation(line: 0, scope: !1143, inlinedAt: !2791)
!2798 = !DILocation(line: 251, column: 28, scope: !1143, inlinedAt: !2791)
!2799 = !DILocation(line: 253, column: 13, scope: !1945, inlinedAt: !2791)
!2800 = !DILocation(line: 254, column: 9, scope: !1945, inlinedAt: !2791)
!2801 = !DILocation(line: 0, scope: !1158, inlinedAt: !2802)
!2802 = distinct !DILocation(line: 335, column: 21, scope: !2803)
!2803 = distinct !DILexicalBlock(scope: !2781, file: !2, line: 334, column: 24)
!2804 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !2802)
!2805 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !2802)
!2806 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !2802)
!2807 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !2802)
!2808 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !2802)
!2809 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !2802)
!2810 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !2802)
!2811 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !2802)
!2812 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !2802)
!2813 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !2802)
!2814 = !DILocation(line: 0, scope: !2781)
!2815 = !DILocation(line: 338, column: 17, scope: !2643)
!2816 = !DILocation(line: 339, column: 13, scope: !2644)
!2817 = !DILocation(line: 339, column: 13, scope: !2643)
!2818 = !DILocation(line: 340, column: 17, scope: !2819)
!2819 = distinct !DILexicalBlock(scope: !2644, file: !2, line: 339, column: 20)
!2820 = !DILocation(line: 344, column: 36, scope: !2821)
!2821 = distinct !DILexicalBlock(scope: !2640, file: !2, line: 343, column: 16)
!2822 = !DILocation(line: 344, column: 44, scope: !2821)
!2823 = !DILocation(line: 344, column: 13, scope: !2821)
!2824 = !DILocation(line: 345, column: 20, scope: !2825)
!2825 = distinct !DILexicalBlock(scope: !2821, file: !2, line: 345, column: 17)
!2826 = !DILocation(line: 345, column: 24, scope: !2825)
!2827 = !DILocation(line: 0, scope: !2825)
!2828 = !DILocation(line: 350, column: 46, scope: !2821)
!2829 = !DILocation(line: 350, column: 13, scope: !2821)
!2830 = !DILocation(line: 0, scope: !1158, inlinedAt: !2831)
!2831 = distinct !DILocation(line: 352, column: 13, scope: !2821)
!2832 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !2831)
!2833 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !2831)
!2834 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !2831)
!2835 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !2831)
!2836 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !2831)
!2837 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !2831)
!2838 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !2831)
!2839 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !2831)
!2840 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !2831)
!2841 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !2831)
!2842 = !DILocation(line: 0, scope: !1187, inlinedAt: !2831)
!2843 = !DILocation(line: 0, scope: !1158, inlinedAt: !2844)
!2844 = distinct !DILocation(line: 356, column: 9, scope: !2641)
!2845 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !2844)
!2846 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !2844)
!2847 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !2844)
!2848 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !2844)
!2849 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !2844)
!2850 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !2844)
!2851 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !2844)
!2852 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !2844)
!2853 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !2844)
!2854 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !2844)
!2855 = !DILocation(line: 0, scope: !1187, inlinedAt: !2844)
!2856 = !DILocation(line: 357, column: 9, scope: !2641)
!2857 = !DILocation(line: 359, column: 1, scope: !2607)
!2858 = distinct !DISubprogram(name: "process_bin_append_prepend", scope: !2, file: !2, line: 1192, type: !606, scopeLine: 1192, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !2859)
!2859 = !{!2860, !2861, !2862, !2863, !2864}
!2860 = !DILocalVariable(name: "c", arg: 1, scope: !2858, file: !2, line: 1192, type: !608)
!2861 = !DILocalVariable(name: "key", scope: !2858, file: !2, line: 1193, type: !399)
!2862 = !DILocalVariable(name: "nkey", scope: !2858, file: !2, line: 1194, type: !383)
!2863 = !DILocalVariable(name: "vlen", scope: !2858, file: !2, line: 1195, type: !418)
!2864 = !DILocalVariable(name: "it", scope: !2858, file: !2, line: 1196, type: !440)
!2865 = !DILocation(line: 0, scope: !2858)
!2866 = !DILocation(line: 0, scope: !2096, inlinedAt: !2867)
!2867 = distinct !DILocation(line: 1200, column: 11, scope: !2858)
!2868 = !DILocation(line: 132, column: 15, scope: !2096, inlinedAt: !2867)
!2869 = !DILocation(line: 132, column: 49, scope: !2096, inlinedAt: !2867)
!2870 = !DILocation(line: 132, column: 21, scope: !2096, inlinedAt: !2867)
!2871 = !DILocation(line: 1202, column: 37, scope: !2858)
!2872 = !DILocation(line: 1202, column: 47, scope: !2858)
!2873 = !DILocation(line: 1202, column: 45, scope: !2858)
!2874 = !DILocation(line: 1204, column: 18, scope: !2875)
!2875 = distinct !DILexicalBlock(scope: !2858, file: !2, line: 1204, column: 9)
!2876 = !DILocation(line: 1204, column: 26, scope: !2875)
!2877 = !DILocation(line: 1204, column: 9, scope: !2858)
!2878 = !DILocation(line: 1205, column: 17, scope: !2879)
!2879 = distinct !DILexicalBlock(scope: !2875, file: !2, line: 1204, column: 31)
!2880 = !DILocation(line: 1205, column: 9, scope: !2879)
!2881 = !DILocation(line: 1206, column: 5, scope: !2879)
!2882 = !DILocation(line: 1208, column: 18, scope: !2883)
!2883 = distinct !DILexicalBlock(scope: !2858, file: !2, line: 1208, column: 9)
!2884 = !DILocation(line: 1208, column: 9, scope: !2883)
!2885 = !DILocation(line: 1208, column: 9, scope: !2858)
!2886 = !DILocation(line: 1209, column: 9, scope: !2887)
!2887 = distinct !DILexicalBlock(scope: !2883, file: !2, line: 1208, column: 34)
!2888 = !DILocation(line: 1210, column: 5, scope: !2887)
!2889 = !DILocation(line: 1212, column: 42, scope: !2858)
!2890 = !DILocation(line: 1212, column: 10, scope: !2858)
!2891 = !DILocation(line: 1214, column: 12, scope: !2892)
!2892 = distinct !DILexicalBlock(scope: !2858, file: !2, line: 1214, column: 9)
!2893 = !DILocation(line: 1214, column: 9, scope: !2858)
!2894 = !DILocation(line: 1215, column: 15, scope: !2895)
!2895 = distinct !DILexicalBlock(scope: !2896, file: !2, line: 1215, column: 13)
!2896 = distinct !DILexicalBlock(scope: !2892, file: !2, line: 1214, column: 18)
!2897 = !DILocation(line: 1215, column: 13, scope: !2896)
!2898 = !DILocation(line: 1216, column: 13, scope: !2899)
!2899 = distinct !DILexicalBlock(scope: !2895, file: !2, line: 1215, column: 48)
!2900 = !DILocation(line: 1217, column: 9, scope: !2899)
!2901 = !DILocation(line: 1218, column: 13, scope: !2902)
!2902 = distinct !DILexicalBlock(scope: !2895, file: !2, line: 1217, column: 16)
!2903 = !DILocation(line: 1220, column: 16, scope: !2902)
!2904 = !DILocation(line: 1220, column: 23, scope: !2902)
!2905 = !DILocation(line: 1223, column: 9, scope: !2896)
!2906 = !DILocation(line: 1224, column: 9, scope: !2896)
!2907 = !DILocation(line: 1227, column: 5, scope: !2908)
!2908 = distinct !DILexicalBlock(scope: !2909, file: !2, line: 1227, column: 5)
!2909 = distinct !DILexicalBlock(scope: !2858, file: !2, line: 1227, column: 5)
!2910 = !DILocation(line: 1227, column: 5, scope: !2909)
!2911 = !DILocation(line: 1227, column: 5, scope: !2912)
!2912 = distinct !DILexicalBlock(scope: !2908, file: !2, line: 1227, column: 5)
!2913 = !DILocation(line: 1229, column: 16, scope: !2858)
!2914 = !DILocation(line: 1229, column: 5, scope: !2858)
!2915 = !DILocation(line: 1235, column: 13, scope: !2916)
!2916 = distinct !DILexicalBlock(scope: !2858, file: !2, line: 1229, column: 21)
!2917 = !DILocation(line: 0, scope: !2916)
!2918 = !DILocation(line: 1240, column: 8, scope: !2858)
!2919 = !DILocation(line: 1240, column: 13, scope: !2858)
!2920 = !DILocation(line: 1248, column: 16, scope: !2858)
!2921 = !DILocation(line: 1248, column: 8, scope: !2858)
!2922 = !DILocation(line: 1248, column: 14, scope: !2858)
!2923 = !DILocation(line: 1250, column: 8, scope: !2858)
!2924 = !DILocation(line: 1250, column: 16, scope: !2858)
!2925 = !DILocation(line: 1251, column: 5, scope: !2858)
!2926 = !DILocation(line: 1252, column: 8, scope: !2858)
!2927 = !DILocation(line: 1252, column: 17, scope: !2858)
!2928 = !DILocation(line: 1253, column: 1, scope: !2858)
!2929 = distinct !DISubprogram(name: "process_bin_stat", scope: !2, file: !2, line: 609, type: !606, scopeLine: 609, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !2930)
!2930 = !{!2931, !2932, !2933, !2934, !2937, !2943, !2946}
!2931 = !DILocalVariable(name: "c", arg: 1, scope: !2929, file: !2, line: 609, type: !608)
!2932 = !DILocalVariable(name: "subcommand", scope: !2929, file: !2, line: 610, type: !399)
!2933 = !DILocalVariable(name: "nkey", scope: !2929, file: !2, line: 611, type: !868)
!2934 = !DILocalVariable(name: "ii", scope: !2935, file: !2, line: 614, type: !418)
!2935 = distinct !DILexicalBlock(scope: !2936, file: !2, line: 613, column: 31)
!2936 = distinct !DILexicalBlock(scope: !2929, file: !2, line: 613, column: 9)
!2937 = !DILocalVariable(name: "subcmd_pos", scope: !2938, file: !2, line: 631, type: !399)
!2938 = distinct !DILexicalBlock(scope: !2939, file: !2, line: 630, column: 55)
!2939 = distinct !DILexicalBlock(scope: !2940, file: !2, line: 630, column: 16)
!2940 = distinct !DILexicalBlock(scope: !2941, file: !2, line: 628, column: 16)
!2941 = distinct !DILexicalBlock(scope: !2942, file: !2, line: 626, column: 16)
!2942 = distinct !DILexicalBlock(scope: !2929, file: !2, line: 622, column: 9)
!2943 = !DILocalVariable(name: "len", scope: !2944, file: !2, line: 633, type: !418)
!2944 = distinct !DILexicalBlock(scope: !2945, file: !2, line: 632, column: 51)
!2945 = distinct !DILexicalBlock(scope: !2938, file: !2, line: 632, column: 13)
!2946 = !DILocalVariable(name: "dump_buf", scope: !2944, file: !2, line: 634, type: !399)
!2947 = distinct !DIAssignID()
!2948 = !DILocation(line: 0, scope: !2944)
!2949 = !DILocation(line: 0, scope: !2929)
!2950 = !DILocation(line: 0, scope: !2096, inlinedAt: !2951)
!2951 = distinct !DILocation(line: 610, column: 24, scope: !2929)
!2952 = !DILocation(line: 132, column: 15, scope: !2096, inlinedAt: !2951)
!2953 = !DILocation(line: 132, column: 49, scope: !2096, inlinedAt: !2951)
!2954 = !DILocation(line: 132, column: 21, scope: !2096, inlinedAt: !2951)
!2955 = !DILocation(line: 613, column: 18, scope: !2936)
!2956 = !DILocation(line: 613, column: 26, scope: !2936)
!2957 = !DILocation(line: 613, column: 9, scope: !2929)
!2958 = !DILocation(line: 615, column: 17, scope: !2935)
!2959 = !DILocation(line: 615, column: 42, scope: !2935)
!2960 = !DILocation(line: 615, column: 9, scope: !2935)
!2961 = !DILocation(line: 0, scope: !2935)
!2962 = !DILocation(line: 616, column: 25, scope: !2963)
!2963 = distinct !DILexicalBlock(scope: !2964, file: !2, line: 616, column: 9)
!2964 = distinct !DILexicalBlock(scope: !2935, file: !2, line: 616, column: 9)
!2965 = !DILocation(line: 616, column: 9, scope: !2964)
!2966 = !DILocation(line: 617, column: 21, scope: !2967)
!2967 = distinct !DILexicalBlock(scope: !2963, file: !2, line: 616, column: 39)
!2968 = !DILocation(line: 617, column: 35, scope: !2967)
!2969 = !DILocation(line: 617, column: 13, scope: !2967)
!2970 = !DILocation(line: 616, column: 33, scope: !2963)
!2971 = distinct !{!2971, !2965, !2972, !1496}
!2972 = !DILocation(line: 618, column: 9, scope: !2964)
!2973 = !DILocation(line: 619, column: 17, scope: !2935)
!2974 = !DILocation(line: 619, column: 9, scope: !2935)
!2975 = !DILocation(line: 620, column: 5, scope: !2935)
!2976 = !DILocation(line: 622, column: 14, scope: !2942)
!2977 = !DILocation(line: 622, column: 9, scope: !2929)
!2978 = !DILocation(line: 624, column: 9, scope: !2979)
!2979 = distinct !DILexicalBlock(scope: !2942, file: !2, line: 622, column: 20)
!2980 = !DILocation(line: 625, column: 15, scope: !2979)
!2981 = !DILocation(line: 626, column: 5, scope: !2979)
!2982 = !DILocation(line: 626, column: 16, scope: !2941)
!2983 = !DILocation(line: 626, column: 48, scope: !2941)
!2984 = !DILocation(line: 626, column: 16, scope: !2942)
!2985 = !DILocation(line: 627, column: 9, scope: !2986)
!2986 = distinct !DILexicalBlock(scope: !2941, file: !2, line: 626, column: 54)
!2987 = !DILocation(line: 628, column: 5, scope: !2986)
!2988 = !DILocation(line: 628, column: 16, scope: !2940)
!2989 = !DILocation(line: 628, column: 51, scope: !2940)
!2990 = !DILocation(line: 628, column: 16, scope: !2941)
!2991 = !DILocation(line: 629, column: 9, scope: !2992)
!2992 = distinct !DILexicalBlock(scope: !2940, file: !2, line: 628, column: 57)
!2993 = !DILocation(line: 630, column: 5, scope: !2992)
!2994 = !DILocation(line: 630, column: 16, scope: !2939)
!2995 = !DILocation(line: 630, column: 49, scope: !2939)
!2996 = !DILocation(line: 630, column: 16, scope: !2940)
!2997 = !DILocation(line: 631, column: 39, scope: !2938)
!2998 = !DILocation(line: 0, scope: !2938)
!2999 = !DILocation(line: 632, column: 13, scope: !2945)
!3000 = !DILocation(line: 632, column: 45, scope: !2945)
!3001 = !DILocation(line: 632, column: 13, scope: !2938)
!3002 = !DILocation(line: 633, column: 13, scope: !2944)
!3003 = !DILocation(line: 634, column: 30, scope: !2944)
!3004 = !DILocation(line: 635, column: 26, scope: !3005)
!3005 = distinct !DILexicalBlock(scope: !2944, file: !2, line: 635, column: 17)
!3006 = !DILocation(line: 635, column: 34, scope: !3005)
!3007 = !DILocation(line: 636, column: 17, scope: !3008)
!3008 = distinct !DILexicalBlock(scope: !3005, file: !2, line: 635, column: 47)
!3009 = !DILocation(line: 637, column: 21, scope: !3008)
!3010 = !DILocation(line: 635, column: 37, scope: !3005)
!3011 = !DILocation(line: 635, column: 41, scope: !3005)
!3012 = !DILocation(line: 635, column: 17, scope: !2944)
!3013 = !DILocation(line: 638, column: 21, scope: !3014)
!3014 = distinct !DILexicalBlock(scope: !3008, file: !2, line: 637, column: 21)
!3015 = !DILocation(line: 641, column: 17, scope: !3016)
!3016 = distinct !DILexicalBlock(scope: !3005, file: !2, line: 640, column: 20)
!3017 = !DILocation(line: 642, column: 17, scope: !3016)
!3018 = !DILocation(line: 644, column: 9, scope: !2945)
!3019 = !DILocation(line: 644, column: 50, scope: !3020)
!3020 = distinct !DILexicalBlock(scope: !2945, file: !2, line: 644, column: 20)
!3021 = !DILocation(line: 644, column: 20, scope: !2945)
!3022 = !DILocation(line: 645, column: 37, scope: !3023)
!3023 = distinct !DILexicalBlock(scope: !3020, file: !2, line: 644, column: 56)
!3024 = !DILocation(line: 646, column: 9, scope: !3023)
!3025 = !DILocation(line: 646, column: 20, scope: !3026)
!3026 = distinct !DILexicalBlock(scope: !3020, file: !2, line: 646, column: 20)
!3027 = !DILocation(line: 646, column: 51, scope: !3026)
!3028 = !DILocation(line: 646, column: 20, scope: !3020)
!3029 = !DILocation(line: 647, column: 37, scope: !3030)
!3030 = distinct !DILexicalBlock(scope: !3026, file: !2, line: 646, column: 57)
!3031 = !DILocation(line: 0, scope: !1158, inlinedAt: !3032)
!3032 = distinct !DILocation(line: 649, column: 13, scope: !3033)
!3033 = distinct !DILexicalBlock(scope: !3026, file: !2, line: 648, column: 16)
!3034 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !3032)
!3035 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !3032)
!3036 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !3032)
!3037 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !3032)
!3038 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !3032)
!3039 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !3032)
!3040 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !3032)
!3041 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !3032)
!3042 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !3032)
!3043 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !3032)
!3044 = !DILocation(line: 0, scope: !1187, inlinedAt: !3032)
!3045 = !DILocation(line: 650, column: 13, scope: !3033)
!3046 = !DILocation(line: 653, column: 35, scope: !3047)
!3047 = distinct !DILexicalBlock(scope: !3048, file: !2, line: 653, column: 13)
!3048 = distinct !DILexicalBlock(scope: !2939, file: !2, line: 652, column: 12)
!3049 = !DILocation(line: 653, column: 13, scope: !3047)
!3050 = !DILocation(line: 653, column: 13, scope: !3048)
!3051 = !DILocation(line: 654, column: 20, scope: !3052)
!3052 = distinct !DILexicalBlock(scope: !3053, file: !2, line: 654, column: 17)
!3053 = distinct !DILexicalBlock(scope: !3047, file: !2, line: 653, column: 60)
!3054 = !DILocation(line: 654, column: 26, scope: !3052)
!3055 = !{!1017, !1018, i64 368}
!3056 = !DILocation(line: 654, column: 33, scope: !3052)
!3057 = !DILocation(line: 654, column: 17, scope: !3053)
!3058 = !DILocation(line: 655, column: 17, scope: !3059)
!3059 = distinct !DILexicalBlock(scope: !3052, file: !2, line: 654, column: 42)
!3060 = !DILocation(line: 656, column: 13, scope: !3059)
!3061 = !DILocation(line: 657, column: 61, scope: !3062)
!3062 = distinct !DILexicalBlock(scope: !3052, file: !2, line: 656, column: 20)
!3063 = !{!1017, !1028, i64 384}
!3064 = !DILocation(line: 657, column: 52, scope: !3062)
!3065 = !DILocation(line: 657, column: 17, scope: !3062)
!3066 = !DILocation(line: 658, column: 33, scope: !3062)
!3067 = !DILocation(line: 0, scope: !1158, inlinedAt: !3068)
!3068 = distinct !DILocation(line: 661, column: 13, scope: !3069)
!3069 = distinct !DILexicalBlock(scope: !3047, file: !2, line: 660, column: 16)
!3070 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !3068)
!3071 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !3068)
!3072 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !3068)
!3073 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !3068)
!3074 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !3068)
!3075 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !3068)
!3076 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !3068)
!3077 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !3068)
!3078 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !3068)
!3079 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !3068)
!3080 = !DILocation(line: 0, scope: !1187, inlinedAt: !3068)
!3081 = !DILocation(line: 668, column: 5, scope: !2929)
!3082 = !DILocation(line: 669, column: 12, scope: !3083)
!3083 = distinct !DILexicalBlock(scope: !2929, file: !2, line: 669, column: 9)
!3084 = !DILocation(line: 669, column: 18, scope: !3083)
!3085 = !DILocation(line: 669, column: 25, scope: !3083)
!3086 = !DILocation(line: 669, column: 9, scope: !2929)
!3087 = !DILocation(line: 670, column: 9, scope: !3088)
!3088 = distinct !DILexicalBlock(scope: !3083, file: !2, line: 669, column: 34)
!3089 = !DILocation(line: 671, column: 5, scope: !3088)
!3090 = !DILocation(line: 672, column: 53, scope: !3091)
!3091 = distinct !DILexicalBlock(scope: !3083, file: !2, line: 671, column: 12)
!3092 = !DILocation(line: 672, column: 44, scope: !3091)
!3093 = !DILocation(line: 672, column: 9, scope: !3091)
!3094 = !DILocation(line: 673, column: 25, scope: !3091)
!3095 = !DILocation(line: 675, column: 1, scope: !2929)
!3096 = distinct !DISubprogram(name: "bin_list_sasl_mechs", scope: !2, file: !2, line: 700, type: !606, scopeLine: 700, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !3097)
!3097 = !{!3098, !3099, !3100, !3101}
!3098 = !DILocalVariable(name: "c", arg: 1, scope: !3096, file: !2, line: 700, type: !608)
!3099 = !DILocalVariable(name: "result_string", scope: !3096, file: !2, line: 710, type: !1161)
!3100 = !DILocalVariable(name: "string_length", scope: !3096, file: !2, line: 711, type: !206)
!3101 = !DILocalVariable(name: "result", scope: !3096, file: !2, line: 712, type: !418)
!3102 = !DILocation(line: 0, scope: !3096)
!3103 = !DILocation(line: 702, column: 19, scope: !3104)
!3104 = distinct !DILexicalBlock(scope: !3096, file: !2, line: 702, column: 9)
!3105 = !DILocation(line: 702, column: 9, scope: !3096)
!3106 = !DILocation(line: 704, column: 50, scope: !3107)
!3107 = distinct !DILexicalBlock(scope: !3104, file: !2, line: 702, column: 25)
!3108 = !DILocation(line: 705, column: 52, scope: !3107)
!3109 = !DILocation(line: 705, column: 27, scope: !3107)
!3110 = !DILocation(line: 705, column: 25, scope: !3107)
!3111 = !DILocation(line: 703, column: 9, scope: !3107)
!3112 = !DILocation(line: 706, column: 9, scope: !3107)
!3113 = !DILocation(line: 0, scope: !1242, inlinedAt: !3114)
!3114 = distinct !DILocation(line: 709, column: 5, scope: !3096)
!3115 = !DILocation(line: 683, column: 8, scope: !1242, inlinedAt: !3114)
!3116 = !DILocation(line: 683, column: 22, scope: !1242, inlinedAt: !3114)
!3117 = !DILocation(line: 685, column: 13, scope: !1246, inlinedAt: !3114)
!3118 = !DILocation(line: 685, column: 10, scope: !1246, inlinedAt: !3114)
!3119 = !DILocation(line: 720, column: 22, scope: !3120)
!3120 = distinct !DILexicalBlock(scope: !3121, file: !2, line: 720, column: 13)
!3121 = distinct !DILexicalBlock(scope: !3122, file: !2, line: 718, column: 28)
!3122 = distinct !DILexicalBlock(scope: !3096, file: !2, line: 718, column: 9)
!3123 = !DILocation(line: 685, column: 9, scope: !1242, inlinedAt: !3114)
!3124 = !DILocation(line: 0, scope: !1245, inlinedAt: !3114)
!3125 = !DILocation(line: 692, column: 17, scope: !1262, inlinedAt: !3114)
!3126 = !DILocation(line: 692, column: 17, scope: !1263, inlinedAt: !3114)
!3127 = !DILocation(line: 693, column: 25, scope: !1268, inlinedAt: !3114)
!3128 = !DILocation(line: 693, column: 17, scope: !1268, inlinedAt: !3114)
!3129 = !DILocation(line: 694, column: 13, scope: !1268, inlinedAt: !3114)
!3130 = !DILocation(line: 695, column: 26, scope: !1263, inlinedAt: !3114)
!3131 = !DILocation(line: 697, column: 5, scope: !1245, inlinedAt: !3114)
!3132 = !DILocation(line: 720, column: 13, scope: !3120)
!3133 = !DILocation(line: 720, column: 13, scope: !3121)
!3134 = !DILocation(line: 721, column: 21, scope: !3135)
!3135 = distinct !DILexicalBlock(scope: !3120, file: !2, line: 720, column: 31)
!3136 = !DILocation(line: 721, column: 13, scope: !3135)
!3137 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !3138)
!3138 = distinct !DILocation(line: 723, column: 9, scope: !3121)
!3139 = !DILocation(line: 0, scope: !1158, inlinedAt: !3138)
!3140 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !3138)
!3141 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !3138)
!3142 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !3138)
!3143 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !3138)
!3144 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !3138)
!3145 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !3138)
!3146 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !3138)
!3147 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !3138)
!3148 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !3138)
!3149 = !DILocation(line: 0, scope: !1187, inlinedAt: !3138)
!3150 = !DILocation(line: 727, column: 1, scope: !3096)
!3151 = distinct !DISubprogram(name: "process_bin_sasl_auth", scope: !2, file: !2, line: 729, type: !606, scopeLine: 729, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !202, retainedNodes: !3152)
!3152 = !{!3153, !3154, !3155, !3156, !3157}
!3153 = !DILocalVariable(name: "c", arg: 1, scope: !3151, file: !2, line: 729, type: !608)
!3154 = !DILocalVariable(name: "nkey", scope: !3151, file: !2, line: 740, type: !383)
!3155 = !DILocalVariable(name: "vlen", scope: !3151, file: !2, line: 741, type: !418)
!3156 = !DILocalVariable(name: "key", scope: !3151, file: !2, line: 749, type: !399)
!3157 = !DILocalVariable(name: "it", scope: !3151, file: !2, line: 752, type: !440)
!3158 = !DILocation(line: 0, scope: !3151)
!3159 = !DILocation(line: 731, column: 19, scope: !3160)
!3160 = distinct !DILexicalBlock(scope: !3151, file: !2, line: 731, column: 9)
!3161 = !DILocation(line: 731, column: 9, scope: !3151)
!3162 = !DILocation(line: 733, column: 50, scope: !3163)
!3163 = distinct !DILexicalBlock(scope: !3160, file: !2, line: 731, column: 25)
!3164 = !DILocation(line: 734, column: 52, scope: !3163)
!3165 = !DILocation(line: 734, column: 27, scope: !3163)
!3166 = !DILocation(line: 734, column: 25, scope: !3163)
!3167 = !DILocation(line: 732, column: 9, scope: !3163)
!3168 = !DILocation(line: 735, column: 9, scope: !3163)
!3169 = !DILocation(line: 740, column: 46, scope: !3151)
!3170 = !DILocation(line: 741, column: 41, scope: !3151)
!3171 = !DILocation(line: 741, column: 51, scope: !3151)
!3172 = !DILocation(line: 741, column: 49, scope: !3151)
!3173 = !DILocation(line: 743, column: 14, scope: !3174)
!3174 = distinct !DILexicalBlock(scope: !3151, file: !2, line: 743, column: 9)
!3175 = !DILocation(line: 743, column: 9, scope: !3151)
!3176 = !DILocation(line: 744, column: 9, scope: !3177)
!3177 = distinct !DILexicalBlock(scope: !3174, file: !2, line: 743, column: 35)
!3178 = !DILocation(line: 745, column: 9, scope: !3177)
!3179 = !DILocation(line: 746, column: 9, scope: !3177)
!3180 = !DILocation(line: 0, scope: !2096, inlinedAt: !3181)
!3181 = distinct !DILocation(line: 749, column: 17, scope: !3151)
!3182 = !DILocation(line: 132, column: 15, scope: !2096, inlinedAt: !3181)
!3183 = !DILocation(line: 132, column: 21, scope: !2096, inlinedAt: !3181)
!3184 = !DILocation(line: 752, column: 48, scope: !3151)
!3185 = !DILocation(line: 752, column: 16, scope: !3151)
!3186 = !DILocation(line: 755, column: 12, scope: !3187)
!3187 = distinct !DILexicalBlock(scope: !3151, file: !2, line: 755, column: 9)
!3188 = !DILocation(line: 755, column: 17, scope: !3187)
!3189 = !DILocation(line: 755, column: 25, scope: !3187)
!3190 = !DILocation(line: 755, column: 34, scope: !3187)
!3191 = !DILocation(line: 755, column: 9, scope: !3151)
!3192 = !DILocation(line: 756, column: 9, scope: !3193)
!3193 = distinct !DILexicalBlock(scope: !3187, file: !2, line: 755, column: 51)
!3194 = !DILocation(line: 757, column: 9, scope: !3193)
!3195 = !DILocation(line: 759, column: 13, scope: !3196)
!3196 = distinct !DILexicalBlock(scope: !3197, file: !2, line: 758, column: 17)
!3197 = distinct !DILexicalBlock(scope: !3193, file: !2, line: 758, column: 13)
!3198 = !DILocation(line: 760, column: 9, scope: !3196)
!3199 = !DILocation(line: 764, column: 8, scope: !3151)
!3200 = !DILocation(line: 764, column: 13, scope: !3151)
!3201 = !DILocation(line: 765, column: 16, scope: !3151)
!3202 = !DILocation(line: 765, column: 8, scope: !3151)
!3203 = !DILocation(line: 765, column: 14, scope: !3151)
!3204 = !DILocation(line: 766, column: 8, scope: !3151)
!3205 = !DILocation(line: 766, column: 16, scope: !3151)
!3206 = !DILocation(line: 767, column: 5, scope: !3151)
!3207 = !DILocation(line: 768, column: 8, scope: !3151)
!3208 = !DILocation(line: 768, column: 17, scope: !3151)
!3209 = !DILocation(line: 769, column: 1, scope: !3151)
!3210 = !DILocation(line: 758, column: 13, scope: !3193)
!3211 = !DISubprogram(name: "realtime", scope: !205, file: !205, line: 1050, type: !3212, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3212 = !DISubroutineType(types: !3213)
!3213 = !{!415, !3214}
!3214 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !1986)
!3215 = !DISubprogram(name: "item_flush_expired", scope: !1384, file: !1384, line: 50, type: !3216, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3216 = !DISubroutineType(types: !3217)
!3217 = !{null}
!3218 = !DISubprogram(name: "stats_prefix_record_set", scope: !3219, file: !3219, line: 31, type: !3220, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3219 = !DIFile(filename: "./stats_prefix.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "c26de3f3a40668b5f799218415be0cc4")
!3220 = !DISubroutineType(types: !3221)
!3221 = !{null, !1161, !3222}
!3222 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !868)
!3223 = !DISubprogram(name: "item_alloc", scope: !205, file: !205, line: 1006, type: !3224, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3224 = !DISubroutineType(types: !3225)
!3225 = !{!440, !1161, !868, !561, !415, !418}
!3226 = !DISubprogram(name: "item_size_ok", scope: !1384, file: !1384, line: 18, type: !3227, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3227 = !DISubroutineType(types: !3228)
!3228 = !{!618, !3222, !3229, !3230}
!3229 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !561)
!3230 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !418)
!3231 = !DISubprogram(name: "out_of_memory", scope: !205, file: !205, line: 1065, type: !1580, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3232 = !DISubprogram(name: "pthread_getspecific", scope: !1919, file: !1919, line: 1305, type: !3233, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3233 = !DISubroutineType(types: !3234)
!3234 = !{!365, !3235}
!3235 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_key_t", file: !451, line: 49, baseType: !206)
!3236 = !DISubprogram(name: "logger_log", scope: !239, file: !239, line: 238, type: !3237, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3237 = !DISubroutineType(types: !3238)
!3238 = !{!352, !442, !3239, !531, null}
!3239 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !238)
!3240 = !DISubprogram(name: "item_get", scope: !205, file: !205, line: 1009, type: !3241, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3241 = !DISubroutineType(types: !3242)
!3242 = !{!440, !1161, !3222, !722, !3243}
!3243 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !618)
!3244 = !DISubprogram(name: "item_unlink", scope: !205, file: !205, line: 1015, type: !1385, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3245 = !DISubprogram(name: "storage_delete", scope: !3246, file: !3246, line: 4, type: !3247, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3246 = !DIFile(filename: "./storage.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d18dbd8a1337d7561522237d8930ae7f")
!3247 = !DISubroutineType(types: !3248)
!3248 = !{null, !365, !440}
!3249 = !DISubprogram(name: "fwrite", scope: !1388, file: !1388, line: 745, type: !3250, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3250 = !DISubroutineType(types: !3251)
!3251 = !{!394, !3252, !868, !868, !1391}
!3252 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !531)
!3253 = !DISubprogram(name: "fputc", scope: !1388, file: !1388, line: 611, type: !3254, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3254 = !DISubroutineType(types: !3255)
!3255 = !{!418, !418, !1392}
!3256 = !DISubprogram(name: "item_touch", scope: !205, file: !205, line: 1011, type: !3257, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3257 = !DISubroutineType(types: !3258)
!3258 = !{!440, !1161, !3222, !388, !722}
!3259 = !DISubprogram(name: "storage_get_item", scope: !3246, file: !3246, line: 18, type: !3260, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3260 = !DISubroutineType(types: !3261)
!3261 = !{!418, !608, !440, !710}
!3262 = !DISubprogram(name: "resp_add_chunked_iov", scope: !205, file: !205, line: 1056, type: !1912, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3263 = !DILocation(line: 0, scope: !2447)
!3264 = !DILocation(line: 446, column: 9, scope: !2455)
!3265 = !DILocation(line: 446, column: 9, scope: !2447)
!3266 = !DILocation(line: 448, column: 20, scope: !2454)
!3267 = !DILocation(line: 448, column: 26, scope: !2454)
!3268 = !DILocation(line: 447, column: 9, scope: !2454)
!3269 = !DILocation(line: 449, column: 24, scope: !2454)
!3270 = !DILocation(line: 449, column: 35, scope: !2454)
!3271 = !DILocation(line: 0, scope: !2454)
!3272 = !DILocation(line: 450, column: 9, scope: !2454)
!3273 = !DILocation(line: 451, column: 25, scope: !2454)
!3274 = !DILocation(line: 451, column: 9, scope: !2454)
!3275 = !DILocation(line: 453, column: 5, scope: !2454)
!3276 = !DILocation(line: 0, scope: !1158, inlinedAt: !3277)
!3277 = distinct !DILocation(line: 454, column: 9, scope: !2461)
!3278 = !DILocation(line: 219, column: 18, scope: !1171, inlinedAt: !3277)
!3279 = !DILocation(line: 219, column: 26, scope: !1171, inlinedAt: !3277)
!3280 = !DILocation(line: 219, column: 9, scope: !1158, inlinedAt: !3277)
!3281 = !DILocation(line: 220, column: 17, scope: !1176, inlinedAt: !3277)
!3282 = !DILocation(line: 220, column: 58, scope: !1176, inlinedAt: !3277)
!3283 = !DILocation(line: 220, column: 9, scope: !1176, inlinedAt: !3277)
!3284 = !DILocation(line: 221, column: 5, scope: !1176, inlinedAt: !3277)
!3285 = !DILocation(line: 224, column: 5, scope: !1158, inlinedAt: !3277)
!3286 = !DILocation(line: 226, column: 25, scope: !1182, inlinedAt: !3277)
!3287 = !DILocation(line: 226, column: 9, scope: !1182, inlinedAt: !3277)
!3288 = !DILocation(line: 0, scope: !2455)
!3289 = !DILocation(line: 457, column: 1, scope: !2447)
!3290 = !DISubprogram(name: "stats_prefix_record_get", scope: !3219, file: !3219, line: 25, type: !3291, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3291 = !DISubroutineType(types: !3292)
!3292 = !{null, !1161, !3222, !3243}
!3293 = !DISubprogram(name: "stats_prefix_record_delete", scope: !3219, file: !3219, line: 28, type: !3220, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3294 = !DISubprogram(name: "item_get_locked", scope: !205, file: !205, line: 1010, type: !3295, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3295 = !DISubroutineType(types: !3296)
!3296 = !{!440, !1161, !3222, !722, !3243, !3297}
!3297 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !388, size: 64)
!3298 = !DISubprogram(name: "do_item_unlink", scope: !1384, file: !1384, line: 21, type: !3299, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3299 = !DISubroutineType(types: !3300)
!3300 = !{null, !440, !3301}
!3301 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !388)
!3302 = !DISubprogram(name: "item_unlock", scope: !205, file: !205, line: 1020, type: !3303, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3303 = !DISubroutineType(types: !3304)
!3304 = !{null, !388}
!3305 = !DISubprogram(name: "add_delta", scope: !205, file: !205, line: 999, type: !3306, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3306 = !DISubroutineType(types: !3307)
!3307 = !{!357, !722, !1161, !3222, !618, !3308, !399, !1928}
!3308 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !3309)
!3309 = !DIDerivedType(tag: DW_TAG_typedef, name: "int64_t", file: !3310, line: 27, baseType: !3311)
!3310 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h", directory: "", checksumkind: CSK_MD5, checksum: "649b383a60bfa3eb90e85840b2b0be20")
!3311 = !DIDerivedType(tag: DW_TAG_typedef, name: "__int64_t", file: !367, line: 44, baseType: !476)
!3312 = !DISubprogram(name: "strtoull", linkageName: "__isoc23_strtoull", scope: !3313, file: !3313, line: 243, type: !3314, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3313 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!3314 = !DISubroutineType(types: !3315)
!3315 = !{!579, !1442, !3316, !418}
!3316 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !3317)
!3317 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !399, size: 64)
!3318 = !DISubprogram(name: "snprintf", scope: !1388, file: !1388, line: 385, type: !3319, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3319 = !DISubroutineType(types: !3320)
!3320 = !{!418, !3321, !868, !1442, null}
!3321 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !399)
!3322 = !DISubprogram(name: "server_stats", scope: !205, file: !205, line: 1068, type: !3323, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3323 = !DISubroutineType(types: !3324)
!3324 = !{null, !3325, !365}
!3325 = !DIDerivedType(tag: DW_TAG_typedef, name: "ADD_STAT", file: !205, line: 194, baseType: !3326)
!3326 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3327, size: 64)
!3327 = !DISubroutineType(types: !3328)
!3328 = !{null, !1161, !3329, !1161, !3301, !531}
!3329 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !383)
!3330 = !DISubprogram(name: "append_stats", scope: !205, file: !205, line: 1069, type: !3327, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3331 = !DISubprogram(name: "get_stats", scope: !205, file: !205, line: 1073, type: !3332, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3332 = !DISubroutineType(types: !3333)
!3333 = !{!618, !1161, !418, !3325, !365}
!3334 = !DISubprogram(name: "strncmp", scope: !1831, file: !1831, line: 159, type: !3335, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3335 = !DISubroutineType(types: !3336)
!3336 = !{!418, !1161, !1161, !868}
!3337 = !DISubprogram(name: "stats_reset", scope: !205, file: !205, line: 1074, type: !3216, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3338 = !DISubprogram(name: "process_stat_settings", scope: !205, file: !205, line: 1075, type: !3323, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3339 = !DISubprogram(name: "stats_prefix_dump", scope: !3219, file: !3219, line: 37, type: !3340, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3340 = !DISubroutineType(types: !3341)
!3341 = !{!399, !1927}
!3342 = !DISubprogram(name: "free", scope: !3313, file: !3313, line: 687, type: !3343, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3343 = !DISubroutineType(types: !3344)
!3344 = !{null, !365}
!3345 = !DISubprogram(name: "write_and_free", scope: !205, file: !205, line: 1067, type: !3346, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3346 = !DISubroutineType(types: !3347)
!3347 = !{null, !608, !399, !418}
