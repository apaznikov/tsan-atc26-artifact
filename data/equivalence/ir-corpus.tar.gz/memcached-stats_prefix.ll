; ModuleID = 'stats_prefix.c'
source_filename = "stats_prefix.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@prefix_delimiter = internal unnamed_addr global i8 0, align 1, !dbg !0
@prefix_stats = internal unnamed_addr global [256 x ptr] zeroinitializer, align 16, !dbg !30
@num_prefixes = internal unnamed_addr global i32 0, align 4, !dbg !55
@total_prefix_size = internal unnamed_addr global i32 0, align 4, !dbg !58
@hash = external local_unnamed_addr global ptr, align 8
@.str = private unnamed_addr constant [49 x i8] c"Can't allocate space for stats structure: calloc\00", align 1, !dbg !7
@.str.1 = private unnamed_addr constant [48 x i8] c"Can't allocate space for copy of prefix: malloc\00", align 1, !dbg !13
@.str.2 = private unnamed_addr constant [48 x i8] c"PREFIX %s get %llu hit %llu set %llu del %llu\0D\0A\00", align 1, !dbg !18
@.str.3 = private unnamed_addr constant [38 x i8] c"Can't allocate stats response: malloc\00", align 1, !dbg !20
@.str.4 = private unnamed_addr constant [6 x i8] c"END\0D\0A\00", align 1, !dbg !25
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local void @stats_prefix_init(i8 noundef signext %delimiter) local_unnamed_addr #0 !dbg !68 {
entry:
  tail call void @llvm.dbg.value(metadata i8 %delimiter, metadata !72, metadata !DIExpression()), !dbg !73
  store i8 %delimiter, ptr @prefix_delimiter, align 1, !dbg !74, !tbaa !75
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(2048) @prefix_stats, i8 0, i64 2048, i1 false), !dbg !78
  ret void, !dbg !79
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #1

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @stats_prefix_clear() local_unnamed_addr #2 !dbg !80 {
entry:
  tail call void @llvm.dbg.value(metadata i32 0, metadata !84, metadata !DIExpression()), !dbg !90
  br label %for.body, !dbg !91

for.body:                                         ; preds = %entry, %for.end
  %indvars.iv = phi i64 [ 0, %entry ], [ %indvars.iv.next, %for.end ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !84, metadata !DIExpression()), !dbg !90
  %arrayidx = getelementptr inbounds [256 x ptr], ptr @prefix_stats, i64 0, i64 %indvars.iv, !dbg !92
  %0 = load ptr, ptr %arrayidx, align 8, !dbg !92, !tbaa !94
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !85, metadata !DIExpression()), !dbg !96
  %cmp2.not15 = icmp eq ptr %0, null, !dbg !97
  br i1 %cmp2.not15, label %for.end, label %for.body3, !dbg !99

for.body3:                                        ; preds = %for.body, %for.body3
  %cur.016 = phi ptr [ %1, %for.body3 ], [ %0, %for.body ]
  tail call void @llvm.dbg.value(metadata ptr %cur.016, metadata !85, metadata !DIExpression()), !dbg !96
  %next4 = getelementptr inbounds i8, ptr %cur.016, i64 48, !dbg !100
  %1 = load ptr, ptr %next4, align 8, !dbg !100, !tbaa !102
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !89, metadata !DIExpression()), !dbg !96
  %2 = load ptr, ptr %cur.016, align 8, !dbg !105, !tbaa !106
  tail call void @free(ptr noundef %2) #14, !dbg !107
  tail call void @free(ptr noundef nonnull %cur.016) #14, !dbg !108
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !85, metadata !DIExpression()), !dbg !96
  %cmp2.not = icmp eq ptr %1, null, !dbg !97
  br i1 %cmp2.not, label %for.end, label %for.body3, !dbg !99, !llvm.loop !109

for.end:                                          ; preds = %for.body3, %for.body
  store ptr null, ptr %arrayidx, align 8, !dbg !112, !tbaa !94
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !113
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !84, metadata !DIExpression()), !dbg !90
  %exitcond.not = icmp eq i64 %indvars.iv.next, 256, !dbg !114
  br i1 %exitcond.not, label %for.end8, label %for.body, !dbg !91, !llvm.loop !115

for.end8:                                         ; preds = %for.end
  store i32 0, ptr @num_prefixes, align 4, !dbg !117, !tbaa !118
  store i32 0, ptr @total_prefix_size, align 4, !dbg !120, !tbaa !118
  ret void, !dbg !121
}

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !122 void @free(ptr allocptr nocapture noundef) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef ptr @stats_prefix_find(ptr noundef %key, i64 noundef %nkey) local_unnamed_addr #2 !dbg !126 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !133, metadata !DIExpression()), !dbg !143
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !134, metadata !DIExpression()), !dbg !143
  tail call void @llvm.dbg.value(metadata i8 1, metadata !141, metadata !DIExpression()), !dbg !143
  tail call void @llvm.dbg.value(metadata i64 0, metadata !140, metadata !DIExpression()), !dbg !143
  %cmp82.not = icmp eq i64 %nkey, 0, !dbg !144
  br i1 %cmp82.not, label %cleanup, label %land.rhs, !dbg !147

land.rhs:                                         ; preds = %entry, %for.inc
  %length.083 = phi i64 [ %inc, %for.inc ], [ 0, %entry ]
  tail call void @llvm.dbg.value(metadata i64 %length.083, metadata !140, metadata !DIExpression()), !dbg !143
  %arrayidx = getelementptr inbounds i8, ptr %key, i64 %length.083, !dbg !148
  %0 = load i8, ptr %arrayidx, align 1, !dbg !148, !tbaa !75
  %cmp1.not = icmp eq i8 %0, 0, !dbg !149
  br i1 %cmp1.not, label %cleanup, label %for.body, !dbg !150

for.body:                                         ; preds = %land.rhs
  %1 = load i8, ptr @prefix_delimiter, align 1, !dbg !151, !tbaa !75
  %cmp6 = icmp eq i8 %0, %1, !dbg !154
  br i1 %cmp6, label %if.end9, label %for.inc, !dbg !155

for.inc:                                          ; preds = %for.body
  %inc = add nuw i64 %length.083, 1, !dbg !156
  tail call void @llvm.dbg.value(metadata i64 %inc, metadata !140, metadata !DIExpression()), !dbg !143
  %exitcond.not = icmp eq i64 %inc, %nkey, !dbg !144
  br i1 %exitcond.not, label %cleanup, label %land.rhs, !dbg !147, !llvm.loop !157

if.end9:                                          ; preds = %for.body
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !141, metadata !DIExpression()), !dbg !143
  %2 = load ptr, ptr @hash, align 8, !dbg !159, !tbaa !94
  %call = tail call i32 %2(ptr noundef nonnull %key, i64 noundef %length.083) #14, !dbg !159
  %rem = and i32 %call, 255, !dbg !160
  tail call void @llvm.dbg.value(metadata i32 %rem, metadata !136, metadata !DIExpression()), !dbg !143
  %idxprom = zext nneg i32 %rem to i64, !dbg !161
  %arrayidx10 = getelementptr inbounds [256 x ptr], ptr @prefix_stats, i64 0, i64 %idxprom, !dbg !161
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !135, metadata !DIExpression()), !dbg !143
  %pfs.084 = load ptr, ptr %arrayidx10, align 8, !dbg !163, !tbaa !94
  %cmp12.not85 = icmp eq ptr %pfs.084, null, !dbg !164
  br i1 %cmp12.not85, label %for.end21, label %for.body14, !dbg !166

for.body14:                                       ; preds = %if.end9, %for.inc20
  %pfs.086 = phi ptr [ %pfs.0, %for.inc20 ], [ %pfs.084, %if.end9 ]
  %3 = load ptr, ptr %pfs.086, align 8, !dbg !167, !tbaa !106
  %call15 = tail call i32 @strncmp(ptr noundef %3, ptr noundef %key, i64 noundef %length.083) #15, !dbg !170
  %cmp16 = icmp eq i32 %call15, 0, !dbg !171
  br i1 %cmp16, label %cleanup, label %for.inc20, !dbg !172

for.inc20:                                        ; preds = %for.body14
  %next = getelementptr inbounds i8, ptr %pfs.086, i64 48, !dbg !173
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !135, metadata !DIExpression()), !dbg !143
  %pfs.0 = load ptr, ptr %next, align 8, !dbg !163, !tbaa !94
  tail call void @llvm.dbg.value(metadata ptr %pfs.0, metadata !135, metadata !DIExpression()), !dbg !143
  %cmp12.not = icmp eq ptr %pfs.0, null, !dbg !164
  br i1 %cmp12.not, label %for.end21, label %for.body14, !dbg !166, !llvm.loop !174

for.end21:                                        ; preds = %for.inc20, %if.end9
  %call22 = tail call noalias dereferenceable_or_null(56) ptr @calloc(i64 noundef 56, i64 noundef 1) #16, !dbg !176
  tail call void @llvm.dbg.value(metadata ptr %call22, metadata !135, metadata !DIExpression()), !dbg !143
  %cmp23 = icmp eq ptr %call22, null, !dbg !177
  br i1 %cmp23, label %if.then25, label %if.end26, !dbg !179

if.then25:                                        ; preds = %for.end21
  tail call void @perror(ptr noundef nonnull @.str) #17, !dbg !180
  br label %cleanup, !dbg !182

if.end26:                                         ; preds = %for.end21
  %add = add i64 %length.083, 1, !dbg !183
  %call27 = tail call noalias ptr @malloc(i64 noundef %add) #18, !dbg !184
  store ptr %call27, ptr %call22, align 8, !dbg !185, !tbaa !106
  %cmp30 = icmp eq ptr %call27, null, !dbg !186
  br i1 %cmp30, label %if.then32, label %if.end33, !dbg !188

if.then32:                                        ; preds = %if.end26
  tail call void @perror(ptr noundef nonnull @.str.1) #17, !dbg !189
  tail call void @free(ptr noundef nonnull %call22) #14, !dbg !191
  br label %cleanup, !dbg !192

if.end33:                                         ; preds = %if.end26
  %call35 = tail call ptr @strncpy(ptr noundef nonnull %call27, ptr noundef %key, i64 noundef %length.083) #14, !dbg !193
  %arrayidx37 = getelementptr inbounds i8, ptr %call27, i64 %length.083, !dbg !194
  store i8 0, ptr %arrayidx37, align 1, !dbg !195, !tbaa !75
  %prefix_len = getelementptr inbounds i8, ptr %call22, i64 8, !dbg !196
  store i64 %length.083, ptr %prefix_len, align 8, !dbg !197, !tbaa !198
  %next40 = getelementptr inbounds i8, ptr %call22, i64 48, !dbg !199
  store ptr %pfs.084, ptr %next40, align 8, !dbg !200, !tbaa !102
  store ptr %call22, ptr %arrayidx10, align 8, !dbg !201, !tbaa !94
  %4 = load i32, ptr @num_prefixes, align 4, !dbg !202, !tbaa !118
  %inc43 = add nsw i32 %4, 1, !dbg !202
  store i32 %inc43, ptr @num_prefixes, align 4, !dbg !202, !tbaa !118
  %5 = load i32, ptr @total_prefix_size, align 4, !dbg !203, !tbaa !118
  %6 = trunc i64 %length.083 to i32, !dbg !203
  %conv46 = add i32 %5, %6, !dbg !203
  store i32 %conv46, ptr @total_prefix_size, align 4, !dbg !203, !tbaa !118
  br label %cleanup, !dbg !204

cleanup:                                          ; preds = %for.inc, %land.rhs, %for.body14, %entry, %if.end33, %if.then32, %if.then25
  %retval.0 = phi ptr [ null, %if.then25 ], [ null, %if.then32 ], [ %call22, %if.end33 ], [ null, %entry ], [ %pfs.086, %for.body14 ], [ null, %land.rhs ], [ null, %for.inc ], !dbg !143
  ret ptr %retval.0, !dbg !205
}

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare !dbg !206 i32 @strncmp(ptr nocapture noundef, ptr nocapture noundef, i64 noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite)
declare !dbg !210 noalias noundef ptr @calloc(i64 noundef, i64 noundef) local_unnamed_addr #5

; Function Attrs: cold nofree nounwind
declare !dbg !213 void @perror(ptr nocapture noundef readonly) local_unnamed_addr #6

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare !dbg !217 noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #7

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: readwrite)
declare !dbg !220 ptr @strncpy(ptr noalias noundef returned writeonly, ptr noalias nocapture noundef readonly, i64 noundef) local_unnamed_addr #8

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @stats_prefix_record_get(ptr noundef %key, i64 noundef %nkey, i1 noundef zeroext %is_hit) local_unnamed_addr #2 !dbg !225 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !230, metadata !DIExpression()), !dbg !234
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !231, metadata !DIExpression()), !dbg !234
  tail call void @llvm.dbg.value(metadata i1 %is_hit, metadata !232, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !234
  tail call void @STATS_LOCK() #14, !dbg !235
  %call = tail call ptr @stats_prefix_find(ptr noundef %key, i64 noundef %nkey), !dbg !236
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !233, metadata !DIExpression()), !dbg !234
  %cmp.not = icmp eq ptr %call, null, !dbg !237
  br i1 %cmp.not, label %if.end3, label %if.then, !dbg !239

if.then:                                          ; preds = %entry
  %num_gets = getelementptr inbounds i8, ptr %call, i64 16, !dbg !240
  %0 = load i64, ptr %num_gets, align 8, !dbg !242, !tbaa !243
  %inc = add i64 %0, 1, !dbg !242
  store i64 %inc, ptr %num_gets, align 8, !dbg !242, !tbaa !243
  br i1 %is_hit, label %if.then1, label %if.end3, !dbg !244

if.then1:                                         ; preds = %if.then
  %num_hits = getelementptr inbounds i8, ptr %call, i64 40, !dbg !245
  %1 = load i64, ptr %num_hits, align 8, !dbg !248, !tbaa !249
  %inc2 = add i64 %1, 1, !dbg !248
  store i64 %inc2, ptr %num_hits, align 8, !dbg !248, !tbaa !249
  br label %if.end3, !dbg !250

if.end3:                                          ; preds = %if.then, %if.then1, %entry
  tail call void @STATS_UNLOCK() #14, !dbg !251
  ret void, !dbg !252
}

declare !dbg !253 void @STATS_LOCK() local_unnamed_addr #9

declare !dbg !255 void @STATS_UNLOCK() local_unnamed_addr #9

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @stats_prefix_record_delete(ptr noundef %key, i64 noundef %nkey) local_unnamed_addr #2 !dbg !256 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !260, metadata !DIExpression()), !dbg !263
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !261, metadata !DIExpression()), !dbg !263
  tail call void @STATS_LOCK() #14, !dbg !264
  %call = tail call ptr @stats_prefix_find(ptr noundef %key, i64 noundef %nkey), !dbg !265
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !262, metadata !DIExpression()), !dbg !263
  %cmp.not = icmp eq ptr %call, null, !dbg !266
  br i1 %cmp.not, label %if.end, label %if.then, !dbg !268

if.then:                                          ; preds = %entry
  %num_deletes = getelementptr inbounds i8, ptr %call, i64 32, !dbg !269
  %0 = load i64, ptr %num_deletes, align 8, !dbg !271, !tbaa !272
  %inc = add i64 %0, 1, !dbg !271
  store i64 %inc, ptr %num_deletes, align 8, !dbg !271, !tbaa !272
  br label %if.end, !dbg !273

if.end:                                           ; preds = %if.then, %entry
  tail call void @STATS_UNLOCK() #14, !dbg !274
  ret void, !dbg !275
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @stats_prefix_record_set(ptr noundef %key, i64 noundef %nkey) local_unnamed_addr #2 !dbg !276 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !278, metadata !DIExpression()), !dbg !281
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !279, metadata !DIExpression()), !dbg !281
  tail call void @STATS_LOCK() #14, !dbg !282
  %call = tail call ptr @stats_prefix_find(ptr noundef %key, i64 noundef %nkey), !dbg !283
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !280, metadata !DIExpression()), !dbg !281
  %cmp.not = icmp eq ptr %call, null, !dbg !284
  br i1 %cmp.not, label %if.end, label %if.then, !dbg !286

if.then:                                          ; preds = %entry
  %num_sets = getelementptr inbounds i8, ptr %call, i64 24, !dbg !287
  %0 = load i64, ptr %num_sets, align 8, !dbg !289, !tbaa !290
  %inc = add i64 %0, 1, !dbg !289
  store i64 %inc, ptr %num_sets, align 8, !dbg !289, !tbaa !290
  br label %if.end, !dbg !291

if.end:                                           ; preds = %if.then, %entry
  tail call void @STATS_UNLOCK() #14, !dbg !292
  ret void, !dbg !293
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noalias noundef ptr @stats_prefix_dump(ptr nocapture noundef writeonly %length) local_unnamed_addr #2 !dbg !294 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %length, metadata !299, metadata !DIExpression()), !dbg !307
  tail call void @llvm.dbg.value(metadata ptr @.str.2, metadata !300, metadata !DIExpression()), !dbg !307
  tail call void @llvm.dbg.value(metadata i64 0, metadata !305, metadata !DIExpression()), !dbg !307
  tail call void @llvm.dbg.value(metadata i64 0, metadata !306, metadata !DIExpression()), !dbg !307
  tail call void @STATS_LOCK() #14, !dbg !308
  %0 = load i32, ptr @total_prefix_size, align 4, !dbg !309, !tbaa !118
  %conv = sext i32 %0 to i64, !dbg !309
  %1 = load i32, ptr @num_prefixes, align 4, !dbg !310, !tbaa !118
  %conv1 = sext i32 %1 to i64, !dbg !310
  %mul = mul nsw i64 %conv1, 109, !dbg !311
  %add4 = add nsw i64 %conv, 53, !dbg !312
  %add5 = add nsw i64 %add4, %mul, !dbg !313
  tail call void @llvm.dbg.value(metadata i64 %add5, metadata !305, metadata !DIExpression()), !dbg !307
  %call6 = tail call noalias ptr @malloc(i64 noundef %add5) #18, !dbg !314
  tail call void @llvm.dbg.value(metadata ptr %call6, metadata !302, metadata !DIExpression()), !dbg !307
  %cmp = icmp eq ptr %call6, null, !dbg !315
  br i1 %cmp, label %if.then, label %for.body, !dbg !317

if.then:                                          ; preds = %entry
  tail call void @perror(ptr noundef nonnull @.str.3) #17, !dbg !318
  tail call void @STATS_UNLOCK() #14, !dbg !320
  br label %cleanup, !dbg !321

for.body:                                         ; preds = %entry, %for.inc21
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.inc21 ], [ 0, %entry ]
  %pos.055 = phi i32 [ %pos.1.lcssa, %for.inc21 ], [ 0, %entry ]
  tail call void @llvm.dbg.value(metadata i32 %pos.055, metadata !304, metadata !DIExpression()), !dbg !307
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !303, metadata !DIExpression()), !dbg !307
  %arrayidx = getelementptr inbounds [256 x ptr], ptr @prefix_stats, i64 0, i64 %indvars.iv, !dbg !322
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !301, metadata !DIExpression()), !dbg !307
  %pfs.050 = load ptr, ptr %arrayidx, align 8, !dbg !327, !tbaa !94
  %cmp11.not51 = icmp eq ptr %pfs.050, null, !dbg !328
  br i1 %cmp11.not51, label %for.inc21, label %for.body13, !dbg !330

for.body13:                                       ; preds = %for.body, %for.body13
  %pfs.053 = phi ptr [ %pfs.0, %for.body13 ], [ %pfs.050, %for.body ]
  %pos.152 = phi i32 [ %add19, %for.body13 ], [ %pos.055, %for.body ]
  tail call void @llvm.dbg.value(metadata i32 %pos.152, metadata !304, metadata !DIExpression()), !dbg !307
  %idx.ext = sext i32 %pos.152 to i64, !dbg !331
  %add.ptr = getelementptr inbounds i8, ptr %call6, i64 %idx.ext, !dbg !331
  %sub15 = sub nsw i64 %add5, %idx.ext, !dbg !333
  %2 = load ptr, ptr %pfs.053, align 8, !dbg !334, !tbaa !106
  %num_gets = getelementptr inbounds i8, ptr %pfs.053, i64 16, !dbg !335
  %3 = load i64, ptr %num_gets, align 8, !dbg !335, !tbaa !243
  %num_hits = getelementptr inbounds i8, ptr %pfs.053, i64 40, !dbg !336
  %4 = load i64, ptr %num_hits, align 8, !dbg !336, !tbaa !249
  %num_sets = getelementptr inbounds i8, ptr %pfs.053, i64 24, !dbg !337
  %5 = load i64, ptr %num_sets, align 8, !dbg !337, !tbaa !290
  %num_deletes = getelementptr inbounds i8, ptr %pfs.053, i64 32, !dbg !338
  %6 = load i64, ptr %num_deletes, align 8, !dbg !338, !tbaa !272
  %call16 = tail call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull %add.ptr, i64 noundef %sub15, ptr noundef nonnull @.str.2, ptr noundef %2, i64 noundef %3, i64 noundef %4, i64 noundef %5, i64 noundef %6) #14, !dbg !339
  tail call void @llvm.dbg.value(metadata i32 %call16, metadata !306, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_signed, DW_OP_LLVM_convert, 64, DW_ATE_signed, DW_OP_stack_value)), !dbg !307
  %add19 = add i32 %call16, %pos.152, !dbg !340
  tail call void @llvm.dbg.value(metadata i32 %add19, metadata !304, metadata !DIExpression()), !dbg !307
  %next = getelementptr inbounds i8, ptr %pfs.053, i64 48, !dbg !341
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !301, metadata !DIExpression()), !dbg !307
  %pfs.0 = load ptr, ptr %next, align 8, !dbg !327, !tbaa !94
  tail call void @llvm.dbg.value(metadata ptr %pfs.0, metadata !301, metadata !DIExpression()), !dbg !307
  %cmp11.not = icmp eq ptr %pfs.0, null, !dbg !328
  br i1 %cmp11.not, label %for.inc21, label %for.body13, !dbg !330, !llvm.loop !342

for.inc21:                                        ; preds = %for.body13, %for.body
  %pos.1.lcssa = phi i32 [ %pos.055, %for.body ], [ %add19, %for.body13 ], !dbg !307
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !344
  tail call void @llvm.dbg.value(metadata i32 %pos.1.lcssa, metadata !304, metadata !DIExpression()), !dbg !307
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !303, metadata !DIExpression()), !dbg !307
  %exitcond.not = icmp eq i64 %indvars.iv.next, 256, !dbg !345
  br i1 %exitcond.not, label %for.end22, label %for.body, !dbg !346, !llvm.loop !347

for.end22:                                        ; preds = %for.inc21
  tail call void @STATS_UNLOCK() #14, !dbg !349
  %idx.ext23 = sext i32 %pos.1.lcssa to i64, !dbg !350
  %add.ptr24 = getelementptr inbounds i8, ptr %call6, i64 %idx.ext23, !dbg !350
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) %add.ptr24, ptr noundef nonnull align 1 dereferenceable(6) @.str.4, i64 6, i1 false), !dbg !351
  %add25 = add nsw i32 %pos.1.lcssa, 5, !dbg !352
  store i32 %add25, ptr %length, align 4, !dbg !353, !tbaa !118
  br label %cleanup, !dbg !354

cleanup:                                          ; preds = %for.end22, %if.then
  ret ptr %call6, !dbg !355
}

; Function Attrs: nofree nounwind
declare !dbg !356 noundef i32 @snprintf(ptr noalias nocapture noundef writeonly, i64 noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #10

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #11

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #12 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #13

attributes #0 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #2 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { mustprogress nofree nounwind willreturn memory(argmem: read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { cold nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { mustprogress nofree nounwind willreturn memory(argmem: readwrite) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #12 = { nounwind uwtable }
attributes #13 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #14 = { nounwind }
attributes #15 = { nounwind willreturn memory(read) }
attributes #16 = { nounwind allocsize(0,1) }
attributes #17 = { cold }
attributes #18 = { nounwind allocsize(0) }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!60, !61, !62, !63, !64, !65, !66}
!llvm.ident = !{!67}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "prefix_delimiter", scope: !2, file: !3, line: 12, type: !10, isLocal: true, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !6, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "stats_prefix.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "4e1572cb85fc861900f5e424355778c1")
!4 = !{!5}
!5 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!6 = !{!7, !13, !18, !20, !25, !30, !0, !55, !58}
!7 = !DIGlobalVariableExpression(var: !8, expr: !DIExpression())
!8 = distinct !DIGlobalVariable(scope: null, file: !3, line: 65, type: !9, isLocal: true, isDefinition: true)
!9 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 392, elements: !11)
!10 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!11 = !{!12}
!12 = !DISubrange(count: 49)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(scope: null, file: !3, line: 71, type: !15, isLocal: true, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 384, elements: !16)
!16 = !{!17}
!17 = !DISubrange(count: 48)
!18 = !DIGlobalVariableExpression(var: !19, expr: !DIExpression())
!19 = distinct !DIGlobalVariable(scope: null, file: !3, line: 126, type: !15, isLocal: true, isDefinition: true)
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(scope: null, file: !3, line: 147, type: !22, isLocal: true, isDefinition: true)
!22 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 304, elements: !23)
!23 = !{!24}
!24 = !DISubrange(count: 38)
!25 = !DIGlobalVariableExpression(var: !26, expr: !DIExpression())
!26 = distinct !DIGlobalVariable(scope: null, file: !3, line: 167, type: !27, isLocal: true, isDefinition: true)
!27 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 48, elements: !28)
!28 = !{!29}
!29 = !DISubrange(count: 6)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "prefix_stats", scope: !2, file: !3, line: 10, type: !32, isLocal: true, isDefinition: true)
!32 = !DICompositeType(tag: DW_TAG_array_type, baseType: !33, size: 16384, elements: !53)
!33 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !34, size: 64)
!34 = !DIDerivedType(tag: DW_TAG_typedef, name: "PREFIX_STATS", file: !35, line: 41, baseType: !36)
!35 = !DIFile(filename: "./stats_prefix.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "c26de3f3a40668b5f799218415be0cc4")
!36 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_prefix_stats", file: !35, line: 42, size: 448, elements: !37)
!37 = !{!38, !40, !44, !49, !50, !51, !52}
!38 = !DIDerivedType(tag: DW_TAG_member, name: "prefix", scope: !36, file: !35, line: 43, baseType: !39, size: 64)
!39 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !10, size: 64)
!40 = !DIDerivedType(tag: DW_TAG_member, name: "prefix_len", scope: !36, file: !35, line: 44, baseType: !41, size: 64, offset: 64)
!41 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !42, line: 18, baseType: !43)
!42 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!43 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!44 = !DIDerivedType(tag: DW_TAG_member, name: "num_gets", scope: !36, file: !35, line: 45, baseType: !45, size: 64, offset: 128)
!45 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !46, line: 27, baseType: !47)
!46 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!47 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !48, line: 45, baseType: !43)
!48 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!49 = !DIDerivedType(tag: DW_TAG_member, name: "num_sets", scope: !36, file: !35, line: 46, baseType: !45, size: 64, offset: 192)
!50 = !DIDerivedType(tag: DW_TAG_member, name: "num_deletes", scope: !36, file: !35, line: 47, baseType: !45, size: 64, offset: 256)
!51 = !DIDerivedType(tag: DW_TAG_member, name: "num_hits", scope: !36, file: !35, line: 48, baseType: !45, size: 64, offset: 320)
!52 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !36, file: !35, line: 49, baseType: !33, size: 64, offset: 384)
!53 = !{!54}
!54 = !DISubrange(count: 256)
!55 = !DIGlobalVariableExpression(var: !56, expr: !DIExpression())
!56 = distinct !DIGlobalVariable(name: "num_prefixes", scope: !2, file: !3, line: 13, type: !57, isLocal: true, isDefinition: true)
!57 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!58 = !DIGlobalVariableExpression(var: !59, expr: !DIExpression())
!59 = distinct !DIGlobalVariable(name: "total_prefix_size", scope: !2, file: !3, line: 14, type: !57, isLocal: true, isDefinition: true)
!60 = !{i32 7, !"Dwarf Version", i32 5}
!61 = !{i32 2, !"Debug Info Version", i32 3}
!62 = !{i32 1, !"wchar_size", i32 4}
!63 = !{i32 8, !"PIC Level", i32 2}
!64 = !{i32 7, !"PIE Level", i32 2}
!65 = !{i32 7, !"uwtable", i32 2}
!66 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!67 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!68 = distinct !DISubprogram(name: "stats_prefix_init", scope: !3, file: !3, line: 16, type: !69, scopeLine: 16, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !71)
!69 = !DISubroutineType(types: !70)
!70 = !{null, !10}
!71 = !{!72}
!72 = !DILocalVariable(name: "delimiter", arg: 1, scope: !68, file: !3, line: 16, type: !10)
!73 = !DILocation(line: 0, scope: !68)
!74 = !DILocation(line: 17, column: 22, scope: !68)
!75 = !{!76, !76, i64 0}
!76 = !{!"omnipotent char", !77, i64 0}
!77 = !{!"Simple C/C++ TBAA"}
!78 = !DILocation(line: 18, column: 5, scope: !68)
!79 = !DILocation(line: 19, column: 1, scope: !68)
!80 = distinct !DISubprogram(name: "stats_prefix_clear", scope: !3, file: !3, line: 21, type: !81, scopeLine: 21, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !83)
!81 = !DISubroutineType(types: !82)
!82 = !{null}
!83 = !{!84, !85, !89}
!84 = !DILocalVariable(name: "i", scope: !80, file: !3, line: 22, type: !57)
!85 = !DILocalVariable(name: "cur", scope: !86, file: !3, line: 25, type: !33)
!86 = distinct !DILexicalBlock(scope: !87, file: !3, line: 24, column: 44)
!87 = distinct !DILexicalBlock(scope: !88, file: !3, line: 24, column: 5)
!88 = distinct !DILexicalBlock(scope: !80, file: !3, line: 24, column: 5)
!89 = !DILocalVariable(name: "next", scope: !86, file: !3, line: 25, type: !33)
!90 = !DILocation(line: 0, scope: !80)
!91 = !DILocation(line: 24, column: 5, scope: !88)
!92 = !DILocation(line: 26, column: 20, scope: !93)
!93 = distinct !DILexicalBlock(scope: !86, file: !3, line: 26, column: 9)
!94 = !{!95, !95, i64 0}
!95 = !{!"any pointer", !76, i64 0}
!96 = !DILocation(line: 0, scope: !86)
!97 = !DILocation(line: 26, column: 41, scope: !98)
!98 = distinct !DILexicalBlock(scope: !93, file: !3, line: 26, column: 9)
!99 = !DILocation(line: 26, column: 9, scope: !93)
!100 = !DILocation(line: 27, column: 25, scope: !101)
!101 = distinct !DILexicalBlock(scope: !98, file: !3, line: 26, column: 62)
!102 = !{!103, !95, i64 48}
!103 = !{!"_prefix_stats", !95, i64 0, !104, i64 8, !104, i64 16, !104, i64 24, !104, i64 32, !104, i64 40, !95, i64 48}
!104 = !{!"long", !76, i64 0}
!105 = !DILocation(line: 28, column: 23, scope: !101)
!106 = !{!103, !95, i64 0}
!107 = !DILocation(line: 28, column: 13, scope: !101)
!108 = !DILocation(line: 29, column: 13, scope: !101)
!109 = distinct !{!109, !99, !110, !111}
!110 = !DILocation(line: 30, column: 9, scope: !93)
!111 = !{!"llvm.loop.mustprogress"}
!112 = !DILocation(line: 31, column: 25, scope: !86)
!113 = !DILocation(line: 24, column: 40, scope: !87)
!114 = !DILocation(line: 24, column: 19, scope: !87)
!115 = distinct !{!115, !91, !116, !111}
!116 = !DILocation(line: 32, column: 5, scope: !88)
!117 = !DILocation(line: 33, column: 18, scope: !80)
!118 = !{!119, !119, i64 0}
!119 = !{!"int", !76, i64 0}
!120 = !DILocation(line: 34, column: 23, scope: !80)
!121 = !DILocation(line: 35, column: 1, scope: !80)
!122 = !DISubprogram(name: "free", scope: !123, file: !123, line: 687, type: !124, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!123 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!124 = !DISubroutineType(types: !125)
!125 = !{null, !5}
!126 = distinct !DISubprogram(name: "stats_prefix_find", scope: !3, file: !3, line: 37, type: !127, scopeLine: 37, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !132)
!127 = !DISubroutineType(types: !128)
!128 = !{!33, !129, !131}
!129 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !130, size: 64)
!130 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !10)
!131 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !41)
!132 = !{!133, !134, !135, !136, !140, !141}
!133 = !DILocalVariable(name: "key", arg: 1, scope: !126, file: !3, line: 37, type: !129)
!134 = !DILocalVariable(name: "nkey", arg: 2, scope: !126, file: !3, line: 37, type: !131)
!135 = !DILocalVariable(name: "pfs", scope: !126, file: !3, line: 38, type: !33)
!136 = !DILocalVariable(name: "hashval", scope: !126, file: !3, line: 39, type: !137)
!137 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !46, line: 26, baseType: !138)
!138 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !48, line: 42, baseType: !139)
!139 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!140 = !DILocalVariable(name: "length", scope: !126, file: !3, line: 40, type: !41)
!141 = !DILocalVariable(name: "bailout", scope: !126, file: !3, line: 41, type: !142)
!142 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!143 = !DILocation(line: 0, scope: !126)
!144 = !DILocation(line: 45, column: 29, scope: !145)
!145 = distinct !DILexicalBlock(scope: !146, file: !3, line: 45, column: 5)
!146 = distinct !DILexicalBlock(scope: !126, file: !3, line: 45, column: 5)
!147 = !DILocation(line: 45, column: 36, scope: !145)
!148 = !DILocation(line: 45, column: 39, scope: !145)
!149 = !DILocation(line: 45, column: 51, scope: !145)
!150 = !DILocation(line: 45, column: 5, scope: !146)
!151 = !DILocation(line: 46, column: 28, scope: !152)
!152 = distinct !DILexicalBlock(scope: !153, file: !3, line: 46, column: 13)
!153 = distinct !DILexicalBlock(scope: !145, file: !3, line: 45, column: 70)
!154 = !DILocation(line: 46, column: 25, scope: !152)
!155 = !DILocation(line: 46, column: 13, scope: !153)
!156 = !DILocation(line: 45, column: 66, scope: !145)
!157 = distinct !{!157, !150, !158, !111}
!158 = !DILocation(line: 50, column: 5, scope: !146)
!159 = !DILocation(line: 56, column: 15, scope: !126)
!160 = !DILocation(line: 56, column: 33, scope: !126)
!161 = !DILocation(line: 58, column: 16, scope: !162)
!162 = distinct !DILexicalBlock(scope: !126, file: !3, line: 58, column: 5)
!163 = !DILocation(line: 58, scope: !162)
!164 = !DILocation(line: 58, column: 44, scope: !165)
!165 = distinct !DILexicalBlock(scope: !162, file: !3, line: 58, column: 5)
!166 = !DILocation(line: 58, column: 5, scope: !162)
!167 = !DILocation(line: 59, column: 26, scope: !168)
!168 = distinct !DILexicalBlock(scope: !169, file: !3, line: 59, column: 13)
!169 = distinct !DILexicalBlock(scope: !165, file: !3, line: 58, column: 69)
!170 = !DILocation(line: 59, column: 13, scope: !168)
!171 = !DILocation(line: 59, column: 47, scope: !168)
!172 = !DILocation(line: 59, column: 13, scope: !169)
!173 = !DILocation(line: 58, column: 63, scope: !165)
!174 = distinct !{!174, !166, !175, !111}
!175 = !DILocation(line: 61, column: 5, scope: !162)
!176 = !DILocation(line: 63, column: 11, scope: !126)
!177 = !DILocation(line: 64, column: 14, scope: !178)
!178 = distinct !DILexicalBlock(scope: !126, file: !3, line: 64, column: 9)
!179 = !DILocation(line: 64, column: 9, scope: !126)
!180 = !DILocation(line: 65, column: 9, scope: !181)
!181 = distinct !DILexicalBlock(scope: !178, file: !3, line: 64, column: 22)
!182 = !DILocation(line: 66, column: 9, scope: !181)
!183 = !DILocation(line: 69, column: 33, scope: !126)
!184 = !DILocation(line: 69, column: 19, scope: !126)
!185 = !DILocation(line: 69, column: 17, scope: !126)
!186 = !DILocation(line: 70, column: 14, scope: !187)
!187 = distinct !DILexicalBlock(scope: !126, file: !3, line: 70, column: 9)
!188 = !DILocation(line: 70, column: 9, scope: !126)
!189 = !DILocation(line: 71, column: 9, scope: !190)
!190 = distinct !DILexicalBlock(scope: !187, file: !3, line: 70, column: 30)
!191 = !DILocation(line: 72, column: 9, scope: !190)
!192 = !DILocation(line: 73, column: 9, scope: !190)
!193 = !DILocation(line: 76, column: 5, scope: !126)
!194 = !DILocation(line: 77, column: 5, scope: !126)
!195 = !DILocation(line: 77, column: 25, scope: !126)
!196 = !DILocation(line: 78, column: 10, scope: !126)
!197 = !DILocation(line: 78, column: 21, scope: !126)
!198 = !{!103, !104, i64 8}
!199 = !DILocation(line: 80, column: 10, scope: !126)
!200 = !DILocation(line: 80, column: 15, scope: !126)
!201 = !DILocation(line: 81, column: 27, scope: !126)
!202 = !DILocation(line: 83, column: 17, scope: !126)
!203 = !DILocation(line: 84, column: 23, scope: !126)
!204 = !DILocation(line: 86, column: 5, scope: !126)
!205 = !DILocation(line: 87, column: 1, scope: !126)
!206 = !DISubprogram(name: "strncmp", scope: !207, file: !207, line: 159, type: !208, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!207 = !DIFile(filename: "/usr/include/string.h", directory: "", checksumkind: CSK_MD5, checksum: "165db1185644f68894fa9e0d17055d70")
!208 = !DISubroutineType(types: !209)
!209 = !{!57, !129, !129, !41}
!210 = !DISubprogram(name: "calloc", scope: !123, file: !123, line: 675, type: !211, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!211 = !DISubroutineType(types: !212)
!212 = !{!5, !41, !41}
!213 = !DISubprogram(name: "perror", scope: !214, file: !214, line: 878, type: !215, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!214 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "1e435c46987a169d9f9186f63a512303")
!215 = !DISubroutineType(types: !216)
!216 = !{null, !129}
!217 = !DISubprogram(name: "malloc", scope: !123, file: !123, line: 672, type: !218, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!218 = !DISubroutineType(types: !219)
!219 = !{!5, !41}
!220 = !DISubprogram(name: "strncpy", scope: !207, file: !207, line: 144, type: !221, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!221 = !DISubroutineType(types: !222)
!222 = !{!39, !223, !224, !41}
!223 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !39)
!224 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !129)
!225 = distinct !DISubprogram(name: "stats_prefix_record_get", scope: !3, file: !3, line: 89, type: !226, scopeLine: 89, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !229)
!226 = !DISubroutineType(types: !227)
!227 = !{null, !129, !131, !228}
!228 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !142)
!229 = !{!230, !231, !232, !233}
!230 = !DILocalVariable(name: "key", arg: 1, scope: !225, file: !3, line: 89, type: !129)
!231 = !DILocalVariable(name: "nkey", arg: 2, scope: !225, file: !3, line: 89, type: !131)
!232 = !DILocalVariable(name: "is_hit", arg: 3, scope: !225, file: !3, line: 89, type: !228)
!233 = !DILocalVariable(name: "pfs", scope: !225, file: !3, line: 90, type: !33)
!234 = !DILocation(line: 0, scope: !225)
!235 = !DILocation(line: 92, column: 5, scope: !225)
!236 = !DILocation(line: 93, column: 11, scope: !225)
!237 = !DILocation(line: 94, column: 14, scope: !238)
!238 = distinct !DILexicalBlock(scope: !225, file: !3, line: 94, column: 9)
!239 = !DILocation(line: 94, column: 9, scope: !225)
!240 = !DILocation(line: 95, column: 14, scope: !241)
!241 = distinct !DILexicalBlock(scope: !238, file: !3, line: 94, column: 22)
!242 = !DILocation(line: 95, column: 22, scope: !241)
!243 = !{!103, !104, i64 16}
!244 = !DILocation(line: 96, column: 13, scope: !241)
!245 = !DILocation(line: 97, column: 18, scope: !246)
!246 = distinct !DILexicalBlock(scope: !247, file: !3, line: 96, column: 21)
!247 = distinct !DILexicalBlock(scope: !241, file: !3, line: 96, column: 13)
!248 = !DILocation(line: 97, column: 26, scope: !246)
!249 = !{!103, !104, i64 40}
!250 = !DILocation(line: 98, column: 9, scope: !246)
!251 = !DILocation(line: 100, column: 5, scope: !225)
!252 = !DILocation(line: 101, column: 1, scope: !225)
!253 = !DISubprogram(name: "STATS_LOCK", scope: !254, file: !254, line: 1026, type: !81, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!254 = !DIFile(filename: "./memcached.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "a52021954a5d6b153b5bc084e2fbff2b")
!255 = !DISubprogram(name: "STATS_UNLOCK", scope: !254, file: !254, line: 1027, type: !81, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!256 = distinct !DISubprogram(name: "stats_prefix_record_delete", scope: !3, file: !3, line: 103, type: !257, scopeLine: 103, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !259)
!257 = !DISubroutineType(types: !258)
!258 = !{null, !129, !131}
!259 = !{!260, !261, !262}
!260 = !DILocalVariable(name: "key", arg: 1, scope: !256, file: !3, line: 103, type: !129)
!261 = !DILocalVariable(name: "nkey", arg: 2, scope: !256, file: !3, line: 103, type: !131)
!262 = !DILocalVariable(name: "pfs", scope: !256, file: !3, line: 104, type: !33)
!263 = !DILocation(line: 0, scope: !256)
!264 = !DILocation(line: 106, column: 5, scope: !256)
!265 = !DILocation(line: 107, column: 11, scope: !256)
!266 = !DILocation(line: 108, column: 14, scope: !267)
!267 = distinct !DILexicalBlock(scope: !256, file: !3, line: 108, column: 9)
!268 = !DILocation(line: 108, column: 9, scope: !256)
!269 = !DILocation(line: 109, column: 14, scope: !270)
!270 = distinct !DILexicalBlock(scope: !267, file: !3, line: 108, column: 22)
!271 = !DILocation(line: 109, column: 25, scope: !270)
!272 = !{!103, !104, i64 32}
!273 = !DILocation(line: 110, column: 5, scope: !270)
!274 = !DILocation(line: 111, column: 5, scope: !256)
!275 = !DILocation(line: 112, column: 1, scope: !256)
!276 = distinct !DISubprogram(name: "stats_prefix_record_set", scope: !3, file: !3, line: 114, type: !257, scopeLine: 114, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !277)
!277 = !{!278, !279, !280}
!278 = !DILocalVariable(name: "key", arg: 1, scope: !276, file: !3, line: 114, type: !129)
!279 = !DILocalVariable(name: "nkey", arg: 2, scope: !276, file: !3, line: 114, type: !131)
!280 = !DILocalVariable(name: "pfs", scope: !276, file: !3, line: 115, type: !33)
!281 = !DILocation(line: 0, scope: !276)
!282 = !DILocation(line: 117, column: 5, scope: !276)
!283 = !DILocation(line: 118, column: 11, scope: !276)
!284 = !DILocation(line: 119, column: 14, scope: !285)
!285 = distinct !DILexicalBlock(scope: !276, file: !3, line: 119, column: 9)
!286 = !DILocation(line: 119, column: 9, scope: !276)
!287 = !DILocation(line: 120, column: 14, scope: !288)
!288 = distinct !DILexicalBlock(scope: !285, file: !3, line: 119, column: 22)
!289 = !DILocation(line: 120, column: 22, scope: !288)
!290 = !{!103, !104, i64 24}
!291 = !DILocation(line: 121, column: 5, scope: !288)
!292 = !DILocation(line: 122, column: 5, scope: !276)
!293 = !DILocation(line: 123, column: 1, scope: !276)
!294 = distinct !DISubprogram(name: "stats_prefix_dump", scope: !3, file: !3, line: 125, type: !295, scopeLine: 125, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !298)
!295 = !DISubroutineType(types: !296)
!296 = !{!39, !297}
!297 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !57, size: 64)
!298 = !{!299, !300, !301, !302, !303, !304, !305, !306}
!299 = !DILocalVariable(name: "length", arg: 1, scope: !294, file: !3, line: 125, type: !297)
!300 = !DILocalVariable(name: "format", scope: !294, file: !3, line: 126, type: !129)
!301 = !DILocalVariable(name: "pfs", scope: !294, file: !3, line: 127, type: !33)
!302 = !DILocalVariable(name: "buf", scope: !294, file: !3, line: 128, type: !39)
!303 = !DILocalVariable(name: "i", scope: !294, file: !3, line: 129, type: !57)
!304 = !DILocalVariable(name: "pos", scope: !294, file: !3, line: 129, type: !57)
!305 = !DILocalVariable(name: "size", scope: !294, file: !3, line: 130, type: !41)
!306 = !DILocalVariable(name: "written", scope: !294, file: !3, line: 130, type: !41)
!307 = !DILocation(line: 0, scope: !294)
!308 = !DILocation(line: 140, column: 5, scope: !294)
!309 = !DILocation(line: 141, column: 29, scope: !294)
!310 = !DILocation(line: 142, column: 12, scope: !294)
!311 = !DILocation(line: 142, column: 25, scope: !294)
!312 = !DILocation(line: 141, column: 47, scope: !294)
!313 = !DILocation(line: 144, column: 28, scope: !294)
!314 = !DILocation(line: 145, column: 11, scope: !294)
!315 = !DILocation(line: 146, column: 14, scope: !316)
!316 = distinct !DILexicalBlock(scope: !294, file: !3, line: 146, column: 9)
!317 = !DILocation(line: 146, column: 9, scope: !294)
!318 = !DILocation(line: 147, column: 9, scope: !319)
!319 = distinct !DILexicalBlock(scope: !316, file: !3, line: 146, column: 22)
!320 = !DILocation(line: 148, column: 9, scope: !319)
!321 = !DILocation(line: 149, column: 9, scope: !319)
!322 = !DILocation(line: 154, column: 20, scope: !323)
!323 = distinct !DILexicalBlock(scope: !324, file: !3, line: 154, column: 9)
!324 = distinct !DILexicalBlock(scope: !325, file: !3, line: 153, column: 44)
!325 = distinct !DILexicalBlock(scope: !326, file: !3, line: 153, column: 5)
!326 = distinct !DILexicalBlock(scope: !294, file: !3, line: 153, column: 5)
!327 = !DILocation(line: 154, scope: !323)
!328 = !DILocation(line: 154, column: 42, scope: !329)
!329 = distinct !DILexicalBlock(scope: !323, file: !3, line: 154, column: 9)
!330 = !DILocation(line: 154, column: 9, scope: !323)
!331 = !DILocation(line: 155, column: 36, scope: !332)
!332 = distinct !DILexicalBlock(scope: !329, file: !3, line: 154, column: 67)
!333 = !DILocation(line: 155, column: 47, scope: !332)
!334 = !DILocation(line: 156, column: 33, scope: !332)
!335 = !DILocation(line: 156, column: 46, scope: !332)
!336 = !DILocation(line: 156, column: 61, scope: !332)
!337 = !DILocation(line: 157, column: 33, scope: !332)
!338 = !DILocation(line: 157, column: 48, scope: !332)
!339 = !DILocation(line: 155, column: 23, scope: !332)
!340 = !DILocation(line: 158, column: 17, scope: !332)
!341 = !DILocation(line: 154, column: 61, scope: !329)
!342 = distinct !{!342, !330, !343, !111}
!343 = !DILocation(line: 163, column: 9, scope: !323)
!344 = !DILocation(line: 153, column: 40, scope: !325)
!345 = !DILocation(line: 153, column: 19, scope: !325)
!346 = !DILocation(line: 153, column: 5, scope: !326)
!347 = distinct !{!347, !346, !348, !111}
!348 = !DILocation(line: 164, column: 5, scope: !326)
!349 = !DILocation(line: 166, column: 5, scope: !294)
!350 = !DILocation(line: 167, column: 16, scope: !294)
!351 = !DILocation(line: 167, column: 5, scope: !294)
!352 = !DILocation(line: 169, column: 19, scope: !294)
!353 = !DILocation(line: 169, column: 13, scope: !294)
!354 = !DILocation(line: 170, column: 5, scope: !294)
!355 = !DILocation(line: 171, column: 1, scope: !294)
!356 = !DISubprogram(name: "snprintf", scope: !214, file: !214, line: 385, type: !357, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!357 = !DISubroutineType(types: !358)
!358 = !{!57, !223, !41, !224, null}
