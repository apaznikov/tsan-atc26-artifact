; ModuleID = 'daemon.c'
source_filename = "daemon.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@.str = private unnamed_addr constant [2 x i8] c"/\00", align 1, !dbg !0
@.str.1 = private unnamed_addr constant [6 x i8] c"chdir\00", align 1, !dbg !7
@.str.2 = private unnamed_addr constant [10 x i8] c"/dev/null\00", align 1, !dbg !12
@.str.3 = private unnamed_addr constant [11 x i8] c"dup2 stdin\00", align 1, !dbg !17
@.str.4 = private unnamed_addr constant [12 x i8] c"dup2 stdout\00", align 1, !dbg !22
@.str.5 = private unnamed_addr constant [12 x i8] c"dup2 stderr\00", align 1, !dbg !27
@.str.6 = private unnamed_addr constant [6 x i8] c"close\00", align 1, !dbg !29
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 -1, 1) i32 @daemonize(i32 noundef %nochdir, i32 noundef %noclose) local_unnamed_addr #0 !dbg !41 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %nochdir, metadata !46, metadata !DIExpression()), !dbg !50
  tail call void @llvm.dbg.value(metadata i32 %noclose, metadata !47, metadata !DIExpression()), !dbg !50
  %call = tail call i32 @fork() #9, !dbg !51
  switch i32 %call, label %sw.default [
    i32 -1, label %cleanup
    i32 0, label %sw.epilog
  ], !dbg !52

sw.default:                                       ; preds = %entry
  tail call void @_exit(i32 noundef 0) #10, !dbg !53
  unreachable, !dbg !53

sw.epilog:                                        ; preds = %entry
  %call1 = tail call i32 @setsid() #9, !dbg !55
  %cmp = icmp eq i32 %call1, -1, !dbg !57
  br i1 %cmp, label %cleanup, label %if.end, !dbg !58

if.end:                                           ; preds = %sw.epilog
  %cmp2 = icmp eq i32 %nochdir, 0, !dbg !59
  br i1 %cmp2, label %if.then3, label %if.end8, !dbg !61

if.then3:                                         ; preds = %if.end
  %call4 = tail call i32 @chdir(ptr noundef nonnull @.str) #9, !dbg !62
  %cmp5.not = icmp eq i32 %call4, 0, !dbg !65
  br i1 %cmp5.not, label %if.end8, label %if.then6, !dbg !66

if.then6:                                         ; preds = %if.then3
  tail call void @perror(ptr noundef nonnull @.str.1) #11, !dbg !67
  br label %cleanup, !dbg !69

if.end8:                                          ; preds = %if.then3, %if.end
  %cmp9 = icmp eq i32 %noclose, 0, !dbg !70
  br i1 %cmp9, label %land.lhs.true, label %cleanup, !dbg !72

land.lhs.true:                                    ; preds = %if.end8
  %call10 = tail call i32 (ptr, i32, ...) @open(ptr noundef nonnull @.str.2, i32 noundef 2, i32 noundef 0) #9, !dbg !73
  tail call void @llvm.dbg.value(metadata i32 %call10, metadata !48, metadata !DIExpression()), !dbg !50
  %cmp11.not = icmp eq i32 %call10, -1, !dbg !74
  br i1 %cmp11.not, label %cleanup, label %if.then12, !dbg !75

if.then12:                                        ; preds = %land.lhs.true
  %call13 = tail call i32 @dup2(i32 noundef %call10, i32 noundef 0) #9, !dbg !76
  %cmp14 = icmp slt i32 %call13, 0, !dbg !79
  br i1 %cmp14, label %err_cleanup, label %if.end16, !dbg !80

if.end16:                                         ; preds = %if.then12
  %call17 = tail call i32 @dup2(i32 noundef %call10, i32 noundef 1) #9, !dbg !81
  %cmp18 = icmp slt i32 %call17, 0, !dbg !83
  br i1 %cmp18, label %err_cleanup, label %if.end20, !dbg !84

if.end20:                                         ; preds = %if.end16
  %call21 = tail call i32 @dup2(i32 noundef %call10, i32 noundef 2) #9, !dbg !85
  %cmp22 = icmp slt i32 %call21, 0, !dbg !87
  br i1 %cmp22, label %err_cleanup, label %if.end24, !dbg !88

if.end24:                                         ; preds = %if.end20
  %call25 = tail call i32 @close(i32 noundef %call10) #9, !dbg !89
  %cmp26 = icmp slt i32 %call25, 0, !dbg !91
  br i1 %cmp26, label %if.then27, label %cleanup, !dbg !92

if.then27:                                        ; preds = %if.end24
  tail call void @perror(ptr noundef nonnull @.str.6) #11, !dbg !93
  br label %cleanup, !dbg !95

err_cleanup:                                      ; preds = %if.end20, %if.end16, %if.then12
  %.str.5.sink = phi ptr [ @.str.3, %if.then12 ], [ @.str.4, %if.end16 ], [ @.str.5, %if.end20 ]
  tail call void @perror(ptr noundef nonnull %.str.5.sink) #11, !dbg !96
  tail call void @llvm.dbg.label(metadata !49), !dbg !97
  %call30 = tail call i32 @close(i32 noundef %call10) #9, !dbg !98
  br label %cleanup, !dbg !99

cleanup:                                          ; preds = %if.end8, %land.lhs.true, %if.end24, %sw.epilog, %entry, %err_cleanup, %if.then27, %if.then6
  %retval.0 = phi i32 [ -1, %if.then6 ], [ -1, %err_cleanup ], [ -1, %if.then27 ], [ %call, %entry ], [ -1, %sw.epilog ], [ 0, %if.end24 ], [ 0, %land.lhs.true ], [ 0, %if.end8 ], !dbg !50
  ret i32 %retval.0, !dbg !100
}

; Function Attrs: nofree nounwind
declare !dbg !101 i32 @fork() local_unnamed_addr #1

; Function Attrs: noreturn
declare !dbg !107 void @_exit(i32 noundef) local_unnamed_addr #2

; Function Attrs: nounwind
declare !dbg !110 i32 @setsid() local_unnamed_addr #3

; Function Attrs: nounwind
declare !dbg !111 i32 @chdir(ptr noundef) local_unnamed_addr #3

; Function Attrs: cold nofree nounwind
declare !dbg !116 void @perror(ptr nocapture noundef readonly) local_unnamed_addr #4

; Function Attrs: nofree
declare !dbg !120 noundef i32 @open(ptr nocapture noundef readonly, i32 noundef, ...) local_unnamed_addr #5

; Function Attrs: nounwind
declare !dbg !124 i32 @dup2(i32 noundef, i32 noundef) local_unnamed_addr #3

declare !dbg !125 i32 @close(i32 noundef) local_unnamed_addr #6

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #7 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #8

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #8

attributes #0 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { cold nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nofree "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { nounwind uwtable }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { nounwind }
attributes #10 = { noreturn nounwind }
attributes #11 = { cold }

!llvm.dbg.cu = !{!31}
!llvm.module.flags = !{!33, !34, !35, !36, !37, !38, !39}
!llvm.ident = !{!40}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(scope: null, file: !2, line: 61, type: !3, isLocal: true, isDefinition: true)
!2 = !DIFile(filename: "daemon.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "c46b1da6a409aca5962f954840b735c9")
!3 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 16, elements: !5)
!4 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!5 = !{!6}
!6 = !DISubrange(count: 2)
!7 = !DIGlobalVariableExpression(var: !8, expr: !DIExpression())
!8 = distinct !DIGlobalVariable(scope: null, file: !2, line: 62, type: !9, isLocal: true, isDefinition: true)
!9 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 48, elements: !10)
!10 = !{!11}
!11 = !DISubrange(count: 6)
!12 = !DIGlobalVariableExpression(var: !13, expr: !DIExpression())
!13 = distinct !DIGlobalVariable(scope: null, file: !2, line: 67, type: !14, isLocal: true, isDefinition: true)
!14 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 80, elements: !15)
!15 = !{!16}
!16 = !DISubrange(count: 10)
!17 = !DIGlobalVariableExpression(var: !18, expr: !DIExpression())
!18 = distinct !DIGlobalVariable(scope: null, file: !2, line: 69, type: !19, isLocal: true, isDefinition: true)
!19 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 88, elements: !20)
!20 = !{!21}
!21 = !DISubrange(count: 11)
!22 = !DIGlobalVariableExpression(var: !23, expr: !DIExpression())
!23 = distinct !DIGlobalVariable(scope: null, file: !2, line: 73, type: !24, isLocal: true, isDefinition: true)
!24 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 96, elements: !25)
!25 = !{!26}
!26 = !DISubrange(count: 12)
!27 = !DIGlobalVariableExpression(var: !28, expr: !DIExpression())
!28 = distinct !DIGlobalVariable(scope: null, file: !2, line: 77, type: !24, isLocal: true, isDefinition: true)
!29 = !DIGlobalVariableExpression(var: !30, expr: !DIExpression())
!30 = distinct !DIGlobalVariable(scope: null, file: !2, line: 82, type: !9, isLocal: true, isDefinition: true)
!31 = distinct !DICompileUnit(language: DW_LANG_C11, file: !2, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, globals: !32, splitDebugInlining: false, nameTableKind: None)
!32 = !{!0, !7, !12, !17, !22, !27, !29}
!33 = !{i32 7, !"Dwarf Version", i32 5}
!34 = !{i32 2, !"Debug Info Version", i32 3}
!35 = !{i32 1, !"wchar_size", i32 4}
!36 = !{i32 8, !"PIC Level", i32 2}
!37 = !{i32 7, !"PIE Level", i32 2}
!38 = !{i32 7, !"uwtable", i32 2}
!39 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!40 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!41 = distinct !DISubprogram(name: "daemonize", scope: !2, file: !2, line: 44, type: !42, scopeLine: 45, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !31, retainedNodes: !45)
!42 = !DISubroutineType(types: !43)
!43 = !{!44, !44, !44}
!44 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!45 = !{!46, !47, !48, !49}
!46 = !DILocalVariable(name: "nochdir", arg: 1, scope: !41, file: !2, line: 44, type: !44)
!47 = !DILocalVariable(name: "noclose", arg: 2, scope: !41, file: !2, line: 44, type: !44)
!48 = !DILocalVariable(name: "fd", scope: !41, file: !2, line: 46, type: !44)
!49 = !DILabel(scope: !41, name: "err_cleanup", file: !2, line: 88)
!50 = !DILocation(line: 0, scope: !41)
!51 = !DILocation(line: 48, column: 13, scope: !41)
!52 = !DILocation(line: 48, column: 5, scope: !41)
!53 = !DILocation(line: 54, column: 9, scope: !54)
!54 = distinct !DILexicalBlock(scope: !41, file: !2, line: 48, column: 21)
!55 = !DILocation(line: 57, column: 9, scope: !56)
!56 = distinct !DILexicalBlock(scope: !41, file: !2, line: 57, column: 9)
!57 = !DILocation(line: 57, column: 18, scope: !56)
!58 = !DILocation(line: 57, column: 9, scope: !41)
!59 = !DILocation(line: 60, column: 17, scope: !60)
!60 = distinct !DILexicalBlock(scope: !41, file: !2, line: 60, column: 9)
!61 = !DILocation(line: 60, column: 9, scope: !41)
!62 = !DILocation(line: 61, column: 12, scope: !63)
!63 = distinct !DILexicalBlock(scope: !64, file: !2, line: 61, column: 12)
!64 = distinct !DILexicalBlock(scope: !60, file: !2, line: 60, column: 23)
!65 = !DILocation(line: 61, column: 23, scope: !63)
!66 = !DILocation(line: 61, column: 12, scope: !64)
!67 = !DILocation(line: 62, column: 13, scope: !68)
!68 = distinct !DILexicalBlock(scope: !63, file: !2, line: 61, column: 29)
!69 = !DILocation(line: 63, column: 13, scope: !68)
!70 = !DILocation(line: 67, column: 17, scope: !71)
!71 = distinct !DILexicalBlock(scope: !41, file: !2, line: 67, column: 9)
!72 = !DILocation(line: 67, column: 22, scope: !71)
!73 = !DILocation(line: 67, column: 31, scope: !71)
!74 = !DILocation(line: 67, column: 61, scope: !71)
!75 = !DILocation(line: 67, column: 9, scope: !41)
!76 = !DILocation(line: 68, column: 12, scope: !77)
!77 = distinct !DILexicalBlock(scope: !78, file: !2, line: 68, column: 12)
!78 = distinct !DILexicalBlock(scope: !71, file: !2, line: 67, column: 68)
!79 = !DILocation(line: 68, column: 35, scope: !77)
!80 = !DILocation(line: 68, column: 12, scope: !78)
!81 = !DILocation(line: 72, column: 12, scope: !82)
!82 = distinct !DILexicalBlock(scope: !78, file: !2, line: 72, column: 12)
!83 = !DILocation(line: 72, column: 36, scope: !82)
!84 = !DILocation(line: 72, column: 12, scope: !78)
!85 = !DILocation(line: 76, column: 12, scope: !86)
!86 = distinct !DILexicalBlock(scope: !78, file: !2, line: 76, column: 12)
!87 = !DILocation(line: 76, column: 36, scope: !86)
!88 = !DILocation(line: 76, column: 12, scope: !78)
!89 = !DILocation(line: 81, column: 12, scope: !90)
!90 = distinct !DILexicalBlock(scope: !78, file: !2, line: 81, column: 12)
!91 = !DILocation(line: 81, column: 22, scope: !90)
!92 = !DILocation(line: 81, column: 12, scope: !78)
!93 = !DILocation(line: 82, column: 13, scope: !94)
!94 = distinct !DILexicalBlock(scope: !90, file: !2, line: 81, column: 27)
!95 = !DILocation(line: 83, column: 13, scope: !94)
!96 = !DILocation(line: 0, scope: !78)
!97 = !DILocation(line: 88, column: 5, scope: !41)
!98 = !DILocation(line: 89, column: 9, scope: !41)
!99 = !DILocation(line: 90, column: 9, scope: !41)
!100 = !DILocation(line: 91, column: 1, scope: !41)
!101 = !DISubprogram(name: "fork", scope: !102, file: !102, line: 778, type: !103, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!102 = !DIFile(filename: "/usr/include/unistd.h", directory: "", checksumkind: CSK_MD5, checksum: "877e832a8bb8424f9180387a13787475")
!103 = !DISubroutineType(types: !104)
!104 = !{!105}
!105 = !DIDerivedType(tag: DW_TAG_typedef, name: "__pid_t", file: !106, line: 154, baseType: !44)
!106 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!107 = !DISubprogram(name: "_exit", scope: !102, file: !102, line: 624, type: !108, flags: DIFlagPrototyped | DIFlagNoReturn, spFlags: DISPFlagOptimized)
!108 = !DISubroutineType(types: !109)
!109 = !{null, !44}
!110 = !DISubprogram(name: "setsid", scope: !102, file: !102, line: 689, type: !103, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!111 = !DISubprogram(name: "chdir", scope: !102, file: !102, line: 517, type: !112, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!112 = !DISubroutineType(types: !113)
!113 = !{!44, !114}
!114 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !115, size: 64)
!115 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !4)
!116 = !DISubprogram(name: "perror", scope: !117, file: !117, line: 878, type: !118, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!117 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "1e435c46987a169d9f9186f63a512303")
!118 = !DISubroutineType(types: !119)
!119 = !{null, !114}
!120 = !DISubprogram(name: "open", scope: !121, file: !121, line: 209, type: !122, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!121 = !DIFile(filename: "/usr/include/fcntl.h", directory: "", checksumkind: CSK_MD5, checksum: "aa7b606679f16283f5b29fcd37124425")
!122 = !DISubroutineType(types: !123)
!123 = !{!44, !114, !44, null}
!124 = !DISubprogram(name: "dup2", scope: !102, file: !102, line: 555, type: !42, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!125 = !DISubprogram(name: "close", scope: !102, file: !102, line: 358, type: !126, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!126 = !DISubroutineType(types: !127)
!127 = !{!44, !44}
