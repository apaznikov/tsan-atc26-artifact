; ModuleID = 'restart.c'
source_filename = "restart.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.settings = type { i64, i32, i32, i32, ptr, i32, i32, i32, ptr, ptr, i32, double, i32, i32, i32, i8, i32, i32, i8, i32, i32, i32, i32, i32, i32, i8, i8, i8, i8, i8, i8, i32, double, i32, i32, i8, i32, i8, i8, ptr, i32, i32, i32, i32, double, double, i32, i8, i32, i32, i32, i32, i32, i8, i8, i8, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, double, double, i8, i32, i32, ptr, i32 }
%struct.__va_list_tag = type { i32, i32, ptr, ptr }
%struct.restart_cb_ctx = type { ptr, ptr, ptr, i8 }
%struct.timeval = type { i64, i64 }

@memory_file = dso_local local_unnamed_addr global ptr null, align 8, !dbg !0
@stderr = external local_unnamed_addr global ptr, align 8
@.str = private unnamed_addr constant [48 x i8] c"[restart] failed to allocate callback register\0A\00", align 1, !dbg !379
@cb_stack = internal unnamed_addr global ptr null, align 8, !dbg !448
@.str.1 = private unnamed_addr constant [60 x i8] c"[restart] internal handler for metadata tag not found: %s:\0A\00", align 1, !dbg !384
@.str.2 = private unnamed_addr constant [38 x i8] c"[restart] invalid metadata line:\0A\0A%s\0A\00", align 1, !dbg !389
@.str.3 = private unnamed_addr constant [77 x i8] c"[restart] fatal error while saving metadata state, value too long for: %s %s\00", align 1, !dbg !394
@.str.4 = private unnamed_addr constant [8 x i8] c"K%s %s\0A\00", align 1, !dbg !399
@mmap_fd = internal unnamed_addr global i32 0, align 4, !dbg !450
@.str.5 = private unnamed_addr constant [29 x i8] c"failed to open file for mmap\00", align 1, !dbg !404
@.str.6 = private unnamed_addr constant [17 x i8] c"ftruncate failed\00", align 1, !dbg !409
@.str.7 = private unnamed_addr constant [77 x i8] c"[restart] memory limit not divisible evenly by pagesize (please report bug)\0A\00", align 1, !dbg !414
@mmap_base = internal unnamed_addr global ptr null, align 8, !dbg !452
@.str.8 = private unnamed_addr constant [25 x i8] c"failed to mmap, aborting\00", align 1, !dbg !416
@slabmem_limit = internal unnamed_addr global i64 0, align 8, !dbg !454
@.str.9 = private unnamed_addr constant [34 x i8] c"[restart] failed to save metadata\00", align 1, !dbg !421
@.str.10 = private unnamed_addr constant [41 x i8] c"[restart] failed to munmap shared memory\00", align 1, !dbg !426
@.str.11 = private unnamed_addr constant [43 x i8] c"[restart] failed to close shared memory fd\00", align 1, !dbg !431
@settings = external local_unnamed_addr global %struct.settings, align 8
@.str.12 = private unnamed_addr constant [53 x i8] c"[restart] original memory base: [%p] new base: [%p]\0A\00", align 1, !dbg !436
@.str.13 = private unnamed_addr constant [34 x i8] c"[restart] recovery start [%d.%d]\0A\00", align 1, !dbg !441
@.str.14 = private unnamed_addr constant [32 x i8] c"[restart] recovery end [%d.%d]\0A\00", align 1, !dbg !443
@.str.15 = private unnamed_addr constant [6 x i8] c".meta\00", align 1, !dbg !456
@.str.16 = private unnamed_addr constant [55 x i8] c"[restart] failed to allocate memory for restart check\0A\00", align 1, !dbg !461
@.str.17 = private unnamed_addr constant [2 x i8] c"r\00", align 1, !dbg !466
@.str.18 = private unnamed_addr constant [62 x i8] c"[restart] no metadata save file, starting with a clean cache\0A\00", align 1, !dbg !471
@.str.19 = private unnamed_addr constant [33 x i8] c"[restart] corrupt metadata file\0A\00", align 1, !dbg !476
@.str.20 = private unnamed_addr constant [51 x i8] c"[restart] Failed to read a tag from metadata file\0A\00", align 1, !dbg !481
@.str.21 = private unnamed_addr constant [68 x i8] c"[restart] failed to validate metadata, starting with a clean cache\0A\00", align 1, !dbg !486
@.str.22 = private unnamed_addr constant [58 x i8] c"[restart] failed to allocate memory during metadata save\0A\00", align 1, !dbg !491
@.str.23 = private unnamed_addr constant [2 x i8] c"w\00", align 1, !dbg !496
@.str.24 = private unnamed_addr constant [30 x i8] c"failed to write metadata file\00", align 1, !dbg !498
@.str.25 = private unnamed_addr constant [5 x i8] c"T%s\0A\00", align 1, !dbg !503
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @restart_register(ptr noundef %tag, ptr noundef %ccb, ptr noundef %scb, ptr noundef %data) local_unnamed_addr #0 !dbg !516 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %tag, metadata !520, metadata !DIExpression()), !dbg !528
  tail call void @llvm.dbg.value(metadata ptr %ccb, metadata !521, metadata !DIExpression()), !dbg !528
  tail call void @llvm.dbg.value(metadata ptr %scb, metadata !522, metadata !DIExpression()), !dbg !528
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !523, metadata !DIExpression()), !dbg !528
  %call = tail call noalias dereferenceable_or_null(288) ptr @calloc(i64 noundef 1, i64 noundef 288) #18, !dbg !529
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !524, metadata !DIExpression()), !dbg !528
  %cmp = icmp eq ptr %call, null, !dbg !530
  br i1 %cmp, label %if.then, label %if.end, !dbg !532

if.then:                                          ; preds = %entry
  %0 = load ptr, ptr @stderr, align 8, !dbg !533, !tbaa !535
  %1 = tail call i64 @fwrite(ptr nonnull @.str, i64 47, i64 1, ptr %0) #19, !dbg !539
  tail call void @abort() #20, !dbg !540
  unreachable, !dbg !540

if.end:                                           ; preds = %entry
  %2 = load ptr, ptr @cb_stack, align 8, !dbg !541, !tbaa !535
  %cmp2 = icmp eq ptr %2, null, !dbg !542
  br i1 %cmp2, label %if.end7, label %while.cond, !dbg !543

while.cond:                                       ; preds = %if.end, %while.cond
  %finder.0 = phi ptr [ %3, %while.cond ], [ %2, %if.end ], !dbg !544
  tail call void @llvm.dbg.value(metadata ptr %finder.0, metadata !525, metadata !DIExpression()), !dbg !544
  %next = getelementptr inbounds i8, ptr %finder.0, i64 8, !dbg !545
  %3 = load ptr, ptr %next, align 8, !dbg !545, !tbaa !546
  %cmp4.not = icmp eq ptr %3, null, !dbg !548
  br i1 %cmp4.not, label %while.end, label %while.cond, !dbg !549, !llvm.loop !550

while.end:                                        ; preds = %while.cond
  %next.le = getelementptr inbounds i8, ptr %finder.0, i64 8
  br label %if.end7

if.end7:                                          ; preds = %if.end, %while.end
  %next.le.sink = phi ptr [ %next.le, %while.end ], [ @cb_stack, %if.end ]
  store ptr %call, ptr %next.le.sink, align 8, !dbg !553, !tbaa !535
  %tag8 = getelementptr inbounds i8, ptr %call, i64 32, !dbg !554
  %call9 = tail call zeroext i1 @safe_strcpy(ptr noundef nonnull %tag8, ptr noundef %tag, i64 noundef 255) #21, !dbg !555
  store ptr %data, ptr %call, align 8, !dbg !556, !tbaa !557
  %ccb11 = getelementptr inbounds i8, ptr %call, i64 16, !dbg !558
  store ptr %ccb, ptr %ccb11, align 8, !dbg !559, !tbaa !560
  %scb12 = getelementptr inbounds i8, ptr %call, i64 24, !dbg !561
  store ptr %scb, ptr %scb12, align 8, !dbg !562, !tbaa !563
  ret void, !dbg !564
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite)
declare !dbg !565 noalias noundef ptr @calloc(i64 noundef, i64 noundef) local_unnamed_addr #2

; Function Attrs: nofree nounwind
declare !dbg !569 noundef i32 @fprintf(ptr nocapture noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #3

; Function Attrs: noreturn nounwind
declare !dbg !575 void @abort() local_unnamed_addr #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

declare !dbg !578 zeroext i1 @safe_strcpy(ptr noundef, ptr noundef, i64 noundef) local_unnamed_addr #5

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef i32 @restart_get_kv(ptr nocapture noundef %ctx, ptr noundef writeonly %key, ptr noundef writeonly %val) local_unnamed_addr #0 !dbg !583 {
entry:
  %line = alloca ptr, align 8, !DIAssignID !602
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !591, metadata !DIExpression(), metadata !602, metadata ptr %line, metadata !DIExpression()), !dbg !603
  %len = alloca i64, align 8, !DIAssignID !604
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !592, metadata !DIExpression(), metadata !604, metadata ptr %len, metadata !DIExpression()), !dbg !603
  tail call void @llvm.dbg.value(metadata ptr %ctx, metadata !588, metadata !DIExpression()), !dbg !603
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !589, metadata !DIExpression()), !dbg !603
  tail call void @llvm.dbg.value(metadata ptr %val, metadata !590, metadata !DIExpression()), !dbg !603
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %line) #21, !dbg !605
  store ptr null, ptr %line, align 8, !dbg !606, !tbaa !535, !DIAssignID !607
  tail call void @llvm.dbg.assign(metadata ptr null, metadata !591, metadata !DIExpression(), metadata !607, metadata ptr %line, metadata !DIExpression()), !dbg !603
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %len) #21, !dbg !608
  store i64 0, ptr %len, align 8, !dbg !609, !tbaa !610, !DIAssignID !612
  tail call void @llvm.dbg.assign(metadata i64 0, metadata !592, metadata !DIExpression(), metadata !612, metadata ptr %len, metadata !DIExpression()), !dbg !603
  tail call void @llvm.dbg.value(metadata ptr null, metadata !593, metadata !DIExpression()), !dbg !603
  tail call void @llvm.dbg.value(metadata ptr %ctx, metadata !594, metadata !DIExpression()), !dbg !603
  %line1 = getelementptr inbounds i8, ptr %ctx, i64 16, !dbg !613
  %0 = load ptr, ptr %line1, align 8, !dbg !613, !tbaa !615
  %cmp.not = icmp eq ptr %0, null, !dbg !618
  br i1 %cmp.not, label %if.end, label %if.then, !dbg !619

if.then:                                          ; preds = %entry
  tail call void @free(ptr noundef nonnull %0) #21, !dbg !620
  store ptr null, ptr %line1, align 8, !dbg !622, !tbaa !615
  br label %if.end, !dbg !623

if.end:                                           ; preds = %if.then, %entry
  %1 = load ptr, ptr %ctx, align 8, !dbg !624, !tbaa !625
  tail call void @llvm.dbg.value(metadata ptr %line, metadata !626, metadata !DIExpression()), !dbg !636
  tail call void @llvm.dbg.value(metadata ptr %len, metadata !634, metadata !DIExpression()), !dbg !636
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !635, metadata !DIExpression()), !dbg !636
  %call.i = call i64 @__getdelim(ptr noundef nonnull %line, ptr noundef nonnull %len, i32 noundef 10, ptr noundef nonnull %1) #21, !dbg !638
  %cmp4.not = icmp eq i64 %call.i, -1, !dbg !639
  br i1 %cmp4.not, label %if.else58, label %if.then5, !dbg !640

if.then5:                                         ; preds = %if.end
  %2 = load ptr, ptr %line, align 8, !dbg !641, !tbaa !535
  tail call void @llvm.dbg.value(metadata ptr %2, metadata !595, metadata !DIExpression()), !dbg !642
  br label %while.cond, !dbg !643

while.cond:                                       ; preds = %while.cond, %if.then5
  %p.0 = phi ptr [ %2, %if.then5 ], [ %incdec.ptr, %while.cond ], !dbg !642
  tail call void @llvm.dbg.value(metadata ptr %p.0, metadata !595, metadata !DIExpression()), !dbg !642
  %3 = load i8, ptr %p.0, align 1, !dbg !644, !tbaa !645
  %cmp6.not = icmp eq i8 %3, 10, !dbg !646
  %incdec.ptr = getelementptr inbounds i8, ptr %p.0, i64 1, !dbg !647
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !595, metadata !DIExpression()), !dbg !642
  br i1 %cmp6.not, label %while.end, label %while.cond, !dbg !643, !llvm.loop !649

while.end:                                        ; preds = %while.cond
  store i8 0, ptr %p.0, align 1, !dbg !651, !tbaa !645
  %4 = load ptr, ptr %line, align 8, !dbg !652, !tbaa !535
  %5 = load i8, ptr %4, align 1, !dbg !652, !tbaa !645
  switch i8 %5, label %if.else55 [
    i8 84, label %while.cond12.preheader
    i8 75, label %if.then33
  ], !dbg !653

while.cond12.preheader:                           ; preds = %while.end
  %cb.091 = load ptr, ptr @cb_stack, align 8, !dbg !654, !tbaa !535
  %cond8492 = icmp eq ptr %cb.091, null, !dbg !656
  br i1 %cond8492, label %if.then24, label %while.body15.lr.ph, !dbg !656

while.body15.lr.ph:                               ; preds = %while.cond12.preheader
  %add.ptr = getelementptr inbounds i8, ptr %4, i64 1
  br label %while.body15, !dbg !656

while.body15:                                     ; preds = %while.body15.lr.ph, %if.end20
  %cb.093 = phi ptr [ %cb.091, %while.body15.lr.ph ], [ %cb.0, %if.end20 ]
  %tag = getelementptr inbounds i8, ptr %cb.093, i64 32, !dbg !657
  %call16 = call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %tag, ptr noundef nonnull dereferenceable(1) %add.ptr) #22, !dbg !660
  %cmp17 = icmp eq i32 %call16, 0, !dbg !661
  br i1 %cmp17, label %cleanup, label %if.end20, !dbg !662

if.end20:                                         ; preds = %while.body15
  %next = getelementptr inbounds i8, ptr %cb.093, i64 8, !dbg !663
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !593, metadata !DIExpression()), !dbg !603
  %cb.0 = load ptr, ptr %next, align 8, !dbg !654, !tbaa !535
  tail call void @llvm.dbg.value(metadata ptr %cb.0, metadata !593, metadata !DIExpression()), !dbg !603
  %cond84 = icmp eq ptr %cb.0, null, !dbg !656
  br i1 %cond84, label %if.then24, label %while.body15, !dbg !656, !llvm.loop !664

if.then24:                                        ; preds = %if.end20, %while.cond12.preheader
  %6 = load ptr, ptr @stderr, align 8, !dbg !666, !tbaa !535
  %add.ptr25 = getelementptr inbounds i8, ptr %4, i64 1, !dbg !669
  %call26 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %6, ptr noundef nonnull @.str.1, ptr noundef nonnull %add.ptr25) #23, !dbg !670
  br label %cleanup60, !dbg !671

if.then33:                                        ; preds = %while.end
  %add.ptr35 = getelementptr inbounds i8, ptr %4, i64 1, !dbg !672
  tail call void @llvm.dbg.value(metadata ptr %add.ptr35, metadata !598, metadata !DIExpression()), !dbg !673
  %cmp36.not = icmp eq ptr %key, null, !dbg !674
  br i1 %cmp36.not, label %if.end39, label %if.then38, !dbg !676

if.then38:                                        ; preds = %if.then33
  store ptr %add.ptr35, ptr %key, align 8, !dbg !677, !tbaa !535
  br label %if.end39, !dbg !679

if.end39:                                         ; preds = %if.then38, %if.then33
  tail call void @llvm.dbg.value(metadata ptr %add.ptr35, metadata !598, metadata !DIExpression()), !dbg !673
  %7 = load i8, ptr %add.ptr35, align 1, !dbg !680, !tbaa !645
  %cmp42.not88 = icmp eq i8 %7, 32, !dbg !681
  br i1 %cmp42.not88, label %while.end48, label %land.rhs.lr.ph, !dbg !682

land.rhs.lr.ph:                                   ; preds = %if.end39
  %sub.ptr.rhs.cast = ptrtoint ptr %4 to i64
  %8 = load i64, ptr %len, align 8, !tbaa !610
  %umax = call i64 @llvm.umax.i64(i64 %8, i64 1), !dbg !682
  %scevgep = getelementptr i8, ptr %4, i64 %umax, !dbg !682
  br label %land.rhs, !dbg !682

land.rhs:                                         ; preds = %land.rhs.lr.ph, %while.body46
  %p34.089 = phi ptr [ %add.ptr35, %land.rhs.lr.ph ], [ %incdec.ptr47, %while.body46 ]
  tail call void @llvm.dbg.value(metadata ptr %p34.089, metadata !598, metadata !DIExpression()), !dbg !673
  %sub.ptr.lhs.cast = ptrtoint ptr %p34.089 to i64, !dbg !683
  %sub.ptr.sub = sub i64 %sub.ptr.lhs.cast, %sub.ptr.rhs.cast, !dbg !683
  %cmp44 = icmp ult i64 %sub.ptr.sub, %8, !dbg !684
  br i1 %cmp44, label %while.body46, label %while.end48, !dbg !685

while.body46:                                     ; preds = %land.rhs
  %incdec.ptr47 = getelementptr inbounds i8, ptr %p34.089, i64 1, !dbg !686
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr47, metadata !598, metadata !DIExpression()), !dbg !673
  %9 = load i8, ptr %incdec.ptr47, align 1, !dbg !680, !tbaa !645
  %cmp42.not = icmp eq i8 %9, 32, !dbg !681
  br i1 %cmp42.not, label %while.end48, label %land.rhs, !dbg !682, !llvm.loop !688

while.end48:                                      ; preds = %land.rhs, %while.body46, %if.end39
  %p34.0.lcssa = phi ptr [ %add.ptr35, %if.end39 ], [ %incdec.ptr47, %while.body46 ], [ %scevgep, %land.rhs ], !dbg !673
  store i8 0, ptr %p34.0.lcssa, align 1, !dbg !690, !tbaa !645
  tail call void @llvm.dbg.value(metadata ptr %p34.0.lcssa, metadata !598, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !673
  %cmp50.not = icmp eq ptr %val, null, !dbg !691
  br i1 %cmp50.not, label %if.end53, label %if.then52, !dbg !693

if.then52:                                        ; preds = %while.end48
  %incdec.ptr49 = getelementptr inbounds i8, ptr %p34.0.lcssa, i64 1, !dbg !694
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr49, metadata !598, metadata !DIExpression()), !dbg !673
  store ptr %incdec.ptr49, ptr %val, align 8, !dbg !695, !tbaa !535
  br label %if.end53, !dbg !697

if.end53:                                         ; preds = %if.then52, %while.end48
  %10 = load ptr, ptr %line, align 8, !dbg !698, !tbaa !535
  store ptr %10, ptr %line1, align 8, !dbg !699, !tbaa !615
  br label %cleanup60

if.else55:                                        ; preds = %while.end
  %11 = load ptr, ptr @stderr, align 8, !dbg !700, !tbaa !535
  %call56 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %11, ptr noundef nonnull @.str.2, ptr noundef nonnull %4) #23, !dbg !702
  %12 = load ptr, ptr %line, align 8, !dbg !703, !tbaa !535
  call void @free(ptr noundef %12) #21, !dbg !704
  br label %cleanup60, !dbg !705

cleanup:                                          ; preds = %while.body15
  %cb28 = getelementptr inbounds i8, ptr %ctx, i64 8, !dbg !706
  store ptr %cb.093, ptr %cb28, align 8, !dbg !707, !tbaa !708
  br label %cleanup60

if.else58:                                        ; preds = %if.end
  %done = getelementptr inbounds i8, ptr %ctx, i64 24, !dbg !709
  store i8 1, ptr %done, align 8, !dbg !711, !tbaa !712
  br label %cleanup60

cleanup60:                                        ; preds = %if.else55, %if.end53, %if.then24, %if.else58, %cleanup
  %retval.1 = phi i32 [ 3, %cleanup ], [ 3, %if.else58 ], [ 2, %if.else55 ], [ 0, %if.end53 ], [ 1, %if.then24 ], !dbg !603
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %len) #21, !dbg !713
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %line) #21, !dbg !713
  ret i32 %retval.1, !dbg !713
}

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !714 void @free(ptr allocptr nocapture noundef) local_unnamed_addr #6

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare !dbg !717 i32 @strcmp(ptr nocapture noundef, ptr nocapture noundef) local_unnamed_addr #7

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @restart_set_kv(ptr nocapture noundef readonly %ctx, ptr noundef %key, ptr nocapture noundef readonly %fmt, ...) local_unnamed_addr #0 !dbg !721 {
entry:
  %ap = alloca [1 x %struct.__va_list_tag], align 16, !DIAssignID !746
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !728, metadata !DIExpression(), metadata !746, metadata ptr %ap, metadata !DIExpression()), !dbg !747
  %valbuf = alloca [4096 x i8], align 16, !DIAssignID !748
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !741, metadata !DIExpression(), metadata !748, metadata ptr %valbuf, metadata !DIExpression()), !dbg !747
  tail call void @llvm.dbg.value(metadata ptr %ctx, metadata !725, metadata !DIExpression()), !dbg !747
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !726, metadata !DIExpression()), !dbg !747
  tail call void @llvm.dbg.value(metadata ptr %fmt, metadata !727, metadata !DIExpression()), !dbg !747
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %ap) #21, !dbg !749
  tail call void @llvm.dbg.value(metadata ptr %ctx, metadata !740, metadata !DIExpression()), !dbg !747
  call void @llvm.lifetime.start.p0(i64 4096, ptr nonnull %valbuf) #21, !dbg !750
  call void @llvm.va_start.p0(ptr nonnull %ap), !dbg !751
  %call = call i32 @vsnprintf(ptr noundef nonnull %valbuf, i64 noundef 4095, ptr noundef %fmt, ptr noundef nonnull %ap) #21, !dbg !752
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !745, metadata !DIExpression()), !dbg !747
  call void @llvm.va_end.p0(ptr nonnull %ap), !dbg !753
  %cmp = icmp sgt i32 %call, 4095, !dbg !754
  br i1 %cmp, label %if.then, label %if.end, !dbg !756

if.then:                                          ; preds = %entry
  %0 = load ptr, ptr @stderr, align 8, !dbg !757, !tbaa !535
  %call5 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %0, ptr noundef nonnull @.str.3, ptr noundef %key, ptr noundef nonnull %valbuf) #23, !dbg !759
  call void @abort() #20, !dbg !760
  unreachable, !dbg !760

if.end:                                           ; preds = %entry
  %1 = load ptr, ptr %ctx, align 8, !dbg !761, !tbaa !625
  %call7 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %1, ptr noundef nonnull @.str.4, ptr noundef %key, ptr noundef nonnull %valbuf) #21, !dbg !762
  call void @llvm.lifetime.end.p0(i64 4096, ptr nonnull %valbuf) #21, !dbg !763
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %ap) #21, !dbg !763
  ret void, !dbg !763
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.va_start.p0(ptr) #8

; Function Attrs: nofree nounwind
declare !dbg !764 noundef i32 @vsnprintf(ptr nocapture noundef, i64 noundef, ptr nocapture noundef readonly, ptr noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.va_end.p0(ptr) #8

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef zeroext i1 @restart_mmap_open(i64 noundef %limit, ptr nocapture noundef readonly %file, ptr nocapture noundef writeonly %mem_base) local_unnamed_addr #0 !dbg !769 {
entry:
  %ctx.i = alloca %struct.restart_cb_ctx, align 8, !DIAssignID !779
  tail call void @llvm.dbg.value(metadata i64 %limit, metadata !774, metadata !DIExpression()), !dbg !780
  tail call void @llvm.dbg.value(metadata ptr %file, metadata !775, metadata !DIExpression()), !dbg !780
  tail call void @llvm.dbg.value(metadata ptr %mem_base, metadata !776, metadata !DIExpression()), !dbg !780
  tail call void @llvm.dbg.value(metadata i8 1, metadata !777, metadata !DIExpression()), !dbg !780
  %call.i = tail call i64 @sysconf(i32 noundef 30) #21, !dbg !781
  tail call void @llvm.dbg.value(metadata i64 %call.i, metadata !778, metadata !DIExpression()), !dbg !780
  %call1 = tail call noalias ptr @strdup(ptr noundef %file) #21, !dbg !786
  store ptr %call1, ptr @memory_file, align 8, !dbg !787, !tbaa !535
  %call2 = tail call i32 (ptr, i32, ...) @open(ptr noundef %file, i32 noundef 66, i32 noundef 448) #21, !dbg !788
  store i32 %call2, ptr @mmap_fd, align 4, !dbg !789, !tbaa !790
  %cmp = icmp eq i32 %call2, -1, !dbg !792
  br i1 %cmp, label %if.then, label %if.end, !dbg !794

if.then:                                          ; preds = %entry
  tail call void @perror(ptr noundef nonnull @.str.5) #19, !dbg !795
  tail call void @abort() #20, !dbg !797
  unreachable, !dbg !797

if.end:                                           ; preds = %entry
  %call3 = tail call i32 @ftruncate(i32 noundef %call2, i64 noundef %limit) #21, !dbg !798
  %cmp4.not = icmp eq i32 %call3, 0, !dbg !800
  br i1 %cmp4.not, label %if.end6, label %if.then5, !dbg !801

if.then5:                                         ; preds = %if.end
  tail call void @perror(ptr noundef nonnull @.str.6) #19, !dbg !802
  tail call void @abort() #20, !dbg !804
  unreachable, !dbg !804

if.end6:                                          ; preds = %if.end
  %rem = urem i64 %limit, %call.i, !dbg !805
  %tobool.not = icmp eq i64 %rem, 0, !dbg !805
  br i1 %tobool.not, label %if.end9, label %if.then7, !dbg !807

if.then7:                                         ; preds = %if.end6
  %0 = load ptr, ptr @stderr, align 8, !dbg !808, !tbaa !535
  %1 = tail call i64 @fwrite(ptr nonnull @.str.7, i64 76, i64 1, ptr %0) #19, !dbg !810
  tail call void @abort() #20, !dbg !811
  unreachable, !dbg !811

if.end9:                                          ; preds = %if.end6
  %2 = load i32, ptr @mmap_fd, align 4, !dbg !812, !tbaa !790
  %call10 = tail call ptr @mmap(ptr noundef null, i64 noundef %limit, i32 noundef 3, i32 noundef 1, i32 noundef %2, i64 noundef 0) #21, !dbg !813
  store ptr %call10, ptr @mmap_base, align 8, !dbg !814, !tbaa !535
  %cmp11 = icmp eq ptr %call10, inttoptr (i64 -1 to ptr), !dbg !815
  br i1 %cmp11, label %if.then12, label %if.end13, !dbg !817

if.then12:                                        ; preds = %if.end9
  tail call void @perror(ptr noundef nonnull @.str.8) #19, !dbg !818
  tail call void @abort() #20, !dbg !820
  unreachable, !dbg !820

if.end13:                                         ; preds = %if.end9
  store i64 %limit, ptr @slabmem_limit, align 8, !dbg !821, !tbaa !610
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !822, metadata !DIExpression(), metadata !779, metadata ptr %ctx.i, metadata !DIExpression()), !dbg !835
  tail call void @llvm.dbg.value(metadata ptr %file, metadata !827, metadata !DIExpression()), !dbg !835
  %call.i24 = tail call i64 @strlen(ptr noundef nonnull readonly dereferenceable(1) %file) #22, !dbg !838
  tail call void @llvm.dbg.value(metadata i64 %call.i24, metadata !828, metadata !DIExpression()), !dbg !835
  tail call void @llvm.dbg.value(metadata ptr @.str.15, metadata !829, metadata !DIExpression()), !dbg !835
  %add2.i = add i64 %call.i24, 6, !dbg !839
  %call3.i = tail call noalias ptr @calloc(i64 noundef 1, i64 noundef %add2.i) #18, !dbg !840
  tail call void @llvm.dbg.value(metadata ptr %call3.i, metadata !830, metadata !DIExpression()), !dbg !835
  %cmp.i = icmp eq ptr %call3.i, null, !dbg !841
  br i1 %cmp.i, label %if.then.i, label %if.end.i, !dbg !843

if.then.i:                                        ; preds = %if.end13
  %3 = load ptr, ptr @stderr, align 8, !dbg !844, !tbaa !535
  %4 = tail call i64 @fwrite(ptr nonnull @.str.16, i64 54, i64 1, ptr %3) #19, !dbg !846
  tail call void @abort() #20, !dbg !847
  unreachable, !dbg !847

if.end.i:                                         ; preds = %if.end13
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %call3.i, ptr readonly align 1 %file, i64 %call.i24, i1 false), !dbg !848
  %add.ptr.i = getelementptr inbounds i8, ptr %call3.i, i64 %call.i24, !dbg !849
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %add.ptr.i, ptr noundef nonnull align 1 dereferenceable(5) @.str.15, i64 5, i1 false), !dbg !850
  %call6.i = tail call noalias ptr @fopen(ptr noundef nonnull %call3.i, ptr noundef nonnull @.str.17), !dbg !851
  tail call void @llvm.dbg.value(metadata ptr %call6.i, metadata !831, metadata !DIExpression()), !dbg !835
  %cmp7.i = icmp eq ptr %call6.i, null, !dbg !852
  br i1 %cmp7.i, label %if.then8.i, label %if.end10.i, !dbg !854

if.then8.i:                                       ; preds = %if.end.i
  %5 = load ptr, ptr @stderr, align 8, !dbg !855, !tbaa !535
  %6 = tail call i64 @fwrite(ptr nonnull @.str.18, i64 61, i64 1, ptr %5) #19, !dbg !857
  tail call void @free(ptr noundef nonnull %call3.i) #21, !dbg !858
  br label %restart_check.exit, !dbg !859

if.end10.i:                                       ; preds = %if.end.i
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %ctx.i) #21, !dbg !860
  store ptr %call6.i, ptr %ctx.i, align 8, !dbg !861, !tbaa !625, !DIAssignID !862
  tail call void @llvm.dbg.assign(metadata ptr %call6.i, metadata !822, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !862, metadata ptr %ctx.i, metadata !DIExpression()), !dbg !835
  %cb.i = getelementptr inbounds i8, ptr %ctx.i, i64 8, !dbg !863
  tail call void @llvm.dbg.assign(metadata ptr null, metadata !822, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !864, metadata ptr %cb.i, metadata !DIExpression()), !dbg !835
  %line.i = getelementptr inbounds i8, ptr %ctx.i, i64 16, !dbg !865
  tail call void @llvm.dbg.assign(metadata ptr null, metadata !822, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64), metadata !864, metadata ptr %line.i, metadata !DIExpression()), !dbg !835
  %done.i = getelementptr inbounds i8, ptr %ctx.i, i64 24, !dbg !866
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !822, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 8), metadata !864, metadata ptr %done.i, metadata !DIExpression()), !dbg !835
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(17) %cb.i, i8 0, i64 17, i1 false), !dbg !867, !DIAssignID !864
  %call12.i = call i32 @restart_get_kv(ptr noundef nonnull %ctx.i, ptr noundef null, ptr noundef null), !dbg !868
  %cmp13.not.i = icmp eq i32 %call12.i, 3, !dbg !870
  br i1 %cmp13.not.i, label %if.end16.i, label %if.then14.i, !dbg !871

if.then14.i:                                      ; preds = %if.end10.i
  %7 = load ptr, ptr @stderr, align 8, !dbg !872, !tbaa !535
  %8 = tail call i64 @fwrite(ptr nonnull @.str.19, i64 32, i64 1, ptr %7) #19, !dbg !874
  tail call void @abort() #20, !dbg !875
  unreachable, !dbg !875

if.end16.i:                                       ; preds = %if.end10.i
  %9 = load ptr, ptr %cb.i, align 8, !dbg !876, !tbaa !708
  %cmp18.i = icmp eq ptr %9, null, !dbg !878
  br i1 %cmp18.i, label %if.then19.i, label %while.cond.i, !dbg !879

if.then19.i:                                      ; preds = %if.end16.i
  %10 = load ptr, ptr @stderr, align 8, !dbg !880, !tbaa !535
  %11 = tail call i64 @fwrite(ptr nonnull @.str.20, i64 50, i64 1, ptr %10) #19, !dbg !882
  tail call void @abort() #20, !dbg !883
  unreachable, !dbg !883

while.cond.i:                                     ; preds = %if.end16.i, %while.body.i
  tail call void @llvm.dbg.value(metadata i8 0, metadata !832, metadata !DIExpression()), !dbg !835
  %12 = load i8, ptr %done.i, align 8, !dbg !884, !tbaa !712, !range !885, !noundef !886
  %tobool.i = trunc nuw i8 %12 to i1, !dbg !884
  br i1 %tobool.i, label %while.end.i, label %while.body.i, !dbg !887

while.body.i:                                     ; preds = %while.cond.i
  %13 = load ptr, ptr %cb.i, align 8, !dbg !888, !tbaa !708
  tail call void @llvm.dbg.value(metadata ptr %13, metadata !833, metadata !DIExpression()), !dbg !889
  %ccb.i = getelementptr inbounds i8, ptr %13, i64 16, !dbg !890
  %14 = load ptr, ptr %ccb.i, align 8, !dbg !890, !tbaa !560
  %tag.i = getelementptr inbounds i8, ptr %13, i64 32, !dbg !892
  %15 = load ptr, ptr %13, align 8, !dbg !893, !tbaa !557
  %call25.i = call i32 %14(ptr noundef nonnull %tag.i, ptr noundef nonnull %ctx.i, ptr noundef %15) #21, !dbg !894
  %cmp26.not.i = icmp eq i32 %call25.i, 0, !dbg !895
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !832, metadata !DIExpression()), !dbg !835
  br i1 %cmp26.not.i, label %while.cond.i, label %while.end.i

while.end.i:                                      ; preds = %while.body.i, %while.cond.i
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !832, metadata !DIExpression()), !dbg !835
  %16 = load ptr, ptr %line.i, align 8, !dbg !896, !tbaa !615
  %tobool30.not.i = icmp eq ptr %16, null, !dbg !898
  br i1 %tobool30.not.i, label %if.end33.i, label %if.then31.i, !dbg !899

if.then31.i:                                      ; preds = %while.end.i
  call void @free(ptr noundef nonnull %16) #21, !dbg !900
  br label %if.end33.i, !dbg !900

if.end33.i:                                       ; preds = %if.then31.i, %while.end.i
  %call34.i = call i32 @fclose(ptr noundef nonnull %call6.i), !dbg !901
  %call35.i = call i32 @unlink(ptr noundef nonnull %call3.i) #21, !dbg !902
  call void @free(ptr noundef %call3.i) #21, !dbg !903
  br i1 %tobool.i, label %cleanup39.i, label %if.then37.i, !dbg !904

if.then37.i:                                      ; preds = %if.end33.i
  %17 = load ptr, ptr @stderr, align 8, !dbg !905, !tbaa !535
  %18 = call i64 @fwrite(ptr nonnull @.str.21, i64 67, i64 1, ptr %17) #19, !dbg !908
  br label %cleanup39.i, !dbg !909

cleanup39.i:                                      ; preds = %if.then37.i, %if.end33.i
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %ctx.i) #21, !dbg !910
  br label %restart_check.exit

restart_check.exit:                               ; preds = %if.then8.i, %cleanup39.i
  %retval.1.i = phi i1 [ false, %if.then8.i ], [ %tobool.i, %cleanup39.i ], !dbg !835
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !777, metadata !DIExpression()), !dbg !780
  %19 = load ptr, ptr @mmap_base, align 8, !dbg !911, !tbaa !535
  store ptr %19, ptr %mem_base, align 8, !dbg !912, !tbaa !535
  ret i1 %retval.1.i, !dbg !913
}

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !914 noalias ptr @strdup(ptr nocapture noundef readonly) local_unnamed_addr #9

; Function Attrs: nofree
declare !dbg !917 noundef i32 @open(ptr nocapture noundef readonly, i32 noundef, ...) local_unnamed_addr #10

; Function Attrs: cold nofree nounwind
declare !dbg !921 void @perror(ptr nocapture noundef readonly) local_unnamed_addr #11

; Function Attrs: nounwind
declare !dbg !924 i32 @ftruncate(i32 noundef, i64 noundef) local_unnamed_addr #12

; Function Attrs: nounwind
declare !dbg !928 ptr @mmap(ptr noundef, i64 noundef, i32 noundef, i32 noundef, i32 noundef, i64 noundef) local_unnamed_addr #12

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @restart_mmap_close() local_unnamed_addr #0 !dbg !932 {
entry:
  %ctx.i = alloca %struct.restart_cb_ctx, align 8, !DIAssignID !933
  %0 = load ptr, ptr @mmap_base, align 8, !dbg !934, !tbaa !535
  %1 = load i64, ptr @slabmem_limit, align 8, !dbg !935, !tbaa !610
  %call = tail call i32 @msync(ptr noundef %0, i64 noundef %1, i32 noundef 4) #21, !dbg !936
  %2 = load ptr, ptr @memory_file, align 8, !dbg !937, !tbaa !535
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !939, metadata !DIExpression(), metadata !933, metadata ptr %ctx.i, metadata !DIExpression()), !dbg !953
  tail call void @llvm.dbg.value(metadata ptr %2, metadata !942, metadata !DIExpression()), !dbg !953
  %call.i = tail call i64 @strlen(ptr noundef nonnull readonly dereferenceable(1) %2) #22, !dbg !955
  tail call void @llvm.dbg.value(metadata i64 %call.i, metadata !943, metadata !DIExpression()), !dbg !953
  tail call void @llvm.dbg.value(metadata ptr @.str.15, metadata !944, metadata !DIExpression()), !dbg !953
  tail call void @llvm.dbg.value(metadata i64 5, metadata !945, metadata !DIExpression()), !dbg !953
  %add2.i = add i64 %call.i, 6, !dbg !956
  %call3.i = tail call noalias ptr @calloc(i64 noundef 1, i64 noundef %add2.i) #18, !dbg !957
  tail call void @llvm.dbg.value(metadata ptr %call3.i, metadata !946, metadata !DIExpression()), !dbg !953
  %cmp.i = icmp eq ptr %call3.i, null, !dbg !958
  br i1 %cmp.i, label %if.then.i, label %if.end.i, !dbg !960

if.then.i:                                        ; preds = %entry
  %3 = load ptr, ptr @stderr, align 8, !dbg !961, !tbaa !535
  %4 = tail call i64 @fwrite(ptr nonnull @.str.22, i64 57, i64 1, ptr %3) #19, !dbg !963
  br label %if.then, !dbg !964

if.end.i:                                         ; preds = %entry
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %call3.i, ptr readonly align 1 %2, i64 %call.i, i1 false), !dbg !965
  %add.ptr.i = getelementptr inbounds i8, ptr %call3.i, i64 %call.i, !dbg !966
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %add.ptr.i, ptr noundef nonnull align 1 dereferenceable(5) @.str.15, i64 5, i1 false), !dbg !967
  %call5.i = tail call i32 @umask(i32 noundef -385) #21, !dbg !968
  tail call void @llvm.dbg.value(metadata i32 %call5.i, metadata !947, metadata !DIExpression()), !dbg !953
  %call6.i = tail call noalias ptr @fopen(ptr noundef nonnull %call3.i, ptr noundef nonnull @.str.23), !dbg !969
  tail call void @llvm.dbg.value(metadata ptr %call6.i, metadata !951, metadata !DIExpression()), !dbg !953
  %call7.i = tail call i32 @umask(i32 noundef %call5.i) #21, !dbg !970
  %cmp8.i = icmp eq ptr %call6.i, null, !dbg !971
  br i1 %cmp8.i, label %if.then9.i, label %if.end10.i, !dbg !973

if.then9.i:                                       ; preds = %if.end.i
  tail call void @free(ptr noundef nonnull %call3.i) #21, !dbg !974
  tail call void @perror(ptr noundef nonnull @.str.24) #19, !dbg !976
  br label %if.then, !dbg !977

if.end10.i:                                       ; preds = %if.end.i
  %5 = load ptr, ptr @cb_stack, align 8, !dbg !978, !tbaa !535
  tail call void @llvm.dbg.value(metadata ptr %5, metadata !952, metadata !DIExpression()), !dbg !953
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %ctx.i) #21, !dbg !979
  store ptr %call6.i, ptr %ctx.i, align 8, !dbg !980, !tbaa !625, !DIAssignID !981
  tail call void @llvm.dbg.assign(metadata ptr %call6.i, metadata !939, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !981, metadata ptr %ctx.i, metadata !DIExpression()), !dbg !953
  tail call void @llvm.dbg.value(metadata ptr %5, metadata !952, metadata !DIExpression()), !dbg !953
  %cmp12.not49.i = icmp eq ptr %5, null, !dbg !982
  br i1 %cmp12.not49.i, label %restart_save.exit, label %while.body.i, !dbg !983

while.body.i:                                     ; preds = %if.end10.i, %if.end20.i
  %cb.050.i = phi ptr [ %8, %if.end20.i ], [ %5, %if.end10.i ]
  tail call void @llvm.dbg.value(metadata ptr %cb.050.i, metadata !952, metadata !DIExpression()), !dbg !953
  %tag.i = getelementptr inbounds i8, ptr %cb.050.i, i64 32, !dbg !984
  %call13.i = call i32 (ptr, ptr, ...) @fprintf(ptr noundef nonnull %call6.i, ptr noundef nonnull @.str.25, ptr noundef nonnull %tag.i) #21, !dbg !986
  %scb.i = getelementptr inbounds i8, ptr %cb.050.i, i64 24, !dbg !987
  %6 = load ptr, ptr %scb.i, align 8, !dbg !987, !tbaa !563
  %7 = load ptr, ptr %cb.050.i, align 8, !dbg !989, !tbaa !557
  %call16.i = call i32 %6(ptr noundef nonnull %tag.i, ptr noundef nonnull %ctx.i, ptr noundef %7) #21, !dbg !990
  %cmp17.not.i = icmp eq i32 %call16.i, 0, !dbg !991
  br i1 %cmp17.not.i, label %if.end20.i, label %if.then.critedge, !dbg !992

if.end20.i:                                       ; preds = %while.body.i
  %next.i = getelementptr inbounds i8, ptr %cb.050.i, i64 8, !dbg !993
  %8 = load ptr, ptr %next.i, align 8, !dbg !993, !tbaa !546
  tail call void @llvm.dbg.value(metadata ptr %8, metadata !952, metadata !DIExpression()), !dbg !953
  %cmp12.not.i = icmp eq ptr %8, null, !dbg !982
  br i1 %cmp12.not.i, label %restart_save.exit, label %while.body.i, !dbg !983, !llvm.loop !994

restart_save.exit:                                ; preds = %if.end20.i, %if.end10.i
  %call21.i = call i32 @fclose(ptr noundef nonnull %call6.i), !dbg !953
  call void @free(ptr noundef %call3.i) #21, !dbg !953
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %ctx.i) #21, !dbg !996
  br label %if.end, !dbg !997

if.then.critedge:                                 ; preds = %while.body.i
  %call21.i.c = call i32 @fclose(ptr noundef nonnull %call6.i), !dbg !953
  call void @free(ptr noundef %call3.i) #21, !dbg !953
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %ctx.i) #21, !dbg !996
  br label %if.then, !dbg !997

if.then:                                          ; preds = %if.then.critedge, %if.then9.i, %if.then.i
  %9 = load ptr, ptr @stderr, align 8, !dbg !998, !tbaa !535
  %10 = call i64 @fwrite(ptr nonnull @.str.9, i64 33, i64 1, ptr %9) #19, !dbg !1000
  br label %if.end, !dbg !1001

if.end:                                           ; preds = %restart_save.exit, %if.then
  %11 = load ptr, ptr @mmap_base, align 8, !dbg !1002, !tbaa !535
  %12 = load i64, ptr @slabmem_limit, align 8, !dbg !1004, !tbaa !610
  %call3 = call i32 @munmap(ptr noundef %11, i64 noundef %12) #21, !dbg !1005
  %cmp4.not = icmp eq i32 %call3, 0, !dbg !1006
  br i1 %cmp4.not, label %if.else, label %if.end10.sink.split, !dbg !1007

if.else:                                          ; preds = %if.end
  %13 = load i32, ptr @mmap_fd, align 4, !dbg !1008, !tbaa !790
  %call6 = call i32 @close(i32 noundef %13) #21, !dbg !1010
  %cmp7.not = icmp eq i32 %call6, 0, !dbg !1011
  br i1 %cmp7.not, label %if.end10, label %if.end10.sink.split, !dbg !1012

if.end10.sink.split:                              ; preds = %if.else, %if.end
  %.str.11.sink = phi ptr [ @.str.10, %if.end ], [ @.str.11, %if.else ]
  call void @perror(ptr noundef nonnull %.str.11.sink) #19, !dbg !1013
  br label %if.end10, !dbg !1014

if.end10:                                         ; preds = %if.end10.sink.split, %if.else
  %14 = load ptr, ptr @memory_file, align 8, !dbg !1014, !tbaa !535
  call void @free(ptr noundef %14) #21, !dbg !1015
  ret void, !dbg !1016
}

declare !dbg !1017 i32 @msync(ptr noundef, i64 noundef, i32 noundef) local_unnamed_addr #5

; Function Attrs: nounwind
declare !dbg !1020 i32 @munmap(ptr noundef, i64 noundef) local_unnamed_addr #12

declare !dbg !1023 i32 @close(i32 noundef) local_unnamed_addr #5

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef i32 @restart_fixup(ptr noundef %orig_addr) local_unnamed_addr #0 !dbg !1026 {
entry:
  %tv = alloca %struct.timeval, align 8, !DIAssignID !1049
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1031, metadata !DIExpression(), metadata !1049, metadata ptr %tv, metadata !DIExpression()), !dbg !1050
  tail call void @llvm.dbg.value(metadata ptr %orig_addr, metadata !1030, metadata !DIExpression()), !dbg !1050
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %tv) #21, !dbg !1051
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1039, metadata !DIExpression()), !dbg !1050
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 23), align 4, !dbg !1052, !tbaa !1053
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !1040, metadata !DIExpression()), !dbg !1050
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !1042, metadata !DIExpression()), !dbg !1050
  %call = call i32 @gettimeofday(ptr noundef nonnull %tv, ptr noundef null) #21, !dbg !1056
  %1 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1057, !tbaa !1059
  %cmp = icmp sgt i32 %1, 0, !dbg !1060
  br i1 %cmp, label %if.then, label %if.end, !dbg !1061

if.then:                                          ; preds = %entry
  %2 = load ptr, ptr @stderr, align 8, !dbg !1062, !tbaa !535
  %3 = load ptr, ptr @mmap_base, align 8, !dbg !1064, !tbaa !535
  %call1 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %2, ptr noundef nonnull @.str.12, ptr noundef %orig_addr, ptr noundef %3) #23, !dbg !1065
  %4 = load ptr, ptr @stderr, align 8, !dbg !1066, !tbaa !535
  %5 = load i64, ptr %tv, align 8, !dbg !1067, !tbaa !1068
  %conv = trunc i64 %5 to i32, !dbg !1070
  %tv_usec = getelementptr inbounds i8, ptr %tv, i64 8, !dbg !1071
  %6 = load i64, ptr %tv_usec, align 8, !dbg !1071, !tbaa !1072
  %conv2 = trunc i64 %6 to i32, !dbg !1073
  %call3 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %4, ptr noundef nonnull @.str.13, i32 noundef %conv, i32 noundef %conv2) #23, !dbg !1074
  br label %if.end, !dbg !1075

if.end:                                           ; preds = %if.then, %entry
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1039, metadata !DIExpression()), !dbg !1050
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !1042, metadata !DIExpression()), !dbg !1050
  %7 = load i64, ptr @slabmem_limit, align 8, !dbg !1076, !tbaa !610
  %cmp4171.not = icmp eq i64 %7, 0, !dbg !1077
  br i1 %cmp4171.not, label %while.end, label %while.body.lr.ph, !dbg !1078

while.body.lr.ph:                                 ; preds = %if.end
  %8 = ptrtoint ptr %orig_addr to i64
  br label %while.body, !dbg !1078

while.body:                                       ; preds = %while.body.lr.ph, %cleanup
  %checked.0173 = phi i64 [ 0, %while.body.lr.ph ], [ %checked.2, %cleanup ]
  %page_remain.0172 = phi i32 [ %0, %while.body.lr.ph ], [ %page_remain.2, %cleanup ]
  tail call void @llvm.dbg.value(metadata i64 %checked.0173, metadata !1039, metadata !DIExpression()), !dbg !1050
  tail call void @llvm.dbg.value(metadata i32 %page_remain.0172, metadata !1042, metadata !DIExpression()), !dbg !1050
  %9 = load ptr, ptr @mmap_base, align 8, !dbg !1079, !tbaa !535
  %add.ptr = getelementptr inbounds i8, ptr %9, i64 %checked.0173, !dbg !1080
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !1043, metadata !DIExpression()), !dbg !1081
  %10 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 23), align 4, !dbg !1082, !tbaa !1053
  %conv7 = sext i32 %10 to i64, !dbg !1083
  %rem = urem i64 %checked.0173, %conv7, !dbg !1084
  %conv8 = trunc i64 %rem to i32, !dbg !1085
  %call9 = tail call i32 @slabs_fixup(ptr noundef %add.ptr, i32 noundef %conv8) #21, !dbg !1086
  tail call void @llvm.dbg.value(metadata i32 %call9, metadata !1045, metadata !DIExpression()), !dbg !1081
  %cmp10 = icmp eq i32 %call9, -1, !dbg !1087
  br i1 %cmp10, label %if.then12, label %if.end14, !dbg !1089

if.then12:                                        ; preds = %while.body
  %conv13 = zext i32 %page_remain.0172 to i64, !dbg !1090
  %add = add i64 %checked.0173, %conv13, !dbg !1092
  tail call void @llvm.dbg.value(metadata i64 %add, metadata !1039, metadata !DIExpression()), !dbg !1050
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !1042, metadata !DIExpression()), !dbg !1050
  br label %cleanup, !dbg !1093, !llvm.loop !1094

if.end14:                                         ; preds = %while.body
  %it_flags = getelementptr inbounds i8, ptr %add.ptr, i64 38, !dbg !1096
  %11 = load i16, ptr %it_flags, align 2, !dbg !1096, !tbaa !1098
  %12 = and i16 %11, 1, !dbg !1100
  %tobool.not = icmp eq i16 %12, 0, !dbg !1100
  br i1 %tobool.not, label %if.end34, label %if.then16, !dbg !1101

if.then16:                                        ; preds = %if.end14
  %13 = load ptr, ptr %add.ptr, align 8, !dbg !1102, !tbaa !535
  %tobool17.not = icmp eq ptr %13, null, !dbg !1105
  br i1 %tobool17.not, label %if.end24, label %if.then18, !dbg !1106

if.then18:                                        ; preds = %if.then16
  %14 = ptrtoint ptr %13 to i64, !dbg !1107
  %sub = sub i64 %14, %8, !dbg !1109
  %15 = load ptr, ptr @mmap_base, align 8, !dbg !1110, !tbaa !535
  %16 = ptrtoint ptr %15 to i64, !dbg !1111
  %add22 = add i64 %sub, %16, !dbg !1112
  %17 = inttoptr i64 %add22 to ptr, !dbg !1113
  store ptr %17, ptr %add.ptr, align 8, !dbg !1114, !tbaa !535
  br label %if.end24, !dbg !1115

if.end24:                                         ; preds = %if.then18, %if.then16
  %prev = getelementptr inbounds i8, ptr %add.ptr, i64 8, !dbg !1116
  %18 = load ptr, ptr %prev, align 8, !dbg !1116, !tbaa !535
  %tobool25.not = icmp eq ptr %18, null, !dbg !1118
  br i1 %tobool25.not, label %if.end33, label %if.then26, !dbg !1119

if.then26:                                        ; preds = %if.end24
  %19 = ptrtoint ptr %18 to i64, !dbg !1120
  %sub28 = sub i64 %19, %8, !dbg !1122
  %20 = load ptr, ptr @mmap_base, align 8, !dbg !1123, !tbaa !535
  %21 = ptrtoint ptr %20 to i64, !dbg !1124
  %add31 = add i64 %sub28, %21, !dbg !1125
  %22 = inttoptr i64 %add31 to ptr, !dbg !1126
  store ptr %22, ptr %prev, align 8, !dbg !1127, !tbaa !535
  br label %if.end33, !dbg !1128

if.end33:                                         ; preds = %if.then26, %if.end24
  tail call void @do_item_link_fixup(ptr noundef nonnull %add.ptr) #21, !dbg !1129
  %.pre = load i16, ptr %it_flags, align 2, !dbg !1130, !tbaa !1098
  br label %if.end34, !dbg !1131

if.end34:                                         ; preds = %if.end33, %if.end14
  %23 = phi i16 [ %.pre, %if.end33 ], [ %11, %if.end14 ], !dbg !1130
  %conv36 = zext i16 %23 to i32, !dbg !1132
  %and37 = and i32 %conv36, 96, !dbg !1133
  %tobool38.not = icmp eq i32 %and37, 0, !dbg !1133
  br i1 %tobool38.not, label %if.end91, label %if.then39, !dbg !1134

if.then39:                                        ; preds = %if.end34
  %and42 = and i32 %conv36, 32, !dbg !1135
  %tobool43.not = icmp eq i32 %and42, 0, !dbg !1135
  br i1 %tobool43.not, label %if.end61, label %if.then44, !dbg !1137

if.then44:                                        ; preds = %if.then39
  %data = getelementptr inbounds i8, ptr %add.ptr, i64 48, !dbg !1138
  %nkey = getelementptr inbounds i8, ptr %add.ptr, i64 41, !dbg !1138
  %24 = load i8, ptr %nkey, align 1, !dbg !1138, !tbaa !645
  %idx.ext = zext i8 %24 to i64
  %add.ptr46 = getelementptr inbounds i8, ptr %data, i64 %idx.ext, !dbg !1138
  %add.ptr47 = getelementptr inbounds i8, ptr %add.ptr46, i64 1, !dbg !1138
  %and50 = lshr i32 %conv36, 6, !dbg !1138
  %25 = and i32 %and50, 4, !dbg !1138
  %cond = zext nneg i32 %25 to i64, !dbg !1138
  %add.ptr52 = getelementptr inbounds i8, ptr %add.ptr47, i64 %cond, !dbg !1138
  %and55 = shl nuw nsw i32 %conv36, 2, !dbg !1138
  %26 = and i32 %and55, 8, !dbg !1138
  %cond57 = zext nneg i32 %26 to i64, !dbg !1138
  %add.ptr58 = getelementptr inbounds i8, ptr %add.ptr52, i64 %cond57, !dbg !1138
  tail call void @llvm.dbg.value(metadata ptr %add.ptr58, metadata !1046, metadata !DIExpression()), !dbg !1140
  %orig_clsid = getelementptr inbounds i8, ptr %add.ptr58, i64 41, !dbg !1141
  %27 = load i8, ptr %orig_clsid, align 1, !dbg !1141, !tbaa !645
  %conv59 = zext i8 %27 to i32, !dbg !1142
  %call60 = tail call i32 @slabs_size(i32 noundef %conv59) #21, !dbg !1143
  tail call void @llvm.dbg.value(metadata i32 %call60, metadata !1045, metadata !DIExpression()), !dbg !1081
  br label %if.end61, !dbg !1144

if.end61:                                         ; preds = %if.then39, %if.then44
  %size.0 = phi i32 [ %call60, %if.then44 ], [ %call9, %if.then39 ], !dbg !1081
  %ch.0 = phi ptr [ %add.ptr58, %if.then44 ], [ %add.ptr, %if.then39 ], !dbg !1145
  tail call void @llvm.dbg.value(metadata ptr %ch.0, metadata !1046, metadata !DIExpression()), !dbg !1140
  tail call void @llvm.dbg.value(metadata i32 %size.0, metadata !1045, metadata !DIExpression()), !dbg !1081
  %28 = load ptr, ptr %ch.0, align 8, !dbg !1146, !tbaa !535
  %tobool63.not = icmp eq ptr %28, null, !dbg !1148
  br i1 %tobool63.not, label %if.end71, label %if.then64, !dbg !1149

if.then64:                                        ; preds = %if.end61
  %29 = ptrtoint ptr %28 to i64, !dbg !1150
  %sub66 = sub i64 %29, %8, !dbg !1152
  %30 = load ptr, ptr @mmap_base, align 8, !dbg !1153, !tbaa !535
  %31 = ptrtoint ptr %30 to i64, !dbg !1154
  %add69 = add i64 %sub66, %31, !dbg !1155
  %32 = inttoptr i64 %add69 to ptr, !dbg !1156
  store ptr %32, ptr %ch.0, align 8, !dbg !1157, !tbaa !535
  br label %if.end71, !dbg !1158

if.end71:                                         ; preds = %if.then64, %if.end61
  %prev72 = getelementptr inbounds i8, ptr %ch.0, i64 8, !dbg !1159
  %33 = load ptr, ptr %prev72, align 8, !dbg !1159, !tbaa !535
  %tobool73.not = icmp eq ptr %33, null, !dbg !1161
  br i1 %tobool73.not, label %if.end81, label %if.then74, !dbg !1162

if.then74:                                        ; preds = %if.end71
  %34 = ptrtoint ptr %33 to i64, !dbg !1163
  %sub76 = sub i64 %34, %8, !dbg !1165
  %35 = load ptr, ptr @mmap_base, align 8, !dbg !1166, !tbaa !535
  %36 = ptrtoint ptr %35 to i64, !dbg !1167
  %add79 = add i64 %sub76, %36, !dbg !1168
  %37 = inttoptr i64 %add79 to ptr, !dbg !1169
  store ptr %37, ptr %prev72, align 8, !dbg !1170, !tbaa !535
  br label %if.end81, !dbg !1171

if.end81:                                         ; preds = %if.then74, %if.end71
  %head = getelementptr inbounds i8, ptr %ch.0, i64 16, !dbg !1172
  %38 = load ptr, ptr %head, align 8, !dbg !1172, !tbaa !535
  %tobool82.not = icmp eq ptr %38, null, !dbg !1174
  br i1 %tobool82.not, label %if.end91, label %if.then83, !dbg !1175

if.then83:                                        ; preds = %if.end81
  %39 = ptrtoint ptr %38 to i64, !dbg !1176
  %sub85 = sub i64 %39, %8, !dbg !1178
  %40 = load ptr, ptr @mmap_base, align 8, !dbg !1179, !tbaa !535
  %41 = ptrtoint ptr %40 to i64, !dbg !1180
  %add88 = add i64 %sub85, %41, !dbg !1181
  %42 = inttoptr i64 %add88 to ptr, !dbg !1182
  store ptr %42, ptr %head, align 8, !dbg !1183, !tbaa !535
  br label %if.end91, !dbg !1184

if.end91:                                         ; preds = %if.end81, %if.then83, %if.end34
  %size.1 = phi i32 [ %call9, %if.end34 ], [ %size.0, %if.then83 ], [ %size.0, %if.end81 ], !dbg !1081
  tail call void @llvm.dbg.value(metadata i32 %size.1, metadata !1045, metadata !DIExpression()), !dbg !1081
  %conv92 = sext i32 %size.1 to i64, !dbg !1185
  %add93 = add i64 %checked.0173, %conv92, !dbg !1186
  tail call void @llvm.dbg.value(metadata i64 %add93, metadata !1039, metadata !DIExpression()), !dbg !1050
  %sub94 = sub i32 %page_remain.0172, %size.1, !dbg !1187
  tail call void @llvm.dbg.value(metadata i32 %sub94, metadata !1042, metadata !DIExpression()), !dbg !1050
  %cmp95 = icmp ugt i32 %size.1, %sub94, !dbg !1188
  br i1 %cmp95, label %if.then97, label %cleanup, !dbg !1190

if.then97:                                        ; preds = %if.end91
  %conv98 = zext i32 %sub94 to i64, !dbg !1191
  %add99 = add i64 %add93, %conv98, !dbg !1193
  tail call void @llvm.dbg.value(metadata i64 %add99, metadata !1039, metadata !DIExpression()), !dbg !1050
  %43 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 23), align 4, !dbg !1194, !tbaa !1053
  tail call void @llvm.dbg.value(metadata i32 %43, metadata !1042, metadata !DIExpression()), !dbg !1050
  br label %cleanup, !dbg !1195

cleanup:                                          ; preds = %if.end91, %if.then97, %if.then12
  %page_remain.2 = phi i32 [ %0, %if.then12 ], [ %43, %if.then97 ], [ %sub94, %if.end91 ], !dbg !1081
  %checked.2 = phi i64 [ %add, %if.then12 ], [ %add99, %if.then97 ], [ %add93, %if.end91 ], !dbg !1081
  tail call void @llvm.dbg.value(metadata i64 %checked.2, metadata !1039, metadata !DIExpression()), !dbg !1050
  tail call void @llvm.dbg.value(metadata i32 %page_remain.2, metadata !1042, metadata !DIExpression()), !dbg !1050
  %44 = load i64, ptr @slabmem_limit, align 8, !dbg !1076, !tbaa !610
  %cmp4 = icmp ult i64 %checked.2, %44, !dbg !1077
  br i1 %cmp4, label %while.body, label %while.end, !dbg !1078

while.end:                                        ; preds = %cleanup, %if.end
  %45 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1196, !tbaa !1059
  %cmp102 = icmp sgt i32 %45, 0, !dbg !1198
  br i1 %cmp102, label %if.then104, label %if.end111, !dbg !1199

if.then104:                                       ; preds = %while.end
  %call105 = call i32 @gettimeofday(ptr noundef nonnull %tv, ptr noundef null) #21, !dbg !1200
  %46 = load ptr, ptr @stderr, align 8, !dbg !1202, !tbaa !535
  %47 = load i64, ptr %tv, align 8, !dbg !1203, !tbaa !1068
  %conv107 = trunc i64 %47 to i32, !dbg !1204
  %tv_usec108 = getelementptr inbounds i8, ptr %tv, i64 8, !dbg !1205
  %48 = load i64, ptr %tv_usec108, align 8, !dbg !1205, !tbaa !1072
  %conv109 = trunc i64 %48 to i32, !dbg !1206
  %call110 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %46, ptr noundef nonnull @.str.14, i32 noundef %conv107, i32 noundef %conv109) #23, !dbg !1207
  br label %if.end111, !dbg !1208

if.end111:                                        ; preds = %if.then104, %while.end
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %tv) #21, !dbg !1209
  ret i32 0, !dbg !1210
}

; Function Attrs: nofree nounwind
declare !dbg !1211 noundef i32 @gettimeofday(ptr nocapture noundef, ptr nocapture noundef) local_unnamed_addr #3

declare !dbg !1218 i32 @slabs_fixup(ptr noundef, i32 noundef) local_unnamed_addr #5

declare !dbg !1223 void @do_item_link_fixup(ptr noundef) local_unnamed_addr #5

declare !dbg !1227 i32 @slabs_size(i32 noundef) local_unnamed_addr #5

declare !dbg !1230 i64 @__getdelim(ptr noundef, ptr noundef, i32 noundef, ptr noundef) local_unnamed_addr #5

; Function Attrs: nounwind
declare !dbg !1235 i64 @sysconf(i32 noundef) local_unnamed_addr #12

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare !dbg !1238 i64 @strlen(ptr nocapture noundef) local_unnamed_addr #7

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #13

; Function Attrs: nofree nounwind
declare !dbg !1241 noalias noundef ptr @fopen(ptr nocapture noundef readonly, ptr nocapture noundef readonly) local_unnamed_addr #3

; Function Attrs: nofree nounwind
declare !dbg !1244 noundef i32 @fclose(ptr nocapture noundef) local_unnamed_addr #3

; Function Attrs: nofree nounwind
declare !dbg !1247 noundef i32 @unlink(ptr nocapture noundef readonly) local_unnamed_addr #3

; Function Attrs: nounwind
declare !dbg !1248 i32 @umask(i32 noundef) local_unnamed_addr #12

; Function Attrs: nofree nounwind
declare noundef i64 @fwrite(ptr nocapture noundef, i64 noundef, i64 noundef, ptr nocapture noundef) local_unnamed_addr #14

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umax.i64(i64, i64) #15

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #16

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #17 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #15

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #15

attributes #0 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { mustprogress nofree nounwind willreturn memory(argmem: read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { mustprogress nocallback nofree nosync nounwind willreturn }
attributes #9 = { mustprogress nofree nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { nofree "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { cold nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #14 = { nofree nounwind }
attributes #15 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #16 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #17 = { nounwind uwtable }
attributes #18 = { nounwind allocsize(0,1) }
attributes #19 = { cold }
attributes #20 = { noreturn nounwind }
attributes #21 = { nounwind }
attributes #22 = { nobuiltin nounwind willreturn memory(read) }
attributes #23 = { cold nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!508, !509, !510, !511, !512, !513, !514}
!llvm.ident = !{!515}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "memory_file", scope: !2, file: !3, line: 27, type: !249, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !233, globals: !378, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "restart.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "746241a1abae182820c51a9ba83b9422")
!4 = !{!5, !13}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "restart_get_kv_ret", file: !6, line: 13, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "./restart.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "34d98453d5bea5bc37d52cb816cff5f2")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12}
!9 = !DIEnumerator(name: "RESTART_OK", value: 0)
!10 = !DIEnumerator(name: "RESTART_NOTAG", value: 1)
!11 = !DIEnumerator(name: "RESTART_BADLINE", value: 2)
!12 = !DIEnumerator(name: "RESTART_DONE", value: 3)
!13 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !14, line: 71, baseType: !7, size: 32, elements: !15)
!14 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/confname.h", directory: "", checksumkind: CSK_MD5, checksum: "8d90d434eef5f225e60d07c486f475d0")
!15 = !{!16, !17, !18, !19, !20, !21, !22, !23, !24, !25, !26, !27, !28, !29, !30, !31, !32, !33, !34, !35, !36, !37, !38, !39, !40, !41, !42, !43, !44, !45, !46, !47, !48, !49, !50, !51, !52, !53, !54, !55, !56, !57, !58, !59, !60, !61, !62, !63, !64, !65, !66, !67, !68, !69, !70, !71, !72, !73, !74, !75, !76, !77, !78, !79, !80, !81, !82, !83, !84, !85, !86, !87, !88, !89, !90, !91, !92, !93, !94, !95, !96, !97, !98, !99, !100, !101, !102, !103, !104, !105, !106, !107, !108, !109, !110, !111, !112, !113, !114, !115, !116, !117, !118, !119, !120, !121, !122, !123, !124, !125, !126, !127, !128, !129, !130, !131, !132, !133, !134, !135, !136, !137, !138, !139, !140, !141, !142, !143, !144, !145, !146, !147, !148, !149, !150, !151, !152, !153, !154, !155, !156, !157, !158, !159, !160, !161, !162, !163, !164, !165, !166, !167, !168, !169, !170, !171, !172, !173, !174, !175, !176, !177, !178, !179, !180, !181, !182, !183, !184, !185, !186, !187, !188, !189, !190, !191, !192, !193, !194, !195, !196, !197, !198, !199, !200, !201, !202, !203, !204, !205, !206, !207, !208, !209, !210, !211, !212, !213, !214, !215, !216, !217, !218, !219, !220, !221, !222, !223, !224, !225, !226, !227, !228, !229, !230, !231, !232}
!16 = !DIEnumerator(name: "_SC_ARG_MAX", value: 0)
!17 = !DIEnumerator(name: "_SC_CHILD_MAX", value: 1)
!18 = !DIEnumerator(name: "_SC_CLK_TCK", value: 2)
!19 = !DIEnumerator(name: "_SC_NGROUPS_MAX", value: 3)
!20 = !DIEnumerator(name: "_SC_OPEN_MAX", value: 4)
!21 = !DIEnumerator(name: "_SC_STREAM_MAX", value: 5)
!22 = !DIEnumerator(name: "_SC_TZNAME_MAX", value: 6)
!23 = !DIEnumerator(name: "_SC_JOB_CONTROL", value: 7)
!24 = !DIEnumerator(name: "_SC_SAVED_IDS", value: 8)
!25 = !DIEnumerator(name: "_SC_REALTIME_SIGNALS", value: 9)
!26 = !DIEnumerator(name: "_SC_PRIORITY_SCHEDULING", value: 10)
!27 = !DIEnumerator(name: "_SC_TIMERS", value: 11)
!28 = !DIEnumerator(name: "_SC_ASYNCHRONOUS_IO", value: 12)
!29 = !DIEnumerator(name: "_SC_PRIORITIZED_IO", value: 13)
!30 = !DIEnumerator(name: "_SC_SYNCHRONIZED_IO", value: 14)
!31 = !DIEnumerator(name: "_SC_FSYNC", value: 15)
!32 = !DIEnumerator(name: "_SC_MAPPED_FILES", value: 16)
!33 = !DIEnumerator(name: "_SC_MEMLOCK", value: 17)
!34 = !DIEnumerator(name: "_SC_MEMLOCK_RANGE", value: 18)
!35 = !DIEnumerator(name: "_SC_MEMORY_PROTECTION", value: 19)
!36 = !DIEnumerator(name: "_SC_MESSAGE_PASSING", value: 20)
!37 = !DIEnumerator(name: "_SC_SEMAPHORES", value: 21)
!38 = !DIEnumerator(name: "_SC_SHARED_MEMORY_OBJECTS", value: 22)
!39 = !DIEnumerator(name: "_SC_AIO_LISTIO_MAX", value: 23)
!40 = !DIEnumerator(name: "_SC_AIO_MAX", value: 24)
!41 = !DIEnumerator(name: "_SC_AIO_PRIO_DELTA_MAX", value: 25)
!42 = !DIEnumerator(name: "_SC_DELAYTIMER_MAX", value: 26)
!43 = !DIEnumerator(name: "_SC_MQ_OPEN_MAX", value: 27)
!44 = !DIEnumerator(name: "_SC_MQ_PRIO_MAX", value: 28)
!45 = !DIEnumerator(name: "_SC_VERSION", value: 29)
!46 = !DIEnumerator(name: "_SC_PAGESIZE", value: 30)
!47 = !DIEnumerator(name: "_SC_RTSIG_MAX", value: 31)
!48 = !DIEnumerator(name: "_SC_SEM_NSEMS_MAX", value: 32)
!49 = !DIEnumerator(name: "_SC_SEM_VALUE_MAX", value: 33)
!50 = !DIEnumerator(name: "_SC_SIGQUEUE_MAX", value: 34)
!51 = !DIEnumerator(name: "_SC_TIMER_MAX", value: 35)
!52 = !DIEnumerator(name: "_SC_BC_BASE_MAX", value: 36)
!53 = !DIEnumerator(name: "_SC_BC_DIM_MAX", value: 37)
!54 = !DIEnumerator(name: "_SC_BC_SCALE_MAX", value: 38)
!55 = !DIEnumerator(name: "_SC_BC_STRING_MAX", value: 39)
!56 = !DIEnumerator(name: "_SC_COLL_WEIGHTS_MAX", value: 40)
!57 = !DIEnumerator(name: "_SC_EQUIV_CLASS_MAX", value: 41)
!58 = !DIEnumerator(name: "_SC_EXPR_NEST_MAX", value: 42)
!59 = !DIEnumerator(name: "_SC_LINE_MAX", value: 43)
!60 = !DIEnumerator(name: "_SC_RE_DUP_MAX", value: 44)
!61 = !DIEnumerator(name: "_SC_CHARCLASS_NAME_MAX", value: 45)
!62 = !DIEnumerator(name: "_SC_2_VERSION", value: 46)
!63 = !DIEnumerator(name: "_SC_2_C_BIND", value: 47)
!64 = !DIEnumerator(name: "_SC_2_C_DEV", value: 48)
!65 = !DIEnumerator(name: "_SC_2_FORT_DEV", value: 49)
!66 = !DIEnumerator(name: "_SC_2_FORT_RUN", value: 50)
!67 = !DIEnumerator(name: "_SC_2_SW_DEV", value: 51)
!68 = !DIEnumerator(name: "_SC_2_LOCALEDEF", value: 52)
!69 = !DIEnumerator(name: "_SC_PII", value: 53)
!70 = !DIEnumerator(name: "_SC_PII_XTI", value: 54)
!71 = !DIEnumerator(name: "_SC_PII_SOCKET", value: 55)
!72 = !DIEnumerator(name: "_SC_PII_INTERNET", value: 56)
!73 = !DIEnumerator(name: "_SC_PII_OSI", value: 57)
!74 = !DIEnumerator(name: "_SC_POLL", value: 58)
!75 = !DIEnumerator(name: "_SC_SELECT", value: 59)
!76 = !DIEnumerator(name: "_SC_UIO_MAXIOV", value: 60)
!77 = !DIEnumerator(name: "_SC_IOV_MAX", value: 60)
!78 = !DIEnumerator(name: "_SC_PII_INTERNET_STREAM", value: 61)
!79 = !DIEnumerator(name: "_SC_PII_INTERNET_DGRAM", value: 62)
!80 = !DIEnumerator(name: "_SC_PII_OSI_COTS", value: 63)
!81 = !DIEnumerator(name: "_SC_PII_OSI_CLTS", value: 64)
!82 = !DIEnumerator(name: "_SC_PII_OSI_M", value: 65)
!83 = !DIEnumerator(name: "_SC_T_IOV_MAX", value: 66)
!84 = !DIEnumerator(name: "_SC_THREADS", value: 67)
!85 = !DIEnumerator(name: "_SC_THREAD_SAFE_FUNCTIONS", value: 68)
!86 = !DIEnumerator(name: "_SC_GETGR_R_SIZE_MAX", value: 69)
!87 = !DIEnumerator(name: "_SC_GETPW_R_SIZE_MAX", value: 70)
!88 = !DIEnumerator(name: "_SC_LOGIN_NAME_MAX", value: 71)
!89 = !DIEnumerator(name: "_SC_TTY_NAME_MAX", value: 72)
!90 = !DIEnumerator(name: "_SC_THREAD_DESTRUCTOR_ITERATIONS", value: 73)
!91 = !DIEnumerator(name: "_SC_THREAD_KEYS_MAX", value: 74)
!92 = !DIEnumerator(name: "_SC_THREAD_STACK_MIN", value: 75)
!93 = !DIEnumerator(name: "_SC_THREAD_THREADS_MAX", value: 76)
!94 = !DIEnumerator(name: "_SC_THREAD_ATTR_STACKADDR", value: 77)
!95 = !DIEnumerator(name: "_SC_THREAD_ATTR_STACKSIZE", value: 78)
!96 = !DIEnumerator(name: "_SC_THREAD_PRIORITY_SCHEDULING", value: 79)
!97 = !DIEnumerator(name: "_SC_THREAD_PRIO_INHERIT", value: 80)
!98 = !DIEnumerator(name: "_SC_THREAD_PRIO_PROTECT", value: 81)
!99 = !DIEnumerator(name: "_SC_THREAD_PROCESS_SHARED", value: 82)
!100 = !DIEnumerator(name: "_SC_NPROCESSORS_CONF", value: 83)
!101 = !DIEnumerator(name: "_SC_NPROCESSORS_ONLN", value: 84)
!102 = !DIEnumerator(name: "_SC_PHYS_PAGES", value: 85)
!103 = !DIEnumerator(name: "_SC_AVPHYS_PAGES", value: 86)
!104 = !DIEnumerator(name: "_SC_ATEXIT_MAX", value: 87)
!105 = !DIEnumerator(name: "_SC_PASS_MAX", value: 88)
!106 = !DIEnumerator(name: "_SC_XOPEN_VERSION", value: 89)
!107 = !DIEnumerator(name: "_SC_XOPEN_XCU_VERSION", value: 90)
!108 = !DIEnumerator(name: "_SC_XOPEN_UNIX", value: 91)
!109 = !DIEnumerator(name: "_SC_XOPEN_CRYPT", value: 92)
!110 = !DIEnumerator(name: "_SC_XOPEN_ENH_I18N", value: 93)
!111 = !DIEnumerator(name: "_SC_XOPEN_SHM", value: 94)
!112 = !DIEnumerator(name: "_SC_2_CHAR_TERM", value: 95)
!113 = !DIEnumerator(name: "_SC_2_C_VERSION", value: 96)
!114 = !DIEnumerator(name: "_SC_2_UPE", value: 97)
!115 = !DIEnumerator(name: "_SC_XOPEN_XPG2", value: 98)
!116 = !DIEnumerator(name: "_SC_XOPEN_XPG3", value: 99)
!117 = !DIEnumerator(name: "_SC_XOPEN_XPG4", value: 100)
!118 = !DIEnumerator(name: "_SC_CHAR_BIT", value: 101)
!119 = !DIEnumerator(name: "_SC_CHAR_MAX", value: 102)
!120 = !DIEnumerator(name: "_SC_CHAR_MIN", value: 103)
!121 = !DIEnumerator(name: "_SC_INT_MAX", value: 104)
!122 = !DIEnumerator(name: "_SC_INT_MIN", value: 105)
!123 = !DIEnumerator(name: "_SC_LONG_BIT", value: 106)
!124 = !DIEnumerator(name: "_SC_WORD_BIT", value: 107)
!125 = !DIEnumerator(name: "_SC_MB_LEN_MAX", value: 108)
!126 = !DIEnumerator(name: "_SC_NZERO", value: 109)
!127 = !DIEnumerator(name: "_SC_SSIZE_MAX", value: 110)
!128 = !DIEnumerator(name: "_SC_SCHAR_MAX", value: 111)
!129 = !DIEnumerator(name: "_SC_SCHAR_MIN", value: 112)
!130 = !DIEnumerator(name: "_SC_SHRT_MAX", value: 113)
!131 = !DIEnumerator(name: "_SC_SHRT_MIN", value: 114)
!132 = !DIEnumerator(name: "_SC_UCHAR_MAX", value: 115)
!133 = !DIEnumerator(name: "_SC_UINT_MAX", value: 116)
!134 = !DIEnumerator(name: "_SC_ULONG_MAX", value: 117)
!135 = !DIEnumerator(name: "_SC_USHRT_MAX", value: 118)
!136 = !DIEnumerator(name: "_SC_NL_ARGMAX", value: 119)
!137 = !DIEnumerator(name: "_SC_NL_LANGMAX", value: 120)
!138 = !DIEnumerator(name: "_SC_NL_MSGMAX", value: 121)
!139 = !DIEnumerator(name: "_SC_NL_NMAX", value: 122)
!140 = !DIEnumerator(name: "_SC_NL_SETMAX", value: 123)
!141 = !DIEnumerator(name: "_SC_NL_TEXTMAX", value: 124)
!142 = !DIEnumerator(name: "_SC_XBS5_ILP32_OFF32", value: 125)
!143 = !DIEnumerator(name: "_SC_XBS5_ILP32_OFFBIG", value: 126)
!144 = !DIEnumerator(name: "_SC_XBS5_LP64_OFF64", value: 127)
!145 = !DIEnumerator(name: "_SC_XBS5_LPBIG_OFFBIG", value: 128)
!146 = !DIEnumerator(name: "_SC_XOPEN_LEGACY", value: 129)
!147 = !DIEnumerator(name: "_SC_XOPEN_REALTIME", value: 130)
!148 = !DIEnumerator(name: "_SC_XOPEN_REALTIME_THREADS", value: 131)
!149 = !DIEnumerator(name: "_SC_ADVISORY_INFO", value: 132)
!150 = !DIEnumerator(name: "_SC_BARRIERS", value: 133)
!151 = !DIEnumerator(name: "_SC_BASE", value: 134)
!152 = !DIEnumerator(name: "_SC_C_LANG_SUPPORT", value: 135)
!153 = !DIEnumerator(name: "_SC_C_LANG_SUPPORT_R", value: 136)
!154 = !DIEnumerator(name: "_SC_CLOCK_SELECTION", value: 137)
!155 = !DIEnumerator(name: "_SC_CPUTIME", value: 138)
!156 = !DIEnumerator(name: "_SC_THREAD_CPUTIME", value: 139)
!157 = !DIEnumerator(name: "_SC_DEVICE_IO", value: 140)
!158 = !DIEnumerator(name: "_SC_DEVICE_SPECIFIC", value: 141)
!159 = !DIEnumerator(name: "_SC_DEVICE_SPECIFIC_R", value: 142)
!160 = !DIEnumerator(name: "_SC_FD_MGMT", value: 143)
!161 = !DIEnumerator(name: "_SC_FIFO", value: 144)
!162 = !DIEnumerator(name: "_SC_PIPE", value: 145)
!163 = !DIEnumerator(name: "_SC_FILE_ATTRIBUTES", value: 146)
!164 = !DIEnumerator(name: "_SC_FILE_LOCKING", value: 147)
!165 = !DIEnumerator(name: "_SC_FILE_SYSTEM", value: 148)
!166 = !DIEnumerator(name: "_SC_MONOTONIC_CLOCK", value: 149)
!167 = !DIEnumerator(name: "_SC_MULTI_PROCESS", value: 150)
!168 = !DIEnumerator(name: "_SC_SINGLE_PROCESS", value: 151)
!169 = !DIEnumerator(name: "_SC_NETWORKING", value: 152)
!170 = !DIEnumerator(name: "_SC_READER_WRITER_LOCKS", value: 153)
!171 = !DIEnumerator(name: "_SC_SPIN_LOCKS", value: 154)
!172 = !DIEnumerator(name: "_SC_REGEXP", value: 155)
!173 = !DIEnumerator(name: "_SC_REGEX_VERSION", value: 156)
!174 = !DIEnumerator(name: "_SC_SHELL", value: 157)
!175 = !DIEnumerator(name: "_SC_SIGNALS", value: 158)
!176 = !DIEnumerator(name: "_SC_SPAWN", value: 159)
!177 = !DIEnumerator(name: "_SC_SPORADIC_SERVER", value: 160)
!178 = !DIEnumerator(name: "_SC_THREAD_SPORADIC_SERVER", value: 161)
!179 = !DIEnumerator(name: "_SC_SYSTEM_DATABASE", value: 162)
!180 = !DIEnumerator(name: "_SC_SYSTEM_DATABASE_R", value: 163)
!181 = !DIEnumerator(name: "_SC_TIMEOUTS", value: 164)
!182 = !DIEnumerator(name: "_SC_TYPED_MEMORY_OBJECTS", value: 165)
!183 = !DIEnumerator(name: "_SC_USER_GROUPS", value: 166)
!184 = !DIEnumerator(name: "_SC_USER_GROUPS_R", value: 167)
!185 = !DIEnumerator(name: "_SC_2_PBS", value: 168)
!186 = !DIEnumerator(name: "_SC_2_PBS_ACCOUNTING", value: 169)
!187 = !DIEnumerator(name: "_SC_2_PBS_LOCATE", value: 170)
!188 = !DIEnumerator(name: "_SC_2_PBS_MESSAGE", value: 171)
!189 = !DIEnumerator(name: "_SC_2_PBS_TRACK", value: 172)
!190 = !DIEnumerator(name: "_SC_SYMLOOP_MAX", value: 173)
!191 = !DIEnumerator(name: "_SC_STREAMS", value: 174)
!192 = !DIEnumerator(name: "_SC_2_PBS_CHECKPOINT", value: 175)
!193 = !DIEnumerator(name: "_SC_V6_ILP32_OFF32", value: 176)
!194 = !DIEnumerator(name: "_SC_V6_ILP32_OFFBIG", value: 177)
!195 = !DIEnumerator(name: "_SC_V6_LP64_OFF64", value: 178)
!196 = !DIEnumerator(name: "_SC_V6_LPBIG_OFFBIG", value: 179)
!197 = !DIEnumerator(name: "_SC_HOST_NAME_MAX", value: 180)
!198 = !DIEnumerator(name: "_SC_TRACE", value: 181)
!199 = !DIEnumerator(name: "_SC_TRACE_EVENT_FILTER", value: 182)
!200 = !DIEnumerator(name: "_SC_TRACE_INHERIT", value: 183)
!201 = !DIEnumerator(name: "_SC_TRACE_LOG", value: 184)
!202 = !DIEnumerator(name: "_SC_LEVEL1_ICACHE_SIZE", value: 185)
!203 = !DIEnumerator(name: "_SC_LEVEL1_ICACHE_ASSOC", value: 186)
!204 = !DIEnumerator(name: "_SC_LEVEL1_ICACHE_LINESIZE", value: 187)
!205 = !DIEnumerator(name: "_SC_LEVEL1_DCACHE_SIZE", value: 188)
!206 = !DIEnumerator(name: "_SC_LEVEL1_DCACHE_ASSOC", value: 189)
!207 = !DIEnumerator(name: "_SC_LEVEL1_DCACHE_LINESIZE", value: 190)
!208 = !DIEnumerator(name: "_SC_LEVEL2_CACHE_SIZE", value: 191)
!209 = !DIEnumerator(name: "_SC_LEVEL2_CACHE_ASSOC", value: 192)
!210 = !DIEnumerator(name: "_SC_LEVEL2_CACHE_LINESIZE", value: 193)
!211 = !DIEnumerator(name: "_SC_LEVEL3_CACHE_SIZE", value: 194)
!212 = !DIEnumerator(name: "_SC_LEVEL3_CACHE_ASSOC", value: 195)
!213 = !DIEnumerator(name: "_SC_LEVEL3_CACHE_LINESIZE", value: 196)
!214 = !DIEnumerator(name: "_SC_LEVEL4_CACHE_SIZE", value: 197)
!215 = !DIEnumerator(name: "_SC_LEVEL4_CACHE_ASSOC", value: 198)
!216 = !DIEnumerator(name: "_SC_LEVEL4_CACHE_LINESIZE", value: 199)
!217 = !DIEnumerator(name: "_SC_IPV6", value: 235)
!218 = !DIEnumerator(name: "_SC_RAW_SOCKETS", value: 236)
!219 = !DIEnumerator(name: "_SC_V7_ILP32_OFF32", value: 237)
!220 = !DIEnumerator(name: "_SC_V7_ILP32_OFFBIG", value: 238)
!221 = !DIEnumerator(name: "_SC_V7_LP64_OFF64", value: 239)
!222 = !DIEnumerator(name: "_SC_V7_LPBIG_OFFBIG", value: 240)
!223 = !DIEnumerator(name: "_SC_SS_REPL_MAX", value: 241)
!224 = !DIEnumerator(name: "_SC_TRACE_EVENT_NAME_MAX", value: 242)
!225 = !DIEnumerator(name: "_SC_TRACE_NAME_MAX", value: 243)
!226 = !DIEnumerator(name: "_SC_TRACE_SYS_MAX", value: 244)
!227 = !DIEnumerator(name: "_SC_TRACE_USER_EVENT_MAX", value: 245)
!228 = !DIEnumerator(name: "_SC_XOPEN_STREAMS", value: 246)
!229 = !DIEnumerator(name: "_SC_THREAD_ROBUST_PRIO_INHERIT", value: 247)
!230 = !DIEnumerator(name: "_SC_THREAD_ROBUST_PRIO_PROTECT", value: 248)
!231 = !DIEnumerator(name: "_SC_MINSIGSTKSZ", value: 249)
!232 = !DIEnumerator(name: "_SC_SIGSTKSZ", value: 250)
!233 = !{!234, !235, !247, !326, !249, !360, !361}
!234 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!235 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !236, size: 64)
!236 = !DIDerivedType(tag: DW_TAG_typedef, name: "restart_cb_ctx", file: !3, line: 65, baseType: !237)
!237 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 60, size: 256, elements: !238)
!238 = !{!239, !302, !323, !324}
!239 = !DIDerivedType(tag: DW_TAG_member, name: "f", scope: !237, file: !3, line: 61, baseType: !240, size: 64)
!240 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !241, size: 64)
!241 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !242, line: 7, baseType: !243)
!242 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!243 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !244, line: 49, size: 1728, elements: !245)
!244 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "7a6d4a00a37ee6b9a40cd04bd01f5d00")
!245 = !{!246, !248, !251, !252, !253, !254, !255, !256, !257, !258, !259, !260, !261, !264, !266, !267, !268, !272, !274, !276, !280, !283, !285, !288, !291, !292, !293, !297, !298}
!246 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !243, file: !244, line: 51, baseType: !247, size: 32)
!247 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!248 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !243, file: !244, line: 54, baseType: !249, size: 64, offset: 64)
!249 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !250, size: 64)
!250 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!251 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !243, file: !244, line: 55, baseType: !249, size: 64, offset: 128)
!252 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !243, file: !244, line: 56, baseType: !249, size: 64, offset: 192)
!253 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !243, file: !244, line: 57, baseType: !249, size: 64, offset: 256)
!254 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !243, file: !244, line: 58, baseType: !249, size: 64, offset: 320)
!255 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !243, file: !244, line: 59, baseType: !249, size: 64, offset: 384)
!256 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !243, file: !244, line: 60, baseType: !249, size: 64, offset: 448)
!257 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !243, file: !244, line: 61, baseType: !249, size: 64, offset: 512)
!258 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !243, file: !244, line: 64, baseType: !249, size: 64, offset: 576)
!259 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !243, file: !244, line: 65, baseType: !249, size: 64, offset: 640)
!260 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !243, file: !244, line: 66, baseType: !249, size: 64, offset: 704)
!261 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !243, file: !244, line: 68, baseType: !262, size: 64, offset: 768)
!262 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !263, size: 64)
!263 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !244, line: 36, flags: DIFlagFwdDecl)
!264 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !243, file: !244, line: 70, baseType: !265, size: 64, offset: 832)
!265 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !243, size: 64)
!266 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !243, file: !244, line: 72, baseType: !247, size: 32, offset: 896)
!267 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !243, file: !244, line: 73, baseType: !247, size: 32, offset: 928)
!268 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !243, file: !244, line: 74, baseType: !269, size: 64, offset: 960)
!269 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !270, line: 152, baseType: !271)
!270 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!271 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!272 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !243, file: !244, line: 77, baseType: !273, size: 16, offset: 1024)
!273 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!274 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !243, file: !244, line: 78, baseType: !275, size: 8, offset: 1040)
!275 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!276 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !243, file: !244, line: 79, baseType: !277, size: 8, offset: 1048)
!277 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 8, elements: !278)
!278 = !{!279}
!279 = !DISubrange(count: 1)
!280 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !243, file: !244, line: 81, baseType: !281, size: 64, offset: 1088)
!281 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !282, size: 64)
!282 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !244, line: 43, baseType: null)
!283 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !243, file: !244, line: 89, baseType: !284, size: 64, offset: 1152)
!284 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !270, line: 153, baseType: !271)
!285 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !243, file: !244, line: 91, baseType: !286, size: 64, offset: 1216)
!286 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !287, size: 64)
!287 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !244, line: 37, flags: DIFlagFwdDecl)
!288 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !243, file: !244, line: 92, baseType: !289, size: 64, offset: 1280)
!289 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !290, size: 64)
!290 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !244, line: 38, flags: DIFlagFwdDecl)
!291 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !243, file: !244, line: 93, baseType: !265, size: 64, offset: 1344)
!292 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !243, file: !244, line: 94, baseType: !234, size: 64, offset: 1408)
!293 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !243, file: !244, line: 95, baseType: !294, size: 64, offset: 1472)
!294 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !295, line: 18, baseType: !296)
!295 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!296 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!297 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !243, file: !244, line: 96, baseType: !247, size: 32, offset: 1536)
!298 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !243, file: !244, line: 98, baseType: !299, size: 160, offset: 1568)
!299 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 160, elements: !300)
!300 = !{!301}
!301 = !DISubrange(count: 20)
!302 = !DIDerivedType(tag: DW_TAG_member, name: "cb", scope: !237, file: !3, line: 62, baseType: !303, size: 64, offset: 64)
!303 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !304, size: 64)
!304 = !DIDerivedType(tag: DW_TAG_typedef, name: "restart_data_cb", file: !3, line: 13, baseType: !305)
!305 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_restart_data_cb", file: !3, line: 15, size: 2304, elements: !306)
!306 = !{!307, !308, !310, !317, !319}
!307 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !305, file: !3, line: 16, baseType: !234, size: 64)
!308 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !305, file: !3, line: 17, baseType: !309, size: 64, offset: 64)
!309 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !305, size: 64)
!310 = !DIDerivedType(tag: DW_TAG_member, name: "ccb", scope: !305, file: !3, line: 18, baseType: !311, size: 64, offset: 128)
!311 = !DIDerivedType(tag: DW_TAG_typedef, name: "restart_check_cb", file: !6, line: 17, baseType: !312)
!312 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !313, size: 64)
!313 = !DISubroutineType(types: !314)
!314 = !{!247, !315, !234, !234}
!315 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !316, size: 64)
!316 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !250)
!317 = !DIDerivedType(tag: DW_TAG_member, name: "scb", scope: !305, file: !3, line: 19, baseType: !318, size: 64, offset: 192)
!318 = !DIDerivedType(tag: DW_TAG_typedef, name: "restart_save_cb", file: !6, line: 18, baseType: !312)
!319 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !305, file: !3, line: 20, baseType: !320, size: 2040, offset: 256)
!320 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 2040, elements: !321)
!321 = !{!322}
!322 = !DISubrange(count: 255)
!323 = !DIDerivedType(tag: DW_TAG_member, name: "line", scope: !237, file: !3, line: 63, baseType: !249, size: 64, offset: 128)
!324 = !DIDerivedType(tag: DW_TAG_member, name: "done", scope: !237, file: !3, line: 64, baseType: !325, size: 8, offset: 192)
!325 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!326 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !327, size: 64)
!327 = !DIDerivedType(tag: DW_TAG_typedef, name: "item", file: !328, line: 616, baseType: !329)
!328 = !DIFile(filename: "./memcached.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "a52021954a5d6b153b5bc084e2fbff2b")
!329 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_stritem", file: !328, line: 593, size: 384, elements: !330)
!330 = !{!331, !333, !334, !335, !338, !339, !340, !341, !345, !349, !350}
!331 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !329, file: !328, line: 595, baseType: !332, size: 64)
!332 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !329, size: 64)
!333 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !329, file: !328, line: 596, baseType: !332, size: 64, offset: 64)
!334 = !DIDerivedType(tag: DW_TAG_member, name: "h_next", scope: !329, file: !328, line: 598, baseType: !332, size: 64, offset: 128)
!335 = !DIDerivedType(tag: DW_TAG_member, name: "time", scope: !329, file: !328, line: 599, baseType: !336, size: 32, offset: 192)
!336 = !DIDerivedType(tag: DW_TAG_typedef, name: "rel_time_t", file: !337, line: 14, baseType: !7)
!337 = !DIFile(filename: "./logger.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "e743c4228b1e0bc1c91bec9cfd28d5ab")
!338 = !DIDerivedType(tag: DW_TAG_member, name: "exptime", scope: !329, file: !328, line: 600, baseType: !336, size: 32, offset: 224)
!339 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !329, file: !328, line: 601, baseType: !247, size: 32, offset: 256)
!340 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !329, file: !328, line: 602, baseType: !273, size: 16, offset: 288)
!341 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !329, file: !328, line: 603, baseType: !342, size: 16, offset: 304)
!342 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint16_t", file: !343, line: 25, baseType: !344)
!343 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!344 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint16_t", file: !270, line: 40, baseType: !273)
!345 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !329, file: !328, line: 604, baseType: !346, size: 8, offset: 320)
!346 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !343, line: 24, baseType: !347)
!347 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !270, line: 38, baseType: !348)
!348 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!349 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !329, file: !328, line: 605, baseType: !346, size: 8, offset: 328)
!350 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !329, file: !328, line: 611, baseType: !351, offset: 384)
!351 = !DICompositeType(tag: DW_TAG_array_type, baseType: !352, elements: !358)
!352 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !329, file: !328, line: 608, size: 64, elements: !353)
!353 = !{!354, !357}
!354 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !352, file: !328, line: 609, baseType: !355, size: 64)
!355 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !343, line: 27, baseType: !356)
!356 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !270, line: 45, baseType: !296)
!357 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !352, file: !328, line: 610, baseType: !250, size: 8)
!358 = !{!359}
!359 = !DISubrange(count: -1)
!360 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_ptr_t", file: !6, line: 8, baseType: !355)
!361 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !362, size: 64)
!362 = !DIDerivedType(tag: DW_TAG_typedef, name: "item_chunk", file: !328, line: 653, baseType: !363)
!363 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_strchunk", file: !328, line: 641, size: 384, elements: !364)
!364 = !{!365, !367, !368, !369, !370, !371, !372, !373, !374, !375, !376}
!365 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !363, file: !328, line: 642, baseType: !366, size: 64)
!366 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !363, size: 64)
!367 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !363, file: !328, line: 643, baseType: !366, size: 64, offset: 64)
!368 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !363, file: !328, line: 644, baseType: !332, size: 64, offset: 128)
!369 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !363, file: !328, line: 645, baseType: !247, size: 32, offset: 192)
!370 = !DIDerivedType(tag: DW_TAG_member, name: "used", scope: !363, file: !328, line: 646, baseType: !247, size: 32, offset: 224)
!371 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !363, file: !328, line: 647, baseType: !247, size: 32, offset: 256)
!372 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !363, file: !328, line: 648, baseType: !273, size: 16, offset: 288)
!373 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !363, file: !328, line: 649, baseType: !342, size: 16, offset: 304)
!374 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !363, file: !328, line: 650, baseType: !346, size: 8, offset: 320)
!375 = !DIDerivedType(tag: DW_TAG_member, name: "orig_clsid", scope: !363, file: !328, line: 651, baseType: !346, size: 8, offset: 328)
!376 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !363, file: !328, line: 652, baseType: !377, offset: 336)
!377 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, elements: !358)
!378 = !{!0, !379, !384, !389, !394, !399, !404, !409, !414, !416, !421, !426, !431, !436, !441, !443, !448, !450, !452, !454, !456, !461, !466, !471, !476, !481, !486, !491, !496, !498, !503}
!379 = !DIGlobalVariableExpression(var: !380, expr: !DIExpression())
!380 = distinct !DIGlobalVariable(scope: null, file: !3, line: 36, type: !381, isLocal: true, isDefinition: true)
!381 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 384, elements: !382)
!382 = !{!383}
!383 = !DISubrange(count: 48)
!384 = !DIGlobalVariableExpression(var: !385, expr: !DIExpression())
!385 = distinct !DIGlobalVariable(scope: null, file: !3, line: 174, type: !386, isLocal: true, isDefinition: true)
!386 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 480, elements: !387)
!387 = !{!388}
!388 = !DISubrange(count: 60)
!389 = !DIGlobalVariableExpression(var: !390, expr: !DIExpression())
!390 = distinct !DIGlobalVariable(scope: null, file: !3, line: 201, type: !391, isLocal: true, isDefinition: true)
!391 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 304, elements: !392)
!392 = !{!393}
!393 = !DISubrange(count: 38)
!394 = !DIGlobalVariableExpression(var: !395, expr: !DIExpression())
!395 = distinct !DIGlobalVariable(scope: null, file: !3, line: 280, type: !396, isLocal: true, isDefinition: true)
!396 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 616, elements: !397)
!397 = !{!398}
!398 = !DISubrange(count: 77)
!399 = !DIGlobalVariableExpression(var: !400, expr: !DIExpression())
!400 = distinct !DIGlobalVariable(scope: null, file: !3, line: 285, type: !401, isLocal: true, isDefinition: true)
!401 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 64, elements: !402)
!402 = !{!403}
!403 = !DISubrange(count: 8)
!404 = !DIGlobalVariableExpression(var: !405, expr: !DIExpression())
!405 = distinct !DIGlobalVariable(scope: null, file: !3, line: 305, type: !406, isLocal: true, isDefinition: true)
!406 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 232, elements: !407)
!407 = !{!408}
!408 = !DISubrange(count: 29)
!409 = !DIGlobalVariableExpression(var: !410, expr: !DIExpression())
!410 = distinct !DIGlobalVariable(scope: null, file: !3, line: 309, type: !411, isLocal: true, isDefinition: true)
!411 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 136, elements: !412)
!412 = !{!413}
!413 = !DISubrange(count: 17)
!414 = !DIGlobalVariableExpression(var: !415, expr: !DIExpression())
!415 = distinct !DIGlobalVariable(scope: null, file: !3, line: 316, type: !396, isLocal: true, isDefinition: true)
!416 = !DIGlobalVariableExpression(var: !417, expr: !DIExpression())
!417 = distinct !DIGlobalVariable(scope: null, file: !3, line: 321, type: !418, isLocal: true, isDefinition: true)
!418 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 200, elements: !419)
!419 = !{!420}
!420 = !DISubrange(count: 25)
!421 = !DIGlobalVariableExpression(var: !422, expr: !DIExpression())
!422 = distinct !DIGlobalVariable(scope: null, file: !3, line: 339, type: !423, isLocal: true, isDefinition: true)
!423 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 272, elements: !424)
!424 = !{!425}
!425 = !DISubrange(count: 34)
!426 = !DIGlobalVariableExpression(var: !427, expr: !DIExpression())
!427 = distinct !DIGlobalVariable(scope: null, file: !3, line: 343, type: !428, isLocal: true, isDefinition: true)
!428 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 328, elements: !429)
!429 = !{!430}
!430 = !DISubrange(count: 41)
!431 = !DIGlobalVariableExpression(var: !432, expr: !DIExpression())
!432 = distinct !DIGlobalVariable(scope: null, file: !3, line: 345, type: !433, isLocal: true, isDefinition: true)
!433 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 344, elements: !434)
!434 = !{!435}
!435 = !DISubrange(count: 43)
!436 = !DIGlobalVariableExpression(var: !437, expr: !DIExpression())
!437 = distinct !DIGlobalVariable(scope: null, file: !3, line: 362, type: !438, isLocal: true, isDefinition: true)
!438 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 424, elements: !439)
!439 = !{!440}
!440 = !DISubrange(count: 53)
!441 = !DIGlobalVariableExpression(var: !442, expr: !DIExpression())
!442 = distinct !DIGlobalVariable(scope: null, file: !3, line: 363, type: !423, isLocal: true, isDefinition: true)
!443 = !DIGlobalVariableExpression(var: !444, expr: !DIExpression())
!444 = distinct !DIGlobalVariable(scope: null, file: !3, line: 439, type: !445, isLocal: true, isDefinition: true)
!445 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 256, elements: !446)
!446 = !{!447}
!447 = !DISubrange(count: 32)
!448 = !DIGlobalVariableExpression(var: !449, expr: !DIExpression())
!449 = distinct !DIGlobalVariable(name: "cb_stack", scope: !2, file: !3, line: 29, type: !303, isLocal: true, isDefinition: true)
!450 = !DIGlobalVariableExpression(var: !451, expr: !DIExpression())
!451 = distinct !DIGlobalVariable(name: "mmap_fd", scope: !2, file: !3, line: 24, type: !247, isLocal: true, isDefinition: true)
!452 = !DIGlobalVariableExpression(var: !453, expr: !DIExpression())
!453 = distinct !DIGlobalVariable(name: "mmap_base", scope: !2, file: !3, line: 25, type: !234, isLocal: true, isDefinition: true)
!454 = !DIGlobalVariableExpression(var: !455, expr: !DIExpression())
!455 = distinct !DIGlobalVariable(name: "slabmem_limit", scope: !2, file: !3, line: 26, type: !294, isLocal: true, isDefinition: true)
!456 = !DIGlobalVariableExpression(var: !457, expr: !DIExpression())
!457 = distinct !DIGlobalVariable(scope: null, file: !3, line: 75, type: !458, isLocal: true, isDefinition: true)
!458 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 48, elements: !459)
!459 = !{!460}
!460 = !DISubrange(count: 6)
!461 = !DIGlobalVariableExpression(var: !462, expr: !DIExpression())
!462 = distinct !DIGlobalVariable(scope: null, file: !3, line: 79, type: !463, isLocal: true, isDefinition: true)
!463 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 440, elements: !464)
!464 = !{!465}
!465 = !DISubrange(count: 55)
!466 = !DIGlobalVariableExpression(var: !467, expr: !DIExpression())
!467 = distinct !DIGlobalVariable(scope: null, file: !3, line: 85, type: !468, isLocal: true, isDefinition: true)
!468 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 16, elements: !469)
!469 = !{!470}
!470 = !DISubrange(count: 2)
!471 = !DIGlobalVariableExpression(var: !472, expr: !DIExpression())
!472 = distinct !DIGlobalVariable(scope: null, file: !3, line: 87, type: !473, isLocal: true, isDefinition: true)
!473 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 496, elements: !474)
!474 = !{!475}
!475 = !DISubrange(count: 62)
!476 = !DIGlobalVariableExpression(var: !477, expr: !DIExpression())
!477 = distinct !DIGlobalVariable(scope: null, file: !3, line: 101, type: !478, isLocal: true, isDefinition: true)
!478 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 264, elements: !479)
!479 = !{!480}
!480 = !DISubrange(count: 33)
!481 = !DIGlobalVariableExpression(var: !482, expr: !DIExpression())
!482 = distinct !DIGlobalVariable(scope: null, file: !3, line: 106, type: !483, isLocal: true, isDefinition: true)
!483 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 408, elements: !484)
!484 = !{!485}
!485 = !DISubrange(count: 51)
!486 = !DIGlobalVariableExpression(var: !487, expr: !DIExpression())
!487 = distinct !DIGlobalVariable(scope: null, file: !3, line: 129, type: !488, isLocal: true, isDefinition: true)
!488 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 544, elements: !489)
!489 = !{!490}
!490 = !DISubrange(count: 68)
!491 = !DIGlobalVariableExpression(var: !492, expr: !DIExpression())
!492 = distinct !DIGlobalVariable(scope: null, file: !3, line: 225, type: !493, isLocal: true, isDefinition: true)
!493 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 464, elements: !494)
!494 = !{!495}
!495 = !DISubrange(count: 58)
!496 = !DIGlobalVariableExpression(var: !497, expr: !DIExpression())
!497 = distinct !DIGlobalVariable(scope: null, file: !3, line: 234, type: !468, isLocal: true, isDefinition: true)
!498 = !DIGlobalVariableExpression(var: !499, expr: !DIExpression())
!499 = distinct !DIGlobalVariable(scope: null, file: !3, line: 239, type: !500, isLocal: true, isDefinition: true)
!500 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 240, elements: !501)
!501 = !{!502}
!502 = !DISubrange(count: 30)
!503 = !DIGlobalVariableExpression(var: !504, expr: !DIExpression())
!504 = distinct !DIGlobalVariable(scope: null, file: !3, line: 248, type: !505, isLocal: true, isDefinition: true)
!505 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 40, elements: !506)
!506 = !{!507}
!507 = !DISubrange(count: 5)
!508 = !{i32 7, !"Dwarf Version", i32 5}
!509 = !{i32 2, !"Debug Info Version", i32 3}
!510 = !{i32 1, !"wchar_size", i32 4}
!511 = !{i32 8, !"PIC Level", i32 2}
!512 = !{i32 7, !"PIE Level", i32 2}
!513 = !{i32 7, !"uwtable", i32 2}
!514 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!515 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!516 = distinct !DISubprogram(name: "restart_register", scope: !3, file: !3, line: 33, type: !517, scopeLine: 33, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !519)
!517 = !DISubroutineType(types: !518)
!518 = !{null, !315, !311, !318, !234}
!519 = !{!520, !521, !522, !523, !524, !525}
!520 = !DILocalVariable(name: "tag", arg: 1, scope: !516, file: !3, line: 33, type: !315)
!521 = !DILocalVariable(name: "ccb", arg: 2, scope: !516, file: !3, line: 33, type: !311)
!522 = !DILocalVariable(name: "scb", arg: 3, scope: !516, file: !3, line: 33, type: !318)
!523 = !DILocalVariable(name: "data", arg: 4, scope: !516, file: !3, line: 33, type: !234)
!524 = !DILocalVariable(name: "cb", scope: !516, file: !3, line: 34, type: !303)
!525 = !DILocalVariable(name: "finder", scope: !526, file: !3, line: 47, type: !303)
!526 = distinct !DILexicalBlock(scope: !527, file: !3, line: 44, column: 12)
!527 = distinct !DILexicalBlock(scope: !516, file: !3, line: 42, column: 9)
!528 = !DILocation(line: 0, scope: !516)
!529 = !DILocation(line: 34, column: 27, scope: !516)
!530 = !DILocation(line: 35, column: 12, scope: !531)
!531 = distinct !DILexicalBlock(scope: !516, file: !3, line: 35, column: 9)
!532 = !DILocation(line: 35, column: 9, scope: !516)
!533 = !DILocation(line: 36, column: 17, scope: !534)
!534 = distinct !DILexicalBlock(scope: !531, file: !3, line: 35, column: 21)
!535 = !{!536, !536, i64 0}
!536 = !{!"any pointer", !537, i64 0}
!537 = !{!"omnipotent char", !538, i64 0}
!538 = !{!"Simple C/C++ TBAA"}
!539 = !DILocation(line: 36, column: 9, scope: !534)
!540 = !DILocation(line: 37, column: 9, scope: !534)
!541 = !DILocation(line: 42, column: 9, scope: !527)
!542 = !DILocation(line: 42, column: 18, scope: !527)
!543 = !DILocation(line: 42, column: 9, scope: !516)
!544 = !DILocation(line: 0, scope: !526)
!545 = !DILocation(line: 48, column: 24, scope: !526)
!546 = !{!547, !536, i64 8}
!547 = !{!"_restart_data_cb", !536, i64 0, !536, i64 8, !536, i64 16, !536, i64 24, !537, i64 32}
!548 = !DILocation(line: 48, column: 29, scope: !526)
!549 = !DILocation(line: 48, column: 9, scope: !526)
!550 = distinct !{!550, !549, !551, !552}
!551 = !DILocation(line: 50, column: 9, scope: !526)
!552 = !{!"llvm.loop.mustprogress"}
!553 = !DILocation(line: 0, scope: !527)
!554 = !DILocation(line: 54, column: 21, scope: !516)
!555 = !DILocation(line: 54, column: 5, scope: !516)
!556 = !DILocation(line: 55, column: 14, scope: !516)
!557 = !{!547, !536, i64 0}
!558 = !DILocation(line: 56, column: 9, scope: !516)
!559 = !DILocation(line: 56, column: 13, scope: !516)
!560 = !{!547, !536, i64 16}
!561 = !DILocation(line: 57, column: 9, scope: !516)
!562 = !DILocation(line: 57, column: 13, scope: !516)
!563 = !{!547, !536, i64 24}
!564 = !DILocation(line: 58, column: 1, scope: !516)
!565 = !DISubprogram(name: "calloc", scope: !566, file: !566, line: 675, type: !567, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!566 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!567 = !DISubroutineType(types: !568)
!568 = !{!234, !294, !294}
!569 = !DISubprogram(name: "fprintf", scope: !570, file: !570, line: 357, type: !571, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!570 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "1e435c46987a169d9f9186f63a512303")
!571 = !DISubroutineType(types: !572)
!572 = !{!247, !573, !574, null}
!573 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !240)
!574 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !315)
!575 = !DISubprogram(name: "abort", scope: !566, file: !566, line: 730, type: !576, flags: DIFlagPrototyped | DIFlagNoReturn, spFlags: DISPFlagOptimized)
!576 = !DISubroutineType(types: !577)
!577 = !{null}
!578 = !DISubprogram(name: "safe_strcpy", scope: !579, file: !579, line: 22, type: !580, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!579 = !DIFile(filename: "./util.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d1ef68c688867746f50aae7567be079a")
!580 = !DISubroutineType(types: !581)
!581 = !{!325, !249, !315, !582}
!582 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !294)
!583 = distinct !DISubprogram(name: "restart_get_kv", scope: !3, file: !3, line: 141, type: !584, scopeLine: 141, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !587)
!584 = !DISubroutineType(types: !585)
!585 = !{!5, !234, !586, !586}
!586 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !249, size: 64)
!587 = !{!588, !589, !590, !591, !592, !593, !594, !595, !598}
!588 = !DILocalVariable(name: "ctx", arg: 1, scope: !583, file: !3, line: 141, type: !234)
!589 = !DILocalVariable(name: "key", arg: 2, scope: !583, file: !3, line: 141, type: !586)
!590 = !DILocalVariable(name: "val", arg: 3, scope: !583, file: !3, line: 141, type: !586)
!591 = !DILocalVariable(name: "line", scope: !583, file: !3, line: 142, type: !249)
!592 = !DILocalVariable(name: "len", scope: !583, file: !3, line: 143, type: !294)
!593 = !DILocalVariable(name: "cb", scope: !583, file: !3, line: 144, type: !303)
!594 = !DILocalVariable(name: "c", scope: !583, file: !3, line: 145, type: !235)
!595 = !DILocalVariable(name: "p", scope: !596, file: !3, line: 158, type: !249)
!596 = distinct !DILexicalBlock(scope: !597, file: !3, line: 154, column: 43)
!597 = distinct !DILexicalBlock(scope: !583, file: !3, line: 154, column: 9)
!598 = !DILocalVariable(name: "p", scope: !599, file: !3, line: 179, type: !249)
!599 = distinct !DILexicalBlock(scope: !600, file: !3, line: 178, column: 36)
!600 = distinct !DILexicalBlock(scope: !601, file: !3, line: 178, column: 20)
!601 = distinct !DILexicalBlock(scope: !596, file: !3, line: 164, column: 13)
!602 = distinct !DIAssignID()
!603 = !DILocation(line: 0, scope: !583)
!604 = distinct !DIAssignID()
!605 = !DILocation(line: 142, column: 5, scope: !583)
!606 = !DILocation(line: 142, column: 11, scope: !583)
!607 = distinct !DIAssignID()
!608 = !DILocation(line: 143, column: 5, scope: !583)
!609 = !DILocation(line: 143, column: 12, scope: !583)
!610 = !{!611, !611, i64 0}
!611 = !{!"long", !537, i64 0}
!612 = distinct !DIAssignID()
!613 = !DILocation(line: 149, column: 12, scope: !614)
!614 = distinct !DILexicalBlock(scope: !583, file: !3, line: 149, column: 9)
!615 = !{!616, !536, i64 16}
!616 = !{!"", !536, i64 0, !536, i64 8, !536, i64 16, !617, i64 24}
!617 = !{!"_Bool", !537, i64 0}
!618 = !DILocation(line: 149, column: 17, scope: !614)
!619 = !DILocation(line: 149, column: 9, scope: !583)
!620 = !DILocation(line: 150, column: 9, scope: !621)
!621 = distinct !DILexicalBlock(scope: !614, file: !3, line: 149, column: 26)
!622 = !DILocation(line: 151, column: 17, scope: !621)
!623 = !DILocation(line: 152, column: 5, scope: !621)
!624 = !DILocation(line: 154, column: 33, scope: !597)
!625 = !{!616, !536, i64 0}
!626 = !DILocalVariable(name: "__lineptr", arg: 1, scope: !627, file: !628, line: 118, type: !586)
!627 = distinct !DISubprogram(name: "getline", scope: !628, file: !628, line: 118, type: !629, scopeLine: 119, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !633)
!628 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "482f6cda8975d1ad2408a10cdc1e14ac")
!629 = !DISubroutineType(types: !630)
!630 = !{!631, !586, !632, !240}
!631 = !DIDerivedType(tag: DW_TAG_typedef, name: "__ssize_t", file: !270, line: 194, baseType: !271)
!632 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !294, size: 64)
!633 = !{!626, !634, !635}
!634 = !DILocalVariable(name: "__n", arg: 2, scope: !627, file: !628, line: 118, type: !632)
!635 = !DILocalVariable(name: "__stream", arg: 3, scope: !627, file: !628, line: 118, type: !240)
!636 = !DILocation(line: 0, scope: !627, inlinedAt: !637)
!637 = distinct !DILocation(line: 154, column: 9, scope: !597)
!638 = !DILocation(line: 120, column: 10, scope: !627, inlinedAt: !637)
!639 = !DILocation(line: 154, column: 36, scope: !597)
!640 = !DILocation(line: 154, column: 9, scope: !583)
!641 = !DILocation(line: 158, column: 19, scope: !596)
!642 = !DILocation(line: 0, scope: !596)
!643 = !DILocation(line: 159, column: 9, scope: !596)
!644 = !DILocation(line: 159, column: 16, scope: !596)
!645 = !{!537, !537, i64 0}
!646 = !DILocation(line: 159, column: 19, scope: !596)
!647 = !DILocation(line: 160, column: 14, scope: !648)
!648 = distinct !DILexicalBlock(scope: !596, file: !3, line: 159, column: 28)
!649 = distinct !{!649, !643, !650, !552}
!650 = !DILocation(line: 161, column: 9, scope: !596)
!651 = !DILocation(line: 162, column: 12, scope: !596)
!652 = !DILocation(line: 164, column: 13, scope: !601)
!653 = !DILocation(line: 164, column: 13, scope: !596)
!654 = !DILocation(line: 0, scope: !655)
!655 = distinct !DILexicalBlock(scope: !601, file: !3, line: 164, column: 29)
!656 = !DILocation(line: 166, column: 13, scope: !655)
!657 = !DILocation(line: 168, column: 32, scope: !658)
!658 = distinct !DILexicalBlock(scope: !659, file: !3, line: 168, column: 21)
!659 = distinct !DILexicalBlock(scope: !655, file: !3, line: 166, column: 32)
!660 = !DILocation(line: 168, column: 21, scope: !658)
!661 = !DILocation(line: 168, column: 45, scope: !658)
!662 = !DILocation(line: 168, column: 21, scope: !659)
!663 = !DILocation(line: 171, column: 26, scope: !659)
!664 = distinct !{!664, !656, !665, !552}
!665 = !DILocation(line: 172, column: 13, scope: !655)
!666 = !DILocation(line: 174, column: 25, scope: !667)
!667 = distinct !DILexicalBlock(scope: !668, file: !3, line: 173, column: 29)
!668 = distinct !DILexicalBlock(scope: !655, file: !3, line: 173, column: 17)
!669 = !DILocation(line: 174, column: 101, scope: !667)
!670 = !DILocation(line: 174, column: 17, scope: !667)
!671 = !DILocation(line: 175, column: 17, scope: !667)
!672 = !DILocation(line: 179, column: 27, scope: !599)
!673 = !DILocation(line: 0, scope: !599)
!674 = !DILocation(line: 181, column: 21, scope: !675)
!675 = distinct !DILexicalBlock(scope: !599, file: !3, line: 181, column: 17)
!676 = !DILocation(line: 181, column: 17, scope: !599)
!677 = !DILocation(line: 182, column: 22, scope: !678)
!678 = distinct !DILexicalBlock(scope: !675, file: !3, line: 181, column: 30)
!679 = !DILocation(line: 183, column: 13, scope: !678)
!680 = !DILocation(line: 186, column: 20, scope: !599)
!681 = !DILocation(line: 186, column: 23, scope: !599)
!682 = !DILocation(line: 186, column: 30, scope: !599)
!683 = !DILocation(line: 186, column: 36, scope: !599)
!684 = !DILocation(line: 186, column: 43, scope: !599)
!685 = !DILocation(line: 186, column: 13, scope: !599)
!686 = !DILocation(line: 187, column: 18, scope: !687)
!687 = distinct !DILexicalBlock(scope: !599, file: !3, line: 186, column: 51)
!688 = distinct !{!688, !685, !689, !552}
!689 = !DILocation(line: 188, column: 13, scope: !599)
!690 = !DILocation(line: 189, column: 16, scope: !599)
!691 = !DILocation(line: 193, column: 21, scope: !692)
!692 = distinct !DILexicalBlock(scope: !599, file: !3, line: 193, column: 17)
!693 = !DILocation(line: 193, column: 17, scope: !599)
!694 = !DILocation(line: 190, column: 14, scope: !599)
!695 = !DILocation(line: 194, column: 22, scope: !696)
!696 = distinct !DILexicalBlock(scope: !692, file: !3, line: 193, column: 30)
!697 = !DILocation(line: 195, column: 13, scope: !696)
!698 = !DILocation(line: 196, column: 23, scope: !599)
!699 = !DILocation(line: 196, column: 21, scope: !599)
!700 = !DILocation(line: 201, column: 21, scope: !701)
!701 = distinct !DILexicalBlock(scope: !600, file: !3, line: 199, column: 16)
!702 = !DILocation(line: 201, column: 13, scope: !701)
!703 = !DILocation(line: 202, column: 18, scope: !701)
!704 = !DILocation(line: 202, column: 13, scope: !701)
!705 = !DILocation(line: 203, column: 13, scope: !701)
!706 = !DILocation(line: 177, column: 16, scope: !655)
!707 = !DILocation(line: 177, column: 19, scope: !655)
!708 = !{!616, !536, i64 8}
!709 = !DILocation(line: 207, column: 12, scope: !710)
!710 = distinct !DILexicalBlock(scope: !597, file: !3, line: 205, column: 12)
!711 = !DILocation(line: 207, column: 17, scope: !710)
!712 = !{!616, !617, i64 24}
!713 = !DILocation(line: 211, column: 1, scope: !583)
!714 = !DISubprogram(name: "free", scope: !566, file: !566, line: 687, type: !715, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!715 = !DISubroutineType(types: !716)
!716 = !{null, !234}
!717 = !DISubprogram(name: "strcmp", scope: !718, file: !718, line: 156, type: !719, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!718 = !DIFile(filename: "/usr/include/string.h", directory: "", checksumkind: CSK_MD5, checksum: "165db1185644f68894fa9e0d17055d70")
!719 = !DISubroutineType(types: !720)
!720 = !{!247, !315, !315}
!721 = distinct !DISubprogram(name: "restart_set_kv", scope: !3, file: !3, line: 268, type: !722, scopeLine: 268, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !724)
!722 = !DISubroutineType(types: !723)
!723 = !{null, !234, !315, !315, null}
!724 = !{!725, !726, !727, !728, !740, !741, !745}
!725 = !DILocalVariable(name: "ctx", arg: 1, scope: !721, file: !3, line: 268, type: !234)
!726 = !DILocalVariable(name: "key", arg: 2, scope: !721, file: !3, line: 268, type: !315)
!727 = !DILocalVariable(name: "fmt", arg: 3, scope: !721, file: !3, line: 268, type: !315)
!728 = !DILocalVariable(name: "ap", scope: !721, file: !3, line: 269, type: !729)
!729 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !570, line: 53, baseType: !730)
!730 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !731, line: 12, baseType: !732)
!731 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stdarg___gnuc_va_list.h", directory: "", checksumkind: CSK_MD5, checksum: "edb3f2eab991638e4dc94f6e55e3530f")
!732 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !3, baseType: !733)
!733 = !DICompositeType(tag: DW_TAG_array_type, baseType: !734, size: 192, elements: !278)
!734 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !735)
!735 = !{!736, !737, !738, !739}
!736 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !734, file: !3, line: 269, baseType: !7, size: 32)
!737 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !734, file: !3, line: 269, baseType: !7, size: 32, offset: 32)
!738 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !734, file: !3, line: 269, baseType: !234, size: 64, offset: 64)
!739 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !734, file: !3, line: 269, baseType: !234, size: 64, offset: 128)
!740 = !DILocalVariable(name: "c", scope: !721, file: !3, line: 270, type: !235)
!741 = !DILocalVariable(name: "valbuf", scope: !721, file: !3, line: 271, type: !742)
!742 = !DICompositeType(tag: DW_TAG_array_type, baseType: !250, size: 32768, elements: !743)
!743 = !{!744}
!744 = !DISubrange(count: 4096)
!745 = !DILocalVariable(name: "vlen", scope: !721, file: !3, line: 274, type: !247)
!746 = distinct !DIAssignID()
!747 = !DILocation(line: 0, scope: !721)
!748 = distinct !DIAssignID()
!749 = !DILocation(line: 269, column: 5, scope: !721)
!750 = !DILocation(line: 271, column: 5, scope: !721)
!751 = !DILocation(line: 273, column: 5, scope: !721)
!752 = !DILocation(line: 274, column: 16, scope: !721)
!753 = !DILocation(line: 275, column: 5, scope: !721)
!754 = !DILocation(line: 279, column: 14, scope: !755)
!755 = distinct !DILexicalBlock(scope: !721, file: !3, line: 279, column: 9)
!756 = !DILocation(line: 279, column: 9, scope: !721)
!757 = !DILocation(line: 280, column: 17, scope: !758)
!758 = distinct !DILexicalBlock(scope: !755, file: !3, line: 279, column: 30)
!759 = !DILocation(line: 280, column: 9, scope: !758)
!760 = !DILocation(line: 282, column: 9, scope: !758)
!761 = !DILocation(line: 285, column: 16, scope: !721)
!762 = !DILocation(line: 285, column: 5, scope: !721)
!763 = !DILocation(line: 287, column: 1, scope: !721)
!764 = !DISubprogram(name: "vsnprintf", scope: !570, file: !570, line: 389, type: !765, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!765 = !DISubroutineType(types: !766)
!766 = !{!247, !767, !294, !574, !768}
!767 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !249)
!768 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !734, size: 64)
!769 = distinct !DISubprogram(name: "restart_mmap_open", scope: !3, file: !3, line: 298, type: !770, scopeLine: 298, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !773)
!770 = !DISubroutineType(types: !771)
!771 = !{!325, !582, !315, !772}
!772 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !234, size: 64)
!773 = !{!774, !775, !776, !777, !778}
!774 = !DILocalVariable(name: "limit", arg: 1, scope: !769, file: !3, line: 298, type: !582)
!775 = !DILocalVariable(name: "file", arg: 2, scope: !769, file: !3, line: 298, type: !315)
!776 = !DILocalVariable(name: "mem_base", arg: 3, scope: !769, file: !3, line: 298, type: !772)
!777 = !DILocalVariable(name: "reuse_mmap", scope: !769, file: !3, line: 299, type: !325)
!778 = !DILocalVariable(name: "pagesize", scope: !769, file: !3, line: 301, type: !271)
!779 = distinct !DIAssignID()
!780 = !DILocation(line: 0, scope: !769)
!781 = !DILocation(line: 291, column: 12, scope: !782, inlinedAt: !785)
!782 = distinct !DISubprogram(name: "_find_pagesize", scope: !3, file: !3, line: 289, type: !783, scopeLine: 289, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!783 = !DISubroutineType(types: !784)
!784 = !{!271}
!785 = distinct !DILocation(line: 301, column: 21, scope: !769)
!786 = !DILocation(line: 302, column: 19, scope: !769)
!787 = !DILocation(line: 302, column: 17, scope: !769)
!788 = !DILocation(line: 303, column: 15, scope: !769)
!789 = !DILocation(line: 303, column: 13, scope: !769)
!790 = !{!791, !791, i64 0}
!791 = !{!"int", !537, i64 0}
!792 = !DILocation(line: 304, column: 17, scope: !793)
!793 = distinct !DILexicalBlock(scope: !769, file: !3, line: 304, column: 9)
!794 = !DILocation(line: 304, column: 9, scope: !769)
!795 = !DILocation(line: 305, column: 9, scope: !796)
!796 = distinct !DILexicalBlock(scope: !793, file: !3, line: 304, column: 24)
!797 = !DILocation(line: 306, column: 9, scope: !796)
!798 = !DILocation(line: 308, column: 9, scope: !799)
!799 = distinct !DILexicalBlock(scope: !769, file: !3, line: 308, column: 9)
!800 = !DILocation(line: 308, column: 35, scope: !799)
!801 = !DILocation(line: 308, column: 9, scope: !769)
!802 = !DILocation(line: 309, column: 9, scope: !803)
!803 = distinct !DILexicalBlock(scope: !799, file: !3, line: 308, column: 41)
!804 = !DILocation(line: 310, column: 9, scope: !803)
!805 = !DILocation(line: 313, column: 15, scope: !806)
!806 = distinct !DILexicalBlock(scope: !769, file: !3, line: 313, column: 9)
!807 = !DILocation(line: 313, column: 9, scope: !769)
!808 = !DILocation(line: 316, column: 17, scope: !809)
!809 = distinct !DILexicalBlock(scope: !806, file: !3, line: 313, column: 27)
!810 = !DILocation(line: 316, column: 9, scope: !809)
!811 = !DILocation(line: 317, column: 9, scope: !809)
!812 = !DILocation(line: 319, column: 69, scope: !769)
!813 = !DILocation(line: 319, column: 17, scope: !769)
!814 = !DILocation(line: 319, column: 15, scope: !769)
!815 = !DILocation(line: 320, column: 19, scope: !816)
!816 = distinct !DILexicalBlock(scope: !769, file: !3, line: 320, column: 9)
!817 = !DILocation(line: 320, column: 9, scope: !769)
!818 = !DILocation(line: 321, column: 9, scope: !819)
!819 = distinct !DILexicalBlock(scope: !816, file: !3, line: 320, column: 34)
!820 = !DILocation(line: 322, column: 9, scope: !819)
!821 = !DILocation(line: 325, column: 19, scope: !769)
!822 = !DILocalVariable(name: "ctx", scope: !823, file: !3, line: 92, type: !236)
!823 = distinct !DISubprogram(name: "restart_check", scope: !3, file: !3, line: 72, type: !824, scopeLine: 72, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !826)
!824 = !DISubroutineType(types: !825)
!825 = !{!247, !315}
!826 = !{!827, !828, !829, !830, !831, !822, !832, !833}
!827 = !DILocalVariable(name: "file", arg: 1, scope: !823, file: !3, line: 72, type: !315)
!828 = !DILocalVariable(name: "flen", scope: !823, file: !3, line: 74, type: !294)
!829 = !DILocalVariable(name: "ext", scope: !823, file: !3, line: 75, type: !315)
!830 = !DILocalVariable(name: "metafile", scope: !823, file: !3, line: 76, type: !249)
!831 = !DILocalVariable(name: "f", scope: !823, file: !3, line: 85, type: !240)
!832 = !DILocalVariable(name: "failed", scope: !823, file: !3, line: 111, type: !325)
!833 = !DILocalVariable(name: "cb", scope: !834, file: !3, line: 113, type: !303)
!834 = distinct !DILexicalBlock(scope: !823, file: !3, line: 112, column: 23)
!835 = !DILocation(line: 0, scope: !823, inlinedAt: !836)
!836 = distinct !DILocation(line: 326, column: 9, scope: !837)
!837 = distinct !DILexicalBlock(scope: !769, file: !3, line: 326, column: 9)
!838 = !DILocation(line: 74, column: 19, scope: !823, inlinedAt: !836)
!839 = !DILocation(line: 76, column: 51, scope: !823, inlinedAt: !836)
!840 = !DILocation(line: 76, column: 22, scope: !823, inlinedAt: !836)
!841 = !DILocation(line: 77, column: 18, scope: !842, inlinedAt: !836)
!842 = distinct !DILexicalBlock(scope: !823, file: !3, line: 77, column: 9)
!843 = !DILocation(line: 77, column: 9, scope: !823, inlinedAt: !836)
!844 = !DILocation(line: 79, column: 17, scope: !845, inlinedAt: !836)
!845 = distinct !DILexicalBlock(scope: !842, file: !3, line: 77, column: 27)
!846 = !DILocation(line: 79, column: 9, scope: !845, inlinedAt: !836)
!847 = !DILocation(line: 80, column: 9, scope: !845, inlinedAt: !836)
!848 = !DILocation(line: 82, column: 5, scope: !823, inlinedAt: !836)
!849 = !DILocation(line: 83, column: 20, scope: !823, inlinedAt: !836)
!850 = !DILocation(line: 83, column: 5, scope: !823, inlinedAt: !836)
!851 = !DILocation(line: 85, column: 15, scope: !823, inlinedAt: !836)
!852 = !DILocation(line: 86, column: 11, scope: !853, inlinedAt: !836)
!853 = distinct !DILexicalBlock(scope: !823, file: !3, line: 86, column: 9)
!854 = !DILocation(line: 86, column: 9, scope: !823, inlinedAt: !836)
!855 = !DILocation(line: 87, column: 17, scope: !856, inlinedAt: !836)
!856 = distinct !DILexicalBlock(scope: !853, file: !3, line: 86, column: 20)
!857 = !DILocation(line: 87, column: 9, scope: !856, inlinedAt: !836)
!858 = !DILocation(line: 88, column: 9, scope: !856, inlinedAt: !836)
!859 = !DILocation(line: 89, column: 9, scope: !856, inlinedAt: !836)
!860 = !DILocation(line: 92, column: 5, scope: !823, inlinedAt: !836)
!861 = !DILocation(line: 94, column: 11, scope: !823, inlinedAt: !836)
!862 = distinct !DIAssignID()
!863 = !DILocation(line: 95, column: 9, scope: !823, inlinedAt: !836)
!864 = distinct !DIAssignID()
!865 = !DILocation(line: 96, column: 9, scope: !823, inlinedAt: !836)
!866 = !DILocation(line: 97, column: 9, scope: !823, inlinedAt: !836)
!867 = !DILocation(line: 96, column: 14, scope: !823, inlinedAt: !836)
!868 = !DILocation(line: 98, column: 9, scope: !869, inlinedAt: !836)
!869 = distinct !DILexicalBlock(scope: !823, file: !3, line: 98, column: 9)
!870 = !DILocation(line: 98, column: 42, scope: !869, inlinedAt: !836)
!871 = !DILocation(line: 98, column: 9, scope: !823, inlinedAt: !836)
!872 = !DILocation(line: 101, column: 17, scope: !873, inlinedAt: !836)
!873 = distinct !DILexicalBlock(scope: !869, file: !3, line: 98, column: 59)
!874 = !DILocation(line: 101, column: 9, scope: !873, inlinedAt: !836)
!875 = !DILocation(line: 103, column: 9, scope: !873, inlinedAt: !836)
!876 = !DILocation(line: 105, column: 13, scope: !877, inlinedAt: !836)
!877 = distinct !DILexicalBlock(scope: !823, file: !3, line: 105, column: 9)
!878 = !DILocation(line: 105, column: 16, scope: !877, inlinedAt: !836)
!879 = !DILocation(line: 105, column: 9, scope: !823, inlinedAt: !836)
!880 = !DILocation(line: 106, column: 17, scope: !881, inlinedAt: !836)
!881 = distinct !DILexicalBlock(scope: !877, file: !3, line: 105, column: 25)
!882 = !DILocation(line: 106, column: 9, scope: !881, inlinedAt: !836)
!883 = !DILocation(line: 107, column: 9, scope: !881, inlinedAt: !836)
!884 = !DILocation(line: 112, column: 17, scope: !823, inlinedAt: !836)
!885 = !{i8 0, i8 2}
!886 = !{}
!887 = !DILocation(line: 112, column: 5, scope: !823, inlinedAt: !836)
!888 = !DILocation(line: 113, column: 35, scope: !834, inlinedAt: !836)
!889 = !DILocation(line: 0, scope: !834, inlinedAt: !836)
!890 = !DILocation(line: 114, column: 17, scope: !891, inlinedAt: !836)
!891 = distinct !DILexicalBlock(scope: !834, file: !3, line: 114, column: 13)
!892 = !DILocation(line: 114, column: 25, scope: !891, inlinedAt: !836)
!893 = !DILocation(line: 114, column: 40, scope: !891, inlinedAt: !836)
!894 = !DILocation(line: 114, column: 13, scope: !891, inlinedAt: !836)
!895 = !DILocation(line: 114, column: 46, scope: !891, inlinedAt: !836)
!896 = !DILocation(line: 120, column: 13, scope: !897, inlinedAt: !836)
!897 = distinct !DILexicalBlock(scope: !823, file: !3, line: 120, column: 9)
!898 = !DILocation(line: 120, column: 9, scope: !897, inlinedAt: !836)
!899 = !DILocation(line: 120, column: 9, scope: !823, inlinedAt: !836)
!900 = !DILocation(line: 121, column: 9, scope: !897, inlinedAt: !836)
!901 = !DILocation(line: 123, column: 5, scope: !823, inlinedAt: !836)
!902 = !DILocation(line: 125, column: 5, scope: !823, inlinedAt: !836)
!903 = !DILocation(line: 126, column: 5, scope: !823, inlinedAt: !836)
!904 = !DILocation(line: 128, column: 9, scope: !823, inlinedAt: !836)
!905 = !DILocation(line: 129, column: 17, scope: !906, inlinedAt: !836)
!906 = distinct !DILexicalBlock(scope: !907, file: !3, line: 128, column: 17)
!907 = distinct !DILexicalBlock(scope: !823, file: !3, line: 128, column: 9)
!908 = !DILocation(line: 129, column: 9, scope: !906, inlinedAt: !836)
!909 = !DILocation(line: 130, column: 9, scope: !906, inlinedAt: !836)
!910 = !DILocation(line: 134, column: 1, scope: !823, inlinedAt: !836)
!911 = !DILocation(line: 329, column: 17, scope: !769)
!912 = !DILocation(line: 329, column: 15, scope: !769)
!913 = !DILocation(line: 331, column: 5, scope: !769)
!914 = !DISubprogram(name: "strdup", scope: !718, file: !718, line: 187, type: !915, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!915 = !DISubroutineType(types: !916)
!916 = !{!249, !315}
!917 = !DISubprogram(name: "open", scope: !918, file: !918, line: 209, type: !919, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!918 = !DIFile(filename: "/usr/include/fcntl.h", directory: "", checksumkind: CSK_MD5, checksum: "aa7b606679f16283f5b29fcd37124425")
!919 = !DISubroutineType(types: !920)
!920 = !{!247, !315, !247, null}
!921 = !DISubprogram(name: "perror", scope: !570, file: !570, line: 878, type: !922, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!922 = !DISubroutineType(types: !923)
!923 = !{null, !315}
!924 = !DISubprogram(name: "ftruncate", scope: !925, file: !925, line: 1049, type: !926, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!925 = !DIFile(filename: "/usr/include/unistd.h", directory: "", checksumkind: CSK_MD5, checksum: "877e832a8bb8424f9180387a13787475")
!926 = !DISubroutineType(types: !927)
!927 = !{!247, !247, !269}
!928 = !DISubprogram(name: "mmap", scope: !929, file: !929, line: 57, type: !930, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!929 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/mman.h", directory: "", checksumkind: CSK_MD5, checksum: "64e45994f192915f7be4ea1b04420e3e")
!930 = !DISubroutineType(types: !931)
!931 = !{!234, !234, !294, !247, !247, !247, !269}
!932 = distinct !DISubprogram(name: "restart_mmap_close", scope: !3, file: !3, line: 335, type: !576, scopeLine: 335, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!933 = distinct !DIAssignID()
!934 = !DILocation(line: 336, column: 11, scope: !932)
!935 = !DILocation(line: 336, column: 22, scope: !932)
!936 = !DILocation(line: 336, column: 5, scope: !932)
!937 = !DILocation(line: 338, column: 22, scope: !938)
!938 = distinct !DILexicalBlock(scope: !932, file: !3, line: 338, column: 9)
!939 = !DILocalVariable(name: "ctx", scope: !940, file: !3, line: 244, type: !236)
!940 = distinct !DISubprogram(name: "restart_save", scope: !3, file: !3, line: 217, type: !824, scopeLine: 217, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !941)
!941 = !{!942, !943, !944, !945, !946, !947, !951, !952, !939}
!942 = !DILocalVariable(name: "file", arg: 1, scope: !940, file: !3, line: 217, type: !315)
!943 = !DILocalVariable(name: "flen", scope: !940, file: !3, line: 220, type: !294)
!944 = !DILocalVariable(name: "ext", scope: !940, file: !3, line: 221, type: !315)
!945 = !DILocalVariable(name: "extlen", scope: !940, file: !3, line: 222, type: !294)
!946 = !DILocalVariable(name: "metafile", scope: !940, file: !3, line: 223, type: !249)
!947 = !DILocalVariable(name: "oldmask", scope: !940, file: !3, line: 233, type: !948)
!948 = !DIDerivedType(tag: DW_TAG_typedef, name: "mode_t", file: !949, line: 69, baseType: !950)
!949 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/types.h", directory: "", checksumkind: CSK_MD5, checksum: "7fb02a803b0c9b11cb5276b77d21e9d8")
!950 = !DIDerivedType(tag: DW_TAG_typedef, name: "__mode_t", file: !270, line: 150, baseType: !7)
!951 = !DILocalVariable(name: "f", scope: !940, file: !3, line: 234, type: !240)
!952 = !DILocalVariable(name: "cb", scope: !940, file: !3, line: 243, type: !303)
!953 = !DILocation(line: 0, scope: !940, inlinedAt: !954)
!954 = distinct !DILocation(line: 338, column: 9, scope: !938)
!955 = !DILocation(line: 220, column: 19, scope: !940, inlinedAt: !954)
!956 = !DILocation(line: 223, column: 46, scope: !940, inlinedAt: !954)
!957 = !DILocation(line: 223, column: 22, scope: !940, inlinedAt: !954)
!958 = !DILocation(line: 224, column: 18, scope: !959, inlinedAt: !954)
!959 = distinct !DILexicalBlock(scope: !940, file: !3, line: 224, column: 9)
!960 = !DILocation(line: 224, column: 9, scope: !940, inlinedAt: !954)
!961 = !DILocation(line: 225, column: 17, scope: !962, inlinedAt: !954)
!962 = distinct !DILexicalBlock(scope: !959, file: !3, line: 224, column: 27)
!963 = !DILocation(line: 225, column: 9, scope: !962, inlinedAt: !954)
!964 = !DILocation(line: 226, column: 9, scope: !962, inlinedAt: !954)
!965 = !DILocation(line: 228, column: 5, scope: !940, inlinedAt: !954)
!966 = !DILocation(line: 229, column: 20, scope: !940, inlinedAt: !954)
!967 = !DILocation(line: 229, column: 5, scope: !940, inlinedAt: !954)
!968 = !DILocation(line: 233, column: 22, scope: !940, inlinedAt: !954)
!969 = !DILocation(line: 234, column: 15, scope: !940, inlinedAt: !954)
!970 = !DILocation(line: 235, column: 5, scope: !940, inlinedAt: !954)
!971 = !DILocation(line: 236, column: 11, scope: !972, inlinedAt: !954)
!972 = distinct !DILexicalBlock(scope: !940, file: !3, line: 236, column: 9)
!973 = !DILocation(line: 236, column: 9, scope: !940, inlinedAt: !954)
!974 = !DILocation(line: 238, column: 9, scope: !975, inlinedAt: !954)
!975 = distinct !DILexicalBlock(scope: !972, file: !3, line: 236, column: 20)
!976 = !DILocation(line: 239, column: 9, scope: !975, inlinedAt: !954)
!977 = !DILocation(line: 240, column: 9, scope: !975, inlinedAt: !954)
!978 = !DILocation(line: 243, column: 27, scope: !940, inlinedAt: !954)
!979 = !DILocation(line: 244, column: 5, scope: !940, inlinedAt: !954)
!980 = !DILocation(line: 245, column: 11, scope: !940, inlinedAt: !954)
!981 = distinct !DIAssignID()
!982 = !DILocation(line: 246, column: 15, scope: !940, inlinedAt: !954)
!983 = !DILocation(line: 246, column: 5, scope: !940, inlinedAt: !954)
!984 = !DILocation(line: 248, column: 33, scope: !985, inlinedAt: !954)
!985 = distinct !DILexicalBlock(scope: !940, file: !3, line: 246, column: 24)
!986 = !DILocation(line: 248, column: 9, scope: !985, inlinedAt: !954)
!987 = !DILocation(line: 249, column: 17, scope: !988, inlinedAt: !954)
!988 = distinct !DILexicalBlock(scope: !985, file: !3, line: 249, column: 13)
!989 = !DILocation(line: 249, column: 40, scope: !988, inlinedAt: !954)
!990 = !DILocation(line: 249, column: 13, scope: !988, inlinedAt: !954)
!991 = !DILocation(line: 249, column: 46, scope: !988, inlinedAt: !954)
!992 = !DILocation(line: 249, column: 13, scope: !985, inlinedAt: !954)
!993 = !DILocation(line: 255, column: 18, scope: !985, inlinedAt: !954)
!994 = distinct !{!994, !983, !995, !552}
!995 = !DILocation(line: 256, column: 5, scope: !940, inlinedAt: !954)
!996 = !DILocation(line: 262, column: 1, scope: !940, inlinedAt: !954)
!997 = !DILocation(line: 338, column: 9, scope: !932)
!998 = !DILocation(line: 339, column: 17, scope: !999)
!999 = distinct !DILexicalBlock(scope: !938, file: !3, line: 338, column: 41)
!1000 = !DILocation(line: 339, column: 9, scope: !999)
!1001 = !DILocation(line: 340, column: 5, scope: !999)
!1002 = !DILocation(line: 342, column: 16, scope: !1003)
!1003 = distinct !DILexicalBlock(scope: !932, file: !3, line: 342, column: 9)
!1004 = !DILocation(line: 342, column: 27, scope: !1003)
!1005 = !DILocation(line: 342, column: 9, scope: !1003)
!1006 = !DILocation(line: 342, column: 42, scope: !1003)
!1007 = !DILocation(line: 342, column: 9, scope: !932)
!1008 = !DILocation(line: 344, column: 22, scope: !1009)
!1009 = distinct !DILexicalBlock(scope: !1003, file: !3, line: 344, column: 16)
!1010 = !DILocation(line: 344, column: 16, scope: !1009)
!1011 = !DILocation(line: 344, column: 31, scope: !1009)
!1012 = !DILocation(line: 344, column: 16, scope: !1003)
!1013 = !DILocation(line: 0, scope: !1003)
!1014 = !DILocation(line: 348, column: 10, scope: !932)
!1015 = !DILocation(line: 348, column: 5, scope: !932)
!1016 = !DILocation(line: 349, column: 1, scope: !932)
!1017 = !DISubprogram(name: "msync", scope: !929, file: !929, line: 89, type: !1018, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1018 = !DISubroutineType(types: !1019)
!1019 = !{!247, !234, !294, !247}
!1020 = !DISubprogram(name: "munmap", scope: !929, file: !929, line: 76, type: !1021, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1021 = !DISubroutineType(types: !1022)
!1022 = !{!247, !234, !294}
!1023 = !DISubprogram(name: "close", scope: !925, file: !925, line: 358, type: !1024, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1024 = !DISubroutineType(types: !1025)
!1025 = !{!247, !247}
!1026 = distinct !DISubprogram(name: "restart_fixup", scope: !3, file: !3, line: 354, type: !1027, scopeLine: 354, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1029)
!1027 = !DISubroutineType(types: !1028)
!1028 = !{!7, !234}
!1029 = !{!1030, !1031, !1039, !1040, !1042, !1043, !1045, !1046}
!1030 = !DILocalVariable(name: "orig_addr", arg: 1, scope: !1026, file: !3, line: 354, type: !234)
!1031 = !DILocalVariable(name: "tv", scope: !1026, file: !3, line: 355, type: !1032)
!1032 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "timeval", file: !1033, line: 8, size: 128, elements: !1034)
!1033 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h", directory: "", checksumkind: CSK_MD5, checksum: "9b45d950050c215f216850b27bd1e8f3")
!1034 = !{!1035, !1037}
!1035 = !DIDerivedType(tag: DW_TAG_member, name: "tv_sec", scope: !1032, file: !1033, line: 14, baseType: !1036, size: 64)
!1036 = !DIDerivedType(tag: DW_TAG_typedef, name: "__time_t", file: !270, line: 160, baseType: !271)
!1037 = !DIDerivedType(tag: DW_TAG_member, name: "tv_usec", scope: !1032, file: !1033, line: 15, baseType: !1038, size: 64, offset: 64)
!1038 = !DIDerivedType(tag: DW_TAG_typedef, name: "__suseconds_t", file: !270, line: 162, baseType: !271)
!1039 = !DILocalVariable(name: "checked", scope: !1026, file: !3, line: 356, type: !355)
!1040 = !DILocalVariable(name: "page_size", scope: !1026, file: !3, line: 357, type: !1041)
!1041 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !7)
!1042 = !DILocalVariable(name: "page_remain", scope: !1026, file: !3, line: 358, type: !7)
!1043 = !DILocalVariable(name: "it", scope: !1044, file: !3, line: 369, type: !326)
!1044 = distinct !DILexicalBlock(scope: !1026, file: !3, line: 367, column: 37)
!1045 = !DILocalVariable(name: "size", scope: !1044, file: !3, line: 371, type: !247)
!1046 = !DILocalVariable(name: "ch", scope: !1047, file: !3, line: 399, type: !361)
!1047 = distinct !DILexicalBlock(scope: !1048, file: !3, line: 398, column: 55)
!1048 = distinct !DILexicalBlock(scope: !1044, file: !3, line: 398, column: 13)
!1049 = distinct !DIAssignID()
!1050 = !DILocation(line: 0, scope: !1026)
!1051 = !DILocation(line: 355, column: 5, scope: !1026)
!1052 = !DILocation(line: 357, column: 45, scope: !1026)
!1053 = !{!1054, !791, i64 124}
!1054 = !{!"settings", !611, i64 0, !791, i64 8, !791, i64 12, !791, i64 16, !536, i64 24, !791, i64 32, !791, i64 36, !791, i64 40, !536, i64 48, !536, i64 56, !791, i64 64, !1055, i64 72, !791, i64 80, !791, i64 84, !791, i64 88, !537, i64 92, !791, i64 96, !791, i64 100, !617, i64 104, !791, i64 108, !791, i64 112, !791, i64 116, !791, i64 120, !791, i64 124, !791, i64 128, !617, i64 132, !617, i64 133, !617, i64 134, !617, i64 135, !617, i64 136, !617, i64 137, !791, i64 140, !1055, i64 144, !791, i64 152, !791, i64 156, !617, i64 160, !791, i64 164, !617, i64 168, !617, i64 169, !536, i64 176, !791, i64 184, !791, i64 188, !791, i64 192, !791, i64 196, !1055, i64 200, !1055, i64 208, !791, i64 216, !617, i64 220, !791, i64 224, !791, i64 228, !791, i64 232, !791, i64 236, !791, i64 240, !617, i64 244, !617, i64 245, !617, i64 246, !791, i64 248, !791, i64 252, !791, i64 256, !791, i64 260, !791, i64 264, !791, i64 268, !791, i64 272, !791, i64 276, !791, i64 280, !791, i64 284, !1055, i64 288, !1055, i64 296, !617, i64 304, !791, i64 308, !791, i64 312, !536, i64 320, !791, i64 328}
!1055 = !{!"double", !537, i64 0}
!1056 = !DILocation(line: 360, column: 5, scope: !1026)
!1057 = !DILocation(line: 361, column: 18, scope: !1058)
!1058 = distinct !DILexicalBlock(scope: !1026, file: !3, line: 361, column: 9)
!1059 = !{!1054, !791, i64 32}
!1060 = !DILocation(line: 361, column: 26, scope: !1058)
!1061 = !DILocation(line: 361, column: 9, scope: !1026)
!1062 = !DILocation(line: 362, column: 17, scope: !1063)
!1063 = distinct !DILexicalBlock(scope: !1058, file: !3, line: 361, column: 31)
!1064 = !DILocation(line: 362, column: 93, scope: !1063)
!1065 = !DILocation(line: 362, column: 9, scope: !1063)
!1066 = !DILocation(line: 363, column: 17, scope: !1063)
!1067 = !DILocation(line: 363, column: 71, scope: !1063)
!1068 = !{!1069, !611, i64 0}
!1069 = !{!"timeval", !611, i64 0, !611, i64 8}
!1070 = !DILocation(line: 363, column: 63, scope: !1063)
!1071 = !DILocation(line: 363, column: 87, scope: !1063)
!1072 = !{!1069, !611, i64 8}
!1073 = !DILocation(line: 363, column: 79, scope: !1063)
!1074 = !DILocation(line: 363, column: 9, scope: !1063)
!1075 = !DILocation(line: 364, column: 5, scope: !1063)
!1076 = !DILocation(line: 367, column: 22, scope: !1026)
!1077 = !DILocation(line: 367, column: 20, scope: !1026)
!1078 = !DILocation(line: 367, column: 5, scope: !1026)
!1079 = !DILocation(line: 369, column: 37, scope: !1044)
!1080 = !DILocation(line: 369, column: 47, scope: !1044)
!1081 = !DILocation(line: 0, scope: !1044)
!1082 = !DILocation(line: 372, column: 36, scope: !1044)
!1083 = !DILocation(line: 372, column: 27, scope: !1044)
!1084 = !DILocation(line: 372, column: 25, scope: !1044)
!1085 = !DILocation(line: 372, column: 17, scope: !1044)
!1086 = !DILocation(line: 371, column: 20, scope: !1044)
!1087 = !DILocation(line: 375, column: 18, scope: !1088)
!1088 = distinct !DILexicalBlock(scope: !1044, file: !3, line: 375, column: 13)
!1089 = !DILocation(line: 375, column: 13, scope: !1044)
!1090 = !DILocation(line: 378, column: 24, scope: !1091)
!1091 = distinct !DILexicalBlock(scope: !1088, file: !3, line: 375, column: 25)
!1092 = !DILocation(line: 378, column: 21, scope: !1091)
!1093 = !DILocation(line: 380, column: 13, scope: !1091)
!1094 = distinct !{!1094, !1078, !1095, !552}
!1095 = !DILocation(line: 435, column: 5, scope: !1026)
!1096 = !DILocation(line: 383, column: 17, scope: !1097)
!1097 = distinct !DILexicalBlock(scope: !1044, file: !3, line: 383, column: 13)
!1098 = !{!1099, !1099, i64 0}
!1099 = !{!"short", !537, i64 0}
!1100 = !DILocation(line: 383, column: 26, scope: !1097)
!1101 = !DILocation(line: 383, column: 13, scope: !1044)
!1102 = !DILocation(line: 385, column: 21, scope: !1103)
!1103 = distinct !DILexicalBlock(scope: !1104, file: !3, line: 385, column: 17)
!1104 = distinct !DILexicalBlock(scope: !1097, file: !3, line: 383, column: 41)
!1105 = !DILocation(line: 385, column: 17, scope: !1103)
!1106 = !DILocation(line: 385, column: 17, scope: !1104)
!1107 = !DILocation(line: 386, column: 37, scope: !1108)
!1108 = distinct !DILexicalBlock(scope: !1103, file: !3, line: 385, column: 27)
!1109 = !DILocation(line: 386, column: 56, scope: !1108)
!1110 = !DILocation(line: 387, column: 68, scope: !1108)
!1111 = !DILocation(line: 387, column: 58, scope: !1108)
!1112 = !DILocation(line: 387, column: 56, scope: !1108)
!1113 = !DILocation(line: 387, column: 28, scope: !1108)
!1114 = !DILocation(line: 387, column: 26, scope: !1108)
!1115 = !DILocation(line: 388, column: 13, scope: !1108)
!1116 = !DILocation(line: 389, column: 21, scope: !1117)
!1117 = distinct !DILexicalBlock(scope: !1104, file: !3, line: 389, column: 17)
!1118 = !DILocation(line: 389, column: 17, scope: !1117)
!1119 = !DILocation(line: 389, column: 17, scope: !1104)
!1120 = !DILocation(line: 390, column: 37, scope: !1121)
!1121 = distinct !DILexicalBlock(scope: !1117, file: !3, line: 389, column: 27)
!1122 = !DILocation(line: 390, column: 56, scope: !1121)
!1123 = !DILocation(line: 391, column: 68, scope: !1121)
!1124 = !DILocation(line: 391, column: 58, scope: !1121)
!1125 = !DILocation(line: 391, column: 56, scope: !1121)
!1126 = !DILocation(line: 391, column: 28, scope: !1121)
!1127 = !DILocation(line: 391, column: 26, scope: !1121)
!1128 = !DILocation(line: 392, column: 13, scope: !1121)
!1129 = !DILocation(line: 395, column: 13, scope: !1104)
!1130 = !DILocation(line: 398, column: 17, scope: !1048)
!1131 = !DILocation(line: 396, column: 9, scope: !1104)
!1132 = !DILocation(line: 398, column: 13, scope: !1048)
!1133 = !DILocation(line: 398, column: 26, scope: !1048)
!1134 = !DILocation(line: 398, column: 13, scope: !1044)
!1135 = !DILocation(line: 400, column: 30, scope: !1136)
!1136 = distinct !DILexicalBlock(scope: !1047, file: !3, line: 400, column: 17)
!1137 = !DILocation(line: 400, column: 17, scope: !1047)
!1138 = !DILocation(line: 401, column: 37, scope: !1139)
!1139 = distinct !DILexicalBlock(scope: !1136, file: !3, line: 400, column: 46)
!1140 = !DILocation(line: 0, scope: !1047)
!1141 = !DILocation(line: 406, column: 39, scope: !1139)
!1142 = !DILocation(line: 406, column: 35, scope: !1139)
!1143 = !DILocation(line: 406, column: 24, scope: !1139)
!1144 = !DILocation(line: 408, column: 13, scope: !1139)
!1145 = !DILocation(line: 0, scope: !1136)
!1146 = !DILocation(line: 412, column: 21, scope: !1147)
!1147 = distinct !DILexicalBlock(scope: !1047, file: !3, line: 412, column: 17)
!1148 = !DILocation(line: 412, column: 17, scope: !1147)
!1149 = !DILocation(line: 412, column: 17, scope: !1047)
!1150 = !DILocation(line: 413, column: 43, scope: !1151)
!1151 = distinct !DILexicalBlock(scope: !1147, file: !3, line: 412, column: 27)
!1152 = !DILocation(line: 413, column: 62, scope: !1151)
!1153 = !DILocation(line: 414, column: 74, scope: !1151)
!1154 = !DILocation(line: 414, column: 64, scope: !1151)
!1155 = !DILocation(line: 414, column: 62, scope: !1151)
!1156 = !DILocation(line: 414, column: 28, scope: !1151)
!1157 = !DILocation(line: 414, column: 26, scope: !1151)
!1158 = !DILocation(line: 415, column: 13, scope: !1151)
!1159 = !DILocation(line: 416, column: 21, scope: !1160)
!1160 = distinct !DILexicalBlock(scope: !1047, file: !3, line: 416, column: 17)
!1161 = !DILocation(line: 416, column: 17, scope: !1160)
!1162 = !DILocation(line: 416, column: 17, scope: !1047)
!1163 = !DILocation(line: 417, column: 43, scope: !1164)
!1164 = distinct !DILexicalBlock(scope: !1160, file: !3, line: 416, column: 27)
!1165 = !DILocation(line: 417, column: 62, scope: !1164)
!1166 = !DILocation(line: 418, column: 74, scope: !1164)
!1167 = !DILocation(line: 418, column: 64, scope: !1164)
!1168 = !DILocation(line: 418, column: 62, scope: !1164)
!1169 = !DILocation(line: 418, column: 28, scope: !1164)
!1170 = !DILocation(line: 418, column: 26, scope: !1164)
!1171 = !DILocation(line: 419, column: 13, scope: !1164)
!1172 = !DILocation(line: 420, column: 21, scope: !1173)
!1173 = distinct !DILexicalBlock(scope: !1047, file: !3, line: 420, column: 17)
!1174 = !DILocation(line: 420, column: 17, scope: !1173)
!1175 = !DILocation(line: 420, column: 17, scope: !1047)
!1176 = !DILocation(line: 421, column: 37, scope: !1177)
!1177 = distinct !DILexicalBlock(scope: !1173, file: !3, line: 420, column: 27)
!1178 = !DILocation(line: 421, column: 56, scope: !1177)
!1179 = !DILocation(line: 422, column: 68, scope: !1177)
!1180 = !DILocation(line: 422, column: 58, scope: !1177)
!1181 = !DILocation(line: 422, column: 56, scope: !1177)
!1182 = !DILocation(line: 422, column: 28, scope: !1177)
!1183 = !DILocation(line: 422, column: 26, scope: !1177)
!1184 = !DILocation(line: 423, column: 13, scope: !1177)
!1185 = !DILocation(line: 427, column: 20, scope: !1044)
!1186 = !DILocation(line: 427, column: 17, scope: !1044)
!1187 = !DILocation(line: 428, column: 21, scope: !1044)
!1188 = !DILocation(line: 429, column: 18, scope: !1189)
!1189 = distinct !DILexicalBlock(scope: !1044, file: !3, line: 429, column: 13)
!1190 = !DILocation(line: 429, column: 13, scope: !1044)
!1191 = !DILocation(line: 431, column: 24, scope: !1192)
!1192 = distinct !DILexicalBlock(scope: !1189, file: !3, line: 429, column: 33)
!1193 = !DILocation(line: 431, column: 21, scope: !1192)
!1194 = !DILocation(line: 432, column: 36, scope: !1192)
!1195 = !DILocation(line: 433, column: 9, scope: !1192)
!1196 = !DILocation(line: 437, column: 18, scope: !1197)
!1197 = distinct !DILexicalBlock(scope: !1026, file: !3, line: 437, column: 9)
!1198 = !DILocation(line: 437, column: 26, scope: !1197)
!1199 = !DILocation(line: 437, column: 9, scope: !1026)
!1200 = !DILocation(line: 438, column: 9, scope: !1201)
!1201 = distinct !DILexicalBlock(scope: !1197, file: !3, line: 437, column: 31)
!1202 = !DILocation(line: 439, column: 17, scope: !1201)
!1203 = !DILocation(line: 439, column: 69, scope: !1201)
!1204 = !DILocation(line: 439, column: 61, scope: !1201)
!1205 = !DILocation(line: 439, column: 85, scope: !1201)
!1206 = !DILocation(line: 439, column: 77, scope: !1201)
!1207 = !DILocation(line: 439, column: 9, scope: !1201)
!1208 = !DILocation(line: 440, column: 5, scope: !1201)
!1209 = !DILocation(line: 443, column: 1, scope: !1026)
!1210 = !DILocation(line: 442, column: 5, scope: !1026)
!1211 = !DISubprogram(name: "gettimeofday", scope: !1212, file: !1212, line: 67, type: !1213, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1212 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/time.h", directory: "", checksumkind: CSK_MD5, checksum: "56372c3f0df8d1bebc689293534b3d5f")
!1213 = !DISubroutineType(types: !1214)
!1214 = !{!247, !1215, !1217}
!1215 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1216)
!1216 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1032, size: 64)
!1217 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !234)
!1218 = !DISubprogram(name: "slabs_fixup", scope: !1219, file: !1219, line: 70, type: !1220, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1219 = !DIFile(filename: "./slabs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "28867aba1f41c79140864d76faedcb32")
!1220 = !DISubroutineType(types: !1221)
!1221 = !{!7, !249, !1222}
!1222 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !247)
!1223 = !DISubprogram(name: "do_item_link_fixup", scope: !1224, file: !1224, line: 27, type: !1225, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1224 = !DIFile(filename: "./items.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "5548db7354621bc680fd5812e10230ba")
!1225 = !DISubroutineType(types: !1226)
!1226 = !{null, !326}
!1227 = !DISubprogram(name: "slabs_size", scope: !1219, file: !1219, line: 22, type: !1228, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1228 = !DISubroutineType(types: !1229)
!1229 = !{!7, !1222}
!1230 = !DISubprogram(name: "__getdelim", scope: !570, file: !570, line: 694, type: !1231, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1231 = !DISubroutineType(types: !1232)
!1232 = !{!631, !1233, !1234, !247, !573}
!1233 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !586)
!1234 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !632)
!1235 = !DISubprogram(name: "sysconf", scope: !925, file: !925, line: 640, type: !1236, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1236 = !DISubroutineType(types: !1237)
!1237 = !{!271, !247}
!1238 = !DISubprogram(name: "strlen", scope: !718, file: !718, line: 407, type: !1239, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1239 = !DISubroutineType(types: !1240)
!1240 = !{!296, !315}
!1241 = !DISubprogram(name: "fopen", scope: !570, file: !570, line: 264, type: !1242, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1242 = !DISubroutineType(types: !1243)
!1243 = !{!240, !574, !574}
!1244 = !DISubprogram(name: "fclose", scope: !570, file: !570, line: 184, type: !1245, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1245 = !DISubroutineType(types: !1246)
!1246 = !{!247, !240}
!1247 = !DISubprogram(name: "unlink", scope: !925, file: !925, line: 858, type: !824, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1248 = !DISubprogram(name: "umask", scope: !1249, file: !1249, line: 380, type: !1250, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1249 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/stat.h", directory: "", checksumkind: CSK_MD5, checksum: "66c5d94e7b5e54481452c91d42ec16bb")
!1250 = !DISubroutineType(types: !1251)
!1251 = !{!950, !950}
