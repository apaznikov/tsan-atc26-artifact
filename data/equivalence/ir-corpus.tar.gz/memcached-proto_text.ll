; ModuleID = 'proto_text.c'
source_filename = "proto_text.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.settings = type { i64, i32, i32, i32, ptr, i32, i32, i32, ptr, ptr, i32, double, i32, i32, i32, i8, i32, i32, i8, i32, i32, i32, i32, i32, i32, i8, i8, i8, i8, i8, i8, i32, double, i32, i32, i8, i32, i8, i8, ptr, i32, i32, i32, i32, double, double, i32, i8, i32, i32, i32, i32, i32, i8, i8, i8, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, double, double, i8, i32, i32, ptr, i32 }
%struct.slab_stats = type { i64, i64, i64, i64, i64, i64, i64, i64 }
%struct.token_s = type { ptr, i64 }
%struct._meta_flags = type { i16, i8, i32, i32, i32, i32, i64, i64, i64, i64 }

@.str = private unnamed_addr constant [3 x i8] c"\0D\0A\00", align 1, !dbg !0
@.str.1 = private unnamed_addr constant [28 x i8] c"CLIENT_ERROR bad data chunk\00", align 1, !dbg !7
@.str.2 = private unnamed_addr constant [7 x i8] c"STORED\00", align 1, !dbg !12
@.str.3 = private unnamed_addr constant [7 x i8] c"EXISTS\00", align 1, !dbg !17
@.str.4 = private unnamed_addr constant [10 x i8] c"NOT_FOUND\00", align 1, !dbg !19
@.str.5 = private unnamed_addr constant [11 x i8] c"NOT_STORED\00", align 1, !dbg !24
@.str.6 = private unnamed_addr constant [37 x i8] c"SERVER_ERROR Unhandled storage type.\00", align 1, !dbg !29
@.str.7 = private unnamed_addr constant [4 x i8] c"set\00", align 1, !dbg !34
@.str.8 = private unnamed_addr constant [29 x i8] c"CLIENT_ERROR unauthenticated\00", align 1, !dbg !39
@.str.9 = private unnamed_addr constant [42 x i8] c"CLIENT_ERROR bad command line termination\00", align 1, !dbg !44
@.str.10 = private unnamed_addr constant [45 x i8] c"CLIENT_ERROR bad authentication token format\00", align 1, !dbg !49
@.str.11 = private unnamed_addr constant [36 x i8] c"CLIENT_ERROR authentication failure\00", align 1, !dbg !54
@.str.12 = private unnamed_addr constant [5 x i8] c"get \00", align 1, !dbg !59
@.str.13 = private unnamed_addr constant [6 x i8] c"gets \00", align 1, !dbg !64
@current_time = external global i32, align 4
@settings = external global %struct.settings, align 8
@stderr = external local_unnamed_addr global ptr, align 8
@.str.14 = private unnamed_addr constant [8 x i8] c"<%d %s\0A\00", align 1, !dbg !69
@.str.15 = private unnamed_addr constant [6 x i8] c"ERROR\00", align 1, !dbg !74
@.str.16 = private unnamed_addr constant [3 x i8] c"MN\00", align 1, !dbg !76
@.str.17 = private unnamed_addr constant [4 x i8] c"get\00", align 1, !dbg !78
@.str.18 = private unnamed_addr constant [5 x i8] c"gets\00", align 1, !dbg !80
@.str.19 = private unnamed_addr constant [4 x i8] c"gat\00", align 1, !dbg !82
@.str.20 = private unnamed_addr constant [5 x i8] c"gats\00", align 1, !dbg !84
@.str.21 = private unnamed_addr constant [6 x i8] c"stats\00", align 1, !dbg !86
@.str.22 = private unnamed_addr constant [9 x i8] c"shutdown\00", align 1, !dbg !88
@.str.23 = private unnamed_addr constant [6 x i8] c"slabs\00", align 1, !dbg !93
@.str.24 = private unnamed_addr constant [4 x i8] c"add\00", align 1, !dbg !95
@.str.25 = private unnamed_addr constant [7 x i8] c"append\00", align 1, !dbg !97
@.str.26 = private unnamed_addr constant [4 x i8] c"cas\00", align 1, !dbg !99
@.str.27 = private unnamed_addr constant [15 x i8] c"cache_memlimit\00", align 1, !dbg !101
@.str.28 = private unnamed_addr constant [5 x i8] c"incr\00", align 1, !dbg !106
@.str.29 = private unnamed_addr constant [7 x i8] c"delete\00", align 1, !dbg !108
@.str.30 = private unnamed_addr constant [5 x i8] c"decr\00", align 1, !dbg !110
@.str.31 = private unnamed_addr constant [6 x i8] c"touch\00", align 1, !dbg !112
@.str.32 = private unnamed_addr constant [8 x i8] c"replace\00", align 1, !dbg !114
@.str.33 = private unnamed_addr constant [8 x i8] c"prepend\00", align 1, !dbg !116
@.str.34 = private unnamed_addr constant [5 x i8] c"bget\00", align 1, !dbg !118
@.str.35 = private unnamed_addr constant [10 x i8] c"flush_all\00", align 1, !dbg !120
@.str.36 = private unnamed_addr constant [8 x i8] c"version\00", align 1, !dbg !122
@.str.37 = private unnamed_addr constant [5 x i8] c"quit\00", align 1, !dbg !124
@.str.38 = private unnamed_addr constant [12 x i8] c"lru_crawler\00", align 1, !dbg !126
@.str.39 = private unnamed_addr constant [6 x i8] c"watch\00", align 1, !dbg !131
@.str.40 = private unnamed_addr constant [10 x i8] c"verbosity\00", align 1, !dbg !133
@.str.41 = private unnamed_addr constant [4 x i8] c"lru\00", align 1, !dbg !135
@.str.42 = private unnamed_addr constant [9 x i8] c"extstore\00", align 1, !dbg !137
@.str.43 = private unnamed_addr constant [6 x i8] c"HTTP/\00", align 1, !dbg !139
@.str.48 = private unnamed_addr constant [37 x i8] c"CLIENT_ERROR bad command line format\00", align 1, !dbg !141
@.str.49 = private unnamed_addr constant [40 x i8] c"CLIENT_ERROR options flags are too long\00", align 1, !dbg !143
@.str.50 = private unnamed_addr constant [44 x i8] c"SERVER_ERROR refcount overflow during fetch\00", align 1, !dbg !148
@.str.51 = private unnamed_addr constant [4 x i8] c"VA \00", align 1, !dbg !153
@.str.52 = private unnamed_addr constant [35 x i8] c"CLIENT_ERROR opaque token too long\00", align 1, !dbg !155
@.str.53 = private unnamed_addr constant [3 x i8] c"EN\00", align 1, !dbg !160
@.str.54 = private unnamed_addr constant [28 x i8] c"CLIENT_ERROR duplicate flag\00", align 1, !dbg !162
@.str.55 = private unnamed_addr constant [32 x i8] c"CLIENT_ERROR error decoding key\00", align 1, !dbg !164
@.str.56 = private unnamed_addr constant [46 x i8] c"CLIENT_ERROR bad token in command line format\00", align 1, !dbg !169
@.str.57 = private unnamed_addr constant [42 x i8] c"CLIENT_ERROR incorrect length for M token\00", align 1, !dbg !174
@.str.58 = private unnamed_addr constant [43 x i8] c"CLIENT_ERROR invalid numeric initial value\00", align 1, !dbg !176
@.str.59 = private unnamed_addr constant [41 x i8] c"CLIENT_ERROR invalid numeric delta value\00", align 1, !dbg !181
@.str.60 = private unnamed_addr constant [26 x i8] c"CLIENT_ERROR invalid flag\00", align 1, !dbg !186
@.str.61 = private unnamed_addr constant [36 x i8] c"CLIENT_ERROR options flags too long\00", align 1, !dbg !191
@.str.62 = private unnamed_addr constant [41 x i8] c"CLIENT_ERROR invalid mode for ms M token\00", align 1, !dbg !193
@.str.63 = private unnamed_addr constant [40 x i8] c"SERVER_ERROR object too large for cache\00", align 1, !dbg !195
@.str.64 = private unnamed_addr constant [42 x i8] c"SERVER_ERROR out of memory storing object\00", align 1, !dbg !197
@logger_key = external local_unnamed_addr global i32, align 4
@.str.65 = private unnamed_addr constant [39 x i8] c"CLIENT_ERROR invalid or duplicate flag\00", align 1, !dbg !199
@.str.66 = private unnamed_addr constant [27 x i8] c"SERVER_ERROR out of memory\00", align 1, !dbg !204
@.str.67 = private unnamed_addr constant [41 x i8] c"CLIENT_ERROR invalid mode for ma M token\00", align 1, !dbg !209
@hash = external local_unnamed_addr global ptr, align 8
@.str.68 = private unnamed_addr constant [61 x i8] c"CLIENT_ERROR cannot increment or decrement non-numeric value\00", align 1, !dbg !211
@.str.69 = private unnamed_addr constant [47 x i8] c"SERVER_ERROR Out of memory allocating new item\00", align 1, !dbg !216
@.str.70 = private unnamed_addr constant [4 x i8] c"ME \00", align 1, !dbg !221
@.str.71 = private unnamed_addr constant [51 x i8] c"exp=%d la=%llu cas=%llu fetch=%s cls=%u size=%lu\0D\0A\00", align 1, !dbg !223
@.str.72 = private unnamed_addr constant [4 x i8] c"yes\00", align 1, !dbg !228
@.str.73 = private unnamed_addr constant [3 x i8] c"no\00", align 1, !dbg !230
@.str.74 = private unnamed_addr constant [38 x i8] c"CLIENT_ERROR invalid exptime argument\00", align 1, !dbg !232
@.str.75 = private unnamed_addr constant [7 x i8] c"VALUE \00", align 1, !dbg !237
@.str.76 = private unnamed_addr constant [17 x i8] c">%d sending key \00", align 1, !dbg !239
@.str.79 = private unnamed_addr constant [9 x i8] c">%d END\0A\00", align 1, !dbg !244
@.str.80 = private unnamed_addr constant [48 x i8] c"SERVER_ERROR out of memory writing get response\00", align 1, !dbg !246
@.str.81 = private unnamed_addr constant [6 x i8] c"END\0D\0A\00", align 1, !dbg !251
@.str.82 = private unnamed_addr constant [8 x i8] c"noreply\00", align 1, !dbg !253
@.str.83 = private unnamed_addr constant [30 x i8] c"CLIENT_ERROR bad command line\00", align 1, !dbg !255
@.str.84 = private unnamed_addr constant [6 x i8] c"reset\00", align 1, !dbg !260
@.str.85 = private unnamed_addr constant [6 x i8] c"RESET\00", align 1, !dbg !262
@.str.86 = private unnamed_addr constant [7 x i8] c"detail\00", align 1, !dbg !264
@.str.87 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1, !dbg !266
@.str.88 = private unnamed_addr constant [9 x i8] c"settings\00", align 1, !dbg !271
@.str.89 = private unnamed_addr constant [10 x i8] c"cachedump\00", align 1, !dbg !273
@.str.90 = private unnamed_addr constant [41 x i8] c"CLIENT_ERROR stats cachedump not allowed\00", align 1, !dbg !275
@.str.91 = private unnamed_addr constant [29 x i8] c"CLIENT_ERROR Illegal slab id\00", align 1, !dbg !277
@.str.92 = private unnamed_addr constant [6 x i8] c"conns\00", align 1, !dbg !279
@.str.93 = private unnamed_addr constant [41 x i8] c"SERVER_ERROR out of memory writing stats\00", align 1, !dbg !281
@.str.95 = private unnamed_addr constant [3 x i8] c"OK\00", align 1, !dbg !283
@.str.96 = private unnamed_addr constant [4 x i8] c"off\00", align 1, !dbg !285
@.str.97 = private unnamed_addr constant [5 x i8] c"dump\00", align 1, !dbg !287
@.str.98 = private unnamed_addr constant [45 x i8] c"CLIENT_ERROR usage: stats detail on|off|dump\00", align 1, !dbg !289
@.str.99 = private unnamed_addr constant [28 x i8] c"ERROR: shutdown not enabled\00", align 1, !dbg !291
@.str.100 = private unnamed_addr constant [9 x i8] c"graceful\00", align 1, !dbg !293
@.str.101 = private unnamed_addr constant [35 x i8] c"CLIENT_ERROR invalid shutdown mode\00", align 1, !dbg !295
@.str.102 = private unnamed_addr constant [9 x i8] c"reassign\00", align 1, !dbg !297
@.str.103 = private unnamed_addr constant [40 x i8] c"CLIENT_ERROR slab reassignment disabled\00", align 1, !dbg !299
@.str.104 = private unnamed_addr constant [43 x i8] c"BUSY currently processing reassign request\00", align 1, !dbg !301
@.str.105 = private unnamed_addr constant [37 x i8] c"BADCLASS invalid src or dst class id\00", align 1, !dbg !303
@.str.106 = private unnamed_addr constant [40 x i8] c"NOSPARE source class has no spare pages\00", align 1, !dbg !305
@.str.107 = private unnamed_addr constant [37 x i8] c"SAME src and dst class are identical\00", align 1, !dbg !307
@.str.108 = private unnamed_addr constant [9 x i8] c"automove\00", align 1, !dbg !309
@.str.109 = private unnamed_addr constant [6 x i8] c"ratio\00", align 1, !dbg !311
@.str.110 = private unnamed_addr constant [55 x i8] c"MEMLIMIT_TOO_SMALL cannot set maxbytes to less than 8m\00", align 1, !dbg !313
@.str.111 = private unnamed_addr constant [58 x i8] c"MEMLIMIT_ADJUST_FAILED input value is megabytes not bytes\00", align 1, !dbg !318
@.str.112 = private unnamed_addr constant [28 x i8] c"maxbytes adjusted to %llum\0A\00", align 1, !dbg !323
@.str.113 = private unnamed_addr constant [57 x i8] c"MEMLIMIT_ADJUST_FAILED out of bounds or unable to adjust\00", align 1, !dbg !325
@.str.114 = private unnamed_addr constant [44 x i8] c"CLIENT_ERROR invalid numeric delta argument\00", align 1, !dbg !330
@.str.116 = private unnamed_addr constant [69 x i8] c"CLIENT_ERROR bad command line format.  Usage: delete <key> [noreply]\00", align 1, !dbg !332
@.str.117 = private unnamed_addr constant [8 x i8] c"DELETED\00", align 1, !dbg !337
@.str.118 = private unnamed_addr constant [8 x i8] c"TOUCHED\00", align 1, !dbg !339
@.str.119 = private unnamed_addr constant [35 x i8] c"CLIENT_ERROR flush_all not allowed\00", align 1, !dbg !341
@.str.120 = private unnamed_addr constant [15 x i8] c"VERSION 1.6.29\00", align 1, !dbg !343
@.str.121 = private unnamed_addr constant [6 x i8] c"crawl\00", align 1, !dbg !345
@.str.122 = private unnamed_addr constant [34 x i8] c"CLIENT_ERROR lru crawler disabled\00", align 1, !dbg !347
@.str.123 = private unnamed_addr constant [42 x i8] c"BUSY currently processing crawler request\00", align 1, !dbg !352
@.str.124 = private unnamed_addr constant [26 x i8] c"BADCLASS invalid class id\00", align 1, !dbg !354
@.str.125 = private unnamed_addr constant [29 x i8] c"NOTSTARTED no items to crawl\00", align 1, !dbg !356
@.str.126 = private unnamed_addr constant [32 x i8] c"ERROR an unknown error happened\00", align 1, !dbg !358
@.str.127 = private unnamed_addr constant [9 x i8] c"metadump\00", align 1, !dbg !360
@.str.128 = private unnamed_addr constant [27 x i8] c"ERROR metadump not allowed\00", align 1, !dbg !362
@.str.129 = private unnamed_addr constant [53 x i8] c"ERROR cannot pipeline other commands before metadump\00", align 1, !dbg !364
@.str.130 = private unnamed_addr constant [7 x i8] c"mgdump\00", align 1, !dbg !369
@.str.131 = private unnamed_addr constant [27 x i8] c"ERROR key dump not allowed\00", align 1, !dbg !371
@.str.132 = private unnamed_addr constant [51 x i8] c"ERROR cannot pipeline other commands before mgdump\00", align 1, !dbg !373
@.str.133 = private unnamed_addr constant [8 x i8] c"tocrawl\00", align 1, !dbg !375
@.str.134 = private unnamed_addr constant [6 x i8] c"sleep\00", align 1, !dbg !377
@.str.135 = private unnamed_addr constant [46 x i8] c"CLIENT_ERROR sleep must be one second or less\00", align 1, !dbg !379
@.str.136 = private unnamed_addr constant [7 x i8] c"enable\00", align 1, !dbg !381
@.str.137 = private unnamed_addr constant [41 x i8] c"ERROR failed to start lru crawler thread\00", align 1, !dbg !383
@.str.138 = private unnamed_addr constant [8 x i8] c"disable\00", align 1, !dbg !385
@.str.139 = private unnamed_addr constant [40 x i8] c"ERROR failed to stop lru crawler thread\00", align 1, !dbg !387
@.str.140 = private unnamed_addr constant [40 x i8] c"CLIENT_ERROR watch commands not allowed\00", align 1, !dbg !389
@.str.141 = private unnamed_addr constant [50 x i8] c"ERROR cannot pipeline other commands before watch\00", align 1, !dbg !391
@.str.142 = private unnamed_addr constant [8 x i8] c"rawcmds\00", align 1, !dbg !396
@.str.143 = private unnamed_addr constant [10 x i8] c"evictions\00", align 1, !dbg !398
@.str.144 = private unnamed_addr constant [9 x i8] c"fetchers\00", align 1, !dbg !400
@.str.145 = private unnamed_addr constant [10 x i8] c"mutations\00", align 1, !dbg !402
@.str.146 = private unnamed_addr constant [10 x i8] c"sysevents\00", align 1, !dbg !404
@.str.147 = private unnamed_addr constant [11 x i8] c"connevents\00", align 1, !dbg !406
@.str.148 = private unnamed_addr constant [10 x i8] c"proxyreqs\00", align 1, !dbg !408
@.str.149 = private unnamed_addr constant [12 x i8] c"proxyevents\00", align 1, !dbg !410
@.str.150 = private unnamed_addr constant [10 x i8] c"proxyuser\00", align 1, !dbg !412
@.str.151 = private unnamed_addr constant [10 x i8] c"deletions\00", align 1, !dbg !414
@.str.152 = private unnamed_addr constant [43 x i8] c"WATCHER_TOO_MANY log watcher limit reached\00", align 1, !dbg !416
@.str.153 = private unnamed_addr constant [41 x i8] c"WATCHER_FAILED failed to add log watcher\00", align 1, !dbg !418
@.str.154 = private unnamed_addr constant [5 x i8] c"tune\00", align 1, !dbg !420
@.str.155 = private unnamed_addr constant [43 x i8] c"ERROR hot and warm pcts must not exceed 80\00", align 1, !dbg !422
@.str.156 = private unnamed_addr constant [50 x i8] c"ERROR hot/warm age factors must be greater than 0\00", align 1, !dbg !424
@.str.157 = private unnamed_addr constant [5 x i8] c"mode\00", align 1, !dbg !426
@.str.158 = private unnamed_addr constant [5 x i8] c"flat\00", align 1, !dbg !428
@.str.159 = private unnamed_addr constant [10 x i8] c"segmented\00", align 1, !dbg !430
@.str.160 = private unnamed_addr constant [9 x i8] c"temp_ttl\00", align 1, !dbg !432
@.str.161 = private unnamed_addr constant [15 x i8] c"free_memchunks\00", align 1, !dbg !434
@.str.162 = private unnamed_addr constant [10 x i8] c"item_size\00", align 1, !dbg !436
@.str.163 = private unnamed_addr constant [9 x i8] c"item_age\00", align 1, !dbg !438
@.str.164 = private unnamed_addr constant [8 x i8] c"low_ttl\00", align 1, !dbg !440
@.str.165 = private unnamed_addr constant [13 x i8] c"recache_rate\00", align 1, !dbg !442
@.str.166 = private unnamed_addr constant [14 x i8] c"compact_under\00", align 1, !dbg !447
@.str.167 = private unnamed_addr constant [11 x i8] c"drop_under\00", align 1, !dbg !452
@.str.168 = private unnamed_addr constant [10 x i8] c"max_sleep\00", align 1, !dbg !454
@.str.169 = private unnamed_addr constant [9 x i8] c"max_frag\00", align 1, !dbg !456
@.str.170 = private unnamed_addr constant [12 x i8] c"drop_unread\00", align 1, !dbg !458
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @complete_nread_ascii(ptr noundef %c) local_unnamed_addr #0 !dbg !777 {
entry:
  %nbytes = alloca i32, align 4, !DIAssignID !1203
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1195, metadata !DIExpression(), metadata !1203, metadata ptr %nbytes, metadata !DIExpression()), !dbg !1204
  %buf = alloca [2 x i8], align 1, !DIAssignID !1205
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1196, metadata !DIExpression(), metadata !1205, metadata ptr %buf, metadata !DIExpression()), !dbg !1206
  %cas = alloca i64, align 8, !DIAssignID !1207
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1200, metadata !DIExpression(), metadata !1207, metadata ptr %cas, metadata !DIExpression()), !dbg !1208
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1190, metadata !DIExpression()), !dbg !1204
  %item = getelementptr inbounds i8, ptr %c, i64 224, !dbg !1209
  %0 = load ptr, ptr %item, align 8, !dbg !1209, !tbaa !1210
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1191, metadata !DIExpression()), !dbg !1204
  %cmd = getelementptr inbounds i8, ptr %c, i64 432, !dbg !1226
  %1 = load i16, ptr %cmd, align 8, !dbg !1226, !tbaa !1227
  %conv = sext i16 %1 to i32, !dbg !1228
  tail call void @llvm.dbg.value(metadata i32 %conv, metadata !1192, metadata !DIExpression()), !dbg !1204
  tail call void @llvm.dbg.value(metadata i8 0, metadata !1194, metadata !DIExpression()), !dbg !1204
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %nbytes) #13, !dbg !1229
  store i32 0, ptr %nbytes, align 4, !dbg !1230, !tbaa !1231, !DIAssignID !1232
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !1195, metadata !DIExpression(), metadata !1232, metadata ptr %nbytes, metadata !DIExpression()), !dbg !1204
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !1233
  %2 = load ptr, ptr %thread, align 8, !dbg !1233, !tbaa !1234
  %stats = getelementptr inbounds i8, ptr %2, i64 352, !dbg !1235
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #13, !dbg !1236
  %3 = load ptr, ptr %thread, align 8, !dbg !1237, !tbaa !1234
  %slab_stats = getelementptr inbounds i8, ptr %3, i64 632, !dbg !1238
  %slabs_clsid = getelementptr inbounds i8, ptr %0, i64 40, !dbg !1239
  %4 = load i8, ptr %slabs_clsid, align 8, !dbg !1239, !tbaa !1240
  %5 = and i8 %4, 63, !dbg !1239
  %idxprom = zext nneg i8 %5 to i64
  %arrayidx = getelementptr inbounds [64 x %struct.slab_stats], ptr %slab_stats, i64 0, i64 %idxprom, !dbg !1241
  %6 = load i64, ptr %arrayidx, align 8, !dbg !1242, !tbaa !1243
  %inc = add i64 %6, 1, !dbg !1242
  store i64 %inc, ptr %arrayidx, align 8, !dbg !1242, !tbaa !1243
  %stats5 = getelementptr inbounds i8, ptr %3, i64 352, !dbg !1245
  %call7 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats5) #13, !dbg !1246
  %it_flags = getelementptr inbounds i8, ptr %0, i64 38, !dbg !1247
  %7 = load i16, ptr %it_flags, align 2, !dbg !1247, !tbaa !1248
  %conv8 = zext i16 %7 to i32, !dbg !1249
  %and9 = and i32 %conv8, 32, !dbg !1250
  %cmp = icmp eq i32 %and9, 0, !dbg !1251
  br i1 %cmp, label %if.end66, label %if.else, !dbg !1252

if.else:                                          ; preds = %entry
  call void @llvm.lifetime.start.p0(i64 2, ptr nonnull %buf) #13, !dbg !1253
  %ritem = getelementptr inbounds i8, ptr %c, i64 208, !dbg !1254
  %8 = load ptr, ptr %ritem, align 8, !dbg !1254, !tbaa !1255
  tail call void @llvm.dbg.value(metadata ptr %8, metadata !1199, metadata !DIExpression()), !dbg !1206
  %used = getelementptr inbounds i8, ptr %8, i64 28, !dbg !1256
  %9 = load i32, ptr %used, align 4, !dbg !1256, !tbaa !1231
  %cmp31 = icmp sgt i32 %9, 1, !dbg !1258
  br i1 %cmp31, label %if.then33, label %if.else45, !dbg !1259

if.then33:                                        ; preds = %if.else
  %data34 = getelementptr inbounds i8, ptr %8, i64 42, !dbg !1260
  %sub = add nsw i32 %9, -2, !dbg !1262
  %idxprom36 = zext nneg i32 %sub to i64
  %arrayidx37 = getelementptr inbounds [0 x i8], ptr %data34, i64 0, i64 %idxprom36, !dbg !1263
  tail call void @llvm.dbg.assign(metadata i8 poison, metadata !1196, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !1264, metadata ptr %buf, metadata !DIExpression()), !dbg !1206
  %sub41 = add nsw i32 %9, -1, !dbg !1265
  %idxprom42 = zext nneg i32 %sub41 to i64, !dbg !1266
  %arrayidx43 = getelementptr inbounds [0 x i8], ptr %data34, i64 0, i64 %idxprom42, !dbg !1266
  tail call void @llvm.dbg.assign(metadata i8 poison, metadata !1196, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !1267, metadata ptr %12, metadata !DIExpression()), !dbg !1206
  br label %if.end59, !dbg !1268

if.else45:                                        ; preds = %if.else
  %prev = getelementptr inbounds i8, ptr %8, i64 8, !dbg !1269
  %10 = load ptr, ptr %prev, align 8, !dbg !1269, !tbaa !1271
  %data46 = getelementptr inbounds i8, ptr %10, i64 42, !dbg !1272
  %used48 = getelementptr inbounds i8, ptr %10, i64 28, !dbg !1273
  %11 = load i32, ptr %used48, align 4, !dbg !1273, !tbaa !1231
  %sub49 = add nsw i32 %11, -1, !dbg !1274
  %idxprom50 = sext i32 %sub49 to i64, !dbg !1275
  %arrayidx51 = getelementptr inbounds [0 x i8], ptr %data46, i64 0, i64 %idxprom50, !dbg !1275
  tail call void @llvm.dbg.assign(metadata i8 poison, metadata !1196, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !1264, metadata ptr %buf, metadata !DIExpression()), !dbg !1206
  %data53 = getelementptr inbounds i8, ptr %8, i64 42, !dbg !1276
  %sub55 = add nsw i32 %9, -1, !dbg !1277
  %idxprom56 = sext i32 %sub55 to i64, !dbg !1278
  %arrayidx57 = getelementptr inbounds [0 x i8], ptr %data53, i64 0, i64 %idxprom56, !dbg !1278
  tail call void @llvm.dbg.assign(metadata i8 poison, metadata !1196, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !1267, metadata ptr %12, metadata !DIExpression()), !dbg !1206
  br label %if.end59

if.end59:                                         ; preds = %if.else45, %if.then33
  %.sink139.in = phi ptr [ %arrayidx37, %if.then33 ], [ %arrayidx51, %if.else45 ]
  %.sink.in = phi ptr [ %arrayidx43, %if.then33 ], [ %arrayidx57, %if.else45 ]
  %.sink = load i8, ptr %.sink.in, align 1, !dbg !1279, !tbaa !1240
  %.sink139 = load i8, ptr %.sink139.in, align 1, !dbg !1279, !tbaa !1240
  store i8 %.sink139, ptr %buf, align 1, !dbg !1279, !DIAssignID !1264
  %12 = getelementptr inbounds i8, ptr %buf, i64 1, !dbg !1279
  store i8 %.sink, ptr %12, align 1, !dbg !1279, !DIAssignID !1267
  %bcmp = call i32 @bcmp(ptr noundef nonnull dereferenceable(2) %buf, ptr noundef nonnull dereferenceable(2) @.str, i64 2) #14, !dbg !1280
  %cmp61 = icmp eq i32 %bcmp, 0, !dbg !1282
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !1194, metadata !DIExpression()), !dbg !1204
  call void @llvm.lifetime.end.p0(i64 2, ptr nonnull %buf) #13, !dbg !1283
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !1194, metadata !DIExpression()), !dbg !1204
  br i1 %cmp61, label %if.else72, label %if.then68, !dbg !1284

if.end66:                                         ; preds = %entry
  %data = getelementptr inbounds i8, ptr %0, i64 48, !dbg !1285
  %nkey = getelementptr inbounds i8, ptr %0, i64 41, !dbg !1285
  %13 = load i8, ptr %nkey, align 1, !dbg !1285, !tbaa !1240
  %idx.ext = zext i8 %13 to i64
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %idx.ext, !dbg !1285
  %add.ptr12 = getelementptr inbounds i8, ptr %add.ptr, i64 1, !dbg !1285
  %and15 = lshr i32 %conv8, 6, !dbg !1285
  %14 = and i32 %and15, 4, !dbg !1285
  %cond = zext nneg i32 %14 to i64, !dbg !1285
  %add.ptr16 = getelementptr inbounds i8, ptr %add.ptr12, i64 %cond, !dbg !1285
  %and19 = shl nuw nsw i32 %conv8, 2, !dbg !1285
  %15 = and i32 %and19, 8, !dbg !1285
  %cond21 = zext nneg i32 %15 to i64, !dbg !1285
  %add.ptr22 = getelementptr inbounds i8, ptr %add.ptr16, i64 %cond21, !dbg !1285
  %nbytes23 = getelementptr inbounds i8, ptr %0, i64 32, !dbg !1288
  %16 = load i32, ptr %nbytes23, align 8, !dbg !1288, !tbaa !1231
  %idx.ext24 = sext i32 %16 to i64, !dbg !1289
  %add.ptr25 = getelementptr inbounds i8, ptr %add.ptr22, i64 %idx.ext24, !dbg !1289
  %add.ptr26 = getelementptr inbounds i8, ptr %add.ptr25, i64 -2, !dbg !1290
  %17 = load i8, ptr %add.ptr26, align 1
  %.not = icmp eq i8 %17, 13
  br i1 %.not, label %if.end66.tail, label %if.then68

if.end66.tail:                                    ; preds = %if.end66
  %18 = getelementptr inbounds i8, ptr %add.ptr25, i64 -1
  %19 = load i8, ptr %18, align 1
  %20 = icmp eq i8 %19, 10, !dbg !1291
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !1194, metadata !DIExpression()), !dbg !1204
  br i1 %20, label %if.else72, label %if.then68, !dbg !1284

if.then68:                                        ; preds = %if.end66, %if.end59, %if.end66.tail
  %mset_res = getelementptr inbounds i8, ptr %c, i64 15, !dbg !1292
  %21 = load i8, ptr %mset_res, align 1, !dbg !1292, !tbaa !1295, !range !1296, !noundef !1297
  %tobool69 = trunc nuw i8 %21 to i1, !dbg !1292
  br i1 %tobool69, label %if.then70, label %if.end71, !dbg !1298

if.then70:                                        ; preds = %if.then68
  %noreply = getelementptr inbounds i8, ptr %c, i64 364, !dbg !1299
  store i8 0, ptr %noreply, align 4, !dbg !1301, !tbaa !1302
  br label %if.end71, !dbg !1303

if.end71:                                         ; preds = %if.then70, %if.then68
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.1) #13, !dbg !1304
  br label %if.end91, !dbg !1305

if.else72:                                        ; preds = %if.end59, %if.end66.tail
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %cas) #13, !dbg !1306
  store i64 0, ptr %cas, align 8, !dbg !1307, !tbaa !1308, !DIAssignID !1309
  tail call void @llvm.dbg.assign(metadata i64 0, metadata !1200, metadata !DIExpression(), metadata !1309, metadata ptr %cas, metadata !DIExpression()), !dbg !1208
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1310
  %22 = load i32, ptr %sfd, align 8, !dbg !1310, !tbaa !1311
  %23 = load ptr, ptr %thread, align 8, !dbg !1312, !tbaa !1234
  %cur_sfd = getelementptr inbounds i8, ptr %23, i64 344, !dbg !1313
  store i32 %22, ptr %cur_sfd, align 8, !dbg !1314, !tbaa !1315
  %cas75 = getelementptr inbounds i8, ptr %c, i64 416, !dbg !1320
  %24 = load i64, ptr %cas75, align 8, !dbg !1320, !tbaa !1321
  %tobool76.not = icmp eq i64 %24, 0, !dbg !1322
  br i1 %tobool76.not, label %cond.false, label %cond.end, !dbg !1322

cond.false:                                       ; preds = %if.else72
  %call78 = tail call i64 @get_cas_id() #13, !dbg !1323
  br label %cond.end, !dbg !1322

cond.end:                                         ; preds = %if.else72, %cond.false
  %cond79 = phi i64 [ %call78, %cond.false ], [ %24, %if.else72 ], !dbg !1322
  %set_stale = getelementptr inbounds i8, ptr %c, i64 14, !dbg !1324
  %25 = load i8, ptr %set_stale, align 2, !dbg !1324, !tbaa !1325, !range !1296, !noundef !1297
  %tobool80 = trunc nuw i8 %25 to i1, !dbg !1324
  %call81 = call i32 @store_item(ptr noundef nonnull %0, i32 noundef %conv, ptr noundef nonnull %23, ptr noundef nonnull %nbytes, ptr noundef nonnull %cas, i64 noundef %cond79, i1 noundef zeroext %tobool80) #13, !dbg !1326
  tail call void @llvm.dbg.value(metadata i32 %call81, metadata !1193, metadata !DIExpression()), !dbg !1204
  store i64 0, ptr %cas75, align 8, !dbg !1327, !tbaa !1321
  %mset_res83 = getelementptr inbounds i8, ptr %c, i64 15, !dbg !1328
  %26 = load i8, ptr %mset_res83, align 1, !dbg !1328, !tbaa !1295, !range !1296, !noundef !1297
  %tobool84 = trunc nuw i8 %26 to i1, !dbg !1328
  br i1 %tobool84, label %if.then85, label %if.else86, !dbg !1330

if.then85:                                        ; preds = %cond.end
  %27 = load i32, ptr %nbytes, align 4, !dbg !1331, !tbaa !1231
  %28 = load i64, ptr %cas, align 8, !dbg !1333, !tbaa !1308
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1334, metadata !DIExpression()), !dbg !1348
  tail call void @llvm.dbg.value(metadata i32 %27, metadata !1339, metadata !DIExpression()), !dbg !1348
  tail call void @llvm.dbg.value(metadata i32 %call81, metadata !1340, metadata !DIExpression()), !dbg !1348
  tail call void @llvm.dbg.value(metadata i64 %28, metadata !1341, metadata !DIExpression()), !dbg !1348
  %resp1.i = getelementptr inbounds i8, ptr %c, i64 192, !dbg !1350
  %29 = load ptr, ptr %resp1.i, align 8, !dbg !1350, !tbaa !1351
  tail call void @llvm.dbg.value(metadata ptr %29, metadata !1342, metadata !DIExpression()), !dbg !1348
  %30 = load ptr, ptr %item, align 8, !dbg !1352, !tbaa !1210
  tail call void @llvm.dbg.value(metadata ptr %30, metadata !1343, metadata !DIExpression()), !dbg !1348
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 1) #13, !dbg !1353
  %wbuf.ptr.i = getelementptr inbounds i8, ptr %29, i64 160, !dbg !1354
  %wbytes.i = getelementptr inbounds i8, ptr %29, i64 16, !dbg !1354
  %31 = load i32, ptr %wbytes.i, align 8, !dbg !1354, !tbaa !1355
  %idx.ext.i = sext i32 %31 to i64, !dbg !1357
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.ptr.i, metadata !1344, metadata !DIExpression()), !dbg !1348
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.ptr.i, metadata !1345, metadata !DIExpression()), !dbg !1348
  %32 = getelementptr i8, ptr %29, i64 %idx.ext.i, !dbg !1358
  %add.ptr.ptr.i = getelementptr i8, ptr %32, i64 160, !dbg !1358
  switch i32 %call81, label %sw.default.i [
    i32 1, label %sw.bb.i
    i32 2, label %sw.bb2.i
    i32 3, label %sw.bb3.i
    i32 0, label %sw.bb4.i
  ], !dbg !1358

sw.bb.i:                                          ; preds = %if.then85
  store i16 17480, ptr %add.ptr.ptr.i, align 1, !dbg !1359
  %noreply.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !1361
  %33 = load i8, ptr %noreply.i, align 4, !dbg !1361, !tbaa !1302, !range !1296, !noundef !1297
  %tobool.i = trunc nuw i8 %33 to i1, !dbg !1361
  br i1 %tobool.i, label %if.then.i, label %sw.epilog.i, !dbg !1363

if.then.i:                                        ; preds = %sw.bb.i
  %skip.i = getelementptr inbounds i8, ptr %29, i64 118, !dbg !1364
  store i8 1, ptr %skip.i, align 2, !dbg !1366, !tbaa !1367
  br label %sw.epilog.i, !dbg !1368

sw.bb2.i:                                         ; preds = %if.then85
  store i16 22597, ptr %add.ptr.ptr.i, align 1, !dbg !1369
  br label %sw.epilog.i, !dbg !1370

sw.bb3.i:                                         ; preds = %if.then85
  store i16 17998, ptr %add.ptr.ptr.i, align 1, !dbg !1371
  br label %sw.epilog.i, !dbg !1372

sw.bb4.i:                                         ; preds = %if.then85
  store i16 21326, ptr %add.ptr.ptr.i, align 1, !dbg !1373
  br label %sw.epilog.i, !dbg !1374

sw.default.i:                                     ; preds = %if.then85
  %noreply5.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !1375
  store i8 0, ptr %noreply5.i, align 4, !dbg !1376, !tbaa !1302
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.6) #13, !dbg !1377
  br label %if.end90, !dbg !1378

sw.epilog.i:                                      ; preds = %sw.bb4.i, %sw.bb3.i, %sw.bb2.i, %if.then.i, %sw.bb.i
  %add.ptr6.i = getelementptr i8, ptr %32, i64 162, !dbg !1379
  tail call void @llvm.dbg.value(metadata ptr %add.ptr6.i, metadata !1344, metadata !DIExpression()), !dbg !1348
  tail call void @llvm.dbg.value(metadata ptr %wbuf.ptr.i, metadata !1346, metadata !DIExpression()), !dbg !1380
  %cmp145.i = icmp sgt i32 %31, 0, !dbg !1381
  br i1 %cmp145.i, label %for.body.lr.ph.i, label %for.cond.cleanup.i, !dbg !1383

for.body.lr.ph.i:                                 ; preds = %sw.epilog.i
  %cmp53.not.i = icmp eq i32 %27, 0
  %sub.i = add nsw i32 %27, -2
  %nbytes58.i = getelementptr inbounds i8, ptr %30, i64 32
  %it_flags.i = getelementptr inbounds i8, ptr %30, i64 38
  %data33.i = getelementptr inbounds i8, ptr %30, i64 48
  %nkey40.i = getelementptr inbounds i8, ptr %30, i64 41
  br label %for.body.i, !dbg !1383

for.cond.cleanup.i:                               ; preds = %for.inc.i, %sw.epilog.i
  %p.0.lcssa.i = phi ptr [ %add.ptr6.i, %sw.epilog.i ], [ %p.2.i, %for.inc.i ], !dbg !1379
  store i16 2573, ptr %p.0.lcssa.i, align 1, !dbg !1384
  %add.ptr65.i = getelementptr inbounds i8, ptr %p.0.lcssa.i, i64 2, !dbg !1385
  tail call void @llvm.dbg.value(metadata ptr %add.ptr65.i, metadata !1344, metadata !DIExpression()), !dbg !1348
  %sub.ptr.lhs.cast.i = ptrtoint ptr %add.ptr65.i to i64, !dbg !1386
  %sub.ptr.rhs.cast.i = ptrtoint ptr %wbuf.ptr.i to i64, !dbg !1386
  %sub.ptr.sub.i = sub i64 %sub.ptr.lhs.cast.i, %sub.ptr.rhs.cast.i, !dbg !1386
  %conv68.i = trunc i64 %sub.ptr.sub.i to i32, !dbg !1387
  store i32 %conv68.i, ptr %wbytes.i, align 8, !dbg !1388, !tbaa !1355
  %sub.ptr.rhs.cast71.i = ptrtoint ptr %add.ptr.ptr.i to i64, !dbg !1389
  %sub.ptr.sub72.i = sub i64 %sub.ptr.lhs.cast.i, %sub.ptr.rhs.cast71.i, !dbg !1389
  %conv73.i = trunc i64 %sub.ptr.sub72.i to i32, !dbg !1390
  call void @resp_add_iov(ptr noundef %29, ptr noundef nonnull %add.ptr.ptr.i, i32 noundef %conv73.i) #13, !dbg !1391
  br label %if.end90, !dbg !1392

for.body.i:                                       ; preds = %for.inc.i, %for.body.lr.ph.i
  %fp.0147.i = phi ptr [ %wbuf.ptr.i, %for.body.lr.ph.i ], [ %incdec.ptr64.i, %for.inc.i ]
  %p.0146.i = phi ptr [ %add.ptr6.i, %for.body.lr.ph.i ], [ %p.2.i, %for.inc.i ]
  tail call void @llvm.dbg.value(metadata ptr %fp.0147.i, metadata !1346, metadata !DIExpression()), !dbg !1380
  tail call void @llvm.dbg.value(metadata ptr %p.0146.i, metadata !1344, metadata !DIExpression()), !dbg !1348
  %34 = load i8, ptr %fp.0147.i, align 1, !dbg !1393, !tbaa !1240
  %conv.i = sext i8 %34 to i32, !dbg !1393
  %35 = add nsw i32 %conv.i, -79, !dbg !1395
  %36 = call i32 @llvm.fshl.i32(i32 %35, i32 %35, i32 30), !dbg !1395
  switch i32 %36, label %for.inc.i [
    i32 0, label %sw.bb9.i
    i32 7, label %sw.bb17.i
    i32 5, label %sw.bb46.i
    i32 9, label %sw.bb50.i
  ], !dbg !1395

sw.bb9.i:                                         ; preds = %for.body.i
  store i8 32, ptr %p.0146.i, align 1, !dbg !1396, !tbaa !1240
  tail call void @llvm.dbg.value(metadata ptr %p.0146.i, metadata !1344, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !1348
  %p.1138.i = getelementptr inbounds i8, ptr %p.0146.i, i64 1, !dbg !1399
  %cmp10139.i = icmp ult ptr %fp.0147.i, %add.ptr.ptr.i, !dbg !1400
  br i1 %cmp10139.i, label %land.rhs.i, label %for.inc.i, !dbg !1401

land.rhs.i:                                       ; preds = %sw.bb9.i, %while.body.i
  %p.1141.i = phi ptr [ %p.1.i, %while.body.i ], [ %p.1138.i, %sw.bb9.i ]
  %fp.1140.i = phi ptr [ %incdec.ptr16.i, %while.body.i ], [ %fp.0147.i, %sw.bb9.i ]
  tail call void @llvm.dbg.value(metadata ptr %fp.1140.i, metadata !1346, metadata !DIExpression()), !dbg !1380
  %37 = load i8, ptr %fp.1140.i, align 1, !dbg !1402, !tbaa !1240
  %cmp13.not.i = icmp eq i8 %37, 32, !dbg !1403
  br i1 %cmp13.not.i, label %for.inc.i, label %while.body.i, !dbg !1404

while.body.i:                                     ; preds = %land.rhs.i
  store i8 %37, ptr %p.1141.i, align 1, !dbg !1405, !tbaa !1240
  tail call void @llvm.dbg.value(metadata ptr %p.1141.i, metadata !1344, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !1348
  %incdec.ptr16.i = getelementptr inbounds i8, ptr %fp.1140.i, i64 1, !dbg !1407
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr16.i, metadata !1346, metadata !DIExpression()), !dbg !1380
  %p.1.i = getelementptr inbounds i8, ptr %p.1141.i, i64 1, !dbg !1399
  tail call void @llvm.dbg.value(metadata ptr %p.1.i, metadata !1344, metadata !DIExpression()), !dbg !1348
  %cmp10.i = icmp ult ptr %incdec.ptr16.i, %add.ptr.ptr.i, !dbg !1400
  br i1 %cmp10.i, label %land.rhs.i, label %for.inc.i, !dbg !1401, !llvm.loop !1408

sw.bb17.i:                                        ; preds = %for.body.i
  store i8 32, ptr %p.0146.i, align 1, !dbg !1411, !tbaa !1240
  %add.ptr18.i = getelementptr inbounds i8, ptr %p.0146.i, i64 1, !dbg !1411
  store i8 107, ptr %add.ptr18.i, align 1, !dbg !1411, !tbaa !1240
  %add.ptr19.i = getelementptr inbounds i8, ptr %p.0146.i, i64 2, !dbg !1411
  tail call void @llvm.dbg.value(metadata ptr %add.ptr19.i, metadata !1344, metadata !DIExpression()), !dbg !1348
  %38 = load i16, ptr %it_flags.i, align 2, !dbg !1414, !tbaa !1248
  %conv20.i = zext i16 %38 to i32, !dbg !1414
  %and.i = and i32 %conv20.i, 4096, !dbg !1414
  %tobool21.not.i = icmp eq i32 %and.i, 0, !dbg !1414
  %and25.i = shl nuw nsw i32 %conv20.i, 2, !dbg !1414
  %39 = and i32 %and25.i, 8, !dbg !1414
  %cond.i = zext nneg i32 %39 to i64, !dbg !1414
  %add.ptr27.i = getelementptr inbounds i8, ptr %data33.i, i64 %cond.i, !dbg !1414
  %40 = load i8, ptr %nkey40.i, align 1, !dbg !1414, !tbaa !1240
  %conv28.i = zext i8 %40 to i64, !dbg !1414
  br i1 %tobool21.not.i, label %if.then22.i, label %if.else.i, !dbg !1416

if.then22.i:                                      ; preds = %sw.bb17.i
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr19.i, ptr nonnull align 1 %add.ptr27.i, i64 %conv28.i, i1 false), !dbg !1417
  %41 = load i8, ptr %nkey40.i, align 1, !dbg !1417, !tbaa !1240
  %idx.ext31.i = zext i8 %41 to i64
  %add.ptr32.i = getelementptr inbounds i8, ptr %add.ptr19.i, i64 %idx.ext31.i, !dbg !1417
  tail call void @llvm.dbg.value(metadata ptr %add.ptr32.i, metadata !1344, metadata !DIExpression()), !dbg !1348
  br label %for.inc.i, !dbg !1417

if.else.i:                                        ; preds = %sw.bb17.i
  %call.i = call i64 @base64_encode(ptr noundef nonnull %add.ptr27.i, i64 noundef %conv28.i, ptr noundef nonnull %add.ptr19.i, i64 noundef 512) #13, !dbg !1419
  %add.ptr42.i = getelementptr inbounds i8, ptr %add.ptr19.i, i64 %call.i, !dbg !1419
  tail call void @llvm.dbg.value(metadata ptr %add.ptr42.i, metadata !1344, metadata !DIExpression()), !dbg !1348
  store i8 32, ptr %add.ptr42.i, align 1, !dbg !1419, !tbaa !1240
  %add.ptr43.i = getelementptr inbounds i8, ptr %add.ptr42.i, i64 1, !dbg !1419
  store i8 98, ptr %add.ptr43.i, align 1, !dbg !1419, !tbaa !1240
  %add.ptr44.i = getelementptr inbounds i8, ptr %add.ptr42.i, i64 2, !dbg !1419
  tail call void @llvm.dbg.value(metadata ptr %add.ptr44.i, metadata !1344, metadata !DIExpression()), !dbg !1348
  br label %for.inc.i

sw.bb46.i:                                        ; preds = %for.body.i
  store i8 32, ptr %p.0146.i, align 1, !dbg !1421, !tbaa !1240
  %add.ptr47.i = getelementptr inbounds i8, ptr %p.0146.i, i64 1, !dbg !1421
  store i8 99, ptr %add.ptr47.i, align 1, !dbg !1421, !tbaa !1240
  %add.ptr48.i = getelementptr inbounds i8, ptr %p.0146.i, i64 2, !dbg !1421
  tail call void @llvm.dbg.value(metadata ptr %add.ptr48.i, metadata !1344, metadata !DIExpression()), !dbg !1348
  %call49.i = call ptr @itoa_u64(i64 noundef %28, ptr noundef nonnull %add.ptr48.i) #13, !dbg !1423
  tail call void @llvm.dbg.value(metadata ptr %call49.i, metadata !1344, metadata !DIExpression()), !dbg !1348
  br label %for.inc.i, !dbg !1424

sw.bb50.i:                                        ; preds = %for.body.i
  store i8 32, ptr %p.0146.i, align 1, !dbg !1425, !tbaa !1240
  %add.ptr51.i = getelementptr inbounds i8, ptr %p.0146.i, i64 1, !dbg !1425
  store i8 115, ptr %add.ptr51.i, align 1, !dbg !1425, !tbaa !1240
  %add.ptr52.i = getelementptr inbounds i8, ptr %p.0146.i, i64 2, !dbg !1425
  tail call void @llvm.dbg.value(metadata ptr %add.ptr52.i, metadata !1344, metadata !DIExpression()), !dbg !1348
  br i1 %cmp53.not.i, label %if.else57.i, label %if.then55.i, !dbg !1427

if.then55.i:                                      ; preds = %sw.bb50.i
  %call56.i = call ptr @itoa_u32(i32 noundef %sub.i, ptr noundef nonnull %add.ptr52.i) #13, !dbg !1428
  tail call void @llvm.dbg.value(metadata ptr %call56.i, metadata !1344, metadata !DIExpression()), !dbg !1348
  br label %for.inc.i, !dbg !1431

if.else57.i:                                      ; preds = %sw.bb50.i
  %42 = load i32, ptr %nbytes58.i, align 8, !dbg !1432, !tbaa !1231
  %sub59.i = add nsw i32 %42, -2, !dbg !1434
  %call60.i = call ptr @itoa_u32(i32 noundef %sub59.i, ptr noundef nonnull %add.ptr52.i) #13, !dbg !1435
  tail call void @llvm.dbg.value(metadata ptr %call60.i, metadata !1344, metadata !DIExpression()), !dbg !1348
  br label %for.inc.i

for.inc.i:                                        ; preds = %while.body.i, %land.rhs.i, %if.else57.i, %if.then55.i, %sw.bb46.i, %if.else.i, %if.then22.i, %sw.bb9.i, %for.body.i
  %p.2.i = phi ptr [ %p.0146.i, %for.body.i ], [ %call56.i, %if.then55.i ], [ %call60.i, %if.else57.i ], [ %call49.i, %sw.bb46.i ], [ %add.ptr44.i, %if.else.i ], [ %add.ptr32.i, %if.then22.i ], [ %p.1138.i, %sw.bb9.i ], [ %p.1.i, %while.body.i ], [ %p.1141.i, %land.rhs.i ], !dbg !1348
  %fp.2.i = phi ptr [ %fp.0147.i, %for.body.i ], [ %fp.0147.i, %if.then55.i ], [ %fp.0147.i, %if.else57.i ], [ %fp.0147.i, %sw.bb46.i ], [ %fp.0147.i, %if.else.i ], [ %fp.0147.i, %if.then22.i ], [ %fp.0147.i, %sw.bb9.i ], [ %incdec.ptr16.i, %while.body.i ], [ %fp.1140.i, %land.rhs.i ], !dbg !1436
  tail call void @llvm.dbg.value(metadata ptr %fp.2.i, metadata !1346, metadata !DIExpression()), !dbg !1380
  tail call void @llvm.dbg.value(metadata ptr %p.2.i, metadata !1344, metadata !DIExpression()), !dbg !1348
  %incdec.ptr64.i = getelementptr inbounds i8, ptr %fp.2.i, i64 1, !dbg !1437
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr64.i, metadata !1346, metadata !DIExpression()), !dbg !1380
  %cmp.i = icmp ult ptr %incdec.ptr64.i, %add.ptr.ptr.i, !dbg !1381
  br i1 %cmp.i, label %for.body.i, label %for.cond.cleanup.i, !dbg !1383, !llvm.loop !1438

if.else86:                                        ; preds = %cond.end
  switch i32 %call81, label %sw.default [
    i32 1, label %sw.bb
    i32 2, label %sw.bb87
    i32 3, label %sw.bb88
    i32 0, label %sw.bb89
  ], !dbg !1440

sw.bb:                                            ; preds = %if.else86
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.2) #13, !dbg !1442
  br label %if.end90, !dbg !1444

sw.bb87:                                          ; preds = %if.else86
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.3) #13, !dbg !1445
  br label %if.end90, !dbg !1446

sw.bb88:                                          ; preds = %if.else86
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.4) #13, !dbg !1447
  br label %if.end90, !dbg !1448

sw.bb89:                                          ; preds = %if.else86
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.5) #13, !dbg !1449
  br label %if.end90, !dbg !1450

sw.default:                                       ; preds = %if.else86
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.6) #13, !dbg !1451
  br label %if.end90, !dbg !1452

if.end90:                                         ; preds = %for.cond.cleanup.i, %sw.default.i, %sw.bb, %sw.bb87, %sw.bb88, %sw.bb89, %sw.default
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %cas) #13, !dbg !1453
  br label %if.end91

if.end91:                                         ; preds = %if.end90, %if.end71
  %set_stale92 = getelementptr inbounds i8, ptr %c, i64 14, !dbg !1454
  store i8 0, ptr %set_stale92, align 2, !dbg !1455, !tbaa !1325
  %mset_res93 = getelementptr inbounds i8, ptr %c, i64 15, !dbg !1456
  store i8 0, ptr %mset_res93, align 1, !dbg !1457, !tbaa !1295
  %43 = load ptr, ptr %item, align 8, !dbg !1458, !tbaa !1210
  call void @item_remove(ptr noundef %43) #13, !dbg !1459
  store ptr null, ptr %item, align 8, !dbg !1460, !tbaa !1210
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %nbytes) #13, !dbg !1461
  ret void, !dbg !1461
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nounwind
declare !dbg !1462 i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind
declare !dbg !1467 i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare !dbg !1468 i32 @strncmp(ptr nocapture noundef, ptr nocapture noundef, i64 noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

declare !dbg !1474 void @out_string(ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !1477 i32 @store_item(ptr noundef, i32 noundef, ptr noundef, ptr noundef, ptr noundef, i64 noundef, i1 noundef zeroext) local_unnamed_addr #4

declare !dbg !1483 i64 @get_cas_id() local_unnamed_addr #4

declare !dbg !1487 void @item_remove(ptr noundef) local_unnamed_addr #4

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef i32 @try_read_command_asciiauth(ptr noundef %c) local_unnamed_addr #0 !dbg !1490 {
entry:
  %tokens = alloca [24 x %struct.token_s], align 16, !DIAssignID !1506
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1493, metadata !DIExpression(), metadata !1506, metadata ptr %tokens, metadata !DIExpression()), !dbg !1507
  %size = alloca i32, align 4, !DIAssignID !1508
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1505, metadata !DIExpression(), metadata !1508, metadata ptr %size, metadata !DIExpression()), !dbg !1509
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1492, metadata !DIExpression()), !dbg !1507
  call void @llvm.lifetime.start.p0(i64 384, ptr nonnull %tokens) #13, !dbg !1510
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1501, metadata !DIExpression()), !dbg !1507
  %sasl_started = getelementptr inbounds i8, ptr %c, i64 12, !dbg !1511
  %0 = load i8, ptr %sasl_started, align 4, !dbg !1511, !tbaa !1512, !range !1296, !noundef !1297
  %tobool = trunc nuw i8 %0 to i1, !dbg !1511
  br i1 %tobool, label %entry.if.end43_crit_edge, label %if.then, !dbg !1513

entry.if.end43_crit_edge:                         ; preds = %entry
  %rlbytes45.phi.trans.insert = getelementptr inbounds i8, ptr %c, i64 216
  %.pre = load i32, ptr %rlbytes45.phi.trans.insert, align 8, !dbg !1514, !tbaa !1516
  br label %if.end43, !dbg !1513

if.then:                                          ; preds = %entry
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %size) #13, !dbg !1517
  store i32 0, ptr %size, align 4, !dbg !1518, !tbaa !1231, !DIAssignID !1519
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !1505, metadata !DIExpression(), metadata !1519, metadata ptr %size, metadata !DIExpression()), !dbg !1509
  %rbytes = getelementptr inbounds i8, ptr %c, i64 188, !dbg !1520
  %1 = load i32, ptr %rbytes, align 4, !dbg !1520, !tbaa !1522
  %cmp = icmp slt i32 %1, 2, !dbg !1523
  br i1 %cmp, label %cleanup.thread, label %if.end, !dbg !1524

if.end:                                           ; preds = %if.then
  %rcurr = getelementptr inbounds i8, ptr %c, i64 176, !dbg !1525
  %2 = load ptr, ptr %rcurr, align 8, !dbg !1525, !tbaa !1526
  %conv = zext nneg i32 %1 to i64
  %call = tail call ptr @memchr(ptr noundef %2, i32 noundef 10, i64 noundef %conv) #15, !dbg !1527
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !1502, metadata !DIExpression()), !dbg !1509
  %tobool3.not = icmp eq ptr %call, null, !dbg !1528
  br i1 %tobool3.not, label %if.then4, label %if.end10, !dbg !1530

if.then4:                                         ; preds = %if.end
  %cmp6 = icmp ugt i32 %1, 2048, !dbg !1531
  br i1 %cmp6, label %if.then8, label %cleanup.thread, !dbg !1534

if.then8:                                         ; preds = %if.then4
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 8) #13, !dbg !1535
  br label %cleanup.thread, !dbg !1537

if.end10:                                         ; preds = %if.end
  store i8 0, ptr %call, align 1, !dbg !1538, !tbaa !1240
  %3 = load ptr, ptr %rcurr, align 8, !dbg !1539, !tbaa !1526
  tail call void @llvm.dbg.value(metadata ptr %3, metadata !1540, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !1547, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata i64 24, metadata !1548, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1551, metadata !DIExpression()), !dbg !1554
  %call.i = tail call i64 @strlen(ptr noundef nonnull dereferenceable(1) %3) #15, !dbg !1556
  tail call void @llvm.dbg.value(metadata i64 %call.i, metadata !1552, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata ptr %3, metadata !1550, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata ptr %3, metadata !1549, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1553, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1551, metadata !DIExpression()), !dbg !1554
  %cmp77.not.i = icmp eq i64 %call.i, 0, !dbg !1557
  br i1 %cmp77.not.i, label %tokenize_command.exit, label %for.body.i, !dbg !1560

for.body.i:                                       ; preds = %if.end10, %if.end13.i
  %i.082.i = phi i32 [ %inc15.i, %if.end13.i ], [ 0, %if.end10 ]
  %s.081.i = phi ptr [ %s.1.i, %if.end13.i ], [ %3, %if.end10 ]
  %ntokens.080.i = phi i64 [ %ntokens.2.i, %if.end13.i ], [ 0, %if.end10 ]
  %e.078.i = phi ptr [ %incdec.ptr14.i, %if.end13.i ], [ %3, %if.end10 ]
  tail call void @llvm.dbg.value(metadata i32 %i.082.i, metadata !1553, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata ptr %s.081.i, metadata !1549, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata i64 %ntokens.080.i, metadata !1551, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata ptr %e.078.i, metadata !1550, metadata !DIExpression()), !dbg !1554
  %4 = load i8, ptr %e.078.i, align 1, !dbg !1561, !tbaa !1240
  %cmp3.i = icmp eq i8 %4, 32, !dbg !1564
  br i1 %cmp3.i, label %if.then.i, label %if.end13.i, !dbg !1565

if.then.i:                                        ; preds = %for.body.i
  %cmp5.not.i = icmp eq ptr %s.081.i, %e.078.i, !dbg !1566
  br i1 %cmp5.not.i, label %if.end12.i, label %if.then7.i, !dbg !1569

if.then7.i:                                       ; preds = %if.then.i
  %arrayidx.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %ntokens.080.i, !dbg !1570
  store ptr %s.081.i, ptr %arrayidx.i, align 16, !dbg !1572, !tbaa !1573
  %sub.ptr.lhs.cast.i = ptrtoint ptr %e.078.i to i64, !dbg !1575
  %sub.ptr.rhs.cast.i = ptrtoint ptr %s.081.i to i64, !dbg !1575
  %sub.ptr.sub.i = sub i64 %sub.ptr.lhs.cast.i, %sub.ptr.rhs.cast.i, !dbg !1575
  %length.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 8, !dbg !1576
  store i64 %sub.ptr.sub.i, ptr %length.i, align 8, !dbg !1577, !tbaa !1578
  %inc.i = add i64 %ntokens.080.i, 1, !dbg !1579
  tail call void @llvm.dbg.value(metadata i64 %inc.i, metadata !1551, metadata !DIExpression()), !dbg !1554
  store i8 0, ptr %e.078.i, align 1, !dbg !1580, !tbaa !1240
  %cmp9.i = icmp eq i64 %inc.i, 23, !dbg !1581
  br i1 %cmp9.i, label %for.end.thread.i, label %if.end12.i, !dbg !1583

for.end.thread.i:                                 ; preds = %if.then7.i
  %incdec.ptr.i = getelementptr inbounds i8, ptr %e.078.i, i64 1, !dbg !1584
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i, metadata !1549, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata i64 23, metadata !1551, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i, metadata !1550, metadata !DIExpression()), !dbg !1554
  br label %tokenize_command.exit, !dbg !1586

if.end12.i:                                       ; preds = %if.then7.i, %if.then.i
  %ntokens.1.i = phi i64 [ %inc.i, %if.then7.i ], [ %ntokens.080.i, %if.then.i ], !dbg !1554
  tail call void @llvm.dbg.value(metadata i64 %ntokens.1.i, metadata !1551, metadata !DIExpression()), !dbg !1554
  %add.ptr.i = getelementptr inbounds i8, ptr %e.078.i, i64 1, !dbg !1587
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !1549, metadata !DIExpression()), !dbg !1554
  br label %if.end13.i, !dbg !1588

if.end13.i:                                       ; preds = %if.end12.i, %for.body.i
  %ntokens.2.i = phi i64 [ %ntokens.1.i, %if.end12.i ], [ %ntokens.080.i, %for.body.i ], !dbg !1554
  %s.1.i = phi ptr [ %add.ptr.i, %if.end12.i ], [ %s.081.i, %for.body.i ], !dbg !1554
  tail call void @llvm.dbg.value(metadata ptr %s.1.i, metadata !1549, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata i64 %ntokens.2.i, metadata !1551, metadata !DIExpression()), !dbg !1554
  %incdec.ptr14.i = getelementptr inbounds i8, ptr %e.078.i, i64 1, !dbg !1589
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr14.i, metadata !1550, metadata !DIExpression()), !dbg !1554
  %inc15.i = add i32 %i.082.i, 1, !dbg !1590
  tail call void @llvm.dbg.value(metadata i32 %inc15.i, metadata !1553, metadata !DIExpression()), !dbg !1554
  %conv.i = zext i32 %inc15.i to i64, !dbg !1591
  %cmp.i = icmp ugt i64 %call.i, %conv.i, !dbg !1557
  br i1 %cmp.i, label %for.body.i, label %for.end.i, !dbg !1560, !llvm.loop !1592

for.end.i:                                        ; preds = %if.end13.i
  tail call void @llvm.dbg.value(metadata ptr %s.1.i, metadata !1549, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata i64 %ntokens.2.i, metadata !1551, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr14.i, metadata !1550, metadata !DIExpression()), !dbg !1554
  %cmp16.not.i = icmp eq ptr %s.1.i, %incdec.ptr14.i, !dbg !1594
  br i1 %cmp16.not.i, label %tokenize_command.exit, label %if.then18.i, !dbg !1586

if.then18.i:                                      ; preds = %for.end.i
  %arrayidx19.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %ntokens.2.i, !dbg !1596
  store ptr %s.1.i, ptr %arrayidx19.i, align 16, !dbg !1598, !tbaa !1573
  %inc26.i = add i64 %ntokens.2.i, 1, !dbg !1599
  tail call void @llvm.dbg.value(metadata i64 %inc26.i, metadata !1551, metadata !DIExpression()), !dbg !1554
  br label %tokenize_command.exit, !dbg !1600

tokenize_command.exit:                            ; preds = %if.end10, %for.end.thread.i, %for.end.i, %if.then18.i
  %e.173.i = phi ptr [ %incdec.ptr14.i, %if.then18.i ], [ %incdec.ptr14.i, %for.end.i ], [ %incdec.ptr.i, %for.end.thread.i ], [ %3, %if.end10 ]
  %ntokens.4.i = phi i64 [ %inc26.i, %if.then18.i ], [ %ntokens.2.i, %for.end.i ], [ 23, %for.end.thread.i ], [ 0, %if.end10 ], !dbg !1554
  tail call void @llvm.dbg.value(metadata i64 %ntokens.4.i, metadata !1551, metadata !DIExpression()), !dbg !1554
  %5 = load i8, ptr %e.173.i, align 1, !dbg !1601, !tbaa !1240
  %cmp29.i = icmp eq i8 %5, 0, !dbg !1602
  %spec.select.i = select i1 %cmp29.i, ptr null, ptr %e.173.i, !dbg !1601
  %arrayidx31.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %ntokens.4.i, !dbg !1603
  store ptr %spec.select.i, ptr %arrayidx31.i, align 16, !dbg !1604, !tbaa !1573
  %inc35.i = add i64 %ntokens.4.i, 1, !dbg !1605
  tail call void @llvm.dbg.value(metadata i64 %inc35.i, metadata !1551, metadata !DIExpression()), !dbg !1554
  tail call void @llvm.dbg.value(metadata i64 %inc35.i, metadata !1500, metadata !DIExpression()), !dbg !1507
  %6 = load ptr, ptr %rcurr, align 8, !dbg !1606, !tbaa !1526
  %sub.ptr.lhs.cast = ptrtoint ptr %call to i64, !dbg !1607
  %sub.ptr.rhs.cast = ptrtoint ptr %6 to i64, !dbg !1607
  %7 = xor i64 %sub.ptr.lhs.cast, -1, !dbg !1608
  %add.neg = add i64 %sub.ptr.rhs.cast, %7, !dbg !1608
  %8 = load i32, ptr %rbytes, align 4, !dbg !1609, !tbaa !1522
  %9 = trunc i64 %add.neg to i32, !dbg !1609
  %conv16 = add i32 %8, %9, !dbg !1609
  store i32 %conv16, ptr %rbytes, align 4, !dbg !1609, !tbaa !1522
  %sub.ptr.sub20 = sub i64 %sub.ptr.lhs.cast, %sub.ptr.rhs.cast, !dbg !1610
  %10 = getelementptr i8, ptr %6, i64 %sub.ptr.sub20, !dbg !1611
  %add.ptr = getelementptr i8, ptr %10, i64 1, !dbg !1611
  store ptr %add.ptr, ptr %rcurr, align 8, !dbg !1611, !tbaa !1526
  %cmp23 = icmp ult i64 %inc35.i, 6, !dbg !1612
  br i1 %cmp23, label %if.then32, label %lor.lhs.false, !dbg !1614

lor.lhs.false:                                    ; preds = %tokenize_command.exit
  %11 = load ptr, ptr %tokens, align 16, !dbg !1615, !tbaa !1573
  %call25 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %11, ptr noundef nonnull dereferenceable(4) @.str.7) #15, !dbg !1616
  %cmp26.not = icmp eq i32 %call25, 0, !dbg !1617
  br i1 %cmp26.not, label %lor.lhs.false28, label %if.then32, !dbg !1618

lor.lhs.false28:                                  ; preds = %lor.lhs.false
  %arrayidx29 = getelementptr inbounds i8, ptr %tokens, i64 64, !dbg !1619
  %12 = load ptr, ptr %arrayidx29, align 16, !dbg !1620, !tbaa !1573
  %call31 = call zeroext i1 @safe_strtoul(ptr noundef %12, ptr noundef nonnull %size) #13, !dbg !1621
  br i1 %call31, label %cleanup, label %if.then32, !dbg !1622

if.then32:                                        ; preds = %lor.lhs.false28, %lor.lhs.false, %tokenize_command.exit
  %resp = getelementptr inbounds i8, ptr %c, i64 192, !dbg !1623
  %13 = load ptr, ptr %resp, align 8, !dbg !1623, !tbaa !1351
  %tobool33.not = icmp eq ptr %13, null, !dbg !1626
  br i1 %tobool33.not, label %if.then34, label %if.end38, !dbg !1627

if.then34:                                        ; preds = %if.then32
  %call35 = call zeroext i1 @resp_start(ptr noundef nonnull %c) #13, !dbg !1628
  br i1 %call35, label %if.end38, label %if.then36, !dbg !1631

if.then36:                                        ; preds = %if.then34
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 8) #13, !dbg !1632
  br label %cleanup.thread, !dbg !1634

if.end38:                                         ; preds = %if.then34, %if.then32
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.8) #13, !dbg !1635
  br label %cleanup.thread, !dbg !1636

cleanup.thread:                                   ; preds = %if.end38, %if.then36, %if.then8, %if.then, %if.then4
  %retval.0.ph = phi i32 [ 0, %if.then4 ], [ 0, %if.then ], [ 1, %if.then8 ], [ 1, %if.then36 ], [ 1, %if.end38 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %size) #13, !dbg !1637
  br label %cleanup114

cleanup:                                          ; preds = %lor.lhs.false28
  %14 = load i32, ptr %size, align 4, !dbg !1638, !tbaa !1231
  %add40 = add i32 %14, 2, !dbg !1639
  %rlbytes = getelementptr inbounds i8, ptr %c, i64 216, !dbg !1640
  store i32 %add40, ptr %rlbytes, align 8, !dbg !1641, !tbaa !1516
  store i8 1, ptr %sasl_started, align 4, !dbg !1642, !tbaa !1512
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %size) #13, !dbg !1637
  br label %if.end43

if.end43:                                         ; preds = %entry.if.end43_crit_edge, %cleanup
  %15 = phi i32 [ %.pre, %entry.if.end43_crit_edge ], [ %add40, %cleanup ], !dbg !1514
  %rbytes44 = getelementptr inbounds i8, ptr %c, i64 188, !dbg !1643
  %16 = load i32, ptr %rbytes44, align 4, !dbg !1643, !tbaa !1522
  %rlbytes45 = getelementptr inbounds i8, ptr %c, i64 216, !dbg !1514
  %cmp46 = icmp slt i32 %16, %15, !dbg !1644
  br i1 %cmp46, label %cleanup114, label %if.end49, !dbg !1645

if.end49:                                         ; preds = %if.end43
  %resp50 = getelementptr inbounds i8, ptr %c, i64 192, !dbg !1646
  %17 = load ptr, ptr %resp50, align 8, !dbg !1646, !tbaa !1351
  %tobool51.not = icmp eq ptr %17, null, !dbg !1648
  br i1 %tobool51.not, label %if.then52, label %if.end56, !dbg !1649

if.then52:                                        ; preds = %if.end49
  %call53 = call zeroext i1 @resp_start(ptr noundef nonnull %c) #13, !dbg !1650
  br i1 %call53, label %if.then52.if.end56_crit_edge, label %if.then54, !dbg !1653

if.then52.if.end56_crit_edge:                     ; preds = %if.then52
  %.pre218 = load i32, ptr %rlbytes45, align 8, !dbg !1654, !tbaa !1516
  %.pre219 = load i32, ptr %rbytes44, align 4, !dbg !1655, !tbaa !1522
  br label %if.end56, !dbg !1653

if.then54:                                        ; preds = %if.then52
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 8) #13, !dbg !1656
  br label %cleanup114, !dbg !1658

if.end56:                                         ; preds = %if.then52.if.end56_crit_edge, %if.end49
  %18 = phi i32 [ %.pre219, %if.then52.if.end56_crit_edge ], [ %16, %if.end49 ], !dbg !1655
  %19 = phi i32 [ %.pre218, %if.then52.if.end56_crit_edge ], [ %15, %if.end49 ], !dbg !1654
  %rcurr57 = getelementptr inbounds i8, ptr %c, i64 176, !dbg !1659
  %20 = load ptr, ptr %rcurr57, align 8, !dbg !1659, !tbaa !1526
  tail call void @llvm.dbg.value(metadata ptr %20, metadata !1501, metadata !DIExpression()), !dbg !1507
  %sub60 = sub nsw i32 %18, %19, !dbg !1655
  store i32 %sub60, ptr %rbytes44, align 4, !dbg !1655, !tbaa !1522
  %idx.ext = sext i32 %19 to i64, !dbg !1660
  %add.ptr63 = getelementptr inbounds i8, ptr %20, i64 %idx.ext, !dbg !1660
  store ptr %add.ptr63, ptr %rcurr57, align 8, !dbg !1660, !tbaa !1526
  store i8 0, ptr %sasl_started, align 4, !dbg !1661, !tbaa !1512
  %add.ptr68 = getelementptr inbounds i8, ptr %add.ptr63, i64 -2, !dbg !1662
  %21 = load i8, ptr %add.ptr68, align 1
  %.not = icmp eq i8 %21, 13
  br i1 %.not, label %if.end56.tail, label %if.then72

if.end56.tail:                                    ; preds = %if.end56
  %22 = getelementptr inbounds i8, ptr %add.ptr63, i64 -1
  %23 = load i8, ptr %22, align 1
  %24 = icmp eq i8 %23, 10, !dbg !1664
  br i1 %24, label %if.end73, label %if.then72, !dbg !1665

if.then72:                                        ; preds = %if.end56, %if.end56.tail
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.9) #13, !dbg !1666
  br label %cleanup114, !dbg !1668

if.end73:                                         ; preds = %if.end56.tail
  store i8 0, ptr %add.ptr68, align 1, !dbg !1669, !tbaa !1240
  tail call void @llvm.dbg.value(metadata ptr %20, metadata !1540, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !1547, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata i64 24, metadata !1548, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1551, metadata !DIExpression()), !dbg !1670
  %call.i165 = call i64 @strlen(ptr noundef nonnull dereferenceable(1) %20) #15, !dbg !1672
  tail call void @llvm.dbg.value(metadata i64 %call.i165, metadata !1552, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata ptr %20, metadata !1550, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata ptr %20, metadata !1549, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1553, metadata !DIExpression()), !dbg !1670
  %cmp77.not.i166 = icmp eq i64 %call.i165, 0, !dbg !1673
  br i1 %cmp77.not.i166, label %tokenize_command.exit211, label %for.body.i167, !dbg !1674

for.body.i167:                                    ; preds = %if.end73, %if.end13.i173
  %i.082.i168 = phi i32 [ %inc15.i177, %if.end13.i173 ], [ 0, %if.end73 ]
  %s.081.i169 = phi ptr [ %s.1.i175, %if.end13.i173 ], [ %20, %if.end73 ]
  %ntokens.080.i170 = phi i64 [ %ntokens.2.i174, %if.end13.i173 ], [ 0, %if.end73 ]
  %e.078.i171 = phi ptr [ %incdec.ptr14.i176, %if.end13.i173 ], [ %20, %if.end73 ]
  tail call void @llvm.dbg.value(metadata i32 %i.082.i168, metadata !1553, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata ptr %s.081.i169, metadata !1549, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata i64 %ntokens.080.i170, metadata !1551, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata ptr %e.078.i171, metadata !1550, metadata !DIExpression()), !dbg !1670
  %25 = load i8, ptr %e.078.i171, align 1, !dbg !1675, !tbaa !1240
  %cmp3.i172 = icmp eq i8 %25, 32, !dbg !1676
  br i1 %cmp3.i172, label %if.then.i196, label %if.end13.i173, !dbg !1677

if.then.i196:                                     ; preds = %for.body.i167
  %cmp5.not.i197 = icmp eq ptr %s.081.i169, %e.078.i171, !dbg !1678
  br i1 %cmp5.not.i197, label %if.end12.i206, label %if.then7.i198, !dbg !1679

if.then7.i198:                                    ; preds = %if.then.i196
  %arrayidx.i199 = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %ntokens.080.i170, !dbg !1680
  store ptr %s.081.i169, ptr %arrayidx.i199, align 16, !dbg !1681, !tbaa !1573
  %sub.ptr.lhs.cast.i200 = ptrtoint ptr %e.078.i171 to i64, !dbg !1682
  %sub.ptr.rhs.cast.i201 = ptrtoint ptr %s.081.i169 to i64, !dbg !1682
  %sub.ptr.sub.i202 = sub i64 %sub.ptr.lhs.cast.i200, %sub.ptr.rhs.cast.i201, !dbg !1682
  %length.i203 = getelementptr inbounds i8, ptr %arrayidx.i199, i64 8, !dbg !1683
  store i64 %sub.ptr.sub.i202, ptr %length.i203, align 8, !dbg !1684, !tbaa !1578
  %inc.i204 = add i64 %ntokens.080.i170, 1, !dbg !1685
  tail call void @llvm.dbg.value(metadata i64 %inc.i204, metadata !1551, metadata !DIExpression()), !dbg !1670
  store i8 0, ptr %e.078.i171, align 1, !dbg !1686, !tbaa !1240
  %cmp9.i205 = icmp eq i64 %inc.i204, 23, !dbg !1687
  br i1 %cmp9.i205, label %for.end.thread.i209, label %if.end12.i206, !dbg !1688

for.end.thread.i209:                              ; preds = %if.then7.i198
  %incdec.ptr.i210 = getelementptr inbounds i8, ptr %e.078.i171, i64 1, !dbg !1689
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i210, metadata !1549, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata i64 23, metadata !1551, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i210, metadata !1550, metadata !DIExpression()), !dbg !1670
  br label %tokenize_command.exit211, !dbg !1690

if.end12.i206:                                    ; preds = %if.then7.i198, %if.then.i196
  %ntokens.1.i207 = phi i64 [ %inc.i204, %if.then7.i198 ], [ %ntokens.080.i170, %if.then.i196 ], !dbg !1670
  tail call void @llvm.dbg.value(metadata i64 %ntokens.1.i207, metadata !1551, metadata !DIExpression()), !dbg !1670
  %add.ptr.i208 = getelementptr inbounds i8, ptr %e.078.i171, i64 1, !dbg !1691
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i208, metadata !1549, metadata !DIExpression()), !dbg !1670
  br label %if.end13.i173, !dbg !1692

if.end13.i173:                                    ; preds = %if.end12.i206, %for.body.i167
  %ntokens.2.i174 = phi i64 [ %ntokens.1.i207, %if.end12.i206 ], [ %ntokens.080.i170, %for.body.i167 ], !dbg !1670
  %s.1.i175 = phi ptr [ %add.ptr.i208, %if.end12.i206 ], [ %s.081.i169, %for.body.i167 ], !dbg !1670
  tail call void @llvm.dbg.value(metadata ptr %s.1.i175, metadata !1549, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata i64 %ntokens.2.i174, metadata !1551, metadata !DIExpression()), !dbg !1670
  %incdec.ptr14.i176 = getelementptr inbounds i8, ptr %e.078.i171, i64 1, !dbg !1693
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr14.i176, metadata !1550, metadata !DIExpression()), !dbg !1670
  %inc15.i177 = add i32 %i.082.i168, 1, !dbg !1694
  tail call void @llvm.dbg.value(metadata i32 %inc15.i177, metadata !1553, metadata !DIExpression()), !dbg !1670
  %conv.i178 = zext i32 %inc15.i177 to i64, !dbg !1695
  %cmp.i179 = icmp ugt i64 %call.i165, %conv.i178, !dbg !1673
  br i1 %cmp.i179, label %for.body.i167, label %for.end.i180, !dbg !1674, !llvm.loop !1696

for.end.i180:                                     ; preds = %if.end13.i173
  tail call void @llvm.dbg.value(metadata ptr %s.1.i175, metadata !1549, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata i64 %ntokens.2.i174, metadata !1551, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr14.i176, metadata !1550, metadata !DIExpression()), !dbg !1670
  %cmp16.not.i181 = icmp eq ptr %s.1.i175, %incdec.ptr14.i176, !dbg !1698
  br i1 %cmp16.not.i181, label %tokenize_command.exit211, label %if.then18.i182, !dbg !1690

if.then18.i182:                                   ; preds = %for.end.i180
  %arrayidx19.i183 = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %ntokens.2.i174, !dbg !1699
  store ptr %s.1.i175, ptr %arrayidx19.i183, align 16, !dbg !1700, !tbaa !1573
  %inc26.i188 = add i64 %ntokens.2.i174, 1, !dbg !1701
  tail call void @llvm.dbg.value(metadata i64 %inc26.i188, metadata !1551, metadata !DIExpression()), !dbg !1670
  br label %tokenize_command.exit211, !dbg !1702

tokenize_command.exit211:                         ; preds = %if.end73, %for.end.thread.i209, %for.end.i180, %if.then18.i182
  %e.173.i189 = phi ptr [ %incdec.ptr14.i176, %if.then18.i182 ], [ %incdec.ptr14.i176, %for.end.i180 ], [ %incdec.ptr.i210, %for.end.thread.i209 ], [ %20, %if.end73 ]
  %ntokens.4.i190 = phi i64 [ %inc26.i188, %if.then18.i182 ], [ %ntokens.2.i174, %for.end.i180 ], [ 23, %for.end.thread.i209 ], [ 0, %if.end73 ], !dbg !1670
  tail call void @llvm.dbg.value(metadata i64 %ntokens.4.i190, metadata !1551, metadata !DIExpression()), !dbg !1670
  %26 = load i8, ptr %e.173.i189, align 1, !dbg !1703, !tbaa !1240
  %cmp29.i191 = icmp eq i8 %26, 0, !dbg !1704
  %spec.select.i192 = select i1 %cmp29.i191, ptr null, ptr %e.173.i189, !dbg !1703
  %arrayidx31.i193 = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %ntokens.4.i190, !dbg !1705
  store ptr %spec.select.i192, ptr %arrayidx31.i193, align 16, !dbg !1706, !tbaa !1573
  %inc35.i195 = add i64 %ntokens.4.i190, 1, !dbg !1707
  tail call void @llvm.dbg.value(metadata i64 %inc35.i195, metadata !1551, metadata !DIExpression()), !dbg !1670
  tail call void @llvm.dbg.value(metadata i64 %inc35.i195, metadata !1500, metadata !DIExpression()), !dbg !1507
  %cmp79 = icmp ult i64 %inc35.i195, 3, !dbg !1708
  br i1 %cmp79, label %if.then81, label %if.end82, !dbg !1710

if.then81:                                        ; preds = %tokenize_command.exit211
  call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.10) #13, !dbg !1711
  br label %cleanup114, !dbg !1713

if.end82:                                         ; preds = %tokenize_command.exit211
  %27 = load ptr, ptr %tokens, align 16, !dbg !1714, !tbaa !1573
  %arrayidx85 = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !1716
  %28 = load ptr, ptr %arrayidx85, align 16, !dbg !1717, !tbaa !1573
  %call87 = call i32 @authfile_check(ptr noundef %27, ptr noundef %28) #13, !dbg !1718
  %cmp88 = icmp eq i32 %call87, 1, !dbg !1719
  br i1 %cmp88, label %if.then90, label %if.else, !dbg !1720

if.then90:                                        ; preds = %if.end82
  call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.2) #13, !dbg !1721
  %authenticated = getelementptr inbounds i8, ptr %c, i64 13, !dbg !1723
  store i8 1, ptr %authenticated, align 1, !dbg !1724, !tbaa !1725
  %try_read_command = getelementptr inbounds i8, ptr %c, i64 464, !dbg !1726
  store ptr @try_read_command_ascii, ptr %try_read_command, align 8, !dbg !1727, !tbaa !1728
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !1729
  %29 = load ptr, ptr %thread, align 8, !dbg !1729, !tbaa !1234
  %stats = getelementptr inbounds i8, ptr %29, i64 352, !dbg !1730
  %call91 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #13, !dbg !1731
  %30 = load ptr, ptr %thread, align 8, !dbg !1732, !tbaa !1234
  %auth_cmds = getelementptr inbounds i8, ptr %30, i64 512, !dbg !1733
  %31 = load i64, ptr %auth_cmds, align 8, !dbg !1734, !tbaa !1735
  %inc = add i64 %31, 1, !dbg !1734
  store i64 %inc, ptr %auth_cmds, align 8, !dbg !1734, !tbaa !1735
  %stats95 = getelementptr inbounds i8, ptr %30, i64 352, !dbg !1736
  %call97 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats95) #13, !dbg !1737
  br label %cleanup114, !dbg !1738

if.else:                                          ; preds = %if.end82
  call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.11) #13, !dbg !1739
  %thread98 = getelementptr inbounds i8, ptr %c, i64 456, !dbg !1741
  %32 = load ptr, ptr %thread98, align 8, !dbg !1741, !tbaa !1234
  %stats99 = getelementptr inbounds i8, ptr %32, i64 352, !dbg !1742
  %call101 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats99) #13, !dbg !1743
  %33 = load ptr, ptr %thread98, align 8, !dbg !1744, !tbaa !1234
  %auth_cmds104 = getelementptr inbounds i8, ptr %33, i64 512, !dbg !1745
  %34 = load <2 x i64>, ptr %auth_cmds104, align 8, !dbg !1746, !tbaa !1308
  %35 = add <2 x i64> %34, <i64 1, i64 1>, !dbg !1746
  store <2 x i64> %35, ptr %auth_cmds104, align 8, !dbg !1746, !tbaa !1308
  %stats110 = getelementptr inbounds i8, ptr %33, i64 352, !dbg !1747
  %call112 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats110) #13, !dbg !1748
  br label %cleanup114

cleanup114:                                       ; preds = %cleanup.thread, %if.then90, %if.else, %if.end43, %if.then81, %if.then72, %if.then54
  %retval.1 = phi i32 [ 1, %if.then72 ], [ 1, %if.then81 ], [ 1, %if.then54 ], [ 0, %if.end43 ], [ 1, %if.else ], [ 1, %if.then90 ], [ %retval.0.ph, %cleanup.thread ], !dbg !1507
  call void @llvm.lifetime.end.p0(i64 384, ptr nonnull %tokens) #13, !dbg !1749
  ret i32 %retval.1, !dbg !1749
}

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare !dbg !1750 ptr @memchr(ptr noundef, i32 noundef, i64 noundef) local_unnamed_addr #3

declare !dbg !1753 void @conn_set_state(ptr noundef, i32 noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare !dbg !1756 i32 @strcmp(ptr nocapture noundef, ptr nocapture noundef) local_unnamed_addr #3

declare !dbg !1759 zeroext i1 @safe_strtoul(ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !1763 zeroext i1 @resp_start(ptr noundef) local_unnamed_addr #4

declare !dbg !1766 i32 @authfile_check(ptr noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 0, 2) i32 @try_read_command_ascii(ptr noundef %c) #0 !dbg !1768 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1770, metadata !DIExpression()), !dbg !1778
  %rbytes = getelementptr inbounds i8, ptr %c, i64 188, !dbg !1779
  %0 = load i32, ptr %rbytes, align 4, !dbg !1779, !tbaa !1522
  %cmp = icmp eq i32 %0, 0, !dbg !1781
  br i1 %cmp, label %cleanup51, label %if.end, !dbg !1782

if.end:                                           ; preds = %entry
  %rcurr = getelementptr inbounds i8, ptr %c, i64 176, !dbg !1783
  %1 = load ptr, ptr %rcurr, align 8, !dbg !1783, !tbaa !1526
  %conv = sext i32 %0 to i64, !dbg !1784
  %call = tail call ptr @memchr(ptr noundef %1, i32 noundef 10, i64 noundef %conv) #15, !dbg !1785
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !1771, metadata !DIExpression()), !dbg !1778
  %tobool.not = icmp eq ptr %call, null, !dbg !1786
  br i1 %tobool.not, label %if.then2, label %if.end27, !dbg !1787

if.then2:                                         ; preds = %if.end
  %cmp4 = icmp sgt i32 %0, 2048, !dbg !1788
  br i1 %cmp4, label %while.cond, label %cleanup51, !dbg !1789

while.cond:                                       ; preds = %if.then2, %while.cond
  %ptr.0 = phi ptr [ %incdec.ptr, %while.cond ], [ %1, %if.then2 ], !dbg !1790
  tail call void @llvm.dbg.value(metadata ptr %ptr.0, metadata !1773, metadata !DIExpression()), !dbg !1790
  %2 = load i8, ptr %ptr.0, align 1, !dbg !1791, !tbaa !1240
  %cmp9 = icmp eq i8 %2, 32, !dbg !1792
  %incdec.ptr = getelementptr inbounds i8, ptr %ptr.0, i64 1, !dbg !1793
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !1773, metadata !DIExpression()), !dbg !1790
  br i1 %cmp9, label %while.cond, label %while.end, !dbg !1795, !llvm.loop !1796

while.end:                                        ; preds = %while.cond
  %sub.ptr.lhs.cast = ptrtoint ptr %ptr.0 to i64, !dbg !1798
  %sub.ptr.rhs.cast = ptrtoint ptr %1 to i64, !dbg !1798
  %sub.ptr.sub = sub i64 %sub.ptr.lhs.cast, %sub.ptr.rhs.cast, !dbg !1798
  %cmp12 = icmp sgt i64 %sub.ptr.sub, 100, !dbg !1800
  br i1 %cmp12, label %if.then18, label %lor.lhs.false, !dbg !1801

lor.lhs.false:                                    ; preds = %while.end
  %call14 = tail call i32 @strncmp(ptr noundef nonnull dereferenceable(1) %ptr.0, ptr noundef nonnull dereferenceable(5) @.str.12, i64 noundef 4) #16, !dbg !1802
  %tobool15.not = icmp eq i32 %call14, 0, !dbg !1802
  br i1 %tobool15.not, label %if.end19, label %land.lhs.true, !dbg !1803

land.lhs.true:                                    ; preds = %lor.lhs.false
  %call16 = tail call i32 @strncmp(ptr noundef nonnull dereferenceable(1) %ptr.0, ptr noundef nonnull dereferenceable(6) @.str.13, i64 noundef 5) #16, !dbg !1804
  %tobool17.not = icmp eq i32 %call16, 0, !dbg !1804
  br i1 %tobool17.not, label %if.end19, label %if.then18, !dbg !1805

if.then18:                                        ; preds = %land.lhs.true, %while.end
  tail call void @conn_set_state(ptr noundef %c, i32 noundef 8) #13, !dbg !1806
  br label %cleanup51, !dbg !1808

if.end19:                                         ; preds = %land.lhs.true, %lor.lhs.false
  %rbuf_malloced = getelementptr inbounds i8, ptr %c, i64 17, !dbg !1809
  %3 = load i8, ptr %rbuf_malloced, align 1, !dbg !1809, !tbaa !1811, !range !1296, !noundef !1297
  %tobool20 = trunc nuw i8 %3 to i1, !dbg !1809
  br i1 %tobool20, label %cleanup51, label %if.then21, !dbg !1812

if.then21:                                        ; preds = %if.end19
  %call22 = tail call zeroext i1 @rbuf_switch_to_malloc(ptr noundef nonnull %c) #13, !dbg !1813
  br i1 %call22, label %cleanup51, label %if.then23, !dbg !1816

if.then23:                                        ; preds = %if.then21
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 8) #13, !dbg !1817
  br label %cleanup51, !dbg !1819

if.end27:                                         ; preds = %if.end
  %add.ptr = getelementptr inbounds i8, ptr %call, i64 1, !dbg !1820
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !1772, metadata !DIExpression()), !dbg !1778
  %sub.ptr.lhs.cast29 = ptrtoint ptr %call to i64, !dbg !1821
  %sub.ptr.rhs.cast30 = ptrtoint ptr %1 to i64, !dbg !1821
  %sub.ptr.sub31 = sub i64 %sub.ptr.lhs.cast29, %sub.ptr.rhs.cast30, !dbg !1821
  %cmp32 = icmp sgt i64 %sub.ptr.sub31, 1, !dbg !1823
  br i1 %cmp32, label %land.lhs.true34, label %if.end41, !dbg !1824

land.lhs.true34:                                  ; preds = %if.end27
  %add.ptr35 = getelementptr inbounds i8, ptr %call, i64 -1, !dbg !1825
  %4 = load i8, ptr %add.ptr35, align 1, !dbg !1826, !tbaa !1240
  %cmp37 = icmp eq i8 %4, 13, !dbg !1827
  %spec.select = select i1 %cmp37, ptr %add.ptr35, ptr %call, !dbg !1828
  br label %if.end41, !dbg !1828

if.end41:                                         ; preds = %land.lhs.true34, %if.end27
  %el.0 = phi ptr [ %call, %if.end27 ], [ %spec.select, %land.lhs.true34 ], !dbg !1778
  tail call void @llvm.dbg.value(metadata ptr %el.0, metadata !1771, metadata !DIExpression()), !dbg !1778
  store i8 0, ptr %el.0, align 1, !dbg !1829, !tbaa !1240
  %5 = load volatile i32, ptr @current_time, align 4, !dbg !1830, !tbaa !1231
  %last_cmd_time = getelementptr inbounds i8, ptr %c, i64 28, !dbg !1831
  store i32 %5, ptr %last_cmd_time, align 4, !dbg !1832, !tbaa !1833
  %6 = load ptr, ptr %rcurr, align 8, !dbg !1834, !tbaa !1526
  tail call void @process_command_ascii(ptr noundef nonnull %c, ptr noundef %6), !dbg !1835
  %7 = load ptr, ptr %rcurr, align 8, !dbg !1836, !tbaa !1526
  %sub.ptr.lhs.cast44 = ptrtoint ptr %add.ptr to i64, !dbg !1837
  %sub.ptr.rhs.cast45 = ptrtoint ptr %7 to i64, !dbg !1837
  %sub.ptr.sub46.neg = sub i64 %sub.ptr.rhs.cast45, %sub.ptr.lhs.cast44, !dbg !1837
  %8 = load i32, ptr %rbytes, align 4, !dbg !1838, !tbaa !1522
  %9 = trunc i64 %sub.ptr.sub46.neg to i32, !dbg !1838
  %conv49 = add i32 %8, %9, !dbg !1838
  store i32 %conv49, ptr %rbytes, align 4, !dbg !1838, !tbaa !1522
  store ptr %add.ptr, ptr %rcurr, align 8, !dbg !1839, !tbaa !1526
  br label %cleanup51, !dbg !1840

cleanup51:                                        ; preds = %if.then18, %if.then23, %if.then2, %if.end19, %if.then21, %entry, %if.end41
  %retval.1 = phi i32 [ 1, %if.end41 ], [ 0, %entry ], [ 0, %if.then21 ], [ 0, %if.end19 ], [ 0, %if.then2 ], [ 1, %if.then23 ], [ 1, %if.then18 ], !dbg !1778
  ret i32 %retval.1, !dbg !1841
}

declare !dbg !1842 zeroext i1 @rbuf_switch_to_malloc(ptr noundef) local_unnamed_addr #4

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @process_command_ascii(ptr noundef %c, ptr noundef %command) local_unnamed_addr #0 !dbg !1843 {
entry:
  %tokens = alloca [24 x %struct.token_s], align 16, !DIAssignID !1853
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1849, metadata !DIExpression(), metadata !1853, metadata ptr %tokens, metadata !DIExpression()), !dbg !1854
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1847, metadata !DIExpression()), !dbg !1854
  tail call void @llvm.dbg.value(metadata ptr %command, metadata !1848, metadata !DIExpression()), !dbg !1854
  call void @llvm.lifetime.start.p0(i64 384, ptr nonnull %tokens) #13, !dbg !1855
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1856, !tbaa !1858
  %cmp = icmp sgt i32 %0, 1, !dbg !1861
  br i1 %cmp, label %if.then, label %if.end, !dbg !1862

if.then:                                          ; preds = %entry
  %1 = load ptr, ptr @stderr, align 8, !dbg !1863, !tbaa !1271
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1864
  %2 = load i32, ptr %sfd, align 8, !dbg !1864, !tbaa !1311
  %call = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %1, ptr noundef nonnull @.str.14, i32 noundef %2, ptr noundef %command) #17, !dbg !1865
  br label %if.end, !dbg !1865

if.end:                                           ; preds = %if.then, %entry
  %call1 = tail call zeroext i1 @resp_start(ptr noundef %c) #13, !dbg !1866
  br i1 %call1, label %if.end3, label %if.then2, !dbg !1868

if.then2:                                         ; preds = %if.end
  tail call void @conn_set_state(ptr noundef %c, i32 noundef 8) #13, !dbg !1869
  br label %cleanup460, !dbg !1871

if.end3:                                          ; preds = %if.end
  %sfd4 = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1872
  %3 = load i32, ptr %sfd4, align 8, !dbg !1872, !tbaa !1311
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !1873
  %4 = load ptr, ptr %thread, align 8, !dbg !1873, !tbaa !1234
  %cur_sfd = getelementptr inbounds i8, ptr %4, i64 344, !dbg !1874
  store i32 %3, ptr %cur_sfd, align 8, !dbg !1875, !tbaa !1315
  tail call void @llvm.dbg.value(metadata ptr %command, metadata !1540, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !1547, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata i64 24, metadata !1548, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1551, metadata !DIExpression()), !dbg !1876
  %call.i = tail call i64 @strlen(ptr noundef nonnull dereferenceable(1) %command) #15, !dbg !1878
  tail call void @llvm.dbg.value(metadata i64 %call.i, metadata !1552, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata ptr %command, metadata !1550, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata ptr %command, metadata !1549, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1553, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1551, metadata !DIExpression()), !dbg !1876
  %cmp77.not.i = icmp eq i64 %call.i, 0, !dbg !1879
  br i1 %cmp77.not.i, label %tokenize_command.exit, label %for.body.i, !dbg !1880

for.body.i:                                       ; preds = %if.end3, %if.end13.i
  %i.082.i = phi i32 [ %inc15.i, %if.end13.i ], [ 0, %if.end3 ]
  %s.081.i = phi ptr [ %s.1.i, %if.end13.i ], [ %command, %if.end3 ]
  %ntokens.080.i = phi i64 [ %ntokens.2.i, %if.end13.i ], [ 0, %if.end3 ]
  %e.078.i = phi ptr [ %incdec.ptr14.i, %if.end13.i ], [ %command, %if.end3 ]
  tail call void @llvm.dbg.value(metadata i32 %i.082.i, metadata !1553, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata ptr %s.081.i, metadata !1549, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata i64 %ntokens.080.i, metadata !1551, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata ptr %e.078.i, metadata !1550, metadata !DIExpression()), !dbg !1876
  %5 = load i8, ptr %e.078.i, align 1, !dbg !1881, !tbaa !1240
  %cmp3.i = icmp eq i8 %5, 32, !dbg !1882
  br i1 %cmp3.i, label %if.then.i, label %if.end13.i, !dbg !1883

if.then.i:                                        ; preds = %for.body.i
  %cmp5.not.i = icmp eq ptr %s.081.i, %e.078.i, !dbg !1884
  br i1 %cmp5.not.i, label %if.end12.i, label %if.then7.i, !dbg !1885

if.then7.i:                                       ; preds = %if.then.i
  %arrayidx.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %ntokens.080.i, !dbg !1886
  store ptr %s.081.i, ptr %arrayidx.i, align 16, !dbg !1887, !tbaa !1573
  %sub.ptr.lhs.cast.i = ptrtoint ptr %e.078.i to i64, !dbg !1888
  %sub.ptr.rhs.cast.i = ptrtoint ptr %s.081.i to i64, !dbg !1888
  %sub.ptr.sub.i = sub i64 %sub.ptr.lhs.cast.i, %sub.ptr.rhs.cast.i, !dbg !1888
  %length.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 8, !dbg !1889
  store i64 %sub.ptr.sub.i, ptr %length.i, align 8, !dbg !1890, !tbaa !1578
  %inc.i = add i64 %ntokens.080.i, 1, !dbg !1891
  tail call void @llvm.dbg.value(metadata i64 %inc.i, metadata !1551, metadata !DIExpression()), !dbg !1876
  store i8 0, ptr %e.078.i, align 1, !dbg !1892, !tbaa !1240
  %cmp9.i = icmp eq i64 %inc.i, 23, !dbg !1893
  br i1 %cmp9.i, label %for.end.thread.i, label %if.end12.i, !dbg !1894

for.end.thread.i:                                 ; preds = %if.then7.i
  %incdec.ptr.i = getelementptr inbounds i8, ptr %e.078.i, i64 1, !dbg !1895
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i, metadata !1549, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata i64 23, metadata !1551, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i, metadata !1550, metadata !DIExpression()), !dbg !1876
  br label %tokenize_command.exit, !dbg !1896

if.end12.i:                                       ; preds = %if.then7.i, %if.then.i
  %ntokens.1.i = phi i64 [ %inc.i, %if.then7.i ], [ %ntokens.080.i, %if.then.i ], !dbg !1876
  tail call void @llvm.dbg.value(metadata i64 %ntokens.1.i, metadata !1551, metadata !DIExpression()), !dbg !1876
  %add.ptr.i = getelementptr inbounds i8, ptr %e.078.i, i64 1, !dbg !1897
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !1549, metadata !DIExpression()), !dbg !1876
  br label %if.end13.i, !dbg !1898

if.end13.i:                                       ; preds = %if.end12.i, %for.body.i
  %ntokens.2.i = phi i64 [ %ntokens.1.i, %if.end12.i ], [ %ntokens.080.i, %for.body.i ], !dbg !1876
  %s.1.i = phi ptr [ %add.ptr.i, %if.end12.i ], [ %s.081.i, %for.body.i ], !dbg !1876
  tail call void @llvm.dbg.value(metadata ptr %s.1.i, metadata !1549, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata i64 %ntokens.2.i, metadata !1551, metadata !DIExpression()), !dbg !1876
  %incdec.ptr14.i = getelementptr inbounds i8, ptr %e.078.i, i64 1, !dbg !1899
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr14.i, metadata !1550, metadata !DIExpression()), !dbg !1876
  %inc15.i = add i32 %i.082.i, 1, !dbg !1900
  tail call void @llvm.dbg.value(metadata i32 %inc15.i, metadata !1553, metadata !DIExpression()), !dbg !1876
  %conv.i = zext i32 %inc15.i to i64, !dbg !1901
  %cmp.i = icmp ugt i64 %call.i, %conv.i, !dbg !1879
  br i1 %cmp.i, label %for.body.i, label %for.end.i, !dbg !1880, !llvm.loop !1902

for.end.i:                                        ; preds = %if.end13.i
  tail call void @llvm.dbg.value(metadata ptr %s.1.i, metadata !1549, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata i64 %ntokens.2.i, metadata !1551, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr14.i, metadata !1550, metadata !DIExpression()), !dbg !1876
  %cmp16.not.i = icmp eq ptr %s.1.i, %incdec.ptr14.i, !dbg !1904
  br i1 %cmp16.not.i, label %tokenize_command.exit, label %if.then18.i, !dbg !1896

if.then18.i:                                      ; preds = %for.end.i
  %arrayidx19.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %ntokens.2.i, !dbg !1905
  store ptr %s.1.i, ptr %arrayidx19.i, align 16, !dbg !1906, !tbaa !1573
  %sub.ptr.lhs.cast21.i = ptrtoint ptr %incdec.ptr14.i to i64, !dbg !1907
  %sub.ptr.rhs.cast22.i = ptrtoint ptr %s.1.i to i64, !dbg !1907
  %sub.ptr.sub23.i = sub i64 %sub.ptr.lhs.cast21.i, %sub.ptr.rhs.cast22.i, !dbg !1907
  %length25.i = getelementptr inbounds i8, ptr %arrayidx19.i, i64 8, !dbg !1908
  store i64 %sub.ptr.sub23.i, ptr %length25.i, align 8, !dbg !1909, !tbaa !1578
  %inc26.i = add i64 %ntokens.2.i, 1, !dbg !1910
  tail call void @llvm.dbg.value(metadata i64 %inc26.i, metadata !1551, metadata !DIExpression()), !dbg !1876
  br label %tokenize_command.exit, !dbg !1911

tokenize_command.exit:                            ; preds = %if.end3, %for.end.thread.i, %for.end.i, %if.then18.i
  %e.173.i = phi ptr [ %incdec.ptr14.i, %if.then18.i ], [ %incdec.ptr14.i, %for.end.i ], [ %incdec.ptr.i, %for.end.thread.i ], [ %command, %if.end3 ]
  %ntokens.4.i = phi i64 [ %inc26.i, %if.then18.i ], [ %ntokens.2.i, %for.end.i ], [ 23, %for.end.thread.i ], [ 0, %if.end3 ], !dbg !1876
  tail call void @llvm.dbg.value(metadata i64 %ntokens.4.i, metadata !1551, metadata !DIExpression()), !dbg !1876
  %6 = load i8, ptr %e.173.i, align 1, !dbg !1912, !tbaa !1240
  %cmp29.i = icmp eq i8 %6, 0, !dbg !1913
  %spec.select.i = select i1 %cmp29.i, ptr null, ptr %e.173.i, !dbg !1912
  %arrayidx31.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %ntokens.4.i, !dbg !1914
  store ptr %spec.select.i, ptr %arrayidx31.i, align 16, !dbg !1915, !tbaa !1573
  %length34.i = getelementptr inbounds i8, ptr %arrayidx31.i, i64 8, !dbg !1916
  store i64 0, ptr %length34.i, align 8, !dbg !1917, !tbaa !1578
  %inc35.i = add i64 %ntokens.4.i, 1, !dbg !1918
  tail call void @llvm.dbg.value(metadata i64 %inc35.i, metadata !1551, metadata !DIExpression()), !dbg !1876
  tail call void @llvm.dbg.value(metadata i64 %inc35.i, metadata !1850, metadata !DIExpression()), !dbg !1854
  %cmp6 = icmp ult i64 %inc35.i, 2, !dbg !1919
  br i1 %cmp6, label %if.then8, label %lor.lhs.false, !dbg !1921

lor.lhs.false:                                    ; preds = %tokenize_command.exit
  %length = getelementptr inbounds i8, ptr %tokens, i64 8, !dbg !1922
  %7 = load i64, ptr %length, align 8, !dbg !1922, !tbaa !1578
  %cmp7 = icmp ult i64 %7, 2, !dbg !1923
  br i1 %cmp7, label %if.then8, label %if.end9, !dbg !1924

if.then8:                                         ; preds = %lor.lhs.false, %tokenize_command.exit
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !1925
  br label %cleanup460, !dbg !1927

if.end9:                                          ; preds = %lor.lhs.false
  %8 = load ptr, ptr %tokens, align 16, !dbg !1928, !tbaa !1573
  %9 = load i8, ptr %8, align 1, !dbg !1929, !tbaa !1240
  tail call void @llvm.dbg.value(metadata i8 %9, metadata !1852, metadata !DIExpression()), !dbg !1854
  %cmp12 = icmp eq i8 %9, 109, !dbg !1930
  %cmp16 = icmp eq i64 %7, 2
  %or.cond = and i1 %cmp16, %cmp12, !dbg !1932
  br i1 %or.cond, label %if.then18, label %if.else, !dbg !1932

if.then18:                                        ; preds = %if.end9
  %arrayidx21 = getelementptr inbounds i8, ptr %8, i64 1, !dbg !1933
  %10 = load i8, ptr %arrayidx21, align 1, !dbg !1933, !tbaa !1240
  switch i8 %10, label %sw.default [
    i8 103, label %sw.bb
    i8 115, label %sw.bb24
    i8 100, label %sw.bb26
    i8 110, label %sw.bb28
    i8 97, label %sw.bb29
    i8 101, label %sw.bb31
  ], !dbg !1935

sw.bb:                                            ; preds = %if.then18
  call fastcc void @process_mget_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !1936
  br label %cleanup460, !dbg !1938

sw.bb24:                                          ; preds = %if.then18
  call fastcc void @process_mset_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !1939
  br label %cleanup460, !dbg !1940

sw.bb26:                                          ; preds = %if.then18
  call fastcc void @process_mdelete_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !1941
  br label %cleanup460, !dbg !1942

sw.bb28:                                          ; preds = %if.then18
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.16) #13, !dbg !1943
  tail call void @conn_set_state(ptr noundef %c, i32 noundef 9) #13, !dbg !1944
  br label %cleanup460, !dbg !1945

sw.bb29:                                          ; preds = %if.then18
  call fastcc void @process_marithmetic_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !1946
  br label %cleanup460, !dbg !1947

sw.bb31:                                          ; preds = %if.then18
  call fastcc void @process_meta_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !1948
  br label %cleanup460, !dbg !1949

sw.default:                                       ; preds = %if.then18
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !1950
  br label %cleanup460, !dbg !1951

if.else:                                          ; preds = %if.end9
  switch i8 %9, label %if.else296 [
    i8 103, label %do.body
    i8 115, label %if.then81
    i8 97, label %if.then133
    i8 99, label %if.then165
    i8 105, label %if.then209
    i8 100, label %if.then233
    i8 116, label %if.then276
  ], !dbg !1952

do.body:                                          ; preds = %if.else
  %cmp37 = icmp eq i64 %inc35.i, 2, !dbg !1953
  br i1 %cmp37, label %if.then39, label %do.end, !dbg !1958

if.then39:                                        ; preds = %do.body
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !1959
  br label %cleanup460, !dbg !1959

do.end:                                           ; preds = %do.body
  %call43 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(4) @.str.17) #15, !dbg !1961
  %cmp44 = icmp eq i32 %call43, 0, !dbg !1963
  br i1 %cmp44, label %if.then46, label %if.else48, !dbg !1964

if.then46:                                        ; preds = %do.end
  call fastcc void @process_get_command(ptr noundef %c, ptr noundef nonnull %tokens, i1 noundef zeroext false, i1 noundef zeroext false), !dbg !1965
  br label %cleanup460, !dbg !1967

if.else48:                                        ; preds = %do.end
  %call51 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(5) @.str.18) #15, !dbg !1968
  %cmp52 = icmp eq i32 %call51, 0, !dbg !1970
  br i1 %cmp52, label %if.then54, label %if.else56, !dbg !1971

if.then54:                                        ; preds = %if.else48
  call fastcc void @process_get_command(ptr noundef %c, ptr noundef nonnull %tokens, i1 noundef zeroext true, i1 noundef zeroext false), !dbg !1972
  br label %cleanup460, !dbg !1974

if.else56:                                        ; preds = %if.else48
  %call59 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(4) @.str.19) #15, !dbg !1975
  %cmp60 = icmp eq i32 %call59, 0, !dbg !1977
  br i1 %cmp60, label %if.then62, label %if.else64, !dbg !1978

if.then62:                                        ; preds = %if.else56
  call fastcc void @process_get_command(ptr noundef %c, ptr noundef nonnull %tokens, i1 noundef zeroext false, i1 noundef zeroext true), !dbg !1979
  br label %cleanup460, !dbg !1981

if.else64:                                        ; preds = %if.else56
  %call67 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(5) @.str.20) #15, !dbg !1982
  %cmp68 = icmp eq i32 %call67, 0, !dbg !1984
  br i1 %cmp68, label %if.then70, label %if.else72, !dbg !1985

if.then70:                                        ; preds = %if.else64
  call fastcc void @process_get_command(ptr noundef %c, ptr noundef nonnull %tokens, i1 noundef zeroext true, i1 noundef zeroext true), !dbg !1986
  br label %cleanup460, !dbg !1988

if.else72:                                        ; preds = %if.else64
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !1989
  br label %cleanup460

if.then81:                                        ; preds = %if.else
  %call84 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(4) @.str.7) #15, !dbg !1991
  %cmp85 = icmp eq i32 %call84, 0, !dbg !1995
  br i1 %cmp85, label %land.lhs.true87, label %if.else100, !dbg !1996

land.lhs.true87:                                  ; preds = %if.then81
  tail call void @llvm.dbg.value(metadata i32 2, metadata !1851, metadata !DIExpression()), !dbg !1854
  %call5.off = add i64 %ntokens.4.i, -5, !dbg !1997
  %switch = icmp ult i64 %call5.off, 2, !dbg !1997
  br i1 %switch, label %do.end98, label %if.then95, !dbg !1997

if.then95:                                        ; preds = %land.lhs.true87
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2001
  br label %cleanup460, !dbg !2001

do.end98:                                         ; preds = %land.lhs.true87
  call fastcc void @process_update_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i, i32 noundef 2, i1 noundef zeroext false), !dbg !2003
  br label %cleanup460, !dbg !2004

if.else100:                                       ; preds = %if.then81
  %call103 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(6) @.str.21) #15, !dbg !2005
  %cmp104 = icmp eq i32 %call103, 0, !dbg !2007
  br i1 %cmp104, label %if.then106, label %if.else108, !dbg !2008

if.then106:                                       ; preds = %if.else100
  call fastcc void @process_stat(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !2009
  br label %cleanup460, !dbg !2011

if.else108:                                       ; preds = %if.else100
  %call111 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(9) @.str.22) #15, !dbg !2012
  %cmp112 = icmp eq i32 %call111, 0, !dbg !2014
  br i1 %cmp112, label %if.then114, label %if.else116, !dbg !2015

if.then114:                                       ; preds = %if.else108
  call fastcc void @process_shutdown_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !2016
  br label %cleanup460, !dbg !2018

if.else116:                                       ; preds = %if.else108
  %call119 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(6) @.str.23) #15, !dbg !2019
  %cmp120 = icmp eq i32 %call119, 0, !dbg !2021
  br i1 %cmp120, label %if.then122, label %if.else124, !dbg !2022

if.then122:                                       ; preds = %if.else116
  call fastcc void @process_slabs_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !2023
  br label %cleanup460, !dbg !2025

if.else124:                                       ; preds = %if.else116
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2026
  br label %cleanup460

if.then133:                                       ; preds = %if.else
  %call136 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(4) @.str.24) #15, !dbg !2028
  %cmp137 = icmp eq i32 %call136, 0, !dbg !2032
  br i1 %cmp137, label %do.body148, label %lor.lhs.false140, !dbg !2033

lor.lhs.false140:                                 ; preds = %if.then133
  %call143 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(7) @.str.25) #15, !dbg !2034
  %cmp144 = icmp eq i32 %call143, 0, !dbg !2035
  br i1 %cmp144, label %do.body148, label %if.else159, !dbg !2036

do.body148:                                       ; preds = %lor.lhs.false140, %if.then133
  %comm.0 = phi i32 [ 1, %if.then133 ], [ 4, %lor.lhs.false140 ], !dbg !2037
  tail call void @llvm.dbg.value(metadata i32 %comm.0, metadata !1851, metadata !DIExpression()), !dbg !1854
  %call5.off592 = add i64 %ntokens.4.i, -5, !dbg !2038
  %switch593 = icmp ult i64 %call5.off592, 2, !dbg !2038
  br i1 %switch593, label %do.end157, label %if.then154, !dbg !2038

if.then154:                                       ; preds = %do.body148
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2042
  br label %cleanup460, !dbg !2042

do.end157:                                        ; preds = %do.body148
  call fastcc void @process_update_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i, i32 noundef %comm.0, i1 noundef zeroext false), !dbg !2044
  br label %cleanup460, !dbg !2045

if.else159:                                       ; preds = %lor.lhs.false140
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2046
  br label %cleanup460

if.then165:                                       ; preds = %if.else
  %call168 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(4) @.str.26) #15, !dbg !2048
  %cmp169 = icmp eq i32 %call168, 0, !dbg !2052
  br i1 %cmp169, label %land.lhs.true171, label %if.else184, !dbg !2053

land.lhs.true171:                                 ; preds = %if.then165
  tail call void @llvm.dbg.value(metadata i32 6, metadata !1851, metadata !DIExpression()), !dbg !1854
  %11 = and i64 %ntokens.4.i, -2, !dbg !2054
  %switch595 = icmp eq i64 %11, 6, !dbg !2054
  br i1 %switch595, label %do.end182, label %if.then179, !dbg !2054

if.then179:                                       ; preds = %land.lhs.true171
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2058
  br label %cleanup460, !dbg !2058

do.end182:                                        ; preds = %land.lhs.true171
  call fastcc void @process_update_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i, i32 noundef 6, i1 noundef zeroext true), !dbg !2060
  br label %cleanup460, !dbg !2061

if.else184:                                       ; preds = %if.then165
  %call187 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(15) @.str.27) #15, !dbg !2062
  %cmp188 = icmp eq i32 %call187, 0, !dbg !2064
  br i1 %cmp188, label %do.body191, label %if.else202, !dbg !2065

do.body191:                                       ; preds = %if.else184
  %12 = and i64 %ntokens.4.i, -2, !dbg !2066
  %switch597 = icmp eq i64 %12, 2, !dbg !2066
  br i1 %switch597, label %do.end200, label %if.then197, !dbg !2066

if.then197:                                       ; preds = %do.body191
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2070
  br label %cleanup460, !dbg !2070

do.end200:                                        ; preds = %do.body191
  call fastcc void @process_memlimit_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !2072
  br label %cleanup460, !dbg !2073

if.else202:                                       ; preds = %if.else184
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2074
  br label %cleanup460

if.then209:                                       ; preds = %if.else
  %call212 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(5) @.str.28) #15, !dbg !2076
  %cmp213 = icmp eq i32 %call212, 0, !dbg !2080
  br i1 %cmp213, label %do.body216, label %if.else227, !dbg !2081

do.body216:                                       ; preds = %if.then209
  %call5.off598 = add i64 %ntokens.4.i, -3, !dbg !2082
  %switch599 = icmp ult i64 %call5.off598, 2, !dbg !2082
  br i1 %switch599, label %do.end225, label %if.then222, !dbg !2082

if.then222:                                       ; preds = %do.body216
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2086
  br label %cleanup460, !dbg !2086

do.end225:                                        ; preds = %do.body216
  call fastcc void @process_arithmetic_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i, i1 noundef zeroext true), !dbg !2088
  br label %cleanup460, !dbg !2089

if.else227:                                       ; preds = %if.then209
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2090
  br label %cleanup460

if.then233:                                       ; preds = %if.else
  %call236 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(7) @.str.29) #15, !dbg !2092
  %cmp237 = icmp eq i32 %call236, 0, !dbg !2096
  br i1 %cmp237, label %do.body240, label %if.else251, !dbg !2097

do.body240:                                       ; preds = %if.then233
  %cmp241 = icmp eq i64 %inc35.i, 2, !dbg !2098
  %cmp244 = icmp ugt i64 %inc35.i, 5, !dbg !2098
  %or.cond591 = or i1 %cmp241, %cmp244, !dbg !2098
  br i1 %or.cond591, label %if.then246, label %do.end249, !dbg !2098

if.then246:                                       ; preds = %do.body240
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2102
  br label %cleanup460, !dbg !2102

do.end249:                                        ; preds = %do.body240
  call fastcc void @process_delete_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !2104
  br label %cleanup460, !dbg !2105

if.else251:                                       ; preds = %if.then233
  %call254 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(5) @.str.30) #15, !dbg !2106
  %cmp255 = icmp eq i32 %call254, 0, !dbg !2108
  br i1 %cmp255, label %do.body258, label %if.else269, !dbg !2109

do.body258:                                       ; preds = %if.else251
  %call5.off600 = add i64 %ntokens.4.i, -3, !dbg !2110
  %switch601 = icmp ult i64 %call5.off600, 2, !dbg !2110
  br i1 %switch601, label %do.end267, label %if.then264, !dbg !2110

if.then264:                                       ; preds = %do.body258
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2114
  br label %cleanup460, !dbg !2114

do.end267:                                        ; preds = %do.body258
  call fastcc void @process_arithmetic_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i, i1 noundef zeroext false), !dbg !2116
  br label %cleanup460, !dbg !2117

if.else269:                                       ; preds = %if.else251
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2118
  br label %cleanup460

if.then276:                                       ; preds = %if.else
  %call279 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(6) @.str.31) #15, !dbg !2120
  %cmp280 = icmp eq i32 %call279, 0, !dbg !2124
  br i1 %cmp280, label %do.body283, label %if.else294, !dbg !2125

do.body283:                                       ; preds = %if.then276
  %call5.off602 = add i64 %ntokens.4.i, -3, !dbg !2126
  %switch603 = icmp ult i64 %call5.off602, 2, !dbg !2126
  br i1 %switch603, label %do.end292, label %if.then289, !dbg !2126

if.then289:                                       ; preds = %do.body283
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2130
  br label %cleanup460, !dbg !2130

do.end292:                                        ; preds = %do.body283
  call fastcc void @process_touch_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !2132
  br label %cleanup460, !dbg !2133

if.else294:                                       ; preds = %if.then276
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2134
  br label %cleanup460

if.else296:                                       ; preds = %if.else
  %call299 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(8) @.str.32) #15, !dbg !2136
  %cmp300 = icmp eq i32 %call299, 0, !dbg !2138
  br i1 %cmp300, label %do.body311, label %lor.lhs.false303, !dbg !2139

lor.lhs.false303:                                 ; preds = %if.else296
  %call306 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(8) @.str.33) #15, !dbg !2140
  %cmp307 = icmp eq i32 %call306, 0, !dbg !2141
  br i1 %cmp307, label %do.body311, label %if.else322, !dbg !2142

do.body311:                                       ; preds = %lor.lhs.false303, %if.else296
  %comm.1 = phi i32 [ 3, %if.else296 ], [ 5, %lor.lhs.false303 ], !dbg !2143
  tail call void @llvm.dbg.value(metadata i32 %comm.1, metadata !1851, metadata !DIExpression()), !dbg !1854
  %call5.off604 = add i64 %ntokens.4.i, -5, !dbg !2144
  %switch605 = icmp ult i64 %call5.off604, 2, !dbg !2144
  br i1 %switch605, label %do.end320, label %if.then317, !dbg !2144

if.then317:                                       ; preds = %do.body311
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2148
  br label %cleanup460, !dbg !2148

do.end320:                                        ; preds = %do.body311
  call fastcc void @process_update_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i, i32 noundef %comm.1, i1 noundef zeroext false), !dbg !2150
  br label %cleanup460, !dbg !2151

if.else322:                                       ; preds = %lor.lhs.false303
  %call325 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(5) @.str.34) #15, !dbg !2152
  %cmp326 = icmp eq i32 %call325, 0, !dbg !2154
  br i1 %cmp326, label %do.body329, label %if.else337, !dbg !2155

do.body329:                                       ; preds = %if.else322
  %cmp330 = icmp eq i64 %inc35.i, 2, !dbg !2156
  br i1 %cmp330, label %if.then332, label %do.end335, !dbg !2160

if.then332:                                       ; preds = %do.body329
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2161
  br label %cleanup460, !dbg !2161

do.end335:                                        ; preds = %do.body329
  call fastcc void @process_get_command(ptr noundef %c, ptr noundef nonnull %tokens, i1 noundef zeroext false, i1 noundef zeroext false), !dbg !2163
  br label %cleanup460, !dbg !2164

if.else337:                                       ; preds = %if.else322
  %call340 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(10) @.str.35) #15, !dbg !2165
  %cmp341 = icmp eq i32 %call340, 0, !dbg !2167
  br i1 %cmp341, label %lor.lhs.false347, label %if.else355, !dbg !2168

lor.lhs.false347:                                 ; preds = %if.else337
  %cmp348 = icmp ugt i64 %inc35.i, 4, !dbg !2169
  br i1 %cmp348, label %if.then350, label %do.end353, !dbg !2173

if.then350:                                       ; preds = %lor.lhs.false347
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2174
  br label %cleanup460, !dbg !2174

do.end353:                                        ; preds = %lor.lhs.false347
  call fastcc void @process_flush_all_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !2176
  br label %cleanup460, !dbg !2177

if.else355:                                       ; preds = %if.else337
  %call358 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(8) @.str.36) #15, !dbg !2178
  %cmp359 = icmp eq i32 %call358, 0, !dbg !2180
  br i1 %cmp359, label %if.then361, label %if.else362, !dbg !2181

if.then361:                                       ; preds = %if.else355
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2182, metadata !DIExpression()), !dbg !2185
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.120) #13, !dbg !2188
  br label %cleanup460, !dbg !2189

if.else362:                                       ; preds = %if.else355
  %call365 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(5) @.str.37) #15, !dbg !2190
  %cmp366 = icmp eq i32 %call365, 0, !dbg !2192
  br i1 %cmp366, label %if.then368, label %if.else369, !dbg !2193

if.then368:                                       ; preds = %if.else362
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2194, metadata !DIExpression()), !dbg !2197
  tail call void @conn_set_state(ptr noundef %c, i32 noundef 9) #13, !dbg !2200
  %close_after_write.i = getelementptr inbounds i8, ptr %c, i64 16, !dbg !2201
  store i8 1, ptr %close_after_write.i, align 8, !dbg !2202, !tbaa !2203
  %close_reason.i = getelementptr inbounds i8, ptr %c, i64 324, !dbg !2204
  store i32 1, ptr %close_reason.i, align 4, !dbg !2205, !tbaa !2206
  br label %cleanup460, !dbg !2207

if.else369:                                       ; preds = %if.else362
  %call372 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(12) @.str.38) #15, !dbg !2208
  %cmp373 = icmp eq i32 %call372, 0, !dbg !2210
  br i1 %cmp373, label %if.then375, label %if.else377, !dbg !2211

if.then375:                                       ; preds = %if.else369
  call fastcc void @process_lru_crawler_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !2212
  br label %cleanup460, !dbg !2214

if.else377:                                       ; preds = %if.else369
  %call380 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(6) @.str.39) #15, !dbg !2215
  %cmp381 = icmp eq i32 %call380, 0, !dbg !2217
  br i1 %cmp381, label %if.then383, label %if.else385, !dbg !2218

if.then383:                                       ; preds = %if.else377
  call fastcc void @process_watch_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !2219
  br label %cleanup460, !dbg !2221

if.else385:                                       ; preds = %if.else377
  %call388 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(10) @.str.40) #15, !dbg !2222
  %cmp389 = icmp eq i32 %call388, 0, !dbg !2224
  br i1 %cmp389, label %do.body392, label %if.else403, !dbg !2225

do.body392:                                       ; preds = %if.else385
  %13 = and i64 %ntokens.4.i, -2, !dbg !2226
  %switch607 = icmp eq i64 %13, 2, !dbg !2226
  br i1 %switch607, label %do.end401, label %if.then398, !dbg !2226

if.then398:                                       ; preds = %do.body392
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2230
  br label %cleanup460, !dbg !2230

do.end401:                                        ; preds = %do.body392
  call fastcc void @process_verbosity_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !2232
  br label %cleanup460, !dbg !2233

if.else403:                                       ; preds = %if.else385
  %call406 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(4) @.str.41) #15, !dbg !2234
  %cmp407 = icmp eq i32 %call406, 0, !dbg !2236
  br i1 %cmp407, label %do.body410, label %if.else418, !dbg !2237

do.body410:                                       ; preds = %if.else403
  %cmp411 = icmp eq i64 %inc35.i, 2, !dbg !2238
  br i1 %cmp411, label %if.then413, label %do.end416, !dbg !2242

if.then413:                                       ; preds = %do.body410
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2243
  br label %cleanup460, !dbg !2243

do.end416:                                        ; preds = %do.body410
  call fastcc void @process_lru_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !2245
  br label %cleanup460, !dbg !2246

if.else418:                                       ; preds = %if.else403
  %call421 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(9) @.str.42) #15, !dbg !2247
  %cmp422 = icmp eq i32 %call421, 0, !dbg !2249
  br i1 %cmp422, label %do.body425, label %if.else433, !dbg !2250

do.body425:                                       ; preds = %if.else418
  %cmp426 = icmp eq i64 %inc35.i, 2, !dbg !2251
  br i1 %cmp426, label %if.then428, label %do.end431, !dbg !2255

if.then428:                                       ; preds = %do.body425
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2256
  br label %cleanup460, !dbg !2256

do.end431:                                        ; preds = %do.body425
  call fastcc void @process_extstore_command(ptr noundef %c, ptr noundef nonnull %tokens, i64 noundef %inc35.i), !dbg !2258
  br label %cleanup460, !dbg !2259

if.else433:                                       ; preds = %if.else418
  %sub = add i64 %ntokens.4.i, -1, !dbg !2260
  %arrayidx434 = getelementptr inbounds [24 x %struct.token_s], ptr %tokens, i64 0, i64 %sub, !dbg !2263
  %14 = load ptr, ptr %arrayidx434, align 16, !dbg !2264, !tbaa !1573
  %call436 = tail call i32 @strncmp(ptr noundef nonnull dereferenceable(1) %14, ptr noundef nonnull dereferenceable(6) @.str.43, i64 noundef 5) #16, !dbg !2265
  %cmp437 = icmp eq i32 %call436, 0, !dbg !2266
  br i1 %cmp437, label %if.then439, label %if.else440, !dbg !2267

if.then439:                                       ; preds = %if.else433
  tail call void @conn_set_state(ptr noundef %c, i32 noundef 8) #13, !dbg !2268
  br label %cleanup460, !dbg !2270

if.else440:                                       ; preds = %if.else433
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !2271
  br label %cleanup460

cleanup460:                                       ; preds = %if.then39, %if.then95, %if.then154, %if.then179, %if.then197, %if.then222, %if.then246, %if.then264, %if.then289, %if.then317, %if.then332, %if.then350, %if.then398, %if.then413, %if.then428, %if.then54, %if.then70, %if.else72, %if.then62, %if.then46, %if.else159, %do.end157, %if.else227, %do.end225, %if.else294, %do.end292, %do.end335, %if.then361, %if.then375, %do.end401, %do.end431, %if.else440, %if.then439, %do.end416, %if.then383, %if.then368, %do.end353, %do.end320, %do.end249, %if.else269, %do.end267, %do.end182, %if.else202, %do.end200, %do.end98, %if.then114, %if.else124, %if.then122, %if.then106, %sw.bb, %sw.bb24, %sw.bb26, %sw.bb28, %sw.bb29, %sw.bb31, %sw.default, %if.then8, %if.then2
  call void @llvm.lifetime.end.p0(i64 384, ptr nonnull %tokens) #13, !dbg !2273
  ret void, !dbg !2273
}

; Function Attrs: nofree nounwind
declare !dbg !2274 noundef i32 @fprintf(ptr nocapture noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #5

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_mget_command(ptr noundef %c, ptr nocapture noundef %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !2330 {
entry:
  %of = alloca %struct._meta_flags, align 8, !DIAssignID !2377
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2341, metadata !DIExpression(), metadata !2377, metadata ptr %of, metadata !DIExpression()), !dbg !2378
  %hv = alloca i32, align 4, !DIAssignID !2379
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2367, metadata !DIExpression(), metadata !2379, metadata ptr %hv, metadata !DIExpression()), !dbg !2378
  %errstr = alloca ptr, align 8, !DIAssignID !2380
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2372, metadata !DIExpression(), metadata !2380, metadata ptr %errstr, metadata !DIExpression()), !dbg !2378
  %overflow = alloca i8, align 1, !DIAssignID !2381
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2375, metadata !DIExpression(), metadata !2381, metadata ptr %overflow, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2334, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !2335, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !2336, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2340, metadata !DIExpression()), !dbg !2378
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %of) #13, !dbg !2382
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %of, i8 0, i64 56, i1 false), !dbg !2383, !DIAssignID !2384
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2341, metadata !DIExpression(), metadata !2384, metadata ptr %of, metadata !DIExpression()), !dbg !2378
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %hv) #13, !dbg !2385
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2368, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2369, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2370, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2371, metadata !DIExpression()), !dbg !2378
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %errstr) #13, !dbg !2386
  store ptr @.str.48, ptr %errstr, align 8, !dbg !2387, !tbaa !1271, !DIAssignID !2388
  tail call void @llvm.dbg.assign(metadata ptr @.str.48, metadata !2372, metadata !DIExpression(), metadata !2388, metadata ptr %errstr, metadata !DIExpression()), !dbg !2378
  %resp1 = getelementptr inbounds i8, ptr %c, i64 192, !dbg !2389
  %0 = load ptr, ptr %resp1, align 8, !dbg !2389, !tbaa !1351
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2373, metadata !DIExpression()), !dbg !2378
  %wbuf = getelementptr inbounds i8, ptr %0, i64 160, !dbg !2390
  tail call void @llvm.dbg.value(metadata ptr %wbuf, metadata !2374, metadata !DIExpression()), !dbg !2378
  %cmp = icmp ult i64 %ntokens, 3, !dbg !2391
  br i1 %cmp, label %if.then, label %do.end, !dbg !2394

if.then:                                          ; preds = %entry
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.15) #13, !dbg !2395
  br label %cleanup524, !dbg !2395

do.end:                                           ; preds = %entry
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !2397
  %length = getelementptr inbounds i8, ptr %tokens, i64 24, !dbg !2399
  %1 = load i64, ptr %length, align 8, !dbg !2399, !tbaa !1578
  %cmp2 = icmp ugt i64 %1, 250, !dbg !2400
  br i1 %cmp2, label %if.then3, label %if.end4, !dbg !2401

if.then3:                                         ; preds = %do.end
  tail call void @out_errstring(ptr noundef nonnull %c, ptr noundef nonnull @.str.48) #13, !dbg !2402
  br label %cleanup524, !dbg !2404

if.end4:                                          ; preds = %do.end
  %cmp5 = icmp ugt i64 %ntokens, 20, !dbg !2405
  br i1 %cmp5, label %if.then6, label %if.end7, !dbg !2407

if.then6:                                         ; preds = %if.end4
  tail call void @out_errstring(ptr noundef nonnull %c, ptr noundef nonnull @.str.49) #13, !dbg !2408
  br label %cleanup524, !dbg !2410

if.end7:                                          ; preds = %if.end4
  %call = call fastcc i32 @_meta_flag_preparse(ptr noundef nonnull %tokens, i64 noundef 2, ptr noundef nonnull %of, ptr noundef nonnull %errstr), !dbg !2411
  %cmp8.not = icmp eq i32 %call, 0, !dbg !2413
  br i1 %cmp8.not, label %if.end10, label %if.then9, !dbg !2414

if.then9:                                         ; preds = %if.end7
  %2 = load ptr, ptr %errstr, align 8, !dbg !2415, !tbaa !1271
  call void @out_errstring(ptr noundef nonnull %c, ptr noundef %2) #13, !dbg !2417
  br label %cleanup524, !dbg !2418

if.end10:                                         ; preds = %if.end7
  %bf.load = load i16, ptr %of, align 8, !dbg !2419
  %noreply = getelementptr inbounds i8, ptr %c, i64 364, !dbg !2420
  %3 = lshr i16 %bf.load, 8, !dbg !2421
  %4 = trunc nuw i16 %3 to i8, !dbg !2421
  %frombool = and i8 %4, 1, !dbg !2421
  store i8 %frombool, ptr %noreply, align 4, !dbg !2421, !tbaa !1302
  %5 = load ptr, ptr %arrayidx, align 8, !dbg !2422, !tbaa !1573
  tail call void @llvm.dbg.value(metadata ptr %5, metadata !2337, metadata !DIExpression()), !dbg !2378
  %6 = load i64, ptr %length, align 8, !dbg !2423, !tbaa !1578
  tail call void @llvm.dbg.value(metadata i64 %6, metadata !2338, metadata !DIExpression()), !dbg !2378
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %overflow) #13, !dbg !2424
  store i8 0, ptr %overflow, align 1, !dbg !2425, !tbaa !2426, !DIAssignID !2427
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2375, metadata !DIExpression(), metadata !2427, metadata ptr %overflow, metadata !DIExpression()), !dbg !2378
  %7 = and i16 %bf.load, 4, !dbg !2428
  %tobool18.not = icmp eq i16 %7, 0, !dbg !2428
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !2430
  %8 = load ptr, ptr %thread, align 8, !dbg !2430, !tbaa !1234
  br i1 %tobool18.not, label %if.then19, label %if.else, !dbg !2431

if.then19:                                        ; preds = %if.end10
  %9 = and i16 %bf.load, 2, !dbg !2432
  %tobool24.not = icmp eq i16 %9, 0, !dbg !2432
  %call25 = call ptr @limited_get(ptr noundef %5, i64 noundef %6, ptr noundef %8, i32 noundef 0, i1 noundef zeroext false, i1 noundef zeroext %tobool24.not, ptr noundef nonnull %overflow) #13, !dbg !2434
  tail call void @llvm.dbg.value(metadata ptr %call25, metadata !2339, metadata !DIExpression()), !dbg !2378
  br label %if.end28, !dbg !2435

if.else:                                          ; preds = %if.end10
  %call27 = call ptr @limited_get_locked(ptr noundef %5, i64 noundef %6, ptr noundef %8, i1 noundef zeroext false, ptr noundef nonnull %hv, ptr noundef nonnull %overflow) #13, !dbg !2436
  tail call void @llvm.dbg.value(metadata ptr %call27, metadata !2339, metadata !DIExpression()), !dbg !2378
  br label %if.end28

if.end28:                                         ; preds = %if.else, %if.then19
  %it.0 = phi ptr [ %call27, %if.else ], [ %call25, %if.then19 ], !dbg !2430
  tail call void @llvm.dbg.value(metadata ptr %it.0, metadata !2339, metadata !DIExpression()), !dbg !2378
  %10 = load i8, ptr %overflow, align 1, !dbg !2438, !tbaa !2426, !range !1296, !noundef !1297
  %tobool29 = trunc nuw i8 %10 to i1, !dbg !2438
  br i1 %tobool29, label %if.then30, label %if.end31, !dbg !2440

if.then30:                                        ; preds = %if.end28
  call void @out_errstring(ptr noundef nonnull %c, ptr noundef nonnull @.str.50) #13, !dbg !2441
  br label %cleanup, !dbg !2443

if.end31:                                         ; preds = %if.end28
  %cmp32 = icmp eq ptr %it.0, null, !dbg !2444
  br i1 %cmp32, label %land.lhs.true, label %if.then65, !dbg !2446

land.lhs.true:                                    ; preds = %if.end31
  %bf.load33 = load i16, ptr %of, align 8, !dbg !2447
  %11 = and i16 %bf.load33, 8, !dbg !2448
  %tobool37.not = icmp eq i16 %11, 0, !dbg !2448
  br i1 %tobool37.not, label %if.end364, label %if.then38, !dbg !2449

if.then38:                                        ; preds = %land.lhs.true
  %call39 = call i32 @realtime(i64 noundef 0) #13, !dbg !2450
  %call40 = call ptr @item_alloc(ptr noundef %5, i64 noundef %6, i32 noundef 0, i32 noundef %call39, i32 noundef 2) #13, !dbg !2452
  tail call void @llvm.dbg.value(metadata ptr %call40, metadata !2339, metadata !DIExpression()), !dbg !2378
  %cmp41.not = icmp eq ptr %call40, null, !dbg !2453
  br i1 %cmp41.not, label %if.end364, label %if.then42, !dbg !2455

if.then42:                                        ; preds = %if.then38
  %data = getelementptr inbounds i8, ptr %call40, i64 48, !dbg !2456
  %nkey43 = getelementptr inbounds i8, ptr %call40, i64 41, !dbg !2456
  %12 = load i8, ptr %nkey43, align 1, !dbg !2456, !tbaa !1240
  %idx.ext = zext i8 %12 to i64
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %idx.ext, !dbg !2456
  %add.ptr44 = getelementptr inbounds i8, ptr %add.ptr, i64 1, !dbg !2456
  %it_flags = getelementptr inbounds i8, ptr %call40, i64 38, !dbg !2456
  %13 = load i16, ptr %it_flags, align 2, !dbg !2456, !tbaa !1248
  %conv45 = zext i16 %13 to i32, !dbg !2456
  %and = lshr i32 %conv45, 6, !dbg !2456
  %14 = and i32 %and, 4, !dbg !2456
  %cond = zext nneg i32 %14 to i64, !dbg !2456
  %add.ptr47 = getelementptr inbounds i8, ptr %add.ptr44, i64 %cond, !dbg !2456
  %and50 = shl nuw nsw i32 %conv45, 2, !dbg !2456
  %15 = and i32 %and50, 8, !dbg !2456
  %cond52 = zext nneg i32 %15 to i64, !dbg !2456
  %add.ptr53 = getelementptr inbounds i8, ptr %add.ptr47, i64 %cond52, !dbg !2456
  store i16 2573, ptr %add.ptr53, align 1, !dbg !2458
  %16 = load i32, ptr %hv, align 4, !dbg !2459, !tbaa !1231
  %bf.load54 = load i16, ptr %of, align 8, !dbg !2460
  %17 = and i16 %bf.load54, 1024, !dbg !2461
  %tobool58.not = icmp eq i16 %17, 0, !dbg !2461
  br i1 %tobool58.not, label %cond.false, label %cond.true, !dbg !2461

cond.true:                                        ; preds = %if.then42
  %cas_id_in = getelementptr inbounds i8, ptr %of, i64 32, !dbg !2462
  %18 = load i64, ptr %cas_id_in, align 8, !dbg !2462, !tbaa !2463
  br label %cond.end, !dbg !2461

cond.false:                                       ; preds = %if.then42
  %call59 = call i64 @get_cas_id() #13, !dbg !2465
  br label %cond.end, !dbg !2461

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond60 = phi i64 [ %18, %cond.true ], [ %call59, %cond.false ], !dbg !2461
  %call61 = call i32 @do_item_link(ptr noundef nonnull %call40, i32 noundef %16, i64 noundef %cond60) #13, !dbg !2466
  tail call void @llvm.dbg.value(metadata i8 1, metadata !2369, metadata !DIExpression()), !dbg !2378
  br label %if.then65, !dbg !2467

if.then65:                                        ; preds = %if.end31, %cond.end
  %it.1 = phi ptr [ %call40, %cond.end ], [ %it.0, %if.end31 ], !dbg !2378
  tail call void @llvm.dbg.value(metadata ptr %it.1, metadata !2339, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2369, metadata !DIExpression()), !dbg !2378
  %bf.load66 = load i16, ptr %of, align 8, !dbg !2468
  %19 = and i16 %bf.load66, 64, !dbg !2472
  %tobool70.not = icmp eq i16 %19, 0, !dbg !2472
  br i1 %tobool70.not, label %if.else74, label %if.then71, !dbg !2473

if.then71:                                        ; preds = %if.then65
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %wbuf, ptr noundef nonnull align 1 dereferenceable(3) @.str.51, i64 3, i1 false), !dbg !2474
  %nbytes = getelementptr inbounds i8, ptr %it.1, i64 32, !dbg !2476
  %20 = load i32, ptr %nbytes, align 8, !dbg !2476, !tbaa !1231
  %sub = add nsw i32 %20, -2, !dbg !2477
  %add.ptr72 = getelementptr inbounds i8, ptr %0, i64 163, !dbg !2478
  %call73 = call ptr @itoa_u32(i32 noundef %sub, ptr noundef nonnull %add.ptr72) #13, !dbg !2479
  tail call void @llvm.dbg.value(metadata ptr %call73, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %if.end76, !dbg !2480

if.else74:                                        ; preds = %if.then65
  store i16 17480, ptr %wbuf, align 1, !dbg !2481
  %add.ptr75 = getelementptr inbounds i8, ptr %0, i64 162, !dbg !2483
  tail call void @llvm.dbg.value(metadata ptr %add.ptr75, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %if.end76

if.end76:                                         ; preds = %if.else74, %if.then71
  %p.0 = phi ptr [ %call73, %if.then71 ], [ %add.ptr75, %if.else74 ], !dbg !2484
  tail call void @llvm.dbg.value(metadata ptr %p.0, metadata !2374, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i32 2, metadata !2340, metadata !DIExpression()), !dbg !2378
  %sub78 = add nsw i64 %ntokens, -1
  tail call void @llvm.dbg.value(metadata ptr %p.0, metadata !2374, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2371, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2370, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i32 2, metadata !2340, metadata !DIExpression()), !dbg !2378
  %cmp79780 = icmp ugt i64 %sub78, 2, !dbg !2485
  br i1 %cmp79780, label %for.body.lr.ph, label %for.end, !dbg !2488

for.body.lr.ph:                                   ; preds = %if.end76
  %it_flags208 = getelementptr inbounds i8, ptr %it.1, i64 38
  %data227 = getelementptr inbounds i8, ptr %it.1, i64 48
  %nkey234 = getelementptr inbounds i8, ptr %it.1, i64 41
  %time = getelementptr inbounds i8, ptr %it.1, i64 24
  %invariant.gep = getelementptr inbounds i8, ptr %it.1, i64 49, !dbg !2488
  %exptime118 = getelementptr inbounds i8, ptr %it.1, i64 28
  %nbytes112 = getelementptr inbounds i8, ptr %it.1, i64 32
  %recache_time = getelementptr inbounds i8, ptr %of, i64 12
  %autoviv_exptime = getelementptr inbounds i8, ptr %of, i64 8
  %exptime = getelementptr inbounds i8, ptr %of, i64 4
  br label %for.body, !dbg !2488

for.body:                                         ; preds = %for.body.lr.ph, %for.inc
  %conv77785 = phi i64 [ 2, %for.body.lr.ph ], [ %conv77, %for.inc ]
  %p.1784 = phi ptr [ %p.0, %for.body.lr.ph ], [ %p.2, %for.inc ]
  %ttl_set.0783 = phi i8 [ 0, %for.body.lr.ph ], [ %ttl_set.1, %for.inc ]
  %won_token.0782 = phi i1 [ false, %for.body.lr.ph ], [ %won_token.1, %for.inc ]
  %i.0781 = phi i32 [ 2, %for.body.lr.ph ], [ %inc, %for.inc ]
  tail call void @llvm.dbg.value(metadata ptr %p.1784, metadata !2374, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i8 %ttl_set.0783, metadata !2371, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i32 %i.0781, metadata !2340, metadata !DIExpression()), !dbg !2378
  %arrayidx81 = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %conv77785, !dbg !2489
  %21 = load ptr, ptr %arrayidx81, align 8, !dbg !2491, !tbaa !1573
  %22 = load i8, ptr %21, align 1, !dbg !2489, !tbaa !1240
  switch i8 %22, label %for.inc [
    i8 84, label %sw.bb
    i8 78, label %sw.bb86
    i8 82, label %sw.bb91
    i8 115, label %sw.bb109
    i8 116, label %sw.bb115
    i8 99, label %sw.bb129
    i8 102, label %sw.bb143
    i8 108, label %sw.bb170
    i8 104, label %sw.bb175
    i8 79, label %sw.bb186
    i8 107, label %sw.bb205
  ], !dbg !2492

sw.bb:                                            ; preds = %for.body
  tail call void @llvm.dbg.value(metadata i8 1, metadata !2371, metadata !DIExpression()), !dbg !2378
  %23 = load i32, ptr %exptime, align 4, !dbg !2493, !tbaa !2495
  store i32 %23, ptr %exptime118, align 4, !dbg !2496, !tbaa !1231
  br label %for.inc, !dbg !2497

sw.bb86:                                          ; preds = %for.body
  br i1 %cmp32, label %if.then88, label %for.inc, !dbg !2498

if.then88:                                        ; preds = %sw.bb86
  %24 = load i32, ptr %autoviv_exptime, align 8, !dbg !2499, !tbaa !2502
  store i32 %24, ptr %exptime118, align 4, !dbg !2503, !tbaa !1231
  tail call void @llvm.dbg.value(metadata i8 1, metadata !2370, metadata !DIExpression()), !dbg !2378
  br label %for.inc, !dbg !2504

sw.bb91:                                          ; preds = %for.body
  %25 = load i16, ptr %it_flags208, align 2, !dbg !2505, !tbaa !1248
  %26 = and i16 %25, 512, !dbg !2507
  %cmp95 = icmp ne i16 %26, 0, !dbg !2508
  %brmerge = or i1 %cmp32, %cmp95, !dbg !2509
  br i1 %brmerge, label %for.inc, label %land.lhs.true99, !dbg !2509

land.lhs.true99:                                  ; preds = %sw.bb91
  %27 = load i32, ptr %exptime118, align 4, !dbg !2510, !tbaa !1231
  %cmp101.not = icmp eq i32 %27, 0, !dbg !2511
  br i1 %cmp101.not, label %for.inc, label %land.lhs.true103, !dbg !2512

land.lhs.true103:                                 ; preds = %land.lhs.true99
  %28 = load i32, ptr %recache_time, align 4, !dbg !2513, !tbaa !2514
  %cmp105 = icmp ult i32 %27, %28, !dbg !2515
  %spec.select = select i1 %cmp105, i1 true, i1 %won_token.0782, !dbg !2516
  br label %for.inc, !dbg !2516

sw.bb109:                                         ; preds = %for.body
  store i8 32, ptr %p.1784, align 1, !dbg !2517, !tbaa !1240
  %add.ptr110 = getelementptr inbounds i8, ptr %p.1784, i64 1, !dbg !2517
  store i8 115, ptr %add.ptr110, align 1, !dbg !2517, !tbaa !1240
  %add.ptr111 = getelementptr inbounds i8, ptr %p.1784, i64 2, !dbg !2517
  tail call void @llvm.dbg.value(metadata ptr %add.ptr111, metadata !2374, metadata !DIExpression()), !dbg !2378
  %29 = load i32, ptr %nbytes112, align 8, !dbg !2519, !tbaa !1231
  %sub113 = add nsw i32 %29, -2, !dbg !2520
  %call114 = call ptr @itoa_u32(i32 noundef %sub113, ptr noundef nonnull %add.ptr111) #13, !dbg !2521
  tail call void @llvm.dbg.value(metadata ptr %call114, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %for.inc, !dbg !2522

sw.bb115:                                         ; preds = %for.body
  store i8 32, ptr %p.1784, align 1, !dbg !2523, !tbaa !1240
  %add.ptr116 = getelementptr inbounds i8, ptr %p.1784, i64 1, !dbg !2523
  store i8 116, ptr %add.ptr116, align 1, !dbg !2523, !tbaa !1240
  %add.ptr117 = getelementptr inbounds i8, ptr %p.1784, i64 2, !dbg !2523
  tail call void @llvm.dbg.value(metadata ptr %add.ptr117, metadata !2374, metadata !DIExpression()), !dbg !2378
  %30 = load i32, ptr %exptime118, align 4, !dbg !2525, !tbaa !1231
  %cmp119 = icmp eq i32 %30, 0, !dbg !2527
  br i1 %cmp119, label %if.then121, label %if.else124, !dbg !2528

if.then121:                                       ; preds = %sw.bb115
  store i8 45, ptr %add.ptr117, align 1, !dbg !2529, !tbaa !1240
  %add.ptr122 = getelementptr inbounds i8, ptr %p.1784, i64 3, !dbg !2531
  store i8 49, ptr %add.ptr122, align 1, !dbg !2532, !tbaa !1240
  %add.ptr123 = getelementptr inbounds i8, ptr %p.1784, i64 4, !dbg !2533
  tail call void @llvm.dbg.value(metadata ptr %add.ptr123, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %for.inc, !dbg !2534

if.else124:                                       ; preds = %sw.bb115
  %31 = load volatile i32, ptr @current_time, align 4, !dbg !2535, !tbaa !1231
  %sub126 = sub i32 %30, %31, !dbg !2537
  %call127 = call ptr @itoa_u32(i32 noundef %sub126, ptr noundef nonnull %add.ptr117) #13, !dbg !2538
  tail call void @llvm.dbg.value(metadata ptr %call127, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %for.inc

sw.bb129:                                         ; preds = %for.body
  store i8 32, ptr %p.1784, align 1, !dbg !2539, !tbaa !1240
  %add.ptr130 = getelementptr inbounds i8, ptr %p.1784, i64 1, !dbg !2539
  store i8 99, ptr %add.ptr130, align 1, !dbg !2539, !tbaa !1240
  %add.ptr131 = getelementptr inbounds i8, ptr %p.1784, i64 2, !dbg !2539
  tail call void @llvm.dbg.value(metadata ptr %add.ptr131, metadata !2374, metadata !DIExpression()), !dbg !2378
  %32 = load i16, ptr %it_flags208, align 2, !dbg !2541, !tbaa !1248
  %33 = and i16 %32, 2, !dbg !2541
  %tobool135.not = icmp eq i16 %33, 0, !dbg !2541
  br i1 %tobool135.not, label %cond.end140, label %cond.true136, !dbg !2541

cond.true136:                                     ; preds = %sw.bb129
  %34 = load i64, ptr %data227, align 8, !dbg !2541, !tbaa !1240
  br label %cond.end140, !dbg !2541

cond.end140:                                      ; preds = %sw.bb129, %cond.true136
  %cond141 = phi i64 [ %34, %cond.true136 ], [ 0, %sw.bb129 ], !dbg !2541
  %call142 = call ptr @itoa_u64(i64 noundef %cond141, ptr noundef nonnull %add.ptr131) #13, !dbg !2542
  tail call void @llvm.dbg.value(metadata ptr %call142, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %for.inc, !dbg !2543

sw.bb143:                                         ; preds = %for.body
  store i8 32, ptr %p.1784, align 1, !dbg !2544, !tbaa !1240
  %add.ptr144 = getelementptr inbounds i8, ptr %p.1784, i64 1, !dbg !2544
  store i8 102, ptr %add.ptr144, align 1, !dbg !2544, !tbaa !1240
  %add.ptr145 = getelementptr inbounds i8, ptr %p.1784, i64 2, !dbg !2544
  tail call void @llvm.dbg.value(metadata ptr %add.ptr145, metadata !2374, metadata !DIExpression()), !dbg !2378
  %35 = load i16, ptr %it_flags208, align 2, !dbg !2546, !tbaa !1248
  %conv147 = zext i16 %35 to i32, !dbg !2546
  %36 = and i32 %conv147, 256, !dbg !2548
  %cmp151 = icmp eq i32 %36, 0, !dbg !2548
  br i1 %cmp151, label %if.then153, label %if.else154, !dbg !2549

if.then153:                                       ; preds = %sw.bb143
  store i8 48, ptr %add.ptr145, align 1, !dbg !2550, !tbaa !1240
  %incdec.ptr = getelementptr inbounds i8, ptr %p.1784, i64 3, !dbg !2552
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %for.inc, !dbg !2553

if.else154:                                       ; preds = %sw.bb143
  %37 = load i8, ptr %nkey234, align 1, !dbg !2554, !tbaa !1240
  %idx.ext158 = zext i8 %37 to i64
  %gep = getelementptr inbounds i8, ptr %invariant.gep, i64 %idx.ext158, !dbg !2554
  %and163 = shl nuw nsw i32 %conv147, 2, !dbg !2554
  %38 = and i32 %and163, 8, !dbg !2554
  %cond165 = zext nneg i32 %38 to i64, !dbg !2554
  %add.ptr166 = getelementptr inbounds i8, ptr %gep, i64 %cond165, !dbg !2554
  %39 = load i32, ptr %add.ptr166, align 4, !dbg !2556, !tbaa !1231
  %conv167 = zext i32 %39 to i64, !dbg !2556
  %call168 = call ptr @itoa_u64(i64 noundef %conv167, ptr noundef nonnull %add.ptr145) #13, !dbg !2557
  tail call void @llvm.dbg.value(metadata ptr %call168, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %for.inc

sw.bb170:                                         ; preds = %for.body
  store i8 32, ptr %p.1784, align 1, !dbg !2558, !tbaa !1240
  %add.ptr171 = getelementptr inbounds i8, ptr %p.1784, i64 1, !dbg !2558
  store i8 108, ptr %add.ptr171, align 1, !dbg !2558, !tbaa !1240
  %add.ptr172 = getelementptr inbounds i8, ptr %p.1784, i64 2, !dbg !2558
  tail call void @llvm.dbg.value(metadata ptr %add.ptr172, metadata !2374, metadata !DIExpression()), !dbg !2378
  %40 = load volatile i32, ptr @current_time, align 4, !dbg !2560, !tbaa !1231
  %41 = load i32, ptr %time, align 8, !dbg !2561, !tbaa !1231
  %sub173 = sub i32 %40, %41, !dbg !2562
  %call174 = call ptr @itoa_u32(i32 noundef %sub173, ptr noundef nonnull %add.ptr172) #13, !dbg !2563
  tail call void @llvm.dbg.value(metadata ptr %call174, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %for.inc, !dbg !2564

sw.bb175:                                         ; preds = %for.body
  store i8 32, ptr %p.1784, align 1, !dbg !2565, !tbaa !1240
  %add.ptr176 = getelementptr inbounds i8, ptr %p.1784, i64 1, !dbg !2565
  store i8 104, ptr %add.ptr176, align 1, !dbg !2565, !tbaa !1240
  %add.ptr177 = getelementptr inbounds i8, ptr %p.1784, i64 2, !dbg !2565
  tail call void @llvm.dbg.value(metadata ptr %add.ptr177, metadata !2374, metadata !DIExpression()), !dbg !2378
  %42 = load i16, ptr %it_flags208, align 2, !dbg !2567, !tbaa !1248
  %43 = and i16 %42, 8, !dbg !2569
  %tobool181.not = icmp eq i16 %43, 0, !dbg !2569
  %. = select i1 %tobool181.not, i8 48, i8 49
  store i8 %., ptr %add.ptr177, align 1, !dbg !2570, !tbaa !1240
  %incdec.ptr185 = getelementptr inbounds i8, ptr %p.1784, i64 3, !dbg !2571
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr185, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %for.inc, !dbg !2572

sw.bb186:                                         ; preds = %for.body
  %length189 = getelementptr inbounds i8, ptr %arrayidx81, i64 8, !dbg !2573
  %44 = load i64, ptr %length189, align 8, !dbg !2573, !tbaa !1578
  %cmp190 = icmp ugt i64 %44, 32, !dbg !2575
  br i1 %cmp190, label %error.thread, label %if.end193, !dbg !2576

error.thread:                                     ; preds = %sw.bb186
  store ptr @.str.52, ptr %errstr, align 8, !dbg !2378, !tbaa !1271, !DIAssignID !2577
  tail call void @llvm.dbg.label(metadata !2376), !dbg !2578
  br label %if.then515, !dbg !2579

if.end193:                                        ; preds = %sw.bb186
  store i8 32, ptr %p.1784, align 1, !dbg !2580, !tbaa !1240
  %incdec.ptr194 = getelementptr inbounds i8, ptr %p.1784, i64 1, !dbg !2580
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr194, metadata !2374, metadata !DIExpression()), !dbg !2378
  %45 = load ptr, ptr %arrayidx81, align 8, !dbg !2582, !tbaa !1573
  %46 = load i64, ptr %length189, align 8, !dbg !2583, !tbaa !1578
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %incdec.ptr194, ptr align 1 %45, i64 %46, i1 false), !dbg !2584
  %47 = load i64, ptr %length189, align 8, !dbg !2585, !tbaa !1578
  %add.ptr204 = getelementptr inbounds i8, ptr %incdec.ptr194, i64 %47, !dbg !2586
  tail call void @llvm.dbg.value(metadata ptr %add.ptr204, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %for.inc, !dbg !2587

sw.bb205:                                         ; preds = %for.body
  store i8 32, ptr %p.1784, align 1, !dbg !2588, !tbaa !1240
  %add.ptr206 = getelementptr inbounds i8, ptr %p.1784, i64 1, !dbg !2588
  store i8 107, ptr %add.ptr206, align 1, !dbg !2588, !tbaa !1240
  %add.ptr207 = getelementptr inbounds i8, ptr %p.1784, i64 2, !dbg !2588
  tail call void @llvm.dbg.value(metadata ptr %add.ptr207, metadata !2374, metadata !DIExpression()), !dbg !2378
  %48 = load i16, ptr %it_flags208, align 2, !dbg !2591, !tbaa !1248
  %conv209 = zext i16 %48 to i32, !dbg !2591
  %and210 = and i32 %conv209, 4096, !dbg !2591
  %tobool211.not = icmp eq i32 %and210, 0, !dbg !2591
  %and216 = shl nuw nsw i32 %conv209, 2, !dbg !2591
  %49 = and i32 %and216, 8, !dbg !2591
  %cond218 = zext nneg i32 %49 to i64, !dbg !2591
  %add.ptr219 = getelementptr inbounds i8, ptr %data227, i64 %cond218, !dbg !2591
  %50 = load i8, ptr %nkey234, align 1, !dbg !2591, !tbaa !1240
  %conv221 = zext i8 %50 to i64, !dbg !2591
  br i1 %tobool211.not, label %if.then212, label %if.else226, !dbg !2593

if.then212:                                       ; preds = %sw.bb205
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr207, ptr nonnull align 1 %add.ptr219, i64 %conv221, i1 false), !dbg !2594
  %51 = load i8, ptr %nkey234, align 1, !dbg !2594, !tbaa !1240
  %idx.ext224 = zext i8 %51 to i64
  %add.ptr225 = getelementptr inbounds i8, ptr %add.ptr207, i64 %idx.ext224, !dbg !2594
  tail call void @llvm.dbg.value(metadata ptr %add.ptr225, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %for.inc, !dbg !2594

if.else226:                                       ; preds = %sw.bb205
  %call236 = call i64 @base64_encode(ptr noundef nonnull %add.ptr219, i64 noundef %conv221, ptr noundef nonnull %add.ptr207, i64 noundef 512) #13, !dbg !2596
  %add.ptr237 = getelementptr inbounds i8, ptr %add.ptr207, i64 %call236, !dbg !2596
  tail call void @llvm.dbg.value(metadata ptr %add.ptr237, metadata !2374, metadata !DIExpression()), !dbg !2378
  store i8 32, ptr %add.ptr237, align 1, !dbg !2596, !tbaa !1240
  %add.ptr238 = getelementptr inbounds i8, ptr %add.ptr237, i64 1, !dbg !2596
  store i8 98, ptr %add.ptr238, align 1, !dbg !2596, !tbaa !1240
  %add.ptr239 = getelementptr inbounds i8, ptr %add.ptr237, i64 2, !dbg !2596
  tail call void @llvm.dbg.value(metadata ptr %add.ptr239, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %for.inc

for.inc:                                          ; preds = %land.lhs.true103, %sw.bb91, %sw.bb, %sw.bb109, %cond.end140, %sw.bb170, %sw.bb175, %if.end193, %for.body, %if.then88, %sw.bb86, %land.lhs.true99, %if.else124, %if.then121, %if.else154, %if.then153, %if.else226, %if.then212
  %won_token.1 = phi i1 [ %won_token.0782, %for.body ], [ %won_token.0782, %if.else226 ], [ %won_token.0782, %if.then212 ], [ %won_token.0782, %if.end193 ], [ %won_token.0782, %sw.bb175 ], [ %won_token.0782, %sw.bb170 ], [ %won_token.0782, %if.then153 ], [ %won_token.0782, %if.else154 ], [ %won_token.0782, %cond.end140 ], [ %won_token.0782, %if.then121 ], [ %won_token.0782, %if.else124 ], [ %won_token.0782, %sw.bb109 ], [ %won_token.0782, %land.lhs.true99 ], [ %won_token.0782, %sw.bb91 ], [ true, %if.then88 ], [ %won_token.0782, %sw.bb86 ], [ %won_token.0782, %sw.bb ], [ %spec.select, %land.lhs.true103 ], !dbg !2378
  %ttl_set.1 = phi i8 [ %ttl_set.0783, %for.body ], [ %ttl_set.0783, %if.else226 ], [ %ttl_set.0783, %if.then212 ], [ %ttl_set.0783, %if.end193 ], [ %ttl_set.0783, %sw.bb175 ], [ %ttl_set.0783, %sw.bb170 ], [ %ttl_set.0783, %if.then153 ], [ %ttl_set.0783, %if.else154 ], [ %ttl_set.0783, %cond.end140 ], [ %ttl_set.0783, %if.then121 ], [ %ttl_set.0783, %if.else124 ], [ %ttl_set.0783, %sw.bb109 ], [ %ttl_set.0783, %land.lhs.true99 ], [ %ttl_set.0783, %sw.bb91 ], [ %ttl_set.0783, %if.then88 ], [ %ttl_set.0783, %sw.bb86 ], [ 1, %sw.bb ], [ %ttl_set.0783, %land.lhs.true103 ], !dbg !2378
  %p.2 = phi ptr [ %p.1784, %for.body ], [ %add.ptr239, %if.else226 ], [ %add.ptr225, %if.then212 ], [ %add.ptr204, %if.end193 ], [ %incdec.ptr185, %sw.bb175 ], [ %call174, %sw.bb170 ], [ %incdec.ptr, %if.then153 ], [ %call168, %if.else154 ], [ %call142, %cond.end140 ], [ %add.ptr123, %if.then121 ], [ %call127, %if.else124 ], [ %call114, %sw.bb109 ], [ %p.1784, %land.lhs.true99 ], [ %p.1784, %sw.bb91 ], [ %p.1784, %if.then88 ], [ %p.1784, %sw.bb86 ], [ %p.1784, %sw.bb ], [ %p.1784, %land.lhs.true103 ], !dbg !2598
  tail call void @llvm.dbg.value(metadata ptr %p.2, metadata !2374, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i8 %ttl_set.1, metadata !2371, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2370, metadata !DIExpression()), !dbg !2378
  %inc = add i32 %i.0781, 1, !dbg !2599
  tail call void @llvm.dbg.value(metadata i32 %inc, metadata !2340, metadata !DIExpression()), !dbg !2378
  %conv77 = zext i32 %inc to i64, !dbg !2600
  %cmp79 = icmp ugt i64 %sub78, %conv77, !dbg !2485
  br i1 %cmp79, label %for.body, label %for.end, !dbg !2488, !llvm.loop !2601

for.end:                                          ; preds = %for.inc, %if.end76
  %won_token.0.lcssa = phi i1 [ false, %if.end76 ], [ %won_token.1, %for.inc ], !dbg !2603
  %ttl_set.0.lcssa = phi i8 [ 0, %if.end76 ], [ %ttl_set.1, %for.inc ], !dbg !2604
  %p.1.lcssa = phi ptr [ %p.0, %if.end76 ], [ %p.2, %for.inc ], !dbg !2605
  %it_flags241 = getelementptr inbounds i8, ptr %it.1, i64 38, !dbg !2606
  %52 = load i16, ptr %it_flags241, align 2, !dbg !2606, !tbaa !1248
  %53 = and i16 %52, 512, !dbg !2608
  %tobool244.not = icmp eq i16 %53, 0, !dbg !2608
  br i1 %tobool244.not, label %if.end248, label %if.then245, !dbg !2609

if.then245:                                       ; preds = %for.end
  store i8 32, ptr %p.1.lcssa, align 1, !dbg !2610, !tbaa !1240
  %add.ptr246 = getelementptr inbounds i8, ptr %p.1.lcssa, i64 1, !dbg !2610
  store i8 90, ptr %add.ptr246, align 1, !dbg !2610, !tbaa !1240
  %add.ptr247 = getelementptr inbounds i8, ptr %p.1.lcssa, i64 2, !dbg !2610
  tail call void @llvm.dbg.value(metadata ptr %add.ptr247, metadata !2374, metadata !DIExpression()), !dbg !2378
  %.pre = load i16, ptr %it_flags241, align 2, !dbg !2613, !tbaa !1248
  br label %if.end248, !dbg !2615

if.end248:                                        ; preds = %if.then245, %for.end
  %54 = phi i16 [ %.pre, %if.then245 ], [ %52, %for.end ], !dbg !2613
  %p.3 = phi ptr [ %add.ptr247, %if.then245 ], [ %p.1.lcssa, %for.end ], !dbg !2598
  tail call void @llvm.dbg.value(metadata ptr %p.3, metadata !2374, metadata !DIExpression()), !dbg !2378
  %55 = and i16 %54, 2048, !dbg !2616
  %tobool252.not = icmp eq i16 %55, 0, !dbg !2616
  br i1 %tobool252.not, label %if.end263, label %if.then253, !dbg !2617

if.then253:                                       ; preds = %if.end248
  store i8 32, ptr %p.3, align 1, !dbg !2618, !tbaa !1240
  %add.ptr254 = getelementptr inbounds i8, ptr %p.3, i64 1, !dbg !2618
  store i8 88, ptr %add.ptr254, align 1, !dbg !2618, !tbaa !1240
  %add.ptr255 = getelementptr inbounds i8, ptr %p.3, i64 2, !dbg !2618
  tail call void @llvm.dbg.value(metadata ptr %add.ptr255, metadata !2374, metadata !DIExpression()), !dbg !2378
  %56 = load i16, ptr %it_flags241, align 2, !dbg !2621, !tbaa !1248
  %57 = and i16 %56, 512, !dbg !2623
  %cmp259 = icmp eq i16 %57, 0, !dbg !2624
  %spec.select760 = select i1 %cmp259, i1 true, i1 %won_token.0.lcssa, !dbg !2625
  tail call void @llvm.dbg.value(metadata ptr %add.ptr255, metadata !2374, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2370, metadata !DIExpression()), !dbg !2378
  br i1 %spec.select760, label %if.then265, label %if.end271, !dbg !2626

if.end263:                                        ; preds = %if.end248
  tail call void @llvm.dbg.value(metadata ptr %p.3, metadata !2374, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2370, metadata !DIExpression()), !dbg !2378
  br i1 %won_token.0.lcssa, label %if.then265, label %if.end271, !dbg !2626

if.then265:                                       ; preds = %if.then253, %if.end263
  %p.4793 = phi ptr [ %add.ptr255, %if.then253 ], [ %p.3, %if.end263 ]
  store i8 32, ptr %p.4793, align 1, !dbg !2627, !tbaa !1240
  %add.ptr266 = getelementptr inbounds i8, ptr %p.4793, i64 1, !dbg !2627
  store i8 87, ptr %add.ptr266, align 1, !dbg !2627, !tbaa !1240
  %add.ptr267 = getelementptr inbounds i8, ptr %p.4793, i64 2, !dbg !2627
  tail call void @llvm.dbg.value(metadata ptr %add.ptr267, metadata !2374, metadata !DIExpression()), !dbg !2378
  %58 = load i16, ptr %it_flags241, align 2, !dbg !2631, !tbaa !1248
  %59 = or i16 %58, 512, !dbg !2631
  store i16 %59, ptr %it_flags241, align 2, !dbg !2631, !tbaa !1248
  br label %if.end271, !dbg !2632

if.end271:                                        ; preds = %if.then253, %if.then265, %if.end263
  %p.5 = phi ptr [ %add.ptr267, %if.then265 ], [ %p.3, %if.end263 ], [ %add.ptr255, %if.then253 ], !dbg !2598
  tail call void @llvm.dbg.value(metadata ptr %p.5, metadata !2374, metadata !DIExpression()), !dbg !2378
  store i8 13, ptr %p.5, align 1, !dbg !2633, !tbaa !1240
  %add.ptr272 = getelementptr inbounds i8, ptr %p.5, i64 1, !dbg !2634
  store i8 10, ptr %add.ptr272, align 1, !dbg !2635, !tbaa !1240
  %add.ptr273 = getelementptr inbounds i8, ptr %p.5, i64 2, !dbg !2636
  store i8 0, ptr %add.ptr273, align 1, !dbg !2637, !tbaa !1240
  tail call void @llvm.dbg.value(metadata ptr %add.ptr273, metadata !2374, metadata !DIExpression()), !dbg !2378
  %sub.ptr.lhs.cast = ptrtoint ptr %add.ptr273 to i64, !dbg !2638
  %sub.ptr.rhs.cast = ptrtoint ptr %wbuf to i64, !dbg !2638
  %sub.ptr.sub = sub i64 %sub.ptr.lhs.cast, %sub.ptr.rhs.cast, !dbg !2638
  %conv279 = trunc i64 %sub.ptr.sub to i32, !dbg !2639
  call void @resp_add_iov(ptr noundef %0, ptr noundef nonnull %wbuf, i32 noundef %conv279) #13, !dbg !2640
  %bf.load280 = load i16, ptr %of, align 8, !dbg !2641
  %60 = and i16 %bf.load280, 64, !dbg !2643
  %tobool284.not = icmp eq i16 %60, 0, !dbg !2643
  br i1 %tobool284.not, label %if.then337, label %if.then285, !dbg !2644

if.then285:                                       ; preds = %if.end271
  %61 = load i16, ptr %it_flags241, align 2, !dbg !2645, !tbaa !1248
  %conv287 = zext i16 %61 to i32, !dbg !2648
  %and288 = and i32 %conv287, 128, !dbg !2649
  %tobool289.not = icmp eq i32 %and288, 0, !dbg !2649
  br i1 %tobool289.not, label %if.else305, label %if.then290, !dbg !2650

if.then290:                                       ; preds = %if.then285
  %call291 = call i32 @storage_get_item(ptr noundef %c, ptr noundef nonnull %it.1, ptr noundef %0) #13, !dbg !2651
  %cmp292.not = icmp eq i32 %call291, 0, !dbg !2654
  br i1 %cmp292.not, label %if.then337, label %if.else353, !dbg !2655

if.else305:                                       ; preds = %if.then285
  %and308 = and i32 %conv287, 32, !dbg !2656
  %cmp309 = icmp eq i32 %and308, 0, !dbg !2658
  br i1 %cmp309, label %if.then311, label %if.else331, !dbg !2659

if.then311:                                       ; preds = %if.else305
  %data312 = getelementptr inbounds i8, ptr %it.1, i64 48, !dbg !2660
  %nkey313 = getelementptr inbounds i8, ptr %it.1, i64 41, !dbg !2660
  %62 = load i8, ptr %nkey313, align 1, !dbg !2660, !tbaa !1240
  %idx.ext315 = zext i8 %62 to i64
  %add.ptr316 = getelementptr inbounds i8, ptr %data312, i64 %idx.ext315, !dbg !2660
  %add.ptr317 = getelementptr inbounds i8, ptr %add.ptr316, i64 1, !dbg !2660
  %and320 = lshr i32 %conv287, 6, !dbg !2660
  %63 = and i32 %and320, 4, !dbg !2660
  %cond322 = zext nneg i32 %63 to i64, !dbg !2660
  %add.ptr323 = getelementptr inbounds i8, ptr %add.ptr317, i64 %cond322, !dbg !2660
  %and326 = shl nuw nsw i32 %conv287, 2, !dbg !2660
  %64 = and i32 %and326, 8, !dbg !2660
  %cond328 = zext nneg i32 %64 to i64, !dbg !2660
  %add.ptr329 = getelementptr inbounds i8, ptr %add.ptr323, i64 %cond328, !dbg !2660
  %nbytes330 = getelementptr inbounds i8, ptr %it.1, i64 32, !dbg !2662
  %65 = load i32, ptr %nbytes330, align 8, !dbg !2662, !tbaa !1231
  call void @resp_add_iov(ptr noundef %0, ptr noundef nonnull %add.ptr329, i32 noundef %65) #13, !dbg !2663
  br label %if.then337, !dbg !2664

if.else331:                                       ; preds = %if.else305
  %nbytes332 = getelementptr inbounds i8, ptr %it.1, i64 32, !dbg !2665
  %66 = load i32, ptr %nbytes332, align 8, !dbg !2665, !tbaa !1231
  call void @resp_add_chunked_iov(ptr noundef %0, ptr noundef nonnull %it.1, i32 noundef %66) #13, !dbg !2667
  br label %if.then337

if.then337:                                       ; preds = %if.then290, %if.then311, %if.else331, %if.end271
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2368, metadata !DIExpression()), !dbg !2378
  %67 = load i16, ptr %it_flags241, align 2, !dbg !2668, !tbaa !1248
  %68 = and i16 %67, 128, !dbg !2672
  %cmp341.not = icmp eq i16 %68, 0, !dbg !2673
  br i1 %cmp341.not, label %if.else350, label %land.lhs.true343, !dbg !2674

land.lhs.true343:                                 ; preds = %if.then337
  %bf.load344 = load i16, ptr %of, align 8, !dbg !2675
  %69 = and i16 %bf.load344, 64, !dbg !2676
  %tobool348.not = icmp eq i16 %69, 0, !dbg !2676
  br i1 %tobool348.not, label %if.else350, label %if.then349, !dbg !2677

if.then349:                                       ; preds = %land.lhs.true343
  %item = getelementptr inbounds i8, ptr %0, i64 40, !dbg !2678
  store ptr null, ptr %item, align 8, !dbg !2680, !tbaa !2681
  br label %if.end364, !dbg !2682

if.else350:                                       ; preds = %land.lhs.true343, %if.then337
  %item351 = getelementptr inbounds i8, ptr %0, i64 40, !dbg !2683
  store ptr %it.1, ptr %item351, align 8, !dbg !2685, !tbaa !2681
  br label %if.end364

if.else353:                                       ; preds = %if.then290
  %thread295 = getelementptr inbounds i8, ptr %c, i64 456, !dbg !2686
  %70 = load ptr, ptr %thread295, align 8, !dbg !2686, !tbaa !1234
  %stats = getelementptr inbounds i8, ptr %70, i64 352, !dbg !2688
  %call296 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #13, !dbg !2689
  %71 = load ptr, ptr %thread295, align 8, !dbg !2690, !tbaa !1234
  %get_oom_extstore = getelementptr inbounds i8, ptr %71, i64 600, !dbg !2691
  %72 = load i64, ptr %get_oom_extstore, align 8, !dbg !2692, !tbaa !2693
  %inc299 = add i64 %72, 1, !dbg !2692
  store i64 %inc299, ptr %get_oom_extstore, align 8, !dbg !2692, !tbaa !2693
  %stats301 = getelementptr inbounds i8, ptr %71, i64 352, !dbg !2694
  %call303 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats301) #13, !dbg !2695
  tail call void @llvm.dbg.value(metadata i8 1, metadata !2368, metadata !DIExpression()), !dbg !2378
  %bf.load354 = load i16, ptr %of, align 8, !dbg !2696
  %73 = and i16 %bf.load354, 4, !dbg !2699
  %tobool358.not = icmp eq i16 %73, 0, !dbg !2699
  br i1 %tobool358.not, label %if.else360, label %if.then359, !dbg !2700

if.then359:                                       ; preds = %if.else353
  call void @do_item_remove(ptr noundef nonnull %it.1) #13, !dbg !2701
  br label %if.end364, !dbg !2703

if.else360:                                       ; preds = %if.else353
  call void @item_remove(ptr noundef nonnull %it.1) #13, !dbg !2704
  br label %if.end364

if.end364:                                        ; preds = %land.lhs.true, %if.then38, %if.else350, %if.then349, %if.else360, %if.then359
  %tobool64.not769 = phi i1 [ false, %if.then359 ], [ false, %if.else360 ], [ false, %if.then349 ], [ false, %if.else350 ], [ true, %if.then38 ], [ true, %land.lhs.true ]
  %it.1765 = phi ptr [ %it.1, %if.then359 ], [ %it.1, %if.else360 ], [ %it.1, %if.then349 ], [ %it.1, %if.else350 ], [ null, %if.then38 ], [ null, %land.lhs.true ]
  %failed.1 = phi i1 [ true, %if.then359 ], [ true, %if.else360 ], [ false, %if.then349 ], [ false, %if.else350 ], [ true, %if.then38 ], [ true, %land.lhs.true ], !dbg !2706
  %ttl_set.2 = phi i8 [ %ttl_set.0.lcssa, %if.then359 ], [ %ttl_set.0.lcssa, %if.else360 ], [ %ttl_set.0.lcssa, %if.then349 ], [ %ttl_set.0.lcssa, %if.else350 ], [ 0, %if.then38 ], [ 0, %land.lhs.true ], !dbg !2604
  %p.6 = phi ptr [ %add.ptr273, %if.then359 ], [ %add.ptr273, %if.else360 ], [ %add.ptr273, %if.then349 ], [ %add.ptr273, %if.else350 ], [ %wbuf, %if.then38 ], [ %wbuf, %land.lhs.true ], !dbg !2378
  tail call void @llvm.dbg.value(metadata ptr %p.6, metadata !2374, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i8 %ttl_set.2, metadata !2371, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2368, metadata !DIExpression()), !dbg !2378
  %bf.load365 = load i16, ptr %of, align 8, !dbg !2707
  %74 = and i16 %bf.load365, 4, !dbg !2709
  %tobool369.not = icmp eq i16 %74, 0, !dbg !2709
  br i1 %tobool369.not, label %if.end382, label %if.then370, !dbg !2710

if.then370:                                       ; preds = %if.end364
  %75 = and i16 %bf.load365, 2, !dbg !2711
  %tobool375.not = icmp ne i16 %75, 0, !dbg !2711
  %brmerge761 = or i1 %tobool64.not769, %tobool375.not, !dbg !2714
  br i1 %brmerge761, label %if.end381, label %if.then379, !dbg !2714

if.then379:                                       ; preds = %if.then370
  %thread380 = getelementptr inbounds i8, ptr %c, i64 456, !dbg !2715
  %76 = load ptr, ptr %thread380, align 8, !dbg !2715, !tbaa !1234
  %77 = load i32, ptr %hv, align 4, !dbg !2717, !tbaa !1231
  call void @do_item_bump(ptr noundef %76, ptr noundef %it.1765, i32 noundef %77) #13, !dbg !2718
  br label %if.end381, !dbg !2719

if.end381:                                        ; preds = %if.then370, %if.then379
  %78 = load i32, ptr %hv, align 4, !dbg !2720, !tbaa !1231
  call void @item_unlock(i32 noundef %78) #13, !dbg !2721
  br label %if.end382, !dbg !2722

if.end382:                                        ; preds = %if.end381, %if.end364
  %thread417 = getelementptr inbounds i8, ptr %c, i64 456, !dbg !2723
  %79 = load ptr, ptr %thread417, align 8, !dbg !2723, !tbaa !1234
  %stats418 = getelementptr inbounds i8, ptr %79, i64 352, !dbg !2723
  %call420 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats418) #13, !dbg !2723
  %tobool421 = trunc nuw i8 %ttl_set.2 to i1, !dbg !2723
  %80 = load ptr, ptr %thread417, align 8, !dbg !2723, !tbaa !1234
  br i1 %failed.1, label %if.else416, label %if.then384, !dbg !2725

if.then384:                                       ; preds = %if.end382
  br i1 %tobool421, label %if.then390, label %if.else401, !dbg !2726

if.then390:                                       ; preds = %if.then384
  %touch_cmds = getelementptr inbounds i8, ptr %80, i64 424, !dbg !2728
  %81 = load i64, ptr %touch_cmds, align 8, !dbg !2731, !tbaa !2732
  %inc393 = add i64 %81, 1, !dbg !2731
  store i64 %inc393, ptr %touch_cmds, align 8, !dbg !2731, !tbaa !2732
  %slab_stats = getelementptr inbounds i8, ptr %80, i64 632, !dbg !2733
  %slabs_clsid = getelementptr inbounds i8, ptr %it.1765, i64 40, !dbg !2734
  %82 = load i8, ptr %slabs_clsid, align 8, !dbg !2734, !tbaa !1240
  %83 = and i8 %82, 63, !dbg !2734
  %idxprom398 = zext nneg i8 %83 to i64
  %touch_hits = getelementptr inbounds [64 x %struct.slab_stats], ptr %slab_stats, i64 0, i64 %idxprom398, i32 2, !dbg !2735
  br label %if.end411, !dbg !2736

if.else401:                                       ; preds = %if.then384
  %lru_hits = getelementptr inbounds i8, ptr %80, i64 4728, !dbg !2737
  %slabs_clsid404 = getelementptr inbounds i8, ptr %it.1765, i64 40, !dbg !2739
  %84 = load i8, ptr %slabs_clsid404, align 8, !dbg !2739, !tbaa !1240
  %idxprom405 = zext i8 %84 to i64, !dbg !2740
  %arrayidx406 = getelementptr inbounds [256 x i64], ptr %lru_hits, i64 0, i64 %idxprom405, !dbg !2740
  %85 = load i64, ptr %arrayidx406, align 8, !dbg !2741, !tbaa !1308
  %inc407 = add i64 %85, 1, !dbg !2741
  store i64 %inc407, ptr %arrayidx406, align 8, !dbg !2741, !tbaa !1308
  %get_cmds = getelementptr inbounds i8, ptr %80, i64 392, !dbg !2742
  br label %if.end411

if.end411:                                        ; preds = %if.else401, %if.then390
  %get_cmds.sink794 = phi ptr [ %get_cmds, %if.else401 ], [ %touch_hits, %if.then390 ]
  %86 = load i64, ptr %get_cmds.sink794, align 8, !dbg !2743, !tbaa !1308
  %inc410 = add i64 %86, 1, !dbg !2743
  store i64 %inc410, ptr %get_cmds.sink794, align 8, !dbg !2743, !tbaa !1308
  %stats413 = getelementptr inbounds i8, ptr %80, i64 352, !dbg !2744
  %call415 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats413) #13, !dbg !2745
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 1) #13, !dbg !2746
  br label %cleanup, !dbg !2747

if.else416:                                       ; preds = %if.end382
  %.799 = select i1 %tobool421, i64 424, i64 400
  %.800 = select i1 %tobool421, i64 432, i64 392
  %get_misses = getelementptr inbounds i8, ptr %80, i64 %.799, !dbg !2748
  %87 = load i64, ptr %get_misses, align 8, !dbg !2748, !tbaa !1308
  %inc433 = add i64 %87, 1, !dbg !2748
  store i64 %inc433, ptr %get_misses, align 8, !dbg !2748, !tbaa !1308
  %get_cmds436 = getelementptr inbounds i8, ptr %80, i64 %.800, !dbg !2748
  %88 = load i64, ptr %get_cmds436, align 8, !dbg !2748, !tbaa !1308
  %inc437 = add i64 %88, 1, !dbg !2748
  store i64 %inc437, ptr %get_cmds436, align 8, !dbg !2748, !tbaa !1308
  %stats440 = getelementptr inbounds i8, ptr %80, i64 352, !dbg !2751
  %call442 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats440) #13, !dbg !2752
  %89 = load i8, ptr %noreply, align 4, !dbg !2753, !tbaa !1302, !range !1296, !noundef !1297
  %tobool444 = trunc nuw i8 %89 to i1, !dbg !2753
  br i1 %tobool444, label %if.then445, label %if.end446, !dbg !2755

if.then445:                                       ; preds = %if.else416
  %skip = getelementptr inbounds i8, ptr %0, i64 118, !dbg !2756
  store i8 1, ptr %skip, align 2, !dbg !2757, !tbaa !1367
  br label %if.end446, !dbg !2758

if.end446:                                        ; preds = %if.then445, %if.else416
  store i16 20037, ptr %p.6, align 1, !dbg !2759
  %add.ptr447 = getelementptr inbounds i8, ptr %p.6, i64 2, !dbg !2760
  tail call void @llvm.dbg.value(metadata ptr %add.ptr447, metadata !2374, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i32 2, metadata !2340, metadata !DIExpression()), !dbg !2378
  %sub450 = add nsw i64 %ntokens, -1
  %cmp451788 = icmp ugt i64 %sub450, 2, !dbg !2761
  br i1 %cmp451788, label %for.body453, label %for.end497, !dbg !2764

for.body453:                                      ; preds = %if.end446, %for.inc495
  %conv449791 = phi i64 [ %conv449, %for.inc495 ], [ 2, %if.end446 ]
  %p.7790 = phi ptr [ %p.8, %for.inc495 ], [ %add.ptr447, %if.end446 ]
  %i.1789 = phi i32 [ %inc496, %for.inc495 ], [ 2, %if.end446 ]
  tail call void @llvm.dbg.value(metadata ptr %p.7790, metadata !2374, metadata !DIExpression()), !dbg !2378
  tail call void @llvm.dbg.value(metadata i32 %i.1789, metadata !2340, metadata !DIExpression()), !dbg !2378
  %arrayidx455 = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %conv449791, !dbg !2765
  %90 = load ptr, ptr %arrayidx455, align 8, !dbg !2767, !tbaa !1573
  %91 = load i8, ptr %90, align 1, !dbg !2765, !tbaa !1240
  switch i8 %91, label %for.inc495 [
    i8 79, label %sw.bb459
    i8 107, label %sw.bb478
  ], !dbg !2768

sw.bb459:                                         ; preds = %for.body453
  %length462 = getelementptr inbounds i8, ptr %arrayidx455, i64 8, !dbg !2769
  %92 = load i64, ptr %length462, align 8, !dbg !2769, !tbaa !1578
  %cmp463 = icmp ugt i64 %92, 32, !dbg !2772
  br i1 %cmp463, label %error, label %if.end466, !dbg !2773

if.end466:                                        ; preds = %sw.bb459
  store i8 32, ptr %p.7790, align 1, !dbg !2774, !tbaa !1240
  %incdec.ptr467 = getelementptr inbounds i8, ptr %p.7790, i64 1, !dbg !2774
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr467, metadata !2374, metadata !DIExpression()), !dbg !2378
  %93 = load ptr, ptr %arrayidx455, align 8, !dbg !2776, !tbaa !1573
  %94 = load i64, ptr %length462, align 8, !dbg !2777, !tbaa !1578
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %incdec.ptr467, ptr align 1 %93, i64 %94, i1 false), !dbg !2778
  %95 = load i64, ptr %length462, align 8, !dbg !2779, !tbaa !1578
  %add.ptr477 = getelementptr inbounds i8, ptr %incdec.ptr467, i64 %95, !dbg !2780
  tail call void @llvm.dbg.value(metadata ptr %add.ptr477, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %for.inc495, !dbg !2781

sw.bb478:                                         ; preds = %for.body453
  store i8 32, ptr %p.7790, align 1, !dbg !2782, !tbaa !1240
  %add.ptr479 = getelementptr inbounds i8, ptr %p.7790, i64 1, !dbg !2782
  store i8 107, ptr %add.ptr479, align 1, !dbg !2782, !tbaa !1240
  %add.ptr480 = getelementptr inbounds i8, ptr %p.7790, i64 2, !dbg !2782
  tail call void @llvm.dbg.value(metadata ptr %add.ptr480, metadata !2374, metadata !DIExpression()), !dbg !2378
  %bf.load481 = load i16, ptr %of, align 8, !dbg !2785
  %96 = and i16 %bf.load481, 4096, !dbg !2785
  %tobool485.not = icmp eq i16 %96, 0, !dbg !2785
  br i1 %tobool485.not, label %if.then486, label %if.else488, !dbg !2787

if.then486:                                       ; preds = %sw.bb478
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr480, ptr align 1 %5, i64 %6, i1 false), !dbg !2788
  %add.ptr487 = getelementptr inbounds i8, ptr %add.ptr480, i64 %6, !dbg !2788
  tail call void @llvm.dbg.value(metadata ptr %add.ptr487, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %for.inc495, !dbg !2788

if.else488:                                       ; preds = %sw.bb478
  %call489 = call i64 @base64_encode(ptr noundef %5, i64 noundef %6, ptr noundef nonnull %add.ptr480, i64 noundef 512) #13, !dbg !2790
  %add.ptr490 = getelementptr inbounds i8, ptr %add.ptr480, i64 %call489, !dbg !2790
  tail call void @llvm.dbg.value(metadata ptr %add.ptr490, metadata !2374, metadata !DIExpression()), !dbg !2378
  store i8 32, ptr %add.ptr490, align 1, !dbg !2790, !tbaa !1240
  %add.ptr491 = getelementptr inbounds i8, ptr %add.ptr490, i64 1, !dbg !2790
  store i8 98, ptr %add.ptr491, align 1, !dbg !2790, !tbaa !1240
  %add.ptr492 = getelementptr inbounds i8, ptr %add.ptr490, i64 2, !dbg !2790
  tail call void @llvm.dbg.value(metadata ptr %add.ptr492, metadata !2374, metadata !DIExpression()), !dbg !2378
  br label %for.inc495

for.inc495:                                       ; preds = %if.end466, %for.body453, %if.else488, %if.then486
  %p.8 = phi ptr [ %p.7790, %for.body453 ], [ %add.ptr492, %if.else488 ], [ %add.ptr487, %if.then486 ], [ %add.ptr477, %if.end466 ], !dbg !2792
  tail call void @llvm.dbg.value(metadata ptr %p.8, metadata !2374, metadata !DIExpression()), !dbg !2378
  %inc496 = add i32 %i.1789, 1, !dbg !2793
  tail call void @llvm.dbg.value(metadata i32 %inc496, metadata !2340, metadata !DIExpression()), !dbg !2378
  %conv449 = zext i32 %inc496 to i64, !dbg !2794
  %cmp451 = icmp ugt i64 %sub450, %conv449, !dbg !2761
  br i1 %cmp451, label %for.body453, label %for.end497, !dbg !2764, !llvm.loop !2795

for.end497:                                       ; preds = %for.inc495, %if.end446
  %p.7.lcssa = phi ptr [ %add.ptr447, %if.end446 ], [ %p.8, %for.inc495 ], !dbg !2760
  %sub.ptr.lhs.cast500 = ptrtoint ptr %p.7.lcssa to i64, !dbg !2797
  %sub.ptr.rhs.cast501 = ptrtoint ptr %wbuf to i64, !dbg !2797
  %sub.ptr.sub502 = sub i64 %sub.ptr.lhs.cast500, %sub.ptr.rhs.cast501, !dbg !2797
  %conv503 = trunc i64 %sub.ptr.sub502 to i32, !dbg !2798
  %wbytes = getelementptr inbounds i8, ptr %0, i64 16, !dbg !2799
  store i32 %conv503, ptr %wbytes, align 8, !dbg !2800, !tbaa !1355
  %sext = shl i64 %sub.ptr.sub502, 32, !dbg !2801
  %idx.ext507 = ashr exact i64 %sext, 32, !dbg !2801
  %add.ptr508 = getelementptr inbounds i8, ptr %wbuf, i64 %idx.ext507, !dbg !2801
  store i16 2573, ptr %add.ptr508, align 1, !dbg !2802
  %97 = load i32, ptr %wbytes, align 8, !dbg !2803, !tbaa !1355
  %add = add nsw i32 %97, 2, !dbg !2803
  store i32 %add, ptr %wbytes, align 8, !dbg !2803, !tbaa !1355
  call void @resp_add_iov(ptr noundef %0, ptr noundef nonnull %wbuf, i32 noundef %add) #13, !dbg !2804
  call void @conn_set_state(ptr noundef %c, i32 noundef 1) #13, !dbg !2805
  br label %cleanup

error:                                            ; preds = %sw.bb459
  store ptr @.str.52, ptr %errstr, align 8, !dbg !2378, !tbaa !1271, !DIAssignID !2577
  tail call void @llvm.dbg.label(metadata !2376), !dbg !2578
  br i1 %tobool64.not769, label %if.end523, label %if.then515, !dbg !2579

if.then515:                                       ; preds = %error.thread, %error
  %it.1766775 = phi ptr [ %it.1, %error.thread ], [ %it.1765, %error ]
  call void @do_item_remove(ptr noundef %it.1766775) #13, !dbg !2806
  %bf.load516 = load i16, ptr %of, align 8, !dbg !2809
  %98 = and i16 %bf.load516, 4, !dbg !2811
  %tobool520.not = icmp eq i16 %98, 0, !dbg !2811
  br i1 %tobool520.not, label %if.end523, label %if.then521, !dbg !2812

if.then521:                                       ; preds = %if.then515
  %99 = load i32, ptr %hv, align 4, !dbg !2813, !tbaa !1231
  call void @item_unlock(i32 noundef %99) #13, !dbg !2815
  br label %if.end523, !dbg !2816

if.end523:                                        ; preds = %if.then515, %if.then521, %error
  %100 = load ptr, ptr %errstr, align 8, !dbg !2817, !tbaa !1271
  call void @out_errstring(ptr noundef %c, ptr noundef %100) #13, !dbg !2818
  br label %cleanup, !dbg !2819

cleanup:                                          ; preds = %if.end411, %for.end497, %if.end523, %if.then30
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %overflow) #13, !dbg !2819
  br label %cleanup524

cleanup524:                                       ; preds = %cleanup, %if.then9, %if.then6, %if.then3, %if.then
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %errstr) #13, !dbg !2819
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %hv) #13, !dbg !2819
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %of) #13, !dbg !2819
  ret void, !dbg !2819
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_mset_command(ptr noundef %c, ptr nocapture noundef %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !2820 {
entry:
  %of = alloca %struct._meta_flags, align 8, !DIAssignID !2844
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2830, metadata !DIExpression(), metadata !2844, metadata ptr %of, metadata !DIExpression()), !dbg !2845
  %errstr = alloca ptr, align 8, !DIAssignID !2846
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2831, metadata !DIExpression(), metadata !2846, metadata ptr %errstr, metadata !DIExpression()), !dbg !2845
  %hv = alloca i32, align 4, !DIAssignID !2847
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2832, metadata !DIExpression(), metadata !2847, metadata ptr %hv, metadata !DIExpression()), !dbg !2845
  %vlen = alloca i32, align 4, !DIAssignID !2848
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2833, metadata !DIExpression(), metadata !2848, metadata ptr %vlen, metadata !DIExpression()), !dbg !2845
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2822, metadata !DIExpression()), !dbg !2845
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !2823, metadata !DIExpression()), !dbg !2845
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !2824, metadata !DIExpression()), !dbg !2845
  tail call void @llvm.dbg.value(metadata i16 2, metadata !2829, metadata !DIExpression()), !dbg !2845
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %of) #13, !dbg !2849
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %of, i8 0, i64 56, i1 false), !dbg !2850, !DIAssignID !2851
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2830, metadata !DIExpression(), metadata !2851, metadata ptr %of, metadata !DIExpression()), !dbg !2845
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %errstr) #13, !dbg !2852
  store ptr @.str.48, ptr %errstr, align 8, !dbg !2853, !tbaa !1271, !DIAssignID !2854
  tail call void @llvm.dbg.assign(metadata ptr @.str.48, metadata !2831, metadata !DIExpression(), metadata !2854, metadata ptr %errstr, metadata !DIExpression()), !dbg !2845
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %hv) #13, !dbg !2855
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %vlen) #13, !dbg !2856
  store i32 0, ptr %vlen, align 4, !dbg !2857, !tbaa !1231, !DIAssignID !2858
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !2833, metadata !DIExpression(), metadata !2858, metadata ptr %vlen, metadata !DIExpression()), !dbg !2845
  %resp1 = getelementptr inbounds i8, ptr %c, i64 192, !dbg !2859
  %0 = load ptr, ptr %resp1, align 8, !dbg !2859, !tbaa !1351
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2834, metadata !DIExpression()), !dbg !2845
  %wbuf = getelementptr inbounds i8, ptr %0, i64 160, !dbg !2860
  tail call void @llvm.dbg.value(metadata ptr %wbuf, metadata !2835, metadata !DIExpression()), !dbg !2845
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2836, metadata !DIExpression()), !dbg !2845
  %cmp = icmp ult i64 %ntokens, 3, !dbg !2861
  br i1 %cmp, label %if.then, label %do.end, !dbg !2864

if.then:                                          ; preds = %entry
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.15) #13, !dbg !2865
  br label %cleanup, !dbg !2865

do.end:                                           ; preds = %entry
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !2867
  %length = getelementptr inbounds i8, ptr %tokens, i64 24, !dbg !2869
  %1 = load i64, ptr %length, align 8, !dbg !2869, !tbaa !1578
  %cmp2 = icmp ugt i64 %1, 250, !dbg !2870
  br i1 %cmp2, label %if.then3, label %if.end4, !dbg !2871

if.then3:                                         ; preds = %do.end
  tail call void @out_errstring(ptr noundef nonnull %c, ptr noundef nonnull @.str.48) #13, !dbg !2872
  br label %cleanup, !dbg !2874

if.end4:                                          ; preds = %do.end
  %cmp5 = icmp eq i64 %ntokens, 3, !dbg !2875
  br i1 %cmp5, label %if.then6, label %if.end7, !dbg !2877

if.then6:                                         ; preds = %if.end4
  tail call void @out_errstring(ptr noundef nonnull %c, ptr noundef nonnull @.str.48) #13, !dbg !2878
  br label %cleanup, !dbg !2880

if.end7:                                          ; preds = %if.end4
  %cmp8 = icmp ugt i64 %ntokens, 20, !dbg !2881
  br i1 %cmp8, label %if.then9, label %if.end10, !dbg !2883

if.then9:                                         ; preds = %if.end7
  tail call void @out_errstring(ptr noundef nonnull %c, ptr noundef nonnull @.str.61) #13, !dbg !2884
  br label %cleanup, !dbg !2886

if.end10:                                         ; preds = %if.end7
  tail call void @llvm.dbg.value(metadata ptr %wbuf, metadata !2835, metadata !DIExpression()), !dbg !2845
  %arrayidx13 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !2887
  %2 = load ptr, ptr %arrayidx13, align 8, !dbg !2889, !tbaa !1573
  %call = call zeroext i1 @safe_strtol(ptr noundef %2, ptr noundef nonnull %vlen) #13, !dbg !2890
  br i1 %call, label %if.end15, label %if.then14, !dbg !2891

if.then14:                                        ; preds = %if.end10
  call void @out_errstring(ptr noundef nonnull %c, ptr noundef nonnull @.str.48) #13, !dbg !2892
  br label %cleanup, !dbg !2894

if.end15:                                         ; preds = %if.end10
  %3 = load i32, ptr %vlen, align 4, !dbg !2895, !tbaa !1231
  %or.cond = icmp ugt i32 %3, 2147483645, !dbg !2897
  br i1 %or.cond, label %if.then18, label %if.end19, !dbg !2897

if.then18:                                        ; preds = %if.end15
  call void @out_errstring(ptr noundef nonnull %c, ptr noundef nonnull @.str.48) #13, !dbg !2898
  br label %cleanup, !dbg !2900

if.end19:                                         ; preds = %if.end15
  %add = add nuw nsw i32 %3, 2, !dbg !2901
  store i32 %add, ptr %vlen, align 4, !dbg !2901, !tbaa !1231, !DIAssignID !2902
  tail call void @llvm.dbg.assign(metadata i32 %add, metadata !2833, metadata !DIExpression(), metadata !2902, metadata ptr %vlen, metadata !DIExpression()), !dbg !2845
  %call20 = call fastcc i32 @_meta_flag_preparse(ptr noundef nonnull %tokens, i64 noundef 3, ptr noundef nonnull %of, ptr noundef nonnull %errstr), !dbg !2903
  %cmp21.not = icmp eq i32 %call20, 0, !dbg !2905
  br i1 %cmp21.not, label %if.end23, label %error, !dbg !2906

if.end23:                                         ; preds = %if.end19
  %4 = load ptr, ptr %arrayidx, align 8, !dbg !2907, !tbaa !1573
  tail call void @llvm.dbg.value(metadata ptr %4, metadata !2825, metadata !DIExpression()), !dbg !2845
  %5 = load i64, ptr %length, align 8, !dbg !2908, !tbaa !1578
  tail call void @llvm.dbg.value(metadata i64 %5, metadata !2826, metadata !DIExpression()), !dbg !2845
  %bf.load = load i16, ptr %of, align 8, !dbg !2909
  %noreply = getelementptr inbounds i8, ptr %c, i64 364, !dbg !2910
  %6 = lshr i16 %bf.load, 8, !dbg !2911
  %7 = trunc nuw i16 %6 to i8, !dbg !2911
  %frombool = and i8 %7, 1, !dbg !2911
  store i8 %frombool, ptr %noreply, align 4, !dbg !2911, !tbaa !1302
  %8 = and i16 %bf.load, 1024, !dbg !2912
  %tobool32.not = icmp eq i16 %8, 0, !dbg !2912
  br i1 %tobool32.not, label %cond.false, label %cond.true, !dbg !2912

cond.true:                                        ; preds = %if.end23
  %cas_id_in = getelementptr inbounds i8, ptr %of, i64 32, !dbg !2913
  %9 = load i64, ptr %cas_id_in, align 8, !dbg !2913, !tbaa !2463
  br label %for.body.preheader, !dbg !2912

cond.false:                                       ; preds = %if.end23
  %call33 = call i64 @get_cas_id() #13, !dbg !2914
  br label %for.body.preheader, !dbg !2912

for.body.preheader:                               ; preds = %cond.true, %cond.false
  %cond = phi i64 [ %9, %cond.true ], [ %call33, %cond.false ], !dbg !2912
  %cas = getelementptr inbounds i8, ptr %c, i64 416, !dbg !2915
  store i64 %cond, ptr %cas, align 8, !dbg !2916, !tbaa !1321
  %exptime34 = getelementptr inbounds i8, ptr %of, i64 4, !dbg !2917
  %10 = load i32, ptr %exptime34, align 4, !dbg !2917, !tbaa !2495
  tail call void @llvm.dbg.value(metadata i32 %10, metadata !2836, metadata !DIExpression()), !dbg !2845
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2837, metadata !DIExpression()), !dbg !2845
  tail call void @llvm.dbg.value(metadata i32 2, metadata !2828, metadata !DIExpression()), !dbg !2845
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2837, metadata !DIExpression()), !dbg !2845
  tail call void @llvm.dbg.value(metadata ptr %wbuf, metadata !2835, metadata !DIExpression()), !dbg !2845
  %11 = add nsw i64 %ntokens, -2
  br label %for.body, !dbg !2918

for.body:                                         ; preds = %for.body.preheader, %for.inc
  %indvars.iv = phi i64 [ 2, %for.body.preheader ], [ %indvars.iv.next, %for.inc ]
  %has_error.0312 = phi i1 [ false, %for.body.preheader ], [ %has_error.1, %for.inc ]
  %p.0311 = phi ptr [ %wbuf, %for.body.preheader ], [ %p.1, %for.inc ]
  tail call void @llvm.dbg.value(metadata ptr %p.0311, metadata !2835, metadata !DIExpression()), !dbg !2845
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2828, metadata !DIExpression()), !dbg !2845
  %arrayidx37 = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %indvars.iv, !dbg !2920
  %12 = load ptr, ptr %arrayidx37, align 8, !dbg !2923, !tbaa !1573
  %13 = load i8, ptr %12, align 1, !dbg !2920, !tbaa !1240
  %conv40 = sext i8 %13 to i32, !dbg !2920
  %14 = add nsw i32 %conv40, -79, !dbg !2924
  %15 = call i32 @llvm.fshl.i32(i32 %14, i32 %14, i32 30), !dbg !2924
  switch i32 %15, label %for.inc [
    i32 0, label %sw.bb
    i32 7, label %sw.bb57
    i32 5, label %sw.bb60
    i32 9, label %sw.bb63
  ], !dbg !2924

sw.bb:                                            ; preds = %for.body
  %length43 = getelementptr inbounds i8, ptr %arrayidx37, i64 8, !dbg !2925
  %16 = load i64, ptr %length43, align 8, !dbg !2925, !tbaa !1578
  %cmp44 = icmp ugt i64 %16, 32, !dbg !2928
  br i1 %cmp44, label %if.then46, label %if.end47, !dbg !2929

if.then46:                                        ; preds = %sw.bb
  store ptr @.str.52, ptr %errstr, align 8, !dbg !2930, !tbaa !1271, !DIAssignID !2932
  tail call void @llvm.dbg.assign(metadata ptr @.str.52, metadata !2831, metadata !DIExpression(), metadata !2932, metadata ptr %errstr, metadata !DIExpression()), !dbg !2845
  tail call void @llvm.dbg.value(metadata i8 1, metadata !2837, metadata !DIExpression()), !dbg !2845
  br label %for.inc, !dbg !2933

if.end47:                                         ; preds = %sw.bb
  store i8 32, ptr %p.0311, align 1, !dbg !2934, !tbaa !1240
  %incdec.ptr = getelementptr inbounds i8, ptr %p.0311, i64 1, !dbg !2934
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !2835, metadata !DIExpression()), !dbg !2845
  %17 = load ptr, ptr %arrayidx37, align 8, !dbg !2936, !tbaa !1573
  %18 = load i64, ptr %length43, align 8, !dbg !2937, !tbaa !1578
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %incdec.ptr, ptr align 1 %17, i64 %18, i1 false), !dbg !2938
  %19 = load i64, ptr %length43, align 8, !dbg !2939, !tbaa !1578
  %add.ptr = getelementptr inbounds i8, ptr %incdec.ptr, i64 %19, !dbg !2940
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !2835, metadata !DIExpression()), !dbg !2845
  br label %for.inc, !dbg !2941

sw.bb57:                                          ; preds = %for.body
  store i8 32, ptr %p.0311, align 1, !dbg !2942, !tbaa !1240
  %add.ptr58 = getelementptr inbounds i8, ptr %p.0311, i64 1, !dbg !2942
  store i8 107, ptr %add.ptr58, align 1, !dbg !2942, !tbaa !1240
  %add.ptr59 = getelementptr inbounds i8, ptr %p.0311, i64 2, !dbg !2942
  tail call void @llvm.dbg.value(metadata ptr %add.ptr59, metadata !2835, metadata !DIExpression()), !dbg !2845
  br label %for.inc, !dbg !2944

sw.bb60:                                          ; preds = %for.body
  store i8 32, ptr %p.0311, align 1, !dbg !2945, !tbaa !1240
  %add.ptr61 = getelementptr inbounds i8, ptr %p.0311, i64 1, !dbg !2945
  store i8 99, ptr %add.ptr61, align 1, !dbg !2945, !tbaa !1240
  %add.ptr62 = getelementptr inbounds i8, ptr %p.0311, i64 2, !dbg !2945
  tail call void @llvm.dbg.value(metadata ptr %add.ptr62, metadata !2835, metadata !DIExpression()), !dbg !2845
  br label %for.inc, !dbg !2947

sw.bb63:                                          ; preds = %for.body
  store i8 32, ptr %p.0311, align 1, !dbg !2948, !tbaa !1240
  %add.ptr64 = getelementptr inbounds i8, ptr %p.0311, i64 1, !dbg !2948
  store i8 115, ptr %add.ptr64, align 1, !dbg !2948, !tbaa !1240
  %add.ptr65 = getelementptr inbounds i8, ptr %p.0311, i64 2, !dbg !2948
  tail call void @llvm.dbg.value(metadata ptr %add.ptr65, metadata !2835, metadata !DIExpression()), !dbg !2845
  br label %for.inc, !dbg !2950

for.inc:                                          ; preds = %if.then46, %if.end47, %sw.bb57, %sw.bb60, %sw.bb63, %for.body
  %p.1 = phi ptr [ %p.0311, %for.body ], [ %add.ptr65, %sw.bb63 ], [ %add.ptr62, %sw.bb60 ], [ %add.ptr59, %sw.bb57 ], [ %p.0311, %if.then46 ], [ %add.ptr, %if.end47 ], !dbg !2845
  %has_error.1 = phi i1 [ %has_error.0312, %for.body ], [ %has_error.0312, %sw.bb63 ], [ %has_error.0312, %sw.bb60 ], [ %has_error.0312, %sw.bb57 ], [ true, %if.then46 ], [ %has_error.0312, %if.end47 ], !dbg !2845
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2837, metadata !DIExpression()), !dbg !2845
  tail call void @llvm.dbg.value(metadata ptr %p.1, metadata !2835, metadata !DIExpression()), !dbg !2845
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !2951
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !2828, metadata !DIExpression()), !dbg !2845
  %exitcond.not = icmp eq i64 %indvars.iv, %11, !dbg !2952
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !2918, !llvm.loop !2953

for.end:                                          ; preds = %for.inc
  %mode = getelementptr inbounds i8, ptr %of, i64 2, !dbg !2955
  %20 = load i8, ptr %mode, align 2, !dbg !2955, !tbaa !2956
  switch i8 %20, label %sw.default [
    i8 0, label %sw.epilog88
    i8 69, label %sw.bb67
    i8 65, label %sw.bb68
    i8 80, label %sw.bb76
    i8 82, label %sw.bb86
    i8 83, label %sw.epilog88
  ], !dbg !2957

sw.bb67:                                          ; preds = %for.end
  tail call void @llvm.dbg.value(metadata i16 1, metadata !2829, metadata !DIExpression()), !dbg !2845
  br label %sw.epilog88, !dbg !2958

sw.bb68:                                          ; preds = %for.end
  %bf.load69 = load i16, ptr %of, align 8, !dbg !2960
  %21 = and i16 %bf.load69, 8, !dbg !2962
  %tobool73.not = icmp eq i16 %21, 0, !dbg !2962
  br i1 %tobool73.not, label %sw.epilog88, label %if.then74, !dbg !2963

if.then74:                                        ; preds = %sw.bb68
  tail call void @llvm.dbg.value(metadata i16 7, metadata !2829, metadata !DIExpression()), !dbg !2845
  %autoviv_exptime = getelementptr inbounds i8, ptr %of, i64 8, !dbg !2964
  %22 = load i32, ptr %autoviv_exptime, align 8, !dbg !2964, !tbaa !2502
  tail call void @llvm.dbg.value(metadata i32 %22, metadata !2836, metadata !DIExpression()), !dbg !2845
  br label %sw.epilog88, !dbg !2966

sw.bb76:                                          ; preds = %for.end
  %bf.load77 = load i16, ptr %of, align 8, !dbg !2967
  %23 = and i16 %bf.load77, 8, !dbg !2969
  %tobool81.not = icmp eq i16 %23, 0, !dbg !2969
  br i1 %tobool81.not, label %sw.epilog88, label %if.then82, !dbg !2970

if.then82:                                        ; preds = %sw.bb76
  tail call void @llvm.dbg.value(metadata i16 8, metadata !2829, metadata !DIExpression()), !dbg !2845
  %autoviv_exptime83 = getelementptr inbounds i8, ptr %of, i64 8, !dbg !2971
  %24 = load i32, ptr %autoviv_exptime83, align 8, !dbg !2971, !tbaa !2502
  tail call void @llvm.dbg.value(metadata i32 %24, metadata !2836, metadata !DIExpression()), !dbg !2845
  br label %sw.epilog88, !dbg !2973

sw.bb86:                                          ; preds = %for.end
  tail call void @llvm.dbg.value(metadata i16 3, metadata !2829, metadata !DIExpression()), !dbg !2845
  br label %sw.epilog88, !dbg !2974

sw.default:                                       ; preds = %for.end
  store ptr @.str.62, ptr %errstr, align 8, !dbg !2975, !tbaa !1271, !DIAssignID !2976
  tail call void @llvm.dbg.assign(metadata ptr @.str.62, metadata !2831, metadata !DIExpression(), metadata !2976, metadata ptr %errstr, metadata !DIExpression()), !dbg !2845
  br label %error, !dbg !2977

sw.epilog88:                                      ; preds = %for.end, %sw.bb76, %sw.bb68, %if.then82, %if.then74, %sw.bb86, %sw.bb67, %for.end
  %comm.0 = phi i16 [ 3, %sw.bb86 ], [ 8, %if.then82 ], [ 7, %if.then74 ], [ 1, %sw.bb67 ], [ 2, %for.end ], [ 4, %sw.bb68 ], [ 5, %sw.bb76 ], [ 2, %for.end ], !dbg !2845
  %exptime.0 = phi i32 [ %10, %sw.bb86 ], [ %24, %if.then82 ], [ %22, %if.then74 ], [ %10, %sw.bb67 ], [ %10, %for.end ], [ %10, %sw.bb68 ], [ %10, %sw.bb76 ], [ %10, %for.end ], !dbg !2845
  %brmerge = phi i1 [ true, %sw.bb86 ], [ false, %if.then82 ], [ false, %if.then74 ], [ false, %sw.bb67 ], [ true, %for.end ], [ false, %sw.bb68 ], [ false, %sw.bb76 ], [ true, %for.end ]
  tail call void @llvm.dbg.value(metadata i32 %exptime.0, metadata !2836, metadata !DIExpression()), !dbg !2845
  tail call void @llvm.dbg.value(metadata i16 %comm.0, metadata !2829, metadata !DIExpression()), !dbg !2845
  %bf.load89 = load i16, ptr %of, align 8, !dbg !2978
  %25 = and i16 %bf.load89, 512, !dbg !2980
  %tobool93.not = icmp ne i16 %25, 0, !dbg !2980
  %or.cond308 = and i1 %brmerge, %tobool93.not, !dbg !2981
  %comm.1 = select i1 %or.cond308, i16 6, i16 %comm.0, !dbg !2981
  tail call void @llvm.dbg.value(metadata i16 %comm.1, metadata !2829, metadata !DIExpression()), !dbg !2845
  br i1 %has_error.1, label %error, label %if.end105, !dbg !2982

if.end105:                                        ; preds = %sw.epilog88
  %client_flags = getelementptr inbounds i8, ptr %of, i64 16, !dbg !2983
  %26 = load i32, ptr %client_flags, align 8, !dbg !2983, !tbaa !2984
  %27 = load i32, ptr %vlen, align 4, !dbg !2985, !tbaa !1231
  %call106 = call ptr @item_alloc(ptr noundef %4, i64 noundef %5, i32 noundef %26, i32 noundef %exptime.0, i32 noundef %27) #13, !dbg !2986
  tail call void @llvm.dbg.value(metadata ptr %call106, metadata !2827, metadata !DIExpression()), !dbg !2845
  %cmp107 = icmp eq ptr %call106, null, !dbg !2987
  br i1 %cmp107, label %if.then109, label %if.end160, !dbg !2988

if.then109:                                       ; preds = %if.end105
  %28 = load i32, ptr %client_flags, align 8, !dbg !2989, !tbaa !2984
  %29 = load i32, ptr %vlen, align 4, !dbg !2991, !tbaa !1231
  %call111 = call zeroext i1 @item_size_ok(i64 noundef %5, i32 noundef %28, i32 noundef %29) #13, !dbg !2992
  %thread122 = getelementptr inbounds i8, ptr %c, i64 456, !dbg !2993
  %30 = load ptr, ptr %thread122, align 8, !dbg !2993, !tbaa !1234
  %stats123 = getelementptr inbounds i8, ptr %30, i64 352, !dbg !2993
  %call125 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats123) #13, !dbg !2993
  %31 = load ptr, ptr %thread122, align 8, !dbg !2993, !tbaa !1234
  %stats130 = getelementptr inbounds i8, ptr %31, i64 352, !dbg !2993
  %. = select i1 %call111, i64 576, i64 568
  %.str.64..str.63 = select i1 %call111, ptr @.str.64, ptr @.str.63
  %.316 = select i1 %call111, i32 5, i32 4
  %store_too_large = getelementptr inbounds i8, ptr %31, i64 %., !dbg !2993
  %32 = load i64, ptr %store_too_large, align 8, !dbg !2993, !tbaa !1308
  %inc116 = add i64 %32, 1, !dbg !2993
  store i64 %inc116, ptr %store_too_large, align 8, !dbg !2993, !tbaa !1308
  %call120 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats130) #13, !dbg !2993
  store ptr %.str.64..str.63, ptr %errstr, align 8, !dbg !2993, !DIAssignID !2994
  tail call void @llvm.dbg.value(metadata i32 %.316, metadata !2838, metadata !DIExpression()), !dbg !2995
  %thread135 = getelementptr inbounds i8, ptr %c, i64 456, !dbg !2996
  %33 = load ptr, ptr %thread135, align 8, !dbg !2996, !tbaa !1234
  %l = getelementptr inbounds i8, ptr %33, i64 6912, !dbg !2996
  %34 = load ptr, ptr %l, align 8, !dbg !2996, !tbaa !2997
  tail call void @llvm.dbg.value(metadata ptr %34, metadata !2841, metadata !DIExpression()), !dbg !2998
  %cmp138 = icmp eq ptr %34, null, !dbg !2999
  br i1 %cmp138, label %if.then140, label %if.end142, !dbg !2996

if.then140:                                       ; preds = %if.then109
  %35 = load i32, ptr @logger_key, align 4, !dbg !2999, !tbaa !1231
  %call141 = call ptr @pthread_getspecific(i32 noundef %35) #13, !dbg !2999
  tail call void @llvm.dbg.value(metadata ptr %call141, metadata !2841, metadata !DIExpression()), !dbg !2998
  br label %if.end142, !dbg !2999

if.end142:                                        ; preds = %if.then140, %if.then109
  %myl.0 = phi ptr [ %call141, %if.then140 ], [ %34, %if.then109 ], !dbg !2996
  tail call void @llvm.dbg.value(metadata ptr %myl.0, metadata !2841, metadata !DIExpression()), !dbg !2998
  %eflags = getelementptr inbounds i8, ptr %myl.0, i64 84, !dbg !3001
  %36 = load i16, ptr %eflags, align 4, !dbg !3001, !tbaa !3003
  %37 = and i16 %36, 8, !dbg !3001
  %tobool144.not = icmp eq i16 %37, 0, !dbg !3001
  br i1 %tobool144.not, label %if.end148, label %if.then145, !dbg !2996

if.then145:                                       ; preds = %if.end142
  %conv146 = zext nneg i16 %comm.1 to i32
  %call147 = call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %myl.0, i32 noundef 3, ptr noundef null, i32 noundef %.316, i32 noundef %conv146, ptr noundef %4, i64 noundef %5, i32 noundef 0, i32 noundef 0) #13, !dbg !3001
  br label %if.end148, !dbg !3001

if.end148:                                        ; preds = %if.then145, %if.end142
  %38 = load ptr, ptr %thread135, align 8, !dbg !3005, !tbaa !1234
  %call152 = call ptr @item_get_locked(ptr noundef %4, i64 noundef %5, ptr noundef %38, i1 noundef zeroext false, ptr noundef nonnull %hv) #13, !dbg !3006
  tail call void @llvm.dbg.value(metadata ptr %call152, metadata !2827, metadata !DIExpression()), !dbg !2845
  %tobool153.not = icmp eq ptr %call152, null, !dbg !3007
  br i1 %tobool153.not, label %if.end159, label %if.then154, !dbg !3009

if.then154:                                       ; preds = %if.end148
  %39 = load i32, ptr %hv, align 4, !dbg !3010, !tbaa !1231
  call void @do_item_unlink(ptr noundef nonnull %call152, i32 noundef %39) #13, !dbg !3012
  %40 = load ptr, ptr %thread135, align 8, !dbg !3013, !tbaa !1234
  %storage = getelementptr inbounds i8, ptr %40, i64 6904, !dbg !3013
  %41 = load ptr, ptr %storage, align 8, !dbg !3013, !tbaa !3015
  call void @storage_delete(ptr noundef %41, ptr noundef nonnull %call152) #13, !dbg !3013
  call void @do_item_remove(ptr noundef nonnull %call152) #13, !dbg !3016
  br label %if.end159, !dbg !3017

if.end159:                                        ; preds = %if.then154, %if.end148
  %42 = load i32, ptr %hv, align 4, !dbg !3018, !tbaa !1231
  call void @item_unlock(i32 noundef %42) #13, !dbg !3019
  br label %error

if.end160:                                        ; preds = %if.end105
  %it_flags = getelementptr inbounds i8, ptr %call106, i64 38, !dbg !3020
  %43 = load i16, ptr %it_flags, align 2, !dbg !3020, !tbaa !1248
  %44 = and i16 %43, 2, !dbg !3020
  %tobool163.not = icmp eq i16 %44, 0, !dbg !3020
  br i1 %tobool163.not, label %if.end166, label %if.then164, !dbg !3023

if.then164:                                       ; preds = %if.end160
  %req_cas_id = getelementptr inbounds i8, ptr %of, i64 24, !dbg !3024
  %45 = load i64, ptr %req_cas_id, align 8, !dbg !3024, !tbaa !3026
  %data = getelementptr inbounds i8, ptr %call106, i64 48, !dbg !3024
  store i64 %45, ptr %data, align 8, !dbg !3024, !tbaa !1240
  br label %if.end166, !dbg !3024

if.end166:                                        ; preds = %if.then164, %if.end160
  %item = getelementptr inbounds i8, ptr %c, i64 224, !dbg !3027
  store ptr %call106, ptr %item, align 8, !dbg !3028, !tbaa !1210
  %data167 = getelementptr inbounds i8, ptr %call106, i64 48, !dbg !3029
  %nkey168 = getelementptr inbounds i8, ptr %call106, i64 41, !dbg !3029
  %46 = load i8, ptr %nkey168, align 1, !dbg !3029, !tbaa !1240
  %idx.ext = zext i8 %46 to i64
  %add.ptr170 = getelementptr inbounds i8, ptr %data167, i64 %idx.ext, !dbg !3029
  %add.ptr171 = getelementptr inbounds i8, ptr %add.ptr170, i64 1, !dbg !3029
  %conv173 = zext i16 %43 to i32, !dbg !3029
  %and174 = lshr i32 %conv173, 6, !dbg !3029
  %47 = and i32 %and174, 4, !dbg !3029
  %cond176 = zext nneg i32 %47 to i64, !dbg !3029
  %add.ptr177 = getelementptr inbounds i8, ptr %add.ptr171, i64 %cond176, !dbg !3029
  %and180 = shl nuw nsw i32 %conv173, 2, !dbg !3029
  %48 = and i32 %and180, 8, !dbg !3029
  %cond182 = zext nneg i32 %48 to i64, !dbg !3029
  %add.ptr183 = getelementptr inbounds i8, ptr %add.ptr177, i64 %cond182, !dbg !3029
  %ritem = getelementptr inbounds i8, ptr %c, i64 208, !dbg !3030
  store ptr %add.ptr183, ptr %ritem, align 8, !dbg !3031, !tbaa !1255
  %nbytes = getelementptr inbounds i8, ptr %call106, i64 32, !dbg !3032
  %49 = load i32, ptr %nbytes, align 8, !dbg !3032, !tbaa !1231
  %rlbytes = getelementptr inbounds i8, ptr %c, i64 216, !dbg !3033
  store i32 %49, ptr %rlbytes, align 8, !dbg !3034, !tbaa !1516
  %cmd = getelementptr inbounds i8, ptr %c, i64 432, !dbg !3035
  store i16 %comm.1, ptr %cmd, align 8, !dbg !3036, !tbaa !1227
  %bf.load184 = load i16, ptr %of, align 8, !dbg !3037
  %50 = and i16 %bf.load184, 4096, !dbg !3039
  %tobool188.not = icmp eq i16 %50, 0, !dbg !3039
  br i1 %tobool188.not, label %if.end193, label %if.then189, !dbg !3040

if.then189:                                       ; preds = %if.end166
  %51 = load i16, ptr %it_flags, align 2, !dbg !3041, !tbaa !1248
  %52 = or i16 %51, 4096, !dbg !3041
  store i16 %52, ptr %it_flags, align 2, !dbg !3041, !tbaa !1248
  br label %if.end193, !dbg !3043

if.end193:                                        ; preds = %if.then189, %if.end166
  %53 = and i16 %bf.load184, 128, !dbg !3044
  %tobool198.not = icmp ne i16 %53, 0, !dbg !3044
  %or.cond307 = and i1 %or.cond308, %tobool198.not, !dbg !3046
  br i1 %or.cond307, label %if.then203, label %if.end204, !dbg !3046

if.then203:                                       ; preds = %if.end193
  %set_stale = getelementptr inbounds i8, ptr %c, i64 14, !dbg !3047
  store i8 1, ptr %set_stale, align 2, !dbg !3049, !tbaa !1325
  br label %if.end204, !dbg !3050

if.end204:                                        ; preds = %if.then203, %if.end193
  %sub.ptr.lhs.cast = ptrtoint ptr %p.1 to i64, !dbg !3051
  %sub.ptr.rhs.cast = ptrtoint ptr %wbuf to i64, !dbg !3051
  %sub.ptr.sub = sub i64 %sub.ptr.lhs.cast, %sub.ptr.rhs.cast, !dbg !3051
  %conv207 = trunc i64 %sub.ptr.sub to i32, !dbg !3052
  %wbytes = getelementptr inbounds i8, ptr %0, i64 16, !dbg !3053
  store i32 %conv207, ptr %wbytes, align 8, !dbg !3054, !tbaa !1355
  %mset_res = getelementptr inbounds i8, ptr %c, i64 15, !dbg !3055
  store i8 1, ptr %mset_res, align 1, !dbg !3056, !tbaa !1295
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 6) #13, !dbg !3057
  br label %cleanup, !dbg !3058

error:                                            ; preds = %if.end159, %sw.epilog88, %if.end19, %sw.default
  tail call void @llvm.dbg.label(metadata !2843), !dbg !3059
  %54 = load i32, ptr %vlen, align 4, !dbg !3060, !tbaa !1231
  %sbytes = getelementptr inbounds i8, ptr %c, i64 232, !dbg !3061
  store i32 %54, ptr %sbytes, align 8, !dbg !3062, !tbaa !3063
  %55 = load ptr, ptr %errstr, align 8, !dbg !3064, !tbaa !1271
  call void @out_errstring(ptr noundef %c, ptr noundef %55) #13, !dbg !3065
  call void @conn_set_state(ptr noundef %c, i32 noundef 7) #13, !dbg !3066
  br label %cleanup, !dbg !3067

cleanup:                                          ; preds = %error, %if.end204, %if.then18, %if.then14, %if.then9, %if.then6, %if.then3, %if.then
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %vlen) #13, !dbg !3067
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %hv) #13, !dbg !3067
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %errstr) #13, !dbg !3067
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %of) #13, !dbg !3067
  ret void, !dbg !3067
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_mdelete_command(ptr noundef %c, ptr nocapture noundef %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !3068 {
entry:
  %hv = alloca i32, align 4, !DIAssignID !3093
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3077, metadata !DIExpression(), metadata !3093, metadata ptr %hv, metadata !DIExpression()), !dbg !3094
  %of = alloca %struct._meta_flags, align 8, !DIAssignID !3095
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3078, metadata !DIExpression(), metadata !3095, metadata ptr %of, metadata !DIExpression()), !dbg !3094
  %errstr = alloca ptr, align 8, !DIAssignID !3096
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3079, metadata !DIExpression(), metadata !3096, metadata ptr %errstr, metadata !DIExpression()), !dbg !3094
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !3070, metadata !DIExpression()), !dbg !3094
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !3071, metadata !DIExpression()), !dbg !3094
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !3072, metadata !DIExpression()), !dbg !3094
  tail call void @llvm.dbg.value(metadata ptr null, metadata !3075, metadata !DIExpression()), !dbg !3094
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %hv) #13, !dbg !3097
  store i32 0, ptr %hv, align 4, !dbg !3098, !tbaa !1231, !DIAssignID !3099
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !3077, metadata !DIExpression(), metadata !3099, metadata ptr %hv, metadata !DIExpression()), !dbg !3094
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %of) #13, !dbg !3100
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %of, i8 0, i64 56, i1 false), !dbg !3101, !DIAssignID !3102
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !3078, metadata !DIExpression(), metadata !3102, metadata ptr %of, metadata !DIExpression()), !dbg !3094
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %errstr) #13, !dbg !3103
  store ptr @.str.48, ptr %errstr, align 8, !dbg !3104, !tbaa !1271, !DIAssignID !3105
  tail call void @llvm.dbg.assign(metadata ptr @.str.48, metadata !3079, metadata !DIExpression(), metadata !3105, metadata ptr %errstr, metadata !DIExpression()), !dbg !3094
  %resp1 = getelementptr inbounds i8, ptr %c, i64 192, !dbg !3106
  %0 = load ptr, ptr %resp1, align 8, !dbg !3106, !tbaa !1351
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !3080, metadata !DIExpression()), !dbg !3094
  %wbuf = getelementptr inbounds i8, ptr %0, i64 160, !dbg !3107
  %add.ptr = getelementptr inbounds i8, ptr %0, i64 162, !dbg !3108
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !3081, metadata !DIExpression()), !dbg !3094
  %cmp = icmp ult i64 %ntokens, 3, !dbg !3109
  br i1 %cmp, label %if.then, label %do.end, !dbg !3112

if.then:                                          ; preds = %entry
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.15) #13, !dbg !3113
  br label %cleanup261, !dbg !3113

do.end:                                           ; preds = %entry
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !3115
  %length = getelementptr inbounds i8, ptr %tokens, i64 24, !dbg !3117
  %1 = load i64, ptr %length, align 8, !dbg !3117, !tbaa !1578
  %cmp2 = icmp ugt i64 %1, 250, !dbg !3118
  br i1 %cmp2, label %if.then3, label %if.end4, !dbg !3119

if.then3:                                         ; preds = %do.end
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.48) #13, !dbg !3120
  br label %cleanup261, !dbg !3122

if.end4:                                          ; preds = %do.end
  %cmp5 = icmp ugt i64 %ntokens, 20, !dbg !3123
  br i1 %cmp5, label %if.then6, label %if.end7, !dbg !3125

if.then6:                                         ; preds = %if.end4
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.61) #13, !dbg !3126
  br label %cleanup261, !dbg !3128

if.end7:                                          ; preds = %if.end4
  %call = call fastcc i32 @_meta_flag_preparse(ptr noundef nonnull %tokens, i64 noundef 2, ptr noundef nonnull %of, ptr noundef nonnull %errstr), !dbg !3129
  %cmp8.not = icmp eq i32 %call, 0, !dbg !3131
  br i1 %cmp8.not, label %if.end10, label %if.then9, !dbg !3132

if.then9:                                         ; preds = %if.end7
  call void @out_errstring(ptr noundef nonnull %c, ptr noundef nonnull @.str.65) #13, !dbg !3133
  br label %cleanup261, !dbg !3135

if.end10:                                         ; preds = %if.end7
  %bf.load = load i16, ptr %of, align 8, !dbg !3136
  %noreply = getelementptr inbounds i8, ptr %c, i64 364, !dbg !3137
  %2 = lshr i16 %bf.load, 8, !dbg !3138
  %3 = trunc nuw i16 %2 to i8, !dbg !3138
  %frombool = and i8 %3, 1, !dbg !3138
  store i8 %frombool, ptr %noreply, align 4, !dbg !3138, !tbaa !1302
  %4 = load ptr, ptr %arrayidx, align 8, !dbg !3139, !tbaa !1573
  tail call void @llvm.dbg.value(metadata ptr %4, metadata !3073, metadata !DIExpression()), !dbg !3094
  %5 = load i64, ptr %length, align 8, !dbg !3140, !tbaa !1578
  tail call void @llvm.dbg.value(metadata i64 %5, metadata !3074, metadata !DIExpression()), !dbg !3094
  tail call void @llvm.dbg.value(metadata i32 2, metadata !3076, metadata !DIExpression()), !dbg !3094
  %sub = add nsw i64 %ntokens, -1
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !3081, metadata !DIExpression()), !dbg !3094
  tail call void @llvm.dbg.value(metadata i32 2, metadata !3076, metadata !DIExpression()), !dbg !3094
  %cmp14382 = icmp ugt i64 %sub, 2, !dbg !3141
  br i1 %cmp14382, label %for.body, label %for.end, !dbg !3144

for.body:                                         ; preds = %if.end10, %for.inc
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.inc ], [ 2, %if.end10 ]
  %p.0384 = phi ptr [ %p.1, %for.inc ], [ %add.ptr, %if.end10 ]
  tail call void @llvm.dbg.value(metadata ptr %p.0384, metadata !3081, metadata !DIExpression()), !dbg !3094
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !3076, metadata !DIExpression()), !dbg !3094
  %arrayidx16 = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %indvars.iv, !dbg !3145
  %6 = load ptr, ptr %arrayidx16, align 8, !dbg !3147, !tbaa !1573
  %7 = load i8, ptr %6, align 1, !dbg !3145, !tbaa !1240
  switch i8 %7, label %for.inc [
    i8 79, label %sw.bb
    i8 107, label %sw.bb37
  ], !dbg !3148

sw.bb:                                            ; preds = %for.body
  %length22 = getelementptr inbounds i8, ptr %arrayidx16, i64 8, !dbg !3149
  %8 = load i64, ptr %length22, align 8, !dbg !3149, !tbaa !1578
  %cmp23 = icmp ugt i64 %8, 32, !dbg !3152
  br i1 %cmp23, label %if.end260, label %if.end26, !dbg !3153

if.end26:                                         ; preds = %sw.bb
  store i8 32, ptr %p.0384, align 1, !dbg !3154, !tbaa !1240
  %incdec.ptr = getelementptr inbounds i8, ptr %p.0384, i64 1, !dbg !3154
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !3081, metadata !DIExpression()), !dbg !3094
  %9 = load ptr, ptr %arrayidx16, align 8, !dbg !3156, !tbaa !1573
  %10 = load i64, ptr %length22, align 8, !dbg !3157, !tbaa !1578
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %incdec.ptr, ptr align 1 %9, i64 %10, i1 false), !dbg !3158
  %11 = load i64, ptr %length22, align 8, !dbg !3159, !tbaa !1578
  %add.ptr36 = getelementptr inbounds i8, ptr %incdec.ptr, i64 %11, !dbg !3160
  tail call void @llvm.dbg.value(metadata ptr %add.ptr36, metadata !3081, metadata !DIExpression()), !dbg !3094
  br label %for.inc, !dbg !3161

sw.bb37:                                          ; preds = %for.body
  store i8 32, ptr %p.0384, align 1, !dbg !3162, !tbaa !1240
  %add.ptr38 = getelementptr inbounds i8, ptr %p.0384, i64 1, !dbg !3162
  store i8 107, ptr %add.ptr38, align 1, !dbg !3162, !tbaa !1240
  %add.ptr39 = getelementptr inbounds i8, ptr %p.0384, i64 2, !dbg !3162
  tail call void @llvm.dbg.value(metadata ptr %add.ptr39, metadata !3081, metadata !DIExpression()), !dbg !3094
  %bf.load40 = load i16, ptr %of, align 8, !dbg !3165
  %12 = and i16 %bf.load40, 4096, !dbg !3165
  %tobool44.not = icmp eq i16 %12, 0, !dbg !3165
  br i1 %tobool44.not, label %if.then45, label %if.else, !dbg !3167

if.then45:                                        ; preds = %sw.bb37
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr39, ptr align 1 %4, i64 %5, i1 false), !dbg !3168
  %add.ptr46 = getelementptr inbounds i8, ptr %add.ptr39, i64 %5, !dbg !3168
  tail call void @llvm.dbg.value(metadata ptr %add.ptr46, metadata !3081, metadata !DIExpression()), !dbg !3094
  br label %for.inc, !dbg !3168

if.else:                                          ; preds = %sw.bb37
  %call47 = call i64 @base64_encode(ptr noundef %4, i64 noundef %5, ptr noundef nonnull %add.ptr39, i64 noundef 512) #13, !dbg !3170
  %add.ptr48 = getelementptr inbounds i8, ptr %add.ptr39, i64 %call47, !dbg !3170
  tail call void @llvm.dbg.value(metadata ptr %add.ptr48, metadata !3081, metadata !DIExpression()), !dbg !3094
  store i8 32, ptr %add.ptr48, align 1, !dbg !3170, !tbaa !1240
  %add.ptr49 = getelementptr inbounds i8, ptr %add.ptr48, i64 1, !dbg !3170
  store i8 98, ptr %add.ptr49, align 1, !dbg !3170, !tbaa !1240
  %add.ptr50 = getelementptr inbounds i8, ptr %add.ptr48, i64 2, !dbg !3170
  tail call void @llvm.dbg.value(metadata ptr %add.ptr50, metadata !3081, metadata !DIExpression()), !dbg !3094
  br label %for.inc

for.inc:                                          ; preds = %if.end26, %for.body, %if.else, %if.then45
  %p.1 = phi ptr [ %p.0384, %for.body ], [ %add.ptr50, %if.else ], [ %add.ptr46, %if.then45 ], [ %add.ptr36, %if.end26 ], !dbg !3094
  tail call void @llvm.dbg.value(metadata ptr %p.1, metadata !3081, metadata !DIExpression()), !dbg !3094
  %indvars.iv.next = add nuw i64 %indvars.iv, 1, !dbg !3172
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !3076, metadata !DIExpression()), !dbg !3094
  %exitcond.not = icmp eq i64 %indvars.iv.next, %sub, !dbg !3141
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !3144, !llvm.loop !3173

for.end:                                          ; preds = %for.inc, %if.end10
  %p.0.lcssa = phi ptr [ %add.ptr, %if.end10 ], [ %p.1, %for.inc ], !dbg !3175
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !3176
  %13 = load ptr, ptr %thread, align 8, !dbg !3176, !tbaa !1234
  %call52 = call ptr @item_get_locked(ptr noundef %4, i64 noundef %5, ptr noundef %13, i1 noundef zeroext false, ptr noundef nonnull %hv) #13, !dbg !3177
  tail call void @llvm.dbg.value(metadata ptr %call52, metadata !3075, metadata !DIExpression()), !dbg !3094
  %tobool53.not = icmp eq ptr %call52, null, !dbg !3178
  br i1 %tobool53.not, label %cleanup242, label %if.then54, !dbg !3179

if.then54:                                        ; preds = %for.end
  %bf.load55 = load i16, ptr %of, align 8, !dbg !3180
  %14 = and i16 %bf.load55, 512, !dbg !3182
  %tobool59.not = icmp eq i16 %14, 0, !dbg !3182
  br i1 %tobool59.not, label %if.end77, label %land.lhs.true, !dbg !3183

land.lhs.true:                                    ; preds = %if.then54
  %it_flags = getelementptr inbounds i8, ptr %call52, i64 38, !dbg !3184
  %15 = load i16, ptr %it_flags, align 2, !dbg !3184, !tbaa !1248
  %16 = and i16 %15, 2, !dbg !3184
  %tobool61.not = icmp eq i16 %16, 0, !dbg !3184
  br i1 %tobool61.not, label %cond.end, label %cond.true, !dbg !3184

cond.true:                                        ; preds = %land.lhs.true
  %data = getelementptr inbounds i8, ptr %call52, i64 48, !dbg !3184
  %17 = load i64, ptr %data, align 8, !dbg !3184, !tbaa !1240
  br label %cond.end, !dbg !3184

cond.end:                                         ; preds = %land.lhs.true, %cond.true
  %cond = phi i64 [ %17, %cond.true ], [ 0, %land.lhs.true ], !dbg !3184
  %req_cas_id = getelementptr inbounds i8, ptr %of, i64 24, !dbg !3185
  %18 = load i64, ptr %req_cas_id, align 8, !dbg !3185, !tbaa !3026
  %cmp63.not = icmp eq i64 %cond, %18, !dbg !3186
  br i1 %cmp63.not, label %if.end77, label %if.then65, !dbg !3187

if.then65:                                        ; preds = %cond.end
  %19 = load ptr, ptr %thread, align 8, !dbg !3188, !tbaa !1234
  %stats = getelementptr inbounds i8, ptr %19, i64 352, !dbg !3190
  %call67 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #13, !dbg !3191
  %20 = load ptr, ptr %thread, align 8, !dbg !3192, !tbaa !1234
  %delete_misses = getelementptr inbounds i8, ptr %20, i64 440, !dbg !3193
  %21 = load i64, ptr %delete_misses, align 8, !dbg !3194, !tbaa !3195
  %inc70 = add i64 %21, 1, !dbg !3194
  store i64 %inc70, ptr %delete_misses, align 8, !dbg !3194, !tbaa !3195
  %stats72 = getelementptr inbounds i8, ptr %20, i64 352, !dbg !3196
  %call74 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats72) #13, !dbg !3197
  br label %if.then244, !dbg !3198

if.end77:                                         ; preds = %cond.end, %if.then54
  %22 = and i16 %bf.load55, 8192, !dbg !3199
  %tobool82.not = icmp eq i16 %22, 0, !dbg !3199
  br i1 %tobool82.not, label %if.end134, label %if.then83, !dbg !3200

if.then83:                                        ; preds = %if.end77
  %client_flags = getelementptr inbounds i8, ptr %of, i64 16, !dbg !3201
  %23 = load i32, ptr %client_flags, align 8, !dbg !3201, !tbaa !2984
  %exptime = getelementptr inbounds i8, ptr %of, i64 4, !dbg !3202
  %24 = load i32, ptr %exptime, align 4, !dbg !3202, !tbaa !2495
  %call84 = call ptr @item_alloc(ptr noundef %4, i64 noundef %5, i32 noundef %23, i32 noundef %24, i32 noundef 2) #13, !dbg !3203
  tail call void @llvm.dbg.value(metadata ptr %call84, metadata !3082, metadata !DIExpression()), !dbg !3204
  %cmp85.not = icmp eq ptr %call84, null, !dbg !3205
  br i1 %cmp85.not, label %if.then259, label %if.then87, !dbg !3207

if.then87:                                        ; preds = %if.then83
  %data88 = getelementptr inbounds i8, ptr %call84, i64 48, !dbg !3208
  %nkey89 = getelementptr inbounds i8, ptr %call84, i64 41, !dbg !3208
  %25 = load i8, ptr %nkey89, align 1, !dbg !3208, !tbaa !1240
  %idx.ext = zext i8 %25 to i64
  %add.ptr91 = getelementptr inbounds i8, ptr %data88, i64 %idx.ext, !dbg !3208
  %add.ptr92 = getelementptr inbounds i8, ptr %add.ptr91, i64 1, !dbg !3208
  %it_flags93 = getelementptr inbounds i8, ptr %call84, i64 38, !dbg !3208
  %26 = load i16, ptr %it_flags93, align 2, !dbg !3208, !tbaa !1248
  %conv94 = zext i16 %26 to i32, !dbg !3208
  %and95 = lshr i32 %conv94, 6, !dbg !3208
  %27 = and i32 %and95, 4, !dbg !3208
  %cond97 = zext nneg i32 %27 to i64, !dbg !3208
  %add.ptr98 = getelementptr inbounds i8, ptr %add.ptr92, i64 %cond97, !dbg !3208
  %and101 = shl nuw nsw i32 %conv94, 2, !dbg !3208
  %28 = and i32 %and101, 8, !dbg !3208
  %cond103 = zext nneg i32 %28 to i64, !dbg !3208
  %add.ptr104 = getelementptr inbounds i8, ptr %add.ptr98, i64 %cond103, !dbg !3208
  store i16 2573, ptr %add.ptr104, align 1, !dbg !3210
  %29 = load ptr, ptr %thread, align 8, !dbg !3211, !tbaa !1234
  %30 = load i32, ptr %hv, align 4, !dbg !3213, !tbaa !1231
  %bf.load106 = load i16, ptr %of, align 8, !dbg !3214
  %31 = and i16 %bf.load106, 1024, !dbg !3215
  %tobool110.not = icmp eq i16 %31, 0, !dbg !3215
  br i1 %tobool110.not, label %cond.false112, label %cond.true111, !dbg !3215

cond.true111:                                     ; preds = %if.then87
  %cas_id_in = getelementptr inbounds i8, ptr %of, i64 32, !dbg !3216
  br label %cond.end123.sink.split, !dbg !3215

cond.false112:                                    ; preds = %if.then87
  %it_flags113 = getelementptr inbounds i8, ptr %call52, i64 38, !dbg !3217
  %32 = load i16, ptr %it_flags113, align 2, !dbg !3217, !tbaa !1248
  %33 = and i16 %32, 2, !dbg !3217
  %tobool116.not = icmp eq i16 %33, 0, !dbg !3217
  br i1 %tobool116.not, label %cond.end123, label %cond.true117, !dbg !3217

cond.true117:                                     ; preds = %cond.false112
  %data118 = getelementptr inbounds i8, ptr %call52, i64 48, !dbg !3217
  br label %cond.end123.sink.split, !dbg !3217

cond.end123.sink.split:                           ; preds = %cond.true111, %cond.true117
  %data118.sink = phi ptr [ %data118, %cond.true117 ], [ %cas_id_in, %cond.true111 ]
  %34 = load i64, ptr %data118.sink, align 8, !dbg !3218, !tbaa !1240
  br label %cond.end123, !dbg !3219

cond.end123:                                      ; preds = %cond.end123.sink.split, %cond.false112
  %cond124 = phi i64 [ 0, %cond.false112 ], [ %34, %cond.end123.sink.split ], !dbg !3215
  %call125 = call i32 @do_store_item(ptr noundef nonnull %call84, i32 noundef 2, ptr noundef %29, i32 noundef %30, ptr noundef null, ptr noundef null, i64 noundef %cond124, i1 noundef zeroext false) #13, !dbg !3219
  %tobool126.not = icmp eq i32 %call125, 0, !dbg !3219
  br i1 %tobool126.not, label %cleanup.thread373, label %cleanup.thread, !dbg !3220

cleanup.thread:                                   ; preds = %cond.end123
  call void @do_item_remove(ptr noundef nonnull %call52) #13, !dbg !3221
  tail call void @llvm.dbg.value(metadata ptr %call84, metadata !3075, metadata !DIExpression()), !dbg !3094
  %bf.load135.pre = load i16, ptr %of, align 8, !dbg !3223
  br label %if.end134

cleanup.thread373:                                ; preds = %cond.end123
  call void @do_item_remove(ptr noundef nonnull %call84) #13, !dbg !3224
  tail call void @llvm.dbg.value(metadata ptr %call52, metadata !3075, metadata !DIExpression()), !dbg !3094
  br label %if.then244

if.end134:                                        ; preds = %cleanup.thread, %if.end77
  %bf.load135 = phi i16 [ %bf.load55, %if.end77 ], [ %bf.load135.pre, %cleanup.thread ], !dbg !3223
  %it.1 = phi ptr [ %call52, %if.end77 ], [ %call84, %cleanup.thread ], !dbg !3094
  tail call void @llvm.dbg.value(metadata ptr %it.1, metadata !3075, metadata !DIExpression()), !dbg !3094
  %35 = and i16 %bf.load135, 128, !dbg !3226
  %tobool139.not = icmp eq i16 %35, 0, !dbg !3226
  br i1 %tobool139.not, label %if.else182, label %if.then140, !dbg !3227

if.then140:                                       ; preds = %if.end134
  %36 = and i16 %bf.load135, 2048, !dbg !3228
  %tobool145.not = icmp eq i16 %36, 0, !dbg !3228
  br i1 %tobool145.not, label %if.end149, label %if.then146, !dbg !3231

if.then146:                                       ; preds = %if.then140
  %exptime147 = getelementptr inbounds i8, ptr %of, i64 4, !dbg !3232
  %37 = load i32, ptr %exptime147, align 4, !dbg !3232, !tbaa !2495
  %exptime148 = getelementptr inbounds i8, ptr %it.1, i64 28, !dbg !3234
  store i32 %37, ptr %exptime148, align 4, !dbg !3235, !tbaa !1231
  br label %if.end149, !dbg !3236

if.end149:                                        ; preds = %if.then146, %if.then140
  %it_flags150 = getelementptr inbounds i8, ptr %it.1, i64 38, !dbg !3237
  %38 = load i16, ptr %it_flags150, align 2, !dbg !3238, !tbaa !1248
  %39 = and i16 %38, -2561, !dbg !3239
  %40 = or disjoint i16 %39, 2048, !dbg !3239
  store i16 %40, ptr %it_flags150, align 2, !dbg !3239, !tbaa !1248
  %41 = and i16 %38, 2, !dbg !3240
  %tobool160.not = icmp eq i16 %41, 0, !dbg !3240
  br i1 %tobool160.not, label %if.end175, label %if.then161, !dbg !3243

if.then161:                                       ; preds = %if.end149
  %42 = and i16 %bf.load135, 1024, !dbg !3244
  %tobool166.not = icmp eq i16 %42, 0, !dbg !3244
  br i1 %tobool166.not, label %cond.false169, label %cond.true167, !dbg !3244

cond.true167:                                     ; preds = %if.then161
  %cas_id_in168 = getelementptr inbounds i8, ptr %of, i64 32, !dbg !3244
  %43 = load i64, ptr %cas_id_in168, align 8, !dbg !3244, !tbaa !2463
  br label %cond.end171, !dbg !3244

cond.false169:                                    ; preds = %if.then161
  %call170 = call i64 @get_cas_id() #13, !dbg !3244
  br label %cond.end171, !dbg !3244

cond.end171:                                      ; preds = %cond.false169, %cond.true167
  %cond172 = phi i64 [ %43, %cond.true167 ], [ %call170, %cond.false169 ], !dbg !3244
  %data173 = getelementptr inbounds i8, ptr %it.1, i64 48, !dbg !3244
  store i64 %cond172, ptr %data173, align 8, !dbg !3244, !tbaa !1240
  br label %if.end175, !dbg !3244

if.end175:                                        ; preds = %cond.end171, %if.end149
  %44 = load i8, ptr %noreply, align 4, !dbg !3246, !tbaa !1302, !range !1296, !noundef !1297
  %tobool177 = trunc nuw i8 %44 to i1, !dbg !3246
  br i1 %tobool177, label %if.then178, label %if.then244, !dbg !3248

if.then178:                                       ; preds = %if.end175
  %skip = getelementptr inbounds i8, ptr %0, i64 118, !dbg !3249
  store i8 1, ptr %skip, align 2, !dbg !3250, !tbaa !1367
  br label %if.then244, !dbg !3251

if.else182:                                       ; preds = %if.end134
  %45 = load ptr, ptr %thread, align 8, !dbg !3252, !tbaa !1234
  %stats184 = getelementptr inbounds i8, ptr %45, i64 352, !dbg !3253
  %call186 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats184) #13, !dbg !3254
  %46 = load ptr, ptr %thread, align 8, !dbg !3255, !tbaa !1234
  %slab_stats = getelementptr inbounds i8, ptr %46, i64 632, !dbg !3256
  %slabs_clsid = getelementptr inbounds i8, ptr %it.1, i64 40, !dbg !3257
  %47 = load i8, ptr %slabs_clsid, align 8, !dbg !3257, !tbaa !1240
  %48 = and i8 %47, 63, !dbg !3257
  %idxprom191 = zext nneg i8 %48 to i64
  %delete_hits = getelementptr inbounds [64 x %struct.slab_stats], ptr %slab_stats, i64 0, i64 %idxprom191, i32 3, !dbg !3258
  %49 = load i64, ptr %delete_hits, align 8, !dbg !3259, !tbaa !3260
  %inc193 = add i64 %49, 1, !dbg !3259
  store i64 %inc193, ptr %delete_hits, align 8, !dbg !3259, !tbaa !3260
  %stats195 = getelementptr inbounds i8, ptr %46, i64 352, !dbg !3261
  %call197 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats195) #13, !dbg !3262
  tail call void @llvm.dbg.value(metadata ptr null, metadata !3087, metadata !DIExpression()), !dbg !3263
  %50 = load i32, ptr @logger_key, align 4, !dbg !3264, !tbaa !1231
  %call199 = call ptr @pthread_getspecific(i32 noundef %50) #13, !dbg !3264
  tail call void @llvm.dbg.value(metadata ptr %call199, metadata !3087, metadata !DIExpression()), !dbg !3263
  %eflags = getelementptr inbounds i8, ptr %call199, i64 84, !dbg !3266
  %51 = load i16, ptr %eflags, align 4, !dbg !3266, !tbaa !3003
  %52 = and i16 %51, 8192, !dbg !3266
  %tobool202.not = icmp eq i16 %52, 0, !dbg !3266
  br i1 %tobool202.not, label %if.end205, label %if.then203, !dbg !3268

if.then203:                                       ; preds = %if.else182
  %call204 = call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %call199, i32 noundef 8, ptr noundef nonnull %it.1, i32 noundef 2) #13, !dbg !3266
  br label %if.end205, !dbg !3266

if.end205:                                        ; preds = %if.then203, %if.else182
  %bf.load208 = load i16, ptr %of, align 8, !dbg !3269
  %53 = and i16 %bf.load208, 8192, !dbg !3271
  %tobool212.not = icmp eq i16 %53, 0, !dbg !3271
  br i1 %tobool212.not, label %if.then213, label %if.end218, !dbg !3272

if.then213:                                       ; preds = %if.end205
  %54 = load i32, ptr %hv, align 4, !dbg !3273, !tbaa !1231
  call void @do_item_unlink(ptr noundef nonnull %it.1, i32 noundef %54) #13, !dbg !3275
  %55 = load ptr, ptr %thread, align 8, !dbg !3276, !tbaa !1234
  %storage = getelementptr inbounds i8, ptr %55, i64 6904, !dbg !3276
  %56 = load ptr, ptr %storage, align 8, !dbg !3276, !tbaa !3015
  call void @storage_delete(ptr noundef %56, ptr noundef nonnull %it.1) #13, !dbg !3276
  br label %if.end218, !dbg !3278

if.end218:                                        ; preds = %if.then213, %if.end205
  %57 = load i8, ptr %noreply, align 4, !dbg !3279, !tbaa !1302, !range !1296, !noundef !1297
  %tobool220 = trunc nuw i8 %57 to i1, !dbg !3279
  br i1 %tobool220, label %if.then221, label %if.then244, !dbg !3281

if.then221:                                       ; preds = %if.end218
  %skip222 = getelementptr inbounds i8, ptr %0, i64 118, !dbg !3282
  store i8 1, ptr %skip222, align 2, !dbg !3283, !tbaa !1367
  br label %if.then244, !dbg !3284

cleanup242:                                       ; preds = %for.end
  %58 = load ptr, ptr %thread, align 8, !dbg !3285, !tbaa !1234
  %stats229 = getelementptr inbounds i8, ptr %58, i64 352, !dbg !3287
  %call231 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats229) #13, !dbg !3288
  %59 = load ptr, ptr %thread, align 8, !dbg !3289, !tbaa !1234
  %delete_misses234 = getelementptr inbounds i8, ptr %59, i64 440, !dbg !3290
  %60 = load i64, ptr %delete_misses234, align 8, !dbg !3291, !tbaa !3195
  %inc235 = add i64 %60, 1, !dbg !3291
  store i64 %inc235, ptr %delete_misses234, align 8, !dbg !3291, !tbaa !3195
  %stats237 = getelementptr inbounds i8, ptr %59, i64 352, !dbg !3292
  %call239 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats237) #13, !dbg !3293
  store i16 17998, ptr %wbuf, align 8, !dbg !3294
  tail call void @llvm.dbg.value(metadata ptr null, metadata !3075, metadata !DIExpression()), !dbg !3094
  tail call void @llvm.dbg.label(metadata !3091), !dbg !3295
  br label %if.end245, !dbg !3296

if.then244:                                       ; preds = %if.end218, %if.then221, %if.end175, %if.then178, %if.then65, %cleanup.thread373
  %.sink = phi i16 [ 22597, %if.then65 ], [ 21326, %cleanup.thread373 ], [ 17480, %if.then178 ], [ 17480, %if.end175 ], [ 17480, %if.then221 ], [ 17480, %if.end218 ]
  %it.2.ph = phi ptr [ %call52, %if.then65 ], [ %call52, %cleanup.thread373 ], [ %it.1, %if.then178 ], [ %it.1, %if.end175 ], [ %it.1, %if.then221 ], [ %it.1, %if.end218 ]
  store i16 %.sink, ptr %wbuf, align 8, !dbg !3297
  tail call void @llvm.dbg.value(metadata ptr %it.2.ph, metadata !3075, metadata !DIExpression()), !dbg !3094
  tail call void @llvm.dbg.label(metadata !3091), !dbg !3295
  call void @do_item_remove(ptr noundef nonnull %it.2.ph) #13, !dbg !3298
  br label %if.end245, !dbg !3301

if.end245:                                        ; preds = %cleanup242, %if.then244
  %61 = load i32, ptr %hv, align 4, !dbg !3302, !tbaa !1231
  call void @item_unlock(i32 noundef %61) #13, !dbg !3303
  %sub.ptr.lhs.cast = ptrtoint ptr %p.0.lcssa to i64, !dbg !3304
  %sub.ptr.rhs.cast = ptrtoint ptr %wbuf to i64, !dbg !3304
  %sub.ptr.sub = sub i64 %sub.ptr.lhs.cast, %sub.ptr.rhs.cast, !dbg !3304
  %conv248 = trunc i64 %sub.ptr.sub to i32, !dbg !3305
  %wbytes = getelementptr inbounds i8, ptr %0, i64 16, !dbg !3306
  store i32 %conv248, ptr %wbytes, align 8, !dbg !3307, !tbaa !1355
  %sext = shl i64 %sub.ptr.sub, 32, !dbg !3308
  %idx.ext252 = ashr exact i64 %sext, 32, !dbg !3308
  %add.ptr253 = getelementptr inbounds i8, ptr %wbuf, i64 %idx.ext252, !dbg !3308
  store i16 2573, ptr %add.ptr253, align 1, !dbg !3309
  %62 = load i32, ptr %wbytes, align 8, !dbg !3310, !tbaa !1355
  %add = add nsw i32 %62, 2, !dbg !3310
  store i32 %add, ptr %wbytes, align 8, !dbg !3310, !tbaa !1355
  call void @resp_add_iov(ptr noundef nonnull %0, ptr noundef nonnull %wbuf, i32 noundef %add) #13, !dbg !3311
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 1) #13, !dbg !3312
  br label %cleanup261, !dbg !3313

if.then259:                                       ; preds = %if.then83
  tail call void @llvm.dbg.assign(metadata ptr @.str.66, metadata !3079, metadata !DIExpression(), metadata !3314, metadata ptr %errstr, metadata !DIExpression()), !dbg !3094
  tail call void @llvm.dbg.value(metadata ptr %call52, metadata !3075, metadata !DIExpression()), !dbg !3094
  tail call void @llvm.dbg.label(metadata !3092), !dbg !3315
  call void @do_item_remove(ptr noundef nonnull %call52) #13, !dbg !3316
  %63 = load i32, ptr %hv, align 4, !dbg !3319, !tbaa !1231
  call void @item_unlock(i32 noundef %63) #13, !dbg !3320
  br label %if.end260, !dbg !3321

if.end260:                                        ; preds = %sw.bb, %if.then259
  %64 = phi ptr [ @.str.66, %if.then259 ], [ @.str.52, %sw.bb ], !dbg !3322
  call void @out_errstring(ptr noundef %c, ptr noundef nonnull %64) #13, !dbg !3323
  br label %cleanup261, !dbg !3324

cleanup261:                                       ; preds = %if.end260, %if.end245, %if.then9, %if.then6, %if.then3, %if.then
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %errstr) #13, !dbg !3324
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %of) #13, !dbg !3324
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %hv) #13, !dbg !3324
  ret void, !dbg !3324
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_marithmetic_command(ptr noundef %c, ptr nocapture noundef %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !3325 {
entry:
  %of = alloca %struct._meta_flags, align 8, !DIAssignID !3352
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3333, metadata !DIExpression(), metadata !3352, metadata ptr %of, metadata !DIExpression()), !dbg !3353
  %errstr = alloca ptr, align 8, !DIAssignID !3354
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3334, metadata !DIExpression(), metadata !3354, metadata ptr %errstr, metadata !DIExpression()), !dbg !3353
  %it = alloca ptr, align 8, !DIAssignID !3355
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3340, metadata !DIExpression(), metadata !3355, metadata ptr %it, metadata !DIExpression()), !dbg !3353
  %tmpbuf = alloca [24 x i8], align 16, !DIAssignID !3356
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3341, metadata !DIExpression(), metadata !3356, metadata ptr %tmpbuf, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !3327, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !3328, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !3329, metadata !DIExpression()), !dbg !3353
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %of) #13, !dbg !3357
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %of, i8 0, i64 40, i1 false), !dbg !3358, !DIAssignID !3359
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !3333, metadata !DIExpression(), metadata !3359, metadata ptr %of, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !3333, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 128), metadata !3360, metadata ptr undef, metadata !DIExpression()), !dbg !3353
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %errstr) #13, !dbg !3361
  store ptr @.str.48, ptr %errstr, align 8, !dbg !3362, !tbaa !1271, !DIAssignID !3363
  tail call void @llvm.dbg.assign(metadata ptr @.str.48, metadata !3334, metadata !DIExpression(), metadata !3363, metadata ptr %errstr, metadata !DIExpression()), !dbg !3353
  %resp1 = getelementptr inbounds i8, ptr %c, i64 192, !dbg !3364
  %0 = load ptr, ptr %resp1, align 8, !dbg !3364, !tbaa !1351
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !3335, metadata !DIExpression()), !dbg !3353
  %wbuf = getelementptr inbounds i8, ptr %0, i64 160, !dbg !3365
  tail call void @llvm.dbg.value(metadata ptr %wbuf, metadata !3336, metadata !DIExpression()), !dbg !3353
  %delta = getelementptr inbounds i8, ptr %of, i64 40, !dbg !3366
  store i64 1, ptr %delta, align 8, !dbg !3367, !tbaa !3368, !DIAssignID !3369
  tail call void @llvm.dbg.assign(metadata i64 1, metadata !3333, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64), metadata !3369, metadata ptr %delta, metadata !DIExpression()), !dbg !3353
  %initial = getelementptr inbounds i8, ptr %of, i64 48, !dbg !3370
  store i64 0, ptr %initial, align 8, !dbg !3371, !tbaa !3372, !DIAssignID !3373
  tail call void @llvm.dbg.assign(metadata i64 0, metadata !3333, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64), metadata !3373, metadata ptr %initial, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata i8 1, metadata !3337, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata i8 0, metadata !3338, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3339, metadata !DIExpression()), !dbg !3353
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %it) #13, !dbg !3374
  store ptr null, ptr %it, align 8, !dbg !3375, !tbaa !1271, !DIAssignID !3376
  tail call void @llvm.dbg.assign(metadata ptr null, metadata !3340, metadata !DIExpression(), metadata !3376, metadata ptr %it, metadata !DIExpression()), !dbg !3353
  %cmp = icmp ult i64 %ntokens, 3, !dbg !3377
  br i1 %cmp, label %if.then, label %do.end, !dbg !3380

if.then:                                          ; preds = %entry
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.15) #13, !dbg !3381
  br label %cleanup312, !dbg !3381

do.end:                                           ; preds = %entry
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !3383
  %length = getelementptr inbounds i8, ptr %tokens, i64 24, !dbg !3385
  %1 = load i64, ptr %length, align 8, !dbg !3385, !tbaa !1578
  %cmp2 = icmp ugt i64 %1, 250, !dbg !3386
  br i1 %cmp2, label %if.then3, label %if.end4, !dbg !3387

if.then3:                                         ; preds = %do.end
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.48) #13, !dbg !3388
  br label %cleanup312, !dbg !3390

if.end4:                                          ; preds = %do.end
  %cmp5 = icmp ugt i64 %ntokens, 20, !dbg !3391
  br i1 %cmp5, label %if.then6, label %if.end7, !dbg !3393

if.then6:                                         ; preds = %if.end4
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.61) #13, !dbg !3394
  br label %cleanup312, !dbg !3396

if.end7:                                          ; preds = %if.end4
  %call = call fastcc i32 @_meta_flag_preparse(ptr noundef nonnull %tokens, i64 noundef 2, ptr noundef nonnull %of, ptr noundef nonnull %errstr), !dbg !3397
  %cmp8.not = icmp eq i32 %call, 0, !dbg !3399
  br i1 %cmp8.not, label %if.end10, label %if.then9, !dbg !3400

if.then9:                                         ; preds = %if.end7
  call void @out_errstring(ptr noundef nonnull %c, ptr noundef nonnull @.str.65) #13, !dbg !3401
  br label %cleanup312, !dbg !3403

if.end10:                                         ; preds = %if.end7
  %bf.load = load i16, ptr %of, align 8, !dbg !3404
  %noreply = getelementptr inbounds i8, ptr %c, i64 364, !dbg !3405
  %2 = lshr i16 %bf.load, 8, !dbg !3406
  %3 = trunc nuw i16 %2 to i8, !dbg !3406
  %frombool = and i8 %3, 1, !dbg !3406
  store i8 %frombool, ptr %noreply, align 4, !dbg !3406, !tbaa !1302
  %4 = load ptr, ptr %arrayidx, align 8, !dbg !3407, !tbaa !1573
  tail call void @llvm.dbg.value(metadata ptr %4, metadata !3330, metadata !DIExpression()), !dbg !3353
  %5 = load i64, ptr %length, align 8, !dbg !3408, !tbaa !1578
  tail call void @llvm.dbg.value(metadata i64 %5, metadata !3331, metadata !DIExpression()), !dbg !3353
  %mode = getelementptr inbounds i8, ptr %of, i64 2, !dbg !3409
  %6 = load i8, ptr %mode, align 2, !dbg !3409, !tbaa !2956
  switch i8 %6, label %error.thread474 [
    i8 0, label %sw.epilog
    i8 73, label %sw.epilog
    i8 43, label %sw.epilog
    i8 68, label %sw.bb14
    i8 45, label %sw.bb14
  ], !dbg !3410

sw.bb14:                                          ; preds = %if.end10, %if.end10
  tail call void @llvm.dbg.value(metadata i8 0, metadata !3337, metadata !DIExpression()), !dbg !3353
  br label %sw.epilog, !dbg !3411

sw.epilog:                                        ; preds = %if.end10, %if.end10, %sw.bb14, %if.end10
  %incr.0 = phi i1 [ false, %sw.bb14 ], [ true, %if.end10 ], [ true, %if.end10 ], [ true, %if.end10 ], !dbg !3353
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !3337, metadata !DIExpression()), !dbg !3353
  %7 = load ptr, ptr @hash, align 8, !dbg !3413, !tbaa !1271
  %call15 = call i32 %7(ptr noundef %4, i64 noundef %5) #13, !dbg !3413
  tail call void @llvm.dbg.value(metadata i32 %call15, metadata !3339, metadata !DIExpression()), !dbg !3353
  call void @item_lock(i32 noundef %call15) #13, !dbg !3414
  tail call void @llvm.dbg.value(metadata i8 1, metadata !3338, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata i8 0, metadata !3343, metadata !DIExpression()), !dbg !3353
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !3415
  %8 = load ptr, ptr %thread, align 8, !dbg !3415, !tbaa !1234
  %9 = load i64, ptr %delta, align 8, !dbg !3416, !tbaa !3368
  %req_cas_id = getelementptr inbounds i8, ptr %of, i64 24, !dbg !3417
  %call19 = call i32 @do_add_delta(ptr noundef %8, ptr noundef %4, i64 noundef %5, i1 noundef zeroext %incr.0, i64 noundef %9, ptr noundef nonnull %tmpbuf, ptr noundef nonnull %req_cas_id, i32 noundef %call15, ptr noundef nonnull %it) #13, !dbg !3418
  switch i32 %call19, label %sw.epilog130 [
    i32 0, label %sw.bb20
    i32 1, label %sw.bb37
    i32 2, label %sw.bb38
    i32 3, label %sw.bb39
    i32 4, label %sw.bb128
  ], !dbg !3419

sw.bb20:                                          ; preds = %sw.epilog
  %10 = load i8, ptr %noreply, align 4, !dbg !3420, !tbaa !1302, !range !1296, !noundef !1297
  %tobool22 = trunc nuw i8 %10 to i1, !dbg !3420
  br i1 %tobool22, label %if.then23, label %if.end24, !dbg !3422

if.then23:                                        ; preds = %sw.bb20
  %skip = getelementptr inbounds i8, ptr %0, i64 118, !dbg !3423
  store i8 1, ptr %skip, align 2, !dbg !3424, !tbaa !1367
  br label %if.end24, !dbg !3425

if.end24:                                         ; preds = %if.then23, %sw.bb20
  %bf.load25 = load i16, ptr %of, align 8, !dbg !3426
  %11 = and i16 %bf.load25, 1024, !dbg !3428
  %tobool29.not = icmp eq i16 %11, 0, !dbg !3428
  br i1 %tobool29.not, label %sw.epilog130, label %if.then30, !dbg !3429

if.then30:                                        ; preds = %if.end24
  %12 = load ptr, ptr %it, align 8, !dbg !3430, !tbaa !1271
  %it_flags = getelementptr inbounds i8, ptr %12, i64 38, !dbg !3430
  %13 = load i16, ptr %it_flags, align 2, !dbg !3430, !tbaa !1248
  %14 = and i16 %13, 2, !dbg !3430
  %tobool32.not = icmp eq i16 %14, 0, !dbg !3430
  br i1 %tobool32.not, label %if.then132, label %if.then33, !dbg !3434

if.then33:                                        ; preds = %if.then30
  %cas_id_in = getelementptr inbounds i8, ptr %of, i64 32, !dbg !3435
  %15 = load i64, ptr %cas_id_in, align 8, !dbg !3435, !tbaa !2463
  %data = getelementptr inbounds i8, ptr %12, i64 48, !dbg !3435
  store i64 %15, ptr %data, align 8, !dbg !3435, !tbaa !1240
  br label %sw.epilog130, !dbg !3435

sw.bb37:                                          ; preds = %sw.epilog
  store ptr @.str.68, ptr %errstr, align 8, !dbg !3437, !tbaa !1271, !DIAssignID !3438
  tail call void @llvm.dbg.assign(metadata ptr @.str.68, metadata !3334, metadata !DIExpression(), metadata !3438, metadata ptr %errstr, metadata !DIExpression()), !dbg !3353
  br label %error, !dbg !3439

sw.bb38:                                          ; preds = %sw.epilog
  store ptr @.str.66, ptr %errstr, align 8, !dbg !3440, !tbaa !1271, !DIAssignID !3441
  tail call void @llvm.dbg.assign(metadata ptr @.str.66, metadata !3334, metadata !DIExpression(), metadata !3441, metadata ptr %errstr, metadata !DIExpression()), !dbg !3353
  br label %error, !dbg !3442

sw.bb39:                                          ; preds = %sw.epilog
  %bf.load40 = load i16, ptr %of, align 8, !dbg !3443
  %16 = and i16 %bf.load40, 8, !dbg !3444
  %tobool44.not = icmp eq i16 %16, 0, !dbg !3444
  br i1 %tobool44.not, label %if.else110, label %if.then45, !dbg !3445

if.then45:                                        ; preds = %sw.bb39
  %17 = load i64, ptr %initial, align 8, !dbg !3446, !tbaa !3372
  %call48 = call ptr @itoa_u64(i64 noundef %17, ptr noundef nonnull %tmpbuf) #13, !dbg !3447
  %call50 = call i64 @strlen(ptr noundef nonnull dereferenceable(1) %tmpbuf) #15, !dbg !3448
  %conv51 = trunc i64 %call50 to i32, !dbg !3448
  tail call void @llvm.dbg.value(metadata i32 %conv51, metadata !3344, metadata !DIExpression()), !dbg !3449
  %add = add nsw i32 %conv51, 2, !dbg !3450
  %call52 = call ptr @item_alloc(ptr noundef %4, i64 noundef %5, i32 noundef 0, i32 noundef 0, i32 noundef %add) #13, !dbg !3451
  store ptr %call52, ptr %it, align 8, !dbg !3452, !tbaa !1271, !DIAssignID !3453
  tail call void @llvm.dbg.assign(metadata ptr %call52, metadata !3340, metadata !DIExpression(), metadata !3453, metadata ptr %it, metadata !DIExpression()), !dbg !3353
  %cmp53.not = icmp eq ptr %call52, null, !dbg !3454
  br i1 %cmp53.not, label %if.end308.thread, label %if.then55, !dbg !3456

if.then55:                                        ; preds = %if.then45
  %data56 = getelementptr inbounds i8, ptr %call52, i64 48, !dbg !3457
  %nkey57 = getelementptr inbounds i8, ptr %call52, i64 41, !dbg !3457
  %18 = load i8, ptr %nkey57, align 1, !dbg !3457, !tbaa !1240
  %idx.ext = zext i8 %18 to i64
  %add.ptr = getelementptr inbounds i8, ptr %data56, i64 %idx.ext, !dbg !3457
  %add.ptr59 = getelementptr inbounds i8, ptr %add.ptr, i64 1, !dbg !3457
  %it_flags60 = getelementptr inbounds i8, ptr %call52, i64 38, !dbg !3457
  %19 = load i16, ptr %it_flags60, align 2, !dbg !3457, !tbaa !1248
  %conv61 = zext i16 %19 to i32, !dbg !3457
  %and62 = lshr i32 %conv61, 6, !dbg !3457
  %20 = and i32 %and62, 4, !dbg !3457
  %cond = zext nneg i32 %20 to i64, !dbg !3457
  %add.ptr64 = getelementptr inbounds i8, ptr %add.ptr59, i64 %cond, !dbg !3457
  %and67 = shl nuw nsw i32 %conv61, 2, !dbg !3457
  %21 = and i32 %and67, 8, !dbg !3457
  %cond69 = zext nneg i32 %21 to i64, !dbg !3457
  %add.ptr70 = getelementptr inbounds i8, ptr %add.ptr64, i64 %cond69, !dbg !3457
  %sext = shl i64 %call50, 32, !dbg !3459
  %conv72 = ashr exact i64 %sext, 32, !dbg !3459
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr70, ptr nonnull align 16 %tmpbuf, i64 %conv72, i1 false), !dbg !3460
  %22 = load ptr, ptr %it, align 8, !dbg !3461, !tbaa !1271
  %data73 = getelementptr inbounds i8, ptr %22, i64 48, !dbg !3461
  %nkey74 = getelementptr inbounds i8, ptr %22, i64 41, !dbg !3461
  %23 = load i8, ptr %nkey74, align 1, !dbg !3461, !tbaa !1240
  %idx.ext76 = zext i8 %23 to i64
  %add.ptr77 = getelementptr inbounds i8, ptr %data73, i64 %idx.ext76, !dbg !3461
  %add.ptr78 = getelementptr inbounds i8, ptr %add.ptr77, i64 1, !dbg !3461
  %it_flags79 = getelementptr inbounds i8, ptr %22, i64 38, !dbg !3461
  %24 = load i16, ptr %it_flags79, align 2, !dbg !3461, !tbaa !1248
  %conv80 = zext i16 %24 to i32, !dbg !3461
  %and81 = lshr i32 %conv80, 6, !dbg !3461
  %25 = and i32 %and81, 4, !dbg !3461
  %cond83 = zext nneg i32 %25 to i64, !dbg !3461
  %add.ptr84 = getelementptr inbounds i8, ptr %add.ptr78, i64 %cond83, !dbg !3461
  %and87 = shl nuw nsw i32 %conv80, 2, !dbg !3461
  %26 = and i32 %and87, 8, !dbg !3461
  %cond89 = zext nneg i32 %26 to i64, !dbg !3461
  %add.ptr90 = getelementptr inbounds i8, ptr %add.ptr84, i64 %cond89, !dbg !3461
  %add.ptr92 = getelementptr inbounds i8, ptr %add.ptr90, i64 %conv72, !dbg !3462
  store i16 2573, ptr %add.ptr92, align 1, !dbg !3463
  %27 = load ptr, ptr %it, align 8, !dbg !3464, !tbaa !1271
  %28 = load ptr, ptr %thread, align 8, !dbg !3466, !tbaa !1234
  %bf.load94 = load i16, ptr %of, align 8, !dbg !3467
  %29 = and i16 %bf.load94, 1024, !dbg !3468
  %tobool98.not = icmp eq i16 %29, 0, !dbg !3468
  br i1 %tobool98.not, label %cond.false, label %cond.true, !dbg !3468

cond.true:                                        ; preds = %if.then55
  %cas_id_in99 = getelementptr inbounds i8, ptr %of, i64 32, !dbg !3469
  %30 = load i64, ptr %cas_id_in99, align 8, !dbg !3469, !tbaa !2463
  br label %cond.end, !dbg !3468

cond.false:                                       ; preds = %if.then55
  %call100 = call i64 @get_cas_id() #13, !dbg !3470
  br label %cond.end, !dbg !3468

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond101 = phi i64 [ %30, %cond.true ], [ %call100, %cond.false ], !dbg !3468
  %call102 = call i32 @do_store_item(ptr noundef %27, i32 noundef 1, ptr noundef %28, i32 noundef %call15, ptr noundef null, ptr noundef null, i64 noundef %cond101, i1 noundef zeroext false) #13, !dbg !3471
  %tobool103.not.not = icmp eq i32 %call102, 0, !dbg !3471
  br i1 %tobool103.not.not, label %if.else, label %sw.epilog130, !dbg !3472

if.else:                                          ; preds = %cond.end
  store i16 21326, ptr %wbuf, align 8, !dbg !3473
  br label %sw.epilog130

if.end308.thread:                                 ; preds = %if.then45
  store ptr @.str.69, ptr %errstr, align 8, !dbg !3475, !tbaa !1271, !DIAssignID !3477
  tail call void @llvm.dbg.assign(metadata ptr @.str.69, metadata !3334, metadata !DIExpression(), metadata !3477, metadata ptr %errstr, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !3343, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata i32 %call15, metadata !3339, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !3338, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.label(metadata !3351), !dbg !3478
  br label %if.then310, !dbg !3479

if.else110:                                       ; preds = %sw.bb39
  %31 = load ptr, ptr %thread, align 8, !dbg !3480, !tbaa !1234
  %stats = getelementptr inbounds i8, ptr %31, i64 352, !dbg !3482
  %call112 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #13, !dbg !3483
  %32 = load ptr, ptr %thread, align 8, !dbg !3484, !tbaa !1234
  %. = select i1 %incr.0, i64 448, i64 456
  %decr_misses = getelementptr inbounds i8, ptr %32, i64 %., !dbg !3484
  %33 = load i64, ptr %decr_misses, align 8, !dbg !3484, !tbaa !1308
  %inc120 = add i64 %33, 1, !dbg !3484
  store i64 %inc120, ptr %decr_misses, align 8, !dbg !3484, !tbaa !1308
  %stats123 = getelementptr inbounds i8, ptr %32, i64 352, !dbg !3486
  %call125 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats123) #13, !dbg !3487
  store i16 17998, ptr %wbuf, align 1, !dbg !3488
  %add.ptr126 = getelementptr inbounds i8, ptr %0, i64 162, !dbg !3489
  tail call void @llvm.dbg.value(metadata ptr %add.ptr126, metadata !3336, metadata !DIExpression()), !dbg !3353
  br label %sw.epilog130

sw.bb128:                                         ; preds = %sw.epilog
  store i16 22597, ptr %wbuf, align 1, !dbg !3490
  %add.ptr129 = getelementptr inbounds i8, ptr %0, i64 162, !dbg !3491
  tail call void @llvm.dbg.value(metadata ptr %add.ptr129, metadata !3336, metadata !DIExpression()), !dbg !3353
  br label %sw.epilog130, !dbg !3492

sw.epilog130:                                     ; preds = %if.else, %cond.end, %if.else110, %if.end24, %if.then33, %sw.epilog, %sw.bb128
  %item_created.2.ph = phi i1 [ false, %if.end24 ], [ false, %if.then33 ], [ false, %if.else110 ], [ false, %sw.bb128 ], [ false, %sw.epilog ], [ false, %if.else ], [ true, %cond.end ]
  %p.0.ph = phi ptr [ %wbuf, %if.end24 ], [ %wbuf, %if.then33 ], [ %add.ptr126, %if.else110 ], [ %add.ptr129, %sw.bb128 ], [ %wbuf, %sw.epilog ], [ %wbuf, %if.else ], [ %wbuf, %cond.end ]
  %.pr = load ptr, ptr %it, align 8, !dbg !3493, !tbaa !1271
  tail call void @llvm.dbg.value(metadata ptr %p.0.ph, metadata !3336, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !3343, metadata !DIExpression()), !dbg !3353
  %tobool131.not = icmp eq ptr %.pr, null, !dbg !3493
  br i1 %tobool131.not, label %for.cond241.preheader, label %sw.epilog130.if.then132_crit_edge, !dbg !3494

sw.epilog130.if.then132_crit_edge:                ; preds = %sw.epilog130
  %bf.load136.pre = load i16, ptr %of, align 8, !dbg !3495
  br label %if.then132, !dbg !3494

for.cond241.preheader:                            ; preds = %sw.epilog130
  %sub243 = add nsw i64 %ntokens, -1
  tail call void @llvm.dbg.value(metadata i32 2, metadata !3332, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata ptr %p.0.ph, metadata !3336, metadata !DIExpression()), !dbg !3353
  %cmp244494 = icmp ugt i64 %sub243, 2, !dbg !3497
  br i1 %cmp244494, label %for.body246, label %if.end291, !dbg !3501

if.then132:                                       ; preds = %sw.epilog130.if.then132_crit_edge, %if.then30
  %bf.load136 = phi i16 [ %bf.load136.pre, %sw.epilog130.if.then132_crit_edge ], [ %bf.load25, %if.then30 ], !dbg !3495
  %p.0462 = phi ptr [ %p.0.ph, %sw.epilog130.if.then132_crit_edge ], [ %wbuf, %if.then30 ]
  %item_created.2461 = phi i1 [ %item_created.2.ph, %sw.epilog130.if.then132_crit_edge ], [ false, %if.then30 ]
  %call135 = call i64 @strlen(ptr noundef nonnull dereferenceable(1) %tmpbuf) #15, !dbg !3502
  tail call void @llvm.dbg.value(metadata i64 %call135, metadata !3348, metadata !DIExpression()), !dbg !3503
  %34 = and i16 %bf.load136, 64, !dbg !3504
  %tobool140.not = icmp eq i16 %34, 0, !dbg !3504
  br i1 %tobool140.not, label %if.else145, label %if.then141, !dbg !3505

if.then141:                                       ; preds = %if.then132
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %p.0462, ptr noundef nonnull align 1 dereferenceable(3) @.str.51, i64 3, i1 false), !dbg !3506
  %conv142 = trunc i64 %call135 to i32, !dbg !3508
  %add.ptr143 = getelementptr inbounds i8, ptr %p.0462, i64 3, !dbg !3509
  %call144 = call ptr @itoa_u32(i32 noundef %conv142, ptr noundef nonnull %add.ptr143) #13, !dbg !3510
  tail call void @llvm.dbg.value(metadata ptr %call144, metadata !3336, metadata !DIExpression()), !dbg !3353
  br label %if.end147, !dbg !3511

if.else145:                                       ; preds = %if.then132
  store i16 17480, ptr %p.0462, align 1, !dbg !3512
  %add.ptr146 = getelementptr inbounds i8, ptr %p.0462, i64 2, !dbg !3514
  tail call void @llvm.dbg.value(metadata ptr %add.ptr146, metadata !3336, metadata !DIExpression()), !dbg !3353
  br label %if.end147

if.end147:                                        ; preds = %if.else145, %if.then141
  %p.1 = phi ptr [ %call144, %if.then141 ], [ %add.ptr146, %if.else145 ], !dbg !3515
  tail call void @llvm.dbg.value(metadata ptr %p.1, metadata !3336, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata i32 2, metadata !3332, metadata !DIExpression()), !dbg !3353
  %sub = add nsw i64 %ntokens, -1
  tail call void @llvm.dbg.value(metadata i32 2, metadata !3332, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata ptr %p.1, metadata !3336, metadata !DIExpression()), !dbg !3353
  %cmp149490 = icmp ugt i64 %sub, 2, !dbg !3516
  br i1 %cmp149490, label %for.body.lr.ph, label %for.end, !dbg !3519

for.body.lr.ph:                                   ; preds = %if.end147
  %autoviv_exptime = getelementptr inbounds i8, ptr %of, i64 8
  %exptime183 = getelementptr inbounds i8, ptr %of, i64 4
  br label %for.body, !dbg !3519

for.body:                                         ; preds = %for.body.lr.ph, %for.inc
  %indvars.iv = phi i64 [ 2, %for.body.lr.ph ], [ %indvars.iv.next, %for.inc ]
  %p.2491 = phi ptr [ %p.1, %for.body.lr.ph ], [ %p.3, %for.inc ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !3332, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata ptr %p.2491, metadata !3336, metadata !DIExpression()), !dbg !3353
  %arrayidx151 = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %indvars.iv, !dbg !3520
  %35 = load ptr, ptr %arrayidx151, align 8, !dbg !3522, !tbaa !1573
  %36 = load i8, ptr %35, align 1, !dbg !3520, !tbaa !1240
  switch i8 %36, label %for.inc [
    i8 99, label %sw.bb155
    i8 116, label %sw.bb169
    i8 84, label %sw.bb182
    i8 78, label %sw.bb185
    i8 79, label %sw.bb190
    i8 107, label %sw.bb208
  ], !dbg !3523

sw.bb155:                                         ; preds = %for.body
  store i8 32, ptr %p.2491, align 1, !dbg !3524, !tbaa !1240
  %add.ptr156 = getelementptr inbounds i8, ptr %p.2491, i64 1, !dbg !3524
  store i8 99, ptr %add.ptr156, align 1, !dbg !3524, !tbaa !1240
  %add.ptr157 = getelementptr inbounds i8, ptr %p.2491, i64 2, !dbg !3524
  tail call void @llvm.dbg.value(metadata ptr %add.ptr157, metadata !3336, metadata !DIExpression()), !dbg !3353
  %37 = load ptr, ptr %it, align 8, !dbg !3527, !tbaa !1271
  %it_flags158 = getelementptr inbounds i8, ptr %37, i64 38, !dbg !3527
  %38 = load i16, ptr %it_flags158, align 2, !dbg !3527, !tbaa !1248
  %39 = and i16 %38, 2, !dbg !3527
  %tobool161.not = icmp eq i16 %39, 0, !dbg !3527
  br i1 %tobool161.not, label %cond.end166, label %cond.true162, !dbg !3527

cond.true162:                                     ; preds = %sw.bb155
  %data163 = getelementptr inbounds i8, ptr %37, i64 48, !dbg !3527
  %40 = load i64, ptr %data163, align 8, !dbg !3527, !tbaa !1240
  br label %cond.end166, !dbg !3527

cond.end166:                                      ; preds = %sw.bb155, %cond.true162
  %cond167 = phi i64 [ %40, %cond.true162 ], [ 0, %sw.bb155 ], !dbg !3527
  %call168 = call ptr @itoa_u64(i64 noundef %cond167, ptr noundef nonnull %add.ptr157) #13, !dbg !3528
  tail call void @llvm.dbg.value(metadata ptr %call168, metadata !3336, metadata !DIExpression()), !dbg !3353
  br label %for.inc, !dbg !3529

sw.bb169:                                         ; preds = %for.body
  store i8 32, ptr %p.2491, align 1, !dbg !3530, !tbaa !1240
  %add.ptr170 = getelementptr inbounds i8, ptr %p.2491, i64 1, !dbg !3530
  store i8 116, ptr %add.ptr170, align 1, !dbg !3530, !tbaa !1240
  %add.ptr171 = getelementptr inbounds i8, ptr %p.2491, i64 2, !dbg !3530
  tail call void @llvm.dbg.value(metadata ptr %add.ptr171, metadata !3336, metadata !DIExpression()), !dbg !3353
  %41 = load ptr, ptr %it, align 8, !dbg !3532, !tbaa !1271
  %exptime = getelementptr inbounds i8, ptr %41, i64 28, !dbg !3534
  %42 = load i32, ptr %exptime, align 4, !dbg !3534, !tbaa !1231
  %cmp172 = icmp eq i32 %42, 0, !dbg !3535
  br i1 %cmp172, label %if.then174, label %if.else177, !dbg !3536

if.then174:                                       ; preds = %sw.bb169
  store i8 45, ptr %add.ptr171, align 1, !dbg !3537, !tbaa !1240
  %add.ptr175 = getelementptr inbounds i8, ptr %p.2491, i64 3, !dbg !3539
  store i8 49, ptr %add.ptr175, align 1, !dbg !3540, !tbaa !1240
  %add.ptr176 = getelementptr inbounds i8, ptr %p.2491, i64 4, !dbg !3541
  tail call void @llvm.dbg.value(metadata ptr %add.ptr176, metadata !3336, metadata !DIExpression()), !dbg !3353
  br label %for.inc, !dbg !3542

if.else177:                                       ; preds = %sw.bb169
  %43 = load volatile i32, ptr @current_time, align 4, !dbg !3543, !tbaa !1231
  %sub179 = sub i32 %42, %43, !dbg !3545
  %call180 = call ptr @itoa_u32(i32 noundef %sub179, ptr noundef nonnull %add.ptr171) #13, !dbg !3546
  tail call void @llvm.dbg.value(metadata ptr %call180, metadata !3336, metadata !DIExpression()), !dbg !3353
  br label %for.inc

sw.bb182:                                         ; preds = %for.body
  %44 = load i32, ptr %exptime183, align 4, !dbg !3547, !tbaa !2495
  %45 = load ptr, ptr %it, align 8, !dbg !3548, !tbaa !1271
  %exptime184 = getelementptr inbounds i8, ptr %45, i64 28, !dbg !3549
  store i32 %44, ptr %exptime184, align 4, !dbg !3550, !tbaa !1231
  br label %for.inc, !dbg !3551

sw.bb185:                                         ; preds = %for.body
  br i1 %item_created.2461, label %if.then187, label %for.inc, !dbg !3552

if.then187:                                       ; preds = %sw.bb185
  %46 = load i32, ptr %autoviv_exptime, align 8, !dbg !3553, !tbaa !2502
  %47 = load ptr, ptr %it, align 8, !dbg !3556, !tbaa !1271
  %exptime188 = getelementptr inbounds i8, ptr %47, i64 28, !dbg !3557
  store i32 %46, ptr %exptime188, align 4, !dbg !3558, !tbaa !1231
  br label %for.inc, !dbg !3559

sw.bb190:                                         ; preds = %for.body
  %length193 = getelementptr inbounds i8, ptr %arrayidx151, i64 8, !dbg !3560
  %48 = load i64, ptr %length193, align 8, !dbg !3560, !tbaa !1578
  %cmp194 = icmp ugt i64 %48, 32, !dbg !3562
  br i1 %cmp194, label %cleanup237, label %if.end197, !dbg !3563

if.end197:                                        ; preds = %sw.bb190
  store i8 32, ptr %p.2491, align 1, !dbg !3564, !tbaa !1240
  %incdec.ptr = getelementptr inbounds i8, ptr %p.2491, i64 1, !dbg !3564
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !3336, metadata !DIExpression()), !dbg !3353
  %49 = load ptr, ptr %arrayidx151, align 8, !dbg !3566, !tbaa !1573
  %50 = load i64, ptr %length193, align 8, !dbg !3567, !tbaa !1578
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %incdec.ptr, ptr align 1 %49, i64 %50, i1 false), !dbg !3568
  %51 = load i64, ptr %length193, align 8, !dbg !3569, !tbaa !1578
  %add.ptr207 = getelementptr inbounds i8, ptr %incdec.ptr, i64 %51, !dbg !3570
  tail call void @llvm.dbg.value(metadata ptr %add.ptr207, metadata !3336, metadata !DIExpression()), !dbg !3353
  br label %for.inc, !dbg !3571

sw.bb208:                                         ; preds = %for.body
  store i8 32, ptr %p.2491, align 1, !dbg !3572, !tbaa !1240
  %add.ptr209 = getelementptr inbounds i8, ptr %p.2491, i64 1, !dbg !3572
  store i8 107, ptr %add.ptr209, align 1, !dbg !3572, !tbaa !1240
  %add.ptr210 = getelementptr inbounds i8, ptr %p.2491, i64 2, !dbg !3572
  tail call void @llvm.dbg.value(metadata ptr %add.ptr210, metadata !3336, metadata !DIExpression()), !dbg !3353
  %bf.load211 = load i16, ptr %of, align 8, !dbg !3575
  %52 = and i16 %bf.load211, 4096, !dbg !3575
  %tobool215.not = icmp eq i16 %52, 0, !dbg !3575
  br i1 %tobool215.not, label %if.then216, label %if.else218, !dbg !3577

if.then216:                                       ; preds = %sw.bb208
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr210, ptr align 1 %4, i64 %5, i1 false), !dbg !3578
  %add.ptr217 = getelementptr inbounds i8, ptr %add.ptr210, i64 %5, !dbg !3578
  tail call void @llvm.dbg.value(metadata ptr %add.ptr217, metadata !3336, metadata !DIExpression()), !dbg !3353
  br label %for.inc, !dbg !3578

if.else218:                                       ; preds = %sw.bb208
  %call219 = call i64 @base64_encode(ptr noundef %4, i64 noundef %5, ptr noundef nonnull %add.ptr210, i64 noundef 512) #13, !dbg !3580
  %add.ptr220 = getelementptr inbounds i8, ptr %add.ptr210, i64 %call219, !dbg !3580
  tail call void @llvm.dbg.value(metadata ptr %add.ptr220, metadata !3336, metadata !DIExpression()), !dbg !3353
  store i8 32, ptr %add.ptr220, align 1, !dbg !3580, !tbaa !1240
  %add.ptr221 = getelementptr inbounds i8, ptr %add.ptr220, i64 1, !dbg !3580
  store i8 98, ptr %add.ptr221, align 1, !dbg !3580, !tbaa !1240
  %add.ptr222 = getelementptr inbounds i8, ptr %add.ptr220, i64 2, !dbg !3580
  tail call void @llvm.dbg.value(metadata ptr %add.ptr222, metadata !3336, metadata !DIExpression()), !dbg !3353
  br label %for.inc

for.inc:                                          ; preds = %cond.end166, %sw.bb182, %if.end197, %for.body, %if.else177, %if.then174, %if.then187, %sw.bb185, %if.else218, %if.then216
  %p.3 = phi ptr [ %p.2491, %for.body ], [ %add.ptr222, %if.else218 ], [ %add.ptr217, %if.then216 ], [ %add.ptr207, %if.end197 ], [ %p.2491, %if.then187 ], [ %p.2491, %sw.bb185 ], [ %p.2491, %sw.bb182 ], [ %add.ptr176, %if.then174 ], [ %call180, %if.else177 ], [ %call168, %cond.end166 ], !dbg !3503
  tail call void @llvm.dbg.value(metadata ptr %p.3, metadata !3336, metadata !DIExpression()), !dbg !3353
  %indvars.iv.next = add nuw i64 %indvars.iv, 1, !dbg !3582
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !3332, metadata !DIExpression()), !dbg !3353
  %exitcond.not = icmp eq i64 %indvars.iv.next, %sub, !dbg !3516
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !3519, !llvm.loop !3583

for.end:                                          ; preds = %for.inc, %if.end147
  %p.2.lcssa = phi ptr [ %p.1, %if.end147 ], [ %p.3, %for.inc ], !dbg !3585
  %bf.load226 = load i16, ptr %of, align 8, !dbg !3586
  %53 = and i16 %bf.load226, 64, !dbg !3588
  %tobool230.not = icmp eq i16 %53, 0, !dbg !3588
  br i1 %tobool230.not, label %cleanup237.thread, label %if.then231, !dbg !3589

if.then231:                                       ; preds = %for.end
  store i8 13, ptr %p.2.lcssa, align 1, !dbg !3590, !tbaa !1240
  %add.ptr232 = getelementptr inbounds i8, ptr %p.2.lcssa, i64 1, !dbg !3592
  store i8 10, ptr %add.ptr232, align 1, !dbg !3593, !tbaa !1240
  %add.ptr233 = getelementptr inbounds i8, ptr %p.2.lcssa, i64 2, !dbg !3594
  tail call void @llvm.dbg.value(metadata ptr %add.ptr233, metadata !3336, metadata !DIExpression()), !dbg !3353
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr233, ptr nonnull align 16 %tmpbuf, i64 %call135, i1 false), !dbg !3595
  %add.ptr235 = getelementptr inbounds i8, ptr %add.ptr233, i64 %call135, !dbg !3596
  tail call void @llvm.dbg.value(metadata ptr %add.ptr235, metadata !3336, metadata !DIExpression()), !dbg !3353
  br label %cleanup237.thread, !dbg !3597

cleanup237.thread:                                ; preds = %for.end, %if.then231
  %p.4 = phi ptr [ %add.ptr235, %if.then231 ], [ %p.2.lcssa, %for.end ], !dbg !3503
  tail call void @llvm.dbg.value(metadata ptr %p.4, metadata !3336, metadata !DIExpression()), !dbg !3353
  %54 = load ptr, ptr %it, align 8, !dbg !3598, !tbaa !1271
  call void @do_item_remove(ptr noundef %54) #13, !dbg !3599
  br label %if.end291

cleanup237:                                       ; preds = %sw.bb190
  store ptr @.str.52, ptr %errstr, align 8, !dbg !3600, !tbaa !1271, !DIAssignID !3602
  tail call void @llvm.dbg.assign(metadata ptr @.str.52, metadata !3334, metadata !DIExpression(), metadata !3602, metadata ptr %errstr, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !3336, metadata !DIExpression()), !dbg !3353
  br label %error

for.body246:                                      ; preds = %for.cond241.preheader, %for.inc288
  %indvars.iv500 = phi i64 [ %indvars.iv.next501, %for.inc288 ], [ 2, %for.cond241.preheader ]
  %p.6495 = phi ptr [ %p.7, %for.inc288 ], [ %p.0.ph, %for.cond241.preheader ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv500, metadata !3332, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata ptr %p.6495, metadata !3336, metadata !DIExpression()), !dbg !3353
  %arrayidx248 = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %indvars.iv500, !dbg !3603
  %55 = load ptr, ptr %arrayidx248, align 8, !dbg !3605, !tbaa !1573
  %56 = load i8, ptr %55, align 1, !dbg !3603, !tbaa !1240
  switch i8 %56, label %for.inc288 [
    i8 79, label %sw.bb252
    i8 107, label %sw.bb271
  ], !dbg !3606

sw.bb252:                                         ; preds = %for.body246
  %length255 = getelementptr inbounds i8, ptr %arrayidx248, i64 8, !dbg !3607
  %57 = load i64, ptr %length255, align 8, !dbg !3607, !tbaa !1578
  %cmp256 = icmp ugt i64 %57, 32, !dbg !3610
  br i1 %cmp256, label %if.then258, label %if.end259, !dbg !3611

if.then258:                                       ; preds = %sw.bb252
  store ptr @.str.52, ptr %errstr, align 8, !dbg !3612, !tbaa !1271, !DIAssignID !3614
  tail call void @llvm.dbg.assign(metadata ptr @.str.52, metadata !3334, metadata !DIExpression(), metadata !3614, metadata ptr %errstr, metadata !DIExpression()), !dbg !3353
  br label %error, !dbg !3615

if.end259:                                        ; preds = %sw.bb252
  store i8 32, ptr %p.6495, align 1, !dbg !3616, !tbaa !1240
  %incdec.ptr260 = getelementptr inbounds i8, ptr %p.6495, i64 1, !dbg !3616
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr260, metadata !3336, metadata !DIExpression()), !dbg !3353
  %58 = load ptr, ptr %arrayidx248, align 8, !dbg !3618, !tbaa !1573
  %59 = load i64, ptr %length255, align 8, !dbg !3619, !tbaa !1578
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %incdec.ptr260, ptr align 1 %58, i64 %59, i1 false), !dbg !3620
  %60 = load i64, ptr %length255, align 8, !dbg !3621, !tbaa !1578
  %add.ptr270 = getelementptr inbounds i8, ptr %incdec.ptr260, i64 %60, !dbg !3622
  tail call void @llvm.dbg.value(metadata ptr %add.ptr270, metadata !3336, metadata !DIExpression()), !dbg !3353
  br label %for.inc288, !dbg !3623

sw.bb271:                                         ; preds = %for.body246
  store i8 32, ptr %p.6495, align 1, !dbg !3624, !tbaa !1240
  %add.ptr272 = getelementptr inbounds i8, ptr %p.6495, i64 1, !dbg !3624
  store i8 107, ptr %add.ptr272, align 1, !dbg !3624, !tbaa !1240
  %add.ptr273 = getelementptr inbounds i8, ptr %p.6495, i64 2, !dbg !3624
  tail call void @llvm.dbg.value(metadata ptr %add.ptr273, metadata !3336, metadata !DIExpression()), !dbg !3353
  %bf.load274 = load i16, ptr %of, align 8, !dbg !3627
  %61 = and i16 %bf.load274, 4096, !dbg !3627
  %tobool278.not = icmp eq i16 %61, 0, !dbg !3627
  br i1 %tobool278.not, label %if.then279, label %if.else281, !dbg !3629

if.then279:                                       ; preds = %sw.bb271
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr273, ptr align 1 %4, i64 %5, i1 false), !dbg !3630
  %add.ptr280 = getelementptr inbounds i8, ptr %add.ptr273, i64 %5, !dbg !3630
  tail call void @llvm.dbg.value(metadata ptr %add.ptr280, metadata !3336, metadata !DIExpression()), !dbg !3353
  br label %for.inc288, !dbg !3630

if.else281:                                       ; preds = %sw.bb271
  %call282 = call i64 @base64_encode(ptr noundef %4, i64 noundef %5, ptr noundef nonnull %add.ptr273, i64 noundef 512) #13, !dbg !3632
  %add.ptr283 = getelementptr inbounds i8, ptr %add.ptr273, i64 %call282, !dbg !3632
  tail call void @llvm.dbg.value(metadata ptr %add.ptr283, metadata !3336, metadata !DIExpression()), !dbg !3353
  store i8 32, ptr %add.ptr283, align 1, !dbg !3632, !tbaa !1240
  %add.ptr284 = getelementptr inbounds i8, ptr %add.ptr283, i64 1, !dbg !3632
  store i8 98, ptr %add.ptr284, align 1, !dbg !3632, !tbaa !1240
  %add.ptr285 = getelementptr inbounds i8, ptr %add.ptr283, i64 2, !dbg !3632
  tail call void @llvm.dbg.value(metadata ptr %add.ptr285, metadata !3336, metadata !DIExpression()), !dbg !3353
  br label %for.inc288

for.inc288:                                       ; preds = %if.end259, %for.body246, %if.else281, %if.then279
  %p.7 = phi ptr [ %p.6495, %for.body246 ], [ %add.ptr285, %if.else281 ], [ %add.ptr280, %if.then279 ], [ %add.ptr270, %if.end259 ], !dbg !3353
  tail call void @llvm.dbg.value(metadata ptr %p.7, metadata !3336, metadata !DIExpression()), !dbg !3353
  %indvars.iv.next501 = add nuw i64 %indvars.iv500, 1, !dbg !3634
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next501, metadata !3332, metadata !DIExpression()), !dbg !3353
  %exitcond503.not = icmp eq i64 %indvars.iv.next501, %sub243, !dbg !3497
  br i1 %exitcond503.not, label %if.end291, label %for.body246, !dbg !3501, !llvm.loop !3635

if.end291:                                        ; preds = %for.inc288, %for.cond241.preheader, %cleanup237.thread
  %p.8 = phi ptr [ %p.4, %cleanup237.thread ], [ %p.0.ph, %for.cond241.preheader ], [ %p.7, %for.inc288 ], !dbg !3353
  tail call void @llvm.dbg.value(metadata ptr %p.8, metadata !3336, metadata !DIExpression()), !dbg !3353
  call void @item_unlock(i32 noundef %call15) #13, !dbg !3637
  %sub.ptr.lhs.cast = ptrtoint ptr %p.8 to i64, !dbg !3638
  %sub.ptr.rhs.cast = ptrtoint ptr %wbuf to i64, !dbg !3638
  %sub.ptr.sub = sub i64 %sub.ptr.lhs.cast, %sub.ptr.rhs.cast, !dbg !3638
  %conv294 = trunc i64 %sub.ptr.sub to i32, !dbg !3639
  %wbytes = getelementptr inbounds i8, ptr %0, i64 16, !dbg !3640
  store i32 %conv294, ptr %wbytes, align 8, !dbg !3641, !tbaa !1355
  %sext455 = shl i64 %sub.ptr.sub, 32, !dbg !3642
  %idx.ext298 = ashr exact i64 %sext455, 32, !dbg !3642
  %add.ptr299 = getelementptr inbounds i8, ptr %wbuf, i64 %idx.ext298, !dbg !3642
  store i16 2573, ptr %add.ptr299, align 1, !dbg !3643
  %62 = load i32, ptr %wbytes, align 8, !dbg !3644, !tbaa !1355
  %add301 = add nsw i32 %62, 2, !dbg !3644
  store i32 %add301, ptr %wbytes, align 8, !dbg !3644, !tbaa !1355
  call void @resp_add_iov(ptr noundef %0, ptr noundef nonnull %wbuf, i32 noundef %add301) #13, !dbg !3645
  call void @conn_set_state(ptr noundef %c, i32 noundef 1) #13, !dbg !3646
  br label %cleanup312, !dbg !3647

error:                                            ; preds = %cleanup237, %if.then258, %sw.bb38, %sw.bb37
  %63 = phi ptr [ @.str.52, %cleanup237 ], [ @.str.52, %if.then258 ], [ @.str.66, %sw.bb38 ], [ @.str.68, %sw.bb37 ]
  %.pr465 = load ptr, ptr %it, align 8, !dbg !3648, !tbaa !1271
  tail call void @llvm.dbg.value(metadata i32 %call15, metadata !3339, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !3338, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.label(metadata !3351), !dbg !3478
  %cmp305.not = icmp eq ptr %.pr465, null, !dbg !3650
  br i1 %cmp305.not, label %if.then310, label %if.then307, !dbg !3651

error.thread474:                                  ; preds = %if.end10
  store ptr @.str.67, ptr %errstr, align 8, !dbg !3652, !tbaa !1271, !DIAssignID !3653
  tail call void @llvm.dbg.assign(metadata ptr @.str.67, metadata !3334, metadata !DIExpression(), metadata !3653, metadata ptr %errstr, metadata !DIExpression()), !dbg !3353
  %.pr465477 = load ptr, ptr %it, align 8, !dbg !3648, !tbaa !1271
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3339, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !3338, metadata !DIExpression()), !dbg !3353
  tail call void @llvm.dbg.label(metadata !3351), !dbg !3478
  %cmp305.not478 = icmp eq ptr %.pr465477, null, !dbg !3650
  br i1 %cmp305.not478, label %if.end311, label %if.then307.thread, !dbg !3651

if.then307.thread:                                ; preds = %error.thread474
  call void @do_item_remove(ptr noundef nonnull %.pr465477) #13, !dbg !3654
  br label %if.end311, !dbg !3479

if.then307:                                       ; preds = %error
  call void @do_item_remove(ptr noundef nonnull %.pr465) #13, !dbg !3654
  br label %if.then310, !dbg !3479

if.then310:                                       ; preds = %error, %if.then307, %if.end308.thread
  %64 = phi ptr [ %63, %error ], [ %63, %if.then307 ], [ @.str.69, %if.end308.thread ]
  call void @item_unlock(i32 noundef %call15) #13, !dbg !3655
  br label %if.end311, !dbg !3655

if.end311:                                        ; preds = %error.thread474, %if.then307.thread, %if.then310
  %65 = phi ptr [ @.str.67, %error.thread474 ], [ @.str.67, %if.then307.thread ], [ %64, %if.then310 ], !dbg !3657
  call void @out_errstring(ptr noundef %c, ptr noundef %65) #13, !dbg !3658
  br label %cleanup312, !dbg !3659

cleanup312:                                       ; preds = %if.end311, %if.end291, %if.then9, %if.then6, %if.then3, %if.then
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %it) #13, !dbg !3659
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %errstr) #13, !dbg !3659
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %of) #13, !dbg !3659
  ret void, !dbg !3659
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_meta_command(ptr noundef %c, ptr nocapture noundef readonly %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !3660 {
entry:
  %overflow = alloca i8, align 1, !DIAssignID !3677
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3670, metadata !DIExpression(), metadata !3677, metadata ptr %overflow, metadata !DIExpression()), !dbg !3678
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !3662, metadata !DIExpression()), !dbg !3678
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !3663, metadata !DIExpression()), !dbg !3678
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !3664, metadata !DIExpression()), !dbg !3678
  %cmp = icmp ult i64 %ntokens, 3, !dbg !3679
  br i1 %cmp, label %if.then, label %lor.lhs.false, !dbg !3681

lor.lhs.false:                                    ; preds = %entry
  %length = getelementptr inbounds i8, ptr %tokens, i64 24, !dbg !3682
  %0 = load i64, ptr %length, align 8, !dbg !3682, !tbaa !1578
  %cmp1 = icmp ugt i64 %0, 250, !dbg !3683
  br i1 %cmp1, label %if.then, label %if.end, !dbg !3684

if.then:                                          ; preds = %lor.lhs.false, %entry
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.48) #13, !dbg !3685
  br label %cleanup.cont128, !dbg !3687

if.end:                                           ; preds = %lor.lhs.false
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !3688
  %1 = load ptr, ptr %arrayidx, align 8, !dbg !3689, !tbaa !1573
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !3665, metadata !DIExpression()), !dbg !3678
  tail call void @llvm.dbg.value(metadata i64 %0, metadata !3666, metadata !DIExpression()), !dbg !3678
  %cmp5.not = icmp eq i64 %ntokens, 3, !dbg !3690
  br i1 %cmp5.not, label %if.end20, label %land.lhs.true, !dbg !3691

land.lhs.true:                                    ; preds = %if.end
  %length7 = getelementptr inbounds i8, ptr %tokens, i64 40, !dbg !3692
  %2 = load i64, ptr %length7, align 8, !dbg !3692, !tbaa !1578
  %cmp8 = icmp eq i64 %2, 1, !dbg !3693
  br i1 %cmp8, label %land.lhs.true9, label %if.end20, !dbg !3694

land.lhs.true9:                                   ; preds = %land.lhs.true
  %arrayidx6 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !3695
  %3 = load ptr, ptr %arrayidx6, align 8, !dbg !3696, !tbaa !1573
  %4 = load i8, ptr %3, align 1, !dbg !3697, !tbaa !1240
  %cmp13 = icmp eq i8 %4, 98, !dbg !3698
  br i1 %cmp13, label %if.then15, label %if.end20, !dbg !3699

if.then15:                                        ; preds = %land.lhs.true9
  %call = tail call i64 @base64_decode(ptr noundef %1, i64 noundef %0, ptr noundef %1, i64 noundef %0) #13, !dbg !3700
  tail call void @llvm.dbg.value(metadata i64 %call, metadata !3667, metadata !DIExpression()), !dbg !3701
  %cmp16.not = icmp eq i64 %call, 0, !dbg !3702
  br i1 %cmp16.not, label %cleanup.thread, label %if.end20, !dbg !3704

cleanup.thread:                                   ; preds = %if.then15
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.48) #13, !dbg !3705
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !3666, metadata !DIExpression()), !dbg !3678
  br label %cleanup.cont128

if.end20:                                         ; preds = %if.then15, %land.lhs.true9, %land.lhs.true, %if.end
  %nkey.1 = phi i64 [ %0, %land.lhs.true9 ], [ %0, %land.lhs.true ], [ %0, %if.end ], [ %call, %if.then15 ], !dbg !3707
  tail call void @llvm.dbg.value(metadata i64 %nkey.1, metadata !3666, metadata !DIExpression()), !dbg !3678
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %overflow) #13, !dbg !3708
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !3709
  %5 = load ptr, ptr %thread, align 8, !dbg !3709, !tbaa !1234
  %call21 = call ptr @limited_get(ptr noundef %1, i64 noundef %nkey.1, ptr noundef %5, i32 noundef 0, i1 noundef zeroext false, i1 noundef zeroext false, ptr noundef nonnull %overflow) #13, !dbg !3710
  tail call void @llvm.dbg.value(metadata ptr %call21, metadata !3671, metadata !DIExpression()), !dbg !3678
  %tobool.not = icmp eq ptr %call21, null, !dbg !3711
  br i1 %tobool.not, label %if.else114, label %if.then22, !dbg !3712

if.then22:                                        ; preds = %if.end20
  %resp23 = getelementptr inbounds i8, ptr %c, i64 192, !dbg !3713
  %6 = load ptr, ptr %resp23, align 8, !dbg !3713, !tbaa !1351
  tail call void @llvm.dbg.value(metadata ptr %6, metadata !3672, metadata !DIExpression()), !dbg !3714
  tail call void @llvm.dbg.value(metadata i64 0, metadata !3675, metadata !DIExpression()), !dbg !3714
  %wbuf = getelementptr inbounds i8, ptr %6, i64 160, !dbg !3715
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(3) %wbuf, ptr noundef nonnull align 1 dereferenceable(3) @.str.70, i64 3, i1 false), !dbg !3716
  tail call void @llvm.dbg.value(metadata i64 3, metadata !3675, metadata !DIExpression()), !dbg !3714
  %it_flags = getelementptr inbounds i8, ptr %call21, i64 38, !dbg !3717
  %7 = load i16, ptr %it_flags, align 2, !dbg !3717, !tbaa !1248
  %conv25 = zext i16 %7 to i32, !dbg !3719
  %and = and i32 %conv25, 4096, !dbg !3720
  %tobool26.not = icmp eq i32 %and, 0, !dbg !3720
  br i1 %tobool26.not, label %if.else, label %if.then27, !dbg !3721

if.then27:                                        ; preds = %if.then22
  %data = getelementptr inbounds i8, ptr %call21, i64 48, !dbg !3722
  %and30 = shl nuw nsw i32 %conv25, 2, !dbg !3722
  %8 = and i32 %and30, 8, !dbg !3722
  %cond = zext nneg i32 %8 to i64, !dbg !3722
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %cond, !dbg !3722
  %nkey32 = getelementptr inbounds i8, ptr %call21, i64 41, !dbg !3724
  %9 = load i8, ptr %nkey32, align 1, !dbg !3724, !tbaa !1240
  %conv33 = zext i8 %9 to i64, !dbg !3725
  %add.ptr36 = getelementptr inbounds i8, ptr %6, i64 163, !dbg !3726
  %call37 = call i64 @base64_encode(ptr noundef nonnull %add.ptr, i64 noundef %conv33, ptr noundef nonnull %add.ptr36, i64 noundef 1021) #13, !dbg !3727
  tail call void @llvm.dbg.value(metadata i64 %call37, metadata !3675, metadata !DIExpression(DW_OP_plus_uconst, 3, DW_OP_stack_value)), !dbg !3714
  br label %if.end54, !dbg !3728

if.else:                                          ; preds = %if.then22
  %add.ptr41 = getelementptr inbounds i8, ptr %6, i64 163, !dbg !3729
  %data42 = getelementptr inbounds i8, ptr %call21, i64 48, !dbg !3731
  %and45 = shl nuw nsw i32 %conv25, 2, !dbg !3731
  %10 = and i32 %and45, 8, !dbg !3731
  %cond47 = zext nneg i32 %10 to i64, !dbg !3731
  %add.ptr48 = getelementptr inbounds i8, ptr %data42, i64 %cond47, !dbg !3731
  %nkey49 = getelementptr inbounds i8, ptr %call21, i64 41, !dbg !3732
  %11 = load i8, ptr %nkey49, align 1, !dbg !3732, !tbaa !1240
  %conv50 = zext i8 %11 to i64, !dbg !3733
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr41, ptr nonnull align 1 %add.ptr48, i64 %conv50, i1 false), !dbg !3734
  %12 = load i8, ptr %nkey49, align 1, !dbg !3735, !tbaa !1240
  %conv52 = zext i8 %12 to i64, !dbg !3736
  tail call void @llvm.dbg.value(metadata i64 %conv52, metadata !3675, metadata !DIExpression(DW_OP_plus_uconst, 3, DW_OP_stack_value)), !dbg !3714
  br label %if.end54

if.end54:                                         ; preds = %if.else, %if.then27
  %total.0.in = phi i64 [ %call37, %if.then27 ], [ %conv52, %if.else ]
  %total.0 = add i64 %total.0.in, 3, !dbg !3737
  tail call void @llvm.dbg.value(metadata i64 %total.0, metadata !3675, metadata !DIExpression()), !dbg !3714
  %arrayidx56 = getelementptr inbounds [1024 x i8], ptr %wbuf, i64 0, i64 %total.0, !dbg !3738
  store i8 32, ptr %arrayidx56, align 1, !dbg !3739, !tbaa !1240
  %inc = add i64 %total.0.in, 4, !dbg !3740
  tail call void @llvm.dbg.value(metadata i64 %inc, metadata !3675, metadata !DIExpression()), !dbg !3714
  %add.ptr59 = getelementptr inbounds i8, ptr %wbuf, i64 %inc, !dbg !3741
  %nkey60 = getelementptr inbounds i8, ptr %call21, i64 41, !dbg !3742
  %13 = load i8, ptr %nkey60, align 1, !dbg !3742, !tbaa !1240
  %conv61 = zext i8 %13 to i64, !dbg !3743
  %sub63 = sub nuw nsw i64 1012, %conv61, !dbg !3744
  %exptime = getelementptr inbounds i8, ptr %call21, i64 28, !dbg !3745
  %14 = load i32, ptr %exptime, align 4, !dbg !3745, !tbaa !1231
  %cmp65 = icmp eq i32 %14, 0, !dbg !3746
  br i1 %cmp65, label %cond.end, label %cond.false, !dbg !3747

cond.false:                                       ; preds = %if.end54
  %15 = load volatile i32, ptr @current_time, align 4, !dbg !3748, !tbaa !1231
  %sub68 = sub i32 %14, %15, !dbg !3749
  br label %cond.end, !dbg !3747

cond.end:                                         ; preds = %if.end54, %cond.false
  %cond69 = phi i32 [ %sub68, %cond.false ], [ -1, %if.end54 ], !dbg !3747
  %16 = load volatile i32, ptr @current_time, align 4, !dbg !3750, !tbaa !1231
  %time = getelementptr inbounds i8, ptr %call21, i64 24, !dbg !3751
  %17 = load i32, ptr %time, align 8, !dbg !3751, !tbaa !1231
  %sub70 = sub i32 %16, %17, !dbg !3752
  %conv71 = zext i32 %sub70 to i64, !dbg !3753
  %18 = load i16, ptr %it_flags, align 2, !dbg !3754, !tbaa !1248
  %19 = and i16 %18, 2, !dbg !3754
  %tobool75.not = icmp eq i16 %19, 0, !dbg !3754
  br i1 %tobool75.not, label %cond.end80, label %cond.true76, !dbg !3754

cond.true76:                                      ; preds = %cond.end
  %data77 = getelementptr inbounds i8, ptr %call21, i64 48, !dbg !3754
  %20 = load i64, ptr %data77, align 8, !dbg !3754, !tbaa !1240
  br label %cond.end80, !dbg !3754

cond.end80:                                       ; preds = %cond.end, %cond.true76
  %cond81 = phi i64 [ %20, %cond.true76 ], [ 0, %cond.end ], !dbg !3754
  %conv83 = zext i16 %18 to i32, !dbg !3755
  %and84 = and i32 %conv83, 8, !dbg !3756
  %tobool85.not = icmp eq i32 %and84, 0, !dbg !3757
  %cond86 = select i1 %tobool85.not, ptr @.str.73, ptr @.str.72, !dbg !3757
  %slabs_clsid = getelementptr inbounds i8, ptr %call21, i64 40, !dbg !3758
  %21 = load i8, ptr %slabs_clsid, align 8, !dbg !3758, !tbaa !1240
  %22 = and i8 %21, 63, !dbg !3758
  %and88 = zext nneg i8 %22 to i32, !dbg !3758
  %add92 = add nuw nsw i64 %conv61, 49, !dbg !3759
  %nbytes = getelementptr inbounds i8, ptr %call21, i64 32, !dbg !3759
  %23 = load i32, ptr %nbytes, align 8, !dbg !3759, !tbaa !1231
  %conv93 = sext i32 %23 to i64, !dbg !3759
  %and97 = lshr i32 %conv83, 6, !dbg !3759
  %24 = and i32 %and97, 4, !dbg !3759
  %cond99 = zext nneg i32 %24 to i64, !dbg !3759
  %and103 = shl nuw nsw i32 %conv83, 2, !dbg !3759
  %25 = and i32 %and103, 8, !dbg !3759
  %cond105 = zext nneg i32 %25 to i64, !dbg !3759
  %add94 = add nuw nsw i64 %add92, %cond99, !dbg !3759
  %add100 = add nuw nsw i64 %add94, %cond105, !dbg !3759
  %add106 = add nsw i64 %add100, %conv93, !dbg !3759
  %call107 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %add.ptr59, i64 noundef %sub63, ptr noundef nonnull @.str.71, i32 noundef %cond69, i64 noundef %conv71, i64 noundef %cond81, ptr noundef nonnull %cond86, i32 noundef %and88, i64 noundef %add106) #13, !dbg !3760
  tail call void @llvm.dbg.value(metadata i32 %call107, metadata !3676, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_signed, DW_OP_LLVM_convert, 64, DW_ATE_signed, DW_OP_stack_value)), !dbg !3714
  call void @item_remove(ptr noundef nonnull %call21) #13, !dbg !3761
  %26 = trunc i64 %inc to i32, !dbg !3762
  %conv110 = add i32 %call107, %26, !dbg !3762
  %wbytes = getelementptr inbounds i8, ptr %6, i64 16, !dbg !3763
  store i32 %conv110, ptr %wbytes, align 8, !dbg !3764, !tbaa !1355
  call void @resp_add_iov(ptr noundef nonnull %6, ptr noundef nonnull %wbuf, i32 noundef %conv110) #13, !dbg !3765
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 1) #13, !dbg !3766
  br label %if.end115, !dbg !3767

if.else114:                                       ; preds = %if.end20
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.53) #13, !dbg !3768
  br label %if.end115

if.end115:                                        ; preds = %if.else114, %cond.end80
  %27 = load ptr, ptr %thread, align 8, !dbg !3770, !tbaa !1234
  %stats = getelementptr inbounds i8, ptr %27, i64 352, !dbg !3771
  %call117 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #13, !dbg !3772
  %28 = load ptr, ptr %thread, align 8, !dbg !3773, !tbaa !1234
  %meta_cmds = getelementptr inbounds i8, ptr %28, i64 472, !dbg !3774
  %29 = load i64, ptr %meta_cmds, align 8, !dbg !3775, !tbaa !3776
  %inc120 = add i64 %29, 1, !dbg !3775
  store i64 %inc120, ptr %meta_cmds, align 8, !dbg !3775, !tbaa !3776
  %stats122 = getelementptr inbounds i8, ptr %28, i64 352, !dbg !3777
  %call124 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats122) #13, !dbg !3778
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %overflow) #13, !dbg !3779
  br label %cleanup.cont128, !dbg !3779

cleanup.cont128:                                  ; preds = %cleanup.thread, %if.end115, %if.then
  ret void, !dbg !3779
}

; Function Attrs: inlinehint nounwind sanitize_thread uwtable
define internal fastcc void @process_get_command(ptr noundef %c, ptr nocapture noundef %tokens, i1 noundef zeroext %return_cas, i1 noundef zeroext %should_touch) unnamed_addr #6 !dbg !3780 {
entry:
  %exptime_int = alloca i32, align 4, !DIAssignID !3809
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3793, metadata !DIExpression(), metadata !3809, metadata ptr %exptime_int, metadata !DIExpression()), !dbg !3810
  %overflow = alloca i8, align 1, !DIAssignID !3811
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3797, metadata !DIExpression(), metadata !3811, metadata ptr %overflow, metadata !DIExpression()), !dbg !3812
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !3784, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !3785, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !3786, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata i1 %return_cas, metadata !3787, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3810
  tail call void @llvm.dbg.value(metadata i1 %should_touch, metadata !3788, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3810
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !3813
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !3792, metadata !DIExpression()), !dbg !3810
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %exptime_int) #13, !dbg !3814
  store i32 0, ptr %exptime_int, align 4, !dbg !3815, !tbaa !1231, !DIAssignID !3816
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !3793, metadata !DIExpression(), metadata !3816, metadata ptr %exptime_int, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3794, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata i8 0, metadata !3795, metadata !DIExpression()), !dbg !3810
  %resp2 = getelementptr inbounds i8, ptr %c, i64 192, !dbg !3817
  %0 = load ptr, ptr %resp2, align 8, !dbg !3817, !tbaa !1351
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !3796, metadata !DIExpression()), !dbg !3810
  br i1 %should_touch, label %if.then, label %if.end6, !dbg !3818

if.then:                                          ; preds = %entry
  %1 = load ptr, ptr %arrayidx, align 8, !dbg !3819, !tbaa !1573
  %call = call zeroext i1 @safe_strtol(ptr noundef %1, ptr noundef nonnull %exptime_int) #13, !dbg !3823
  br i1 %call, label %if.end, label %if.then4, !dbg !3824

if.then4:                                         ; preds = %if.then
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.74) #13, !dbg !3825
  br label %cleanup217, !dbg !3827

if.end:                                           ; preds = %if.then
  %incdec.ptr = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !3828
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr, metadata !3792, metadata !DIExpression()), !dbg !3810
  %2 = load i32, ptr %exptime_int, align 4, !dbg !3829, !tbaa !1231
  %cmp = icmp slt i32 %2, 0, !dbg !3829
  %spec.select = select i1 %cmp, i32 2592001, i32 %2, !dbg !3829
  %conv = zext nneg i32 %spec.select to i64
  %call5 = call i32 @realtime(i64 noundef %conv) #13, !dbg !3830
  tail call void @llvm.dbg.value(metadata i32 %call5, metadata !3794, metadata !DIExpression()), !dbg !3810
  br label %if.end6, !dbg !3831

if.end6:                                          ; preds = %if.end, %entry
  %exptime.0 = phi i32 [ %call5, %if.end ], [ 0, %entry ], !dbg !3810
  %key_token.0 = phi ptr [ %incdec.ptr, %if.end ], [ %arrayidx, %entry ], !dbg !3810
  tail call void @llvm.dbg.value(metadata ptr %key_token.0, metadata !3792, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata i32 %exptime.0, metadata !3794, metadata !DIExpression()), !dbg !3810
  %thread = getelementptr inbounds i8, ptr %c, i64 456
  %sfd = getelementptr inbounds i8, ptr %c, i64 8
  %. = select i1 %should_touch, i64 424, i64 400
  %.387 = select i1 %should_touch, i64 432, i64 392
  br label %do.body, !dbg !3832

do.body:                                          ; preds = %do.cond, %if.end6
  %resp.0 = phi ptr [ %0, %if.end6 ], [ %59, %do.cond ], !dbg !3810
  %key_token.1 = phi ptr [ %key_token.0, %if.end6 ], [ %tokens, %do.cond ], !dbg !3810
  tail call void @llvm.dbg.value(metadata ptr %key_token.1, metadata !3792, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata ptr %resp.0, metadata !3796, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata i8 0, metadata !3795, metadata !DIExpression()), !dbg !3810
  %length349 = getelementptr inbounds i8, ptr %key_token.1, i64 8, !dbg !3833
  %3 = load i64, ptr %length349, align 8, !dbg !3833, !tbaa !1578
  %cmp7.not350 = icmp eq i64 %3, 0, !dbg !3834
  br i1 %cmp7.not350, label %while.end, label %while.body, !dbg !3835

while.body:                                       ; preds = %do.body, %cleanup181
  %4 = phi i64 [ %.pre, %cleanup181 ], [ %3, %do.body ]
  %key_token.2353 = phi ptr [ %incdec.ptr171, %cleanup181 ], [ %key_token.1, %do.body ]
  %resp.1351 = phi ptr [ %55, %cleanup181 ], [ %resp.0, %do.body ]
  tail call void @llvm.dbg.value(metadata ptr %key_token.2353, metadata !3792, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata ptr %resp.1351, metadata !3796, metadata !DIExpression()), !dbg !3810
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %overflow) #13, !dbg !3836
  %5 = load ptr, ptr %key_token.2353, align 8, !dbg !3837, !tbaa !1573
  tail call void @llvm.dbg.value(metadata ptr %5, metadata !3789, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata i64 %4, metadata !3790, metadata !DIExpression()), !dbg !3810
  %cmp11 = icmp ugt i64 %4, 250, !dbg !3838
  br i1 %cmp11, label %cleanup181.thread, label %if.end14, !dbg !3840

if.end14:                                         ; preds = %while.body
  %6 = load ptr, ptr %thread, align 8, !dbg !3841, !tbaa !1234
  %call16 = call ptr @limited_get(ptr noundef %5, i64 noundef %4, ptr noundef %6, i32 noundef %exptime.0, i1 noundef zeroext %should_touch, i1 noundef zeroext true, ptr noundef nonnull %overflow) #13, !dbg !3842
  tail call void @llvm.dbg.value(metadata ptr %call16, metadata !3791, metadata !DIExpression()), !dbg !3810
  %7 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 16), align 8, !dbg !3843, !tbaa !3845
  %tobool17.not = icmp eq i32 %7, 0, !dbg !3846
  br i1 %tobool17.not, label %if.end21, label %if.then18, !dbg !3847

if.then18:                                        ; preds = %if.end14
  %cmp19 = icmp ne ptr %call16, null, !dbg !3848
  call void @stats_prefix_record_get(ptr noundef %5, i64 noundef %4, i1 noundef zeroext %cmp19) #13, !dbg !3850
  br label %if.end21, !dbg !3851

if.end21:                                         ; preds = %if.then18, %if.end14
  %tobool22.not = icmp eq ptr %call16, null, !dbg !3852
  br i1 %tobool22.not, label %if.else143, label %if.then23, !dbg !3853

if.then23:                                        ; preds = %if.end21
  %nbytes24 = getelementptr inbounds i8, ptr %call16, i64 32, !dbg !3854
  %8 = load i32, ptr %nbytes24, align 8, !dbg !3854, !tbaa !1231
  tail call void @llvm.dbg.value(metadata i32 %8, metadata !3800, metadata !DIExpression()), !dbg !3855
  %wbuf = getelementptr inbounds i8, ptr %resp.1351, i64 160, !dbg !3856
  tail call void @llvm.dbg.value(metadata ptr %wbuf, metadata !3804, metadata !DIExpression()), !dbg !3855
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) %wbuf, ptr noundef nonnull align 1 dereferenceable(6) @.str.75, i64 6, i1 false), !dbg !3857
  %add.ptr = getelementptr inbounds i8, ptr %resp.1351, i64 166, !dbg !3858
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !3804, metadata !DIExpression()), !dbg !3855
  %data = getelementptr inbounds i8, ptr %call16, i64 48, !dbg !3859
  %it_flags = getelementptr inbounds i8, ptr %call16, i64 38, !dbg !3859
  %9 = load i16, ptr %it_flags, align 2, !dbg !3859, !tbaa !1248
  %10 = shl i16 %9, 2, !dbg !3859
  %11 = and i16 %10, 8, !dbg !3859
  %cond27 = zext nneg i16 %11 to i64, !dbg !3859
  %add.ptr28 = getelementptr inbounds i8, ptr %data, i64 %cond27, !dbg !3859
  %nkey29 = getelementptr inbounds i8, ptr %call16, i64 41, !dbg !3860
  %12 = load i8, ptr %nkey29, align 1, !dbg !3860, !tbaa !1240
  %conv30 = zext i8 %12 to i64, !dbg !3861
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr, ptr nonnull align 1 %add.ptr28, i64 %conv30, i1 false), !dbg !3862
  %13 = load i8, ptr %nkey29, align 1, !dbg !3863, !tbaa !1240
  %idx.ext = zext i8 %13 to i64
  %add.ptr33 = getelementptr inbounds i8, ptr %add.ptr, i64 %idx.ext, !dbg !3864
  tail call void @llvm.dbg.value(metadata ptr %add.ptr33, metadata !3804, metadata !DIExpression()), !dbg !3855
  tail call void @llvm.dbg.value(metadata ptr %add.ptr33, metadata !3865, metadata !DIExpression()), !dbg !3874
  tail call void @llvm.dbg.value(metadata ptr %call16, metadata !3870, metadata !DIExpression()), !dbg !3874
  tail call void @llvm.dbg.value(metadata i1 %return_cas, metadata !3871, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3874
  tail call void @llvm.dbg.value(metadata i32 %8, metadata !3872, metadata !DIExpression()), !dbg !3874
  tail call void @llvm.dbg.value(metadata ptr %add.ptr33, metadata !3873, metadata !DIExpression()), !dbg !3874
  store i8 32, ptr %add.ptr33, align 1, !dbg !3876, !tbaa !1240
  %incdec.ptr.i = getelementptr inbounds i8, ptr %add.ptr33, i64 1, !dbg !3877
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i, metadata !3873, metadata !DIExpression()), !dbg !3874
  %14 = load i16, ptr %it_flags, align 2, !dbg !3878, !tbaa !1248
  %conv.i = zext i16 %14 to i32, !dbg !3878
  %15 = and i32 %conv.i, 256, !dbg !3880
  %cmp.i = icmp eq i32 %15, 0, !dbg !3880
  br i1 %cmp.i, label %if.then.i, label %if.else.i, !dbg !3881

if.then.i:                                        ; preds = %if.then23
  store i8 48, ptr %incdec.ptr.i, align 1, !dbg !3882, !tbaa !1240
  %incdec.ptr2.i = getelementptr inbounds i8, ptr %add.ptr33, i64 2, !dbg !3884
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr2.i, metadata !3873, metadata !DIExpression()), !dbg !3874
  br label %if.end.i, !dbg !3885

if.else.i:                                        ; preds = %if.then23
  %16 = load i8, ptr %nkey29, align 1, !dbg !3886, !tbaa !1240
  %idx.ext.i = zext i8 %16 to i64
  %add.ptr.i = getelementptr inbounds i8, ptr %data, i64 %idx.ext.i, !dbg !3886
  %add.ptr4.i = getelementptr inbounds i8, ptr %add.ptr.i, i64 1, !dbg !3886
  %and7.i = shl nuw nsw i32 %conv.i, 2, !dbg !3886
  %17 = and i32 %and7.i, 8, !dbg !3886
  %cond9.i = zext nneg i32 %17 to i64, !dbg !3886
  %add.ptr10.i = getelementptr inbounds i8, ptr %add.ptr4.i, i64 %cond9.i, !dbg !3886
  %18 = load i32, ptr %add.ptr10.i, align 4, !dbg !3888, !tbaa !1231
  %conv11.i = zext i32 %18 to i64, !dbg !3888
  %call.i = call ptr @itoa_u64(i64 noundef %conv11.i, ptr noundef nonnull %incdec.ptr.i) #13, !dbg !3889
  tail call void @llvm.dbg.value(metadata ptr %call.i, metadata !3873, metadata !DIExpression()), !dbg !3874
  br label %if.end.i

if.end.i:                                         ; preds = %if.else.i, %if.then.i
  %p.0.i = phi ptr [ %incdec.ptr2.i, %if.then.i ], [ %call.i, %if.else.i ], !dbg !3890
  tail call void @llvm.dbg.value(metadata ptr %p.0.i, metadata !3873, metadata !DIExpression()), !dbg !3874
  store i8 32, ptr %p.0.i, align 1, !dbg !3891, !tbaa !1240
  %sub.i = add nsw i32 %8, -2, !dbg !3892
  %add.ptr12.i = getelementptr inbounds i8, ptr %p.0.i, i64 1, !dbg !3893
  %call13.i = call ptr @itoa_u32(i32 noundef %sub.i, ptr noundef nonnull %add.ptr12.i) #13, !dbg !3894
  tail call void @llvm.dbg.value(metadata ptr %call13.i, metadata !3873, metadata !DIExpression()), !dbg !3874
  br i1 %return_cas, label %if.then15.i, label %make_ascii_get_suffix.exit, !dbg !3895

if.then15.i:                                      ; preds = %if.end.i
  store i8 32, ptr %call13.i, align 1, !dbg !3896, !tbaa !1240
  %19 = load i16, ptr %it_flags, align 2, !dbg !3899, !tbaa !1248
  %20 = and i16 %19, 2, !dbg !3899
  %tobool19.not.i = icmp eq i16 %20, 0, !dbg !3899
  br i1 %tobool19.not.i, label %cond.end.i, label %cond.true.i, !dbg !3899

cond.true.i:                                      ; preds = %if.then15.i
  %21 = load i64, ptr %data, align 8, !dbg !3899, !tbaa !1240
  br label %cond.end.i, !dbg !3899

cond.end.i:                                       ; preds = %cond.true.i, %if.then15.i
  %cond21.i = phi i64 [ %21, %cond.true.i ], [ 0, %if.then15.i ], !dbg !3899
  %add.ptr22.i = getelementptr inbounds i8, ptr %call13.i, i64 1, !dbg !3900
  %call23.i = call ptr @itoa_u64(i64 noundef %cond21.i, ptr noundef nonnull %add.ptr22.i) #13, !dbg !3901
  tail call void @llvm.dbg.value(metadata ptr %call23.i, metadata !3873, metadata !DIExpression()), !dbg !3874
  br label %make_ascii_get_suffix.exit, !dbg !3902

make_ascii_get_suffix.exit:                       ; preds = %if.end.i, %cond.end.i
  %p.1.i = phi ptr [ %call23.i, %cond.end.i ], [ %call13.i, %if.end.i ], !dbg !3874
  tail call void @llvm.dbg.value(metadata ptr %p.1.i, metadata !3873, metadata !DIExpression()), !dbg !3874
  store i8 13, ptr %p.1.i, align 1, !dbg !3903, !tbaa !1240
  %add.ptr25.i = getelementptr inbounds i8, ptr %p.1.i, i64 1, !dbg !3904
  store i8 10, ptr %add.ptr25.i, align 1, !dbg !3905, !tbaa !1240
  %add.ptr26.i = getelementptr inbounds i8, ptr %p.1.i, i64 2, !dbg !3906
  store i8 0, ptr %add.ptr26.i, align 1, !dbg !3907, !tbaa !1240
  %sub.ptr.lhs.cast.i = ptrtoint ptr %p.1.i to i64, !dbg !3908
  %sub.ptr.rhs.cast.i = ptrtoint ptr %add.ptr33 to i64, !dbg !3908
  %sub.ptr.sub.i = sub i64 %sub.ptr.lhs.cast.i, %sub.ptr.rhs.cast.i, !dbg !3908
  %conv27.i = shl i64 %sub.ptr.sub.i, 32, !dbg !3909
  %sext = add i64 %conv27.i, 8589934592, !dbg !3909
  %idx.ext36 = ashr exact i64 %sext, 32, !dbg !3909
  %add.ptr37 = getelementptr inbounds i8, ptr %add.ptr33, i64 %idx.ext36, !dbg !3909
  tail call void @llvm.dbg.value(metadata ptr %add.ptr37, metadata !3804, metadata !DIExpression()), !dbg !3855
  %sub.ptr.lhs.cast = ptrtoint ptr %add.ptr37 to i64, !dbg !3910
  %sub.ptr.rhs.cast = ptrtoint ptr %wbuf to i64, !dbg !3910
  %sub.ptr.sub = sub i64 %sub.ptr.lhs.cast, %sub.ptr.rhs.cast, !dbg !3910
  %conv42 = trunc i64 %sub.ptr.sub to i32, !dbg !3911
  call void @resp_add_iov(ptr noundef nonnull %resp.1351, ptr noundef nonnull %wbuf, i32 noundef %conv42) #13, !dbg !3912
  %22 = load i16, ptr %it_flags, align 2, !dbg !3913, !tbaa !1248
  %conv44 = zext i16 %22 to i32, !dbg !3915
  %and45 = and i32 %conv44, 128, !dbg !3916
  %tobool46.not = icmp eq i32 %and45, 0, !dbg !3916
  br i1 %tobool46.not, label %if.else, label %if.then47, !dbg !3917

if.then47:                                        ; preds = %make_ascii_get_suffix.exit
  %call48 = call i32 @storage_get_item(ptr noundef nonnull %c, ptr noundef nonnull %call16, ptr noundef nonnull %resp.1351) #13, !dbg !3918
  %cmp49.not = icmp eq i32 %call48, 0, !dbg !3921
  br i1 %cmp49.not, label %cleanup.cont, label %cleanup, !dbg !3922

if.else:                                          ; preds = %make_ascii_get_suffix.exit
  %and63 = and i32 %conv44, 32, !dbg !3923
  %cmp64 = icmp eq i32 %and63, 0, !dbg !3925
  br i1 %cmp64, label %if.then66, label %if.else86, !dbg !3926

if.then66:                                        ; preds = %if.else
  %23 = load i8, ptr %nkey29, align 1, !dbg !3927, !tbaa !1240
  %idx.ext70 = zext i8 %23 to i64
  %add.ptr71 = getelementptr inbounds i8, ptr %data, i64 %idx.ext70, !dbg !3927
  %add.ptr72 = getelementptr inbounds i8, ptr %add.ptr71, i64 1, !dbg !3927
  %and75 = lshr i32 %conv44, 6, !dbg !3927
  %24 = and i32 %and75, 4, !dbg !3927
  %cond77 = zext nneg i32 %24 to i64, !dbg !3927
  %add.ptr78 = getelementptr inbounds i8, ptr %add.ptr72, i64 %cond77, !dbg !3927
  %and81 = shl nuw nsw i32 %conv44, 2, !dbg !3927
  %25 = and i32 %and81, 8, !dbg !3927
  %cond83 = zext nneg i32 %25 to i64, !dbg !3927
  %add.ptr84 = getelementptr inbounds i8, ptr %add.ptr78, i64 %cond83, !dbg !3927
  %26 = load i32, ptr %nbytes24, align 8, !dbg !3929, !tbaa !1231
  call void @resp_add_iov(ptr noundef nonnull %resp.1351, ptr noundef nonnull %add.ptr84, i32 noundef %26) #13, !dbg !3930
  br label %cleanup.cont, !dbg !3931

if.else86:                                        ; preds = %if.else
  %27 = load i32, ptr %nbytes24, align 8, !dbg !3932, !tbaa !1231
  call void @resp_add_chunked_iov(ptr noundef nonnull %resp.1351, ptr noundef nonnull %call16, i32 noundef %27) #13, !dbg !3934
  br label %cleanup.cont

cleanup:                                          ; preds = %if.then47
  %28 = load ptr, ptr %thread, align 8, !dbg !3935, !tbaa !1234
  %stats = getelementptr inbounds i8, ptr %28, i64 352, !dbg !3937
  %call53 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #13, !dbg !3938
  %29 = load ptr, ptr %thread, align 8, !dbg !3939, !tbaa !1234
  %get_oom_extstore = getelementptr inbounds i8, ptr %29, i64 600, !dbg !3940
  %30 = load i64, ptr %get_oom_extstore, align 8, !dbg !3941, !tbaa !2693
  %inc = add i64 %30, 1, !dbg !3941
  store i64 %inc, ptr %get_oom_extstore, align 8, !dbg !3941, !tbaa !2693
  %stats57 = getelementptr inbounds i8, ptr %29, i64 352, !dbg !3942
  %call59 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats57) #13, !dbg !3943
  call void @item_remove(ptr noundef nonnull %call16) #13, !dbg !3944
  br label %cleanup181.thread

cleanup.cont:                                     ; preds = %if.then66, %if.else86, %if.then47
  %31 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !3945, !tbaa !1858
  %cmp91 = icmp sgt i32 %31, 1, !dbg !3946
  br i1 %cmp91, label %if.then93, label %if.end104, !dbg !3947

if.then93:                                        ; preds = %cleanup.cont
  %32 = load ptr, ptr @stderr, align 8, !dbg !3948, !tbaa !1271
  %33 = load i32, ptr %sfd, align 8, !dbg !3949, !tbaa !1311
  %call94 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %32, ptr noundef nonnull @.str.76, i32 noundef %33) #17, !dbg !3950
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3805, metadata !DIExpression()), !dbg !3951
  %34 = load i8, ptr %nkey29, align 1, !dbg !3952, !tbaa !1240
  %cmp97347.not = icmp eq i8 %34, 0, !dbg !3955
  br i1 %cmp97347.not, label %for.end, label %for.body, !dbg !3956

for.body:                                         ; preds = %if.then93, %for.body
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.body ], [ 0, %if.then93 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !3805, metadata !DIExpression()), !dbg !3951
  %35 = load ptr, ptr @stderr, align 8, !dbg !3957, !tbaa !1271
  %arrayidx99 = getelementptr inbounds i8, ptr %5, i64 %indvars.iv, !dbg !3959
  %36 = load i8, ptr %arrayidx99, align 1, !dbg !3959, !tbaa !1240
  %conv100 = sext i8 %36 to i32, !dbg !3959
  %fputc319 = call i32 @fputc(i32 %conv100, ptr %35), !dbg !3960
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !3961
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !3805, metadata !DIExpression()), !dbg !3951
  %37 = load i8, ptr %nkey29, align 1, !dbg !3952, !tbaa !1240
  %38 = zext i8 %37 to i64, !dbg !3955
  %cmp97 = icmp ult i64 %indvars.iv.next, %38, !dbg !3955
  br i1 %cmp97, label %for.body, label %for.end, !dbg !3956, !llvm.loop !3962

for.end:                                          ; preds = %for.body, %if.then93
  %39 = load ptr, ptr @stderr, align 8, !dbg !3964, !tbaa !1271
  %fputc = call i32 @fputc(i32 10, ptr %39), !dbg !3965
  br label %if.end104, !dbg !3966

if.end104:                                        ; preds = %for.end, %cleanup.cont
  %40 = load ptr, ptr %thread, align 8, !dbg !3967, !tbaa !1234
  %stats106 = getelementptr inbounds i8, ptr %40, i64 352, !dbg !3968
  %call108 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats106) #13, !dbg !3969
  %41 = load ptr, ptr %thread, align 8, !dbg !3970, !tbaa !1234
  br i1 %should_touch, label %if.then110, label %if.else121, !dbg !3972

if.then110:                                       ; preds = %if.end104
  %touch_cmds = getelementptr inbounds i8, ptr %41, i64 424, !dbg !3973
  %42 = load i64, ptr %touch_cmds, align 8, !dbg !3975, !tbaa !2732
  %inc113 = add i64 %42, 1, !dbg !3975
  store i64 %inc113, ptr %touch_cmds, align 8, !dbg !3975, !tbaa !2732
  %slab_stats = getelementptr inbounds i8, ptr %41, i64 632, !dbg !3976
  %slabs_clsid = getelementptr inbounds i8, ptr %call16, i64 40, !dbg !3977
  %43 = load i8, ptr %slabs_clsid, align 8, !dbg !3977, !tbaa !1240
  %44 = and i8 %43, 63, !dbg !3977
  %idxprom118 = zext nneg i8 %44 to i64
  %touch_hits = getelementptr inbounds [64 x %struct.slab_stats], ptr %slab_stats, i64 0, i64 %idxprom118, i32 2, !dbg !3978
  br label %if.end131, !dbg !3979

if.else121:                                       ; preds = %if.end104
  %lru_hits = getelementptr inbounds i8, ptr %41, i64 4728, !dbg !3980
  %slabs_clsid124 = getelementptr inbounds i8, ptr %call16, i64 40, !dbg !3982
  %45 = load i8, ptr %slabs_clsid124, align 8, !dbg !3982, !tbaa !1240
  %idxprom125 = zext i8 %45 to i64, !dbg !3983
  %arrayidx126 = getelementptr inbounds [256 x i64], ptr %lru_hits, i64 0, i64 %idxprom125, !dbg !3983
  %46 = load i64, ptr %arrayidx126, align 8, !dbg !3984, !tbaa !1308
  %inc127 = add i64 %46, 1, !dbg !3984
  store i64 %inc127, ptr %arrayidx126, align 8, !dbg !3984, !tbaa !1308
  %get_cmds = getelementptr inbounds i8, ptr %41, i64 392, !dbg !3985
  br label %if.end131

if.end131:                                        ; preds = %if.else121, %if.then110
  %get_cmds.sink382 = phi ptr [ %get_cmds, %if.else121 ], [ %touch_hits, %if.then110 ]
  %47 = load i64, ptr %get_cmds.sink382, align 8, !dbg !3970, !tbaa !1308
  %inc130 = add i64 %47, 1, !dbg !3970
  store i64 %inc130, ptr %get_cmds.sink382, align 8, !dbg !3970, !tbaa !1308
  %stats133 = getelementptr inbounds i8, ptr %41, i64 352, !dbg !3986
  %call135 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats133) #13, !dbg !3987
  %48 = load i16, ptr %it_flags, align 2, !dbg !3988, !tbaa !1248
  %49 = and i16 %48, 128, !dbg !3990
  %cmp139 = icmp eq i16 %49, 0, !dbg !3991
  br i1 %cmp139, label %if.then141, label %if.end170, !dbg !3992

if.then141:                                       ; preds = %if.end131
  %item = getelementptr inbounds i8, ptr %resp.1351, i64 40, !dbg !3993
  store ptr %call16, ptr %item, align 8, !dbg !3995, !tbaa !2681
  br label %if.end170, !dbg !3996

if.else143:                                       ; preds = %if.end21
  %50 = load ptr, ptr %thread, align 8, !dbg !3997, !tbaa !1234
  %stats145 = getelementptr inbounds i8, ptr %50, i64 352, !dbg !3999
  %call147 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats145) #13, !dbg !4000
  %51 = load ptr, ptr %thread, align 8, !dbg !4001, !tbaa !1234
  %get_misses = getelementptr inbounds i8, ptr %51, i64 %., !dbg !4001
  %52 = load i64, ptr %get_misses, align 8, !dbg !4001, !tbaa !1308
  %inc160 = add i64 %52, 1, !dbg !4001
  store i64 %inc160, ptr %get_misses, align 8, !dbg !4001, !tbaa !1308
  %get_cmds163 = getelementptr inbounds i8, ptr %51, i64 %.387, !dbg !4001
  %53 = load i64, ptr %get_cmds163, align 8, !dbg !4001, !tbaa !1308
  %inc164 = add i64 %53, 1, !dbg !4001
  store i64 %inc164, ptr %get_cmds163, align 8, !dbg !4001, !tbaa !1308
  %stats167 = getelementptr inbounds i8, ptr %51, i64 352, !dbg !4003
  %call169 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats167) #13, !dbg !4004
  br label %if.end170

if.end170:                                        ; preds = %if.end131, %if.then141, %if.else143
  %incdec.ptr171 = getelementptr inbounds i8, ptr %key_token.2353, i64 16, !dbg !4005
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr171, metadata !3792, metadata !DIExpression()), !dbg !3810
  %length172 = getelementptr inbounds i8, ptr %key_token.2353, i64 24, !dbg !4006
  %54 = load i64, ptr %length172, align 8, !dbg !4006, !tbaa !1578
  %cmp173.not = icmp eq i64 %54, 0, !dbg !4008
  br i1 %cmp173.not, label %cleanup181.thread367, label %if.then175, !dbg !4009

cleanup181.thread367:                             ; preds = %if.end170
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr171, metadata !3792, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata ptr %resp.1351, metadata !3796, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata i8 0, metadata !3795, metadata !DIExpression()), !dbg !3810
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %overflow) #13, !dbg !4010
  br label %while.end, !dbg !3835

if.then175:                                       ; preds = %if.end170
  %call176 = call zeroext i1 @resp_start(ptr noundef nonnull %c) #13, !dbg !4011
  br i1 %call176, label %cleanup181, label %cleanup181.thread, !dbg !4014

cleanup181.thread:                                ; preds = %while.body, %if.then175, %cleanup
  %cmp11358 = phi i1 [ false, %cleanup ], [ true, %while.body ], [ %cmp11, %if.then175 ]
  %key_token.3.ph = phi ptr [ %key_token.2353, %cleanup ], [ %key_token.2353, %while.body ], [ %incdec.ptr171, %if.then175 ]
  tail call void @llvm.dbg.value(metadata ptr %key_token.3.ph, metadata !3792, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata ptr %resp.1351, metadata !3796, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !3795, metadata !DIExpression()), !dbg !3810
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %overflow) #13, !dbg !4010
  br label %stop

cleanup181:                                       ; preds = %if.then175
  %55 = load ptr, ptr %resp2, align 8, !dbg !4015, !tbaa !1351
  tail call void @llvm.dbg.value(metadata ptr %55, metadata !3796, metadata !DIExpression()), !dbg !3810
  %.pre = load i64, ptr %length172, align 8, !dbg !3833, !tbaa !1578
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr171, metadata !3792, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata i8 0, metadata !3795, metadata !DIExpression()), !dbg !3810
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %overflow) #13, !dbg !4010
  %cmp7.not = icmp eq i64 %.pre, 0, !dbg !3834
  br i1 %cmp7.not, label %while.end, label %while.body, !dbg !3835

while.end:                                        ; preds = %cleanup181, %cleanup181.thread367, %do.body
  %resp.1.lcssa = phi ptr [ %resp.0, %do.body ], [ %resp.1351, %cleanup181.thread367 ], [ %55, %cleanup181 ], !dbg !4016
  %key_token.2.lcssa = phi ptr [ %key_token.1, %do.body ], [ %incdec.ptr171, %cleanup181.thread367 ], [ %incdec.ptr171, %cleanup181 ], !dbg !3828
  %56 = load ptr, ptr %key_token.2.lcssa, align 8, !dbg !4017, !tbaa !1573
  %cmp185.not = icmp eq ptr %56, null, !dbg !4019
  br i1 %cmp185.not, label %stop, label %if.then187, !dbg !4020

if.then187:                                       ; preds = %while.end
  tail call void @llvm.dbg.value(metadata ptr %56, metadata !1540, metadata !DIExpression()), !dbg !4021
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !1547, metadata !DIExpression()), !dbg !4021
  tail call void @llvm.dbg.value(metadata i64 24, metadata !1548, metadata !DIExpression()), !dbg !4021
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1551, metadata !DIExpression()), !dbg !4021
  %call.i320 = call i64 @strlen(ptr noundef nonnull dereferenceable(1) %56) #15, !dbg !4024
  tail call void @llvm.dbg.value(metadata i64 %call.i320, metadata !1552, metadata !DIExpression()), !dbg !4021
  tail call void @llvm.dbg.value(metadata ptr %56, metadata !1550, metadata !DIExpression()), !dbg !4021
  tail call void @llvm.dbg.value(metadata ptr %56, metadata !1549, metadata !DIExpression()), !dbg !4021
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1553, metadata !DIExpression()), !dbg !4021
  %cmp77.not.i = icmp eq i64 %call.i320, 0, !dbg !4025
  br i1 %cmp77.not.i, label %tokenize_command.exit, label %for.body.i, !dbg !4026

for.body.i:                                       ; preds = %if.then187, %if.end13.i
  %i.082.i = phi i32 [ %inc15.i, %if.end13.i ], [ 0, %if.then187 ]
  %s.081.i = phi ptr [ %s.1.i, %if.end13.i ], [ %56, %if.then187 ]
  %ntokens.080.i = phi i64 [ %ntokens.2.i, %if.end13.i ], [ 0, %if.then187 ]
  %e.078.i = phi ptr [ %incdec.ptr14.i, %if.end13.i ], [ %56, %if.then187 ]
  tail call void @llvm.dbg.value(metadata i32 %i.082.i, metadata !1553, metadata !DIExpression()), !dbg !4021
  tail call void @llvm.dbg.value(metadata ptr %s.081.i, metadata !1549, metadata !DIExpression()), !dbg !4021
  tail call void @llvm.dbg.value(metadata i64 %ntokens.080.i, metadata !1551, metadata !DIExpression()), !dbg !4021
  tail call void @llvm.dbg.value(metadata ptr %e.078.i, metadata !1550, metadata !DIExpression()), !dbg !4021
  %57 = load i8, ptr %e.078.i, align 1, !dbg !4027, !tbaa !1240
  %cmp3.i = icmp eq i8 %57, 32, !dbg !4028
  br i1 %cmp3.i, label %if.then.i323, label %if.end13.i, !dbg !4029

if.then.i323:                                     ; preds = %for.body.i
  %cmp5.not.i = icmp eq ptr %s.081.i, %e.078.i, !dbg !4030
  br i1 %cmp5.not.i, label %if.end12.i, label %if.then7.i, !dbg !4031

if.then7.i:                                       ; preds = %if.then.i323
  %arrayidx.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %ntokens.080.i, !dbg !4032
  store ptr %s.081.i, ptr %arrayidx.i, align 8, !dbg !4033, !tbaa !1573
  %sub.ptr.lhs.cast.i324 = ptrtoint ptr %e.078.i to i64, !dbg !4034
  %sub.ptr.rhs.cast.i325 = ptrtoint ptr %s.081.i to i64, !dbg !4034
  %sub.ptr.sub.i326 = sub i64 %sub.ptr.lhs.cast.i324, %sub.ptr.rhs.cast.i325, !dbg !4034
  %length.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 8, !dbg !4035
  store i64 %sub.ptr.sub.i326, ptr %length.i, align 8, !dbg !4036, !tbaa !1578
  %inc.i = add i64 %ntokens.080.i, 1, !dbg !4037
  tail call void @llvm.dbg.value(metadata i64 %inc.i, metadata !1551, metadata !DIExpression()), !dbg !4021
  store i8 0, ptr %e.078.i, align 1, !dbg !4038, !tbaa !1240
  %cmp9.i = icmp eq i64 %inc.i, 23, !dbg !4039
  br i1 %cmp9.i, label %for.end.thread.i, label %if.end12.i, !dbg !4040

for.end.thread.i:                                 ; preds = %if.then7.i
  %incdec.ptr.i328 = getelementptr inbounds i8, ptr %e.078.i, i64 1, !dbg !4041
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i328, metadata !1549, metadata !DIExpression()), !dbg !4021
  tail call void @llvm.dbg.value(metadata i64 23, metadata !1551, metadata !DIExpression()), !dbg !4021
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i328, metadata !1550, metadata !DIExpression()), !dbg !4021
  br label %tokenize_command.exit, !dbg !4042

if.end12.i:                                       ; preds = %if.then7.i, %if.then.i323
  %ntokens.1.i = phi i64 [ %inc.i, %if.then7.i ], [ %ntokens.080.i, %if.then.i323 ], !dbg !4021
  tail call void @llvm.dbg.value(metadata i64 %ntokens.1.i, metadata !1551, metadata !DIExpression()), !dbg !4021
  %add.ptr.i327 = getelementptr inbounds i8, ptr %e.078.i, i64 1, !dbg !4043
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i327, metadata !1549, metadata !DIExpression()), !dbg !4021
  br label %if.end13.i, !dbg !4044

if.end13.i:                                       ; preds = %if.end12.i, %for.body.i
  %ntokens.2.i = phi i64 [ %ntokens.1.i, %if.end12.i ], [ %ntokens.080.i, %for.body.i ], !dbg !4021
  %s.1.i = phi ptr [ %add.ptr.i327, %if.end12.i ], [ %s.081.i, %for.body.i ], !dbg !4021
  tail call void @llvm.dbg.value(metadata ptr %s.1.i, metadata !1549, metadata !DIExpression()), !dbg !4021
  tail call void @llvm.dbg.value(metadata i64 %ntokens.2.i, metadata !1551, metadata !DIExpression()), !dbg !4021
  %incdec.ptr14.i = getelementptr inbounds i8, ptr %e.078.i, i64 1, !dbg !4045
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr14.i, metadata !1550, metadata !DIExpression()), !dbg !4021
  %inc15.i = add i32 %i.082.i, 1, !dbg !4046
  tail call void @llvm.dbg.value(metadata i32 %inc15.i, metadata !1553, metadata !DIExpression()), !dbg !4021
  %conv.i321 = zext i32 %inc15.i to i64, !dbg !4047
  %cmp.i322 = icmp ugt i64 %call.i320, %conv.i321, !dbg !4025
  br i1 %cmp.i322, label %for.body.i, label %for.end.i, !dbg !4026, !llvm.loop !4048

for.end.i:                                        ; preds = %if.end13.i
  tail call void @llvm.dbg.value(metadata ptr %s.1.i, metadata !1549, metadata !DIExpression()), !dbg !4021
  tail call void @llvm.dbg.value(metadata i64 %ntokens.2.i, metadata !1551, metadata !DIExpression()), !dbg !4021
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr14.i, metadata !1550, metadata !DIExpression()), !dbg !4021
  %cmp16.not.i = icmp eq ptr %s.1.i, %incdec.ptr14.i, !dbg !4050
  br i1 %cmp16.not.i, label %tokenize_command.exit, label %if.then18.i, !dbg !4042

if.then18.i:                                      ; preds = %for.end.i
  %arrayidx19.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %ntokens.2.i, !dbg !4051
  store ptr %s.1.i, ptr %arrayidx19.i, align 8, !dbg !4052, !tbaa !1573
  %sub.ptr.lhs.cast21.i = ptrtoint ptr %incdec.ptr14.i to i64, !dbg !4053
  %sub.ptr.rhs.cast22.i = ptrtoint ptr %s.1.i to i64, !dbg !4053
  %sub.ptr.sub23.i = sub i64 %sub.ptr.lhs.cast21.i, %sub.ptr.rhs.cast22.i, !dbg !4053
  %length25.i = getelementptr inbounds i8, ptr %arrayidx19.i, i64 8, !dbg !4054
  store i64 %sub.ptr.sub23.i, ptr %length25.i, align 8, !dbg !4055, !tbaa !1578
  %inc26.i = add i64 %ntokens.2.i, 1, !dbg !4056
  tail call void @llvm.dbg.value(metadata i64 %inc26.i, metadata !1551, metadata !DIExpression()), !dbg !4021
  br label %tokenize_command.exit, !dbg !4057

tokenize_command.exit:                            ; preds = %if.then187, %for.end.thread.i, %for.end.i, %if.then18.i
  %e.173.i = phi ptr [ %incdec.ptr14.i, %if.then18.i ], [ %incdec.ptr14.i, %for.end.i ], [ %incdec.ptr.i328, %for.end.thread.i ], [ %56, %if.then187 ]
  %ntokens.4.i = phi i64 [ %inc26.i, %if.then18.i ], [ %ntokens.2.i, %for.end.i ], [ 23, %for.end.thread.i ], [ 0, %if.then187 ], !dbg !4021
  tail call void @llvm.dbg.value(metadata i64 %ntokens.4.i, metadata !1551, metadata !DIExpression()), !dbg !4021
  %58 = load i8, ptr %e.173.i, align 1, !dbg !4058, !tbaa !1240
  %cmp29.i = icmp eq i8 %58, 0, !dbg !4059
  %spec.select.i = select i1 %cmp29.i, ptr null, ptr %e.173.i, !dbg !4058
  %arrayidx31.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %ntokens.4.i, !dbg !4060
  store ptr %spec.select.i, ptr %arrayidx31.i, align 8, !dbg !4061, !tbaa !1573
  %length34.i = getelementptr inbounds i8, ptr %arrayidx31.i, i64 8, !dbg !4062
  store i64 0, ptr %length34.i, align 8, !dbg !4063, !tbaa !1578
  tail call void @llvm.dbg.value(metadata i64 %ntokens.4.i, metadata !1551, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !4021
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !3786, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !3792, metadata !DIExpression()), !dbg !3810
  %call190 = call zeroext i1 @resp_start(ptr noundef %c) #13, !dbg !4064
  br i1 %call190, label %do.cond, label %stop, !dbg !4066

do.cond:                                          ; preds = %tokenize_command.exit
  %59 = load ptr, ptr %resp2, align 8, !dbg !4067, !tbaa !1351
  tail call void @llvm.dbg.value(metadata ptr %59, metadata !3796, metadata !DIExpression()), !dbg !3810
  %.pr = load ptr, ptr %tokens, align 8, !dbg !4068, !tbaa !1573
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !3792, metadata !DIExpression()), !dbg !3810
  %cmp196.not = icmp eq ptr %.pr, null, !dbg !4069
  br i1 %cmp196.not, label %stop, label %do.body, !dbg !4070, !llvm.loop !4071

stop:                                             ; preds = %while.end, %do.cond, %tokenize_command.exit, %cleanup181.thread
  %fail_length.3 = phi i1 [ %cmp11358, %cleanup181.thread ], [ false, %tokenize_command.exit ], [ false, %do.cond ], [ false, %while.end ], !dbg !3810
  %resp.5 = phi ptr [ %resp.1351, %cleanup181.thread ], [ %resp.1.lcssa, %while.end ], [ %59, %do.cond ], [ %resp.1.lcssa, %tokenize_command.exit ], !dbg !3810
  %key_token.5 = phi ptr [ %key_token.3.ph, %cleanup181.thread ], [ %key_token.2.lcssa, %while.end ], [ %tokens, %do.cond ], [ %tokens, %tokenize_command.exit ], !dbg !3810
  tail call void @llvm.dbg.value(metadata ptr %key_token.5, metadata !3792, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata ptr %resp.5, metadata !3796, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !3795, metadata !DIExpression()), !dbg !3810
  tail call void @llvm.dbg.label(metadata !3808), !dbg !4073
  %60 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !4074, !tbaa !1858
  %cmp198 = icmp sgt i32 %60, 1, !dbg !4076
  br i1 %cmp198, label %if.then200, label %if.end203, !dbg !4077

if.then200:                                       ; preds = %stop
  %61 = load ptr, ptr @stderr, align 8, !dbg !4078, !tbaa !1271
  %62 = load i32, ptr %sfd, align 8, !dbg !4079, !tbaa !1311
  %call202 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %61, ptr noundef nonnull @.str.79, i32 noundef %62) #17, !dbg !4080
  br label %if.end203, !dbg !4080

if.end203:                                        ; preds = %if.then200, %stop
  %63 = load ptr, ptr %key_token.5, align 8, !dbg !4081, !tbaa !1573
  %cmp205.not = icmp eq ptr %63, null, !dbg !4083
  br i1 %cmp205.not, label %if.else215, label %if.then207, !dbg !4084

if.then207:                                       ; preds = %if.end203
  call void @conn_release_items(ptr noundef %c) #13, !dbg !4085
  %call208 = call zeroext i1 @resp_start(ptr noundef %c) #13, !dbg !4087
  br i1 %call208, label %if.end210, label %if.then209, !dbg !4089

if.then209:                                       ; preds = %if.then207
  call void @conn_set_state(ptr noundef %c, i32 noundef 8) #13, !dbg !4090
  br label %cleanup217, !dbg !4092

if.end210:                                        ; preds = %if.then207
  br i1 %fail_length.3, label %if.then212, label %if.else213, !dbg !4093

if.then212:                                       ; preds = %if.end210
  call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.48) #13, !dbg !4094
  br label %cleanup217, !dbg !4097

if.else213:                                       ; preds = %if.end210
  call void @out_of_memory(ptr noundef %c, ptr noundef nonnull @.str.80) #13, !dbg !4098
  br label %cleanup217

if.else215:                                       ; preds = %if.end203
  call void @resp_add_iov(ptr noundef %resp.5, ptr noundef nonnull @.str.81, i32 noundef 5) #13, !dbg !4100
  call void @conn_set_state(ptr noundef %c, i32 noundef 9) #13, !dbg !4102
  br label %cleanup217

cleanup217:                                       ; preds = %if.else215, %if.else213, %if.then212, %if.then209, %if.then4
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %exptime_int) #13, !dbg !4103
  ret void, !dbg !4103
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_update_command(ptr noundef %c, ptr nocapture noundef readonly %tokens, i64 noundef %ntokens, i32 noundef %comm, i1 noundef zeroext %handle_cas) unnamed_addr #0 !dbg !4104 {
entry:
  %flags = alloca i32, align 4, !DIAssignID !4126
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4115, metadata !DIExpression(), metadata !4126, metadata ptr %flags, metadata !DIExpression()), !dbg !4127
  %exptime_int = alloca i32, align 4, !DIAssignID !4128
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4116, metadata !DIExpression(), metadata !4128, metadata ptr %exptime_int, metadata !DIExpression()), !dbg !4127
  %vlen = alloca i32, align 4, !DIAssignID !4129
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4118, metadata !DIExpression(), metadata !4129, metadata ptr %vlen, metadata !DIExpression()), !dbg !4127
  %req_cas_id = alloca i64, align 8, !DIAssignID !4130
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4119, metadata !DIExpression(), metadata !4130, metadata ptr %req_cas_id, metadata !DIExpression()), !dbg !4127
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4108, metadata !DIExpression()), !dbg !4127
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4109, metadata !DIExpression()), !dbg !4127
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4110, metadata !DIExpression()), !dbg !4127
  tail call void @llvm.dbg.value(metadata i32 %comm, metadata !4111, metadata !DIExpression()), !dbg !4127
  tail call void @llvm.dbg.value(metadata i1 %handle_cas, metadata !4112, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4127
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %flags) #13, !dbg !4131
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %exptime_int) #13, !dbg !4132
  store i32 0, ptr %exptime_int, align 4, !dbg !4133, !tbaa !1231, !DIAssignID !4134
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !4116, metadata !DIExpression(), metadata !4134, metadata ptr %exptime_int, metadata !DIExpression()), !dbg !4127
  tail call void @llvm.dbg.value(metadata i32 0, metadata !4117, metadata !DIExpression()), !dbg !4127
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %vlen) #13, !dbg !4135
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %req_cas_id) #13, !dbg !4136
  store i64 0, ptr %req_cas_id, align 8, !dbg !4137, !tbaa !1308, !DIAssignID !4138
  tail call void @llvm.dbg.assign(metadata i64 0, metadata !4119, metadata !DIExpression(), metadata !4138, metadata ptr %req_cas_id, metadata !DIExpression()), !dbg !4127
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4139, metadata !DIExpression()), !dbg !4147
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4144, metadata !DIExpression()), !dbg !4147
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4145, metadata !DIExpression()), !dbg !4147
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4146, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_minus, DW_OP_stack_value)), !dbg !4147
  %conv.i = shl i64 %ntokens, 32, !dbg !4149
  %sext.i = add i64 %conv.i, -8589934592, !dbg !4149
  %idxprom.i = ashr exact i64 %sext.i, 32, !dbg !4149
  %arrayidx.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %idxprom.i, !dbg !4149
  %0 = load ptr, ptr %arrayidx.i, align 8, !dbg !4151, !tbaa !1573
  %tobool.not.i = icmp eq ptr %0, null, !dbg !4149
  br i1 %tobool.not.i, label %set_noreply_maybe.exit, label %land.lhs.true.i, !dbg !4152

land.lhs.true.i:                                  ; preds = %entry
  %call.i = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(8) @.str.82) #15, !dbg !4153
  %cmp.i = icmp eq i32 %call.i, 0, !dbg !4154
  br i1 %cmp.i, label %if.then.i, label %set_noreply_maybe.exit, !dbg !4155

if.then.i:                                        ; preds = %land.lhs.true.i
  %noreply.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !4156
  store i8 1, ptr %noreply.i, align 4, !dbg !4158, !tbaa !1302
  br label %set_noreply_maybe.exit, !dbg !4159

set_noreply_maybe.exit:                           ; preds = %entry, %land.lhs.true.i, %if.then.i
  %length = getelementptr inbounds i8, ptr %tokens, i64 24, !dbg !4160
  %1 = load i64, ptr %length, align 8, !dbg !4160, !tbaa !1578
  %cmp = icmp ugt i64 %1, 250, !dbg !4162
  br i1 %cmp, label %if.then, label %if.end, !dbg !4163

if.then:                                          ; preds = %set_noreply_maybe.exit
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.48) #13, !dbg !4164
  br label %cleanup, !dbg !4166

if.end:                                           ; preds = %set_noreply_maybe.exit
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !4167
  %2 = load ptr, ptr %arrayidx, align 8, !dbg !4168, !tbaa !1573
  tail call void @llvm.dbg.value(metadata ptr %2, metadata !4113, metadata !DIExpression()), !dbg !4127
  tail call void @llvm.dbg.value(metadata i64 %1, metadata !4114, metadata !DIExpression()), !dbg !4127
  %arrayidx4 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !4169
  %3 = load ptr, ptr %arrayidx4, align 8, !dbg !4171, !tbaa !1573
  %call6 = call zeroext i1 @safe_strtoul(ptr noundef %3, ptr noundef nonnull %flags) #13, !dbg !4172
  br i1 %call6, label %land.lhs.true, label %if.then14, !dbg !4173

land.lhs.true:                                    ; preds = %if.end
  %arrayidx7 = getelementptr inbounds i8, ptr %tokens, i64 48, !dbg !4174
  %4 = load ptr, ptr %arrayidx7, align 8, !dbg !4175, !tbaa !1573
  %call9 = call zeroext i1 @safe_strtol(ptr noundef %4, ptr noundef nonnull %exptime_int) #13, !dbg !4176
  br i1 %call9, label %land.lhs.true10, label %if.then14, !dbg !4177

land.lhs.true10:                                  ; preds = %land.lhs.true
  %arrayidx11 = getelementptr inbounds i8, ptr %tokens, i64 64, !dbg !4178
  %5 = load ptr, ptr %arrayidx11, align 8, !dbg !4179, !tbaa !1573
  %call13 = call zeroext i1 @safe_strtol(ptr noundef %5, ptr noundef nonnull %vlen) #13, !dbg !4180
  br i1 %call13, label %if.end15, label %if.then14, !dbg !4181

if.then14:                                        ; preds = %land.lhs.true10, %land.lhs.true, %if.end
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.48) #13, !dbg !4182
  br label %cleanup, !dbg !4184

if.end15:                                         ; preds = %land.lhs.true10
  %6 = load i32, ptr %exptime_int, align 4, !dbg !4185, !tbaa !1231
  %cmp16 = icmp slt i32 %6, 0, !dbg !4185
  %narrow = select i1 %cmp16, i32 2592001, i32 %6, !dbg !4185
  %spec.select = zext i32 %narrow to i64, !dbg !4185
  %call17 = call i32 @realtime(i64 noundef %spec.select) #13, !dbg !4186
  tail call void @llvm.dbg.value(metadata i32 %call17, metadata !4117, metadata !DIExpression()), !dbg !4127
  br i1 %handle_cas, label %if.then18, label %if.end24, !dbg !4187

if.then18:                                        ; preds = %if.end15
  %arrayidx19 = getelementptr inbounds i8, ptr %tokens, i64 80, !dbg !4188
  %7 = load ptr, ptr %arrayidx19, align 8, !dbg !4192, !tbaa !1573
  %call21 = call zeroext i1 @safe_strtoull(ptr noundef %7, ptr noundef nonnull %req_cas_id) #13, !dbg !4193
  br i1 %call21, label %if.end24, label %if.then22, !dbg !4194

if.then22:                                        ; preds = %if.then18
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.48) #13, !dbg !4195
  br label %cleanup, !dbg !4197

if.end24:                                         ; preds = %if.then18, %if.end15
  %8 = load i32, ptr %vlen, align 4, !dbg !4198, !tbaa !1231
  %or.cond = icmp ugt i32 %8, 2147483645, !dbg !4200
  br i1 %or.cond, label %if.then29, label %if.end30, !dbg !4200

if.then29:                                        ; preds = %if.end24
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.48) #13, !dbg !4201
  br label %cleanup, !dbg !4203

if.end30:                                         ; preds = %if.end24
  %add = add nuw nsw i32 %8, 2, !dbg !4204
  store i32 %add, ptr %vlen, align 4, !dbg !4204, !tbaa !1231, !DIAssignID !4205
  tail call void @llvm.dbg.assign(metadata i32 %add, metadata !4118, metadata !DIExpression(), metadata !4205, metadata ptr %vlen, metadata !DIExpression()), !dbg !4127
  %9 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 16), align 8, !dbg !4206, !tbaa !3845
  %tobool31.not = icmp eq i32 %9, 0, !dbg !4208
  br i1 %tobool31.not, label %if.end33, label %if.then32, !dbg !4209

if.then32:                                        ; preds = %if.end30
  call void @stats_prefix_record_set(ptr noundef %2, i64 noundef %1) #13, !dbg !4210
  %.pre = load i32, ptr %vlen, align 4, !dbg !4212, !tbaa !1231
  br label %if.end33, !dbg !4213

if.end33:                                         ; preds = %if.then32, %if.end30
  %10 = phi i32 [ %.pre, %if.then32 ], [ %add, %if.end30 ], !dbg !4212
  %11 = load i32, ptr %flags, align 4, !dbg !4214, !tbaa !1231
  %call34 = call ptr @item_alloc(ptr noundef %2, i64 noundef %1, i32 noundef %11, i32 noundef %call17, i32 noundef %10) #13, !dbg !4215
  tail call void @llvm.dbg.value(metadata ptr %call34, metadata !4120, metadata !DIExpression()), !dbg !4127
  %cmp35 = icmp eq ptr %call34, null, !dbg !4216
  br i1 %cmp35, label %if.then37, label %if.end85, !dbg !4217

if.then37:                                        ; preds = %if.end33
  %12 = load i32, ptr %flags, align 4, !dbg !4218, !tbaa !1231
  %13 = load i32, ptr %vlen, align 4, !dbg !4220, !tbaa !1231
  %call38 = call zeroext i1 @item_size_ok(i64 noundef %1, i32 noundef %12, i32 noundef %13) #13, !dbg !4221
  %thread47 = getelementptr inbounds i8, ptr %c, i64 456, !dbg !4222
  br i1 %call38, label %if.else, label %if.then39, !dbg !4223

if.then39:                                        ; preds = %if.then37
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.63) #13, !dbg !4224
  tail call void @llvm.dbg.value(metadata i32 4, metadata !4121, metadata !DIExpression()), !dbg !4226
  %14 = load ptr, ptr %thread47, align 8, !dbg !4227, !tbaa !1234
  %stats = getelementptr inbounds i8, ptr %14, i64 352, !dbg !4228
  %call40 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #13, !dbg !4229
  %15 = load ptr, ptr %thread47, align 8, !dbg !4230, !tbaa !1234
  %store_too_large = getelementptr inbounds i8, ptr %15, i64 568, !dbg !4231
  br label %do.body, !dbg !4232

if.else:                                          ; preds = %if.then37
  call void @out_of_memory(ptr noundef nonnull %c, ptr noundef nonnull @.str.64) #13, !dbg !4233
  tail call void @llvm.dbg.value(metadata i32 5, metadata !4121, metadata !DIExpression()), !dbg !4226
  %16 = load ptr, ptr %thread47, align 8, !dbg !4235, !tbaa !1234
  %stats48 = getelementptr inbounds i8, ptr %16, i64 352, !dbg !4236
  %call50 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats48) #13, !dbg !4237
  %17 = load ptr, ptr %thread47, align 8, !dbg !4238, !tbaa !1234
  %store_no_memory = getelementptr inbounds i8, ptr %17, i64 576, !dbg !4239
  br label %do.body

do.body:                                          ; preds = %if.then39, %if.else
  %store_too_large.sink172 = phi ptr [ %store_too_large, %if.then39 ], [ %store_no_memory, %if.else ]
  %.sink = phi ptr [ %15, %if.then39 ], [ %17, %if.else ]
  %status.0 = phi i32 [ 4, %if.then39 ], [ 5, %if.else ], !dbg !4222
  %18 = load i64, ptr %store_too_large.sink172, align 8, !dbg !4222, !tbaa !1308
  %inc = add i64 %18, 1, !dbg !4222
  store i64 %inc, ptr %store_too_large.sink172, align 8, !dbg !4222, !tbaa !1308
  %stats44 = getelementptr inbounds i8, ptr %.sink, i64 352, !dbg !4222
  %call46 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats44) #13, !dbg !4222
  tail call void @llvm.dbg.value(metadata i32 %status.0, metadata !4121, metadata !DIExpression()), !dbg !4226
  %thread59 = getelementptr inbounds i8, ptr %c, i64 456, !dbg !4240
  %19 = load ptr, ptr %thread59, align 8, !dbg !4240, !tbaa !1234
  %l = getelementptr inbounds i8, ptr %19, i64 6912, !dbg !4240
  %20 = load ptr, ptr %l, align 8, !dbg !4240, !tbaa !2997
  tail call void @llvm.dbg.value(metadata ptr %20, metadata !4124, metadata !DIExpression()), !dbg !4241
  %cmp62 = icmp eq ptr %20, null, !dbg !4242
  br i1 %cmp62, label %if.then64, label %if.end66, !dbg !4240

if.then64:                                        ; preds = %do.body
  %21 = load i32, ptr @logger_key, align 4, !dbg !4242, !tbaa !1231
  %call65 = call ptr @pthread_getspecific(i32 noundef %21) #13, !dbg !4242
  tail call void @llvm.dbg.value(metadata ptr %call65, metadata !4124, metadata !DIExpression()), !dbg !4241
  br label %if.end66, !dbg !4242

if.end66:                                         ; preds = %if.then64, %do.body
  %myl.0 = phi ptr [ %call65, %if.then64 ], [ %20, %do.body ], !dbg !4240
  tail call void @llvm.dbg.value(metadata ptr %myl.0, metadata !4124, metadata !DIExpression()), !dbg !4241
  %eflags = getelementptr inbounds i8, ptr %myl.0, i64 84, !dbg !4244
  %22 = load i16, ptr %eflags, align 4, !dbg !4244, !tbaa !3003
  %23 = and i16 %22, 8, !dbg !4244
  %tobool68.not = icmp eq i16 %23, 0, !dbg !4244
  br i1 %tobool68.not, label %if.end71, label %if.then69, !dbg !4240

if.then69:                                        ; preds = %if.end66
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !4244
  %24 = load i32, ptr %sfd, align 8, !dbg !4244, !tbaa !1311
  %call70 = call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %myl.0, i32 noundef 3, ptr noundef null, i32 noundef %status.0, i32 noundef %comm, ptr noundef %2, i64 noundef %1, i32 noundef 0, i32 noundef 0, i32 noundef %24) #13, !dbg !4244
  br label %if.end71, !dbg !4244

if.end71:                                         ; preds = %if.then69, %if.end66
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 7) #13, !dbg !4246
  %25 = load i32, ptr %vlen, align 4, !dbg !4247, !tbaa !1231
  %sbytes = getelementptr inbounds i8, ptr %c, i64 232, !dbg !4248
  store i32 %25, ptr %sbytes, align 8, !dbg !4249, !tbaa !3063
  %cmp72 = icmp eq i32 %comm, 2, !dbg !4250
  br i1 %cmp72, label %if.then74, label %cleanup, !dbg !4252

if.then74:                                        ; preds = %if.end71
  %26 = load ptr, ptr %thread59, align 8, !dbg !4253, !tbaa !1234
  %call76 = call ptr @item_get(ptr noundef %2, i64 noundef %1, ptr noundef %26, i1 noundef zeroext false) #13, !dbg !4255
  tail call void @llvm.dbg.value(metadata ptr %call76, metadata !4120, metadata !DIExpression()), !dbg !4127
  %tobool77.not = icmp eq ptr %call76, null, !dbg !4256
  br i1 %tobool77.not, label %cleanup, label %if.then78, !dbg !4258

if.then78:                                        ; preds = %if.then74
  call void @item_unlink(ptr noundef nonnull %call76) #13, !dbg !4259
  %27 = load ptr, ptr %thread59, align 8, !dbg !4261, !tbaa !1234
  %storage = getelementptr inbounds i8, ptr %27, i64 6904, !dbg !4261
  %28 = load ptr, ptr %storage, align 8, !dbg !4261, !tbaa !3015
  call void @storage_delete(ptr noundef %28, ptr noundef nonnull %call76) #13, !dbg !4261
  call void @item_remove(ptr noundef nonnull %call76) #13, !dbg !4263
  br label %cleanup, !dbg !4264

if.end85:                                         ; preds = %if.end33
  %it_flags = getelementptr inbounds i8, ptr %call34, i64 38, !dbg !4265
  %29 = load i16, ptr %it_flags, align 2, !dbg !4265, !tbaa !1248
  %30 = and i16 %29, 2, !dbg !4265
  %tobool88.not = icmp eq i16 %30, 0, !dbg !4265
  br i1 %tobool88.not, label %if.end90, label %if.then89, !dbg !4268

if.then89:                                        ; preds = %if.end85
  %31 = load i64, ptr %req_cas_id, align 8, !dbg !4269, !tbaa !1308
  %data = getelementptr inbounds i8, ptr %call34, i64 48, !dbg !4269
  store i64 %31, ptr %data, align 8, !dbg !4269, !tbaa !1240
  br label %if.end90, !dbg !4269

if.end90:                                         ; preds = %if.then89, %if.end85
  %item = getelementptr inbounds i8, ptr %c, i64 224, !dbg !4271
  store ptr %call34, ptr %item, align 8, !dbg !4272, !tbaa !1210
  %data91 = getelementptr inbounds i8, ptr %call34, i64 48, !dbg !4273
  %nkey92 = getelementptr inbounds i8, ptr %call34, i64 41, !dbg !4273
  %32 = load i8, ptr %nkey92, align 1, !dbg !4273, !tbaa !1240
  %idx.ext = zext i8 %32 to i64
  %add.ptr = getelementptr inbounds i8, ptr %data91, i64 %idx.ext, !dbg !4273
  %add.ptr94 = getelementptr inbounds i8, ptr %add.ptr, i64 1, !dbg !4273
  %conv96 = zext i16 %29 to i32, !dbg !4273
  %and97 = lshr i32 %conv96, 6, !dbg !4273
  %33 = and i32 %and97, 4, !dbg !4273
  %cond99 = zext nneg i32 %33 to i64, !dbg !4273
  %add.ptr100 = getelementptr inbounds i8, ptr %add.ptr94, i64 %cond99, !dbg !4273
  %and103 = shl nuw nsw i32 %conv96, 2, !dbg !4273
  %34 = and i32 %and103, 8, !dbg !4273
  %cond105 = zext nneg i32 %34 to i64, !dbg !4273
  %add.ptr106 = getelementptr inbounds i8, ptr %add.ptr100, i64 %cond105, !dbg !4273
  %ritem = getelementptr inbounds i8, ptr %c, i64 208, !dbg !4274
  store ptr %add.ptr106, ptr %ritem, align 8, !dbg !4275, !tbaa !1255
  %nbytes = getelementptr inbounds i8, ptr %call34, i64 32, !dbg !4276
  %35 = load i32, ptr %nbytes, align 8, !dbg !4276, !tbaa !1231
  %rlbytes = getelementptr inbounds i8, ptr %c, i64 216, !dbg !4277
  store i32 %35, ptr %rlbytes, align 8, !dbg !4278, !tbaa !1516
  %conv107 = trunc nuw nsw i32 %comm to i16, !dbg !4279
  %cmd = getelementptr inbounds i8, ptr %c, i64 432, !dbg !4280
  store i16 %conv107, ptr %cmd, align 8, !dbg !4281, !tbaa !1227
  call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 6) #13, !dbg !4282
  br label %cleanup, !dbg !4283

cleanup:                                          ; preds = %if.end71, %if.then78, %if.then74, %if.end90, %if.then29, %if.then22, %if.then14, %if.then
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %req_cas_id) #13, !dbg !4283
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %vlen) #13, !dbg !4283
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %exptime_int) #13, !dbg !4283
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %flags) #13, !dbg !4283
  ret void, !dbg !4283
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_stat(ptr noundef %c, ptr nocapture noundef readonly %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !4284 {
entry:
  %bytes = alloca i32, align 4, !DIAssignID !4300
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4297, metadata !DIExpression(), metadata !4300, metadata ptr %bytes, metadata !DIExpression()), !dbg !4301
  %id = alloca i32, align 4, !DIAssignID !4302
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4298, metadata !DIExpression(), metadata !4302, metadata ptr %id, metadata !DIExpression()), !dbg !4301
  %limit = alloca i32, align 4, !DIAssignID !4303
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4299, metadata !DIExpression(), metadata !4303, metadata ptr %limit, metadata !DIExpression()), !dbg !4301
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4286, metadata !DIExpression()), !dbg !4304
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4287, metadata !DIExpression()), !dbg !4304
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4288, metadata !DIExpression()), !dbg !4304
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !4305
  %0 = load ptr, ptr %arrayidx, align 8, !dbg !4306, !tbaa !1573
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !4289, metadata !DIExpression()), !dbg !4304
  %cmp1 = icmp eq i64 %ntokens, 2, !dbg !4307
  br i1 %cmp1, label %if.then2, label %if.else, !dbg !4308

if.then2:                                         ; preds = %entry
  tail call void @server_stats(ptr noundef nonnull @append_stats, ptr noundef %c) #13, !dbg !4309
  %call = tail call zeroext i1 @get_stats(ptr noundef null, i32 noundef 0, ptr noundef nonnull @append_stats, ptr noundef %c) #13, !dbg !4311
  br label %if.end75, !dbg !4312

if.else:                                          ; preds = %entry
  %call3 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(6) @.str.84) #15, !dbg !4313
  %cmp4 = icmp eq i32 %call3, 0, !dbg !4314
  br i1 %cmp4, label %if.then5, label %if.else6, !dbg !4315

if.then5:                                         ; preds = %if.else
  tail call void @stats_reset() #13, !dbg !4316
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.85) #13, !dbg !4318
  br label %cleanup90, !dbg !4319

if.else6:                                         ; preds = %if.else
  %call7 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(7) @.str.86) #15, !dbg !4320
  %cmp8 = icmp eq i32 %call7, 0, !dbg !4321
  br i1 %cmp8, label %if.then9, label %if.else16, !dbg !4322

if.then9:                                         ; preds = %if.else6
  %cmp10 = icmp ult i64 %ntokens, 4, !dbg !4323
  br i1 %cmp10, label %if.then11, label %if.else12, !dbg !4326

if.then11:                                        ; preds = %if.then9
  tail call fastcc void @process_stats_detail(ptr noundef %c, ptr noundef nonnull @.str.87), !dbg !4327
  br label %cleanup90, !dbg !4327

if.else12:                                        ; preds = %if.then9
  %arrayidx13 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !4328
  %1 = load ptr, ptr %arrayidx13, align 8, !dbg !4329, !tbaa !1573
  tail call fastcc void @process_stats_detail(ptr noundef %c, ptr noundef %1), !dbg !4330
  br label %cleanup90

if.else16:                                        ; preds = %if.else6
  %call17 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(9) @.str.88) #15, !dbg !4331
  %cmp18 = icmp eq i32 %call17, 0, !dbg !4332
  br i1 %cmp18, label %if.then19, label %if.else20, !dbg !4333

if.then19:                                        ; preds = %if.else16
  tail call void @process_stat_settings(ptr noundef nonnull @append_stats, ptr noundef %c) #13, !dbg !4334
  br label %if.end75, !dbg !4336

if.else20:                                        ; preds = %if.else16
  %call21 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(10) @.str.89) #15, !dbg !4337
  %cmp22 = icmp eq i32 %call21, 0, !dbg !4338
  br i1 %cmp22, label %if.then23, label %if.else44, !dbg !4339

if.then23:                                        ; preds = %if.else20
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %bytes) #13, !dbg !4340
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %id) #13, !dbg !4340
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %limit) #13, !dbg !4340
  store i32 0, ptr %limit, align 4, !dbg !4341, !tbaa !1231, !DIAssignID !4342
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !4299, metadata !DIExpression(), metadata !4342, metadata ptr %limit, metadata !DIExpression()), !dbg !4301
  %2 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 38), align 1, !dbg !4343, !tbaa !4345, !range !1296, !noundef !1297
  %tobool = trunc nuw i8 %2 to i1, !dbg !4343
  br i1 %tobool, label %if.end25, label %if.then24, !dbg !4346

if.then24:                                        ; preds = %if.then23
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.90) #13, !dbg !4347
  br label %cleanup, !dbg !4349

if.end25:                                         ; preds = %if.then23
  %cmp26 = icmp ult i64 %ntokens, 5, !dbg !4350
  br i1 %cmp26, label %if.then27, label %if.end28, !dbg !4352

if.then27:                                        ; preds = %if.end25
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.83) #13, !dbg !4353
  br label %cleanup, !dbg !4355

if.end28:                                         ; preds = %if.end25
  %arrayidx29 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !4356
  %3 = load ptr, ptr %arrayidx29, align 8, !dbg !4358, !tbaa !1573
  %call31 = call zeroext i1 @safe_strtoul(ptr noundef %3, ptr noundef nonnull %id) #13, !dbg !4359
  br i1 %call31, label %lor.lhs.false, label %if.then35, !dbg !4360

lor.lhs.false:                                    ; preds = %if.end28
  %arrayidx32 = getelementptr inbounds i8, ptr %tokens, i64 48, !dbg !4361
  %4 = load ptr, ptr %arrayidx32, align 8, !dbg !4362, !tbaa !1573
  %call34 = call zeroext i1 @safe_strtoul(ptr noundef %4, ptr noundef nonnull %limit) #13, !dbg !4363
  br i1 %call34, label %if.end36, label %if.then35, !dbg !4364

if.then35:                                        ; preds = %lor.lhs.false, %if.end28
  call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.48) #13, !dbg !4365
  br label %cleanup, !dbg !4367

if.end36:                                         ; preds = %lor.lhs.false
  %5 = load i32, ptr %id, align 4, !dbg !4368, !tbaa !1231
  %cmp37 = icmp ugt i32 %5, 63, !dbg !4370
  br i1 %cmp37, label %if.then38, label %if.end39, !dbg !4371

if.then38:                                        ; preds = %if.end36
  call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.91) #13, !dbg !4372
  br label %cleanup, !dbg !4374

if.end39:                                         ; preds = %if.end36
  %6 = load i32, ptr %limit, align 4, !dbg !4375, !tbaa !1231
  %call40 = call ptr @item_cachedump(i32 noundef %5, i32 noundef %6, ptr noundef nonnull %bytes) #13, !dbg !4376
  tail call void @llvm.dbg.value(metadata ptr %call40, metadata !4290, metadata !DIExpression()), !dbg !4301
  %7 = load i32, ptr %bytes, align 4, !dbg !4377, !tbaa !1231
  call void @write_and_free(ptr noundef %c, ptr noundef %call40, i32 noundef %7) #13, !dbg !4378
  br label %cleanup, !dbg !4379

cleanup:                                          ; preds = %if.end39, %if.then38, %if.then35, %if.then27, %if.then24
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %limit) #13, !dbg !4380
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %id) #13, !dbg !4380
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %bytes) #13, !dbg !4380
  br label %cleanup90

if.else44:                                        ; preds = %if.else20
  %call45 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(6) @.str.92) #15, !dbg !4381
  %cmp46 = icmp eq i32 %call45, 0, !dbg !4383
  br i1 %cmp46, label %if.then47, label %if.else48, !dbg !4384

if.then47:                                        ; preds = %if.else44
  tail call void @process_stats_conns(ptr noundef nonnull @append_stats, ptr noundef %c) #13, !dbg !4385
  br label %if.end75, !dbg !4387

if.else48:                                        ; preds = %if.else44
  %call49 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(9) @.str.42) #15, !dbg !4388
  %cmp50 = icmp eq i32 %call49, 0, !dbg !4390
  br i1 %cmp50, label %if.then51, label %if.else52, !dbg !4391

if.then51:                                        ; preds = %if.else48
  tail call void @process_extstore_stats(ptr noundef nonnull @append_stats, ptr noundef %c) #13, !dbg !4392
  br label %if.end75

if.else52:                                        ; preds = %if.else48
  %call53 = tail call i64 @strlen(ptr noundef nonnull dereferenceable(1) %0) #15, !dbg !4394
  %conv = trunc i64 %call53 to i32, !dbg !4394
  %call54 = tail call zeroext i1 @get_stats(ptr noundef %0, i32 noundef %conv, ptr noundef nonnull @append_stats, ptr noundef %c) #13, !dbg !4397
  br i1 %call54, label %if.then55, label %if.else67, !dbg !4398

if.then55:                                        ; preds = %if.else52
  %stats = getelementptr inbounds i8, ptr %c, i64 368, !dbg !4399
  %8 = load ptr, ptr %stats, align 8, !dbg !4402, !tbaa !4403
  %cmp56 = icmp eq ptr %8, null, !dbg !4404
  br i1 %cmp56, label %if.then58, label %if.else59, !dbg !4405

if.then58:                                        ; preds = %if.then55
  tail call void @out_of_memory(ptr noundef nonnull %c, ptr noundef nonnull @.str.93) #13, !dbg !4406
  br label %cleanup90, !dbg !4408

if.else59:                                        ; preds = %if.then55
  %offset = getelementptr inbounds i8, ptr %c, i64 384, !dbg !4409
  %9 = load i64, ptr %offset, align 8, !dbg !4409, !tbaa !4411
  %conv63 = trunc i64 %9 to i32, !dbg !4412
  tail call void @write_and_free(ptr noundef nonnull %c, ptr noundef nonnull %8, i32 noundef %conv63) #13, !dbg !4413
  store ptr null, ptr %stats, align 8, !dbg !4414, !tbaa !4403
  br label %cleanup90

if.else67:                                        ; preds = %if.else52
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !4415
  br label %cleanup90

if.end75:                                         ; preds = %if.then19, %if.then47, %if.then51, %if.then2
  tail call void @append_stats(ptr noundef null, i16 noundef zeroext 0, ptr noundef null, i32 noundef 0, ptr noundef %c) #13, !dbg !4417
  %stats76 = getelementptr inbounds i8, ptr %c, i64 368, !dbg !4418
  %10 = load ptr, ptr %stats76, align 8, !dbg !4420, !tbaa !4403
  %cmp78 = icmp eq ptr %10, null, !dbg !4421
  br i1 %cmp78, label %if.then80, label %if.else81, !dbg !4422

if.then80:                                        ; preds = %if.end75
  tail call void @out_of_memory(ptr noundef nonnull %c, ptr noundef nonnull @.str.93) #13, !dbg !4423
  br label %cleanup90, !dbg !4425

if.else81:                                        ; preds = %if.end75
  %offset85 = getelementptr inbounds i8, ptr %c, i64 384, !dbg !4426
  %11 = load i64, ptr %offset85, align 8, !dbg !4426, !tbaa !4411
  %conv86 = trunc i64 %11 to i32, !dbg !4428
  tail call void @write_and_free(ptr noundef nonnull %c, ptr noundef nonnull %10, i32 noundef %conv86) #13, !dbg !4429
  store ptr null, ptr %stats76, align 8, !dbg !4430, !tbaa !4403
  br label %cleanup90

cleanup90:                                        ; preds = %if.then80, %if.else81, %if.else67, %if.else59, %if.then58, %if.then11, %if.else12, %cleanup, %if.then5
  ret void, !dbg !4431
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_shutdown_command(ptr noundef %c, ptr nocapture noundef readonly %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !4432 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4434, metadata !DIExpression()), !dbg !4437
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4435, metadata !DIExpression()), !dbg !4437
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4436, metadata !DIExpression()), !dbg !4437
  %0 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 35), align 8, !dbg !4438, !tbaa !4440, !range !1296, !noundef !1297
  %tobool = trunc nuw i8 %0 to i1, !dbg !4438
  br i1 %tobool, label %if.end, label %if.then, !dbg !4441

if.then:                                          ; preds = %entry
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.99) #13, !dbg !4442
  br label %if.end10, !dbg !4444

if.end:                                           ; preds = %entry
  switch i64 %ntokens, label %if.else8 [
    i64 2, label %if.then1
    i64 3, label %land.lhs.true
  ], !dbg !4445

if.then1:                                         ; preds = %if.end
  %close_reason = getelementptr inbounds i8, ptr %c, i64 324, !dbg !4446
  store i32 3, ptr %close_reason, align 4, !dbg !4449, !tbaa !2206
  tail call void @conn_set_state(ptr noundef %c, i32 noundef 8) #13, !dbg !4450
  %call = tail call i32 @raise(i32 noundef 2) #13, !dbg !4451
  br label %if.end10, !dbg !4452

land.lhs.true:                                    ; preds = %if.end
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !4453
  %1 = load ptr, ptr %arrayidx, align 8, !dbg !4455, !tbaa !1573
  %call3 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %1, ptr noundef nonnull dereferenceable(9) @.str.100) #15, !dbg !4456
  %cmp4 = icmp eq i32 %call3, 0, !dbg !4457
  br i1 %cmp4, label %if.then5, label %if.else8, !dbg !4458

if.then5:                                         ; preds = %land.lhs.true
  %close_reason6 = getelementptr inbounds i8, ptr %c, i64 324, !dbg !4459
  store i32 3, ptr %close_reason6, align 4, !dbg !4461, !tbaa !2206
  tail call void @conn_set_state(ptr noundef %c, i32 noundef 8) #13, !dbg !4462
  %call7 = tail call i32 @raise(i32 noundef 10) #13, !dbg !4463
  br label %if.end10, !dbg !4464

if.else8:                                         ; preds = %if.end, %land.lhs.true
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.101) #13, !dbg !4465
  br label %if.end10

if.end10:                                         ; preds = %if.then5, %if.else8, %if.then, %if.then1
  ret void, !dbg !4467
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_slabs_command(ptr noundef %c, ptr nocapture noundef readonly %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !4468 {
entry:
  %level.i = alloca i32, align 4, !DIAssignID !4478
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4479, metadata !DIExpression(), metadata !4478, metadata ptr %level.i, metadata !DIExpression()), !dbg !4487
  %ratio.i = alloca double, align 8, !DIAssignID !4491
  %src = alloca i32, align 4, !DIAssignID !4492
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4473, metadata !DIExpression(), metadata !4492, metadata ptr %src, metadata !DIExpression()), !dbg !4493
  %dst = alloca i32, align 4, !DIAssignID !4494
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4476, metadata !DIExpression(), metadata !4494, metadata ptr %dst, metadata !DIExpression()), !dbg !4493
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4470, metadata !DIExpression()), !dbg !4495
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4471, metadata !DIExpression()), !dbg !4495
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4472, metadata !DIExpression()), !dbg !4495
  %cmp = icmp eq i64 %ntokens, 5, !dbg !4496
  br i1 %cmp, label %land.lhs.true, label %if.else, !dbg !4497

land.lhs.true:                                    ; preds = %entry
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !4498
  %0 = load ptr, ptr %arrayidx, align 8, !dbg !4499, !tbaa !1573
  %call = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(9) @.str.102) #15, !dbg !4500
  %cmp1 = icmp eq i32 %call, 0, !dbg !4501
  br i1 %cmp1, label %if.then, label %land.lhs.true25, !dbg !4502

if.then:                                          ; preds = %land.lhs.true
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %src) #13, !dbg !4503
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %dst) #13, !dbg !4503
  %1 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 30), align 1, !dbg !4504, !tbaa !4506, !range !1296, !noundef !1297
  %cmp2 = icmp eq i8 %1, 0, !dbg !4507
  br i1 %cmp2, label %if.then4, label %if.end, !dbg !4508

if.then4:                                         ; preds = %if.then
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.103) #13, !dbg !4509
  br label %cleanup, !dbg !4511

if.end:                                           ; preds = %if.then
  %arrayidx5 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !4512
  %2 = load ptr, ptr %arrayidx5, align 8, !dbg !4514, !tbaa !1573
  %call7 = call zeroext i1 @safe_strtol(ptr noundef %2, ptr noundef nonnull %src) #13, !dbg !4515
  br i1 %call7, label %land.lhs.true9, label %if.then14, !dbg !4516

land.lhs.true9:                                   ; preds = %if.end
  %arrayidx10 = getelementptr inbounds i8, ptr %tokens, i64 48, !dbg !4517
  %3 = load ptr, ptr %arrayidx10, align 8, !dbg !4518, !tbaa !1573
  %call12 = call zeroext i1 @safe_strtol(ptr noundef %3, ptr noundef nonnull %dst) #13, !dbg !4519
  br i1 %call12, label %if.end15, label %if.then14, !dbg !4520

if.then14:                                        ; preds = %land.lhs.true9, %if.end
  call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.48) #13, !dbg !4521
  br label %cleanup, !dbg !4523

if.end15:                                         ; preds = %land.lhs.true9
  %4 = load i32, ptr %src, align 4, !dbg !4524, !tbaa !1231
  %5 = load i32, ptr %dst, align 4, !dbg !4525, !tbaa !1231
  %call16 = call i32 @slabs_reassign(i32 noundef %4, i32 noundef %5) #13, !dbg !4526
  tail call void @llvm.dbg.value(metadata i32 %call16, metadata !4477, metadata !DIExpression()), !dbg !4493
  switch i32 %call16, label %cleanup [
    i32 0, label %sw.bb
    i32 1, label %sw.bb17
    i32 2, label %sw.bb18
    i32 3, label %sw.bb19
    i32 4, label %sw.bb20
  ], !dbg !4527

sw.bb:                                            ; preds = %if.end15
  call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.95) #13, !dbg !4528
  br label %cleanup, !dbg !4530

sw.bb17:                                          ; preds = %if.end15
  call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.104) #13, !dbg !4531
  br label %cleanup, !dbg !4532

sw.bb18:                                          ; preds = %if.end15
  call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.105) #13, !dbg !4533
  br label %cleanup, !dbg !4534

sw.bb19:                                          ; preds = %if.end15
  call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.106) #13, !dbg !4535
  br label %cleanup, !dbg !4536

sw.bb20:                                          ; preds = %if.end15
  call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.107) #13, !dbg !4537
  br label %cleanup, !dbg !4538

cleanup:                                          ; preds = %sw.bb, %sw.bb17, %sw.bb18, %sw.bb19, %sw.bb20, %if.end15, %if.then14, %if.then4
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %dst) #13, !dbg !4539
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %src) #13, !dbg !4539
  br label %if.end34

if.else:                                          ; preds = %entry
  %cmp23 = icmp ugt i64 %ntokens, 3, !dbg !4540
  br i1 %cmp23, label %if.else.land.lhs.true25_crit_edge, label %if.else32, !dbg !4541

if.else.land.lhs.true25_crit_edge:                ; preds = %if.else
  %arrayidx26.phi.trans.insert = getelementptr inbounds i8, ptr %tokens, i64 16
  %.pre = load ptr, ptr %arrayidx26.phi.trans.insert, align 8, !dbg !4542, !tbaa !1573
  br label %land.lhs.true25, !dbg !4541

land.lhs.true25:                                  ; preds = %if.else.land.lhs.true25_crit_edge, %land.lhs.true
  %6 = phi ptr [ %.pre, %if.else.land.lhs.true25_crit_edge ], [ %0, %land.lhs.true ], !dbg !4542
  %call28 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %6, ptr noundef nonnull dereferenceable(9) @.str.108) #15, !dbg !4543
  %cmp29 = icmp eq i32 %call28, 0, !dbg !4544
  br i1 %cmp29, label %if.then31, label %if.else32, !dbg !4545

if.then31:                                        ; preds = %land.lhs.true25
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4485, metadata !DIExpression(), metadata !4491, metadata ptr %ratio.i, metadata !DIExpression()), !dbg !4487
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4482, metadata !DIExpression()), !dbg !4487
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4483, metadata !DIExpression()), !dbg !4487
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4484, metadata !DIExpression()), !dbg !4487
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %level.i) #13, !dbg !4546
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %ratio.i) #13, !dbg !4547
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4139, metadata !DIExpression()), !dbg !4548
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4144, metadata !DIExpression()), !dbg !4548
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4145, metadata !DIExpression()), !dbg !4548
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4146, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_minus, DW_OP_stack_value)), !dbg !4548
  %conv.i.i = shl i64 %ntokens, 32, !dbg !4550
  %sext.i.i = add i64 %conv.i.i, -8589934592, !dbg !4550
  %idxprom.i.i = ashr exact i64 %sext.i.i, 32, !dbg !4550
  %arrayidx.i.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %idxprom.i.i, !dbg !4550
  %7 = load ptr, ptr %arrayidx.i.i, align 8, !dbg !4551, !tbaa !1573
  %tobool.not.i.i = icmp eq ptr %7, null, !dbg !4550
  br i1 %tobool.not.i.i, label %set_noreply_maybe.exit.i, label %land.lhs.true.i.i, !dbg !4552

land.lhs.true.i.i:                                ; preds = %if.then31
  %call.i.i = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %7, ptr noundef nonnull dereferenceable(8) @.str.82) #15, !dbg !4553
  %cmp.i.i = icmp eq i32 %call.i.i, 0, !dbg !4554
  br i1 %cmp.i.i, label %if.then.i.i, label %set_noreply_maybe.exit.i, !dbg !4555

if.then.i.i:                                      ; preds = %land.lhs.true.i.i
  %noreply.i.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !4556
  store i8 1, ptr %noreply.i.i, align 4, !dbg !4557, !tbaa !1302
  br label %set_noreply_maybe.exit.i, !dbg !4558

set_noreply_maybe.exit.i:                         ; preds = %if.then.i.i, %land.lhs.true.i.i, %if.then31
  %arrayidx.i = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !4559
  %8 = load ptr, ptr %arrayidx.i, align 8, !dbg !4561, !tbaa !1573
  %call1.i = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %8, ptr noundef nonnull dereferenceable(6) @.str.109) #15, !dbg !4562
  %cmp.i = icmp eq i32 %call1.i, 0, !dbg !4563
  br i1 %cmp.i, label %if.then.i, label %if.else.i, !dbg !4564

if.then.i:                                        ; preds = %set_noreply_maybe.exit.i
  %cmp2.i = icmp ult i64 %ntokens, 5, !dbg !4565
  br i1 %cmp2.i, label %process_slabs_automove_command.exit, label %lor.lhs.false.i, !dbg !4568

lor.lhs.false.i:                                  ; preds = %if.then.i
  %arrayidx3.i = getelementptr inbounds i8, ptr %tokens, i64 48, !dbg !4569
  %9 = load ptr, ptr %arrayidx3.i, align 8, !dbg !4570, !tbaa !1573
  %call5.i = call zeroext i1 @safe_strtod(ptr noundef %9, ptr noundef nonnull %ratio.i) #13, !dbg !4571
  br i1 %call5.i, label %if.end.i, label %process_slabs_automove_command.exit, !dbg !4572

if.end.i:                                         ; preds = %lor.lhs.false.i
  %10 = load double, ptr %ratio.i, align 8, !dbg !4573, !tbaa !4574
  store double %10, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 32), align 8, !dbg !4575, !tbaa !4576
  br label %process_slabs_automove_command.exit, !dbg !4577

if.else.i:                                        ; preds = %set_noreply_maybe.exit.i
  %call9.i = call zeroext i1 @safe_strtoul(ptr noundef %8, ptr noundef nonnull %level.i) #13, !dbg !4578
  br i1 %call9.i, label %if.end11.i, label %process_slabs_automove_command.exit, !dbg !4581

if.end11.i:                                       ; preds = %if.else.i
  %11 = load i32, ptr %level.i, align 4, !dbg !4582, !tbaa !1231
  switch i32 %11, label %process_slabs_automove_command.exit [
    i32 0, label %if.then13.i
    i32 1, label %if.then18.i
    i32 2, label %if.then18.i
  ], !dbg !4584

if.then13.i:                                      ; preds = %if.end11.i
  store i32 0, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 31), align 4, !dbg !4585, !tbaa !4587
  br label %process_slabs_automove_command.exit, !dbg !4588

if.then18.i:                                      ; preds = %if.end11.i, %if.end11.i
  store i32 %11, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 31), align 4, !dbg !4589, !tbaa !4587
  br label %process_slabs_automove_command.exit

process_slabs_automove_command.exit:              ; preds = %if.then.i, %lor.lhs.false.i, %if.end.i, %if.else.i, %if.end11.i, %if.then13.i, %if.then18.i
  %.str.95.sink.i = phi ptr [ @.str.15, %lor.lhs.false.i ], [ @.str.15, %if.then.i ], [ @.str.48, %if.else.i ], [ @.str.15, %if.end11.i ], [ @.str.95, %if.then13.i ], [ @.str.95, %if.then18.i ], [ @.str.95, %if.end.i ]
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull %.str.95.sink.i) #13, !dbg !4487
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %ratio.i) #13, !dbg !4592
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %level.i) #13, !dbg !4592
  br label %if.end34, !dbg !4593

if.else32:                                        ; preds = %land.lhs.true25, %if.else
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !4594
  br label %if.end34

if.end34:                                         ; preds = %process_slabs_automove_command.exit, %if.else32, %cleanup
  ret void, !dbg !4596
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_memlimit_command(ptr noundef %c, ptr nocapture noundef readonly %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !4597 {
entry:
  %memlimit = alloca i32, align 4, !DIAssignID !4603
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4602, metadata !DIExpression(), metadata !4603, metadata ptr %memlimit, metadata !DIExpression()), !dbg !4604
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4599, metadata !DIExpression()), !dbg !4604
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4600, metadata !DIExpression()), !dbg !4604
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4601, metadata !DIExpression()), !dbg !4604
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %memlimit) #13, !dbg !4605
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4139, metadata !DIExpression()), !dbg !4606
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4144, metadata !DIExpression()), !dbg !4606
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4145, metadata !DIExpression()), !dbg !4606
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4146, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_minus, DW_OP_stack_value)), !dbg !4606
  %conv.i = shl i64 %ntokens, 32, !dbg !4608
  %sext.i = add i64 %conv.i, -8589934592, !dbg !4608
  %idxprom.i = ashr exact i64 %sext.i, 32, !dbg !4608
  %arrayidx.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %idxprom.i, !dbg !4608
  %0 = load ptr, ptr %arrayidx.i, align 8, !dbg !4609, !tbaa !1573
  %tobool.not.i = icmp eq ptr %0, null, !dbg !4608
  br i1 %tobool.not.i, label %set_noreply_maybe.exit, label %land.lhs.true.i, !dbg !4610

land.lhs.true.i:                                  ; preds = %entry
  %call.i = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(8) @.str.82) #15, !dbg !4611
  %cmp.i = icmp eq i32 %call.i, 0, !dbg !4612
  br i1 %cmp.i, label %if.then.i, label %set_noreply_maybe.exit, !dbg !4613

if.then.i:                                        ; preds = %land.lhs.true.i
  %noreply.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !4614
  store i8 1, ptr %noreply.i, align 4, !dbg !4615, !tbaa !1302
  br label %set_noreply_maybe.exit, !dbg !4616

set_noreply_maybe.exit:                           ; preds = %entry, %land.lhs.true.i, %if.then.i
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !4617
  %1 = load ptr, ptr %arrayidx, align 8, !dbg !4619, !tbaa !1573
  %call1 = call zeroext i1 @safe_strtoul(ptr noundef %1, ptr noundef nonnull %memlimit) #13, !dbg !4620
  br i1 %call1, label %if.else, label %if.end19, !dbg !4621

if.else:                                          ; preds = %set_noreply_maybe.exit
  %2 = load i32, ptr %memlimit, align 4, !dbg !4622, !tbaa !1231
  %cmp = icmp ult i32 %2, 8, !dbg !4625
  br i1 %cmp, label %if.end19, label %if.else3, !dbg !4626

if.else3:                                         ; preds = %if.else
  %cmp4 = icmp ugt i32 %2, 1000000000, !dbg !4627
  br i1 %cmp4, label %if.end19, label %if.else6, !dbg !4630

if.else6:                                         ; preds = %if.else3
  %conv = zext nneg i32 %2 to i64, !dbg !4631
  %mul7 = shl nuw nsw i64 %conv, 20, !dbg !4633
  %call8 = call zeroext i1 @slabs_adjust_mem_limit(i64 noundef %mul7) #13, !dbg !4634
  br i1 %call8, label %if.then9, label %if.end19, !dbg !4635

if.then9:                                         ; preds = %if.else6
  %3 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !4636, !tbaa !1858
  %cmp10 = icmp sgt i32 %3, 0, !dbg !4639
  br i1 %cmp10, label %if.then12, label %if.end19, !dbg !4640

if.then12:                                        ; preds = %if.then9
  %4 = load ptr, ptr @stderr, align 8, !dbg !4641, !tbaa !1271
  %5 = load i32, ptr %memlimit, align 4, !dbg !4643, !tbaa !1231
  %conv13 = zext i32 %5 to i64, !dbg !4644
  %call14 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %4, ptr noundef nonnull @.str.112, i64 noundef %conv13) #17, !dbg !4645
  br label %if.end19, !dbg !4646

if.end19:                                         ; preds = %if.else6, %if.then9, %if.then12, %if.else3, %if.else, %set_noreply_maybe.exit
  %.str.110.sink = phi ptr [ @.str.15, %set_noreply_maybe.exit ], [ @.str.110, %if.else ], [ @.str.111, %if.else3 ], [ @.str.95, %if.then12 ], [ @.str.95, %if.then9 ], [ @.str.113, %if.else6 ]
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull %.str.110.sink) #13, !dbg !4647
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %memlimit) #13, !dbg !4648
  ret void, !dbg !4648
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_arithmetic_command(ptr noundef %c, ptr nocapture noundef readonly %tokens, i64 noundef %ntokens, i1 noundef zeroext %incr) unnamed_addr #0 !dbg !4649 {
entry:
  %temp = alloca [24 x i8], align 16, !DIAssignID !4662
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4658, metadata !DIExpression(), metadata !4662, metadata ptr %temp, metadata !DIExpression()), !dbg !4663
  %delta = alloca i64, align 8, !DIAssignID !4664
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4659, metadata !DIExpression(), metadata !4664, metadata ptr %delta, metadata !DIExpression()), !dbg !4663
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4654, metadata !DIExpression()), !dbg !4663
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4655, metadata !DIExpression()), !dbg !4663
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4656, metadata !DIExpression()), !dbg !4663
  tail call void @llvm.dbg.value(metadata i1 %incr, metadata !4657, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4663
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %temp) #13, !dbg !4665
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %delta) #13, !dbg !4666
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4139, metadata !DIExpression()), !dbg !4667
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4144, metadata !DIExpression()), !dbg !4667
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4145, metadata !DIExpression()), !dbg !4667
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4146, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_minus, DW_OP_stack_value)), !dbg !4667
  %conv.i = shl i64 %ntokens, 32, !dbg !4669
  %sext.i = add i64 %conv.i, -8589934592, !dbg !4669
  %idxprom.i = ashr exact i64 %sext.i, 32, !dbg !4669
  %arrayidx.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %idxprom.i, !dbg !4669
  %0 = load ptr, ptr %arrayidx.i, align 8, !dbg !4670, !tbaa !1573
  %tobool.not.i = icmp eq ptr %0, null, !dbg !4669
  br i1 %tobool.not.i, label %set_noreply_maybe.exit, label %land.lhs.true.i, !dbg !4671

land.lhs.true.i:                                  ; preds = %entry
  %call.i = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(8) @.str.82) #15, !dbg !4672
  %cmp.i = icmp eq i32 %call.i, 0, !dbg !4673
  br i1 %cmp.i, label %if.then.i, label %set_noreply_maybe.exit, !dbg !4674

if.then.i:                                        ; preds = %land.lhs.true.i
  %noreply.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !4675
  store i8 1, ptr %noreply.i, align 4, !dbg !4676, !tbaa !1302
  br label %set_noreply_maybe.exit, !dbg !4677

set_noreply_maybe.exit:                           ; preds = %entry, %land.lhs.true.i, %if.then.i
  %length = getelementptr inbounds i8, ptr %tokens, i64 24, !dbg !4678
  %1 = load i64, ptr %length, align 8, !dbg !4678, !tbaa !1578
  %cmp = icmp ugt i64 %1, 250, !dbg !4680
  br i1 %cmp, label %if.then, label %if.end, !dbg !4681

if.then:                                          ; preds = %set_noreply_maybe.exit
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.48) #13, !dbg !4682
  br label %cleanup, !dbg !4684

if.end:                                           ; preds = %set_noreply_maybe.exit
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !4685
  %2 = load ptr, ptr %arrayidx, align 8, !dbg !4686, !tbaa !1573
  tail call void @llvm.dbg.value(metadata ptr %2, metadata !4660, metadata !DIExpression()), !dbg !4663
  tail call void @llvm.dbg.value(metadata i64 %1, metadata !4661, metadata !DIExpression()), !dbg !4663
  %arrayidx4 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !4687
  %3 = load ptr, ptr %arrayidx4, align 8, !dbg !4689, !tbaa !1573
  %call6 = call zeroext i1 @safe_strtoull(ptr noundef %3, ptr noundef nonnull %delta) #13, !dbg !4690
  br i1 %call6, label %if.end8, label %if.then7, !dbg !4691

if.then7:                                         ; preds = %if.end
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.114) #13, !dbg !4692
  br label %cleanup, !dbg !4694

if.end8:                                          ; preds = %if.end
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !4695
  %4 = load ptr, ptr %thread, align 8, !dbg !4695, !tbaa !1234
  %5 = load i64, ptr %delta, align 8, !dbg !4696, !tbaa !1308
  %call9 = call i32 @add_delta(ptr noundef %4, ptr noundef %2, i64 noundef %1, i1 noundef zeroext %incr, i64 noundef %5, ptr noundef nonnull %temp, ptr noundef null) #13, !dbg !4697
  switch i32 %call9, label %cleanup [
    i32 0, label %sw.bb
    i32 1, label %sw.bb11
    i32 2, label %sw.bb12
    i32 3, label %sw.bb13
  ], !dbg !4698

sw.bb:                                            ; preds = %if.end8
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull %temp) #13, !dbg !4699
  br label %cleanup, !dbg !4701

sw.bb11:                                          ; preds = %if.end8
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.68) #13, !dbg !4702
  br label %cleanup, !dbg !4703

sw.bb12:                                          ; preds = %if.end8
  call void @out_of_memory(ptr noundef nonnull %c, ptr noundef nonnull @.str.66) #13, !dbg !4704
  br label %cleanup, !dbg !4705

sw.bb13:                                          ; preds = %if.end8
  %6 = load ptr, ptr %thread, align 8, !dbg !4706, !tbaa !1234
  %stats = getelementptr inbounds i8, ptr %6, i64 352, !dbg !4707
  %call15 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #13, !dbg !4708
  %7 = load ptr, ptr %thread, align 8, !dbg !4709, !tbaa !1234
  %. = select i1 %incr, i64 448, i64 456
  %decr_misses = getelementptr inbounds i8, ptr %7, i64 %., !dbg !4709
  %8 = load i64, ptr %decr_misses, align 8, !dbg !4709, !tbaa !1308
  %inc22 = add i64 %8, 1, !dbg !4709
  store i64 %inc22, ptr %decr_misses, align 8, !dbg !4709, !tbaa !1308
  %stats25 = getelementptr inbounds i8, ptr %7, i64 352, !dbg !4711
  %call27 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats25) #13, !dbg !4712
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.4) #13, !dbg !4713
  br label %cleanup, !dbg !4714

cleanup:                                          ; preds = %sw.bb, %sw.bb11, %sw.bb12, %sw.bb13, %if.end8, %if.then7, %if.then
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %delta) #13, !dbg !4715
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %temp) #13, !dbg !4715
  ret void, !dbg !4715
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_delete_command(ptr noundef %c, ptr nocapture noundef readonly %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !4716 {
entry:
  %hv = alloca i32, align 4, !DIAssignID !4734
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4724, metadata !DIExpression(), metadata !4734, metadata ptr %hv, metadata !DIExpression()), !dbg !4735
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4718, metadata !DIExpression()), !dbg !4735
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4719, metadata !DIExpression()), !dbg !4735
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4720, metadata !DIExpression()), !dbg !4735
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %hv) #13, !dbg !4736
  %cmp = icmp ugt i64 %ntokens, 3, !dbg !4737
  br i1 %cmp, label %if.then, label %if.end15, !dbg !4738

if.then:                                          ; preds = %entry
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !4739
  %0 = load ptr, ptr %arrayidx, align 8, !dbg !4740, !tbaa !1573
  %1 = load i8, ptr %0, align 1
  %.not = icmp eq i8 %1, 48
  br i1 %.not, label %sub_1, label %if.then.tail

sub_1:                                            ; preds = %if.then
  %2 = getelementptr inbounds i8, ptr %0, i64 1
  %3 = load i8, ptr %2, align 1
  %4 = icmp eq i8 %3, 0, !dbg !4741
  br label %if.then.tail

if.then.tail:                                     ; preds = %if.then, %sub_1
  %cmp1 = phi i1 [ false, %if.then ], [ %4, %sub_1 ]
  tail call void @llvm.dbg.value(metadata i1 %cmp1, metadata !4725, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4742
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4139, metadata !DIExpression()), !dbg !4743
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4144, metadata !DIExpression()), !dbg !4743
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4145, metadata !DIExpression()), !dbg !4743
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4146, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_minus, DW_OP_stack_value)), !dbg !4743
  %conv.i = shl i64 %ntokens, 32, !dbg !4745
  %sext.i = add i64 %conv.i, -8589934592, !dbg !4745
  %idxprom.i = ashr exact i64 %sext.i, 32, !dbg !4745
  %arrayidx.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %idxprom.i, !dbg !4745
  %5 = load ptr, ptr %arrayidx.i, align 8, !dbg !4746, !tbaa !1573
  %tobool.not.i = icmp eq ptr %5, null, !dbg !4745
  br i1 %tobool.not.i, label %set_noreply_maybe.exit, label %land.lhs.true.i, !dbg !4747

land.lhs.true.i:                                  ; preds = %if.then.tail
  %call.i = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %5, ptr noundef nonnull dereferenceable(8) @.str.82) #15, !dbg !4748
  %cmp.i = icmp eq i32 %call.i, 0, !dbg !4749
  br i1 %cmp.i, label %if.then.i, label %set_noreply_maybe.exit, !dbg !4750

if.then.i:                                        ; preds = %land.lhs.true.i
  %noreply.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !4751
  store i8 1, ptr %noreply.i, align 4, !dbg !4752, !tbaa !1302
  br label %set_noreply_maybe.exit, !dbg !4753

set_noreply_maybe.exit:                           ; preds = %if.then.tail, %land.lhs.true.i, %if.then.i
  %noreply5.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !4754
  %6 = load i8, ptr %noreply5.i, align 4, !dbg !4754, !tbaa !1302, !range !1296, !noundef !1297
  %tobool6.i = trunc nuw i8 %6 to i1, !dbg !4754
  tail call void @llvm.dbg.value(metadata i1 %tobool6.i, metadata !4728, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4742
  switch i64 %ntokens, label %if.then12 [
    i64 4, label %land.lhs.true
    i64 5, label %land.lhs.true7
  ], !dbg !4755

land.lhs.true:                                    ; preds = %set_noreply_maybe.exit
  %brmerge = select i1 %cmp1, i1 true, i1 %tobool6.i, !dbg !4756
  br i1 %brmerge, label %if.end15, label %if.then12, !dbg !4756

land.lhs.true7:                                   ; preds = %set_noreply_maybe.exit
  %spec.select.old = select i1 %cmp1, i1 %tobool6.i, i1 false, !dbg !4757
  tail call void @llvm.dbg.value(metadata i1 %spec.select.old, metadata !4729, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4742
  br i1 %spec.select.old, label %if.end15, label %if.then12, !dbg !4758

if.then12:                                        ; preds = %land.lhs.true, %set_noreply_maybe.exit, %land.lhs.true7
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.116) #13, !dbg !4759
  br label %cleanup60

if.end15:                                         ; preds = %land.lhs.true, %land.lhs.true7, %entry
  %arrayidx16 = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !4762
  %7 = load ptr, ptr %arrayidx16, align 8, !dbg !4763, !tbaa !1573
  tail call void @llvm.dbg.value(metadata ptr %7, metadata !4721, metadata !DIExpression()), !dbg !4735
  %length = getelementptr inbounds i8, ptr %tokens, i64 24, !dbg !4764
  %8 = load i64, ptr %length, align 8, !dbg !4764, !tbaa !1578
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !4722, metadata !DIExpression()), !dbg !4735
  %cmp19 = icmp ugt i64 %8, 250, !dbg !4765
  br i1 %cmp19, label %if.then20, label %if.end21, !dbg !4767

if.then20:                                        ; preds = %if.end15
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.48) #13, !dbg !4768
  br label %cleanup60, !dbg !4770

if.end21:                                         ; preds = %if.end15
  %9 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 16), align 8, !dbg !4771, !tbaa !3845
  %tobool22.not = icmp eq i32 %9, 0, !dbg !4773
  br i1 %tobool22.not, label %if.end24, label %if.then23, !dbg !4774

if.then23:                                        ; preds = %if.end21
  tail call void @stats_prefix_record_delete(ptr noundef %7, i64 noundef %8) #13, !dbg !4775
  br label %if.end24, !dbg !4777

if.end24:                                         ; preds = %if.then23, %if.end21
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !4778
  %10 = load ptr, ptr %thread, align 8, !dbg !4778, !tbaa !1234
  %call25 = call ptr @item_get_locked(ptr noundef %7, i64 noundef %8, ptr noundef %10, i1 noundef zeroext false, ptr noundef nonnull %hv) #13, !dbg !4779
  tail call void @llvm.dbg.value(metadata ptr %call25, metadata !4723, metadata !DIExpression()), !dbg !4735
  %tobool26.not = icmp eq ptr %call25, null, !dbg !4780
  %11 = load ptr, ptr %thread, align 8, !dbg !4781, !tbaa !1234
  %stats49 = getelementptr inbounds i8, ptr %11, i64 352, !dbg !4781
  %call51 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats49) #13, !dbg !4781
  %12 = load ptr, ptr %thread, align 8, !dbg !4781, !tbaa !1234
  br i1 %tobool26.not, label %if.else, label %if.then27, !dbg !4782

if.then27:                                        ; preds = %if.end24
  %slab_stats = getelementptr inbounds i8, ptr %12, i64 632, !dbg !4783
  %slabs_clsid = getelementptr inbounds i8, ptr %call25, i64 40, !dbg !4784
  %13 = load i8, ptr %slabs_clsid, align 8, !dbg !4784, !tbaa !1240
  %14 = and i8 %13, 63, !dbg !4784
  %idxprom = zext nneg i8 %14 to i64
  %delete_hits = getelementptr inbounds [64 x %struct.slab_stats], ptr %slab_stats, i64 0, i64 %idxprom, i32 3, !dbg !4785
  %15 = load i64, ptr %delete_hits, align 8, !dbg !4786, !tbaa !3260
  %inc = add i64 %15, 1, !dbg !4786
  store i64 %inc, ptr %delete_hits, align 8, !dbg !4786, !tbaa !3260
  %stats34 = getelementptr inbounds i8, ptr %12, i64 352, !dbg !4787
  %call36 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats34) #13, !dbg !4788
  tail call void @llvm.dbg.value(metadata ptr null, metadata !4730, metadata !DIExpression()), !dbg !4789
  %16 = load i32, ptr @logger_key, align 4, !dbg !4790, !tbaa !1231
  %call37 = call ptr @pthread_getspecific(i32 noundef %16) #13, !dbg !4790
  tail call void @llvm.dbg.value(metadata ptr %call37, metadata !4730, metadata !DIExpression()), !dbg !4789
  %eflags = getelementptr inbounds i8, ptr %call37, i64 84, !dbg !4792
  %17 = load i16, ptr %eflags, align 4, !dbg !4792, !tbaa !3003
  %18 = and i16 %17, 8192, !dbg !4792
  %tobool40.not = icmp eq i16 %18, 0, !dbg !4792
  br i1 %tobool40.not, label %if.end43, label %if.then41, !dbg !4794

if.then41:                                        ; preds = %if.then27
  %call42 = call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %call37, i32 noundef 8, ptr noundef nonnull %call25, i32 noundef 1) #13, !dbg !4792
  br label %if.end43, !dbg !4792

if.end43:                                         ; preds = %if.then41, %if.then27
  %19 = load i32, ptr %hv, align 4, !dbg !4795, !tbaa !1231
  call void @do_item_unlink(ptr noundef nonnull %call25, i32 noundef %19) #13, !dbg !4796
  %20 = load ptr, ptr %thread, align 8, !dbg !4797, !tbaa !1234
  %storage = getelementptr inbounds i8, ptr %20, i64 6904, !dbg !4797
  %21 = load ptr, ptr %storage, align 8, !dbg !4797, !tbaa !3015
  call void @storage_delete(ptr noundef %21, ptr noundef nonnull %call25) #13, !dbg !4797
  call void @do_item_remove(ptr noundef nonnull %call25) #13, !dbg !4799
  br label %if.end59, !dbg !4800

if.else:                                          ; preds = %if.end24
  %delete_misses = getelementptr inbounds i8, ptr %12, i64 440, !dbg !4801
  %22 = load i64, ptr %delete_misses, align 8, !dbg !4803, !tbaa !3195
  %inc54 = add i64 %22, 1, !dbg !4803
  store i64 %inc54, ptr %delete_misses, align 8, !dbg !4803, !tbaa !3195
  %stats56 = getelementptr inbounds i8, ptr %12, i64 352, !dbg !4804
  %call58 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats56) #13, !dbg !4805
  br label %if.end59

if.end59:                                         ; preds = %if.else, %if.end43
  %.str.4.sink = phi ptr [ @.str.4, %if.else ], [ @.str.117, %if.end43 ]
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull %.str.4.sink) #13, !dbg !4781
  %23 = load i32, ptr %hv, align 4, !dbg !4806, !tbaa !1231
  call void @item_unlock(i32 noundef %23) #13, !dbg !4807
  br label %cleanup60, !dbg !4808

cleanup60:                                        ; preds = %if.then12, %if.end59, %if.then20
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %hv) #13, !dbg !4808
  ret void, !dbg !4808
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_touch_command(ptr noundef %c, ptr nocapture noundef readonly %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !4809 {
entry:
  %exptime_int = alloca i32, align 4, !DIAssignID !4819
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4816, metadata !DIExpression(), metadata !4819, metadata ptr %exptime_int, metadata !DIExpression()), !dbg !4820
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4811, metadata !DIExpression()), !dbg !4820
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4812, metadata !DIExpression()), !dbg !4820
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4813, metadata !DIExpression()), !dbg !4820
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %exptime_int) #13, !dbg !4821
  store i32 0, ptr %exptime_int, align 4, !dbg !4822, !tbaa !1231, !DIAssignID !4823
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !4816, metadata !DIExpression(), metadata !4823, metadata ptr %exptime_int, metadata !DIExpression()), !dbg !4820
  tail call void @llvm.dbg.value(metadata i32 0, metadata !4817, metadata !DIExpression()), !dbg !4820
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4139, metadata !DIExpression()), !dbg !4824
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4144, metadata !DIExpression()), !dbg !4824
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4145, metadata !DIExpression()), !dbg !4824
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4146, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_minus, DW_OP_stack_value)), !dbg !4824
  %conv.i = shl i64 %ntokens, 32, !dbg !4826
  %sext.i = add i64 %conv.i, -8589934592, !dbg !4826
  %idxprom.i = ashr exact i64 %sext.i, 32, !dbg !4826
  %arrayidx.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %idxprom.i, !dbg !4826
  %0 = load ptr, ptr %arrayidx.i, align 8, !dbg !4827, !tbaa !1573
  %tobool.not.i = icmp eq ptr %0, null, !dbg !4826
  br i1 %tobool.not.i, label %set_noreply_maybe.exit, label %land.lhs.true.i, !dbg !4828

land.lhs.true.i:                                  ; preds = %entry
  %call.i = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(8) @.str.82) #15, !dbg !4829
  %cmp.i = icmp eq i32 %call.i, 0, !dbg !4830
  br i1 %cmp.i, label %if.then.i, label %set_noreply_maybe.exit, !dbg !4831

if.then.i:                                        ; preds = %land.lhs.true.i
  %noreply.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !4832
  store i8 1, ptr %noreply.i, align 4, !dbg !4833, !tbaa !1302
  br label %set_noreply_maybe.exit, !dbg !4834

set_noreply_maybe.exit:                           ; preds = %entry, %land.lhs.true.i, %if.then.i
  %length = getelementptr inbounds i8, ptr %tokens, i64 24, !dbg !4835
  %1 = load i64, ptr %length, align 8, !dbg !4835, !tbaa !1578
  %cmp = icmp ugt i64 %1, 250, !dbg !4837
  br i1 %cmp, label %if.then, label %if.end, !dbg !4838

if.then:                                          ; preds = %set_noreply_maybe.exit
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.48) #13, !dbg !4839
  br label %cleanup, !dbg !4841

if.end:                                           ; preds = %set_noreply_maybe.exit
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !4842
  %2 = load ptr, ptr %arrayidx, align 8, !dbg !4843, !tbaa !1573
  tail call void @llvm.dbg.value(metadata ptr %2, metadata !4814, metadata !DIExpression()), !dbg !4820
  tail call void @llvm.dbg.value(metadata i64 %1, metadata !4815, metadata !DIExpression()), !dbg !4820
  %arrayidx4 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !4844
  %3 = load ptr, ptr %arrayidx4, align 8, !dbg !4846, !tbaa !1573
  %call6 = call zeroext i1 @safe_strtol(ptr noundef %3, ptr noundef nonnull %exptime_int) #13, !dbg !4847
  br i1 %call6, label %if.end8, label %if.then7, !dbg !4848

if.then7:                                         ; preds = %if.end
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.74) #13, !dbg !4849
  br label %cleanup, !dbg !4851

if.end8:                                          ; preds = %if.end
  %4 = load i32, ptr %exptime_int, align 4, !dbg !4852, !tbaa !1231
  %cmp9 = icmp slt i32 %4, 0, !dbg !4852
  %narrow = select i1 %cmp9, i32 2592001, i32 %4, !dbg !4852
  %spec.select = zext i32 %narrow to i64, !dbg !4852
  %call10 = call i32 @realtime(i64 noundef %spec.select) #13, !dbg !4853
  tail call void @llvm.dbg.value(metadata i32 %call10, metadata !4817, metadata !DIExpression()), !dbg !4820
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !4854
  %5 = load ptr, ptr %thread, align 8, !dbg !4854, !tbaa !1234
  %call11 = call ptr @item_touch(ptr noundef %2, i64 noundef %1, i32 noundef %call10, ptr noundef %5) #13, !dbg !4855
  tail call void @llvm.dbg.value(metadata ptr %call11, metadata !4818, metadata !DIExpression()), !dbg !4820
  %tobool.not = icmp eq ptr %call11, null, !dbg !4856
  %6 = load ptr, ptr %thread, align 8, !dbg !4858, !tbaa !1234
  %stats27 = getelementptr inbounds i8, ptr %6, i64 352, !dbg !4858
  %call29 = call i32 @pthread_mutex_lock(ptr noundef nonnull %stats27) #13, !dbg !4858
  %7 = load ptr, ptr %thread, align 8, !dbg !4858, !tbaa !1234
  %touch_cmds32 = getelementptr inbounds i8, ptr %7, i64 424, !dbg !4858
  %8 = load i64, ptr %touch_cmds32, align 8, !dbg !4858, !tbaa !2732
  %inc33 = add i64 %8, 1, !dbg !4858
  store i64 %inc33, ptr %touch_cmds32, align 8, !dbg !4858, !tbaa !2732
  br i1 %tobool.not, label %if.else, label %if.then12, !dbg !4859

if.then12:                                        ; preds = %if.end8
  %slab_stats = getelementptr inbounds i8, ptr %7, i64 632, !dbg !4860
  %slabs_clsid = getelementptr inbounds i8, ptr %call11, i64 40, !dbg !4862
  %9 = load i8, ptr %slabs_clsid, align 8, !dbg !4862, !tbaa !1240
  %10 = and i8 %9, 63, !dbg !4862
  %idxprom = zext nneg i8 %10 to i64
  %touch_hits = getelementptr inbounds [64 x %struct.slab_stats], ptr %slab_stats, i64 0, i64 %idxprom, i32 2, !dbg !4863
  %11 = load i64, ptr %touch_hits, align 8, !dbg !4864, !tbaa !4865
  %inc21 = add i64 %11, 1, !dbg !4864
  store i64 %inc21, ptr %touch_hits, align 8, !dbg !4864, !tbaa !4865
  %stats23 = getelementptr inbounds i8, ptr %7, i64 352, !dbg !4866
  %call25 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats23) #13, !dbg !4867
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.118) #13, !dbg !4868
  call void @item_remove(ptr noundef nonnull %call11) #13, !dbg !4869
  br label %cleanup, !dbg !4870

if.else:                                          ; preds = %if.end8
  %touch_misses = getelementptr inbounds i8, ptr %7, i64 432, !dbg !4871
  %12 = load i64, ptr %touch_misses, align 8, !dbg !4873, !tbaa !4874
  %inc36 = add i64 %12, 1, !dbg !4873
  store i64 %inc36, ptr %touch_misses, align 8, !dbg !4873, !tbaa !4874
  %stats38 = getelementptr inbounds i8, ptr %7, i64 352, !dbg !4875
  %call40 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats38) #13, !dbg !4876
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.4) #13, !dbg !4877
  br label %cleanup

cleanup:                                          ; preds = %if.then12, %if.else, %if.then7, %if.then
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %exptime_int) #13, !dbg !4878
  ret void, !dbg !4878
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_flush_all_command(ptr noundef %c, ptr nocapture noundef readonly %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !4879 {
entry:
  %exptime = alloca i32, align 4, !DIAssignID !4886
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4884, metadata !DIExpression(), metadata !4886, metadata ptr %exptime, metadata !DIExpression()), !dbg !4887
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4881, metadata !DIExpression()), !dbg !4887
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4882, metadata !DIExpression()), !dbg !4887
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4883, metadata !DIExpression()), !dbg !4887
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %exptime) #13, !dbg !4888
  store i32 0, ptr %exptime, align 4, !dbg !4889, !tbaa !1231, !DIAssignID !4890
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !4884, metadata !DIExpression(), metadata !4890, metadata ptr %exptime, metadata !DIExpression()), !dbg !4887
  tail call void @llvm.dbg.value(metadata i32 0, metadata !4885, metadata !DIExpression()), !dbg !4887
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4139, metadata !DIExpression()), !dbg !4891
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4144, metadata !DIExpression()), !dbg !4891
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4145, metadata !DIExpression()), !dbg !4891
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4146, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_minus, DW_OP_stack_value)), !dbg !4891
  %conv.i = shl i64 %ntokens, 32, !dbg !4893
  %sext.i = add i64 %conv.i, -8589934592, !dbg !4893
  %idxprom.i = ashr exact i64 %sext.i, 32, !dbg !4893
  %arrayidx.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %idxprom.i, !dbg !4893
  %0 = load ptr, ptr %arrayidx.i, align 8, !dbg !4894, !tbaa !1573
  %tobool.not.i = icmp eq ptr %0, null, !dbg !4893
  br i1 %tobool.not.i, label %set_noreply_maybe.exit, label %land.lhs.true.i, !dbg !4895

land.lhs.true.i:                                  ; preds = %entry
  %call.i = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(8) @.str.82) #15, !dbg !4896
  %cmp.i = icmp eq i32 %call.i, 0, !dbg !4897
  br i1 %cmp.i, label %if.then.i, label %set_noreply_maybe.exit, !dbg !4898

if.then.i:                                        ; preds = %land.lhs.true.i
  %noreply.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !4899
  store i8 1, ptr %noreply.i, align 4, !dbg !4900, !tbaa !1302
  br label %set_noreply_maybe.exit, !dbg !4901

set_noreply_maybe.exit:                           ; preds = %entry, %land.lhs.true.i, %if.then.i
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !4902
  %1 = load ptr, ptr %thread, align 8, !dbg !4902, !tbaa !1234
  %stats = getelementptr inbounds i8, ptr %1, i64 352, !dbg !4903
  %call1 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #13, !dbg !4904
  %2 = load ptr, ptr %thread, align 8, !dbg !4905, !tbaa !1234
  %flush_cmds = getelementptr inbounds i8, ptr %2, i64 496, !dbg !4906
  %3 = load i64, ptr %flush_cmds, align 8, !dbg !4907, !tbaa !4908
  %inc = add i64 %3, 1, !dbg !4907
  store i64 %inc, ptr %flush_cmds, align 8, !dbg !4907, !tbaa !4908
  %stats5 = getelementptr inbounds i8, ptr %2, i64 352, !dbg !4909
  %call7 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats5) #13, !dbg !4910
  %4 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 37), align 8, !dbg !4911, !tbaa !4913, !range !1296, !noundef !1297
  %tobool = trunc nuw i8 %4 to i1, !dbg !4911
  br i1 %tobool, label %if.end, label %if.then, !dbg !4914

if.then:                                          ; preds = %set_noreply_maybe.exit
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.119) #13, !dbg !4915
  br label %cleanup, !dbg !4917

if.end:                                           ; preds = %set_noreply_maybe.exit
  %noreply5.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !4918
  %5 = load i8, ptr %noreply5.i, align 4, !dbg !4919, !tbaa !1302, !range !1296, !noundef !1297
  %tobool8 = trunc nuw i8 %5 to i1, !dbg !4919
  %conv = select i1 %tobool8, i64 3, i64 2, !dbg !4921
  %cmp.not = icmp eq i64 %conv, %ntokens, !dbg !4922
  br i1 %cmp.not, label %if.else, label %if.then10, !dbg !4923

if.then10:                                        ; preds = %if.end
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !4924
  %6 = load ptr, ptr %arrayidx, align 8, !dbg !4927, !tbaa !1573
  %call11 = call zeroext i1 @safe_strtol(ptr noundef %6, ptr noundef nonnull %exptime) #13, !dbg !4928
  br i1 %call11, label %if.end14, label %if.then12, !dbg !4929

if.then12:                                        ; preds = %if.then10
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.74) #13, !dbg !4930
  br label %cleanup, !dbg !4932

if.end14:                                         ; preds = %if.then10
  %.pre = load i32, ptr %exptime, align 4, !dbg !4933, !tbaa !1231
  %cmp15 = icmp sgt i32 %.pre, 0, !dbg !4935
  br i1 %cmp15, label %if.then17, label %if.else, !dbg !4936

if.then17:                                        ; preds = %if.end14
  %conv18 = zext nneg i32 %.pre to i64
  %call19 = call i32 @realtime(i64 noundef %conv18) #13, !dbg !4937
  tail call void @llvm.dbg.value(metadata i32 %call19, metadata !4885, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !4887
  br label %if.end21, !dbg !4939

if.else:                                          ; preds = %if.end, %if.end14
  %7 = load volatile i32, ptr @current_time, align 4, !dbg !4940, !tbaa !1231
  tail call void @llvm.dbg.value(metadata i32 %7, metadata !4885, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !4887
  br label %if.end21

if.end21:                                         ; preds = %if.else, %if.then17
  %new_oldest.0.in = phi i32 [ %call19, %if.then17 ], [ %7, %if.else ]
  %new_oldest.0 = add i32 %new_oldest.0.in, -1, !dbg !4942
  tail call void @llvm.dbg.value(metadata i32 %new_oldest.0, metadata !4885, metadata !DIExpression()), !dbg !4887
  store i32 %new_oldest.0, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 6), align 4, !dbg !4943, !tbaa !4944
  call void @item_flush_expired() #13, !dbg !4945
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.95) #13, !dbg !4946
  br label %cleanup, !dbg !4947

cleanup:                                          ; preds = %if.end21, %if.then12, %if.then
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %exptime) #13, !dbg !4947
  ret void, !dbg !4947
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_lru_crawler_command(ptr noundef %c, ptr nocapture noundef readonly %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !4948 {
entry:
  %tocrawl = alloca i32, align 4, !DIAssignID !4968
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4962, metadata !DIExpression(), metadata !4968, metadata ptr %tocrawl, metadata !DIExpression()), !dbg !4969
  %tosleep = alloca i32, align 4, !DIAssignID !4970
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !4965, metadata !DIExpression(), metadata !4970, metadata ptr %tosleep, metadata !DIExpression()), !dbg !4971
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4950, metadata !DIExpression()), !dbg !4972
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4951, metadata !DIExpression()), !dbg !4972
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4952, metadata !DIExpression()), !dbg !4972
  switch i64 %ntokens, label %if.else149 [
    i64 4, label %land.lhs.true
    i64 3, label %if.then120
  ], !dbg !4973

land.lhs.true:                                    ; preds = %entry
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !4974
  %0 = load ptr, ptr %arrayidx, align 8, !dbg !4975, !tbaa !1573
  %call = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(6) @.str.121) #15, !dbg !4976
  %cmp1 = icmp eq i32 %call, 0, !dbg !4977
  br i1 %cmp1, label %if.then, label %land.lhs.true14, !dbg !4978

if.then:                                          ; preds = %land.lhs.true
  %1 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 27), align 2, !dbg !4979, !tbaa !4981, !range !1296, !noundef !1297
  %cmp2 = icmp eq i8 %1, 0, !dbg !4982
  br i1 %cmp2, label %if.then4, label %if.end, !dbg !4983

if.then4:                                         ; preds = %if.then
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.122) #13, !dbg !4984
  br label %if.end155, !dbg !4986

if.end:                                           ; preds = %if.then
  %arrayidx5 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !4987
  %2 = load ptr, ptr %arrayidx5, align 8, !dbg !4988, !tbaa !1573
  %3 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 41), align 4, !dbg !4989, !tbaa !4990
  %call7 = tail call i32 @lru_crawler_crawl(ptr noundef %2, i32 noundef 1, ptr noundef null, i32 noundef 0, i32 noundef %3) #13, !dbg !4991
  tail call void @llvm.dbg.value(metadata i32 %call7, metadata !4953, metadata !DIExpression()), !dbg !4992
  switch i32 %call7, label %if.end155 [
    i32 0, label %sw.bb
    i32 1, label %sw.bb8
    i32 2, label %sw.bb9
    i32 3, label %sw.bb10
    i32 4, label %sw.bb11
  ], !dbg !4993

sw.bb:                                            ; preds = %if.end
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.95) #13, !dbg !4994
  br label %if.end155, !dbg !4996

sw.bb8:                                           ; preds = %if.end
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.123) #13, !dbg !4997
  br label %if.end155, !dbg !4998

sw.bb9:                                           ; preds = %if.end
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.124) #13, !dbg !4999
  br label %if.end155, !dbg !5000

sw.bb10:                                          ; preds = %if.end
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.125) #13, !dbg !5001
  br label %if.end155, !dbg !5002

sw.bb11:                                          ; preds = %if.end
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.126) #13, !dbg !5003
  br label %if.end155, !dbg !5004

land.lhs.true14:                                  ; preds = %land.lhs.true
  %call17 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(9) @.str.127) #15, !dbg !5005
  %cmp18 = icmp eq i32 %call17, 0, !dbg !5006
  br i1 %cmp18, label %if.then20, label %land.lhs.true48, !dbg !5007

if.then20:                                        ; preds = %land.lhs.true14
  %4 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 27), align 2, !dbg !5008, !tbaa !4981, !range !1296, !noundef !1297
  %cmp23 = icmp eq i8 %4, 0, !dbg !5010
  br i1 %cmp23, label %if.then25, label %if.end26, !dbg !5011

if.then25:                                        ; preds = %if.then20
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.122) #13, !dbg !5012
  br label %if.end155, !dbg !5014

if.end26:                                         ; preds = %if.then20
  %5 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 38), align 1, !dbg !5015, !tbaa !4345, !range !1296, !noundef !1297
  %tobool27 = trunc nuw i8 %5 to i1, !dbg !5015
  br i1 %tobool27, label %if.end29, label %if.then28, !dbg !5017

if.then28:                                        ; preds = %if.end26
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.128) #13, !dbg !5018
  br label %if.end155, !dbg !5020

if.end29:                                         ; preds = %if.end26
  %call30 = tail call zeroext i1 @resp_has_stack(ptr noundef %c) #13, !dbg !5021
  br i1 %call30, label %if.then31, label %if.end32, !dbg !5023

if.then31:                                        ; preds = %if.end29
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.129) #13, !dbg !5024
  br label %if.end155, !dbg !5026

if.end32:                                         ; preds = %if.end29
  %arrayidx34 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5027
  %6 = load ptr, ptr %arrayidx34, align 8, !dbg !5028, !tbaa !1573
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !5029
  %7 = load i32, ptr %sfd, align 8, !dbg !5029, !tbaa !1311
  %call36 = tail call i32 @lru_crawler_crawl(ptr noundef %6, i32 noundef 2, ptr noundef %c, i32 noundef %7, i32 noundef -1) #13, !dbg !5030
  tail call void @llvm.dbg.value(metadata i32 %call36, metadata !4956, metadata !DIExpression()), !dbg !5031
  switch i32 %call36, label %if.end155 [
    i32 0, label %sw.bb37
    i32 1, label %sw.bb39
    i32 2, label %sw.bb40
    i32 3, label %sw.bb41
    i32 4, label %sw.bb42
  ], !dbg !5032

sw.bb37:                                          ; preds = %if.end32
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 11) #13, !dbg !5033
  %event = getelementptr inbounds i8, ptr %c, i64 32, !dbg !5035
  %call38 = tail call i32 @event_del(ptr noundef nonnull %event) #13, !dbg !5036
  br label %if.end155, !dbg !5037

sw.bb39:                                          ; preds = %if.end32
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.123) #13, !dbg !5038
  br label %if.end155, !dbg !5039

sw.bb40:                                          ; preds = %if.end32
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.124) #13, !dbg !5040
  br label %if.end155, !dbg !5041

sw.bb41:                                          ; preds = %if.end32
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.125) #13, !dbg !5042
  br label %if.end155, !dbg !5043

sw.bb42:                                          ; preds = %if.end32
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.126) #13, !dbg !5044
  br label %if.end155, !dbg !5045

land.lhs.true48:                                  ; preds = %land.lhs.true14
  %call51 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(7) @.str.130) #15, !dbg !5046
  %cmp52 = icmp eq i32 %call51, 0, !dbg !5047
  br i1 %cmp52, label %if.then54, label %land.lhs.true84, !dbg !5048

if.then54:                                        ; preds = %land.lhs.true48
  %8 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 27), align 2, !dbg !5049, !tbaa !4981, !range !1296, !noundef !1297
  %cmp57 = icmp eq i8 %8, 0, !dbg !5051
  br i1 %cmp57, label %if.then59, label %if.end60, !dbg !5052

if.then59:                                        ; preds = %if.then54
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.122) #13, !dbg !5053
  br label %if.end155, !dbg !5055

if.end60:                                         ; preds = %if.then54
  %9 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 38), align 1, !dbg !5056, !tbaa !4345, !range !1296, !noundef !1297
  %tobool61 = trunc nuw i8 %9 to i1, !dbg !5056
  br i1 %tobool61, label %if.end63, label %if.then62, !dbg !5058

if.then62:                                        ; preds = %if.end60
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.131) #13, !dbg !5059
  br label %if.end155, !dbg !5061

if.end63:                                         ; preds = %if.end60
  %call64 = tail call zeroext i1 @resp_has_stack(ptr noundef %c) #13, !dbg !5062
  br i1 %call64, label %if.then65, label %if.end66, !dbg !5064

if.then65:                                        ; preds = %if.end63
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.132) #13, !dbg !5065
  br label %if.end155, !dbg !5067

if.end66:                                         ; preds = %if.end63
  %arrayidx68 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5068
  %10 = load ptr, ptr %arrayidx68, align 8, !dbg !5069, !tbaa !1573
  %sfd70 = getelementptr inbounds i8, ptr %c, i64 8, !dbg !5070
  %11 = load i32, ptr %sfd70, align 8, !dbg !5070, !tbaa !1311
  %call71 = tail call i32 @lru_crawler_crawl(ptr noundef %10, i32 noundef 3, ptr noundef %c, i32 noundef %11, i32 noundef -1) #13, !dbg !5071
  tail call void @llvm.dbg.value(metadata i32 %call71, metadata !4959, metadata !DIExpression()), !dbg !5072
  switch i32 %call71, label %if.end155 [
    i32 0, label %sw.bb72
    i32 1, label %sw.bb75
    i32 2, label %sw.bb76
    i32 3, label %sw.bb77
    i32 4, label %sw.bb78
  ], !dbg !5073

sw.bb72:                                          ; preds = %if.end66
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 11) #13, !dbg !5074
  %event73 = getelementptr inbounds i8, ptr %c, i64 32, !dbg !5076
  %call74 = tail call i32 @event_del(ptr noundef nonnull %event73) #13, !dbg !5077
  br label %if.end155, !dbg !5078

sw.bb75:                                          ; preds = %if.end66
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.123) #13, !dbg !5079
  br label %if.end155, !dbg !5080

sw.bb76:                                          ; preds = %if.end66
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.124) #13, !dbg !5081
  br label %if.end155, !dbg !5082

sw.bb77:                                          ; preds = %if.end66
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.125) #13, !dbg !5083
  br label %if.end155, !dbg !5084

sw.bb78:                                          ; preds = %if.end66
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.126) #13, !dbg !5085
  br label %if.end155, !dbg !5086

land.lhs.true84:                                  ; preds = %land.lhs.true48
  %call87 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(8) @.str.133) #15, !dbg !5087
  %cmp88 = icmp eq i32 %call87, 0, !dbg !5088
  br i1 %cmp88, label %if.then90, label %land.lhs.true100, !dbg !5089

if.then90:                                        ; preds = %land.lhs.true84
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %tocrawl) #13, !dbg !5090
  %arrayidx91 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5091
  %12 = load ptr, ptr %arrayidx91, align 8, !dbg !5093, !tbaa !1573
  %call93 = call zeroext i1 @safe_strtoul(ptr noundef %12, ptr noundef nonnull %tocrawl) #13, !dbg !5094
  br i1 %call93, label %if.end95, label %cleanup96, !dbg !5095

if.end95:                                         ; preds = %if.then90
  %13 = load i32, ptr %tocrawl, align 4, !dbg !5096, !tbaa !1231
  store i32 %13, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 41), align 4, !dbg !5097, !tbaa !4990
  br label %cleanup96, !dbg !5098

cleanup96:                                        ; preds = %if.then90, %if.end95
  %.str.95.sink = phi ptr [ @.str.95, %if.end95 ], [ @.str.48, %if.then90 ]
  call void @out_string(ptr noundef %c, ptr noundef nonnull %.str.95.sink) #13, !dbg !4969
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %tocrawl) #13, !dbg !5099
  br label %if.end155

land.lhs.true100:                                 ; preds = %land.lhs.true84
  %call103 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(6) @.str.134) #15, !dbg !5100
  %cmp104 = icmp eq i32 %call103, 0, !dbg !5101
  br i1 %cmp104, label %if.then106, label %if.else149, !dbg !5102

if.then106:                                       ; preds = %land.lhs.true100
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %tosleep) #13, !dbg !5103
  %arrayidx107 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5104
  %14 = load ptr, ptr %arrayidx107, align 8, !dbg !5106, !tbaa !1573
  %call109 = call zeroext i1 @safe_strtoul(ptr noundef %14, ptr noundef nonnull %tosleep) #13, !dbg !5107
  br i1 %call109, label %if.end111, label %cleanup116, !dbg !5108

if.end111:                                        ; preds = %if.then106
  %15 = load i32, ptr %tosleep, align 4, !dbg !5109, !tbaa !1231
  %cmp112 = icmp ugt i32 %15, 1000000, !dbg !5111
  br i1 %cmp112, label %cleanup116, label %if.end115, !dbg !5112

if.end115:                                        ; preds = %if.end111
  store i32 %15, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 40), align 8, !dbg !5113, !tbaa !5114
  br label %cleanup116, !dbg !5115

cleanup116:                                       ; preds = %if.end111, %if.then106, %if.end115
  %.str.95.sink213 = phi ptr [ @.str.95, %if.end115 ], [ @.str.48, %if.then106 ], [ @.str.135, %if.end111 ]
  call void @out_string(ptr noundef %c, ptr noundef nonnull %.str.95.sink213) #13, !dbg !4971
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %tosleep) #13, !dbg !5116
  br label %if.end155

if.then120:                                       ; preds = %entry
  %arrayidx121 = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !5117
  %16 = load ptr, ptr %arrayidx121, align 8, !dbg !5121, !tbaa !1573
  %call123 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %16, ptr noundef nonnull dereferenceable(7) @.str.136) #15, !dbg !5122
  %cmp124 = icmp eq i32 %call123, 0, !dbg !5123
  br i1 %cmp124, label %if.then126, label %if.else133, !dbg !5124

if.then126:                                       ; preds = %if.then120
  %call127 = tail call i32 @start_item_crawler_thread() #13, !dbg !5125
  %cmp128 = icmp eq i32 %call127, 0, !dbg !5128
  br i1 %cmp128, label %if.then130, label %if.else131, !dbg !5129

if.then130:                                       ; preds = %if.then126
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.95) #13, !dbg !5130
  br label %if.end155, !dbg !5132

if.else131:                                       ; preds = %if.then126
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.137) #13, !dbg !5133
  br label %if.end155

if.else133:                                       ; preds = %if.then120
  %call136 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %16, ptr noundef nonnull dereferenceable(8) @.str.138) #15, !dbg !5135
  %cmp137 = icmp eq i32 %call136, 0, !dbg !5137
  br i1 %cmp137, label %if.then139, label %if.else146, !dbg !5138

if.then139:                                       ; preds = %if.else133
  %call140 = tail call i32 @stop_item_crawler_thread(i1 noundef zeroext false) #13, !dbg !5139
  %cmp141 = icmp eq i32 %call140, 0, !dbg !5142
  br i1 %cmp141, label %if.then143, label %if.else144, !dbg !5143

if.then143:                                       ; preds = %if.then139
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.95) #13, !dbg !5144
  br label %if.end155, !dbg !5146

if.else144:                                       ; preds = %if.then139
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.139) #13, !dbg !5147
  br label %if.end155

if.else146:                                       ; preds = %if.else133
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !5149
  br label %if.end155

if.else149:                                       ; preds = %entry, %land.lhs.true100
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !5151
  br label %if.end155

if.end155:                                        ; preds = %sw.bb72, %sw.bb75, %sw.bb76, %sw.bb77, %sw.bb78, %if.end66, %sw.bb37, %sw.bb39, %sw.bb40, %sw.bb41, %sw.bb42, %if.end32, %if.then4, %if.end, %sw.bb11, %sw.bb10, %sw.bb9, %sw.bb8, %sw.bb, %if.else131, %if.then130, %if.then143, %if.else144, %if.else146, %if.then25, %if.then28, %if.then31, %if.then59, %if.then62, %if.then65, %cleanup96, %cleanup116, %if.else149
  ret void, !dbg !5153
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_watch_command(ptr noundef %c, ptr nocapture noundef readonly %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !5154 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !5156, metadata !DIExpression()), !dbg !5161
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !5157, metadata !DIExpression()), !dbg !5161
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !5158, metadata !DIExpression()), !dbg !5161
  tail call void @llvm.dbg.value(metadata i16 0, metadata !5159, metadata !DIExpression()), !dbg !5161
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4139, metadata !DIExpression()), !dbg !5162
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4144, metadata !DIExpression()), !dbg !5162
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4145, metadata !DIExpression()), !dbg !5162
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4146, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_minus, DW_OP_stack_value)), !dbg !5162
  %conv.i = shl i64 %ntokens, 32, !dbg !5164
  %sext.i = add i64 %conv.i, -8589934592, !dbg !5164
  %idxprom.i = ashr exact i64 %sext.i, 32, !dbg !5164
  %arrayidx.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %idxprom.i, !dbg !5164
  %0 = load ptr, ptr %arrayidx.i, align 8, !dbg !5165, !tbaa !1573
  %tobool.not.i = icmp eq ptr %0, null, !dbg !5164
  br i1 %tobool.not.i, label %set_noreply_maybe.exit, label %land.lhs.true.i, !dbg !5166

land.lhs.true.i:                                  ; preds = %entry
  %call.i = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(8) @.str.82) #15, !dbg !5167
  %cmp.i = icmp eq i32 %call.i, 0, !dbg !5168
  br i1 %cmp.i, label %if.then.i, label %set_noreply_maybe.exit, !dbg !5169

if.then.i:                                        ; preds = %land.lhs.true.i
  %noreply.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !5170
  store i8 1, ptr %noreply.i, align 4, !dbg !5171, !tbaa !1302
  br label %set_noreply_maybe.exit, !dbg !5172

set_noreply_maybe.exit:                           ; preds = %entry, %land.lhs.true.i, %if.then.i
  %1 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 54), align 1, !dbg !5173, !tbaa !5175, !range !1296, !noundef !1297
  %tobool = trunc nuw i8 %1 to i1, !dbg !5173
  br i1 %tobool, label %if.end, label %if.then, !dbg !5176

if.then:                                          ; preds = %set_noreply_maybe.exit
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.140) #13, !dbg !5177
  br label %cleanup, !dbg !5179

if.end:                                           ; preds = %set_noreply_maybe.exit
  %call1 = tail call zeroext i1 @resp_has_stack(ptr noundef nonnull %c) #13, !dbg !5180
  br i1 %call1, label %if.then2, label %if.end3, !dbg !5182

if.then2:                                         ; preds = %if.end
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.141) #13, !dbg !5183
  br label %cleanup, !dbg !5185

if.end3:                                          ; preds = %if.end
  %cmp = icmp ugt i64 %ntokens, 2, !dbg !5186
  br i1 %cmp, label %for.body.preheader, label %if.end126, !dbg !5188

for.body.preheader:                               ; preds = %if.end3
  %2 = add i64 %ntokens, -2
  br label %for.body, !dbg !5189

for.body:                                         ; preds = %for.body.preheader, %for.inc
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.inc ], [ 1, %for.body.preheader ]
  %f.0178 = phi i16 [ %4, %for.inc ], [ 0, %for.body.preheader ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !5160, metadata !DIExpression()), !dbg !5161
  tail call void @llvm.dbg.value(metadata i16 %f.0178, metadata !5159, metadata !DIExpression()), !dbg !5161
  %arrayidx = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %indvars.iv, !dbg !5192
  %3 = load ptr, ptr %arrayidx, align 8, !dbg !5196, !tbaa !1573
  %call7 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %3, ptr noundef nonnull dereferenceable(8) @.str.142) #15, !dbg !5197
  %cmp8 = icmp eq i32 %call7, 0, !dbg !5198
  br i1 %cmp8, label %for.inc, label %if.else, !dbg !5199

if.else:                                          ; preds = %for.body
  %call16 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %3, ptr noundef nonnull dereferenceable(10) @.str.143) #15, !dbg !5200
  %cmp17 = icmp eq i32 %call16, 0, !dbg !5202
  br i1 %cmp17, label %for.inc, label %if.else23, !dbg !5203

if.else23:                                        ; preds = %if.else
  %call27 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %3, ptr noundef nonnull dereferenceable(9) @.str.144) #15, !dbg !5204
  %cmp28 = icmp eq i32 %call27, 0, !dbg !5206
  br i1 %cmp28, label %for.inc, label %if.else34, !dbg !5207

if.else34:                                        ; preds = %if.else23
  %call38 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %3, ptr noundef nonnull dereferenceable(10) @.str.145) #15, !dbg !5208
  %cmp39 = icmp eq i32 %call38, 0, !dbg !5210
  br i1 %cmp39, label %for.inc, label %if.else45, !dbg !5211

if.else45:                                        ; preds = %if.else34
  %call49 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %3, ptr noundef nonnull dereferenceable(10) @.str.146) #15, !dbg !5212
  %cmp50 = icmp eq i32 %call49, 0, !dbg !5214
  br i1 %cmp50, label %for.inc, label %if.else56, !dbg !5215

if.else56:                                        ; preds = %if.else45
  %call60 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %3, ptr noundef nonnull dereferenceable(11) @.str.147) #15, !dbg !5216
  %cmp61 = icmp eq i32 %call60, 0, !dbg !5218
  br i1 %cmp61, label %for.inc, label %if.else67, !dbg !5219

if.else67:                                        ; preds = %if.else56
  %call71 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %3, ptr noundef nonnull dereferenceable(10) @.str.148) #15, !dbg !5220
  %cmp72 = icmp eq i32 %call71, 0, !dbg !5222
  br i1 %cmp72, label %for.inc, label %if.else78, !dbg !5223

if.else78:                                        ; preds = %if.else67
  %call82 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %3, ptr noundef nonnull dereferenceable(12) @.str.149) #15, !dbg !5224
  %cmp83 = icmp eq i32 %call82, 0, !dbg !5226
  br i1 %cmp83, label %for.inc, label %if.else89, !dbg !5227

if.else89:                                        ; preds = %if.else78
  %call93 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %3, ptr noundef nonnull dereferenceable(10) @.str.150) #15, !dbg !5228
  %cmp94 = icmp eq i32 %call93, 0, !dbg !5230
  br i1 %cmp94, label %for.inc, label %if.else100, !dbg !5231

if.else100:                                       ; preds = %if.else89
  %call104 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %3, ptr noundef nonnull dereferenceable(10) @.str.151) #15, !dbg !5232
  %cmp105 = icmp eq i32 %call104, 0, !dbg !5234
  br i1 %cmp105, label %for.inc, label %if.else111, !dbg !5235

if.else111:                                       ; preds = %if.else100
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.15) #13, !dbg !5236
  br label %cleanup, !dbg !5238

for.inc:                                          ; preds = %if.else100, %if.else89, %if.else78, %if.else67, %if.else56, %if.else45, %if.else34, %if.else23, %if.else, %for.body
  %.sink = phi i16 [ 512, %for.body ], [ 64, %if.else ], [ 4, %if.else23 ], [ 8, %if.else34 ], [ 2, %if.else45 ], [ 32, %if.else56 ], [ 1024, %if.else67 ], [ 2048, %if.else78 ], [ 4096, %if.else89 ], [ 8192, %if.else100 ]
  %4 = or i16 %f.0178, %.sink, !dbg !5239
  tail call void @llvm.dbg.value(metadata i16 %4, metadata !5159, metadata !DIExpression()), !dbg !5161
  %indvars.iv.next = add nuw i64 %indvars.iv, 1, !dbg !5240
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !5160, metadata !DIExpression()), !dbg !5161
  %exitcond.not = icmp eq i64 %indvars.iv, %2, !dbg !5241
  br i1 %exitcond.not, label %if.end126, label %for.body, !dbg !5189, !llvm.loop !5242

if.end126:                                        ; preds = %for.inc, %if.end3
  %f.2 = phi i16 [ 4, %if.end3 ], [ %4, %for.inc ], !dbg !5161
  tail call void @llvm.dbg.value(metadata i16 %f.2, metadata !5159, metadata !DIExpression()), !dbg !5161
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !5244
  %5 = load i32, ptr %sfd, align 8, !dbg !5244, !tbaa !1311
  %call127 = tail call i32 @logger_add_watcher(ptr noundef %c, i32 noundef %5, i16 noundef zeroext %f.2) #13, !dbg !5245
  switch i32 %call127, label %cleanup [
    i32 0, label %sw.bb
    i32 2, label %sw.bb128
    i32 1, label %sw.bb129
  ], !dbg !5246

sw.bb:                                            ; preds = %if.end126
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.152) #13, !dbg !5247
  br label %cleanup, !dbg !5249

sw.bb128:                                         ; preds = %if.end126
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.153) #13, !dbg !5250
  br label %cleanup, !dbg !5251

sw.bb129:                                         ; preds = %if.end126
  tail call void @conn_set_state(ptr noundef nonnull %c, i32 noundef 11) #13, !dbg !5252
  %event = getelementptr inbounds i8, ptr %c, i64 32, !dbg !5253
  %call130 = tail call i32 @event_del(ptr noundef nonnull %event) #13, !dbg !5254
  br label %cleanup, !dbg !5255

cleanup:                                          ; preds = %sw.bb, %sw.bb128, %sw.bb129, %if.end126, %if.else111, %if.then2, %if.then
  ret void, !dbg !5256
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_verbosity_command(ptr noundef %c, ptr nocapture noundef readonly %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !5257 {
entry:
  %level = alloca i32, align 4, !DIAssignID !5263
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !5262, metadata !DIExpression(), metadata !5263, metadata ptr %level, metadata !DIExpression()), !dbg !5264
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !5259, metadata !DIExpression()), !dbg !5264
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !5260, metadata !DIExpression()), !dbg !5264
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !5261, metadata !DIExpression()), !dbg !5264
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %level) #13, !dbg !5265
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4139, metadata !DIExpression()), !dbg !5266
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4144, metadata !DIExpression()), !dbg !5266
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4145, metadata !DIExpression()), !dbg !5266
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4146, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_minus, DW_OP_stack_value)), !dbg !5266
  %conv.i = shl i64 %ntokens, 32, !dbg !5268
  %sext.i = add i64 %conv.i, -8589934592, !dbg !5268
  %idxprom.i = ashr exact i64 %sext.i, 32, !dbg !5268
  %arrayidx.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %idxprom.i, !dbg !5268
  %0 = load ptr, ptr %arrayidx.i, align 8, !dbg !5269, !tbaa !1573
  %tobool.not.i = icmp eq ptr %0, null, !dbg !5268
  br i1 %tobool.not.i, label %set_noreply_maybe.exit, label %land.lhs.true.i, !dbg !5270

land.lhs.true.i:                                  ; preds = %entry
  %call.i = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(8) @.str.82) #15, !dbg !5271
  %cmp.i = icmp eq i32 %call.i, 0, !dbg !5272
  br i1 %cmp.i, label %if.then.i, label %set_noreply_maybe.exit, !dbg !5273

if.then.i:                                        ; preds = %land.lhs.true.i
  %noreply.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !5274
  store i8 1, ptr %noreply.i, align 4, !dbg !5275, !tbaa !1302
  br label %set_noreply_maybe.exit, !dbg !5276

set_noreply_maybe.exit:                           ; preds = %entry, %land.lhs.true.i, %if.then.i
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !5277
  %1 = load ptr, ptr %arrayidx, align 8, !dbg !5279, !tbaa !1573
  %call1 = call zeroext i1 @safe_strtoul(ptr noundef %1, ptr noundef nonnull %level) #13, !dbg !5280
  br i1 %call1, label %if.end, label %cleanup, !dbg !5281

if.end:                                           ; preds = %set_noreply_maybe.exit
  %2 = load i32, ptr %level, align 4, !dbg !5282, !tbaa !1231
  %spec.select = call i32 @llvm.umin.i32(i32 %2, i32 2), !dbg !5282
  store i32 %spec.select, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !5283, !tbaa !1858
  br label %cleanup, !dbg !5284

cleanup:                                          ; preds = %set_noreply_maybe.exit, %if.end
  %.str.95.sink = phi ptr [ @.str.95, %if.end ], [ @.str.48, %set_noreply_maybe.exit ]
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull %.str.95.sink) #13, !dbg !5264
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %level) #13, !dbg !5285
  ret void, !dbg !5285
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_lru_command(ptr noundef %c, ptr nocapture noundef readonly %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !5286 {
entry:
  %pct_hot = alloca i32, align 4, !DIAssignID !5296
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !5291, metadata !DIExpression(), metadata !5296, metadata ptr %pct_hot, metadata !DIExpression()), !dbg !5297
  %pct_warm = alloca i32, align 4, !DIAssignID !5298
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !5292, metadata !DIExpression(), metadata !5298, metadata ptr %pct_warm, metadata !DIExpression()), !dbg !5297
  %hot_factor = alloca double, align 8, !DIAssignID !5299
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !5293, metadata !DIExpression(), metadata !5299, metadata ptr %hot_factor, metadata !DIExpression()), !dbg !5297
  %ttl = alloca i32, align 4, !DIAssignID !5300
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !5294, metadata !DIExpression(), metadata !5300, metadata ptr %ttl, metadata !DIExpression()), !dbg !5297
  %factor = alloca double, align 8, !DIAssignID !5301
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !5295, metadata !DIExpression(), metadata !5301, metadata ptr %factor, metadata !DIExpression()), !dbg !5297
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !5288, metadata !DIExpression()), !dbg !5297
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !5289, metadata !DIExpression()), !dbg !5297
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !5290, metadata !DIExpression()), !dbg !5297
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %pct_hot) #13, !dbg !5302
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %pct_warm) #13, !dbg !5303
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %hot_factor) #13, !dbg !5304
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %ttl) #13, !dbg !5305
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %factor) #13, !dbg !5306
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4139, metadata !DIExpression()), !dbg !5307
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4144, metadata !DIExpression()), !dbg !5307
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4145, metadata !DIExpression()), !dbg !5307
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4146, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_minus, DW_OP_stack_value)), !dbg !5307
  %conv.i = shl i64 %ntokens, 32, !dbg !5309
  %sext.i = add i64 %conv.i, -8589934592, !dbg !5309
  %idxprom.i = ashr exact i64 %sext.i, 32, !dbg !5309
  %arrayidx.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %idxprom.i, !dbg !5309
  %0 = load ptr, ptr %arrayidx.i, align 8, !dbg !5310, !tbaa !1573
  %tobool.not.i = icmp eq ptr %0, null, !dbg !5309
  br i1 %tobool.not.i, label %set_noreply_maybe.exit, label %land.lhs.true.i, !dbg !5311

land.lhs.true.i:                                  ; preds = %entry
  %call.i = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(8) @.str.82) #15, !dbg !5312
  %cmp.i = icmp eq i32 %call.i, 0, !dbg !5313
  br i1 %cmp.i, label %if.then.i, label %set_noreply_maybe.exit, !dbg !5314

if.then.i:                                        ; preds = %land.lhs.true.i
  %noreply.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !5315
  store i8 1, ptr %noreply.i, align 4, !dbg !5316, !tbaa !1302
  br label %set_noreply_maybe.exit, !dbg !5317

set_noreply_maybe.exit:                           ; preds = %entry, %land.lhs.true.i, %if.then.i
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !5318
  %1 = load ptr, ptr %arrayidx, align 8, !dbg !5320, !tbaa !1573
  %call1 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %1, ptr noundef nonnull dereferenceable(5) @.str.154) #15, !dbg !5321
  %cmp = icmp eq i32 %call1, 0, !dbg !5322
  %cmp2 = icmp ugt i64 %ntokens, 6
  %or.cond = and i1 %cmp2, %cmp, !dbg !5323
  br i1 %or.cond, label %if.then, label %if.else28, !dbg !5323

if.then:                                          ; preds = %set_noreply_maybe.exit
  %arrayidx3 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5324
  %2 = load ptr, ptr %arrayidx3, align 8, !dbg !5327, !tbaa !1573
  %call5 = call zeroext i1 @safe_strtoul(ptr noundef %2, ptr noundef nonnull %pct_hot) #13, !dbg !5328
  br i1 %call5, label %lor.lhs.false, label %if.then17, !dbg !5329

lor.lhs.false:                                    ; preds = %if.then
  %arrayidx6 = getelementptr inbounds i8, ptr %tokens, i64 48, !dbg !5330
  %3 = load ptr, ptr %arrayidx6, align 8, !dbg !5331, !tbaa !1573
  %call8 = call zeroext i1 @safe_strtoul(ptr noundef %3, ptr noundef nonnull %pct_warm) #13, !dbg !5332
  br i1 %call8, label %lor.lhs.false9, label %if.then17, !dbg !5333

lor.lhs.false9:                                   ; preds = %lor.lhs.false
  %arrayidx10 = getelementptr inbounds i8, ptr %tokens, i64 64, !dbg !5334
  %4 = load ptr, ptr %arrayidx10, align 8, !dbg !5335, !tbaa !1573
  %call12 = call zeroext i1 @safe_strtod(ptr noundef %4, ptr noundef nonnull %hot_factor) #13, !dbg !5336
  br i1 %call12, label %lor.lhs.false13, label %if.then17, !dbg !5337

lor.lhs.false13:                                  ; preds = %lor.lhs.false9
  %arrayidx14 = getelementptr inbounds i8, ptr %tokens, i64 80, !dbg !5338
  %5 = load ptr, ptr %arrayidx14, align 8, !dbg !5339, !tbaa !1573
  %call16 = call zeroext i1 @safe_strtod(ptr noundef %5, ptr noundef nonnull %factor) #13, !dbg !5340
  br i1 %call16, label %if.else, label %if.then17, !dbg !5341

if.then17:                                        ; preds = %lor.lhs.false13, %lor.lhs.false9, %lor.lhs.false, %if.then
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.15) #13, !dbg !5342
  br label %if.end74, !dbg !5344

if.else:                                          ; preds = %lor.lhs.false13
  %6 = load i32, ptr %pct_hot, align 4, !dbg !5345, !tbaa !1231
  %7 = load i32, ptr %pct_warm, align 4, !dbg !5348, !tbaa !1231
  %add = add i32 %7, %6, !dbg !5349
  %cmp18 = icmp ugt i32 %add, 80, !dbg !5350
  br i1 %cmp18, label %if.then19, label %if.else20, !dbg !5351

if.then19:                                        ; preds = %if.else
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.155) #13, !dbg !5352
  br label %if.end74, !dbg !5354

if.else20:                                        ; preds = %if.else
  %8 = load double, ptr %factor, align 8, !dbg !5355, !tbaa !4574
  %cmp21 = fcmp ugt double %8, 0.000000e+00, !dbg !5357
  br i1 %cmp21, label %lor.lhs.false22, label %if.then24, !dbg !5358

lor.lhs.false22:                                  ; preds = %if.else20
  %9 = load double, ptr %hot_factor, align 8, !dbg !5359, !tbaa !4574
  %cmp23 = fcmp ugt double %9, 0.000000e+00, !dbg !5360
  br i1 %cmp23, label %if.else25, label %if.then24, !dbg !5361

if.then24:                                        ; preds = %lor.lhs.false22, %if.else20
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.156) #13, !dbg !5362
  br label %if.end74, !dbg !5364

if.else25:                                        ; preds = %lor.lhs.false22
  store i32 %6, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 42), align 8, !dbg !5365, !tbaa !5367
  store i32 %7, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 43), align 4, !dbg !5368, !tbaa !5369
  store double %9, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 44), align 8, !dbg !5370, !tbaa !5371
  store double %8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 45), align 8, !dbg !5372, !tbaa !5373
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.95) #13, !dbg !5374
  br label %if.end74

if.else28:                                        ; preds = %set_noreply_maybe.exit
  %call31 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %1, ptr noundef nonnull dereferenceable(5) @.str.157) #15, !dbg !5375
  %cmp32 = icmp eq i32 %call31, 0, !dbg !5377
  %cmp34 = icmp ugt i64 %ntokens, 3
  %or.cond98 = and i1 %cmp34, %cmp32, !dbg !5378
  br i1 %or.cond98, label %land.lhs.true35, label %if.else51, !dbg !5378

land.lhs.true35:                                  ; preds = %if.else28
  %10 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 28), align 1, !dbg !5379, !tbaa !5380, !range !1296, !noundef !1297
  %tobool = trunc nuw i8 %10 to i1, !dbg !5379
  br i1 %tobool, label %if.then36, label %if.else51, !dbg !5381

if.then36:                                        ; preds = %land.lhs.true35
  %arrayidx37 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5382
  %11 = load ptr, ptr %arrayidx37, align 8, !dbg !5385, !tbaa !1573
  %call39 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %11, ptr noundef nonnull dereferenceable(5) @.str.158) #15, !dbg !5386
  %cmp40 = icmp eq i32 %call39, 0, !dbg !5387
  br i1 %cmp40, label %if.then41, label %if.else42, !dbg !5388

if.then41:                                        ; preds = %if.then36
  store i8 0, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 29), align 8, !dbg !5389, !tbaa !5391
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.95) #13, !dbg !5392
  br label %if.end74, !dbg !5393

if.else42:                                        ; preds = %if.then36
  %call45 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %11, ptr noundef nonnull dereferenceable(10) @.str.159) #15, !dbg !5394
  %cmp46 = icmp eq i32 %call45, 0, !dbg !5396
  br i1 %cmp46, label %if.then47, label %if.else48, !dbg !5397

if.then47:                                        ; preds = %if.else42
  store i8 1, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 29), align 8, !dbg !5398, !tbaa !5391
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.95) #13, !dbg !5400
  br label %if.end74, !dbg !5401

if.else48:                                        ; preds = %if.else42
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.15) #13, !dbg !5402
  br label %if.end74

if.else51:                                        ; preds = %land.lhs.true35, %if.else28
  %call54 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %1, ptr noundef nonnull dereferenceable(9) @.str.160) #15, !dbg !5404
  %cmp55 = icmp eq i32 %call54, 0, !dbg !5406
  %or.cond99 = and i1 %cmp34, %cmp55, !dbg !5407
  br i1 %or.cond99, label %land.lhs.true58, label %if.else71, !dbg !5407

land.lhs.true58:                                  ; preds = %if.else51
  %12 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 28), align 1, !dbg !5408, !tbaa !5380, !range !1296, !noundef !1297
  %tobool59 = trunc nuw i8 %12 to i1, !dbg !5408
  br i1 %tobool59, label %if.then60, label %if.else71, !dbg !5409

if.then60:                                        ; preds = %land.lhs.true58
  %arrayidx61 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5410
  %13 = load ptr, ptr %arrayidx61, align 8, !dbg !5413, !tbaa !1573
  %call63 = call zeroext i1 @safe_strtol(ptr noundef %13, ptr noundef nonnull %ttl) #13, !dbg !5414
  br i1 %call63, label %if.else65, label %if.then64, !dbg !5415

if.then64:                                        ; preds = %if.then60
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.15) #13, !dbg !5416
  br label %if.end74, !dbg !5418

if.else65:                                        ; preds = %if.then60
  %14 = load i32, ptr %ttl, align 4, !dbg !5419, !tbaa !1231
  %cmp66 = icmp slt i32 %14, 0, !dbg !5422
  br i1 %cmp66, label %if.end69, label %if.else68, !dbg !5423

if.else68:                                        ; preds = %if.else65
  store i32 %14, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 48), align 8, !dbg !5424, !tbaa !5426
  br label %if.end69

if.end69:                                         ; preds = %if.else65, %if.else68
  %.sink = phi i8 [ 1, %if.else68 ], [ 0, %if.else65 ], !dbg !5427
  store i8 %.sink, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 47), align 4, !dbg !5427
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.95) #13, !dbg !5428
  br label %if.end74

if.else71:                                        ; preds = %land.lhs.true58, %if.else51
  tail call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull @.str.15) #13, !dbg !5429
  br label %if.end74

if.end74:                                         ; preds = %if.then47, %if.else48, %if.then41, %if.then64, %if.end69, %if.else71, %if.then17, %if.then24, %if.else25, %if.then19
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %factor) #13, !dbg !5431
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %ttl) #13, !dbg !5431
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %hot_factor) #13, !dbg !5431
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %pct_warm) #13, !dbg !5431
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %pct_hot) #13, !dbg !5431
  ret void, !dbg !5431
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @process_extstore_command(ptr noundef %c, ptr nocapture noundef readonly %tokens, i64 noundef %ntokens) unnamed_addr #0 !dbg !5432 {
entry:
  %clsid = alloca i32, align 4, !DIAssignID !5454
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !5438, metadata !DIExpression(), metadata !5454, metadata ptr %clsid, metadata !DIExpression()), !dbg !5455
  %limit = alloca i32, align 4, !DIAssignID !5456
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !5442, metadata !DIExpression(), metadata !5456, metadata ptr %limit, metadata !DIExpression()), !dbg !5455
  %v = alloca i32, align 4, !DIAssignID !5457
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !5443, metadata !DIExpression(), metadata !5457, metadata ptr %v, metadata !DIExpression()), !dbg !5458
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !5434, metadata !DIExpression()), !dbg !5459
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !5435, metadata !DIExpression()), !dbg !5459
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !5436, metadata !DIExpression()), !dbg !5459
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !4139, metadata !DIExpression()), !dbg !5460
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !4144, metadata !DIExpression()), !dbg !5460
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4145, metadata !DIExpression()), !dbg !5460
  tail call void @llvm.dbg.value(metadata i64 %ntokens, metadata !4146, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_minus, DW_OP_stack_value)), !dbg !5460
  %conv.i = shl i64 %ntokens, 32, !dbg !5462
  %sext.i = add i64 %conv.i, -8589934592, !dbg !5462
  %idxprom.i = ashr exact i64 %sext.i, 32, !dbg !5462
  %arrayidx.i = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %idxprom.i, !dbg !5462
  %0 = load ptr, ptr %arrayidx.i, align 8, !dbg !5463, !tbaa !1573
  %tobool.not.i = icmp eq ptr %0, null, !dbg !5462
  br i1 %tobool.not.i, label %set_noreply_maybe.exit, label %land.lhs.true.i, !dbg !5464

land.lhs.true.i:                                  ; preds = %entry
  %call.i = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %0, ptr noundef nonnull dereferenceable(8) @.str.82) #15, !dbg !5465
  %cmp.i = icmp eq i32 %call.i, 0, !dbg !5466
  br i1 %cmp.i, label %if.then.i, label %set_noreply_maybe.exit, !dbg !5467

if.then.i:                                        ; preds = %land.lhs.true.i
  %noreply.i = getelementptr inbounds i8, ptr %c, i64 364, !dbg !5468
  store i8 1, ptr %noreply.i, align 4, !dbg !5469, !tbaa !1302
  br label %set_noreply_maybe.exit, !dbg !5470

set_noreply_maybe.exit:                           ; preds = %entry, %land.lhs.true.i, %if.then.i
  tail call void @llvm.dbg.value(metadata i8 1, metadata !5437, metadata !DIExpression()), !dbg !5459
  %cmp = icmp ult i64 %ntokens, 4, !dbg !5471
  br i1 %cmp, label %if.end133, label %if.else, !dbg !5472

if.else:                                          ; preds = %set_noreply_maybe.exit
  %arrayidx = getelementptr inbounds i8, ptr %tokens, i64 16, !dbg !5473
  %1 = load ptr, ptr %arrayidx, align 8, !dbg !5474, !tbaa !1573
  %call1 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %1, ptr noundef nonnull dereferenceable(15) @.str.161) #15, !dbg !5475
  %cmp2 = icmp ne i32 %call1, 0, !dbg !5476
  %cmp3.not = icmp eq i64 %ntokens, 4
  %or.cond = or i1 %cmp3.not, %cmp2, !dbg !5477
  br i1 %or.cond, label %if.else17, label %if.then4, !dbg !5477

if.then4:                                         ; preds = %if.else
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %clsid) #13, !dbg !5478
  store i32 0, ptr %clsid, align 4, !dbg !5479, !tbaa !1231, !DIAssignID !5480
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !5438, metadata !DIExpression(), metadata !5480, metadata ptr %clsid, metadata !DIExpression()), !dbg !5455
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %limit) #13, !dbg !5481
  store i32 0, ptr %limit, align 4, !dbg !5482, !tbaa !1231, !DIAssignID !5483
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !5442, metadata !DIExpression(), metadata !5483, metadata ptr %limit, metadata !DIExpression()), !dbg !5455
  %arrayidx5 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5484
  %2 = load ptr, ptr %arrayidx5, align 8, !dbg !5486, !tbaa !1573
  %call7 = call zeroext i1 @safe_strtoul(ptr noundef %2, ptr noundef nonnull %clsid) #13, !dbg !5487
  br i1 %call7, label %lor.lhs.false, label %if.end16.thread, !dbg !5488

lor.lhs.false:                                    ; preds = %if.then4
  %arrayidx8 = getelementptr inbounds i8, ptr %tokens, i64 48, !dbg !5489
  %3 = load ptr, ptr %arrayidx8, align 8, !dbg !5490, !tbaa !1573
  %call10 = call zeroext i1 @safe_strtoul(ptr noundef %3, ptr noundef nonnull %limit) #13, !dbg !5491
  br i1 %call10, label %if.end16, label %if.end16.thread, !dbg !5492

if.end16.thread:                                  ; preds = %lor.lhs.false, %if.then4
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !5437, metadata !DIExpression()), !dbg !5459
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %limit) #13, !dbg !5493
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %clsid) #13, !dbg !5493
  br label %if.end133, !dbg !5494

if.end16:                                         ; preds = %lor.lhs.false
  %4 = load i32, ptr %clsid, align 4, !dbg !5495, !tbaa !1231
  %cmp13 = icmp ult i32 %4, 64, !dbg !5498
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !5437, metadata !DIExpression()), !dbg !5459
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %limit) #13, !dbg !5493
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %clsid) #13, !dbg !5493
  br i1 %cmp13, label %if.else132, label %if.end133, !dbg !5494

if.else17:                                        ; preds = %if.else
  %call20 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %1, ptr noundef nonnull dereferenceable(10) @.str.162) #15, !dbg !5499
  %cmp21 = icmp eq i32 %call20, 0, !dbg !5500
  br i1 %cmp21, label %if.then22, label %if.else28, !dbg !5501

if.then22:                                        ; preds = %if.else17
  %arrayidx23 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5502
  %5 = load ptr, ptr %arrayidx23, align 8, !dbg !5505, !tbaa !1573
  %call25 = tail call zeroext i1 @safe_strtoul(ptr noundef %5, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 58)) #13, !dbg !5506
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !5437, metadata !DIExpression()), !dbg !5459
  br i1 %call25, label %if.else132, label %if.end133, !dbg !5494

if.else28:                                        ; preds = %if.else17
  %call31 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %1, ptr noundef nonnull dereferenceable(9) @.str.163) #15, !dbg !5507
  %cmp32 = icmp eq i32 %call31, 0, !dbg !5508
  br i1 %cmp32, label %if.then33, label %if.else39, !dbg !5509

if.then33:                                        ; preds = %if.else28
  %arrayidx34 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5510
  %6 = load ptr, ptr %arrayidx34, align 8, !dbg !5513, !tbaa !1573
  %call36 = tail call zeroext i1 @safe_strtoul(ptr noundef %6, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 59)) #13, !dbg !5514
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !5437, metadata !DIExpression()), !dbg !5459
  br i1 %call36, label %if.else132, label %if.end133, !dbg !5494

if.else39:                                        ; preds = %if.else28
  %call42 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %1, ptr noundef nonnull dereferenceable(8) @.str.164) #15, !dbg !5515
  %cmp43 = icmp eq i32 %call42, 0, !dbg !5516
  br i1 %cmp43, label %if.then44, label %if.else50, !dbg !5517

if.then44:                                        ; preds = %if.else39
  %arrayidx45 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5518
  %7 = load ptr, ptr %arrayidx45, align 8, !dbg !5521, !tbaa !1573
  %call47 = tail call zeroext i1 @safe_strtoul(ptr noundef %7, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 60)) #13, !dbg !5522
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !5437, metadata !DIExpression()), !dbg !5459
  br i1 %call47, label %if.else132, label %if.end133, !dbg !5494

if.else50:                                        ; preds = %if.else39
  %call53 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %1, ptr noundef nonnull dereferenceable(13) @.str.165) #15, !dbg !5523
  %cmp54 = icmp eq i32 %call53, 0, !dbg !5524
  br i1 %cmp54, label %if.then55, label %if.else61, !dbg !5525

if.then55:                                        ; preds = %if.else50
  %arrayidx56 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5526
  %8 = load ptr, ptr %arrayidx56, align 8, !dbg !5529, !tbaa !1573
  %call58 = tail call zeroext i1 @safe_strtoul(ptr noundef %8, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 61)) #13, !dbg !5530
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !5437, metadata !DIExpression()), !dbg !5459
  br i1 %call58, label %if.else132, label %if.end133, !dbg !5494

if.else61:                                        ; preds = %if.else50
  %call64 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %1, ptr noundef nonnull dereferenceable(14) @.str.166) #15, !dbg !5531
  %cmp65 = icmp eq i32 %call64, 0, !dbg !5532
  br i1 %cmp65, label %if.then66, label %if.else72, !dbg !5533

if.then66:                                        ; preds = %if.else61
  %arrayidx67 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5534
  %9 = load ptr, ptr %arrayidx67, align 8, !dbg !5537, !tbaa !1573
  %call69 = tail call zeroext i1 @safe_strtoul(ptr noundef %9, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 63)) #13, !dbg !5538
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !5437, metadata !DIExpression()), !dbg !5459
  br i1 %call69, label %if.else132, label %if.end133, !dbg !5494

if.else72:                                        ; preds = %if.else61
  %call75 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %1, ptr noundef nonnull dereferenceable(11) @.str.167) #15, !dbg !5539
  %cmp76 = icmp eq i32 %call75, 0, !dbg !5540
  br i1 %cmp76, label %if.then77, label %if.else83, !dbg !5541

if.then77:                                        ; preds = %if.else72
  %arrayidx78 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5542
  %10 = load ptr, ptr %arrayidx78, align 8, !dbg !5545, !tbaa !1573
  %call80 = tail call zeroext i1 @safe_strtoul(ptr noundef %10, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 64)) #13, !dbg !5546
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !5437, metadata !DIExpression()), !dbg !5459
  br i1 %call80, label %if.else132, label %if.end133, !dbg !5494

if.else83:                                        ; preds = %if.else72
  %call86 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %1, ptr noundef nonnull dereferenceable(10) @.str.168) #15, !dbg !5547
  %cmp87 = icmp eq i32 %call86, 0, !dbg !5548
  br i1 %cmp87, label %if.then88, label %if.else94, !dbg !5549

if.then88:                                        ; preds = %if.else83
  %arrayidx89 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5550
  %11 = load ptr, ptr %arrayidx89, align 8, !dbg !5553, !tbaa !1573
  %call91 = tail call zeroext i1 @safe_strtoul(ptr noundef %11, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 65)) #13, !dbg !5554
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !5437, metadata !DIExpression()), !dbg !5459
  br i1 %call91, label %if.else132, label %if.end133, !dbg !5494

if.else94:                                        ; preds = %if.else83
  %call97 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %1, ptr noundef nonnull dereferenceable(9) @.str.169) #15, !dbg !5555
  %cmp98 = icmp eq i32 %call97, 0, !dbg !5556
  br i1 %cmp98, label %if.end129, label %if.else105, !dbg !5557

if.else105:                                       ; preds = %if.else94
  %call108 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %1, ptr noundef nonnull dereferenceable(12) @.str.170) #15, !dbg !5558
  %cmp109 = icmp eq i32 %call108, 0, !dbg !5559
  br i1 %cmp109, label %if.then110, label %if.end133, !dbg !5560

if.then110:                                       ; preds = %if.else105
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %v) #13, !dbg !5561
  %arrayidx111 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5562
  %12 = load ptr, ptr %arrayidx111, align 8, !dbg !5564, !tbaa !1573
  %call113 = call zeroext i1 @safe_strtoul(ptr noundef %12, ptr noundef nonnull %v) #13, !dbg !5565
  br i1 %call113, label %if.end117.thread, label %if.end117, !dbg !5566

if.end117.thread:                                 ; preds = %if.then110
  %13 = load i32, ptr %v, align 4, !dbg !5567, !tbaa !1231
  %cmp116 = icmp ne i32 %13, 0, !dbg !5569
  %frombool = zext i1 %cmp116 to i8, !dbg !5570
  store i8 %frombool, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 68), align 8, !dbg !5570, !tbaa !5571
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !5437, metadata !DIExpression()), !dbg !5459
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %v) #13, !dbg !5572
  br label %if.else132, !dbg !5494

if.end117:                                        ; preds = %if.then110
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !5437, metadata !DIExpression()), !dbg !5459
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %v) #13, !dbg !5572
  br label %if.end133

if.end129:                                        ; preds = %if.else94
  %arrayidx100 = getelementptr inbounds i8, ptr %tokens, i64 32, !dbg !5573
  %14 = load ptr, ptr %arrayidx100, align 8, !dbg !5576, !tbaa !1573
  %call102 = tail call zeroext i1 @safe_strtod(ptr noundef %14, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 66)) #13, !dbg !5577
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !5437, metadata !DIExpression()), !dbg !5459
  br i1 %call102, label %if.else132, label %if.end133, !dbg !5494

if.else132:                                       ; preds = %if.end117.thread, %if.then88, %if.then77, %if.then66, %if.then55, %if.then44, %if.then33, %if.then22, %if.end16, %if.end129
  br label %if.end133

if.end133:                                        ; preds = %if.end129, %if.else105, %set_noreply_maybe.exit, %if.end16, %if.then22, %if.then33, %if.then44, %if.then55, %if.then66, %if.then77, %if.then88, %if.end16.thread, %if.end117, %if.else132
  %.str.95.sink = phi ptr [ @.str.95, %if.else132 ], [ @.str.15, %if.end117 ], [ @.str.15, %if.end16.thread ], [ @.str.15, %if.then88 ], [ @.str.15, %if.then77 ], [ @.str.15, %if.then66 ], [ @.str.15, %if.then55 ], [ @.str.15, %if.then44 ], [ @.str.15, %if.then33 ], [ @.str.15, %if.then22 ], [ @.str.15, %if.end16 ], [ @.str.15, %set_noreply_maybe.exit ], [ @.str.15, %if.else105 ], [ @.str.15, %if.end129 ]
  call void @out_string(ptr noundef nonnull %c, ptr noundef nonnull %.str.95.sink) #13, !dbg !5578
  ret void, !dbg !5580
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #7

declare !dbg !5581 i64 @base64_encode(ptr noundef, i64 noundef, ptr noundef, i64 noundef) local_unnamed_addr #4

declare !dbg !5587 ptr @itoa_u64(i64 noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5591 ptr @itoa_u32(i32 noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5594 void @resp_add_iov(ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare !dbg !5597 i64 @strlen(ptr nocapture noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #8

declare !dbg !5600 void @out_errstring(ptr noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc i32 @_meta_flag_preparse(ptr nocapture noundef %tokens, i64 noundef %start, ptr noundef %of, ptr nocapture noundef writeonly %errstr) unnamed_addr #0 !dbg !5601 {
entry:
  %tmp_int = alloca i32, align 4, !DIAssignID !5622
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !5613, metadata !DIExpression(), metadata !5622, metadata ptr %tmp_int, metadata !DIExpression()), !dbg !5623
  %seen = alloca [127 x i8], align 16, !DIAssignID !5624
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !5614, metadata !DIExpression(), metadata !5624, metadata ptr %seen, metadata !DIExpression()), !dbg !5623
  tail call void @llvm.dbg.value(metadata ptr %tokens, metadata !5607, metadata !DIExpression()), !dbg !5623
  tail call void @llvm.dbg.value(metadata i64 %start, metadata !5608, metadata !DIExpression()), !dbg !5623
  tail call void @llvm.dbg.value(metadata ptr %of, metadata !5609, metadata !DIExpression()), !dbg !5623
  tail call void @llvm.dbg.value(metadata ptr %errstr, metadata !5610, metadata !DIExpression()), !dbg !5623
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %tmp_int) #13, !dbg !5625
  call void @llvm.lifetime.start.p0(i64 127, ptr nonnull %seen) #13, !dbg !5626
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(127) %seen, i8 0, i64 127, i1 false), !dbg !5627, !DIAssignID !5628
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !5614, metadata !DIExpression(), metadata !5628, metadata ptr %seen, metadata !DIExpression()), !dbg !5623
  tail call void @llvm.dbg.value(metadata i64 %start, metadata !5611, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !5623
  %idxprom303 = and i64 %start, 4294967295, !dbg !5629
  %arrayidx304 = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %idxprom303, !dbg !5629
  %length305 = getelementptr inbounds i8, ptr %arrayidx304, i64 8, !dbg !5630
  %0 = load i64, ptr %length305, align 8, !dbg !5630, !tbaa !1578
  %cmp.not306 = icmp eq i64 %0, 0, !dbg !5631
  br i1 %cmp.not306, label %for.end, label %for.body.lr.ph, !dbg !5632

for.body.lr.ph:                                   ; preds = %entry
  %conv = trunc nuw nsw i64 %start to i32, !dbg !5633
  tail call void @llvm.dbg.value(metadata i32 %conv, metadata !5611, metadata !DIExpression()), !dbg !5623
  %delta = getelementptr inbounds i8, ptr %of, i64 40
  %initial = getelementptr inbounds i8, ptr %of, i64 48
  %mode = getelementptr inbounds i8, ptr %of, i64 2
  %cas_id_in = getelementptr inbounds i8, ptr %of, i64 32
  %req_cas_id = getelementptr inbounds i8, ptr %of, i64 24
  %client_flags = getelementptr inbounds i8, ptr %of, i64 16
  %recache_time = getelementptr inbounds i8, ptr %of, i64 12
  %exptime = getelementptr inbounds i8, ptr %of, i64 4
  %autoviv_exptime = getelementptr inbounds i8, ptr %of, i64 8
  %arrayidx16 = getelementptr inbounds i8, ptr %tokens, i64 16
  %length19 = getelementptr inbounds i8, ptr %tokens, i64 24
  br label %for.body, !dbg !5632

for.body:                                         ; preds = %for.body.lr.ph, %for.inc
  %1 = phi i64 [ %0, %for.body.lr.ph ], [ %14, %for.inc ]
  %arrayidx308 = phi ptr [ %arrayidx304, %for.body.lr.ph ], [ %arrayidx, %for.inc ]
  %i.0307 = phi i32 [ %conv, %for.body.lr.ph ], [ %inc, %for.inc ]
  tail call void @llvm.dbg.value(metadata i32 %i.0307, metadata !5611, metadata !DIExpression()), !dbg !5623
  %2 = load ptr, ptr %arrayidx308, align 8, !dbg !5634, !tbaa !1573
  %3 = load i8, ptr %2, align 1, !dbg !5635, !tbaa !1240
  tail call void @llvm.dbg.value(metadata i8 %3, metadata !5618, metadata !DIExpression()), !dbg !5636
  %cmp6 = icmp ugt i8 %3, 126, !dbg !5637
  br i1 %cmp6, label %if.then, label %lor.lhs.false, !dbg !5639

lor.lhs.false:                                    ; preds = %for.body
  %idxprom8 = zext nneg i8 %3 to i64, !dbg !5640
  %arrayidx9 = getelementptr inbounds [127 x i8], ptr %seen, i64 0, i64 %idxprom8, !dbg !5640
  %4 = load i8, ptr %arrayidx9, align 1, !dbg !5640, !tbaa !1240
  %cmp11.not = icmp eq i8 %4, 0, !dbg !5641
  br i1 %cmp11.not, label %if.end, label %if.then, !dbg !5642

if.then:                                          ; preds = %lor.lhs.false, %for.body
  store ptr @.str.54, ptr %errstr, align 8, !dbg !5643, !tbaa !1271
  br label %cleanup217, !dbg !5645

if.end:                                           ; preds = %lor.lhs.false
  store i8 1, ptr %arrayidx9, align 1, !dbg !5646, !tbaa !1240
  switch i8 %3, label %sw.default [
    i8 98, label %sw.bb
    i8 78, label %sw.bb33
    i8 84, label %sw.bb53
    i8 82, label %sw.bb79
    i8 108, label %sw.bb102
    i8 79, label %for.inc
    i8 80, label %for.inc
    i8 76, label %for.inc
    i8 107, label %for.inc
    i8 115, label %for.inc
    i8 116, label %for.inc
    i8 99, label %for.inc
    i8 102, label %for.inc
    i8 118, label %sw.bb111
    i8 104, label %sw.bb115
    i8 117, label %sw.bb119
    i8 113, label %sw.bb123
    i8 120, label %sw.bb127
    i8 70, label %sw.bb131
    i8 67, label %sw.bb142
    i8 69, label %sw.bb157
    i8 77, label %sw.bb172
    i8 74, label %sw.bb188
    i8 68, label %sw.bb199
    i8 73, label %sw.bb210
  ], !dbg !5647

sw.bb:                                            ; preds = %if.end
  %5 = load ptr, ptr %arrayidx16, align 8, !dbg !5648, !tbaa !1573
  %6 = load i64, ptr %length19, align 8, !dbg !5650, !tbaa !1578
  %call = call i64 @base64_decode(ptr noundef %5, i64 noundef %6, ptr noundef %5, i64 noundef %6) #13, !dbg !5651
  tail call void @llvm.dbg.value(metadata i64 %call, metadata !5612, metadata !DIExpression()), !dbg !5623
  %cmp24 = icmp eq i64 %call, 0, !dbg !5652
  br i1 %cmp24, label %if.then26, label %if.end27, !dbg !5654

if.then26:                                        ; preds = %sw.bb
  store ptr @.str.55, ptr %errstr, align 8, !dbg !5655, !tbaa !1271
  %bf.load = load i16, ptr %of, align 8, !dbg !5657
  %bf.set = or i16 %bf.load, 1, !dbg !5657
  store i16 %bf.set, ptr %of, align 8, !dbg !5657
  br label %if.end27, !dbg !5658

if.end27:                                         ; preds = %if.then26, %sw.bb
  store i64 %call, ptr %length19, align 8, !dbg !5659, !tbaa !1578
  %bf.load30 = load i16, ptr %of, align 8, !dbg !5660
  %bf.set32 = or i16 %bf.load30, 4096, !dbg !5660
  store i16 %bf.set32, ptr %of, align 8, !dbg !5660
  br label %for.inc, !dbg !5661

sw.bb33:                                          ; preds = %if.end
  %bf.load34 = load i16, ptr %of, align 8, !dbg !5662
  %bf.set39 = or i16 %bf.load34, 12, !dbg !5663
  store i16 %bf.set39, ptr %of, align 8, !dbg !5663
  %7 = load ptr, ptr %arrayidx308, align 8, !dbg !5664, !tbaa !1573
  %add.ptr = getelementptr inbounds i8, ptr %7, i64 1, !dbg !5666
  %call43 = call zeroext i1 @safe_strtol(ptr noundef nonnull %add.ptr, ptr noundef nonnull %tmp_int) #13, !dbg !5667
  br i1 %call43, label %if.else, label %if.then44, !dbg !5668

if.then44:                                        ; preds = %sw.bb33
  store ptr @.str.56, ptr %errstr, align 8, !dbg !5669, !tbaa !1271
  %bf.load45 = load i16, ptr %of, align 8, !dbg !5671
  %bf.set47 = or i16 %bf.load45, 1, !dbg !5671
  store i16 %bf.set47, ptr %of, align 8, !dbg !5671
  br label %for.inc, !dbg !5672

if.else:                                          ; preds = %sw.bb33
  %8 = load i32, ptr %tmp_int, align 4, !dbg !5673, !tbaa !1231
  %cmp48 = icmp slt i32 %8, 0, !dbg !5673
  %spec.select = select i1 %cmp48, i32 2592001, i32 %8, !dbg !5673
  %conv50 = zext nneg i32 %spec.select to i64
  %call51 = call i32 @realtime(i64 noundef %conv50) #13, !dbg !5675
  store i32 %call51, ptr %autoviv_exptime, align 8, !dbg !5676, !tbaa !2502
  br label %for.inc

sw.bb53:                                          ; preds = %if.end
  %bf.load54 = load i16, ptr %of, align 8, !dbg !5677
  %bf.set56 = or i16 %bf.load54, 4, !dbg !5677
  store i16 %bf.set56, ptr %of, align 8, !dbg !5677
  %9 = load ptr, ptr %arrayidx308, align 8, !dbg !5678, !tbaa !1573
  %add.ptr60 = getelementptr inbounds i8, ptr %9, i64 1, !dbg !5680
  %call61 = call zeroext i1 @safe_strtol(ptr noundef nonnull %add.ptr60, ptr noundef nonnull %tmp_int) #13, !dbg !5681
  br i1 %call61, label %if.else66, label %if.then62, !dbg !5682

if.then62:                                        ; preds = %sw.bb53
  store ptr @.str.56, ptr %errstr, align 8, !dbg !5683, !tbaa !1271
  %bf.load63 = load i16, ptr %of, align 8, !dbg !5685
  %bf.set65 = or i16 %bf.load63, 1, !dbg !5685
  store i16 %bf.set65, ptr %of, align 8, !dbg !5685
  br label %for.inc, !dbg !5686

if.else66:                                        ; preds = %sw.bb53
  %10 = load i32, ptr %tmp_int, align 4, !dbg !5687, !tbaa !1231
  %cmp67 = icmp slt i32 %10, 0, !dbg !5687
  %spec.select301 = select i1 %cmp67, i32 2592001, i32 %10, !dbg !5687
  %conv73 = zext nneg i32 %spec.select301 to i64
  %call74 = call i32 @realtime(i64 noundef %conv73) #13, !dbg !5689
  store i32 %call74, ptr %exptime, align 4, !dbg !5690, !tbaa !2495
  %bf.load75 = load i16, ptr %of, align 8, !dbg !5691
  %bf.set77 = or i16 %bf.load75, 2048, !dbg !5691
  store i16 %bf.set77, ptr %of, align 8, !dbg !5691
  br label %for.inc

sw.bb79:                                          ; preds = %if.end
  %bf.load80 = load i16, ptr %of, align 8, !dbg !5692
  %bf.set82 = or i16 %bf.load80, 4, !dbg !5692
  store i16 %bf.set82, ptr %of, align 8, !dbg !5692
  %11 = load ptr, ptr %arrayidx308, align 8, !dbg !5693, !tbaa !1573
  %add.ptr86 = getelementptr inbounds i8, ptr %11, i64 1, !dbg !5695
  %call87 = call zeroext i1 @safe_strtol(ptr noundef nonnull %add.ptr86, ptr noundef nonnull %tmp_int) #13, !dbg !5696
  br i1 %call87, label %if.else92, label %if.then88, !dbg !5697

if.then88:                                        ; preds = %sw.bb79
  store ptr @.str.56, ptr %errstr, align 8, !dbg !5698, !tbaa !1271
  %bf.load89 = load i16, ptr %of, align 8, !dbg !5700
  %bf.set91 = or i16 %bf.load89, 1, !dbg !5700
  store i16 %bf.set91, ptr %of, align 8, !dbg !5700
  br label %for.inc, !dbg !5701

if.else92:                                        ; preds = %sw.bb79
  %12 = load i32, ptr %tmp_int, align 4, !dbg !5702, !tbaa !1231
  %cmp93 = icmp slt i32 %12, 0, !dbg !5702
  %spec.select302 = select i1 %cmp93, i32 2592001, i32 %12, !dbg !5702
  %conv99 = zext nneg i32 %spec.select302 to i64
  %call100 = call i32 @realtime(i64 noundef %conv99) #13, !dbg !5704
  store i32 %call100, ptr %recache_time, align 4, !dbg !5705, !tbaa !2514
  br label %for.inc

sw.bb102:                                         ; preds = %if.end
  %bf.load103 = load i16, ptr %of, align 8, !dbg !5706
  %bf.set108 = or i16 %bf.load103, 20, !dbg !5707
  store i16 %bf.set108, ptr %of, align 8, !dbg !5707
  br label %for.inc, !dbg !5708

sw.bb111:                                         ; preds = %if.end
  %bf.load112 = load i16, ptr %of, align 8, !dbg !5709
  %bf.set114 = or i16 %bf.load112, 64, !dbg !5709
  store i16 %bf.set114, ptr %of, align 8, !dbg !5709
  br label %for.inc, !dbg !5710

sw.bb115:                                         ; preds = %if.end
  %bf.load116 = load i16, ptr %of, align 8, !dbg !5711
  %bf.set118 = or i16 %bf.load116, 4, !dbg !5711
  store i16 %bf.set118, ptr %of, align 8, !dbg !5711
  br label %for.inc, !dbg !5712

sw.bb119:                                         ; preds = %if.end
  %bf.load120 = load i16, ptr %of, align 8, !dbg !5713
  %bf.set122 = or i16 %bf.load120, 2, !dbg !5713
  store i16 %bf.set122, ptr %of, align 8, !dbg !5713
  br label %for.inc, !dbg !5714

sw.bb123:                                         ; preds = %if.end
  %bf.load124 = load i16, ptr %of, align 8, !dbg !5715
  %bf.set126 = or i16 %bf.load124, 256, !dbg !5715
  store i16 %bf.set126, ptr %of, align 8, !dbg !5715
  br label %for.inc, !dbg !5716

sw.bb127:                                         ; preds = %if.end
  %bf.load128 = load i16, ptr %of, align 8, !dbg !5717
  %bf.set130 = or i16 %bf.load128, 8192, !dbg !5717
  store i16 %bf.set130, ptr %of, align 8, !dbg !5717
  br label %for.inc, !dbg !5718

sw.bb131:                                         ; preds = %if.end
  %add.ptr135 = getelementptr inbounds i8, ptr %2, i64 1, !dbg !5719
  %call136 = call zeroext i1 @safe_strtoul(ptr noundef nonnull %add.ptr135, ptr noundef nonnull %client_flags) #13, !dbg !5721
  br i1 %call136, label %for.inc, label %if.then137, !dbg !5722

if.then137:                                       ; preds = %sw.bb131
  %bf.load138 = load i16, ptr %of, align 8, !dbg !5723
  %bf.set140 = or i16 %bf.load138, 1, !dbg !5723
  store i16 %bf.set140, ptr %of, align 8, !dbg !5723
  br label %for.inc, !dbg !5725

sw.bb142:                                         ; preds = %if.end
  %add.ptr146 = getelementptr inbounds i8, ptr %2, i64 1, !dbg !5726
  %call147 = call zeroext i1 @safe_strtoull(ptr noundef nonnull %add.ptr146, ptr noundef nonnull %req_cas_id) #13, !dbg !5728
  br i1 %call147, label %if.else152, label %if.then148, !dbg !5729

if.then148:                                       ; preds = %sw.bb142
  store ptr @.str.56, ptr %errstr, align 8, !dbg !5730, !tbaa !1271
  %bf.load149 = load i16, ptr %of, align 8, !dbg !5732
  %bf.set151 = or i16 %bf.load149, 1, !dbg !5732
  store i16 %bf.set151, ptr %of, align 8, !dbg !5732
  br label %for.inc, !dbg !5733

if.else152:                                       ; preds = %sw.bb142
  %bf.load153 = load i16, ptr %of, align 8, !dbg !5734
  %bf.set155 = or i16 %bf.load153, 512, !dbg !5734
  store i16 %bf.set155, ptr %of, align 8, !dbg !5734
  br label %for.inc

sw.bb157:                                         ; preds = %if.end
  %add.ptr161 = getelementptr inbounds i8, ptr %2, i64 1, !dbg !5736
  %call162 = call zeroext i1 @safe_strtoull(ptr noundef nonnull %add.ptr161, ptr noundef nonnull %cas_id_in) #13, !dbg !5738
  br i1 %call162, label %if.else167, label %if.then163, !dbg !5739

if.then163:                                       ; preds = %sw.bb157
  store ptr @.str.56, ptr %errstr, align 8, !dbg !5740, !tbaa !1271
  %bf.load164 = load i16, ptr %of, align 8, !dbg !5742
  %bf.set166 = or i16 %bf.load164, 1, !dbg !5742
  store i16 %bf.set166, ptr %of, align 8, !dbg !5742
  br label %for.inc, !dbg !5743

if.else167:                                       ; preds = %sw.bb157
  %bf.load168 = load i16, ptr %of, align 8, !dbg !5744
  %bf.set170 = or i16 %bf.load168, 1024, !dbg !5744
  store i16 %bf.set170, ptr %of, align 8, !dbg !5744
  br label %for.inc

sw.bb172:                                         ; preds = %if.end
  %cmp176.not = icmp eq i64 %1, 2, !dbg !5746
  br i1 %cmp176.not, label %if.else182, label %if.then178, !dbg !5748

if.then178:                                       ; preds = %sw.bb172
  store ptr @.str.57, ptr %errstr, align 8, !dbg !5749, !tbaa !1271
  %bf.load179 = load i16, ptr %of, align 8, !dbg !5751
  %bf.set181 = or i16 %bf.load179, 1, !dbg !5751
  store i16 %bf.set181, ptr %of, align 8, !dbg !5751
  br label %for.inc, !dbg !5752

if.else182:                                       ; preds = %sw.bb172
  %arrayidx186 = getelementptr inbounds i8, ptr %2, i64 1, !dbg !5753
  %13 = load i8, ptr %arrayidx186, align 1, !dbg !5753, !tbaa !1240
  store i8 %13, ptr %mode, align 2, !dbg !5755, !tbaa !2956
  br label %for.inc

sw.bb188:                                         ; preds = %if.end
  %add.ptr192 = getelementptr inbounds i8, ptr %2, i64 1, !dbg !5756
  %call193 = call zeroext i1 @safe_strtoull(ptr noundef nonnull %add.ptr192, ptr noundef nonnull %initial) #13, !dbg !5758
  br i1 %call193, label %for.inc, label %if.then194, !dbg !5759

if.then194:                                       ; preds = %sw.bb188
  store ptr @.str.58, ptr %errstr, align 8, !dbg !5760, !tbaa !1271
  %bf.load195 = load i16, ptr %of, align 8, !dbg !5762
  %bf.set197 = or i16 %bf.load195, 1, !dbg !5762
  store i16 %bf.set197, ptr %of, align 8, !dbg !5762
  br label %for.inc, !dbg !5763

sw.bb199:                                         ; preds = %if.end
  %add.ptr203 = getelementptr inbounds i8, ptr %2, i64 1, !dbg !5764
  %call204 = call zeroext i1 @safe_strtoull(ptr noundef nonnull %add.ptr203, ptr noundef nonnull %delta) #13, !dbg !5766
  br i1 %call204, label %for.inc, label %if.then205, !dbg !5767

if.then205:                                       ; preds = %sw.bb199
  store ptr @.str.59, ptr %errstr, align 8, !dbg !5768, !tbaa !1271
  %bf.load206 = load i16, ptr %of, align 8, !dbg !5770
  %bf.set208 = or i16 %bf.load206, 1, !dbg !5770
  store i16 %bf.set208, ptr %of, align 8, !dbg !5770
  br label %for.inc, !dbg !5771

sw.bb210:                                         ; preds = %if.end
  %bf.load211 = load i16, ptr %of, align 8, !dbg !5772
  %bf.set213 = or i16 %bf.load211, 128, !dbg !5772
  store i16 %bf.set213, ptr %of, align 8, !dbg !5772
  br label %for.inc, !dbg !5773

sw.default:                                       ; preds = %if.end
  store ptr @.str.60, ptr %errstr, align 8, !dbg !5774, !tbaa !1271
  br label %cleanup217, !dbg !5775

for.inc:                                          ; preds = %sw.bb199, %if.then205, %sw.bb188, %if.then194, %if.then178, %if.else182, %if.then163, %if.else167, %if.then148, %if.else152, %sw.bb131, %if.then137, %if.end, %if.end, %if.end, %if.end, %if.end, %if.end, %if.end, %if.end, %if.then88, %if.else92, %if.then62, %if.else66, %if.then44, %if.else, %sw.bb210, %sw.bb127, %sw.bb123, %sw.bb119, %sw.bb115, %sw.bb111, %sw.bb102, %if.end27
  %inc = add i32 %i.0307, 1, !dbg !5776
  tail call void @llvm.dbg.value(metadata i32 %inc, metadata !5611, metadata !DIExpression()), !dbg !5623
  %idxprom = zext i32 %inc to i64, !dbg !5629
  %arrayidx = getelementptr inbounds %struct.token_s, ptr %tokens, i64 %idxprom, !dbg !5629
  %length = getelementptr inbounds i8, ptr %arrayidx, i64 8, !dbg !5630
  %14 = load i64, ptr %length, align 8, !dbg !5630, !tbaa !1578
  %cmp.not = icmp eq i64 %14, 0, !dbg !5631
  br i1 %cmp.not, label %for.end, label %for.body, !dbg !5632, !llvm.loop !5777

for.end:                                          ; preds = %for.inc, %entry
  %bf.load214 = load i16, ptr %of, align 8, !dbg !5779
  %15 = and i16 %bf.load214, 1, !dbg !5780
  %sext = sub nsw i16 0, %15, !dbg !5780
  %cond216 = sext i16 %sext to i32, !dbg !5780
  br label %cleanup217, !dbg !5781

cleanup217:                                       ; preds = %if.then, %sw.default, %for.end
  %retval.2 = phi i32 [ %cond216, %for.end ], [ -1, %sw.default ], [ -1, %if.then ], !dbg !5623
  call void @llvm.lifetime.end.p0(i64 127, ptr nonnull %seen) #13, !dbg !5782
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %tmp_int) #13, !dbg !5782
  ret i32 %retval.2, !dbg !5782
}

declare !dbg !5783 ptr @limited_get(ptr noundef, i64 noundef, ptr noundef, i32 noundef, i1 noundef zeroext, i1 noundef zeroext, ptr noundef) local_unnamed_addr #4

declare !dbg !5787 ptr @limited_get_locked(ptr noundef, i64 noundef, ptr noundef, i1 noundef zeroext, ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5790 ptr @item_alloc(ptr noundef, i64 noundef, i32 noundef, i32 noundef, i32 noundef) local_unnamed_addr #4

declare !dbg !5793 i32 @realtime(i64 noundef) local_unnamed_addr #4

declare !dbg !5799 i32 @do_item_link(ptr noundef, i32 noundef, i64 noundef) local_unnamed_addr #4

declare !dbg !5803 i32 @storage_get_item(ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5807 void @resp_add_chunked_iov(ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #4

declare !dbg !5808 void @do_item_remove(ptr noundef) local_unnamed_addr #4

declare !dbg !5809 void @do_item_bump(ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #4

declare !dbg !5812 void @item_unlock(i32 noundef) local_unnamed_addr #4

declare !dbg !5815 i64 @base64_decode(ptr noundef, i64 noundef, ptr noundef, i64 noundef) local_unnamed_addr #4

declare !dbg !5816 zeroext i1 @safe_strtol(ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5819 zeroext i1 @safe_strtoull(ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5822 zeroext i1 @item_size_ok(i64 noundef, i32 noundef, i32 noundef) local_unnamed_addr #4

; Function Attrs: nounwind
declare !dbg !5827 ptr @pthread_getspecific(i32 noundef) local_unnamed_addr #2

declare !dbg !5831 i32 @logger_log(ptr noundef, i32 noundef, ptr noundef, ...) local_unnamed_addr #4

declare !dbg !5835 ptr @item_get_locked(ptr noundef, i64 noundef, ptr noundef, i1 noundef zeroext, ptr noundef) local_unnamed_addr #4

declare !dbg !5838 void @do_item_unlink(ptr noundef, i32 noundef) local_unnamed_addr #4

declare !dbg !5841 void @storage_delete(ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5844 i32 @do_store_item(ptr noundef, i32 noundef, ptr noundef, i32 noundef, ptr noundef, ptr noundef, i64 noundef, i1 noundef zeroext) local_unnamed_addr #4

declare !dbg !5847 void @item_lock(i32 noundef) local_unnamed_addr #4

declare !dbg !5848 i32 @do_add_delta(ptr noundef, ptr noundef, i64 noundef, i1 noundef zeroext, i64 noundef, ptr noundef, ptr noundef, i32 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: nofree nounwind
declare !dbg !5855 noundef i32 @snprintf(ptr noalias nocapture noundef writeonly, i64 noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #5

declare !dbg !5859 void @stats_prefix_record_get(ptr noundef, i64 noundef, i1 noundef zeroext) local_unnamed_addr #4

declare !dbg !5863 void @conn_release_items(ptr noundef) local_unnamed_addr #4

declare !dbg !5864 void @out_of_memory(ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5865 void @stats_prefix_record_set(ptr noundef, i64 noundef) local_unnamed_addr #4

declare !dbg !5868 ptr @item_get(ptr noundef, i64 noundef, ptr noundef, i1 noundef zeroext) local_unnamed_addr #4

declare !dbg !5871 void @item_unlink(ptr noundef) local_unnamed_addr #4

declare !dbg !5872 void @server_stats(ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5880 void @append_stats(ptr noundef, i16 noundef zeroext, ptr noundef, i32 noundef, ptr noundef) #4

declare !dbg !5881 zeroext i1 @get_stats(ptr noundef, i32 noundef, ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5884 void @stats_reset() local_unnamed_addr #4

; Function Attrs: inlinehint nounwind sanitize_thread uwtable
define internal fastcc void @process_stats_detail(ptr noundef %c, ptr nocapture noundef readonly %command) unnamed_addr #6 !dbg !5887 {
entry:
  %len = alloca i32, align 4, !DIAssignID !5897
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !5891, metadata !DIExpression(), metadata !5897, metadata ptr %len, metadata !DIExpression()), !dbg !5898
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !5889, metadata !DIExpression()), !dbg !5899
  tail call void @llvm.dbg.value(metadata ptr %command, metadata !5890, metadata !DIExpression()), !dbg !5899
  %0 = load i8, ptr %command, align 1
  %.not = icmp eq i8 %0, 111
  br i1 %.not, label %sub_1, label %if.else

sub_1:                                            ; preds = %entry
  %1 = getelementptr inbounds i8, ptr %command, i64 1
  %2 = load i8, ptr %1, align 1
  %.not17 = icmp eq i8 %2, 110
  br i1 %.not17, label %entry.tail, label %if.else

entry.tail:                                       ; preds = %sub_1
  %3 = getelementptr inbounds i8, ptr %command, i64 2
  %4 = load i8, ptr %3, align 1
  %5 = icmp eq i8 %4, 0, !dbg !5900
  br i1 %5, label %if.then, label %if.else, !dbg !5901

if.then:                                          ; preds = %entry.tail
  store i32 1, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 16), align 8, !dbg !5902, !tbaa !3845
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.95) #13, !dbg !5904
  br label %if.end11, !dbg !5905

if.else:                                          ; preds = %sub_1, %entry, %entry.tail
  %call1 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %command, ptr noundef nonnull dereferenceable(4) @.str.96) #15, !dbg !5906
  %cmp2 = icmp eq i32 %call1, 0, !dbg !5907
  br i1 %cmp2, label %if.then3, label %if.else4, !dbg !5908

if.then3:                                         ; preds = %if.else
  store i32 0, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 16), align 8, !dbg !5909, !tbaa !3845
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.95) #13, !dbg !5911
  br label %if.end11, !dbg !5912

if.else4:                                         ; preds = %if.else
  %call5 = tail call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %command, ptr noundef nonnull dereferenceable(5) @.str.97) #15, !dbg !5913
  %cmp6 = icmp eq i32 %call5, 0, !dbg !5914
  br i1 %cmp6, label %if.then7, label %if.else9, !dbg !5915

if.then7:                                         ; preds = %if.else4
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %len) #13, !dbg !5916
  %call8 = call ptr @stats_prefix_dump(ptr noundef nonnull %len) #13, !dbg !5917
  tail call void @llvm.dbg.value(metadata ptr %call8, metadata !5896, metadata !DIExpression()), !dbg !5898
  %6 = load i32, ptr %len, align 4, !dbg !5918, !tbaa !1231
  call void @write_and_free(ptr noundef %c, ptr noundef %call8, i32 noundef %6) #13, !dbg !5919
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %len) #13, !dbg !5920
  br label %if.end11, !dbg !5921

if.else9:                                         ; preds = %if.else4
  tail call void @out_string(ptr noundef %c, ptr noundef nonnull @.str.98) #13, !dbg !5922
  br label %if.end11

if.end11:                                         ; preds = %if.then3, %if.else9, %if.then7, %if.then
  ret void, !dbg !5924
}

declare !dbg !5925 void @process_stat_settings(ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5926 ptr @item_cachedump(i32 noundef, i32 noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5931 void @write_and_free(ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #4

declare !dbg !5934 void @process_stats_conns(ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5935 void @process_extstore_stats(ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5936 ptr @stats_prefix_dump(ptr noundef) local_unnamed_addr #4

; Function Attrs: nounwind
declare !dbg !5939 i32 @raise(i32 noundef) local_unnamed_addr #2

declare !dbg !5943 i32 @slabs_reassign(i32 noundef, i32 noundef) local_unnamed_addr #4

declare !dbg !5946 zeroext i1 @safe_strtod(ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5950 zeroext i1 @slabs_adjust_mem_limit(i64 noundef) local_unnamed_addr #4

declare !dbg !5953 i32 @add_delta(ptr noundef, ptr noundef, i64 noundef, i1 noundef zeroext, i64 noundef, ptr noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5956 void @stats_prefix_record_delete(ptr noundef, i64 noundef) local_unnamed_addr #4

declare !dbg !5957 ptr @item_touch(ptr noundef, i64 noundef, i32 noundef, ptr noundef) local_unnamed_addr #4

declare !dbg !5960 void @item_flush_expired() local_unnamed_addr #4

declare !dbg !5961 i32 @lru_crawler_crawl(ptr noundef, i32 noundef, ptr noundef, i32 noundef, i32 noundef) local_unnamed_addr #4

declare !dbg !5964 zeroext i1 @resp_has_stack(ptr noundef) local_unnamed_addr #4

declare !dbg !5965 i32 @event_del(ptr noundef) local_unnamed_addr #4

declare !dbg !5969 i32 @start_item_crawler_thread() local_unnamed_addr #4

declare !dbg !5972 i32 @stop_item_crawler_thread(i1 noundef zeroext) local_unnamed_addr #4

declare !dbg !5975 i32 @logger_add_watcher(ptr noundef, i32 noundef, i16 noundef zeroext) local_unnamed_addr #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fshl.i32(i32, i32, i32) #9

; Function Attrs: nofree nounwind willreturn memory(argmem: read)
declare i32 @bcmp(ptr nocapture, ptr nocapture, i64) local_unnamed_addr #10

; Function Attrs: nofree nounwind
declare noundef i32 @fputc(i32 noundef, ptr nocapture noundef) local_unnamed_addr #11

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #9

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #12 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #9

attributes #0 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress nofree nounwind willreturn memory(argmem: read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { inlinehint nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #9 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { nofree nounwind willreturn memory(argmem: read) }
attributes #11 = { nofree nounwind }
attributes #12 = { nounwind uwtable }
attributes #13 = { nounwind }
attributes #14 = { nobuiltin }
attributes #15 = { nobuiltin nounwind willreturn memory(read) }
attributes #16 = { nounwind willreturn memory(read) }
attributes #17 = { cold nounwind }

!llvm.dbg.cu = !{!460}
!llvm.module.flags = !{!769, !770, !771, !772, !773, !774, !775}
!llvm.ident = !{!776}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(scope: null, file: !2, line: 148, type: !3, isLocal: true, isDefinition: true)
!2 = !DIFile(filename: "proto_text.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "2d3226f3f9e34eef93eb776720991a99")
!3 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 24, elements: !5)
!4 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!5 = !{!6}
!6 = !DISubrange(count: 3)
!7 = !DIGlobalVariableExpression(var: !8, expr: !DIExpression())
!8 = distinct !DIGlobalVariable(scope: null, file: !2, line: 180, type: !9, isLocal: true, isDefinition: true)
!9 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 224, elements: !10)
!10 = !{!11}
!11 = !DISubrange(count: 28)
!12 = !DIGlobalVariableExpression(var: !13, expr: !DIExpression())
!13 = distinct !DIGlobalVariable(scope: null, file: !2, line: 221, type: !14, isLocal: true, isDefinition: true)
!14 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 56, elements: !15)
!15 = !{!16}
!16 = !DISubrange(count: 7)
!17 = !DIGlobalVariableExpression(var: !18, expr: !DIExpression())
!18 = distinct !DIGlobalVariable(scope: null, file: !2, line: 224, type: !14, isLocal: true, isDefinition: true)
!19 = !DIGlobalVariableExpression(var: !20, expr: !DIExpression())
!20 = distinct !DIGlobalVariable(scope: null, file: !2, line: 227, type: !21, isLocal: true, isDefinition: true)
!21 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 80, elements: !22)
!22 = !{!23}
!23 = !DISubrange(count: 10)
!24 = !DIGlobalVariableExpression(var: !25, expr: !DIExpression())
!25 = distinct !DIGlobalVariable(scope: null, file: !2, line: 230, type: !26, isLocal: true, isDefinition: true)
!26 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 88, elements: !27)
!27 = !{!28}
!28 = !DISubrange(count: 11)
!29 = !DIGlobalVariableExpression(var: !30, expr: !DIExpression())
!30 = distinct !DIGlobalVariable(scope: null, file: !2, line: 233, type: !31, isLocal: true, isDefinition: true)
!31 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 296, elements: !32)
!32 = !{!33}
!33 = !DISubrange(count: 37)
!34 = !DIGlobalVariableExpression(var: !35, expr: !DIExpression())
!35 = distinct !DIGlobalVariable(scope: null, file: !2, line: 374, type: !36, isLocal: true, isDefinition: true)
!36 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 32, elements: !37)
!37 = !{!38}
!38 = !DISubrange(count: 4)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(scope: null, file: !2, line: 382, type: !41, isLocal: true, isDefinition: true)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 232, elements: !42)
!42 = !{!43}
!43 = !DISubrange(count: 29)
!44 = !DIGlobalVariableExpression(var: !45, expr: !DIExpression())
!45 = distinct !DIGlobalVariable(scope: null, file: !2, line: 416, type: !46, isLocal: true, isDefinition: true)
!46 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 336, elements: !47)
!47 = !{!48}
!48 = !DISubrange(count: 42)
!49 = !DIGlobalVariableExpression(var: !50, expr: !DIExpression())
!50 = distinct !DIGlobalVariable(scope: null, file: !2, line: 425, type: !51, isLocal: true, isDefinition: true)
!51 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 360, elements: !52)
!52 = !{!53}
!53 = !DISubrange(count: 45)
!54 = !DIGlobalVariableExpression(var: !55, expr: !DIExpression())
!55 = distinct !DIGlobalVariable(scope: null, file: !2, line: 437, type: !56, isLocal: true, isDefinition: true)
!56 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 288, elements: !57)
!57 = !{!58}
!58 = !DISubrange(count: 36)
!59 = !DIGlobalVariableExpression(var: !60, expr: !DIExpression())
!60 = distinct !DIGlobalVariable(scope: null, file: !2, line: 466, type: !61, isLocal: true, isDefinition: true)
!61 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 40, elements: !62)
!62 = !{!63}
!63 = !DISubrange(count: 5)
!64 = !DIGlobalVariableExpression(var: !65, expr: !DIExpression())
!65 = distinct !DIGlobalVariable(scope: null, file: !2, line: 466, type: !66, isLocal: true, isDefinition: true)
!66 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 48, elements: !67)
!67 = !{!68}
!68 = !DISubrange(count: 6)
!69 = !DIGlobalVariableExpression(var: !70, expr: !DIExpression())
!70 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2836, type: !71, isLocal: true, isDefinition: true)
!71 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 64, elements: !72)
!72 = !{!73}
!73 = !DISubrange(count: 8)
!74 = !DIGlobalVariableExpression(var: !75, expr: !DIExpression())
!75 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2854, type: !66, isLocal: true, isDefinition: true)
!76 = !DIGlobalVariableExpression(var: !77, expr: !DIExpression())
!77 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2872, type: !3, isLocal: true, isDefinition: true)
!78 = !DIGlobalVariableExpression(var: !79, expr: !DIExpression())
!79 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2889, type: !36, isLocal: true, isDefinition: true)
!80 = !DIGlobalVariableExpression(var: !81, expr: !DIExpression())
!81 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2892, type: !61, isLocal: true, isDefinition: true)
!82 = !DIGlobalVariableExpression(var: !83, expr: !DIExpression())
!83 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2895, type: !36, isLocal: true, isDefinition: true)
!84 = !DIGlobalVariableExpression(var: !85, expr: !DIExpression())
!85 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2898, type: !61, isLocal: true, isDefinition: true)
!86 = !DIGlobalVariableExpression(var: !87, expr: !DIExpression())
!87 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2909, type: !66, isLocal: true, isDefinition: true)
!88 = !DIGlobalVariableExpression(var: !89, expr: !DIExpression())
!89 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2912, type: !90, isLocal: true, isDefinition: true)
!90 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 72, elements: !91)
!91 = !{!92}
!92 = !DISubrange(count: 9)
!93 = !DIGlobalVariableExpression(var: !94, expr: !DIExpression())
!94 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2915, type: !66, isLocal: true, isDefinition: true)
!95 = !DIGlobalVariableExpression(var: !96, expr: !DIExpression())
!96 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2922, type: !36, isLocal: true, isDefinition: true)
!97 = !DIGlobalVariableExpression(var: !98, expr: !DIExpression())
!98 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2923, type: !14, isLocal: true, isDefinition: true)
!99 = !DIGlobalVariableExpression(var: !100, expr: !DIExpression())
!100 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2931, type: !36, isLocal: true, isDefinition: true)
!101 = !DIGlobalVariableExpression(var: !102, expr: !DIExpression())
!102 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2935, type: !103, isLocal: true, isDefinition: true)
!103 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 120, elements: !104)
!104 = !{!105}
!105 = !DISubrange(count: 15)
!106 = !DIGlobalVariableExpression(var: !107, expr: !DIExpression())
!107 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2943, type: !61, isLocal: true, isDefinition: true)
!108 = !DIGlobalVariableExpression(var: !109, expr: !DIExpression())
!109 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2951, type: !14, isLocal: true, isDefinition: true)
!110 = !DIGlobalVariableExpression(var: !111, expr: !DIExpression())
!111 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2955, type: !61, isLocal: true, isDefinition: true)
!112 = !DIGlobalVariableExpression(var: !113, expr: !DIExpression())
!113 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2968, type: !66, isLocal: true, isDefinition: true)
!114 = !DIGlobalVariableExpression(var: !115, expr: !DIExpression())
!115 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2976, type: !71, isLocal: true, isDefinition: true)
!116 = !DIGlobalVariableExpression(var: !117, expr: !DIExpression())
!117 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2977, type: !71, isLocal: true, isDefinition: true)
!118 = !DIGlobalVariableExpression(var: !119, expr: !DIExpression())
!119 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2982, type: !61, isLocal: true, isDefinition: true)
!120 = !DIGlobalVariableExpression(var: !121, expr: !DIExpression())
!121 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2989, type: !21, isLocal: true, isDefinition: true)
!122 = !DIGlobalVariableExpression(var: !123, expr: !DIExpression())
!123 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2994, type: !71, isLocal: true, isDefinition: true)
!124 = !DIGlobalVariableExpression(var: !125, expr: !DIExpression())
!125 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2998, type: !61, isLocal: true, isDefinition: true)
!126 = !DIGlobalVariableExpression(var: !127, expr: !DIExpression())
!127 = distinct !DIGlobalVariable(scope: null, file: !2, line: 3002, type: !128, isLocal: true, isDefinition: true)
!128 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 96, elements: !129)
!129 = !{!130}
!130 = !DISubrange(count: 12)
!131 = !DIGlobalVariableExpression(var: !132, expr: !DIExpression())
!132 = distinct !DIGlobalVariable(scope: null, file: !2, line: 3006, type: !66, isLocal: true, isDefinition: true)
!133 = !DIGlobalVariableExpression(var: !134, expr: !DIExpression())
!134 = distinct !DIGlobalVariable(scope: null, file: !2, line: 3010, type: !21, isLocal: true, isDefinition: true)
!135 = !DIGlobalVariableExpression(var: !136, expr: !DIExpression())
!136 = distinct !DIGlobalVariable(scope: null, file: !2, line: 3013, type: !36, isLocal: true, isDefinition: true)
!137 = !DIGlobalVariableExpression(var: !138, expr: !DIExpression())
!138 = distinct !DIGlobalVariable(scope: null, file: !2, line: 3022, type: !90, isLocal: true, isDefinition: true)
!139 = !DIGlobalVariableExpression(var: !140, expr: !DIExpression())
!140 = distinct !DIGlobalVariable(scope: null, file: !2, line: 3031, type: !66, isLocal: true, isDefinition: true)
!141 = !DIGlobalVariableExpression(var: !142, expr: !DIExpression())
!142 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1088, type: !31, isLocal: true, isDefinition: true)
!143 = !DIGlobalVariableExpression(var: !144, expr: !DIExpression())
!144 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1106, type: !145, isLocal: true, isDefinition: true)
!145 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 320, elements: !146)
!146 = !{!147}
!147 = !DISubrange(count: 40)
!148 = !DIGlobalVariableExpression(var: !149, expr: !DIExpression())
!149 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1137, type: !150, isLocal: true, isDefinition: true)
!150 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 352, elements: !151)
!151 = !{!152}
!152 = !DISubrange(count: 44)
!153 = !DIGlobalVariableExpression(var: !154, expr: !DIExpression())
!154 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1162, type: !36, isLocal: true, isDefinition: true)
!155 = !DIGlobalVariableExpression(var: !156, expr: !DIExpression())
!156 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1235, type: !157, isLocal: true, isDefinition: true)
!157 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 280, elements: !158)
!158 = !{!159}
!159 = !DISubrange(count: 35)
!160 = !DIGlobalVariableExpression(var: !161, expr: !DIExpression())
!161 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1361, type: !3, isLocal: true, isDefinition: true)
!162 = !DIGlobalVariableExpression(var: !163, expr: !DIExpression())
!163 = distinct !DIGlobalVariable(scope: null, file: !2, line: 944, type: !9, isLocal: true, isDefinition: true)
!164 = !DIGlobalVariableExpression(var: !165, expr: !DIExpression())
!165 = distinct !DIGlobalVariable(scope: null, file: !2, line: 956, type: !166, isLocal: true, isDefinition: true)
!166 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 256, elements: !167)
!167 = !{!168}
!168 = !DISubrange(count: 32)
!169 = !DIGlobalVariableExpression(var: !170, expr: !DIExpression())
!170 = distinct !DIGlobalVariable(scope: null, file: !2, line: 969, type: !171, isLocal: true, isDefinition: true)
!171 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 368, elements: !172)
!172 = !{!173}
!173 = !DISubrange(count: 46)
!174 = !DIGlobalVariableExpression(var: !175, expr: !DIExpression())
!175 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1047, type: !46, isLocal: true, isDefinition: true)
!176 = !DIGlobalVariableExpression(var: !177, expr: !DIExpression())
!177 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1055, type: !178, isLocal: true, isDefinition: true)
!178 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 344, elements: !179)
!179 = !{!180}
!180 = !DISubrange(count: 43)
!181 = !DIGlobalVariableExpression(var: !182, expr: !DIExpression())
!182 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1061, type: !183, isLocal: true, isDefinition: true)
!183 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 328, elements: !184)
!184 = !{!185}
!185 = !DISubrange(count: 41)
!186 = !DIGlobalVariableExpression(var: !187, expr: !DIExpression())
!187 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1069, type: !188, isLocal: true, isDefinition: true)
!188 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 208, elements: !189)
!189 = !{!190}
!190 = !DISubrange(count: 26)
!191 = !DIGlobalVariableExpression(var: !192, expr: !DIExpression())
!192 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1426, type: !56, isLocal: true, isDefinition: true)
!193 = !DIGlobalVariableExpression(var: !194, expr: !DIExpression())
!194 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1519, type: !183, isLocal: true, isDefinition: true)
!195 = !DIGlobalVariableExpression(var: !196, expr: !DIExpression())
!196 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1544, type: !145, isLocal: true, isDefinition: true)
!197 = !DIGlobalVariableExpression(var: !198, expr: !DIExpression())
!198 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1550, type: !46, isLocal: true, isDefinition: true)
!199 = !DIGlobalVariableExpression(var: !200, expr: !DIExpression())
!200 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1642, type: !201, isLocal: true, isDefinition: true)
!201 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 312, elements: !202)
!202 = !{!203}
!203 = !DISubrange(count: 39)
!204 = !DIGlobalVariableExpression(var: !205, expr: !DIExpression())
!205 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1698, type: !206, isLocal: true, isDefinition: true)
!206 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 216, elements: !207)
!207 = !{!208}
!208 = !DISubrange(count: 27)
!209 = !DIGlobalVariableExpression(var: !210, expr: !DIExpression())
!210 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1821, type: !183, isLocal: true, isDefinition: true)
!211 = !DIGlobalVariableExpression(var: !212, expr: !DIExpression())
!212 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1848, type: !213, isLocal: true, isDefinition: true)
!213 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 488, elements: !214)
!214 = !{!215}
!215 = !DISubrange(count: 61)
!216 = !DIGlobalVariableExpression(var: !217, expr: !DIExpression())
!217 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1872, type: !218, isLocal: true, isDefinition: true)
!218 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 376, elements: !219)
!219 = !{!220}
!220 = !DISubrange(count: 47)
!221 = !DIGlobalVariableExpression(var: !222, expr: !DIExpression())
!222 = distinct !DIGlobalVariable(scope: null, file: !2, line: 869, type: !36, isLocal: true, isDefinition: true)
!223 = !DIGlobalVariableExpression(var: !224, expr: !DIExpression())
!224 = distinct !DIGlobalVariable(scope: null, file: !2, line: 884, type: !225, isLocal: true, isDefinition: true)
!225 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 408, elements: !226)
!226 = !{!227}
!227 = !DISubrange(count: 51)
!228 = !DIGlobalVariableExpression(var: !229, expr: !DIExpression())
!229 = distinct !DIGlobalVariable(scope: null, file: !2, line: 888, type: !36, isLocal: true, isDefinition: true)
!230 = !DIGlobalVariableExpression(var: !231, expr: !DIExpression())
!231 = distinct !DIGlobalVariable(scope: null, file: !2, line: 888, type: !3, isLocal: true, isDefinition: true)
!232 = !DIGlobalVariableExpression(var: !233, expr: !DIExpression())
!233 = distinct !DIGlobalVariable(scope: null, file: !2, line: 563, type: !234, isLocal: true, isDefinition: true)
!234 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 304, elements: !235)
!235 = !{!236}
!236 = !DISubrange(count: 38)
!237 = !DIGlobalVariableExpression(var: !238, expr: !DIExpression())
!238 = distinct !DIGlobalVariable(scope: null, file: !2, line: 599, type: !14, isLocal: true, isDefinition: true)
!239 = !DIGlobalVariableExpression(var: !240, expr: !DIExpression())
!240 = distinct !DIGlobalVariable(scope: null, file: !2, line: 632, type: !241, isLocal: true, isDefinition: true)
!241 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 136, elements: !242)
!242 = !{!243}
!243 = !DISubrange(count: 17)
!244 = !DIGlobalVariableExpression(var: !245, expr: !DIExpression())
!245 = distinct !DIGlobalVariable(scope: null, file: !2, line: 695, type: !90, isLocal: true, isDefinition: true)
!246 = !DIGlobalVariableExpression(var: !247, expr: !DIExpression())
!247 = distinct !DIGlobalVariable(scope: null, file: !2, line: 714, type: !248, isLocal: true, isDefinition: true)
!248 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 384, elements: !249)
!249 = !{!250}
!250 = !DISubrange(count: 48)
!251 = !DIGlobalVariableExpression(var: !252, expr: !DIExpression())
!252 = distinct !DIGlobalVariable(scope: null, file: !2, line: 718, type: !66, isLocal: true, isDefinition: true)
!253 = !DIGlobalVariableExpression(var: !254, expr: !DIExpression())
!254 = distinct !DIGlobalVariable(scope: null, file: !2, line: 517, type: !71, isLocal: true, isDefinition: true)
!255 = !DIGlobalVariableExpression(var: !256, expr: !DIExpression())
!256 = distinct !DIGlobalVariable(scope: null, file: !2, line: 749, type: !257, isLocal: true, isDefinition: true)
!257 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 240, elements: !258)
!258 = !{!259}
!259 = !DISubrange(count: 30)
!260 = !DIGlobalVariableExpression(var: !261, expr: !DIExpression())
!261 = distinct !DIGlobalVariable(scope: null, file: !2, line: 756, type: !66, isLocal: true, isDefinition: true)
!262 = !DIGlobalVariableExpression(var: !263, expr: !DIExpression())
!263 = distinct !DIGlobalVariable(scope: null, file: !2, line: 758, type: !66, isLocal: true, isDefinition: true)
!264 = !DIGlobalVariableExpression(var: !265, expr: !DIExpression())
!265 = distinct !DIGlobalVariable(scope: null, file: !2, line: 760, type: !14, isLocal: true, isDefinition: true)
!266 = !DIGlobalVariableExpression(var: !267, expr: !DIExpression())
!267 = distinct !DIGlobalVariable(scope: null, file: !2, line: 763, type: !268, isLocal: true, isDefinition: true)
!268 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 8, elements: !269)
!269 = !{!270}
!270 = !DISubrange(count: 1)
!271 = !DIGlobalVariableExpression(var: !272, expr: !DIExpression())
!272 = distinct !DIGlobalVariable(scope: null, file: !2, line: 768, type: !90, isLocal: true, isDefinition: true)
!273 = !DIGlobalVariableExpression(var: !274, expr: !DIExpression())
!274 = distinct !DIGlobalVariable(scope: null, file: !2, line: 770, type: !21, isLocal: true, isDefinition: true)
!275 = !DIGlobalVariableExpression(var: !276, expr: !DIExpression())
!276 = distinct !DIGlobalVariable(scope: null, file: !2, line: 775, type: !183, isLocal: true, isDefinition: true)
!277 = !DIGlobalVariableExpression(var: !278, expr: !DIExpression())
!278 = distinct !DIGlobalVariable(scope: null, file: !2, line: 791, type: !41, isLocal: true, isDefinition: true)
!279 = !DIGlobalVariableExpression(var: !280, expr: !DIExpression())
!280 = distinct !DIGlobalVariable(scope: null, file: !2, line: 798, type: !66, isLocal: true, isDefinition: true)
!281 = !DIGlobalVariableExpression(var: !282, expr: !DIExpression())
!282 = distinct !DIGlobalVariable(scope: null, file: !2, line: 817, type: !183, isLocal: true, isDefinition: true)
!283 = !DIGlobalVariableExpression(var: !284, expr: !DIExpression())
!284 = distinct !DIGlobalVariable(scope: null, file: !2, line: 728, type: !3, isLocal: true, isDefinition: true)
!285 = !DIGlobalVariableExpression(var: !286, expr: !DIExpression())
!286 = distinct !DIGlobalVariable(scope: null, file: !2, line: 730, type: !36, isLocal: true, isDefinition: true)
!287 = !DIGlobalVariableExpression(var: !288, expr: !DIExpression())
!288 = distinct !DIGlobalVariable(scope: null, file: !2, line: 734, type: !61, isLocal: true, isDefinition: true)
!289 = !DIGlobalVariableExpression(var: !290, expr: !DIExpression())
!290 = distinct !DIGlobalVariable(scope: null, file: !2, line: 740, type: !51, isLocal: true, isDefinition: true)
!291 = !DIGlobalVariableExpression(var: !292, expr: !DIExpression())
!292 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2598, type: !9, isLocal: true, isDefinition: true)
!293 = !DIGlobalVariableExpression(var: !294, expr: !DIExpression())
!294 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2606, type: !90, isLocal: true, isDefinition: true)
!295 = !DIGlobalVariableExpression(var: !296, expr: !DIExpression())
!296 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2611, type: !157, isLocal: true, isDefinition: true)
!297 = !DIGlobalVariableExpression(var: !298, expr: !DIExpression())
!298 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2616, type: !90, isLocal: true, isDefinition: true)
!299 = !DIGlobalVariableExpression(var: !300, expr: !DIExpression())
!300 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2620, type: !145, isLocal: true, isDefinition: true)
!301 = !DIGlobalVariableExpression(var: !302, expr: !DIExpression())
!302 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2636, type: !178, isLocal: true, isDefinition: true)
!303 = !DIGlobalVariableExpression(var: !304, expr: !DIExpression())
!304 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2639, type: !31, isLocal: true, isDefinition: true)
!305 = !DIGlobalVariableExpression(var: !306, expr: !DIExpression())
!306 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2642, type: !145, isLocal: true, isDefinition: true)
!307 = !DIGlobalVariableExpression(var: !308, expr: !DIExpression())
!308 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2645, type: !31, isLocal: true, isDefinition: true)
!309 = !DIGlobalVariableExpression(var: !310, expr: !DIExpression())
!310 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2650, type: !90, isLocal: true, isDefinition: true)
!311 = !DIGlobalVariableExpression(var: !312, expr: !DIExpression())
!312 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2316, type: !66, isLocal: true, isDefinition: true)
!313 = !DIGlobalVariableExpression(var: !314, expr: !DIExpression())
!314 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2412, type: !315, isLocal: true, isDefinition: true)
!315 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 440, elements: !316)
!316 = !{!317}
!317 = !DISubrange(count: 55)
!318 = !DIGlobalVariableExpression(var: !319, expr: !DIExpression())
!319 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2415, type: !320, isLocal: true, isDefinition: true)
!320 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 464, elements: !321)
!321 = !{!322}
!322 = !DISubrange(count: 58)
!323 = !DIGlobalVariableExpression(var: !324, expr: !DIExpression())
!324 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2418, type: !9, isLocal: true, isDefinition: true)
!325 = !DIGlobalVariableExpression(var: !326, expr: !DIExpression())
!326 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2423, type: !327, isLocal: true, isDefinition: true)
!327 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 456, elements: !328)
!328 = !{!329}
!329 = !DISubrange(count: 57)
!330 = !DIGlobalVariableExpression(var: !331, expr: !DIExpression())
!331 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2160, type: !150, isLocal: true, isDefinition: true)
!332 = !DIGlobalVariableExpression(var: !333, expr: !DIExpression())
!333 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2205, type: !334, isLocal: true, isDefinition: true)
!334 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 552, elements: !335)
!335 = !{!336}
!336 = !DISubrange(count: 69)
!337 = !DIGlobalVariableExpression(var: !338, expr: !DIExpression())
!338 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2235, type: !71, isLocal: true, isDefinition: true)
!339 = !DIGlobalVariableExpression(var: !340, expr: !DIExpression())
!340 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2129, type: !71, isLocal: true, isDefinition: true)
!341 = !DIGlobalVariableExpression(var: !342, expr: !DIExpression())
!342 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2558, type: !157, isLocal: true, isDefinition: true)
!343 = !DIGlobalVariableExpression(var: !344, expr: !DIExpression())
!344 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2587, type: !103, isLocal: true, isDefinition: true)
!345 = !DIGlobalVariableExpression(var: !346, expr: !DIExpression())
!346 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2658, type: !66, isLocal: true, isDefinition: true)
!347 = !DIGlobalVariableExpression(var: !348, expr: !DIExpression())
!348 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2661, type: !349, isLocal: true, isDefinition: true)
!349 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 272, elements: !350)
!350 = !{!351}
!351 = !DISubrange(count: 34)
!352 = !DIGlobalVariableExpression(var: !353, expr: !DIExpression())
!353 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2672, type: !46, isLocal: true, isDefinition: true)
!354 = !DIGlobalVariableExpression(var: !355, expr: !DIExpression())
!355 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2675, type: !188, isLocal: true, isDefinition: true)
!356 = !DIGlobalVariableExpression(var: !357, expr: !DIExpression())
!357 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2678, type: !41, isLocal: true, isDefinition: true)
!358 = !DIGlobalVariableExpression(var: !359, expr: !DIExpression())
!359 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2681, type: !166, isLocal: true, isDefinition: true)
!360 = !DIGlobalVariableExpression(var: !361, expr: !DIExpression())
!361 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2685, type: !90, isLocal: true, isDefinition: true)
!362 = !DIGlobalVariableExpression(var: !363, expr: !DIExpression())
!363 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2691, type: !206, isLocal: true, isDefinition: true)
!364 = !DIGlobalVariableExpression(var: !365, expr: !DIExpression())
!365 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2695, type: !366, isLocal: true, isDefinition: true)
!366 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 424, elements: !367)
!367 = !{!368}
!368 = !DISubrange(count: 53)
!369 = !DIGlobalVariableExpression(var: !370, expr: !DIExpression())
!370 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2726, type: !14, isLocal: true, isDefinition: true)
!371 = !DIGlobalVariableExpression(var: !372, expr: !DIExpression())
!372 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2732, type: !206, isLocal: true, isDefinition: true)
!373 = !DIGlobalVariableExpression(var: !374, expr: !DIExpression())
!374 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2736, type: !225, isLocal: true, isDefinition: true)
!375 = !DIGlobalVariableExpression(var: !376, expr: !DIExpression())
!376 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2761, type: !71, isLocal: true, isDefinition: true)
!377 = !DIGlobalVariableExpression(var: !378, expr: !DIExpression())
!378 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2770, type: !66, isLocal: true, isDefinition: true)
!379 = !DIGlobalVariableExpression(var: !380, expr: !DIExpression())
!380 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2777, type: !171, isLocal: true, isDefinition: true)
!381 = !DIGlobalVariableExpression(var: !382, expr: !DIExpression())
!382 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2784, type: !14, isLocal: true, isDefinition: true)
!383 = !DIGlobalVariableExpression(var: !384, expr: !DIExpression())
!384 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2788, type: !183, isLocal: true, isDefinition: true)
!385 = !DIGlobalVariableExpression(var: !386, expr: !DIExpression())
!386 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2790, type: !71, isLocal: true, isDefinition: true)
!387 = !DIGlobalVariableExpression(var: !388, expr: !DIExpression())
!388 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2794, type: !145, isLocal: true, isDefinition: true)
!389 = !DIGlobalVariableExpression(var: !390, expr: !DIExpression())
!390 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2348, type: !145, isLocal: true, isDefinition: true)
!391 = !DIGlobalVariableExpression(var: !392, expr: !DIExpression())
!392 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2353, type: !393, isLocal: true, isDefinition: true)
!393 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 400, elements: !394)
!394 = !{!395}
!395 = !DISubrange(count: 50)
!396 = !DIGlobalVariableExpression(var: !397, expr: !DIExpression())
!397 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2359, type: !71, isLocal: true, isDefinition: true)
!398 = !DIGlobalVariableExpression(var: !399, expr: !DIExpression())
!399 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2361, type: !21, isLocal: true, isDefinition: true)
!400 = !DIGlobalVariableExpression(var: !401, expr: !DIExpression())
!401 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2363, type: !90, isLocal: true, isDefinition: true)
!402 = !DIGlobalVariableExpression(var: !403, expr: !DIExpression())
!403 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2365, type: !21, isLocal: true, isDefinition: true)
!404 = !DIGlobalVariableExpression(var: !405, expr: !DIExpression())
!405 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2367, type: !21, isLocal: true, isDefinition: true)
!406 = !DIGlobalVariableExpression(var: !407, expr: !DIExpression())
!407 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2369, type: !26, isLocal: true, isDefinition: true)
!408 = !DIGlobalVariableExpression(var: !409, expr: !DIExpression())
!409 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2371, type: !21, isLocal: true, isDefinition: true)
!410 = !DIGlobalVariableExpression(var: !411, expr: !DIExpression())
!411 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2373, type: !128, isLocal: true, isDefinition: true)
!412 = !DIGlobalVariableExpression(var: !413, expr: !DIExpression())
!413 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2375, type: !21, isLocal: true, isDefinition: true)
!414 = !DIGlobalVariableExpression(var: !415, expr: !DIExpression())
!415 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2377, type: !21, isLocal: true, isDefinition: true)
!416 = !DIGlobalVariableExpression(var: !417, expr: !DIExpression())
!417 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2390, type: !178, isLocal: true, isDefinition: true)
!418 = !DIGlobalVariableExpression(var: !419, expr: !DIExpression())
!419 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2393, type: !183, isLocal: true, isDefinition: true)
!420 = !DIGlobalVariableExpression(var: !421, expr: !DIExpression())
!421 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2438, type: !61, isLocal: true, isDefinition: true)
!422 = !DIGlobalVariableExpression(var: !423, expr: !DIExpression())
!423 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2446, type: !178, isLocal: true, isDefinition: true)
!424 = !DIGlobalVariableExpression(var: !425, expr: !DIExpression())
!425 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2448, type: !393, isLocal: true, isDefinition: true)
!426 = !DIGlobalVariableExpression(var: !427, expr: !DIExpression())
!427 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2457, type: !61, isLocal: true, isDefinition: true)
!428 = !DIGlobalVariableExpression(var: !429, expr: !DIExpression())
!429 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2459, type: !61, isLocal: true, isDefinition: true)
!430 = !DIGlobalVariableExpression(var: !431, expr: !DIExpression())
!431 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2462, type: !21, isLocal: true, isDefinition: true)
!432 = !DIGlobalVariableExpression(var: !433, expr: !DIExpression())
!433 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2468, type: !90, isLocal: true, isDefinition: true)
!434 = !DIGlobalVariableExpression(var: !435, expr: !DIExpression())
!435 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2491, type: !103, isLocal: true, isDefinition: true)
!436 = !DIGlobalVariableExpression(var: !437, expr: !DIExpression())
!437 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2505, type: !21, isLocal: true, isDefinition: true)
!438 = !DIGlobalVariableExpression(var: !439, expr: !DIExpression())
!439 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2508, type: !90, isLocal: true, isDefinition: true)
!440 = !DIGlobalVariableExpression(var: !441, expr: !DIExpression())
!441 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2511, type: !71, isLocal: true, isDefinition: true)
!442 = !DIGlobalVariableExpression(var: !443, expr: !DIExpression())
!443 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2514, type: !444, isLocal: true, isDefinition: true)
!444 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 104, elements: !445)
!445 = !{!446}
!446 = !DISubrange(count: 13)
!447 = !DIGlobalVariableExpression(var: !448, expr: !DIExpression())
!448 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2517, type: !449, isLocal: true, isDefinition: true)
!449 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 112, elements: !450)
!450 = !{!451}
!451 = !DISubrange(count: 14)
!452 = !DIGlobalVariableExpression(var: !453, expr: !DIExpression())
!453 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2520, type: !26, isLocal: true, isDefinition: true)
!454 = !DIGlobalVariableExpression(var: !455, expr: !DIExpression())
!455 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2523, type: !21, isLocal: true, isDefinition: true)
!456 = !DIGlobalVariableExpression(var: !457, expr: !DIExpression())
!457 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2526, type: !90, isLocal: true, isDefinition: true)
!458 = !DIGlobalVariableExpression(var: !459, expr: !DIExpression())
!459 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2529, type: !128, isLocal: true, isDefinition: true)
!460 = distinct !DICompileUnit(language: DW_LANG_C11, file: !2, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !461, retainedTypes: !578, globals: !749, splitDebugInlining: false, nameTableKind: None)
!461 = !{!462, !482, !496, !515, !520, !525, !531, !539, !544, !551, !559, !565, !573}
!462 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "conn_states", file: !463, line: 204, baseType: !464, size: 32, elements: !465)
!463 = !DIFile(filename: "./memcached.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "a52021954a5d6b153b5bc084e2fbff2b")
!464 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!465 = !{!466, !467, !468, !469, !470, !471, !472, !473, !474, !475, !476, !477, !478, !479, !480, !481}
!466 = !DIEnumerator(name: "conn_listening", value: 0)
!467 = !DIEnumerator(name: "conn_new_cmd", value: 1)
!468 = !DIEnumerator(name: "conn_waiting", value: 2)
!469 = !DIEnumerator(name: "conn_read", value: 3)
!470 = !DIEnumerator(name: "conn_parse_cmd", value: 4)
!471 = !DIEnumerator(name: "conn_write", value: 5)
!472 = !DIEnumerator(name: "conn_nread", value: 6)
!473 = !DIEnumerator(name: "conn_swallow", value: 7)
!474 = !DIEnumerator(name: "conn_closing", value: 8)
!475 = !DIEnumerator(name: "conn_mwrite", value: 9)
!476 = !DIEnumerator(name: "conn_closed", value: 10)
!477 = !DIEnumerator(name: "conn_watch", value: 11)
!478 = !DIEnumerator(name: "conn_io_queue", value: 12)
!479 = !DIEnumerator(name: "conn_io_resume", value: 13)
!480 = !DIEnumerator(name: "conn_io_pending", value: 14)
!481 = !DIEnumerator(name: "conn_max_state", value: 15)
!482 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "bin_substates", file: !463, line: 223, baseType: !464, size: 32, elements: !483)
!483 = !{!484, !485, !486, !487, !488, !489, !490, !491, !492, !493, !494, !495}
!484 = !DIEnumerator(name: "bin_no_state", value: 0)
!485 = !DIEnumerator(name: "bin_reading_set_header", value: 1)
!486 = !DIEnumerator(name: "bin_reading_cas_header", value: 2)
!487 = !DIEnumerator(name: "bin_read_set_value", value: 3)
!488 = !DIEnumerator(name: "bin_reading_get_key", value: 4)
!489 = !DIEnumerator(name: "bin_reading_stat", value: 5)
!490 = !DIEnumerator(name: "bin_reading_del_header", value: 6)
!491 = !DIEnumerator(name: "bin_reading_incr_header", value: 7)
!492 = !DIEnumerator(name: "bin_read_flush_exptime", value: 8)
!493 = !DIEnumerator(name: "bin_reading_sasl_auth", value: 9)
!494 = !DIEnumerator(name: "bin_reading_sasl_auth_data", value: 10)
!495 = !DIEnumerator(name: "bin_reading_touch_key", value: 11)
!496 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "log_entry_type", file: !497, line: 16, baseType: !464, size: 32, elements: !498)
!497 = !DIFile(filename: "./logger.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "e743c4228b1e0bc1c91bec9cfd28d5ab")
!498 = !{!499, !500, !501, !502, !503, !504, !505, !506, !507, !508, !509, !510, !511, !512, !513, !514}
!499 = !DIEnumerator(name: "LOGGER_ASCII_CMD", value: 0)
!500 = !DIEnumerator(name: "LOGGER_EVICTION", value: 1)
!501 = !DIEnumerator(name: "LOGGER_ITEM_GET", value: 2)
!502 = !DIEnumerator(name: "LOGGER_ITEM_STORE", value: 3)
!503 = !DIEnumerator(name: "LOGGER_CRAWLER_STATUS", value: 4)
!504 = !DIEnumerator(name: "LOGGER_SLAB_MOVE", value: 5)
!505 = !DIEnumerator(name: "LOGGER_CONNECTION_NEW", value: 6)
!506 = !DIEnumerator(name: "LOGGER_CONNECTION_CLOSE", value: 7)
!507 = !DIEnumerator(name: "LOGGER_DELETIONS", value: 8)
!508 = !DIEnumerator(name: "LOGGER_EXTSTORE_WRITE", value: 9)
!509 = !DIEnumerator(name: "LOGGER_COMPACT_START", value: 10)
!510 = !DIEnumerator(name: "LOGGER_COMPACT_ABORT", value: 11)
!511 = !DIEnumerator(name: "LOGGER_COMPACT_READ_START", value: 12)
!512 = !DIEnumerator(name: "LOGGER_COMPACT_READ_END", value: 13)
!513 = !DIEnumerator(name: "LOGGER_COMPACT_END", value: 14)
!514 = !DIEnumerator(name: "LOGGER_COMPACT_FRAGINFO", value: 15)
!515 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "protocol", file: !463, line: 238, baseType: !464, size: 32, elements: !516)
!516 = !{!517, !518, !519}
!517 = !DIEnumerator(name: "ascii_prot", value: 3)
!518 = !DIEnumerator(name: "binary_prot", value: 4)
!519 = !DIEnumerator(name: "negotiating_prot", value: 5)
!520 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "network_transport", file: !463, line: 247, baseType: !464, size: 32, elements: !521)
!521 = !{!522, !523, !524}
!522 = !DIEnumerator(name: "local_transport", value: 0)
!523 = !DIEnumerator(name: "tcp_transport", value: 1)
!524 = !DIEnumerator(name: "udp_transport", value: 2)
!525 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "close_reasons", file: !463, line: 266, baseType: !464, size: 32, elements: !526)
!526 = !{!527, !528, !529, !530}
!527 = !DIEnumerator(name: "ERROR_CLOSE", value: 0)
!528 = !DIEnumerator(name: "NORMAL_CLOSE", value: 1)
!529 = !DIEnumerator(name: "IDLE_TIMEOUT_CLOSE", value: 2)
!530 = !DIEnumerator(name: "SHUTDOWN_CLOSE", value: 3)
!531 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "store_item_type", file: !463, line: 291, baseType: !464, size: 32, elements: !532)
!532 = !{!533, !534, !535, !536, !537, !538}
!533 = !DIEnumerator(name: "NOT_STORED", value: 0)
!534 = !DIEnumerator(name: "STORED", value: 1)
!535 = !DIEnumerator(name: "EXISTS", value: 2)
!536 = !DIEnumerator(name: "NOT_FOUND", value: 3)
!537 = !DIEnumerator(name: "TOO_LARGE", value: 4)
!538 = !DIEnumerator(name: "NO_MEMORY", value: 5)
!539 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "logger_ret_type", file: !497, line: 45, baseType: !464, size: 32, elements: !540)
!540 = !{!541, !542, !543}
!541 = !DIEnumerator(name: "LOGGER_RET_OK", value: 0)
!542 = !DIEnumerator(name: "LOGGER_RET_NOSPACE", value: 1)
!543 = !DIEnumerator(name: "LOGGER_RET_ERR", value: 2)
!544 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "delta_result_type", file: !463, line: 295, baseType: !464, size: 32, elements: !545)
!545 = !{!546, !547, !548, !549, !550}
!546 = !DIEnumerator(name: "OK", value: 0)
!547 = !DIEnumerator(name: "NON_NUMERIC", value: 1)
!548 = !DIEnumerator(name: "EOM", value: 2)
!549 = !DIEnumerator(name: "DELTA_ITEM_NOT_FOUND", value: 3)
!550 = !DIEnumerator(name: "DELTA_ITEM_CAS_MISMATCH", value: 4)
!551 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "reassign_result_type", file: !552, line: 55, baseType: !464, size: 32, elements: !553)
!552 = !DIFile(filename: "./slabs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "28867aba1f41c79140864d76faedcb32")
!553 = !{!554, !555, !556, !557, !558}
!554 = !DIEnumerator(name: "REASSIGN_OK", value: 0)
!555 = !DIEnumerator(name: "REASSIGN_RUNNING", value: 1)
!556 = !DIEnumerator(name: "REASSIGN_BADCLASS", value: 2)
!557 = !DIEnumerator(name: "REASSIGN_NOSPARE", value: 3)
!558 = !DIEnumerator(name: "REASSIGN_SRC_DST_SAME", value: 4)
!559 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "crawler_run_type", file: !463, line: 619, baseType: !464, size: 32, elements: !560)
!560 = !{!561, !562, !563, !564}
!561 = !DIEnumerator(name: "CRAWLER_AUTOEXPIRE", value: 0)
!562 = !DIEnumerator(name: "CRAWLER_EXPIRED", value: 1)
!563 = !DIEnumerator(name: "CRAWLER_METADUMP", value: 2)
!564 = !DIEnumerator(name: "CRAWLER_MGDUMP", value: 3)
!565 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "crawler_result_type", file: !566, line: 27, baseType: !464, size: 32, elements: !567)
!566 = !DIFile(filename: "./crawler.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "4dc9e6e54966538ea20b64490631aef9")
!567 = !{!568, !569, !570, !571, !572}
!568 = !DIEnumerator(name: "CRAWLER_OK", value: 0)
!569 = !DIEnumerator(name: "CRAWLER_RUNNING", value: 1)
!570 = !DIEnumerator(name: "CRAWLER_BADCLASS", value: 2)
!571 = !DIEnumerator(name: "CRAWLER_NOTSTARTED", value: 3)
!572 = !DIEnumerator(name: "CRAWLER_ERROR", value: 4)
!573 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "logger_add_watcher_ret", file: !497, line: 240, baseType: !464, size: 32, elements: !574)
!574 = !{!575, !576, !577}
!575 = !DIEnumerator(name: "LOGGER_ADD_WATCHER_TOO_MANY", value: 0)
!576 = !DIEnumerator(name: "LOGGER_ADD_WATCHER_OK", value: 1)
!577 = !DIEnumerator(name: "LOGGER_ADD_WATCHER_FAILED", value: 2)
!578 = !{!579, !580, !631, !632, !616, !633, !607, !637, !641, !745, !618, !746, !747}
!579 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !4, size: 64)
!580 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !581, size: 64)
!581 = !DIDerivedType(tag: DW_TAG_typedef, name: "item_chunk", file: !463, line: 653, baseType: !582)
!582 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_strchunk", file: !463, line: 641, size: 384, elements: !583)
!583 = !{!584, !586, !587, !622, !623, !624, !625, !626, !627, !628, !629}
!584 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !582, file: !463, line: 642, baseType: !585, size: 64)
!585 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !582, size: 64)
!586 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !582, file: !463, line: 643, baseType: !585, size: 64, offset: 64)
!587 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !582, file: !463, line: 644, baseType: !588, size: 64, offset: 128)
!588 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !589, size: 64)
!589 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_stritem", file: !463, line: 593, size: 384, elements: !590)
!590 = !{!591, !592, !593, !594, !596, !597, !599, !601, !606, !610, !611}
!591 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !589, file: !463, line: 595, baseType: !588, size: 64)
!592 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !589, file: !463, line: 596, baseType: !588, size: 64, offset: 64)
!593 = !DIDerivedType(tag: DW_TAG_member, name: "h_next", scope: !589, file: !463, line: 598, baseType: !588, size: 64, offset: 128)
!594 = !DIDerivedType(tag: DW_TAG_member, name: "time", scope: !589, file: !463, line: 599, baseType: !595, size: 32, offset: 192)
!595 = !DIDerivedType(tag: DW_TAG_typedef, name: "rel_time_t", file: !497, line: 14, baseType: !464)
!596 = !DIDerivedType(tag: DW_TAG_member, name: "exptime", scope: !589, file: !463, line: 600, baseType: !595, size: 32, offset: 224)
!597 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !589, file: !463, line: 601, baseType: !598, size: 32, offset: 256)
!598 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!599 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !589, file: !463, line: 602, baseType: !600, size: 16, offset: 288)
!600 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!601 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !589, file: !463, line: 603, baseType: !602, size: 16, offset: 304)
!602 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint16_t", file: !603, line: 25, baseType: !604)
!603 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!604 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint16_t", file: !605, line: 40, baseType: !600)
!605 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!606 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !589, file: !463, line: 604, baseType: !607, size: 8, offset: 320)
!607 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !603, line: 24, baseType: !608)
!608 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !605, line: 38, baseType: !609)
!609 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!610 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !589, file: !463, line: 605, baseType: !607, size: 8, offset: 328)
!611 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !589, file: !463, line: 611, baseType: !612, offset: 384)
!612 = !DICompositeType(tag: DW_TAG_array_type, baseType: !613, elements: !620)
!613 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !589, file: !463, line: 608, size: 64, elements: !614)
!614 = !{!615, !619}
!615 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !613, file: !463, line: 609, baseType: !616, size: 64)
!616 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !603, line: 27, baseType: !617)
!617 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !605, line: 45, baseType: !618)
!618 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!619 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !613, file: !463, line: 610, baseType: !4, size: 8)
!620 = !{!621}
!621 = !DISubrange(count: -1)
!622 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !582, file: !463, line: 645, baseType: !598, size: 32, offset: 192)
!623 = !DIDerivedType(tag: DW_TAG_member, name: "used", scope: !582, file: !463, line: 646, baseType: !598, size: 32, offset: 224)
!624 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !582, file: !463, line: 647, baseType: !598, size: 32, offset: 256)
!625 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !582, file: !463, line: 648, baseType: !600, size: 16, offset: 288)
!626 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !582, file: !463, line: 649, baseType: !602, size: 16, offset: 304)
!627 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !582, file: !463, line: 650, baseType: !607, size: 8, offset: 320)
!628 = !DIDerivedType(tag: DW_TAG_member, name: "orig_clsid", scope: !582, file: !463, line: 651, baseType: !607, size: 8, offset: 328)
!629 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !582, file: !463, line: 652, baseType: !630, offset: 336)
!630 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, elements: !620)
!631 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !609, size: 64)
!632 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!633 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !634, size: 64)
!634 = !DIDerivedType(tag: DW_TAG_typedef, name: "client_flags_t", file: !463, line: 99, baseType: !635)
!635 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !603, line: 26, baseType: !636)
!636 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !605, line: 42, baseType: !464)
!637 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !638, size: 64)
!638 = !DIDerivedType(tag: DW_TAG_typedef, name: "int32_t", file: !639, line: 26, baseType: !640)
!639 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h", directory: "", checksumkind: CSK_MD5, checksum: "649b383a60bfa3eb90e85840b2b0be20")
!640 = !DIDerivedType(tag: DW_TAG_typedef, name: "__int32_t", file: !605, line: 41, baseType: !598)
!641 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !642, size: 64)
!642 = !DIDerivedType(tag: DW_TAG_typedef, name: "logger", file: !497, line: 193, baseType: !643)
!643 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logger", file: !497, line: 181, size: 832, elements: !644)
!644 = !{!645, !647, !648, !676, !677, !678, !679, !680, !681, !682, !695}
!645 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !643, file: !497, line: 182, baseType: !646, size: 64)
!646 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !643, size: 64)
!647 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !643, file: !497, line: 183, baseType: !646, size: 64, offset: 64)
!648 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !643, file: !497, line: 184, baseType: !649, size: 320, offset: 128)
!649 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutex_t", file: !650, line: 72, baseType: !651)
!650 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h", directory: "", checksumkind: CSK_MD5, checksum: "8a5acdbeec491eca11cf81cb1ef77ea7")
!651 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !650, line: 67, size: 320, elements: !652)
!652 = !{!653, !673, !674}
!653 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !651, file: !650, line: 69, baseType: !654, size: 320)
!654 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_mutex_s", file: !655, line: 22, size: 320, elements: !656)
!655 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h", directory: "", checksumkind: CSK_MD5, checksum: "6b075eca9ab0e2d761b2afc4ecfab776")
!656 = !{!657, !658, !659, !660, !661, !662, !664, !665}
!657 = !DIDerivedType(tag: DW_TAG_member, name: "__lock", scope: !654, file: !655, line: 24, baseType: !598, size: 32)
!658 = !DIDerivedType(tag: DW_TAG_member, name: "__count", scope: !654, file: !655, line: 25, baseType: !464, size: 32, offset: 32)
!659 = !DIDerivedType(tag: DW_TAG_member, name: "__owner", scope: !654, file: !655, line: 26, baseType: !598, size: 32, offset: 64)
!660 = !DIDerivedType(tag: DW_TAG_member, name: "__nusers", scope: !654, file: !655, line: 28, baseType: !464, size: 32, offset: 96)
!661 = !DIDerivedType(tag: DW_TAG_member, name: "__kind", scope: !654, file: !655, line: 32, baseType: !598, size: 32, offset: 128)
!662 = !DIDerivedType(tag: DW_TAG_member, name: "__spins", scope: !654, file: !655, line: 34, baseType: !663, size: 16, offset: 160)
!663 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!664 = !DIDerivedType(tag: DW_TAG_member, name: "__elision", scope: !654, file: !655, line: 35, baseType: !663, size: 16, offset: 176)
!665 = !DIDerivedType(tag: DW_TAG_member, name: "__list", scope: !654, file: !655, line: 36, baseType: !666, size: 128, offset: 192)
!666 = !DIDerivedType(tag: DW_TAG_typedef, name: "__pthread_list_t", file: !667, line: 55, baseType: !668)
!667 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h", directory: "", checksumkind: CSK_MD5, checksum: "b9a7199822bce372686baacd32a9f4f3")
!668 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_internal_list", file: !667, line: 51, size: 128, elements: !669)
!669 = !{!670, !672}
!670 = !DIDerivedType(tag: DW_TAG_member, name: "__prev", scope: !668, file: !667, line: 53, baseType: !671, size: 64)
!671 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !668, size: 64)
!672 = !DIDerivedType(tag: DW_TAG_member, name: "__next", scope: !668, file: !667, line: 54, baseType: !671, size: 64, offset: 64)
!673 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !651, file: !650, line: 70, baseType: !145, size: 320)
!674 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !651, file: !650, line: 71, baseType: !675, size: 64)
!675 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!676 = !DIDerivedType(tag: DW_TAG_member, name: "written", scope: !643, file: !497, line: 185, baseType: !616, size: 64, offset: 448)
!677 = !DIDerivedType(tag: DW_TAG_member, name: "dropped", scope: !643, file: !497, line: 186, baseType: !616, size: 64, offset: 512)
!678 = !DIDerivedType(tag: DW_TAG_member, name: "blocked", scope: !643, file: !497, line: 187, baseType: !616, size: 64, offset: 576)
!679 = !DIDerivedType(tag: DW_TAG_member, name: "fetcher_ratio", scope: !643, file: !497, line: 188, baseType: !602, size: 16, offset: 640)
!680 = !DIDerivedType(tag: DW_TAG_member, name: "mutation_ratio", scope: !643, file: !497, line: 189, baseType: !602, size: 16, offset: 656)
!681 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !643, file: !497, line: 190, baseType: !602, size: 16, offset: 672)
!682 = !DIDerivedType(tag: DW_TAG_member, name: "buf", scope: !643, file: !497, line: 191, baseType: !683, size: 64, offset: 704)
!683 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !684, size: 64)
!684 = !DIDerivedType(tag: DW_TAG_typedef, name: "bipbuf_t", file: !685, line: 18, baseType: !686)
!685 = !DIFile(filename: "./bipbuffer.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "99606bcb8393045e6bc9eef40115066f")
!686 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !685, line: 4, size: 192, elements: !687)
!687 = !{!688, !689, !690, !691, !692, !693}
!688 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !686, file: !685, line: 6, baseType: !618, size: 64)
!689 = !DIDerivedType(tag: DW_TAG_member, name: "a_start", scope: !686, file: !685, line: 9, baseType: !464, size: 32, offset: 64)
!690 = !DIDerivedType(tag: DW_TAG_member, name: "a_end", scope: !686, file: !685, line: 9, baseType: !464, size: 32, offset: 96)
!691 = !DIDerivedType(tag: DW_TAG_member, name: "b_end", scope: !686, file: !685, line: 12, baseType: !464, size: 32, offset: 128)
!692 = !DIDerivedType(tag: DW_TAG_member, name: "b_inuse", scope: !686, file: !685, line: 15, baseType: !598, size: 32, offset: 160)
!693 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !686, file: !685, line: 17, baseType: !694, offset: 192)
!694 = !DICompositeType(tag: DW_TAG_array_type, baseType: !609, elements: !620)
!695 = !DIDerivedType(tag: DW_TAG_member, name: "entry_map", scope: !643, file: !497, line: 192, baseType: !696, size: 64, offset: 768)
!696 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !697, size: 64)
!697 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !698)
!698 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_details", file: !497, line: 58, baseType: !699)
!699 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_entry_details", file: !497, line: 63, size: 256, elements: !700)
!700 = !{!701, !702, !703, !739, !744}
!701 = !DIDerivedType(tag: DW_TAG_member, name: "reqlen", scope: !699, file: !497, line: 64, baseType: !598, size: 32)
!702 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !699, file: !497, line: 65, baseType: !602, size: 16, offset: 32)
!703 = !DIDerivedType(tag: DW_TAG_member, name: "log_cb", scope: !699, file: !497, line: 66, baseType: !704, size: 64, offset: 64)
!704 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_log_cb", file: !497, line: 60, baseType: !705)
!705 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !706, size: 64)
!706 = !DISubroutineType(types: !707)
!707 = !{null, !708, !696, !730, !732}
!708 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !709, size: 64)
!709 = !DIDerivedType(tag: DW_TAG_typedef, name: "logentry", file: !497, line: 57, baseType: !710)
!710 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logentry", file: !497, line: 156, size: 320, elements: !711)
!711 = !{!712, !713, !714, !715, !716, !724, !725}
!712 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !710, file: !497, line: 157, baseType: !496, size: 32)
!713 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !710, file: !497, line: 158, baseType: !607, size: 8, offset: 32)
!714 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !710, file: !497, line: 159, baseType: !602, size: 16, offset: 48)
!715 = !DIDerivedType(tag: DW_TAG_member, name: "gid", scope: !710, file: !497, line: 160, baseType: !616, size: 64, offset: 64)
!716 = !DIDerivedType(tag: DW_TAG_member, name: "tv", scope: !710, file: !497, line: 161, baseType: !717, size: 128, offset: 128)
!717 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "timeval", file: !718, line: 8, size: 128, elements: !719)
!718 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h", directory: "", checksumkind: CSK_MD5, checksum: "9b45d950050c215f216850b27bd1e8f3")
!719 = !{!720, !722}
!720 = !DIDerivedType(tag: DW_TAG_member, name: "tv_sec", scope: !717, file: !718, line: 14, baseType: !721, size: 64)
!721 = !DIDerivedType(tag: DW_TAG_typedef, name: "__time_t", file: !605, line: 160, baseType: !675)
!722 = !DIDerivedType(tag: DW_TAG_member, name: "tv_usec", scope: !717, file: !718, line: 15, baseType: !723, size: 64, offset: 64)
!723 = !DIDerivedType(tag: DW_TAG_typedef, name: "__suseconds_t", file: !605, line: 162, baseType: !675)
!724 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !710, file: !497, line: 162, baseType: !598, size: 32, offset: 256)
!725 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !710, file: !497, line: 165, baseType: !726, offset: 288)
!726 = !DICompositeType(tag: DW_TAG_array_type, baseType: !727, elements: !620)
!727 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !710, file: !497, line: 163, size: 8, elements: !728)
!728 = !{!729}
!729 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !727, file: !497, line: 164, baseType: !4, size: 8)
!730 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !731, size: 64)
!731 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!732 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !733, size: 64)
!733 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !734)
!734 = !{!735, !736, !737, !738}
!735 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !733, file: !2, baseType: !464, size: 32)
!736 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !733, file: !2, baseType: !464, size: 32, offset: 32)
!737 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !733, file: !2, baseType: !632, size: 64, offset: 64)
!738 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !733, file: !2, baseType: !632, size: 64, offset: 128)
!739 = !DIDerivedType(tag: DW_TAG_member, name: "parse_cb", scope: !699, file: !497, line: 67, baseType: !740, size: 64, offset: 128)
!740 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_parse_cb", file: !497, line: 61, baseType: !741)
!741 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !742, size: 64)
!742 = !DISubroutineType(types: !743)
!743 = !{!598, !708, !579}
!744 = !DIDerivedType(tag: DW_TAG_member, name: "format", scope: !699, file: !497, line: 68, baseType: !579, size: 64, offset: 192)
!745 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!746 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !635, size: 64)
!747 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !748, line: 18, baseType: !618)
!748 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!749 = !{!0, !7, !12, !17, !19, !24, !29, !34, !39, !44, !49, !54, !59, !64, !69, !74, !76, !78, !80, !82, !84, !86, !88, !93, !95, !97, !99, !101, !106, !108, !110, !112, !114, !116, !118, !120, !122, !124, !126, !131, !133, !135, !137, !139, !750, !752, !754, !756, !141, !143, !148, !153, !155, !160, !162, !164, !169, !174, !176, !181, !186, !191, !193, !195, !197, !199, !204, !209, !211, !216, !221, !223, !228, !230, !232, !237, !239, !758, !760, !244, !246, !251, !253, !255, !260, !262, !264, !266, !271, !273, !275, !277, !279, !281, !765, !283, !285, !287, !289, !291, !293, !295, !297, !299, !301, !303, !305, !307, !309, !311, !313, !318, !323, !325, !330, !767, !332, !337, !339, !341, !343, !345, !347, !352, !354, !356, !358, !360, !362, !364, !369, !371, !373, !375, !377, !379, !381, !383, !385, !387, !389, !391, !396, !398, !400, !402, !404, !406, !408, !410, !412, !414, !416, !418, !420, !422, !424, !426, !428, !430, !432, !434, !436, !438, !440, !442, !447, !452, !454, !456, !458}
!750 = !DIGlobalVariableExpression(var: !751, expr: !DIExpression())
!751 = distinct !DIGlobalVariable(scope: null, file: !2, line: 65, type: !3, isLocal: true, isDefinition: true)
!752 = !DIGlobalVariableExpression(var: !753, expr: !DIExpression())
!753 = distinct !DIGlobalVariable(scope: null, file: !2, line: 72, type: !3, isLocal: true, isDefinition: true)
!754 = !DIGlobalVariableExpression(var: !755, expr: !DIExpression())
!755 = distinct !DIGlobalVariable(scope: null, file: !2, line: 75, type: !3, isLocal: true, isDefinition: true)
!756 = !DIGlobalVariableExpression(var: !757, expr: !DIExpression())
!757 = distinct !DIGlobalVariable(scope: null, file: !2, line: 78, type: !3, isLocal: true, isDefinition: true)
!758 = !DIGlobalVariableExpression(var: !759, expr: !DIExpression())
!759 = distinct !DIGlobalVariable(scope: null, file: !2, line: 634, type: !3, isLocal: true, isDefinition: true)
!760 = !DIGlobalVariableExpression(var: !761, expr: !DIExpression())
!761 = distinct !DIGlobalVariable(scope: null, file: !2, line: 636, type: !762, isLocal: true, isDefinition: true)
!762 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 16, elements: !763)
!763 = !{!764}
!764 = !DISubrange(count: 2)
!765 = !DIGlobalVariableExpression(var: !766, expr: !DIExpression())
!766 = distinct !DIGlobalVariable(scope: null, file: !2, line: 726, type: !3, isLocal: true, isDefinition: true)
!767 = !DIGlobalVariableExpression(var: !768, expr: !DIExpression())
!768 = distinct !DIGlobalVariable(scope: null, file: !2, line: 2200, type: !762, isLocal: true, isDefinition: true)
!769 = !{i32 7, !"Dwarf Version", i32 5}
!770 = !{i32 2, !"Debug Info Version", i32 3}
!771 = !{i32 1, !"wchar_size", i32 4}
!772 = !{i32 8, !"PIC Level", i32 2}
!773 = !{i32 7, !"PIE Level", i32 2}
!774 = !{i32 7, !"uwtable", i32 2}
!775 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!776 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!777 = distinct !DISubprogram(name: "complete_nread_ascii", scope: !2, file: !2, line: 134, type: !778, scopeLine: 134, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !1189)
!778 = !DISubroutineType(types: !779)
!779 = !{null, !780}
!780 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !781, size: 64)
!781 = !DIDerivedType(tag: DW_TAG_typedef, name: "conn", file: !463, line: 813, baseType: !782)
!782 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "conn", file: !463, line: 829, size: 3968, elements: !783)
!783 = !{!784, !788, !789, !791, !792, !793, !794, !795, !796, !797, !798, !799, !800, !875, !876, !877, !878, !879, !880, !881, !1112, !1113, !1114, !1115, !1116, !1117, !1118, !1120, !1121, !1122, !1123, !1124, !1125, !1126, !1127, !1128, !1134, !1155, !1156, !1157, !1158, !1159, !1160, !1161, !1162, !1166, !1173, !1188}
!784 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_conn", scope: !782, file: !463, line: 830, baseType: !785, size: 64)
!785 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !786, size: 64)
!786 = !DIDerivedType(tag: DW_TAG_typedef, name: "sasl_conn_t", file: !787, line: 16, baseType: !632)
!787 = !DIFile(filename: "./sasl_defs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "3a8678a43d09d8e311388b26eedc7a3e")
!788 = !DIDerivedType(tag: DW_TAG_member, name: "sfd", scope: !782, file: !463, line: 831, baseType: !598, size: 32, offset: 64)
!789 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_started", scope: !782, file: !463, line: 832, baseType: !790, size: 8, offset: 96)
!790 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!791 = !DIDerivedType(tag: DW_TAG_member, name: "authenticated", scope: !782, file: !463, line: 833, baseType: !790, size: 8, offset: 104)
!792 = !DIDerivedType(tag: DW_TAG_member, name: "set_stale", scope: !782, file: !463, line: 834, baseType: !790, size: 8, offset: 112)
!793 = !DIDerivedType(tag: DW_TAG_member, name: "mset_res", scope: !782, file: !463, line: 835, baseType: !790, size: 8, offset: 120)
!794 = !DIDerivedType(tag: DW_TAG_member, name: "close_after_write", scope: !782, file: !463, line: 836, baseType: !790, size: 8, offset: 128)
!795 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_malloced", scope: !782, file: !463, line: 837, baseType: !790, size: 8, offset: 136)
!796 = !DIDerivedType(tag: DW_TAG_member, name: "item_malloced", scope: !782, file: !463, line: 838, baseType: !790, size: 8, offset: 144)
!797 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !782, file: !463, line: 844, baseType: !462, size: 32, offset: 160)
!798 = !DIDerivedType(tag: DW_TAG_member, name: "substate", scope: !782, file: !463, line: 845, baseType: !482, size: 32, offset: 192)
!799 = !DIDerivedType(tag: DW_TAG_member, name: "last_cmd_time", scope: !782, file: !463, line: 846, baseType: !595, size: 32, offset: 224)
!800 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !782, file: !463, line: 847, baseType: !801, size: 1024, offset: 256)
!801 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event", file: !802, line: 123, size: 1024, elements: !803)
!802 = !DIFile(filename: "/usr/include/event2/event_struct.h", directory: "", checksumkind: CSK_MD5, checksum: "005d89b34bed2ed9e30b0cc3160619c1")
!803 = !{!804, !835, !845, !846, !849, !872, !873, !874}
!804 = !DIDerivedType(tag: DW_TAG_member, name: "ev_evcallback", scope: !801, file: !802, line: 124, baseType: !805, size: 320)
!805 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event_callback", file: !802, line: 107, size: 320, elements: !806)
!806 = !{!807, !814, !815, !816, !817, !834}
!807 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_active_next", scope: !805, file: !802, line: 108, baseType: !808, size: 128)
!808 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !805, file: !802, line: 108, size: 128, elements: !809)
!809 = !{!810, !812}
!810 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !808, file: !802, line: 108, baseType: !811, size: 64)
!811 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !805, size: 64)
!812 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !808, file: !802, line: 108, baseType: !813, size: 64, offset: 64)
!813 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !811, size: 64)
!814 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_flags", scope: !805, file: !802, line: 109, baseType: !663, size: 16, offset: 128)
!815 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_pri", scope: !805, file: !802, line: 110, baseType: !607, size: 8, offset: 144)
!816 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_closure", scope: !805, file: !802, line: 111, baseType: !607, size: 8, offset: 152)
!817 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cb_union", scope: !805, file: !802, line: 118, baseType: !818, size: 64, offset: 192)
!818 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !805, file: !802, line: 113, size: 64, elements: !819)
!819 = !{!820, !824, !828, !833}
!820 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_callback", scope: !818, file: !802, line: 114, baseType: !821, size: 64)
!821 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !822, size: 64)
!822 = !DISubroutineType(types: !823)
!823 = !{null, !598, !663, !632}
!824 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_selfcb", scope: !818, file: !802, line: 115, baseType: !825, size: 64)
!825 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !826, size: 64)
!826 = !DISubroutineType(types: !827)
!827 = !{null, !811, !632}
!828 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_evfinalize", scope: !818, file: !802, line: 116, baseType: !829, size: 64)
!829 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !830, size: 64)
!830 = !DISubroutineType(types: !831)
!831 = !{null, !832, !632}
!832 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !801, size: 64)
!833 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cbfinalize", scope: !818, file: !802, line: 117, baseType: !825, size: 64)
!834 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_arg", scope: !805, file: !802, line: 119, baseType: !632, size: 64, offset: 256)
!835 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout_pos", scope: !801, file: !802, line: 130, baseType: !836, size: 128, offset: 320)
!836 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !801, file: !802, line: 127, size: 128, elements: !837)
!837 = !{!838, !844}
!838 = !DIDerivedType(tag: DW_TAG_member, name: "ev_next_with_common_timeout", scope: !836, file: !802, line: 128, baseType: !839, size: 128)
!839 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !836, file: !802, line: 128, size: 128, elements: !840)
!840 = !{!841, !842}
!841 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !839, file: !802, line: 128, baseType: !832, size: 64)
!842 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !839, file: !802, line: 128, baseType: !843, size: 64, offset: 64)
!843 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !832, size: 64)
!844 = !DIDerivedType(tag: DW_TAG_member, name: "min_heap_idx", scope: !836, file: !802, line: 129, baseType: !598, size: 32)
!845 = !DIDerivedType(tag: DW_TAG_member, name: "ev_fd", scope: !801, file: !802, line: 131, baseType: !598, size: 32, offset: 448)
!846 = !DIDerivedType(tag: DW_TAG_member, name: "ev_base", scope: !801, file: !802, line: 133, baseType: !847, size: 64, offset: 512)
!847 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !848, size: 64)
!848 = !DICompositeType(tag: DW_TAG_structure_type, name: "event_base", file: !802, line: 122, flags: DIFlagFwdDecl)
!849 = !DIDerivedType(tag: DW_TAG_member, name: "ev_", scope: !801, file: !802, line: 149, baseType: !850, size: 256, offset: 576)
!850 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !801, file: !802, line: 135, size: 256, elements: !851)
!851 = !{!852, !861}
!852 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io", scope: !850, file: !802, line: 140, baseType: !853, size: 256)
!853 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !850, file: !802, line: 137, size: 256, elements: !854)
!854 = !{!855, !860}
!855 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io_next", scope: !853, file: !802, line: 138, baseType: !856, size: 128)
!856 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !853, file: !802, line: 138, size: 128, elements: !857)
!857 = !{!858, !859}
!858 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !856, file: !802, line: 138, baseType: !832, size: 64)
!859 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !856, file: !802, line: 138, baseType: !843, size: 64, offset: 64)
!860 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !853, file: !802, line: 139, baseType: !717, size: 128, offset: 128)
!861 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal", scope: !850, file: !802, line: 148, baseType: !862, size: 256)
!862 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !850, file: !802, line: 143, size: 256, elements: !863)
!863 = !{!864, !869, !870}
!864 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal_next", scope: !862, file: !802, line: 144, baseType: !865, size: 128)
!865 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !862, file: !802, line: 144, size: 128, elements: !866)
!866 = !{!867, !868}
!867 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !865, file: !802, line: 144, baseType: !832, size: 64)
!868 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !865, file: !802, line: 144, baseType: !843, size: 64, offset: 64)
!869 = !DIDerivedType(tag: DW_TAG_member, name: "ev_ncalls", scope: !862, file: !802, line: 145, baseType: !663, size: 16, offset: 128)
!870 = !DIDerivedType(tag: DW_TAG_member, name: "ev_pncalls", scope: !862, file: !802, line: 147, baseType: !871, size: 64, offset: 192)
!871 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !663, size: 64)
!872 = !DIDerivedType(tag: DW_TAG_member, name: "ev_events", scope: !801, file: !802, line: 151, baseType: !663, size: 16, offset: 832)
!873 = !DIDerivedType(tag: DW_TAG_member, name: "ev_res", scope: !801, file: !802, line: 152, baseType: !663, size: 16, offset: 848)
!874 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !801, file: !802, line: 153, baseType: !717, size: 128, offset: 896)
!875 = !DIDerivedType(tag: DW_TAG_member, name: "ev_flags", scope: !782, file: !463, line: 848, baseType: !663, size: 16, offset: 1280)
!876 = !DIDerivedType(tag: DW_TAG_member, name: "which", scope: !782, file: !463, line: 849, baseType: !663, size: 16, offset: 1296)
!877 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf", scope: !782, file: !463, line: 851, baseType: !579, size: 64, offset: 1344)
!878 = !DIDerivedType(tag: DW_TAG_member, name: "rcurr", scope: !782, file: !463, line: 852, baseType: !579, size: 64, offset: 1408)
!879 = !DIDerivedType(tag: DW_TAG_member, name: "rsize", scope: !782, file: !463, line: 853, baseType: !598, size: 32, offset: 1472)
!880 = !DIDerivedType(tag: DW_TAG_member, name: "rbytes", scope: !782, file: !463, line: 854, baseType: !598, size: 32, offset: 1504)
!881 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !782, file: !463, line: 856, baseType: !882, size: 64, offset: 1536)
!882 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !883, size: 64)
!883 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp", file: !463, line: 801, baseType: !884)
!884 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp", file: !463, line: 771, size: 9472, elements: !885)
!885 = !{!886, !1055, !1057, !1058, !1059, !1060, !1061, !1064, !1071, !1072, !1073, !1074, !1075, !1076, !1077, !1078, !1079, !1104, !1108}
!886 = !DIDerivedType(tag: DW_TAG_member, name: "bundle", scope: !884, file: !463, line: 772, baseType: !887, size: 64)
!887 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !888, size: 64)
!888 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp_bundle", file: !463, line: 720, baseType: !889)
!889 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp_bundle", file: !463, line: 804, size: 256, elements: !890)
!890 = !{!891, !892, !893, !1050, !1052, !1053}
!891 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !889, file: !463, line: 805, baseType: !607, size: 8)
!892 = !DIDerivedType(tag: DW_TAG_member, name: "next_check", scope: !889, file: !463, line: 806, baseType: !607, size: 8, offset: 8)
!893 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !889, file: !463, line: 807, baseType: !894, size: 64, offset: 64)
!894 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !895, size: 64)
!895 = !DIDerivedType(tag: DW_TAG_typedef, name: "LIBEVENT_THREAD", file: !463, line: 765, baseType: !896)
!896 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !463, line: 721, size: 55488, elements: !897)
!897 = !{!898, !900, !901, !906, !907, !908, !938, !939, !940, !995, !1015, !1018, !1044, !1045, !1046, !1047, !1048, !1049}
!898 = !DIDerivedType(tag: DW_TAG_member, name: "thread_id", scope: !896, file: !463, line: 722, baseType: !899, size: 64)
!899 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_t", file: !650, line: 27, baseType: !618)
!900 = !DIDerivedType(tag: DW_TAG_member, name: "base", scope: !896, file: !463, line: 723, baseType: !847, size: 64, offset: 64)
!901 = !DIDerivedType(tag: DW_TAG_member, name: "n", scope: !896, file: !463, line: 724, baseType: !902, size: 1088, offset: 128)
!902 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_notify", file: !463, line: 710, size: 1088, elements: !903)
!903 = !{!904, !905}
!904 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event", scope: !902, file: !463, line: 711, baseType: !801, size: 1024)
!905 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event_fd", scope: !902, file: !463, line: 713, baseType: !598, size: 32, offset: 1024)
!906 = !DIDerivedType(tag: DW_TAG_member, name: "ion", scope: !896, file: !463, line: 725, baseType: !902, size: 1088, offset: 1216)
!907 = !DIDerivedType(tag: DW_TAG_member, name: "ion_lock", scope: !896, file: !463, line: 726, baseType: !649, size: 320, offset: 2304)
!908 = !DIDerivedType(tag: DW_TAG_member, name: "ion_head", scope: !896, file: !463, line: 727, baseType: !909, size: 128, offset: 2624)
!909 = !DIDerivedType(tag: DW_TAG_typedef, name: "iop_head_t", file: !463, line: 686, baseType: !910)
!910 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iop_head_s", file: !463, line: 686, size: 128, elements: !911)
!911 = !{!912, !936}
!912 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !910, file: !463, line: 686, baseType: !913, size: 64)
!913 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !914, size: 64)
!914 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_io_pending_t", file: !463, line: 815, size: 1408, elements: !915)
!915 = !{!916, !917, !918, !919, !920, !927, !928, !932}
!916 = !DIDerivedType(tag: DW_TAG_member, name: "io_queue_type", scope: !914, file: !463, line: 816, baseType: !598, size: 32)
!917 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !914, file: !463, line: 817, baseType: !894, size: 64, offset: 64)
!918 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !914, file: !463, line: 818, baseType: !780, size: 64, offset: 128)
!919 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !914, file: !463, line: 819, baseType: !882, size: 64, offset: 192)
!920 = !DIDerivedType(tag: DW_TAG_member, name: "return_cb", scope: !914, file: !463, line: 820, baseType: !921, size: 64, offset: 256)
!921 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb", file: !463, line: 690, baseType: !922)
!922 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !923, size: 64)
!923 = !DISubroutineType(types: !924)
!924 = !{null, !925}
!925 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !926, size: 64)
!926 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_pending_t", file: !463, line: 687, baseType: !914)
!927 = !DIDerivedType(tag: DW_TAG_member, name: "finalize_cb", scope: !914, file: !463, line: 821, baseType: !921, size: 64, offset: 320)
!928 = !DIDerivedType(tag: DW_TAG_member, name: "iop_next", scope: !914, file: !463, line: 822, baseType: !929, size: 64, offset: 384)
!929 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !914, file: !463, line: 822, size: 64, elements: !930)
!930 = !{!931}
!931 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !929, file: !463, line: 822, baseType: !913, size: 64)
!932 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !914, file: !463, line: 823, baseType: !933, size: 960, offset: 448)
!933 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 960, elements: !934)
!934 = !{!935}
!935 = !DISubrange(count: 120)
!936 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !910, file: !463, line: 686, baseType: !937, size: 64, offset: 64)
!937 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !913, size: 64)
!938 = !DIDerivedType(tag: DW_TAG_member, name: "cur_sfd", scope: !896, file: !463, line: 728, baseType: !598, size: 32, offset: 2752)
!939 = !DIDerivedType(tag: DW_TAG_member, name: "thread_baseid", scope: !896, file: !463, line: 729, baseType: !598, size: 32, offset: 2784)
!940 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !896, file: !463, line: 730, baseType: !941, size: 51584, offset: 2816)
!941 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_stats", file: !463, line: 372, size: 51584, elements: !942)
!942 = !{!943, !944, !945, !946, !947, !948, !949, !950, !951, !952, !953, !954, !955, !956, !957, !958, !959, !960, !961, !962, !963, !964, !965, !966, !967, !968, !969, !970, !971, !972, !973, !974, !988, !992, !993, !994}
!943 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !941, file: !463, line: 373, baseType: !649, size: 320)
!944 = !DIDerivedType(tag: DW_TAG_member, name: "get_cmds", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 320)
!945 = !DIDerivedType(tag: DW_TAG_member, name: "get_misses", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 384)
!946 = !DIDerivedType(tag: DW_TAG_member, name: "get_expired", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 448)
!947 = !DIDerivedType(tag: DW_TAG_member, name: "get_flushed", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 512)
!948 = !DIDerivedType(tag: DW_TAG_member, name: "touch_cmds", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 576)
!949 = !DIDerivedType(tag: DW_TAG_member, name: "touch_misses", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 640)
!950 = !DIDerivedType(tag: DW_TAG_member, name: "delete_misses", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 704)
!951 = !DIDerivedType(tag: DW_TAG_member, name: "incr_misses", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 768)
!952 = !DIDerivedType(tag: DW_TAG_member, name: "decr_misses", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 832)
!953 = !DIDerivedType(tag: DW_TAG_member, name: "cas_misses", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 896)
!954 = !DIDerivedType(tag: DW_TAG_member, name: "meta_cmds", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 960)
!955 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_read", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 1024)
!956 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_written", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 1088)
!957 = !DIDerivedType(tag: DW_TAG_member, name: "flush_cmds", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 1152)
!958 = !DIDerivedType(tag: DW_TAG_member, name: "conn_yields", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 1216)
!959 = !DIDerivedType(tag: DW_TAG_member, name: "auth_cmds", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 1280)
!960 = !DIDerivedType(tag: DW_TAG_member, name: "auth_errors", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 1344)
!961 = !DIDerivedType(tag: DW_TAG_member, name: "idle_kicks", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 1408)
!962 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_oom", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 1472)
!963 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_count", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 1536)
!964 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_bytes", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 1600)
!965 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_oom", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 1664)
!966 = !DIDerivedType(tag: DW_TAG_member, name: "store_too_large", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 1728)
!967 = !DIDerivedType(tag: DW_TAG_member, name: "store_no_memory", scope: !941, file: !463, line: 375, baseType: !616, size: 64, offset: 1792)
!968 = !DIDerivedType(tag: DW_TAG_member, name: "get_extstore", scope: !941, file: !463, line: 377, baseType: !616, size: 64, offset: 1856)
!969 = !DIDerivedType(tag: DW_TAG_member, name: "get_aborted_extstore", scope: !941, file: !463, line: 377, baseType: !616, size: 64, offset: 1920)
!970 = !DIDerivedType(tag: DW_TAG_member, name: "get_oom_extstore", scope: !941, file: !463, line: 377, baseType: !616, size: 64, offset: 1984)
!971 = !DIDerivedType(tag: DW_TAG_member, name: "recache_from_extstore", scope: !941, file: !463, line: 377, baseType: !616, size: 64, offset: 2048)
!972 = !DIDerivedType(tag: DW_TAG_member, name: "miss_from_extstore", scope: !941, file: !463, line: 377, baseType: !616, size: 64, offset: 2112)
!973 = !DIDerivedType(tag: DW_TAG_member, name: "badcrc_from_extstore", scope: !941, file: !463, line: 377, baseType: !616, size: 64, offset: 2176)
!974 = !DIDerivedType(tag: DW_TAG_member, name: "slab_stats", scope: !941, file: !463, line: 383, baseType: !975, size: 32768, offset: 2240)
!975 = !DICompositeType(tag: DW_TAG_array_type, baseType: !976, size: 32768, elements: !986)
!976 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "slab_stats", file: !463, line: 318, size: 512, elements: !977)
!977 = !{!978, !979, !980, !981, !982, !983, !984, !985}
!978 = !DIDerivedType(tag: DW_TAG_member, name: "set_cmds", scope: !976, file: !463, line: 320, baseType: !616, size: 64)
!979 = !DIDerivedType(tag: DW_TAG_member, name: "get_hits", scope: !976, file: !463, line: 320, baseType: !616, size: 64, offset: 64)
!980 = !DIDerivedType(tag: DW_TAG_member, name: "touch_hits", scope: !976, file: !463, line: 320, baseType: !616, size: 64, offset: 128)
!981 = !DIDerivedType(tag: DW_TAG_member, name: "delete_hits", scope: !976, file: !463, line: 320, baseType: !616, size: 64, offset: 192)
!982 = !DIDerivedType(tag: DW_TAG_member, name: "cas_hits", scope: !976, file: !463, line: 320, baseType: !616, size: 64, offset: 256)
!983 = !DIDerivedType(tag: DW_TAG_member, name: "cas_badval", scope: !976, file: !463, line: 320, baseType: !616, size: 64, offset: 320)
!984 = !DIDerivedType(tag: DW_TAG_member, name: "incr_hits", scope: !976, file: !463, line: 320, baseType: !616, size: 64, offset: 384)
!985 = !DIDerivedType(tag: DW_TAG_member, name: "decr_hits", scope: !976, file: !463, line: 320, baseType: !616, size: 64, offset: 448)
!986 = !{!987}
!987 = !DISubrange(count: 64)
!988 = !DIDerivedType(tag: DW_TAG_member, name: "lru_hits", scope: !941, file: !463, line: 384, baseType: !989, size: 16384, offset: 35008)
!989 = !DICompositeType(tag: DW_TAG_array_type, baseType: !616, size: 16384, elements: !990)
!990 = !{!991}
!991 = !DISubrange(count: 256)
!992 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_count", scope: !941, file: !463, line: 385, baseType: !616, size: 64, offset: 51392)
!993 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes", scope: !941, file: !463, line: 386, baseType: !616, size: 64, offset: 51456)
!994 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes_free", scope: !941, file: !463, line: 387, baseType: !616, size: 64, offset: 51520)
!995 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !896, file: !463, line: 731, baseType: !996, size: 576, offset: 54400)
!996 = !DICompositeType(tag: DW_TAG_array_type, baseType: !997, size: 576, elements: !5)
!997 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb_t", file: !463, line: 708, baseType: !998)
!998 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_cb_s", file: !463, line: 704, size: 192, elements: !999)
!999 = !{!1000, !1001, !1014}
!1000 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !998, file: !463, line: 705, baseType: !632, size: 64)
!1001 = !DIDerivedType(tag: DW_TAG_member, name: "submit_cb", scope: !998, file: !463, line: 706, baseType: !1002, size: 64, offset: 64)
!1002 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_stack_cb", file: !463, line: 689, baseType: !1003)
!1003 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1004, size: 64)
!1004 = !DISubroutineType(types: !1005)
!1005 = !{null, !1006}
!1006 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1007, size: 64)
!1007 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_t", file: !463, line: 688, baseType: !1008)
!1008 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_s", file: !463, line: 697, size: 192, elements: !1009)
!1009 = !{!1010, !1011, !1012, !1013}
!1010 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !1008, file: !463, line: 698, baseType: !632, size: 64)
!1011 = !DIDerivedType(tag: DW_TAG_member, name: "stack_ctx", scope: !1008, file: !463, line: 699, baseType: !632, size: 64, offset: 64)
!1012 = !DIDerivedType(tag: DW_TAG_member, name: "count", scope: !1008, file: !463, line: 700, baseType: !598, size: 32, offset: 128)
!1013 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !1008, file: !463, line: 701, baseType: !598, size: 32, offset: 160)
!1014 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !998, file: !463, line: 707, baseType: !598, size: 32, offset: 128)
!1015 = !DIDerivedType(tag: DW_TAG_member, name: "ev_queue", scope: !896, file: !463, line: 732, baseType: !1016, size: 64, offset: 54976)
!1016 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1017, size: 64)
!1017 = !DICompositeType(tag: DW_TAG_structure_type, name: "conn_queue", file: !463, line: 732, flags: DIFlagFwdDecl)
!1018 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_cache", scope: !896, file: !463, line: 733, baseType: !1019, size: 64, offset: 55040)
!1019 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1020, size: 64)
!1020 = !DIDerivedType(tag: DW_TAG_typedef, name: "cache_t", file: !1021, line: 39, baseType: !1022)
!1021 = !DIFile(filename: "./cache.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d97639c8540587a19d8550d7d7156448")
!1022 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !1021, line: 22, size: 704, elements: !1023)
!1023 = !{!1024, !1025, !1026, !1039, !1040, !1041, !1042, !1043}
!1024 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !1022, file: !1021, line: 24, baseType: !649, size: 320)
!1025 = !DIDerivedType(tag: DW_TAG_member, name: "name", scope: !1022, file: !1021, line: 26, baseType: !579, size: 64, offset: 320)
!1026 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !1022, file: !1021, line: 28, baseType: !1027, size: 128, offset: 384)
!1027 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_head", file: !1021, line: 28, size: 128, elements: !1028)
!1028 = !{!1029, !1037}
!1029 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !1027, file: !1021, line: 28, baseType: !1030, size: 64)
!1030 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1031, size: 64)
!1031 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_free_s", file: !1021, line: 12, size: 64, elements: !1032)
!1032 = !{!1033}
!1033 = !DIDerivedType(tag: DW_TAG_member, name: "c_next", scope: !1031, file: !1021, line: 13, baseType: !1034, size: 64)
!1034 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !1031, file: !1021, line: 13, size: 64, elements: !1035)
!1035 = !{!1036}
!1036 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !1034, file: !1021, line: 13, baseType: !1030, size: 64)
!1037 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !1027, file: !1021, line: 28, baseType: !1038, size: 64, offset: 64)
!1038 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1030, size: 64)
!1039 = !DIDerivedType(tag: DW_TAG_member, name: "bufsize", scope: !1022, file: !1021, line: 30, baseType: !747, size: 64, offset: 512)
!1040 = !DIDerivedType(tag: DW_TAG_member, name: "freetotal", scope: !1022, file: !1021, line: 32, baseType: !598, size: 32, offset: 576)
!1041 = !DIDerivedType(tag: DW_TAG_member, name: "total", scope: !1022, file: !1021, line: 34, baseType: !598, size: 32, offset: 608)
!1042 = !DIDerivedType(tag: DW_TAG_member, name: "freecurr", scope: !1022, file: !1021, line: 36, baseType: !598, size: 32, offset: 640)
!1043 = !DIDerivedType(tag: DW_TAG_member, name: "limit", scope: !1022, file: !1021, line: 38, baseType: !598, size: 32, offset: 672)
!1044 = !DIDerivedType(tag: DW_TAG_member, name: "open_bundle", scope: !896, file: !463, line: 734, baseType: !887, size: 64, offset: 55104)
!1045 = !DIDerivedType(tag: DW_TAG_member, name: "io_cache", scope: !896, file: !463, line: 735, baseType: !1019, size: 64, offset: 55168)
!1046 = !DIDerivedType(tag: DW_TAG_member, name: "storage", scope: !896, file: !463, line: 737, baseType: !632, size: 64, offset: 55232)
!1047 = !DIDerivedType(tag: DW_TAG_member, name: "l", scope: !896, file: !463, line: 739, baseType: !641, size: 64, offset: 55296)
!1048 = !DIDerivedType(tag: DW_TAG_member, name: "lru_bump_buf", scope: !896, file: !463, line: 740, baseType: !632, size: 64, offset: 55360)
!1049 = !DIDerivedType(tag: DW_TAG_member, name: "napi_id", scope: !896, file: !463, line: 744, baseType: !598, size: 32, offset: 55424)
!1050 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !889, file: !463, line: 808, baseType: !1051, size: 64, offset: 128)
!1051 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !889, size: 64)
!1052 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !889, file: !463, line: 809, baseType: !1051, size: 64, offset: 192)
!1053 = !DIDerivedType(tag: DW_TAG_member, name: "r", scope: !889, file: !463, line: 810, baseType: !1054, offset: 256)
!1054 = !DICompositeType(tag: DW_TAG_array_type, baseType: !883, elements: !620)
!1055 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !884, file: !463, line: 773, baseType: !1056, size: 64, offset: 64)
!1056 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !884, size: 64)
!1057 = !DIDerivedType(tag: DW_TAG_member, name: "wbytes", scope: !884, file: !463, line: 774, baseType: !598, size: 32, offset: 128)
!1058 = !DIDerivedType(tag: DW_TAG_member, name: "tosend", scope: !884, file: !463, line: 775, baseType: !598, size: 32, offset: 160)
!1059 = !DIDerivedType(tag: DW_TAG_member, name: "write_and_free", scope: !884, file: !463, line: 776, baseType: !632, size: 64, offset: 192)
!1060 = !DIDerivedType(tag: DW_TAG_member, name: "io_pending", scope: !884, file: !463, line: 777, baseType: !925, size: 64, offset: 256)
!1061 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !884, file: !463, line: 779, baseType: !1062, size: 64, offset: 320)
!1062 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1063, size: 64)
!1063 = !DIDerivedType(tag: DW_TAG_typedef, name: "item", file: !463, line: 616, baseType: !589)
!1064 = !DIDerivedType(tag: DW_TAG_member, name: "iov", scope: !884, file: !463, line: 780, baseType: !1065, size: 512, offset: 384)
!1065 = !DICompositeType(tag: DW_TAG_array_type, baseType: !1066, size: 512, elements: !37)
!1066 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iovec", file: !1067, line: 26, size: 128, elements: !1068)
!1067 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_iovec.h", directory: "", checksumkind: CSK_MD5, checksum: "a53f2c2488bb0e21e47850624c16538a")
!1068 = !{!1069, !1070}
!1069 = !DIDerivedType(tag: DW_TAG_member, name: "iov_base", scope: !1066, file: !1067, line: 28, baseType: !632, size: 64)
!1070 = !DIDerivedType(tag: DW_TAG_member, name: "iov_len", scope: !1066, file: !1067, line: 29, baseType: !747, size: 64, offset: 64)
!1071 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_total", scope: !884, file: !463, line: 781, baseType: !598, size: 32, offset: 896)
!1072 = !DIDerivedType(tag: DW_TAG_member, name: "iovcnt", scope: !884, file: !463, line: 782, baseType: !607, size: 8, offset: 928)
!1073 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_data_iov", scope: !884, file: !463, line: 783, baseType: !607, size: 8, offset: 936)
!1074 = !DIDerivedType(tag: DW_TAG_member, name: "skip", scope: !884, file: !463, line: 788, baseType: !790, size: 8, offset: 944)
!1075 = !DIDerivedType(tag: DW_TAG_member, name: "free", scope: !884, file: !463, line: 789, baseType: !790, size: 8, offset: 952)
!1076 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !884, file: !463, line: 794, baseType: !602, size: 16, offset: 960)
!1077 = !DIDerivedType(tag: DW_TAG_member, name: "udp_sequence", scope: !884, file: !463, line: 795, baseType: !602, size: 16, offset: 976)
!1078 = !DIDerivedType(tag: DW_TAG_member, name: "udp_total", scope: !884, file: !463, line: 796, baseType: !602, size: 16, offset: 992)
!1079 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !884, file: !463, line: 797, baseType: !1080, size: 224, offset: 1024)
!1080 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "sockaddr_in6", file: !1081, line: 262, size: 224, elements: !1082)
!1081 = !DIFile(filename: "/usr/include/netinet/in.h", directory: "", checksumkind: CSK_MD5, checksum: "fbd766480c8cb9a8fe07ee7aa568ee60")
!1082 = !{!1083, !1086, !1088, !1089, !1103}
!1083 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_family", scope: !1080, file: !1081, line: 264, baseType: !1084, size: 16)
!1084 = !DIDerivedType(tag: DW_TAG_typedef, name: "sa_family_t", file: !1085, line: 28, baseType: !600)
!1085 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/sockaddr.h", directory: "", checksumkind: CSK_MD5, checksum: "5066b774f0f3cdb5cbbb5467306060db")
!1086 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_port", scope: !1080, file: !1081, line: 265, baseType: !1087, size: 16, offset: 16)
!1087 = !DIDerivedType(tag: DW_TAG_typedef, name: "in_port_t", file: !1081, line: 125, baseType: !602)
!1088 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_flowinfo", scope: !1080, file: !1081, line: 266, baseType: !635, size: 32, offset: 32)
!1089 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_addr", scope: !1080, file: !1081, line: 267, baseType: !1090, size: 128, offset: 64)
!1090 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "in6_addr", file: !1081, line: 221, size: 128, elements: !1091)
!1091 = !{!1092}
!1092 = !DIDerivedType(tag: DW_TAG_member, name: "__in6_u", scope: !1090, file: !1081, line: 228, baseType: !1093, size: 128)
!1093 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !1090, file: !1081, line: 223, size: 128, elements: !1094)
!1094 = !{!1095, !1099, !1101}
!1095 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr8", scope: !1093, file: !1081, line: 225, baseType: !1096, size: 128)
!1096 = !DICompositeType(tag: DW_TAG_array_type, baseType: !607, size: 128, elements: !1097)
!1097 = !{!1098}
!1098 = !DISubrange(count: 16)
!1099 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr16", scope: !1093, file: !1081, line: 226, baseType: !1100, size: 128)
!1100 = !DICompositeType(tag: DW_TAG_array_type, baseType: !602, size: 128, elements: !72)
!1101 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr32", scope: !1093, file: !1081, line: 227, baseType: !1102, size: 128)
!1102 = !DICompositeType(tag: DW_TAG_array_type, baseType: !635, size: 128, elements: !37)
!1103 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_scope_id", scope: !1080, file: !1081, line: 268, baseType: !635, size: 32, offset: 192)
!1104 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !884, file: !463, line: 798, baseType: !1105, size: 32, offset: 1248)
!1105 = !DIDerivedType(tag: DW_TAG_typedef, name: "socklen_t", file: !1106, line: 33, baseType: !1107)
!1106 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/socket.h", directory: "", checksumkind: CSK_MD5, checksum: "71a09f67661e8e55cf505c19b5ddbb85")
!1107 = !DIDerivedType(tag: DW_TAG_typedef, name: "__socklen_t", file: !605, line: 210, baseType: !464)
!1108 = !DIDerivedType(tag: DW_TAG_member, name: "wbuf", scope: !884, file: !463, line: 800, baseType: !1109, size: 8192, offset: 1280)
!1109 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 8192, elements: !1110)
!1110 = !{!1111}
!1111 = !DISubrange(count: 1024)
!1112 = !DIDerivedType(tag: DW_TAG_member, name: "resp_head", scope: !782, file: !463, line: 857, baseType: !882, size: 64, offset: 1600)
!1113 = !DIDerivedType(tag: DW_TAG_member, name: "ritem", scope: !782, file: !463, line: 858, baseType: !579, size: 64, offset: 1664)
!1114 = !DIDerivedType(tag: DW_TAG_member, name: "rlbytes", scope: !782, file: !463, line: 859, baseType: !598, size: 32, offset: 1728)
!1115 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !782, file: !463, line: 867, baseType: !632, size: 64, offset: 1792)
!1116 = !DIDerivedType(tag: DW_TAG_member, name: "sbytes", scope: !782, file: !463, line: 870, baseType: !598, size: 32, offset: 1856)
!1117 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues_submitted", scope: !782, file: !463, line: 872, baseType: !598, size: 32, offset: 1888)
!1118 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !782, file: !463, line: 873, baseType: !1119, size: 576, offset: 1920)
!1119 = !DICompositeType(tag: DW_TAG_array_type, baseType: !1007, size: 576, elements: !5)
!1120 = !DIDerivedType(tag: DW_TAG_member, name: "recache_counter", scope: !782, file: !463, line: 878, baseType: !464, size: 32, offset: 2496)
!1121 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !782, file: !463, line: 880, baseType: !515, size: 32, offset: 2528)
!1122 = !DIDerivedType(tag: DW_TAG_member, name: "transport", scope: !782, file: !463, line: 881, baseType: !520, size: 32, offset: 2560)
!1123 = !DIDerivedType(tag: DW_TAG_member, name: "close_reason", scope: !782, file: !463, line: 882, baseType: !525, size: 32, offset: 2592)
!1124 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !782, file: !463, line: 885, baseType: !598, size: 32, offset: 2624)
!1125 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !782, file: !463, line: 886, baseType: !1080, size: 224, offset: 2656)
!1126 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !782, file: !463, line: 887, baseType: !1105, size: 32, offset: 2880)
!1127 = !DIDerivedType(tag: DW_TAG_member, name: "noreply", scope: !782, file: !463, line: 889, baseType: !790, size: 8, offset: 2912)
!1128 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !782, file: !463, line: 895, baseType: !1129, size: 192, offset: 2944)
!1129 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !782, file: !463, line: 891, size: 192, elements: !1130)
!1130 = !{!1131, !1132, !1133}
!1131 = !DIDerivedType(tag: DW_TAG_member, name: "buffer", scope: !1129, file: !463, line: 892, baseType: !579, size: 64)
!1132 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !1129, file: !463, line: 893, baseType: !747, size: 64, offset: 64)
!1133 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !1129, file: !463, line: 894, baseType: !747, size: 64, offset: 128)
!1134 = !DIDerivedType(tag: DW_TAG_member, name: "binary_header", scope: !782, file: !463, line: 899, baseType: !1135, size: 192, offset: 3136)
!1135 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_request_header", file: !1136, line: 164, baseType: !1137)
!1136 = !DIFile(filename: "./protocol_binary.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "7a322a65fa8661e9a597acbeeeb23107")
!1137 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !1136, line: 151, size: 192, elements: !1138)
!1138 = !{!1139, !1151}
!1139 = !DIDerivedType(tag: DW_TAG_member, name: "request", scope: !1137, file: !1136, line: 162, baseType: !1140, size: 192)
!1140 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !1137, file: !1136, line: 152, size: 192, elements: !1141)
!1141 = !{!1142, !1143, !1144, !1145, !1146, !1147, !1148, !1149, !1150}
!1142 = !DIDerivedType(tag: DW_TAG_member, name: "magic", scope: !1140, file: !1136, line: 153, baseType: !607, size: 8)
!1143 = !DIDerivedType(tag: DW_TAG_member, name: "opcode", scope: !1140, file: !1136, line: 154, baseType: !607, size: 8, offset: 8)
!1144 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !1140, file: !1136, line: 155, baseType: !602, size: 16, offset: 16)
!1145 = !DIDerivedType(tag: DW_TAG_member, name: "extlen", scope: !1140, file: !1136, line: 156, baseType: !607, size: 8, offset: 32)
!1146 = !DIDerivedType(tag: DW_TAG_member, name: "datatype", scope: !1140, file: !1136, line: 157, baseType: !607, size: 8, offset: 40)
!1147 = !DIDerivedType(tag: DW_TAG_member, name: "reserved", scope: !1140, file: !1136, line: 158, baseType: !602, size: 16, offset: 48)
!1148 = !DIDerivedType(tag: DW_TAG_member, name: "bodylen", scope: !1140, file: !1136, line: 159, baseType: !635, size: 32, offset: 64)
!1149 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !1140, file: !1136, line: 160, baseType: !635, size: 32, offset: 96)
!1150 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !1140, file: !1136, line: 161, baseType: !616, size: 64, offset: 128)
!1151 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !1137, file: !1136, line: 163, baseType: !1152, size: 192)
!1152 = !DICompositeType(tag: DW_TAG_array_type, baseType: !607, size: 192, elements: !1153)
!1153 = !{!1154}
!1154 = !DISubrange(count: 24)
!1155 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !782, file: !463, line: 900, baseType: !616, size: 64, offset: 3328)
!1156 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !782, file: !463, line: 901, baseType: !616, size: 64, offset: 3392)
!1157 = !DIDerivedType(tag: DW_TAG_member, name: "cmd", scope: !782, file: !463, line: 902, baseType: !663, size: 16, offset: 3456)
!1158 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !782, file: !463, line: 903, baseType: !598, size: 32, offset: 3488)
!1159 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !782, file: !463, line: 904, baseType: !598, size: 32, offset: 3520)
!1160 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !782, file: !463, line: 905, baseType: !780, size: 64, offset: 3584)
!1161 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !782, file: !463, line: 906, baseType: !894, size: 64, offset: 3648)
!1162 = !DIDerivedType(tag: DW_TAG_member, name: "try_read_command", scope: !782, file: !463, line: 907, baseType: !1163, size: 64, offset: 3712)
!1163 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1164, size: 64)
!1164 = !DISubroutineType(types: !1165)
!1165 = !{!598, !780}
!1166 = !DIDerivedType(tag: DW_TAG_member, name: "read", scope: !782, file: !463, line: 908, baseType: !1167, size: 64, offset: 3776)
!1167 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1168, size: 64)
!1168 = !DISubroutineType(types: !1169)
!1169 = !{!1170, !780, !632, !747}
!1170 = !DIDerivedType(tag: DW_TAG_typedef, name: "ssize_t", file: !1171, line: 108, baseType: !1172)
!1171 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/types.h", directory: "", checksumkind: CSK_MD5, checksum: "7fb02a803b0c9b11cb5276b77d21e9d8")
!1172 = !DIDerivedType(tag: DW_TAG_typedef, name: "__ssize_t", file: !605, line: 194, baseType: !675)
!1173 = !DIDerivedType(tag: DW_TAG_member, name: "sendmsg", scope: !782, file: !463, line: 909, baseType: !1174, size: 64, offset: 3840)
!1174 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1175, size: 64)
!1175 = !DISubroutineType(types: !1176)
!1176 = !{!1170, !780, !1177, !598}
!1177 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1178, size: 64)
!1178 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "msghdr", file: !1106, line: 262, size: 448, elements: !1179)
!1179 = !{!1180, !1181, !1182, !1184, !1185, !1186, !1187}
!1180 = !DIDerivedType(tag: DW_TAG_member, name: "msg_name", scope: !1178, file: !1106, line: 264, baseType: !632, size: 64)
!1181 = !DIDerivedType(tag: DW_TAG_member, name: "msg_namelen", scope: !1178, file: !1106, line: 265, baseType: !1105, size: 32, offset: 64)
!1182 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iov", scope: !1178, file: !1106, line: 267, baseType: !1183, size: 64, offset: 128)
!1183 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1066, size: 64)
!1184 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iovlen", scope: !1178, file: !1106, line: 268, baseType: !747, size: 64, offset: 192)
!1185 = !DIDerivedType(tag: DW_TAG_member, name: "msg_control", scope: !1178, file: !1106, line: 270, baseType: !632, size: 64, offset: 256)
!1186 = !DIDerivedType(tag: DW_TAG_member, name: "msg_controllen", scope: !1178, file: !1106, line: 271, baseType: !747, size: 64, offset: 320)
!1187 = !DIDerivedType(tag: DW_TAG_member, name: "msg_flags", scope: !1178, file: !1106, line: 276, baseType: !598, size: 32, offset: 384)
!1188 = !DIDerivedType(tag: DW_TAG_member, name: "write", scope: !782, file: !463, line: 910, baseType: !1167, size: 64, offset: 3904)
!1189 = !{!1190, !1191, !1192, !1193, !1194, !1195, !1196, !1199, !1200}
!1190 = !DILocalVariable(name: "c", arg: 1, scope: !777, file: !2, line: 134, type: !780)
!1191 = !DILocalVariable(name: "it", scope: !777, file: !2, line: 137, type: !1062)
!1192 = !DILocalVariable(name: "comm", scope: !777, file: !2, line: 138, type: !598)
!1193 = !DILocalVariable(name: "ret", scope: !777, file: !2, line: 139, type: !531)
!1194 = !DILocalVariable(name: "is_valid", scope: !777, file: !2, line: 140, type: !790)
!1195 = !DILocalVariable(name: "nbytes", scope: !777, file: !2, line: 141, type: !598)
!1196 = !DILocalVariable(name: "buf", scope: !1197, file: !2, line: 152, type: !762)
!1197 = distinct !DILexicalBlock(scope: !1198, file: !2, line: 151, column: 12)
!1198 = distinct !DILexicalBlock(scope: !777, file: !2, line: 147, column: 9)
!1199 = !DILocalVariable(name: "ch", scope: !1197, file: !2, line: 154, type: !580)
!1200 = !DILocalVariable(name: "cas", scope: !1201, file: !2, line: 182, type: !616)
!1201 = distinct !DILexicalBlock(scope: !1202, file: !2, line: 181, column: 12)
!1202 = distinct !DILexicalBlock(scope: !777, file: !2, line: 175, column: 9)
!1203 = distinct !DIAssignID()
!1204 = !DILocation(line: 0, scope: !777)
!1205 = distinct !DIAssignID()
!1206 = !DILocation(line: 0, scope: !1197)
!1207 = distinct !DIAssignID()
!1208 = !DILocation(line: 0, scope: !1201)
!1209 = !DILocation(line: 137, column: 19, scope: !777)
!1210 = !{!1211, !1212, i64 224}
!1211 = !{!"conn", !1212, i64 0, !1215, i64 8, !1216, i64 12, !1216, i64 13, !1216, i64 14, !1216, i64 15, !1216, i64 16, !1216, i64 17, !1216, i64 18, !1215, i64 20, !1215, i64 24, !1215, i64 28, !1217, i64 32, !1220, i64 160, !1220, i64 162, !1212, i64 168, !1212, i64 176, !1215, i64 184, !1215, i64 188, !1212, i64 192, !1212, i64 200, !1212, i64 208, !1215, i64 216, !1212, i64 224, !1215, i64 232, !1215, i64 236, !1213, i64 240, !1215, i64 312, !1215, i64 316, !1215, i64 320, !1215, i64 324, !1215, i64 328, !1223, i64 332, !1215, i64 360, !1216, i64 364, !1225, i64 368, !1213, i64 392, !1222, i64 416, !1222, i64 424, !1220, i64 432, !1215, i64 436, !1215, i64 440, !1212, i64 448, !1212, i64 456, !1212, i64 464, !1212, i64 472, !1212, i64 480, !1212, i64 488}
!1212 = !{!"any pointer", !1213, i64 0}
!1213 = !{!"omnipotent char", !1214, i64 0}
!1214 = !{!"Simple C/C++ TBAA"}
!1215 = !{!"int", !1213, i64 0}
!1216 = !{!"_Bool", !1213, i64 0}
!1217 = !{!"event", !1218, i64 0, !1213, i64 40, !1215, i64 56, !1212, i64 64, !1213, i64 72, !1220, i64 104, !1220, i64 106, !1221, i64 112}
!1218 = !{!"event_callback", !1219, i64 0, !1220, i64 16, !1213, i64 18, !1213, i64 19, !1213, i64 24, !1212, i64 32}
!1219 = !{!"", !1212, i64 0, !1212, i64 8}
!1220 = !{!"short", !1213, i64 0}
!1221 = !{!"timeval", !1222, i64 0, !1222, i64 8}
!1222 = !{!"long", !1213, i64 0}
!1223 = !{!"sockaddr_in6", !1220, i64 0, !1220, i64 2, !1215, i64 4, !1224, i64 8, !1215, i64 24}
!1224 = !{!"in6_addr", !1213, i64 0}
!1225 = !{!"", !1212, i64 0, !1222, i64 8, !1222, i64 16}
!1226 = !DILocation(line: 138, column: 19, scope: !777)
!1227 = !{!1211, !1220, i64 432}
!1228 = !DILocation(line: 138, column: 16, scope: !777)
!1229 = !DILocation(line: 141, column: 5, scope: !777)
!1230 = !DILocation(line: 141, column: 9, scope: !777)
!1231 = !{!1215, !1215, i64 0}
!1232 = distinct !DIAssignID()
!1233 = !DILocation(line: 143, column: 28, scope: !777)
!1234 = !{!1211, !1212, i64 456}
!1235 = !DILocation(line: 143, column: 36, scope: !777)
!1236 = !DILocation(line: 143, column: 5, scope: !777)
!1237 = !DILocation(line: 144, column: 8, scope: !777)
!1238 = !DILocation(line: 144, column: 22, scope: !777)
!1239 = !DILocation(line: 144, column: 33, scope: !777)
!1240 = !{!1213, !1213, i64 0}
!1241 = !DILocation(line: 144, column: 5, scope: !777)
!1242 = !DILocation(line: 144, column: 57, scope: !777)
!1243 = !{!1244, !1222, i64 0}
!1244 = !{!"slab_stats", !1222, i64 0, !1222, i64 8, !1222, i64 16, !1222, i64 24, !1222, i64 32, !1222, i64 40, !1222, i64 48, !1222, i64 56}
!1245 = !DILocation(line: 145, column: 38, scope: !777)
!1246 = !DILocation(line: 145, column: 5, scope: !777)
!1247 = !DILocation(line: 147, column: 14, scope: !1198)
!1248 = !{!1220, !1220, i64 0}
!1249 = !DILocation(line: 147, column: 10, scope: !1198)
!1250 = !DILocation(line: 147, column: 23, scope: !1198)
!1251 = !DILocation(line: 147, column: 39, scope: !1198)
!1252 = !DILocation(line: 147, column: 9, scope: !777)
!1253 = !DILocation(line: 152, column: 9, scope: !1197)
!1254 = !DILocation(line: 154, column: 44, scope: !1197)
!1255 = !{!1211, !1212, i64 208}
!1256 = !DILocation(line: 159, column: 17, scope: !1257)
!1257 = distinct !DILexicalBlock(scope: !1197, file: !2, line: 159, column: 13)
!1258 = !DILocation(line: 159, column: 22, scope: !1257)
!1259 = !DILocation(line: 159, column: 13, scope: !1197)
!1260 = !DILocation(line: 160, column: 26, scope: !1261)
!1261 = distinct !DILexicalBlock(scope: !1257, file: !2, line: 159, column: 27)
!1262 = !DILocation(line: 160, column: 40, scope: !1261)
!1263 = !DILocation(line: 160, column: 22, scope: !1261)
!1264 = distinct !DIAssignID()
!1265 = !DILocation(line: 161, column: 40, scope: !1261)
!1266 = !DILocation(line: 161, column: 22, scope: !1261)
!1267 = distinct !DIAssignID()
!1268 = !DILocation(line: 162, column: 9, scope: !1261)
!1269 = !DILocation(line: 165, column: 26, scope: !1270)
!1270 = distinct !DILexicalBlock(scope: !1257, file: !2, line: 162, column: 16)
!1271 = !{!1212, !1212, i64 0}
!1272 = !DILocation(line: 165, column: 32, scope: !1270)
!1273 = !DILocation(line: 165, column: 47, scope: !1270)
!1274 = !DILocation(line: 165, column: 52, scope: !1270)
!1275 = !DILocation(line: 165, column: 22, scope: !1270)
!1276 = !DILocation(line: 166, column: 26, scope: !1270)
!1277 = !DILocation(line: 166, column: 40, scope: !1270)
!1278 = !DILocation(line: 166, column: 22, scope: !1270)
!1279 = !DILocation(line: 0, scope: !1257)
!1280 = !DILocation(line: 168, column: 13, scope: !1281)
!1281 = distinct !DILexicalBlock(scope: !1197, file: !2, line: 168, column: 13)
!1282 = !DILocation(line: 168, column: 37, scope: !1281)
!1283 = !DILocation(line: 173, column: 5, scope: !1198)
!1284 = !DILocation(line: 175, column: 9, scope: !777)
!1285 = !DILocation(line: 148, column: 21, scope: !1286)
!1286 = distinct !DILexicalBlock(scope: !1287, file: !2, line: 148, column: 13)
!1287 = distinct !DILexicalBlock(scope: !1198, file: !2, line: 147, column: 45)
!1288 = !DILocation(line: 148, column: 41, scope: !1286)
!1289 = !DILocation(line: 148, column: 35, scope: !1286)
!1290 = !DILocation(line: 148, column: 48, scope: !1286)
!1291 = !DILocation(line: 148, column: 64, scope: !1286)
!1292 = !DILocation(line: 177, column: 16, scope: !1293)
!1293 = distinct !DILexicalBlock(scope: !1294, file: !2, line: 177, column: 13)
!1294 = distinct !DILexicalBlock(scope: !1202, file: !2, line: 175, column: 20)
!1295 = !{!1211, !1216, i64 15}
!1296 = !{i8 0, i8 2}
!1297 = !{}
!1298 = !DILocation(line: 177, column: 13, scope: !1294)
!1299 = !DILocation(line: 178, column: 16, scope: !1300)
!1300 = distinct !DILexicalBlock(scope: !1293, file: !2, line: 177, column: 26)
!1301 = !DILocation(line: 178, column: 24, scope: !1300)
!1302 = !{!1211, !1216, i64 364}
!1303 = !DILocation(line: 179, column: 9, scope: !1300)
!1304 = !DILocation(line: 180, column: 9, scope: !1294)
!1305 = !DILocation(line: 181, column: 5, scope: !1294)
!1306 = !DILocation(line: 182, column: 7, scope: !1201)
!1307 = !DILocation(line: 182, column: 16, scope: !1201)
!1308 = !{!1222, !1222, i64 0}
!1309 = distinct !DIAssignID()
!1310 = !DILocation(line: 183, column: 31, scope: !1201)
!1311 = !{!1211, !1215, i64 8}
!1312 = !DILocation(line: 183, column: 10, scope: !1201)
!1313 = !DILocation(line: 183, column: 18, scope: !1201)
!1314 = !DILocation(line: 183, column: 26, scope: !1201)
!1315 = !{!1316, !1215, i64 344}
!1316 = !{!"", !1222, i64 0, !1212, i64 8, !1317, i64 16, !1317, i64 152, !1213, i64 288, !1318, i64 328, !1215, i64 344, !1215, i64 348, !1319, i64 352, !1213, i64 6800, !1212, i64 6872, !1212, i64 6880, !1212, i64 6888, !1212, i64 6896, !1212, i64 6904, !1212, i64 6912, !1212, i64 6920, !1215, i64 6928}
!1317 = !{!"thread_notify", !1217, i64 0, !1215, i64 128}
!1318 = !{!"iop_head_s", !1212, i64 0, !1212, i64 8}
!1319 = !{!"thread_stats", !1213, i64 0, !1222, i64 40, !1222, i64 48, !1222, i64 56, !1222, i64 64, !1222, i64 72, !1222, i64 80, !1222, i64 88, !1222, i64 96, !1222, i64 104, !1222, i64 112, !1222, i64 120, !1222, i64 128, !1222, i64 136, !1222, i64 144, !1222, i64 152, !1222, i64 160, !1222, i64 168, !1222, i64 176, !1222, i64 184, !1222, i64 192, !1222, i64 200, !1222, i64 208, !1222, i64 216, !1222, i64 224, !1222, i64 232, !1222, i64 240, !1222, i64 248, !1222, i64 256, !1222, i64 264, !1222, i64 272, !1213, i64 280, !1213, i64 4376, !1222, i64 6424, !1222, i64 6432, !1222, i64 6440}
!1320 = !DILocation(line: 184, column: 63, scope: !1201)
!1321 = !{!1211, !1222, i64 416}
!1322 = !DILocation(line: 184, column: 60, scope: !1201)
!1323 = !DILocation(line: 184, column: 78, scope: !1201)
!1324 = !DILocation(line: 184, column: 95, scope: !1201)
!1325 = !{!1211, !1216, i64 14}
!1326 = !DILocation(line: 184, column: 13, scope: !1201)
!1327 = !DILocation(line: 185, column: 14, scope: !1201)
!1328 = !DILocation(line: 216, column: 14, scope: !1329)
!1329 = distinct !DILexicalBlock(scope: !1201, file: !2, line: 216, column: 11)
!1330 = !DILocation(line: 216, column: 11, scope: !1201)
!1331 = !DILocation(line: 217, column: 29, scope: !1332)
!1332 = distinct !DILexicalBlock(scope: !1329, file: !2, line: 216, column: 24)
!1333 = !DILocation(line: 217, column: 42, scope: !1332)
!1334 = !DILocalVariable(name: "c", arg: 1, scope: !1335, file: !2, line: 54, type: !780)
!1335 = distinct !DISubprogram(name: "_finalize_mset", scope: !2, file: !2, line: 54, type: !1336, scopeLine: 54, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !1338)
!1336 = !DISubroutineType(types: !1337)
!1337 = !{null, !780, !598, !531, !616}
!1338 = !{!1334, !1339, !1340, !1341, !1342, !1343, !1344, !1345, !1346}
!1339 = !DILocalVariable(name: "nbytes", arg: 2, scope: !1335, file: !2, line: 54, type: !598)
!1340 = !DILocalVariable(name: "ret", arg: 3, scope: !1335, file: !2, line: 54, type: !531)
!1341 = !DILocalVariable(name: "cas", arg: 4, scope: !1335, file: !2, line: 54, type: !616)
!1342 = !DILocalVariable(name: "resp", scope: !1335, file: !2, line: 55, type: !882)
!1343 = !DILocalVariable(name: "it", scope: !1335, file: !2, line: 56, type: !1062)
!1344 = !DILocalVariable(name: "p", scope: !1335, file: !2, line: 60, type: !579)
!1345 = !DILocalVariable(name: "end", scope: !1335, file: !2, line: 61, type: !579)
!1346 = !DILocalVariable(name: "fp", scope: !1347, file: !2, line: 87, type: !579)
!1347 = distinct !DILexicalBlock(scope: !1335, file: !2, line: 87, column: 5)
!1348 = !DILocation(line: 0, scope: !1335, inlinedAt: !1349)
!1349 = distinct !DILocation(line: 217, column: 11, scope: !1332)
!1350 = !DILocation(line: 55, column: 24, scope: !1335, inlinedAt: !1349)
!1351 = !{!1211, !1212, i64 192}
!1352 = !DILocation(line: 56, column: 19, scope: !1335, inlinedAt: !1349)
!1353 = !DILocation(line: 57, column: 5, scope: !1335, inlinedAt: !1349)
!1354 = !DILocation(line: 60, column: 34, scope: !1335, inlinedAt: !1349)
!1355 = !{!1356, !1215, i64 16}
!1356 = !{!"_mc_resp", !1212, i64 0, !1212, i64 8, !1215, i64 16, !1215, i64 20, !1212, i64 24, !1212, i64 32, !1212, i64 40, !1213, i64 48, !1215, i64 112, !1213, i64 116, !1213, i64 117, !1216, i64 118, !1216, i64 119, !1220, i64 120, !1220, i64 122, !1220, i64 124, !1223, i64 128, !1215, i64 156, !1213, i64 160}
!1357 = !DILocation(line: 60, column: 26, scope: !1335, inlinedAt: !1349)
!1358 = !DILocation(line: 63, column: 5, scope: !1335, inlinedAt: !1349)
!1359 = !DILocation(line: 65, column: 7, scope: !1360, inlinedAt: !1349)
!1360 = distinct !DILexicalBlock(scope: !1335, file: !2, line: 63, column: 18)
!1361 = !DILocation(line: 67, column: 14, scope: !1362, inlinedAt: !1349)
!1362 = distinct !DILexicalBlock(scope: !1360, file: !2, line: 67, column: 11)
!1363 = !DILocation(line: 67, column: 11, scope: !1360, inlinedAt: !1349)
!1364 = !DILocation(line: 68, column: 17, scope: !1365, inlinedAt: !1349)
!1365 = distinct !DILexicalBlock(scope: !1362, file: !2, line: 67, column: 23)
!1366 = !DILocation(line: 68, column: 22, scope: !1365, inlinedAt: !1349)
!1367 = !{!1356, !1216, i64 118}
!1368 = !DILocation(line: 69, column: 7, scope: !1365, inlinedAt: !1349)
!1369 = !DILocation(line: 72, column: 7, scope: !1360, inlinedAt: !1349)
!1370 = !DILocation(line: 73, column: 7, scope: !1360, inlinedAt: !1349)
!1371 = !DILocation(line: 75, column: 7, scope: !1360, inlinedAt: !1349)
!1372 = !DILocation(line: 76, column: 7, scope: !1360, inlinedAt: !1349)
!1373 = !DILocation(line: 78, column: 7, scope: !1360, inlinedAt: !1349)
!1374 = !DILocation(line: 79, column: 7, scope: !1360, inlinedAt: !1349)
!1375 = !DILocation(line: 81, column: 10, scope: !1360, inlinedAt: !1349)
!1376 = !DILocation(line: 81, column: 18, scope: !1360, inlinedAt: !1349)
!1377 = !DILocation(line: 82, column: 7, scope: !1360, inlinedAt: !1349)
!1378 = !DILocation(line: 83, column: 7, scope: !1360, inlinedAt: !1349)
!1379 = !DILocation(line: 85, column: 7, scope: !1335, inlinedAt: !1349)
!1380 = !DILocation(line: 0, scope: !1347, inlinedAt: !1349)
!1381 = !DILocation(line: 87, column: 36, scope: !1382, inlinedAt: !1349)
!1382 = distinct !DILexicalBlock(scope: !1347, file: !2, line: 87, column: 5)
!1383 = !DILocation(line: 87, column: 5, scope: !1347, inlinedAt: !1349)
!1384 = !DILocation(line: 123, column: 5, scope: !1335, inlinedAt: !1349)
!1385 = !DILocation(line: 124, column: 7, scope: !1335, inlinedAt: !1349)
!1386 = !DILocation(line: 126, column: 22, scope: !1335, inlinedAt: !1349)
!1387 = !DILocation(line: 126, column: 20, scope: !1335, inlinedAt: !1349)
!1388 = !DILocation(line: 126, column: 18, scope: !1335, inlinedAt: !1349)
!1389 = !DILocation(line: 127, column: 31, scope: !1335, inlinedAt: !1349)
!1390 = !DILocation(line: 127, column: 29, scope: !1335, inlinedAt: !1349)
!1391 = !DILocation(line: 127, column: 5, scope: !1335, inlinedAt: !1349)
!1392 = !DILocation(line: 128, column: 1, scope: !1335, inlinedAt: !1349)
!1393 = !DILocation(line: 88, column: 17, scope: !1394, inlinedAt: !1349)
!1394 = distinct !DILexicalBlock(scope: !1382, file: !2, line: 87, column: 49)
!1395 = !DILocation(line: 88, column: 9, scope: !1394, inlinedAt: !1349)
!1396 = !DILocation(line: 91, column: 17, scope: !1397, inlinedAt: !1349)
!1397 = distinct !DILexicalBlock(scope: !1398, file: !2, line: 91, column: 17)
!1398 = distinct !DILexicalBlock(scope: !1394, file: !2, line: 88, column: 22)
!1399 = !DILocation(line: 0, scope: !1398, inlinedAt: !1349)
!1400 = !DILocation(line: 92, column: 27, scope: !1398, inlinedAt: !1349)
!1401 = !DILocation(line: 92, column: 33, scope: !1398, inlinedAt: !1349)
!1402 = !DILocation(line: 92, column: 36, scope: !1398, inlinedAt: !1349)
!1403 = !DILocation(line: 92, column: 40, scope: !1398, inlinedAt: !1349)
!1404 = !DILocation(line: 92, column: 17, scope: !1398, inlinedAt: !1349)
!1405 = !DILocation(line: 93, column: 24, scope: !1406, inlinedAt: !1349)
!1406 = distinct !DILexicalBlock(scope: !1398, file: !2, line: 92, column: 48)
!1407 = !DILocation(line: 95, column: 23, scope: !1406, inlinedAt: !1349)
!1408 = distinct !{!1408, !1404, !1409, !1410}
!1409 = !DILocation(line: 96, column: 17, scope: !1398, inlinedAt: !1349)
!1410 = !{!"llvm.loop.mustprogress"}
!1411 = !DILocation(line: 100, column: 17, scope: !1412, inlinedAt: !1349)
!1412 = distinct !DILexicalBlock(scope: !1413, file: !2, line: 100, column: 17)
!1413 = distinct !DILexicalBlock(scope: !1398, file: !2, line: 100, column: 17)
!1414 = !DILocation(line: 100, column: 17, scope: !1415, inlinedAt: !1349)
!1415 = distinct !DILexicalBlock(scope: !1413, file: !2, line: 100, column: 17)
!1416 = !DILocation(line: 100, column: 17, scope: !1413, inlinedAt: !1349)
!1417 = !DILocation(line: 100, column: 17, scope: !1418, inlinedAt: !1349)
!1418 = distinct !DILexicalBlock(scope: !1415, file: !2, line: 100, column: 17)
!1419 = !DILocation(line: 100, column: 17, scope: !1420, inlinedAt: !1349)
!1420 = distinct !DILexicalBlock(scope: !1415, file: !2, line: 100, column: 17)
!1421 = !DILocation(line: 105, column: 17, scope: !1422, inlinedAt: !1349)
!1422 = distinct !DILexicalBlock(scope: !1398, file: !2, line: 105, column: 17)
!1423 = !DILocation(line: 106, column: 21, scope: !1398, inlinedAt: !1349)
!1424 = !DILocation(line: 107, column: 17, scope: !1398, inlinedAt: !1349)
!1425 = !DILocation(line: 110, column: 17, scope: !1426, inlinedAt: !1349)
!1426 = distinct !DILexicalBlock(scope: !1398, file: !2, line: 110, column: 17)
!1427 = !DILocation(line: 112, column: 21, scope: !1398, inlinedAt: !1349)
!1428 = !DILocation(line: 113, column: 25, scope: !1429, inlinedAt: !1349)
!1429 = distinct !DILexicalBlock(scope: !1430, file: !2, line: 112, column: 34)
!1430 = distinct !DILexicalBlock(scope: !1398, file: !2, line: 112, column: 21)
!1431 = !DILocation(line: 114, column: 17, scope: !1429, inlinedAt: !1349)
!1432 = !DILocation(line: 115, column: 38, scope: !1433, inlinedAt: !1349)
!1433 = distinct !DILexicalBlock(scope: !1430, file: !2, line: 114, column: 24)
!1434 = !DILocation(line: 115, column: 44, scope: !1433, inlinedAt: !1349)
!1435 = !DILocation(line: 115, column: 25, scope: !1433, inlinedAt: !1349)
!1436 = !DILocation(line: 87, column: 16, scope: !1347, inlinedAt: !1349)
!1437 = !DILocation(line: 87, column: 45, scope: !1382, inlinedAt: !1349)
!1438 = distinct !{!1438, !1383, !1439, !1410}
!1439 = !DILocation(line: 121, column: 5, scope: !1347, inlinedAt: !1349)
!1440 = !DILocation(line: 219, column: 11, scope: !1441)
!1441 = distinct !DILexicalBlock(scope: !1329, file: !2, line: 218, column: 14)
!1442 = !DILocation(line: 221, column: 15, scope: !1443)
!1443 = distinct !DILexicalBlock(scope: !1441, file: !2, line: 219, column: 24)
!1444 = !DILocation(line: 222, column: 15, scope: !1443)
!1445 = !DILocation(line: 224, column: 15, scope: !1443)
!1446 = !DILocation(line: 225, column: 15, scope: !1443)
!1447 = !DILocation(line: 227, column: 15, scope: !1443)
!1448 = !DILocation(line: 228, column: 15, scope: !1443)
!1449 = !DILocation(line: 230, column: 15, scope: !1443)
!1450 = !DILocation(line: 231, column: 15, scope: !1443)
!1451 = !DILocation(line: 233, column: 15, scope: !1443)
!1452 = !DILocation(line: 234, column: 11, scope: !1443)
!1453 = !DILocation(line: 237, column: 5, scope: !1202)
!1454 = !DILocation(line: 239, column: 8, scope: !777)
!1455 = !DILocation(line: 239, column: 18, scope: !777)
!1456 = !DILocation(line: 240, column: 8, scope: !777)
!1457 = !DILocation(line: 240, column: 17, scope: !777)
!1458 = !DILocation(line: 241, column: 20, scope: !777)
!1459 = !DILocation(line: 241, column: 5, scope: !777)
!1460 = !DILocation(line: 242, column: 13, scope: !777)
!1461 = !DILocation(line: 243, column: 1, scope: !777)
!1462 = !DISubprogram(name: "pthread_mutex_lock", scope: !1463, file: !1463, line: 794, type: !1464, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1463 = !DIFile(filename: "/usr/include/pthread.h", directory: "", checksumkind: CSK_MD5, checksum: "cbcd748b3d3ecaa7356dc2925b45d819")
!1464 = !DISubroutineType(types: !1465)
!1465 = !{!598, !1466}
!1466 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !649, size: 64)
!1467 = !DISubprogram(name: "pthread_mutex_unlock", scope: !1463, file: !1463, line: 835, type: !1464, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1468 = !DISubprogram(name: "strncmp", scope: !1469, file: !1469, line: 159, type: !1470, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1469 = !DIFile(filename: "/usr/include/string.h", directory: "", checksumkind: CSK_MD5, checksum: "165db1185644f68894fa9e0d17055d70")
!1470 = !DISubroutineType(types: !1471)
!1471 = !{!598, !1472, !1472, !747}
!1472 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1473, size: 64)
!1473 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !4)
!1474 = !DISubprogram(name: "out_string", scope: !463, file: !463, line: 1043, type: !1475, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1475 = !DISubroutineType(types: !1476)
!1476 = !{null, !780, !1472}
!1477 = !DISubprogram(name: "store_item", scope: !463, file: !463, line: 1040, type: !1478, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1478 = !DISubroutineType(types: !1479)
!1479 = !{!531, !1062, !598, !894, !1480, !1481, !1482, !790}
!1480 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !598, size: 64)
!1481 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !616, size: 64)
!1482 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !616)
!1483 = !DISubprogram(name: "get_cas_id", scope: !1484, file: !1484, line: 10, type: !1485, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1484 = !DIFile(filename: "./items.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "5548db7354621bc680fd5812e10230ba")
!1485 = !DISubroutineType(types: !1486)
!1486 = !{!616}
!1487 = !DISubprogram(name: "item_remove", scope: !463, file: !463, line: 1013, type: !1488, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1488 = !DISubroutineType(types: !1489)
!1489 = !{null, !1062}
!1490 = distinct !DISubprogram(name: "try_read_command_asciiauth", scope: !2, file: !2, line: 335, type: !1164, scopeLine: 335, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !1491)
!1491 = !{!1492, !1493, !1500, !1501, !1502, !1505}
!1492 = !DILocalVariable(name: "c", arg: 1, scope: !1490, file: !2, line: 335, type: !780)
!1493 = !DILocalVariable(name: "tokens", scope: !1490, file: !2, line: 336, type: !1494)
!1494 = !DICompositeType(tag: DW_TAG_array_type, baseType: !1495, size: 3072, elements: !1153)
!1495 = !DIDerivedType(tag: DW_TAG_typedef, name: "token_t", file: !2, line: 52, baseType: !1496)
!1496 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "token_s", file: !2, line: 49, size: 128, elements: !1497)
!1497 = !{!1498, !1499}
!1498 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !1496, file: !2, line: 50, baseType: !579, size: 64)
!1499 = !DIDerivedType(tag: DW_TAG_member, name: "length", scope: !1496, file: !2, line: 51, baseType: !747, size: 64, offset: 64)
!1500 = !DILocalVariable(name: "ntokens", scope: !1490, file: !2, line: 337, type: !747)
!1501 = !DILocalVariable(name: "cont", scope: !1490, file: !2, line: 338, type: !579)
!1502 = !DILocalVariable(name: "el", scope: !1503, file: !2, line: 342, type: !579)
!1503 = distinct !DILexicalBlock(scope: !1504, file: !2, line: 341, column: 27)
!1504 = distinct !DILexicalBlock(scope: !1490, file: !2, line: 341, column: 9)
!1505 = !DILocalVariable(name: "size", scope: !1503, file: !2, line: 343, type: !635)
!1506 = distinct !DIAssignID()
!1507 = !DILocation(line: 0, scope: !1490)
!1508 = distinct !DIAssignID()
!1509 = !DILocation(line: 0, scope: !1503)
!1510 = !DILocation(line: 336, column: 5, scope: !1490)
!1511 = !DILocation(line: 341, column: 13, scope: !1504)
!1512 = !{!1211, !1216, i64 12}
!1513 = !DILocation(line: 341, column: 9, scope: !1490)
!1514 = !DILocation(line: 393, column: 24, scope: !1515)
!1515 = distinct !DILexicalBlock(scope: !1490, file: !2, line: 393, column: 9)
!1516 = !{!1211, !1215, i64 216}
!1517 = !DILocation(line: 343, column: 9, scope: !1503)
!1518 = !DILocation(line: 343, column: 18, scope: !1503)
!1519 = distinct !DIAssignID()
!1520 = !DILocation(line: 346, column: 16, scope: !1521)
!1521 = distinct !DILexicalBlock(scope: !1503, file: !2, line: 346, column: 13)
!1522 = !{!1211, !1215, i64 188}
!1523 = !DILocation(line: 346, column: 23, scope: !1521)
!1524 = !DILocation(line: 346, column: 13, scope: !1503)
!1525 = !DILocation(line: 349, column: 24, scope: !1503)
!1526 = !{!1211, !1212, i64 176}
!1527 = !DILocation(line: 349, column: 14, scope: !1503)
!1528 = !DILocation(line: 352, column: 14, scope: !1529)
!1529 = distinct !DILexicalBlock(scope: !1503, file: !2, line: 352, column: 13)
!1530 = !DILocation(line: 352, column: 13, scope: !1503)
!1531 = !DILocation(line: 353, column: 27, scope: !1532)
!1532 = distinct !DILexicalBlock(scope: !1533, file: !2, line: 353, column: 17)
!1533 = distinct !DILexicalBlock(scope: !1529, file: !2, line: 352, column: 18)
!1534 = !DILocation(line: 353, column: 17, scope: !1533)
!1535 = !DILocation(line: 354, column: 17, scope: !1536)
!1536 = distinct !DILexicalBlock(scope: !1532, file: !2, line: 353, column: 35)
!1537 = !DILocation(line: 355, column: 17, scope: !1536)
!1538 = !DILocation(line: 365, column: 13, scope: !1503)
!1539 = !DILocation(line: 367, column: 39, scope: !1503)
!1540 = !DILocalVariable(name: "command", arg: 1, scope: !1541, file: !2, line: 292, type: !579)
!1541 = distinct !DISubprogram(name: "tokenize_command", scope: !2, file: !2, line: 292, type: !1542, scopeLine: 292, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !1546)
!1542 = !DISubroutineType(types: !1543)
!1543 = !{!747, !579, !1544, !1545}
!1544 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1495, size: 64)
!1545 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !747)
!1546 = !{!1540, !1547, !1548, !1549, !1550, !1551, !1552, !1553}
!1547 = !DILocalVariable(name: "tokens", arg: 2, scope: !1541, file: !2, line: 292, type: !1544)
!1548 = !DILocalVariable(name: "max_tokens", arg: 3, scope: !1541, file: !2, line: 292, type: !1545)
!1549 = !DILocalVariable(name: "s", scope: !1541, file: !2, line: 293, type: !579)
!1550 = !DILocalVariable(name: "e", scope: !1541, file: !2, line: 293, type: !579)
!1551 = !DILocalVariable(name: "ntokens", scope: !1541, file: !2, line: 294, type: !747)
!1552 = !DILocalVariable(name: "len", scope: !1541, file: !2, line: 296, type: !747)
!1553 = !DILocalVariable(name: "i", scope: !1541, file: !2, line: 297, type: !464)
!1554 = !DILocation(line: 0, scope: !1541, inlinedAt: !1555)
!1555 = distinct !DILocation(line: 367, column: 19, scope: !1503)
!1556 = !DILocation(line: 296, column: 18, scope: !1541, inlinedAt: !1555)
!1557 = !DILocation(line: 300, column: 19, scope: !1558, inlinedAt: !1555)
!1558 = distinct !DILexicalBlock(scope: !1559, file: !2, line: 300, column: 5)
!1559 = distinct !DILexicalBlock(scope: !1541, file: !2, line: 300, column: 5)
!1560 = !DILocation(line: 300, column: 5, scope: !1559, inlinedAt: !1555)
!1561 = !DILocation(line: 301, column: 13, scope: !1562, inlinedAt: !1555)
!1562 = distinct !DILexicalBlock(scope: !1563, file: !2, line: 301, column: 13)
!1563 = distinct !DILexicalBlock(scope: !1558, file: !2, line: 300, column: 31)
!1564 = !DILocation(line: 301, column: 16, scope: !1562, inlinedAt: !1555)
!1565 = !DILocation(line: 301, column: 13, scope: !1563, inlinedAt: !1555)
!1566 = !DILocation(line: 302, column: 19, scope: !1567, inlinedAt: !1555)
!1567 = distinct !DILexicalBlock(scope: !1568, file: !2, line: 302, column: 17)
!1568 = distinct !DILexicalBlock(scope: !1562, file: !2, line: 301, column: 24)
!1569 = !DILocation(line: 302, column: 17, scope: !1568, inlinedAt: !1555)
!1570 = !DILocation(line: 303, column: 17, scope: !1571, inlinedAt: !1555)
!1571 = distinct !DILexicalBlock(scope: !1567, file: !2, line: 302, column: 25)
!1572 = !DILocation(line: 303, column: 39, scope: !1571, inlinedAt: !1555)
!1573 = !{!1574, !1212, i64 0}
!1574 = !{!"token_s", !1212, i64 0, !1222, i64 8}
!1575 = !DILocation(line: 304, column: 44, scope: !1571, inlinedAt: !1555)
!1576 = !DILocation(line: 304, column: 33, scope: !1571, inlinedAt: !1555)
!1577 = !DILocation(line: 304, column: 40, scope: !1571, inlinedAt: !1555)
!1578 = !{!1574, !1222, i64 8}
!1579 = !DILocation(line: 305, column: 24, scope: !1571, inlinedAt: !1555)
!1580 = !DILocation(line: 306, column: 20, scope: !1571, inlinedAt: !1555)
!1581 = !DILocation(line: 307, column: 29, scope: !1582, inlinedAt: !1555)
!1582 = distinct !DILexicalBlock(scope: !1571, file: !2, line: 307, column: 21)
!1583 = !DILocation(line: 307, column: 21, scope: !1571, inlinedAt: !1555)
!1584 = !DILocation(line: 308, column: 22, scope: !1585, inlinedAt: !1555)
!1585 = distinct !DILexicalBlock(scope: !1582, file: !2, line: 307, column: 48)
!1586 = !DILocation(line: 318, column: 9, scope: !1541, inlinedAt: !1555)
!1587 = !DILocation(line: 313, column: 19, scope: !1568, inlinedAt: !1555)
!1588 = !DILocation(line: 314, column: 9, scope: !1568, inlinedAt: !1555)
!1589 = !DILocation(line: 315, column: 10, scope: !1563, inlinedAt: !1555)
!1590 = !DILocation(line: 300, column: 27, scope: !1558, inlinedAt: !1555)
!1591 = !DILocation(line: 300, column: 17, scope: !1558, inlinedAt: !1555)
!1592 = distinct !{!1592, !1560, !1593, !1410}
!1593 = !DILocation(line: 316, column: 5, scope: !1559, inlinedAt: !1555)
!1594 = !DILocation(line: 318, column: 11, scope: !1595, inlinedAt: !1555)
!1595 = distinct !DILexicalBlock(scope: !1541, file: !2, line: 318, column: 9)
!1596 = !DILocation(line: 319, column: 9, scope: !1597, inlinedAt: !1555)
!1597 = distinct !DILexicalBlock(scope: !1595, file: !2, line: 318, column: 17)
!1598 = !DILocation(line: 319, column: 31, scope: !1597, inlinedAt: !1555)
!1599 = !DILocation(line: 321, column: 16, scope: !1597, inlinedAt: !1555)
!1600 = !DILocation(line: 322, column: 5, scope: !1597, inlinedAt: !1555)
!1601 = !DILocation(line: 328, column: 30, scope: !1541, inlinedAt: !1555)
!1602 = !DILocation(line: 328, column: 33, scope: !1541, inlinedAt: !1555)
!1603 = !DILocation(line: 328, column: 5, scope: !1541, inlinedAt: !1555)
!1604 = !DILocation(line: 328, column: 27, scope: !1541, inlinedAt: !1555)
!1605 = !DILocation(line: 330, column: 12, scope: !1541, inlinedAt: !1555)
!1606 = !DILocation(line: 369, column: 31, scope: !1503)
!1607 = !DILocation(line: 369, column: 26, scope: !1503)
!1608 = !DILocation(line: 369, column: 38, scope: !1503)
!1609 = !DILocation(line: 369, column: 19, scope: !1503)
!1610 = !DILocation(line: 370, column: 25, scope: !1503)
!1611 = !DILocation(line: 370, column: 18, scope: !1503)
!1612 = !DILocation(line: 373, column: 21, scope: !1613)
!1613 = distinct !DILexicalBlock(scope: !1503, file: !2, line: 373, column: 13)
!1614 = !DILocation(line: 374, column: 17, scope: !1613)
!1615 = !DILocation(line: 374, column: 37, scope: !1613)
!1616 = !DILocation(line: 374, column: 20, scope: !1613)
!1617 = !DILocation(line: 374, column: 51, scope: !1613)
!1618 = !DILocation(line: 375, column: 17, scope: !1613)
!1619 = !DILocation(line: 375, column: 34, scope: !1613)
!1620 = !DILocation(line: 375, column: 44, scope: !1613)
!1621 = !DILocation(line: 375, column: 21, scope: !1613)
!1622 = !DILocation(line: 373, column: 13, scope: !1503)
!1623 = !DILocation(line: 376, column: 21, scope: !1624)
!1624 = distinct !DILexicalBlock(scope: !1625, file: !2, line: 376, column: 17)
!1625 = distinct !DILexicalBlock(scope: !1613, file: !2, line: 375, column: 59)
!1626 = !DILocation(line: 376, column: 18, scope: !1624)
!1627 = !DILocation(line: 376, column: 17, scope: !1625)
!1628 = !DILocation(line: 377, column: 22, scope: !1629)
!1629 = distinct !DILexicalBlock(scope: !1630, file: !2, line: 377, column: 21)
!1630 = distinct !DILexicalBlock(scope: !1624, file: !2, line: 376, column: 27)
!1631 = !DILocation(line: 377, column: 21, scope: !1630)
!1632 = !DILocation(line: 378, column: 21, scope: !1633)
!1633 = distinct !DILexicalBlock(scope: !1629, file: !2, line: 377, column: 37)
!1634 = !DILocation(line: 379, column: 21, scope: !1633)
!1635 = !DILocation(line: 382, column: 13, scope: !1625)
!1636 = !DILocation(line: 383, column: 13, scope: !1625)
!1637 = !DILocation(line: 391, column: 5, scope: !1504)
!1638 = !DILocation(line: 388, column: 22, scope: !1503)
!1639 = !DILocation(line: 388, column: 27, scope: !1503)
!1640 = !DILocation(line: 388, column: 12, scope: !1503)
!1641 = !DILocation(line: 388, column: 20, scope: !1503)
!1642 = !DILocation(line: 390, column: 25, scope: !1503)
!1643 = !DILocation(line: 393, column: 12, scope: !1515)
!1644 = !DILocation(line: 393, column: 19, scope: !1515)
!1645 = !DILocation(line: 393, column: 9, scope: !1490)
!1646 = !DILocation(line: 399, column: 13, scope: !1647)
!1647 = distinct !DILexicalBlock(scope: !1490, file: !2, line: 399, column: 9)
!1648 = !DILocation(line: 399, column: 10, scope: !1647)
!1649 = !DILocation(line: 399, column: 9, scope: !1490)
!1650 = !DILocation(line: 400, column: 14, scope: !1651)
!1651 = distinct !DILexicalBlock(scope: !1652, file: !2, line: 400, column: 13)
!1652 = distinct !DILexicalBlock(scope: !1647, file: !2, line: 399, column: 19)
!1653 = !DILocation(line: 400, column: 13, scope: !1652)
!1654 = !DILocation(line: 408, column: 21, scope: !1490)
!1655 = !DILocation(line: 408, column: 15, scope: !1490)
!1656 = !DILocation(line: 401, column: 13, scope: !1657)
!1657 = distinct !DILexicalBlock(scope: !1651, file: !2, line: 400, column: 29)
!1658 = !DILocation(line: 402, column: 13, scope: !1657)
!1659 = !DILocation(line: 406, column: 15, scope: !1490)
!1660 = !DILocation(line: 409, column: 14, scope: !1490)
!1661 = !DILocation(line: 410, column: 21, scope: !1490)
!1662 = !DILocation(line: 415, column: 35, scope: !1663)
!1663 = distinct !DILexicalBlock(scope: !1490, file: !2, line: 415, column: 9)
!1664 = !DILocation(line: 415, column: 51, scope: !1663)
!1665 = !DILocation(line: 415, column: 9, scope: !1490)
!1666 = !DILocation(line: 416, column: 9, scope: !1667)
!1667 = distinct !DILexicalBlock(scope: !1663, file: !2, line: 415, column: 57)
!1668 = !DILocation(line: 417, column: 9, scope: !1667)
!1669 = !DILocation(line: 421, column: 26, scope: !1490)
!1670 = !DILocation(line: 0, scope: !1541, inlinedAt: !1671)
!1671 = distinct !DILocation(line: 422, column: 15, scope: !1490)
!1672 = !DILocation(line: 296, column: 18, scope: !1541, inlinedAt: !1671)
!1673 = !DILocation(line: 300, column: 19, scope: !1558, inlinedAt: !1671)
!1674 = !DILocation(line: 300, column: 5, scope: !1559, inlinedAt: !1671)
!1675 = !DILocation(line: 301, column: 13, scope: !1562, inlinedAt: !1671)
!1676 = !DILocation(line: 301, column: 16, scope: !1562, inlinedAt: !1671)
!1677 = !DILocation(line: 301, column: 13, scope: !1563, inlinedAt: !1671)
!1678 = !DILocation(line: 302, column: 19, scope: !1567, inlinedAt: !1671)
!1679 = !DILocation(line: 302, column: 17, scope: !1568, inlinedAt: !1671)
!1680 = !DILocation(line: 303, column: 17, scope: !1571, inlinedAt: !1671)
!1681 = !DILocation(line: 303, column: 39, scope: !1571, inlinedAt: !1671)
!1682 = !DILocation(line: 304, column: 44, scope: !1571, inlinedAt: !1671)
!1683 = !DILocation(line: 304, column: 33, scope: !1571, inlinedAt: !1671)
!1684 = !DILocation(line: 304, column: 40, scope: !1571, inlinedAt: !1671)
!1685 = !DILocation(line: 305, column: 24, scope: !1571, inlinedAt: !1671)
!1686 = !DILocation(line: 306, column: 20, scope: !1571, inlinedAt: !1671)
!1687 = !DILocation(line: 307, column: 29, scope: !1582, inlinedAt: !1671)
!1688 = !DILocation(line: 307, column: 21, scope: !1571, inlinedAt: !1671)
!1689 = !DILocation(line: 308, column: 22, scope: !1585, inlinedAt: !1671)
!1690 = !DILocation(line: 318, column: 9, scope: !1541, inlinedAt: !1671)
!1691 = !DILocation(line: 313, column: 19, scope: !1568, inlinedAt: !1671)
!1692 = !DILocation(line: 314, column: 9, scope: !1568, inlinedAt: !1671)
!1693 = !DILocation(line: 315, column: 10, scope: !1563, inlinedAt: !1671)
!1694 = !DILocation(line: 300, column: 27, scope: !1558, inlinedAt: !1671)
!1695 = !DILocation(line: 300, column: 17, scope: !1558, inlinedAt: !1671)
!1696 = distinct !{!1696, !1674, !1697, !1410}
!1697 = !DILocation(line: 316, column: 5, scope: !1559, inlinedAt: !1671)
!1698 = !DILocation(line: 318, column: 11, scope: !1595, inlinedAt: !1671)
!1699 = !DILocation(line: 319, column: 9, scope: !1597, inlinedAt: !1671)
!1700 = !DILocation(line: 319, column: 31, scope: !1597, inlinedAt: !1671)
!1701 = !DILocation(line: 321, column: 16, scope: !1597, inlinedAt: !1671)
!1702 = !DILocation(line: 322, column: 5, scope: !1597, inlinedAt: !1671)
!1703 = !DILocation(line: 328, column: 30, scope: !1541, inlinedAt: !1671)
!1704 = !DILocation(line: 328, column: 33, scope: !1541, inlinedAt: !1671)
!1705 = !DILocation(line: 328, column: 5, scope: !1541, inlinedAt: !1671)
!1706 = !DILocation(line: 328, column: 27, scope: !1541, inlinedAt: !1671)
!1707 = !DILocation(line: 330, column: 12, scope: !1541, inlinedAt: !1671)
!1708 = !DILocation(line: 424, column: 17, scope: !1709)
!1709 = distinct !DILexicalBlock(scope: !1490, file: !2, line: 424, column: 9)
!1710 = !DILocation(line: 424, column: 9, scope: !1490)
!1711 = !DILocation(line: 425, column: 9, scope: !1712)
!1712 = distinct !DILexicalBlock(scope: !1709, file: !2, line: 424, column: 22)
!1713 = !DILocation(line: 426, column: 9, scope: !1712)
!1714 = !DILocation(line: 429, column: 34, scope: !1715)
!1715 = distinct !DILexicalBlock(scope: !1490, file: !2, line: 429, column: 9)
!1716 = !DILocation(line: 429, column: 41, scope: !1715)
!1717 = !DILocation(line: 429, column: 51, scope: !1715)
!1718 = !DILocation(line: 429, column: 9, scope: !1715)
!1719 = !DILocation(line: 429, column: 58, scope: !1715)
!1720 = !DILocation(line: 429, column: 9, scope: !1490)
!1721 = !DILocation(line: 430, column: 9, scope: !1722)
!1722 = distinct !DILexicalBlock(scope: !1715, file: !2, line: 429, column: 64)
!1723 = !DILocation(line: 431, column: 12, scope: !1722)
!1724 = !DILocation(line: 431, column: 26, scope: !1722)
!1725 = !{!1211, !1216, i64 13}
!1726 = !DILocation(line: 432, column: 12, scope: !1722)
!1727 = !DILocation(line: 432, column: 29, scope: !1722)
!1728 = !{!1211, !1212, i64 464}
!1729 = !DILocation(line: 433, column: 32, scope: !1722)
!1730 = !DILocation(line: 433, column: 40, scope: !1722)
!1731 = !DILocation(line: 433, column: 9, scope: !1722)
!1732 = !DILocation(line: 434, column: 12, scope: !1722)
!1733 = !DILocation(line: 434, column: 26, scope: !1722)
!1734 = !DILocation(line: 434, column: 35, scope: !1722)
!1735 = !{!1316, !1222, i64 512}
!1736 = !DILocation(line: 435, column: 42, scope: !1722)
!1737 = !DILocation(line: 435, column: 9, scope: !1722)
!1738 = !DILocation(line: 436, column: 5, scope: !1722)
!1739 = !DILocation(line: 437, column: 9, scope: !1740)
!1740 = distinct !DILexicalBlock(scope: !1715, file: !2, line: 436, column: 12)
!1741 = !DILocation(line: 438, column: 32, scope: !1740)
!1742 = !DILocation(line: 438, column: 40, scope: !1740)
!1743 = !DILocation(line: 438, column: 9, scope: !1740)
!1744 = !DILocation(line: 439, column: 12, scope: !1740)
!1745 = !DILocation(line: 439, column: 26, scope: !1740)
!1746 = !DILocation(line: 439, column: 35, scope: !1740)
!1747 = !DILocation(line: 441, column: 42, scope: !1740)
!1748 = !DILocation(line: 441, column: 9, scope: !1740)
!1749 = !DILocation(line: 445, column: 1, scope: !1490)
!1750 = !DISubprogram(name: "memchr", scope: !1469, file: !1469, line: 107, type: !1751, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1751 = !DISubroutineType(types: !1752)
!1752 = !{!632, !730, !598, !747}
!1753 = !DISubprogram(name: "conn_set_state", scope: !463, file: !463, line: 1064, type: !1754, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1754 = !DISubroutineType(types: !1755)
!1755 = !{null, !780, !462}
!1756 = !DISubprogram(name: "strcmp", scope: !1469, file: !1469, line: 156, type: !1757, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1757 = !DISubroutineType(types: !1758)
!1758 = !{!598, !1472, !1472}
!1759 = !DISubprogram(name: "safe_strtoul", scope: !1760, file: !1760, line: 19, type: !1761, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1760 = !DIFile(filename: "./util.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d1ef68c688867746f50aae7567be079a")
!1761 = !DISubroutineType(types: !1762)
!1762 = !{!790, !1472, !746}
!1763 = !DISubprogram(name: "resp_start", scope: !463, file: !463, line: 1057, type: !1764, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1764 = !DISubroutineType(types: !1765)
!1765 = !{!790, !780}
!1766 = !DISubprogram(name: "authfile_check", scope: !1767, file: !1767, line: 14, type: !1757, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1767 = !DIFile(filename: "./authfile.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "0dde135e0a78cac5fa53ca0c0171cf2a")
!1768 = distinct !DISubprogram(name: "try_read_command_ascii", scope: !2, file: !2, line: 447, type: !1164, scopeLine: 447, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !1769)
!1769 = !{!1770, !1771, !1772, !1773}
!1770 = !DILocalVariable(name: "c", arg: 1, scope: !1768, file: !2, line: 447, type: !780)
!1771 = !DILocalVariable(name: "el", scope: !1768, file: !2, line: 448, type: !579)
!1772 = !DILocalVariable(name: "cont", scope: !1768, file: !2, line: 448, type: !579)
!1773 = !DILocalVariable(name: "ptr", scope: !1774, file: !2, line: 460, type: !579)
!1774 = distinct !DILexicalBlock(scope: !1775, file: !2, line: 455, column: 31)
!1775 = distinct !DILexicalBlock(scope: !1776, file: !2, line: 455, column: 13)
!1776 = distinct !DILexicalBlock(scope: !1777, file: !2, line: 454, column: 14)
!1777 = distinct !DILexicalBlock(scope: !1768, file: !2, line: 454, column: 9)
!1778 = !DILocation(line: 0, scope: !1768)
!1779 = !DILocation(line: 450, column: 12, scope: !1780)
!1780 = distinct !DILexicalBlock(scope: !1768, file: !2, line: 450, column: 9)
!1781 = !DILocation(line: 450, column: 19, scope: !1780)
!1782 = !DILocation(line: 450, column: 9, scope: !1768)
!1783 = !DILocation(line: 453, column: 20, scope: !1768)
!1784 = !DILocation(line: 453, column: 33, scope: !1768)
!1785 = !DILocation(line: 453, column: 10, scope: !1768)
!1786 = !DILocation(line: 454, column: 10, scope: !1777)
!1787 = !DILocation(line: 454, column: 9, scope: !1768)
!1788 = !DILocation(line: 455, column: 23, scope: !1775)
!1789 = !DILocation(line: 455, column: 13, scope: !1776)
!1790 = !DILocation(line: 0, scope: !1774)
!1791 = !DILocation(line: 461, column: 20, scope: !1774)
!1792 = !DILocation(line: 461, column: 25, scope: !1774)
!1793 = !DILocation(line: 462, column: 17, scope: !1794)
!1794 = distinct !DILexicalBlock(scope: !1774, file: !2, line: 461, column: 33)
!1795 = !DILocation(line: 461, column: 13, scope: !1774)
!1796 = distinct !{!1796, !1795, !1797, !1410}
!1797 = !DILocation(line: 463, column: 13, scope: !1774)
!1798 = !DILocation(line: 465, column: 21, scope: !1799)
!1799 = distinct !DILexicalBlock(scope: !1774, file: !2, line: 465, column: 17)
!1800 = !DILocation(line: 465, column: 32, scope: !1799)
!1801 = !DILocation(line: 465, column: 38, scope: !1799)
!1802 = !DILocation(line: 466, column: 18, scope: !1799)
!1803 = !DILocation(line: 466, column: 42, scope: !1799)
!1804 = !DILocation(line: 466, column: 45, scope: !1799)
!1805 = !DILocation(line: 465, column: 17, scope: !1774)
!1806 = !DILocation(line: 468, column: 17, scope: !1807)
!1807 = distinct !DILexicalBlock(scope: !1799, file: !2, line: 466, column: 72)
!1808 = !DILocation(line: 469, column: 17, scope: !1807)
!1809 = !DILocation(line: 475, column: 21, scope: !1810)
!1810 = distinct !DILexicalBlock(scope: !1774, file: !2, line: 475, column: 17)
!1811 = !{!1211, !1216, i64 17}
!1812 = !DILocation(line: 475, column: 17, scope: !1774)
!1813 = !DILocation(line: 476, column: 22, scope: !1814)
!1814 = distinct !DILexicalBlock(scope: !1815, file: !2, line: 476, column: 21)
!1815 = distinct !DILexicalBlock(scope: !1810, file: !2, line: 475, column: 36)
!1816 = !DILocation(line: 476, column: 21, scope: !1815)
!1817 = !DILocation(line: 477, column: 21, scope: !1818)
!1818 = distinct !DILexicalBlock(scope: !1814, file: !2, line: 476, column: 48)
!1819 = !DILocation(line: 478, column: 21, scope: !1818)
!1820 = !DILocation(line: 485, column: 15, scope: !1768)
!1821 = !DILocation(line: 486, column: 13, scope: !1822)
!1822 = distinct !DILexicalBlock(scope: !1768, file: !2, line: 486, column: 9)
!1823 = !DILocation(line: 486, column: 25, scope: !1822)
!1824 = !DILocation(line: 486, column: 29, scope: !1822)
!1825 = !DILocation(line: 486, column: 37, scope: !1822)
!1826 = !DILocation(line: 486, column: 32, scope: !1822)
!1827 = !DILocation(line: 486, column: 42, scope: !1822)
!1828 = !DILocation(line: 486, column: 9, scope: !1768)
!1829 = !DILocation(line: 489, column: 9, scope: !1768)
!1830 = !DILocation(line: 493, column: 24, scope: !1768)
!1831 = !DILocation(line: 493, column: 8, scope: !1768)
!1832 = !DILocation(line: 493, column: 22, scope: !1768)
!1833 = !{!1211, !1215, i64 28}
!1834 = !DILocation(line: 494, column: 33, scope: !1768)
!1835 = !DILocation(line: 494, column: 5, scope: !1768)
!1836 = !DILocation(line: 496, column: 29, scope: !1768)
!1837 = !DILocation(line: 496, column: 24, scope: !1768)
!1838 = !DILocation(line: 496, column: 15, scope: !1768)
!1839 = !DILocation(line: 497, column: 14, scope: !1768)
!1840 = !DILocation(line: 501, column: 5, scope: !1768)
!1841 = !DILocation(line: 502, column: 1, scope: !1768)
!1842 = !DISubprogram(name: "rbuf_switch_to_malloc", scope: !463, file: !463, line: 1062, type: !1764, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1843 = distinct !DISubprogram(name: "process_command_ascii", scope: !2, file: !2, line: 2825, type: !1844, scopeLine: 2825, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !1846)
!1844 = !DISubroutineType(types: !1845)
!1845 = !{null, !780, !579}
!1846 = !{!1847, !1848, !1849, !1850, !1851, !1852}
!1847 = !DILocalVariable(name: "c", arg: 1, scope: !1843, file: !2, line: 2825, type: !780)
!1848 = !DILocalVariable(name: "command", arg: 2, scope: !1843, file: !2, line: 2825, type: !579)
!1849 = !DILocalVariable(name: "tokens", scope: !1843, file: !2, line: 2827, type: !1494)
!1850 = !DILocalVariable(name: "ntokens", scope: !1843, file: !2, line: 2828, type: !747)
!1851 = !DILocalVariable(name: "comm", scope: !1843, file: !2, line: 2829, type: !598)
!1852 = !DILocalVariable(name: "first", scope: !1843, file: !2, line: 2859, type: !4)
!1853 = distinct !DIAssignID()
!1854 = !DILocation(line: 0, scope: !1843)
!1855 = !DILocation(line: 2827, column: 5, scope: !1843)
!1856 = !DILocation(line: 2835, column: 18, scope: !1857)
!1857 = distinct !DILexicalBlock(scope: !1843, file: !2, line: 2835, column: 9)
!1858 = !{!1859, !1215, i64 32}
!1859 = !{!"settings", !1222, i64 0, !1215, i64 8, !1215, i64 12, !1215, i64 16, !1212, i64 24, !1215, i64 32, !1215, i64 36, !1215, i64 40, !1212, i64 48, !1212, i64 56, !1215, i64 64, !1860, i64 72, !1215, i64 80, !1215, i64 84, !1215, i64 88, !1213, i64 92, !1215, i64 96, !1215, i64 100, !1216, i64 104, !1215, i64 108, !1215, i64 112, !1215, i64 116, !1215, i64 120, !1215, i64 124, !1215, i64 128, !1216, i64 132, !1216, i64 133, !1216, i64 134, !1216, i64 135, !1216, i64 136, !1216, i64 137, !1215, i64 140, !1860, i64 144, !1215, i64 152, !1215, i64 156, !1216, i64 160, !1215, i64 164, !1216, i64 168, !1216, i64 169, !1212, i64 176, !1215, i64 184, !1215, i64 188, !1215, i64 192, !1215, i64 196, !1860, i64 200, !1860, i64 208, !1215, i64 216, !1216, i64 220, !1215, i64 224, !1215, i64 228, !1215, i64 232, !1215, i64 236, !1215, i64 240, !1216, i64 244, !1216, i64 245, !1216, i64 246, !1215, i64 248, !1215, i64 252, !1215, i64 256, !1215, i64 260, !1215, i64 264, !1215, i64 268, !1215, i64 272, !1215, i64 276, !1215, i64 280, !1215, i64 284, !1860, i64 288, !1860, i64 296, !1216, i64 304, !1215, i64 308, !1215, i64 312, !1212, i64 320, !1215, i64 328}
!1860 = !{!"double", !1213, i64 0}
!1861 = !DILocation(line: 2835, column: 26, scope: !1857)
!1862 = !DILocation(line: 2835, column: 9, scope: !1843)
!1863 = !DILocation(line: 2836, column: 17, scope: !1857)
!1864 = !DILocation(line: 2836, column: 40, scope: !1857)
!1865 = !DILocation(line: 2836, column: 9, scope: !1857)
!1866 = !DILocation(line: 2844, column: 10, scope: !1867)
!1867 = distinct !DILexicalBlock(scope: !1843, file: !2, line: 2844, column: 9)
!1868 = !DILocation(line: 2844, column: 9, scope: !1843)
!1869 = !DILocation(line: 2845, column: 9, scope: !1870)
!1870 = distinct !DILexicalBlock(scope: !1867, file: !2, line: 2844, column: 25)
!1871 = !DILocation(line: 2846, column: 9, scope: !1870)
!1872 = !DILocation(line: 2849, column: 29, scope: !1843)
!1873 = !DILocation(line: 2849, column: 8, scope: !1843)
!1874 = !DILocation(line: 2849, column: 16, scope: !1843)
!1875 = !DILocation(line: 2849, column: 24, scope: !1843)
!1876 = !DILocation(line: 0, scope: !1541, inlinedAt: !1877)
!1877 = distinct !DILocation(line: 2850, column: 15, scope: !1843)
!1878 = !DILocation(line: 296, column: 18, scope: !1541, inlinedAt: !1877)
!1879 = !DILocation(line: 300, column: 19, scope: !1558, inlinedAt: !1877)
!1880 = !DILocation(line: 300, column: 5, scope: !1559, inlinedAt: !1877)
!1881 = !DILocation(line: 301, column: 13, scope: !1562, inlinedAt: !1877)
!1882 = !DILocation(line: 301, column: 16, scope: !1562, inlinedAt: !1877)
!1883 = !DILocation(line: 301, column: 13, scope: !1563, inlinedAt: !1877)
!1884 = !DILocation(line: 302, column: 19, scope: !1567, inlinedAt: !1877)
!1885 = !DILocation(line: 302, column: 17, scope: !1568, inlinedAt: !1877)
!1886 = !DILocation(line: 303, column: 17, scope: !1571, inlinedAt: !1877)
!1887 = !DILocation(line: 303, column: 39, scope: !1571, inlinedAt: !1877)
!1888 = !DILocation(line: 304, column: 44, scope: !1571, inlinedAt: !1877)
!1889 = !DILocation(line: 304, column: 33, scope: !1571, inlinedAt: !1877)
!1890 = !DILocation(line: 304, column: 40, scope: !1571, inlinedAt: !1877)
!1891 = !DILocation(line: 305, column: 24, scope: !1571, inlinedAt: !1877)
!1892 = !DILocation(line: 306, column: 20, scope: !1571, inlinedAt: !1877)
!1893 = !DILocation(line: 307, column: 29, scope: !1582, inlinedAt: !1877)
!1894 = !DILocation(line: 307, column: 21, scope: !1571, inlinedAt: !1877)
!1895 = !DILocation(line: 308, column: 22, scope: !1585, inlinedAt: !1877)
!1896 = !DILocation(line: 318, column: 9, scope: !1541, inlinedAt: !1877)
!1897 = !DILocation(line: 313, column: 19, scope: !1568, inlinedAt: !1877)
!1898 = !DILocation(line: 314, column: 9, scope: !1568, inlinedAt: !1877)
!1899 = !DILocation(line: 315, column: 10, scope: !1563, inlinedAt: !1877)
!1900 = !DILocation(line: 300, column: 27, scope: !1558, inlinedAt: !1877)
!1901 = !DILocation(line: 300, column: 17, scope: !1558, inlinedAt: !1877)
!1902 = distinct !{!1902, !1880, !1903, !1410}
!1903 = !DILocation(line: 316, column: 5, scope: !1559, inlinedAt: !1877)
!1904 = !DILocation(line: 318, column: 11, scope: !1595, inlinedAt: !1877)
!1905 = !DILocation(line: 319, column: 9, scope: !1597, inlinedAt: !1877)
!1906 = !DILocation(line: 319, column: 31, scope: !1597, inlinedAt: !1877)
!1907 = !DILocation(line: 320, column: 36, scope: !1597, inlinedAt: !1877)
!1908 = !DILocation(line: 320, column: 25, scope: !1597, inlinedAt: !1877)
!1909 = !DILocation(line: 320, column: 32, scope: !1597, inlinedAt: !1877)
!1910 = !DILocation(line: 321, column: 16, scope: !1597, inlinedAt: !1877)
!1911 = !DILocation(line: 322, column: 5, scope: !1597, inlinedAt: !1877)
!1912 = !DILocation(line: 328, column: 30, scope: !1541, inlinedAt: !1877)
!1913 = !DILocation(line: 328, column: 33, scope: !1541, inlinedAt: !1877)
!1914 = !DILocation(line: 328, column: 5, scope: !1541, inlinedAt: !1877)
!1915 = !DILocation(line: 328, column: 27, scope: !1541, inlinedAt: !1877)
!1916 = !DILocation(line: 329, column: 21, scope: !1541, inlinedAt: !1877)
!1917 = !DILocation(line: 329, column: 28, scope: !1541, inlinedAt: !1877)
!1918 = !DILocation(line: 330, column: 12, scope: !1541, inlinedAt: !1877)
!1919 = !DILocation(line: 2853, column: 17, scope: !1920)
!1920 = distinct !DILexicalBlock(scope: !1843, file: !2, line: 2853, column: 9)
!1921 = !DILocation(line: 2853, column: 21, scope: !1920)
!1922 = !DILocation(line: 2853, column: 46, scope: !1920)
!1923 = !DILocation(line: 2853, column: 53, scope: !1920)
!1924 = !DILocation(line: 2853, column: 9, scope: !1843)
!1925 = !DILocation(line: 2854, column: 9, scope: !1926)
!1926 = distinct !DILexicalBlock(scope: !1920, file: !2, line: 2853, column: 58)
!1927 = !DILocation(line: 2855, column: 9, scope: !1926)
!1928 = !DILocation(line: 2859, column: 40, scope: !1843)
!1929 = !DILocation(line: 2859, column: 18, scope: !1843)
!1930 = !DILocation(line: 2860, column: 15, scope: !1931)
!1931 = distinct !DILexicalBlock(scope: !1843, file: !2, line: 2860, column: 9)
!1932 = !DILocation(line: 2860, column: 22, scope: !1931)
!1933 = !DILocation(line: 2861, column: 17, scope: !1934)
!1934 = distinct !DILexicalBlock(scope: !1931, file: !2, line: 2860, column: 60)
!1935 = !DILocation(line: 2861, column: 9, scope: !1934)
!1936 = !DILocation(line: 2863, column: 17, scope: !1937)
!1937 = distinct !DILexicalBlock(scope: !1934, file: !2, line: 2861, column: 49)
!1938 = !DILocation(line: 2864, column: 17, scope: !1937)
!1939 = !DILocation(line: 2866, column: 17, scope: !1937)
!1940 = !DILocation(line: 2867, column: 17, scope: !1937)
!1941 = !DILocation(line: 2869, column: 17, scope: !1937)
!1942 = !DILocation(line: 2870, column: 17, scope: !1937)
!1943 = !DILocation(line: 2872, column: 17, scope: !1937)
!1944 = !DILocation(line: 2874, column: 17, scope: !1937)
!1945 = !DILocation(line: 2875, column: 17, scope: !1937)
!1946 = !DILocation(line: 2877, column: 17, scope: !1937)
!1947 = !DILocation(line: 2878, column: 17, scope: !1937)
!1948 = !DILocation(line: 2880, column: 17, scope: !1937)
!1949 = !DILocation(line: 2881, column: 17, scope: !1937)
!1950 = !DILocation(line: 2883, column: 17, scope: !1937)
!1951 = !DILocation(line: 2884, column: 17, scope: !1937)
!1952 = !DILocation(line: 2886, column: 16, scope: !1931)
!1953 = !DILocation(line: 2888, column: 9, scope: !1954)
!1954 = distinct !DILexicalBlock(scope: !1955, file: !2, line: 2888, column: 9)
!1955 = distinct !DILexicalBlock(scope: !1956, file: !2, line: 2888, column: 9)
!1956 = distinct !DILexicalBlock(scope: !1957, file: !2, line: 2886, column: 30)
!1957 = distinct !DILexicalBlock(scope: !1931, file: !2, line: 2886, column: 16)
!1958 = !DILocation(line: 2888, column: 9, scope: !1955)
!1959 = !DILocation(line: 2888, column: 9, scope: !1960)
!1960 = distinct !DILexicalBlock(scope: !1954, file: !2, line: 2888, column: 9)
!1961 = !DILocation(line: 2889, column: 13, scope: !1962)
!1962 = distinct !DILexicalBlock(scope: !1956, file: !2, line: 2889, column: 13)
!1963 = !DILocation(line: 2889, column: 56, scope: !1962)
!1964 = !DILocation(line: 2889, column: 13, scope: !1956)
!1965 = !DILocation(line: 2891, column: 13, scope: !1966)
!1966 = distinct !DILexicalBlock(scope: !1962, file: !2, line: 2889, column: 62)
!1967 = !DILocation(line: 2892, column: 9, scope: !1966)
!1968 = !DILocation(line: 2892, column: 20, scope: !1969)
!1969 = distinct !DILexicalBlock(scope: !1962, file: !2, line: 2892, column: 20)
!1970 = !DILocation(line: 2892, column: 64, scope: !1969)
!1971 = !DILocation(line: 2892, column: 20, scope: !1962)
!1972 = !DILocation(line: 2894, column: 13, scope: !1973)
!1973 = distinct !DILexicalBlock(scope: !1969, file: !2, line: 2892, column: 70)
!1974 = !DILocation(line: 2895, column: 9, scope: !1973)
!1975 = !DILocation(line: 2895, column: 20, scope: !1976)
!1976 = distinct !DILexicalBlock(scope: !1969, file: !2, line: 2895, column: 20)
!1977 = !DILocation(line: 2895, column: 63, scope: !1976)
!1978 = !DILocation(line: 2895, column: 20, scope: !1969)
!1979 = !DILocation(line: 2897, column: 13, scope: !1980)
!1980 = distinct !DILexicalBlock(scope: !1976, file: !2, line: 2895, column: 69)
!1981 = !DILocation(line: 2898, column: 9, scope: !1980)
!1982 = !DILocation(line: 2898, column: 20, scope: !1983)
!1983 = distinct !DILexicalBlock(scope: !1976, file: !2, line: 2898, column: 20)
!1984 = !DILocation(line: 2898, column: 64, scope: !1983)
!1985 = !DILocation(line: 2898, column: 20, scope: !1976)
!1986 = !DILocation(line: 2900, column: 13, scope: !1987)
!1987 = distinct !DILexicalBlock(scope: !1983, file: !2, line: 2898, column: 70)
!1988 = !DILocation(line: 2901, column: 9, scope: !1987)
!1989 = !DILocation(line: 2902, column: 13, scope: !1990)
!1990 = distinct !DILexicalBlock(scope: !1983, file: !2, line: 2901, column: 16)
!1991 = !DILocation(line: 2905, column: 13, scope: !1992)
!1992 = distinct !DILexicalBlock(scope: !1993, file: !2, line: 2905, column: 13)
!1993 = distinct !DILexicalBlock(scope: !1994, file: !2, line: 2904, column: 30)
!1994 = distinct !DILexicalBlock(scope: !1957, file: !2, line: 2904, column: 16)
!1995 = !DILocation(line: 2905, column: 56, scope: !1992)
!1996 = !DILocation(line: 2905, column: 61, scope: !1992)
!1997 = !DILocation(line: 2907, column: 13, scope: !1998)
!1998 = distinct !DILexicalBlock(scope: !1999, file: !2, line: 2907, column: 13)
!1999 = distinct !DILexicalBlock(scope: !2000, file: !2, line: 2907, column: 13)
!2000 = distinct !DILexicalBlock(scope: !1992, file: !2, line: 2905, column: 84)
!2001 = !DILocation(line: 2907, column: 13, scope: !2002)
!2002 = distinct !DILexicalBlock(scope: !1998, file: !2, line: 2907, column: 13)
!2003 = !DILocation(line: 2908, column: 13, scope: !2000)
!2004 = !DILocation(line: 2909, column: 9, scope: !2000)
!2005 = !DILocation(line: 2909, column: 20, scope: !2006)
!2006 = distinct !DILexicalBlock(scope: !1992, file: !2, line: 2909, column: 20)
!2007 = !DILocation(line: 2909, column: 65, scope: !2006)
!2008 = !DILocation(line: 2909, column: 20, scope: !1992)
!2009 = !DILocation(line: 2911, column: 13, scope: !2010)
!2010 = distinct !DILexicalBlock(scope: !2006, file: !2, line: 2909, column: 71)
!2011 = !DILocation(line: 2912, column: 9, scope: !2010)
!2012 = !DILocation(line: 2912, column: 20, scope: !2013)
!2013 = distinct !DILexicalBlock(scope: !2006, file: !2, line: 2912, column: 20)
!2014 = !DILocation(line: 2912, column: 68, scope: !2013)
!2015 = !DILocation(line: 2912, column: 20, scope: !2006)
!2016 = !DILocation(line: 2914, column: 13, scope: !2017)
!2017 = distinct !DILexicalBlock(scope: !2013, file: !2, line: 2912, column: 74)
!2018 = !DILocation(line: 2915, column: 9, scope: !2017)
!2019 = !DILocation(line: 2915, column: 20, scope: !2020)
!2020 = distinct !DILexicalBlock(scope: !2013, file: !2, line: 2915, column: 20)
!2021 = !DILocation(line: 2915, column: 65, scope: !2020)
!2022 = !DILocation(line: 2915, column: 20, scope: !2013)
!2023 = !DILocation(line: 2917, column: 13, scope: !2024)
!2024 = distinct !DILexicalBlock(scope: !2020, file: !2, line: 2915, column: 71)
!2025 = !DILocation(line: 2918, column: 9, scope: !2024)
!2026 = !DILocation(line: 2919, column: 13, scope: !2027)
!2027 = distinct !DILexicalBlock(scope: !2020, file: !2, line: 2918, column: 16)
!2028 = !DILocation(line: 2922, column: 14, scope: !2029)
!2029 = distinct !DILexicalBlock(scope: !2030, file: !2, line: 2922, column: 13)
!2030 = distinct !DILexicalBlock(scope: !2031, file: !2, line: 2921, column: 30)
!2031 = distinct !DILexicalBlock(scope: !1994, file: !2, line: 2921, column: 16)
!2032 = !DILocation(line: 2922, column: 57, scope: !2029)
!2033 = !DILocation(line: 2922, column: 62, scope: !2029)
!2034 = !DILocation(line: 2923, column: 14, scope: !2029)
!2035 = !DILocation(line: 2923, column: 60, scope: !2029)
!2036 = !DILocation(line: 2923, column: 65, scope: !2029)
!2037 = !DILocation(line: 0, scope: !2029)
!2038 = !DILocation(line: 2925, column: 13, scope: !2039)
!2039 = distinct !DILexicalBlock(scope: !2040, file: !2, line: 2925, column: 13)
!2040 = distinct !DILexicalBlock(scope: !2041, file: !2, line: 2925, column: 13)
!2041 = distinct !DILexicalBlock(scope: !2029, file: !2, line: 2923, column: 93)
!2042 = !DILocation(line: 2925, column: 13, scope: !2043)
!2043 = distinct !DILexicalBlock(scope: !2039, file: !2, line: 2925, column: 13)
!2044 = !DILocation(line: 2926, column: 13, scope: !2041)
!2045 = !DILocation(line: 2927, column: 9, scope: !2041)
!2046 = !DILocation(line: 2928, column: 13, scope: !2047)
!2047 = distinct !DILexicalBlock(scope: !2029, file: !2, line: 2927, column: 16)
!2048 = !DILocation(line: 2931, column: 13, scope: !2049)
!2049 = distinct !DILexicalBlock(scope: !2050, file: !2, line: 2931, column: 13)
!2050 = distinct !DILexicalBlock(scope: !2051, file: !2, line: 2930, column: 30)
!2051 = distinct !DILexicalBlock(scope: !2031, file: !2, line: 2930, column: 16)
!2052 = !DILocation(line: 2931, column: 56, scope: !2049)
!2053 = !DILocation(line: 2931, column: 61, scope: !2049)
!2054 = !DILocation(line: 2933, column: 13, scope: !2055)
!2055 = distinct !DILexicalBlock(scope: !2056, file: !2, line: 2933, column: 13)
!2056 = distinct !DILexicalBlock(scope: !2057, file: !2, line: 2933, column: 13)
!2057 = distinct !DILexicalBlock(scope: !2049, file: !2, line: 2931, column: 84)
!2058 = !DILocation(line: 2933, column: 13, scope: !2059)
!2059 = distinct !DILexicalBlock(scope: !2055, file: !2, line: 2933, column: 13)
!2060 = !DILocation(line: 2934, column: 13, scope: !2057)
!2061 = !DILocation(line: 2935, column: 9, scope: !2057)
!2062 = !DILocation(line: 2935, column: 20, scope: !2063)
!2063 = distinct !DILexicalBlock(scope: !2049, file: !2, line: 2935, column: 20)
!2064 = !DILocation(line: 2935, column: 74, scope: !2063)
!2065 = !DILocation(line: 2935, column: 20, scope: !2049)
!2066 = !DILocation(line: 2937, column: 13, scope: !2067)
!2067 = distinct !DILexicalBlock(scope: !2068, file: !2, line: 2937, column: 13)
!2068 = distinct !DILexicalBlock(scope: !2069, file: !2, line: 2937, column: 13)
!2069 = distinct !DILexicalBlock(scope: !2063, file: !2, line: 2935, column: 80)
!2070 = !DILocation(line: 2937, column: 13, scope: !2071)
!2071 = distinct !DILexicalBlock(scope: !2067, file: !2, line: 2937, column: 13)
!2072 = !DILocation(line: 2938, column: 13, scope: !2069)
!2073 = !DILocation(line: 2939, column: 9, scope: !2069)
!2074 = !DILocation(line: 2940, column: 13, scope: !2075)
!2075 = distinct !DILexicalBlock(scope: !2063, file: !2, line: 2939, column: 16)
!2076 = !DILocation(line: 2943, column: 13, scope: !2077)
!2077 = distinct !DILexicalBlock(scope: !2078, file: !2, line: 2943, column: 13)
!2078 = distinct !DILexicalBlock(scope: !2079, file: !2, line: 2942, column: 30)
!2079 = distinct !DILexicalBlock(scope: !2051, file: !2, line: 2942, column: 16)
!2080 = !DILocation(line: 2943, column: 57, scope: !2077)
!2081 = !DILocation(line: 2943, column: 13, scope: !2078)
!2082 = !DILocation(line: 2945, column: 13, scope: !2083)
!2083 = distinct !DILexicalBlock(scope: !2084, file: !2, line: 2945, column: 13)
!2084 = distinct !DILexicalBlock(scope: !2085, file: !2, line: 2945, column: 13)
!2085 = distinct !DILexicalBlock(scope: !2077, file: !2, line: 2943, column: 63)
!2086 = !DILocation(line: 2945, column: 13, scope: !2087)
!2087 = distinct !DILexicalBlock(scope: !2083, file: !2, line: 2945, column: 13)
!2088 = !DILocation(line: 2946, column: 13, scope: !2085)
!2089 = !DILocation(line: 2947, column: 9, scope: !2085)
!2090 = !DILocation(line: 2948, column: 13, scope: !2091)
!2091 = distinct !DILexicalBlock(scope: !2077, file: !2, line: 2947, column: 16)
!2092 = !DILocation(line: 2951, column: 13, scope: !2093)
!2093 = distinct !DILexicalBlock(scope: !2094, file: !2, line: 2951, column: 13)
!2094 = distinct !DILexicalBlock(scope: !2095, file: !2, line: 2950, column: 30)
!2095 = distinct !DILexicalBlock(scope: !2079, file: !2, line: 2950, column: 16)
!2096 = !DILocation(line: 2951, column: 59, scope: !2093)
!2097 = !DILocation(line: 2951, column: 13, scope: !2094)
!2098 = !DILocation(line: 2953, column: 13, scope: !2099)
!2099 = distinct !DILexicalBlock(scope: !2100, file: !2, line: 2953, column: 13)
!2100 = distinct !DILexicalBlock(scope: !2101, file: !2, line: 2953, column: 13)
!2101 = distinct !DILexicalBlock(scope: !2093, file: !2, line: 2951, column: 65)
!2102 = !DILocation(line: 2953, column: 13, scope: !2103)
!2103 = distinct !DILexicalBlock(scope: !2099, file: !2, line: 2953, column: 13)
!2104 = !DILocation(line: 2954, column: 13, scope: !2101)
!2105 = !DILocation(line: 2955, column: 9, scope: !2101)
!2106 = !DILocation(line: 2955, column: 20, scope: !2107)
!2107 = distinct !DILexicalBlock(scope: !2093, file: !2, line: 2955, column: 20)
!2108 = !DILocation(line: 2955, column: 64, scope: !2107)
!2109 = !DILocation(line: 2955, column: 20, scope: !2093)
!2110 = !DILocation(line: 2957, column: 13, scope: !2111)
!2111 = distinct !DILexicalBlock(scope: !2112, file: !2, line: 2957, column: 13)
!2112 = distinct !DILexicalBlock(scope: !2113, file: !2, line: 2957, column: 13)
!2113 = distinct !DILexicalBlock(scope: !2107, file: !2, line: 2955, column: 70)
!2114 = !DILocation(line: 2957, column: 13, scope: !2115)
!2115 = distinct !DILexicalBlock(scope: !2111, file: !2, line: 2957, column: 13)
!2116 = !DILocation(line: 2958, column: 13, scope: !2113)
!2117 = !DILocation(line: 2964, column: 9, scope: !2113)
!2118 = !DILocation(line: 2965, column: 13, scope: !2119)
!2119 = distinct !DILexicalBlock(scope: !2107, file: !2, line: 2964, column: 16)
!2120 = !DILocation(line: 2968, column: 13, scope: !2121)
!2121 = distinct !DILexicalBlock(scope: !2122, file: !2, line: 2968, column: 13)
!2122 = distinct !DILexicalBlock(scope: !2123, file: !2, line: 2967, column: 30)
!2123 = distinct !DILexicalBlock(scope: !2095, file: !2, line: 2967, column: 16)
!2124 = !DILocation(line: 2968, column: 58, scope: !2121)
!2125 = !DILocation(line: 2968, column: 13, scope: !2122)
!2126 = !DILocation(line: 2970, column: 13, scope: !2127)
!2127 = distinct !DILexicalBlock(scope: !2128, file: !2, line: 2970, column: 13)
!2128 = distinct !DILexicalBlock(scope: !2129, file: !2, line: 2970, column: 13)
!2129 = distinct !DILexicalBlock(scope: !2121, file: !2, line: 2968, column: 64)
!2130 = !DILocation(line: 2970, column: 13, scope: !2131)
!2131 = distinct !DILexicalBlock(scope: !2127, file: !2, line: 2970, column: 13)
!2132 = !DILocation(line: 2971, column: 13, scope: !2129)
!2133 = !DILocation(line: 2972, column: 9, scope: !2129)
!2134 = !DILocation(line: 2973, column: 13, scope: !2135)
!2135 = distinct !DILexicalBlock(scope: !2121, file: !2, line: 2972, column: 16)
!2136 = !DILocation(line: 2976, column: 18, scope: !2137)
!2137 = distinct !DILexicalBlock(scope: !2123, file: !2, line: 2976, column: 17)
!2138 = !DILocation(line: 2976, column: 65, scope: !2137)
!2139 = !DILocation(line: 2976, column: 70, scope: !2137)
!2140 = !DILocation(line: 2977, column: 18, scope: !2137)
!2141 = !DILocation(line: 2977, column: 65, scope: !2137)
!2142 = !DILocation(line: 2977, column: 70, scope: !2137)
!2143 = !DILocation(line: 0, scope: !2137)
!2144 = !DILocation(line: 2979, column: 9, scope: !2145)
!2145 = distinct !DILexicalBlock(scope: !2146, file: !2, line: 2979, column: 9)
!2146 = distinct !DILexicalBlock(scope: !2147, file: !2, line: 2979, column: 9)
!2147 = distinct !DILexicalBlock(scope: !2137, file: !2, line: 2977, column: 99)
!2148 = !DILocation(line: 2979, column: 9, scope: !2149)
!2149 = distinct !DILexicalBlock(scope: !2145, file: !2, line: 2979, column: 9)
!2150 = !DILocation(line: 2980, column: 9, scope: !2147)
!2151 = !DILocation(line: 2982, column: 5, scope: !2147)
!2152 = !DILocation(line: 2982, column: 16, scope: !2153)
!2153 = distinct !DILexicalBlock(scope: !2137, file: !2, line: 2982, column: 16)
!2154 = !DILocation(line: 2982, column: 60, scope: !2153)
!2155 = !DILocation(line: 2982, column: 16, scope: !2137)
!2156 = !DILocation(line: 2986, column: 9, scope: !2157)
!2157 = distinct !DILexicalBlock(scope: !2158, file: !2, line: 2986, column: 9)
!2158 = distinct !DILexicalBlock(scope: !2159, file: !2, line: 2986, column: 9)
!2159 = distinct !DILexicalBlock(scope: !2153, file: !2, line: 2982, column: 66)
!2160 = !DILocation(line: 2986, column: 9, scope: !2158)
!2161 = !DILocation(line: 2986, column: 9, scope: !2162)
!2162 = distinct !DILexicalBlock(scope: !2157, file: !2, line: 2986, column: 9)
!2163 = !DILocation(line: 2987, column: 9, scope: !2159)
!2164 = !DILocation(line: 2989, column: 5, scope: !2159)
!2165 = !DILocation(line: 2989, column: 16, scope: !2166)
!2166 = distinct !DILexicalBlock(scope: !2153, file: !2, line: 2989, column: 16)
!2167 = !DILocation(line: 2989, column: 65, scope: !2166)
!2168 = !DILocation(line: 2989, column: 16, scope: !2153)
!2169 = !DILocation(line: 2991, column: 9, scope: !2170)
!2170 = distinct !DILexicalBlock(scope: !2171, file: !2, line: 2991, column: 9)
!2171 = distinct !DILexicalBlock(scope: !2172, file: !2, line: 2991, column: 9)
!2172 = distinct !DILexicalBlock(scope: !2166, file: !2, line: 2989, column: 71)
!2173 = !DILocation(line: 2991, column: 9, scope: !2171)
!2174 = !DILocation(line: 2991, column: 9, scope: !2175)
!2175 = distinct !DILexicalBlock(scope: !2170, file: !2, line: 2991, column: 9)
!2176 = !DILocation(line: 2992, column: 9, scope: !2172)
!2177 = !DILocation(line: 2994, column: 5, scope: !2172)
!2178 = !DILocation(line: 2994, column: 16, scope: !2179)
!2179 = distinct !DILexicalBlock(scope: !2166, file: !2, line: 2994, column: 16)
!2180 = !DILocation(line: 2994, column: 63, scope: !2179)
!2181 = !DILocation(line: 2994, column: 16, scope: !2166)
!2182 = !DILocalVariable(name: "c", arg: 1, scope: !2183, file: !2, line: 2586, type: !780)
!2183 = distinct !DISubprogram(name: "process_version_command", scope: !2, file: !2, line: 2586, type: !778, scopeLine: 2586, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !2184)
!2184 = !{!2182}
!2185 = !DILocation(line: 0, scope: !2183, inlinedAt: !2186)
!2186 = distinct !DILocation(line: 2996, column: 9, scope: !2187)
!2187 = distinct !DILexicalBlock(scope: !2179, file: !2, line: 2994, column: 69)
!2188 = !DILocation(line: 2587, column: 5, scope: !2183, inlinedAt: !2186)
!2189 = !DILocation(line: 2998, column: 5, scope: !2187)
!2190 = !DILocation(line: 2998, column: 16, scope: !2191)
!2191 = distinct !DILexicalBlock(scope: !2179, file: !2, line: 2998, column: 16)
!2192 = !DILocation(line: 2998, column: 60, scope: !2191)
!2193 = !DILocation(line: 2998, column: 16, scope: !2179)
!2194 = !DILocalVariable(name: "c", arg: 1, scope: !2195, file: !2, line: 2590, type: !780)
!2195 = distinct !DISubprogram(name: "process_quit_command", scope: !2, file: !2, line: 2590, type: !778, scopeLine: 2590, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !2196)
!2196 = !{!2194}
!2197 = !DILocation(line: 0, scope: !2195, inlinedAt: !2198)
!2198 = distinct !DILocation(line: 3000, column: 9, scope: !2199)
!2199 = distinct !DILexicalBlock(scope: !2191, file: !2, line: 2998, column: 66)
!2200 = !DILocation(line: 2591, column: 5, scope: !2195, inlinedAt: !2198)
!2201 = !DILocation(line: 2592, column: 8, scope: !2195, inlinedAt: !2198)
!2202 = !DILocation(line: 2592, column: 26, scope: !2195, inlinedAt: !2198)
!2203 = !{!1211, !1216, i64 16}
!2204 = !DILocation(line: 2593, column: 8, scope: !2195, inlinedAt: !2198)
!2205 = !DILocation(line: 2593, column: 21, scope: !2195, inlinedAt: !2198)
!2206 = !{!1211, !1215, i64 324}
!2207 = !DILocation(line: 3002, column: 5, scope: !2199)
!2208 = !DILocation(line: 3002, column: 16, scope: !2209)
!2209 = distinct !DILexicalBlock(scope: !2191, file: !2, line: 3002, column: 16)
!2210 = !DILocation(line: 3002, column: 67, scope: !2209)
!2211 = !DILocation(line: 3002, column: 16, scope: !2191)
!2212 = !DILocation(line: 3004, column: 9, scope: !2213)
!2213 = distinct !DILexicalBlock(scope: !2209, file: !2, line: 3002, column: 73)
!2214 = !DILocation(line: 3006, column: 5, scope: !2213)
!2215 = !DILocation(line: 3006, column: 16, scope: !2216)
!2216 = distinct !DILexicalBlock(scope: !2209, file: !2, line: 3006, column: 16)
!2217 = !DILocation(line: 3006, column: 61, scope: !2216)
!2218 = !DILocation(line: 3006, column: 16, scope: !2209)
!2219 = !DILocation(line: 3008, column: 9, scope: !2220)
!2220 = distinct !DILexicalBlock(scope: !2216, file: !2, line: 3006, column: 67)
!2221 = !DILocation(line: 3010, column: 5, scope: !2220)
!2222 = !DILocation(line: 3010, column: 16, scope: !2223)
!2223 = distinct !DILexicalBlock(scope: !2216, file: !2, line: 3010, column: 16)
!2224 = !DILocation(line: 3010, column: 65, scope: !2223)
!2225 = !DILocation(line: 3010, column: 16, scope: !2216)
!2226 = !DILocation(line: 3011, column: 9, scope: !2227)
!2227 = distinct !DILexicalBlock(scope: !2228, file: !2, line: 3011, column: 9)
!2228 = distinct !DILexicalBlock(scope: !2229, file: !2, line: 3011, column: 9)
!2229 = distinct !DILexicalBlock(scope: !2223, file: !2, line: 3010, column: 71)
!2230 = !DILocation(line: 3011, column: 9, scope: !2231)
!2231 = distinct !DILexicalBlock(scope: !2227, file: !2, line: 3011, column: 9)
!2232 = !DILocation(line: 3012, column: 9, scope: !2229)
!2233 = !DILocation(line: 3013, column: 5, scope: !2229)
!2234 = !DILocation(line: 3013, column: 16, scope: !2235)
!2235 = distinct !DILexicalBlock(scope: !2223, file: !2, line: 3013, column: 16)
!2236 = !DILocation(line: 3013, column: 59, scope: !2235)
!2237 = !DILocation(line: 3013, column: 16, scope: !2223)
!2238 = !DILocation(line: 3014, column: 9, scope: !2239)
!2239 = distinct !DILexicalBlock(scope: !2240, file: !2, line: 3014, column: 9)
!2240 = distinct !DILexicalBlock(scope: !2241, file: !2, line: 3014, column: 9)
!2241 = distinct !DILexicalBlock(scope: !2235, file: !2, line: 3013, column: 65)
!2242 = !DILocation(line: 3014, column: 9, scope: !2240)
!2243 = !DILocation(line: 3014, column: 9, scope: !2244)
!2244 = distinct !DILexicalBlock(scope: !2239, file: !2, line: 3014, column: 9)
!2245 = !DILocation(line: 3015, column: 9, scope: !2241)
!2246 = !DILocation(line: 3022, column: 5, scope: !2241)
!2247 = !DILocation(line: 3022, column: 16, scope: !2248)
!2248 = distinct !DILexicalBlock(scope: !2235, file: !2, line: 3022, column: 16)
!2249 = !DILocation(line: 3022, column: 64, scope: !2248)
!2250 = !DILocation(line: 3022, column: 16, scope: !2235)
!2251 = !DILocation(line: 3023, column: 9, scope: !2252)
!2252 = distinct !DILexicalBlock(scope: !2253, file: !2, line: 3023, column: 9)
!2253 = distinct !DILexicalBlock(scope: !2254, file: !2, line: 3023, column: 9)
!2254 = distinct !DILexicalBlock(scope: !2248, file: !2, line: 3022, column: 70)
!2255 = !DILocation(line: 3023, column: 9, scope: !2253)
!2256 = !DILocation(line: 3023, column: 9, scope: !2257)
!2257 = distinct !DILexicalBlock(scope: !2252, file: !2, line: 3023, column: 9)
!2258 = !DILocation(line: 3024, column: 9, scope: !2254)
!2259 = !DILocation(line: 3030, column: 5, scope: !2254)
!2260 = !DILocation(line: 3031, column: 36, scope: !2261)
!2261 = distinct !DILexicalBlock(scope: !2262, file: !2, line: 3031, column: 13)
!2262 = distinct !DILexicalBlock(scope: !2248, file: !2, line: 3030, column: 12)
!2263 = !DILocation(line: 3031, column: 21, scope: !2261)
!2264 = !DILocation(line: 3031, column: 41, scope: !2261)
!2265 = !DILocation(line: 3031, column: 13, scope: !2261)
!2266 = !DILocation(line: 3031, column: 60, scope: !2261)
!2267 = !DILocation(line: 3031, column: 13, scope: !2262)
!2268 = !DILocation(line: 3032, column: 13, scope: !2269)
!2269 = distinct !DILexicalBlock(scope: !2261, file: !2, line: 3031, column: 66)
!2270 = !DILocation(line: 3033, column: 9, scope: !2269)
!2271 = !DILocation(line: 3034, column: 13, scope: !2272)
!2272 = distinct !DILexicalBlock(scope: !2261, file: !2, line: 3033, column: 16)
!2273 = !DILocation(line: 3038, column: 1, scope: !1843)
!2274 = !DISubprogram(name: "fprintf", scope: !2275, file: !2275, line: 357, type: !2276, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2275 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "1e435c46987a169d9f9186f63a512303")
!2276 = !DISubroutineType(types: !2277)
!2277 = !{!598, !2278, !2329, null}
!2278 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !2279)
!2279 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2280, size: 64)
!2280 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !2281, line: 7, baseType: !2282)
!2281 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!2282 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !2283, line: 49, size: 1728, elements: !2284)
!2283 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "7a6d4a00a37ee6b9a40cd04bd01f5d00")
!2284 = !{!2285, !2286, !2287, !2288, !2289, !2290, !2291, !2292, !2293, !2294, !2295, !2296, !2297, !2300, !2302, !2303, !2304, !2306, !2307, !2309, !2310, !2313, !2315, !2318, !2321, !2322, !2323, !2324, !2325}
!2285 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !2282, file: !2283, line: 51, baseType: !598, size: 32)
!2286 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !2282, file: !2283, line: 54, baseType: !579, size: 64, offset: 64)
!2287 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !2282, file: !2283, line: 55, baseType: !579, size: 64, offset: 128)
!2288 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !2282, file: !2283, line: 56, baseType: !579, size: 64, offset: 192)
!2289 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !2282, file: !2283, line: 57, baseType: !579, size: 64, offset: 256)
!2290 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !2282, file: !2283, line: 58, baseType: !579, size: 64, offset: 320)
!2291 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !2282, file: !2283, line: 59, baseType: !579, size: 64, offset: 384)
!2292 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !2282, file: !2283, line: 60, baseType: !579, size: 64, offset: 448)
!2293 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !2282, file: !2283, line: 61, baseType: !579, size: 64, offset: 512)
!2294 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !2282, file: !2283, line: 64, baseType: !579, size: 64, offset: 576)
!2295 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !2282, file: !2283, line: 65, baseType: !579, size: 64, offset: 640)
!2296 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !2282, file: !2283, line: 66, baseType: !579, size: 64, offset: 704)
!2297 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !2282, file: !2283, line: 68, baseType: !2298, size: 64, offset: 768)
!2298 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2299, size: 64)
!2299 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !2283, line: 36, flags: DIFlagFwdDecl)
!2300 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !2282, file: !2283, line: 70, baseType: !2301, size: 64, offset: 832)
!2301 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2282, size: 64)
!2302 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !2282, file: !2283, line: 72, baseType: !598, size: 32, offset: 896)
!2303 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !2282, file: !2283, line: 73, baseType: !598, size: 32, offset: 928)
!2304 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !2282, file: !2283, line: 74, baseType: !2305, size: 64, offset: 960)
!2305 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !605, line: 152, baseType: !675)
!2306 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !2282, file: !2283, line: 77, baseType: !600, size: 16, offset: 1024)
!2307 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !2282, file: !2283, line: 78, baseType: !2308, size: 8, offset: 1040)
!2308 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!2309 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !2282, file: !2283, line: 79, baseType: !268, size: 8, offset: 1048)
!2310 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !2282, file: !2283, line: 81, baseType: !2311, size: 64, offset: 1088)
!2311 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2312, size: 64)
!2312 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !2283, line: 43, baseType: null)
!2313 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !2282, file: !2283, line: 89, baseType: !2314, size: 64, offset: 1152)
!2314 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !605, line: 153, baseType: !675)
!2315 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !2282, file: !2283, line: 91, baseType: !2316, size: 64, offset: 1216)
!2316 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2317, size: 64)
!2317 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !2283, line: 37, flags: DIFlagFwdDecl)
!2318 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !2282, file: !2283, line: 92, baseType: !2319, size: 64, offset: 1280)
!2319 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2320, size: 64)
!2320 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !2283, line: 38, flags: DIFlagFwdDecl)
!2321 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !2282, file: !2283, line: 93, baseType: !2301, size: 64, offset: 1344)
!2322 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !2282, file: !2283, line: 94, baseType: !632, size: 64, offset: 1408)
!2323 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !2282, file: !2283, line: 95, baseType: !747, size: 64, offset: 1472)
!2324 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !2282, file: !2283, line: 96, baseType: !598, size: 32, offset: 1536)
!2325 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !2282, file: !2283, line: 98, baseType: !2326, size: 160, offset: 1568)
!2326 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 160, elements: !2327)
!2327 = !{!2328}
!2328 = !DISubrange(count: 20)
!2329 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1472)
!2330 = distinct !DISubprogram(name: "process_mget_command", scope: !2, file: !2, line: 1077, type: !2331, scopeLine: 1077, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !2333)
!2331 = !DISubroutineType(types: !2332)
!2332 = !{null, !780, !1544, !1545}
!2333 = !{!2334, !2335, !2336, !2337, !2338, !2339, !2340, !2341, !2367, !2368, !2369, !2370, !2371, !2372, !2373, !2374, !2375, !2376}
!2334 = !DILocalVariable(name: "c", arg: 1, scope: !2330, file: !2, line: 1077, type: !780)
!2335 = !DILocalVariable(name: "tokens", arg: 2, scope: !2330, file: !2, line: 1077, type: !1544)
!2336 = !DILocalVariable(name: "ntokens", arg: 3, scope: !2330, file: !2, line: 1077, type: !1545)
!2337 = !DILocalVariable(name: "key", scope: !2330, file: !2, line: 1078, type: !579)
!2338 = !DILocalVariable(name: "nkey", scope: !2330, file: !2, line: 1079, type: !747)
!2339 = !DILocalVariable(name: "it", scope: !2330, file: !2, line: 1080, type: !1062)
!2340 = !DILocalVariable(name: "i", scope: !2330, file: !2, line: 1081, type: !464)
!2341 = !DILocalVariable(name: "of", scope: !2330, file: !2, line: 1082, type: !2342)
!2342 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_meta_flags", file: !2, line: 907, size: 448, elements: !2343)
!2343 = !{!2344, !2345, !2346, !2347, !2348, !2349, !2350, !2351, !2352, !2353, !2354, !2355, !2356, !2357, !2358, !2359, !2360, !2361, !2362, !2363, !2364, !2365, !2366}
!2344 = !DIDerivedType(tag: DW_TAG_member, name: "has_error", scope: !2342, file: !2, line: 908, baseType: !464, size: 1, flags: DIFlagBitField, extraData: i64 0)
!2345 = !DIDerivedType(tag: DW_TAG_member, name: "no_update", scope: !2342, file: !2, line: 909, baseType: !464, size: 1, offset: 1, flags: DIFlagBitField, extraData: i64 0)
!2346 = !DIDerivedType(tag: DW_TAG_member, name: "locked", scope: !2342, file: !2, line: 910, baseType: !464, size: 1, offset: 2, flags: DIFlagBitField, extraData: i64 0)
!2347 = !DIDerivedType(tag: DW_TAG_member, name: "vivify", scope: !2342, file: !2, line: 911, baseType: !464, size: 1, offset: 3, flags: DIFlagBitField, extraData: i64 0)
!2348 = !DIDerivedType(tag: DW_TAG_member, name: "la", scope: !2342, file: !2, line: 912, baseType: !464, size: 1, offset: 4, flags: DIFlagBitField, extraData: i64 0)
!2349 = !DIDerivedType(tag: DW_TAG_member, name: "hit", scope: !2342, file: !2, line: 913, baseType: !464, size: 1, offset: 5, flags: DIFlagBitField, extraData: i64 0)
!2350 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !2342, file: !2, line: 914, baseType: !464, size: 1, offset: 6, flags: DIFlagBitField, extraData: i64 0)
!2351 = !DIDerivedType(tag: DW_TAG_member, name: "set_stale", scope: !2342, file: !2, line: 915, baseType: !464, size: 1, offset: 7, flags: DIFlagBitField, extraData: i64 0)
!2352 = !DIDerivedType(tag: DW_TAG_member, name: "no_reply", scope: !2342, file: !2, line: 916, baseType: !464, size: 1, offset: 8, flags: DIFlagBitField, extraData: i64 0)
!2353 = !DIDerivedType(tag: DW_TAG_member, name: "has_cas", scope: !2342, file: !2, line: 917, baseType: !464, size: 1, offset: 9, flags: DIFlagBitField, extraData: i64 0)
!2354 = !DIDerivedType(tag: DW_TAG_member, name: "has_cas_in", scope: !2342, file: !2, line: 918, baseType: !464, size: 1, offset: 10, flags: DIFlagBitField, extraData: i64 0)
!2355 = !DIDerivedType(tag: DW_TAG_member, name: "new_ttl", scope: !2342, file: !2, line: 919, baseType: !464, size: 1, offset: 11, flags: DIFlagBitField, extraData: i64 0)
!2356 = !DIDerivedType(tag: DW_TAG_member, name: "key_binary", scope: !2342, file: !2, line: 920, baseType: !464, size: 1, offset: 12, flags: DIFlagBitField, extraData: i64 0)
!2357 = !DIDerivedType(tag: DW_TAG_member, name: "remove_val", scope: !2342, file: !2, line: 921, baseType: !464, size: 1, offset: 13, flags: DIFlagBitField, extraData: i64 0)
!2358 = !DIDerivedType(tag: DW_TAG_member, name: "mode", scope: !2342, file: !2, line: 922, baseType: !4, size: 8, offset: 16)
!2359 = !DIDerivedType(tag: DW_TAG_member, name: "exptime", scope: !2342, file: !2, line: 923, baseType: !595, size: 32, offset: 32)
!2360 = !DIDerivedType(tag: DW_TAG_member, name: "autoviv_exptime", scope: !2342, file: !2, line: 924, baseType: !595, size: 32, offset: 64)
!2361 = !DIDerivedType(tag: DW_TAG_member, name: "recache_time", scope: !2342, file: !2, line: 925, baseType: !595, size: 32, offset: 96)
!2362 = !DIDerivedType(tag: DW_TAG_member, name: "client_flags", scope: !2342, file: !2, line: 926, baseType: !634, size: 32, offset: 128)
!2363 = !DIDerivedType(tag: DW_TAG_member, name: "req_cas_id", scope: !2342, file: !2, line: 927, baseType: !616, size: 64, offset: 192)
!2364 = !DIDerivedType(tag: DW_TAG_member, name: "cas_id_in", scope: !2342, file: !2, line: 928, baseType: !616, size: 64, offset: 256)
!2365 = !DIDerivedType(tag: DW_TAG_member, name: "delta", scope: !2342, file: !2, line: 929, baseType: !616, size: 64, offset: 320)
!2366 = !DIDerivedType(tag: DW_TAG_member, name: "initial", scope: !2342, file: !2, line: 930, baseType: !616, size: 64, offset: 384)
!2367 = !DILocalVariable(name: "hv", scope: !2330, file: !2, line: 1083, type: !635)
!2368 = !DILocalVariable(name: "failed", scope: !2330, file: !2, line: 1084, type: !790)
!2369 = !DILocalVariable(name: "item_created", scope: !2330, file: !2, line: 1085, type: !790)
!2370 = !DILocalVariable(name: "won_token", scope: !2330, file: !2, line: 1086, type: !790)
!2371 = !DILocalVariable(name: "ttl_set", scope: !2330, file: !2, line: 1087, type: !790)
!2372 = !DILocalVariable(name: "errstr", scope: !2330, file: !2, line: 1088, type: !579)
!2373 = !DILocalVariable(name: "resp", scope: !2330, file: !2, line: 1090, type: !882)
!2374 = !DILocalVariable(name: "p", scope: !2330, file: !2, line: 1091, type: !579)
!2375 = !DILocalVariable(name: "overflow", scope: !2330, file: !2, line: 1124, type: !790)
!2376 = !DILabel(scope: !2330, name: "error", file: !2, line: 1387)
!2377 = distinct !DIAssignID()
!2378 = !DILocation(line: 0, scope: !2330)
!2379 = distinct !DIAssignID()
!2380 = distinct !DIAssignID()
!2381 = distinct !DIAssignID()
!2382 = !DILocation(line: 1082, column: 5, scope: !2330)
!2383 = !DILocation(line: 1082, column: 24, scope: !2330)
!2384 = distinct !DIAssignID()
!2385 = !DILocation(line: 1083, column: 5, scope: !2330)
!2386 = !DILocation(line: 1088, column: 5, scope: !2330)
!2387 = !DILocation(line: 1088, column: 11, scope: !2330)
!2388 = distinct !DIAssignID()
!2389 = !DILocation(line: 1090, column: 24, scope: !2330)
!2390 = !DILocation(line: 1091, column: 21, scope: !2330)
!2391 = !DILocation(line: 1093, column: 5, scope: !2392)
!2392 = distinct !DILexicalBlock(scope: !2393, file: !2, line: 1093, column: 5)
!2393 = distinct !DILexicalBlock(scope: !2330, file: !2, line: 1093, column: 5)
!2394 = !DILocation(line: 1093, column: 5, scope: !2393)
!2395 = !DILocation(line: 1093, column: 5, scope: !2396)
!2396 = distinct !DILexicalBlock(scope: !2392, file: !2, line: 1093, column: 5)
!2397 = !DILocation(line: 1096, column: 9, scope: !2398)
!2398 = distinct !DILexicalBlock(scope: !2330, file: !2, line: 1096, column: 9)
!2399 = !DILocation(line: 1096, column: 27, scope: !2398)
!2400 = !DILocation(line: 1096, column: 34, scope: !2398)
!2401 = !DILocation(line: 1096, column: 9, scope: !2330)
!2402 = !DILocation(line: 1097, column: 9, scope: !2403)
!2403 = distinct !DILexicalBlock(scope: !2398, file: !2, line: 1096, column: 52)
!2404 = !DILocation(line: 1098, column: 9, scope: !2403)
!2405 = !DILocation(line: 1104, column: 17, scope: !2406)
!2406 = distinct !DILexicalBlock(scope: !2330, file: !2, line: 1104, column: 9)
!2407 = !DILocation(line: 1104, column: 9, scope: !2330)
!2408 = !DILocation(line: 1106, column: 9, scope: !2409)
!2409 = distinct !DILexicalBlock(scope: !2406, file: !2, line: 1104, column: 41)
!2410 = !DILocation(line: 1107, column: 9, scope: !2409)
!2411 = !DILocation(line: 1112, column: 9, scope: !2412)
!2412 = distinct !DILexicalBlock(scope: !2330, file: !2, line: 1112, column: 9)
!2413 = !DILocation(line: 1112, column: 54, scope: !2412)
!2414 = !DILocation(line: 1112, column: 9, scope: !2330)
!2415 = !DILocation(line: 1113, column: 26, scope: !2416)
!2416 = distinct !DILexicalBlock(scope: !2412, file: !2, line: 1112, column: 60)
!2417 = !DILocation(line: 1113, column: 9, scope: !2416)
!2418 = !DILocation(line: 1114, column: 9, scope: !2416)
!2419 = !DILocation(line: 1116, column: 21, scope: !2330)
!2420 = !DILocation(line: 1116, column: 8, scope: !2330)
!2421 = !DILocation(line: 1116, column: 16, scope: !2330)
!2422 = !DILocation(line: 1119, column: 29, scope: !2330)
!2423 = !DILocation(line: 1120, column: 30, scope: !2330)
!2424 = !DILocation(line: 1124, column: 5, scope: !2330)
!2425 = !DILocation(line: 1124, column: 10, scope: !2330)
!2426 = !{!1216, !1216, i64 0}
!2427 = distinct !DIAssignID()
!2428 = !DILocation(line: 1125, column: 10, scope: !2429)
!2429 = distinct !DILexicalBlock(scope: !2330, file: !2, line: 1125, column: 9)
!2430 = !DILocation(line: 0, scope: !2429)
!2431 = !DILocation(line: 1125, column: 9, scope: !2330)
!2432 = !DILocation(line: 1126, column: 58, scope: !2433)
!2433 = distinct !DILexicalBlock(scope: !2429, file: !2, line: 1125, column: 21)
!2434 = !DILocation(line: 1126, column: 14, scope: !2433)
!2435 = !DILocation(line: 1127, column: 5, scope: !2433)
!2436 = !DILocation(line: 1129, column: 14, scope: !2437)
!2437 = distinct !DILexicalBlock(scope: !2429, file: !2, line: 1127, column: 12)
!2438 = !DILocation(line: 1135, column: 9, scope: !2439)
!2439 = distinct !DILexicalBlock(scope: !2330, file: !2, line: 1135, column: 9)
!2440 = !DILocation(line: 1135, column: 9, scope: !2330)
!2441 = !DILocation(line: 1137, column: 9, scope: !2442)
!2442 = distinct !DILexicalBlock(scope: !2439, file: !2, line: 1135, column: 19)
!2443 = !DILocation(line: 1138, column: 9, scope: !2442)
!2444 = !DILocation(line: 1141, column: 12, scope: !2445)
!2445 = distinct !DILexicalBlock(scope: !2330, file: !2, line: 1141, column: 9)
!2446 = !DILocation(line: 1141, column: 20, scope: !2445)
!2447 = !DILocation(line: 1141, column: 26, scope: !2445)
!2448 = !DILocation(line: 1141, column: 23, scope: !2445)
!2449 = !DILocation(line: 1141, column: 9, scope: !2330)
!2450 = !DILocation(line: 1143, column: 39, scope: !2451)
!2451 = distinct !DILexicalBlock(scope: !2445, file: !2, line: 1141, column: 34)
!2452 = !DILocation(line: 1143, column: 14, scope: !2451)
!2453 = !DILocation(line: 1149, column: 16, scope: !2454)
!2454 = distinct !DILexicalBlock(scope: !2451, file: !2, line: 1149, column: 13)
!2455 = !DILocation(line: 1149, column: 13, scope: !2451)
!2456 = !DILocation(line: 1151, column: 20, scope: !2457)
!2457 = distinct !DILexicalBlock(scope: !2454, file: !2, line: 1149, column: 25)
!2458 = !DILocation(line: 1151, column: 13, scope: !2457)
!2459 = !DILocation(line: 1153, column: 30, scope: !2457)
!2460 = !DILocation(line: 1153, column: 37, scope: !2457)
!2461 = !DILocation(line: 1153, column: 34, scope: !2457)
!2462 = !DILocation(line: 1153, column: 53, scope: !2457)
!2463 = !{!2464, !1222, i64 32}
!2464 = !{!"_meta_flags", !1215, i64 0, !1215, i64 0, !1215, i64 0, !1215, i64 0, !1215, i64 0, !1215, i64 0, !1215, i64 0, !1215, i64 0, !1215, i64 1, !1215, i64 1, !1215, i64 1, !1215, i64 1, !1215, i64 1, !1215, i64 1, !1213, i64 2, !1215, i64 4, !1215, i64 8, !1215, i64 12, !1215, i64 16, !1222, i64 24, !1222, i64 32, !1222, i64 40, !1222, i64 48}
!2465 = !DILocation(line: 1153, column: 65, scope: !2457)
!2466 = !DILocation(line: 1153, column: 13, scope: !2457)
!2467 = !DILocation(line: 1155, column: 9, scope: !2457)
!2468 = !DILocation(line: 1161, column: 16, scope: !2469)
!2469 = distinct !DILexicalBlock(scope: !2470, file: !2, line: 1161, column: 13)
!2470 = distinct !DILexicalBlock(scope: !2471, file: !2, line: 1160, column: 13)
!2471 = distinct !DILexicalBlock(scope: !2330, file: !2, line: 1160, column: 9)
!2472 = !DILocation(line: 1161, column: 13, scope: !2469)
!2473 = !DILocation(line: 1161, column: 13, scope: !2470)
!2474 = !DILocation(line: 1162, column: 13, scope: !2475)
!2475 = distinct !DILexicalBlock(scope: !2469, file: !2, line: 1161, column: 23)
!2476 = !DILocation(line: 1163, column: 30, scope: !2475)
!2477 = !DILocation(line: 1163, column: 36, scope: !2475)
!2478 = !DILocation(line: 1163, column: 41, scope: !2475)
!2479 = !DILocation(line: 1163, column: 17, scope: !2475)
!2480 = !DILocation(line: 1164, column: 9, scope: !2475)
!2481 = !DILocation(line: 1165, column: 13, scope: !2482)
!2482 = distinct !DILexicalBlock(scope: !2469, file: !2, line: 1164, column: 16)
!2483 = !DILocation(line: 1166, column: 15, scope: !2482)
!2484 = !DILocation(line: 0, scope: !2469)
!2485 = !DILocation(line: 1169, column: 33, scope: !2486)
!2486 = distinct !DILexicalBlock(scope: !2487, file: !2, line: 1169, column: 9)
!2487 = distinct !DILexicalBlock(scope: !2470, file: !2, line: 1169, column: 9)
!2488 = !DILocation(line: 1169, column: 9, scope: !2487)
!2489 = !DILocation(line: 1170, column: 21, scope: !2490)
!2490 = distinct !DILexicalBlock(scope: !2486, file: !2, line: 1169, column: 51)
!2491 = !DILocation(line: 1170, column: 31, scope: !2490)
!2492 = !DILocation(line: 1170, column: 13, scope: !2490)
!2493 = !DILocation(line: 1173, column: 38, scope: !2494)
!2494 = distinct !DILexicalBlock(scope: !2490, file: !2, line: 1170, column: 41)
!2495 = !{!2464, !1215, i64 4}
!2496 = !DILocation(line: 1173, column: 33, scope: !2494)
!2497 = !DILocation(line: 1174, column: 21, scope: !2494)
!2498 = !DILocation(line: 1176, column: 25, scope: !2494)
!2499 = !DILocation(line: 1177, column: 42, scope: !2500)
!2500 = distinct !DILexicalBlock(scope: !2501, file: !2, line: 1176, column: 39)
!2501 = distinct !DILexicalBlock(scope: !2494, file: !2, line: 1176, column: 25)
!2502 = !{!2464, !1215, i64 8}
!2503 = !DILocation(line: 1177, column: 37, scope: !2500)
!2504 = !DILocation(line: 1179, column: 21, scope: !2500)
!2505 = !DILocation(line: 1184, column: 30, scope: !2506)
!2506 = distinct !DILexicalBlock(scope: !2494, file: !2, line: 1184, column: 25)
!2507 = !DILocation(line: 1184, column: 39, scope: !2506)
!2508 = !DILocation(line: 1184, column: 58, scope: !2506)
!2509 = !DILocation(line: 1185, column: 29, scope: !2506)
!2510 = !DILocation(line: 1186, column: 36, scope: !2506)
!2511 = !DILocation(line: 1186, column: 44, scope: !2506)
!2512 = !DILocation(line: 1187, column: 29, scope: !2506)
!2513 = !DILocation(line: 1187, column: 49, scope: !2506)
!2514 = !{!2464, !1215, i64 12}
!2515 = !DILocation(line: 1187, column: 44, scope: !2506)
!2516 = !DILocation(line: 1184, column: 25, scope: !2494)
!2517 = !DILocation(line: 1192, column: 21, scope: !2518)
!2518 = distinct !DILexicalBlock(scope: !2494, file: !2, line: 1192, column: 21)
!2519 = !DILocation(line: 1193, column: 38, scope: !2494)
!2520 = !DILocation(line: 1193, column: 44, scope: !2494)
!2521 = !DILocation(line: 1193, column: 25, scope: !2494)
!2522 = !DILocation(line: 1194, column: 21, scope: !2494)
!2523 = !DILocation(line: 1198, column: 21, scope: !2524)
!2524 = distinct !DILexicalBlock(scope: !2494, file: !2, line: 1198, column: 21)
!2525 = !DILocation(line: 1199, column: 29, scope: !2526)
!2526 = distinct !DILexicalBlock(scope: !2494, file: !2, line: 1199, column: 25)
!2527 = !DILocation(line: 1199, column: 37, scope: !2526)
!2528 = !DILocation(line: 1199, column: 25, scope: !2494)
!2529 = !DILocation(line: 1200, column: 28, scope: !2530)
!2530 = distinct !DILexicalBlock(scope: !2526, file: !2, line: 1199, column: 43)
!2531 = !DILocation(line: 1201, column: 28, scope: !2530)
!2532 = !DILocation(line: 1201, column: 32, scope: !2530)
!2533 = !DILocation(line: 1202, column: 27, scope: !2530)
!2534 = !DILocation(line: 1203, column: 21, scope: !2530)
!2535 = !DILocation(line: 1204, column: 52, scope: !2536)
!2536 = distinct !DILexicalBlock(scope: !2526, file: !2, line: 1203, column: 28)
!2537 = !DILocation(line: 1204, column: 50, scope: !2536)
!2538 = !DILocation(line: 1204, column: 29, scope: !2536)
!2539 = !DILocation(line: 1208, column: 21, scope: !2540)
!2540 = distinct !DILexicalBlock(scope: !2494, file: !2, line: 1208, column: 21)
!2541 = !DILocation(line: 1209, column: 34, scope: !2494)
!2542 = !DILocation(line: 1209, column: 25, scope: !2494)
!2543 = !DILocation(line: 1210, column: 21, scope: !2494)
!2544 = !DILocation(line: 1212, column: 21, scope: !2545)
!2545 = distinct !DILexicalBlock(scope: !2494, file: !2, line: 1212, column: 21)
!2546 = !DILocation(line: 1213, column: 25, scope: !2547)
!2547 = distinct !DILexicalBlock(scope: !2494, file: !2, line: 1213, column: 25)
!2548 = !DILocation(line: 1213, column: 40, scope: !2547)
!2549 = !DILocation(line: 1213, column: 25, scope: !2494)
!2550 = !DILocation(line: 1214, column: 28, scope: !2551)
!2551 = distinct !DILexicalBlock(scope: !2547, file: !2, line: 1213, column: 46)
!2552 = !DILocation(line: 1215, column: 26, scope: !2551)
!2553 = !DILocation(line: 1216, column: 21, scope: !2551)
!2554 = !DILocation(line: 1217, column: 59, scope: !2555)
!2555 = distinct !DILexicalBlock(scope: !2547, file: !2, line: 1216, column: 28)
!2556 = !DILocation(line: 1217, column: 38, scope: !2555)
!2557 = !DILocation(line: 1217, column: 29, scope: !2555)
!2558 = !DILocation(line: 1221, column: 21, scope: !2559)
!2559 = distinct !DILexicalBlock(scope: !2494, file: !2, line: 1221, column: 21)
!2560 = !DILocation(line: 1222, column: 34, scope: !2494)
!2561 = !DILocation(line: 1222, column: 53, scope: !2494)
!2562 = !DILocation(line: 1222, column: 47, scope: !2494)
!2563 = !DILocation(line: 1222, column: 25, scope: !2494)
!2564 = !DILocation(line: 1223, column: 21, scope: !2494)
!2565 = !DILocation(line: 1225, column: 21, scope: !2566)
!2566 = distinct !DILexicalBlock(scope: !2494, file: !2, line: 1225, column: 21)
!2567 = !DILocation(line: 1226, column: 29, scope: !2568)
!2568 = distinct !DILexicalBlock(scope: !2494, file: !2, line: 1226, column: 25)
!2569 = !DILocation(line: 1226, column: 38, scope: !2568)
!2570 = !DILocation(line: 0, scope: !2568)
!2571 = !DILocation(line: 1231, column: 22, scope: !2494)
!2572 = !DILocation(line: 1232, column: 21, scope: !2494)
!2573 = !DILocation(line: 1234, column: 35, scope: !2574)
!2574 = distinct !DILexicalBlock(scope: !2494, file: !2, line: 1234, column: 25)
!2575 = !DILocation(line: 1234, column: 42, scope: !2574)
!2576 = !DILocation(line: 1234, column: 25, scope: !2494)
!2577 = distinct !DIAssignID()
!2578 = !DILocation(line: 1387, column: 1, scope: !2330)
!2579 = !DILocation(line: 1388, column: 9, scope: !2330)
!2580 = !DILocation(line: 1238, column: 21, scope: !2581)
!2581 = distinct !DILexicalBlock(scope: !2494, file: !2, line: 1238, column: 21)
!2582 = !DILocation(line: 1239, column: 41, scope: !2494)
!2583 = !DILocation(line: 1239, column: 58, scope: !2494)
!2584 = !DILocation(line: 1239, column: 21, scope: !2494)
!2585 = !DILocation(line: 1240, column: 36, scope: !2494)
!2586 = !DILocation(line: 1240, column: 23, scope: !2494)
!2587 = !DILocation(line: 1241, column: 21, scope: !2494)
!2588 = !DILocation(line: 1243, column: 21, scope: !2589)
!2589 = distinct !DILexicalBlock(scope: !2590, file: !2, line: 1243, column: 21)
!2590 = distinct !DILexicalBlock(scope: !2494, file: !2, line: 1243, column: 21)
!2591 = !DILocation(line: 1243, column: 21, scope: !2592)
!2592 = distinct !DILexicalBlock(scope: !2590, file: !2, line: 1243, column: 21)
!2593 = !DILocation(line: 1243, column: 21, scope: !2590)
!2594 = !DILocation(line: 1243, column: 21, scope: !2595)
!2595 = distinct !DILexicalBlock(scope: !2592, file: !2, line: 1243, column: 21)
!2596 = !DILocation(line: 1243, column: 21, scope: !2597)
!2597 = distinct !DILexicalBlock(scope: !2592, file: !2, line: 1243, column: 21)
!2598 = !DILocation(line: 0, scope: !2470)
!2599 = !DILocation(line: 1169, column: 47, scope: !2486)
!2600 = !DILocation(line: 1169, column: 31, scope: !2486)
!2601 = distinct !{!2601, !2488, !2602, !1410}
!2602 = !DILocation(line: 1246, column: 9, scope: !2487)
!2603 = !DILocation(line: 1086, column: 10, scope: !2330)
!2604 = !DILocation(line: 1087, column: 10, scope: !2330)
!2605 = !DILocation(line: 1163, column: 15, scope: !2475)
!2606 = !DILocation(line: 1251, column: 17, scope: !2607)
!2607 = distinct !DILexicalBlock(scope: !2470, file: !2, line: 1251, column: 13)
!2608 = !DILocation(line: 1251, column: 26, scope: !2607)
!2609 = !DILocation(line: 1251, column: 13, scope: !2470)
!2610 = !DILocation(line: 1252, column: 13, scope: !2611)
!2611 = distinct !DILexicalBlock(scope: !2612, file: !2, line: 1252, column: 13)
!2612 = distinct !DILexicalBlock(scope: !2607, file: !2, line: 1251, column: 45)
!2613 = !DILocation(line: 1254, column: 17, scope: !2614)
!2614 = distinct !DILexicalBlock(scope: !2470, file: !2, line: 1254, column: 13)
!2615 = !DILocation(line: 1253, column: 9, scope: !2612)
!2616 = !DILocation(line: 1254, column: 26, scope: !2614)
!2617 = !DILocation(line: 1254, column: 13, scope: !2470)
!2618 = !DILocation(line: 1255, column: 13, scope: !2619)
!2619 = distinct !DILexicalBlock(scope: !2620, file: !2, line: 1255, column: 13)
!2620 = distinct !DILexicalBlock(scope: !2614, file: !2, line: 1254, column: 40)
!2621 = !DILocation(line: 1257, column: 22, scope: !2622)
!2622 = distinct !DILexicalBlock(scope: !2620, file: !2, line: 1257, column: 17)
!2623 = !DILocation(line: 1257, column: 31, scope: !2622)
!2624 = !DILocation(line: 1257, column: 50, scope: !2622)
!2625 = !DILocation(line: 1257, column: 17, scope: !2620)
!2626 = !DILocation(line: 1263, column: 13, scope: !2470)
!2627 = !DILocation(line: 1265, column: 13, scope: !2628)
!2628 = distinct !DILexicalBlock(scope: !2629, file: !2, line: 1265, column: 13)
!2629 = distinct !DILexicalBlock(scope: !2630, file: !2, line: 1263, column: 24)
!2630 = distinct !DILexicalBlock(scope: !2470, file: !2, line: 1263, column: 13)
!2631 = !DILocation(line: 1266, column: 26, scope: !2629)
!2632 = !DILocation(line: 1267, column: 9, scope: !2629)
!2633 = !DILocation(line: 1269, column: 12, scope: !2470)
!2634 = !DILocation(line: 1270, column: 12, scope: !2470)
!2635 = !DILocation(line: 1270, column: 16, scope: !2470)
!2636 = !DILocation(line: 1271, column: 12, scope: !2470)
!2637 = !DILocation(line: 1271, column: 16, scope: !2470)
!2638 = !DILocation(line: 1274, column: 42, scope: !2470)
!2639 = !DILocation(line: 1274, column: 40, scope: !2470)
!2640 = !DILocation(line: 1274, column: 9, scope: !2470)
!2641 = !DILocation(line: 1276, column: 16, scope: !2642)
!2642 = distinct !DILexicalBlock(scope: !2470, file: !2, line: 1276, column: 13)
!2643 = !DILocation(line: 1276, column: 13, scope: !2642)
!2644 = !DILocation(line: 1276, column: 13, scope: !2470)
!2645 = !DILocation(line: 1278, column: 21, scope: !2646)
!2646 = distinct !DILexicalBlock(scope: !2647, file: !2, line: 1278, column: 17)
!2647 = distinct !DILexicalBlock(scope: !2642, file: !2, line: 1276, column: 23)
!2648 = !DILocation(line: 1278, column: 17, scope: !2646)
!2649 = !DILocation(line: 1278, column: 30, scope: !2646)
!2650 = !DILocation(line: 1278, column: 17, scope: !2647)
!2651 = !DILocation(line: 1279, column: 21, scope: !2652)
!2652 = distinct !DILexicalBlock(scope: !2653, file: !2, line: 1279, column: 21)
!2653 = distinct !DILexicalBlock(scope: !2646, file: !2, line: 1278, column: 42)
!2654 = !DILocation(line: 1279, column: 51, scope: !2652)
!2655 = !DILocation(line: 1279, column: 21, scope: !2653)
!2656 = !DILocation(line: 1286, column: 38, scope: !2657)
!2657 = distinct !DILexicalBlock(scope: !2646, file: !2, line: 1286, column: 24)
!2658 = !DILocation(line: 1286, column: 54, scope: !2657)
!2659 = !DILocation(line: 1286, column: 24, scope: !2646)
!2660 = !DILocation(line: 1287, column: 36, scope: !2661)
!2661 = distinct !DILexicalBlock(scope: !2657, file: !2, line: 1286, column: 60)
!2662 = !DILocation(line: 1287, column: 55, scope: !2661)
!2663 = !DILocation(line: 1287, column: 17, scope: !2661)
!2664 = !DILocation(line: 1288, column: 13, scope: !2661)
!2665 = !DILocation(line: 1289, column: 52, scope: !2666)
!2666 = distinct !DILexicalBlock(scope: !2657, file: !2, line: 1288, column: 20)
!2667 = !DILocation(line: 1289, column: 17, scope: !2666)
!2668 = !DILocation(line: 1303, column: 22, scope: !2669)
!2669 = distinct !DILexicalBlock(scope: !2670, file: !2, line: 1303, column: 17)
!2670 = distinct !DILexicalBlock(scope: !2671, file: !2, line: 1302, column: 22)
!2671 = distinct !DILexicalBlock(scope: !2470, file: !2, line: 1302, column: 13)
!2672 = !DILocation(line: 1303, column: 31, scope: !2669)
!2673 = !DILocation(line: 1303, column: 43, scope: !2669)
!2674 = !DILocation(line: 1303, column: 48, scope: !2669)
!2675 = !DILocation(line: 1303, column: 54, scope: !2669)
!2676 = !DILocation(line: 1303, column: 51, scope: !2669)
!2677 = !DILocation(line: 1303, column: 17, scope: !2670)
!2678 = !DILocation(line: 1305, column: 23, scope: !2679)
!2679 = distinct !DILexicalBlock(scope: !2669, file: !2, line: 1303, column: 61)
!2680 = !DILocation(line: 1305, column: 28, scope: !2679)
!2681 = !{!1356, !1212, i64 40}
!2682 = !DILocation(line: 1306, column: 13, scope: !2679)
!2683 = !DILocation(line: 1307, column: 23, scope: !2684)
!2684 = distinct !DILexicalBlock(scope: !2669, file: !2, line: 1306, column: 20)
!2685 = !DILocation(line: 1307, column: 28, scope: !2684)
!2686 = !DILocation(line: 1280, column: 44, scope: !2687)
!2687 = distinct !DILexicalBlock(scope: !2652, file: !2, line: 1279, column: 57)
!2688 = !DILocation(line: 1280, column: 52, scope: !2687)
!2689 = !DILocation(line: 1280, column: 21, scope: !2687)
!2690 = !DILocation(line: 1281, column: 24, scope: !2687)
!2691 = !DILocation(line: 1281, column: 38, scope: !2687)
!2692 = !DILocation(line: 1281, column: 54, scope: !2687)
!2693 = !{!1316, !1222, i64 600}
!2694 = !DILocation(line: 1282, column: 54, scope: !2687)
!2695 = !DILocation(line: 1282, column: 21, scope: !2687)
!2696 = !DILocation(line: 1311, column: 20, scope: !2697)
!2697 = distinct !DILexicalBlock(scope: !2698, file: !2, line: 1311, column: 17)
!2698 = distinct !DILexicalBlock(scope: !2671, file: !2, line: 1309, column: 16)
!2699 = !DILocation(line: 1311, column: 17, scope: !2697)
!2700 = !DILocation(line: 1311, column: 17, scope: !2698)
!2701 = !DILocation(line: 1312, column: 17, scope: !2702)
!2702 = distinct !DILexicalBlock(scope: !2697, file: !2, line: 1311, column: 28)
!2703 = !DILocation(line: 1313, column: 13, scope: !2702)
!2704 = !DILocation(line: 1314, column: 17, scope: !2705)
!2705 = distinct !DILexicalBlock(scope: !2697, file: !2, line: 1313, column: 20)
!2706 = !DILocation(line: 0, scope: !2471)
!2707 = !DILocation(line: 1324, column: 12, scope: !2708)
!2708 = distinct !DILexicalBlock(scope: !2330, file: !2, line: 1324, column: 9)
!2709 = !DILocation(line: 1324, column: 9, scope: !2708)
!2710 = !DILocation(line: 1324, column: 9, scope: !2330)
!2711 = !DILocation(line: 1326, column: 14, scope: !2712)
!2712 = distinct !DILexicalBlock(scope: !2713, file: !2, line: 1326, column: 13)
!2713 = distinct !DILexicalBlock(scope: !2708, file: !2, line: 1324, column: 20)
!2714 = !DILocation(line: 1326, column: 27, scope: !2712)
!2715 = !DILocation(line: 1327, column: 29, scope: !2716)
!2716 = distinct !DILexicalBlock(scope: !2712, file: !2, line: 1326, column: 42)
!2717 = !DILocation(line: 1327, column: 41, scope: !2716)
!2718 = !DILocation(line: 1327, column: 13, scope: !2716)
!2719 = !DILocation(line: 1328, column: 9, scope: !2716)
!2720 = !DILocation(line: 1329, column: 21, scope: !2713)
!2721 = !DILocation(line: 1329, column: 9, scope: !2713)
!2722 = !DILocation(line: 1330, column: 5, scope: !2713)
!2723 = !DILocation(line: 0, scope: !2724)
!2724 = distinct !DILexicalBlock(scope: !2330, file: !2, line: 1334, column: 9)
!2725 = !DILocation(line: 1334, column: 9, scope: !2330)
!2726 = !DILocation(line: 1336, column: 13, scope: !2727)
!2727 = distinct !DILexicalBlock(scope: !2724, file: !2, line: 1334, column: 18)
!2728 = !DILocation(line: 1337, column: 30, scope: !2729)
!2729 = distinct !DILexicalBlock(scope: !2730, file: !2, line: 1336, column: 22)
!2730 = distinct !DILexicalBlock(scope: !2727, file: !2, line: 1336, column: 13)
!2731 = !DILocation(line: 1337, column: 40, scope: !2729)
!2732 = !{!1316, !1222, i64 424}
!2733 = !DILocation(line: 1338, column: 30, scope: !2729)
!2734 = !DILocation(line: 1338, column: 41, scope: !2729)
!2735 = !DILocation(line: 1338, column: 57, scope: !2729)
!2736 = !DILocation(line: 1339, column: 9, scope: !2729)
!2737 = !DILocation(line: 1340, column: 30, scope: !2738)
!2738 = distinct !DILexicalBlock(scope: !2730, file: !2, line: 1339, column: 16)
!2739 = !DILocation(line: 1340, column: 43, scope: !2738)
!2740 = !DILocation(line: 1340, column: 13, scope: !2738)
!2741 = !DILocation(line: 1340, column: 55, scope: !2738)
!2742 = !DILocation(line: 1341, column: 30, scope: !2738)
!2743 = !DILocation(line: 0, scope: !2730)
!2744 = !DILocation(line: 1343, column: 42, scope: !2727)
!2745 = !DILocation(line: 1343, column: 9, scope: !2727)
!2746 = !DILocation(line: 1345, column: 9, scope: !2727)
!2747 = !DILocation(line: 1346, column: 5, scope: !2727)
!2748 = !DILocation(line: 0, scope: !2749)
!2749 = distinct !DILexicalBlock(scope: !2750, file: !2, line: 1348, column: 13)
!2750 = distinct !DILexicalBlock(scope: !2724, file: !2, line: 1346, column: 12)
!2751 = !DILocation(line: 1356, column: 42, scope: !2750)
!2752 = !DILocation(line: 1356, column: 9, scope: !2750)
!2753 = !DILocation(line: 1359, column: 16, scope: !2754)
!2754 = distinct !DILexicalBlock(scope: !2750, file: !2, line: 1359, column: 13)
!2755 = !DILocation(line: 1359, column: 13, scope: !2750)
!2756 = !DILocation(line: 1360, column: 19, scope: !2754)
!2757 = !DILocation(line: 1360, column: 24, scope: !2754)
!2758 = !DILocation(line: 1360, column: 13, scope: !2754)
!2759 = !DILocation(line: 1361, column: 9, scope: !2750)
!2760 = !DILocation(line: 1362, column: 11, scope: !2750)
!2761 = !DILocation(line: 1363, column: 33, scope: !2762)
!2762 = distinct !DILexicalBlock(scope: !2763, file: !2, line: 1363, column: 9)
!2763 = distinct !DILexicalBlock(scope: !2750, file: !2, line: 1363, column: 9)
!2764 = !DILocation(line: 1363, column: 9, scope: !2763)
!2765 = !DILocation(line: 1364, column: 21, scope: !2766)
!2766 = distinct !DILexicalBlock(scope: !2762, file: !2, line: 1363, column: 51)
!2767 = !DILocation(line: 1364, column: 31, scope: !2766)
!2768 = !DILocation(line: 1364, column: 13, scope: !2766)
!2769 = !DILocation(line: 1367, column: 35, scope: !2770)
!2770 = distinct !DILexicalBlock(scope: !2771, file: !2, line: 1367, column: 25)
!2771 = distinct !DILexicalBlock(scope: !2766, file: !2, line: 1364, column: 41)
!2772 = !DILocation(line: 1367, column: 42, scope: !2770)
!2773 = !DILocation(line: 1367, column: 25, scope: !2771)
!2774 = !DILocation(line: 1371, column: 21, scope: !2775)
!2775 = distinct !DILexicalBlock(scope: !2771, file: !2, line: 1371, column: 21)
!2776 = !DILocation(line: 1372, column: 41, scope: !2771)
!2777 = !DILocation(line: 1372, column: 58, scope: !2771)
!2778 = !DILocation(line: 1372, column: 21, scope: !2771)
!2779 = !DILocation(line: 1373, column: 36, scope: !2771)
!2780 = !DILocation(line: 1373, column: 23, scope: !2771)
!2781 = !DILocation(line: 1374, column: 21, scope: !2771)
!2782 = !DILocation(line: 1376, column: 21, scope: !2783)
!2783 = distinct !DILexicalBlock(scope: !2784, file: !2, line: 1376, column: 21)
!2784 = distinct !DILexicalBlock(scope: !2771, file: !2, line: 1376, column: 21)
!2785 = !DILocation(line: 1376, column: 21, scope: !2786)
!2786 = distinct !DILexicalBlock(scope: !2784, file: !2, line: 1376, column: 21)
!2787 = !DILocation(line: 1376, column: 21, scope: !2784)
!2788 = !DILocation(line: 1376, column: 21, scope: !2789)
!2789 = distinct !DILexicalBlock(scope: !2786, file: !2, line: 1376, column: 21)
!2790 = !DILocation(line: 1376, column: 21, scope: !2791)
!2791 = distinct !DILexicalBlock(scope: !2786, file: !2, line: 1376, column: 21)
!2792 = !DILocation(line: 0, scope: !2750)
!2793 = !DILocation(line: 1363, column: 47, scope: !2762)
!2794 = !DILocation(line: 1363, column: 31, scope: !2762)
!2795 = distinct !{!2795, !2764, !2796, !1410}
!2796 = !DILocation(line: 1379, column: 9, scope: !2763)
!2797 = !DILocation(line: 1380, column: 26, scope: !2750)
!2798 = !DILocation(line: 1380, column: 24, scope: !2750)
!2799 = !DILocation(line: 1380, column: 15, scope: !2750)
!2800 = !DILocation(line: 1380, column: 22, scope: !2750)
!2801 = !DILocation(line: 1381, column: 27, scope: !2750)
!2802 = !DILocation(line: 1381, column: 9, scope: !2750)
!2803 = !DILocation(line: 1382, column: 22, scope: !2750)
!2804 = !DILocation(line: 1383, column: 9, scope: !2750)
!2805 = !DILocation(line: 1384, column: 9, scope: !2750)
!2806 = !DILocation(line: 1389, column: 9, scope: !2807)
!2807 = distinct !DILexicalBlock(scope: !2808, file: !2, line: 1388, column: 13)
!2808 = distinct !DILexicalBlock(scope: !2330, file: !2, line: 1388, column: 9)
!2809 = !DILocation(line: 1390, column: 16, scope: !2810)
!2810 = distinct !DILexicalBlock(scope: !2807, file: !2, line: 1390, column: 13)
!2811 = !DILocation(line: 1390, column: 13, scope: !2810)
!2812 = !DILocation(line: 1390, column: 13, scope: !2807)
!2813 = !DILocation(line: 1391, column: 25, scope: !2814)
!2814 = distinct !DILexicalBlock(scope: !2810, file: !2, line: 1390, column: 24)
!2815 = !DILocation(line: 1391, column: 13, scope: !2814)
!2816 = !DILocation(line: 1392, column: 9, scope: !2814)
!2817 = !DILocation(line: 1394, column: 22, scope: !2330)
!2818 = !DILocation(line: 1394, column: 5, scope: !2330)
!2819 = !DILocation(line: 1395, column: 1, scope: !2330)
!2820 = distinct !DISubprogram(name: "process_mset_command", scope: !2, file: !2, line: 1397, type: !2331, scopeLine: 1397, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !2821)
!2821 = !{!2822, !2823, !2824, !2825, !2826, !2827, !2828, !2829, !2830, !2831, !2832, !2833, !2834, !2835, !2836, !2837, !2838, !2841, !2843}
!2822 = !DILocalVariable(name: "c", arg: 1, scope: !2820, file: !2, line: 1397, type: !780)
!2823 = !DILocalVariable(name: "tokens", arg: 2, scope: !2820, file: !2, line: 1397, type: !1544)
!2824 = !DILocalVariable(name: "ntokens", arg: 3, scope: !2820, file: !2, line: 1397, type: !1545)
!2825 = !DILocalVariable(name: "key", scope: !2820, file: !2, line: 1398, type: !579)
!2826 = !DILocalVariable(name: "nkey", scope: !2820, file: !2, line: 1399, type: !747)
!2827 = !DILocalVariable(name: "it", scope: !2820, file: !2, line: 1400, type: !1062)
!2828 = !DILocalVariable(name: "i", scope: !2820, file: !2, line: 1401, type: !598)
!2829 = !DILocalVariable(name: "comm", scope: !2820, file: !2, line: 1402, type: !663)
!2830 = !DILocalVariable(name: "of", scope: !2820, file: !2, line: 1403, type: !2342)
!2831 = !DILocalVariable(name: "errstr", scope: !2820, file: !2, line: 1404, type: !579)
!2832 = !DILocalVariable(name: "hv", scope: !2820, file: !2, line: 1405, type: !635)
!2833 = !DILocalVariable(name: "vlen", scope: !2820, file: !2, line: 1406, type: !598)
!2834 = !DILocalVariable(name: "resp", scope: !2820, file: !2, line: 1408, type: !882)
!2835 = !DILocalVariable(name: "p", scope: !2820, file: !2, line: 1409, type: !579)
!2836 = !DILocalVariable(name: "exptime", scope: !2820, file: !2, line: 1410, type: !595)
!2837 = !DILocalVariable(name: "has_error", scope: !2820, file: !2, line: 1461, type: !790)
!2838 = !DILocalVariable(name: "status", scope: !2839, file: !2, line: 1540, type: !531)
!2839 = distinct !DILexicalBlock(scope: !2840, file: !2, line: 1539, column: 18)
!2840 = distinct !DILexicalBlock(scope: !2820, file: !2, line: 1539, column: 9)
!2841 = !DILocalVariable(name: "myl", scope: !2842, file: !2, line: 1557, type: !641)
!2842 = distinct !DILexicalBlock(scope: !2839, file: !2, line: 1557, column: 9)
!2843 = !DILabel(scope: !2820, name: "error", file: !2, line: 1601)
!2844 = distinct !DIAssignID()
!2845 = !DILocation(line: 0, scope: !2820)
!2846 = distinct !DIAssignID()
!2847 = distinct !DIAssignID()
!2848 = distinct !DIAssignID()
!2849 = !DILocation(line: 1403, column: 5, scope: !2820)
!2850 = !DILocation(line: 1403, column: 24, scope: !2820)
!2851 = distinct !DIAssignID()
!2852 = !DILocation(line: 1404, column: 5, scope: !2820)
!2853 = !DILocation(line: 1404, column: 11, scope: !2820)
!2854 = distinct !DIAssignID()
!2855 = !DILocation(line: 1405, column: 5, scope: !2820)
!2856 = !DILocation(line: 1406, column: 5, scope: !2820)
!2857 = !DILocation(line: 1406, column: 9, scope: !2820)
!2858 = distinct !DIAssignID()
!2859 = !DILocation(line: 1408, column: 24, scope: !2820)
!2860 = !DILocation(line: 1409, column: 21, scope: !2820)
!2861 = !DILocation(line: 1412, column: 5, scope: !2862)
!2862 = distinct !DILexicalBlock(scope: !2863, file: !2, line: 1412, column: 5)
!2863 = distinct !DILexicalBlock(scope: !2820, file: !2, line: 1412, column: 5)
!2864 = !DILocation(line: 1412, column: 5, scope: !2863)
!2865 = !DILocation(line: 1412, column: 5, scope: !2866)
!2866 = distinct !DILexicalBlock(scope: !2862, file: !2, line: 1412, column: 5)
!2867 = !DILocation(line: 1415, column: 9, scope: !2868)
!2868 = distinct !DILexicalBlock(scope: !2820, file: !2, line: 1415, column: 9)
!2869 = !DILocation(line: 1415, column: 27, scope: !2868)
!2870 = !DILocation(line: 1415, column: 34, scope: !2868)
!2871 = !DILocation(line: 1415, column: 9, scope: !2820)
!2872 = !DILocation(line: 1416, column: 9, scope: !2873)
!2873 = distinct !DILexicalBlock(scope: !2868, file: !2, line: 1415, column: 52)
!2874 = !DILocation(line: 1417, column: 9, scope: !2873)
!2875 = !DILocation(line: 1420, column: 17, scope: !2876)
!2876 = distinct !DILexicalBlock(scope: !2820, file: !2, line: 1420, column: 9)
!2877 = !DILocation(line: 1420, column: 9, scope: !2820)
!2878 = !DILocation(line: 1421, column: 9, scope: !2879)
!2879 = distinct !DILexicalBlock(scope: !2876, file: !2, line: 1420, column: 23)
!2880 = !DILocation(line: 1422, column: 9, scope: !2879)
!2881 = !DILocation(line: 1425, column: 17, scope: !2882)
!2882 = distinct !DILexicalBlock(scope: !2820, file: !2, line: 1425, column: 9)
!2883 = !DILocation(line: 1425, column: 9, scope: !2820)
!2884 = !DILocation(line: 1426, column: 9, scope: !2885)
!2885 = distinct !DILexicalBlock(scope: !2882, file: !2, line: 1425, column: 41)
!2886 = !DILocation(line: 1427, column: 9, scope: !2885)
!2887 = !DILocation(line: 1434, column: 22, scope: !2888)
!2888 = distinct !DILexicalBlock(scope: !2820, file: !2, line: 1434, column: 9)
!2889 = !DILocation(line: 1434, column: 44, scope: !2888)
!2890 = !DILocation(line: 1434, column: 10, scope: !2888)
!2891 = !DILocation(line: 1434, column: 9, scope: !2820)
!2892 = !DILocation(line: 1435, column: 9, scope: !2893)
!2893 = distinct !DILexicalBlock(scope: !2888, file: !2, line: 1434, column: 69)
!2894 = !DILocation(line: 1436, column: 9, scope: !2893)
!2895 = !DILocation(line: 1439, column: 9, scope: !2896)
!2896 = distinct !DILexicalBlock(scope: !2820, file: !2, line: 1439, column: 9)
!2897 = !DILocation(line: 1439, column: 18, scope: !2896)
!2898 = !DILocation(line: 1440, column: 9, scope: !2899)
!2899 = distinct !DILexicalBlock(scope: !2896, file: !2, line: 1439, column: 43)
!2900 = !DILocation(line: 1441, column: 9, scope: !2899)
!2901 = !DILocation(line: 1443, column: 10, scope: !2820)
!2902 = distinct !DIAssignID()
!2903 = !DILocation(line: 1448, column: 9, scope: !2904)
!2904 = distinct !DILexicalBlock(scope: !2820, file: !2, line: 1448, column: 9)
!2905 = !DILocation(line: 1448, column: 54, scope: !2904)
!2906 = !DILocation(line: 1448, column: 9, scope: !2820)
!2907 = !DILocation(line: 1452, column: 29, scope: !2820)
!2908 = !DILocation(line: 1453, column: 30, scope: !2820)
!2909 = !DILocation(line: 1456, column: 21, scope: !2820)
!2910 = !DILocation(line: 1456, column: 8, scope: !2820)
!2911 = !DILocation(line: 1456, column: 16, scope: !2820)
!2912 = !DILocation(line: 1458, column: 14, scope: !2820)
!2913 = !DILocation(line: 1458, column: 33, scope: !2820)
!2914 = !DILocation(line: 1458, column: 45, scope: !2820)
!2915 = !DILocation(line: 1458, column: 8, scope: !2820)
!2916 = !DILocation(line: 1458, column: 12, scope: !2820)
!2917 = !DILocation(line: 1459, column: 18, scope: !2820)
!2918 = !DILocation(line: 1462, column: 5, scope: !2919)
!2919 = distinct !DILexicalBlock(scope: !2820, file: !2, line: 1462, column: 5)
!2920 = !DILocation(line: 1463, column: 17, scope: !2921)
!2921 = distinct !DILexicalBlock(scope: !2922, file: !2, line: 1462, column: 47)
!2922 = distinct !DILexicalBlock(scope: !2919, file: !2, line: 1462, column: 5)
!2923 = !DILocation(line: 1463, column: 27, scope: !2921)
!2924 = !DILocation(line: 1463, column: 9, scope: !2921)
!2925 = !DILocation(line: 1466, column: 31, scope: !2926)
!2926 = distinct !DILexicalBlock(scope: !2927, file: !2, line: 1466, column: 21)
!2927 = distinct !DILexicalBlock(scope: !2921, file: !2, line: 1463, column: 37)
!2928 = !DILocation(line: 1466, column: 38, scope: !2926)
!2929 = !DILocation(line: 1466, column: 21, scope: !2927)
!2930 = !DILocation(line: 1467, column: 28, scope: !2931)
!2931 = distinct !DILexicalBlock(scope: !2926, file: !2, line: 1466, column: 65)
!2932 = distinct !DIAssignID()
!2933 = !DILocation(line: 1469, column: 21, scope: !2931)
!2934 = !DILocation(line: 1471, column: 17, scope: !2935)
!2935 = distinct !DILexicalBlock(scope: !2927, file: !2, line: 1471, column: 17)
!2936 = !DILocation(line: 1472, column: 37, scope: !2927)
!2937 = !DILocation(line: 1472, column: 54, scope: !2927)
!2938 = !DILocation(line: 1472, column: 17, scope: !2927)
!2939 = !DILocation(line: 1473, column: 32, scope: !2927)
!2940 = !DILocation(line: 1473, column: 19, scope: !2927)
!2941 = !DILocation(line: 1474, column: 17, scope: !2927)
!2942 = !DILocation(line: 1476, column: 17, scope: !2943)
!2943 = distinct !DILexicalBlock(scope: !2927, file: !2, line: 1476, column: 17)
!2944 = !DILocation(line: 1477, column: 17, scope: !2927)
!2945 = !DILocation(line: 1480, column: 17, scope: !2946)
!2946 = distinct !DILexicalBlock(scope: !2927, file: !2, line: 1480, column: 17)
!2947 = !DILocation(line: 1481, column: 17, scope: !2927)
!2948 = !DILocation(line: 1484, column: 17, scope: !2949)
!2949 = distinct !DILexicalBlock(scope: !2927, file: !2, line: 1484, column: 17)
!2950 = !DILocation(line: 1485, column: 17, scope: !2927)
!2951 = !DILocation(line: 1462, column: 43, scope: !2922)
!2952 = !DILocation(line: 1462, column: 29, scope: !2922)
!2953 = distinct !{!2953, !2918, !2954, !1410}
!2954 = !DILocation(line: 1487, column: 5, scope: !2919)
!2955 = !DILocation(line: 1490, column: 16, scope: !2820)
!2956 = !{!2464, !1213, i64 2}
!2957 = !DILocation(line: 1490, column: 5, scope: !2820)
!2958 = !DILocation(line: 1495, column: 13, scope: !2959)
!2959 = distinct !DILexicalBlock(scope: !2820, file: !2, line: 1490, column: 22)
!2960 = !DILocation(line: 1497, column: 20, scope: !2961)
!2961 = distinct !DILexicalBlock(scope: !2959, file: !2, line: 1497, column: 17)
!2962 = !DILocation(line: 1497, column: 17, scope: !2961)
!2963 = !DILocation(line: 1497, column: 17, scope: !2959)
!2964 = !DILocation(line: 1499, column: 30, scope: !2965)
!2965 = distinct !DILexicalBlock(scope: !2961, file: !2, line: 1497, column: 28)
!2966 = !DILocation(line: 1500, column: 13, scope: !2965)
!2967 = !DILocation(line: 1505, column: 20, scope: !2968)
!2968 = distinct !DILexicalBlock(scope: !2959, file: !2, line: 1505, column: 17)
!2969 = !DILocation(line: 1505, column: 17, scope: !2968)
!2970 = !DILocation(line: 1505, column: 17, scope: !2959)
!2971 = !DILocation(line: 1507, column: 30, scope: !2972)
!2972 = distinct !DILexicalBlock(scope: !2968, file: !2, line: 1505, column: 28)
!2973 = !DILocation(line: 1508, column: 13, scope: !2972)
!2974 = !DILocation(line: 1514, column: 13, scope: !2959)
!2975 = !DILocation(line: 1519, column: 20, scope: !2959)
!2976 = distinct !DIAssignID()
!2977 = !DILocation(line: 1520, column: 13, scope: !2959)
!2978 = !DILocation(line: 1528, column: 12, scope: !2979)
!2979 = distinct !DILexicalBlock(scope: !2820, file: !2, line: 1528, column: 9)
!2980 = !DILocation(line: 1528, column: 9, scope: !2979)
!2981 = !DILocation(line: 1528, column: 20, scope: !2979)
!2982 = !DILocation(line: 1534, column: 9, scope: !2820)
!2983 = !DILocation(line: 1537, column: 35, scope: !2820)
!2984 = !{!2464, !1215, i64 16}
!2985 = !DILocation(line: 1537, column: 58, scope: !2820)
!2986 = !DILocation(line: 1537, column: 10, scope: !2820)
!2987 = !DILocation(line: 1539, column: 12, scope: !2840)
!2988 = !DILocation(line: 1539, column: 9, scope: !2820)
!2989 = !DILocation(line: 1543, column: 37, scope: !2990)
!2990 = distinct !DILexicalBlock(scope: !2839, file: !2, line: 1543, column: 13)
!2991 = !DILocation(line: 1543, column: 51, scope: !2990)
!2992 = !DILocation(line: 1543, column: 15, scope: !2990)
!2993 = !DILocation(line: 0, scope: !2990)
!2994 = distinct !DIAssignID()
!2995 = !DILocation(line: 0, scope: !2839)
!2996 = !DILocation(line: 1557, column: 9, scope: !2842)
!2997 = !{!1316, !1212, i64 6912}
!2998 = !DILocation(line: 0, scope: !2842)
!2999 = !DILocation(line: 1557, column: 9, scope: !3000)
!3000 = distinct !DILexicalBlock(scope: !2842, file: !2, line: 1557, column: 9)
!3001 = !DILocation(line: 1557, column: 9, scope: !3002)
!3002 = distinct !DILexicalBlock(scope: !2842, file: !2, line: 1557, column: 9)
!3003 = !{!3004, !1220, i64 84}
!3004 = !{!"_logger", !1212, i64 0, !1212, i64 8, !1213, i64 16, !1222, i64 56, !1222, i64 64, !1222, i64 72, !1220, i64 80, !1220, i64 82, !1220, i64 84, !1212, i64 88, !1212, i64 96}
!3005 = !DILocation(line: 1562, column: 44, scope: !2839)
!3006 = !DILocation(line: 1562, column: 14, scope: !2839)
!3007 = !DILocation(line: 1563, column: 13, scope: !3008)
!3008 = distinct !DILexicalBlock(scope: !2839, file: !2, line: 1563, column: 13)
!3009 = !DILocation(line: 1563, column: 13, scope: !2839)
!3010 = !DILocation(line: 1564, column: 32, scope: !3011)
!3011 = distinct !DILexicalBlock(scope: !3008, file: !2, line: 1563, column: 17)
!3012 = !DILocation(line: 1564, column: 13, scope: !3011)
!3013 = !DILocation(line: 1565, column: 13, scope: !3014)
!3014 = distinct !DILexicalBlock(scope: !3011, file: !2, line: 1565, column: 13)
!3015 = !{!1316, !1212, i64 6904}
!3016 = !DILocation(line: 1566, column: 13, scope: !3011)
!3017 = !DILocation(line: 1567, column: 9, scope: !3011)
!3018 = !DILocation(line: 1568, column: 21, scope: !2839)
!3019 = !DILocation(line: 1568, column: 9, scope: !2839)
!3020 = !DILocation(line: 1572, column: 5, scope: !3021)
!3021 = distinct !DILexicalBlock(scope: !3022, file: !2, line: 1572, column: 5)
!3022 = distinct !DILexicalBlock(scope: !2820, file: !2, line: 1572, column: 5)
!3023 = !DILocation(line: 1572, column: 5, scope: !3022)
!3024 = !DILocation(line: 1572, column: 5, scope: !3025)
!3025 = distinct !DILexicalBlock(scope: !3021, file: !2, line: 1572, column: 5)
!3026 = !{!2464, !1222, i64 24}
!3027 = !DILocation(line: 1574, column: 8, scope: !2820)
!3028 = !DILocation(line: 1574, column: 13, scope: !2820)
!3029 = !DILocation(line: 1582, column: 16, scope: !2820)
!3030 = !DILocation(line: 1582, column: 8, scope: !2820)
!3031 = !DILocation(line: 1582, column: 14, scope: !2820)
!3032 = !DILocation(line: 1584, column: 22, scope: !2820)
!3033 = !DILocation(line: 1584, column: 8, scope: !2820)
!3034 = !DILocation(line: 1584, column: 16, scope: !2820)
!3035 = !DILocation(line: 1585, column: 8, scope: !2820)
!3036 = !DILocation(line: 1585, column: 12, scope: !2820)
!3037 = !DILocation(line: 1588, column: 12, scope: !3038)
!3038 = distinct !DILexicalBlock(scope: !2820, file: !2, line: 1588, column: 9)
!3039 = !DILocation(line: 1588, column: 9, scope: !3038)
!3040 = !DILocation(line: 1588, column: 9, scope: !2820)
!3041 = !DILocation(line: 1589, column: 22, scope: !3042)
!3042 = distinct !DILexicalBlock(scope: !3038, file: !2, line: 1588, column: 24)
!3043 = !DILocation(line: 1590, column: 5, scope: !3042)
!3044 = !DILocation(line: 1592, column: 9, scope: !3045)
!3045 = distinct !DILexicalBlock(scope: !2820, file: !2, line: 1592, column: 9)
!3046 = !DILocation(line: 1592, column: 22, scope: !3045)
!3047 = !DILocation(line: 1593, column: 12, scope: !3048)
!3048 = distinct !DILexicalBlock(scope: !3045, file: !2, line: 1592, column: 44)
!3049 = !DILocation(line: 1593, column: 22, scope: !3048)
!3050 = !DILocation(line: 1594, column: 5, scope: !3048)
!3051 = !DILocation(line: 1595, column: 22, scope: !2820)
!3052 = !DILocation(line: 1595, column: 20, scope: !2820)
!3053 = !DILocation(line: 1595, column: 11, scope: !2820)
!3054 = !DILocation(line: 1595, column: 18, scope: !2820)
!3055 = !DILocation(line: 1598, column: 8, scope: !2820)
!3056 = !DILocation(line: 1598, column: 17, scope: !2820)
!3057 = !DILocation(line: 1599, column: 5, scope: !2820)
!3058 = !DILocation(line: 1600, column: 5, scope: !2820)
!3059 = !DILocation(line: 1601, column: 1, scope: !2820)
!3060 = !DILocation(line: 1603, column: 17, scope: !2820)
!3061 = !DILocation(line: 1603, column: 8, scope: !2820)
!3062 = !DILocation(line: 1603, column: 15, scope: !2820)
!3063 = !{!1211, !1215, i64 232}
!3064 = !DILocation(line: 1607, column: 22, scope: !2820)
!3065 = !DILocation(line: 1607, column: 5, scope: !2820)
!3066 = !DILocation(line: 1609, column: 5, scope: !2820)
!3067 = !DILocation(line: 1610, column: 1, scope: !2820)
!3068 = distinct !DISubprogram(name: "process_mdelete_command", scope: !2, file: !2, line: 1612, type: !2331, scopeLine: 1612, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !3069)
!3069 = !{!3070, !3071, !3072, !3073, !3074, !3075, !3076, !3077, !3078, !3079, !3080, !3081, !3082, !3087, !3091, !3092}
!3070 = !DILocalVariable(name: "c", arg: 1, scope: !3068, file: !2, line: 1612, type: !780)
!3071 = !DILocalVariable(name: "tokens", arg: 2, scope: !3068, file: !2, line: 1612, type: !1544)
!3072 = !DILocalVariable(name: "ntokens", arg: 3, scope: !3068, file: !2, line: 1612, type: !1545)
!3073 = !DILocalVariable(name: "key", scope: !3068, file: !2, line: 1613, type: !579)
!3074 = !DILocalVariable(name: "nkey", scope: !3068, file: !2, line: 1614, type: !747)
!3075 = !DILocalVariable(name: "it", scope: !3068, file: !2, line: 1615, type: !1062)
!3076 = !DILocalVariable(name: "i", scope: !3068, file: !2, line: 1616, type: !598)
!3077 = !DILocalVariable(name: "hv", scope: !3068, file: !2, line: 1617, type: !635)
!3078 = !DILocalVariable(name: "of", scope: !3068, file: !2, line: 1618, type: !2342)
!3079 = !DILocalVariable(name: "errstr", scope: !3068, file: !2, line: 1619, type: !579)
!3080 = !DILocalVariable(name: "resp", scope: !3068, file: !2, line: 1621, type: !882)
!3081 = !DILocalVariable(name: "p", scope: !3068, file: !2, line: 1623, type: !579)
!3082 = !DILocalVariable(name: "new_it", scope: !3083, file: !2, line: 1685, type: !1062)
!3083 = distinct !DILexicalBlock(scope: !3084, file: !2, line: 1684, column: 28)
!3084 = distinct !DILexicalBlock(scope: !3085, file: !2, line: 1684, column: 13)
!3085 = distinct !DILexicalBlock(scope: !3086, file: !2, line: 1670, column: 13)
!3086 = distinct !DILexicalBlock(scope: !3068, file: !2, line: 1670, column: 9)
!3087 = !DILocalVariable(name: "myl", scope: !3088, file: !2, line: 1725, type: !641)
!3088 = distinct !DILexicalBlock(scope: !3089, file: !2, line: 1725, column: 13)
!3089 = distinct !DILexicalBlock(scope: !3090, file: !2, line: 1720, column: 16)
!3090 = distinct !DILexicalBlock(scope: !3085, file: !2, line: 1706, column: 13)
!3091 = !DILabel(scope: !3068, name: "cleanup", file: !2, line: 1743)
!3092 = !DILabel(scope: !3068, name: "error", file: !2, line: 1755)
!3093 = distinct !DIAssignID()
!3094 = !DILocation(line: 0, scope: !3068)
!3095 = distinct !DIAssignID()
!3096 = distinct !DIAssignID()
!3097 = !DILocation(line: 1617, column: 5, scope: !3068)
!3098 = !DILocation(line: 1617, column: 14, scope: !3068)
!3099 = distinct !DIAssignID()
!3100 = !DILocation(line: 1618, column: 5, scope: !3068)
!3101 = !DILocation(line: 1618, column: 24, scope: !3068)
!3102 = distinct !DIAssignID()
!3103 = !DILocation(line: 1619, column: 5, scope: !3068)
!3104 = !DILocation(line: 1619, column: 11, scope: !3068)
!3105 = distinct !DIAssignID()
!3106 = !DILocation(line: 1621, column: 24, scope: !3068)
!3107 = !DILocation(line: 1623, column: 21, scope: !3068)
!3108 = !DILocation(line: 1623, column: 26, scope: !3068)
!3109 = !DILocation(line: 1625, column: 5, scope: !3110)
!3110 = distinct !DILexicalBlock(scope: !3111, file: !2, line: 1625, column: 5)
!3111 = distinct !DILexicalBlock(scope: !3068, file: !2, line: 1625, column: 5)
!3112 = !DILocation(line: 1625, column: 5, scope: !3111)
!3113 = !DILocation(line: 1625, column: 5, scope: !3114)
!3114 = distinct !DILexicalBlock(scope: !3110, file: !2, line: 1625, column: 5)
!3115 = !DILocation(line: 1628, column: 9, scope: !3116)
!3116 = distinct !DILexicalBlock(scope: !3068, file: !2, line: 1628, column: 9)
!3117 = !DILocation(line: 1628, column: 27, scope: !3116)
!3118 = !DILocation(line: 1628, column: 34, scope: !3116)
!3119 = !DILocation(line: 1628, column: 9, scope: !3068)
!3120 = !DILocation(line: 1629, column: 9, scope: !3121)
!3121 = distinct !DILexicalBlock(scope: !3116, file: !2, line: 1628, column: 52)
!3122 = !DILocation(line: 1630, column: 9, scope: !3121)
!3123 = !DILocation(line: 1633, column: 17, scope: !3124)
!3124 = distinct !DILexicalBlock(scope: !3068, file: !2, line: 1633, column: 9)
!3125 = !DILocation(line: 1633, column: 9, scope: !3068)
!3126 = !DILocation(line: 1634, column: 9, scope: !3127)
!3127 = distinct !DILexicalBlock(scope: !3124, file: !2, line: 1633, column: 41)
!3128 = !DILocation(line: 1635, column: 9, scope: !3127)
!3129 = !DILocation(line: 1641, column: 9, scope: !3130)
!3130 = distinct !DILexicalBlock(scope: !3068, file: !2, line: 1641, column: 9)
!3131 = !DILocation(line: 1641, column: 54, scope: !3130)
!3132 = !DILocation(line: 1641, column: 9, scope: !3068)
!3133 = !DILocation(line: 1642, column: 9, scope: !3134)
!3134 = distinct !DILexicalBlock(scope: !3130, file: !2, line: 1641, column: 60)
!3135 = !DILocation(line: 1643, column: 9, scope: !3134)
!3136 = !DILocation(line: 1646, column: 21, scope: !3068)
!3137 = !DILocation(line: 1646, column: 8, scope: !3068)
!3138 = !DILocation(line: 1646, column: 16, scope: !3068)
!3139 = !DILocation(line: 1648, column: 29, scope: !3068)
!3140 = !DILocation(line: 1649, column: 30, scope: !3068)
!3141 = !DILocation(line: 1651, column: 29, scope: !3142)
!3142 = distinct !DILexicalBlock(scope: !3143, file: !2, line: 1651, column: 5)
!3143 = distinct !DILexicalBlock(scope: !3068, file: !2, line: 1651, column: 5)
!3144 = !DILocation(line: 1651, column: 5, scope: !3143)
!3145 = !DILocation(line: 1652, column: 17, scope: !3146)
!3146 = distinct !DILexicalBlock(scope: !3142, file: !2, line: 1651, column: 47)
!3147 = !DILocation(line: 1652, column: 27, scope: !3146)
!3148 = !DILocation(line: 1652, column: 9, scope: !3146)
!3149 = !DILocation(line: 1655, column: 31, scope: !3150)
!3150 = distinct !DILexicalBlock(scope: !3151, file: !2, line: 1655, column: 21)
!3151 = distinct !DILexicalBlock(scope: !3146, file: !2, line: 1652, column: 37)
!3152 = !DILocation(line: 1655, column: 38, scope: !3150)
!3153 = !DILocation(line: 1655, column: 21, scope: !3151)
!3154 = !DILocation(line: 1659, column: 17, scope: !3155)
!3155 = distinct !DILexicalBlock(scope: !3151, file: !2, line: 1659, column: 17)
!3156 = !DILocation(line: 1660, column: 37, scope: !3151)
!3157 = !DILocation(line: 1660, column: 54, scope: !3151)
!3158 = !DILocation(line: 1660, column: 17, scope: !3151)
!3159 = !DILocation(line: 1661, column: 32, scope: !3151)
!3160 = !DILocation(line: 1661, column: 19, scope: !3151)
!3161 = !DILocation(line: 1662, column: 17, scope: !3151)
!3162 = !DILocation(line: 1664, column: 17, scope: !3163)
!3163 = distinct !DILexicalBlock(scope: !3164, file: !2, line: 1664, column: 17)
!3164 = distinct !DILexicalBlock(scope: !3151, file: !2, line: 1664, column: 17)
!3165 = !DILocation(line: 1664, column: 17, scope: !3166)
!3166 = distinct !DILexicalBlock(scope: !3164, file: !2, line: 1664, column: 17)
!3167 = !DILocation(line: 1664, column: 17, scope: !3164)
!3168 = !DILocation(line: 1664, column: 17, scope: !3169)
!3169 = distinct !DILexicalBlock(scope: !3166, file: !2, line: 1664, column: 17)
!3170 = !DILocation(line: 1664, column: 17, scope: !3171)
!3171 = distinct !DILexicalBlock(scope: !3166, file: !2, line: 1664, column: 17)
!3172 = !DILocation(line: 1651, column: 43, scope: !3142)
!3173 = distinct !{!3173, !3144, !3174, !1410}
!3174 = !DILocation(line: 1667, column: 5, scope: !3143)
!3175 = !DILocation(line: 1623, column: 11, scope: !3068)
!3176 = !DILocation(line: 1669, column: 40, scope: !3068)
!3177 = !DILocation(line: 1669, column: 10, scope: !3068)
!3178 = !DILocation(line: 1670, column: 9, scope: !3086)
!3179 = !DILocation(line: 1670, column: 9, scope: !3068)
!3180 = !DILocation(line: 1674, column: 16, scope: !3181)
!3181 = distinct !DILexicalBlock(scope: !3085, file: !2, line: 1674, column: 13)
!3182 = !DILocation(line: 1674, column: 13, scope: !3181)
!3183 = !DILocation(line: 1674, column: 24, scope: !3181)
!3184 = !DILocation(line: 1674, column: 27, scope: !3181)
!3185 = !DILocation(line: 1674, column: 50, scope: !3181)
!3186 = !DILocation(line: 1674, column: 44, scope: !3181)
!3187 = !DILocation(line: 1674, column: 13, scope: !3085)
!3188 = !DILocation(line: 1675, column: 36, scope: !3189)
!3189 = distinct !DILexicalBlock(scope: !3181, file: !2, line: 1674, column: 62)
!3190 = !DILocation(line: 1675, column: 44, scope: !3189)
!3191 = !DILocation(line: 1675, column: 13, scope: !3189)
!3192 = !DILocation(line: 1676, column: 16, scope: !3189)
!3193 = !DILocation(line: 1676, column: 30, scope: !3189)
!3194 = !DILocation(line: 1676, column: 43, scope: !3189)
!3195 = !{!1316, !1222, i64 440}
!3196 = !DILocation(line: 1677, column: 46, scope: !3189)
!3197 = !DILocation(line: 1677, column: 13, scope: !3189)
!3198 = !DILocation(line: 1680, column: 13, scope: !3189)
!3199 = !DILocation(line: 1684, column: 13, scope: !3084)
!3200 = !DILocation(line: 1684, column: 13, scope: !3085)
!3201 = !DILocation(line: 1685, column: 53, scope: !3083)
!3202 = !DILocation(line: 1685, column: 70, scope: !3083)
!3203 = !DILocation(line: 1685, column: 28, scope: !3083)
!3204 = !DILocation(line: 0, scope: !3083)
!3205 = !DILocation(line: 1686, column: 24, scope: !3206)
!3206 = distinct !DILexicalBlock(scope: !3083, file: !2, line: 1686, column: 17)
!3207 = !DILocation(line: 1686, column: 17, scope: !3083)
!3208 = !DILocation(line: 1687, column: 24, scope: !3209)
!3209 = distinct !DILexicalBlock(scope: !3206, file: !2, line: 1686, column: 33)
!3210 = !DILocation(line: 1687, column: 17, scope: !3209)
!3211 = !DILocation(line: 1688, column: 57, scope: !3212)
!3212 = distinct !DILexicalBlock(scope: !3209, file: !2, line: 1688, column: 21)
!3213 = !DILocation(line: 1688, column: 65, scope: !3212)
!3214 = !DILocation(line: 1689, column: 32, scope: !3212)
!3215 = !DILocation(line: 1689, column: 29, scope: !3212)
!3216 = !DILocation(line: 1689, column: 48, scope: !3212)
!3217 = !DILocation(line: 1689, column: 60, scope: !3212)
!3218 = !DILocation(line: 1689, scope: !3212)
!3219 = !DILocation(line: 1688, column: 21, scope: !3212)
!3220 = !DILocation(line: 1688, column: 21, scope: !3209)
!3221 = !DILocation(line: 1690, column: 21, scope: !3222)
!3222 = distinct !DILexicalBlock(scope: !3212, file: !2, line: 1689, column: 93)
!3223 = !DILocation(line: 1706, column: 16, scope: !3090)
!3224 = !DILocation(line: 1693, column: 21, scope: !3225)
!3225 = distinct !DILexicalBlock(scope: !3212, file: !2, line: 1692, column: 24)
!3226 = !DILocation(line: 1706, column: 13, scope: !3090)
!3227 = !DILocation(line: 1706, column: 13, scope: !3085)
!3228 = !DILocation(line: 1707, column: 17, scope: !3229)
!3229 = distinct !DILexicalBlock(scope: !3230, file: !2, line: 1707, column: 17)
!3230 = distinct !DILexicalBlock(scope: !3090, file: !2, line: 1706, column: 27)
!3231 = !DILocation(line: 1707, column: 17, scope: !3230)
!3232 = !DILocation(line: 1708, column: 34, scope: !3233)
!3233 = distinct !DILexicalBlock(scope: !3229, file: !2, line: 1707, column: 29)
!3234 = !DILocation(line: 1708, column: 21, scope: !3233)
!3235 = !DILocation(line: 1708, column: 29, scope: !3233)
!3236 = !DILocation(line: 1709, column: 13, scope: !3233)
!3237 = !DILocation(line: 1710, column: 17, scope: !3230)
!3238 = !DILocation(line: 1710, column: 26, scope: !3230)
!3239 = !DILocation(line: 1712, column: 26, scope: !3230)
!3240 = !DILocation(line: 1714, column: 13, scope: !3241)
!3241 = distinct !DILexicalBlock(scope: !3242, file: !2, line: 1714, column: 13)
!3242 = distinct !DILexicalBlock(scope: !3230, file: !2, line: 1714, column: 13)
!3243 = !DILocation(line: 1714, column: 13, scope: !3242)
!3244 = !DILocation(line: 1714, column: 13, scope: !3245)
!3245 = distinct !DILexicalBlock(scope: !3241, file: !2, line: 1714, column: 13)
!3246 = !DILocation(line: 1716, column: 20, scope: !3247)
!3247 = distinct !DILexicalBlock(scope: !3230, file: !2, line: 1716, column: 17)
!3248 = !DILocation(line: 1716, column: 17, scope: !3230)
!3249 = !DILocation(line: 1717, column: 23, scope: !3247)
!3250 = !DILocation(line: 1717, column: 28, scope: !3247)
!3251 = !DILocation(line: 1717, column: 17, scope: !3247)
!3252 = !DILocation(line: 1721, column: 36, scope: !3089)
!3253 = !DILocation(line: 1721, column: 44, scope: !3089)
!3254 = !DILocation(line: 1721, column: 13, scope: !3089)
!3255 = !DILocation(line: 1722, column: 16, scope: !3089)
!3256 = !DILocation(line: 1722, column: 30, scope: !3089)
!3257 = !DILocation(line: 1722, column: 41, scope: !3089)
!3258 = !DILocation(line: 1722, column: 57, scope: !3089)
!3259 = !DILocation(line: 1722, column: 68, scope: !3089)
!3260 = !{!1244, !1222, i64 24}
!3261 = !DILocation(line: 1723, column: 46, scope: !3089)
!3262 = !DILocation(line: 1723, column: 13, scope: !3089)
!3263 = !DILocation(line: 0, scope: !3088)
!3264 = !DILocation(line: 1725, column: 13, scope: !3265)
!3265 = distinct !DILexicalBlock(scope: !3088, file: !2, line: 1725, column: 13)
!3266 = !DILocation(line: 1725, column: 13, scope: !3267)
!3267 = distinct !DILexicalBlock(scope: !3088, file: !2, line: 1725, column: 13)
!3268 = !DILocation(line: 1725, column: 13, scope: !3088)
!3269 = !DILocation(line: 1726, column: 21, scope: !3270)
!3270 = distinct !DILexicalBlock(scope: !3089, file: !2, line: 1726, column: 17)
!3271 = !DILocation(line: 1726, column: 18, scope: !3270)
!3272 = !DILocation(line: 1726, column: 17, scope: !3089)
!3273 = !DILocation(line: 1727, column: 36, scope: !3274)
!3274 = distinct !DILexicalBlock(scope: !3270, file: !2, line: 1726, column: 33)
!3275 = !DILocation(line: 1727, column: 17, scope: !3274)
!3276 = !DILocation(line: 1728, column: 17, scope: !3277)
!3277 = distinct !DILexicalBlock(scope: !3274, file: !2, line: 1728, column: 17)
!3278 = !DILocation(line: 1729, column: 13, scope: !3274)
!3279 = !DILocation(line: 1730, column: 20, scope: !3280)
!3280 = distinct !DILexicalBlock(scope: !3089, file: !2, line: 1730, column: 17)
!3281 = !DILocation(line: 1730, column: 17, scope: !3089)
!3282 = !DILocation(line: 1731, column: 23, scope: !3280)
!3283 = !DILocation(line: 1731, column: 28, scope: !3280)
!3284 = !DILocation(line: 1731, column: 17, scope: !3280)
!3285 = !DILocation(line: 1736, column: 32, scope: !3286)
!3286 = distinct !DILexicalBlock(scope: !3086, file: !2, line: 1735, column: 12)
!3287 = !DILocation(line: 1736, column: 40, scope: !3286)
!3288 = !DILocation(line: 1736, column: 9, scope: !3286)
!3289 = !DILocation(line: 1737, column: 12, scope: !3286)
!3290 = !DILocation(line: 1737, column: 26, scope: !3286)
!3291 = !DILocation(line: 1737, column: 39, scope: !3286)
!3292 = !DILocation(line: 1738, column: 42, scope: !3286)
!3293 = !DILocation(line: 1738, column: 9, scope: !3286)
!3294 = !DILocation(line: 1740, column: 9, scope: !3286)
!3295 = !DILocation(line: 1743, column: 1, scope: !3068)
!3296 = !DILocation(line: 1744, column: 9, scope: !3068)
!3297 = !DILocation(line: 0, scope: !3085)
!3298 = !DILocation(line: 1745, column: 9, scope: !3299)
!3299 = distinct !DILexicalBlock(scope: !3300, file: !2, line: 1744, column: 13)
!3300 = distinct !DILexicalBlock(scope: !3068, file: !2, line: 1744, column: 9)
!3301 = !DILocation(line: 1746, column: 5, scope: !3299)
!3302 = !DILocation(line: 1748, column: 17, scope: !3068)
!3303 = !DILocation(line: 1748, column: 5, scope: !3068)
!3304 = !DILocation(line: 1749, column: 22, scope: !3068)
!3305 = !DILocation(line: 1749, column: 20, scope: !3068)
!3306 = !DILocation(line: 1749, column: 11, scope: !3068)
!3307 = !DILocation(line: 1749, column: 18, scope: !3068)
!3308 = !DILocation(line: 1750, column: 23, scope: !3068)
!3309 = !DILocation(line: 1750, column: 5, scope: !3068)
!3310 = !DILocation(line: 1751, column: 18, scope: !3068)
!3311 = !DILocation(line: 1752, column: 5, scope: !3068)
!3312 = !DILocation(line: 1753, column: 5, scope: !3068)
!3313 = !DILocation(line: 1754, column: 5, scope: !3068)
!3314 = distinct !DIAssignID()
!3315 = !DILocation(line: 1755, column: 1, scope: !3068)
!3316 = !DILocation(line: 1758, column: 9, scope: !3317)
!3317 = distinct !DILexicalBlock(scope: !3318, file: !2, line: 1757, column: 13)
!3318 = distinct !DILexicalBlock(scope: !3068, file: !2, line: 1757, column: 9)
!3319 = !DILocation(line: 1759, column: 21, scope: !3317)
!3320 = !DILocation(line: 1759, column: 9, scope: !3317)
!3321 = !DILocation(line: 1760, column: 5, scope: !3317)
!3322 = !DILocation(line: 1761, column: 22, scope: !3068)
!3323 = !DILocation(line: 1761, column: 5, scope: !3068)
!3324 = !DILocation(line: 1762, column: 1, scope: !3068)
!3325 = distinct !DISubprogram(name: "process_marithmetic_command", scope: !2, file: !2, line: 1764, type: !2331, scopeLine: 1764, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !3326)
!3326 = !{!3327, !3328, !3329, !3330, !3331, !3332, !3333, !3334, !3335, !3336, !3337, !3338, !3339, !3340, !3341, !3343, !3344, !3348, !3351}
!3327 = !DILocalVariable(name: "c", arg: 1, scope: !3325, file: !2, line: 1764, type: !780)
!3328 = !DILocalVariable(name: "tokens", arg: 2, scope: !3325, file: !2, line: 1764, type: !1544)
!3329 = !DILocalVariable(name: "ntokens", arg: 3, scope: !3325, file: !2, line: 1764, type: !1545)
!3330 = !DILocalVariable(name: "key", scope: !3325, file: !2, line: 1765, type: !579)
!3331 = !DILocalVariable(name: "nkey", scope: !3325, file: !2, line: 1766, type: !747)
!3332 = !DILocalVariable(name: "i", scope: !3325, file: !2, line: 1767, type: !598)
!3333 = !DILocalVariable(name: "of", scope: !3325, file: !2, line: 1768, type: !2342)
!3334 = !DILocalVariable(name: "errstr", scope: !3325, file: !2, line: 1769, type: !579)
!3335 = !DILocalVariable(name: "resp", scope: !3325, file: !2, line: 1771, type: !882)
!3336 = !DILocalVariable(name: "p", scope: !3325, file: !2, line: 1773, type: !579)
!3337 = !DILocalVariable(name: "incr", scope: !3325, file: !2, line: 1778, type: !790)
!3338 = !DILocalVariable(name: "locked", scope: !3325, file: !2, line: 1779, type: !790)
!3339 = !DILocalVariable(name: "hv", scope: !3325, file: !2, line: 1780, type: !635)
!3340 = !DILocalVariable(name: "it", scope: !3325, file: !2, line: 1781, type: !1062)
!3341 = !DILocalVariable(name: "tmpbuf", scope: !3325, file: !2, line: 1831, type: !3342)
!3342 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 192, elements: !1153)
!3343 = !DILocalVariable(name: "item_created", scope: !3325, file: !2, line: 1835, type: !790)
!3344 = !DILocalVariable(name: "vlen", scope: !3345, file: !2, line: 1858, type: !598)
!3345 = distinct !DILexicalBlock(scope: !3346, file: !2, line: 1856, column: 24)
!3346 = distinct !DILexicalBlock(scope: !3347, file: !2, line: 1856, column: 13)
!3347 = distinct !DILexicalBlock(scope: !3325, file: !2, line: 1836, column: 97)
!3348 = !DILocalVariable(name: "vlen", scope: !3349, file: !2, line: 1899, type: !747)
!3349 = distinct !DILexicalBlock(scope: !3350, file: !2, line: 1898, column: 13)
!3350 = distinct !DILexicalBlock(scope: !3325, file: !2, line: 1898, column: 9)
!3351 = !DILabel(scope: !3325, name: "error", file: !2, line: 1986)
!3352 = distinct !DIAssignID()
!3353 = !DILocation(line: 0, scope: !3325)
!3354 = distinct !DIAssignID()
!3355 = distinct !DIAssignID()
!3356 = distinct !DIAssignID()
!3357 = !DILocation(line: 1768, column: 5, scope: !3325)
!3358 = !DILocation(line: 1768, column: 24, scope: !3325)
!3359 = distinct !DIAssignID()
!3360 = distinct !DIAssignID()
!3361 = !DILocation(line: 1769, column: 5, scope: !3325)
!3362 = !DILocation(line: 1769, column: 11, scope: !3325)
!3363 = distinct !DIAssignID()
!3364 = !DILocation(line: 1771, column: 24, scope: !3325)
!3365 = !DILocation(line: 1773, column: 21, scope: !3325)
!3366 = !DILocation(line: 1776, column: 8, scope: !3325)
!3367 = !DILocation(line: 1776, column: 14, scope: !3325)
!3368 = !{!2464, !1222, i64 40}
!3369 = distinct !DIAssignID()
!3370 = !DILocation(line: 1777, column: 8, scope: !3325)
!3371 = !DILocation(line: 1777, column: 16, scope: !3325)
!3372 = !{!2464, !1222, i64 48}
!3373 = distinct !DIAssignID()
!3374 = !DILocation(line: 1781, column: 5, scope: !3325)
!3375 = !DILocation(line: 1781, column: 11, scope: !3325)
!3376 = distinct !DIAssignID()
!3377 = !DILocation(line: 1783, column: 5, scope: !3378)
!3378 = distinct !DILexicalBlock(scope: !3379, file: !2, line: 1783, column: 5)
!3379 = distinct !DILexicalBlock(scope: !3325, file: !2, line: 1783, column: 5)
!3380 = !DILocation(line: 1783, column: 5, scope: !3379)
!3381 = !DILocation(line: 1783, column: 5, scope: !3382)
!3382 = distinct !DILexicalBlock(scope: !3378, file: !2, line: 1783, column: 5)
!3383 = !DILocation(line: 1786, column: 9, scope: !3384)
!3384 = distinct !DILexicalBlock(scope: !3325, file: !2, line: 1786, column: 9)
!3385 = !DILocation(line: 1786, column: 27, scope: !3384)
!3386 = !DILocation(line: 1786, column: 34, scope: !3384)
!3387 = !DILocation(line: 1786, column: 9, scope: !3325)
!3388 = !DILocation(line: 1787, column: 9, scope: !3389)
!3389 = distinct !DILexicalBlock(scope: !3384, file: !2, line: 1786, column: 52)
!3390 = !DILocation(line: 1788, column: 9, scope: !3389)
!3391 = !DILocation(line: 1791, column: 17, scope: !3392)
!3392 = distinct !DILexicalBlock(scope: !3325, file: !2, line: 1791, column: 9)
!3393 = !DILocation(line: 1791, column: 9, scope: !3325)
!3394 = !DILocation(line: 1792, column: 9, scope: !3395)
!3395 = distinct !DILexicalBlock(scope: !3392, file: !2, line: 1791, column: 41)
!3396 = !DILocation(line: 1793, column: 9, scope: !3395)
!3397 = !DILocation(line: 1798, column: 9, scope: !3398)
!3398 = distinct !DILexicalBlock(scope: !3325, file: !2, line: 1798, column: 9)
!3399 = !DILocation(line: 1798, column: 54, scope: !3398)
!3400 = !DILocation(line: 1798, column: 9, scope: !3325)
!3401 = !DILocation(line: 1799, column: 9, scope: !3402)
!3402 = distinct !DILexicalBlock(scope: !3398, file: !2, line: 1798, column: 60)
!3403 = !DILocation(line: 1800, column: 9, scope: !3402)
!3404 = !DILocation(line: 1803, column: 21, scope: !3325)
!3405 = !DILocation(line: 1803, column: 8, scope: !3325)
!3406 = !DILocation(line: 1803, column: 16, scope: !3325)
!3407 = !DILocation(line: 1805, column: 29, scope: !3325)
!3408 = !DILocation(line: 1806, column: 30, scope: !3325)
!3409 = !DILocation(line: 1809, column: 16, scope: !3325)
!3410 = !DILocation(line: 1809, column: 5, scope: !3325)
!3411 = !DILocation(line: 1819, column: 13, scope: !3412)
!3412 = distinct !DILexicalBlock(scope: !3325, file: !2, line: 1809, column: 22)
!3413 = !DILocation(line: 1828, column: 10, scope: !3325)
!3414 = !DILocation(line: 1829, column: 5, scope: !3325)
!3415 = !DILocation(line: 1836, column: 28, scope: !3325)
!3416 = !DILocation(line: 1836, column: 56, scope: !3325)
!3417 = !DILocation(line: 1836, column: 75, scope: !3325)
!3418 = !DILocation(line: 1836, column: 12, scope: !3325)
!3419 = !DILocation(line: 1836, column: 5, scope: !3325)
!3420 = !DILocation(line: 1838, column: 16, scope: !3421)
!3421 = distinct !DILexicalBlock(scope: !3347, file: !2, line: 1838, column: 13)
!3422 = !DILocation(line: 1838, column: 13, scope: !3347)
!3423 = !DILocation(line: 1839, column: 19, scope: !3421)
!3424 = !DILocation(line: 1839, column: 24, scope: !3421)
!3425 = !DILocation(line: 1839, column: 13, scope: !3421)
!3426 = !DILocation(line: 1841, column: 16, scope: !3427)
!3427 = distinct !DILexicalBlock(scope: !3347, file: !2, line: 1841, column: 13)
!3428 = !DILocation(line: 1841, column: 13, scope: !3427)
!3429 = !DILocation(line: 1841, column: 13, scope: !3347)
!3430 = !DILocation(line: 1844, column: 13, scope: !3431)
!3431 = distinct !DILexicalBlock(scope: !3432, file: !2, line: 1844, column: 13)
!3432 = distinct !DILexicalBlock(scope: !3433, file: !2, line: 1844, column: 13)
!3433 = distinct !DILexicalBlock(scope: !3427, file: !2, line: 1841, column: 28)
!3434 = !DILocation(line: 1844, column: 13, scope: !3432)
!3435 = !DILocation(line: 1844, column: 13, scope: !3436)
!3436 = distinct !DILexicalBlock(scope: !3431, file: !2, line: 1844, column: 13)
!3437 = !DILocation(line: 1848, column: 16, scope: !3347)
!3438 = distinct !DIAssignID()
!3439 = !DILocation(line: 1849, column: 9, scope: !3347)
!3440 = !DILocation(line: 1852, column: 16, scope: !3347)
!3441 = distinct !DIAssignID()
!3442 = !DILocation(line: 1853, column: 9, scope: !3347)
!3443 = !DILocation(line: 1856, column: 16, scope: !3346)
!3444 = !DILocation(line: 1856, column: 13, scope: !3346)
!3445 = !DILocation(line: 1856, column: 13, scope: !3347)
!3446 = !DILocation(line: 1857, column: 25, scope: !3345)
!3447 = !DILocation(line: 1857, column: 13, scope: !3345)
!3448 = !DILocation(line: 1858, column: 24, scope: !3345)
!3449 = !DILocation(line: 0, scope: !3345)
!3450 = !DILocation(line: 1860, column: 50, scope: !3345)
!3451 = !DILocation(line: 1860, column: 18, scope: !3345)
!3452 = !DILocation(line: 1860, column: 16, scope: !3345)
!3453 = distinct !DIAssignID()
!3454 = !DILocation(line: 1861, column: 20, scope: !3455)
!3455 = distinct !DILexicalBlock(scope: !3345, file: !2, line: 1861, column: 17)
!3456 = !DILocation(line: 1861, column: 17, scope: !3345)
!3457 = !DILocation(line: 1862, column: 24, scope: !3458)
!3458 = distinct !DILexicalBlock(scope: !3455, file: !2, line: 1861, column: 29)
!3459 = !DILocation(line: 1862, column: 47, scope: !3458)
!3460 = !DILocation(line: 1862, column: 17, scope: !3458)
!3461 = !DILocation(line: 1863, column: 24, scope: !3458)
!3462 = !DILocation(line: 1863, column: 38, scope: !3458)
!3463 = !DILocation(line: 1863, column: 17, scope: !3458)
!3464 = !DILocation(line: 1864, column: 35, scope: !3465)
!3465 = distinct !DILexicalBlock(scope: !3458, file: !2, line: 1864, column: 21)
!3466 = !DILocation(line: 1864, column: 53, scope: !3465)
!3467 = !DILocation(line: 1865, column: 32, scope: !3465)
!3468 = !DILocation(line: 1865, column: 29, scope: !3465)
!3469 = !DILocation(line: 1865, column: 48, scope: !3465)
!3470 = !DILocation(line: 1865, column: 60, scope: !3465)
!3471 = !DILocation(line: 1864, column: 21, scope: !3465)
!3472 = !DILocation(line: 1864, column: 21, scope: !3458)
!3473 = !DILocation(line: 1869, column: 21, scope: !3474)
!3474 = distinct !DILexicalBlock(scope: !3465, file: !2, line: 1867, column: 24)
!3475 = !DILocation(line: 1872, column: 24, scope: !3476)
!3476 = distinct !DILexicalBlock(scope: !3455, file: !2, line: 1871, column: 20)
!3477 = distinct !DIAssignID()
!3478 = !DILocation(line: 1986, column: 1, scope: !3325)
!3479 = !DILocation(line: 1989, column: 9, scope: !3325)
!3480 = !DILocation(line: 1876, column: 36, scope: !3481)
!3481 = distinct !DILexicalBlock(scope: !3346, file: !2, line: 1875, column: 16)
!3482 = !DILocation(line: 1876, column: 44, scope: !3481)
!3483 = !DILocation(line: 1876, column: 13, scope: !3481)
!3484 = !DILocation(line: 0, scope: !3485)
!3485 = distinct !DILexicalBlock(scope: !3481, file: !2, line: 1877, column: 17)
!3486 = !DILocation(line: 1882, column: 46, scope: !3481)
!3487 = !DILocation(line: 1882, column: 13, scope: !3481)
!3488 = !DILocation(line: 1884, column: 13, scope: !3481)
!3489 = !DILocation(line: 1885, column: 15, scope: !3481)
!3490 = !DILocation(line: 1890, column: 9, scope: !3347)
!3491 = !DILocation(line: 1891, column: 11, scope: !3347)
!3492 = !DILocation(line: 1892, column: 9, scope: !3347)
!3493 = !DILocation(line: 1898, column: 9, scope: !3350)
!3494 = !DILocation(line: 1898, column: 9, scope: !3325)
!3495 = !DILocation(line: 1900, column: 16, scope: !3496)
!3496 = distinct !DILexicalBlock(scope: !3349, file: !2, line: 1900, column: 13)
!3497 = !DILocation(line: 1959, column: 33, scope: !3498)
!3498 = distinct !DILexicalBlock(scope: !3499, file: !2, line: 1959, column: 9)
!3499 = distinct !DILexicalBlock(scope: !3500, file: !2, line: 1959, column: 9)
!3500 = distinct !DILexicalBlock(scope: !3350, file: !2, line: 1957, column: 12)
!3501 = !DILocation(line: 1959, column: 9, scope: !3499)
!3502 = !DILocation(line: 1899, column: 23, scope: !3349)
!3503 = !DILocation(line: 0, scope: !3349)
!3504 = !DILocation(line: 1900, column: 13, scope: !3496)
!3505 = !DILocation(line: 1900, column: 13, scope: !3349)
!3506 = !DILocation(line: 1901, column: 13, scope: !3507)
!3507 = distinct !DILexicalBlock(scope: !3496, file: !2, line: 1900, column: 23)
!3508 = !DILocation(line: 1902, column: 26, scope: !3507)
!3509 = !DILocation(line: 1902, column: 33, scope: !3507)
!3510 = !DILocation(line: 1902, column: 17, scope: !3507)
!3511 = !DILocation(line: 1903, column: 9, scope: !3507)
!3512 = !DILocation(line: 1904, column: 13, scope: !3513)
!3513 = distinct !DILexicalBlock(scope: !3496, file: !2, line: 1903, column: 16)
!3514 = !DILocation(line: 1905, column: 15, scope: !3513)
!3515 = !DILocation(line: 0, scope: !3496)
!3516 = !DILocation(line: 1908, column: 33, scope: !3517)
!3517 = distinct !DILexicalBlock(scope: !3518, file: !2, line: 1908, column: 9)
!3518 = distinct !DILexicalBlock(scope: !3349, file: !2, line: 1908, column: 9)
!3519 = !DILocation(line: 1908, column: 9, scope: !3518)
!3520 = !DILocation(line: 1909, column: 21, scope: !3521)
!3521 = distinct !DILexicalBlock(scope: !3517, file: !2, line: 1908, column: 51)
!3522 = !DILocation(line: 1909, column: 31, scope: !3521)
!3523 = !DILocation(line: 1909, column: 13, scope: !3521)
!3524 = !DILocation(line: 1911, column: 21, scope: !3525)
!3525 = distinct !DILexicalBlock(scope: !3526, file: !2, line: 1911, column: 21)
!3526 = distinct !DILexicalBlock(scope: !3521, file: !2, line: 1909, column: 41)
!3527 = !DILocation(line: 1912, column: 34, scope: !3526)
!3528 = !DILocation(line: 1912, column: 25, scope: !3526)
!3529 = !DILocation(line: 1913, column: 21, scope: !3526)
!3530 = !DILocation(line: 1915, column: 21, scope: !3531)
!3531 = distinct !DILexicalBlock(scope: !3526, file: !2, line: 1915, column: 21)
!3532 = !DILocation(line: 1916, column: 25, scope: !3533)
!3533 = distinct !DILexicalBlock(scope: !3526, file: !2, line: 1916, column: 25)
!3534 = !DILocation(line: 1916, column: 29, scope: !3533)
!3535 = !DILocation(line: 1916, column: 37, scope: !3533)
!3536 = !DILocation(line: 1916, column: 25, scope: !3526)
!3537 = !DILocation(line: 1917, column: 28, scope: !3538)
!3538 = distinct !DILexicalBlock(scope: !3533, file: !2, line: 1916, column: 43)
!3539 = !DILocation(line: 1918, column: 28, scope: !3538)
!3540 = !DILocation(line: 1918, column: 32, scope: !3538)
!3541 = !DILocation(line: 1919, column: 27, scope: !3538)
!3542 = !DILocation(line: 1920, column: 21, scope: !3538)
!3543 = !DILocation(line: 1921, column: 52, scope: !3544)
!3544 = distinct !DILexicalBlock(scope: !3533, file: !2, line: 1920, column: 28)
!3545 = !DILocation(line: 1921, column: 50, scope: !3544)
!3546 = !DILocation(line: 1921, column: 29, scope: !3544)
!3547 = !DILocation(line: 1925, column: 38, scope: !3526)
!3548 = !DILocation(line: 1925, column: 21, scope: !3526)
!3549 = !DILocation(line: 1925, column: 25, scope: !3526)
!3550 = !DILocation(line: 1925, column: 33, scope: !3526)
!3551 = !DILocation(line: 1926, column: 21, scope: !3526)
!3552 = !DILocation(line: 1928, column: 25, scope: !3526)
!3553 = !DILocation(line: 1929, column: 42, scope: !3554)
!3554 = distinct !DILexicalBlock(scope: !3555, file: !2, line: 1928, column: 39)
!3555 = distinct !DILexicalBlock(scope: !3526, file: !2, line: 1928, column: 25)
!3556 = !DILocation(line: 1929, column: 25, scope: !3554)
!3557 = !DILocation(line: 1929, column: 29, scope: !3554)
!3558 = !DILocation(line: 1929, column: 37, scope: !3554)
!3559 = !DILocation(line: 1930, column: 21, scope: !3554)
!3560 = !DILocation(line: 1934, column: 35, scope: !3561)
!3561 = distinct !DILexicalBlock(scope: !3526, file: !2, line: 1934, column: 25)
!3562 = !DILocation(line: 1934, column: 42, scope: !3561)
!3563 = !DILocation(line: 1934, column: 25, scope: !3526)
!3564 = !DILocation(line: 1938, column: 21, scope: !3565)
!3565 = distinct !DILexicalBlock(scope: !3526, file: !2, line: 1938, column: 21)
!3566 = !DILocation(line: 1939, column: 41, scope: !3526)
!3567 = !DILocation(line: 1939, column: 58, scope: !3526)
!3568 = !DILocation(line: 1939, column: 21, scope: !3526)
!3569 = !DILocation(line: 1940, column: 36, scope: !3526)
!3570 = !DILocation(line: 1940, column: 23, scope: !3526)
!3571 = !DILocation(line: 1941, column: 21, scope: !3526)
!3572 = !DILocation(line: 1943, column: 21, scope: !3573)
!3573 = distinct !DILexicalBlock(scope: !3574, file: !2, line: 1943, column: 21)
!3574 = distinct !DILexicalBlock(scope: !3526, file: !2, line: 1943, column: 21)
!3575 = !DILocation(line: 1943, column: 21, scope: !3576)
!3576 = distinct !DILexicalBlock(scope: !3574, file: !2, line: 1943, column: 21)
!3577 = !DILocation(line: 1943, column: 21, scope: !3574)
!3578 = !DILocation(line: 1943, column: 21, scope: !3579)
!3579 = distinct !DILexicalBlock(scope: !3576, file: !2, line: 1943, column: 21)
!3580 = !DILocation(line: 1943, column: 21, scope: !3581)
!3581 = distinct !DILexicalBlock(scope: !3576, file: !2, line: 1943, column: 21)
!3582 = !DILocation(line: 1908, column: 47, scope: !3517)
!3583 = distinct !{!3583, !3519, !3584, !1410}
!3584 = !DILocation(line: 1946, column: 9, scope: !3518)
!3585 = !DILocation(line: 1902, column: 15, scope: !3507)
!3586 = !DILocation(line: 1948, column: 16, scope: !3587)
!3587 = distinct !DILexicalBlock(scope: !3349, file: !2, line: 1948, column: 13)
!3588 = !DILocation(line: 1948, column: 13, scope: !3587)
!3589 = !DILocation(line: 1948, column: 13, scope: !3349)
!3590 = !DILocation(line: 1949, column: 16, scope: !3591)
!3591 = distinct !DILexicalBlock(scope: !3587, file: !2, line: 1948, column: 23)
!3592 = !DILocation(line: 1950, column: 16, scope: !3591)
!3593 = !DILocation(line: 1950, column: 20, scope: !3591)
!3594 = !DILocation(line: 1951, column: 15, scope: !3591)
!3595 = !DILocation(line: 1952, column: 13, scope: !3591)
!3596 = !DILocation(line: 1953, column: 15, scope: !3591)
!3597 = !DILocation(line: 1954, column: 9, scope: !3591)
!3598 = !DILocation(line: 1956, column: 24, scope: !3349)
!3599 = !DILocation(line: 1956, column: 9, scope: !3349)
!3600 = !DILocation(line: 1935, column: 32, scope: !3601)
!3601 = distinct !DILexicalBlock(scope: !3561, file: !2, line: 1934, column: 69)
!3602 = distinct !DIAssignID()
!3603 = !DILocation(line: 1960, column: 21, scope: !3604)
!3604 = distinct !DILexicalBlock(scope: !3498, file: !2, line: 1959, column: 51)
!3605 = !DILocation(line: 1960, column: 31, scope: !3604)
!3606 = !DILocation(line: 1960, column: 13, scope: !3604)
!3607 = !DILocation(line: 1963, column: 35, scope: !3608)
!3608 = distinct !DILexicalBlock(scope: !3609, file: !2, line: 1963, column: 25)
!3609 = distinct !DILexicalBlock(scope: !3604, file: !2, line: 1960, column: 41)
!3610 = !DILocation(line: 1963, column: 42, scope: !3608)
!3611 = !DILocation(line: 1963, column: 25, scope: !3609)
!3612 = !DILocation(line: 1964, column: 32, scope: !3613)
!3613 = distinct !DILexicalBlock(scope: !3608, file: !2, line: 1963, column: 69)
!3614 = distinct !DIAssignID()
!3615 = !DILocation(line: 1965, column: 25, scope: !3613)
!3616 = !DILocation(line: 1967, column: 21, scope: !3617)
!3617 = distinct !DILexicalBlock(scope: !3609, file: !2, line: 1967, column: 21)
!3618 = !DILocation(line: 1968, column: 41, scope: !3609)
!3619 = !DILocation(line: 1968, column: 58, scope: !3609)
!3620 = !DILocation(line: 1968, column: 21, scope: !3609)
!3621 = !DILocation(line: 1969, column: 36, scope: !3609)
!3622 = !DILocation(line: 1969, column: 23, scope: !3609)
!3623 = !DILocation(line: 1970, column: 21, scope: !3609)
!3624 = !DILocation(line: 1972, column: 21, scope: !3625)
!3625 = distinct !DILexicalBlock(scope: !3626, file: !2, line: 1972, column: 21)
!3626 = distinct !DILexicalBlock(scope: !3609, file: !2, line: 1972, column: 21)
!3627 = !DILocation(line: 1972, column: 21, scope: !3628)
!3628 = distinct !DILexicalBlock(scope: !3626, file: !2, line: 1972, column: 21)
!3629 = !DILocation(line: 1972, column: 21, scope: !3626)
!3630 = !DILocation(line: 1972, column: 21, scope: !3631)
!3631 = distinct !DILexicalBlock(scope: !3628, file: !2, line: 1972, column: 21)
!3632 = !DILocation(line: 1972, column: 21, scope: !3633)
!3633 = distinct !DILexicalBlock(scope: !3628, file: !2, line: 1972, column: 21)
!3634 = !DILocation(line: 1959, column: 47, scope: !3498)
!3635 = distinct !{!3635, !3501, !3636, !1410}
!3636 = !DILocation(line: 1975, column: 9, scope: !3499)
!3637 = !DILocation(line: 1978, column: 5, scope: !3325)
!3638 = !DILocation(line: 1980, column: 22, scope: !3325)
!3639 = !DILocation(line: 1980, column: 20, scope: !3325)
!3640 = !DILocation(line: 1980, column: 11, scope: !3325)
!3641 = !DILocation(line: 1980, column: 18, scope: !3325)
!3642 = !DILocation(line: 1981, column: 23, scope: !3325)
!3643 = !DILocation(line: 1981, column: 5, scope: !3325)
!3644 = !DILocation(line: 1982, column: 18, scope: !3325)
!3645 = !DILocation(line: 1983, column: 5, scope: !3325)
!3646 = !DILocation(line: 1984, column: 5, scope: !3325)
!3647 = !DILocation(line: 1985, column: 5, scope: !3325)
!3648 = !DILocation(line: 1987, column: 9, scope: !3649)
!3649 = distinct !DILexicalBlock(scope: !3325, file: !2, line: 1987, column: 9)
!3650 = !DILocation(line: 1987, column: 12, scope: !3649)
!3651 = !DILocation(line: 1987, column: 9, scope: !3325)
!3652 = !DILocation(line: 1821, column: 20, scope: !3412)
!3653 = distinct !DIAssignID()
!3654 = !DILocation(line: 1988, column: 9, scope: !3649)
!3655 = !DILocation(line: 1990, column: 9, scope: !3656)
!3656 = distinct !DILexicalBlock(scope: !3325, file: !2, line: 1989, column: 9)
!3657 = !DILocation(line: 1991, column: 22, scope: !3325)
!3658 = !DILocation(line: 1991, column: 5, scope: !3325)
!3659 = !DILocation(line: 1992, column: 1, scope: !3325)
!3660 = distinct !DISubprogram(name: "process_meta_command", scope: !2, file: !2, line: 840, type: !2331, scopeLine: 840, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !3661)
!3661 = !{!3662, !3663, !3664, !3665, !3666, !3667, !3670, !3671, !3672, !3675, !3676}
!3662 = !DILocalVariable(name: "c", arg: 1, scope: !3660, file: !2, line: 840, type: !780)
!3663 = !DILocalVariable(name: "tokens", arg: 2, scope: !3660, file: !2, line: 840, type: !1544)
!3664 = !DILocalVariable(name: "ntokens", arg: 3, scope: !3660, file: !2, line: 840, type: !1545)
!3665 = !DILocalVariable(name: "key", scope: !3660, file: !2, line: 848, type: !579)
!3666 = !DILocalVariable(name: "nkey", scope: !3660, file: !2, line: 849, type: !747)
!3667 = !DILocalVariable(name: "ret", scope: !3668, file: !2, line: 852, type: !747)
!3668 = distinct !DILexicalBlock(scope: !3669, file: !2, line: 851, column: 77)
!3669 = distinct !DILexicalBlock(scope: !3660, file: !2, line: 851, column: 9)
!3670 = !DILocalVariable(name: "overflow", scope: !3660, file: !2, line: 862, type: !790)
!3671 = !DILocalVariable(name: "it", scope: !3660, file: !2, line: 863, type: !1062)
!3672 = !DILocalVariable(name: "resp", scope: !3673, file: !2, line: 865, type: !882)
!3673 = distinct !DILexicalBlock(scope: !3674, file: !2, line: 864, column: 13)
!3674 = distinct !DILexicalBlock(scope: !3660, file: !2, line: 864, column: 9)
!3675 = !DILocalVariable(name: "total", scope: !3673, file: !2, line: 866, type: !747)
!3676 = !DILocalVariable(name: "ret", scope: !3673, file: !2, line: 867, type: !747)
!3677 = distinct !DIAssignID()
!3678 = !DILocation(line: 0, scope: !3660)
!3679 = !DILocation(line: 843, column: 17, scope: !3680)
!3680 = distinct !DILexicalBlock(scope: !3660, file: !2, line: 843, column: 9)
!3681 = !DILocation(line: 843, column: 21, scope: !3680)
!3682 = !DILocation(line: 843, column: 42, scope: !3680)
!3683 = !DILocation(line: 843, column: 49, scope: !3680)
!3684 = !DILocation(line: 843, column: 9, scope: !3660)
!3685 = !DILocation(line: 844, column: 9, scope: !3686)
!3686 = distinct !DILexicalBlock(scope: !3680, file: !2, line: 843, column: 67)
!3687 = !DILocation(line: 845, column: 9, scope: !3686)
!3688 = !DILocation(line: 843, column: 24, scope: !3680)
!3689 = !DILocation(line: 848, column: 35, scope: !3660)
!3690 = !DILocation(line: 851, column: 17, scope: !3669)
!3691 = !DILocation(line: 851, column: 22, scope: !3669)
!3692 = !DILocation(line: 851, column: 35, scope: !3669)
!3693 = !DILocation(line: 851, column: 42, scope: !3669)
!3694 = !DILocation(line: 851, column: 47, scope: !3669)
!3695 = !DILocation(line: 851, column: 25, scope: !3669)
!3696 = !DILocation(line: 851, column: 60, scope: !3669)
!3697 = !DILocation(line: 851, column: 50, scope: !3669)
!3698 = !DILocation(line: 851, column: 69, scope: !3669)
!3699 = !DILocation(line: 851, column: 9, scope: !3660)
!3700 = !DILocation(line: 852, column: 22, scope: !3668)
!3701 = !DILocation(line: 0, scope: !3668)
!3702 = !DILocation(line: 854, column: 17, scope: !3703)
!3703 = distinct !DILexicalBlock(scope: !3668, file: !2, line: 854, column: 13)
!3704 = !DILocation(line: 854, column: 13, scope: !3668)
!3705 = !DILocation(line: 856, column: 13, scope: !3706)
!3706 = distinct !DILexicalBlock(scope: !3703, file: !2, line: 854, column: 23)
!3707 = !DILocation(line: 849, column: 12, scope: !3660)
!3708 = !DILocation(line: 862, column: 5, scope: !3660)
!3709 = !DILocation(line: 863, column: 42, scope: !3660)
!3710 = !DILocation(line: 863, column: 16, scope: !3660)
!3711 = !DILocation(line: 864, column: 9, scope: !3674)
!3712 = !DILocation(line: 864, column: 9, scope: !3660)
!3713 = !DILocation(line: 865, column: 28, scope: !3673)
!3714 = !DILocation(line: 0, scope: !3673)
!3715 = !DILocation(line: 869, column: 22, scope: !3673)
!3716 = !DILocation(line: 869, column: 9, scope: !3673)
!3717 = !DILocation(line: 871, column: 17, scope: !3718)
!3718 = distinct !DILexicalBlock(scope: !3673, file: !2, line: 871, column: 13)
!3719 = !DILocation(line: 871, column: 13, scope: !3718)
!3720 = !DILocation(line: 871, column: 26, scope: !3718)
!3721 = !DILocation(line: 871, column: 13, scope: !3673)
!3722 = !DILocation(line: 875, column: 54, scope: !3723)
!3723 = distinct !DILexicalBlock(scope: !3718, file: !2, line: 871, column: 45)
!3724 = !DILocation(line: 875, column: 72, scope: !3723)
!3725 = !DILocation(line: 875, column: 68, scope: !3723)
!3726 = !DILocation(line: 875, column: 106, scope: !3723)
!3727 = !DILocation(line: 875, column: 22, scope: !3723)
!3728 = !DILocation(line: 876, column: 9, scope: !3723)
!3729 = !DILocation(line: 877, column: 31, scope: !3730)
!3730 = distinct !DILexicalBlock(scope: !3718, file: !2, line: 876, column: 16)
!3731 = !DILocation(line: 877, column: 40, scope: !3730)
!3732 = !DILocation(line: 877, column: 58, scope: !3730)
!3733 = !DILocation(line: 877, column: 54, scope: !3730)
!3734 = !DILocation(line: 877, column: 13, scope: !3730)
!3735 = !DILocation(line: 878, column: 26, scope: !3730)
!3736 = !DILocation(line: 878, column: 22, scope: !3730)
!3737 = !DILocation(line: 0, scope: !3718)
!3738 = !DILocation(line: 880, column: 9, scope: !3673)
!3739 = !DILocation(line: 880, column: 27, scope: !3673)
!3740 = !DILocation(line: 881, column: 14, scope: !3673)
!3741 = !DILocation(line: 883, column: 35, scope: !3673)
!3742 = !DILocation(line: 883, column: 69, scope: !3673)
!3743 = !DILocation(line: 883, column: 65, scope: !3673)
!3744 = !DILocation(line: 883, column: 62, scope: !3673)
!3745 = !DILocation(line: 885, column: 22, scope: !3673)
!3746 = !DILocation(line: 885, column: 30, scope: !3673)
!3747 = !DILocation(line: 885, column: 17, scope: !3673)
!3748 = !DILocation(line: 885, column: 58, scope: !3673)
!3749 = !DILocation(line: 885, column: 56, scope: !3673)
!3750 = !DILocation(line: 886, column: 38, scope: !3673)
!3751 = !DILocation(line: 886, column: 57, scope: !3673)
!3752 = !DILocation(line: 886, column: 51, scope: !3673)
!3753 = !DILocation(line: 886, column: 17, scope: !3673)
!3754 = !DILocation(line: 887, column: 37, scope: !3673)
!3755 = !DILocation(line: 888, column: 18, scope: !3673)
!3756 = !DILocation(line: 888, column: 31, scope: !3673)
!3757 = !DILocation(line: 888, column: 17, scope: !3673)
!3758 = !DILocation(line: 889, column: 17, scope: !3673)
!3759 = !DILocation(line: 890, column: 33, scope: !3673)
!3760 = !DILocation(line: 883, column: 15, scope: !3673)
!3761 = !DILocation(line: 892, column: 9, scope: !3673)
!3762 = !DILocation(line: 893, column: 24, scope: !3673)
!3763 = !DILocation(line: 893, column: 15, scope: !3673)
!3764 = !DILocation(line: 893, column: 22, scope: !3673)
!3765 = !DILocation(line: 894, column: 9, scope: !3673)
!3766 = !DILocation(line: 895, column: 9, scope: !3673)
!3767 = !DILocation(line: 896, column: 5, scope: !3673)
!3768 = !DILocation(line: 897, column: 9, scope: !3769)
!3769 = distinct !DILexicalBlock(scope: !3674, file: !2, line: 896, column: 12)
!3770 = !DILocation(line: 899, column: 28, scope: !3660)
!3771 = !DILocation(line: 899, column: 36, scope: !3660)
!3772 = !DILocation(line: 899, column: 5, scope: !3660)
!3773 = !DILocation(line: 900, column: 8, scope: !3660)
!3774 = !DILocation(line: 900, column: 22, scope: !3660)
!3775 = !DILocation(line: 900, column: 31, scope: !3660)
!3776 = !{!1316, !1222, i64 472}
!3777 = !DILocation(line: 901, column: 38, scope: !3660)
!3778 = !DILocation(line: 901, column: 5, scope: !3660)
!3779 = !DILocation(line: 902, column: 1, scope: !3660)
!3780 = distinct !DISubprogram(name: "process_get_command", scope: !2, file: !2, line: 549, type: !3781, scopeLine: 549, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !3783)
!3781 = !DISubroutineType(cc: DW_CC_nocall, types: !3782)
!3782 = !{null, !780, !1544, !747, !790, !790}
!3783 = !{!3784, !3785, !3786, !3787, !3788, !3789, !3790, !3791, !3792, !3793, !3794, !3795, !3796, !3797, !3800, !3804, !3805, !3808}
!3784 = !DILocalVariable(name: "c", arg: 1, scope: !3780, file: !2, line: 549, type: !780)
!3785 = !DILocalVariable(name: "tokens", arg: 2, scope: !3780, file: !2, line: 549, type: !1544)
!3786 = !DILocalVariable(name: "ntokens", arg: 3, scope: !3780, file: !2, line: 549, type: !747)
!3787 = !DILocalVariable(name: "return_cas", arg: 4, scope: !3780, file: !2, line: 549, type: !790)
!3788 = !DILocalVariable(name: "should_touch", arg: 5, scope: !3780, file: !2, line: 549, type: !790)
!3789 = !DILocalVariable(name: "key", scope: !3780, file: !2, line: 550, type: !579)
!3790 = !DILocalVariable(name: "nkey", scope: !3780, file: !2, line: 551, type: !747)
!3791 = !DILocalVariable(name: "it", scope: !3780, file: !2, line: 552, type: !1062)
!3792 = !DILocalVariable(name: "key_token", scope: !3780, file: !2, line: 553, type: !1544)
!3793 = !DILocalVariable(name: "exptime_int", scope: !3780, file: !2, line: 554, type: !638)
!3794 = !DILocalVariable(name: "exptime", scope: !3780, file: !2, line: 555, type: !595)
!3795 = !DILocalVariable(name: "fail_length", scope: !3780, file: !2, line: 556, type: !790)
!3796 = !DILocalVariable(name: "resp", scope: !3780, file: !2, line: 558, type: !882)
!3797 = !DILocalVariable(name: "overflow", scope: !3798, file: !2, line: 572, type: !790)
!3798 = distinct !DILexicalBlock(scope: !3799, file: !2, line: 571, column: 39)
!3799 = distinct !DILexicalBlock(scope: !3780, file: !2, line: 570, column: 8)
!3800 = !DILocalVariable(name: "nbytes", scope: !3801, file: !2, line: 597, type: !598)
!3801 = distinct !DILexicalBlock(scope: !3802, file: !2, line: 594, column: 17)
!3802 = distinct !DILexicalBlock(scope: !3803, file: !2, line: 585, column: 21)
!3803 = distinct !DILexicalBlock(scope: !3798, file: !2, line: 585, column: 17)
!3804 = !DILocalVariable(name: "p", scope: !3801, file: !2, line: 598, type: !579)
!3805 = !DILocalVariable(name: "ii", scope: !3806, file: !2, line: 631, type: !598)
!3806 = distinct !DILexicalBlock(scope: !3807, file: !2, line: 630, column: 43)
!3807 = distinct !DILexicalBlock(scope: !3802, file: !2, line: 630, column: 21)
!3808 = !DILabel(scope: !3780, name: "stop", file: !2, line: 692)
!3809 = distinct !DIAssignID()
!3810 = !DILocation(line: 0, scope: !3780)
!3811 = distinct !DIAssignID()
!3812 = !DILocation(line: 0, scope: !3798)
!3813 = !DILocation(line: 553, column: 27, scope: !3780)
!3814 = !DILocation(line: 554, column: 5, scope: !3780)
!3815 = !DILocation(line: 554, column: 13, scope: !3780)
!3816 = distinct !DIAssignID()
!3817 = !DILocation(line: 558, column: 24, scope: !3780)
!3818 = !DILocation(line: 560, column: 9, scope: !3780)
!3819 = !DILocation(line: 562, column: 36, scope: !3820)
!3820 = distinct !DILexicalBlock(scope: !3821, file: !2, line: 562, column: 13)
!3821 = distinct !DILexicalBlock(scope: !3822, file: !2, line: 560, column: 23)
!3822 = distinct !DILexicalBlock(scope: !3780, file: !2, line: 560, column: 9)
!3823 = !DILocation(line: 562, column: 14, scope: !3820)
!3824 = !DILocation(line: 562, column: 13, scope: !3821)
!3825 = !DILocation(line: 563, column: 13, scope: !3826)
!3826 = distinct !DILexicalBlock(scope: !3820, file: !2, line: 562, column: 58)
!3827 = !DILocation(line: 564, column: 13, scope: !3826)
!3828 = !DILocation(line: 566, column: 18, scope: !3821)
!3829 = !DILocation(line: 567, column: 28, scope: !3821)
!3830 = !DILocation(line: 567, column: 19, scope: !3821)
!3831 = !DILocation(line: 568, column: 5, scope: !3821)
!3832 = !DILocation(line: 570, column: 5, scope: !3780)
!3833 = !DILocation(line: 571, column: 26, scope: !3799)
!3834 = !DILocation(line: 571, column: 33, scope: !3799)
!3835 = !DILocation(line: 571, column: 9, scope: !3799)
!3836 = !DILocation(line: 572, column: 13, scope: !3798)
!3837 = !DILocation(line: 573, column: 30, scope: !3798)
!3838 = !DILocation(line: 576, column: 22, scope: !3839)
!3839 = distinct !DILexicalBlock(scope: !3798, file: !2, line: 576, column: 17)
!3840 = !DILocation(line: 576, column: 17, scope: !3798)
!3841 = !DILocation(line: 581, column: 44, scope: !3798)
!3842 = !DILocation(line: 581, column: 18, scope: !3798)
!3843 = !DILocation(line: 582, column: 26, scope: !3844)
!3844 = distinct !DILexicalBlock(scope: !3798, file: !2, line: 582, column: 17)
!3845 = !{!1859, !1215, i64 96}
!3846 = !DILocation(line: 582, column: 17, scope: !3844)
!3847 = !DILocation(line: 582, column: 17, scope: !3798)
!3848 = !DILocation(line: 583, column: 57, scope: !3849)
!3849 = distinct !DILexicalBlock(scope: !3844, file: !2, line: 582, column: 42)
!3850 = !DILocation(line: 583, column: 17, scope: !3849)
!3851 = !DILocation(line: 584, column: 13, scope: !3849)
!3852 = !DILocation(line: 585, column: 17, scope: !3803)
!3853 = !DILocation(line: 585, column: 17, scope: !3798)
!3854 = !DILocation(line: 597, column: 36, scope: !3801)
!3855 = !DILocation(line: 0, scope: !3801)
!3856 = !DILocation(line: 598, column: 35, scope: !3801)
!3857 = !DILocation(line: 599, column: 19, scope: !3801)
!3858 = !DILocation(line: 600, column: 21, scope: !3801)
!3859 = !DILocation(line: 601, column: 29, scope: !3801)
!3860 = !DILocation(line: 601, column: 47, scope: !3801)
!3861 = !DILocation(line: 601, column: 43, scope: !3801)
!3862 = !DILocation(line: 601, column: 19, scope: !3801)
!3863 = !DILocation(line: 602, column: 28, scope: !3801)
!3864 = !DILocation(line: 602, column: 21, scope: !3801)
!3865 = !DILocalVariable(name: "suffix", arg: 1, scope: !3866, file: !2, line: 524, type: !579)
!3866 = distinct !DISubprogram(name: "make_ascii_get_suffix", scope: !2, file: !2, line: 524, type: !3867, scopeLine: 524, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !3869)
!3867 = !DISubroutineType(types: !3868)
!3868 = !{!598, !579, !1062, !790, !598}
!3869 = !{!3865, !3870, !3871, !3872, !3873}
!3870 = !DILocalVariable(name: "it", arg: 2, scope: !3866, file: !2, line: 524, type: !1062)
!3871 = !DILocalVariable(name: "return_cas", arg: 3, scope: !3866, file: !2, line: 524, type: !790)
!3872 = !DILocalVariable(name: "nbytes", arg: 4, scope: !3866, file: !2, line: 524, type: !598)
!3873 = !DILocalVariable(name: "p", scope: !3866, file: !2, line: 525, type: !579)
!3874 = !DILocation(line: 0, scope: !3866, inlinedAt: !3875)
!3875 = distinct !DILocation(line: 603, column: 24, scope: !3801)
!3876 = !DILocation(line: 526, column: 8, scope: !3866, inlinedAt: !3875)
!3877 = !DILocation(line: 527, column: 6, scope: !3866, inlinedAt: !3875)
!3878 = !DILocation(line: 528, column: 9, scope: !3879, inlinedAt: !3875)
!3879 = distinct !DILexicalBlock(scope: !3866, file: !2, line: 528, column: 9)
!3880 = !DILocation(line: 528, column: 24, scope: !3879, inlinedAt: !3875)
!3881 = !DILocation(line: 528, column: 9, scope: !3866, inlinedAt: !3875)
!3882 = !DILocation(line: 529, column: 12, scope: !3883, inlinedAt: !3875)
!3883 = distinct !DILexicalBlock(scope: !3879, file: !2, line: 528, column: 30)
!3884 = !DILocation(line: 530, column: 10, scope: !3883, inlinedAt: !3875)
!3885 = !DILocation(line: 531, column: 5, scope: !3883, inlinedAt: !3875)
!3886 = !DILocation(line: 532, column: 43, scope: !3887, inlinedAt: !3875)
!3887 = distinct !DILexicalBlock(scope: !3879, file: !2, line: 531, column: 12)
!3888 = !DILocation(line: 532, column: 22, scope: !3887, inlinedAt: !3875)
!3889 = !DILocation(line: 532, column: 13, scope: !3887, inlinedAt: !3875)
!3890 = !DILocation(line: 0, scope: !3879, inlinedAt: !3875)
!3891 = !DILocation(line: 534, column: 8, scope: !3866, inlinedAt: !3875)
!3892 = !DILocation(line: 535, column: 24, scope: !3866, inlinedAt: !3875)
!3893 = !DILocation(line: 535, column: 29, scope: !3866, inlinedAt: !3875)
!3894 = !DILocation(line: 535, column: 9, scope: !3866, inlinedAt: !3875)
!3895 = !DILocation(line: 537, column: 9, scope: !3866, inlinedAt: !3875)
!3896 = !DILocation(line: 538, column: 12, scope: !3897, inlinedAt: !3875)
!3897 = distinct !DILexicalBlock(scope: !3898, file: !2, line: 537, column: 21)
!3898 = distinct !DILexicalBlock(scope: !3866, file: !2, line: 537, column: 9)
!3899 = !DILocation(line: 539, column: 22, scope: !3897, inlinedAt: !3875)
!3900 = !DILocation(line: 539, column: 41, scope: !3897, inlinedAt: !3875)
!3901 = !DILocation(line: 539, column: 13, scope: !3897, inlinedAt: !3875)
!3902 = !DILocation(line: 540, column: 5, scope: !3897, inlinedAt: !3875)
!3903 = !DILocation(line: 542, column: 8, scope: !3866, inlinedAt: !3875)
!3904 = !DILocation(line: 543, column: 8, scope: !3866, inlinedAt: !3875)
!3905 = !DILocation(line: 543, column: 12, scope: !3866, inlinedAt: !3875)
!3906 = !DILocation(line: 544, column: 8, scope: !3866, inlinedAt: !3875)
!3907 = !DILocation(line: 544, column: 12, scope: !3866, inlinedAt: !3875)
!3908 = !DILocation(line: 545, column: 15, scope: !3866, inlinedAt: !3875)
!3909 = !DILocation(line: 603, column: 21, scope: !3801)
!3910 = !DILocation(line: 604, column: 52, scope: !3801)
!3911 = !DILocation(line: 604, column: 50, scope: !3801)
!3912 = !DILocation(line: 604, column: 19, scope: !3801)
!3913 = !DILocation(line: 607, column: 27, scope: !3914)
!3914 = distinct !DILexicalBlock(scope: !3801, file: !2, line: 607, column: 23)
!3915 = !DILocation(line: 607, column: 23, scope: !3914)
!3916 = !DILocation(line: 607, column: 36, scope: !3914)
!3917 = !DILocation(line: 607, column: 23, scope: !3801)
!3918 = !DILocation(line: 608, column: 27, scope: !3919)
!3919 = distinct !DILexicalBlock(scope: !3920, file: !2, line: 608, column: 27)
!3920 = distinct !DILexicalBlock(scope: !3914, file: !2, line: 607, column: 48)
!3921 = !DILocation(line: 608, column: 57, scope: !3919)
!3922 = !DILocation(line: 608, column: 27, scope: !3920)
!3923 = !DILocation(line: 616, column: 44, scope: !3924)
!3924 = distinct !DILexicalBlock(scope: !3914, file: !2, line: 616, column: 30)
!3925 = !DILocation(line: 616, column: 60, scope: !3924)
!3926 = !DILocation(line: 616, column: 30, scope: !3914)
!3927 = !DILocation(line: 617, column: 42, scope: !3928)
!3928 = distinct !DILexicalBlock(scope: !3924, file: !2, line: 616, column: 66)
!3929 = !DILocation(line: 617, column: 61, scope: !3928)
!3930 = !DILocation(line: 617, column: 23, scope: !3928)
!3931 = !DILocation(line: 618, column: 19, scope: !3928)
!3932 = !DILocation(line: 619, column: 58, scope: !3933)
!3933 = distinct !DILexicalBlock(scope: !3924, file: !2, line: 618, column: 26)
!3934 = !DILocation(line: 619, column: 23, scope: !3933)
!3935 = !DILocation(line: 609, column: 50, scope: !3936)
!3936 = distinct !DILexicalBlock(scope: !3919, file: !2, line: 608, column: 63)
!3937 = !DILocation(line: 609, column: 58, scope: !3936)
!3938 = !DILocation(line: 609, column: 27, scope: !3936)
!3939 = !DILocation(line: 610, column: 30, scope: !3936)
!3940 = !DILocation(line: 610, column: 44, scope: !3936)
!3941 = !DILocation(line: 610, column: 60, scope: !3936)
!3942 = !DILocation(line: 611, column: 60, scope: !3936)
!3943 = !DILocation(line: 611, column: 27, scope: !3936)
!3944 = !DILocation(line: 613, column: 27, scope: !3936)
!3945 = !DILocation(line: 630, column: 30, scope: !3807)
!3946 = !DILocation(line: 630, column: 38, scope: !3807)
!3947 = !DILocation(line: 630, column: 21, scope: !3802)
!3948 = !DILocation(line: 632, column: 29, scope: !3806)
!3949 = !DILocation(line: 632, column: 60, scope: !3806)
!3950 = !DILocation(line: 632, column: 21, scope: !3806)
!3951 = !DILocation(line: 0, scope: !3806)
!3952 = !DILocation(line: 633, column: 43, scope: !3953)
!3953 = distinct !DILexicalBlock(scope: !3954, file: !2, line: 633, column: 21)
!3954 = distinct !DILexicalBlock(scope: !3806, file: !2, line: 633, column: 21)
!3955 = !DILocation(line: 633, column: 37, scope: !3953)
!3956 = !DILocation(line: 633, column: 21, scope: !3954)
!3957 = !DILocation(line: 634, column: 33, scope: !3958)
!3958 = distinct !DILexicalBlock(scope: !3953, file: !2, line: 633, column: 55)
!3959 = !DILocation(line: 634, column: 47, scope: !3958)
!3960 = !DILocation(line: 634, column: 25, scope: !3958)
!3961 = !DILocation(line: 633, column: 49, scope: !3953)
!3962 = distinct !{!3962, !3956, !3963, !1410}
!3963 = !DILocation(line: 635, column: 21, scope: !3954)
!3964 = !DILocation(line: 636, column: 29, scope: !3806)
!3965 = !DILocation(line: 636, column: 21, scope: !3806)
!3966 = !DILocation(line: 637, column: 17, scope: !3806)
!3967 = !DILocation(line: 640, column: 40, scope: !3802)
!3968 = !DILocation(line: 640, column: 48, scope: !3802)
!3969 = !DILocation(line: 640, column: 17, scope: !3802)
!3970 = !DILocation(line: 0, scope: !3971)
!3971 = distinct !DILexicalBlock(scope: !3802, file: !2, line: 641, column: 21)
!3972 = !DILocation(line: 641, column: 21, scope: !3802)
!3973 = !DILocation(line: 642, column: 38, scope: !3974)
!3974 = distinct !DILexicalBlock(scope: !3971, file: !2, line: 641, column: 35)
!3975 = !DILocation(line: 642, column: 48, scope: !3974)
!3976 = !DILocation(line: 643, column: 38, scope: !3974)
!3977 = !DILocation(line: 643, column: 49, scope: !3974)
!3978 = !DILocation(line: 643, column: 65, scope: !3974)
!3979 = !DILocation(line: 644, column: 17, scope: !3974)
!3980 = !DILocation(line: 645, column: 38, scope: !3981)
!3981 = distinct !DILexicalBlock(scope: !3971, file: !2, line: 644, column: 24)
!3982 = !DILocation(line: 645, column: 51, scope: !3981)
!3983 = !DILocation(line: 645, column: 21, scope: !3981)
!3984 = !DILocation(line: 645, column: 63, scope: !3981)
!3985 = !DILocation(line: 646, column: 38, scope: !3981)
!3986 = !DILocation(line: 648, column: 50, scope: !3802)
!3987 = !DILocation(line: 648, column: 17, scope: !3802)
!3988 = !DILocation(line: 651, column: 26, scope: !3989)
!3989 = distinct !DILexicalBlock(scope: !3802, file: !2, line: 651, column: 21)
!3990 = !DILocation(line: 651, column: 35, scope: !3989)
!3991 = !DILocation(line: 651, column: 47, scope: !3989)
!3992 = !DILocation(line: 651, column: 21, scope: !3802)
!3993 = !DILocation(line: 652, column: 27, scope: !3994)
!3994 = distinct !DILexicalBlock(scope: !3989, file: !2, line: 651, column: 53)
!3995 = !DILocation(line: 652, column: 32, scope: !3994)
!3996 = !DILocation(line: 653, column: 17, scope: !3994)
!3997 = !DILocation(line: 658, column: 40, scope: !3998)
!3998 = distinct !DILexicalBlock(scope: !3803, file: !2, line: 657, column: 20)
!3999 = !DILocation(line: 658, column: 48, scope: !3998)
!4000 = !DILocation(line: 658, column: 17, scope: !3998)
!4001 = !DILocation(line: 0, scope: !4002)
!4002 = distinct !DILexicalBlock(scope: !3998, file: !2, line: 659, column: 21)
!4003 = !DILocation(line: 667, column: 50, scope: !3998)
!4004 = !DILocation(line: 667, column: 17, scope: !3998)
!4005 = !DILocation(line: 670, column: 22, scope: !3798)
!4006 = !DILocation(line: 671, column: 28, scope: !4007)
!4007 = distinct !DILexicalBlock(scope: !3798, file: !2, line: 671, column: 17)
!4008 = !DILocation(line: 671, column: 35, scope: !4007)
!4009 = !DILocation(line: 671, column: 17, scope: !3798)
!4010 = !DILocation(line: 677, column: 9, scope: !3799)
!4011 = !DILocation(line: 672, column: 22, scope: !4012)
!4012 = distinct !DILexicalBlock(scope: !4013, file: !2, line: 672, column: 21)
!4013 = distinct !DILexicalBlock(scope: !4007, file: !2, line: 671, column: 41)
!4014 = !DILocation(line: 672, column: 21, scope: !4013)
!4015 = !DILocation(line: 675, column: 27, scope: !4013)
!4016 = !DILocation(line: 558, column: 14, scope: !3780)
!4017 = !DILocation(line: 683, column: 24, scope: !4018)
!4018 = distinct !DILexicalBlock(scope: !3799, file: !2, line: 683, column: 13)
!4019 = !DILocation(line: 683, column: 30, scope: !4018)
!4020 = !DILocation(line: 683, column: 13, scope: !3799)
!4021 = !DILocation(line: 0, scope: !1541, inlinedAt: !4022)
!4022 = distinct !DILocation(line: 684, column: 23, scope: !4023)
!4023 = distinct !DILexicalBlock(scope: !4018, file: !2, line: 683, column: 39)
!4024 = !DILocation(line: 296, column: 18, scope: !1541, inlinedAt: !4022)
!4025 = !DILocation(line: 300, column: 19, scope: !1558, inlinedAt: !4022)
!4026 = !DILocation(line: 300, column: 5, scope: !1559, inlinedAt: !4022)
!4027 = !DILocation(line: 301, column: 13, scope: !1562, inlinedAt: !4022)
!4028 = !DILocation(line: 301, column: 16, scope: !1562, inlinedAt: !4022)
!4029 = !DILocation(line: 301, column: 13, scope: !1563, inlinedAt: !4022)
!4030 = !DILocation(line: 302, column: 19, scope: !1567, inlinedAt: !4022)
!4031 = !DILocation(line: 302, column: 17, scope: !1568, inlinedAt: !4022)
!4032 = !DILocation(line: 303, column: 17, scope: !1571, inlinedAt: !4022)
!4033 = !DILocation(line: 303, column: 39, scope: !1571, inlinedAt: !4022)
!4034 = !DILocation(line: 304, column: 44, scope: !1571, inlinedAt: !4022)
!4035 = !DILocation(line: 304, column: 33, scope: !1571, inlinedAt: !4022)
!4036 = !DILocation(line: 304, column: 40, scope: !1571, inlinedAt: !4022)
!4037 = !DILocation(line: 305, column: 24, scope: !1571, inlinedAt: !4022)
!4038 = !DILocation(line: 306, column: 20, scope: !1571, inlinedAt: !4022)
!4039 = !DILocation(line: 307, column: 29, scope: !1582, inlinedAt: !4022)
!4040 = !DILocation(line: 307, column: 21, scope: !1571, inlinedAt: !4022)
!4041 = !DILocation(line: 308, column: 22, scope: !1585, inlinedAt: !4022)
!4042 = !DILocation(line: 318, column: 9, scope: !1541, inlinedAt: !4022)
!4043 = !DILocation(line: 313, column: 19, scope: !1568, inlinedAt: !4022)
!4044 = !DILocation(line: 314, column: 9, scope: !1568, inlinedAt: !4022)
!4045 = !DILocation(line: 315, column: 10, scope: !1563, inlinedAt: !4022)
!4046 = !DILocation(line: 300, column: 27, scope: !1558, inlinedAt: !4022)
!4047 = !DILocation(line: 300, column: 17, scope: !1558, inlinedAt: !4022)
!4048 = distinct !{!4048, !4026, !4049, !1410}
!4049 = !DILocation(line: 316, column: 5, scope: !1559, inlinedAt: !4022)
!4050 = !DILocation(line: 318, column: 11, scope: !1595, inlinedAt: !4022)
!4051 = !DILocation(line: 319, column: 9, scope: !1597, inlinedAt: !4022)
!4052 = !DILocation(line: 319, column: 31, scope: !1597, inlinedAt: !4022)
!4053 = !DILocation(line: 320, column: 36, scope: !1597, inlinedAt: !4022)
!4054 = !DILocation(line: 320, column: 25, scope: !1597, inlinedAt: !4022)
!4055 = !DILocation(line: 320, column: 32, scope: !1597, inlinedAt: !4022)
!4056 = !DILocation(line: 321, column: 16, scope: !1597, inlinedAt: !4022)
!4057 = !DILocation(line: 322, column: 5, scope: !1597, inlinedAt: !4022)
!4058 = !DILocation(line: 328, column: 30, scope: !1541, inlinedAt: !4022)
!4059 = !DILocation(line: 328, column: 33, scope: !1541, inlinedAt: !4022)
!4060 = !DILocation(line: 328, column: 5, scope: !1541, inlinedAt: !4022)
!4061 = !DILocation(line: 328, column: 27, scope: !1541, inlinedAt: !4022)
!4062 = !DILocation(line: 329, column: 21, scope: !1541, inlinedAt: !4022)
!4063 = !DILocation(line: 329, column: 28, scope: !1541, inlinedAt: !4022)
!4064 = !DILocation(line: 686, column: 18, scope: !4065)
!4065 = distinct !DILexicalBlock(scope: !4023, file: !2, line: 686, column: 17)
!4066 = !DILocation(line: 686, column: 17, scope: !4023)
!4067 = !DILocation(line: 689, column: 23, scope: !4023)
!4068 = !DILocation(line: 691, column: 24, scope: !3780)
!4069 = !DILocation(line: 691, column: 30, scope: !3780)
!4070 = !DILocation(line: 691, column: 5, scope: !3799)
!4071 = distinct !{!4071, !3832, !4072, !1410}
!4072 = !DILocation(line: 691, column: 37, scope: !3780)
!4073 = !DILocation(line: 692, column: 1, scope: !3780)
!4074 = !DILocation(line: 694, column: 18, scope: !4075)
!4075 = distinct !DILexicalBlock(scope: !3780, file: !2, line: 694, column: 9)
!4076 = !DILocation(line: 694, column: 26, scope: !4075)
!4077 = !DILocation(line: 694, column: 9, scope: !3780)
!4078 = !DILocation(line: 695, column: 17, scope: !4075)
!4079 = !DILocation(line: 695, column: 41, scope: !4075)
!4080 = !DILocation(line: 695, column: 9, scope: !4075)
!4081 = !DILocation(line: 702, column: 20, scope: !4082)
!4082 = distinct !DILexicalBlock(scope: !3780, file: !2, line: 702, column: 9)
!4083 = !DILocation(line: 702, column: 26, scope: !4082)
!4084 = !DILocation(line: 702, column: 9, scope: !3780)
!4085 = !DILocation(line: 704, column: 9, scope: !4086)
!4086 = distinct !DILexicalBlock(scope: !4082, file: !2, line: 702, column: 35)
!4087 = !DILocation(line: 706, column: 14, scope: !4088)
!4088 = distinct !DILexicalBlock(scope: !4086, file: !2, line: 706, column: 13)
!4089 = !DILocation(line: 706, column: 13, scope: !4086)
!4090 = !DILocation(line: 708, column: 13, scope: !4091)
!4091 = distinct !DILexicalBlock(scope: !4088, file: !2, line: 706, column: 29)
!4092 = !DILocation(line: 709, column: 13, scope: !4091)
!4093 = !DILocation(line: 711, column: 13, scope: !4086)
!4094 = !DILocation(line: 712, column: 13, scope: !4095)
!4095 = distinct !DILexicalBlock(scope: !4096, file: !2, line: 711, column: 26)
!4096 = distinct !DILexicalBlock(scope: !4086, file: !2, line: 711, column: 13)
!4097 = !DILocation(line: 713, column: 9, scope: !4095)
!4098 = !DILocation(line: 714, column: 13, scope: !4099)
!4099 = distinct !DILexicalBlock(scope: !4096, file: !2, line: 713, column: 16)
!4100 = !DILocation(line: 718, column: 9, scope: !4101)
!4101 = distinct !DILexicalBlock(scope: !4082, file: !2, line: 716, column: 12)
!4102 = !DILocation(line: 719, column: 9, scope: !4101)
!4103 = !DILocation(line: 721, column: 1, scope: !3780)
!4104 = distinct !DISubprogram(name: "process_update_command", scope: !2, file: !2, line: 1995, type: !4105, scopeLine: 1995, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !4107)
!4105 = !DISubroutineType(types: !4106)
!4106 = !{null, !780, !1544, !1545, !598, !790}
!4107 = !{!4108, !4109, !4110, !4111, !4112, !4113, !4114, !4115, !4116, !4117, !4118, !4119, !4120, !4121, !4124}
!4108 = !DILocalVariable(name: "c", arg: 1, scope: !4104, file: !2, line: 1995, type: !780)
!4109 = !DILocalVariable(name: "tokens", arg: 2, scope: !4104, file: !2, line: 1995, type: !1544)
!4110 = !DILocalVariable(name: "ntokens", arg: 3, scope: !4104, file: !2, line: 1995, type: !1545)
!4111 = !DILocalVariable(name: "comm", arg: 4, scope: !4104, file: !2, line: 1995, type: !598)
!4112 = !DILocalVariable(name: "handle_cas", arg: 5, scope: !4104, file: !2, line: 1995, type: !790)
!4113 = !DILocalVariable(name: "key", scope: !4104, file: !2, line: 1996, type: !579)
!4114 = !DILocalVariable(name: "nkey", scope: !4104, file: !2, line: 1997, type: !747)
!4115 = !DILocalVariable(name: "flags", scope: !4104, file: !2, line: 1998, type: !634)
!4116 = !DILocalVariable(name: "exptime_int", scope: !4104, file: !2, line: 1999, type: !638)
!4117 = !DILocalVariable(name: "exptime", scope: !4104, file: !2, line: 2000, type: !595)
!4118 = !DILocalVariable(name: "vlen", scope: !4104, file: !2, line: 2001, type: !598)
!4119 = !DILocalVariable(name: "req_cas_id", scope: !4104, file: !2, line: 2002, type: !616)
!4120 = !DILocalVariable(name: "it", scope: !4104, file: !2, line: 2003, type: !1062)
!4121 = !DILocalVariable(name: "status", scope: !4122, file: !2, line: 2047, type: !531)
!4122 = distinct !DILexicalBlock(scope: !4123, file: !2, line: 2046, column: 18)
!4123 = distinct !DILexicalBlock(scope: !4104, file: !2, line: 2046, column: 9)
!4124 = !DILocalVariable(name: "myl", scope: !4125, file: !2, line: 2061, type: !641)
!4125 = distinct !DILexicalBlock(scope: !4122, file: !2, line: 2061, column: 9)
!4126 = distinct !DIAssignID()
!4127 = !DILocation(line: 0, scope: !4104)
!4128 = distinct !DIAssignID()
!4129 = distinct !DIAssignID()
!4130 = distinct !DIAssignID()
!4131 = !DILocation(line: 1998, column: 5, scope: !4104)
!4132 = !DILocation(line: 1999, column: 5, scope: !4104)
!4133 = !DILocation(line: 1999, column: 13, scope: !4104)
!4134 = distinct !DIAssignID()
!4135 = !DILocation(line: 2001, column: 5, scope: !4104)
!4136 = !DILocation(line: 2002, column: 5, scope: !4104)
!4137 = !DILocation(line: 2002, column: 14, scope: !4104)
!4138 = distinct !DIAssignID()
!4139 = !DILocalVariable(name: "c", arg: 1, scope: !4140, file: !2, line: 505, type: !780)
!4140 = distinct !DISubprogram(name: "set_noreply_maybe", scope: !2, file: !2, line: 505, type: !4141, scopeLine: 506, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !4143)
!4141 = !DISubroutineType(types: !4142)
!4142 = !{!790, !780, !1544, !747}
!4143 = !{!4139, !4144, !4145, !4146}
!4144 = !DILocalVariable(name: "tokens", arg: 2, scope: !4140, file: !2, line: 505, type: !1544)
!4145 = !DILocalVariable(name: "ntokens", arg: 3, scope: !4140, file: !2, line: 505, type: !747)
!4146 = !DILocalVariable(name: "noreply_index", scope: !4140, file: !2, line: 507, type: !598)
!4147 = !DILocation(line: 0, scope: !4140, inlinedAt: !4148)
!4148 = distinct !DILocation(line: 2007, column: 5, scope: !4104)
!4149 = !DILocation(line: 516, column: 9, scope: !4150, inlinedAt: !4148)
!4150 = distinct !DILexicalBlock(scope: !4140, file: !2, line: 516, column: 9)
!4151 = !DILocation(line: 516, column: 31, scope: !4150, inlinedAt: !4148)
!4152 = !DILocation(line: 517, column: 9, scope: !4150, inlinedAt: !4148)
!4153 = !DILocation(line: 517, column: 12, scope: !4150, inlinedAt: !4148)
!4154 = !DILocation(line: 517, column: 59, scope: !4150, inlinedAt: !4148)
!4155 = !DILocation(line: 516, column: 9, scope: !4140, inlinedAt: !4148)
!4156 = !DILocation(line: 518, column: 12, scope: !4157, inlinedAt: !4148)
!4157 = distinct !DILexicalBlock(scope: !4150, file: !2, line: 517, column: 65)
!4158 = !DILocation(line: 518, column: 20, scope: !4157, inlinedAt: !4148)
!4159 = !DILocation(line: 519, column: 5, scope: !4157, inlinedAt: !4148)
!4160 = !DILocation(line: 2009, column: 27, scope: !4161)
!4161 = distinct !DILexicalBlock(scope: !4104, file: !2, line: 2009, column: 9)
!4162 = !DILocation(line: 2009, column: 34, scope: !4161)
!4163 = !DILocation(line: 2009, column: 9, scope: !4104)
!4164 = !DILocation(line: 2010, column: 9, scope: !4165)
!4165 = distinct !DILexicalBlock(scope: !4161, file: !2, line: 2009, column: 52)
!4166 = !DILocation(line: 2011, column: 9, scope: !4165)
!4167 = !DILocation(line: 2009, column: 9, scope: !4161)
!4168 = !DILocation(line: 2014, column: 29, scope: !4104)
!4169 = !DILocation(line: 2017, column: 28, scope: !4170)
!4170 = distinct !DILexicalBlock(scope: !4104, file: !2, line: 2017, column: 9)
!4171 = !DILocation(line: 2017, column: 38, scope: !4170)
!4172 = !DILocation(line: 2017, column: 12, scope: !4170)
!4173 = !DILocation(line: 2018, column: 12, scope: !4170)
!4174 = !DILocation(line: 2018, column: 27, scope: !4170)
!4175 = !DILocation(line: 2018, column: 37, scope: !4170)
!4176 = !DILocation(line: 2018, column: 15, scope: !4170)
!4177 = !DILocation(line: 2019, column: 12, scope: !4170)
!4178 = !DILocation(line: 2019, column: 27, scope: !4170)
!4179 = !DILocation(line: 2019, column: 37, scope: !4170)
!4180 = !DILocation(line: 2019, column: 15, scope: !4170)
!4181 = !DILocation(line: 2017, column: 9, scope: !4104)
!4182 = !DILocation(line: 2020, column: 9, scope: !4183)
!4183 = distinct !DILexicalBlock(scope: !4170, file: !2, line: 2019, column: 64)
!4184 = !DILocation(line: 2021, column: 9, scope: !4183)
!4185 = !DILocation(line: 2024, column: 24, scope: !4104)
!4186 = !DILocation(line: 2024, column: 15, scope: !4104)
!4187 = !DILocation(line: 2027, column: 9, scope: !4104)
!4188 = !DILocation(line: 2028, column: 28, scope: !4189)
!4189 = distinct !DILexicalBlock(scope: !4190, file: !2, line: 2028, column: 13)
!4190 = distinct !DILexicalBlock(scope: !4191, file: !2, line: 2027, column: 21)
!4191 = distinct !DILexicalBlock(scope: !4104, file: !2, line: 2027, column: 9)
!4192 = !DILocation(line: 2028, column: 38, scope: !4189)
!4193 = !DILocation(line: 2028, column: 14, scope: !4189)
!4194 = !DILocation(line: 2028, column: 13, scope: !4190)
!4195 = !DILocation(line: 2029, column: 13, scope: !4196)
!4196 = distinct !DILexicalBlock(scope: !4189, file: !2, line: 2028, column: 59)
!4197 = !DILocation(line: 2030, column: 13, scope: !4196)
!4198 = !DILocation(line: 2034, column: 9, scope: !4199)
!4199 = distinct !DILexicalBlock(scope: !4104, file: !2, line: 2034, column: 9)
!4200 = !DILocation(line: 2034, column: 18, scope: !4199)
!4201 = !DILocation(line: 2035, column: 9, scope: !4202)
!4202 = distinct !DILexicalBlock(scope: !4199, file: !2, line: 2034, column: 43)
!4203 = !DILocation(line: 2036, column: 9, scope: !4202)
!4204 = !DILocation(line: 2038, column: 10, scope: !4104)
!4205 = distinct !DIAssignID()
!4206 = !DILocation(line: 2040, column: 18, scope: !4207)
!4207 = distinct !DILexicalBlock(scope: !4104, file: !2, line: 2040, column: 9)
!4208 = !DILocation(line: 2040, column: 9, scope: !4207)
!4209 = !DILocation(line: 2040, column: 9, scope: !4104)
!4210 = !DILocation(line: 2041, column: 9, scope: !4211)
!4211 = distinct !DILexicalBlock(scope: !4207, file: !2, line: 2040, column: 34)
!4212 = !DILocation(line: 2044, column: 48, scope: !4104)
!4213 = !DILocation(line: 2042, column: 5, scope: !4211)
!4214 = !DILocation(line: 2044, column: 32, scope: !4104)
!4215 = !DILocation(line: 2044, column: 10, scope: !4104)
!4216 = !DILocation(line: 2046, column: 12, scope: !4123)
!4217 = !DILocation(line: 2046, column: 9, scope: !4104)
!4218 = !DILocation(line: 2048, column: 34, scope: !4219)
!4219 = distinct !DILexicalBlock(scope: !4122, file: !2, line: 2048, column: 13)
!4220 = !DILocation(line: 2048, column: 41, scope: !4219)
!4221 = !DILocation(line: 2048, column: 15, scope: !4219)
!4222 = !DILocation(line: 0, scope: !4219)
!4223 = !DILocation(line: 2048, column: 13, scope: !4122)
!4224 = !DILocation(line: 2049, column: 13, scope: !4225)
!4225 = distinct !DILexicalBlock(scope: !4219, file: !2, line: 2048, column: 48)
!4226 = !DILocation(line: 0, scope: !4122)
!4227 = !DILocation(line: 2051, column: 36, scope: !4225)
!4228 = !DILocation(line: 2051, column: 44, scope: !4225)
!4229 = !DILocation(line: 2051, column: 13, scope: !4225)
!4230 = !DILocation(line: 2052, column: 16, scope: !4225)
!4231 = !DILocation(line: 2052, column: 30, scope: !4225)
!4232 = !DILocation(line: 2054, column: 9, scope: !4225)
!4233 = !DILocation(line: 2055, column: 13, scope: !4234)
!4234 = distinct !DILexicalBlock(scope: !4219, file: !2, line: 2054, column: 16)
!4235 = !DILocation(line: 2057, column: 36, scope: !4234)
!4236 = !DILocation(line: 2057, column: 44, scope: !4234)
!4237 = !DILocation(line: 2057, column: 13, scope: !4234)
!4238 = !DILocation(line: 2058, column: 16, scope: !4234)
!4239 = !DILocation(line: 2058, column: 30, scope: !4234)
!4240 = !DILocation(line: 2061, column: 9, scope: !4125)
!4241 = !DILocation(line: 0, scope: !4125)
!4242 = !DILocation(line: 2061, column: 9, scope: !4243)
!4243 = distinct !DILexicalBlock(scope: !4125, file: !2, line: 2061, column: 9)
!4244 = !DILocation(line: 2061, column: 9, scope: !4245)
!4245 = distinct !DILexicalBlock(scope: !4125, file: !2, line: 2061, column: 9)
!4246 = !DILocation(line: 2064, column: 9, scope: !4122)
!4247 = !DILocation(line: 2065, column: 21, scope: !4122)
!4248 = !DILocation(line: 2065, column: 12, scope: !4122)
!4249 = !DILocation(line: 2065, column: 19, scope: !4122)
!4250 = !DILocation(line: 2069, column: 18, scope: !4251)
!4251 = distinct !DILexicalBlock(scope: !4122, file: !2, line: 2069, column: 13)
!4252 = !DILocation(line: 2069, column: 13, scope: !4122)
!4253 = !DILocation(line: 2070, column: 41, scope: !4254)
!4254 = distinct !DILexicalBlock(scope: !4251, file: !2, line: 2069, column: 32)
!4255 = !DILocation(line: 2070, column: 18, scope: !4254)
!4256 = !DILocation(line: 2071, column: 17, scope: !4257)
!4257 = distinct !DILexicalBlock(scope: !4254, file: !2, line: 2071, column: 17)
!4258 = !DILocation(line: 2071, column: 17, scope: !4254)
!4259 = !DILocation(line: 2072, column: 17, scope: !4260)
!4260 = distinct !DILexicalBlock(scope: !4257, file: !2, line: 2071, column: 21)
!4261 = !DILocation(line: 2073, column: 17, scope: !4262)
!4262 = distinct !DILexicalBlock(scope: !4260, file: !2, line: 2073, column: 17)
!4263 = !DILocation(line: 2074, column: 17, scope: !4260)
!4264 = !DILocation(line: 2075, column: 13, scope: !4260)
!4265 = !DILocation(line: 2080, column: 5, scope: !4266)
!4266 = distinct !DILexicalBlock(scope: !4267, file: !2, line: 2080, column: 5)
!4267 = distinct !DILexicalBlock(scope: !4104, file: !2, line: 2080, column: 5)
!4268 = !DILocation(line: 2080, column: 5, scope: !4267)
!4269 = !DILocation(line: 2080, column: 5, scope: !4270)
!4270 = distinct !DILexicalBlock(scope: !4266, file: !2, line: 2080, column: 5)
!4271 = !DILocation(line: 2082, column: 8, scope: !4104)
!4272 = !DILocation(line: 2082, column: 13, scope: !4104)
!4273 = !DILocation(line: 2090, column: 16, scope: !4104)
!4274 = !DILocation(line: 2090, column: 8, scope: !4104)
!4275 = !DILocation(line: 2090, column: 14, scope: !4104)
!4276 = !DILocation(line: 2092, column: 22, scope: !4104)
!4277 = !DILocation(line: 2092, column: 8, scope: !4104)
!4278 = !DILocation(line: 2092, column: 16, scope: !4104)
!4279 = !DILocation(line: 2093, column: 14, scope: !4104)
!4280 = !DILocation(line: 2093, column: 8, scope: !4104)
!4281 = !DILocation(line: 2093, column: 12, scope: !4104)
!4282 = !DILocation(line: 2094, column: 5, scope: !4104)
!4283 = !DILocation(line: 2095, column: 1, scope: !4104)
!4284 = distinct !DISubprogram(name: "process_stat", scope: !2, file: !2, line: 744, type: !2331, scopeLine: 744, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !4285)
!4285 = !{!4286, !4287, !4288, !4289, !4290, !4297, !4298, !4299}
!4286 = !DILocalVariable(name: "c", arg: 1, scope: !4284, file: !2, line: 744, type: !780)
!4287 = !DILocalVariable(name: "tokens", arg: 2, scope: !4284, file: !2, line: 744, type: !1544)
!4288 = !DILocalVariable(name: "ntokens", arg: 3, scope: !4284, file: !2, line: 744, type: !1545)
!4289 = !DILocalVariable(name: "subcommand", scope: !4284, file: !2, line: 745, type: !1472)
!4290 = !DILocalVariable(name: "buf", scope: !4291, file: !2, line: 771, type: !579)
!4291 = distinct !DILexicalBlock(scope: !4292, file: !2, line: 770, column: 54)
!4292 = distinct !DILexicalBlock(scope: !4293, file: !2, line: 770, column: 16)
!4293 = distinct !DILexicalBlock(scope: !4294, file: !2, line: 768, column: 16)
!4294 = distinct !DILexicalBlock(scope: !4295, file: !2, line: 760, column: 16)
!4295 = distinct !DILexicalBlock(scope: !4296, file: !2, line: 756, column: 16)
!4296 = distinct !DILexicalBlock(scope: !4284, file: !2, line: 753, column: 9)
!4297 = !DILocalVariable(name: "bytes", scope: !4291, file: !2, line: 772, type: !464)
!4298 = !DILocalVariable(name: "id", scope: !4291, file: !2, line: 772, type: !464)
!4299 = !DILocalVariable(name: "limit", scope: !4291, file: !2, line: 772, type: !464)
!4300 = distinct !DIAssignID()
!4301 = !DILocation(line: 0, scope: !4291)
!4302 = distinct !DIAssignID()
!4303 = distinct !DIAssignID()
!4304 = !DILocation(line: 0, scope: !4284)
!4305 = !DILocation(line: 745, column: 30, scope: !4284)
!4306 = !DILocation(line: 745, column: 55, scope: !4284)
!4307 = !DILocation(line: 753, column: 17, scope: !4296)
!4308 = !DILocation(line: 753, column: 9, scope: !4284)
!4309 = !DILocation(line: 754, column: 9, scope: !4310)
!4310 = distinct !DILexicalBlock(scope: !4296, file: !2, line: 753, column: 23)
!4311 = !DILocation(line: 755, column: 15, scope: !4310)
!4312 = !DILocation(line: 756, column: 5, scope: !4310)
!4313 = !DILocation(line: 756, column: 16, scope: !4295)
!4314 = !DILocation(line: 756, column: 44, scope: !4295)
!4315 = !DILocation(line: 756, column: 16, scope: !4296)
!4316 = !DILocation(line: 757, column: 9, scope: !4317)
!4317 = distinct !DILexicalBlock(scope: !4295, file: !2, line: 756, column: 50)
!4318 = !DILocation(line: 758, column: 9, scope: !4317)
!4319 = !DILocation(line: 759, column: 9, scope: !4317)
!4320 = !DILocation(line: 760, column: 16, scope: !4294)
!4321 = !DILocation(line: 760, column: 45, scope: !4294)
!4322 = !DILocation(line: 760, column: 16, scope: !4295)
!4323 = !DILocation(line: 762, column: 21, scope: !4324)
!4324 = distinct !DILexicalBlock(scope: !4325, file: !2, line: 762, column: 13)
!4325 = distinct !DILexicalBlock(scope: !4294, file: !2, line: 760, column: 51)
!4326 = !DILocation(line: 762, column: 13, scope: !4325)
!4327 = !DILocation(line: 763, column: 13, scope: !4324)
!4328 = !DILocation(line: 765, column: 37, scope: !4324)
!4329 = !DILocation(line: 765, column: 47, scope: !4324)
!4330 = !DILocation(line: 765, column: 13, scope: !4324)
!4331 = !DILocation(line: 768, column: 16, scope: !4293)
!4332 = !DILocation(line: 768, column: 47, scope: !4293)
!4333 = !DILocation(line: 768, column: 16, scope: !4294)
!4334 = !DILocation(line: 769, column: 9, scope: !4335)
!4335 = distinct !DILexicalBlock(scope: !4293, file: !2, line: 768, column: 53)
!4336 = !DILocation(line: 770, column: 5, scope: !4335)
!4337 = !DILocation(line: 770, column: 16, scope: !4292)
!4338 = !DILocation(line: 770, column: 48, scope: !4292)
!4339 = !DILocation(line: 770, column: 16, scope: !4293)
!4340 = !DILocation(line: 772, column: 9, scope: !4291)
!4341 = !DILocation(line: 772, column: 33, scope: !4291)
!4342 = distinct !DIAssignID()
!4343 = !DILocation(line: 774, column: 23, scope: !4344)
!4344 = distinct !DILexicalBlock(scope: !4291, file: !2, line: 774, column: 13)
!4345 = !{!1859, !1216, i64 169}
!4346 = !DILocation(line: 774, column: 13, scope: !4291)
!4347 = !DILocation(line: 775, column: 13, scope: !4348)
!4348 = distinct !DILexicalBlock(scope: !4344, file: !2, line: 774, column: 37)
!4349 = !DILocation(line: 776, column: 13, scope: !4348)
!4350 = !DILocation(line: 779, column: 21, scope: !4351)
!4351 = distinct !DILexicalBlock(scope: !4291, file: !2, line: 779, column: 13)
!4352 = !DILocation(line: 779, column: 13, scope: !4291)
!4353 = !DILocation(line: 780, column: 13, scope: !4354)
!4354 = distinct !DILexicalBlock(scope: !4351, file: !2, line: 779, column: 26)
!4355 = !DILocation(line: 781, column: 13, scope: !4354)
!4356 = !DILocation(line: 784, column: 27, scope: !4357)
!4357 = distinct !DILexicalBlock(scope: !4291, file: !2, line: 784, column: 13)
!4358 = !DILocation(line: 784, column: 37, scope: !4357)
!4359 = !DILocation(line: 784, column: 14, scope: !4357)
!4360 = !DILocation(line: 784, column: 49, scope: !4357)
!4361 = !DILocation(line: 785, column: 27, scope: !4357)
!4362 = !DILocation(line: 785, column: 37, scope: !4357)
!4363 = !DILocation(line: 785, column: 14, scope: !4357)
!4364 = !DILocation(line: 784, column: 13, scope: !4291)
!4365 = !DILocation(line: 786, column: 13, scope: !4366)
!4366 = distinct !DILexicalBlock(scope: !4357, file: !2, line: 785, column: 53)
!4367 = !DILocation(line: 787, column: 13, scope: !4366)
!4368 = !DILocation(line: 790, column: 13, scope: !4369)
!4369 = distinct !DILexicalBlock(scope: !4291, file: !2, line: 790, column: 13)
!4370 = !DILocation(line: 790, column: 16, scope: !4369)
!4371 = !DILocation(line: 790, column: 13, scope: !4291)
!4372 = !DILocation(line: 791, column: 13, scope: !4373)
!4373 = distinct !DILexicalBlock(scope: !4369, file: !2, line: 790, column: 47)
!4374 = !DILocation(line: 792, column: 13, scope: !4373)
!4375 = !DILocation(line: 795, column: 34, scope: !4291)
!4376 = !DILocation(line: 795, column: 15, scope: !4291)
!4377 = !DILocation(line: 796, column: 32, scope: !4291)
!4378 = !DILocation(line: 796, column: 9, scope: !4291)
!4379 = !DILocation(line: 797, column: 9, scope: !4291)
!4380 = !DILocation(line: 798, column: 5, scope: !4292)
!4381 = !DILocation(line: 798, column: 16, scope: !4382)
!4382 = distinct !DILexicalBlock(scope: !4292, file: !2, line: 798, column: 16)
!4383 = !DILocation(line: 798, column: 44, scope: !4382)
!4384 = !DILocation(line: 798, column: 16, scope: !4292)
!4385 = !DILocation(line: 799, column: 9, scope: !4386)
!4386 = distinct !DILexicalBlock(scope: !4382, file: !2, line: 798, column: 50)
!4387 = !DILocation(line: 801, column: 5, scope: !4386)
!4388 = !DILocation(line: 801, column: 16, scope: !4389)
!4389 = distinct !DILexicalBlock(scope: !4382, file: !2, line: 801, column: 16)
!4390 = !DILocation(line: 801, column: 47, scope: !4389)
!4391 = !DILocation(line: 801, column: 16, scope: !4382)
!4392 = !DILocation(line: 802, column: 9, scope: !4393)
!4393 = distinct !DILexicalBlock(scope: !4389, file: !2, line: 801, column: 53)
!4394 = !DILocation(line: 815, column: 35, scope: !4395)
!4395 = distinct !DILexicalBlock(scope: !4396, file: !2, line: 815, column: 13)
!4396 = distinct !DILexicalBlock(scope: !4389, file: !2, line: 812, column: 12)
!4397 = !DILocation(line: 815, column: 13, scope: !4395)
!4398 = !DILocation(line: 815, column: 13, scope: !4396)
!4399 = !DILocation(line: 816, column: 20, scope: !4400)
!4400 = distinct !DILexicalBlock(scope: !4401, file: !2, line: 816, column: 17)
!4401 = distinct !DILexicalBlock(scope: !4395, file: !2, line: 815, column: 74)
!4402 = !DILocation(line: 816, column: 26, scope: !4400)
!4403 = !{!1211, !1212, i64 368}
!4404 = !DILocation(line: 816, column: 33, scope: !4400)
!4405 = !DILocation(line: 816, column: 17, scope: !4401)
!4406 = !DILocation(line: 817, column: 17, scope: !4407)
!4407 = distinct !DILexicalBlock(scope: !4400, file: !2, line: 816, column: 42)
!4408 = !DILocation(line: 818, column: 13, scope: !4407)
!4409 = !DILocation(line: 819, column: 61, scope: !4410)
!4410 = distinct !DILexicalBlock(scope: !4400, file: !2, line: 818, column: 20)
!4411 = !{!1211, !1222, i64 384}
!4412 = !DILocation(line: 819, column: 52, scope: !4410)
!4413 = !DILocation(line: 819, column: 17, scope: !4410)
!4414 = !DILocation(line: 820, column: 33, scope: !4410)
!4415 = !DILocation(line: 823, column: 13, scope: !4416)
!4416 = distinct !DILexicalBlock(scope: !4395, file: !2, line: 822, column: 16)
!4417 = !DILocation(line: 829, column: 5, scope: !4284)
!4418 = !DILocation(line: 831, column: 12, scope: !4419)
!4419 = distinct !DILexicalBlock(scope: !4284, file: !2, line: 831, column: 9)
!4420 = !DILocation(line: 831, column: 18, scope: !4419)
!4421 = !DILocation(line: 831, column: 25, scope: !4419)
!4422 = !DILocation(line: 831, column: 9, scope: !4284)
!4423 = !DILocation(line: 832, column: 9, scope: !4424)
!4424 = distinct !DILexicalBlock(scope: !4419, file: !2, line: 831, column: 34)
!4425 = !DILocation(line: 833, column: 5, scope: !4424)
!4426 = !DILocation(line: 834, column: 53, scope: !4427)
!4427 = distinct !DILexicalBlock(scope: !4419, file: !2, line: 833, column: 12)
!4428 = !DILocation(line: 834, column: 44, scope: !4427)
!4429 = !DILocation(line: 834, column: 9, scope: !4427)
!4430 = !DILocation(line: 835, column: 25, scope: !4427)
!4431 = !DILocation(line: 837, column: 1, scope: !4284)
!4432 = distinct !DISubprogram(name: "process_shutdown_command", scope: !2, file: !2, line: 2596, type: !2331, scopeLine: 2596, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !4433)
!4433 = !{!4434, !4435, !4436}
!4434 = !DILocalVariable(name: "c", arg: 1, scope: !4432, file: !2, line: 2596, type: !780)
!4435 = !DILocalVariable(name: "tokens", arg: 2, scope: !4432, file: !2, line: 2596, type: !1544)
!4436 = !DILocalVariable(name: "ntokens", arg: 3, scope: !4432, file: !2, line: 2596, type: !1545)
!4437 = !DILocation(line: 0, scope: !4432)
!4438 = !DILocation(line: 2597, column: 19, scope: !4439)
!4439 = distinct !DILexicalBlock(scope: !4432, file: !2, line: 2597, column: 9)
!4440 = !{!1859, !1216, i64 160}
!4441 = !DILocation(line: 2597, column: 9, scope: !4432)
!4442 = !DILocation(line: 2598, column: 9, scope: !4443)
!4443 = distinct !DILexicalBlock(scope: !4439, file: !2, line: 2597, column: 37)
!4444 = !DILocation(line: 2599, column: 9, scope: !4443)
!4445 = !DILocation(line: 2602, column: 9, scope: !4432)
!4446 = !DILocation(line: 2603, column: 12, scope: !4447)
!4447 = distinct !DILexicalBlock(scope: !4448, file: !2, line: 2602, column: 23)
!4448 = distinct !DILexicalBlock(scope: !4432, file: !2, line: 2602, column: 9)
!4449 = !DILocation(line: 2603, column: 25, scope: !4447)
!4450 = !DILocation(line: 2604, column: 9, scope: !4447)
!4451 = !DILocation(line: 2605, column: 9, scope: !4447)
!4452 = !DILocation(line: 2606, column: 5, scope: !4447)
!4453 = !DILocation(line: 2606, column: 39, scope: !4454)
!4454 = distinct !DILexicalBlock(scope: !4448, file: !2, line: 2606, column: 16)
!4455 = !DILocation(line: 2606, column: 64, scope: !4454)
!4456 = !DILocation(line: 2606, column: 32, scope: !4454)
!4457 = !DILocation(line: 2606, column: 83, scope: !4454)
!4458 = !DILocation(line: 2606, column: 16, scope: !4448)
!4459 = !DILocation(line: 2607, column: 12, scope: !4460)
!4460 = distinct !DILexicalBlock(scope: !4454, file: !2, line: 2606, column: 89)
!4461 = !DILocation(line: 2607, column: 25, scope: !4460)
!4462 = !DILocation(line: 2608, column: 9, scope: !4460)
!4463 = !DILocation(line: 2609, column: 9, scope: !4460)
!4464 = !DILocation(line: 2610, column: 5, scope: !4460)
!4465 = !DILocation(line: 2611, column: 9, scope: !4466)
!4466 = distinct !DILexicalBlock(scope: !4454, file: !2, line: 2610, column: 12)
!4467 = !DILocation(line: 2613, column: 1, scope: !4432)
!4468 = distinct !DISubprogram(name: "process_slabs_command", scope: !2, file: !2, line: 2615, type: !2331, scopeLine: 2615, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !4469)
!4469 = !{!4470, !4471, !4472, !4473, !4476, !4477}
!4470 = !DILocalVariable(name: "c", arg: 1, scope: !4468, file: !2, line: 2615, type: !780)
!4471 = !DILocalVariable(name: "tokens", arg: 2, scope: !4468, file: !2, line: 2615, type: !1544)
!4472 = !DILocalVariable(name: "ntokens", arg: 3, scope: !4468, file: !2, line: 2615, type: !1545)
!4473 = !DILocalVariable(name: "src", scope: !4474, file: !2, line: 2617, type: !598)
!4474 = distinct !DILexicalBlock(scope: !4475, file: !2, line: 2616, column: 83)
!4475 = distinct !DILexicalBlock(scope: !4468, file: !2, line: 2616, column: 9)
!4476 = !DILocalVariable(name: "dst", scope: !4474, file: !2, line: 2617, type: !598)
!4477 = !DILocalVariable(name: "rv", scope: !4474, file: !2, line: 2617, type: !598)
!4478 = distinct !DIAssignID()
!4479 = !DILocalVariable(name: "level", scope: !4480, file: !2, line: 2309, type: !464)
!4480 = distinct !DISubprogram(name: "process_slabs_automove_command", scope: !2, file: !2, line: 2308, type: !2331, scopeLine: 2308, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !4481)
!4481 = !{!4482, !4483, !4484, !4479, !4485}
!4482 = !DILocalVariable(name: "c", arg: 1, scope: !4480, file: !2, line: 2308, type: !780)
!4483 = !DILocalVariable(name: "tokens", arg: 2, scope: !4480, file: !2, line: 2308, type: !1544)
!4484 = !DILocalVariable(name: "ntokens", arg: 3, scope: !4480, file: !2, line: 2308, type: !1545)
!4485 = !DILocalVariable(name: "ratio", scope: !4480, file: !2, line: 2310, type: !4486)
!4486 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!4487 = !DILocation(line: 0, scope: !4480, inlinedAt: !4488)
!4488 = distinct !DILocation(line: 2651, column: 9, scope: !4489)
!4489 = distinct !DILexicalBlock(scope: !4490, file: !2, line: 2650, column: 69)
!4490 = distinct !DILexicalBlock(scope: !4475, file: !2, line: 2649, column: 16)
!4491 = distinct !DIAssignID()
!4492 = distinct !DIAssignID()
!4493 = !DILocation(line: 0, scope: !4474)
!4494 = distinct !DIAssignID()
!4495 = !DILocation(line: 0, scope: !4468)
!4496 = !DILocation(line: 2616, column: 17, scope: !4475)
!4497 = !DILocation(line: 2616, column: 22, scope: !4475)
!4498 = !DILocation(line: 2616, column: 32, scope: !4475)
!4499 = !DILocation(line: 2616, column: 58, scope: !4475)
!4500 = !DILocation(line: 2616, column: 25, scope: !4475)
!4501 = !DILocation(line: 2616, column: 77, scope: !4475)
!4502 = !DILocation(line: 2616, column: 9, scope: !4468)
!4503 = !DILocation(line: 2617, column: 9, scope: !4474)
!4504 = !DILocation(line: 2619, column: 22, scope: !4505)
!4505 = distinct !DILexicalBlock(scope: !4474, file: !2, line: 2619, column: 13)
!4506 = !{!1859, !1216, i64 137}
!4507 = !DILocation(line: 2619, column: 36, scope: !4505)
!4508 = !DILocation(line: 2619, column: 13, scope: !4474)
!4509 = !DILocation(line: 2620, column: 13, scope: !4510)
!4510 = distinct !DILexicalBlock(scope: !4505, file: !2, line: 2619, column: 46)
!4511 = !DILocation(line: 2621, column: 13, scope: !4510)
!4512 = !DILocation(line: 2624, column: 28, scope: !4513)
!4513 = distinct !DILexicalBlock(scope: !4474, file: !2, line: 2624, column: 13)
!4514 = !DILocation(line: 2624, column: 38, scope: !4513)
!4515 = !DILocation(line: 2624, column: 16, scope: !4513)
!4516 = !DILocation(line: 2625, column: 16, scope: !4513)
!4517 = !DILocation(line: 2625, column: 31, scope: !4513)
!4518 = !DILocation(line: 2625, column: 41, scope: !4513)
!4519 = !DILocation(line: 2625, column: 19, scope: !4513)
!4520 = !DILocation(line: 2624, column: 13, scope: !4474)
!4521 = !DILocation(line: 2626, column: 13, scope: !4522)
!4522 = distinct !DILexicalBlock(scope: !4513, file: !2, line: 2625, column: 66)
!4523 = !DILocation(line: 2627, column: 13, scope: !4522)
!4524 = !DILocation(line: 2630, column: 29, scope: !4474)
!4525 = !DILocation(line: 2630, column: 34, scope: !4474)
!4526 = !DILocation(line: 2630, column: 14, scope: !4474)
!4527 = !DILocation(line: 2631, column: 9, scope: !4474)
!4528 = !DILocation(line: 2633, column: 13, scope: !4529)
!4529 = distinct !DILexicalBlock(scope: !4474, file: !2, line: 2631, column: 21)
!4530 = !DILocation(line: 2634, column: 13, scope: !4529)
!4531 = !DILocation(line: 2636, column: 13, scope: !4529)
!4532 = !DILocation(line: 2637, column: 13, scope: !4529)
!4533 = !DILocation(line: 2639, column: 13, scope: !4529)
!4534 = !DILocation(line: 2640, column: 13, scope: !4529)
!4535 = !DILocation(line: 2642, column: 13, scope: !4529)
!4536 = !DILocation(line: 2643, column: 13, scope: !4529)
!4537 = !DILocation(line: 2645, column: 13, scope: !4529)
!4538 = !DILocation(line: 2646, column: 13, scope: !4529)
!4539 = !DILocation(line: 2649, column: 5, scope: !4475)
!4540 = !DILocation(line: 2649, column: 24, scope: !4490)
!4541 = !DILocation(line: 2649, column: 29, scope: !4490)
!4542 = !DILocation(line: 2650, column: 43, scope: !4490)
!4543 = !DILocation(line: 2650, column: 10, scope: !4490)
!4544 = !DILocation(line: 2650, column: 62, scope: !4490)
!4545 = !DILocation(line: 2649, column: 16, scope: !4475)
!4546 = !DILocation(line: 2309, column: 5, scope: !4480, inlinedAt: !4488)
!4547 = !DILocation(line: 2310, column: 5, scope: !4480, inlinedAt: !4488)
!4548 = !DILocation(line: 0, scope: !4140, inlinedAt: !4549)
!4549 = distinct !DILocation(line: 2314, column: 5, scope: !4480, inlinedAt: !4488)
!4550 = !DILocation(line: 516, column: 9, scope: !4150, inlinedAt: !4549)
!4551 = !DILocation(line: 516, column: 31, scope: !4150, inlinedAt: !4549)
!4552 = !DILocation(line: 517, column: 9, scope: !4150, inlinedAt: !4549)
!4553 = !DILocation(line: 517, column: 12, scope: !4150, inlinedAt: !4549)
!4554 = !DILocation(line: 517, column: 59, scope: !4150, inlinedAt: !4549)
!4555 = !DILocation(line: 516, column: 9, scope: !4140, inlinedAt: !4549)
!4556 = !DILocation(line: 518, column: 12, scope: !4157, inlinedAt: !4549)
!4557 = !DILocation(line: 518, column: 20, scope: !4157, inlinedAt: !4549)
!4558 = !DILocation(line: 519, column: 5, scope: !4157, inlinedAt: !4549)
!4559 = !DILocation(line: 2316, column: 16, scope: !4560, inlinedAt: !4488)
!4560 = distinct !DILexicalBlock(scope: !4480, file: !2, line: 2316, column: 9)
!4561 = !DILocation(line: 2316, column: 26, scope: !4560, inlinedAt: !4488)
!4562 = !DILocation(line: 2316, column: 9, scope: !4560, inlinedAt: !4488)
!4563 = !DILocation(line: 2316, column: 42, scope: !4560, inlinedAt: !4488)
!4564 = !DILocation(line: 2316, column: 9, scope: !4480, inlinedAt: !4488)
!4565 = !DILocation(line: 2317, column: 21, scope: !4566, inlinedAt: !4488)
!4566 = distinct !DILexicalBlock(scope: !4567, file: !2, line: 2317, column: 13)
!4567 = distinct !DILexicalBlock(scope: !4560, file: !2, line: 2316, column: 48)
!4568 = !DILocation(line: 2317, column: 25, scope: !4566, inlinedAt: !4488)
!4569 = !DILocation(line: 2317, column: 41, scope: !4566, inlinedAt: !4488)
!4570 = !DILocation(line: 2317, column: 51, scope: !4566, inlinedAt: !4488)
!4571 = !DILocation(line: 2317, column: 29, scope: !4566, inlinedAt: !4488)
!4572 = !DILocation(line: 2317, column: 13, scope: !4567, inlinedAt: !4488)
!4573 = !DILocation(line: 2321, column: 40, scope: !4567, inlinedAt: !4488)
!4574 = !{!1860, !1860, i64 0}
!4575 = !DILocation(line: 2321, column: 38, scope: !4567, inlinedAt: !4488)
!4576 = !{!1859, !1860, i64 144}
!4577 = !DILocation(line: 2322, column: 5, scope: !4567, inlinedAt: !4488)
!4578 = !DILocation(line: 2323, column: 14, scope: !4579, inlinedAt: !4488)
!4579 = distinct !DILexicalBlock(scope: !4580, file: !2, line: 2323, column: 13)
!4580 = distinct !DILexicalBlock(scope: !4560, file: !2, line: 2322, column: 12)
!4581 = !DILocation(line: 2323, column: 13, scope: !4580, inlinedAt: !4488)
!4582 = !DILocation(line: 2327, column: 13, scope: !4583, inlinedAt: !4488)
!4583 = distinct !DILexicalBlock(scope: !4580, file: !2, line: 2327, column: 13)
!4584 = !DILocation(line: 2327, column: 13, scope: !4580, inlinedAt: !4488)
!4585 = !DILocation(line: 2328, column: 36, scope: !4586, inlinedAt: !4488)
!4586 = distinct !DILexicalBlock(scope: !4583, file: !2, line: 2327, column: 25)
!4587 = !{!1859, !1215, i64 140}
!4588 = !DILocation(line: 2329, column: 9, scope: !4586, inlinedAt: !4488)
!4589 = !DILocation(line: 2330, column: 36, scope: !4590, inlinedAt: !4488)
!4590 = distinct !DILexicalBlock(scope: !4591, file: !2, line: 2329, column: 46)
!4591 = distinct !DILexicalBlock(scope: !4583, file: !2, line: 2329, column: 20)
!4592 = !DILocation(line: 2338, column: 1, scope: !4480, inlinedAt: !4488)
!4593 = !DILocation(line: 2652, column: 5, scope: !4489)
!4594 = !DILocation(line: 2653, column: 9, scope: !4595)
!4595 = distinct !DILexicalBlock(scope: !4490, file: !2, line: 2652, column: 12)
!4596 = !DILocation(line: 2655, column: 1, scope: !4468)
!4597 = distinct !DISubprogram(name: "process_memlimit_command", scope: !2, file: !2, line: 2402, type: !2331, scopeLine: 2402, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !4598)
!4598 = !{!4599, !4600, !4601, !4602}
!4599 = !DILocalVariable(name: "c", arg: 1, scope: !4597, file: !2, line: 2402, type: !780)
!4600 = !DILocalVariable(name: "tokens", arg: 2, scope: !4597, file: !2, line: 2402, type: !1544)
!4601 = !DILocalVariable(name: "ntokens", arg: 3, scope: !4597, file: !2, line: 2402, type: !1545)
!4602 = !DILocalVariable(name: "memlimit", scope: !4597, file: !2, line: 2403, type: !635)
!4603 = distinct !DIAssignID()
!4604 = !DILocation(line: 0, scope: !4597)
!4605 = !DILocation(line: 2403, column: 5, scope: !4597)
!4606 = !DILocation(line: 0, scope: !4140, inlinedAt: !4607)
!4607 = distinct !DILocation(line: 2406, column: 5, scope: !4597)
!4608 = !DILocation(line: 516, column: 9, scope: !4150, inlinedAt: !4607)
!4609 = !DILocation(line: 516, column: 31, scope: !4150, inlinedAt: !4607)
!4610 = !DILocation(line: 517, column: 9, scope: !4150, inlinedAt: !4607)
!4611 = !DILocation(line: 517, column: 12, scope: !4150, inlinedAt: !4607)
!4612 = !DILocation(line: 517, column: 59, scope: !4150, inlinedAt: !4607)
!4613 = !DILocation(line: 516, column: 9, scope: !4140, inlinedAt: !4607)
!4614 = !DILocation(line: 518, column: 12, scope: !4157, inlinedAt: !4607)
!4615 = !DILocation(line: 518, column: 20, scope: !4157, inlinedAt: !4607)
!4616 = !DILocation(line: 519, column: 5, scope: !4157, inlinedAt: !4607)
!4617 = !DILocation(line: 2408, column: 23, scope: !4618)
!4618 = distinct !DILexicalBlock(scope: !4597, file: !2, line: 2408, column: 9)
!4619 = !DILocation(line: 2408, column: 33, scope: !4618)
!4620 = !DILocation(line: 2408, column: 10, scope: !4618)
!4621 = !DILocation(line: 2408, column: 9, scope: !4597)
!4622 = !DILocation(line: 2411, column: 13, scope: !4623)
!4623 = distinct !DILexicalBlock(scope: !4624, file: !2, line: 2411, column: 13)
!4624 = distinct !DILexicalBlock(scope: !4618, file: !2, line: 2410, column: 12)
!4625 = !DILocation(line: 2411, column: 22, scope: !4623)
!4626 = !DILocation(line: 2411, column: 13, scope: !4624)
!4627 = !DILocation(line: 2414, column: 26, scope: !4628)
!4628 = distinct !DILexicalBlock(scope: !4629, file: !2, line: 2414, column: 17)
!4629 = distinct !DILexicalBlock(scope: !4623, file: !2, line: 2413, column: 16)
!4630 = !DILocation(line: 2414, column: 17, scope: !4629)
!4631 = !DILocation(line: 2416, column: 47, scope: !4632)
!4632 = distinct !DILexicalBlock(scope: !4628, file: !2, line: 2416, column: 24)
!4633 = !DILocation(line: 2416, column: 72, scope: !4632)
!4634 = !DILocation(line: 2416, column: 24, scope: !4632)
!4635 = !DILocation(line: 2416, column: 24, scope: !4628)
!4636 = !DILocation(line: 2417, column: 30, scope: !4637)
!4637 = distinct !DILexicalBlock(scope: !4638, file: !2, line: 2417, column: 21)
!4638 = distinct !DILexicalBlock(scope: !4632, file: !2, line: 2416, column: 81)
!4639 = !DILocation(line: 2417, column: 38, scope: !4637)
!4640 = !DILocation(line: 2417, column: 21, scope: !4638)
!4641 = !DILocation(line: 2418, column: 29, scope: !4642)
!4642 = distinct !DILexicalBlock(scope: !4637, file: !2, line: 2417, column: 43)
!4643 = !DILocation(line: 2418, column: 89, scope: !4642)
!4644 = !DILocation(line: 2418, column: 69, scope: !4642)
!4645 = !DILocation(line: 2418, column: 21, scope: !4642)
!4646 = !DILocation(line: 2419, column: 17, scope: !4642)
!4647 = !DILocation(line: 0, scope: !4618)
!4648 = !DILocation(line: 2427, column: 1, scope: !4597)
!4649 = distinct !DISubprogram(name: "process_arithmetic_command", scope: !2, file: !2, line: 2141, type: !4650, scopeLine: 2141, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !4653)
!4650 = !DISubroutineType(types: !4651)
!4651 = !{null, !780, !1544, !1545, !4652}
!4652 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !790)
!4653 = !{!4654, !4655, !4656, !4657, !4658, !4659, !4660, !4661}
!4654 = !DILocalVariable(name: "c", arg: 1, scope: !4649, file: !2, line: 2141, type: !780)
!4655 = !DILocalVariable(name: "tokens", arg: 2, scope: !4649, file: !2, line: 2141, type: !1544)
!4656 = !DILocalVariable(name: "ntokens", arg: 3, scope: !4649, file: !2, line: 2141, type: !1545)
!4657 = !DILocalVariable(name: "incr", arg: 4, scope: !4649, file: !2, line: 2141, type: !4652)
!4658 = !DILocalVariable(name: "temp", scope: !4649, file: !2, line: 2142, type: !3342)
!4659 = !DILocalVariable(name: "delta", scope: !4649, file: !2, line: 2143, type: !616)
!4660 = !DILocalVariable(name: "key", scope: !4649, file: !2, line: 2144, type: !579)
!4661 = !DILocalVariable(name: "nkey", scope: !4649, file: !2, line: 2145, type: !747)
!4662 = distinct !DIAssignID()
!4663 = !DILocation(line: 0, scope: !4649)
!4664 = distinct !DIAssignID()
!4665 = !DILocation(line: 2142, column: 5, scope: !4649)
!4666 = !DILocation(line: 2143, column: 5, scope: !4649)
!4667 = !DILocation(line: 0, scope: !4140, inlinedAt: !4668)
!4668 = distinct !DILocation(line: 2149, column: 5, scope: !4649)
!4669 = !DILocation(line: 516, column: 9, scope: !4150, inlinedAt: !4668)
!4670 = !DILocation(line: 516, column: 31, scope: !4150, inlinedAt: !4668)
!4671 = !DILocation(line: 517, column: 9, scope: !4150, inlinedAt: !4668)
!4672 = !DILocation(line: 517, column: 12, scope: !4150, inlinedAt: !4668)
!4673 = !DILocation(line: 517, column: 59, scope: !4150, inlinedAt: !4668)
!4674 = !DILocation(line: 516, column: 9, scope: !4140, inlinedAt: !4668)
!4675 = !DILocation(line: 518, column: 12, scope: !4157, inlinedAt: !4668)
!4676 = !DILocation(line: 518, column: 20, scope: !4157, inlinedAt: !4668)
!4677 = !DILocation(line: 519, column: 5, scope: !4157, inlinedAt: !4668)
!4678 = !DILocation(line: 2151, column: 27, scope: !4679)
!4679 = distinct !DILexicalBlock(scope: !4649, file: !2, line: 2151, column: 9)
!4680 = !DILocation(line: 2151, column: 34, scope: !4679)
!4681 = !DILocation(line: 2151, column: 9, scope: !4649)
!4682 = !DILocation(line: 2152, column: 9, scope: !4683)
!4683 = distinct !DILexicalBlock(scope: !4679, file: !2, line: 2151, column: 52)
!4684 = !DILocation(line: 2153, column: 9, scope: !4683)
!4685 = !DILocation(line: 2151, column: 9, scope: !4679)
!4686 = !DILocation(line: 2156, column: 29, scope: !4649)
!4687 = !DILocation(line: 2159, column: 24, scope: !4688)
!4688 = distinct !DILexicalBlock(scope: !4649, file: !2, line: 2159, column: 9)
!4689 = !DILocation(line: 2159, column: 34, scope: !4688)
!4690 = !DILocation(line: 2159, column: 10, scope: !4688)
!4691 = !DILocation(line: 2159, column: 9, scope: !4649)
!4692 = !DILocation(line: 2160, column: 9, scope: !4693)
!4693 = distinct !DILexicalBlock(scope: !4688, file: !2, line: 2159, column: 50)
!4694 = !DILocation(line: 2161, column: 9, scope: !4693)
!4695 = !DILocation(line: 2164, column: 25, scope: !4649)
!4696 = !DILocation(line: 2164, column: 50, scope: !4649)
!4697 = !DILocation(line: 2164, column: 12, scope: !4649)
!4698 = !DILocation(line: 2164, column: 5, scope: !4649)
!4699 = !DILocation(line: 2166, column: 9, scope: !4700)
!4700 = distinct !DILexicalBlock(scope: !4649, file: !2, line: 2164, column: 70)
!4701 = !DILocation(line: 2167, column: 9, scope: !4700)
!4702 = !DILocation(line: 2169, column: 9, scope: !4700)
!4703 = !DILocation(line: 2170, column: 9, scope: !4700)
!4704 = !DILocation(line: 2172, column: 9, scope: !4700)
!4705 = !DILocation(line: 2173, column: 9, scope: !4700)
!4706 = !DILocation(line: 2175, column: 32, scope: !4700)
!4707 = !DILocation(line: 2175, column: 40, scope: !4700)
!4708 = !DILocation(line: 2175, column: 9, scope: !4700)
!4709 = !DILocation(line: 0, scope: !4710)
!4710 = distinct !DILexicalBlock(scope: !4700, file: !2, line: 2176, column: 13)
!4711 = !DILocation(line: 2181, column: 42, scope: !4700)
!4712 = !DILocation(line: 2181, column: 9, scope: !4700)
!4713 = !DILocation(line: 2183, column: 9, scope: !4700)
!4714 = !DILocation(line: 2184, column: 9, scope: !4700)
!4715 = !DILocation(line: 2188, column: 1, scope: !4649)
!4716 = distinct !DISubprogram(name: "process_delete_command", scope: !2, file: !2, line: 2191, type: !2331, scopeLine: 2191, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !4717)
!4717 = !{!4718, !4719, !4720, !4721, !4722, !4723, !4724, !4725, !4728, !4729, !4730}
!4718 = !DILocalVariable(name: "c", arg: 1, scope: !4716, file: !2, line: 2191, type: !780)
!4719 = !DILocalVariable(name: "tokens", arg: 2, scope: !4716, file: !2, line: 2191, type: !1544)
!4720 = !DILocalVariable(name: "ntokens", arg: 3, scope: !4716, file: !2, line: 2191, type: !1545)
!4721 = !DILocalVariable(name: "key", scope: !4716, file: !2, line: 2192, type: !579)
!4722 = !DILocalVariable(name: "nkey", scope: !4716, file: !2, line: 2193, type: !747)
!4723 = !DILocalVariable(name: "it", scope: !4716, file: !2, line: 2194, type: !1062)
!4724 = !DILocalVariable(name: "hv", scope: !4716, file: !2, line: 2195, type: !635)
!4725 = !DILocalVariable(name: "hold_is_zero", scope: !4726, file: !2, line: 2200, type: !790)
!4726 = distinct !DILexicalBlock(scope: !4727, file: !2, line: 2199, column: 22)
!4727 = distinct !DILexicalBlock(scope: !4716, file: !2, line: 2199, column: 9)
!4728 = !DILocalVariable(name: "sets_noreply", scope: !4726, file: !2, line: 2201, type: !790)
!4729 = !DILocalVariable(name: "valid", scope: !4726, file: !2, line: 2202, type: !790)
!4730 = !DILocalVariable(name: "myl", scope: !4731, file: !2, line: 2231, type: !641)
!4731 = distinct !DILexicalBlock(scope: !4732, file: !2, line: 2231, column: 9)
!4732 = distinct !DILexicalBlock(scope: !4733, file: !2, line: 2225, column: 13)
!4733 = distinct !DILexicalBlock(scope: !4716, file: !2, line: 2225, column: 9)
!4734 = distinct !DIAssignID()
!4735 = !DILocation(line: 0, scope: !4716)
!4736 = !DILocation(line: 2195, column: 5, scope: !4716)
!4737 = !DILocation(line: 2199, column: 17, scope: !4727)
!4738 = !DILocation(line: 2199, column: 9, scope: !4716)
!4739 = !DILocation(line: 2200, column: 36, scope: !4726)
!4740 = !DILocation(line: 2200, column: 56, scope: !4726)
!4741 = !DILocation(line: 2200, column: 68, scope: !4726)
!4742 = !DILocation(line: 0, scope: !4726)
!4743 = !DILocation(line: 0, scope: !4140, inlinedAt: !4744)
!4744 = distinct !DILocation(line: 2201, column: 29, scope: !4726)
!4745 = !DILocation(line: 516, column: 9, scope: !4150, inlinedAt: !4744)
!4746 = !DILocation(line: 516, column: 31, scope: !4150, inlinedAt: !4744)
!4747 = !DILocation(line: 517, column: 9, scope: !4150, inlinedAt: !4744)
!4748 = !DILocation(line: 517, column: 12, scope: !4150, inlinedAt: !4744)
!4749 = !DILocation(line: 517, column: 59, scope: !4150, inlinedAt: !4744)
!4750 = !DILocation(line: 516, column: 9, scope: !4140, inlinedAt: !4744)
!4751 = !DILocation(line: 518, column: 12, scope: !4157, inlinedAt: !4744)
!4752 = !DILocation(line: 518, column: 20, scope: !4157, inlinedAt: !4744)
!4753 = !DILocation(line: 519, column: 5, scope: !4157, inlinedAt: !4744)
!4754 = !DILocation(line: 520, column: 15, scope: !4140, inlinedAt: !4744)
!4755 = !DILocation(line: 2202, column: 36, scope: !4726)
!4756 = !DILocation(line: 2202, column: 53, scope: !4726)
!4757 = !DILocation(line: 2203, column: 46, scope: !4726)
!4758 = !DILocation(line: 2204, column: 13, scope: !4726)
!4759 = !DILocation(line: 2205, column: 13, scope: !4760)
!4760 = distinct !DILexicalBlock(scope: !4761, file: !2, line: 2204, column: 21)
!4761 = distinct !DILexicalBlock(scope: !4726, file: !2, line: 2204, column: 13)
!4762 = !DILocation(line: 2212, column: 11, scope: !4716)
!4763 = !DILocation(line: 2212, column: 29, scope: !4716)
!4764 = !DILocation(line: 2213, column: 30, scope: !4716)
!4765 = !DILocation(line: 2215, column: 13, scope: !4766)
!4766 = distinct !DILexicalBlock(scope: !4716, file: !2, line: 2215, column: 8)
!4767 = !DILocation(line: 2215, column: 8, scope: !4716)
!4768 = !DILocation(line: 2216, column: 9, scope: !4769)
!4769 = distinct !DILexicalBlock(scope: !4766, file: !2, line: 2215, column: 31)
!4770 = !DILocation(line: 2217, column: 9, scope: !4769)
!4771 = !DILocation(line: 2220, column: 18, scope: !4772)
!4772 = distinct !DILexicalBlock(scope: !4716, file: !2, line: 2220, column: 9)
!4773 = !DILocation(line: 2220, column: 9, scope: !4772)
!4774 = !DILocation(line: 2220, column: 9, scope: !4716)
!4775 = !DILocation(line: 2221, column: 9, scope: !4776)
!4776 = distinct !DILexicalBlock(scope: !4772, file: !2, line: 2220, column: 34)
!4777 = !DILocation(line: 2222, column: 5, scope: !4776)
!4778 = !DILocation(line: 2224, column: 40, scope: !4716)
!4779 = !DILocation(line: 2224, column: 10, scope: !4716)
!4780 = !DILocation(line: 2225, column: 9, scope: !4733)
!4781 = !DILocation(line: 0, scope: !4733)
!4782 = !DILocation(line: 2225, column: 9, scope: !4716)
!4783 = !DILocation(line: 2229, column: 26, scope: !4732)
!4784 = !DILocation(line: 2229, column: 37, scope: !4732)
!4785 = !DILocation(line: 2229, column: 53, scope: !4732)
!4786 = !DILocation(line: 2229, column: 64, scope: !4732)
!4787 = !DILocation(line: 2230, column: 42, scope: !4732)
!4788 = !DILocation(line: 2230, column: 9, scope: !4732)
!4789 = !DILocation(line: 0, scope: !4731)
!4790 = !DILocation(line: 2231, column: 9, scope: !4791)
!4791 = distinct !DILexicalBlock(scope: !4731, file: !2, line: 2231, column: 9)
!4792 = !DILocation(line: 2231, column: 9, scope: !4793)
!4793 = distinct !DILexicalBlock(scope: !4731, file: !2, line: 2231, column: 9)
!4794 = !DILocation(line: 2231, column: 9, scope: !4731)
!4795 = !DILocation(line: 2232, column: 28, scope: !4732)
!4796 = !DILocation(line: 2232, column: 9, scope: !4732)
!4797 = !DILocation(line: 2233, column: 9, scope: !4798)
!4798 = distinct !DILexicalBlock(scope: !4732, file: !2, line: 2233, column: 9)
!4799 = !DILocation(line: 2234, column: 9, scope: !4732)
!4800 = !DILocation(line: 2236, column: 5, scope: !4732)
!4801 = !DILocation(line: 2238, column: 26, scope: !4802)
!4802 = distinct !DILexicalBlock(scope: !4733, file: !2, line: 2236, column: 12)
!4803 = !DILocation(line: 2238, column: 39, scope: !4802)
!4804 = !DILocation(line: 2239, column: 42, scope: !4802)
!4805 = !DILocation(line: 2239, column: 9, scope: !4802)
!4806 = !DILocation(line: 2243, column: 17, scope: !4716)
!4807 = !DILocation(line: 2243, column: 5, scope: !4716)
!4808 = !DILocation(line: 2244, column: 1, scope: !4716)
!4809 = distinct !DISubprogram(name: "process_touch_command", scope: !2, file: !2, line: 2097, type: !2331, scopeLine: 2097, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !4810)
!4810 = !{!4811, !4812, !4813, !4814, !4815, !4816, !4817, !4818}
!4811 = !DILocalVariable(name: "c", arg: 1, scope: !4809, file: !2, line: 2097, type: !780)
!4812 = !DILocalVariable(name: "tokens", arg: 2, scope: !4809, file: !2, line: 2097, type: !1544)
!4813 = !DILocalVariable(name: "ntokens", arg: 3, scope: !4809, file: !2, line: 2097, type: !1545)
!4814 = !DILocalVariable(name: "key", scope: !4809, file: !2, line: 2098, type: !579)
!4815 = !DILocalVariable(name: "nkey", scope: !4809, file: !2, line: 2099, type: !747)
!4816 = !DILocalVariable(name: "exptime_int", scope: !4809, file: !2, line: 2100, type: !638)
!4817 = !DILocalVariable(name: "exptime", scope: !4809, file: !2, line: 2101, type: !595)
!4818 = !DILocalVariable(name: "it", scope: !4809, file: !2, line: 2102, type: !1062)
!4819 = distinct !DIAssignID()
!4820 = !DILocation(line: 0, scope: !4809)
!4821 = !DILocation(line: 2100, column: 5, scope: !4809)
!4822 = !DILocation(line: 2100, column: 13, scope: !4809)
!4823 = distinct !DIAssignID()
!4824 = !DILocation(line: 0, scope: !4140, inlinedAt: !4825)
!4825 = distinct !DILocation(line: 2106, column: 5, scope: !4809)
!4826 = !DILocation(line: 516, column: 9, scope: !4150, inlinedAt: !4825)
!4827 = !DILocation(line: 516, column: 31, scope: !4150, inlinedAt: !4825)
!4828 = !DILocation(line: 517, column: 9, scope: !4150, inlinedAt: !4825)
!4829 = !DILocation(line: 517, column: 12, scope: !4150, inlinedAt: !4825)
!4830 = !DILocation(line: 517, column: 59, scope: !4150, inlinedAt: !4825)
!4831 = !DILocation(line: 516, column: 9, scope: !4140, inlinedAt: !4825)
!4832 = !DILocation(line: 518, column: 12, scope: !4157, inlinedAt: !4825)
!4833 = !DILocation(line: 518, column: 20, scope: !4157, inlinedAt: !4825)
!4834 = !DILocation(line: 519, column: 5, scope: !4157, inlinedAt: !4825)
!4835 = !DILocation(line: 2108, column: 27, scope: !4836)
!4836 = distinct !DILexicalBlock(scope: !4809, file: !2, line: 2108, column: 9)
!4837 = !DILocation(line: 2108, column: 34, scope: !4836)
!4838 = !DILocation(line: 2108, column: 9, scope: !4809)
!4839 = !DILocation(line: 2109, column: 9, scope: !4840)
!4840 = distinct !DILexicalBlock(scope: !4836, file: !2, line: 2108, column: 52)
!4841 = !DILocation(line: 2110, column: 9, scope: !4840)
!4842 = !DILocation(line: 2108, column: 9, scope: !4836)
!4843 = !DILocation(line: 2113, column: 29, scope: !4809)
!4844 = !DILocation(line: 2116, column: 22, scope: !4845)
!4845 = distinct !DILexicalBlock(scope: !4809, file: !2, line: 2116, column: 9)
!4846 = !DILocation(line: 2116, column: 32, scope: !4845)
!4847 = !DILocation(line: 2116, column: 10, scope: !4845)
!4848 = !DILocation(line: 2116, column: 9, scope: !4809)
!4849 = !DILocation(line: 2117, column: 9, scope: !4850)
!4850 = distinct !DILexicalBlock(scope: !4845, file: !2, line: 2116, column: 54)
!4851 = !DILocation(line: 2118, column: 9, scope: !4850)
!4852 = !DILocation(line: 2121, column: 24, scope: !4809)
!4853 = !DILocation(line: 2121, column: 15, scope: !4809)
!4854 = !DILocation(line: 2122, column: 44, scope: !4809)
!4855 = !DILocation(line: 2122, column: 10, scope: !4809)
!4856 = !DILocation(line: 2123, column: 9, scope: !4857)
!4857 = distinct !DILexicalBlock(scope: !4809, file: !2, line: 2123, column: 9)
!4858 = !DILocation(line: 0, scope: !4857)
!4859 = !DILocation(line: 2123, column: 9, scope: !4809)
!4860 = !DILocation(line: 2126, column: 26, scope: !4861)
!4861 = distinct !DILexicalBlock(scope: !4857, file: !2, line: 2123, column: 13)
!4862 = !DILocation(line: 2126, column: 37, scope: !4861)
!4863 = !DILocation(line: 2126, column: 53, scope: !4861)
!4864 = !DILocation(line: 2126, column: 63, scope: !4861)
!4865 = !{!1244, !1222, i64 16}
!4866 = !DILocation(line: 2127, column: 42, scope: !4861)
!4867 = !DILocation(line: 2127, column: 9, scope: !4861)
!4868 = !DILocation(line: 2129, column: 9, scope: !4861)
!4869 = !DILocation(line: 2130, column: 9, scope: !4861)
!4870 = !DILocation(line: 2131, column: 5, scope: !4861)
!4871 = !DILocation(line: 2134, column: 26, scope: !4872)
!4872 = distinct !DILexicalBlock(scope: !4857, file: !2, line: 2131, column: 12)
!4873 = !DILocation(line: 2134, column: 38, scope: !4872)
!4874 = !{!1316, !1222, i64 432}
!4875 = !DILocation(line: 2135, column: 42, scope: !4872)
!4876 = !DILocation(line: 2135, column: 9, scope: !4872)
!4877 = !DILocation(line: 2137, column: 9, scope: !4872)
!4878 = !DILocation(line: 2139, column: 1, scope: !4809)
!4879 = distinct !DISubprogram(name: "process_flush_all_command", scope: !2, file: !2, line: 2546, type: !2331, scopeLine: 2546, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !4880)
!4880 = !{!4881, !4882, !4883, !4884, !4885}
!4881 = !DILocalVariable(name: "c", arg: 1, scope: !4879, file: !2, line: 2546, type: !780)
!4882 = !DILocalVariable(name: "tokens", arg: 2, scope: !4879, file: !2, line: 2546, type: !1544)
!4883 = !DILocalVariable(name: "ntokens", arg: 3, scope: !4879, file: !2, line: 2546, type: !1545)
!4884 = !DILocalVariable(name: "exptime", scope: !4879, file: !2, line: 2547, type: !638)
!4885 = !DILocalVariable(name: "new_oldest", scope: !4879, file: !2, line: 2548, type: !595)
!4886 = distinct !DIAssignID()
!4887 = !DILocation(line: 0, scope: !4879)
!4888 = !DILocation(line: 2547, column: 5, scope: !4879)
!4889 = !DILocation(line: 2547, column: 13, scope: !4879)
!4890 = distinct !DIAssignID()
!4891 = !DILocation(line: 0, scope: !4140, inlinedAt: !4892)
!4892 = distinct !DILocation(line: 2550, column: 5, scope: !4879)
!4893 = !DILocation(line: 516, column: 9, scope: !4150, inlinedAt: !4892)
!4894 = !DILocation(line: 516, column: 31, scope: !4150, inlinedAt: !4892)
!4895 = !DILocation(line: 517, column: 9, scope: !4150, inlinedAt: !4892)
!4896 = !DILocation(line: 517, column: 12, scope: !4150, inlinedAt: !4892)
!4897 = !DILocation(line: 517, column: 59, scope: !4150, inlinedAt: !4892)
!4898 = !DILocation(line: 516, column: 9, scope: !4140, inlinedAt: !4892)
!4899 = !DILocation(line: 518, column: 12, scope: !4157, inlinedAt: !4892)
!4900 = !DILocation(line: 518, column: 20, scope: !4157, inlinedAt: !4892)
!4901 = !DILocation(line: 519, column: 5, scope: !4157, inlinedAt: !4892)
!4902 = !DILocation(line: 2552, column: 28, scope: !4879)
!4903 = !DILocation(line: 2552, column: 36, scope: !4879)
!4904 = !DILocation(line: 2552, column: 5, scope: !4879)
!4905 = !DILocation(line: 2553, column: 8, scope: !4879)
!4906 = !DILocation(line: 2553, column: 22, scope: !4879)
!4907 = !DILocation(line: 2553, column: 32, scope: !4879)
!4908 = !{!1316, !1222, i64 496}
!4909 = !DILocation(line: 2554, column: 38, scope: !4879)
!4910 = !DILocation(line: 2554, column: 5, scope: !4879)
!4911 = !DILocation(line: 2556, column: 19, scope: !4912)
!4912 = distinct !DILexicalBlock(scope: !4879, file: !2, line: 2556, column: 9)
!4913 = !{!1859, !1216, i64 168}
!4914 = !DILocation(line: 2556, column: 9, scope: !4879)
!4915 = !DILocation(line: 2558, column: 9, scope: !4916)
!4916 = distinct !DILexicalBlock(scope: !4912, file: !2, line: 2556, column: 34)
!4917 = !DILocation(line: 2559, column: 9, scope: !4916)
!4918 = !DILocation(line: 520, column: 15, scope: !4140, inlinedAt: !4892)
!4919 = !DILocation(line: 2562, column: 24, scope: !4920)
!4920 = distinct !DILexicalBlock(scope: !4879, file: !2, line: 2562, column: 9)
!4921 = !DILocation(line: 2562, column: 21, scope: !4920)
!4922 = !DILocation(line: 2562, column: 17, scope: !4920)
!4923 = !DILocation(line: 2562, column: 9, scope: !4879)
!4924 = !DILocation(line: 2563, column: 26, scope: !4925)
!4925 = distinct !DILexicalBlock(scope: !4926, file: !2, line: 2563, column: 13)
!4926 = distinct !DILexicalBlock(scope: !4920, file: !2, line: 2562, column: 42)
!4927 = !DILocation(line: 2563, column: 36, scope: !4925)
!4928 = !DILocation(line: 2563, column: 14, scope: !4925)
!4929 = !DILocation(line: 2563, column: 13, scope: !4926)
!4930 = !DILocation(line: 2564, column: 13, scope: !4931)
!4931 = distinct !DILexicalBlock(scope: !4925, file: !2, line: 2563, column: 54)
!4932 = !DILocation(line: 2565, column: 13, scope: !4931)
!4933 = !DILocation(line: 2575, column: 9, scope: !4934)
!4934 = distinct !DILexicalBlock(scope: !4879, file: !2, line: 2575, column: 9)
!4935 = !DILocation(line: 2575, column: 17, scope: !4934)
!4936 = !DILocation(line: 2575, column: 9, scope: !4879)
!4937 = !DILocation(line: 2576, column: 22, scope: !4938)
!4938 = distinct !DILexicalBlock(scope: !4934, file: !2, line: 2575, column: 22)
!4939 = !DILocation(line: 2577, column: 5, scope: !4938)
!4940 = !DILocation(line: 2578, column: 22, scope: !4941)
!4941 = distinct !DILexicalBlock(scope: !4934, file: !2, line: 2577, column: 12)
!4942 = !DILocation(line: 0, scope: !4934)
!4943 = !DILocation(line: 2581, column: 26, scope: !4879)
!4944 = !{!1859, !1215, i64 36}
!4945 = !DILocation(line: 2582, column: 5, scope: !4879)
!4946 = !DILocation(line: 2583, column: 5, scope: !4879)
!4947 = !DILocation(line: 2584, column: 1, scope: !4879)
!4948 = distinct !DISubprogram(name: "process_lru_crawler_command", scope: !2, file: !2, line: 2657, type: !2331, scopeLine: 2657, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !4949)
!4949 = !{!4950, !4951, !4952, !4953, !4956, !4959, !4962, !4965}
!4950 = !DILocalVariable(name: "c", arg: 1, scope: !4948, file: !2, line: 2657, type: !780)
!4951 = !DILocalVariable(name: "tokens", arg: 2, scope: !4948, file: !2, line: 2657, type: !1544)
!4952 = !DILocalVariable(name: "ntokens", arg: 3, scope: !4948, file: !2, line: 2657, type: !1545)
!4953 = !DILocalVariable(name: "rv", scope: !4954, file: !2, line: 2659, type: !598)
!4954 = distinct !DILexicalBlock(scope: !4955, file: !2, line: 2658, column: 80)
!4955 = distinct !DILexicalBlock(scope: !4948, file: !2, line: 2658, column: 9)
!4956 = !DILocalVariable(name: "rv", scope: !4957, file: !2, line: 2699, type: !598)
!4957 = distinct !DILexicalBlock(scope: !4958, file: !2, line: 2685, column: 90)
!4958 = distinct !DILexicalBlock(scope: !4955, file: !2, line: 2685, column: 16)
!4959 = !DILocalVariable(name: "rv", scope: !4960, file: !2, line: 2740, type: !598)
!4960 = distinct !DILexicalBlock(scope: !4961, file: !2, line: 2726, column: 88)
!4961 = distinct !DILexicalBlock(scope: !4958, file: !2, line: 2726, column: 16)
!4962 = !DILocalVariable(name: "tocrawl", scope: !4963, file: !2, line: 2762, type: !635)
!4963 = distinct !DILexicalBlock(scope: !4964, file: !2, line: 2761, column: 89)
!4964 = distinct !DILexicalBlock(scope: !4961, file: !2, line: 2761, column: 16)
!4965 = !DILocalVariable(name: "tosleep", scope: !4966, file: !2, line: 2771, type: !635)
!4966 = distinct !DILexicalBlock(scope: !4967, file: !2, line: 2770, column: 87)
!4967 = distinct !DILexicalBlock(scope: !4964, file: !2, line: 2770, column: 16)
!4968 = distinct !DIAssignID()
!4969 = !DILocation(line: 0, scope: !4963)
!4970 = distinct !DIAssignID()
!4971 = !DILocation(line: 0, scope: !4966)
!4972 = !DILocation(line: 0, scope: !4948)
!4973 = !DILocation(line: 2658, column: 22, scope: !4955)
!4974 = !DILocation(line: 2658, column: 32, scope: !4955)
!4975 = !DILocation(line: 2658, column: 58, scope: !4955)
!4976 = !DILocation(line: 2658, column: 25, scope: !4955)
!4977 = !DILocation(line: 2658, column: 74, scope: !4955)
!4978 = !DILocation(line: 2658, column: 9, scope: !4948)
!4979 = !DILocation(line: 2660, column: 22, scope: !4980)
!4980 = distinct !DILexicalBlock(scope: !4954, file: !2, line: 2660, column: 13)
!4981 = !{!1859, !1216, i64 134}
!4982 = !DILocation(line: 2660, column: 34, scope: !4980)
!4983 = !DILocation(line: 2660, column: 13, scope: !4954)
!4984 = !DILocation(line: 2661, column: 13, scope: !4985)
!4985 = distinct !DILexicalBlock(scope: !4980, file: !2, line: 2660, column: 44)
!4986 = !DILocation(line: 2662, column: 13, scope: !4985)
!4987 = !DILocation(line: 2665, column: 32, scope: !4954)
!4988 = !DILocation(line: 2665, column: 42, scope: !4954)
!4989 = !DILocation(line: 2666, column: 26, scope: !4954)
!4990 = !{!1859, !1215, i64 188}
!4991 = !DILocation(line: 2665, column: 14, scope: !4954)
!4992 = !DILocation(line: 0, scope: !4954)
!4993 = !DILocation(line: 2667, column: 9, scope: !4954)
!4994 = !DILocation(line: 2669, column: 13, scope: !4995)
!4995 = distinct !DILexicalBlock(scope: !4954, file: !2, line: 2667, column: 20)
!4996 = !DILocation(line: 2670, column: 13, scope: !4995)
!4997 = !DILocation(line: 2672, column: 13, scope: !4995)
!4998 = !DILocation(line: 2673, column: 13, scope: !4995)
!4999 = !DILocation(line: 2675, column: 13, scope: !4995)
!5000 = !DILocation(line: 2676, column: 13, scope: !4995)
!5001 = !DILocation(line: 2678, column: 13, scope: !4995)
!5002 = !DILocation(line: 2679, column: 13, scope: !4995)
!5003 = !DILocation(line: 2681, column: 13, scope: !4995)
!5004 = !DILocation(line: 2682, column: 13, scope: !4995)
!5005 = !DILocation(line: 2685, column: 32, scope: !4958)
!5006 = !DILocation(line: 2685, column: 84, scope: !4958)
!5007 = !DILocation(line: 2685, column: 16, scope: !4955)
!5008 = !DILocation(line: 2686, column: 22, scope: !5009)
!5009 = distinct !DILexicalBlock(scope: !4957, file: !2, line: 2686, column: 13)
!5010 = !DILocation(line: 2686, column: 34, scope: !5009)
!5011 = !DILocation(line: 2686, column: 13, scope: !4957)
!5012 = !DILocation(line: 2687, column: 13, scope: !5013)
!5013 = distinct !DILexicalBlock(scope: !5009, file: !2, line: 2686, column: 44)
!5014 = !DILocation(line: 2688, column: 13, scope: !5013)
!5015 = !DILocation(line: 2690, column: 23, scope: !5016)
!5016 = distinct !DILexicalBlock(scope: !4957, file: !2, line: 2690, column: 13)
!5017 = !DILocation(line: 2690, column: 13, scope: !4957)
!5018 = !DILocation(line: 2691, column: 13, scope: !5019)
!5019 = distinct !DILexicalBlock(scope: !5016, file: !2, line: 2690, column: 37)
!5020 = !DILocation(line: 2692, column: 13, scope: !5019)
!5021 = !DILocation(line: 2694, column: 13, scope: !5022)
!5022 = distinct !DILexicalBlock(scope: !4957, file: !2, line: 2694, column: 13)
!5023 = !DILocation(line: 2694, column: 13, scope: !4957)
!5024 = !DILocation(line: 2695, column: 13, scope: !5025)
!5025 = distinct !DILexicalBlock(scope: !5022, file: !2, line: 2694, column: 32)
!5026 = !DILocation(line: 2696, column: 13, scope: !5025)
!5027 = !DILocation(line: 2699, column: 36, scope: !4957)
!5028 = !DILocation(line: 2699, column: 46, scope: !4957)
!5029 = !DILocation(line: 2700, column: 23, scope: !4957)
!5030 = !DILocation(line: 2699, column: 18, scope: !4957)
!5031 = !DILocation(line: 0, scope: !4957)
!5032 = !DILocation(line: 2701, column: 9, scope: !4957)
!5033 = !DILocation(line: 2709, column: 17, scope: !5034)
!5034 = distinct !DILexicalBlock(scope: !4957, file: !2, line: 2701, column: 20)
!5035 = !DILocation(line: 2710, column: 31, scope: !5034)
!5036 = !DILocation(line: 2710, column: 17, scope: !5034)
!5037 = !DILocation(line: 2711, column: 17, scope: !5034)
!5038 = !DILocation(line: 2713, column: 17, scope: !5034)
!5039 = !DILocation(line: 2714, column: 17, scope: !5034)
!5040 = !DILocation(line: 2716, column: 17, scope: !5034)
!5041 = !DILocation(line: 2717, column: 17, scope: !5034)
!5042 = !DILocation(line: 2719, column: 17, scope: !5034)
!5043 = !DILocation(line: 2720, column: 17, scope: !5034)
!5044 = !DILocation(line: 2722, column: 17, scope: !5034)
!5045 = !DILocation(line: 2723, column: 17, scope: !5034)
!5046 = !DILocation(line: 2726, column: 32, scope: !4961)
!5047 = !DILocation(line: 2726, column: 82, scope: !4961)
!5048 = !DILocation(line: 2726, column: 16, scope: !4958)
!5049 = !DILocation(line: 2727, column: 22, scope: !5050)
!5050 = distinct !DILexicalBlock(scope: !4960, file: !2, line: 2727, column: 13)
!5051 = !DILocation(line: 2727, column: 34, scope: !5050)
!5052 = !DILocation(line: 2727, column: 13, scope: !4960)
!5053 = !DILocation(line: 2728, column: 13, scope: !5054)
!5054 = distinct !DILexicalBlock(scope: !5050, file: !2, line: 2727, column: 44)
!5055 = !DILocation(line: 2729, column: 13, scope: !5054)
!5056 = !DILocation(line: 2731, column: 23, scope: !5057)
!5057 = distinct !DILexicalBlock(scope: !4960, file: !2, line: 2731, column: 13)
!5058 = !DILocation(line: 2731, column: 13, scope: !4960)
!5059 = !DILocation(line: 2732, column: 13, scope: !5060)
!5060 = distinct !DILexicalBlock(scope: !5057, file: !2, line: 2731, column: 37)
!5061 = !DILocation(line: 2733, column: 13, scope: !5060)
!5062 = !DILocation(line: 2735, column: 13, scope: !5063)
!5063 = distinct !DILexicalBlock(scope: !4960, file: !2, line: 2735, column: 13)
!5064 = !DILocation(line: 2735, column: 13, scope: !4960)
!5065 = !DILocation(line: 2736, column: 13, scope: !5066)
!5066 = distinct !DILexicalBlock(scope: !5063, file: !2, line: 2735, column: 32)
!5067 = !DILocation(line: 2737, column: 13, scope: !5066)
!5068 = !DILocation(line: 2740, column: 36, scope: !4960)
!5069 = !DILocation(line: 2740, column: 46, scope: !4960)
!5070 = !DILocation(line: 2741, column: 23, scope: !4960)
!5071 = !DILocation(line: 2740, column: 18, scope: !4960)
!5072 = !DILocation(line: 0, scope: !4960)
!5073 = !DILocation(line: 2742, column: 9, scope: !4960)
!5074 = !DILocation(line: 2744, column: 17, scope: !5075)
!5075 = distinct !DILexicalBlock(scope: !4960, file: !2, line: 2742, column: 20)
!5076 = !DILocation(line: 2745, column: 31, scope: !5075)
!5077 = !DILocation(line: 2745, column: 17, scope: !5075)
!5078 = !DILocation(line: 2746, column: 17, scope: !5075)
!5079 = !DILocation(line: 2748, column: 17, scope: !5075)
!5080 = !DILocation(line: 2749, column: 17, scope: !5075)
!5081 = !DILocation(line: 2751, column: 17, scope: !5075)
!5082 = !DILocation(line: 2752, column: 17, scope: !5075)
!5083 = !DILocation(line: 2754, column: 17, scope: !5075)
!5084 = !DILocation(line: 2755, column: 17, scope: !5075)
!5085 = !DILocation(line: 2757, column: 17, scope: !5075)
!5086 = !DILocation(line: 2758, column: 17, scope: !5075)
!5087 = !DILocation(line: 2761, column: 32, scope: !4964)
!5088 = !DILocation(line: 2761, column: 83, scope: !4964)
!5089 = !DILocation(line: 2761, column: 16, scope: !4961)
!5090 = !DILocation(line: 2762, column: 9, scope: !4963)
!5091 = !DILocation(line: 2763, column: 28, scope: !5092)
!5092 = distinct !DILexicalBlock(scope: !4963, file: !2, line: 2763, column: 14)
!5093 = !DILocation(line: 2763, column: 38, scope: !5092)
!5094 = !DILocation(line: 2763, column: 15, scope: !5092)
!5095 = !DILocation(line: 2763, column: 14, scope: !4963)
!5096 = !DILocation(line: 2767, column: 40, scope: !4963)
!5097 = !DILocation(line: 2767, column: 38, scope: !4963)
!5098 = !DILocation(line: 2769, column: 9, scope: !4963)
!5099 = !DILocation(line: 2770, column: 5, scope: !4964)
!5100 = !DILocation(line: 2770, column: 32, scope: !4967)
!5101 = !DILocation(line: 2770, column: 81, scope: !4967)
!5102 = !DILocation(line: 2770, column: 16, scope: !4964)
!5103 = !DILocation(line: 2771, column: 9, scope: !4966)
!5104 = !DILocation(line: 2772, column: 27, scope: !5105)
!5105 = distinct !DILexicalBlock(scope: !4966, file: !2, line: 2772, column: 13)
!5106 = !DILocation(line: 2772, column: 37, scope: !5105)
!5107 = !DILocation(line: 2772, column: 14, scope: !5105)
!5108 = !DILocation(line: 2772, column: 13, scope: !4966)
!5109 = !DILocation(line: 2776, column: 13, scope: !5110)
!5110 = distinct !DILexicalBlock(scope: !4966, file: !2, line: 2776, column: 13)
!5111 = !DILocation(line: 2776, column: 21, scope: !5110)
!5112 = !DILocation(line: 2776, column: 13, scope: !4966)
!5113 = !DILocation(line: 2780, column: 36, scope: !4966)
!5114 = !{!1859, !1215, i64 184}
!5115 = !DILocation(line: 2782, column: 9, scope: !4966)
!5116 = !DILocation(line: 2783, column: 5, scope: !4967)
!5117 = !DILocation(line: 2784, column: 21, scope: !5118)
!5118 = distinct !DILexicalBlock(scope: !5119, file: !2, line: 2784, column: 13)
!5119 = distinct !DILexicalBlock(scope: !5120, file: !2, line: 2783, column: 30)
!5120 = distinct !DILexicalBlock(scope: !4967, file: !2, line: 2783, column: 16)
!5121 = !DILocation(line: 2784, column: 47, scope: !5118)
!5122 = !DILocation(line: 2784, column: 14, scope: !5118)
!5123 = !DILocation(line: 2784, column: 64, scope: !5118)
!5124 = !DILocation(line: 2784, column: 13, scope: !5119)
!5125 = !DILocation(line: 2785, column: 17, scope: !5126)
!5126 = distinct !DILexicalBlock(scope: !5127, file: !2, line: 2785, column: 17)
!5127 = distinct !DILexicalBlock(scope: !5118, file: !2, line: 2784, column: 71)
!5128 = !DILocation(line: 2785, column: 45, scope: !5126)
!5129 = !DILocation(line: 2785, column: 17, scope: !5127)
!5130 = !DILocation(line: 2786, column: 17, scope: !5131)
!5131 = distinct !DILexicalBlock(scope: !5126, file: !2, line: 2785, column: 51)
!5132 = !DILocation(line: 2787, column: 13, scope: !5131)
!5133 = !DILocation(line: 2788, column: 17, scope: !5134)
!5134 = distinct !DILexicalBlock(scope: !5126, file: !2, line: 2787, column: 20)
!5135 = !DILocation(line: 2790, column: 21, scope: !5136)
!5136 = distinct !DILexicalBlock(scope: !5118, file: !2, line: 2790, column: 20)
!5137 = !DILocation(line: 2790, column: 72, scope: !5136)
!5138 = !DILocation(line: 2790, column: 20, scope: !5118)
!5139 = !DILocation(line: 2791, column: 17, scope: !5140)
!5140 = distinct !DILexicalBlock(scope: !5141, file: !2, line: 2791, column: 17)
!5141 = distinct !DILexicalBlock(scope: !5136, file: !2, line: 2790, column: 79)
!5142 = !DILocation(line: 2791, column: 58, scope: !5140)
!5143 = !DILocation(line: 2791, column: 17, scope: !5141)
!5144 = !DILocation(line: 2792, column: 17, scope: !5145)
!5145 = distinct !DILexicalBlock(scope: !5140, file: !2, line: 2791, column: 64)
!5146 = !DILocation(line: 2793, column: 13, scope: !5145)
!5147 = !DILocation(line: 2794, column: 17, scope: !5148)
!5148 = distinct !DILexicalBlock(scope: !5140, file: !2, line: 2793, column: 20)
!5149 = !DILocation(line: 2797, column: 13, scope: !5150)
!5150 = distinct !DILexicalBlock(scope: !5136, file: !2, line: 2796, column: 16)
!5151 = !DILocation(line: 2801, column: 9, scope: !5152)
!5152 = distinct !DILexicalBlock(scope: !5120, file: !2, line: 2800, column: 12)
!5153 = !DILocation(line: 2803, column: 1, scope: !4948)
!5154 = distinct !DISubprogram(name: "process_watch_command", scope: !2, file: !2, line: 2341, type: !2331, scopeLine: 2341, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !5155)
!5155 = !{!5156, !5157, !5158, !5159, !5160}
!5156 = !DILocalVariable(name: "c", arg: 1, scope: !5154, file: !2, line: 2341, type: !780)
!5157 = !DILocalVariable(name: "tokens", arg: 2, scope: !5154, file: !2, line: 2341, type: !1544)
!5158 = !DILocalVariable(name: "ntokens", arg: 3, scope: !5154, file: !2, line: 2341, type: !1545)
!5159 = !DILocalVariable(name: "f", scope: !5154, file: !2, line: 2342, type: !602)
!5160 = !DILocalVariable(name: "x", scope: !5154, file: !2, line: 2343, type: !598)
!5161 = !DILocation(line: 0, scope: !5154)
!5162 = !DILocation(line: 0, scope: !4140, inlinedAt: !5163)
!5163 = distinct !DILocation(line: 2346, column: 5, scope: !5154)
!5164 = !DILocation(line: 516, column: 9, scope: !4150, inlinedAt: !5163)
!5165 = !DILocation(line: 516, column: 31, scope: !4150, inlinedAt: !5163)
!5166 = !DILocation(line: 517, column: 9, scope: !4150, inlinedAt: !5163)
!5167 = !DILocation(line: 517, column: 12, scope: !4150, inlinedAt: !5163)
!5168 = !DILocation(line: 517, column: 59, scope: !4150, inlinedAt: !5163)
!5169 = !DILocation(line: 516, column: 9, scope: !4140, inlinedAt: !5163)
!5170 = !DILocation(line: 518, column: 12, scope: !4157, inlinedAt: !5163)
!5171 = !DILocation(line: 518, column: 20, scope: !4157, inlinedAt: !5163)
!5172 = !DILocation(line: 519, column: 5, scope: !4157, inlinedAt: !5163)
!5173 = !DILocation(line: 2347, column: 19, scope: !5174)
!5174 = distinct !DILexicalBlock(scope: !5154, file: !2, line: 2347, column: 9)
!5175 = !{!1859, !1216, i64 245}
!5176 = !DILocation(line: 2347, column: 9, scope: !5154)
!5177 = !DILocation(line: 2348, column: 9, scope: !5178)
!5178 = distinct !DILexicalBlock(scope: !5174, file: !2, line: 2347, column: 34)
!5179 = !DILocation(line: 2349, column: 9, scope: !5178)
!5180 = !DILocation(line: 2352, column: 9, scope: !5181)
!5181 = distinct !DILexicalBlock(scope: !5154, file: !2, line: 2352, column: 9)
!5182 = !DILocation(line: 2352, column: 9, scope: !5154)
!5183 = !DILocation(line: 2353, column: 9, scope: !5184)
!5184 = distinct !DILexicalBlock(scope: !5181, file: !2, line: 2352, column: 28)
!5185 = !DILocation(line: 2354, column: 9, scope: !5184)
!5186 = !DILocation(line: 2357, column: 17, scope: !5187)
!5187 = distinct !DILexicalBlock(scope: !5154, file: !2, line: 2357, column: 9)
!5188 = !DILocation(line: 2357, column: 9, scope: !5154)
!5189 = !DILocation(line: 2358, column: 9, scope: !5190)
!5190 = distinct !DILexicalBlock(scope: !5191, file: !2, line: 2358, column: 9)
!5191 = distinct !DILexicalBlock(scope: !5187, file: !2, line: 2357, column: 22)
!5192 = !DILocation(line: 2359, column: 25, scope: !5193)
!5193 = distinct !DILexicalBlock(scope: !5194, file: !2, line: 2359, column: 17)
!5194 = distinct !DILexicalBlock(scope: !5195, file: !2, line: 2358, column: 59)
!5195 = distinct !DILexicalBlock(scope: !5190, file: !2, line: 2358, column: 9)
!5196 = !DILocation(line: 2359, column: 35, scope: !5193)
!5197 = !DILocation(line: 2359, column: 18, scope: !5193)
!5198 = !DILocation(line: 2359, column: 53, scope: !5193)
!5199 = !DILocation(line: 2359, column: 17, scope: !5194)
!5200 = !DILocation(line: 2361, column: 25, scope: !5201)
!5201 = distinct !DILexicalBlock(scope: !5193, file: !2, line: 2361, column: 24)
!5202 = !DILocation(line: 2361, column: 62, scope: !5201)
!5203 = !DILocation(line: 2361, column: 24, scope: !5193)
!5204 = !DILocation(line: 2363, column: 25, scope: !5205)
!5205 = distinct !DILexicalBlock(scope: !5201, file: !2, line: 2363, column: 24)
!5206 = !DILocation(line: 2363, column: 61, scope: !5205)
!5207 = !DILocation(line: 2363, column: 24, scope: !5201)
!5208 = !DILocation(line: 2365, column: 25, scope: !5209)
!5209 = distinct !DILexicalBlock(scope: !5205, file: !2, line: 2365, column: 24)
!5210 = !DILocation(line: 2365, column: 62, scope: !5209)
!5211 = !DILocation(line: 2365, column: 24, scope: !5205)
!5212 = !DILocation(line: 2367, column: 25, scope: !5213)
!5213 = distinct !DILexicalBlock(scope: !5209, file: !2, line: 2367, column: 24)
!5214 = !DILocation(line: 2367, column: 62, scope: !5213)
!5215 = !DILocation(line: 2367, column: 24, scope: !5209)
!5216 = !DILocation(line: 2369, column: 25, scope: !5217)
!5217 = distinct !DILexicalBlock(scope: !5213, file: !2, line: 2369, column: 24)
!5218 = !DILocation(line: 2369, column: 63, scope: !5217)
!5219 = !DILocation(line: 2369, column: 24, scope: !5213)
!5220 = !DILocation(line: 2371, column: 25, scope: !5221)
!5221 = distinct !DILexicalBlock(scope: !5217, file: !2, line: 2371, column: 24)
!5222 = !DILocation(line: 2371, column: 62, scope: !5221)
!5223 = !DILocation(line: 2371, column: 24, scope: !5217)
!5224 = !DILocation(line: 2373, column: 25, scope: !5225)
!5225 = distinct !DILexicalBlock(scope: !5221, file: !2, line: 2373, column: 24)
!5226 = !DILocation(line: 2373, column: 64, scope: !5225)
!5227 = !DILocation(line: 2373, column: 24, scope: !5221)
!5228 = !DILocation(line: 2375, column: 25, scope: !5229)
!5229 = distinct !DILexicalBlock(scope: !5225, file: !2, line: 2375, column: 24)
!5230 = !DILocation(line: 2375, column: 62, scope: !5229)
!5231 = !DILocation(line: 2375, column: 24, scope: !5225)
!5232 = !DILocation(line: 2377, column: 25, scope: !5233)
!5233 = distinct !DILexicalBlock(scope: !5229, file: !2, line: 2377, column: 24)
!5234 = !DILocation(line: 2377, column: 62, scope: !5233)
!5235 = !DILocation(line: 2377, column: 24, scope: !5229)
!5236 = !DILocation(line: 2380, column: 17, scope: !5237)
!5237 = distinct !DILexicalBlock(scope: !5233, file: !2, line: 2379, column: 20)
!5238 = !DILocation(line: 2381, column: 17, scope: !5237)
!5239 = !DILocation(line: 0, scope: !5193)
!5240 = !DILocation(line: 2358, column: 55, scope: !5195)
!5241 = !DILocation(line: 2358, column: 39, scope: !5195)
!5242 = distinct !{!5242, !5189, !5243, !1410}
!5243 = !DILocation(line: 2383, column: 9, scope: !5190)
!5244 = !DILocation(line: 2388, column: 37, scope: !5154)
!5245 = !DILocation(line: 2388, column: 12, scope: !5154)
!5246 = !DILocation(line: 2388, column: 5, scope: !5154)
!5247 = !DILocation(line: 2390, column: 13, scope: !5248)
!5248 = distinct !DILexicalBlock(scope: !5154, file: !2, line: 2388, column: 46)
!5249 = !DILocation(line: 2391, column: 13, scope: !5248)
!5250 = !DILocation(line: 2393, column: 13, scope: !5248)
!5251 = !DILocation(line: 2394, column: 13, scope: !5248)
!5252 = !DILocation(line: 2396, column: 13, scope: !5248)
!5253 = !DILocation(line: 2397, column: 27, scope: !5248)
!5254 = !DILocation(line: 2397, column: 13, scope: !5248)
!5255 = !DILocation(line: 2398, column: 13, scope: !5248)
!5256 = !DILocation(line: 2400, column: 1, scope: !5154)
!5257 = distinct !DISubprogram(name: "process_verbosity_command", scope: !2, file: !2, line: 2246, type: !2331, scopeLine: 2246, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !5258)
!5258 = !{!5259, !5260, !5261, !5262}
!5259 = !DILocalVariable(name: "c", arg: 1, scope: !5257, file: !2, line: 2246, type: !780)
!5260 = !DILocalVariable(name: "tokens", arg: 2, scope: !5257, file: !2, line: 2246, type: !1544)
!5261 = !DILocalVariable(name: "ntokens", arg: 3, scope: !5257, file: !2, line: 2246, type: !1545)
!5262 = !DILocalVariable(name: "level", scope: !5257, file: !2, line: 2247, type: !464)
!5263 = distinct !DIAssignID()
!5264 = !DILocation(line: 0, scope: !5257)
!5265 = !DILocation(line: 2247, column: 5, scope: !5257)
!5266 = !DILocation(line: 0, scope: !4140, inlinedAt: !5267)
!5267 = distinct !DILocation(line: 2251, column: 5, scope: !5257)
!5268 = !DILocation(line: 516, column: 9, scope: !4150, inlinedAt: !5267)
!5269 = !DILocation(line: 516, column: 31, scope: !4150, inlinedAt: !5267)
!5270 = !DILocation(line: 517, column: 9, scope: !4150, inlinedAt: !5267)
!5271 = !DILocation(line: 517, column: 12, scope: !4150, inlinedAt: !5267)
!5272 = !DILocation(line: 517, column: 59, scope: !4150, inlinedAt: !5267)
!5273 = !DILocation(line: 516, column: 9, scope: !4140, inlinedAt: !5267)
!5274 = !DILocation(line: 518, column: 12, scope: !4157, inlinedAt: !5267)
!5275 = !DILocation(line: 518, column: 20, scope: !4157, inlinedAt: !5267)
!5276 = !DILocation(line: 519, column: 5, scope: !4157, inlinedAt: !5267)
!5277 = !DILocation(line: 2253, column: 23, scope: !5278)
!5278 = distinct !DILexicalBlock(scope: !5257, file: !2, line: 2253, column: 9)
!5279 = !DILocation(line: 2253, column: 33, scope: !5278)
!5280 = !DILocation(line: 2253, column: 10, scope: !5278)
!5281 = !DILocation(line: 2253, column: 9, scope: !5257)
!5282 = !DILocation(line: 2257, column: 24, scope: !5257)
!5283 = !DILocation(line: 2257, column: 22, scope: !5257)
!5284 = !DILocation(line: 2259, column: 5, scope: !5257)
!5285 = !DILocation(line: 2260, column: 1, scope: !5257)
!5286 = distinct !DISubprogram(name: "process_lru_command", scope: !2, file: !2, line: 2429, type: !2331, scopeLine: 2429, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !5287)
!5287 = !{!5288, !5289, !5290, !5291, !5292, !5293, !5294, !5295}
!5288 = !DILocalVariable(name: "c", arg: 1, scope: !5286, file: !2, line: 2429, type: !780)
!5289 = !DILocalVariable(name: "tokens", arg: 2, scope: !5286, file: !2, line: 2429, type: !1544)
!5290 = !DILocalVariable(name: "ntokens", arg: 3, scope: !5286, file: !2, line: 2429, type: !1545)
!5291 = !DILocalVariable(name: "pct_hot", scope: !5286, file: !2, line: 2430, type: !635)
!5292 = !DILocalVariable(name: "pct_warm", scope: !5286, file: !2, line: 2431, type: !635)
!5293 = !DILocalVariable(name: "hot_factor", scope: !5286, file: !2, line: 2432, type: !4486)
!5294 = !DILocalVariable(name: "ttl", scope: !5286, file: !2, line: 2433, type: !638)
!5295 = !DILocalVariable(name: "factor", scope: !5286, file: !2, line: 2434, type: !4486)
!5296 = distinct !DIAssignID()
!5297 = !DILocation(line: 0, scope: !5286)
!5298 = distinct !DIAssignID()
!5299 = distinct !DIAssignID()
!5300 = distinct !DIAssignID()
!5301 = distinct !DIAssignID()
!5302 = !DILocation(line: 2430, column: 5, scope: !5286)
!5303 = !DILocation(line: 2431, column: 5, scope: !5286)
!5304 = !DILocation(line: 2432, column: 5, scope: !5286)
!5305 = !DILocation(line: 2433, column: 5, scope: !5286)
!5306 = !DILocation(line: 2434, column: 5, scope: !5286)
!5307 = !DILocation(line: 0, scope: !4140, inlinedAt: !5308)
!5308 = distinct !DILocation(line: 2436, column: 5, scope: !5286)
!5309 = !DILocation(line: 516, column: 9, scope: !4150, inlinedAt: !5308)
!5310 = !DILocation(line: 516, column: 31, scope: !4150, inlinedAt: !5308)
!5311 = !DILocation(line: 517, column: 9, scope: !4150, inlinedAt: !5308)
!5312 = !DILocation(line: 517, column: 12, scope: !4150, inlinedAt: !5308)
!5313 = !DILocation(line: 517, column: 59, scope: !4150, inlinedAt: !5308)
!5314 = !DILocation(line: 516, column: 9, scope: !4140, inlinedAt: !5308)
!5315 = !DILocation(line: 518, column: 12, scope: !4157, inlinedAt: !5308)
!5316 = !DILocation(line: 518, column: 20, scope: !4157, inlinedAt: !5308)
!5317 = !DILocation(line: 519, column: 5, scope: !4157, inlinedAt: !5308)
!5318 = !DILocation(line: 2438, column: 16, scope: !5319)
!5319 = distinct !DILexicalBlock(scope: !5286, file: !2, line: 2438, column: 9)
!5320 = !DILocation(line: 2438, column: 26, scope: !5319)
!5321 = !DILocation(line: 2438, column: 9, scope: !5319)
!5322 = !DILocation(line: 2438, column: 41, scope: !5319)
!5323 = !DILocation(line: 2438, column: 46, scope: !5319)
!5324 = !DILocation(line: 2439, column: 27, scope: !5325)
!5325 = distinct !DILexicalBlock(scope: !5326, file: !2, line: 2439, column: 13)
!5326 = distinct !DILexicalBlock(scope: !5319, file: !2, line: 2438, column: 63)
!5327 = !DILocation(line: 2439, column: 37, scope: !5325)
!5328 = !DILocation(line: 2439, column: 14, scope: !5325)
!5329 = !DILocation(line: 2439, column: 54, scope: !5325)
!5330 = !DILocation(line: 2440, column: 27, scope: !5325)
!5331 = !DILocation(line: 2440, column: 37, scope: !5325)
!5332 = !DILocation(line: 2440, column: 14, scope: !5325)
!5333 = !DILocation(line: 2440, column: 55, scope: !5325)
!5334 = !DILocation(line: 2441, column: 26, scope: !5325)
!5335 = !DILocation(line: 2441, column: 36, scope: !5325)
!5336 = !DILocation(line: 2441, column: 14, scope: !5325)
!5337 = !DILocation(line: 2441, column: 56, scope: !5325)
!5338 = !DILocation(line: 2442, column: 26, scope: !5325)
!5339 = !DILocation(line: 2442, column: 36, scope: !5325)
!5340 = !DILocation(line: 2442, column: 14, scope: !5325)
!5341 = !DILocation(line: 2439, column: 13, scope: !5326)
!5342 = !DILocation(line: 2443, column: 13, scope: !5343)
!5343 = distinct !DILexicalBlock(scope: !5325, file: !2, line: 2442, column: 53)
!5344 = !DILocation(line: 2444, column: 9, scope: !5343)
!5345 = !DILocation(line: 2445, column: 17, scope: !5346)
!5346 = distinct !DILexicalBlock(scope: !5347, file: !2, line: 2445, column: 17)
!5347 = distinct !DILexicalBlock(scope: !5325, file: !2, line: 2444, column: 16)
!5348 = !DILocation(line: 2445, column: 27, scope: !5346)
!5349 = !DILocation(line: 2445, column: 25, scope: !5346)
!5350 = !DILocation(line: 2445, column: 36, scope: !5346)
!5351 = !DILocation(line: 2445, column: 17, scope: !5347)
!5352 = !DILocation(line: 2446, column: 17, scope: !5353)
!5353 = distinct !DILexicalBlock(scope: !5346, file: !2, line: 2445, column: 42)
!5354 = !DILocation(line: 2447, column: 13, scope: !5353)
!5355 = !DILocation(line: 2447, column: 24, scope: !5356)
!5356 = distinct !DILexicalBlock(scope: !5346, file: !2, line: 2447, column: 24)
!5357 = !DILocation(line: 2447, column: 31, scope: !5356)
!5358 = !DILocation(line: 2447, column: 36, scope: !5356)
!5359 = !DILocation(line: 2447, column: 39, scope: !5356)
!5360 = !DILocation(line: 2447, column: 50, scope: !5356)
!5361 = !DILocation(line: 2447, column: 24, scope: !5346)
!5362 = !DILocation(line: 2448, column: 17, scope: !5363)
!5363 = distinct !DILexicalBlock(scope: !5356, file: !2, line: 2447, column: 56)
!5364 = !DILocation(line: 2449, column: 13, scope: !5363)
!5365 = !DILocation(line: 2450, column: 38, scope: !5366)
!5366 = distinct !DILexicalBlock(scope: !5356, file: !2, line: 2449, column: 20)
!5367 = !{!1859, !1215, i64 192}
!5368 = !DILocation(line: 2451, column: 39, scope: !5366)
!5369 = !{!1859, !1215, i64 196}
!5370 = !DILocation(line: 2452, column: 41, scope: !5366)
!5371 = !{!1859, !1860, i64 200}
!5372 = !DILocation(line: 2453, column: 42, scope: !5366)
!5373 = !{!1859, !1860, i64 208}
!5374 = !DILocation(line: 2454, column: 17, scope: !5366)
!5375 = !DILocation(line: 2457, column: 16, scope: !5376)
!5376 = distinct !DILexicalBlock(scope: !5319, file: !2, line: 2457, column: 16)
!5377 = !DILocation(line: 2457, column: 48, scope: !5376)
!5378 = !DILocation(line: 2457, column: 53, scope: !5376)
!5379 = !DILocation(line: 2458, column: 25, scope: !5376)
!5380 = !{!1859, !1216, i64 135}
!5381 = !DILocation(line: 2457, column: 16, scope: !5319)
!5382 = !DILocation(line: 2459, column: 20, scope: !5383)
!5383 = distinct !DILexicalBlock(scope: !5384, file: !2, line: 2459, column: 13)
!5384 = distinct !DILexicalBlock(scope: !5376, file: !2, line: 2458, column: 48)
!5385 = !DILocation(line: 2459, column: 30, scope: !5383)
!5386 = !DILocation(line: 2459, column: 13, scope: !5383)
!5387 = !DILocation(line: 2459, column: 45, scope: !5383)
!5388 = !DILocation(line: 2459, column: 13, scope: !5384)
!5389 = !DILocation(line: 2460, column: 36, scope: !5390)
!5390 = distinct !DILexicalBlock(scope: !5383, file: !2, line: 2459, column: 51)
!5391 = !{!1859, !1216, i64 136}
!5392 = !DILocation(line: 2461, column: 13, scope: !5390)
!5393 = !DILocation(line: 2462, column: 9, scope: !5390)
!5394 = !DILocation(line: 2462, column: 20, scope: !5395)
!5395 = distinct !DILexicalBlock(scope: !5383, file: !2, line: 2462, column: 20)
!5396 = !DILocation(line: 2462, column: 57, scope: !5395)
!5397 = !DILocation(line: 2462, column: 20, scope: !5383)
!5398 = !DILocation(line: 2463, column: 36, scope: !5399)
!5399 = distinct !DILexicalBlock(scope: !5395, file: !2, line: 2462, column: 63)
!5400 = !DILocation(line: 2464, column: 13, scope: !5399)
!5401 = !DILocation(line: 2465, column: 9, scope: !5399)
!5402 = !DILocation(line: 2466, column: 13, scope: !5403)
!5403 = distinct !DILexicalBlock(scope: !5395, file: !2, line: 2465, column: 16)
!5404 = !DILocation(line: 2468, column: 16, scope: !5405)
!5405 = distinct !DILexicalBlock(scope: !5376, file: !2, line: 2468, column: 16)
!5406 = !DILocation(line: 2468, column: 52, scope: !5405)
!5407 = !DILocation(line: 2468, column: 57, scope: !5405)
!5408 = !DILocation(line: 2469, column: 25, scope: !5405)
!5409 = !DILocation(line: 2468, column: 16, scope: !5376)
!5410 = !DILocation(line: 2470, column: 26, scope: !5411)
!5411 = distinct !DILexicalBlock(scope: !5412, file: !2, line: 2470, column: 13)
!5412 = distinct !DILexicalBlock(scope: !5405, file: !2, line: 2469, column: 48)
!5413 = !DILocation(line: 2470, column: 36, scope: !5411)
!5414 = !DILocation(line: 2470, column: 14, scope: !5411)
!5415 = !DILocation(line: 2470, column: 13, scope: !5412)
!5416 = !DILocation(line: 2471, column: 13, scope: !5417)
!5417 = distinct !DILexicalBlock(scope: !5411, file: !2, line: 2470, column: 50)
!5418 = !DILocation(line: 2472, column: 9, scope: !5417)
!5419 = !DILocation(line: 2473, column: 17, scope: !5420)
!5420 = distinct !DILexicalBlock(scope: !5421, file: !2, line: 2473, column: 17)
!5421 = distinct !DILexicalBlock(scope: !5411, file: !2, line: 2472, column: 16)
!5422 = !DILocation(line: 2473, column: 21, scope: !5420)
!5423 = !DILocation(line: 2473, column: 17, scope: !5421)
!5424 = !DILocation(line: 2477, column: 40, scope: !5425)
!5425 = distinct !DILexicalBlock(scope: !5420, file: !2, line: 2475, column: 20)
!5426 = !{!1859, !1215, i64 224}
!5427 = !DILocation(line: 0, scope: !5420)
!5428 = !DILocation(line: 2479, column: 13, scope: !5421)
!5429 = !DILocation(line: 2482, column: 9, scope: !5430)
!5430 = distinct !DILexicalBlock(scope: !5405, file: !2, line: 2481, column: 12)
!5431 = !DILocation(line: 2484, column: 1, scope: !5286)
!5432 = distinct !DISubprogram(name: "process_extstore_command", scope: !2, file: !2, line: 2486, type: !2331, scopeLine: 2486, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !5433)
!5433 = !{!5434, !5435, !5436, !5437, !5438, !5442, !5443}
!5434 = !DILocalVariable(name: "c", arg: 1, scope: !5432, file: !2, line: 2486, type: !780)
!5435 = !DILocalVariable(name: "tokens", arg: 2, scope: !5432, file: !2, line: 2486, type: !1544)
!5436 = !DILocalVariable(name: "ntokens", arg: 3, scope: !5432, file: !2, line: 2486, type: !1545)
!5437 = !DILocalVariable(name: "ok", scope: !5432, file: !2, line: 2488, type: !790)
!5438 = !DILocalVariable(name: "clsid", scope: !5439, file: !2, line: 2493, type: !464)
!5439 = distinct !DILexicalBlock(scope: !5440, file: !2, line: 2491, column: 79)
!5440 = distinct !DILexicalBlock(scope: !5441, file: !2, line: 2491, column: 16)
!5441 = distinct !DILexicalBlock(scope: !5432, file: !2, line: 2489, column: 9)
!5442 = !DILocalVariable(name: "limit", scope: !5439, file: !2, line: 2494, type: !464)
!5443 = !DILocalVariable(name: "v", scope: !5444, file: !2, line: 2530, type: !464)
!5444 = distinct !DILexicalBlock(scope: !5445, file: !2, line: 2529, column: 61)
!5445 = distinct !DILexicalBlock(scope: !5446, file: !2, line: 2529, column: 16)
!5446 = distinct !DILexicalBlock(scope: !5447, file: !2, line: 2526, column: 16)
!5447 = distinct !DILexicalBlock(scope: !5448, file: !2, line: 2523, column: 16)
!5448 = distinct !DILexicalBlock(scope: !5449, file: !2, line: 2520, column: 16)
!5449 = distinct !DILexicalBlock(scope: !5450, file: !2, line: 2517, column: 16)
!5450 = distinct !DILexicalBlock(scope: !5451, file: !2, line: 2514, column: 16)
!5451 = distinct !DILexicalBlock(scope: !5452, file: !2, line: 2511, column: 16)
!5452 = distinct !DILexicalBlock(scope: !5453, file: !2, line: 2508, column: 16)
!5453 = distinct !DILexicalBlock(scope: !5440, file: !2, line: 2505, column: 16)
!5454 = distinct !DIAssignID()
!5455 = !DILocation(line: 0, scope: !5439)
!5456 = distinct !DIAssignID()
!5457 = distinct !DIAssignID()
!5458 = !DILocation(line: 0, scope: !5444)
!5459 = !DILocation(line: 0, scope: !5432)
!5460 = !DILocation(line: 0, scope: !4140, inlinedAt: !5461)
!5461 = distinct !DILocation(line: 2487, column: 5, scope: !5432)
!5462 = !DILocation(line: 516, column: 9, scope: !4150, inlinedAt: !5461)
!5463 = !DILocation(line: 516, column: 31, scope: !4150, inlinedAt: !5461)
!5464 = !DILocation(line: 517, column: 9, scope: !4150, inlinedAt: !5461)
!5465 = !DILocation(line: 517, column: 12, scope: !4150, inlinedAt: !5461)
!5466 = !DILocation(line: 517, column: 59, scope: !4150, inlinedAt: !5461)
!5467 = !DILocation(line: 516, column: 9, scope: !4140, inlinedAt: !5461)
!5468 = !DILocation(line: 518, column: 12, scope: !4157, inlinedAt: !5461)
!5469 = !DILocation(line: 518, column: 20, scope: !4157, inlinedAt: !5461)
!5470 = !DILocation(line: 519, column: 5, scope: !4157, inlinedAt: !5461)
!5471 = !DILocation(line: 2489, column: 17, scope: !5441)
!5472 = !DILocation(line: 2489, column: 9, scope: !5432)
!5473 = !DILocation(line: 2491, column: 23, scope: !5440)
!5474 = !DILocation(line: 2491, column: 33, scope: !5440)
!5475 = !DILocation(line: 2491, column: 16, scope: !5440)
!5476 = !DILocation(line: 2491, column: 58, scope: !5440)
!5477 = !DILocation(line: 2491, column: 63, scope: !5440)
!5478 = !DILocation(line: 2493, column: 9, scope: !5439)
!5479 = !DILocation(line: 2493, column: 22, scope: !5439)
!5480 = distinct !DIAssignID()
!5481 = !DILocation(line: 2494, column: 9, scope: !5439)
!5482 = !DILocation(line: 2494, column: 22, scope: !5439)
!5483 = distinct !DIAssignID()
!5484 = !DILocation(line: 2495, column: 27, scope: !5485)
!5485 = distinct !DILexicalBlock(scope: !5439, file: !2, line: 2495, column: 13)
!5486 = !DILocation(line: 2495, column: 37, scope: !5485)
!5487 = !DILocation(line: 2495, column: 14, scope: !5485)
!5488 = !DILocation(line: 2495, column: 52, scope: !5485)
!5489 = !DILocation(line: 2496, column: 31, scope: !5485)
!5490 = !DILocation(line: 2496, column: 41, scope: !5485)
!5491 = !DILocation(line: 2496, column: 18, scope: !5485)
!5492 = !DILocation(line: 2495, column: 13, scope: !5439)
!5493 = !DILocation(line: 2505, column: 5, scope: !5440)
!5494 = !DILocation(line: 2539, column: 9, scope: !5432)
!5495 = !DILocation(line: 2499, column: 17, scope: !5496)
!5496 = distinct !DILexicalBlock(scope: !5497, file: !2, line: 2499, column: 17)
!5497 = distinct !DILexicalBlock(scope: !5485, file: !2, line: 2498, column: 16)
!5498 = !DILocation(line: 2499, column: 23, scope: !5496)
!5499 = !DILocation(line: 2505, column: 16, scope: !5453)
!5500 = !DILocation(line: 2505, column: 53, scope: !5453)
!5501 = !DILocation(line: 2505, column: 16, scope: !5440)
!5502 = !DILocation(line: 2506, column: 27, scope: !5503)
!5503 = distinct !DILexicalBlock(scope: !5504, file: !2, line: 2506, column: 13)
!5504 = distinct !DILexicalBlock(scope: !5453, file: !2, line: 2505, column: 59)
!5505 = !DILocation(line: 2506, column: 37, scope: !5503)
!5506 = !DILocation(line: 2506, column: 14, scope: !5503)
!5507 = !DILocation(line: 2508, column: 16, scope: !5452)
!5508 = !DILocation(line: 2508, column: 52, scope: !5452)
!5509 = !DILocation(line: 2508, column: 16, scope: !5453)
!5510 = !DILocation(line: 2509, column: 27, scope: !5511)
!5511 = distinct !DILexicalBlock(scope: !5512, file: !2, line: 2509, column: 13)
!5512 = distinct !DILexicalBlock(scope: !5452, file: !2, line: 2508, column: 58)
!5513 = !DILocation(line: 2509, column: 37, scope: !5511)
!5514 = !DILocation(line: 2509, column: 14, scope: !5511)
!5515 = !DILocation(line: 2511, column: 16, scope: !5451)
!5516 = !DILocation(line: 2511, column: 51, scope: !5451)
!5517 = !DILocation(line: 2511, column: 16, scope: !5452)
!5518 = !DILocation(line: 2512, column: 27, scope: !5519)
!5519 = distinct !DILexicalBlock(scope: !5520, file: !2, line: 2512, column: 13)
!5520 = distinct !DILexicalBlock(scope: !5451, file: !2, line: 2511, column: 57)
!5521 = !DILocation(line: 2512, column: 37, scope: !5519)
!5522 = !DILocation(line: 2512, column: 14, scope: !5519)
!5523 = !DILocation(line: 2514, column: 16, scope: !5450)
!5524 = !DILocation(line: 2514, column: 56, scope: !5450)
!5525 = !DILocation(line: 2514, column: 16, scope: !5451)
!5526 = !DILocation(line: 2515, column: 27, scope: !5527)
!5527 = distinct !DILexicalBlock(scope: !5528, file: !2, line: 2515, column: 13)
!5528 = distinct !DILexicalBlock(scope: !5450, file: !2, line: 2514, column: 62)
!5529 = !DILocation(line: 2515, column: 37, scope: !5527)
!5530 = !DILocation(line: 2515, column: 14, scope: !5527)
!5531 = !DILocation(line: 2517, column: 16, scope: !5449)
!5532 = !DILocation(line: 2517, column: 57, scope: !5449)
!5533 = !DILocation(line: 2517, column: 16, scope: !5450)
!5534 = !DILocation(line: 2518, column: 27, scope: !5535)
!5535 = distinct !DILexicalBlock(scope: !5536, file: !2, line: 2518, column: 13)
!5536 = distinct !DILexicalBlock(scope: !5449, file: !2, line: 2517, column: 63)
!5537 = !DILocation(line: 2518, column: 37, scope: !5535)
!5538 = !DILocation(line: 2518, column: 14, scope: !5535)
!5539 = !DILocation(line: 2520, column: 16, scope: !5448)
!5540 = !DILocation(line: 2520, column: 54, scope: !5448)
!5541 = !DILocation(line: 2520, column: 16, scope: !5449)
!5542 = !DILocation(line: 2521, column: 27, scope: !5543)
!5543 = distinct !DILexicalBlock(scope: !5544, file: !2, line: 2521, column: 13)
!5544 = distinct !DILexicalBlock(scope: !5448, file: !2, line: 2520, column: 60)
!5545 = !DILocation(line: 2521, column: 37, scope: !5543)
!5546 = !DILocation(line: 2521, column: 14, scope: !5543)
!5547 = !DILocation(line: 2523, column: 16, scope: !5447)
!5548 = !DILocation(line: 2523, column: 53, scope: !5447)
!5549 = !DILocation(line: 2523, column: 16, scope: !5448)
!5550 = !DILocation(line: 2524, column: 27, scope: !5551)
!5551 = distinct !DILexicalBlock(scope: !5552, file: !2, line: 2524, column: 13)
!5552 = distinct !DILexicalBlock(scope: !5447, file: !2, line: 2523, column: 59)
!5553 = !DILocation(line: 2524, column: 37, scope: !5551)
!5554 = !DILocation(line: 2524, column: 14, scope: !5551)
!5555 = !DILocation(line: 2526, column: 16, scope: !5446)
!5556 = !DILocation(line: 2526, column: 52, scope: !5446)
!5557 = !DILocation(line: 2526, column: 16, scope: !5447)
!5558 = !DILocation(line: 2529, column: 16, scope: !5445)
!5559 = !DILocation(line: 2529, column: 55, scope: !5445)
!5560 = !DILocation(line: 2529, column: 16, scope: !5446)
!5561 = !DILocation(line: 2530, column: 9, scope: !5444)
!5562 = !DILocation(line: 2531, column: 27, scope: !5563)
!5563 = distinct !DILexicalBlock(scope: !5444, file: !2, line: 2531, column: 13)
!5564 = !DILocation(line: 2531, column: 37, scope: !5563)
!5565 = !DILocation(line: 2531, column: 14, scope: !5563)
!5566 = !DILocation(line: 2531, column: 13, scope: !5444)
!5567 = !DILocation(line: 2534, column: 40, scope: !5568)
!5568 = distinct !DILexicalBlock(scope: !5563, file: !2, line: 2533, column: 16)
!5569 = !DILocation(line: 2534, column: 42, scope: !5568)
!5570 = !DILocation(line: 2534, column: 38, scope: !5568)
!5571 = !{!1859, !1216, i64 304}
!5572 = !DILocation(line: 2536, column: 5, scope: !5445)
!5573 = !DILocation(line: 2527, column: 26, scope: !5574)
!5574 = distinct !DILexicalBlock(scope: !5575, file: !2, line: 2527, column: 13)
!5575 = distinct !DILexicalBlock(scope: !5446, file: !2, line: 2526, column: 58)
!5576 = !DILocation(line: 2527, column: 36, scope: !5574)
!5577 = !DILocation(line: 2527, column: 14, scope: !5574)
!5578 = !DILocation(line: 0, scope: !5579)
!5579 = distinct !DILexicalBlock(scope: !5432, file: !2, line: 2539, column: 9)
!5580 = !DILocation(line: 2544, column: 1, scope: !5432)
!5581 = !DISubprogram(name: "base64_encode", scope: !5582, file: !5582, line: 12, type: !5583, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5582 = !DIFile(filename: "./base64.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "df9eb6d1c290d1a122f3ee1ae425ece4")
!5583 = !DISubroutineType(types: !5584)
!5584 = !{!747, !5585, !747, !631, !747}
!5585 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5586, size: 64)
!5586 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !609)
!5587 = !DISubprogram(name: "itoa_u64", scope: !5588, file: !5588, line: 25, type: !5589, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5588 = !DIFile(filename: "./itoa_ljust.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "5be9fc604132469dbbed0757f77ba718")
!5589 = !DISubroutineType(types: !5590)
!5590 = !{!579, !616, !579}
!5591 = !DISubprogram(name: "itoa_u32", scope: !5588, file: !5588, line: 23, type: !5592, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5592 = !DISubroutineType(types: !5593)
!5593 = !{!579, !635, !579}
!5594 = !DISubprogram(name: "resp_add_iov", scope: !463, file: !463, line: 1055, type: !5595, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5595 = !DISubroutineType(types: !5596)
!5596 = !{null, !882, !730, !598}
!5597 = !DISubprogram(name: "strlen", scope: !1469, file: !1469, line: 407, type: !5598, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5598 = !DISubroutineType(types: !5599)
!5599 = !{!618, !1472}
!5600 = !DISubprogram(name: "out_errstring", scope: !463, file: !463, line: 1066, type: !1475, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5601 = distinct !DISubprogram(name: "_meta_flag_preparse", scope: !2, file: !2, line: 933, type: !5602, scopeLine: 934, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !5606)
!5602 = !DISubroutineType(types: !5603)
!5603 = !{!598, !1544, !1545, !5604, !5605}
!5604 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2342, size: 64)
!5605 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !579, size: 64)
!5606 = !{!5607, !5608, !5609, !5610, !5611, !5612, !5613, !5614, !5618}
!5607 = !DILocalVariable(name: "tokens", arg: 1, scope: !5601, file: !2, line: 933, type: !1544)
!5608 = !DILocalVariable(name: "start", arg: 2, scope: !5601, file: !2, line: 933, type: !1545)
!5609 = !DILocalVariable(name: "of", arg: 3, scope: !5601, file: !2, line: 934, type: !5604)
!5610 = !DILocalVariable(name: "errstr", arg: 4, scope: !5601, file: !2, line: 934, type: !5605)
!5611 = !DILocalVariable(name: "i", scope: !5601, file: !2, line: 935, type: !464)
!5612 = !DILocalVariable(name: "ret", scope: !5601, file: !2, line: 936, type: !747)
!5613 = !DILocalVariable(name: "tmp_int", scope: !5601, file: !2, line: 937, type: !638)
!5614 = !DILocalVariable(name: "seen", scope: !5601, file: !2, line: 938, type: !5615)
!5615 = !DICompositeType(tag: DW_TAG_array_type, baseType: !607, size: 1016, elements: !5616)
!5616 = !{!5617}
!5617 = !DISubrange(count: 127)
!5618 = !DILocalVariable(name: "o", scope: !5619, file: !2, line: 941, type: !607)
!5619 = distinct !DILexicalBlock(scope: !5620, file: !2, line: 940, column: 49)
!5620 = distinct !DILexicalBlock(scope: !5621, file: !2, line: 940, column: 5)
!5621 = distinct !DILexicalBlock(scope: !5601, file: !2, line: 940, column: 5)
!5622 = distinct !DIAssignID()
!5623 = !DILocation(line: 0, scope: !5601)
!5624 = distinct !DIAssignID()
!5625 = !DILocation(line: 937, column: 5, scope: !5601)
!5626 = !DILocation(line: 938, column: 5, scope: !5601)
!5627 = !DILocation(line: 938, column: 13, scope: !5601)
!5628 = distinct !DIAssignID()
!5629 = !DILocation(line: 940, column: 21, scope: !5620)
!5630 = !DILocation(line: 940, column: 31, scope: !5620)
!5631 = !DILocation(line: 940, column: 38, scope: !5620)
!5632 = !DILocation(line: 940, column: 5, scope: !5621)
!5633 = !DILocation(line: 940, column: 14, scope: !5621)
!5634 = !DILocation(line: 941, column: 40, scope: !5619)
!5635 = !DILocation(line: 941, column: 30, scope: !5619)
!5636 = !DILocation(line: 0, scope: !5619)
!5637 = !DILocation(line: 943, column: 15, scope: !5638)
!5638 = distinct !DILexicalBlock(scope: !5619, file: !2, line: 943, column: 13)
!5639 = !DILocation(line: 943, column: 22, scope: !5638)
!5640 = !DILocation(line: 943, column: 25, scope: !5638)
!5641 = !DILocation(line: 943, column: 33, scope: !5638)
!5642 = !DILocation(line: 943, column: 13, scope: !5619)
!5643 = !DILocation(line: 944, column: 21, scope: !5644)
!5644 = distinct !DILexicalBlock(scope: !5638, file: !2, line: 943, column: 39)
!5645 = !DILocation(line: 945, column: 13, scope: !5644)
!5646 = !DILocation(line: 947, column: 17, scope: !5619)
!5647 = !DILocation(line: 948, column: 9, scope: !5619)
!5648 = !DILocation(line: 952, column: 72, scope: !5649)
!5649 = distinct !DILexicalBlock(scope: !5619, file: !2, line: 948, column: 20)
!5650 = !DILocation(line: 952, column: 97, scope: !5649)
!5651 = !DILocation(line: 952, column: 23, scope: !5649)
!5652 = !DILocation(line: 954, column: 25, scope: !5653)
!5653 = distinct !DILexicalBlock(scope: !5649, file: !2, line: 954, column: 21)
!5654 = !DILocation(line: 954, column: 21, scope: !5649)
!5655 = !DILocation(line: 956, column: 29, scope: !5656)
!5656 = distinct !DILexicalBlock(scope: !5653, file: !2, line: 954, column: 31)
!5657 = !DILocation(line: 957, column: 35, scope: !5656)
!5658 = !DILocation(line: 958, column: 17, scope: !5656)
!5659 = !DILocation(line: 959, column: 42, scope: !5649)
!5660 = !DILocation(line: 960, column: 32, scope: !5649)
!5661 = !DILocation(line: 961, column: 17, scope: !5649)
!5662 = !DILocation(line: 966, column: 28, scope: !5649)
!5663 = !DILocation(line: 967, column: 28, scope: !5649)
!5664 = !DILocation(line: 968, column: 44, scope: !5665)
!5665 = distinct !DILexicalBlock(scope: !5649, file: !2, line: 968, column: 21)
!5666 = !DILocation(line: 968, column: 49, scope: !5665)
!5667 = !DILocation(line: 968, column: 22, scope: !5665)
!5668 = !DILocation(line: 968, column: 21, scope: !5649)
!5669 = !DILocation(line: 969, column: 29, scope: !5670)
!5670 = distinct !DILexicalBlock(scope: !5665, file: !2, line: 968, column: 64)
!5671 = !DILocation(line: 970, column: 35, scope: !5670)
!5672 = !DILocation(line: 971, column: 17, scope: !5670)
!5673 = !DILocation(line: 972, column: 52, scope: !5674)
!5674 = distinct !DILexicalBlock(scope: !5665, file: !2, line: 971, column: 24)
!5675 = !DILocation(line: 972, column: 43, scope: !5674)
!5676 = !DILocation(line: 972, column: 41, scope: !5674)
!5677 = !DILocation(line: 976, column: 28, scope: !5649)
!5678 = !DILocation(line: 977, column: 44, scope: !5679)
!5679 = distinct !DILexicalBlock(scope: !5649, file: !2, line: 977, column: 21)
!5680 = !DILocation(line: 977, column: 49, scope: !5679)
!5681 = !DILocation(line: 977, column: 22, scope: !5679)
!5682 = !DILocation(line: 977, column: 21, scope: !5649)
!5683 = !DILocation(line: 978, column: 29, scope: !5684)
!5684 = distinct !DILexicalBlock(scope: !5679, file: !2, line: 977, column: 64)
!5685 = !DILocation(line: 979, column: 35, scope: !5684)
!5686 = !DILocation(line: 980, column: 17, scope: !5684)
!5687 = !DILocation(line: 981, column: 44, scope: !5688)
!5688 = distinct !DILexicalBlock(scope: !5679, file: !2, line: 980, column: 24)
!5689 = !DILocation(line: 981, column: 35, scope: !5688)
!5690 = !DILocation(line: 981, column: 33, scope: !5688)
!5691 = !DILocation(line: 982, column: 33, scope: !5688)
!5692 = !DILocation(line: 986, column: 28, scope: !5649)
!5693 = !DILocation(line: 987, column: 44, scope: !5694)
!5694 = distinct !DILexicalBlock(scope: !5649, file: !2, line: 987, column: 21)
!5695 = !DILocation(line: 987, column: 49, scope: !5694)
!5696 = !DILocation(line: 987, column: 22, scope: !5694)
!5697 = !DILocation(line: 987, column: 21, scope: !5649)
!5698 = !DILocation(line: 988, column: 29, scope: !5699)
!5699 = distinct !DILexicalBlock(scope: !5694, file: !2, line: 987, column: 64)
!5700 = !DILocation(line: 989, column: 35, scope: !5699)
!5701 = !DILocation(line: 990, column: 17, scope: !5699)
!5702 = !DILocation(line: 991, column: 49, scope: !5703)
!5703 = distinct !DILexicalBlock(scope: !5694, file: !2, line: 990, column: 24)
!5704 = !DILocation(line: 991, column: 40, scope: !5703)
!5705 = !DILocation(line: 991, column: 38, scope: !5703)
!5706 = !DILocation(line: 995, column: 24, scope: !5649)
!5707 = !DILocation(line: 996, column: 28, scope: !5649)
!5708 = !DILocation(line: 997, column: 17, scope: !5649)
!5709 = !DILocation(line: 1009, column: 27, scope: !5649)
!5710 = !DILocation(line: 1010, column: 17, scope: !5649)
!5711 = !DILocation(line: 1012, column: 28, scope: !5649)
!5712 = !DILocation(line: 1013, column: 17, scope: !5649)
!5713 = !DILocation(line: 1015, column: 31, scope: !5649)
!5714 = !DILocation(line: 1016, column: 17, scope: !5649)
!5715 = !DILocation(line: 1018, column: 30, scope: !5649)
!5716 = !DILocation(line: 1019, column: 17, scope: !5649)
!5717 = !DILocation(line: 1021, column: 32, scope: !5649)
!5718 = !DILocation(line: 1022, column: 17, scope: !5649)
!5719 = !DILocation(line: 1025, column: 53, scope: !5720)
!5720 = distinct !DILexicalBlock(scope: !5649, file: !2, line: 1025, column: 21)
!5721 = !DILocation(line: 1025, column: 22, scope: !5720)
!5722 = !DILocation(line: 1025, column: 21, scope: !5649)
!5723 = !DILocation(line: 1026, column: 35, scope: !5724)
!5724 = distinct !DILexicalBlock(scope: !5720, file: !2, line: 1025, column: 77)
!5725 = !DILocation(line: 1027, column: 17, scope: !5724)
!5726 = !DILocation(line: 1030, column: 51, scope: !5727)
!5727 = distinct !DILexicalBlock(scope: !5649, file: !2, line: 1030, column: 21)
!5728 = !DILocation(line: 1030, column: 22, scope: !5727)
!5729 = !DILocation(line: 1030, column: 21, scope: !5649)
!5730 = !DILocation(line: 1031, column: 29, scope: !5731)
!5731 = distinct !DILexicalBlock(scope: !5727, file: !2, line: 1030, column: 73)
!5732 = !DILocation(line: 1032, column: 35, scope: !5731)
!5733 = !DILocation(line: 1033, column: 17, scope: !5731)
!5734 = !DILocation(line: 1034, column: 33, scope: !5735)
!5735 = distinct !DILexicalBlock(scope: !5727, file: !2, line: 1033, column: 24)
!5736 = !DILocation(line: 1038, column: 51, scope: !5737)
!5737 = distinct !DILexicalBlock(scope: !5649, file: !2, line: 1038, column: 21)
!5738 = !DILocation(line: 1038, column: 22, scope: !5737)
!5739 = !DILocation(line: 1038, column: 21, scope: !5649)
!5740 = !DILocation(line: 1039, column: 29, scope: !5741)
!5741 = distinct !DILexicalBlock(scope: !5737, file: !2, line: 1038, column: 72)
!5742 = !DILocation(line: 1040, column: 35, scope: !5741)
!5743 = !DILocation(line: 1041, column: 17, scope: !5741)
!5744 = !DILocation(line: 1042, column: 36, scope: !5745)
!5745 = distinct !DILexicalBlock(scope: !5737, file: !2, line: 1041, column: 24)
!5746 = !DILocation(line: 1046, column: 38, scope: !5747)
!5747 = distinct !DILexicalBlock(scope: !5649, file: !2, line: 1046, column: 21)
!5748 = !DILocation(line: 1046, column: 21, scope: !5649)
!5749 = !DILocation(line: 1047, column: 29, scope: !5750)
!5750 = distinct !DILexicalBlock(scope: !5747, file: !2, line: 1046, column: 44)
!5751 = !DILocation(line: 1048, column: 35, scope: !5750)
!5752 = !DILocation(line: 1049, column: 17, scope: !5750)
!5753 = !DILocation(line: 1050, column: 32, scope: !5754)
!5754 = distinct !DILexicalBlock(scope: !5747, file: !2, line: 1049, column: 24)
!5755 = !DILocation(line: 1050, column: 30, scope: !5754)
!5756 = !DILocation(line: 1054, column: 51, scope: !5757)
!5757 = distinct !DILexicalBlock(scope: !5649, file: !2, line: 1054, column: 21)
!5758 = !DILocation(line: 1054, column: 22, scope: !5757)
!5759 = !DILocation(line: 1054, column: 21, scope: !5649)
!5760 = !DILocation(line: 1055, column: 29, scope: !5761)
!5761 = distinct !DILexicalBlock(scope: !5757, file: !2, line: 1054, column: 70)
!5762 = !DILocation(line: 1056, column: 35, scope: !5761)
!5763 = !DILocation(line: 1057, column: 17, scope: !5761)
!5764 = !DILocation(line: 1060, column: 51, scope: !5765)
!5765 = distinct !DILexicalBlock(scope: !5649, file: !2, line: 1060, column: 21)
!5766 = !DILocation(line: 1060, column: 22, scope: !5765)
!5767 = !DILocation(line: 1060, column: 21, scope: !5649)
!5768 = !DILocation(line: 1061, column: 29, scope: !5769)
!5769 = distinct !DILexicalBlock(scope: !5765, file: !2, line: 1060, column: 68)
!5770 = !DILocation(line: 1062, column: 35, scope: !5769)
!5771 = !DILocation(line: 1063, column: 17, scope: !5769)
!5772 = !DILocation(line: 1066, column: 31, scope: !5649)
!5773 = !DILocation(line: 1067, column: 17, scope: !5649)
!5774 = !DILocation(line: 1069, column: 25, scope: !5649)
!5775 = !DILocation(line: 1070, column: 17, scope: !5649)
!5776 = !DILocation(line: 940, column: 45, scope: !5620)
!5777 = distinct !{!5777, !5632, !5778, !1410}
!5778 = !DILocation(line: 1072, column: 5, scope: !5621)
!5779 = !DILocation(line: 1074, column: 16, scope: !5601)
!5780 = !DILocation(line: 1074, column: 12, scope: !5601)
!5781 = !DILocation(line: 1074, column: 5, scope: !5601)
!5782 = !DILocation(line: 1075, column: 1, scope: !5601)
!5783 = !DISubprogram(name: "limited_get", scope: !463, file: !463, line: 1051, type: !5784, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5784 = !DISubroutineType(types: !5785)
!5785 = !{!1062, !1472, !747, !894, !635, !790, !790, !5786}
!5786 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !790, size: 64)
!5787 = !DISubprogram(name: "limited_get_locked", scope: !463, file: !463, line: 1052, type: !5788, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5788 = !DISubroutineType(types: !5789)
!5789 = !{!1062, !1472, !747, !894, !790, !746, !5786}
!5790 = !DISubprogram(name: "item_alloc", scope: !463, file: !463, line: 1006, type: !5791, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5791 = !DISubroutineType(types: !5792)
!5792 = !{!1062, !1472, !747, !634, !595, !598}
!5793 = !DISubprogram(name: "realtime", scope: !463, file: !463, line: 1050, type: !5794, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5794 = !DISubroutineType(types: !5795)
!5795 = !{!595, !5796}
!5796 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !5797)
!5797 = !DIDerivedType(tag: DW_TAG_typedef, name: "time_t", file: !5798, line: 10, baseType: !721)
!5798 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/time_t.h", directory: "", checksumkind: CSK_MD5, checksum: "5c299a4954617c88bb03645c7864e1b1")
!5799 = !DISubprogram(name: "do_item_link", scope: !1484, file: !1484, line: 20, type: !5800, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5800 = !DISubroutineType(types: !5801)
!5801 = !{!598, !1062, !5802, !1482}
!5802 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !635)
!5803 = !DISubprogram(name: "storage_get_item", scope: !5804, file: !5804, line: 18, type: !5805, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5804 = !DIFile(filename: "./storage.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d18dbd8a1337d7561522237d8930ae7f")
!5805 = !DISubroutineType(types: !5806)
!5806 = !{!598, !780, !1062, !882}
!5807 = !DISubprogram(name: "resp_add_chunked_iov", scope: !463, file: !463, line: 1056, type: !5595, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5808 = !DISubprogram(name: "do_item_remove", scope: !1484, file: !1484, line: 23, type: !1488, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5809 = !DISubprogram(name: "do_item_bump", scope: !1484, file: !1484, line: 75, type: !5810, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5810 = !DISubroutineType(types: !5811)
!5811 = !{null, !894, !1062, !5802}
!5812 = !DISubprogram(name: "item_unlock", scope: !463, file: !463, line: 1020, type: !5813, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5813 = !DISubroutineType(types: !5814)
!5814 = !{null, !635}
!5815 = !DISubprogram(name: "base64_decode", scope: !5582, file: !5582, line: 14, type: !5583, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5816 = !DISubprogram(name: "safe_strtol", scope: !1760, file: !1760, line: 20, type: !5817, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5817 = !DISubroutineType(types: !5818)
!5818 = !{!790, !1472, !637}
!5819 = !DISubprogram(name: "safe_strtoull", scope: !1760, file: !1760, line: 16, type: !5820, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5820 = !DISubroutineType(types: !5821)
!5821 = !{!790, !1472, !1481}
!5822 = !DISubprogram(name: "item_size_ok", scope: !1484, file: !1484, line: 18, type: !5823, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5823 = !DISubroutineType(types: !5824)
!5824 = !{!790, !1545, !5825, !5826}
!5825 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !634)
!5826 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !598)
!5827 = !DISubprogram(name: "pthread_getspecific", scope: !1463, file: !1463, line: 1305, type: !5828, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5828 = !DISubroutineType(types: !5829)
!5829 = !{!632, !5830}
!5830 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_key_t", file: !650, line: 49, baseType: !464)
!5831 = !DISubprogram(name: "logger_log", scope: !497, file: !497, line: 238, type: !5832, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5832 = !DISubroutineType(types: !5833)
!5833 = !{!539, !641, !5834, !730, null}
!5834 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !496)
!5835 = !DISubprogram(name: "item_get_locked", scope: !463, file: !463, line: 1010, type: !5836, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5836 = !DISubroutineType(types: !5837)
!5837 = !{!1062, !1472, !1545, !894, !4652, !746}
!5838 = !DISubprogram(name: "do_item_unlink", scope: !1484, file: !1484, line: 21, type: !5839, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5839 = !DISubroutineType(types: !5840)
!5840 = !{null, !1062, !5802}
!5841 = !DISubprogram(name: "storage_delete", scope: !5804, file: !5804, line: 4, type: !5842, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5842 = !DISubroutineType(types: !5843)
!5843 = !{null, !632, !1062}
!5844 = !DISubprogram(name: "do_store_item", scope: !463, file: !463, line: 957, type: !5845, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5845 = !DISubroutineType(types: !5846)
!5846 = !{!531, !1062, !598, !894, !5802, !1480, !1481, !1482, !790}
!5847 = !DISubprogram(name: "item_lock", scope: !463, file: !463, line: 1017, type: !5813, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5848 = !DISubprogram(name: "do_add_delta", scope: !463, file: !463, line: 952, type: !5849, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5849 = !DISubroutineType(types: !5850)
!5850 = !{!544, !894, !1472, !1545, !4652, !5851, !579, !1481, !5802, !5854}
!5851 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !5852)
!5852 = !DIDerivedType(tag: DW_TAG_typedef, name: "int64_t", file: !639, line: 27, baseType: !5853)
!5853 = !DIDerivedType(tag: DW_TAG_typedef, name: "__int64_t", file: !605, line: 44, baseType: !675)
!5854 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1062, size: 64)
!5855 = !DISubprogram(name: "snprintf", scope: !2275, file: !2275, line: 385, type: !5856, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5856 = !DISubroutineType(types: !5857)
!5857 = !{!598, !5858, !747, !2329, null}
!5858 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !579)
!5859 = !DISubprogram(name: "stats_prefix_record_get", scope: !5860, file: !5860, line: 25, type: !5861, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5860 = !DIFile(filename: "./stats_prefix.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "c26de3f3a40668b5f799218415be0cc4")
!5861 = !DISubroutineType(types: !5862)
!5862 = !{null, !1472, !1545, !4652}
!5863 = !DISubprogram(name: "conn_release_items", scope: !463, file: !463, line: 1063, type: !778, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5864 = !DISubprogram(name: "out_of_memory", scope: !463, file: !463, line: 1065, type: !1844, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5865 = !DISubprogram(name: "stats_prefix_record_set", scope: !5860, file: !5860, line: 31, type: !5866, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5866 = !DISubroutineType(types: !5867)
!5867 = !{null, !1472, !1545}
!5868 = !DISubprogram(name: "item_get", scope: !463, file: !463, line: 1009, type: !5869, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5869 = !DISubroutineType(types: !5870)
!5870 = !{!1062, !1472, !1545, !894, !4652}
!5871 = !DISubprogram(name: "item_unlink", scope: !463, file: !463, line: 1015, type: !1488, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5872 = !DISubprogram(name: "server_stats", scope: !463, file: !463, line: 1068, type: !5873, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5873 = !DISubroutineType(types: !5874)
!5874 = !{null, !5875, !632}
!5875 = !DIDerivedType(tag: DW_TAG_typedef, name: "ADD_STAT", file: !463, line: 194, baseType: !5876)
!5876 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5877, size: 64)
!5877 = !DISubroutineType(types: !5878)
!5878 = !{null, !1472, !5879, !1472, !5802, !730}
!5879 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !602)
!5880 = !DISubprogram(name: "append_stats", scope: !463, file: !463, line: 1069, type: !5877, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5881 = !DISubprogram(name: "get_stats", scope: !463, file: !463, line: 1073, type: !5882, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5882 = !DISubroutineType(types: !5883)
!5883 = !{!790, !1472, !598, !5875, !632}
!5884 = !DISubprogram(name: "stats_reset", scope: !463, file: !463, line: 1074, type: !5885, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5885 = !DISubroutineType(types: !5886)
!5886 = !{null}
!5887 = distinct !DISubprogram(name: "process_stats_detail", scope: !2, file: !2, line: 723, type: !1475, scopeLine: 723, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !460, retainedNodes: !5888)
!5888 = !{!5889, !5890, !5891, !5896}
!5889 = !DILocalVariable(name: "c", arg: 1, scope: !5887, file: !2, line: 723, type: !780)
!5890 = !DILocalVariable(name: "command", arg: 2, scope: !5887, file: !2, line: 723, type: !1472)
!5891 = !DILocalVariable(name: "len", scope: !5892, file: !2, line: 735, type: !598)
!5892 = distinct !DILexicalBlock(scope: !5893, file: !2, line: 734, column: 44)
!5893 = distinct !DILexicalBlock(scope: !5894, file: !2, line: 734, column: 14)
!5894 = distinct !DILexicalBlock(scope: !5895, file: !2, line: 730, column: 14)
!5895 = distinct !DILexicalBlock(scope: !5887, file: !2, line: 726, column: 9)
!5896 = !DILocalVariable(name: "stats", scope: !5892, file: !2, line: 736, type: !579)
!5897 = distinct !DIAssignID()
!5898 = !DILocation(line: 0, scope: !5892)
!5899 = !DILocation(line: 0, scope: !5887)
!5900 = !DILocation(line: 726, column: 31, scope: !5895)
!5901 = !DILocation(line: 726, column: 9, scope: !5887)
!5902 = !DILocation(line: 727, column: 33, scope: !5903)
!5903 = distinct !DILexicalBlock(scope: !5895, file: !2, line: 726, column: 37)
!5904 = !DILocation(line: 728, column: 9, scope: !5903)
!5905 = !DILocation(line: 729, column: 5, scope: !5903)
!5906 = !DILocation(line: 730, column: 14, scope: !5894)
!5907 = !DILocation(line: 730, column: 37, scope: !5894)
!5908 = !DILocation(line: 730, column: 14, scope: !5895)
!5909 = !DILocation(line: 731, column: 33, scope: !5910)
!5910 = distinct !DILexicalBlock(scope: !5894, file: !2, line: 730, column: 43)
!5911 = !DILocation(line: 732, column: 9, scope: !5910)
!5912 = !DILocation(line: 733, column: 5, scope: !5910)
!5913 = !DILocation(line: 734, column: 14, scope: !5893)
!5914 = !DILocation(line: 734, column: 38, scope: !5893)
!5915 = !DILocation(line: 734, column: 14, scope: !5894)
!5916 = !DILocation(line: 735, column: 9, scope: !5892)
!5917 = !DILocation(line: 736, column: 23, scope: !5892)
!5918 = !DILocation(line: 737, column: 34, scope: !5892)
!5919 = !DILocation(line: 737, column: 9, scope: !5892)
!5920 = !DILocation(line: 738, column: 5, scope: !5893)
!5921 = !DILocation(line: 738, column: 5, scope: !5892)
!5922 = !DILocation(line: 740, column: 9, scope: !5923)
!5923 = distinct !DILexicalBlock(scope: !5893, file: !2, line: 739, column: 10)
!5924 = !DILocation(line: 742, column: 1, scope: !5887)
!5925 = !DISubprogram(name: "process_stat_settings", scope: !463, file: !463, line: 1075, type: !5873, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5926 = !DISubprogram(name: "item_cachedump", scope: !1484, file: !1484, line: 53, type: !5927, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5927 = !DISubroutineType(types: !5928)
!5928 = !{!579, !5929, !5929, !5930}
!5929 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !464)
!5930 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !464, size: 64)
!5931 = !DISubprogram(name: "write_and_free", scope: !463, file: !463, line: 1067, type: !5932, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5932 = !DISubroutineType(types: !5933)
!5933 = !{null, !780, !579, !598}
!5934 = !DISubprogram(name: "process_stats_conns", scope: !463, file: !463, line: 1076, type: !5873, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5935 = !DISubprogram(name: "process_extstore_stats", scope: !5804, file: !5804, line: 16, type: !5873, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5936 = !DISubprogram(name: "stats_prefix_dump", scope: !5860, file: !5860, line: 37, type: !5937, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5937 = !DISubroutineType(types: !5938)
!5938 = !{!579, !1480}
!5939 = !DISubprogram(name: "raise", scope: !5940, file: !5940, line: 123, type: !5941, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5940 = !DIFile(filename: "/usr/include/signal.h", directory: "", checksumkind: CSK_MD5, checksum: "889444797eff632f3342b063de2e2650")
!5941 = !DISubroutineType(types: !5942)
!5942 = !{!598, !598}
!5943 = !DISubprogram(name: "slabs_reassign", scope: !552, file: !552, line: 60, type: !5944, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5944 = !DISubroutineType(types: !5945)
!5945 = !{!551, !598, !598}
!5946 = !DISubprogram(name: "safe_strtod", scope: !1760, file: !1760, line: 21, type: !5947, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5947 = !DISubroutineType(types: !5948)
!5948 = !{!790, !1472, !5949}
!5949 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !4486, size: 64)
!5950 = !DISubprogram(name: "slabs_adjust_mem_limit", scope: !552, file: !552, line: 32, type: !5951, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5951 = !DISubroutineType(types: !5952)
!5952 = !{!790, !747}
!5953 = !DISubprogram(name: "add_delta", scope: !463, file: !463, line: 999, type: !5954, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5954 = !DISubroutineType(types: !5955)
!5955 = !{!544, !894, !1472, !1545, !790, !5851, !579, !1481}
!5956 = !DISubprogram(name: "stats_prefix_record_delete", scope: !5860, file: !5860, line: 28, type: !5866, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5957 = !DISubprogram(name: "item_touch", scope: !463, file: !463, line: 1011, type: !5958, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5958 = !DISubroutineType(types: !5959)
!5959 = !{!1062, !1472, !1545, !635, !894}
!5960 = !DISubprogram(name: "item_flush_expired", scope: !1484, file: !1484, line: 50, type: !5885, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5961 = !DISubprogram(name: "lru_crawler_crawl", scope: !566, file: !566, line: 35, type: !5962, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5962 = !DISubroutineType(types: !5963)
!5963 = !{!565, !579, !559, !632, !5826, !464}
!5964 = !DISubprogram(name: "resp_has_stack", scope: !463, file: !463, line: 1061, type: !1764, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5965 = !DISubprogram(name: "event_del", scope: !5966, file: !5966, line: 1259, type: !5967, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5966 = !DIFile(filename: "/usr/include/event2/event.h", directory: "", checksumkind: CSK_MD5, checksum: "90db4fa73456052afa8984291985dfd5")
!5967 = !DISubroutineType(types: !5968)
!5968 = !{!598, !832}
!5969 = !DISubprogram(name: "start_item_crawler_thread", scope: !566, file: !566, line: 30, type: !5970, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5970 = !DISubroutineType(types: !5971)
!5971 = !{!598}
!5972 = !DISubprogram(name: "stop_item_crawler_thread", scope: !566, file: !566, line: 33, type: !5973, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5973 = !DISubroutineType(types: !5974)
!5974 = !{!598, !790}
!5975 = !DISubprogram(name: "logger_add_watcher", scope: !497, file: !497, line: 246, type: !5976, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!5976 = !DISubroutineType(types: !5977)
!5977 = !{!573, !632, !5826, !602}
