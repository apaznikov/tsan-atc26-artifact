; ModuleID = 'storage.c'
source_filename = "storage.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.stats = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, %struct.timeval, i64, i64 }
%struct.timeval = type { i64, i64 }
%struct.settings = type { i64, i32, i32, i32, ptr, i32, i32, i32, ptr, ptr, i32, double, i32, i32, i32, i8, i32, i32, i8, i32, i32, i32, i32, i32, i32, i8, i8, i8, i8, i8, i8, i32, double, i32, i32, i8, i32, i8, i8, ptr, i32, i32, i32, i32, double, double, i32, i8, i32, i32, i32, i32, i32, i8, i8, i8, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, double, double, i8, i32, i32, ptr, i32 }
%union.pthread_mutex_t = type { %struct.__pthread_mutex_s }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i16, i16, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%union.pthread_cond_t = type { %struct.__pthread_cond_s }
%struct.__pthread_cond_s = type { %union.__atomic_wide_counter, %union.__atomic_wide_counter, [2 x i32], [2 x i32], i32, i32, [2 x i32] }
%union.__atomic_wide_counter = type { i64 }
%struct.extstore_stats = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, ptr }
%struct.extstore_page_data = type { i64, i64, i32, i32, i8 }
%struct.iovec = type { ptr, i64 }
%struct.lru_pull_tail_return = type { ptr, i32 }
%struct._obj_io = type { ptr, ptr, ptr, ptr, i32, i32, i32, i32, i16, i32, ptr }
%struct.__storage_buk = type { i32, i32, i32, i64, i64, i32, i32, i32, i32, i8, i8 }
%struct.storage_compact_wrap = type { %struct._obj_io, %union.pthread_mutex_t, i8, i8, i8 }

@ext_storage = external local_unnamed_addr global ptr, align 8
@.str = private unnamed_addr constant [6 x i8] c"%d:%s\00", align 1, !dbg !0
@.str.1 = private unnamed_addr constant [8 x i8] c"version\00", align 1, !dbg !7
@.str.2 = private unnamed_addr constant [5 x i8] c"%llu\00", align 1, !dbg !12
@.str.3 = private unnamed_addr constant [6 x i8] c"bytes\00", align 1, !dbg !17
@.str.4 = private unnamed_addr constant [7 x i8] c"bucket\00", align 1, !dbg !19
@.str.5 = private unnamed_addr constant [3 x i8] c"%u\00", align 1, !dbg !24
@.str.6 = private unnamed_addr constant [12 x i8] c"free_bucket\00", align 1, !dbg !29
@.str.7 = private unnamed_addr constant [22 x i8] c"extstore_compact_lost\00", align 1, !dbg !34
@stats = external local_unnamed_addr global %struct.stats, align 8
@.str.8 = private unnamed_addr constant [25 x i8] c"extstore_compact_rescues\00", align 1, !dbg !39
@.str.9 = private unnamed_addr constant [27 x i8] c"extstore_compact_resc_cold\00", align 1, !dbg !44
@.str.10 = private unnamed_addr constant [26 x i8] c"extstore_compact_resc_old\00", align 1, !dbg !49
@.str.11 = private unnamed_addr constant [25 x i8] c"extstore_compact_skipped\00", align 1, !dbg !54
@.str.12 = private unnamed_addr constant [21 x i8] c"extstore_page_allocs\00", align 1, !dbg !56
@.str.13 = private unnamed_addr constant [24 x i8] c"extstore_page_evictions\00", align 1, !dbg !61
@.str.14 = private unnamed_addr constant [23 x i8] c"extstore_page_reclaims\00", align 1, !dbg !66
@.str.15 = private unnamed_addr constant [20 x i8] c"extstore_pages_free\00", align 1, !dbg !71
@.str.16 = private unnamed_addr constant [20 x i8] c"extstore_pages_used\00", align 1, !dbg !76
@.str.17 = private unnamed_addr constant [25 x i8] c"extstore_objects_evicted\00", align 1, !dbg !78
@.str.18 = private unnamed_addr constant [22 x i8] c"extstore_objects_read\00", align 1, !dbg !80
@.str.19 = private unnamed_addr constant [25 x i8] c"extstore_objects_written\00", align 1, !dbg !82
@.str.20 = private unnamed_addr constant [22 x i8] c"extstore_objects_used\00", align 1, !dbg !84
@.str.21 = private unnamed_addr constant [23 x i8] c"extstore_bytes_evicted\00", align 1, !dbg !86
@.str.22 = private unnamed_addr constant [23 x i8] c"extstore_bytes_written\00", align 1, !dbg !88
@.str.23 = private unnamed_addr constant [20 x i8] c"extstore_bytes_read\00", align 1, !dbg !90
@.str.24 = private unnamed_addr constant [20 x i8] c"extstore_bytes_used\00", align 1, !dbg !92
@.str.25 = private unnamed_addr constant [26 x i8] c"extstore_bytes_fragmented\00", align 1, !dbg !94
@.str.26 = private unnamed_addr constant [24 x i8] c"extstore_limit_maxbytes\00", align 1, !dbg !96
@.str.27 = private unnamed_addr constant [18 x i8] c"extstore_io_queue\00", align 1, !dbg !98
@settings = external global %struct.settings, align 8
@.str.28 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1, !dbg !103
@storage_write_plock = internal global %union.pthread_mutex_t zeroinitializer, align 8, !dbg !108
@storage_write_tid = internal global i64 0, align 8, !dbg !1170
@stderr = external local_unnamed_addr global ptr, align 8
@.str.29 = private unnamed_addr constant [39 x i8] c"Can't create storage_write thread: %s\0A\00", align 1, !dbg !927
@.str.30 = private unnamed_addr constant [13 x i8] c"mc-ext-write\00", align 1, !dbg !932
@storage_compact_plock = internal global %union.pthread_mutex_t zeroinitializer, align 8, !dbg !1136
@storage_compact_cond = internal global %union.pthread_cond_t zeroinitializer, align 8, !dbg !1138
@storage_compact_tid = internal global i64 0, align 8, !dbg !1134
@.str.31 = private unnamed_addr constant [41 x i8] c"Can't create storage_compact thread: %s\0A\00", align 1, !dbg !937
@.str.32 = private unnamed_addr constant [15 x i8] c"mc-ext-compact\00", align 1, !dbg !942
@.str.33 = private unnamed_addr constant [2 x i8] c":\00", align 1, !dbg !947
@.str.34 = private unnamed_addr constant [73 x i8] c"must supply size to ext_path, ie: ext_path=/f/e:64m (M|G|T|P supported)\0A\00", align 1, !dbg !952
@.str.35 = private unnamed_addr constant [45 x i8] c"supplied ext_path has zero size, cannot use\0A\00", align 1, !dbg !957
@.str.36 = private unnamed_addr constant [8 x i8] c"compact\00", align 1, !dbg !962
@.str.37 = private unnamed_addr constant [7 x i8] c"lowttl\00", align 1, !dbg !964
@.str.38 = private unnamed_addr constant [8 x i8] c"chunked\00", align 1, !dbg !966
@.str.39 = private unnamed_addr constant [8 x i8] c"default\00", align 1, !dbg !968
@.str.40 = private unnamed_addr constant [12 x i8] c"coldcompact\00", align 1, !dbg !970
@.str.41 = private unnamed_addr constant [4 x i8] c"old\00", align 1, !dbg !972
@.str.42 = private unnamed_addr constant [29 x i8] c"Unknown extstore bucket: %s\0A\00", align 1, !dbg !975
@.str.43 = private unnamed_addr constant [14 x i8] c"ext_page_size\00", align 1, !dbg !980
@.str.44 = private unnamed_addr constant [14 x i8] c"ext_wbuf_size\00", align 1, !dbg !985
@.str.45 = private unnamed_addr constant [12 x i8] c"ext_threads\00", align 1, !dbg !987
@.str.46 = private unnamed_addr constant [13 x i8] c"ext_io_depth\00", align 1, !dbg !989
@.str.47 = private unnamed_addr constant [9 x i8] c"ext_path\00", align 1, !dbg !991
@.str.48 = private unnamed_addr constant [14 x i8] c"ext_item_size\00", align 1, !dbg !996
@.str.49 = private unnamed_addr constant [13 x i8] c"ext_item_age\00", align 1, !dbg !998
@.str.50 = private unnamed_addr constant [12 x i8] c"ext_low_ttl\00", align 1, !dbg !1000
@.str.51 = private unnamed_addr constant [17 x i8] c"ext_recache_rate\00", align 1, !dbg !1002
@.str.52 = private unnamed_addr constant [18 x i8] c"ext_compact_under\00", align 1, !dbg !1007
@.str.53 = private unnamed_addr constant [15 x i8] c"ext_drop_under\00", align 1, !dbg !1009
@.str.54 = private unnamed_addr constant [14 x i8] c"ext_max_sleep\00", align 1, !dbg !1011
@.str.55 = private unnamed_addr constant [13 x i8] c"ext_max_frag\00", align 1, !dbg !1013
@.str.56 = private unnamed_addr constant [16 x i8] c"ext_drop_unread\00", align 1, !dbg !1015
@.str.57 = private unnamed_addr constant [24 x i8] c"slab_automove_freeratio\00", align 1, !dbg !1018
@__const.storage_read_config.subopts_tokens = private unnamed_addr constant [16 x ptr] [ptr @.str.43, ptr @.str.44, ptr @.str.45, ptr @.str.46, ptr @.str.47, ptr @.str.48, ptr @.str.49, ptr @.str.50, ptr @.str.51, ptr @.str.52, ptr @.str.53, ptr @.str.54, ptr @.str.55, ptr @.str.56, ptr @.str.57, ptr null], align 16
@.str.58 = private unnamed_addr constant [58 x i8] c"Must specify ext_page_size before any ext_path arguments\0A\00", align 1, !dbg !1020
@.str.59 = private unnamed_addr constant [32 x i8] c"Missing ext_page_size argument\0A\00", align 1, !dbg !1025
@.str.60 = private unnamed_addr constant [43 x i8] c"could not parse argument to ext_page_size\0A\00", align 1, !dbg !1030
@.str.61 = private unnamed_addr constant [32 x i8] c"Missing ext_wbuf_size argument\0A\00", align 1, !dbg !1035
@.str.62 = private unnamed_addr constant [43 x i8] c"could not parse argument to ext_wbuf_size\0A\00", align 1, !dbg !1037
@.str.63 = private unnamed_addr constant [30 x i8] c"Missing ext_threads argument\0A\00", align 1, !dbg !1039
@.str.64 = private unnamed_addr constant [41 x i8] c"could not parse argument to ext_threads\0A\00", align 1, !dbg !1044
@.str.65 = private unnamed_addr constant [31 x i8] c"Missing ext_io_depth argument\0A\00", align 1, !dbg !1046
@.str.66 = private unnamed_addr constant [42 x i8] c"could not parse argument to ext_io_depth\0A\00", align 1, !dbg !1051
@.str.67 = private unnamed_addr constant [32 x i8] c"Missing ext_item_size argument\0A\00", align 1, !dbg !1056
@.str.68 = private unnamed_addr constant [43 x i8] c"could not parse argument to ext_item_size\0A\00", align 1, !dbg !1058
@.str.69 = private unnamed_addr constant [31 x i8] c"Missing ext_item_age argument\0A\00", align 1, !dbg !1060
@.str.70 = private unnamed_addr constant [42 x i8] c"could not parse argument to ext_item_age\0A\00", align 1, !dbg !1062
@.str.71 = private unnamed_addr constant [30 x i8] c"Missing ext_low_ttl argument\0A\00", align 1, !dbg !1064
@.str.72 = private unnamed_addr constant [41 x i8] c"could not parse argument to ext_low_ttl\0A\00", align 1, !dbg !1066
@.str.73 = private unnamed_addr constant [35 x i8] c"Missing ext_recache_rate argument\0A\00", align 1, !dbg !1068
@.str.74 = private unnamed_addr constant [46 x i8] c"could not parse argument to ext_recache_rate\0A\00", align 1, !dbg !1073
@.str.75 = private unnamed_addr constant [36 x i8] c"Missing ext_compact_under argument\0A\00", align 1, !dbg !1078
@.str.76 = private unnamed_addr constant [47 x i8] c"could not parse argument to ext_compact_under\0A\00", align 1, !dbg !1083
@.str.77 = private unnamed_addr constant [33 x i8] c"Missing ext_drop_under argument\0A\00", align 1, !dbg !1088
@.str.78 = private unnamed_addr constant [44 x i8] c"could not parse argument to ext_drop_under\0A\00", align 1, !dbg !1093
@.str.79 = private unnamed_addr constant [32 x i8] c"Missing ext_max_sleep argument\0A\00", align 1, !dbg !1098
@.str.80 = private unnamed_addr constant [43 x i8] c"could not parse argument to ext_max_sleep\0A\00", align 1, !dbg !1100
@.str.81 = private unnamed_addr constant [31 x i8] c"Missing ext_max_frag argument\0A\00", align 1, !dbg !1102
@.str.82 = private unnamed_addr constant [42 x i8] c"could not parse argument to ext_max_frag\0A\00", align 1, !dbg !1104
@.str.83 = private unnamed_addr constant [42 x i8] c"Missing slab_automove_freeratio argument\0A\00", align 1, !dbg !1106
@.str.84 = private unnamed_addr constant [53 x i8] c"could not parse argument to slab_automove_freeratio\0A\00", align 1, !dbg !1108
@.str.85 = private unnamed_addr constant [35 x i8] c"failed to parse ext_path argument\0A\00", align 1, !dbg !1113
@.str.86 = private unnamed_addr constant [55 x i8] c"missing argument to ext_path, ie: ext_path=/d/file:5G\0A\00", align 1, !dbg !1115
@.str.87 = private unnamed_addr constant [24 x i8] c"Illegal suboption \22%s\22\0A\00", align 1, !dbg !1120
@.str.88 = private unnamed_addr constant [64 x i8] c"-I (item_size_max: %d) cannot be larger than ext_wbuf_size: %d\0A\00", align 1, !dbg !1122
@.str.89 = private unnamed_addr constant [56 x i8] c"Cannot use UDP with extstore enabled (-U 0 to disable)\0A\00", align 1, !dbg !1125
@.str.90 = private unnamed_addr constant [43 x i8] c"Failed to initialize external storage: %s\0A\00", align 1, !dbg !1130
@.str.91 = private unnamed_addr constant [14 x i8] c"extstore open\00", align 1, !dbg !1132
@crc32c = external local_unnamed_addr global ptr, align 8
@.str.92 = private unnamed_addr constant [4 x i8] c"VA \00", align 1, !dbg !1172
@.str.93 = private unnamed_addr constant [5 x i8] c"EN\0D\0A\00", align 1, !dbg !1174
@current_time = external global i32, align 4
@.str.94 = private unnamed_addr constant [57 x i8] c"Failed to allocate logger for storage compaction thread\0A\00", align 1, !dbg !1176
@logger_key = external local_unnamed_addr global i32, align 4
@.str.95 = private unnamed_addr constant [66 x i8] c"Failed to allocate readback buffer for storage compaction thread\0A\00", align 1, !dbg !1181
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local zeroext i1 @storage_validate_item(ptr noundef %e, ptr nocapture noundef readonly %it) local_unnamed_addr #0 !dbg !1194 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !1198, metadata !DIExpression()), !dbg !1201
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1199, metadata !DIExpression()), !dbg !1201
  %data = getelementptr inbounds i8, ptr %it, i64 48, !dbg !1202
  %nkey = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1202
  %0 = load i8, ptr %nkey, align 1, !dbg !1202, !tbaa !1203
  %idx.ext = zext i8 %0 to i64
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %idx.ext, !dbg !1202
  %add.ptr1 = getelementptr inbounds i8, ptr %add.ptr, i64 1, !dbg !1202
  %it_flags = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1202
  %1 = load i16, ptr %it_flags, align 2, !dbg !1202, !tbaa !1206
  %conv2 = zext i16 %1 to i32, !dbg !1202
  %and = lshr i32 %conv2, 6, !dbg !1202
  %2 = and i32 %and, 4, !dbg !1202
  %cond = zext nneg i32 %2 to i64, !dbg !1202
  %add.ptr3 = getelementptr inbounds i8, ptr %add.ptr1, i64 %cond, !dbg !1202
  %and6 = shl nuw nsw i32 %conv2, 2, !dbg !1202
  %3 = and i32 %and6, 8, !dbg !1202
  %cond8 = zext nneg i32 %3 to i64, !dbg !1202
  %add.ptr9 = getelementptr inbounds i8, ptr %add.ptr3, i64 %cond8, !dbg !1202
  tail call void @llvm.dbg.value(metadata ptr %add.ptr9, metadata !1200, metadata !DIExpression()), !dbg !1201
  %page_id = getelementptr inbounds i8, ptr %add.ptr9, i64 8, !dbg !1208
  %4 = load i16, ptr %page_id, align 4, !dbg !1208, !tbaa !1210
  %conv10 = zext i16 %4 to i32, !dbg !1213
  %5 = load i32, ptr %add.ptr9, align 4, !dbg !1214, !tbaa !1215
  %conv11 = zext i32 %5 to i64, !dbg !1216
  %call = tail call i32 @extstore_check(ptr noundef %e, i32 noundef %conv10, i64 noundef %conv11) #23, !dbg !1217
  %cmp.not = icmp eq i32 %call, 0, !dbg !1218
  ret i1 %cmp.not, !dbg !1219
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

declare !dbg !1220 i32 @extstore_check(ptr noundef, i32 noundef, i64 noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @storage_delete(ptr noundef %e, ptr nocapture noundef readonly %it) local_unnamed_addr #0 !dbg !1223 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !1227, metadata !DIExpression()), !dbg !1232
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1228, metadata !DIExpression()), !dbg !1232
  %it_flags = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1233
  %0 = load i16, ptr %it_flags, align 2, !dbg !1233, !tbaa !1206
  %conv = zext i16 %0 to i32, !dbg !1234
  %and = and i32 %conv, 128, !dbg !1235
  %tobool.not = icmp eq i32 %and, 0, !dbg !1235
  br i1 %tobool.not, label %if.end, label %if.then, !dbg !1236

if.then:                                          ; preds = %entry
  %data = getelementptr inbounds i8, ptr %it, i64 48, !dbg !1237
  %nkey = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1237
  %1 = load i8, ptr %nkey, align 1, !dbg !1237, !tbaa !1203
  %idx.ext = zext i8 %1 to i64
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %idx.ext, !dbg !1237
  %add.ptr2 = getelementptr inbounds i8, ptr %add.ptr, i64 1, !dbg !1237
  %and5 = lshr i32 %conv, 6, !dbg !1237
  %2 = and i32 %and5, 4, !dbg !1237
  %cond = zext nneg i32 %2 to i64, !dbg !1237
  %add.ptr7 = getelementptr inbounds i8, ptr %add.ptr2, i64 %cond, !dbg !1237
  %and10 = shl nuw nsw i32 %conv, 2, !dbg !1237
  %3 = and i32 %and10, 8, !dbg !1237
  %cond12 = zext nneg i32 %3 to i64, !dbg !1237
  %add.ptr13 = getelementptr inbounds i8, ptr %add.ptr7, i64 %cond12, !dbg !1237
  tail call void @llvm.dbg.value(metadata ptr %add.ptr13, metadata !1229, metadata !DIExpression()), !dbg !1238
  %page_id = getelementptr inbounds i8, ptr %add.ptr13, i64 8, !dbg !1239
  %4 = load i16, ptr %page_id, align 4, !dbg !1239, !tbaa !1210
  %conv14 = zext i16 %4 to i32, !dbg !1240
  %5 = load i32, ptr %add.ptr13, align 4, !dbg !1241, !tbaa !1215
  %conv15 = zext i32 %5 to i64, !dbg !1242
  %conv17 = zext i8 %1 to i32, !dbg !1243
  %nbytes = getelementptr inbounds i8, ptr %it, i64 32, !dbg !1243
  %6 = load i32, ptr %nbytes, align 8, !dbg !1243, !tbaa !1244
  %add18 = or disjoint i32 %2, %3, !dbg !1243
  %add20 = or disjoint i32 %add18, 49, !dbg !1243
  %add26 = add nuw nsw i32 %add20, %conv17, !dbg !1243
  %add32 = add i32 %add26, %6, !dbg !1243
  %call = tail call i32 @extstore_delete(ptr noundef %e, i32 noundef %conv14, i64 noundef %conv15, i32 noundef 1, i32 noundef %add32) #23, !dbg !1245
  br label %if.end, !dbg !1246

if.end:                                           ; preds = %if.then, %entry
  ret void, !dbg !1247
}

declare !dbg !1248 i32 @extstore_delete(ptr noundef, i32 noundef, i64 noundef, i32 noundef, i32 noundef) local_unnamed_addr #2

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @process_extstore_stats(ptr nocapture noundef readonly %add_stats, ptr noundef %c) local_unnamed_addr #0 !dbg !1251 {
entry:
  %key_str = alloca [128 x i8], align 16, !DIAssignID !1303
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1266, metadata !DIExpression(), metadata !1303, metadata ptr %key_str, metadata !DIExpression()), !dbg !1304
  %val_str = alloca [128 x i8], align 16, !DIAssignID !1305
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1270, metadata !DIExpression(), metadata !1305, metadata ptr %val_str, metadata !DIExpression()), !dbg !1304
  %st = alloca %struct.extstore_stats, align 8, !DIAssignID !1306
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1273, metadata !DIExpression(), metadata !1306, metadata ptr %st, metadata !DIExpression()), !dbg !1304
  tail call void @llvm.dbg.value(metadata ptr %add_stats, metadata !1263, metadata !DIExpression()), !dbg !1304
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1264, metadata !DIExpression()), !dbg !1304
  call void @llvm.lifetime.start.p0(i64 128, ptr nonnull %key_str) #23, !dbg !1307
  call void @llvm.lifetime.start.p0(i64 128, ptr nonnull %val_str) #23, !dbg !1308
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1271, metadata !DIExpression()), !dbg !1304
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1272, metadata !DIExpression()), !dbg !1304
  call void @llvm.lifetime.start.p0(i64 144, ptr nonnull %st) #23, !dbg !1309
  %0 = load ptr, ptr @ext_storage, align 8, !dbg !1310, !tbaa !1311
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1302, metadata !DIExpression()), !dbg !1304
  %cmp = icmp eq ptr %0, null, !dbg !1313
  br i1 %cmp, label %cleanup, label %if.end, !dbg !1315

if.end:                                           ; preds = %entry
  call void @extstore_get_stats(ptr noundef nonnull %0, ptr noundef nonnull %st) #23, !dbg !1316
  %page_count = getelementptr inbounds i8, ptr %st, i64 8, !dbg !1317
  %1 = load i64, ptr %page_count, align 8, !dbg !1317, !tbaa !1318
  %call = call noalias ptr @calloc(i64 noundef %1, i64 noundef 32) #24, !dbg !1321
  %page_data = getelementptr inbounds i8, ptr %st, i64 136, !dbg !1322
  store ptr %call, ptr %page_data, align 8, !dbg !1323, !tbaa !1324, !DIAssignID !1325
  tail call void @llvm.dbg.assign(metadata ptr %call, metadata !1273, metadata !DIExpression(DW_OP_LLVM_fragment, 1088, 64), metadata !1325, metadata ptr %page_data, metadata !DIExpression()), !dbg !1304
  call void @extstore_get_page_data(ptr noundef nonnull %0, ptr noundef nonnull %st) #23, !dbg !1326
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1265, metadata !DIExpression()), !dbg !1304
  %2 = load i64, ptr %page_count, align 8, !dbg !1327, !tbaa !1318
  %cmp271.not = icmp eq i64 %2, 0, !dbg !1330
  br i1 %cmp271.not, label %for.end, label %for.body, !dbg !1331

for.body:                                         ; preds = %if.end, %for.body
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.body ], [ 0, %if.end ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1265, metadata !DIExpression()), !dbg !1304
  %3 = trunc nuw nsw i64 %indvars.iv to i32, !dbg !1332
  %call4 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str, i32 noundef %3, ptr noundef nonnull @.str.1) #23, !dbg !1332
  tail call void @llvm.dbg.value(metadata i32 %call4, metadata !1271, metadata !DIExpression()), !dbg !1304
  %4 = load ptr, ptr %page_data, align 8, !dbg !1332, !tbaa !1324
  %arrayidx = getelementptr inbounds %struct.extstore_page_data, ptr %4, i64 %indvars.iv, !dbg !1332
  %5 = load i64, ptr %arrayidx, align 8, !dbg !1332, !tbaa !1334
  %call7 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.2, i64 noundef %5) #23, !dbg !1332
  tail call void @llvm.dbg.value(metadata i32 %call7, metadata !1272, metadata !DIExpression()), !dbg !1304
  %conv9 = trunc i32 %call4 to i16, !dbg !1332
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv9, ptr noundef nonnull %val_str, i32 noundef %call7, ptr noundef %c) #23, !dbg !1332
  %call12 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str, i32 noundef %3, ptr noundef nonnull @.str.3) #23, !dbg !1337
  tail call void @llvm.dbg.value(metadata i32 %call12, metadata !1271, metadata !DIExpression()), !dbg !1304
  %6 = load ptr, ptr %page_data, align 8, !dbg !1337, !tbaa !1324
  %bytes_used = getelementptr inbounds %struct.extstore_page_data, ptr %6, i64 %indvars.iv, i32 1, !dbg !1337
  %7 = load i64, ptr %bytes_used, align 8, !dbg !1337, !tbaa !1338
  %call17 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.2, i64 noundef %7) #23, !dbg !1337
  tail call void @llvm.dbg.value(metadata i32 %call17, metadata !1272, metadata !DIExpression()), !dbg !1304
  %conv19 = trunc i32 %call12 to i16, !dbg !1337
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv19, ptr noundef nonnull %val_str, i32 noundef %call17, ptr noundef %c) #23, !dbg !1337
  %call22 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str, i32 noundef %3, ptr noundef nonnull @.str.4) #23, !dbg !1339
  tail call void @llvm.dbg.value(metadata i32 %call22, metadata !1271, metadata !DIExpression()), !dbg !1304
  %8 = load ptr, ptr %page_data, align 8, !dbg !1339, !tbaa !1324
  %bucket = getelementptr inbounds %struct.extstore_page_data, ptr %8, i64 %indvars.iv, i32 2, !dbg !1339
  %9 = load i32, ptr %bucket, align 8, !dbg !1339, !tbaa !1340
  %call27 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.5, i32 noundef %9) #23, !dbg !1339
  tail call void @llvm.dbg.value(metadata i32 %call27, metadata !1272, metadata !DIExpression()), !dbg !1304
  %conv29 = trunc i32 %call22 to i16, !dbg !1339
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv29, ptr noundef nonnull %val_str, i32 noundef %call27, ptr noundef %c) #23, !dbg !1339
  %call32 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str, i32 noundef %3, ptr noundef nonnull @.str.6) #23, !dbg !1341
  tail call void @llvm.dbg.value(metadata i32 %call32, metadata !1271, metadata !DIExpression()), !dbg !1304
  %10 = load ptr, ptr %page_data, align 8, !dbg !1341, !tbaa !1324
  %free_bucket = getelementptr inbounds %struct.extstore_page_data, ptr %10, i64 %indvars.iv, i32 3, !dbg !1341
  %11 = load i32, ptr %free_bucket, align 4, !dbg !1341, !tbaa !1342
  %call37 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.5, i32 noundef %11) #23, !dbg !1341
  tail call void @llvm.dbg.value(metadata i32 %call37, metadata !1272, metadata !DIExpression()), !dbg !1304
  %conv39 = trunc i32 %call32 to i16, !dbg !1341
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv39, ptr noundef nonnull %val_str, i32 noundef %call37, ptr noundef %c) #23, !dbg !1341
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !1343
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !1265, metadata !DIExpression()), !dbg !1304
  %12 = load i64, ptr %page_count, align 8, !dbg !1327, !tbaa !1318
  %cmp2 = icmp ugt i64 %12, %indvars.iv.next, !dbg !1330
  br i1 %cmp2, label %for.body, label %for.end, !dbg !1331, !llvm.loop !1344

for.end:                                          ; preds = %for.body, %if.end
  %13 = load ptr, ptr %page_data, align 8, !dbg !1347, !tbaa !1324
  call void @free(ptr noundef %13) #23, !dbg !1348
  br label %cleanup, !dbg !1349

cleanup:                                          ; preds = %entry, %for.end
  call void @llvm.lifetime.end.p0(i64 144, ptr nonnull %st) #23, !dbg !1349
  call void @llvm.lifetime.end.p0(i64 128, ptr nonnull %val_str) #23, !dbg !1349
  call void @llvm.lifetime.end.p0(i64 128, ptr nonnull %key_str) #23, !dbg !1349
  ret void, !dbg !1349
}

declare !dbg !1350 void @extstore_get_stats(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite)
declare !dbg !1354 noalias noundef ptr @calloc(i64 noundef, i64 noundef) local_unnamed_addr #3

declare !dbg !1358 void @extstore_get_page_data(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nofree nounwind
declare !dbg !1359 noundef i32 @snprintf(ptr noalias nocapture noundef writeonly, i64 noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #4

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !1365 void @free(ptr allocptr nocapture noundef) local_unnamed_addr #5

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @storage_stats(ptr noundef %add_stats, ptr noundef %c) local_unnamed_addr #0 !dbg !1368 {
entry:
  %st = alloca %struct.extstore_stats, align 8, !DIAssignID !1373
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1372, metadata !DIExpression(), metadata !1373, metadata ptr %st, metadata !DIExpression()), !dbg !1374
  tail call void @llvm.dbg.value(metadata ptr %add_stats, metadata !1370, metadata !DIExpression()), !dbg !1374
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1371, metadata !DIExpression()), !dbg !1374
  call void @llvm.lifetime.start.p0(i64 144, ptr nonnull %st) #23, !dbg !1375
  %0 = load ptr, ptr @ext_storage, align 8, !dbg !1376, !tbaa !1311
  %tobool.not = icmp eq ptr %0, null, !dbg !1376
  br i1 %tobool.not, label %if.end, label %if.then, !dbg !1378

if.then:                                          ; preds = %entry
  tail call void @STATS_LOCK() #23, !dbg !1379
  %1 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 19), align 8, !dbg !1381, !tbaa !1382
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.7, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %1) #23, !dbg !1381
  %2 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 20), align 8, !dbg !1385, !tbaa !1386
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.8, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %2) #23, !dbg !1385
  %3 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 22), align 8, !dbg !1387, !tbaa !1388
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.9, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %3) #23, !dbg !1387
  %4 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 23), align 8, !dbg !1389, !tbaa !1390
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.10, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %4) #23, !dbg !1389
  %5 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 21), align 8, !dbg !1391, !tbaa !1392
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.11, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %5) #23, !dbg !1391
  tail call void @STATS_UNLOCK() #23, !dbg !1393
  %6 = load ptr, ptr @ext_storage, align 8, !dbg !1394, !tbaa !1311
  call void @extstore_get_stats(ptr noundef %6, ptr noundef nonnull %st) #23, !dbg !1395
  %7 = load i64, ptr %st, align 8, !dbg !1396, !tbaa !1397
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.12, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %7) #23, !dbg !1396
  %page_evictions = getelementptr inbounds i8, ptr %st, i64 16, !dbg !1398
  %8 = load i64, ptr %page_evictions, align 8, !dbg !1398, !tbaa !1399
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.13, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %8) #23, !dbg !1398
  %page_reclaims = getelementptr inbounds i8, ptr %st, i64 24, !dbg !1400
  %9 = load i64, ptr %page_reclaims, align 8, !dbg !1400, !tbaa !1401
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.14, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %9) #23, !dbg !1400
  %pages_free = getelementptr inbounds i8, ptr %st, i64 40, !dbg !1402
  %10 = load i64, ptr %pages_free, align 8, !dbg !1402, !tbaa !1403
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.15, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %10) #23, !dbg !1402
  %pages_used = getelementptr inbounds i8, ptr %st, i64 48, !dbg !1404
  %11 = load i64, ptr %pages_used, align 8, !dbg !1404, !tbaa !1405
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.16, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %11) #23, !dbg !1404
  %objects_evicted = getelementptr inbounds i8, ptr %st, i64 56, !dbg !1406
  %12 = load i64, ptr %objects_evicted, align 8, !dbg !1406, !tbaa !1407
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.17, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %12) #23, !dbg !1406
  %objects_read = getelementptr inbounds i8, ptr %st, i64 64, !dbg !1408
  %13 = load i64, ptr %objects_read, align 8, !dbg !1408, !tbaa !1409
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.18, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %13) #23, !dbg !1408
  %objects_written = getelementptr inbounds i8, ptr %st, i64 72, !dbg !1410
  %14 = load i64, ptr %objects_written, align 8, !dbg !1410, !tbaa !1411
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.19, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %14) #23, !dbg !1410
  %objects_used = getelementptr inbounds i8, ptr %st, i64 80, !dbg !1412
  %15 = load i64, ptr %objects_used, align 8, !dbg !1412, !tbaa !1413
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.20, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %15) #23, !dbg !1412
  %bytes_evicted = getelementptr inbounds i8, ptr %st, i64 88, !dbg !1414
  %16 = load i64, ptr %bytes_evicted, align 8, !dbg !1414, !tbaa !1415
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.21, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %16) #23, !dbg !1414
  %bytes_written = getelementptr inbounds i8, ptr %st, i64 96, !dbg !1416
  %17 = load i64, ptr %bytes_written, align 8, !dbg !1416, !tbaa !1417
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.22, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %17) #23, !dbg !1416
  %bytes_read = getelementptr inbounds i8, ptr %st, i64 104, !dbg !1418
  %18 = load i64, ptr %bytes_read, align 8, !dbg !1418, !tbaa !1419
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.23, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %18) #23, !dbg !1418
  %bytes_used = getelementptr inbounds i8, ptr %st, i64 112, !dbg !1420
  %19 = load i64, ptr %bytes_used, align 8, !dbg !1420, !tbaa !1421
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.24, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %19) #23, !dbg !1420
  %bytes_fragmented = getelementptr inbounds i8, ptr %st, i64 120, !dbg !1422
  %20 = load i64, ptr %bytes_fragmented, align 8, !dbg !1422, !tbaa !1423
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.25, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %20) #23, !dbg !1422
  %page_count = getelementptr inbounds i8, ptr %st, i64 8, !dbg !1424
  %21 = load i64, ptr %page_count, align 8, !dbg !1424, !tbaa !1318
  %page_size = getelementptr inbounds i8, ptr %st, i64 32, !dbg !1424
  %22 = load i64, ptr %page_size, align 8, !dbg !1424, !tbaa !1425
  %mul = mul i64 %22, %21, !dbg !1424
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.26, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %mul) #23, !dbg !1424
  %io_queue = getelementptr inbounds i8, ptr %st, i64 128, !dbg !1426
  %23 = load i64, ptr %io_queue, align 8, !dbg !1426, !tbaa !1427
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.27, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.2, i64 noundef %23) #23, !dbg !1426
  br label %if.end, !dbg !1428

if.end:                                           ; preds = %if.then, %entry
  call void @llvm.lifetime.end.p0(i64 144, ptr nonnull %st) #23, !dbg !1429
  ret void, !dbg !1429
}

declare !dbg !1430 void @STATS_LOCK() local_unnamed_addr #2

declare !dbg !1433 void @append_stat(ptr noundef, ptr noundef, ptr noundef, ptr noundef, ...) local_unnamed_addr #2

declare !dbg !1436 void @STATS_UNLOCK() local_unnamed_addr #2

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 -1, 1) i32 @storage_get_item(ptr noundef %c, ptr noundef %it, ptr noundef %resp) local_unnamed_addr #0 !dbg !1437 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1441, metadata !DIExpression()), !dbg !1461
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1442, metadata !DIExpression()), !dbg !1461
  tail call void @llvm.dbg.value(metadata ptr %resp, metadata !1443, metadata !DIExpression()), !dbg !1461
  %data = getelementptr inbounds i8, ptr %it, i64 48, !dbg !1462
  %nkey = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1462
  %0 = load i8, ptr %nkey, align 1, !dbg !1462, !tbaa !1203
  %idx.ext = zext i8 %0 to i64
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %idx.ext, !dbg !1462
  %add.ptr1 = getelementptr inbounds i8, ptr %add.ptr, i64 1, !dbg !1462
  %it_flags = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1462
  %1 = load i16, ptr %it_flags, align 2, !dbg !1462, !tbaa !1206
  %conv2 = zext i16 %1 to i32, !dbg !1462
  %and = lshr i32 %conv2, 6, !dbg !1462
  %2 = and i32 %and, 4, !dbg !1462
  %cond = zext nneg i32 %2 to i64, !dbg !1462
  %add.ptr3 = getelementptr inbounds i8, ptr %add.ptr1, i64 %cond, !dbg !1462
  %and6 = shl nuw nsw i32 %conv2, 2, !dbg !1462
  %3 = and i32 %and6, 8, !dbg !1462
  %cond8 = zext nneg i32 %3 to i64, !dbg !1462
  %add.ptr9 = getelementptr inbounds i8, ptr %add.ptr3, i64 %cond8, !dbg !1462
  tail call void @llvm.dbg.value(metadata ptr %add.ptr9, metadata !1444, metadata !DIExpression()), !dbg !1461
  %call = tail call ptr @conn_io_queue_get(ptr noundef %c, i32 noundef 1) #23, !dbg !1463
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !1445, metadata !DIExpression()), !dbg !1461
  %4 = load i8, ptr %nkey, align 1, !dbg !1464, !tbaa !1203
  %conv11 = zext i8 %4 to i64, !dbg !1464
  %add12 = add nuw nsw i64 %conv11, 49, !dbg !1464
  %nbytes = getelementptr inbounds i8, ptr %it, i64 32, !dbg !1464
  %5 = load i32, ptr %nbytes, align 8, !dbg !1464, !tbaa !1244
  %conv13 = sext i32 %5 to i64, !dbg !1464
  %add14 = add nsw i64 %add12, %conv13, !dbg !1464
  %6 = load i16, ptr %it_flags, align 2, !dbg !1464, !tbaa !1206
  %conv16 = zext i16 %6 to i32, !dbg !1464
  %and17 = lshr i32 %conv16, 6, !dbg !1464
  %7 = and i32 %and17, 4, !dbg !1464
  %cond19 = zext nneg i32 %7 to i64, !dbg !1464
  %add20 = add nsw i64 %add14, %cond19, !dbg !1464
  %and23 = shl nuw nsw i32 %conv16, 2, !dbg !1464
  %8 = and i32 %and23, 8, !dbg !1464
  %cond25 = zext nneg i32 %8 to i64, !dbg !1464
  %add26 = add nsw i64 %add20, %cond25, !dbg !1464
  tail call void @llvm.dbg.value(metadata i64 %add26, metadata !1446, metadata !DIExpression()), !dbg !1461
  %call27 = tail call i32 @slabs_clsid(i64 noundef %add26) #23, !dbg !1465
  tail call void @llvm.dbg.value(metadata i32 %call27, metadata !1447, metadata !DIExpression()), !dbg !1461
  tail call void @llvm.dbg.value(metadata i8 0, metadata !1449, metadata !DIExpression()), !dbg !1461
  %9 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 22), align 8, !dbg !1466, !tbaa !1467
  %conv28 = sext i32 %9 to i64, !dbg !1470
  %cmp = icmp ugt i64 %add26, %conv28, !dbg !1471
  br i1 %cmp, label %if.then, label %if.else58, !dbg !1472

if.then:                                          ; preds = %entry
  %10 = load i16, ptr %it_flags, align 2, !dbg !1473, !tbaa !1206
  %conv31 = zext i16 %10 to i32, !dbg !1473
  %and32 = and i32 %conv31, 256, !dbg !1473
  %tobool33.not = icmp eq i32 %and32, 0, !dbg !1473
  %.pre = load i8, ptr %nkey, align 1, !dbg !1476, !tbaa !1203
  %.pre332 = zext i8 %.pre to i64
  br i1 %tobool33.not, label %if.end, label %if.then34, !dbg !1477

if.then34:                                        ; preds = %if.then
  %add.ptr39 = getelementptr inbounds i8, ptr %data, i64 %.pre332, !dbg !1478
  %add.ptr40 = getelementptr inbounds i8, ptr %add.ptr39, i64 1, !dbg !1478
  %and43 = shl nuw nsw i32 %conv31, 2, !dbg !1478
  %11 = and i32 %and43, 8, !dbg !1478
  %cond45 = zext nneg i32 %11 to i64, !dbg !1478
  %add.ptr46 = getelementptr inbounds i8, ptr %add.ptr40, i64 %cond45, !dbg !1478
  %12 = load i32, ptr %add.ptr46, align 4, !dbg !1478, !tbaa !1244
  tail call void @llvm.dbg.value(metadata i32 %12, metadata !1450, metadata !DIExpression()), !dbg !1480
  br label %if.end, !dbg !1478

if.end:                                           ; preds = %if.then, %if.then34
  %flags.0 = phi i32 [ %12, %if.then34 ], [ 0, %if.then ], !dbg !1473
  tail call void @llvm.dbg.value(metadata i32 %flags.0, metadata !1450, metadata !DIExpression()), !dbg !1480
  %13 = shl i16 %10, 2, !dbg !1481
  %14 = and i16 %13, 8, !dbg !1481
  %cond52 = zext nneg i16 %14 to i64, !dbg !1481
  %add.ptr53 = getelementptr inbounds i8, ptr %data, i64 %cond52, !dbg !1481
  %exptime = getelementptr inbounds i8, ptr %it, i64 28, !dbg !1482
  %15 = load i32, ptr %exptime, align 4, !dbg !1482, !tbaa !1244
  %16 = load i32, ptr %nbytes, align 8, !dbg !1483, !tbaa !1244
  %call57 = tail call ptr @item_alloc(ptr noundef nonnull %add.ptr53, i64 noundef %.pre332, i32 noundef %flags.0, i32 noundef %15, i32 noundef %16) #23, !dbg !1484
  tail call void @llvm.dbg.value(metadata ptr %call57, metadata !1448, metadata !DIExpression()), !dbg !1461
  tail call void @llvm.dbg.value(metadata i8 1, metadata !1449, metadata !DIExpression()), !dbg !1461
  br label %if.end60, !dbg !1485

if.else58:                                        ; preds = %entry
  %call59 = tail call ptr @do_item_alloc_pull(i64 noundef %add26, i32 noundef %call27) #23, !dbg !1486
  tail call void @llvm.dbg.value(metadata ptr %call59, metadata !1448, metadata !DIExpression()), !dbg !1461
  br label %if.end60

if.end60:                                         ; preds = %if.else58, %if.end
  %new_it.0 = phi ptr [ %call57, %if.end ], [ %call59, %if.else58 ], !dbg !1488
  tail call void @llvm.dbg.value(metadata ptr %new_it.0, metadata !1448, metadata !DIExpression()), !dbg !1461
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !1449, metadata !DIExpression()), !dbg !1461
  %cmp61 = icmp eq ptr %new_it.0, null, !dbg !1489
  br i1 %cmp61, label %cleanup206, label %if.end64, !dbg !1491

if.end64:                                         ; preds = %if.end60
  %conv65 = trunc i32 %call27 to i8, !dbg !1492
  %slabs_clsid = getelementptr inbounds i8, ptr %new_it.0, i64 40, !dbg !1493
  store i8 %conv65, ptr %slabs_clsid, align 8, !dbg !1494, !tbaa !1203
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !1495
  %17 = load ptr, ptr %thread, align 8, !dbg !1495, !tbaa !1496
  %io_cache = getelementptr inbounds i8, ptr %17, i64 6896, !dbg !1504
  %18 = load ptr, ptr %io_cache, align 8, !dbg !1504, !tbaa !1505
  %call66 = tail call ptr @do_cache_alloc(ptr noundef %18) #23, !dbg !1510
  tail call void @llvm.dbg.value(metadata ptr %call66, metadata !1453, metadata !DIExpression()), !dbg !1461
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(136) %call66, i8 0, i64 136, i1 false), !dbg !1511
  %active = getelementptr inbounds i8, ptr %call66, i64 135, !dbg !1512
  store i8 1, ptr %active, align 1, !dbg !1513, !tbaa !1514
  %badcrc = getelementptr inbounds i8, ptr %call66, i64 134, !dbg !1518
  store i8 0, ptr %badcrc, align 2, !dbg !1519, !tbaa !1520
  %noreply = getelementptr inbounds i8, ptr %c, i64 364, !dbg !1521
  %19 = load i8, ptr %noreply, align 4, !dbg !1521, !tbaa !1522, !range !1523, !noundef !1524
  %noreply68 = getelementptr inbounds i8, ptr %call66, i64 132, !dbg !1525
  store i8 %19, ptr %noreply68, align 4, !dbg !1526, !tbaa !1527
  %20 = load ptr, ptr %thread, align 8, !dbg !1528, !tbaa !1496
  %thread70 = getelementptr inbounds i8, ptr %call66, i64 8, !dbg !1529
  store ptr %20, ptr %thread70, align 8, !dbg !1530, !tbaa !1531
  %return_cb = getelementptr inbounds i8, ptr %call66, i64 32, !dbg !1532
  store ptr @storage_return_cb, ptr %return_cb, align 8, !dbg !1533, !tbaa !1534
  %finalize_cb = getelementptr inbounds i8, ptr %call66, i64 40, !dbg !1535
  store ptr @storage_finalize_cb, ptr %finalize_cb, align 8, !dbg !1536, !tbaa !1537
  %hdr_it = getelementptr inbounds i8, ptr %call66, i64 56, !dbg !1538
  store ptr %it, ptr %hdr_it, align 8, !dbg !1539, !tbaa !1540
  %resp71 = getelementptr inbounds i8, ptr %call66, i64 24, !dbg !1541
  store ptr %resp, ptr %resp71, align 8, !dbg !1542, !tbaa !1543
  store i32 1, ptr %call66, align 8, !dbg !1544, !tbaa !1545
  %io_ctx = getelementptr inbounds i8, ptr %call66, i64 64, !dbg !1546
  tail call void @llvm.dbg.value(metadata ptr %io_ctx, metadata !1454, metadata !DIExpression()), !dbg !1461
  br i1 %cmp, label %if.then73, label %if.end170, !dbg !1547

if.then73:                                        ; preds = %if.end64
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1455, metadata !DIExpression()), !dbg !1548
  %nbytes74 = getelementptr inbounds i8, ptr %new_it.0, i64 32, !dbg !1549
  %21 = load i32, ptr %nbytes74, align 8, !dbg !1549, !tbaa !1244
  tail call void @llvm.dbg.value(metadata i32 %21, metadata !1458, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_signed, DW_OP_LLVM_convert, 64, DW_ATE_signed, DW_OP_stack_value)), !dbg !1548
  %nkey77 = getelementptr inbounds i8, ptr %new_it.0, i64 41, !dbg !1550
  %22 = load i8, ptr %nkey77, align 1, !dbg !1550, !tbaa !1203
  %it_flags82 = getelementptr inbounds i8, ptr %new_it.0, i64 38, !dbg !1550
  %23 = load i16, ptr %it_flags82, align 2, !dbg !1550, !tbaa !1206
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %new_it.0, i16 %23, i16 %23, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 48, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 6, DW_OP_shr, DW_OP_constu, 4, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_constu, 8, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  %call94 = tail call noalias dereferenceable_or_null(16384) ptr @malloc(i64 noundef 16384) #25, !dbg !1551
  %iov = getelementptr inbounds i8, ptr %call66, i64 88, !dbg !1552
  store ptr %call94, ptr %iov, align 8, !dbg !1553, !tbaa !1554
  %cmp96 = icmp eq ptr %call94, null, !dbg !1555
  br i1 %cmp96, label %if.then98, label %if.end101, !dbg !1557

if.then98:                                        ; preds = %if.then73
  tail call void @item_remove(ptr noundef nonnull %new_it.0) #23, !dbg !1558
  %24 = load ptr, ptr %thread, align 8, !dbg !1560, !tbaa !1496
  %io_cache100 = getelementptr inbounds i8, ptr %24, i64 6896, !dbg !1561
  %25 = load ptr, ptr %io_cache100, align 8, !dbg !1561, !tbaa !1505
  tail call void @do_cache_free(ptr noundef %25, ptr noundef nonnull %call66) #23, !dbg !1562
  br label %cleanup206, !dbg !1563

if.end101:                                        ; preds = %if.then73
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %new_it.0, i16 %23, i16 %23, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 48, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 6, DW_OP_shr, DW_OP_constu, 4, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_constu, 8, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %new_it.0, i16 %23, i16 %23, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 48, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 6, DW_OP_shr, DW_OP_constu, 4, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_constu, 8, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %new_it.0, i16 %23, i16 %23, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 48, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 6, DW_OP_shr, DW_OP_constu, 4, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_constu, 8, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %new_it.0, i16 %23, i16 %23, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 48, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 6, DW_OP_shr, DW_OP_constu, 4, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_constu, 8, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  %conv83 = zext i16 %23 to i32, !dbg !1550
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %new_it.0, i32 %conv83, i32 %conv83, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 48, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_constu, 6, DW_OP_shr, DW_OP_constu, 4, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_constu, 2, DW_OP_shl, DW_OP_constu, 8, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  %and84 = lshr i32 %conv83, 6, !dbg !1550
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %new_it.0, i32 %conv83, i32 %and84, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 48, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_constu, 4, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_constu, 2, DW_OP_shl, DW_OP_constu, 8, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  %26 = and i32 %and84, 4, !dbg !1550
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %new_it.0, i32 %conv83, i32 %26, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 48, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_constu, 2, DW_OP_shl, DW_OP_constu, 8, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  %cond86 = zext nneg i32 %26 to i64, !dbg !1550
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %new_it.0, i32 %conv83, i64 %cond86, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 48, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_constu, 2, DW_OP_shl, DW_OP_constu, 8, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %new_it.0, i32 %conv83, i64 %cond86, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 48, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_constu, 2, DW_OP_shl, DW_OP_constu, 8, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  %and90 = shl nuw nsw i32 %conv83, 2, !dbg !1550
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %new_it.0, i32 %and90, i64 %cond86, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 48, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_constu, 8, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  %27 = and i32 %and90, 8, !dbg !1550
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %new_it.0, i32 %27, i64 %cond86, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 48, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  %cond92 = zext nneg i32 %27 to i64, !dbg !1550
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %new_it.0, i64 %cond92, i64 %cond86, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 48, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %new_it.0, i64 %cond92, i64 %cond86, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 48, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  tail call void @llvm.dbg.value(metadata i32 %21, metadata !1458, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_signed, DW_OP_LLVM_convert, 64, DW_ATE_signed, DW_OP_stack_value)), !dbg !1548
  store ptr %new_it.0, ptr %call94, align 8, !dbg !1564, !tbaa !1565
  %28 = load i8, ptr %nkey77, align 1, !dbg !1567, !tbaa !1203
  %conv104 = zext i8 %28 to i64, !dbg !1567
  %add115 = or disjoint i64 %cond86, %cond92, !dbg !1567
  %add121 = or disjoint i64 %add115, 49, !dbg !1567
  %sub = add nuw nsw i64 %add121, %conv104, !dbg !1568
  %iov_len = getelementptr inbounds i8, ptr %call94, i64 8, !dbg !1569
  store i64 %sub, ptr %iov_len, align 8, !dbg !1570, !tbaa !1571
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1455, metadata !DIExpression()), !dbg !1548
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %new_it.0, i64 %cond92, i64 %cond86, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 48, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  tail call void @llvm.dbg.value(metadata i32 %21, metadata !1458, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_signed, DW_OP_LLVM_convert, 64, DW_ATE_signed, DW_OP_stack_value)), !dbg !1548
  %cmp126.not327 = icmp eq i32 %21, 0, !dbg !1572
  br i1 %cmp126.not327, label %while.end, label %while.body.preheader, !dbg !1573

while.body.preheader:                             ; preds = %if.end101
  %conv75 = sext i32 %21 to i64, !dbg !1574
  tail call void @llvm.dbg.value(metadata i64 %conv75, metadata !1458, metadata !DIExpression()), !dbg !1548
  %data76 = getelementptr inbounds i8, ptr %new_it.0, i64 48, !dbg !1550
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %data76, i64 %cond92, i64 %cond86, i8 %22), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  %idx.ext79 = zext i8 %22 to i64
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %data76, i64 %cond92, i64 %cond86, i64 %idx.ext79), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 3, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  %add.ptr80 = getelementptr inbounds i8, ptr %data76, i64 %idx.ext79, !dbg !1550
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %add.ptr80, i64 %cond92, i64 %cond86), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  %add.ptr81 = getelementptr inbounds i8, ptr %add.ptr80, i64 1, !dbg !1550
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %add.ptr81, i64 %cond92, i64 %cond86), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 2, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  %add.ptr87 = getelementptr inbounds i8, ptr %add.ptr81, i64 %cond86, !dbg !1550
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %add.ptr87, i64 %cond92), metadata !1459, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1548
  %add.ptr93 = getelementptr inbounds i8, ptr %add.ptr87, i64 %cond92, !dbg !1550
  tail call void @llvm.dbg.value(metadata ptr %add.ptr93, metadata !1459, metadata !DIExpression()), !dbg !1548
  br label %while.body, !dbg !1573

while.body:                                       ; preds = %while.body.preheader, %if.end138
  %indvars.iv = phi i64 [ 1, %while.body.preheader ], [ %indvars.iv.next, %if.end138 ]
  %chunk.0330 = phi ptr [ %add.ptr93, %while.body.preheader ], [ %call128, %if.end138 ]
  %remain.0329 = phi i64 [ %conv75, %while.body.preheader ], [ %sub166, %if.end138 ]
  tail call void @llvm.dbg.value(metadata ptr %chunk.0330, metadata !1459, metadata !DIExpression()), !dbg !1548
  tail call void @llvm.dbg.value(metadata i64 %remain.0329, metadata !1458, metadata !DIExpression()), !dbg !1548
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1455, metadata !DIExpression()), !dbg !1548
  %call128 = tail call ptr @do_item_alloc_chunk(ptr noundef nonnull %chunk.0330, i64 noundef %remain.0329) #23, !dbg !1575
  tail call void @llvm.dbg.value(metadata ptr %call128, metadata !1459, metadata !DIExpression()), !dbg !1548
  %cmp129 = icmp eq ptr %call128, null, !dbg !1577
  %cmp131 = icmp ugt i64 %indvars.iv, 1023
  %or.cond = select i1 %cmp129, i1 true, i1 %cmp131, !dbg !1579
  br i1 %or.cond, label %if.then133, label %if.end138, !dbg !1579

if.then133:                                       ; preds = %while.body
  tail call void @item_remove(ptr noundef nonnull %new_it.0) #23, !dbg !1580
  %29 = load ptr, ptr %iov, align 8, !dbg !1582, !tbaa !1554
  tail call void @free(ptr noundef %29) #23, !dbg !1583
  store ptr null, ptr %iov, align 8, !dbg !1584, !tbaa !1554
  %30 = load ptr, ptr %thread, align 8, !dbg !1585, !tbaa !1496
  %io_cache137 = getelementptr inbounds i8, ptr %30, i64 6896, !dbg !1586
  %31 = load ptr, ptr %io_cache137, align 8, !dbg !1586, !tbaa !1505
  tail call void @do_cache_free(ptr noundef %31, ptr noundef nonnull %call66) #23, !dbg !1587
  br label %cleanup206, !dbg !1588

if.end138:                                        ; preds = %while.body
  %data139 = getelementptr inbounds i8, ptr %call128, i64 42, !dbg !1589
  %32 = load ptr, ptr %iov, align 8, !dbg !1590, !tbaa !1554
  %arrayidx141 = getelementptr inbounds %struct.iovec, ptr %32, i64 %indvars.iv, !dbg !1591
  store ptr %data139, ptr %arrayidx141, align 8, !dbg !1592, !tbaa !1565
  %size = getelementptr inbounds i8, ptr %call128, i64 24, !dbg !1593
  %33 = load i32, ptr %size, align 8, !dbg !1593, !tbaa !1244
  %conv143 = sext i32 %33 to i64, !dbg !1594
  %remain.0.conv143 = tail call i64 @llvm.umin.i64(i64 %remain.0329, i64 %conv143), !dbg !1595
  %iov_len152 = getelementptr inbounds %struct.iovec, ptr %32, i64 %indvars.iv, i32 1, !dbg !1596
  store i64 %remain.0.conv143, ptr %iov_len152, align 8, !dbg !1597, !tbaa !1571
  %conv163 = trunc i64 %remain.0.conv143 to i32, !dbg !1598
  %used = getelementptr inbounds i8, ptr %call128, i64 28, !dbg !1599
  store i32 %conv163, ptr %used, align 4, !dbg !1600, !tbaa !1244
  %sub166 = sub i64 %remain.0329, %conv143, !dbg !1601
  tail call void @llvm.dbg.value(metadata i64 %sub166, metadata !1458, metadata !DIExpression()), !dbg !1548
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !1602
  tail call void @llvm.dbg.value(metadata ptr %call128, metadata !1459, metadata !DIExpression()), !dbg !1548
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !1455, metadata !DIExpression()), !dbg !1548
  %cmp126.not = icmp eq i64 %sub166, 0, !dbg !1572
  br i1 %cmp126.not, label %while.end.loopexit, label %while.body, !dbg !1573, !llvm.loop !1603

while.end.loopexit:                               ; preds = %if.end138
  %34 = trunc nuw nsw i64 %indvars.iv.next to i32, !dbg !1605
  br label %while.end, !dbg !1605

while.end:                                        ; preds = %while.end.loopexit, %if.end101
  %ciovcnt.0.lcssa = phi i32 [ 1, %if.end101 ], [ %34, %while.end.loopexit ], !dbg !1548
  %iovcnt = getelementptr inbounds i8, ptr %call66, i64 96, !dbg !1605
  store i32 %ciovcnt.0.lcssa, ptr %iovcnt, align 8, !dbg !1606, !tbaa !1607
  br label %if.end170

if.end170:                                        ; preds = %while.end, %if.end64
  %iovcnt171 = getelementptr inbounds i8, ptr %resp, i64 116, !dbg !1608
  %35 = load i8, ptr %iovcnt171, align 4, !dbg !1608, !tbaa !1609
  %conv172 = zext i8 %35 to i32, !dbg !1611
  %iovec_data = getelementptr inbounds i8, ptr %call66, i64 128, !dbg !1612
  store i32 %conv172, ptr %iovec_data, align 8, !dbg !1613, !tbaa !1614
  %protocol = getelementptr inbounds i8, ptr %c, i64 316, !dbg !1615
  %36 = load i32, ptr %protocol, align 4, !dbg !1615, !tbaa !1616
  %cmp173 = icmp eq i32 %36, 4, !dbg !1617
  %37 = load i32, ptr %nbytes, align 8, !dbg !1618, !tbaa !1244
  %sub177 = add nsw i32 %37, -2, !dbg !1619
  %cond181 = select i1 %cmp173, i32 %sub177, i32 %37, !dbg !1619
  tail call void @llvm.dbg.value(metadata i32 %cond181, metadata !1460, metadata !DIExpression()), !dbg !1461
  br i1 %cmp, label %if.then183, label %if.else184, !dbg !1620

if.then183:                                       ; preds = %if.end170
  tail call void @resp_add_chunked_iov(ptr noundef nonnull %resp, ptr noundef nonnull %new_it.0, i32 noundef %cond181) #23, !dbg !1621
  br label %if.end185, !dbg !1624

if.else184:                                       ; preds = %if.end170
  tail call void @resp_add_iov(ptr noundef nonnull %resp, ptr noundef nonnull @.str.28, i32 noundef %cond181) #23, !dbg !1625
  br label %if.end185

if.end185:                                        ; preds = %if.else184, %if.then183
  %io_pending = getelementptr inbounds i8, ptr %resp, i64 32, !dbg !1627
  store ptr %call66, ptr %io_pending, align 8, !dbg !1628, !tbaa !1629
  %buf = getelementptr inbounds i8, ptr %call66, i64 80, !dbg !1630
  store ptr %new_it.0, ptr %buf, align 8, !dbg !1631, !tbaa !1632
  %c186 = getelementptr inbounds i8, ptr %call66, i64 16, !dbg !1633
  store ptr %c, ptr %c186, align 8, !dbg !1634, !tbaa !1635
  %stack_ctx = getelementptr inbounds i8, ptr %call, i64 8, !dbg !1636
  %38 = load ptr, ptr %stack_ctx, align 8, !dbg !1636, !tbaa !1637
  %next = getelementptr inbounds i8, ptr %call66, i64 72, !dbg !1639
  store ptr %38, ptr %next, align 8, !dbg !1640, !tbaa !1641
  store ptr %io_ctx, ptr %stack_ctx, align 8, !dbg !1642, !tbaa !1637
  %count = getelementptr inbounds i8, ptr %call, i64 16, !dbg !1643
  %39 = load i32, ptr %count, align 8, !dbg !1644, !tbaa !1645
  %inc188 = add nsw i32 %39, 1, !dbg !1644
  store i32 %inc188, ptr %count, align 8, !dbg !1644, !tbaa !1645
  store ptr %call66, ptr %io_ctx, align 8, !dbg !1646, !tbaa !1647
  %40 = load i32, ptr %add.ptr9, align 4, !dbg !1648, !tbaa !1215
  %page_version190 = getelementptr inbounds i8, ptr %call66, i64 100, !dbg !1649
  store i32 %40, ptr %page_version190, align 4, !dbg !1650, !tbaa !1651
  %page_id = getelementptr inbounds i8, ptr %add.ptr9, i64 8, !dbg !1652
  %41 = load i16, ptr %page_id, align 4, !dbg !1652, !tbaa !1210
  %page_id191 = getelementptr inbounds i8, ptr %call66, i64 112, !dbg !1653
  store i16 %41, ptr %page_id191, align 8, !dbg !1654, !tbaa !1655
  %offset = getelementptr inbounds i8, ptr %add.ptr9, i64 4, !dbg !1656
  %42 = load i32, ptr %offset, align 4, !dbg !1656, !tbaa !1657
  %offset192 = getelementptr inbounds i8, ptr %call66, i64 108, !dbg !1658
  store i32 %42, ptr %offset192, align 4, !dbg !1659, !tbaa !1660
  %conv193 = trunc i64 %add26 to i32, !dbg !1661
  %len = getelementptr inbounds i8, ptr %call66, i64 104, !dbg !1662
  store i32 %conv193, ptr %len, align 8, !dbg !1663, !tbaa !1664
  %mode = getelementptr inbounds i8, ptr %call66, i64 116, !dbg !1665
  store i32 0, ptr %mode, align 4, !dbg !1666, !tbaa !1667
  %cb = getelementptr inbounds i8, ptr %call66, i64 120, !dbg !1668
  store ptr @_storage_get_item_cb, ptr %cb, align 8, !dbg !1669, !tbaa !1670
  %43 = load ptr, ptr %thread, align 8, !dbg !1671, !tbaa !1496
  %stats = getelementptr inbounds i8, ptr %43, i64 352, !dbg !1672
  %call195 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #23, !dbg !1673
  %44 = load ptr, ptr %thread, align 8, !dbg !1674, !tbaa !1496
  %get_extstore = getelementptr inbounds i8, ptr %44, i64 584, !dbg !1675
  %45 = load i64, ptr %get_extstore, align 8, !dbg !1676, !tbaa !1677
  %inc198 = add i64 %45, 1, !dbg !1676
  store i64 %inc198, ptr %get_extstore, align 8, !dbg !1676, !tbaa !1677
  %stats200 = getelementptr inbounds i8, ptr %44, i64 352, !dbg !1678
  %call202 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats200) #23, !dbg !1679
  br label %cleanup206

cleanup206:                                       ; preds = %if.end185, %if.then133, %if.then98, %if.end60
  %retval.2 = phi i32 [ -1, %if.end60 ], [ 0, %if.end185 ], [ -1, %if.then133 ], [ -1, %if.then98 ], !dbg !1461
  ret i32 %retval.2, !dbg !1680
}

declare !dbg !1681 ptr @conn_io_queue_get(ptr noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !1684 i32 @slabs_clsid(i64 noundef) local_unnamed_addr #2

declare !dbg !1689 ptr @item_alloc(ptr noundef, i64 noundef, i32 noundef, i32 noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !1692 ptr @do_item_alloc_pull(i64 noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !1697 ptr @do_cache_alloc(ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #6

; Function Attrs: nounwind sanitize_thread uwtable
define internal void @storage_return_cb(ptr nocapture noundef readonly %pending) #0 !dbg !1700 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %pending, metadata !1702, metadata !DIExpression()), !dbg !1704
  %c = getelementptr inbounds i8, ptr %pending, i64 16, !dbg !1705
  %0 = load ptr, ptr %c, align 8, !dbg !1705, !tbaa !1706
  %1 = load i32, ptr %pending, align 8, !dbg !1708, !tbaa !1709
  %call = tail call ptr @conn_io_queue_get(ptr noundef %0, i32 noundef %1) #23, !dbg !1710
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !1703, metadata !DIExpression()), !dbg !1704
  %count = getelementptr inbounds i8, ptr %call, i64 16, !dbg !1711
  %2 = load i32, ptr %count, align 8, !dbg !1712, !tbaa !1645
  %dec = add nsw i32 %2, -1, !dbg !1712
  store i32 %dec, ptr %count, align 8, !dbg !1712, !tbaa !1645
  %cmp = icmp eq i32 %dec, 0, !dbg !1713
  br i1 %cmp, label %if.then, label %if.end, !dbg !1715

if.then:                                          ; preds = %entry
  %3 = load ptr, ptr %c, align 8, !dbg !1716, !tbaa !1706
  tail call void @conn_worker_readd(ptr noundef %3) #23, !dbg !1718
  br label %if.end, !dbg !1719

if.end:                                           ; preds = %if.then, %entry
  ret void, !dbg !1720
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal void @storage_finalize_cb(ptr nocapture noundef %pending) #0 !dbg !1721 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %pending, metadata !1723, metadata !DIExpression()), !dbg !1726
  tail call void @llvm.dbg.value(metadata ptr %pending, metadata !1727, metadata !DIExpression()), !dbg !1750
  tail call void @llvm.dbg.value(metadata ptr %pending, metadata !1730, metadata !DIExpression()), !dbg !1750
  %c1.i = getelementptr inbounds i8, ptr %pending, i64 16, !dbg !1752
  %0 = load ptr, ptr %c1.i, align 8, !dbg !1752, !tbaa !1635
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1731, metadata !DIExpression()), !dbg !1750
  tail call void @llvm.dbg.value(metadata ptr %pending, metadata !1732, metadata !DIExpression(DW_OP_plus_uconst, 64, DW_OP_stack_value)), !dbg !1750
  %buf.i = getelementptr inbounds i8, ptr %pending, i64 80, !dbg !1753
  %1 = load ptr, ptr %buf.i, align 8, !dbg !1753, !tbaa !1632
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !1733, metadata !DIExpression()), !dbg !1750
  tail call void @llvm.dbg.value(metadata i8 1, metadata !1734, metadata !DIExpression()), !dbg !1750
  %active.i = getelementptr inbounds i8, ptr %pending, i64 135, !dbg !1754
  %2 = load i8, ptr %active.i, align 1, !dbg !1754, !tbaa !1514, !range !1523, !noundef !1524
  %tobool.i = trunc nuw i8 %2 to i1, !dbg !1754
  br i1 %tobool.i, label %if.then.i, label %if.else.i, !dbg !1755

if.then.i:                                        ; preds = %entry
  tail call void @llvm.dbg.value(metadata i8 0, metadata !1734, metadata !DIExpression()), !dbg !1750
  %hdr_it.i = getelementptr inbounds i8, ptr %pending, i64 56, !dbg !1756
  %3 = load ptr, ptr %hdr_it.i, align 8, !dbg !1756, !tbaa !1540
  %nkey.i = getelementptr inbounds i8, ptr %3, i64 41, !dbg !1756
  %4 = load i8, ptr %nkey.i, align 1, !dbg !1756, !tbaa !1203
  %conv.i = zext i8 %4 to i64, !dbg !1756
  %add2.i = add nuw nsw i64 %conv.i, 49, !dbg !1756
  %nbytes.i = getelementptr inbounds i8, ptr %3, i64 32, !dbg !1756
  %5 = load i32, ptr %nbytes.i, align 8, !dbg !1756, !tbaa !1244
  %conv4.i = sext i32 %5 to i64, !dbg !1756
  %add5.i = add nsw i64 %add2.i, %conv4.i, !dbg !1756
  %it_flags.i = getelementptr inbounds i8, ptr %3, i64 38, !dbg !1756
  %6 = load i16, ptr %it_flags.i, align 2, !dbg !1756, !tbaa !1206
  %conv7.i = zext i16 %6 to i32, !dbg !1756
  %and.i = lshr i32 %conv7.i, 6, !dbg !1756
  %7 = and i32 %and.i, 4, !dbg !1756
  %cond.i = zext nneg i32 %7 to i64, !dbg !1756
  %add9.i = add nsw i64 %add5.i, %cond.i, !dbg !1756
  %and13.i = shl nuw nsw i32 %conv7.i, 2, !dbg !1756
  %8 = and i32 %and13.i, 8, !dbg !1756
  %cond15.i = zext nneg i32 %8 to i64, !dbg !1756
  %add16.i = add nsw i64 %add9.i, %cond15.i, !dbg !1756
  tail call void @llvm.dbg.value(metadata i64 %add16.i, metadata !1735, metadata !DIExpression()), !dbg !1757
  %call.i = tail call i32 @slabs_clsid(i64 noundef %add16.i) #23, !dbg !1758
  tail call void @slabs_free(ptr noundef %1, i64 noundef %add16.i, i32 noundef %call.i) #23, !dbg !1759
  %9 = load i32, ptr %pending, align 8, !dbg !1760, !tbaa !1545
  %call17.i = tail call ptr @conn_io_queue_get(ptr noundef %0, i32 noundef %9) #23, !dbg !1761
  tail call void @llvm.dbg.value(metadata ptr %call17.i, metadata !1738, metadata !DIExpression()), !dbg !1757
  %count.i = getelementptr inbounds i8, ptr %call17.i, i64 16, !dbg !1762
  %10 = load i32, ptr %count.i, align 8, !dbg !1763, !tbaa !1645
  %dec.i = add nsw i32 %10, -1, !dbg !1763
  store i32 %dec.i, ptr %count.i, align 8, !dbg !1763, !tbaa !1645
  %thread.i = getelementptr inbounds i8, ptr %0, i64 456, !dbg !1764
  %11 = load ptr, ptr %thread.i, align 8, !dbg !1764, !tbaa !1496
  %stats.i = getelementptr inbounds i8, ptr %11, i64 352, !dbg !1765
  %call18.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats.i) #23, !dbg !1766
  %12 = load ptr, ptr %thread.i, align 8, !dbg !1767, !tbaa !1496
  %get_aborted_extstore.i = getelementptr inbounds i8, ptr %12, i64 592, !dbg !1768
  %13 = load i64, ptr %get_aborted_extstore.i, align 8, !dbg !1769, !tbaa !1770
  %inc.i = add i64 %13, 1, !dbg !1769
  store i64 %inc.i, ptr %get_aborted_extstore.i, align 8, !dbg !1769, !tbaa !1770
  %stats22.i = getelementptr inbounds i8, ptr %12, i64 352, !dbg !1771
  %call24.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats22.i) #23, !dbg !1772
  br label %recache_or_free.exit, !dbg !1773

if.else.i:                                        ; preds = %entry
  %miss.i = getelementptr inbounds i8, ptr %pending, i64 133, !dbg !1774
  %14 = load i8, ptr %miss.i, align 1, !dbg !1774, !tbaa !1775, !range !1523, !noundef !1524
  %tobool25.i = trunc nuw i8 %14 to i1, !dbg !1774
  br i1 %tobool25.i, label %if.then26.i, label %if.else69.i, !dbg !1776

if.then26.i:                                      ; preds = %if.else.i
  tail call void @llvm.dbg.value(metadata i8 0, metadata !1734, metadata !DIExpression()), !dbg !1750
  %hdr_it28.i = getelementptr inbounds i8, ptr %pending, i64 56, !dbg !1777
  %15 = load ptr, ptr %hdr_it28.i, align 8, !dbg !1777, !tbaa !1540
  %nkey29.i = getelementptr inbounds i8, ptr %15, i64 41, !dbg !1777
  %16 = load i8, ptr %nkey29.i, align 1, !dbg !1777, !tbaa !1203
  %conv30.i = zext i8 %16 to i64, !dbg !1777
  %add32.i = add nuw nsw i64 %conv30.i, 49, !dbg !1777
  %nbytes34.i = getelementptr inbounds i8, ptr %15, i64 32, !dbg !1777
  %17 = load i32, ptr %nbytes34.i, align 8, !dbg !1777, !tbaa !1244
  %conv35.i = sext i32 %17 to i64, !dbg !1777
  %add36.i = add nsw i64 %add32.i, %conv35.i, !dbg !1777
  %it_flags38.i = getelementptr inbounds i8, ptr %15, i64 38, !dbg !1777
  %18 = load i16, ptr %it_flags38.i, align 2, !dbg !1777, !tbaa !1206
  %conv39.i = zext i16 %18 to i32, !dbg !1777
  %and40.i = lshr i32 %conv39.i, 6, !dbg !1777
  %19 = and i32 %and40.i, 4, !dbg !1777
  %cond42.i = zext nneg i32 %19 to i64, !dbg !1777
  %add43.i = add nsw i64 %add36.i, %cond42.i, !dbg !1777
  %and47.i = shl nuw nsw i32 %conv39.i, 2, !dbg !1777
  %20 = and i32 %and47.i, 8, !dbg !1777
  %cond49.i = zext nneg i32 %20 to i64, !dbg !1777
  %add50.i = add nsw i64 %add43.i, %cond49.i, !dbg !1777
  tail call void @llvm.dbg.value(metadata i64 %add50.i, metadata !1739, metadata !DIExpression()), !dbg !1778
  tail call void @item_unlink(ptr noundef %15) #23, !dbg !1779
  %call52.i = tail call i32 @slabs_clsid(i64 noundef %add50.i) #23, !dbg !1780
  tail call void @slabs_free(ptr noundef %1, i64 noundef %add50.i, i32 noundef %call52.i) #23, !dbg !1781
  %thread53.i = getelementptr inbounds i8, ptr %0, i64 456, !dbg !1782
  %21 = load ptr, ptr %thread53.i, align 8, !dbg !1782, !tbaa !1496
  %stats54.i = getelementptr inbounds i8, ptr %21, i64 352, !dbg !1783
  %call56.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats54.i) #23, !dbg !1784
  %22 = load ptr, ptr %thread53.i, align 8, !dbg !1785, !tbaa !1496
  %miss_from_extstore.i = getelementptr inbounds i8, ptr %22, i64 616, !dbg !1786
  %23 = load i64, ptr %miss_from_extstore.i, align 8, !dbg !1787, !tbaa !1788
  %inc59.i = add i64 %23, 1, !dbg !1787
  store i64 %inc59.i, ptr %miss_from_extstore.i, align 8, !dbg !1787, !tbaa !1788
  %badcrc.i = getelementptr inbounds i8, ptr %pending, i64 134, !dbg !1789
  %24 = load i8, ptr %badcrc.i, align 2, !dbg !1789, !tbaa !1520, !range !1523, !noundef !1524
  %tobool60.i = trunc nuw i8 %24 to i1, !dbg !1789
  br i1 %tobool60.i, label %if.then61.i, label %if.end.i, !dbg !1791

if.then61.i:                                      ; preds = %if.then26.i
  %badcrc_from_extstore.i = getelementptr inbounds i8, ptr %22, i64 624, !dbg !1792
  %25 = load i64, ptr %badcrc_from_extstore.i, align 8, !dbg !1793, !tbaa !1794
  %inc64.i = add i64 %25, 1, !dbg !1793
  store i64 %inc64.i, ptr %badcrc_from_extstore.i, align 8, !dbg !1793, !tbaa !1794
  br label %if.end.i, !dbg !1795

if.end.i:                                         ; preds = %if.then61.i, %if.then26.i
  %stats66.i = getelementptr inbounds i8, ptr %22, i64 352, !dbg !1796
  %call68.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats66.i) #23, !dbg !1797
  br label %recache_or_free.exit, !dbg !1798

if.else69.i:                                      ; preds = %if.else.i
  %26 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 61), align 4, !dbg !1799, !tbaa !1800
  %tobool70.not.i = icmp eq i32 %26, 0, !dbg !1801
  br i1 %tobool70.not.i, label %if.then123.i, label %if.then71.i, !dbg !1802

if.then71.i:                                      ; preds = %if.else69.i
  %time.i = getelementptr inbounds i8, ptr %1, i64 24, !dbg !1803
  %27 = load i32, ptr %time.i, align 8, !dbg !1803, !tbaa !1244
  tail call void @llvm.dbg.value(metadata i32 %27, metadata !1742, metadata !DIExpression()), !dbg !1804
  %call72.i = tail call ptr @item_trylock(i32 noundef %27) #23, !dbg !1805
  tail call void @llvm.dbg.value(metadata ptr %call72.i, metadata !1745, metadata !DIExpression()), !dbg !1804
  %cmp.not.i = icmp eq ptr %call72.i, null, !dbg !1806
  br i1 %cmp.not.i, label %if.then123.i, label %if.then74.i, !dbg !1807

if.then74.i:                                      ; preds = %if.then71.i
  %hdr_it75.i = getelementptr inbounds i8, ptr %pending, i64 56, !dbg !1808
  %28 = load ptr, ptr %hdr_it75.i, align 8, !dbg !1808, !tbaa !1540
  tail call void @llvm.dbg.value(metadata ptr %28, metadata !1746, metadata !DIExpression()), !dbg !1809
  tail call void @llvm.dbg.value(metadata i8 25, metadata !1749, metadata !DIExpression()), !dbg !1809
  %it_flags76.i = getelementptr inbounds i8, ptr %28, i64 38, !dbg !1810
  %29 = load i16, ptr %it_flags76.i, align 2, !dbg !1810, !tbaa !1206
  %30 = and i16 %29, 25, !dbg !1812
  %cmp81.i = icmp eq i16 %30, 25, !dbg !1813
  br i1 %cmp81.i, label %land.lhs.true.i, label %if.end121.thread211.i, !dbg !1814

land.lhs.true.i:                                  ; preds = %if.then74.i
  %time83.i = getelementptr inbounds i8, ptr %28, i64 24, !dbg !1815
  %31 = load i32, ptr %time83.i, align 8, !dbg !1815, !tbaa !1244
  %32 = load volatile i32, ptr @current_time, align 4, !dbg !1816, !tbaa !1244
  %sub.i = add i32 %32, -60, !dbg !1817
  %cmp84.i = icmp ugt i32 %31, %sub.i, !dbg !1818
  br i1 %cmp84.i, label %land.lhs.true86.i, label %if.end121.thread211.i, !dbg !1819

land.lhs.true86.i:                                ; preds = %land.lhs.true.i
  %recache_counter.i = getelementptr inbounds i8, ptr %0, i64 312, !dbg !1820
  %33 = load i32, ptr %recache_counter.i, align 8, !dbg !1821, !tbaa !1822
  %inc87.i = add i32 %33, 1, !dbg !1821
  store i32 %inc87.i, ptr %recache_counter.i, align 8, !dbg !1821, !tbaa !1822
  %34 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 61), align 4, !dbg !1823, !tbaa !1800
  %rem.i = urem i32 %33, %34, !dbg !1824
  %cmp88.i = icmp eq i32 %rem.i, 0, !dbg !1825
  br i1 %cmp88.i, label %if.then90.i, label %if.end121.thread211.i, !dbg !1826

if.then90.i:                                      ; preds = %land.lhs.true86.i
  tail call void @llvm.dbg.value(metadata i8 0, metadata !1734, metadata !DIExpression()), !dbg !1750
  %exptime.i = getelementptr inbounds i8, ptr %28, i64 28, !dbg !1827
  %35 = load i32, ptr %exptime.i, align 4, !dbg !1827, !tbaa !1244
  %exptime91.i = getelementptr inbounds i8, ptr %1, i64 28, !dbg !1829
  store i32 %35, ptr %exptime91.i, align 4, !dbg !1830, !tbaa !1244
  %it_flags92.i = getelementptr inbounds i8, ptr %1, i64 38, !dbg !1831
  %36 = load i16, ptr %it_flags92.i, align 2, !dbg !1832, !tbaa !1206
  %37 = and i16 %36, -2, !dbg !1832
  store i16 %37, ptr %it_flags92.i, align 2, !dbg !1832, !tbaa !1206
  %refcount.i = getelementptr inbounds i8, ptr %1, i64 36, !dbg !1833
  store i16 0, ptr %refcount.i, align 4, !dbg !1834, !tbaa !1206
  %h_next.i = getelementptr inbounds i8, ptr %1, i64 16, !dbg !1835
  store ptr null, ptr %h_next.i, align 8, !dbg !1836, !tbaa !1311
  %thread96.i = getelementptr inbounds i8, ptr %0, i64 456, !dbg !1837
  %38 = load ptr, ptr %thread96.i, align 8, !dbg !1837, !tbaa !1496
  %storage.i = getelementptr inbounds i8, ptr %38, i64 6904, !dbg !1837
  %39 = load ptr, ptr %storage.i, align 8, !dbg !1837, !tbaa !1839
  tail call void @storage_delete(ptr noundef %39, ptr noundef nonnull %28), !dbg !1837
  %40 = load i16, ptr %it_flags76.i, align 2, !dbg !1840, !tbaa !1206
  %41 = and i16 %40, 2, !dbg !1840
  %tobool100.not.i = icmp eq i16 %41, 0, !dbg !1840
  br i1 %tobool100.not.i, label %if.end121.i, label %cond.true.i, !dbg !1840

cond.true.i:                                      ; preds = %if.then90.i
  %data.i = getelementptr inbounds i8, ptr %28, i64 48, !dbg !1840
  %42 = load i64, ptr %data.i, align 8, !dbg !1840, !tbaa !1203
  br label %if.end121.i, !dbg !1840

if.end121.thread211.i:                            ; preds = %land.lhs.true86.i, %land.lhs.true.i, %if.then74.i
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !1734, metadata !DIExpression()), !dbg !1750
  tail call void @item_trylock_unlock(ptr noundef nonnull %call72.i) #23, !dbg !1841
  br label %if.then123.i, !dbg !1843

if.end121.i:                                      ; preds = %cond.true.i, %if.then90.i
  %cond101.i = phi i64 [ %42, %cond.true.i ], [ 0, %if.then90.i ], !dbg !1840
  %call102.i = tail call i32 @item_replace(ptr noundef nonnull %28, ptr noundef nonnull %1, i32 noundef %27, i64 noundef %cond101.i) #23, !dbg !1844
  %43 = load ptr, ptr %thread96.i, align 8, !dbg !1845, !tbaa !1496
  %stats104.i = getelementptr inbounds i8, ptr %43, i64 352, !dbg !1846
  %call106.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats104.i) #23, !dbg !1847
  %44 = load ptr, ptr %thread96.i, align 8, !dbg !1848, !tbaa !1496
  %recache_from_extstore.i = getelementptr inbounds i8, ptr %44, i64 608, !dbg !1849
  %45 = load i64, ptr %recache_from_extstore.i, align 8, !dbg !1850, !tbaa !1851
  %inc109.i = add i64 %45, 1, !dbg !1850
  store i64 %inc109.i, ptr %recache_from_extstore.i, align 8, !dbg !1850, !tbaa !1851
  %stats111.i = getelementptr inbounds i8, ptr %44, i64 352, !dbg !1852
  %call113.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats111.i) #23, !dbg !1853
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !1734, metadata !DIExpression()), !dbg !1750
  tail call void @item_trylock_unlock(ptr noundef nonnull %call72.i) #23, !dbg !1841
  br label %recache_or_free.exit, !dbg !1843

if.then123.i:                                     ; preds = %if.end121.thread211.i, %if.then71.i, %if.else69.i
  %nkey124.i = getelementptr inbounds i8, ptr %1, i64 41, !dbg !1854
  %46 = load i8, ptr %nkey124.i, align 1, !dbg !1854, !tbaa !1203
  %conv125.i = zext i8 %46 to i64, !dbg !1854
  %add127.i = add nuw nsw i64 %conv125.i, 49, !dbg !1854
  %nbytes128.i = getelementptr inbounds i8, ptr %1, i64 32, !dbg !1854
  %47 = load i32, ptr %nbytes128.i, align 8, !dbg !1854, !tbaa !1244
  %conv129.i = sext i32 %47 to i64, !dbg !1854
  %add130.i = add nsw i64 %add127.i, %conv129.i, !dbg !1854
  %it_flags131.i = getelementptr inbounds i8, ptr %1, i64 38, !dbg !1854
  %48 = load i16, ptr %it_flags131.i, align 2, !dbg !1854, !tbaa !1206
  %conv132.i = zext i16 %48 to i32, !dbg !1854
  %and133.i = lshr i32 %conv132.i, 6, !dbg !1854
  %49 = and i32 %and133.i, 4, !dbg !1854
  %cond135.i = zext nneg i32 %49 to i64, !dbg !1854
  %add136.i = add nsw i64 %add130.i, %cond135.i, !dbg !1854
  %and139.i = shl nuw nsw i32 %conv132.i, 2, !dbg !1854
  %50 = and i32 %and139.i, 8, !dbg !1854
  %cond141.i = zext nneg i32 %50 to i64, !dbg !1854
  %add142.i = add nsw i64 %add136.i, %cond141.i, !dbg !1854
  %slabs_clsid.i = getelementptr inbounds i8, ptr %1, i64 40, !dbg !1856
  %51 = load i8, ptr %slabs_clsid.i, align 8, !dbg !1856, !tbaa !1203
  %52 = and i8 %51, 63, !dbg !1856
  %and144.i = zext nneg i8 %52 to i32, !dbg !1856
  tail call void @slabs_free(ptr noundef %1, i64 noundef %add142.i, i32 noundef %and144.i) #23, !dbg !1857
  br label %recache_or_free.exit, !dbg !1857

recache_or_free.exit:                             ; preds = %if.then.i, %if.end.i, %if.end121.i, %if.then123.i
  tail call void @llvm.dbg.value(metadata ptr %pending, metadata !1732, metadata !DIExpression(DW_OP_plus_uconst, 64, DW_OP_stack_value)), !dbg !1750
  %next.i = getelementptr inbounds i8, ptr %pending, i64 72, !dbg !1858
  store i8 0, ptr %active.i, align 1, !dbg !1859, !tbaa !1514
  %hdr_it150.i = getelementptr inbounds i8, ptr %pending, i64 56, !dbg !1860
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %next.i, i8 0, i64 16, i1 false), !dbg !1861
  %53 = load ptr, ptr %hdr_it150.i, align 8, !dbg !1860, !tbaa !1540
  tail call void @item_remove(ptr noundef %53) #23, !dbg !1862
  tail call void @llvm.dbg.value(metadata ptr %pending, metadata !1724, metadata !DIExpression()), !dbg !1726
  tail call void @llvm.dbg.value(metadata ptr %pending, metadata !1725, metadata !DIExpression(DW_OP_plus_uconst, 64, DW_OP_stack_value)), !dbg !1726
  %iov = getelementptr inbounds i8, ptr %pending, i64 88, !dbg !1863
  %54 = load ptr, ptr %iov, align 8, !dbg !1863, !tbaa !1554
  %tobool.not = icmp eq ptr %54, null, !dbg !1865
  br i1 %tobool.not, label %if.end, label %if.then, !dbg !1866

if.then:                                          ; preds = %recache_or_free.exit
  tail call void @free(ptr noundef nonnull %54) #23, !dbg !1867
  store ptr null, ptr %iov, align 8, !dbg !1869, !tbaa !1554
  br label %if.end, !dbg !1870

if.end:                                           ; preds = %if.then, %recache_or_free.exit
  ret void, !dbg !1871
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare !dbg !1872 noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #7

declare !dbg !1875 void @item_remove(ptr noundef) local_unnamed_addr #2

declare !dbg !1878 void @do_cache_free(ptr noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !1881 ptr @do_item_alloc_chunk(ptr noundef, i64 noundef) local_unnamed_addr #2

declare !dbg !1884 void @resp_add_chunked_iov(ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !1887 void @resp_add_iov(ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #2

; Function Attrs: nounwind sanitize_thread uwtable
define internal void @_storage_get_item_cb(ptr nocapture readnone %e, ptr nocapture noundef readonly %io, i32 noundef %ret) #0 !dbg !1888 {
entry:
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1890, metadata !DIExpression()), !dbg !1914
  tail call void @llvm.dbg.value(metadata ptr %io, metadata !1891, metadata !DIExpression()), !dbg !1914
  tail call void @llvm.dbg.value(metadata i32 %ret, metadata !1892, metadata !DIExpression()), !dbg !1914
  %0 = load ptr, ptr %io, align 8, !dbg !1915, !tbaa !1647
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1893, metadata !DIExpression()), !dbg !1914
  %resp1 = getelementptr inbounds i8, ptr %0, i64 24, !dbg !1916
  %1 = load ptr, ptr %resp1, align 8, !dbg !1916, !tbaa !1543
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !1894, metadata !DIExpression()), !dbg !1914
  %c2 = getelementptr inbounds i8, ptr %0, i64 16, !dbg !1917
  %2 = load ptr, ptr %c2, align 8, !dbg !1917, !tbaa !1635
  tail call void @llvm.dbg.value(metadata ptr %2, metadata !1895, metadata !DIExpression()), !dbg !1914
  %buf = getelementptr inbounds i8, ptr %io, i64 16, !dbg !1918
  %3 = load ptr, ptr %buf, align 8, !dbg !1918, !tbaa !1632
  tail call void @llvm.dbg.value(metadata ptr %3, metadata !1896, metadata !DIExpression()), !dbg !1914
  tail call void @llvm.dbg.value(metadata i8 0, metadata !1897, metadata !DIExpression()), !dbg !1914
  %cmp = icmp slt i32 %ret, 1, !dbg !1919
  br i1 %cmp, label %if.then29, label %if.else, !dbg !1920

if.else:                                          ; preds = %entry
  %exptime = getelementptr inbounds i8, ptr %3, i64 28, !dbg !1921
  %4 = load i32, ptr %exptime, align 4, !dbg !1921, !tbaa !1244
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !1901, metadata !DIExpression()), !dbg !1922
  %iov = getelementptr inbounds i8, ptr %io, i64 24, !dbg !1923
  %5 = load ptr, ptr %iov, align 8, !dbg !1923, !tbaa !1554
  %cmp3.not = icmp eq ptr %5, null, !dbg !1925
  %6 = load ptr, ptr @crc32c, align 8, !dbg !1926, !tbaa !1311
  br i1 %cmp3.not, label %if.else20, label %if.then4, !dbg !1927

if.then4:                                         ; preds = %if.else
  %7 = load ptr, ptr %5, align 8, !dbg !1928, !tbaa !1565
  %add.ptr = getelementptr inbounds i8, ptr %7, i64 32, !dbg !1930
  %iov_len = getelementptr inbounds i8, ptr %5, i64 8, !dbg !1931
  %8 = load i64, ptr %iov_len, align 8, !dbg !1931, !tbaa !1571
  %sub = add i64 %8, -32, !dbg !1932
  %call = tail call i32 %6(i32 noundef 0, ptr noundef nonnull %add.ptr, i64 noundef %sub) #23, !dbg !1933
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !1898, metadata !DIExpression()), !dbg !1922
  %9 = load ptr, ptr %iov, align 8, !dbg !1934, !tbaa !1554
  %iov_len10 = getelementptr inbounds i8, ptr %9, i64 8, !dbg !1935
  store i64 0, ptr %iov_len10, align 8, !dbg !1936, !tbaa !1571
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1902, metadata !DIExpression()), !dbg !1922
  %iovcnt = getelementptr inbounds i8, ptr %io, i64 32
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !1898, metadata !DIExpression()), !dbg !1922
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1902, metadata !DIExpression()), !dbg !1922
  %10 = load i32, ptr %iovcnt, align 8, !dbg !1937, !tbaa !1607
  %cmp11212 = icmp ugt i32 %10, 1, !dbg !1940
  br i1 %cmp11212, label %for.body, label %if.end, !dbg !1941

for.body:                                         ; preds = %if.then4, %for.body
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.body ], [ 1, %if.then4 ]
  %crc2.0214 = phi i32 [ %call19, %for.body ], [ %call, %if.then4 ]
  tail call void @llvm.dbg.value(metadata i32 %crc2.0214, metadata !1898, metadata !DIExpression()), !dbg !1922
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1902, metadata !DIExpression()), !dbg !1922
  %11 = load ptr, ptr @crc32c, align 8, !dbg !1942, !tbaa !1311
  %12 = load ptr, ptr %iov, align 8, !dbg !1944, !tbaa !1554
  %arrayidx13 = getelementptr inbounds %struct.iovec, ptr %12, i64 %indvars.iv, !dbg !1945
  %13 = load ptr, ptr %arrayidx13, align 8, !dbg !1946, !tbaa !1565
  %iov_len18 = getelementptr inbounds i8, ptr %arrayidx13, i64 8, !dbg !1947
  %14 = load i64, ptr %iov_len18, align 8, !dbg !1947, !tbaa !1571
  %call19 = tail call i32 %11(i32 noundef %crc2.0214, ptr noundef %13, i64 noundef %14) #23, !dbg !1942
  tail call void @llvm.dbg.value(metadata i32 %call19, metadata !1898, metadata !DIExpression()), !dbg !1922
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !1948
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !1902, metadata !DIExpression()), !dbg !1922
  %15 = load i32, ptr %iovcnt, align 8, !dbg !1937, !tbaa !1607
  %16 = zext i32 %15 to i64, !dbg !1940
  %cmp11 = icmp ult i64 %indvars.iv.next, %16, !dbg !1940
  br i1 %cmp11, label %for.body, label %if.end, !dbg !1941, !llvm.loop !1949

if.else20:                                        ; preds = %if.else
  %add.ptr21 = getelementptr inbounds i8, ptr %3, i64 32, !dbg !1951
  %len = getelementptr inbounds i8, ptr %io, i64 40, !dbg !1953
  %17 = load i32, ptr %len, align 8, !dbg !1953, !tbaa !1664
  %conv = zext i32 %17 to i64, !dbg !1954
  %sub22 = add nsw i64 %conv, -32, !dbg !1955
  %call23 = tail call i32 %6(i32 noundef 0, ptr noundef nonnull %add.ptr21, i64 noundef %sub22) #23, !dbg !1956
  tail call void @llvm.dbg.value(metadata i32 %call23, metadata !1898, metadata !DIExpression()), !dbg !1922
  br label %if.end

if.end:                                           ; preds = %for.body, %if.then4, %if.else20
  %crc2.1 = phi i32 [ %call23, %if.else20 ], [ %call, %if.then4 ], [ %call19, %for.body ], !dbg !1926
  tail call void @llvm.dbg.value(metadata i32 %crc2.1, metadata !1898, metadata !DIExpression()), !dbg !1922
  %cmp24.not.not = icmp eq i32 %4, %crc2.1, !dbg !1957
  br i1 %cmp24.not.not, label %if.else121, label %if.then26, !dbg !1959

if.then26:                                        ; preds = %if.end
  tail call void @llvm.dbg.value(metadata i8 1, metadata !1897, metadata !DIExpression()), !dbg !1914
  %badcrc = getelementptr inbounds i8, ptr %0, i64 134, !dbg !1960
  store i8 1, ptr %badcrc, align 2, !dbg !1962, !tbaa !1520
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !1897, metadata !DIExpression()), !dbg !1914
  br label %if.then29, !dbg !1963

if.then29:                                        ; preds = %entry, %if.then26
  %noreply = getelementptr inbounds i8, ptr %0, i64 132, !dbg !1964
  %18 = load i8, ptr %noreply, align 4, !dbg !1964, !tbaa !1527, !range !1523, !noundef !1524
  %tobool30 = trunc nuw i8 %18 to i1, !dbg !1964
  br i1 %tobool30, label %if.then31, label %if.else32, !dbg !1965

if.then31:                                        ; preds = %if.then29
  %skip = getelementptr inbounds i8, ptr %1, i64 118, !dbg !1966
  store i8 1, ptr %skip, align 2, !dbg !1968, !tbaa !1969
  br label %if.end148, !dbg !1970

if.else32:                                        ; preds = %if.then29
  %protocol = getelementptr inbounds i8, ptr %2, i64 316, !dbg !1971
  %19 = load i32, ptr %protocol, align 4, !dbg !1971, !tbaa !1616
  %cmp33 = icmp eq i32 %19, 4, !dbg !1972
  br i1 %cmp33, label %if.then35, label %if.else70, !dbg !1973

if.then35:                                        ; preds = %if.else32
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !1903, metadata !DIExpression(DW_OP_plus_uconst, 160, DW_OP_stack_value)), !dbg !1974
  %bodylen = getelementptr inbounds i8, ptr %1, i64 168, !dbg !1975
  %20 = load i32, ptr %bodylen, align 8, !dbg !1975, !tbaa !1203
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !1976, metadata !DIExpression()), !dbg !1982
  %or7.i = tail call noundef i32 @llvm.bswap.i32(i32 %20), !dbg !1984
  tail call void @llvm.dbg.value(metadata i32 %or7.i, metadata !1910, metadata !DIExpression()), !dbg !1974
  %extlen = getelementptr inbounds i8, ptr %1, i64 164, !dbg !1985
  %21 = load i8, ptr %extlen, align 4, !dbg !1985, !tbaa !1203
  tail call void @llvm.dbg.value(metadata i8 %21, metadata !1911, metadata !DIExpression()), !dbg !1974
  %iov37 = getelementptr inbounds i8, ptr %1, i64 48, !dbg !1986
  %iovec_data = getelementptr inbounds i8, ptr %0, i64 128, !dbg !1987
  %22 = load i32, ptr %iovec_data, align 8, !dbg !1987, !tbaa !1614
  %idxprom38 = zext i32 %22 to i64, !dbg !1988
  %iov_len40 = getelementptr inbounds [4 x %struct.iovec], ptr %iov37, i64 0, i64 %idxprom38, i32 1, !dbg !1989
  %23 = load i64, ptr %iov_len40, align 8, !dbg !1989, !tbaa !1571
  %conv41 = zext i8 %21 to i64, !dbg !1990
  %add = add i64 %23, %conv41, !dbg !1991
  %24 = trunc i64 %add to i32, !dbg !1992
  %conv44 = sub i32 %or7.i, %24, !dbg !1992
  tail call void @llvm.dbg.value(metadata i32 %conv44, metadata !1910, metadata !DIExpression()), !dbg !1974
  %tosend = getelementptr inbounds i8, ptr %1, i64 20, !dbg !1993
  %25 = load i32, ptr %tosend, align 4, !dbg !1994, !tbaa !1995
  %conv54 = sub i32 %25, %24, !dbg !1994
  store i32 %conv54, ptr %tosend, align 4, !dbg !1994, !tbaa !1995
  store i8 0, ptr %extlen, align 4, !dbg !1996, !tbaa !1203
  %status = getelementptr inbounds i8, ptr %1, i64 166, !dbg !1997
  store i16 256, ptr %status, align 2, !dbg !1998, !tbaa !1203
  tail call void @llvm.dbg.value(metadata i32 %conv44, metadata !1976, metadata !DIExpression()), !dbg !1999
  %or7.i211 = tail call noundef i32 @llvm.bswap.i32(i32 %conv44), !dbg !2001
  store i32 %or7.i211, ptr %bodylen, align 8, !dbg !2002, !tbaa !1203
  %26 = load i32, ptr %iovec_data, align 8, !dbg !2003, !tbaa !1614
  %idxprom61 = zext i32 %26 to i64, !dbg !2004
  %iov_len63 = getelementptr inbounds [4 x %struct.iovec], ptr %iov37, i64 0, i64 %idxprom61, i32 1, !dbg !2005
  store i64 0, ptr %iov_len63, align 8, !dbg !2006, !tbaa !1571
  %sub66 = add i32 %26, -1, !dbg !2007
  %idxprom67 = zext i32 %sub66 to i64, !dbg !2008
  %iov_len69 = getelementptr inbounds [4 x %struct.iovec], ptr %iov37, i64 0, i64 %idxprom67, i32 1, !dbg !2009
  store i64 0, ptr %iov_len69, align 8, !dbg !2010, !tbaa !1571
  %chunked_data_iov = getelementptr inbounds i8, ptr %1, i64 117, !dbg !2011
  store i8 0, ptr %chunked_data_iov, align 1, !dbg !2012, !tbaa !2013
  br label %if.end148, !dbg !2014

if.else70:                                        ; preds = %if.else32
  %iov71 = getelementptr i8, ptr %1, i64 48, !dbg !2015
  %iov_len73 = getelementptr inbounds i8, ptr %1, i64 56, !dbg !2017
  %27 = load i64, ptr %iov_len73, align 8, !dbg !2017, !tbaa !1571
  %cmp74 = icmp ugt i64 %27, 2, !dbg !2018
  br i1 %cmp74, label %land.lhs.true, label %if.else91, !dbg !2019

land.lhs.true:                                    ; preds = %if.else70
  %28 = load ptr, ptr %iov71, align 8, !dbg !2020, !tbaa !1565
  %bcmp = tail call i32 @bcmp(ptr noundef nonnull dereferenceable(3) %28, ptr noundef nonnull dereferenceable(3) @.str.92, i64 3) #26, !dbg !2021
  %cmp80 = icmp eq i32 %bcmp, 0, !dbg !2022
  br i1 %cmp80, label %if.then82, label %if.else91, !dbg !2023

if.then82:                                        ; preds = %land.lhs.true
  %iovcnt83 = getelementptr inbounds i8, ptr %1, i64 116, !dbg !2024
  store i8 1, ptr %iovcnt83, align 4, !dbg !2026, !tbaa !1609
  store i64 4, ptr %iov_len73, align 8, !dbg !2027, !tbaa !1571
  store ptr @.str.93, ptr %iov71, align 8, !dbg !2028, !tbaa !1565
  %tosend90 = getelementptr inbounds i8, ptr %1, i64 20, !dbg !2029
  store i32 4, ptr %tosend90, align 4, !dbg !2030, !tbaa !1995
  br label %if.end116, !dbg !2031

if.else91:                                        ; preds = %land.lhs.true, %if.else70
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1912, metadata !DIExpression()), !dbg !2032
  %iovec_data93 = getelementptr inbounds i8, ptr %0, i64 128
  %29 = load i32, ptr %iovec_data93, align 8, !tbaa !1614
  %tosend101 = getelementptr inbounds i8, ptr %1, i64 20
  %tosend101.promoted = load i32, ptr %tosend101, align 4, !tbaa !1995
  %30 = add i32 %29, 1, !dbg !2033
  %wide.trip.count = zext i32 %30 to i64, !dbg !2036
  %31 = add nsw i64 %wide.trip.count, -1, !dbg !2033
  %xtraiter = and i64 %wide.trip.count, 3, !dbg !2033
  %32 = icmp ult i64 %31, 3, !dbg !2033
  br i1 %32, label %if.end116.loopexit.unr-lcssa, label %if.else91.new, !dbg !2033

if.else91.new:                                    ; preds = %if.else91
  %unroll_iter = and i64 %wide.trip.count, 4294967292, !dbg !2033
  br label %for.body96, !dbg !2033

for.body96:                                       ; preds = %for.body96, %if.else91.new
  %indvars.iv217 = phi i64 [ 0, %if.else91.new ], [ %indvars.iv.next218.3, %for.body96 ]
  %33 = phi i32 [ %tosend101.promoted, %if.else91.new ], [ %conv104.3, %for.body96 ]
  %niter = phi i64 [ 0, %if.else91.new ], [ %niter.next.3, %for.body96 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv217, metadata !1912, metadata !DIExpression()), !dbg !2032
  %arrayidx99 = getelementptr inbounds [4 x %struct.iovec], ptr %iov71, i64 0, i64 %indvars.iv217, !dbg !2038
  %iov_len100 = getelementptr inbounds i8, ptr %arrayidx99, i64 8, !dbg !2040
  %34 = load i64, ptr %iov_len100, align 8, !dbg !2040, !tbaa !1571
  %35 = trunc i64 %34 to i32, !dbg !2041
  %indvars.iv.next218 = or disjoint i64 %indvars.iv217, 1, !dbg !2042
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next218, metadata !1912, metadata !DIExpression()), !dbg !2032
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %arrayidx99, i8 0, i64 16, i1 false), !dbg !2043
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next218, metadata !1912, metadata !DIExpression()), !dbg !2032
  %arrayidx99.1 = getelementptr inbounds [4 x %struct.iovec], ptr %iov71, i64 0, i64 %indvars.iv.next218, !dbg !2038
  %iov_len100.1 = getelementptr inbounds i8, ptr %arrayidx99.1, i64 8, !dbg !2040
  %36 = load i64, ptr %iov_len100.1, align 8, !dbg !2040, !tbaa !1571
  %37 = trunc i64 %36 to i32, !dbg !2041
  %38 = add i32 %35, %37, !dbg !2041
  %indvars.iv.next218.1 = or disjoint i64 %indvars.iv217, 2, !dbg !2042
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next218.1, metadata !1912, metadata !DIExpression()), !dbg !2032
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %arrayidx99.1, i8 0, i64 16, i1 false), !dbg !2043
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next218.1, metadata !1912, metadata !DIExpression()), !dbg !2032
  %arrayidx99.2 = getelementptr inbounds [4 x %struct.iovec], ptr %iov71, i64 0, i64 %indvars.iv.next218.1, !dbg !2038
  %iov_len100.2 = getelementptr inbounds i8, ptr %arrayidx99.2, i64 8, !dbg !2040
  %39 = load i64, ptr %iov_len100.2, align 8, !dbg !2040, !tbaa !1571
  %40 = trunc i64 %39 to i32, !dbg !2041
  %41 = add i32 %38, %40, !dbg !2041
  %indvars.iv.next218.2 = or disjoint i64 %indvars.iv217, 3, !dbg !2042
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next218.2, metadata !1912, metadata !DIExpression()), !dbg !2032
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %arrayidx99.2, i8 0, i64 16, i1 false), !dbg !2043
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next218.2, metadata !1912, metadata !DIExpression()), !dbg !2032
  %arrayidx99.3 = getelementptr inbounds [4 x %struct.iovec], ptr %iov71, i64 0, i64 %indvars.iv.next218.2, !dbg !2038
  %iov_len100.3 = getelementptr inbounds i8, ptr %arrayidx99.3, i64 8, !dbg !2040
  %42 = load i64, ptr %iov_len100.3, align 8, !dbg !2040, !tbaa !1571
  %43 = trunc i64 %42 to i32, !dbg !2041
  %44 = add i32 %41, %43, !dbg !2041
  %conv104.3 = sub i32 %33, %44, !dbg !2041
  %indvars.iv.next218.3 = add nuw nsw i64 %indvars.iv217, 4, !dbg !2042
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next218.3, metadata !1912, metadata !DIExpression()), !dbg !2032
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %arrayidx99.3, i8 0, i64 16, i1 false), !dbg !2043
  %niter.next.3 = add i64 %niter, 4, !dbg !2033
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter, !dbg !2033
  br i1 %niter.ncmp.3, label %if.end116.loopexit.unr-lcssa, label %for.body96, !dbg !2033, !llvm.loop !2044

if.end116.loopexit.unr-lcssa:                     ; preds = %for.body96, %if.else91
  %conv104.lcssa.ph = phi i32 [ undef, %if.else91 ], [ %conv104.3, %for.body96 ]
  %indvars.iv217.unr = phi i64 [ 0, %if.else91 ], [ %indvars.iv.next218.3, %for.body96 ]
  %.unr = phi i32 [ %tosend101.promoted, %if.else91 ], [ %conv104.3, %for.body96 ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0, !dbg !2033
  br i1 %lcmp.mod.not, label %if.end116.loopexit, label %for.body96.epil, !dbg !2033

for.body96.epil:                                  ; preds = %if.end116.loopexit.unr-lcssa, %for.body96.epil
  %indvars.iv217.epil = phi i64 [ %indvars.iv.next218.epil, %for.body96.epil ], [ %indvars.iv217.unr, %if.end116.loopexit.unr-lcssa ]
  %45 = phi i32 [ %conv104.epil, %for.body96.epil ], [ %.unr, %if.end116.loopexit.unr-lcssa ]
  %epil.iter = phi i64 [ %epil.iter.next, %for.body96.epil ], [ 0, %if.end116.loopexit.unr-lcssa ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv217.epil, metadata !1912, metadata !DIExpression()), !dbg !2032
  %arrayidx99.epil = getelementptr inbounds [4 x %struct.iovec], ptr %iov71, i64 0, i64 %indvars.iv217.epil, !dbg !2038
  %iov_len100.epil = getelementptr inbounds i8, ptr %arrayidx99.epil, i64 8, !dbg !2040
  %46 = load i64, ptr %iov_len100.epil, align 8, !dbg !2040, !tbaa !1571
  %47 = trunc i64 %46 to i32, !dbg !2041
  %conv104.epil = sub i32 %45, %47, !dbg !2041
  %indvars.iv.next218.epil = add nuw nsw i64 %indvars.iv217.epil, 1, !dbg !2042
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next218.epil, metadata !1912, metadata !DIExpression()), !dbg !2032
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %arrayidx99.epil, i8 0, i64 16, i1 false), !dbg !2043
  %epil.iter.next = add i64 %epil.iter, 1, !dbg !2033
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter, !dbg !2033
  br i1 %epil.iter.cmp.not, label %if.end116.loopexit, label %for.body96.epil, !dbg !2033, !llvm.loop !2046

if.end116.loopexit:                               ; preds = %for.body96.epil, %if.end116.loopexit.unr-lcssa
  %conv104.lcssa = phi i32 [ %conv104.lcssa.ph, %if.end116.loopexit.unr-lcssa ], [ %conv104.epil, %for.body96.epil ], !dbg !2041
  store i32 %conv104.lcssa, ptr %tosend101, align 4, !dbg !2041, !tbaa !1995
  br label %if.end116, !dbg !2048

if.end116:                                        ; preds = %if.end116.loopexit, %if.then82
  %chunked_total = getelementptr inbounds i8, ptr %1, i64 112, !dbg !2048
  store i32 0, ptr %chunked_total, align 8, !dbg !2049, !tbaa !2050
  %chunked_data_iov117 = getelementptr inbounds i8, ptr %1, i64 117, !dbg !2051
  store i8 0, ptr %chunked_data_iov117, align 1, !dbg !2052, !tbaa !2013
  br label %if.end148

if.else121:                                       ; preds = %if.end
  %it_flags = getelementptr inbounds i8, ptr %3, i64 38, !dbg !2053
  %48 = load i16, ptr %it_flags, align 2, !dbg !2053, !tbaa !1206
  %conv122 = zext i16 %48 to i32, !dbg !2056
  %and = and i32 %conv122, 32, !dbg !2057
  %cmp123 = icmp eq i32 %and, 0, !dbg !2058
  br i1 %cmp123, label %if.then125, label %if.end148, !dbg !2059

if.then125:                                       ; preds = %if.else121
  %data126 = getelementptr inbounds i8, ptr %3, i64 48, !dbg !2060
  %nkey = getelementptr inbounds i8, ptr %3, i64 41, !dbg !2060
  %49 = load i8, ptr %nkey, align 1, !dbg !2060, !tbaa !1203
  %idx.ext = zext i8 %49 to i64
  %add.ptr128 = getelementptr inbounds i8, ptr %data126, i64 %idx.ext, !dbg !2060
  %add.ptr129 = getelementptr inbounds i8, ptr %add.ptr128, i64 1, !dbg !2060
  %and132 = lshr i32 %conv122, 6, !dbg !2060
  %50 = and i32 %and132, 4, !dbg !2060
  %cond = zext nneg i32 %50 to i64, !dbg !2060
  %add.ptr134 = getelementptr inbounds i8, ptr %add.ptr129, i64 %cond, !dbg !2060
  %and137 = shl nuw nsw i32 %conv122, 2, !dbg !2060
  %51 = and i32 %and137, 8, !dbg !2060
  %cond139 = zext nneg i32 %51 to i64, !dbg !2060
  %add.ptr140 = getelementptr inbounds i8, ptr %add.ptr134, i64 %cond139, !dbg !2060
  %iov141 = getelementptr inbounds i8, ptr %1, i64 48, !dbg !2062
  %iovec_data142 = getelementptr inbounds i8, ptr %0, i64 128, !dbg !2063
  %52 = load i32, ptr %iovec_data142, align 8, !dbg !2063, !tbaa !1614
  %idxprom143 = zext i32 %52 to i64, !dbg !2064
  %arrayidx144 = getelementptr inbounds [4 x %struct.iovec], ptr %iov141, i64 0, i64 %idxprom143, !dbg !2064
  store ptr %add.ptr140, ptr %arrayidx144, align 8, !dbg !2065, !tbaa !1565
  br label %if.end148, !dbg !2066

if.end148:                                        ; preds = %if.else121, %if.then125, %if.then31, %if.end116, %if.then35
  %.sink = phi i8 [ 1, %if.then35 ], [ 1, %if.end116 ], [ 1, %if.then31 ], [ 0, %if.then125 ], [ 0, %if.else121 ]
  %miss147 = getelementptr inbounds i8, ptr %0, i64 133, !dbg !2067
  store i8 %.sink, ptr %miss147, align 1, !dbg !2067, !tbaa !1775
  %active = getelementptr inbounds i8, ptr %0, i64 135, !dbg !2068
  store i8 0, ptr %active, align 1, !dbg !2069, !tbaa !1514
  tail call void @return_io_pending(ptr noundef nonnull %0) #23, !dbg !2070
  ret void, !dbg !2071
}

; Function Attrs: nounwind
declare !dbg !2072 i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind
declare !dbg !2077 i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @storage_submit_cb(ptr nocapture noundef %q) local_unnamed_addr #0 !dbg !2078 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %q, metadata !2080, metadata !DIExpression()), !dbg !2081
  %0 = load ptr, ptr %q, align 8, !dbg !2082, !tbaa !2083
  %stack_ctx = getelementptr inbounds i8, ptr %q, i64 8, !dbg !2084
  %1 = load ptr, ptr %stack_ctx, align 8, !dbg !2084, !tbaa !1637
  %call = tail call i32 @extstore_submit(ptr noundef %0, ptr noundef %1) #23, !dbg !2085
  store ptr null, ptr %stack_ctx, align 8, !dbg !2086, !tbaa !1637
  ret void, !dbg !2087
}

declare !dbg !2088 i32 @extstore_submit(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @storage_write_pause() local_unnamed_addr #0 !dbg !2091 {
entry:
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @storage_write_plock) #23, !dbg !2092
  ret void, !dbg !2093
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @storage_write_resume() local_unnamed_addr #0 !dbg !2094 {
entry:
  %call = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @storage_write_plock) #23, !dbg !2095
  ret void, !dbg !2096
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 -1, 1) i32 @start_storage_write_thread(ptr noundef %arg) local_unnamed_addr #0 !dbg !2097 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2101, metadata !DIExpression()), !dbg !2103
  %call = tail call i32 @pthread_mutex_init(ptr noundef nonnull @storage_write_plock, ptr noundef null) #23, !dbg !2104
  %call1 = tail call i32 @pthread_create(ptr noundef nonnull @storage_write_tid, ptr noundef null, ptr noundef nonnull @storage_write_thread, ptr noundef %arg) #23, !dbg !2105
  tail call void @llvm.dbg.value(metadata i32 %call1, metadata !2102, metadata !DIExpression()), !dbg !2103
  %cmp.not = icmp eq i32 %call1, 0, !dbg !2107
  br i1 %cmp.not, label %if.end, label %if.then, !dbg !2108

if.then:                                          ; preds = %entry
  %0 = load ptr, ptr @stderr, align 8, !dbg !2109, !tbaa !1311
  %call2 = tail call ptr @strerror(i32 noundef %call1) #23, !dbg !2111
  %call3 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %0, ptr noundef nonnull @.str.29, ptr noundef %call2) #27, !dbg !2112
  br label %cleanup, !dbg !2113

if.end:                                           ; preds = %entry
  %1 = load i64, ptr @storage_write_tid, align 8, !dbg !2114, !tbaa !2115
  tail call void @thread_setname(i64 noundef %1, ptr noundef nonnull @.str.30) #23, !dbg !2116
  br label %cleanup, !dbg !2117

cleanup:                                          ; preds = %if.end, %if.then
  %retval.0 = phi i32 [ -1, %if.then ], [ 0, %if.end ], !dbg !2103
  ret i32 %retval.0, !dbg !2118
}

; Function Attrs: nounwind
declare !dbg !2119 i32 @pthread_mutex_init(ptr noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind
declare !dbg !2129 i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: noreturn nounwind sanitize_thread uwtable
define internal noundef ptr @storage_write_thread(ptr noundef %arg) #9 !dbg !2146 {
entry:
  %it_info.i = alloca %struct.lru_pull_tail_return, align 8, !DIAssignID !2178
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2179, metadata !DIExpression(), metadata !2178, metadata ptr %it_info.i, metadata !DIExpression()), !dbg !2215
  %io.i = alloca %struct._obj_io, align 8, !DIAssignID !2219
  %backoff = alloca [64 x i32], align 16, !DIAssignID !2220
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2150, metadata !DIExpression(), metadata !2220, metadata ptr %backoff, metadata !DIExpression()), !dbg !2221
  %mem_limit_reached = alloca i8, align 1, !DIAssignID !2222
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2168, metadata !DIExpression(), metadata !2222, metadata ptr %mem_limit_reached, metadata !DIExpression()), !dbg !2223
  %chunks_perpage = alloca i32, align 4, !DIAssignID !2224
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2171, metadata !DIExpression(), metadata !2224, metadata ptr %chunks_perpage, metadata !DIExpression()), !dbg !2223
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2148, metadata !DIExpression()), !dbg !2221
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2149, metadata !DIExpression()), !dbg !2221
  call void @llvm.lifetime.start.p0(i64 256, ptr nonnull %backoff) #23, !dbg !2225
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(256) %backoff, i8 0, i64 256, i1 false), !dbg !2226, !DIAssignID !2227
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2150, metadata !DIExpression(), metadata !2227, metadata ptr %backoff, metadata !DIExpression()), !dbg !2221
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2152, metadata !DIExpression()), !dbg !2221
  tail call void @llvm.dbg.value(metadata i32 200, metadata !2153, metadata !DIExpression()), !dbg !2221
  %call = tail call ptr @logger_create() #23, !dbg !2228
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !2156, metadata !DIExpression()), !dbg !2221
  %cmp = icmp eq ptr %call, null, !dbg !2229
  br i1 %cmp, label %if.then, label %if.end, !dbg !2231

if.then:                                          ; preds = %entry
  %0 = load ptr, ptr @stderr, align 8, !dbg !2232, !tbaa !1311
  %1 = tail call i64 @fwrite(ptr nonnull @.str.94, i64 56, i64 1, ptr %0) #28, !dbg !2234
  tail call void @abort() #29, !dbg !2235
  unreachable, !dbg !2235

if.end:                                           ; preds = %entry
  %call2 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @storage_write_plock) #23, !dbg !2236
  %2 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 23), align 4, !dbg !2237, !tbaa !2238
  tail call void @llvm.dbg.value(metadata i32 %2, metadata !2157, metadata !DIExpression()), !dbg !2221
  %len.i = getelementptr inbounds i8, ptr %io.i, i64 40
  %mode.i = getelementptr inbounds i8, ptr %io.i, i64 52
  %buf.i = getelementptr inbounds i8, ptr %io.i, i64 16
  %hv.i = getelementptr inbounds i8, ptr %it_info.i, i64 8
  %page_version.i = getelementptr inbounds i8, ptr %io.i, i64 36
  %page_id.i = getelementptr inbounds i8, ptr %io.i, i64 48
  %offset.i = getelementptr inbounds i8, ptr %io.i, i64 44
  %3 = getelementptr inbounds i8, ptr %backoff, i64 16
  %4 = getelementptr inbounds i8, ptr %backoff, i64 32
  %5 = getelementptr inbounds i8, ptr %backoff, i64 48
  %6 = getelementptr inbounds i8, ptr %backoff, i64 64
  %7 = getelementptr inbounds i8, ptr %backoff, i64 80
  %8 = getelementptr inbounds i8, ptr %backoff, i64 96
  %9 = getelementptr inbounds i8, ptr %backoff, i64 112
  %10 = getelementptr inbounds i8, ptr %backoff, i64 128
  %11 = getelementptr inbounds i8, ptr %backoff, i64 144
  %12 = getelementptr inbounds i8, ptr %backoff, i64 160
  %13 = getelementptr inbounds i8, ptr %backoff, i64 176
  %14 = getelementptr inbounds i8, ptr %backoff, i64 192
  %15 = getelementptr inbounds i8, ptr %backoff, i64 208
  %16 = getelementptr inbounds i8, ptr %backoff, i64 224
  %17 = getelementptr inbounds i8, ptr %backoff, i64 240
  br label %while.cond, !dbg !2239

while.cond:                                       ; preds = %if.end90, %if.end
  %check_compact.0 = phi i32 [ %2, %if.end ], [ %check_compact.7, %if.end90 ], !dbg !2221
  %to_sleep.0 = phi i32 [ 200, %if.end ], [ %to_sleep.7, %if.end90 ], !dbg !2221
  %counter.0 = phi i32 [ 0, %if.end ], [ %inc, %if.end90 ], !dbg !2221
  tail call void @llvm.dbg.value(metadata i32 %counter.0, metadata !2152, metadata !DIExpression()), !dbg !2221
  tail call void @llvm.dbg.value(metadata i32 %to_sleep.0, metadata !2153, metadata !DIExpression()), !dbg !2221
  tail call void @llvm.dbg.value(metadata i32 %check_compact.0, metadata !2157, metadata !DIExpression()), !dbg !2221
  %18 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 58), align 8, !dbg !2240, !tbaa !2241
  %conv = zext i32 %18 to i64, !dbg !2242
  %call3 = call i32 @slabs_clsid(i64 noundef %conv) #23, !dbg !2243
  tail call void @llvm.dbg.value(metadata i32 %call3, metadata !2158, metadata !DIExpression()), !dbg !2244
  %call4 = call i32 @global_page_pool_size(ptr noundef null) #23, !dbg !2245
  tail call void @llvm.dbg.value(metadata i32 %call4, metadata !2160, metadata !DIExpression()), !dbg !2244
  tail call void @llvm.dbg.value(metadata i8 1, metadata !2161, metadata !DIExpression()), !dbg !2244
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2162, metadata !DIExpression()), !dbg !2244
  %19 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 69), align 4, !dbg !2246, !tbaa !2248
  %spec.select = call i32 @llvm.usub.sat.i32(i32 %19, i32 %call4), !dbg !2249
  tail call void @llvm.dbg.value(metadata i32 %spec.select, metadata !2162, metadata !DIExpression()), !dbg !2244
  %inc = add i32 %counter.0, 1, !dbg !2250
  tail call void @llvm.dbg.value(metadata i32 %inc, metadata !2152, metadata !DIExpression()), !dbg !2221
  %20 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 65), align 4, !dbg !2251, !tbaa !2253
  %to_sleep.1 = call i32 @llvm.umin.i32(i32 %to_sleep.0, i32 %20), !dbg !2254
  tail call void @llvm.dbg.value(metadata i32 %to_sleep.1, metadata !2153, metadata !DIExpression()), !dbg !2221
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2163, metadata !DIExpression()), !dbg !2255
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2161, metadata !DIExpression()), !dbg !2244
  %21 = sext i32 %call3 to i64, !dbg !2256
  br label %for.body, !dbg !2256

for.cond.cleanup:                                 ; preds = %cleanup60
  %call66 = call i32 @pthread_mutex_unlock(ptr noundef nonnull @storage_write_plock) #23, !dbg !2257
  br i1 %do_sleep.3, label %vector.body, label %if.end90, !dbg !2258

vector.body:                                      ; preds = %for.cond.cleanup
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %backoff, align 16, !dbg !2259, !tbaa !1244
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %3, align 16, !dbg !2259, !tbaa !1244
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %4, align 16, !dbg !2259, !tbaa !1244
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %5, align 16, !dbg !2259, !tbaa !1244
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %6, align 16, !dbg !2259, !tbaa !1244
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %7, align 16, !dbg !2259, !tbaa !1244
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %8, align 16, !dbg !2259, !tbaa !1244
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %9, align 16, !dbg !2259, !tbaa !1244
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %10, align 16, !dbg !2259, !tbaa !1244
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %11, align 16, !dbg !2259, !tbaa !1244
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %12, align 16, !dbg !2259, !tbaa !1244
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %13, align 16, !dbg !2259, !tbaa !1244
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %14, align 16, !dbg !2259, !tbaa !1244
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %15, align 16, !dbg !2259, !tbaa !1244
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %16, align 16, !dbg !2259, !tbaa !1244
  store <4 x i32> <i32 1, i32 1, i32 1, i32 1>, ptr %17, align 16, !dbg !2259, !tbaa !1244
  %mul81.neg = mul i32 %to_sleep.6, -10, !dbg !2262
  %sub82 = add i32 %mul81.neg, %check_compact.5, !dbg !2263
  tail call void @llvm.dbg.value(metadata i32 %sub82, metadata !2157, metadata !DIExpression()), !dbg !2221
  %cmp83 = icmp slt i32 %sub82, 0, !dbg !2264
  br i1 %cmp83, label %if.then85, label %if.end87, !dbg !2266

for.body:                                         ; preds = %while.cond, %cleanup60
  %indvars.iv = phi i64 [ 0, %while.cond ], [ %indvars.iv.next, %cleanup60 ]
  %to_sleep.2145 = phi i32 [ %to_sleep.1, %while.cond ], [ %to_sleep.6, %cleanup60 ]
  %do_sleep.0139 = phi i1 [ true, %while.cond ], [ %do_sleep.3, %cleanup60 ]
  %check_compact.1138 = phi i32 [ %check_compact.0, %while.cond ], [ %check_compact.5, %cleanup60 ]
  tail call void @llvm.dbg.value(metadata i32 %to_sleep.2145, metadata !2153, metadata !DIExpression()), !dbg !2221
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2163, metadata !DIExpression()), !dbg !2255
  tail call void @llvm.dbg.value(metadata i32 %check_compact.1138, metadata !2157, metadata !DIExpression()), !dbg !2221
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2165, metadata !DIExpression()), !dbg !2223
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %mem_limit_reached) #23, !dbg !2267
  store i8 0, ptr %mem_limit_reached, align 1, !dbg !2268, !tbaa !2269, !DIAssignID !2270
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2168, metadata !DIExpression(), metadata !2270, metadata ptr %mem_limit_reached, metadata !DIExpression()), !dbg !2223
  %cmp15 = icmp slt i64 %indvars.iv, %21, !dbg !2271
  br i1 %cmp15, label %cleanup60, label %lor.lhs.false, !dbg !2273

lor.lhs.false:                                    ; preds = %for.body
  %arrayidx = getelementptr inbounds [64 x i32], ptr %backoff, i64 0, i64 %indvars.iv, !dbg !2274
  %22 = load i32, ptr %arrayidx, align 4, !dbg !2274, !tbaa !1244
  %tobool.not = icmp eq i32 %22, 0, !dbg !2274
  br i1 %tobool.not, label %if.end22, label %land.lhs.true, !dbg !2275

land.lhs.true:                                    ; preds = %lor.lhs.false
  %rem = urem i32 %inc, %22, !dbg !2276
  %cmp19.not = icmp eq i32 %rem, 0, !dbg !2277
  br i1 %cmp19.not, label %if.end22, label %cleanup60, !dbg !2278

if.end22:                                         ; preds = %land.lhs.true, %lor.lhs.false
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %chunks_perpage) #23, !dbg !2279
  store i32 0, ptr %chunks_perpage, align 4, !dbg !2280, !tbaa !1244, !DIAssignID !2281
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !2171, metadata !DIExpression(), metadata !2281, metadata ptr %chunks_perpage, metadata !DIExpression()), !dbg !2223
  %23 = trunc nuw nsw i64 %indvars.iv to i32, !dbg !2282
  %call23 = call i32 @slabs_available_chunks(i32 noundef %23, ptr noundef nonnull %mem_limit_reached, ptr noundef nonnull %chunks_perpage) #23, !dbg !2282
  tail call void @llvm.dbg.value(metadata i32 %call23, metadata !2169, metadata !DIExpression()), !dbg !2223
  %24 = load i32, ptr %chunks_perpage, align 4, !dbg !2283, !tbaa !1244
  %cmp24 = icmp eq i32 %24, 0, !dbg !2285
  br i1 %cmp24, label %cleanup, label %if.end27, !dbg !2286

if.end27:                                         ; preds = %if.end22
  %mul = mul i32 %24, %spec.select, !dbg !2287
  tail call void @llvm.dbg.value(metadata i32 %mul, metadata !2172, metadata !DIExpression()), !dbg !2223
  %25 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 23), align 4, !dbg !2288, !tbaa !2238
  %div = udiv i32 %25, %24, !dbg !2289
  tail call void @llvm.dbg.value(metadata i32 %div, metadata !2173, metadata !DIExpression()), !dbg !2223
  br label %while.cond28, !dbg !2290

while.cond28:                                     ; preds = %if.end43, %if.end27
  %check_compact.2 = phi i32 [ %check_compact.1138, %if.end27 ], [ %check_compact.3, %if.end43 ], !dbg !2221
  %do_sleep.1 = phi i1 [ %do_sleep.0139, %if.end27 ], [ false, %if.end43 ], !dbg !2244
  %did_move.0 = phi i1 [ false, %if.end27 ], [ true, %if.end43 ], !dbg !2223
  %chunks_free.0 = phi i32 [ %call23, %if.end27 ], [ %inc37, %if.end43 ], !dbg !2223
  %to_sleep.3 = phi i32 [ %to_sleep.2145, %if.end27 ], [ %spec.select117, %if.end43 ], !dbg !2244
  tail call void @llvm.dbg.value(metadata i32 %to_sleep.3, metadata !2153, metadata !DIExpression()), !dbg !2221
  tail call void @llvm.dbg.value(metadata i32 %chunks_free.0, metadata !2169, metadata !DIExpression()), !dbg !2223
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2165, metadata !DIExpression()), !dbg !2223
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2161, metadata !DIExpression()), !dbg !2244
  tail call void @llvm.dbg.value(metadata i32 %check_compact.2, metadata !2157, metadata !DIExpression()), !dbg !2221
  %cmp30 = icmp ult i32 %chunks_free.0, %mul, !dbg !2291
  br i1 %cmp30, label %if.end33, label %if.else, !dbg !2293

if.else:                                          ; preds = %while.cond28
  %26 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 59), align 4, !dbg !2294, !tbaa !2296
  tail call void @llvm.dbg.value(metadata i32 %26, metadata !2170, metadata !DIExpression()), !dbg !2223
  br label %if.end33

if.end33:                                         ; preds = %while.cond28, %if.else
  %item_age.0 = phi i32 [ %26, %if.else ], [ 0, %while.cond28 ], !dbg !2297
  tail call void @llvm.dbg.value(metadata i32 %item_age.0, metadata !2170, metadata !DIExpression()), !dbg !2223
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2189, metadata !DIExpression(), metadata !2219, metadata ptr %io.i, metadata !DIExpression()), !dbg !2215
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2185, metadata !DIExpression()), !dbg !2215
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2186, metadata !DIExpression()), !dbg !2215
  tail call void @llvm.dbg.value(metadata i32 %item_age.0, metadata !2187, metadata !DIExpression()), !dbg !2215
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2188, metadata !DIExpression()), !dbg !2215
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %it_info.i) #23, !dbg !2298
  store ptr null, ptr %it_info.i, align 8, !dbg !2299, !tbaa !2300, !DIAssignID !2302
  tail call void @llvm.dbg.assign(metadata ptr null, metadata !2179, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2302, metadata ptr %it_info.i, metadata !DIExpression()), !dbg !2215
  %call.i = call i32 @lru_pull_tail(i32 noundef %23, i32 noundef 128, i64 noundef 0, i8 noundef zeroext 4, i32 noundef 0, ptr noundef nonnull %it_info.i) #23, !dbg !2303
  %27 = load ptr, ptr %it_info.i, align 8, !dbg !2304, !tbaa !2300
  %cmp.i = icmp eq ptr %27, null, !dbg !2306
  br i1 %cmp.i, label %storage_write.exit.thread, label %if.end.i, !dbg !2307

storage_write.exit.thread:                        ; preds = %if.end33
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %it_info.i) #23, !dbg !2308
  br label %while.end, !dbg !2309

if.end.i:                                         ; preds = %if.end33
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %io.i) #23, !dbg !2310
  tail call void @llvm.dbg.value(metadata ptr %27, metadata !2190, metadata !DIExpression()), !dbg !2215
  %nkey.i = getelementptr inbounds i8, ptr %27, i64 41, !dbg !2311
  %28 = load i8, ptr %nkey.i, align 1, !dbg !2311, !tbaa !1203
  %conv.i = zext i8 %28 to i64, !dbg !2311
  %add4.i = add nuw nsw i64 %conv.i, 49, !dbg !2311
  %nbytes.i = getelementptr inbounds i8, ptr %27, i64 32, !dbg !2311
  %29 = load i32, ptr %nbytes.i, align 8, !dbg !2311, !tbaa !1244
  %conv5.i = sext i32 %29 to i64, !dbg !2311
  %add6.i = add nsw i64 %add4.i, %conv5.i, !dbg !2311
  %it_flags.i = getelementptr inbounds i8, ptr %27, i64 38, !dbg !2311
  %30 = load i16, ptr %it_flags.i, align 2, !dbg !2311, !tbaa !1206
  %conv7.i = zext i16 %30 to i32, !dbg !2311
  %and.i = lshr i32 %conv7.i, 6, !dbg !2311
  %31 = and i32 %and.i, 4, !dbg !2311
  %cond.i = zext nneg i32 %31 to i64, !dbg !2311
  %add8.i = add nsw i64 %add6.i, %cond.i, !dbg !2311
  %and11.i = shl nuw nsw i32 %conv7.i, 2, !dbg !2311
  %32 = and i32 %and11.i, 8, !dbg !2311
  %cond13.i = zext nneg i32 %32 to i64, !dbg !2311
  %add14.i = add nsw i64 %add8.i, %cond13.i, !dbg !2311
  tail call void @llvm.dbg.value(metadata i64 %add14.i, metadata !2191, metadata !DIExpression()), !dbg !2215
  %and17.i = and i32 %conv7.i, 128, !dbg !2312
  %cmp18.i = icmp eq i32 %and17.i, 0, !dbg !2313
  br i1 %cmp18.i, label %land.lhs.true.i, label %while.end.critedge, !dbg !2314

land.lhs.true.i:                                  ; preds = %if.end.i
  %cmp20.i = icmp eq i32 %item_age.0, 0, !dbg !2315
  br i1 %cmp20.i, label %if.then24.i, label %lor.lhs.false.i, !dbg !2316

lor.lhs.false.i:                                  ; preds = %land.lhs.true.i
  %33 = load volatile i32, ptr @current_time, align 4, !dbg !2317, !tbaa !1244
  %time.i = getelementptr inbounds i8, ptr %27, i64 24, !dbg !2318
  %34 = load i32, ptr %time.i, align 8, !dbg !2318, !tbaa !1244
  %sub.i = sub i32 %33, %34, !dbg !2319
  %cmp22.i = icmp ugt i32 %sub.i, %item_age.0, !dbg !2320
  br i1 %cmp22.i, label %if.then24.i, label %while.end.critedge, !dbg !2321

if.then24.i:                                      ; preds = %lor.lhs.false.i, %land.lhs.true.i
  %and27.i = and i32 %conv7.i, 256, !dbg !2322
  %tobool28.not.i = icmp eq i32 %and27.i, 0, !dbg !2322
  br i1 %tobool28.not.i, label %if.end39.i, label %if.then29.i, !dbg !2325

if.then29.i:                                      ; preds = %if.then24.i
  %data.i = getelementptr inbounds i8, ptr %27, i64 48, !dbg !2326
  %add.ptr.i = getelementptr inbounds i8, ptr %data.i, i64 %conv.i, !dbg !2326
  %add.ptr32.i = getelementptr inbounds i8, ptr %add.ptr.i, i64 1, !dbg !2326
  %add.ptr38.i = getelementptr inbounds i8, ptr %add.ptr32.i, i64 %cond13.i, !dbg !2326
  %35 = load i32, ptr %add.ptr38.i, align 4, !dbg !2326, !tbaa !1244
  tail call void @llvm.dbg.value(metadata i32 %35, metadata !2192, metadata !DIExpression()), !dbg !2215
  br label %if.end39.i, !dbg !2326

if.end39.i:                                       ; preds = %if.then29.i, %if.then24.i
  %flags.0.i = phi i32 [ %35, %if.then29.i ], [ 0, %if.then24.i ], !dbg !2322
  tail call void @llvm.dbg.value(metadata i32 %flags.0.i, metadata !2192, metadata !DIExpression()), !dbg !2215
  %data40.i = getelementptr inbounds i8, ptr %27, i64 48, !dbg !2328
  %36 = shl i16 %30, 2, !dbg !2328
  %37 = and i16 %36, 8, !dbg !2328
  %cond45.i = zext nneg i16 %37 to i64, !dbg !2328
  %add.ptr46.i = getelementptr inbounds i8, ptr %data40.i, i64 %cond45.i, !dbg !2328
  %exptime.i = getelementptr inbounds i8, ptr %27, i64 28, !dbg !2329
  %38 = load i32, ptr %exptime.i, align 4, !dbg !2329, !tbaa !1244
  %call49.i = call ptr @do_item_alloc(ptr noundef nonnull %add.ptr46.i, i64 noundef %conv.i, i32 noundef %flags.0.i, i32 noundef %38, i32 noundef 12) #23, !dbg !2330
  tail call void @llvm.dbg.value(metadata ptr %call49.i, metadata !2193, metadata !DIExpression()), !dbg !2331
  %cmp50.not.i = icmp eq ptr %call49.i, null, !dbg !2332
  br i1 %cmp50.not.i, label %while.end.critedge, label %if.then52.i, !dbg !2333

if.then52.i:                                      ; preds = %if.end39.i
  %39 = load i16, ptr %it_flags.i, align 2, !dbg !2334, !tbaa !1206
  %40 = lshr i16 %39, 4, !dbg !2335
  %41 = and i16 %40, 2, !dbg !2335
  %cond57.i = zext nneg i16 %41 to i32, !dbg !2335
  tail call void @llvm.dbg.value(metadata i32 %cond57.i, metadata !2196, metadata !DIExpression()), !dbg !2336
  %42 = load i32, ptr %exptime.i, align 4, !dbg !2337, !tbaa !1244
  %43 = load volatile i32, ptr @current_time, align 4, !dbg !2339, !tbaa !1244
  %sub59.i = sub i32 %42, %43, !dbg !2340
  %44 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 60), align 8, !dbg !2341, !tbaa !2342
  %cmp60.i = icmp ult i32 %sub59.i, %44, !dbg !2343
  %spec.select.i = select i1 %cmp60.i, i32 3, i32 %cond57.i, !dbg !2344
  tail call void @llvm.dbg.value(metadata i32 %spec.select.i, metadata !2196, metadata !DIExpression()), !dbg !2336
  %it_flags64.i = getelementptr inbounds i8, ptr %call49.i, i64 38, !dbg !2345
  %45 = load i16, ptr %it_flags64.i, align 2, !dbg !2346, !tbaa !1206
  %46 = or i16 %45, 128, !dbg !2346
  store i16 %46, ptr %it_flags64.i, align 2, !dbg !2346, !tbaa !1206
  %conv67.i = trunc i64 %add14.i to i32, !dbg !2347
  store i32 %conv67.i, ptr %len.i, align 8, !dbg !2348, !tbaa !1664, !DIAssignID !2349
  tail call void @llvm.dbg.assign(metadata i32 %conv67.i, metadata !2189, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 32), metadata !2349, metadata ptr %len.i, metadata !DIExpression()), !dbg !2215
  store i32 1, ptr %mode.i, align 4, !dbg !2350, !tbaa !1667, !DIAssignID !2351
  tail call void @llvm.dbg.assign(metadata i32 1, metadata !2189, metadata !DIExpression(DW_OP_LLVM_fragment, 416, 32), metadata !2351, metadata ptr %mode.i, metadata !DIExpression()), !dbg !2215
  %call68.i = call i32 @extstore_write_request(ptr noundef %arg, i32 noundef %spec.select.i, i32 noundef %spec.select.i, ptr noundef nonnull %io.i) #23, !dbg !2352
  %cmp69.i = icmp eq i32 %call68.i, 0, !dbg !2353
  br i1 %cmp69.i, label %if.then71.i, label %if.else192.i, !dbg !2354

if.then71.i:                                      ; preds = %if.then52.i
  %47 = load ptr, ptr %buf.i, align 8, !dbg !2355, !tbaa !1632
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !2199, metadata !DIExpression()), !dbg !2356
  %48 = load i32, ptr %hv.i, align 8, !dbg !2357, !tbaa !2358
  %time72.i = getelementptr inbounds i8, ptr %47, i64 24, !dbg !2359
  store i32 %48, ptr %time72.i, align 8, !dbg !2360, !tbaa !1244
  %49 = load i16, ptr %it_flags.i, align 2, !dbg !2361, !tbaa !1206
  %conv74.i = zext i16 %49 to i32, !dbg !2362
  %and75.i = and i32 %conv74.i, 32, !dbg !2363
  %tobool76.not.i = icmp eq i32 %and75.i, 0, !dbg !2363
  br i1 %tobool76.not.i, label %if.else136.i, label %if.then77.i, !dbg !2364

if.then77.i:                                      ; preds = %if.then71.i
  %50 = load i8, ptr %nkey.i, align 1, !dbg !2365, !tbaa !1203
  %and86.i = lshr i32 %conv74.i, 6, !dbg !2365
  %51 = and i32 %and86.i, 4, !dbg !2365
  %and92.i = shl nuw nsw i32 %conv74.i, 2, !dbg !2365
  %52 = and i32 %and92.i, 8, !dbg !2365
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %data40.i, i32 %52, i32 %51, i8 %50), metadata !2202, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !2366
  tail call void @llvm.dbg.value(metadata i32 %conv67.i, metadata !2205, metadata !DIExpression()), !dbg !2366
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2206, metadata !DIExpression()), !dbg !2366
  %conv98.i = zext i8 %50 to i32, !dbg !2367
  %add109.i = or disjoint i32 %52, %51, !dbg !2367
  %add115.i = or disjoint i32 %add109.i, 49, !dbg !2367
  %sub118.i = add nuw nsw i32 %add115.i, %conv98.i, !dbg !2368
  tail call void @llvm.dbg.value(metadata i32 %sub118.i, metadata !2207, metadata !DIExpression()), !dbg !2366
  %add.ptr121.i = getelementptr inbounds i8, ptr %47, i64 32, !dbg !2369
  %conv123.i = zext nneg i32 %sub118.i to i64, !dbg !2370
  %sub124.i = add nsw i64 %conv123.i, -32, !dbg !2371
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr121.i, ptr nonnull align 1 %nbytes.i, i64 %sub124.i, i1 false), !dbg !2372
  tail call void @llvm.dbg.value(metadata i32 %sub118.i, metadata !2206, metadata !DIExpression()), !dbg !2366
  %tobool126.not286.i = icmp eq i32 %conv67.i, 0, !dbg !2373
  br i1 %tobool126.not286.i, label %if.end143.i, label %while.body.preheader.i, !dbg !2373

while.body.preheader.i:                           ; preds = %if.then77.i
  %idx.ext81.i = zext i8 %50 to i64
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %data40.i, i32 %52, i32 %51, i64 %idx.ext81.i), metadata !2202, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 3, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !2366
  %add.ptr82.i = getelementptr inbounds i8, ptr %data40.i, i64 %idx.ext81.i, !dbg !2365
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %add.ptr82.i, i32 %52, i32 %51), metadata !2202, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 1, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !2366
  %add.ptr83.i = getelementptr inbounds i8, ptr %add.ptr82.i, i64 1, !dbg !2365
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %add.ptr83.i, i32 %52, i32 %51), metadata !2202, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !2366
  %cond88.i = zext nneg i32 %51 to i64, !dbg !2365
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %add.ptr83.i, i32 %52, i64 %cond88.i), metadata !2202, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 2, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !2366
  %add.ptr89.i = getelementptr inbounds i8, ptr %add.ptr83.i, i64 %cond88.i, !dbg !2365
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %add.ptr89.i, i32 %52), metadata !2202, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !2366
  %cond94.i = zext nneg i32 %52 to i64, !dbg !2365
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %add.ptr89.i, i64 %cond94.i), metadata !2202, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 1, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !2366
  %add.ptr95.i = getelementptr inbounds i8, ptr %add.ptr89.i, i64 %cond94.i, !dbg !2365
  tail call void @llvm.dbg.value(metadata ptr %add.ptr95.i, metadata !2202, metadata !DIExpression()), !dbg !2366
  br label %while.body.i, !dbg !2374

while.body.i:                                     ; preds = %while.body.i, %while.body.preheader.i
  %copied.0289.i = phi i32 [ %add135.i, %while.body.i ], [ %sub118.i, %while.body.preheader.i ]
  %remain.0288.i = phi i32 [ %sub133.i, %while.body.i ], [ %conv67.i, %while.body.preheader.i ]
  %sch.0287.i = phi ptr [ %56, %while.body.i ], [ %add.ptr95.i, %while.body.preheader.i ]
  tail call void @llvm.dbg.value(metadata i32 %copied.0289.i, metadata !2206, metadata !DIExpression()), !dbg !2366
  tail call void @llvm.dbg.value(metadata i32 %remain.0288.i, metadata !2205, metadata !DIExpression()), !dbg !2366
  tail call void @llvm.dbg.value(metadata ptr %sch.0287.i, metadata !2202, metadata !DIExpression()), !dbg !2366
  %53 = load ptr, ptr %buf.i, align 8, !dbg !2375, !tbaa !1632
  %idx.ext128.i = sext i32 %copied.0289.i to i64, !dbg !2377
  %add.ptr129.i = getelementptr inbounds i8, ptr %53, i64 %idx.ext128.i, !dbg !2377
  %data130.i = getelementptr inbounds i8, ptr %sch.0287.i, i64 42, !dbg !2378
  %used.i = getelementptr inbounds i8, ptr %sch.0287.i, i64 28, !dbg !2379
  %54 = load i32, ptr %used.i, align 4, !dbg !2379, !tbaa !1244
  %conv131.i = sext i32 %54 to i64, !dbg !2380
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %add.ptr129.i, ptr nonnull align 2 %data130.i, i64 %conv131.i, i1 false), !dbg !2381
  %55 = load i32, ptr %used.i, align 4, !dbg !2382, !tbaa !1244
  %sub133.i = sub nsw i32 %remain.0288.i, %55, !dbg !2383
  tail call void @llvm.dbg.value(metadata i32 %sub133.i, metadata !2205, metadata !DIExpression()), !dbg !2366
  %add135.i = add nsw i32 %55, %copied.0289.i, !dbg !2384
  tail call void @llvm.dbg.value(metadata i32 %add135.i, metadata !2206, metadata !DIExpression()), !dbg !2366
  %56 = load ptr, ptr %sch.0287.i, align 8, !dbg !2385, !tbaa !1311
  tail call void @llvm.dbg.value(metadata ptr %56, metadata !2202, metadata !DIExpression()), !dbg !2366
  %tobool125.not.i = icmp eq ptr %56, null, !dbg !2386
  %tobool126.not.i = icmp eq i32 %sub133.i, 0, !dbg !2373
  %or.cond.i = select i1 %tobool125.not.i, i1 true, i1 %tobool126.not.i, !dbg !2373
  br i1 %or.cond.i, label %if.end143.loopexit.i, label %while.body.i, !dbg !2373, !llvm.loop !2387

if.else136.i:                                     ; preds = %if.then71.i
  %add.ptr138.i = getelementptr inbounds i8, ptr %47, i64 32, !dbg !2389
  %57 = load i32, ptr %len.i, align 8, !dbg !2391, !tbaa !1664
  %conv141.i = zext i32 %57 to i64, !dbg !2392
  %sub142.i = add nsw i64 %conv141.i, -32, !dbg !2393
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr138.i, ptr nonnull align 1 %nbytes.i, i64 %sub142.i, i1 false), !dbg !2394
  br label %if.end143.i

if.end143.loopexit.i:                             ; preds = %while.body.i
  %.pre.i = load ptr, ptr %buf.i, align 8, !dbg !2395, !tbaa !1632
  br label %if.end143.i, !dbg !2396

if.end143.i:                                      ; preds = %if.end143.loopexit.i, %if.else136.i, %if.then77.i
  %58 = phi ptr [ %.pre.i, %if.end143.loopexit.i ], [ %47, %if.then77.i ], [ %47, %if.else136.i ], !dbg !2395
  %it_flags144.i = getelementptr inbounds i8, ptr %47, i64 38, !dbg !2396
  %59 = load i16, ptr %it_flags144.i, align 2, !dbg !2397, !tbaa !1206
  %60 = and i16 %59, -2, !dbg !2397
  store i16 %60, ptr %it_flags144.i, align 2, !dbg !2397, !tbaa !1206
  %61 = load ptr, ptr @crc32c, align 8, !dbg !2398, !tbaa !1311
  %add.ptr149.i = getelementptr inbounds i8, ptr %58, i64 32, !dbg !2399
  %sub150.i = add nsw i64 %add14.i, -32, !dbg !2400
  %call151.i = call i32 %61(i32 noundef 0, ptr noundef nonnull %add.ptr149.i, i64 noundef %sub150.i) #23, !dbg !2398
  %exptime152.i = getelementptr inbounds i8, ptr %47, i64 28, !dbg !2401
  store i32 %call151.i, ptr %exptime152.i, align 4, !dbg !2402, !tbaa !1244
  call void @extstore_write(ptr noundef %arg, ptr noundef nonnull %io.i) #23, !dbg !2403
  %data153.i = getelementptr inbounds i8, ptr %call49.i, i64 48, !dbg !2404
  %nkey154.i = getelementptr inbounds i8, ptr %call49.i, i64 41, !dbg !2404
  %62 = load i8, ptr %nkey154.i, align 1, !dbg !2404, !tbaa !1203
  %idx.ext156.i = zext i8 %62 to i64
  %add.ptr157.i = getelementptr inbounds i8, ptr %data153.i, i64 %idx.ext156.i, !dbg !2404
  %add.ptr158.i = getelementptr inbounds i8, ptr %add.ptr157.i, i64 1, !dbg !2404
  %63 = load i16, ptr %it_flags64.i, align 2, !dbg !2404, !tbaa !1206
  %conv160.i = zext i16 %63 to i32, !dbg !2404
  %and161.i = lshr i32 %conv160.i, 6, !dbg !2404
  %64 = and i32 %and161.i, 4, !dbg !2404
  %cond163.i = zext nneg i32 %64 to i64, !dbg !2404
  %add.ptr164.i = getelementptr inbounds i8, ptr %add.ptr158.i, i64 %cond163.i, !dbg !2404
  %and167.i = shl nuw nsw i32 %conv160.i, 2, !dbg !2404
  %65 = and i32 %and167.i, 8, !dbg !2404
  %cond169.i = zext nneg i32 %65 to i64, !dbg !2404
  %add.ptr170.i = getelementptr inbounds i8, ptr %add.ptr164.i, i64 %cond169.i, !dbg !2404
  tail call void @llvm.dbg.value(metadata ptr %add.ptr170.i, metadata !2208, metadata !DIExpression()), !dbg !2356
  %66 = load i32, ptr %page_version.i, align 4, !dbg !2405, !tbaa !1651
  store i32 %66, ptr %add.ptr170.i, align 4, !dbg !2406, !tbaa !1215
  %67 = load i16, ptr %page_id.i, align 8, !dbg !2407, !tbaa !1655
  %page_id172.i = getelementptr inbounds i8, ptr %add.ptr170.i, i64 8, !dbg !2408
  store i16 %67, ptr %page_id172.i, align 4, !dbg !2409, !tbaa !1210
  %68 = load i32, ptr %offset.i, align 4, !dbg !2410, !tbaa !1660
  %offset173.i = getelementptr inbounds i8, ptr %add.ptr170.i, i64 4, !dbg !2411
  store i32 %68, ptr %offset173.i, align 4, !dbg !2412, !tbaa !1657
  %69 = load i32, ptr %nbytes.i, align 8, !dbg !2413, !tbaa !1244
  %nbytes175.i = getelementptr inbounds i8, ptr %call49.i, i64 32, !dbg !2414
  store i32 %69, ptr %nbytes175.i, align 8, !dbg !2415, !tbaa !1244
  %70 = load i32, ptr %hv.i, align 8, !dbg !2416, !tbaa !2358
  %71 = load i16, ptr %it_flags.i, align 2, !dbg !2417, !tbaa !1206
  %72 = and i16 %71, 2, !dbg !2417
  %tobool180.not.i = icmp eq i16 %72, 0, !dbg !2417
  br i1 %tobool180.not.i, label %cond.end.i, label %cond.true.i, !dbg !2417

cond.true.i:                                      ; preds = %if.end143.i
  %73 = load i64, ptr %data40.i, align 8, !dbg !2417, !tbaa !1203
  br label %cond.end.i, !dbg !2417

cond.end.i:                                       ; preds = %cond.true.i, %if.end143.i
  %cond183.i = phi i64 [ %73, %cond.true.i ], [ 0, %if.end143.i ], !dbg !2417
  %call184.i = call i32 @item_replace(ptr noundef nonnull %27, ptr noundef nonnull %call49.i, i32 noundef %70, i64 noundef %cond183.i) #23, !dbg !2418
  call void @do_item_remove(ptr noundef nonnull %call49.i) #23, !dbg !2419
  tail call void @llvm.dbg.value(metadata i32 1, metadata !2188, metadata !DIExpression()), !dbg !2215
  tail call void @llvm.dbg.value(metadata ptr null, metadata !2209, metadata !DIExpression()), !dbg !2420
  %74 = load i32, ptr @logger_key, align 4, !dbg !2421, !tbaa !1244
  %call185.i = call ptr @pthread_getspecific(i32 noundef %74) #23, !dbg !2421
  tail call void @llvm.dbg.value(metadata ptr %call185.i, metadata !2209, metadata !DIExpression()), !dbg !2420
  %eflags.i = getelementptr inbounds i8, ptr %call185.i, i64 84, !dbg !2423
  %75 = load i16, ptr %eflags.i, align 4, !dbg !2423, !tbaa !2425
  %76 = and i16 %75, 64, !dbg !2423
  %tobool188.not.i = icmp eq i16 %76, 0, !dbg !2423
  br i1 %tobool188.not.i, label %storage_write.exit, label %if.then189.i, !dbg !2427

if.then189.i:                                     ; preds = %cond.end.i
  %call190.i = call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %call185.i, i32 noundef 9, ptr noundef nonnull %27, i32 noundef %spec.select.i) #23, !dbg !2423
  br label %storage_write.exit, !dbg !2423

if.else192.i:                                     ; preds = %if.then52.i
  %nkey193.i = getelementptr inbounds i8, ptr %call49.i, i64 41, !dbg !2428
  %77 = load i8, ptr %nkey193.i, align 1, !dbg !2428, !tbaa !1203
  %conv194.i = zext i8 %77 to i64, !dbg !2428
  %add196.i = add nuw nsw i64 %conv194.i, 49, !dbg !2428
  %nbytes197.i = getelementptr inbounds i8, ptr %call49.i, i64 32, !dbg !2428
  %78 = load i32, ptr %nbytes197.i, align 8, !dbg !2428, !tbaa !1244
  %conv198.i = sext i32 %78 to i64, !dbg !2428
  %add199.i = add nsw i64 %add196.i, %conv198.i, !dbg !2428
  %79 = load i16, ptr %it_flags64.i, align 2, !dbg !2428, !tbaa !1206
  %conv201.i = zext i16 %79 to i32, !dbg !2428
  %and202.i = lshr i32 %conv201.i, 6, !dbg !2428
  %80 = and i32 %and202.i, 4, !dbg !2428
  %cond204.i = zext nneg i32 %80 to i64, !dbg !2428
  %add205.i = add nsw i64 %add199.i, %cond204.i, !dbg !2428
  %and208.i = shl nuw nsw i32 %conv201.i, 2, !dbg !2428
  %81 = and i32 %and208.i, 8, !dbg !2428
  %cond210.i = zext nneg i32 %81 to i64, !dbg !2428
  %add211.i = add nsw i64 %add205.i, %cond210.i, !dbg !2428
  %slabs_clsid.i = getelementptr inbounds i8, ptr %call49.i, i64 40, !dbg !2430
  %82 = load i8, ptr %slabs_clsid.i, align 8, !dbg !2430, !tbaa !1203
  %83 = and i8 %82, 63, !dbg !2430
  %and213.i = zext nneg i8 %83 to i32, !dbg !2430
  call void @slabs_free(ptr noundef nonnull %call49.i, i64 noundef %add211.i, i32 noundef %and213.i) #23, !dbg !2431
  br label %while.end.critedge

storage_write.exit:                               ; preds = %cond.end.i, %if.then189.i
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !2188, metadata !DIExpression()), !dbg !2215
  call void @do_item_remove(ptr noundef nonnull %27) #23, !dbg !2432
  %84 = load i32, ptr %hv.i, align 8, !dbg !2433, !tbaa !2358
  call void @item_unlock(i32 noundef %84) #23, !dbg !2434
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %io.i) #23, !dbg !2308
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %it_info.i) #23, !dbg !2308
  %inc37 = add i32 %chunks_free.0, 1, !dbg !2435
  tail call void @llvm.dbg.value(metadata i32 %inc37, metadata !2169, metadata !DIExpression()), !dbg !2223
  %sub38 = sub i32 %check_compact.2, %div, !dbg !2437
  tail call void @llvm.dbg.value(metadata i32 %sub38, metadata !2157, metadata !DIExpression()), !dbg !2221
  %cmp39 = icmp slt i32 %sub38, 0, !dbg !2438
  br i1 %cmp39, label %if.then41, label %if.end43, !dbg !2440

if.then41:                                        ; preds = %storage_write.exit
  %call42 = call i32 @pthread_cond_signal(ptr noundef nonnull @storage_compact_cond) #23, !dbg !2441
  %85 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 23), align 4, !dbg !2443, !tbaa !2238
  tail call void @llvm.dbg.value(metadata i32 %85, metadata !2157, metadata !DIExpression()), !dbg !2221
  br label %if.end43, !dbg !2444

if.end43:                                         ; preds = %if.then41, %storage_write.exit
  %check_compact.3 = phi i32 [ %85, %if.then41 ], [ %sub38, %storage_write.exit ], !dbg !2445
  tail call void @llvm.dbg.value(metadata i32 %check_compact.3, metadata !2157, metadata !DIExpression()), !dbg !2221
  tail call void @llvm.dbg.value(metadata i8 1, metadata !2165, metadata !DIExpression()), !dbg !2223
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2161, metadata !DIExpression()), !dbg !2244
  %cmp44 = icmp ugt i32 %to_sleep.3, 200, !dbg !2446
  %div47116 = zext i1 %cmp44 to i32, !dbg !2448
  %spec.select117 = lshr i32 %to_sleep.3, %div47116, !dbg !2448
  tail call void @llvm.dbg.value(metadata i32 %spec.select117, metadata !2153, metadata !DIExpression()), !dbg !2221
  br label %while.cond28, !dbg !2290, !llvm.loop !2449

while.end.critedge:                               ; preds = %if.end39.i, %if.end.i, %lor.lhs.false.i, %if.else192.i
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !2188, metadata !DIExpression()), !dbg !2215
  call void @do_item_remove(ptr noundef nonnull %27) #23, !dbg !2432
  %86 = load i32, ptr %hv.i, align 8, !dbg !2433, !tbaa !2358
  call void @item_unlock(i32 noundef %86) #23, !dbg !2434
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %io.i) #23, !dbg !2308
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %it_info.i) #23, !dbg !2308
  br label %while.end, !dbg !2309

while.end:                                        ; preds = %while.end.critedge, %storage_write.exit.thread
  br i1 %did_move.0, label %if.end59, label %if.then52, !dbg !2451

if.then52:                                        ; preds = %while.end
  %87 = load i32, ptr %arrayidx, align 4, !dbg !2452, !tbaa !1244
  %inc55 = add i32 %87, 1, !dbg !2452
  br label %if.end59, !dbg !2455

if.end59:                                         ; preds = %while.end, %if.then52
  %storemerge = phi i32 [ %inc55, %if.then52 ], [ 1, %while.end ], !dbg !2456
  store i32 %storemerge, ptr %arrayidx, align 4, !dbg !2456, !tbaa !1244
  br label %cleanup, !dbg !2457

cleanup:                                          ; preds = %if.end22, %if.end59
  %check_compact.4 = phi i32 [ %check_compact.2, %if.end59 ], [ %check_compact.1138, %if.end22 ], !dbg !2458
  %do_sleep.2 = phi i1 [ %do_sleep.1, %if.end59 ], [ %do_sleep.0139, %if.end22 ], !dbg !2459
  %to_sleep.5 = phi i32 [ %to_sleep.3, %if.end59 ], [ %to_sleep.2145, %if.end22 ], !dbg !2460
  tail call void @llvm.dbg.value(metadata i32 %to_sleep.5, metadata !2153, metadata !DIExpression()), !dbg !2221
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2161, metadata !DIExpression()), !dbg !2244
  tail call void @llvm.dbg.value(metadata i32 %check_compact.4, metadata !2157, metadata !DIExpression()), !dbg !2221
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %chunks_perpage) #23, !dbg !2457
  br label %cleanup60

cleanup60:                                        ; preds = %for.body, %land.lhs.true, %cleanup
  %check_compact.5 = phi i32 [ %check_compact.4, %cleanup ], [ %check_compact.1138, %land.lhs.true ], [ %check_compact.1138, %for.body ], !dbg !2458
  %do_sleep.3 = phi i1 [ %do_sleep.2, %cleanup ], [ %do_sleep.0139, %land.lhs.true ], [ %do_sleep.0139, %for.body ], !dbg !2459
  %to_sleep.6 = phi i32 [ %to_sleep.5, %cleanup ], [ %to_sleep.2145, %land.lhs.true ], [ %to_sleep.2145, %for.body ], !dbg !2460
  tail call void @llvm.dbg.value(metadata i32 %to_sleep.6, metadata !2153, metadata !DIExpression()), !dbg !2221
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2161, metadata !DIExpression()), !dbg !2244
  tail call void @llvm.dbg.value(metadata i32 %check_compact.5, metadata !2157, metadata !DIExpression()), !dbg !2221
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %mem_limit_reached) #23, !dbg !2457
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !2461
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !2163, metadata !DIExpression()), !dbg !2255
  %exitcond.not = icmp eq i64 %indvars.iv.next, 64, !dbg !2462
  br i1 %exitcond.not, label %for.cond.cleanup, label %for.body, !dbg !2256, !llvm.loop !2463

if.then85:                                        ; preds = %vector.body
  %call86 = call i32 @pthread_cond_signal(ptr noundef nonnull @storage_compact_cond) #23, !dbg !2465
  %88 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 23), align 4, !dbg !2467, !tbaa !2238
  tail call void @llvm.dbg.value(metadata i32 %88, metadata !2157, metadata !DIExpression()), !dbg !2221
  br label %if.end87, !dbg !2468

if.end87:                                         ; preds = %if.then85, %vector.body
  %check_compact.6 = phi i32 [ %88, %if.then85 ], [ %sub82, %vector.body ], !dbg !2469
  tail call void @llvm.dbg.value(metadata i32 %check_compact.6, metadata !2157, metadata !DIExpression()), !dbg !2221
  %call88 = call i32 @usleep(i32 noundef %to_sleep.6) #23, !dbg !2470
  %inc89 = add i32 %to_sleep.6, 1, !dbg !2471
  tail call void @llvm.dbg.value(metadata i32 %inc89, metadata !2153, metadata !DIExpression()), !dbg !2221
  br label %if.end90, !dbg !2472

if.end90:                                         ; preds = %if.end87, %for.cond.cleanup
  %check_compact.7 = phi i32 [ %check_compact.6, %if.end87 ], [ %check_compact.5, %for.cond.cleanup ], !dbg !2221
  %to_sleep.7 = phi i32 [ %inc89, %if.end87 ], [ %to_sleep.6, %for.cond.cleanup ], !dbg !2244
  tail call void @llvm.dbg.value(metadata i32 %to_sleep.7, metadata !2153, metadata !DIExpression()), !dbg !2221
  tail call void @llvm.dbg.value(metadata i32 %check_compact.7, metadata !2157, metadata !DIExpression()), !dbg !2221
  %call91 = call i32 @pthread_mutex_lock(ptr noundef nonnull @storage_write_plock) #23, !dbg !2473
  br label %while.cond, !dbg !2239, !llvm.loop !2474
}

; Function Attrs: nofree nounwind
declare !dbg !2476 noundef i32 @fprintf(ptr nocapture noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #4

; Function Attrs: nounwind
declare !dbg !2527 ptr @strerror(i32 noundef) local_unnamed_addr #8

declare !dbg !2531 void @thread_setname(i64 noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @storage_compact_pause() local_unnamed_addr #0 !dbg !2534 {
entry:
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @storage_compact_plock) #23, !dbg !2535
  ret void, !dbg !2536
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @storage_compact_resume() local_unnamed_addr #0 !dbg !2537 {
entry:
  %call = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @storage_compact_plock) #23, !dbg !2538
  ret void, !dbg !2539
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 -1, 1) i32 @start_storage_compact_thread(ptr noundef %arg) local_unnamed_addr #0 !dbg !2540 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2542, metadata !DIExpression()), !dbg !2544
  %call = tail call i32 @pthread_mutex_init(ptr noundef nonnull @storage_compact_plock, ptr noundef null) #23, !dbg !2545
  %call1 = tail call i32 @pthread_cond_init(ptr noundef nonnull @storage_compact_cond, ptr noundef null) #23, !dbg !2546
  %call2 = tail call i32 @pthread_create(ptr noundef nonnull @storage_compact_tid, ptr noundef null, ptr noundef nonnull @storage_compact_thread, ptr noundef %arg) #23, !dbg !2547
  tail call void @llvm.dbg.value(metadata i32 %call2, metadata !2543, metadata !DIExpression()), !dbg !2544
  %cmp.not = icmp eq i32 %call2, 0, !dbg !2549
  br i1 %cmp.not, label %if.end, label %if.then, !dbg !2550

if.then:                                          ; preds = %entry
  %0 = load ptr, ptr @stderr, align 8, !dbg !2551, !tbaa !1311
  %call3 = tail call ptr @strerror(i32 noundef %call2) #23, !dbg !2553
  %call4 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %0, ptr noundef nonnull @.str.31, ptr noundef %call3) #27, !dbg !2554
  br label %cleanup, !dbg !2555

if.end:                                           ; preds = %entry
  %1 = load i64, ptr @storage_compact_tid, align 8, !dbg !2556, !tbaa !2115
  tail call void @thread_setname(i64 noundef %1, ptr noundef nonnull @.str.32) #23, !dbg !2557
  br label %cleanup, !dbg !2558

cleanup:                                          ; preds = %if.end, %if.then
  %retval.0 = phi i32 [ -1, %if.then ], [ 0, %if.end ], !dbg !2544
  ret i32 %retval.0, !dbg !2559
}

; Function Attrs: nounwind
declare !dbg !2560 i32 @pthread_cond_init(ptr noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: noreturn nounwind sanitize_thread uwtable
define internal noalias noundef nonnull ptr @storage_compact_thread(ptr noundef %arg) #9 !dbg !2573 {
entry:
  %io.i = alloca %struct._obj_io, align 8, !DIAssignID !2611
  %st.i = alloca %struct.extstore_stats, align 8, !DIAssignID !2612
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2613, metadata !DIExpression(), metadata !2612, metadata ptr %st.i, metadata !DIExpression()), !dbg !2660
  %buckets.i = alloca [6 x %struct.__storage_buk], align 16, !DIAssignID !2662
  %wrap = alloca %struct.storage_compact_wrap, align 8, !DIAssignID !2663
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2590, metadata !DIExpression(), metadata !2663, metadata ptr %wrap, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2575, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2576, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2577, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2578, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2579, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2580, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2581, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata ptr null, metadata !2589, metadata !DIExpression()), !dbg !2664
  call void @llvm.lifetime.start.p0(i64 112, ptr nonnull %wrap) #23, !dbg !2665
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  tail call void @llvm.dbg.value(metadata i24 0, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 24)), !dbg !2664
  %call = tail call ptr @logger_create() #23, !dbg !2666
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !2591, metadata !DIExpression()), !dbg !2664
  %cmp = icmp eq ptr %call, null, !dbg !2667
  br i1 %cmp, label %if.then, label %if.end, !dbg !2669

if.then:                                          ; preds = %entry
  %0 = load ptr, ptr @stderr, align 8, !dbg !2670, !tbaa !1311
  %1 = tail call i64 @fwrite(ptr nonnull @.str.94, i64 56, i64 1, ptr %0) #28, !dbg !2672
  tail call void @abort() #29, !dbg !2673
  unreachable, !dbg !2673

if.end:                                           ; preds = %entry
  %2 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 62), align 8, !dbg !2674, !tbaa !2675
  %conv = zext i32 %2 to i64, !dbg !2676
  %call2 = tail call noalias ptr @malloc(i64 noundef %conv) #25, !dbg !2677
  tail call void @llvm.dbg.value(metadata ptr %call2, metadata !2589, metadata !DIExpression()), !dbg !2664
  %cmp3 = icmp eq ptr %call2, null, !dbg !2678
  br i1 %cmp3, label %if.then5, label %if.end7, !dbg !2680

if.then5:                                         ; preds = %if.end
  %3 = load ptr, ptr @stderr, align 8, !dbg !2681, !tbaa !1311
  %4 = tail call i64 @fwrite(ptr nonnull @.str.95, i64 65, i64 1, ptr %3) #28, !dbg !2683
  tail call void @abort() #29, !dbg !2684
  unreachable, !dbg !2684

if.end7:                                          ; preds = %if.end
  %lock = getelementptr inbounds i8, ptr %wrap, i64 64, !dbg !2685
  %call8 = call i32 @pthread_mutex_init(ptr noundef nonnull %lock, ptr noundef null) #23, !dbg !2686
  %done = getelementptr inbounds i8, ptr %wrap, i64 104, !dbg !2687
  store i8 0, ptr %done, align 8, !dbg !2688, !tbaa !2689, !DIAssignID !2691
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 8), metadata !2691, metadata ptr %done, metadata !DIExpression()), !dbg !2664
  %submitted = getelementptr inbounds i8, ptr %wrap, i64 105, !dbg !2692
  store i8 0, ptr %submitted, align 1, !dbg !2693, !tbaa !2694, !DIAssignID !2695
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 840, 8), metadata !2695, metadata ptr %submitted, metadata !DIExpression()), !dbg !2664
  store ptr %wrap, ptr %wrap, align 8, !dbg !2696, !tbaa !2697, !DIAssignID !2698
  tail call void @llvm.dbg.assign(metadata ptr %wrap, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2698, metadata ptr %wrap, metadata !DIExpression()), !dbg !2664
  %iov = getelementptr inbounds i8, ptr %wrap, i64 24, !dbg !2699
  store ptr null, ptr %iov, align 8, !dbg !2700, !tbaa !2701, !DIAssignID !2702
  tail call void @llvm.dbg.assign(metadata ptr null, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64), metadata !2702, metadata ptr %iov, metadata !DIExpression()), !dbg !2664
  %buf = getelementptr inbounds i8, ptr %wrap, i64 16, !dbg !2703
  store ptr %call2, ptr %buf, align 8, !dbg !2704, !tbaa !2705, !DIAssignID !2706
  tail call void @llvm.dbg.assign(metadata ptr %call2, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64), metadata !2706, metadata ptr %buf, metadata !DIExpression()), !dbg !2664
  %5 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 62), align 8, !dbg !2707, !tbaa !2675
  %len = getelementptr inbounds i8, ptr %wrap, i64 40, !dbg !2708
  store i32 %5, ptr %len, align 8, !dbg !2709, !tbaa !2710, !DIAssignID !2711
  tail call void @llvm.dbg.assign(metadata i32 %5, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 32), metadata !2711, metadata ptr %len, metadata !DIExpression()), !dbg !2664
  %mode = getelementptr inbounds i8, ptr %wrap, i64 52, !dbg !2712
  store i32 0, ptr %mode, align 4, !dbg !2713, !tbaa !2714, !DIAssignID !2715
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 416, 32), metadata !2715, metadata ptr %mode, metadata !DIExpression()), !dbg !2664
  %cb = getelementptr inbounds i8, ptr %wrap, i64 56, !dbg !2716
  store ptr @_storage_compact_cb, ptr %cb, align 8, !dbg !2717, !tbaa !2718, !DIAssignID !2719
  tail call void @llvm.dbg.assign(metadata ptr @_storage_compact_cb, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64), metadata !2719, metadata ptr %cb, metadata !DIExpression()), !dbg !2664
  %call14 = call i32 @pthread_mutex_lock(ptr noundef nonnull @storage_compact_plock) #23, !dbg !2720
  %pages_used.i = getelementptr inbounds i8, ptr %st.i, i64 48
  %low_version.i = getelementptr inbounds i8, ptr %buckets.i, i64 16
  %lowest_version.i = getelementptr inbounds i8, ptr %buckets.i, i64 24
  %arrayidx.1.i = getelementptr inbounds i8, ptr %buckets.i, i64 56
  %low_version.1.i = getelementptr inbounds i8, ptr %buckets.i, i64 72
  %lowest_version.1.i = getelementptr inbounds i8, ptr %buckets.i, i64 80
  %arrayidx.2.i = getelementptr inbounds i8, ptr %buckets.i, i64 112
  %low_version.2.i = getelementptr inbounds i8, ptr %buckets.i, i64 128
  %lowest_version.2.i = getelementptr inbounds i8, ptr %buckets.i, i64 136
  %arrayidx.3.i = getelementptr inbounds i8, ptr %buckets.i, i64 168
  %low_version.3.i = getelementptr inbounds i8, ptr %buckets.i, i64 184
  %arrayidx.4.i = getelementptr inbounds i8, ptr %buckets.i, i64 224
  %low_version.4.i = getelementptr inbounds i8, ptr %buckets.i, i64 240
  %arrayidx.5.i = getelementptr inbounds i8, ptr %buckets.i, i64 280
  %low_version.5.i = getelementptr inbounds i8, ptr %buckets.i, i64 296
  %page_size6.i = getelementptr inbounds i8, ptr %st.i, i64 32
  %eflags.i = getelementptr inbounds i8, ptr %call, i64 84
  %page_count.i = getelementptr inbounds i8, ptr %st.i, i64 8
  %page_data.i = getelementptr inbounds i8, ptr %st.i, i64 136
  %pages_total88.i = getelementptr inbounds i8, ptr %buckets.i, i64 264
  %pages_free95.i = getelementptr inbounds i8, ptr %buckets.i, i64 256
  %lowest_version99.i = getelementptr inbounds i8, ptr %buckets.i, i64 248
  %lowest_page103.i = getelementptr inbounds i8, ptr %buckets.i, i64 232
  %pages_total108.i = getelementptr inbounds i8, ptr %buckets.i, i64 320
  %pages_free115.i = getelementptr inbounds i8, ptr %buckets.i, i64 312
  %lowest_version119.i = getelementptr inbounds i8, ptr %buckets.i, i64 304
  %lowest_page123.i = getelementptr inbounds i8, ptr %buckets.i, i64 288
  %pages_total136.i = getelementptr inbounds i8, ptr %buckets.i, i64 40
  %pages_free143.i = getelementptr inbounds i8, ptr %buckets.i, i64 32
  %pages_total136.1.i = getelementptr inbounds i8, ptr %buckets.i, i64 96
  %pages_free143.1.i = getelementptr inbounds i8, ptr %buckets.i, i64 88
  %pages_total136.2.i = getelementptr inbounds i8, ptr %buckets.i, i64 152
  %pages_free143.2.i = getelementptr inbounds i8, ptr %buckets.i, i64 144
  %page_version47 = getelementptr inbounds i8, ptr %wrap, i64 36
  %page_id50 = getelementptr inbounds i8, ptr %wrap, i64 48
  %offset = getelementptr inbounds i8, ptr %wrap, i64 44
  %next = getelementptr inbounds i8, ptr %wrap, i64 8
  %miss = getelementptr inbounds i8, ptr %wrap, i64 106
  %len.i = getelementptr inbounds i8, ptr %io.i, i64 40
  %mode.i = getelementptr inbounds i8, ptr %io.i, i64 52
  %buf.i = getelementptr inbounds i8, ptr %io.i, i64 16
  %page_version186.i = getelementptr inbounds i8, ptr %io.i, i64 36
  %page_id188.i = getelementptr inbounds i8, ptr %io.i, i64 48
  %offset190.i = getelementptr inbounds i8, ptr %io.i, i64 44
  br label %while.cond, !dbg !2721

while.cond.loopexit:                              ; preds = %if.end133, %if.end133.thread, %if.end29
  %flags.sroa.0.12206 = phi i8 [ %flags.sroa.0.11, %if.end29 ], [ %flags.sroa.0.12205, %if.end133.thread ], [ %flags.sroa.0.12205, %if.end133 ]
  %page_version.3204 = phi i64 [ %page_version.0, %if.end29 ], [ %page_version.3203, %if.end133.thread ], [ %page_version.3203, %if.end133 ]
  %page_id.3202 = phi i32 [ %page_id.0, %if.end29 ], [ %page_id.3201, %if.end133.thread ], [ %page_id.3201, %if.end133 ]
  %page_size.3200 = phi i64 [ %page_size.2, %if.end29 ], [ %page_size.3199, %if.end133.thread ], [ %page_size.3199, %if.end133 ]
  %page_offset.2.lcssa = phi i32 [ %page_offset.0, %if.end29 ], [ %page_offset.2189, %if.end133.thread ], [ %page_offset.3, %if.end133 ], !dbg !2722
  %compacting.2.lcssa = phi i8 [ %compacting.0, %if.end29 ], [ 0, %if.end133.thread ], [ %compacting.1208, %if.end133 ], !dbg !2664
  br label %while.cond, !dbg !2721, !llvm.loop !2723

while.cond:                                       ; preds = %while.cond.loopexit, %if.end7
  %page_size.0 = phi i64 [ 0, %if.end7 ], [ %page_size.3200, %while.cond.loopexit ], !dbg !2725
  %page_id.0 = phi i32 [ 0, %if.end7 ], [ %page_id.3202, %while.cond.loopexit ], !dbg !2726
  %page_version.0 = phi i64 [ 0, %if.end7 ], [ %page_version.3204, %while.cond.loopexit ], !dbg !2727
  %flags.sroa.0.0 = phi i8 [ 0, %if.end7 ], [ %flags.sroa.0.12206, %while.cond.loopexit ], !dbg !2728
  %page_offset.0 = phi i32 [ 0, %if.end7 ], [ %page_offset.2.lcssa, %while.cond.loopexit ], !dbg !2722
  %compacting.0 = phi i8 [ 0, %if.end7 ], [ %compacting.2.lcssa, %while.cond.loopexit ], !dbg !2729
  tail call void @llvm.dbg.value(metadata i8 %flags.sroa.0.0, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 %page_version.0, metadata !2578, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i32 %page_id.0, metadata !2581, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 %page_size.0, metadata !2579, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i8 %compacting.0, metadata !2577, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i32 %page_offset.0, metadata !2580, metadata !DIExpression()), !dbg !2664
  %tobool = trunc nuw i8 %compacting.0 to i1, !dbg !2730
  br i1 %tobool, label %if.end29, label %land.lhs.true, !dbg !2731

land.lhs.true:                                    ; preds = %while.cond
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2627, metadata !DIExpression(), metadata !2662, metadata ptr %buckets.i, metadata !DIExpression()), !dbg !2660
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2621, metadata !DIExpression()), !dbg !2660
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !2622, metadata !DIExpression()), !dbg !2660
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2623, metadata !DIExpression()), !dbg !2660
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2624, metadata !DIExpression()), !dbg !2660
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2625, metadata !DIExpression()), !dbg !2660
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2626, metadata !DIExpression()), !dbg !2660
  call void @llvm.lifetime.start.p0(i64 144, ptr nonnull %st.i) #23, !dbg !2732
  call void @llvm.lifetime.start.p0(i64 336, ptr nonnull %buckets.i) #23, !dbg !2733
  tail call void @llvm.dbg.value(metadata ptr null, metadata !2643, metadata !DIExpression()), !dbg !2660
  call void @extstore_get_stats(ptr noundef %arg, ptr noundef nonnull %st.i) #23, !dbg !2734
  %6 = load i64, ptr %pages_used.i, align 8, !dbg !2735, !tbaa !1405
  %cmp.i = icmp eq i64 %6, 0, !dbg !2737
  br i1 %cmp.i, label %storage_compact_check.exit.thread, label %for.body.preheader.i, !dbg !2738

for.body.preheader.i:                             ; preds = %land.lhs.true
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2646, metadata !DIExpression()), !dbg !2739
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(56) %buckets.i, i8 0, i64 56, i1 false), !dbg !2740
  tail call void @llvm.dbg.value(metadata i64 1, metadata !2646, metadata !DIExpression()), !dbg !2739
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %low_version.i, i8 -1, i64 16, i1 false), !dbg !2743
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %arrayidx.1.i, i8 0, i64 56, i1 false), !dbg !2740
  tail call void @llvm.dbg.value(metadata i64 2, metadata !2646, metadata !DIExpression()), !dbg !2739
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %low_version.1.i, i8 -1, i64 16, i1 false), !dbg !2743
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(56) %arrayidx.2.i, i8 0, i64 56, i1 false), !dbg !2740
  tail call void @llvm.dbg.value(metadata i64 3, metadata !2646, metadata !DIExpression()), !dbg !2739
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %low_version.2.i, i8 -1, i64 16, i1 false), !dbg !2743
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %arrayidx.3.i, i8 0, i64 56, i1 false), !dbg !2740
  tail call void @llvm.dbg.value(metadata i64 4, metadata !2646, metadata !DIExpression()), !dbg !2739
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %low_version.3.i, i8 -1, i64 16, i1 false), !dbg !2743
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(56) %arrayidx.4.i, i8 0, i64 56, i1 false), !dbg !2740
  tail call void @llvm.dbg.value(metadata i64 5, metadata !2646, metadata !DIExpression()), !dbg !2739
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %low_version.4.i, i8 -1, i64 16, i1 false), !dbg !2743
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %arrayidx.5.i, i8 0, i64 56, i1 false), !dbg !2740
  tail call void @llvm.dbg.value(metadata i64 6, metadata !2646, metadata !DIExpression()), !dbg !2739
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %low_version.5.i, i8 -1, i64 16, i1 false), !dbg !2743
  %bf.clear.i = and i8 %flags.sroa.0.0, -2, !dbg !2744
  tail call void @llvm.dbg.value(metadata i8 %bf.clear.i, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  %7 = load i64, ptr %page_size6.i, align 8, !dbg !2745, !tbaa !1425
  %conv.i = uitofp i64 %7 to double, !dbg !2746
  %8 = load double, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 66), align 8, !dbg !2747, !tbaa !2748
  %mul.i = fmul double %8, %conv.i, !dbg !2749
  %conv7.i = fptoui double %mul.i to i64, !dbg !2746
  tail call void @llvm.dbg.value(metadata i64 %conv7.i, metadata !2645, metadata !DIExpression()), !dbg !2660
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !2648, metadata !DIExpression()), !dbg !2750
  %9 = load i16, ptr %eflags.i, align 4, !dbg !2751, !tbaa !2425
  %10 = and i16 %9, 2, !dbg !2751
  %tobool.not.i = icmp eq i16 %10, 0, !dbg !2751
  br i1 %tobool.not.i, label %if.end15.i, label %if.then13.i, !dbg !2753

if.then13.i:                                      ; preds = %for.body.preheader.i
  %call14.i = call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %call, i32 noundef 15, ptr noundef null, double noundef %8, i64 noundef %conv7.i) #23, !dbg !2751
  br label %if.end15.i, !dbg !2751

if.end15.i:                                       ; preds = %if.then13.i, %for.body.preheader.i
  %11 = load i64, ptr %page_count.i, align 8, !dbg !2754, !tbaa !1318
  %call16.i = call noalias ptr @calloc(i64 noundef %11, i64 noundef 32) #24, !dbg !2755
  store ptr %call16.i, ptr %page_data.i, align 8, !dbg !2756, !tbaa !1324, !DIAssignID !2757
  tail call void @llvm.dbg.assign(metadata ptr %call16.i, metadata !2613, metadata !DIExpression(DW_OP_LLVM_fragment, 1088, 64), metadata !2757, metadata ptr %page_data.i, metadata !DIExpression()), !dbg !2660
  call void @extstore_get_page_data(ptr noundef %arg, ptr noundef nonnull %st.i) #23, !dbg !2758
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2650, metadata !DIExpression()), !dbg !2759
  %12 = load i64, ptr %page_count.i, align 8, !tbaa !1318
  %cmp21291.not.i = icmp eq i64 %12, 0, !dbg !2760
  %.pre.i = load ptr, ptr %page_data.i, align 8, !dbg !2761, !tbaa !1324
  br i1 %cmp21291.not.i, label %for.cond.cleanup23.i, label %for.body24.i, !dbg !2762

for.cond.cleanup23.i:                             ; preds = %for.inc82.i, %if.end15.i
  %13 = load i64, ptr %page_size6.i, align 8, !dbg !2763, !tbaa !1425
  tail call void @llvm.dbg.value(metadata i64 %13, metadata !2579, metadata !DIExpression()), !dbg !2664
  call void @free(ptr noundef %.pre.i) #23, !dbg !2764
  tail call void @llvm.dbg.value(metadata ptr %buckets.i, metadata !2643, metadata !DIExpression(DW_OP_plus_uconst, 224, DW_OP_stack_value)), !dbg !2660
  %14 = load i32, ptr %pages_total88.i, align 8, !dbg !2765, !tbaa !2767
  %cmp89.not.i = icmp eq i32 %14, 0, !dbg !2769
  br i1 %cmp89.not.i, label %if.end106.i, label %if.then91.i, !dbg !2770

for.body24.i:                                     ; preds = %if.end15.i, %for.inc82.i
  %indvars.iv.i = phi i64 [ %indvars.iv.next.i, %for.inc82.i ], [ 0, %if.end15.i ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i, metadata !2650, metadata !DIExpression()), !dbg !2759
  %free_bucket.i = getelementptr inbounds %struct.extstore_page_data, ptr %.pre.i, i64 %indvars.iv.i, i32 3, !dbg !2771
  %15 = load i32, ptr %free_bucket.i, align 4, !dbg !2771, !tbaa !1342
  %idxprom28.i = zext i32 %15 to i64, !dbg !2772
  %arrayidx29.i = getelementptr inbounds [6 x %struct.__storage_buk], ptr %buckets.i, i64 0, i64 %idxprom28.i, !dbg !2772
  tail call void @llvm.dbg.value(metadata ptr %arrayidx29.i, metadata !2643, metadata !DIExpression()), !dbg !2660
  %pages_total.i = getelementptr inbounds i8, ptr %arrayidx29.i, i64 40, !dbg !2773
  %16 = load i32, ptr %pages_total.i, align 8, !dbg !2774, !tbaa !2767
  %inc30.i = add i32 %16, 1, !dbg !2774
  store i32 %inc30.i, ptr %pages_total.i, align 8, !dbg !2774, !tbaa !2767
  %arrayidx33.i = getelementptr inbounds %struct.extstore_page_data, ptr %.pre.i, i64 %indvars.iv.i, !dbg !2775
  %17 = load i64, ptr %arrayidx33.i, align 8, !dbg !2777, !tbaa !1334
  %cmp34.i = icmp eq i64 %17, 0, !dbg !2778
  br i1 %cmp34.i, label %if.then36.i, label %if.else.i, !dbg !2779

if.then36.i:                                      ; preds = %for.body24.i
  %pages_free.i = getelementptr inbounds i8, ptr %arrayidx29.i, i64 32, !dbg !2780
  %18 = load i32, ptr %pages_free.i, align 8, !dbg !2782, !tbaa !2783
  %inc37.i = add i32 %18, 1, !dbg !2782
  store i32 %inc37.i, ptr %pages_free.i, align 8, !dbg !2782, !tbaa !2783
  br label %for.inc82.i, !dbg !2784

if.else.i:                                        ; preds = %for.body24.i
  %pages_used38.i = getelementptr inbounds i8, ptr %arrayidx29.i, i64 36, !dbg !2785
  %19 = load i32, ptr %pages_used38.i, align 4, !dbg !2787, !tbaa !2788
  %inc39.i = add i32 %19, 1, !dbg !2787
  store i32 %inc39.i, ptr %pages_used38.i, align 4, !dbg !2787, !tbaa !2788
  %active.i = getelementptr inbounds i8, ptr %arrayidx33.i, i64 24, !dbg !2789
  %20 = load i8, ptr %active.i, align 8, !dbg !2789, !tbaa !2791, !range !1523, !noundef !1524
  %tobool44.i = trunc nuw i8 %20 to i1, !dbg !2789
  br i1 %tobool44.i, label %for.inc82.i, label %if.end46.i, !dbg !2792

if.end46.i:                                       ; preds = %if.else.i
  %lowest_version51.i = getelementptr inbounds i8, ptr %arrayidx29.i, i64 24, !dbg !2793
  %21 = load i64, ptr %lowest_version51.i, align 8, !dbg !2793, !tbaa !2795
  %cmp52.i = icmp ult i64 %17, %21, !dbg !2796
  br i1 %cmp52.i, label %if.then54.i, label %if.end60.i, !dbg !2797

if.then54.i:                                      ; preds = %if.end46.i
  %lowest_page.i = getelementptr inbounds i8, ptr %arrayidx29.i, i64 8, !dbg !2798
  %22 = trunc nuw nsw i64 %indvars.iv.i to i32, !dbg !2800
  store i32 %22, ptr %lowest_page.i, align 8, !dbg !2800, !tbaa !2801
  store i64 %17, ptr %lowest_version51.i, align 8, !dbg !2802, !tbaa !2795
  br label %if.end60.i, !dbg !2803

if.end60.i:                                       ; preds = %if.then54.i, %if.end46.i
  %23 = load i64, ptr %page_size6.i, align 8, !dbg !2804, !tbaa !1425
  %bytes_used.i = getelementptr inbounds %struct.extstore_page_data, ptr %.pre.i, i64 %indvars.iv.i, i32 1, !dbg !2805
  %24 = load i64, ptr %bytes_used.i, align 8, !dbg !2805, !tbaa !1338
  %sub.i = sub i64 %23, %24, !dbg !2806
  %conv65.i = trunc i64 %sub.i to i32, !dbg !2807
  tail call void @llvm.dbg.value(metadata i32 %conv65.i, metadata !2652, metadata !DIExpression()), !dbg !2808
  %cmp70.i = icmp ult i64 %24, %conv7.i, !dbg !2809
  br i1 %cmp70.i, label %land.lhs.true.i, label %for.inc82.i, !dbg !2811

land.lhs.true.i:                                  ; preds = %if.end60.i
  %bytes_fragmented.i = getelementptr inbounds i8, ptr %arrayidx29.i, i64 44, !dbg !2812
  %25 = load i32, ptr %bytes_fragmented.i, align 4, !dbg !2812, !tbaa !2813
  %cmp72.i = icmp ult i32 %25, %conv65.i, !dbg !2814
  br i1 %cmp72.i, label %if.then74.i, label %for.inc82.i, !dbg !2815

if.then74.i:                                      ; preds = %land.lhs.true.i
  %low_page.i = getelementptr inbounds i8, ptr %arrayidx29.i, i64 4, !dbg !2816
  %26 = trunc nuw nsw i64 %indvars.iv.i to i32, !dbg !2818
  store i32 %26, ptr %low_page.i, align 4, !dbg !2818, !tbaa !2819
  %low_version79.i = getelementptr inbounds i8, ptr %arrayidx29.i, i64 16, !dbg !2820
  store i64 %17, ptr %low_version79.i, align 8, !dbg !2821, !tbaa !2822
  store i32 %conv65.i, ptr %bytes_fragmented.i, align 4, !dbg !2823, !tbaa !2813
  br label %for.inc82.i, !dbg !2824

for.inc82.i:                                      ; preds = %if.then74.i, %land.lhs.true.i, %if.end60.i, %if.else.i, %if.then36.i
  %indvars.iv.next.i = add nuw nsw i64 %indvars.iv.i, 1, !dbg !2825
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !2650, metadata !DIExpression()), !dbg !2759
  %exitcond.not.i = icmp eq i64 %indvars.iv.next.i, %12, !dbg !2760
  br i1 %exitcond.not.i, label %for.cond.cleanup23.i, label %for.body24.i, !dbg !2762, !llvm.loop !2826

if.then91.i:                                      ; preds = %for.cond.cleanup23.i
  %bf.set94.i = or i8 %bf.clear.i, 2, !dbg !2828
  tail call void @llvm.dbg.value(metadata i8 %bf.set94.i, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  %27 = load i32, ptr %pages_free95.i, align 16, !dbg !2830, !tbaa !2783
  %cmp96.i = icmp eq i32 %27, 0, !dbg !2832
  br i1 %cmp96.i, label %land.lhs.true98.i, label %if.end106.i, !dbg !2833

land.lhs.true98.i:                                ; preds = %if.then91.i
  %28 = load i64, ptr %lowest_version99.i, align 8, !dbg !2834, !tbaa !2795
  %cmp100.not.i = icmp eq i64 %28, -1, !dbg !2835
  br i1 %cmp100.not.i, label %if.end106.i, label %storage_compact_check.exit.thread.sink.split, !dbg !2836

if.end106.i:                                      ; preds = %land.lhs.true98.i, %if.then91.i, %for.cond.cleanup23.i
  %flags.sroa.0.1 = phi i8 [ %bf.clear.i, %for.cond.cleanup23.i ], [ %bf.set94.i, %land.lhs.true98.i ], [ %bf.set94.i, %if.then91.i ], !dbg !2660
  tail call void @llvm.dbg.value(metadata i8 %flags.sroa.0.1, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  tail call void @llvm.dbg.value(metadata ptr %buckets.i, metadata !2643, metadata !DIExpression(DW_OP_plus_uconst, 280, DW_OP_stack_value)), !dbg !2660
  %29 = load i32, ptr %pages_total108.i, align 16, !dbg !2837, !tbaa !2767
  %cmp109.not.i = icmp eq i32 %29, 0, !dbg !2839
  br i1 %cmp109.not.i, label %if.end126.i, label %if.then111.i, !dbg !2840

if.then111.i:                                     ; preds = %if.end106.i
  %bf.set114.i = or i8 %flags.sroa.0.1, 4, !dbg !2841
  tail call void @llvm.dbg.value(metadata i8 %bf.set114.i, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  %30 = load i32, ptr %pages_free115.i, align 8, !dbg !2843, !tbaa !2783
  %cmp116.i = icmp eq i32 %30, 0, !dbg !2845
  br i1 %cmp116.i, label %land.lhs.true118.i, label %if.end126.i, !dbg !2846

land.lhs.true118.i:                               ; preds = %if.then111.i
  %31 = load i64, ptr %lowest_version119.i, align 16, !dbg !2847, !tbaa !2795
  %cmp120.not.i = icmp eq i64 %31, -1, !dbg !2848
  br i1 %cmp120.not.i, label %if.end126.i, label %storage_compact_check.exit.thread.sink.split, !dbg !2849

if.end126.i:                                      ; preds = %land.lhs.true118.i, %if.then111.i, %if.end106.i
  %flags.sroa.0.2 = phi i8 [ %flags.sroa.0.1, %if.end106.i ], [ %bf.set114.i, %land.lhs.true118.i ], [ %bf.set114.i, %if.then111.i ], !dbg !2660
  tail call void @llvm.dbg.value(metadata i8 %flags.sroa.0.2, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2655, metadata !DIExpression()), !dbg !2850
  tail call void @llvm.dbg.value(metadata ptr %buckets.i, metadata !2643, metadata !DIExpression()), !dbg !2660
  %32 = load i32, ptr %pages_total136.i, align 8, !dbg !2851, !tbaa !2767
  tail call void @llvm.dbg.value(metadata i32 %32, metadata !2657, metadata !DIExpression()), !dbg !2852
  %cmp137.i = icmp eq i32 %32, 0, !dbg !2853
  br i1 %cmp137.i, label %for.inc203.i, label %if.end142.i, !dbg !2855

if.end142.i:                                      ; preds = %if.end126.i
  %33 = load i32, ptr %pages_free143.i, align 16, !dbg !2856, !tbaa !2783
  %34 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 63), align 4, !dbg !2858, !tbaa !2859
  %cmp144.i = icmp ult i32 %33, %34, !dbg !2860
  br i1 %cmp144.i, label %if.then146.i, label %for.inc203.i, !dbg !2861

if.then146.i:                                     ; preds = %if.end142.i
  %35 = load i64, ptr %low_version.i, align 16, !dbg !2862, !tbaa !2822
  %cmp148.not.i = icmp eq i64 %35, -1, !dbg !2865
  br i1 %cmp148.not.i, label %if.else153.i, label %if.then150.i, !dbg !2866

if.then150.i:                                     ; preds = %if.then146.5.i, %if.then146.4.i, %if.then146.2.i, %if.then146.1.i, %if.then146.i
  %flags.sroa.0.3 = phi i8 [ %flags.sroa.0.9, %if.then146.5.i ], [ %flags.sroa.0.9, %if.then146.4.i ], [ %flags.sroa.0.7, %if.then146.2.i ], [ %flags.sroa.0.5, %if.then146.1.i ], [ %flags.sroa.0.2, %if.then146.i ], !dbg !2744
  %arrayidx134.lcssa.i = phi ptr [ %arrayidx.5.i, %if.then146.5.i ], [ %arrayidx.4.i, %if.then146.4.i ], [ %arrayidx.2.i, %if.then146.2.i ], [ %arrayidx.1.i, %if.then146.1.i ], [ %buckets.i, %if.then146.i ], !dbg !2867
  %.lcssa.i = phi i64 [ %62, %if.then146.5.i ], [ %59, %if.then146.4.i ], [ %52, %if.then146.2.i ], [ %44, %if.then146.1.i ], [ %35, %if.then146.i ], !dbg !2862
  tail call void @llvm.dbg.value(metadata i8 %flags.sroa.0.3, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  %low_page151.i = getelementptr inbounds i8, ptr %arrayidx134.lcssa.i, i64 4, !dbg !2868
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !2581, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 %.lcssa.i, metadata !2578, metadata !DIExpression()), !dbg !2664
  br label %if.end22, !dbg !2870

if.else153.i:                                     ; preds = %if.then146.i
  %36 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 64), align 8, !dbg !2871, !tbaa !2873
  %cmp155.i = icmp ult i32 %33, %36, !dbg !2874
  br i1 %cmp155.i, label %land.lhs.true157.i, label %for.inc203.i, !dbg !2875

land.lhs.true157.i:                               ; preds = %if.else153.i
  %37 = load i64, ptr %lowest_version.i, align 8, !dbg !2876, !tbaa !2795
  %cmp159.not.i = icmp eq i64 %37, -1, !dbg !2877
  br i1 %cmp159.not.i, label %for.inc203.i, label %if.end168.i, !dbg !2878

if.end168.i:                                      ; preds = %land.lhs.true157.i
  %38 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 68), align 8, !dbg !2879, !tbaa !2882, !range !1523, !noundef !1524
  %spec.select = or i8 %flags.sroa.0.2, %38, !dbg !2883
  tail call void @llvm.dbg.value(metadata i8 %spec.select, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  %39 = and i8 %spec.select, 7, !dbg !2884
  %or.cond281.i = icmp eq i8 %39, 0, !dbg !2884
  br i1 %or.cond281.i, label %for.inc203.i, label %if.then189.i, !dbg !2884

if.then189.i:                                     ; preds = %if.end168.2.i, %if.end168.1.i, %if.end168.i
  %arrayidx134.lcssa298.i = phi ptr [ %buckets.i, %if.end168.i ], [ %arrayidx.1.i, %if.end168.1.i ], [ %arrayidx.2.i, %if.end168.2.i ], !dbg !2867
  %bf.load175.lcssa.i = phi i8 [ %spec.select, %if.end168.i ], [ %spec.select184, %if.end168.1.i ], [ %spec.select186, %if.end168.2.i ], !dbg !2886
  %.lcssa297.i = phi i64 [ %37, %if.end168.i ], [ %46, %if.end168.1.i ], [ %54, %if.end168.2.i ], !dbg !2876
  %40 = shl i8 %bf.load175.lcssa.i, 1, !dbg !2887
  %bf.shl.i = and i8 %40, 8, !dbg !2887
  %bf.clear195.i = and i8 %bf.load175.lcssa.i, -9, !dbg !2887
  %bf.set196.i = or disjoint i8 %bf.shl.i, %bf.clear195.i, !dbg !2887
  tail call void @llvm.dbg.value(metadata i8 %bf.set196.i, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  %lowest_page197.i = getelementptr inbounds i8, ptr %arrayidx134.lcssa298.i, i64 8, !dbg !2889
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !2581, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 %.lcssa297.i, metadata !2578, metadata !DIExpression()), !dbg !2664
  br label %if.end22, !dbg !2890

for.inc203.i:                                     ; preds = %if.end168.i, %land.lhs.true157.i, %if.else153.i, %if.end142.i, %if.end126.i
  %flags.sroa.0.5 = phi i8 [ %flags.sroa.0.2, %if.end126.i ], [ %flags.sroa.0.2, %land.lhs.true157.i ], [ %spec.select, %if.end168.i ], [ %flags.sroa.0.2, %if.else153.i ], [ %flags.sroa.0.2, %if.end142.i ], !dbg !2660
  tail call void @llvm.dbg.value(metadata i8 %flags.sroa.0.5, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 1, metadata !2655, metadata !DIExpression()), !dbg !2850
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.1.i, metadata !2643, metadata !DIExpression()), !dbg !2660
  %41 = load i32, ptr %pages_total136.1.i, align 16, !dbg !2851, !tbaa !2767
  tail call void @llvm.dbg.value(metadata i32 %41, metadata !2657, metadata !DIExpression()), !dbg !2852
  %cmp137.1.i = icmp eq i32 %41, 0, !dbg !2853
  br i1 %cmp137.1.i, label %for.inc203.1.i, label %if.end142.1.i, !dbg !2855

if.end142.1.i:                                    ; preds = %for.inc203.i
  %42 = load i32, ptr %pages_free143.1.i, align 8, !dbg !2856, !tbaa !2783
  %43 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 63), align 4, !dbg !2858, !tbaa !2859
  %cmp144.1.i = icmp ult i32 %42, %43, !dbg !2860
  br i1 %cmp144.1.i, label %if.then146.1.i, label %for.inc203.1.i, !dbg !2861

if.then146.1.i:                                   ; preds = %if.end142.1.i
  %44 = load i64, ptr %low_version.1.i, align 8, !dbg !2862, !tbaa !2822
  %cmp148.not.1.i = icmp eq i64 %44, -1, !dbg !2865
  br i1 %cmp148.not.1.i, label %if.else153.1.i, label %if.then150.i, !dbg !2866

if.else153.1.i:                                   ; preds = %if.then146.1.i
  %45 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 64), align 8, !dbg !2871, !tbaa !2873
  %cmp155.1.i = icmp ult i32 %42, %45, !dbg !2874
  br i1 %cmp155.1.i, label %land.lhs.true157.1.i, label %for.inc203.1.i, !dbg !2875

land.lhs.true157.1.i:                             ; preds = %if.else153.1.i
  %46 = load i64, ptr %lowest_version.1.i, align 16, !dbg !2876, !tbaa !2795
  %cmp159.not.1.i = icmp eq i64 %46, -1, !dbg !2877
  br i1 %cmp159.not.1.i, label %for.inc203.1.i, label %if.end168.1.i, !dbg !2878

if.end168.1.i:                                    ; preds = %land.lhs.true157.1.i
  %47 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 68), align 8, !dbg !2879, !tbaa !2882, !range !1523, !noundef !1524
  %spec.select184 = or i8 %flags.sroa.0.5, %47, !dbg !2883
  tail call void @llvm.dbg.value(metadata i8 %spec.select184, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  %48 = and i8 %spec.select184, 7, !dbg !2884
  %or.cond281.1.i = icmp eq i8 %48, 0, !dbg !2884
  br i1 %or.cond281.1.i, label %for.inc203.1.i, label %if.then189.i, !dbg !2884

for.inc203.1.i:                                   ; preds = %if.end168.1.i, %land.lhs.true157.1.i, %if.else153.1.i, %if.end142.1.i, %for.inc203.i
  %flags.sroa.0.7 = phi i8 [ %flags.sroa.0.5, %for.inc203.i ], [ %flags.sroa.0.5, %land.lhs.true157.1.i ], [ %spec.select184, %if.end168.1.i ], [ %flags.sroa.0.5, %if.else153.1.i ], [ %flags.sroa.0.5, %if.end142.1.i ], !dbg !2660
  tail call void @llvm.dbg.value(metadata i8 %flags.sroa.0.7, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 2, metadata !2655, metadata !DIExpression()), !dbg !2850
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.2.i, metadata !2643, metadata !DIExpression()), !dbg !2660
  %49 = load i32, ptr %pages_total136.2.i, align 8, !dbg !2851, !tbaa !2767
  tail call void @llvm.dbg.value(metadata i32 %49, metadata !2657, metadata !DIExpression()), !dbg !2852
  %cmp137.2.i = icmp eq i32 %49, 0, !dbg !2853
  br i1 %cmp137.2.i, label %for.inc203.3.i, label %if.end142.2.i, !dbg !2855

if.end142.2.i:                                    ; preds = %for.inc203.1.i
  %50 = load i32, ptr %pages_free143.2.i, align 16, !dbg !2856, !tbaa !2783
  %51 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 63), align 4, !dbg !2858, !tbaa !2859
  %cmp144.2.i = icmp ult i32 %50, %51, !dbg !2860
  br i1 %cmp144.2.i, label %if.then146.2.i, label %for.inc203.3.i, !dbg !2861

if.then146.2.i:                                   ; preds = %if.end142.2.i
  %52 = load i64, ptr %low_version.2.i, align 16, !dbg !2862, !tbaa !2822
  %cmp148.not.2.i = icmp eq i64 %52, -1, !dbg !2865
  br i1 %cmp148.not.2.i, label %if.else153.2.i, label %if.then150.i, !dbg !2866

if.else153.2.i:                                   ; preds = %if.then146.2.i
  %53 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 64), align 8, !dbg !2871, !tbaa !2873
  %cmp155.2.i = icmp ult i32 %50, %53, !dbg !2874
  br i1 %cmp155.2.i, label %land.lhs.true157.2.i, label %for.inc203.3.i, !dbg !2875

land.lhs.true157.2.i:                             ; preds = %if.else153.2.i
  %54 = load i64, ptr %lowest_version.2.i, align 8, !dbg !2876, !tbaa !2795
  %cmp159.not.2.i = icmp eq i64 %54, -1, !dbg !2877
  br i1 %cmp159.not.2.i, label %for.inc203.3.i, label %if.end168.2.i, !dbg !2878

if.end168.2.i:                                    ; preds = %land.lhs.true157.2.i
  %55 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 68), align 8, !dbg !2879, !tbaa !2882, !range !1523, !noundef !1524
  %spec.select186 = or i8 %flags.sroa.0.7, %55, !dbg !2883
  tail call void @llvm.dbg.value(metadata i8 %spec.select186, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  %56 = and i8 %spec.select186, 7, !dbg !2884
  %or.cond281.2.i = icmp eq i8 %56, 0, !dbg !2884
  br i1 %or.cond281.2.i, label %for.inc203.3.i, label %if.then189.i, !dbg !2884

for.inc203.3.i:                                   ; preds = %if.end168.2.i, %land.lhs.true157.2.i, %if.else153.2.i, %if.end142.2.i, %for.inc203.1.i
  %flags.sroa.0.9 = phi i8 [ %flags.sroa.0.7, %for.inc203.1.i ], [ %flags.sroa.0.7, %land.lhs.true157.2.i ], [ %spec.select186, %if.end168.2.i ], [ %flags.sroa.0.7, %if.else153.2.i ], [ %flags.sroa.0.7, %if.end142.2.i ], !dbg !2660
  tail call void @llvm.dbg.value(metadata i8 %flags.sroa.0.9, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 4, metadata !2655, metadata !DIExpression()), !dbg !2850
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.4.i, metadata !2643, metadata !DIExpression()), !dbg !2660
  tail call void @llvm.dbg.value(metadata i32 %14, metadata !2657, metadata !DIExpression()), !dbg !2852
  br i1 %cmp89.not.i, label %for.inc203.4.i, label %if.end142.4.i, !dbg !2855

if.end142.4.i:                                    ; preds = %for.inc203.3.i
  %57 = load i32, ptr %pages_free95.i, align 16, !dbg !2856, !tbaa !2783
  %58 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 63), align 4, !dbg !2858, !tbaa !2859
  %cmp144.4.i = icmp ult i32 %57, %58, !dbg !2860
  br i1 %cmp144.4.i, label %if.then146.4.i, label %for.inc203.4.i, !dbg !2861

if.then146.4.i:                                   ; preds = %if.end142.4.i
  %59 = load i64, ptr %low_version.4.i, align 16, !dbg !2862, !tbaa !2822
  %cmp148.not.4.i = icmp eq i64 %59, -1, !dbg !2865
  br i1 %cmp148.not.4.i, label %for.inc203.4.i, label %if.then150.i, !dbg !2866

for.inc203.4.i:                                   ; preds = %if.then146.4.i, %if.end142.4.i, %for.inc203.3.i
  tail call void @llvm.dbg.value(metadata i64 5, metadata !2655, metadata !DIExpression()), !dbg !2850
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.5.i, metadata !2643, metadata !DIExpression()), !dbg !2660
  tail call void @llvm.dbg.value(metadata i32 %29, metadata !2657, metadata !DIExpression()), !dbg !2852
  br i1 %cmp109.not.i, label %storage_compact_check.exit.thread, label %if.end142.5.i, !dbg !2855

if.end142.5.i:                                    ; preds = %for.inc203.4.i
  %60 = load i32, ptr %pages_free115.i, align 8, !dbg !2856, !tbaa !2783
  %61 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 63), align 4, !dbg !2858, !tbaa !2859
  %cmp144.5.i = icmp ult i32 %60, %61, !dbg !2860
  br i1 %cmp144.5.i, label %if.then146.5.i, label %storage_compact_check.exit.thread, !dbg !2861

if.then146.5.i:                                   ; preds = %if.end142.5.i
  %62 = load i64, ptr %low_version.5.i, align 8, !dbg !2862, !tbaa !2822
  %cmp148.not.5.i = icmp eq i64 %62, -1, !dbg !2865
  br i1 %cmp148.not.5.i, label %storage_compact_check.exit.thread, label %if.then150.i, !dbg !2866

storage_compact_check.exit.thread.sink.split:     ; preds = %land.lhs.true118.i, %land.lhs.true98.i
  %lowest_page103.i.sink = phi ptr [ %lowest_page103.i, %land.lhs.true98.i ], [ %lowest_page123.i, %land.lhs.true118.i ]
  %.sink216 = phi i64 [ %28, %land.lhs.true98.i ], [ %31, %land.lhs.true118.i ]
  %flags.sroa.0.10.ph.ph = phi i8 [ %bf.set94.i, %land.lhs.true98.i ], [ %bf.set114.i, %land.lhs.true118.i ]
  %63 = load i32, ptr %lowest_page103.i.sink, align 8, !dbg !2660, !tbaa !2801
  call void @extstore_evict_page(ptr noundef %arg, i32 noundef %63, i64 noundef %.sink216) #23, !dbg !2660
  br label %storage_compact_check.exit.thread, !dbg !2891

storage_compact_check.exit.thread:                ; preds = %storage_compact_check.exit.thread.sink.split, %land.lhs.true, %if.end142.5.i, %for.inc203.4.i, %if.then146.5.i
  %page_size.1.ph = phi i64 [ %13, %if.end142.5.i ], [ %13, %if.then146.5.i ], [ %13, %for.inc203.4.i ], [ %page_size.0, %land.lhs.true ], [ %13, %storage_compact_check.exit.thread.sink.split ]
  %flags.sroa.0.10.ph = phi i8 [ %flags.sroa.0.9, %if.end142.5.i ], [ %flags.sroa.0.9, %if.then146.5.i ], [ %flags.sroa.0.9, %for.inc203.4.i ], [ %flags.sroa.0.0, %land.lhs.true ], [ %flags.sroa.0.10.ph.ph, %storage_compact_check.exit.thread.sink.split ]
  tail call void @llvm.dbg.value(metadata i8 %flags.sroa.0.10.ph, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 %page_version.0, metadata !2578, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i32 %page_id.0, metadata !2581, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 %page_size.1.ph, metadata !2579, metadata !DIExpression()), !dbg !2664
  call void @llvm.lifetime.end.p0(i64 336, ptr nonnull %buckets.i) #23, !dbg !2891
  call void @llvm.lifetime.end.p0(i64 144, ptr nonnull %st.i) #23, !dbg !2891
  br label %if.end29, !dbg !2892

if.end22:                                         ; preds = %if.then189.i, %if.then150.i
  %page_id.1.in = phi ptr [ %low_page151.i, %if.then150.i ], [ %lowest_page197.i, %if.then189.i ]
  %page_version.1 = phi i64 [ %.lcssa.i, %if.then150.i ], [ %.lcssa297.i, %if.then189.i ], !dbg !2664
  %flags.sroa.0.10 = phi i8 [ %flags.sroa.0.3, %if.then150.i ], [ %bf.set196.i, %if.then189.i ], !dbg !2664
  %page_id.1 = load i32, ptr %page_id.1.in, align 4, !dbg !2664, !tbaa !1244
  tail call void @llvm.dbg.value(metadata i8 %flags.sroa.0.10, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 %page_version.1, metadata !2578, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i32 %page_id.1, metadata !2581, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 %13, metadata !2579, metadata !DIExpression()), !dbg !2664
  call void @llvm.lifetime.end.p0(i64 336, ptr nonnull %buckets.i) #23, !dbg !2891
  call void @llvm.lifetime.end.p0(i64 144, ptr nonnull %st.i) #23, !dbg !2891
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2580, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i8 1, metadata !2577, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !2592, metadata !DIExpression()), !dbg !2893
  %64 = load i16, ptr %eflags.i, align 4, !dbg !2894, !tbaa !2425
  %65 = and i16 %64, 2, !dbg !2894
  %tobool24.not = icmp eq i16 %65, 0, !dbg !2894
  br i1 %tobool24.not, label %while.body32.lr.ph, label %if.then25, !dbg !2896

if.then25:                                        ; preds = %if.end22
  %call26 = call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %call, i32 noundef 10, ptr noundef null, i32 noundef %page_id.1, i64 noundef %page_version.1) #23, !dbg !2894
  br label %while.body32.lr.ph, !dbg !2894

if.end29:                                         ; preds = %while.cond, %storage_compact_check.exit.thread
  %page_size.2 = phi i64 [ %page_size.0, %while.cond ], [ %page_size.1.ph, %storage_compact_check.exit.thread ], !dbg !2725
  %flags.sroa.0.11 = phi i8 [ %flags.sroa.0.0, %while.cond ], [ %flags.sroa.0.10.ph, %storage_compact_check.exit.thread ], !dbg !2728
  tail call void @llvm.dbg.value(metadata i8 %flags.sroa.0.11, metadata !2582, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8)), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 %page_version.0, metadata !2578, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i32 %page_id.0, metadata !2581, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i64 %page_size.2, metadata !2579, metadata !DIExpression()), !dbg !2664
  %call28 = call i32 @pthread_cond_wait(ptr noundef nonnull @storage_compact_cond, ptr noundef nonnull @storage_compact_plock) #23, !dbg !2897
  tail call void @llvm.dbg.value(metadata i8 %compacting.0, metadata !2577, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i32 %page_offset.0, metadata !2580, metadata !DIExpression()), !dbg !2664
  %tobool31188 = trunc nuw i8 %compacting.0 to i1, !dbg !2899
  br i1 %tobool31188, label %while.body32.lr.ph, label %while.cond.loopexit, !dbg !2900

while.body32.lr.ph:                               ; preds = %if.then25, %if.end22, %if.end29
  %compacting.1208 = phi i8 [ %compacting.0, %if.end29 ], [ 1, %if.end22 ], [ 1, %if.then25 ]
  %page_offset.1207 = phi i32 [ %page_offset.0, %if.end29 ], [ 0, %if.end22 ], [ 0, %if.then25 ]
  %flags.sroa.0.12205 = phi i8 [ %flags.sroa.0.11, %if.end29 ], [ %flags.sroa.0.10, %if.end22 ], [ %flags.sroa.0.10, %if.then25 ]
  %page_version.3203 = phi i64 [ %page_version.0, %if.end29 ], [ %page_version.1, %if.end22 ], [ %page_version.1, %if.then25 ]
  %page_id.3201 = phi i32 [ %page_id.0, %if.end29 ], [ %page_id.1, %if.end22 ], [ %page_id.1, %if.then25 ]
  %page_size.3199 = phi i64 [ %page_size.2, %if.end29 ], [ %13, %if.end22 ], [ %13, %if.then25 ]
  %conv45 = trunc i64 %page_version.3203 to i32
  %conv48 = trunc i32 %page_id.3201 to i16
  %flags.sroa.0.0.insert.ext = zext i8 %flags.sroa.0.12205 to i32
  %66 = and i32 %flags.sroa.0.0.insert.ext, 8
  %tobool28.not.i = icmp eq i32 %66, 0
  %cond29.i = select i1 %tobool28.not.i, i32 1, i32 5
  %67 = and i32 %flags.sroa.0.0.insert.ext, 2
  %tobool86.not.i = icmp ne i32 %67, 0
  %bf.clear89.i = and i32 %flags.sroa.0.0.insert.ext, 1
  %tobool91.not.i = icmp eq i32 %bf.clear89.i, 0
  %tobool31 = trunc nuw i8 %compacting.1208 to i1
  br label %while.body32, !dbg !2900

while.body32:                                     ; preds = %while.body32.lr.ph, %if.end133
  %page_offset.2189 = phi i32 [ %page_offset.1207, %while.body32.lr.ph ], [ %page_offset.3, %if.end133 ]
  tail call void @llvm.dbg.value(metadata i8 %compacting.1208, metadata !2577, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i32 %page_offset.2189, metadata !2580, metadata !DIExpression()), !dbg !2664
  %call34 = call i32 @pthread_mutex_lock(ptr noundef nonnull %lock) #23, !dbg !2901
  %conv35 = zext i32 %page_offset.2189 to i64, !dbg !2902
  %cmp36 = icmp ugt i64 %page_size.3199, %conv35, !dbg !2903
  br i1 %cmp36, label %land.lhs.true38, label %if.else56, !dbg !2904

land.lhs.true38:                                  ; preds = %while.body32
  %68 = load i8, ptr %done, align 8, !dbg !2905, !tbaa !2689, !range !1523, !noundef !1524
  %tobool40 = trunc nuw i8 %68 to i1, !dbg !2905
  br i1 %tobool40, label %if.else56, label %land.lhs.true41, !dbg !2906

land.lhs.true41:                                  ; preds = %land.lhs.true38
  %69 = load i8, ptr %submitted, align 1, !dbg !2907, !tbaa !2694, !range !1523, !noundef !1524
  %tobool43 = trunc nuw i8 %69 to i1, !dbg !2907
  br i1 %tobool43, label %if.else56, label %if.then44, !dbg !2908

if.then44:                                        ; preds = %land.lhs.true41
  store i32 %conv45, ptr %page_version47, align 4, !dbg !2909, !tbaa !2911, !DIAssignID !2912
  tail call void @llvm.dbg.assign(metadata i32 %conv45, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 288, 32), metadata !2912, metadata ptr %page_version47, metadata !DIExpression()), !dbg !2664
  store i16 %conv48, ptr %page_id50, align 8, !dbg !2913, !tbaa !2914, !DIAssignID !2915
  tail call void @llvm.dbg.assign(metadata i16 %conv48, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 16), metadata !2915, metadata ptr %page_id50, metadata !DIExpression()), !dbg !2664
  store i32 %page_offset.2189, ptr %offset, align 4, !dbg !2916, !tbaa !2917, !DIAssignID !2918
  tail call void @llvm.dbg.assign(metadata i32 %page_offset.2189, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 352, 32), metadata !2918, metadata ptr %offset, metadata !DIExpression()), !dbg !2664
  store ptr null, ptr %next, align 8, !dbg !2919, !tbaa !2920, !DIAssignID !2921
  tail call void @llvm.dbg.assign(metadata ptr null, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !2921, metadata ptr %next, metadata !DIExpression()), !dbg !2664
  store i8 1, ptr %submitted, align 1, !dbg !2922, !tbaa !2694, !DIAssignID !2923
  tail call void @llvm.dbg.assign(metadata i8 1, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 840, 8), metadata !2923, metadata ptr %submitted, metadata !DIExpression()), !dbg !2664
  store i8 0, ptr %miss, align 2, !dbg !2924, !tbaa !2925, !DIAssignID !2926
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 848, 8), metadata !2926, metadata ptr %miss, metadata !DIExpression()), !dbg !2664
  %call55 = call i32 @extstore_submit_bg(ptr noundef %arg, ptr noundef nonnull %wrap) #23, !dbg !2927
  br label %if.end133, !dbg !2928

if.else56:                                        ; preds = %land.lhs.true41, %land.lhs.true38, %while.body32
  %70 = load i8, ptr %miss, align 2, !dbg !2929, !tbaa !2925, !range !1523, !noundef !1524
  %tobool58 = trunc nuw i8 %70 to i1, !dbg !2929
  br i1 %tobool58, label %if.end66, label %if.else78, !dbg !2930

if.end66:                                         ; preds = %if.else56
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !2597, metadata !DIExpression()), !dbg !2931
  %71 = load i16, ptr %eflags.i, align 4, !dbg !2932, !tbaa !2425
  %72 = and i16 %71, 2, !dbg !2932
  %tobool70.not = icmp eq i16 %72, 0, !dbg !2932
  br i1 %tobool70.not, label %if.end73, label %if.then71, !dbg !2934

if.then71:                                        ; preds = %if.end66
  %call72 = call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %call, i32 noundef 11, ptr noundef null, i32 noundef %page_id.3201) #23, !dbg !2932
  br label %if.end73, !dbg !2932

if.end73:                                         ; preds = %if.then71, %if.end66
  store i8 0, ptr %done, align 8, !dbg !2935, !tbaa !2689, !DIAssignID !2936
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 8), metadata !2936, metadata ptr %done, metadata !DIExpression()), !dbg !2664
  store i8 0, ptr %submitted, align 1, !dbg !2937, !tbaa !2694, !DIAssignID !2938
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 840, 8), metadata !2938, metadata ptr %submitted, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2577, metadata !DIExpression()), !dbg !2664
  br label %if.end133.thread, !dbg !2939

if.else78:                                        ; preds = %if.else56
  %73 = load i8, ptr %submitted, align 1, !dbg !2940, !tbaa !2694, !range !1523, !noundef !1524
  %tobool80 = trunc nuw i8 %73 to i1, !dbg !2940
  br i1 %tobool80, label %land.lhs.true82, label %if.else106, !dbg !2941

land.lhs.true82:                                  ; preds = %if.else78
  %74 = load i8, ptr %done, align 8, !dbg !2942, !tbaa !2689, !range !1523, !noundef !1524
  %tobool84 = trunc nuw i8 %74 to i1, !dbg !2942
  br i1 %tobool84, label %if.end93, label %if.else106, !dbg !2943

if.end93:                                         ; preds = %land.lhs.true82
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !2603, metadata !DIExpression()), !dbg !2944
  %75 = load i16, ptr %eflags.i, align 4, !dbg !2945, !tbaa !2425
  %76 = and i16 %75, 2, !dbg !2945
  %tobool97.not = icmp eq i16 %76, 0, !dbg !2945
  br i1 %tobool97.not, label %if.end100, label %if.then98, !dbg !2947

if.then98:                                        ; preds = %if.end93
  %call99 = call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %call, i32 noundef 12, ptr noundef null, i32 noundef %page_id.3201, i32 noundef %page_offset.2189) #23, !dbg !2945
  br label %if.end100, !dbg !2945

if.end100:                                        ; preds = %if.then98, %if.end93
  %77 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 62), align 8, !dbg !2948, !tbaa !2675
  %conv103 = zext i32 %77 to i64, !dbg !2949
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2950, metadata !DIExpression(), metadata !2611, metadata ptr %io.i, metadata !DIExpression()), !dbg !2995
  tail call void @llvm.dbg.value(metadata i32 %flags.sroa.0.0.insert.ext, metadata !2962, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 8)), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %flags.sroa.0.0.insert.ext, metadata !2962, metadata !DIExpression(DW_OP_constu, 8, DW_OP_shr, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 24, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 8, 24)), !dbg !2997
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2960, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !2961, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata ptr %call2, metadata !2963, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %page_id.3201, metadata !2964, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i64 %page_version.3203, metadata !2965, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %page_offset.2189, metadata !2966, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i64 %conv103, metadata !2967, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2968, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2969, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2970, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2971, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2972, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2973, metadata !DIExpression()), !dbg !2997
  br label %while.cond.i, !dbg !2998

while.cond.i:                                     ; preds = %if.end222.i, %if.end100
  %rescue_old.0.i = phi i32 [ 0, %if.end100 ], [ %rescue_old.4.i, %if.end222.i ], !dbg !2999
  %rescue_cold.0.i = phi i32 [ 0, %if.end100 ], [ %rescue_cold.4.i, %if.end222.i ], !dbg !3000
  %skipped.0.i = phi i32 [ 0, %if.end100 ], [ %skipped.2.i, %if.end222.i ], !dbg !3001
  %lost.0.i = phi i32 [ 0, %if.end100 ], [ %lost.5.i, %if.end222.i ], !dbg !3002
  %rescues.0.i = phi i32 [ 0, %if.end100 ], [ %rescues.4.i, %if.end222.i ], !dbg !3003
  %offset.0.i = phi i64 [ 0, %if.end100 ], [ %add224.i, %if.end222.i ], !dbg !3004
  tail call void @llvm.dbg.value(metadata i64 %offset.0.i, metadata !2968, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %rescues.0.i, metadata !2969, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %lost.0.i, metadata !2970, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %skipped.0.i, metadata !2971, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %rescue_cold.0.i, metadata !2972, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %rescue_old.0.i, metadata !2973, metadata !DIExpression()), !dbg !2997
  %cmp.i161 = icmp ult i64 %offset.0.i, %conv103, !dbg !3005
  br i1 %cmp.i161, label %while.body.i, label %while.end.i, !dbg !2998

while.body.i:                                     ; preds = %while.cond.i
  tail call void @llvm.dbg.value(metadata ptr null, metadata !2974, metadata !DIExpression()), !dbg !3006
  tail call void @llvm.dbg.value(metadata ptr null, metadata !2975, metadata !DIExpression()), !dbg !3006
  %add.ptr.i = getelementptr inbounds i8, ptr %call2, i64 %offset.0.i, !dbg !3007
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !2976, metadata !DIExpression()), !dbg !3006
  %nkey.i = getelementptr inbounds i8, ptr %add.ptr.i, i64 41, !dbg !3008
  %78 = load i8, ptr %nkey.i, align 1, !dbg !3008, !tbaa !1203
  %cmp1.i = icmp eq i8 %78, 0, !dbg !3010
  br i1 %cmp1.i, label %while.end.i, label %if.end.i, !dbg !3011

if.end.i:                                         ; preds = %while.body.i
  %conv4.i = zext i8 %78 to i32, !dbg !3012
  %add5.i = add nuw nsw i32 %conv4.i, 49, !dbg !3012
  %nbytes.i = getelementptr inbounds i8, ptr %add.ptr.i, i64 32, !dbg !3012
  %79 = load i32, ptr %nbytes.i, align 8, !dbg !3012, !tbaa !1244
  %add7.i = add i32 %add5.i, %79, !dbg !3012
  %it_flags.i = getelementptr inbounds i8, ptr %add.ptr.i, i64 38, !dbg !3012
  %80 = load i16, ptr %it_flags.i, align 2, !dbg !3012, !tbaa !1206
  %conv8.i = zext i16 %80 to i32, !dbg !3012
  %and.i = lshr i32 %conv8.i, 6, !dbg !3012
  %81 = and i32 %and.i, 4, !dbg !3012
  %add9.i = add i32 %add7.i, %81, !dbg !3012
  %and12.i = shl nuw nsw i32 %conv8.i, 2, !dbg !3012
  %82 = and i32 %and12.i, 8, !dbg !3012
  %add15.i = add i32 %add9.i, %82, !dbg !3012
  tail call void @llvm.dbg.value(metadata i32 %add15.i, metadata !2977, metadata !DIExpression()), !dbg !3006
  %time.i = getelementptr inbounds i8, ptr %add.ptr.i, i64 24, !dbg !3013
  %83 = load i32, ptr %time.i, align 8, !dbg !3013, !tbaa !1244
  tail call void @llvm.dbg.value(metadata i32 %83, metadata !2978, metadata !DIExpression()), !dbg !3006
  call void @item_lock(i32 noundef %83) #23, !dbg !3014
  %data.i = getelementptr inbounds i8, ptr %add.ptr.i, i64 48, !dbg !3015
  %84 = load i16, ptr %it_flags.i, align 2, !dbg !3015, !tbaa !1206
  %85 = shl i16 %84, 2, !dbg !3015
  %86 = and i16 %85, 8, !dbg !3015
  %cond21.i = zext nneg i16 %86 to i64, !dbg !3015
  %add.ptr22.i = getelementptr inbounds i8, ptr %data.i, i64 %cond21.i, !dbg !3015
  %87 = load i8, ptr %nkey.i, align 1, !dbg !3016, !tbaa !1203
  %conv24.i = zext i8 %87 to i64, !dbg !3017
  %call.i = call ptr @assoc_find(ptr noundef nonnull %add.ptr22.i, i64 noundef %conv24.i, i32 noundef %83) #23, !dbg !3018
  tail call void @llvm.dbg.value(metadata ptr %call.i, metadata !2974, metadata !DIExpression()), !dbg !3006
  %cmp25.not.i = icmp eq ptr %call.i, null, !dbg !3019
  br i1 %cmp25.not.i, label %if.end222.i, label %if.then27.i, !dbg !3020

if.then27.i:                                      ; preds = %if.end.i
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2979, metadata !DIExpression()), !dbg !3021
  tail call void @llvm.dbg.value(metadata i32 %cond29.i, metadata !2980, metadata !DIExpression()), !dbg !3021
  %refcount.i = getelementptr inbounds i8, ptr %call.i, i64 36, !dbg !3022
  %88 = load i16, ptr %refcount.i, align 4, !dbg !3022, !tbaa !1206
  %inc.i = add i16 %88, 1, !dbg !3022
  store i16 %inc.i, ptr %refcount.i, align 4, !dbg !3022, !tbaa !1206
  %it_flags30.i = getelementptr inbounds i8, ptr %call.i, i64 38, !dbg !3023
  %89 = load i16, ptr %it_flags30.i, align 2, !dbg !3023, !tbaa !1206
  %90 = and i16 %89, 128, !dbg !3025
  %tobool33.not.i = icmp eq i16 %90, 0, !dbg !3025
  br i1 %tobool33.not.i, label %if.end221.i, label %land.lhs.true.i163, !dbg !3026

land.lhs.true.i163:                               ; preds = %if.then27.i
  %call34.i = call i32 @item_is_flushed(ptr noundef nonnull %call.i) #23, !dbg !3027
  %tobool35.not.i = icmp eq i32 %call34.i, 0, !dbg !3027
  br i1 %tobool35.not.i, label %land.lhs.true36.i, label %if.end221.i, !dbg !3028

land.lhs.true36.i:                                ; preds = %land.lhs.true.i163
  %exptime.i = getelementptr inbounds i8, ptr %call.i, i64 28, !dbg !3029
  %91 = load i32, ptr %exptime.i, align 4, !dbg !3029, !tbaa !1244
  %cmp37.i = icmp eq i32 %91, 0, !dbg !3030
  br i1 %cmp37.i, label %if.then42.i, label %lor.lhs.false.i, !dbg !3031

lor.lhs.false.i:                                  ; preds = %land.lhs.true36.i
  %92 = load volatile i32, ptr @current_time, align 4, !dbg !3032, !tbaa !1244
  %cmp40.i = icmp ugt i32 %91, %92, !dbg !3033
  br i1 %cmp40.i, label %if.then42.i, label %if.end221.i, !dbg !3034

if.then42.i:                                      ; preds = %lor.lhs.false.i, %land.lhs.true36.i
  %data43.i = getelementptr inbounds i8, ptr %call.i, i64 48, !dbg !3035
  %nkey44.i = getelementptr inbounds i8, ptr %call.i, i64 41, !dbg !3035
  %93 = load i8, ptr %nkey44.i, align 1, !dbg !3035, !tbaa !1203
  %idx.ext.i = zext i8 %93 to i64
  %add.ptr46.i = getelementptr inbounds i8, ptr %data43.i, i64 %idx.ext.i, !dbg !3035
  %add.ptr47.i = getelementptr inbounds i8, ptr %add.ptr46.i, i64 1, !dbg !3035
  %94 = load i16, ptr %it_flags30.i, align 2, !dbg !3035, !tbaa !1206
  %conv49.i = zext i16 %94 to i32, !dbg !3035
  %and50.i = lshr i32 %conv49.i, 6, !dbg !3035
  %95 = and i32 %and50.i, 4, !dbg !3035
  %cond52.i = zext nneg i32 %95 to i64, !dbg !3035
  %add.ptr53.i = getelementptr inbounds i8, ptr %add.ptr47.i, i64 %cond52.i, !dbg !3035
  %and56.i = shl nuw nsw i32 %conv49.i, 2, !dbg !3035
  %96 = and i32 %and56.i, 8, !dbg !3035
  %cond58.i = zext nneg i32 %96 to i64, !dbg !3035
  %add.ptr59.i = getelementptr inbounds i8, ptr %add.ptr53.i, i64 %cond58.i, !dbg !3035
  tail call void @llvm.dbg.value(metadata ptr %add.ptr59.i, metadata !2975, metadata !DIExpression()), !dbg !3006
  %page_id60.i = getelementptr inbounds i8, ptr %add.ptr59.i, i64 8, !dbg !3037
  %97 = load i16, ptr %page_id60.i, align 4, !dbg !3037, !tbaa !1210
  %conv61.i = zext i16 %97 to i32, !dbg !3039
  %cmp62.i = icmp eq i32 %page_id.3201, %conv61.i, !dbg !3040
  br i1 %cmp62.i, label %land.lhs.true64.i, label %if.end221.i, !dbg !3041

land.lhs.true64.i:                                ; preds = %if.then42.i
  %98 = load i32, ptr %add.ptr59.i, align 4, !dbg !3042, !tbaa !1215
  %conv66.i = zext i32 %98 to i64, !dbg !3043
  %cmp67.i = icmp eq i64 %page_version.3203, %conv66.i, !dbg !3044
  br i1 %cmp67.i, label %land.lhs.true69.i, label %if.end221.i, !dbg !3045

land.lhs.true69.i:                                ; preds = %land.lhs.true64.i
  %offset70.i = getelementptr inbounds i8, ptr %add.ptr59.i, i64 4, !dbg !3046
  %99 = load i32, ptr %offset70.i, align 4, !dbg !3046, !tbaa !1657
  %conv71.i = trunc nuw i64 %offset.0.i to i32, !dbg !3047
  %add72.i = add i32 %page_offset.2189, %conv71.i, !dbg !3048
  %cmp73.i = icmp eq i32 %99, %add72.i, !dbg !3049
  br i1 %cmp73.i, label %if.then75.i, label %if.end221.i, !dbg !3050

if.then75.i:                                      ; preds = %land.lhs.true69.i
  %call76.i = call i32 @extstore_delete(ptr noundef %arg, i32 noundef %page_id.3201, i64 noundef %page_version.3203, i32 noundef 1, i32 noundef %add15.i) #23, !dbg !3051
  tail call void @llvm.dbg.value(metadata i8 1, metadata !2979, metadata !DIExpression()), !dbg !3021
  %slabs_clsid.i = getelementptr inbounds i8, ptr %call.i, i64 40, !dbg !3053
  %100 = load i8, ptr %slabs_clsid.i, align 8, !dbg !3053, !tbaa !1203
  %101 = and i8 %100, -64, !dbg !3053
  %cmp79.i = icmp ne i8 %101, -128, !dbg !3055
  %brmerge.i = select i1 %cmp79.i, i1 true, i1 %tobool86.not.i, !dbg !3056
  %cond29.mux.i = select i1 %cmp79.i, i32 %cond29.i, i32 4, !dbg !3056
  br i1 %brmerge.i, label %if.then100.i, label %if.end98.i, !dbg !3056

if.end98.i:                                       ; preds = %if.then75.i
  %inc93.i = add i32 %skipped.0.i, 1
  tail call void @llvm.dbg.value(metadata i32 %cond29.i, metadata !2980, metadata !DIExpression()), !dbg !3021
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2979, metadata !DIExpression()), !dbg !3021
  tail call void @llvm.dbg.value(metadata i32 undef, metadata !2971, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata ptr %add.ptr59.i, metadata !2975, metadata !DIExpression()), !dbg !3006
  br i1 %tobool91.not.i, label %if.then100.i, label %if.end221.i, !dbg !3057

if.then100.i:                                     ; preds = %if.end98.i, %if.then75.i
  %bucket.0350.i = phi i32 [ %cond29.i, %if.end98.i ], [ %cond29.mux.i, %if.then75.i ]
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2981, metadata !DIExpression()), !dbg !2995
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %io.i) #23, !dbg !3058
  store i32 %add15.i, ptr %len.i, align 8, !dbg !3059, !tbaa !1664, !DIAssignID !3060
  tail call void @llvm.dbg.assign(metadata i32 %add15.i, metadata !2950, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 32), metadata !3060, metadata ptr %len.i, metadata !DIExpression()), !dbg !2995
  store i32 1, ptr %mode.i, align 4, !dbg !3061, !tbaa !1667, !DIAssignID !3062
  tail call void @llvm.dbg.assign(metadata i32 1, metadata !2950, metadata !DIExpression(DW_OP_LLVM_fragment, 416, 32), metadata !3062, metadata ptr %mode.i, metadata !DIExpression()), !dbg !2995
  tail call void @llvm.dbg.value(metadata i32 10, metadata !2982, metadata !DIExpression()), !dbg !2995
  %call103.i = call i32 @extstore_write_request(ptr noundef %arg, i32 noundef %bucket.0350.i, i32 noundef %bucket.0350.i, ptr noundef nonnull %io.i) #23, !dbg !3063
  %cmp104.i = icmp eq i32 %call103.i, 0, !dbg !3068
  br i1 %cmp104.i, label %if.then113.i, label %if.else109.i, !dbg !3069

if.else109.i:                                     ; preds = %if.then100.i
  %call110.i = call i32 @usleep(i32 noundef 1000) #23, !dbg !3070
  tail call void @llvm.dbg.value(metadata i32 9, metadata !2982, metadata !DIExpression()), !dbg !2995
  %call103.1.i = call i32 @extstore_write_request(ptr noundef %arg, i32 noundef %bucket.0350.i, i32 noundef %bucket.0350.i, ptr noundef nonnull %io.i) #23, !dbg !3063
  %cmp104.1.i = icmp eq i32 %call103.1.i, 0, !dbg !3068
  br i1 %cmp104.1.i, label %if.then113.i, label %if.else109.1.i, !dbg !3069

if.else109.1.i:                                   ; preds = %if.else109.i
  %call110.1.i = call i32 @usleep(i32 noundef 1000) #23, !dbg !3070
  tail call void @llvm.dbg.value(metadata i32 8, metadata !2982, metadata !DIExpression()), !dbg !2995
  %call103.2.i = call i32 @extstore_write_request(ptr noundef %arg, i32 noundef %bucket.0350.i, i32 noundef %bucket.0350.i, ptr noundef nonnull %io.i) #23, !dbg !3063
  %cmp104.2.i = icmp eq i32 %call103.2.i, 0, !dbg !3068
  br i1 %cmp104.2.i, label %if.then113.i, label %if.else109.2.i, !dbg !3069

if.else109.2.i:                                   ; preds = %if.else109.1.i
  %call110.2.i = call i32 @usleep(i32 noundef 1000) #23, !dbg !3070
  tail call void @llvm.dbg.value(metadata i32 7, metadata !2982, metadata !DIExpression()), !dbg !2995
  %call103.3.i = call i32 @extstore_write_request(ptr noundef %arg, i32 noundef %bucket.0350.i, i32 noundef %bucket.0350.i, ptr noundef nonnull %io.i) #23, !dbg !3063
  %cmp104.3.i = icmp eq i32 %call103.3.i, 0, !dbg !3068
  br i1 %cmp104.3.i, label %if.then113.i, label %if.else109.3.i, !dbg !3069

if.else109.3.i:                                   ; preds = %if.else109.2.i
  %call110.3.i = call i32 @usleep(i32 noundef 1000) #23, !dbg !3070
  tail call void @llvm.dbg.value(metadata i32 6, metadata !2982, metadata !DIExpression()), !dbg !2995
  %call103.4.i = call i32 @extstore_write_request(ptr noundef %arg, i32 noundef %bucket.0350.i, i32 noundef %bucket.0350.i, ptr noundef nonnull %io.i) #23, !dbg !3063
  %cmp104.4.i = icmp eq i32 %call103.4.i, 0, !dbg !3068
  br i1 %cmp104.4.i, label %if.then113.i, label %if.else109.4.i, !dbg !3069

if.else109.4.i:                                   ; preds = %if.else109.3.i
  %call110.4.i = call i32 @usleep(i32 noundef 1000) #23, !dbg !3070
  tail call void @llvm.dbg.value(metadata i32 5, metadata !2982, metadata !DIExpression()), !dbg !2995
  %call103.5.i = call i32 @extstore_write_request(ptr noundef %arg, i32 noundef %bucket.0350.i, i32 noundef %bucket.0350.i, ptr noundef nonnull %io.i) #23, !dbg !3063
  %cmp104.5.i = icmp eq i32 %call103.5.i, 0, !dbg !3068
  br i1 %cmp104.5.i, label %if.then113.i, label %if.else109.5.i, !dbg !3069

if.else109.5.i:                                   ; preds = %if.else109.4.i
  %call110.5.i = call i32 @usleep(i32 noundef 1000) #23, !dbg !3070
  tail call void @llvm.dbg.value(metadata i32 4, metadata !2982, metadata !DIExpression()), !dbg !2995
  %call103.6.i = call i32 @extstore_write_request(ptr noundef %arg, i32 noundef %bucket.0350.i, i32 noundef %bucket.0350.i, ptr noundef nonnull %io.i) #23, !dbg !3063
  %cmp104.6.i = icmp eq i32 %call103.6.i, 0, !dbg !3068
  br i1 %cmp104.6.i, label %if.then113.i, label %if.else109.6.i, !dbg !3069

if.else109.6.i:                                   ; preds = %if.else109.5.i
  %call110.6.i = call i32 @usleep(i32 noundef 1000) #23, !dbg !3070
  tail call void @llvm.dbg.value(metadata i32 3, metadata !2982, metadata !DIExpression()), !dbg !2995
  %call103.7.i = call i32 @extstore_write_request(ptr noundef %arg, i32 noundef %bucket.0350.i, i32 noundef %bucket.0350.i, ptr noundef nonnull %io.i) #23, !dbg !3063
  %cmp104.7.i = icmp eq i32 %call103.7.i, 0, !dbg !3068
  br i1 %cmp104.7.i, label %if.then113.i, label %if.else109.7.i, !dbg !3069

if.else109.7.i:                                   ; preds = %if.else109.6.i
  %call110.7.i = call i32 @usleep(i32 noundef 1000) #23, !dbg !3070
  tail call void @llvm.dbg.value(metadata i32 2, metadata !2982, metadata !DIExpression()), !dbg !2995
  %call103.8.i = call i32 @extstore_write_request(ptr noundef %arg, i32 noundef %bucket.0350.i, i32 noundef %bucket.0350.i, ptr noundef nonnull %io.i) #23, !dbg !3063
  %cmp104.8.i = icmp eq i32 %call103.8.i, 0, !dbg !3068
  br i1 %cmp104.8.i, label %if.then113.i, label %if.else109.8.i, !dbg !3069

if.else109.8.i:                                   ; preds = %if.else109.7.i
  %call110.8.i = call i32 @usleep(i32 noundef 1000) #23, !dbg !3070
  tail call void @llvm.dbg.value(metadata i32 1, metadata !2982, metadata !DIExpression()), !dbg !2995
  %call103.9.i = call i32 @extstore_write_request(ptr noundef %arg, i32 noundef %bucket.0350.i, i32 noundef %bucket.0350.i, ptr noundef nonnull %io.i) #23, !dbg !3063
  %cmp104.9.i = icmp eq i32 %call103.9.i, 0, !dbg !3068
  br i1 %cmp104.9.i, label %if.then113.i, label %if.else109.9.i, !dbg !3069

if.else109.9.i:                                   ; preds = %if.else109.8.i
  %call110.9.i = call i32 @usleep(i32 noundef 1000) #23, !dbg !3070
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2982, metadata !DIExpression()), !dbg !2995
  %inc219.i = add i32 %lost.0.i, 1, !dbg !3072
  tail call void @llvm.dbg.value(metadata i32 %inc219.i, metadata !2970, metadata !DIExpression()), !dbg !2997
  br label %if.end220.i

if.then113.i:                                     ; preds = %if.else109.8.i, %if.else109.7.i, %if.else109.6.i, %if.else109.5.i, %if.else109.4.i, %if.else109.3.i, %if.else109.2.i, %if.else109.1.i, %if.else109.i, %if.then100.i
  %102 = load ptr, ptr %buf.i, align 8, !dbg !3074, !tbaa !1632
  %103 = load i32, ptr %len.i, align 8, !dbg !3076, !tbaa !1664
  %conv108.i = zext i32 %103 to i64, !dbg !3077
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %102, ptr nonnull align 8 %add.ptr.i, i64 %conv108.i, i1 false), !dbg !3078
  call void @extstore_write(ptr noundef %arg, ptr noundef nonnull %io.i) #23, !dbg !3079
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2981, metadata !DIExpression()), !dbg !2995
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2983, metadata !DIExpression()), !dbg !3080
  %refcount114.i = getelementptr inbounds i8, ptr %add.ptr.i, i64 36, !dbg !3081
  %104 = load i16, ptr %refcount114.i, align 4, !dbg !3081, !tbaa !1206
  %cmp116.i165 = icmp eq i16 %104, 2, !dbg !3082
  br i1 %cmp116.i165, label %if.then118.i, label %if.else125.i, !dbg !3083

if.then118.i:                                     ; preds = %if.then113.i
  %105 = load i32, ptr %page_version186.i, align 4, !dbg !3084, !tbaa !1651
  store i32 %105, ptr %add.ptr59.i, align 4, !dbg !3086, !tbaa !1215
  %106 = load i16, ptr %page_id188.i, align 8, !dbg !3087, !tbaa !1655
  store i16 %106, ptr %page_id60.i, align 4, !dbg !3088, !tbaa !1210
  %107 = load i32, ptr %offset190.i, align 4, !dbg !3089, !tbaa !1660
  store i32 %107, ptr %offset70.i, align 4, !dbg !3090, !tbaa !1657
  tail call void @llvm.dbg.value(metadata i8 1, metadata !2983, metadata !DIExpression()), !dbg !3080
  br label %if.then204.i, !dbg !3091

if.else125.i:                                     ; preds = %if.then113.i
  %108 = load i16, ptr %it_flags30.i, align 2, !dbg !3092, !tbaa !1206
  %conv128.i = zext i16 %108 to i32, !dbg !3092
  %and129.i = and i32 %conv128.i, 256, !dbg !3092
  %tobool130.not.i = icmp eq i32 %and129.i, 0, !dbg !3092
  %.pre.i166 = load i8, ptr %nkey44.i, align 1, !dbg !3095, !tbaa !1203
  %.pre363.i = zext i8 %.pre.i166 to i64
  br i1 %tobool130.not.i, label %if.end145.i, label %if.then131.i, !dbg !3096

if.then131.i:                                     ; preds = %if.else125.i
  %add.ptr136.i = getelementptr inbounds i8, ptr %data43.i, i64 %.pre363.i, !dbg !3097
  %add.ptr137.i = getelementptr inbounds i8, ptr %add.ptr136.i, i64 1, !dbg !3097
  %and140.i = shl nuw nsw i32 %conv128.i, 2, !dbg !3097
  %109 = and i32 %and140.i, 8, !dbg !3097
  %cond142.i = zext nneg i32 %109 to i64, !dbg !3097
  %add.ptr143.i = getelementptr inbounds i8, ptr %add.ptr137.i, i64 %cond142.i, !dbg !3097
  %110 = load i32, ptr %add.ptr143.i, align 4, !dbg !3097, !tbaa !1244
  tail call void @llvm.dbg.value(metadata i32 %110, metadata !2986, metadata !DIExpression()), !dbg !3099
  br label %if.end145.i, !dbg !3097

if.end145.i:                                      ; preds = %if.then131.i, %if.else125.i
  %flags126.0.i = phi i32 [ %110, %if.then131.i ], [ 0, %if.else125.i ], !dbg !3092
  tail call void @llvm.dbg.value(metadata i32 %flags126.0.i, metadata !2986, metadata !DIExpression()), !dbg !3099
  %111 = shl i16 %108, 2, !dbg !3100
  %112 = and i16 %111, 8, !dbg !3100
  %cond151.i = zext nneg i16 %112 to i64, !dbg !3100
  %add.ptr152.i = getelementptr inbounds i8, ptr %data43.i, i64 %cond151.i, !dbg !3100
  %113 = load i32, ptr %exptime.i, align 4, !dbg !3101, !tbaa !1244
  %call156.i = call ptr @do_item_alloc(ptr noundef nonnull %add.ptr152.i, i64 noundef %.pre363.i, i32 noundef %flags126.0.i, i32 noundef %113, i32 noundef 12) #23, !dbg !3102
  tail call void @llvm.dbg.value(metadata ptr %call156.i, metadata !2989, metadata !DIExpression()), !dbg !3099
  %tobool157.not.not.i = icmp eq ptr %call156.i, null, !dbg !3103
  br i1 %tobool157.not.not.i, label %if.end202.i, label %if.then158.i, !dbg !3104

if.then158.i:                                     ; preds = %if.end145.i
  %114 = load i16, ptr %it_flags30.i, align 2, !dbg !3105, !tbaa !1206
  %115 = and i16 %114, -2, !dbg !3106
  %it_flags163.i = getelementptr inbounds i8, ptr %call156.i, i64 38, !dbg !3107
  store i16 %115, ptr %it_flags163.i, align 2, !dbg !3108, !tbaa !1206
  %time164.i = getelementptr inbounds i8, ptr %call.i, i64 24, !dbg !3109
  %116 = load i32, ptr %time164.i, align 8, !dbg !3109, !tbaa !1244
  %time165.i = getelementptr inbounds i8, ptr %call156.i, i64 24, !dbg !3110
  store i32 %116, ptr %time165.i, align 8, !dbg !3111, !tbaa !1244
  %nbytes166.i = getelementptr inbounds i8, ptr %call.i, i64 32, !dbg !3112
  %117 = load i32, ptr %nbytes166.i, align 8, !dbg !3112, !tbaa !1244
  %nbytes167.i = getelementptr inbounds i8, ptr %call156.i, i64 32, !dbg !3113
  store i32 %117, ptr %nbytes167.i, align 8, !dbg !3114, !tbaa !1244
  %data168.i = getelementptr inbounds i8, ptr %call156.i, i64 48, !dbg !3115
  %nkey169.i = getelementptr inbounds i8, ptr %call156.i, i64 41, !dbg !3115
  %118 = load i8, ptr %nkey169.i, align 1, !dbg !3115, !tbaa !1203
  %idx.ext171.i = zext i8 %118 to i64
  %add.ptr172.i = getelementptr inbounds i8, ptr %data168.i, i64 %idx.ext171.i, !dbg !3115
  %add.ptr173.i = getelementptr inbounds i8, ptr %add.ptr172.i, i64 1, !dbg !3115
  %conv175.i = zext i16 %115 to i32, !dbg !3115
  %and176.i = lshr i32 %conv175.i, 6, !dbg !3115
  %119 = and i32 %and176.i, 4, !dbg !3115
  %cond178.i = zext nneg i32 %119 to i64, !dbg !3115
  %add.ptr179.i = getelementptr inbounds i8, ptr %add.ptr173.i, i64 %cond178.i, !dbg !3115
  %and182.i = shl nuw nsw i32 %conv175.i, 2, !dbg !3115
  %120 = and i32 %and182.i, 8, !dbg !3115
  %cond184.i = zext nneg i32 %120 to i64, !dbg !3115
  %add.ptr185.i = getelementptr inbounds i8, ptr %add.ptr179.i, i64 %cond184.i, !dbg !3115
  tail call void @llvm.dbg.value(metadata ptr %add.ptr185.i, metadata !2990, metadata !DIExpression()), !dbg !3116
  %121 = load i32, ptr %page_version186.i, align 4, !dbg !3117, !tbaa !1651
  store i32 %121, ptr %add.ptr185.i, align 4, !dbg !3118, !tbaa !1215
  %122 = load i16, ptr %page_id188.i, align 8, !dbg !3119, !tbaa !1655
  %page_id189.i = getelementptr inbounds i8, ptr %add.ptr185.i, i64 8, !dbg !3120
  store i16 %122, ptr %page_id189.i, align 4, !dbg !3121, !tbaa !1210
  %123 = load i32, ptr %offset190.i, align 4, !dbg !3122, !tbaa !1660
  %offset191.i = getelementptr inbounds i8, ptr %add.ptr185.i, i64 4, !dbg !3123
  store i32 %123, ptr %offset191.i, align 4, !dbg !3124, !tbaa !1657
  %124 = load i16, ptr %it_flags30.i, align 2, !dbg !3125, !tbaa !1206
  %125 = and i16 %124, 2, !dbg !3125
  %tobool195.not.i = icmp eq i16 %125, 0, !dbg !3125
  br i1 %tobool195.not.i, label %cond.end.i, label %cond.true.i, !dbg !3125

cond.true.i:                                      ; preds = %if.then158.i
  %126 = load i64, ptr %data43.i, align 8, !dbg !3125, !tbaa !1203
  br label %cond.end.i, !dbg !3125

cond.end.i:                                       ; preds = %cond.true.i, %if.then158.i
  %cond197.i = phi i64 [ %126, %cond.true.i ], [ 0, %if.then158.i ], !dbg !3125
  %call198.i = call i32 @item_replace(ptr noundef nonnull %call.i, ptr noundef nonnull %call156.i, i32 noundef %83, i64 noundef %cond197.i) #23, !dbg !3126
  call void @do_item_remove(ptr noundef nonnull %call156.i) #23, !dbg !3127
  tail call void @llvm.dbg.value(metadata i8 1, metadata !2983, metadata !DIExpression()), !dbg !3080
  br label %if.then204.i, !dbg !3128

if.end202.i:                                      ; preds = %if.end145.i
  %inc200.i = add i32 %lost.0.i, 1, !dbg !3129
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2983, metadata !DIExpression()), !dbg !3080
  tail call void @llvm.dbg.value(metadata i32 %inc200.i, metadata !2970, metadata !DIExpression()), !dbg !2997
  br label %if.end220.i, !dbg !3131

if.then204.i:                                     ; preds = %cond.end.i, %if.then118.i
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !2983, metadata !DIExpression()), !dbg !3080
  tail call void @llvm.dbg.value(metadata i32 %lost.0.i, metadata !2970, metadata !DIExpression()), !dbg !2997
  %inc205.i = add i32 %rescues.0.i, 1, !dbg !3132
  tail call void @llvm.dbg.value(metadata i32 %inc205.i, metadata !2969, metadata !DIExpression()), !dbg !2997
  switch i32 %bucket.0350.i, label %if.end220.i [
    i32 4, label %if.then208.i
    i32 5, label %if.then213.i
  ], !dbg !3135

if.then208.i:                                     ; preds = %if.then204.i
  %inc209.i = add i32 %rescue_cold.0.i, 1, !dbg !3136
  tail call void @llvm.dbg.value(metadata i32 %inc209.i, metadata !2972, metadata !DIExpression()), !dbg !2997
  br label %if.end220.i, !dbg !3139

if.then213.i:                                     ; preds = %if.then204.i
  %inc214.i = add i32 %rescue_old.0.i, 1, !dbg !3140
  tail call void @llvm.dbg.value(metadata i32 %inc214.i, metadata !2973, metadata !DIExpression()), !dbg !2997
  br label %if.end220.i, !dbg !3143

if.end220.i:                                      ; preds = %if.then213.i, %if.then208.i, %if.then204.i, %if.end202.i, %if.else109.9.i
  %rescue_old.2.i = phi i32 [ %rescue_old.0.i, %if.else109.9.i ], [ %rescue_old.0.i, %if.then208.i ], [ %inc214.i, %if.then213.i ], [ %rescue_old.0.i, %if.end202.i ], [ %rescue_old.0.i, %if.then204.i ], !dbg !2999
  %rescue_cold.2.i = phi i32 [ %rescue_cold.0.i, %if.else109.9.i ], [ %inc209.i, %if.then208.i ], [ %rescue_cold.0.i, %if.then213.i ], [ %rescue_cold.0.i, %if.end202.i ], [ %rescue_cold.0.i, %if.then204.i ], !dbg !2997
  %lost.3.i = phi i32 [ %inc219.i, %if.else109.9.i ], [ %lost.0.i, %if.then208.i ], [ %lost.0.i, %if.then213.i ], [ %inc200.i, %if.end202.i ], [ %lost.0.i, %if.then204.i ], !dbg !2997
  %rescues.2.i = phi i32 [ %rescues.0.i, %if.else109.9.i ], [ %inc205.i, %if.then208.i ], [ %inc205.i, %if.then213.i ], [ %rescues.0.i, %if.end202.i ], [ %inc205.i, %if.then204.i ], !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %rescues.2.i, metadata !2969, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %lost.3.i, metadata !2970, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %rescue_cold.2.i, metadata !2972, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %rescue_old.2.i, metadata !2973, metadata !DIExpression()), !dbg !2997
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %io.i) #23, !dbg !3144
  br label %if.end221.i, !dbg !3145

if.end221.i:                                      ; preds = %if.end220.i, %if.end98.i, %land.lhs.true69.i, %land.lhs.true64.i, %if.then42.i, %lor.lhs.false.i, %land.lhs.true.i163, %if.then27.i
  %skipped.1341.i = phi i32 [ %skipped.0.i, %if.end220.i ], [ %inc93.i, %if.end98.i ], [ %skipped.0.i, %land.lhs.true.i163 ], [ %skipped.0.i, %land.lhs.true69.i ], [ %skipped.0.i, %land.lhs.true64.i ], [ %skipped.0.i, %if.then42.i ], [ %skipped.0.i, %lor.lhs.false.i ], [ %skipped.0.i, %if.then27.i ]
  %rescue_old.3.i = phi i32 [ %rescue_old.2.i, %if.end220.i ], [ %rescue_old.0.i, %if.end98.i ], [ %rescue_old.0.i, %land.lhs.true.i163 ], [ %rescue_old.0.i, %land.lhs.true69.i ], [ %rescue_old.0.i, %land.lhs.true64.i ], [ %rescue_old.0.i, %if.then42.i ], [ %rescue_old.0.i, %lor.lhs.false.i ], [ %rescue_old.0.i, %if.then27.i ], !dbg !2999
  %rescue_cold.3.i = phi i32 [ %rescue_cold.2.i, %if.end220.i ], [ %rescue_cold.0.i, %if.end98.i ], [ %rescue_cold.0.i, %land.lhs.true.i163 ], [ %rescue_cold.0.i, %land.lhs.true69.i ], [ %rescue_cold.0.i, %land.lhs.true64.i ], [ %rescue_cold.0.i, %if.then42.i ], [ %rescue_cold.0.i, %lor.lhs.false.i ], [ %rescue_cold.0.i, %if.then27.i ], !dbg !2997
  %lost.4.i = phi i32 [ %lost.3.i, %if.end220.i ], [ %lost.0.i, %if.end98.i ], [ %lost.0.i, %land.lhs.true.i163 ], [ %lost.0.i, %land.lhs.true69.i ], [ %lost.0.i, %land.lhs.true64.i ], [ %lost.0.i, %if.then42.i ], [ %lost.0.i, %lor.lhs.false.i ], [ %lost.0.i, %if.then27.i ], !dbg !3002
  %rescues.3.i = phi i32 [ %rescues.2.i, %if.end220.i ], [ %rescues.0.i, %if.end98.i ], [ %rescues.0.i, %land.lhs.true.i163 ], [ %rescues.0.i, %land.lhs.true69.i ], [ %rescues.0.i, %land.lhs.true64.i ], [ %rescues.0.i, %if.then42.i ], [ %rescues.0.i, %lor.lhs.false.i ], [ %rescues.0.i, %if.then27.i ], !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %rescues.3.i, metadata !2969, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %lost.4.i, metadata !2970, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %rescue_cold.3.i, metadata !2972, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %rescue_old.3.i, metadata !2973, metadata !DIExpression()), !dbg !2997
  call void @do_item_remove(ptr noundef nonnull %call.i) #23, !dbg !3146
  br label %if.end222.i, !dbg !3147

if.end222.i:                                      ; preds = %if.end221.i, %if.end.i
  %rescue_old.4.i = phi i32 [ %rescue_old.3.i, %if.end221.i ], [ %rescue_old.0.i, %if.end.i ], !dbg !2999
  %rescue_cold.4.i = phi i32 [ %rescue_cold.3.i, %if.end221.i ], [ %rescue_cold.0.i, %if.end.i ], !dbg !2997
  %skipped.2.i = phi i32 [ %skipped.1341.i, %if.end221.i ], [ %skipped.0.i, %if.end.i ], !dbg !3001
  %lost.5.i = phi i32 [ %lost.4.i, %if.end221.i ], [ %lost.0.i, %if.end.i ], !dbg !3002
  %rescues.4.i = phi i32 [ %rescues.3.i, %if.end221.i ], [ %rescues.0.i, %if.end.i ], !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %rescues.4.i, metadata !2969, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %lost.5.i, metadata !2970, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %skipped.2.i, metadata !2971, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %rescue_cold.4.i, metadata !2972, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %rescue_old.4.i, metadata !2973, metadata !DIExpression()), !dbg !2997
  call void @item_unlock(i32 noundef %83) #23, !dbg !3148
  %conv223.i = zext i32 %add15.i to i64, !dbg !3149
  %add224.i = add nuw nsw i64 %offset.0.i, %conv223.i, !dbg !3150
  tail call void @llvm.dbg.value(metadata i64 %add224.i, metadata !2968, metadata !DIExpression()), !dbg !2997
  %sub.i164 = sub nsw i64 %conv103, %add224.i, !dbg !3151
  %cmp225.i = icmp ult i64 %sub.i164, 48, !dbg !3153
  br i1 %cmp225.i, label %while.end.i, label %while.cond.i

while.end.i:                                      ; preds = %if.end222.i, %while.body.i, %while.cond.i
  %rescue_old.6.i = phi i32 [ %rescue_old.0.i, %while.cond.i ], [ %rescue_old.0.i, %while.body.i ], [ %rescue_old.4.i, %if.end222.i ], !dbg !2999
  %rescue_cold.6.i = phi i32 [ %rescue_cold.0.i, %while.cond.i ], [ %rescue_cold.0.i, %while.body.i ], [ %rescue_cold.4.i, %if.end222.i ], !dbg !3000
  %skipped.4.i = phi i32 [ %skipped.0.i, %while.cond.i ], [ %skipped.0.i, %while.body.i ], [ %skipped.2.i, %if.end222.i ], !dbg !3001
  %lost.7.i = phi i32 [ %lost.0.i, %while.cond.i ], [ %lost.0.i, %while.body.i ], [ %lost.5.i, %if.end222.i ], !dbg !3002
  %rescues.6.i = phi i32 [ %rescues.0.i, %while.cond.i ], [ %rescues.0.i, %while.body.i ], [ %rescues.4.i, %if.end222.i ], !dbg !3003
  %offset.2.i = phi i64 [ %offset.0.i, %while.cond.i ], [ %offset.0.i, %while.body.i ], [ %add224.i, %if.end222.i ], !dbg !3004
  tail call void @llvm.dbg.value(metadata i64 %offset.2.i, metadata !2968, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %rescues.6.i, metadata !2969, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %lost.7.i, metadata !2970, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %skipped.4.i, metadata !2971, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %rescue_cold.6.i, metadata !2972, metadata !DIExpression()), !dbg !2997
  tail call void @llvm.dbg.value(metadata i32 %rescue_old.6.i, metadata !2973, metadata !DIExpression()), !dbg !2997
  call void @STATS_LOCK() #23, !dbg !3154
  %conv233.i = zext i32 %lost.7.i to i64, !dbg !3155
  %127 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 19), align 8, !dbg !3156, !tbaa !1382
  %add234.i = add i64 %127, %conv233.i, !dbg !3156
  store i64 %add234.i, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 19), align 8, !dbg !3156, !tbaa !1382
  %conv235.i = zext i32 %rescues.6.i to i64, !dbg !3157
  %128 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 20), align 8, !dbg !3158, !tbaa !1386
  %add236.i = add i64 %128, %conv235.i, !dbg !3158
  store i64 %add236.i, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 20), align 8, !dbg !3158, !tbaa !1386
  %conv237.i = zext i32 %skipped.4.i to i64, !dbg !3159
  %129 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 21), align 8, !dbg !3160, !tbaa !1392
  %add238.i = add i64 %129, %conv237.i, !dbg !3160
  store i64 %add238.i, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 21), align 8, !dbg !3160, !tbaa !1392
  %conv239.i = zext i32 %rescue_cold.6.i to i64, !dbg !3161
  %130 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 22), align 8, !dbg !3162, !tbaa !1388
  %add240.i = add i64 %130, %conv239.i, !dbg !3162
  store i64 %add240.i, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 22), align 8, !dbg !3162, !tbaa !1388
  %conv241.i = zext i32 %rescue_old.6.i to i64, !dbg !3163
  %131 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 23), align 8, !dbg !3164, !tbaa !1390
  %add242.i = add i64 %131, %conv241.i, !dbg !3164
  store i64 %add242.i, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 23), align 8, !dbg !3164, !tbaa !1390
  call void @STATS_UNLOCK() #23, !dbg !3165
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !2993, metadata !DIExpression()), !dbg !3166
  %132 = load i16, ptr %eflags.i, align 4, !dbg !3167, !tbaa !2425
  %133 = and i16 %132, 2, !dbg !3167
  %tobool250.not.i = icmp eq i16 %133, 0, !dbg !3167
  br i1 %tobool250.not.i, label %storage_compact_readback.exit, label %if.then251.i, !dbg !3169

if.then251.i:                                     ; preds = %while.end.i
  %call252.i = call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %call, i32 noundef 13, ptr noundef null, i32 noundef %page_id.3201, i64 noundef %offset.2.i, i32 noundef %rescues.6.i, i32 noundef %lost.7.i, i32 noundef %skipped.4.i) #23, !dbg !3167
  br label %storage_compact_readback.exit, !dbg !3167

storage_compact_readback.exit:                    ; preds = %while.end.i, %if.then251.i
  %134 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 62), align 8, !dbg !3170, !tbaa !2675
  %add = add i32 %134, %page_offset.2189, !dbg !3171
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !2580, metadata !DIExpression()), !dbg !2664
  store i8 0, ptr %done, align 8, !dbg !3172, !tbaa !2689, !DIAssignID !3173
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 8), metadata !3173, metadata ptr %done, metadata !DIExpression()), !dbg !2664
  store i8 0, ptr %submitted, align 1, !dbg !3174, !tbaa !2694, !DIAssignID !3175
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 840, 8), metadata !3175, metadata ptr %submitted, metadata !DIExpression()), !dbg !2664
  br label %if.end133, !dbg !3176

if.else106:                                       ; preds = %land.lhs.true82, %if.else78
  br i1 %cmp36, label %if.end133, label %if.then110, !dbg !3177

if.then110:                                       ; preds = %if.else106
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2577, metadata !DIExpression()), !dbg !2664
  store i8 0, ptr %done, align 8, !dbg !3178, !tbaa !2689, !DIAssignID !3179
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 8), metadata !3179, metadata ptr %done, metadata !DIExpression()), !dbg !2664
  store i8 0, ptr %submitted, align 1, !dbg !3180, !tbaa !2694, !DIAssignID !3181
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2590, metadata !DIExpression(DW_OP_LLVM_fragment, 840, 8), metadata !3181, metadata ptr %submitted, metadata !DIExpression()), !dbg !2664
  call void @extstore_close_page(ptr noundef %arg, i32 noundef %page_id.3201, i64 noundef %page_version.3203) #23, !dbg !3182
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !2607, metadata !DIExpression()), !dbg !3183
  %135 = load i16, ptr %eflags.i, align 4, !dbg !3184, !tbaa !2425
  %136 = and i16 %135, 2, !dbg !3184
  %tobool123.not = icmp eq i16 %136, 0, !dbg !3184
  br i1 %tobool123.not, label %if.end126, label %if.then124, !dbg !3186

if.then124:                                       ; preds = %if.then110
  %call125 = call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %call, i32 noundef 14, ptr noundef null, i32 noundef %page_id.3201) #23, !dbg !3184
  br label %if.end126, !dbg !3184

if.end126:                                        ; preds = %if.then124, %if.then110
  %call129 = call i32 @usleep(i32 noundef 1000) #23, !dbg !3187
  br label %if.end133.thread, !dbg !3188

if.end133.thread:                                 ; preds = %if.end73, %if.end126
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2577, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i32 %page_offset.2189, metadata !2580, metadata !DIExpression()), !dbg !2664
  %call135211 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %lock) #23, !dbg !3189
  br label %while.cond.loopexit, !dbg !2900

if.end133:                                        ; preds = %if.else106, %storage_compact_readback.exit, %if.then44
  %page_offset.3 = phi i32 [ %add, %storage_compact_readback.exit ], [ %page_offset.2189, %if.else106 ], [ %page_offset.2189, %if.then44 ], !dbg !2664
  tail call void @llvm.dbg.value(metadata i8 %compacting.1208, metadata !2577, metadata !DIExpression()), !dbg !2664
  tail call void @llvm.dbg.value(metadata i32 %page_offset.3, metadata !2580, metadata !DIExpression()), !dbg !2664
  %call135 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %lock) #23, !dbg !3189
  br i1 %tobool31, label %while.body32, label %while.cond.loopexit, !dbg !2900, !llvm.loop !3190
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noalias noundef ptr @storage_conf_parse(ptr noundef %arg, i32 noundef %page_size) local_unnamed_addr #0 !dbg !3192 {
entry:
  %b = alloca ptr, align 8, !DIAssignID !3207
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3199, metadata !DIExpression(), metadata !3207, metadata ptr %b, metadata !DIExpression()), !dbg !3208
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !3196, metadata !DIExpression()), !dbg !3208
  tail call void @llvm.dbg.value(metadata i32 %page_size, metadata !3197, metadata !DIExpression()), !dbg !3208
  tail call void @llvm.dbg.value(metadata ptr null, metadata !3198, metadata !DIExpression()), !dbg !3208
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %b) #23, !dbg !3209
  store ptr null, ptr %b, align 8, !dbg !3210, !tbaa !1311, !DIAssignID !3211
  tail call void @llvm.dbg.assign(metadata ptr null, metadata !3199, metadata !DIExpression(), metadata !3211, metadata ptr %b, metadata !DIExpression()), !dbg !3208
  %call = call ptr @strtok_r(ptr noundef %arg, ptr noundef nonnull @.str.33, ptr noundef nonnull %b) #23, !dbg !3212
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !3200, metadata !DIExpression()), !dbg !3208
  tail call void @llvm.dbg.value(metadata i8 0, metadata !3201, metadata !DIExpression()), !dbg !3208
  tail call void @llvm.dbg.value(metadata i64 0, metadata !3202, metadata !DIExpression()), !dbg !3208
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3203, metadata !DIExpression()), !dbg !3208
  %cmp = icmp eq ptr %call, null, !dbg !3213
  br i1 %cmp, label %cleanup, label %if.end, !dbg !3215

if.end:                                           ; preds = %entry
  %call1 = call noalias dereferenceable_or_null(48) ptr @calloc(i64 noundef 1, i64 noundef 48) #24, !dbg !3216
  tail call void @llvm.dbg.value(metadata ptr %call1, metadata !3198, metadata !DIExpression()), !dbg !3208
  %call2 = call noalias ptr @strdup(ptr noundef nonnull %call) #23, !dbg !3217
  %file = getelementptr inbounds i8, ptr %call1, i64 8, !dbg !3218
  store ptr %call2, ptr %file, align 8, !dbg !3219, !tbaa !3220
  %call3 = call ptr @strtok_r(ptr noundef null, ptr noundef nonnull @.str.33, ptr noundef nonnull %b) #23, !dbg !3222
  tail call void @llvm.dbg.value(metadata ptr %call3, metadata !3200, metadata !DIExpression()), !dbg !3208
  %cmp4 = icmp eq ptr %call3, null, !dbg !3223
  br i1 %cmp4, label %if.then5, label %if.end7, !dbg !3225

if.then5:                                         ; preds = %if.end
  %0 = load ptr, ptr @stderr, align 8, !dbg !3226, !tbaa !1311
  %1 = call i64 @fwrite(ptr nonnull @.str.34, i64 72, i64 1, ptr %0) #28, !dbg !3228
  br label %if.then80, !dbg !3229

if.end7:                                          ; preds = %if.end
  %call8 = tail call ptr @__ctype_tolower_loc() #30, !dbg !3230
  %2 = load ptr, ptr %call8, align 8, !dbg !3230, !tbaa !1311
  %call9 = call i64 @strlen(ptr noundef nonnull dereferenceable(1) %call3) #31, !dbg !3230
  %3 = getelementptr i8, ptr %call3, i64 %call9, !dbg !3230
  %arrayidx = getelementptr i8, ptr %3, i64 -1, !dbg !3230
  %4 = load i8, ptr %arrayidx, align 1, !dbg !3230, !tbaa !1203
  %idxprom = sext i8 %4 to i64, !dbg !3230
  %arrayidx10 = getelementptr inbounds i32, ptr %2, i64 %idxprom, !dbg !3230
  %5 = load i32, ptr %arrayidx10, align 4, !dbg !3230, !tbaa !1244
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !3204, metadata !DIExpression()), !dbg !3232
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !3201, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3208
  store i8 0, ptr %arrayidx, align 1, !dbg !3233, !tbaa !1203
  %sext = shl i32 %5, 24, !dbg !3234
  %conv15 = ashr exact i32 %sext, 24, !dbg !3234
  switch i32 %conv15, label %sw.default [
    i32 109, label %sw.epilog
    i32 103, label %sw.bb16
    i32 116, label %sw.bb17
    i32 112, label %sw.bb18
  ], !dbg !3235

sw.bb16:                                          ; preds = %if.end7
  tail call void @llvm.dbg.value(metadata i64 1073741824, metadata !3202, metadata !DIExpression()), !dbg !3208
  br label %sw.epilog, !dbg !3236

sw.bb17:                                          ; preds = %if.end7
  tail call void @llvm.dbg.value(metadata i64 1048576, metadata !3202, metadata !DIExpression()), !dbg !3208
  tail call void @llvm.dbg.value(metadata i64 1099511627776, metadata !3202, metadata !DIExpression()), !dbg !3208
  br label %sw.epilog, !dbg !3238

sw.bb18:                                          ; preds = %if.end7
  tail call void @llvm.dbg.value(metadata i64 1048576, metadata !3202, metadata !DIExpression()), !dbg !3208
  tail call void @llvm.dbg.value(metadata i64 1125899906842624, metadata !3202, metadata !DIExpression()), !dbg !3208
  br label %sw.epilog, !dbg !3239

sw.default:                                       ; preds = %if.end7
  %6 = load ptr, ptr @stderr, align 8, !dbg !3240, !tbaa !1311
  %7 = call i64 @fwrite(ptr nonnull @.str.34, i64 72, i64 1, ptr %6) #28, !dbg !3241
  br label %if.then80, !dbg !3242

sw.epilog:                                        ; preds = %if.end7, %sw.bb18, %sw.bb17, %sw.bb16
  %multiplier.0 = phi i64 [ 1125899906842624, %sw.bb18 ], [ 1099511627776, %sw.bb17 ], [ 1073741824, %sw.bb16 ], [ 1048576, %if.end7 ], !dbg !3243
  tail call void @llvm.dbg.value(metadata i64 %multiplier.0, metadata !3202, metadata !DIExpression()), !dbg !3208
  tail call void @llvm.dbg.value(metadata ptr %call3, metadata !3244, metadata !DIExpression()), !dbg !3249
  %call.i = call i64 @__isoc23_strtol(ptr noundef nonnull %call3, ptr noundef null, i32 noundef 10) #23, !dbg !3251
  tail call void @llvm.dbg.value(metadata i64 %call.i, metadata !3203, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3208
  %sext127 = shl i64 %call.i, 32, !dbg !3252
  %conv22 = ashr exact i64 %sext127, 32, !dbg !3252
  %mul23 = mul i64 %conv22, %multiplier.0, !dbg !3253
  tail call void @llvm.dbg.value(metadata i64 %mul23, metadata !3202, metadata !DIExpression()), !dbg !3208
  %conv24 = zext i32 %page_size to i64, !dbg !3254
  %div = udiv i64 %mul23, %conv24, !dbg !3255
  %conv25 = trunc i64 %div to i32, !dbg !3256
  store i32 %conv25, ptr %call1, align 8, !dbg !3257, !tbaa !3258
  %cmp27 = icmp eq i32 %conv25, 0, !dbg !3259
  br i1 %cmp27, label %if.then29, label %if.end31, !dbg !3261

if.then29:                                        ; preds = %sw.epilog
  %8 = load ptr, ptr @stderr, align 8, !dbg !3262, !tbaa !1311
  %9 = call i64 @fwrite(ptr nonnull @.str.35, i64 44, i64 1, ptr %8) #28, !dbg !3264
  br label %if.then80, !dbg !3265

if.end31:                                         ; preds = %sw.epilog
  %call32 = call ptr @strtok_r(ptr noundef null, ptr noundef nonnull @.str.33, ptr noundef nonnull %b) #23, !dbg !3266
  tail call void @llvm.dbg.value(metadata ptr %call32, metadata !3200, metadata !DIExpression()), !dbg !3208
  %cmp33.not = icmp eq ptr %call32, null, !dbg !3267
  br i1 %cmp33.not, label %cleanup, label %if.then35, !dbg !3269

if.then35:                                        ; preds = %if.end31
  %call36 = call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %call32, ptr noundef nonnull dereferenceable(8) @.str.36) #31, !dbg !3270
  %cmp37 = icmp eq i32 %call36, 0, !dbg !3273
  br i1 %cmp37, label %if.then39, label %if.else, !dbg !3274

if.then39:                                        ; preds = %if.then35
  %free_bucket = getelementptr inbounds i8, ptr %call1, i64 36, !dbg !3275
  store i32 1, ptr %free_bucket, align 4, !dbg !3277, !tbaa !3278
  br label %cleanup, !dbg !3279

if.else:                                          ; preds = %if.then35
  %call40 = call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %call32, ptr noundef nonnull dereferenceable(7) @.str.37) #31, !dbg !3280
  %cmp41 = icmp eq i32 %call40, 0, !dbg !3282
  br i1 %cmp41, label %if.then43, label %if.else45, !dbg !3283

if.then43:                                        ; preds = %if.else
  %free_bucket44 = getelementptr inbounds i8, ptr %call1, i64 36, !dbg !3284
  store i32 3, ptr %free_bucket44, align 4, !dbg !3286, !tbaa !3278
  br label %cleanup, !dbg !3287

if.else45:                                        ; preds = %if.else
  %call46 = call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %call32, ptr noundef nonnull dereferenceable(8) @.str.38) #31, !dbg !3288
  %cmp47 = icmp eq i32 %call46, 0, !dbg !3290
  br i1 %cmp47, label %if.then49, label %if.else51, !dbg !3291

if.then49:                                        ; preds = %if.else45
  %free_bucket50 = getelementptr inbounds i8, ptr %call1, i64 36, !dbg !3292
  store i32 2, ptr %free_bucket50, align 4, !dbg !3294, !tbaa !3278
  br label %cleanup, !dbg !3295

if.else51:                                        ; preds = %if.else45
  %call52 = call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %call32, ptr noundef nonnull dereferenceable(8) @.str.39) #31, !dbg !3296
  %cmp53 = icmp eq i32 %call52, 0, !dbg !3298
  br i1 %cmp53, label %cleanup, label %if.else57, !dbg !3299

if.else57:                                        ; preds = %if.else51
  %call58 = call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %call32, ptr noundef nonnull dereferenceable(12) @.str.40) #31, !dbg !3300
  %cmp59 = icmp eq i32 %call58, 0, !dbg !3302
  br i1 %cmp59, label %if.then61, label %if.else63, !dbg !3303

if.then61:                                        ; preds = %if.else57
  %free_bucket62 = getelementptr inbounds i8, ptr %call1, i64 36, !dbg !3304
  store i32 4, ptr %free_bucket62, align 4, !dbg !3306, !tbaa !3278
  br label %cleanup, !dbg !3307

if.else63:                                        ; preds = %if.else57
  %call64 = call i32 @strcmp(ptr noundef nonnull dereferenceable(1) %call32, ptr noundef nonnull dereferenceable(4) @.str.41) #31, !dbg !3308
  %cmp65 = icmp eq i32 %call64, 0, !dbg !3310
  br i1 %cmp65, label %if.then67, label %if.else69, !dbg !3311

if.then67:                                        ; preds = %if.else63
  %free_bucket68 = getelementptr inbounds i8, ptr %call1, i64 36, !dbg !3312
  store i32 5, ptr %free_bucket68, align 4, !dbg !3314, !tbaa !3278
  br label %cleanup

if.else69:                                        ; preds = %if.else63
  %10 = load ptr, ptr @stderr, align 8, !dbg !3315, !tbaa !1311
  %call70 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %10, ptr noundef nonnull @.str.42, ptr noundef nonnull %call32) #27, !dbg !3317
  br label %if.then80, !dbg !3318

if.then80:                                        ; preds = %if.then5, %sw.default, %if.then29, %if.else69
  tail call void @llvm.dbg.value(metadata ptr %call1, metadata !3198, metadata !DIExpression()), !dbg !3208
  tail call void @llvm.dbg.label(metadata !3206), !dbg !3319
  %tobool82.not = icmp eq ptr %call2, null, !dbg !3320
  br i1 %tobool82.not, label %if.end85, label %if.then83, !dbg !3324

if.then83:                                        ; preds = %if.then80
  call void @free(ptr noundef nonnull %call2) #23, !dbg !3325
  br label %if.end85, !dbg !3325

if.end85:                                         ; preds = %if.then83, %if.then80
  call void @free(ptr noundef nonnull %call1) #23, !dbg !3326
  br label %cleanup, !dbg !3327

cleanup:                                          ; preds = %if.end31, %if.else51, %entry, %if.end85, %if.then43, %if.then67, %if.then61, %if.then49, %if.then39
  %retval.0 = phi ptr [ %call1, %if.then39 ], [ %call1, %if.then49 ], [ %call1, %if.then61 ], [ %call1, %if.then67 ], [ %call1, %if.then43 ], [ null, %if.end85 ], [ null, %entry ], [ %call1, %if.else51 ], [ %call1, %if.end31 ], !dbg !3208
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %b) #23, !dbg !3328
  ret ptr %retval.0, !dbg !3328
}

; Function Attrs: mustprogress nofree nounwind willreturn
declare !dbg !3329 ptr @strtok_r(ptr noundef, ptr nocapture noundef readonly, ptr noundef) local_unnamed_addr #10

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !3333 noalias ptr @strdup(ptr nocapture noundef readonly) local_unnamed_addr #11

; Function Attrs: mustprogress nofree nosync nounwind willreturn memory(none)
declare !dbg !3336 ptr @__ctype_tolower_loc() local_unnamed_addr #12

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare !dbg !3344 i64 @strlen(ptr nocapture noundef) local_unnamed_addr #13

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare !dbg !3347 i32 @strcmp(ptr nocapture noundef, ptr nocapture noundef) local_unnamed_addr #13

; Function Attrs: mustprogress nofree nounwind sanitize_thread willreturn memory(readwrite, argmem: write) uwtable
define dso_local noalias noundef ptr @storage_init_config(ptr nocapture noundef writeonly %s) local_unnamed_addr #14 !dbg !3350 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %s, metadata !3435, metadata !DIExpression()), !dbg !3437
  %call = tail call noalias dereferenceable_or_null(40) ptr @calloc(i64 noundef 1, i64 noundef 40) #24, !dbg !3438
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !3436, metadata !DIExpression()), !dbg !3437
  %ext_item_size = getelementptr inbounds i8, ptr %s, i64 256, !dbg !3439
  store <4 x i32> <i32 512, i32 -1, i32 0, i32 2000>, ptr %ext_item_size, align 8, !dbg !3440, !tbaa !1244
  %ext_max_frag = getelementptr inbounds i8, ptr %s, i64 288, !dbg !3441
  %ext_drop_unread = getelementptr inbounds i8, ptr %s, i64 304, !dbg !3442
  store i8 0, ptr %ext_drop_unread, align 8, !dbg !3443, !tbaa !2882
  %ext_wbuf_size = getelementptr inbounds i8, ptr %s, i64 272, !dbg !3444
  store <4 x i32> <i32 4194304, i32 0, i32 0, i32 1000000>, ptr %ext_wbuf_size, align 8, !dbg !3445, !tbaa !1244
  store <2 x double> <double 8.000000e-01, double 1.000000e-02>, ptr %ext_max_frag, align 8, !dbg !3446, !tbaa !3447
  %ext_page_size = getelementptr inbounds i8, ptr %s, i64 252, !dbg !3448
  store i32 67108864, ptr %ext_page_size, align 4, !dbg !3449, !tbaa !3450
  %ext_io_threadcount = getelementptr inbounds i8, ptr %s, i64 248, !dbg !3451
  store i32 1, ptr %ext_io_threadcount, align 8, !dbg !3452, !tbaa !3453
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 57), align 4, !dbg !3454, !tbaa !3450
  %ext_cf = getelementptr inbounds i8, ptr %call, i64 8, !dbg !3455
  store i32 %0, ptr %ext_cf, align 8, !dbg !3456, !tbaa !3457
  %1 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 62), align 8, !dbg !3460, !tbaa !2675
  %wbuf_size = getelementptr inbounds i8, ptr %call, i64 24, !dbg !3461
  store i32 %1, ptr %wbuf_size, align 8, !dbg !3462, !tbaa !3463
  %2 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 56), align 8, !dbg !3464, !tbaa !3453
  %io_threadcount = getelementptr inbounds i8, ptr %call, i64 32, !dbg !3465
  store i32 %2, ptr %io_threadcount, align 8, !dbg !3466, !tbaa !3467
  %io_depth = getelementptr inbounds i8, ptr %call, i64 36, !dbg !3468
  store i32 1, ptr %io_depth, align 4, !dbg !3469, !tbaa !3470
  %page_buckets = getelementptr inbounds i8, ptr %call, i64 16, !dbg !3471
  store i32 6, ptr %page_buckets, align 8, !dbg !3472, !tbaa !3473
  %wbuf_count = getelementptr inbounds i8, ptr %call, i64 28, !dbg !3474
  store i32 6, ptr %wbuf_count, align 4, !dbg !3475, !tbaa !3476
  ret ptr %call, !dbg !3477
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 0, 2) i32 @storage_read_config(ptr noundef %conf, ptr noundef %subopt) local_unnamed_addr #0 !dbg !187 {
entry:
  %subopts_value = alloca ptr, align 8, !DIAssignID !3478
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !230, metadata !DIExpression(), metadata !3478, metadata ptr %subopts_value, metadata !DIExpression()), !dbg !3479
  %subopts_tokens = alloca [16 x ptr], align 16, !DIAssignID !3480
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !231, metadata !DIExpression(), metadata !3480, metadata ptr %subopts_tokens, metadata !DIExpression()), !dbg !3479
  tail call void @llvm.dbg.value(metadata ptr %conf, metadata !195, metadata !DIExpression()), !dbg !3479
  tail call void @llvm.dbg.value(metadata ptr %subopt, metadata !196, metadata !DIExpression()), !dbg !3479
  tail call void @llvm.dbg.value(metadata ptr %conf, metadata !197, metadata !DIExpression()), !dbg !3479
  %ext_cf1 = getelementptr inbounds i8, ptr %conf, i64 8, !dbg !3481
  tail call void @llvm.dbg.value(metadata ptr %ext_cf1, metadata !228, metadata !DIExpression()), !dbg !3479
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %subopts_value) #23, !dbg !3482
  call void @llvm.lifetime.start.p0(i64 128, ptr nonnull %subopts_tokens) #23, !dbg !3483
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(128) %subopts_tokens, ptr noundef nonnull align 16 dereferenceable(128) @__const.storage_read_config.subopts_tokens, i64 128, i1 false), !dbg !3484, !DIAssignID !3485
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !231, metadata !DIExpression(), metadata !3485, metadata ptr %subopts_tokens, metadata !DIExpression()), !dbg !3479
  %call = call i32 @getsubopt(ptr noundef %subopt, ptr noundef nonnull %subopts_tokens, ptr noundef nonnull %subopts_value) #23, !dbg !3486
  switch i32 %call, label %sw.default [
    i32 0, label %sw.bb
    i32 1, label %sw.bb11
    i32 2, label %sw.bb23
    i32 3, label %sw.bb32
    i32 5, label %sw.bb41
    i32 6, label %sw.bb50
    i32 7, label %sw.bb59
    i32 8, label %sw.bb68
    i32 9, label %sw.bb77
    i32 10, label %sw.bb86
    i32 11, label %sw.bb95
    i32 12, label %sw.bb104
    i32 14, label %sw.bb113
    i32 13, label %sw.bb122
    i32 4, label %sw.bb123
  ], !dbg !3487

sw.bb:                                            ; preds = %entry
  %0 = load ptr, ptr %conf, align 8, !dbg !3488, !tbaa !3490
  %tobool.not = icmp eq ptr %0, null, !dbg !3491
  br i1 %tobool.not, label %if.end, label %if.then, !dbg !3492

if.then:                                          ; preds = %sw.bb
  %1 = load ptr, ptr @stderr, align 8, !dbg !3493, !tbaa !1311
  %2 = call i64 @fwrite(ptr nonnull @.str.58, i64 57, i64 1, ptr %1) #28, !dbg !3495
  br label %cleanup141, !dbg !3496

if.end:                                           ; preds = %sw.bb
  %3 = load ptr, ptr %subopts_value, align 8, !dbg !3497, !tbaa !1311
  %cmp = icmp eq ptr %3, null, !dbg !3499
  br i1 %cmp, label %if.then3, label %if.end5, !dbg !3500

if.then3:                                         ; preds = %if.end
  %4 = load ptr, ptr @stderr, align 8, !dbg !3501, !tbaa !1311
  %5 = call i64 @fwrite(ptr nonnull @.str.59, i64 31, i64 1, ptr %4) #28, !dbg !3503
  br label %cleanup141, !dbg !3504

if.end5:                                          ; preds = %if.end
  %call6 = call zeroext i1 @safe_strtoul(ptr noundef nonnull %3, ptr noundef nonnull %ext_cf1) #23, !dbg !3505
  br i1 %call6, label %if.end9, label %if.then7, !dbg !3507

if.then7:                                         ; preds = %if.end5
  %6 = load ptr, ptr @stderr, align 8, !dbg !3508, !tbaa !1311
  %7 = call i64 @fwrite(ptr nonnull @.str.60, i64 42, i64 1, ptr %6) #28, !dbg !3510
  br label %cleanup141, !dbg !3511

if.end9:                                          ; preds = %if.end5
  %8 = load i32, ptr %ext_cf1, align 4, !dbg !3512, !tbaa !3513
  %mul = shl i32 %8, 20, !dbg !3512
  store i32 %mul, ptr %ext_cf1, align 4, !dbg !3512, !tbaa !3513
  br label %cleanup141, !dbg !3514

sw.bb11:                                          ; preds = %entry
  %9 = load ptr, ptr %subopts_value, align 8, !dbg !3515, !tbaa !1311
  %cmp12 = icmp eq ptr %9, null, !dbg !3517
  br i1 %cmp12, label %if.then13, label %if.end15, !dbg !3518

if.then13:                                        ; preds = %sw.bb11
  %10 = load ptr, ptr @stderr, align 8, !dbg !3519, !tbaa !1311
  %11 = call i64 @fwrite(ptr nonnull @.str.61, i64 31, i64 1, ptr %10) #28, !dbg !3521
  br label %cleanup141, !dbg !3522

if.end15:                                         ; preds = %sw.bb11
  %wbuf_size = getelementptr inbounds i8, ptr %conf, i64 24, !dbg !3523
  %call16 = call zeroext i1 @safe_strtoul(ptr noundef nonnull %9, ptr noundef nonnull %wbuf_size) #23, !dbg !3525
  br i1 %call16, label %if.end19, label %if.then17, !dbg !3526

if.then17:                                        ; preds = %if.end15
  %12 = load ptr, ptr @stderr, align 8, !dbg !3527, !tbaa !1311
  %13 = call i64 @fwrite(ptr nonnull @.str.62, i64 42, i64 1, ptr %12) #28, !dbg !3529
  br label %cleanup141, !dbg !3530

if.end19:                                         ; preds = %if.end15
  %14 = load i32, ptr %wbuf_size, align 4, !dbg !3531, !tbaa !3532
  %mul21 = shl i32 %14, 20, !dbg !3531
  store i32 %mul21, ptr %wbuf_size, align 4, !dbg !3531, !tbaa !3532
  store i32 %mul21, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 62), align 8, !dbg !3533, !tbaa !2675
  br label %cleanup141, !dbg !3534

sw.bb23:                                          ; preds = %entry
  %15 = load ptr, ptr %subopts_value, align 8, !dbg !3535, !tbaa !1311
  %cmp24 = icmp eq ptr %15, null, !dbg !3537
  br i1 %cmp24, label %if.then25, label %if.end27, !dbg !3538

if.then25:                                        ; preds = %sw.bb23
  %16 = load ptr, ptr @stderr, align 8, !dbg !3539, !tbaa !1311
  %17 = call i64 @fwrite(ptr nonnull @.str.63, i64 29, i64 1, ptr %16) #28, !dbg !3541
  br label %cleanup141, !dbg !3542

if.end27:                                         ; preds = %sw.bb23
  %io_threadcount = getelementptr inbounds i8, ptr %conf, i64 32, !dbg !3543
  %call28 = call zeroext i1 @safe_strtoul(ptr noundef nonnull %15, ptr noundef nonnull %io_threadcount) #23, !dbg !3545
  br i1 %call28, label %cleanup141, label %if.then29, !dbg !3546

if.then29:                                        ; preds = %if.end27
  %18 = load ptr, ptr @stderr, align 8, !dbg !3547, !tbaa !1311
  %19 = call i64 @fwrite(ptr nonnull @.str.64, i64 40, i64 1, ptr %18) #28, !dbg !3549
  br label %cleanup141, !dbg !3550

sw.bb32:                                          ; preds = %entry
  %20 = load ptr, ptr %subopts_value, align 8, !dbg !3551, !tbaa !1311
  %cmp33 = icmp eq ptr %20, null, !dbg !3553
  br i1 %cmp33, label %if.then34, label %if.end36, !dbg !3554

if.then34:                                        ; preds = %sw.bb32
  %21 = load ptr, ptr @stderr, align 8, !dbg !3555, !tbaa !1311
  %22 = call i64 @fwrite(ptr nonnull @.str.65, i64 30, i64 1, ptr %21) #28, !dbg !3557
  br label %cleanup141, !dbg !3558

if.end36:                                         ; preds = %sw.bb32
  %io_depth = getelementptr inbounds i8, ptr %conf, i64 36, !dbg !3559
  %call37 = call zeroext i1 @safe_strtoul(ptr noundef nonnull %20, ptr noundef nonnull %io_depth) #23, !dbg !3561
  br i1 %call37, label %cleanup141, label %if.then38, !dbg !3562

if.then38:                                        ; preds = %if.end36
  %23 = load ptr, ptr @stderr, align 8, !dbg !3563, !tbaa !1311
  %24 = call i64 @fwrite(ptr nonnull @.str.66, i64 41, i64 1, ptr %23) #28, !dbg !3565
  br label %cleanup141, !dbg !3566

sw.bb41:                                          ; preds = %entry
  %25 = load ptr, ptr %subopts_value, align 8, !dbg !3567, !tbaa !1311
  %cmp42 = icmp eq ptr %25, null, !dbg !3569
  br i1 %cmp42, label %if.then43, label %if.end45, !dbg !3570

if.then43:                                        ; preds = %sw.bb41
  %26 = load ptr, ptr @stderr, align 8, !dbg !3571, !tbaa !1311
  %27 = call i64 @fwrite(ptr nonnull @.str.67, i64 31, i64 1, ptr %26) #28, !dbg !3573
  br label %cleanup141, !dbg !3574

if.end45:                                         ; preds = %sw.bb41
  %call46 = call zeroext i1 @safe_strtoul(ptr noundef nonnull %25, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 58)) #23, !dbg !3575
  br i1 %call46, label %cleanup141, label %if.then47, !dbg !3577

if.then47:                                        ; preds = %if.end45
  %28 = load ptr, ptr @stderr, align 8, !dbg !3578, !tbaa !1311
  %29 = call i64 @fwrite(ptr nonnull @.str.68, i64 42, i64 1, ptr %28) #28, !dbg !3580
  br label %cleanup141, !dbg !3581

sw.bb50:                                          ; preds = %entry
  %30 = load ptr, ptr %subopts_value, align 8, !dbg !3582, !tbaa !1311
  %cmp51 = icmp eq ptr %30, null, !dbg !3584
  br i1 %cmp51, label %if.then52, label %if.end54, !dbg !3585

if.then52:                                        ; preds = %sw.bb50
  %31 = load ptr, ptr @stderr, align 8, !dbg !3586, !tbaa !1311
  %32 = call i64 @fwrite(ptr nonnull @.str.69, i64 30, i64 1, ptr %31) #28, !dbg !3588
  br label %cleanup141, !dbg !3589

if.end54:                                         ; preds = %sw.bb50
  %call55 = call zeroext i1 @safe_strtoul(ptr noundef nonnull %30, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 59)) #23, !dbg !3590
  br i1 %call55, label %cleanup141, label %if.then56, !dbg !3592

if.then56:                                        ; preds = %if.end54
  %33 = load ptr, ptr @stderr, align 8, !dbg !3593, !tbaa !1311
  %34 = call i64 @fwrite(ptr nonnull @.str.70, i64 41, i64 1, ptr %33) #28, !dbg !3595
  br label %cleanup141, !dbg !3596

sw.bb59:                                          ; preds = %entry
  %35 = load ptr, ptr %subopts_value, align 8, !dbg !3597, !tbaa !1311
  %cmp60 = icmp eq ptr %35, null, !dbg !3599
  br i1 %cmp60, label %if.then61, label %if.end63, !dbg !3600

if.then61:                                        ; preds = %sw.bb59
  %36 = load ptr, ptr @stderr, align 8, !dbg !3601, !tbaa !1311
  %37 = call i64 @fwrite(ptr nonnull @.str.71, i64 29, i64 1, ptr %36) #28, !dbg !3603
  br label %cleanup141, !dbg !3604

if.end63:                                         ; preds = %sw.bb59
  %call64 = call zeroext i1 @safe_strtoul(ptr noundef nonnull %35, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 60)) #23, !dbg !3605
  br i1 %call64, label %cleanup141, label %if.then65, !dbg !3607

if.then65:                                        ; preds = %if.end63
  %38 = load ptr, ptr @stderr, align 8, !dbg !3608, !tbaa !1311
  %39 = call i64 @fwrite(ptr nonnull @.str.72, i64 40, i64 1, ptr %38) #28, !dbg !3610
  br label %cleanup141, !dbg !3611

sw.bb68:                                          ; preds = %entry
  %40 = load ptr, ptr %subopts_value, align 8, !dbg !3612, !tbaa !1311
  %cmp69 = icmp eq ptr %40, null, !dbg !3614
  br i1 %cmp69, label %if.then70, label %if.end72, !dbg !3615

if.then70:                                        ; preds = %sw.bb68
  %41 = load ptr, ptr @stderr, align 8, !dbg !3616, !tbaa !1311
  %42 = call i64 @fwrite(ptr nonnull @.str.73, i64 34, i64 1, ptr %41) #28, !dbg !3618
  br label %cleanup141, !dbg !3619

if.end72:                                         ; preds = %sw.bb68
  %call73 = call zeroext i1 @safe_strtoul(ptr noundef nonnull %40, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 61)) #23, !dbg !3620
  br i1 %call73, label %cleanup141, label %if.then74, !dbg !3622

if.then74:                                        ; preds = %if.end72
  %43 = load ptr, ptr @stderr, align 8, !dbg !3623, !tbaa !1311
  %44 = call i64 @fwrite(ptr nonnull @.str.74, i64 45, i64 1, ptr %43) #28, !dbg !3625
  br label %cleanup141, !dbg !3626

sw.bb77:                                          ; preds = %entry
  %45 = load ptr, ptr %subopts_value, align 8, !dbg !3627, !tbaa !1311
  %cmp78 = icmp eq ptr %45, null, !dbg !3629
  br i1 %cmp78, label %if.then79, label %if.end81, !dbg !3630

if.then79:                                        ; preds = %sw.bb77
  %46 = load ptr, ptr @stderr, align 8, !dbg !3631, !tbaa !1311
  %47 = call i64 @fwrite(ptr nonnull @.str.75, i64 35, i64 1, ptr %46) #28, !dbg !3633
  br label %cleanup141, !dbg !3634

if.end81:                                         ; preds = %sw.bb77
  %call82 = call zeroext i1 @safe_strtoul(ptr noundef nonnull %45, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 63)) #23, !dbg !3635
  br i1 %call82, label %cleanup141, label %if.then83, !dbg !3637

if.then83:                                        ; preds = %if.end81
  %48 = load ptr, ptr @stderr, align 8, !dbg !3638, !tbaa !1311
  %49 = call i64 @fwrite(ptr nonnull @.str.76, i64 46, i64 1, ptr %48) #28, !dbg !3640
  br label %cleanup141, !dbg !3641

sw.bb86:                                          ; preds = %entry
  %50 = load ptr, ptr %subopts_value, align 8, !dbg !3642, !tbaa !1311
  %cmp87 = icmp eq ptr %50, null, !dbg !3644
  br i1 %cmp87, label %if.then88, label %if.end90, !dbg !3645

if.then88:                                        ; preds = %sw.bb86
  %51 = load ptr, ptr @stderr, align 8, !dbg !3646, !tbaa !1311
  %52 = call i64 @fwrite(ptr nonnull @.str.77, i64 32, i64 1, ptr %51) #28, !dbg !3648
  br label %cleanup141, !dbg !3649

if.end90:                                         ; preds = %sw.bb86
  %call91 = call zeroext i1 @safe_strtoul(ptr noundef nonnull %50, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 64)) #23, !dbg !3650
  br i1 %call91, label %cleanup141, label %if.then92, !dbg !3652

if.then92:                                        ; preds = %if.end90
  %53 = load ptr, ptr @stderr, align 8, !dbg !3653, !tbaa !1311
  %54 = call i64 @fwrite(ptr nonnull @.str.78, i64 43, i64 1, ptr %53) #28, !dbg !3655
  br label %cleanup141, !dbg !3656

sw.bb95:                                          ; preds = %entry
  %55 = load ptr, ptr %subopts_value, align 8, !dbg !3657, !tbaa !1311
  %cmp96 = icmp eq ptr %55, null, !dbg !3659
  br i1 %cmp96, label %if.then97, label %if.end99, !dbg !3660

if.then97:                                        ; preds = %sw.bb95
  %56 = load ptr, ptr @stderr, align 8, !dbg !3661, !tbaa !1311
  %57 = call i64 @fwrite(ptr nonnull @.str.79, i64 31, i64 1, ptr %56) #28, !dbg !3663
  br label %cleanup141, !dbg !3664

if.end99:                                         ; preds = %sw.bb95
  %call100 = call zeroext i1 @safe_strtoul(ptr noundef nonnull %55, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 65)) #23, !dbg !3665
  br i1 %call100, label %cleanup141, label %if.then101, !dbg !3667

if.then101:                                       ; preds = %if.end99
  %58 = load ptr, ptr @stderr, align 8, !dbg !3668, !tbaa !1311
  %59 = call i64 @fwrite(ptr nonnull @.str.80, i64 42, i64 1, ptr %58) #28, !dbg !3670
  br label %cleanup141, !dbg !3671

sw.bb104:                                         ; preds = %entry
  %60 = load ptr, ptr %subopts_value, align 8, !dbg !3672, !tbaa !1311
  %cmp105 = icmp eq ptr %60, null, !dbg !3674
  br i1 %cmp105, label %if.then106, label %if.end108, !dbg !3675

if.then106:                                       ; preds = %sw.bb104
  %61 = load ptr, ptr @stderr, align 8, !dbg !3676, !tbaa !1311
  %62 = call i64 @fwrite(ptr nonnull @.str.81, i64 30, i64 1, ptr %61) #28, !dbg !3678
  br label %cleanup141, !dbg !3679

if.end108:                                        ; preds = %sw.bb104
  %call109 = call zeroext i1 @safe_strtod(ptr noundef nonnull %60, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 66)) #23, !dbg !3680
  br i1 %call109, label %cleanup141, label %if.then110, !dbg !3682

if.then110:                                       ; preds = %if.end108
  %63 = load ptr, ptr @stderr, align 8, !dbg !3683, !tbaa !1311
  %64 = call i64 @fwrite(ptr nonnull @.str.82, i64 41, i64 1, ptr %63) #28, !dbg !3685
  br label %cleanup141, !dbg !3686

sw.bb113:                                         ; preds = %entry
  %65 = load ptr, ptr %subopts_value, align 8, !dbg !3687, !tbaa !1311
  %cmp114 = icmp eq ptr %65, null, !dbg !3689
  br i1 %cmp114, label %if.then115, label %if.end117, !dbg !3690

if.then115:                                       ; preds = %sw.bb113
  %66 = load ptr, ptr @stderr, align 8, !dbg !3691, !tbaa !1311
  %67 = call i64 @fwrite(ptr nonnull @.str.83, i64 41, i64 1, ptr %66) #28, !dbg !3693
  br label %cleanup141, !dbg !3694

if.end117:                                        ; preds = %sw.bb113
  %call118 = call zeroext i1 @safe_strtod(ptr noundef nonnull %65, ptr noundef nonnull getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 67)) #23, !dbg !3695
  br i1 %call118, label %cleanup141, label %if.then119, !dbg !3697

if.then119:                                       ; preds = %if.end117
  %68 = load ptr, ptr @stderr, align 8, !dbg !3698, !tbaa !1311
  %69 = call i64 @fwrite(ptr nonnull @.str.84, i64 52, i64 1, ptr %68) #28, !dbg !3700
  br label %cleanup141, !dbg !3701

sw.bb122:                                         ; preds = %entry
  store i8 1, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 68), align 8, !dbg !3702, !tbaa !2882
  br label %cleanup141, !dbg !3703

sw.bb123:                                         ; preds = %entry
  %70 = load ptr, ptr %subopts_value, align 8, !dbg !3704, !tbaa !1311
  %tobool124.not = icmp eq ptr %70, null, !dbg !3704
  br i1 %tobool124.not, label %if.else, label %if.then125, !dbg !3705

if.then125:                                       ; preds = %sw.bb123
  %71 = load i32, ptr %ext_cf1, align 4, !dbg !3706, !tbaa !3513
  %call127 = call ptr @storage_conf_parse(ptr noundef nonnull %70, i32 noundef %71), !dbg !3707
  tail call void @llvm.dbg.value(metadata ptr %call127, metadata !236, metadata !DIExpression()), !dbg !3708
  %cmp128.not = icmp eq ptr %call127, null, !dbg !3709
  br i1 %cmp128.not, label %cleanup.thread, label %if.end131, !dbg !3711

cleanup.thread:                                   ; preds = %if.then125
  %72 = load ptr, ptr @stderr, align 8, !dbg !3712, !tbaa !1311
  %73 = call i64 @fwrite(ptr nonnull @.str.85, i64 34, i64 1, ptr %72) #28, !dbg !3714
  br label %cleanup141

if.end131:                                        ; preds = %if.then125
  %74 = load ptr, ptr %conf, align 8, !dbg !3715, !tbaa !3490
  %cmp133.not = icmp eq ptr %74, null, !dbg !3717
  br i1 %cmp133.not, label %cleanup, label %if.then134, !dbg !3718

if.then134:                                       ; preds = %if.end131
  %next = getelementptr inbounds i8, ptr %call127, i64 40, !dbg !3719
  store ptr %74, ptr %next, align 8, !dbg !3721, !tbaa !3722
  br label %cleanup, !dbg !3723

cleanup:                                          ; preds = %if.end131, %if.then134
  store ptr %call127, ptr %conf, align 8, !dbg !3724, !tbaa !3490
  br label %cleanup141

if.else:                                          ; preds = %sw.bb123
  %75 = load ptr, ptr @stderr, align 8, !dbg !3725, !tbaa !1311
  %76 = call i64 @fwrite(ptr nonnull @.str.86, i64 54, i64 1, ptr %75) #28, !dbg !3727
  br label %cleanup141, !dbg !3728

sw.default:                                       ; preds = %entry
  %77 = load ptr, ptr @stderr, align 8, !dbg !3729, !tbaa !1311
  %78 = load ptr, ptr %subopts_value, align 8, !dbg !3730, !tbaa !1311
  %call140 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %77, ptr noundef nonnull @.str.87, ptr noundef %78) #27, !dbg !3731
  br label %cleanup141, !dbg !3732

cleanup141:                                       ; preds = %if.end9, %if.end19, %sw.bb122, %if.end27, %if.end36, %if.end45, %if.end54, %if.end63, %if.end72, %if.end81, %if.end90, %if.end99, %if.end108, %if.end117, %cleanup, %cleanup.thread, %sw.default, %if.else, %if.then119, %if.then115, %if.then110, %if.then106, %if.then101, %if.then97, %if.then92, %if.then88, %if.then83, %if.then79, %if.then74, %if.then70, %if.then65, %if.then61, %if.then56, %if.then52, %if.then47, %if.then43, %if.then38, %if.then34, %if.then29, %if.then25, %if.then17, %if.then13, %if.then7, %if.then3, %if.then
  %retval.1 = phi i32 [ 1, %sw.default ], [ 1, %if.else ], [ 1, %if.then115 ], [ 1, %if.then119 ], [ 1, %if.then106 ], [ 1, %if.then110 ], [ 1, %if.then97 ], [ 1, %if.then101 ], [ 1, %if.then88 ], [ 1, %if.then92 ], [ 1, %if.then79 ], [ 1, %if.then83 ], [ 1, %if.then70 ], [ 1, %if.then74 ], [ 1, %if.then61 ], [ 1, %if.then65 ], [ 1, %if.then52 ], [ 1, %if.then56 ], [ 1, %if.then43 ], [ 1, %if.then47 ], [ 1, %if.then34 ], [ 1, %if.then38 ], [ 1, %if.then25 ], [ 1, %if.then29 ], [ 1, %if.then13 ], [ 1, %if.then17 ], [ 1, %if.then ], [ 1, %if.then3 ], [ 1, %if.then7 ], [ 1, %cleanup.thread ], [ 0, %cleanup ], [ 0, %if.end117 ], [ 0, %if.end108 ], [ 0, %if.end99 ], [ 0, %if.end90 ], [ 0, %if.end81 ], [ 0, %if.end72 ], [ 0, %if.end63 ], [ 0, %if.end54 ], [ 0, %if.end45 ], [ 0, %if.end36 ], [ 0, %if.end27 ], [ 0, %sw.bb122 ], [ 0, %if.end19 ], [ 0, %if.end9 ], !dbg !3479
  call void @llvm.lifetime.end.p0(i64 128, ptr nonnull %subopts_tokens) #23, !dbg !3733
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %subopts_value) #23, !dbg !3733
  ret i32 %retval.1, !dbg !3733
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #15

; Function Attrs: nounwind
declare !dbg !3734 i32 @getsubopt(ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #8

declare !dbg !3739 zeroext i1 @safe_strtoul(ptr noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !3743 zeroext i1 @safe_strtod(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nofree nounwind sanitize_thread uwtable
define dso_local range(i32 0, 3) i32 @storage_check_config(ptr nocapture noundef readonly %conf) local_unnamed_addr #16 !dbg !3747 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %conf, metadata !3749, metadata !DIExpression()), !dbg !3752
  tail call void @llvm.dbg.value(metadata ptr %conf, metadata !3750, metadata !DIExpression()), !dbg !3752
  tail call void @llvm.dbg.value(metadata ptr %conf, metadata !3751, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !3752
  %0 = load ptr, ptr %conf, align 8, !dbg !3753, !tbaa !3490
  %tobool.not = icmp eq ptr %0, null, !dbg !3755
  br i1 %tobool.not, label %cleanup, label %if.then, !dbg !3756

if.then:                                          ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr %conf, metadata !3751, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !3752
  %1 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 21), align 4, !dbg !3757, !tbaa !3760
  %wbuf_size = getelementptr inbounds i8, ptr %conf, i64 24, !dbg !3761
  %2 = load i32, ptr %wbuf_size, align 4, !dbg !3761, !tbaa !3532
  %cmp = icmp ugt i32 %1, %2, !dbg !3762
  br i1 %cmp, label %if.then2, label %if.end, !dbg !3763

if.then2:                                         ; preds = %if.then
  %3 = load ptr, ptr @stderr, align 8, !dbg !3764, !tbaa !1311
  %call = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %3, ptr noundef nonnull @.str.88, i32 noundef %1, i32 noundef %2) #27, !dbg !3766
  br label %cleanup, !dbg !3767

if.end:                                           ; preds = %if.then
  %4 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 3), align 8, !dbg !3768, !tbaa !3770
  %tobool4.not = icmp eq i32 %4, 0, !dbg !3771
  br i1 %tobool4.not, label %cleanup, label %if.then5, !dbg !3772

if.then5:                                         ; preds = %if.end
  %5 = load ptr, ptr @stderr, align 8, !dbg !3773, !tbaa !1311
  %6 = tail call i64 @fwrite(ptr nonnull @.str.89, i64 55, i64 1, ptr %5) #28, !dbg !3775
  br label %cleanup, !dbg !3776

cleanup:                                          ; preds = %entry, %if.end, %if.then5, %if.then2
  %retval.0 = phi i32 [ 1, %if.then2 ], [ 1, %if.then5 ], [ 0, %if.end ], [ 2, %entry ], !dbg !3752
  ret i32 %retval.0, !dbg !3777
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local ptr @storage_init(ptr noundef %conf) local_unnamed_addr #0 !dbg !3778 {
entry:
  %eres = alloca i32, align 4, !DIAssignID !3785
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3783, metadata !DIExpression(), metadata !3785, metadata ptr %eres, metadata !DIExpression()), !dbg !3786
  tail call void @llvm.dbg.value(metadata ptr %conf, metadata !3780, metadata !DIExpression()), !dbg !3786
  tail call void @llvm.dbg.value(metadata ptr %conf, metadata !3781, metadata !DIExpression()), !dbg !3786
  %ext_cf1 = getelementptr inbounds i8, ptr %conf, i64 8, !dbg !3787
  tail call void @llvm.dbg.value(metadata ptr %ext_cf1, metadata !3782, metadata !DIExpression()), !dbg !3786
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %eres) #23, !dbg !3788
  tail call void @llvm.dbg.value(metadata ptr null, metadata !3784, metadata !DIExpression()), !dbg !3786
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 63), align 4, !dbg !3789, !tbaa !2859
  %cmp = icmp eq i32 %0, 0, !dbg !3791
  br i1 %cmp, label %if.then, label %if.end15, !dbg !3792

if.then:                                          ; preds = %entry
  %1 = load ptr, ptr %conf, align 8, !dbg !3793, !tbaa !3490
  %2 = load i32, ptr %1, align 8, !dbg !3795, !tbaa !3258
  %conv = uitofp i32 %2 to double, !dbg !3796
  %mul = fmul double %conv, 1.000000e-02, !dbg !3797
  %conv2 = fptoui double %mul to i32, !dbg !3796
  store i32 %conv2, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 63), align 4, !dbg !3798, !tbaa !2859
  store i32 %conv2, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 64), align 8, !dbg !3799, !tbaa !2873
  %cmp8 = icmp eq i32 %conv2, 0, !dbg !3800
  br i1 %cmp8, label %if.then13, label %if.end15, !dbg !3802

if.then13:                                        ; preds = %if.then
  store i32 1, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 63), align 4, !dbg !3803, !tbaa !2859
  store i32 1, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 64), align 8, !dbg !3805, !tbaa !2873
  br label %if.end15, !dbg !3808

if.end15:                                         ; preds = %if.then, %if.then13, %entry
  tail call void @crc32c_init() #23, !dbg !3809
  store i32 0, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 69), align 4, !dbg !3810, !tbaa !2248
  %3 = load ptr, ptr %conf, align 8, !dbg !3811, !tbaa !3490
  %call = call ptr @extstore_init(ptr noundef %3, ptr noundef nonnull %ext_cf1, ptr noundef nonnull %eres) #23, !dbg !3812
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !3784, metadata !DIExpression()), !dbg !3786
  %cmp17 = icmp eq ptr %call, null, !dbg !3813
  br i1 %cmp17, label %if.then19, label %cleanup, !dbg !3815

if.then19:                                        ; preds = %if.end15
  %4 = load ptr, ptr @stderr, align 8, !dbg !3816, !tbaa !1311
  %5 = load i32, ptr %eres, align 4, !dbg !3818, !tbaa !1244
  %call20 = call ptr @extstore_err(i32 noundef %5) #23, !dbg !3819
  %call21 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %4, ptr noundef nonnull @.str.90, ptr noundef %call20) #27, !dbg !3820
  %6 = load i32, ptr %eres, align 4, !dbg !3821, !tbaa !1244
  %cmp22 = icmp eq i32 %6, 7, !dbg !3823
  br i1 %cmp22, label %if.then24, label %cleanup, !dbg !3824

if.then24:                                        ; preds = %if.then19
  call void @perror(ptr noundef nonnull @.str.91) #28, !dbg !3825
  br label %cleanup, !dbg !3827

cleanup:                                          ; preds = %if.end15, %if.then19, %if.then24
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %eres) #23, !dbg !3828
  ret ptr %call, !dbg !3828
}

declare !dbg !3829 void @crc32c_init() local_unnamed_addr #2

declare !dbg !3831 ptr @extstore_init(ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !3835 ptr @extstore_err(i32 noundef) local_unnamed_addr #2

; Function Attrs: cold nofree nounwind
declare !dbg !3838 void @perror(ptr nocapture noundef readonly) local_unnamed_addr #17

declare !dbg !3841 void @return_io_pending(ptr noundef) local_unnamed_addr #2

declare !dbg !3842 void @conn_worker_readd(ptr noundef) local_unnamed_addr #2

declare !dbg !3845 void @slabs_free(ptr noundef, i64 noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !3848 void @item_unlink(ptr noundef) local_unnamed_addr #2

declare !dbg !3849 ptr @item_trylock(i32 noundef) local_unnamed_addr #2

declare !dbg !3852 i32 @item_replace(ptr noundef, ptr noundef, i32 noundef, i64 noundef) local_unnamed_addr #2

declare !dbg !3856 void @item_trylock_unlock(ptr noundef) local_unnamed_addr #2

declare !dbg !3857 ptr @logger_create() local_unnamed_addr #2

; Function Attrs: noreturn nounwind
declare !dbg !3860 void @abort() local_unnamed_addr #18

declare !dbg !3861 i32 @global_page_pool_size(ptr noundef) local_unnamed_addr #2

declare !dbg !3865 i32 @slabs_available_chunks(i32 noundef, ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind
declare !dbg !3869 i32 @pthread_cond_signal(ptr noundef) local_unnamed_addr #8

declare !dbg !3872 i32 @usleep(i32 noundef) local_unnamed_addr #2

declare !dbg !3876 i32 @lru_pull_tail(i32 noundef, i32 noundef, i64 noundef, i8 noundef zeroext, i32 noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !3882 ptr @do_item_alloc(ptr noundef, i64 noundef, i32 noundef, i32 noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !3886 i32 @extstore_write_request(ptr noundef, i32 noundef, i32 noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !3889 void @extstore_write(ptr noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !3892 void @do_item_remove(ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind
declare !dbg !3893 ptr @pthread_getspecific(i32 noundef) local_unnamed_addr #8

declare !dbg !3897 i32 @logger_log(ptr noundef, i32 noundef, ptr noundef, ...) local_unnamed_addr #2

declare !dbg !3901 void @item_unlock(i32 noundef) local_unnamed_addr #2

; Function Attrs: nounwind sanitize_thread uwtable
define internal void @_storage_compact_cb(ptr nocapture readnone %e, ptr nocapture noundef readonly %io, i32 noundef %ret) #0 !dbg !3904 {
entry:
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !3906, metadata !DIExpression()), !dbg !3910
  tail call void @llvm.dbg.value(metadata ptr %io, metadata !3907, metadata !DIExpression()), !dbg !3910
  tail call void @llvm.dbg.value(metadata i32 %ret, metadata !3908, metadata !DIExpression()), !dbg !3910
  %0 = load ptr, ptr %io, align 8, !dbg !3911, !tbaa !1647
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !3909, metadata !DIExpression()), !dbg !3910
  %cmp = icmp slt i32 %ret, 1, !dbg !3912
  br i1 %cmp, label %if.then, label %if.end, !dbg !3914

if.then:                                          ; preds = %entry
  %miss = getelementptr inbounds i8, ptr %0, i64 106, !dbg !3915
  store i8 1, ptr %miss, align 2, !dbg !3917, !tbaa !2925
  br label %if.end, !dbg !3918

if.end:                                           ; preds = %if.then, %entry
  %done = getelementptr inbounds i8, ptr %0, i64 104, !dbg !3919
  store i8 1, ptr %done, align 8, !dbg !3920, !tbaa !2689
  %lock = getelementptr inbounds i8, ptr %0, i64 64, !dbg !3921
  %call = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %lock) #23, !dbg !3922
  ret void, !dbg !3923
}

declare !dbg !3924 i32 @pthread_cond_wait(ptr noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !3928 i32 @extstore_submit_bg(ptr noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !3929 void @extstore_close_page(ptr noundef, i32 noundef, i64 noundef) local_unnamed_addr #2

declare !dbg !3932 void @extstore_evict_page(ptr noundef, i32 noundef, i64 noundef) local_unnamed_addr #2

declare !dbg !3933 void @item_lock(i32 noundef) local_unnamed_addr #2

declare !dbg !3934 ptr @assoc_find(ptr noundef, i64 noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !3938 i32 @item_is_flushed(ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind
declare !dbg !3941 i64 @__isoc23_strtol(ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #8

; Function Attrs: nofree nounwind willreturn memory(argmem: read)
declare i32 @bcmp(ptr nocapture, ptr nocapture, i64) local_unnamed_addr #19

; Function Attrs: nofree nounwind
declare noundef i64 @fwrite(ptr nocapture noundef, i64 noundef, i64 noundef, ptr nocapture noundef) local_unnamed_addr #20

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #21

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #21

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.usub.sat.i32(i32, i32) #21

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #21

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #22 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #21

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #21

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #21

attributes #0 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #7 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { noreturn nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { mustprogress nofree nounwind willreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { mustprogress nofree nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { mustprogress nofree nosync nounwind willreturn memory(none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { mustprogress nofree nounwind willreturn memory(argmem: read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { mustprogress nofree nounwind sanitize_thread willreturn memory(readwrite, argmem: write) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #16 = { nofree nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #17 = { cold nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #18 = { noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #19 = { nofree nounwind willreturn memory(argmem: read) }
attributes #20 = { nofree nounwind }
attributes #21 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #22 = { nounwind uwtable }
attributes #23 = { nounwind }
attributes #24 = { nounwind allocsize(0,1) }
attributes #25 = { nounwind allocsize(0) }
attributes #26 = { nobuiltin }
attributes #27 = { cold nounwind }
attributes #28 = { cold }
attributes #29 = { noreturn nounwind }
attributes #30 = { nounwind willreturn memory(none) }
attributes #31 = { nobuiltin nounwind willreturn memory(read) }

!llvm.dbg.cu = !{!110}
!llvm.module.flags = !{!1186, !1187, !1188, !1189, !1190, !1191, !1192}
!llvm.ident = !{!1193}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(scope: null, file: !2, line: 95, type: !3, isLocal: true, isDefinition: true)
!2 = !DIFile(filename: "storage.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d515065a1727c5c5e8136fd3a10ed9b2")
!3 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 48, elements: !5)
!4 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!5 = !{!6}
!6 = !DISubrange(count: 6)
!7 = !DIGlobalVariableExpression(var: !8, expr: !DIExpression())
!8 = distinct !DIGlobalVariable(scope: null, file: !2, line: 95, type: !9, isLocal: true, isDefinition: true)
!9 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 64, elements: !10)
!10 = !{!11}
!11 = !DISubrange(count: 8)
!12 = !DIGlobalVariableExpression(var: !13, expr: !DIExpression())
!13 = distinct !DIGlobalVariable(scope: null, file: !2, line: 95, type: !14, isLocal: true, isDefinition: true)
!14 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 40, elements: !15)
!15 = !{!16}
!16 = !DISubrange(count: 5)
!17 = !DIGlobalVariableExpression(var: !18, expr: !DIExpression())
!18 = distinct !DIGlobalVariable(scope: null, file: !2, line: 97, type: !3, isLocal: true, isDefinition: true)
!19 = !DIGlobalVariableExpression(var: !20, expr: !DIExpression())
!20 = distinct !DIGlobalVariable(scope: null, file: !2, line: 99, type: !21, isLocal: true, isDefinition: true)
!21 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 56, elements: !22)
!22 = !{!23}
!23 = !DISubrange(count: 7)
!24 = !DIGlobalVariableExpression(var: !25, expr: !DIExpression())
!25 = distinct !DIGlobalVariable(scope: null, file: !2, line: 99, type: !26, isLocal: true, isDefinition: true)
!26 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 24, elements: !27)
!27 = !{!28}
!28 = !DISubrange(count: 3)
!29 = !DIGlobalVariableExpression(var: !30, expr: !DIExpression())
!30 = distinct !DIGlobalVariable(scope: null, file: !2, line: 101, type: !31, isLocal: true, isDefinition: true)
!31 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 96, elements: !32)
!32 = !{!33}
!33 = !DISubrange(count: 12)
!34 = !DIGlobalVariableExpression(var: !35, expr: !DIExpression())
!35 = distinct !DIGlobalVariable(scope: null, file: !2, line: 113, type: !36, isLocal: true, isDefinition: true)
!36 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 176, elements: !37)
!37 = !{!38}
!38 = !DISubrange(count: 22)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(scope: null, file: !2, line: 114, type: !41, isLocal: true, isDefinition: true)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 200, elements: !42)
!42 = !{!43}
!43 = !DISubrange(count: 25)
!44 = !DIGlobalVariableExpression(var: !45, expr: !DIExpression())
!45 = distinct !DIGlobalVariable(scope: null, file: !2, line: 115, type: !46, isLocal: true, isDefinition: true)
!46 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 216, elements: !47)
!47 = !{!48}
!48 = !DISubrange(count: 27)
!49 = !DIGlobalVariableExpression(var: !50, expr: !DIExpression())
!50 = distinct !DIGlobalVariable(scope: null, file: !2, line: 116, type: !51, isLocal: true, isDefinition: true)
!51 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 208, elements: !52)
!52 = !{!53}
!53 = !DISubrange(count: 26)
!54 = !DIGlobalVariableExpression(var: !55, expr: !DIExpression())
!55 = distinct !DIGlobalVariable(scope: null, file: !2, line: 117, type: !41, isLocal: true, isDefinition: true)
!56 = !DIGlobalVariableExpression(var: !57, expr: !DIExpression())
!57 = distinct !DIGlobalVariable(scope: null, file: !2, line: 120, type: !58, isLocal: true, isDefinition: true)
!58 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 168, elements: !59)
!59 = !{!60}
!60 = !DISubrange(count: 21)
!61 = !DIGlobalVariableExpression(var: !62, expr: !DIExpression())
!62 = distinct !DIGlobalVariable(scope: null, file: !2, line: 121, type: !63, isLocal: true, isDefinition: true)
!63 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 192, elements: !64)
!64 = !{!65}
!65 = !DISubrange(count: 24)
!66 = !DIGlobalVariableExpression(var: !67, expr: !DIExpression())
!67 = distinct !DIGlobalVariable(scope: null, file: !2, line: 122, type: !68, isLocal: true, isDefinition: true)
!68 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 184, elements: !69)
!69 = !{!70}
!70 = !DISubrange(count: 23)
!71 = !DIGlobalVariableExpression(var: !72, expr: !DIExpression())
!72 = distinct !DIGlobalVariable(scope: null, file: !2, line: 123, type: !73, isLocal: true, isDefinition: true)
!73 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 160, elements: !74)
!74 = !{!75}
!75 = !DISubrange(count: 20)
!76 = !DIGlobalVariableExpression(var: !77, expr: !DIExpression())
!77 = distinct !DIGlobalVariable(scope: null, file: !2, line: 124, type: !73, isLocal: true, isDefinition: true)
!78 = !DIGlobalVariableExpression(var: !79, expr: !DIExpression())
!79 = distinct !DIGlobalVariable(scope: null, file: !2, line: 125, type: !41, isLocal: true, isDefinition: true)
!80 = !DIGlobalVariableExpression(var: !81, expr: !DIExpression())
!81 = distinct !DIGlobalVariable(scope: null, file: !2, line: 126, type: !36, isLocal: true, isDefinition: true)
!82 = !DIGlobalVariableExpression(var: !83, expr: !DIExpression())
!83 = distinct !DIGlobalVariable(scope: null, file: !2, line: 127, type: !41, isLocal: true, isDefinition: true)
!84 = !DIGlobalVariableExpression(var: !85, expr: !DIExpression())
!85 = distinct !DIGlobalVariable(scope: null, file: !2, line: 128, type: !36, isLocal: true, isDefinition: true)
!86 = !DIGlobalVariableExpression(var: !87, expr: !DIExpression())
!87 = distinct !DIGlobalVariable(scope: null, file: !2, line: 129, type: !68, isLocal: true, isDefinition: true)
!88 = !DIGlobalVariableExpression(var: !89, expr: !DIExpression())
!89 = distinct !DIGlobalVariable(scope: null, file: !2, line: 130, type: !68, isLocal: true, isDefinition: true)
!90 = !DIGlobalVariableExpression(var: !91, expr: !DIExpression())
!91 = distinct !DIGlobalVariable(scope: null, file: !2, line: 131, type: !73, isLocal: true, isDefinition: true)
!92 = !DIGlobalVariableExpression(var: !93, expr: !DIExpression())
!93 = distinct !DIGlobalVariable(scope: null, file: !2, line: 132, type: !73, isLocal: true, isDefinition: true)
!94 = !DIGlobalVariableExpression(var: !95, expr: !DIExpression())
!95 = distinct !DIGlobalVariable(scope: null, file: !2, line: 133, type: !51, isLocal: true, isDefinition: true)
!96 = !DIGlobalVariableExpression(var: !97, expr: !DIExpression())
!97 = distinct !DIGlobalVariable(scope: null, file: !2, line: 134, type: !63, isLocal: true, isDefinition: true)
!98 = !DIGlobalVariableExpression(var: !99, expr: !DIExpression())
!99 = distinct !DIGlobalVariable(scope: null, file: !2, line: 135, type: !100, isLocal: true, isDefinition: true)
!100 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 144, elements: !101)
!101 = !{!102}
!102 = !DISubrange(count: 18)
!103 = !DIGlobalVariableExpression(var: !104, expr: !DIExpression())
!104 = distinct !DIGlobalVariable(scope: null, file: !2, line: 341, type: !105, isLocal: true, isDefinition: true)
!105 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 8, elements: !106)
!106 = !{!107}
!107 = !DISubrange(count: 1)
!108 = !DIGlobalVariableExpression(var: !109, expr: !DIExpression())
!109 = distinct !DIGlobalVariable(name: "storage_write_plock", scope: !110, file: !2, line: 588, type: !447, isLocal: true, isDefinition: true)
!110 = distinct !DICompileUnit(language: DW_LANG_C11, file: !2, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !111, retainedTypes: !285, globals: !926, splitDebugInlining: false, nameTableKind: None)
!111 = !{!112, !132, !146, !165, !170, !175, !181, !186, !256, !266, !280}
!112 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "conn_states", file: !113, line: 204, baseType: !114, size: 32, elements: !115)
!113 = !DIFile(filename: "./memcached.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "a52021954a5d6b153b5bc084e2fbff2b")
!114 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!115 = !{!116, !117, !118, !119, !120, !121, !122, !123, !124, !125, !126, !127, !128, !129, !130, !131}
!116 = !DIEnumerator(name: "conn_listening", value: 0)
!117 = !DIEnumerator(name: "conn_new_cmd", value: 1)
!118 = !DIEnumerator(name: "conn_waiting", value: 2)
!119 = !DIEnumerator(name: "conn_read", value: 3)
!120 = !DIEnumerator(name: "conn_parse_cmd", value: 4)
!121 = !DIEnumerator(name: "conn_write", value: 5)
!122 = !DIEnumerator(name: "conn_nread", value: 6)
!123 = !DIEnumerator(name: "conn_swallow", value: 7)
!124 = !DIEnumerator(name: "conn_closing", value: 8)
!125 = !DIEnumerator(name: "conn_mwrite", value: 9)
!126 = !DIEnumerator(name: "conn_closed", value: 10)
!127 = !DIEnumerator(name: "conn_watch", value: 11)
!128 = !DIEnumerator(name: "conn_io_queue", value: 12)
!129 = !DIEnumerator(name: "conn_io_resume", value: 13)
!130 = !DIEnumerator(name: "conn_io_pending", value: 14)
!131 = !DIEnumerator(name: "conn_max_state", value: 15)
!132 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "bin_substates", file: !113, line: 223, baseType: !114, size: 32, elements: !133)
!133 = !{!134, !135, !136, !137, !138, !139, !140, !141, !142, !143, !144, !145}
!134 = !DIEnumerator(name: "bin_no_state", value: 0)
!135 = !DIEnumerator(name: "bin_reading_set_header", value: 1)
!136 = !DIEnumerator(name: "bin_reading_cas_header", value: 2)
!137 = !DIEnumerator(name: "bin_read_set_value", value: 3)
!138 = !DIEnumerator(name: "bin_reading_get_key", value: 4)
!139 = !DIEnumerator(name: "bin_reading_stat", value: 5)
!140 = !DIEnumerator(name: "bin_reading_del_header", value: 6)
!141 = !DIEnumerator(name: "bin_reading_incr_header", value: 7)
!142 = !DIEnumerator(name: "bin_read_flush_exptime", value: 8)
!143 = !DIEnumerator(name: "bin_reading_sasl_auth", value: 9)
!144 = !DIEnumerator(name: "bin_reading_sasl_auth_data", value: 10)
!145 = !DIEnumerator(name: "bin_reading_touch_key", value: 11)
!146 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "log_entry_type", file: !147, line: 16, baseType: !114, size: 32, elements: !148)
!147 = !DIFile(filename: "./logger.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "e743c4228b1e0bc1c91bec9cfd28d5ab")
!148 = !{!149, !150, !151, !152, !153, !154, !155, !156, !157, !158, !159, !160, !161, !162, !163, !164}
!149 = !DIEnumerator(name: "LOGGER_ASCII_CMD", value: 0)
!150 = !DIEnumerator(name: "LOGGER_EVICTION", value: 1)
!151 = !DIEnumerator(name: "LOGGER_ITEM_GET", value: 2)
!152 = !DIEnumerator(name: "LOGGER_ITEM_STORE", value: 3)
!153 = !DIEnumerator(name: "LOGGER_CRAWLER_STATUS", value: 4)
!154 = !DIEnumerator(name: "LOGGER_SLAB_MOVE", value: 5)
!155 = !DIEnumerator(name: "LOGGER_CONNECTION_NEW", value: 6)
!156 = !DIEnumerator(name: "LOGGER_CONNECTION_CLOSE", value: 7)
!157 = !DIEnumerator(name: "LOGGER_DELETIONS", value: 8)
!158 = !DIEnumerator(name: "LOGGER_EXTSTORE_WRITE", value: 9)
!159 = !DIEnumerator(name: "LOGGER_COMPACT_START", value: 10)
!160 = !DIEnumerator(name: "LOGGER_COMPACT_ABORT", value: 11)
!161 = !DIEnumerator(name: "LOGGER_COMPACT_READ_START", value: 12)
!162 = !DIEnumerator(name: "LOGGER_COMPACT_READ_END", value: 13)
!163 = !DIEnumerator(name: "LOGGER_COMPACT_END", value: 14)
!164 = !DIEnumerator(name: "LOGGER_COMPACT_FRAGINFO", value: 15)
!165 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "protocol", file: !113, line: 238, baseType: !114, size: 32, elements: !166)
!166 = !{!167, !168, !169}
!167 = !DIEnumerator(name: "ascii_prot", value: 3)
!168 = !DIEnumerator(name: "binary_prot", value: 4)
!169 = !DIEnumerator(name: "negotiating_prot", value: 5)
!170 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "network_transport", file: !113, line: 247, baseType: !114, size: 32, elements: !171)
!171 = !{!172, !173, !174}
!172 = !DIEnumerator(name: "local_transport", value: 0)
!173 = !DIEnumerator(name: "tcp_transport", value: 1)
!174 = !DIEnumerator(name: "udp_transport", value: 2)
!175 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "close_reasons", file: !113, line: 266, baseType: !114, size: 32, elements: !176)
!176 = !{!177, !178, !179, !180}
!177 = !DIEnumerator(name: "ERROR_CLOSE", value: 0)
!178 = !DIEnumerator(name: "NORMAL_CLOSE", value: 1)
!179 = !DIEnumerator(name: "IDLE_TIMEOUT_CLOSE", value: 2)
!180 = !DIEnumerator(name: "SHUTDOWN_CLOSE", value: 3)
!181 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "obj_io_mode", file: !182, line: 66, baseType: !114, size: 32, elements: !183)
!182 = !DIFile(filename: "./extstore.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "848685d924a1d79d44595af1ab890a1f")
!183 = !{!184, !185}
!184 = !DIEnumerator(name: "OBJ_IO_READ", value: 0)
!185 = !DIEnumerator(name: "OBJ_IO_WRITE", value: 1)
!186 = !DICompositeType(tag: DW_TAG_enumeration_type, scope: !187, file: !2, line: 1313, baseType: !114, size: 32, elements: !240)
!187 = distinct !DISubprogram(name: "storage_read_config", scope: !2, file: !2, line: 1308, type: !188, scopeLine: 1308, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !194)
!188 = !DISubroutineType(types: !189)
!189 = !{!190, !191, !192}
!190 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!191 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!192 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !193, size: 64)
!193 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !4, size: 64)
!194 = !{!195, !196, !197, !228, !230, !231, !236}
!195 = !DILocalVariable(name: "conf", arg: 1, scope: !187, file: !2, line: 1308, type: !191)
!196 = !DILocalVariable(name: "subopt", arg: 2, scope: !187, file: !2, line: 1308, type: !192)
!197 = !DILocalVariable(name: "cf", scope: !187, file: !2, line: 1309, type: !198)
!198 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !199, size: 64)
!199 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "storage_settings", file: !2, line: 1276, size: 320, elements: !200)
!200 = !{!201, !217}
!201 = !DIDerivedType(tag: DW_TAG_member, name: "storage_file", scope: !199, file: !2, line: 1277, baseType: !202, size: 64)
!202 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !203, size: 64)
!203 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "extstore_conf_file", file: !182, line: 56, size: 384, elements: !204)
!204 = !{!205, !206, !207, !208, !214, !215, !216}
!205 = !DIDerivedType(tag: DW_TAG_member, name: "page_count", scope: !203, file: !182, line: 57, baseType: !114, size: 32)
!206 = !DIDerivedType(tag: DW_TAG_member, name: "file", scope: !203, file: !182, line: 58, baseType: !193, size: 64, offset: 64)
!207 = !DIDerivedType(tag: DW_TAG_member, name: "fd", scope: !203, file: !182, line: 59, baseType: !190, size: 32, offset: 128)
!208 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !203, file: !182, line: 60, baseType: !209, size: 64, offset: 192)
!209 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !210, line: 27, baseType: !211)
!210 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!211 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !212, line: 45, baseType: !213)
!212 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!213 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!214 = !DIDerivedType(tag: DW_TAG_member, name: "bucket", scope: !203, file: !182, line: 61, baseType: !114, size: 32, offset: 256)
!215 = !DIDerivedType(tag: DW_TAG_member, name: "free_bucket", scope: !203, file: !182, line: 62, baseType: !114, size: 32, offset: 288)
!216 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !203, file: !182, line: 63, baseType: !202, size: 64, offset: 320)
!217 = !DIDerivedType(tag: DW_TAG_member, name: "ext_cf", scope: !199, file: !2, line: 1278, baseType: !218, size: 256, offset: 64)
!218 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "extstore_conf", file: !182, line: 45, size: 256, elements: !219)
!219 = !{!220, !221, !222, !223, !224, !225, !226, !227}
!220 = !DIDerivedType(tag: DW_TAG_member, name: "page_size", scope: !218, file: !182, line: 46, baseType: !114, size: 32)
!221 = !DIDerivedType(tag: DW_TAG_member, name: "page_count", scope: !218, file: !182, line: 47, baseType: !114, size: 32, offset: 32)
!222 = !DIDerivedType(tag: DW_TAG_member, name: "page_buckets", scope: !218, file: !182, line: 48, baseType: !114, size: 32, offset: 64)
!223 = !DIDerivedType(tag: DW_TAG_member, name: "free_page_buckets", scope: !218, file: !182, line: 49, baseType: !114, size: 32, offset: 96)
!224 = !DIDerivedType(tag: DW_TAG_member, name: "wbuf_size", scope: !218, file: !182, line: 50, baseType: !114, size: 32, offset: 128)
!225 = !DIDerivedType(tag: DW_TAG_member, name: "wbuf_count", scope: !218, file: !182, line: 51, baseType: !114, size: 32, offset: 160)
!226 = !DIDerivedType(tag: DW_TAG_member, name: "io_threadcount", scope: !218, file: !182, line: 52, baseType: !114, size: 32, offset: 192)
!227 = !DIDerivedType(tag: DW_TAG_member, name: "io_depth", scope: !218, file: !182, line: 53, baseType: !114, size: 32, offset: 224)
!228 = !DILocalVariable(name: "ext_cf", scope: !187, file: !2, line: 1310, type: !229)
!229 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !218, size: 64)
!230 = !DILocalVariable(name: "subopts_value", scope: !187, file: !2, line: 1311, type: !193)
!231 = !DILocalVariable(name: "subopts_tokens", scope: !187, file: !2, line: 1331, type: !232)
!232 = !DICompositeType(tag: DW_TAG_array_type, baseType: !233, size: 1024, elements: !234)
!233 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !193)
!234 = !{!235}
!235 = !DISubrange(count: 16)
!236 = !DILocalVariable(name: "tmp", scope: !237, file: !2, line: 1493, type: !202)
!237 = distinct !DILexicalBlock(scope: !238, file: !2, line: 1492, column: 32)
!238 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1492, column: 17)
!239 = distinct !DILexicalBlock(scope: !187, file: !2, line: 1350, column: 64)
!240 = !{!241, !242, !243, !244, !245, !246, !247, !248, !249, !250, !251, !252, !253, !254, !255}
!241 = !DIEnumerator(name: "EXT_PAGE_SIZE", value: 0)
!242 = !DIEnumerator(name: "EXT_WBUF_SIZE", value: 1)
!243 = !DIEnumerator(name: "EXT_THREADS", value: 2)
!244 = !DIEnumerator(name: "EXT_IO_DEPTH", value: 3)
!245 = !DIEnumerator(name: "EXT_PATH", value: 4)
!246 = !DIEnumerator(name: "EXT_ITEM_SIZE", value: 5)
!247 = !DIEnumerator(name: "EXT_ITEM_AGE", value: 6)
!248 = !DIEnumerator(name: "EXT_LOW_TTL", value: 7)
!249 = !DIEnumerator(name: "EXT_RECACHE_RATE", value: 8)
!250 = !DIEnumerator(name: "EXT_COMPACT_UNDER", value: 9)
!251 = !DIEnumerator(name: "EXT_DROP_UNDER", value: 10)
!252 = !DIEnumerator(name: "EXT_MAX_SLEEP", value: 11)
!253 = !DIEnumerator(name: "EXT_MAX_FRAG", value: 12)
!254 = !DIEnumerator(name: "EXT_DROP_UNREAD", value: 13)
!255 = !DIEnumerator(name: "SLAB_AUTOMOVE_FREERATIO", value: 14)
!256 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "extstore_res", file: !182, line: 93, baseType: !114, size: 32, elements: !257)
!257 = !{!258, !259, !260, !261, !262, !263, !264, !265}
!258 = !DIEnumerator(name: "EXTSTORE_INIT_BAD_WBUF_SIZE", value: 1)
!259 = !DIEnumerator(name: "EXTSTORE_INIT_NEED_MORE_WBUF", value: 2)
!260 = !DIEnumerator(name: "EXTSTORE_INIT_NEED_MORE_BUCKETS", value: 3)
!261 = !DIEnumerator(name: "EXTSTORE_INIT_PAGE_WBUF_ALIGNMENT", value: 4)
!262 = !DIEnumerator(name: "EXTSTORE_INIT_TOO_MANY_PAGES", value: 5)
!263 = !DIEnumerator(name: "EXTSTORE_INIT_OOM", value: 6)
!264 = !DIEnumerator(name: "EXTSTORE_INIT_OPEN_FAIL", value: 7)
!265 = !DIEnumerator(name: "EXTSTORE_INIT_THREAD_FAIL", value: 8)
!266 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !267, line: 62, baseType: !114, size: 32, elements: !268)
!267 = !DIFile(filename: "./protocol_binary.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "7a322a65fa8661e9a597acbeeeb23107")
!268 = !{!269, !270, !271, !272, !273, !274, !275, !276, !277, !278, !279}
!269 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_SUCCESS", value: 0)
!270 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_KEY_ENOENT", value: 1)
!271 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_KEY_EEXISTS", value: 2)
!272 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_E2BIG", value: 3)
!273 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_EINVAL", value: 4)
!274 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_NOT_STORED", value: 5)
!275 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_DELTA_BADVAL", value: 6)
!276 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_AUTH_ERROR", value: 32)
!277 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_AUTH_CONTINUE", value: 33)
!278 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_UNKNOWN_COMMAND", value: 129)
!279 = !DIEnumerator(name: "PROTOCOL_BINARY_RESPONSE_ENOMEM", value: 130)
!280 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "logger_ret_type", file: !147, line: 45, baseType: !114, size: 32, elements: !281)
!281 = !{!282, !283, !284}
!282 = !DIEnumerator(name: "LOGGER_RET_OK", value: 0)
!283 = !DIEnumerator(name: "LOGGER_RET_NOSPACE", value: 1)
!284 = !DIEnumerator(name: "LOGGER_RET_ERR", value: 2)
!285 = !{!286, !193, !191, !294, !295, !299, !343, !190, !858, !614, !297, !901, !319, !320, !209, !668, !918, !192}
!286 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !287, size: 64)
!287 = !DIDerivedType(tag: DW_TAG_typedef, name: "item_hdr", file: !113, line: 677, baseType: !288)
!288 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !113, line: 673, size: 96, elements: !289)
!289 = !{!290, !291, !292}
!290 = !DIDerivedType(tag: DW_TAG_member, name: "page_version", scope: !288, file: !113, line: 674, baseType: !114, size: 32)
!291 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !288, file: !113, line: 675, baseType: !114, size: 32, offset: 32)
!292 = !DIDerivedType(tag: DW_TAG_member, name: "page_id", scope: !288, file: !113, line: 676, baseType: !293, size: 16, offset: 64)
!293 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!294 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!295 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !296, size: 64)
!296 = !DIDerivedType(tag: DW_TAG_typedef, name: "client_flags_t", file: !113, line: 99, baseType: !297)
!297 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !210, line: 26, baseType: !298)
!298 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !212, line: 42, baseType: !114)
!299 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !300, size: 64)
!300 = !DIDerivedType(tag: DW_TAG_typedef, name: "item_chunk", file: !113, line: 653, baseType: !301)
!301 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_strchunk", file: !113, line: 641, size: 384, elements: !302)
!302 = !{!303, !305, !306, !334, !335, !336, !337, !338, !339, !340, !341}
!303 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !301, file: !113, line: 642, baseType: !304, size: 64)
!304 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !301, size: 64)
!305 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !301, file: !113, line: 643, baseType: !304, size: 64, offset: 64)
!306 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !301, file: !113, line: 644, baseType: !307, size: 64, offset: 128)
!307 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !308, size: 64)
!308 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_stritem", file: !113, line: 593, size: 384, elements: !309)
!309 = !{!310, !311, !312, !313, !315, !316, !317, !318, !321, !325, !326}
!310 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !308, file: !113, line: 595, baseType: !307, size: 64)
!311 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !308, file: !113, line: 596, baseType: !307, size: 64, offset: 64)
!312 = !DIDerivedType(tag: DW_TAG_member, name: "h_next", scope: !308, file: !113, line: 598, baseType: !307, size: 64, offset: 128)
!313 = !DIDerivedType(tag: DW_TAG_member, name: "time", scope: !308, file: !113, line: 599, baseType: !314, size: 32, offset: 192)
!314 = !DIDerivedType(tag: DW_TAG_typedef, name: "rel_time_t", file: !147, line: 14, baseType: !114)
!315 = !DIDerivedType(tag: DW_TAG_member, name: "exptime", scope: !308, file: !113, line: 600, baseType: !314, size: 32, offset: 224)
!316 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !308, file: !113, line: 601, baseType: !190, size: 32, offset: 256)
!317 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !308, file: !113, line: 602, baseType: !293, size: 16, offset: 288)
!318 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !308, file: !113, line: 603, baseType: !319, size: 16, offset: 304)
!319 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint16_t", file: !210, line: 25, baseType: !320)
!320 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint16_t", file: !212, line: 40, baseType: !293)
!321 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !308, file: !113, line: 604, baseType: !322, size: 8, offset: 320)
!322 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !210, line: 24, baseType: !323)
!323 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !212, line: 38, baseType: !324)
!324 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!325 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !308, file: !113, line: 605, baseType: !322, size: 8, offset: 328)
!326 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !308, file: !113, line: 611, baseType: !327, offset: 384)
!327 = !DICompositeType(tag: DW_TAG_array_type, baseType: !328, elements: !332)
!328 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !308, file: !113, line: 608, size: 64, elements: !329)
!329 = !{!330, !331}
!330 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !328, file: !113, line: 609, baseType: !209, size: 64)
!331 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !328, file: !113, line: 610, baseType: !4, size: 8)
!332 = !{!333}
!333 = !DISubrange(count: -1)
!334 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !301, file: !113, line: 645, baseType: !190, size: 32, offset: 192)
!335 = !DIDerivedType(tag: DW_TAG_member, name: "used", scope: !301, file: !113, line: 646, baseType: !190, size: 32, offset: 224)
!336 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !301, file: !113, line: 647, baseType: !190, size: 32, offset: 256)
!337 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !301, file: !113, line: 648, baseType: !293, size: 16, offset: 288)
!338 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !301, file: !113, line: 649, baseType: !319, size: 16, offset: 304)
!339 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !301, file: !113, line: 650, baseType: !322, size: 8, offset: 320)
!340 = !DIDerivedType(tag: DW_TAG_member, name: "orig_clsid", scope: !301, file: !113, line: 651, baseType: !322, size: 8, offset: 328)
!341 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !301, file: !113, line: 652, baseType: !342, offset: 336)
!342 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, elements: !332)
!343 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !344, size: 64)
!344 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_pending_t", file: !113, line: 687, baseType: !345)
!345 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_io_pending_t", file: !113, line: 815, size: 1408, elements: !346)
!346 = !{!347, !348, !740, !843, !844, !849, !850, !854}
!347 = !DIDerivedType(tag: DW_TAG_member, name: "io_queue_type", scope: !345, file: !113, line: 816, baseType: !190, size: 32)
!348 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !345, file: !113, line: 817, baseType: !349, size: 64, offset: 64)
!349 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !350, size: 64)
!350 = !DIDerivedType(tag: DW_TAG_typedef, name: "LIBEVENT_THREAD", file: !113, line: 765, baseType: !351)
!351 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !113, line: 721, size: 55488, elements: !352)
!352 = !{!353, !356, !360, !445, !446, !474, !482, !483, !484, !539, !559, !562, !590, !665, !666, !667, !738, !739}
!353 = !DIDerivedType(tag: DW_TAG_member, name: "thread_id", scope: !351, file: !113, line: 722, baseType: !354, size: 64)
!354 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_t", file: !355, line: 27, baseType: !213)
!355 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h", directory: "", checksumkind: CSK_MD5, checksum: "8a5acdbeec491eca11cf81cb1ef77ea7")
!356 = !DIDerivedType(tag: DW_TAG_member, name: "base", scope: !351, file: !113, line: 723, baseType: !357, size: 64, offset: 64)
!357 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !358, size: 64)
!358 = !DICompositeType(tag: DW_TAG_structure_type, name: "event_base", file: !359, line: 122, flags: DIFlagFwdDecl)
!359 = !DIFile(filename: "/usr/include/event2/event_struct.h", directory: "", checksumkind: CSK_MD5, checksum: "005d89b34bed2ed9e30b0cc3160619c1")
!360 = !DIDerivedType(tag: DW_TAG_member, name: "n", scope: !351, file: !113, line: 724, baseType: !361, size: 1088, offset: 128)
!361 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_notify", file: !113, line: 710, size: 1088, elements: !362)
!362 = !{!363, !444}
!363 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event", scope: !361, file: !113, line: 711, baseType: !364, size: 1024)
!364 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event", file: !359, line: 123, size: 1024, elements: !365)
!365 = !{!366, !398, !408, !409, !410, !441, !442, !443}
!366 = !DIDerivedType(tag: DW_TAG_member, name: "ev_evcallback", scope: !364, file: !359, line: 124, baseType: !367, size: 320)
!367 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event_callback", file: !359, line: 107, size: 320, elements: !368)
!368 = !{!369, !376, !378, !379, !380, !397}
!369 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_active_next", scope: !367, file: !359, line: 108, baseType: !370, size: 128)
!370 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !367, file: !359, line: 108, size: 128, elements: !371)
!371 = !{!372, !374}
!372 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !370, file: !359, line: 108, baseType: !373, size: 64)
!373 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !367, size: 64)
!374 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !370, file: !359, line: 108, baseType: !375, size: 64, offset: 64)
!375 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !373, size: 64)
!376 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_flags", scope: !367, file: !359, line: 109, baseType: !377, size: 16, offset: 128)
!377 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!378 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_pri", scope: !367, file: !359, line: 110, baseType: !322, size: 8, offset: 144)
!379 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_closure", scope: !367, file: !359, line: 111, baseType: !322, size: 8, offset: 152)
!380 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cb_union", scope: !367, file: !359, line: 118, baseType: !381, size: 64, offset: 192)
!381 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !367, file: !359, line: 113, size: 64, elements: !382)
!382 = !{!383, !387, !391, !396}
!383 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_callback", scope: !381, file: !359, line: 114, baseType: !384, size: 64)
!384 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !385, size: 64)
!385 = !DISubroutineType(types: !386)
!386 = !{null, !190, !377, !191}
!387 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_selfcb", scope: !381, file: !359, line: 115, baseType: !388, size: 64)
!388 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !389, size: 64)
!389 = !DISubroutineType(types: !390)
!390 = !{null, !373, !191}
!391 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_evfinalize", scope: !381, file: !359, line: 116, baseType: !392, size: 64)
!392 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !393, size: 64)
!393 = !DISubroutineType(types: !394)
!394 = !{null, !395, !191}
!395 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !364, size: 64)
!396 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cbfinalize", scope: !381, file: !359, line: 117, baseType: !388, size: 64)
!397 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_arg", scope: !367, file: !359, line: 119, baseType: !191, size: 64, offset: 256)
!398 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout_pos", scope: !364, file: !359, line: 130, baseType: !399, size: 128, offset: 320)
!399 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !364, file: !359, line: 127, size: 128, elements: !400)
!400 = !{!401, !407}
!401 = !DIDerivedType(tag: DW_TAG_member, name: "ev_next_with_common_timeout", scope: !399, file: !359, line: 128, baseType: !402, size: 128)
!402 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !399, file: !359, line: 128, size: 128, elements: !403)
!403 = !{!404, !405}
!404 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !402, file: !359, line: 128, baseType: !395, size: 64)
!405 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !402, file: !359, line: 128, baseType: !406, size: 64, offset: 64)
!406 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !395, size: 64)
!407 = !DIDerivedType(tag: DW_TAG_member, name: "min_heap_idx", scope: !399, file: !359, line: 129, baseType: !190, size: 32)
!408 = !DIDerivedType(tag: DW_TAG_member, name: "ev_fd", scope: !364, file: !359, line: 131, baseType: !190, size: 32, offset: 448)
!409 = !DIDerivedType(tag: DW_TAG_member, name: "ev_base", scope: !364, file: !359, line: 133, baseType: !357, size: 64, offset: 512)
!410 = !DIDerivedType(tag: DW_TAG_member, name: "ev_", scope: !364, file: !359, line: 149, baseType: !411, size: 256, offset: 576)
!411 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !364, file: !359, line: 135, size: 256, elements: !412)
!412 = !{!413, !430}
!413 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io", scope: !411, file: !359, line: 140, baseType: !414, size: 256)
!414 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !411, file: !359, line: 137, size: 256, elements: !415)
!415 = !{!416, !421}
!416 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io_next", scope: !414, file: !359, line: 138, baseType: !417, size: 128)
!417 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !414, file: !359, line: 138, size: 128, elements: !418)
!418 = !{!419, !420}
!419 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !417, file: !359, line: 138, baseType: !395, size: 64)
!420 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !417, file: !359, line: 138, baseType: !406, size: 64, offset: 64)
!421 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !414, file: !359, line: 139, baseType: !422, size: 128, offset: 128)
!422 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "timeval", file: !423, line: 8, size: 128, elements: !424)
!423 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h", directory: "", checksumkind: CSK_MD5, checksum: "9b45d950050c215f216850b27bd1e8f3")
!424 = !{!425, !428}
!425 = !DIDerivedType(tag: DW_TAG_member, name: "tv_sec", scope: !422, file: !423, line: 14, baseType: !426, size: 64)
!426 = !DIDerivedType(tag: DW_TAG_typedef, name: "__time_t", file: !212, line: 160, baseType: !427)
!427 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!428 = !DIDerivedType(tag: DW_TAG_member, name: "tv_usec", scope: !422, file: !423, line: 15, baseType: !429, size: 64, offset: 64)
!429 = !DIDerivedType(tag: DW_TAG_typedef, name: "__suseconds_t", file: !212, line: 162, baseType: !427)
!430 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal", scope: !411, file: !359, line: 148, baseType: !431, size: 256)
!431 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !411, file: !359, line: 143, size: 256, elements: !432)
!432 = !{!433, !438, !439}
!433 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal_next", scope: !431, file: !359, line: 144, baseType: !434, size: 128)
!434 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !431, file: !359, line: 144, size: 128, elements: !435)
!435 = !{!436, !437}
!436 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !434, file: !359, line: 144, baseType: !395, size: 64)
!437 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !434, file: !359, line: 144, baseType: !406, size: 64, offset: 64)
!438 = !DIDerivedType(tag: DW_TAG_member, name: "ev_ncalls", scope: !431, file: !359, line: 145, baseType: !377, size: 16, offset: 128)
!439 = !DIDerivedType(tag: DW_TAG_member, name: "ev_pncalls", scope: !431, file: !359, line: 147, baseType: !440, size: 64, offset: 192)
!440 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !377, size: 64)
!441 = !DIDerivedType(tag: DW_TAG_member, name: "ev_events", scope: !364, file: !359, line: 151, baseType: !377, size: 16, offset: 832)
!442 = !DIDerivedType(tag: DW_TAG_member, name: "ev_res", scope: !364, file: !359, line: 152, baseType: !377, size: 16, offset: 848)
!443 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !364, file: !359, line: 153, baseType: !422, size: 128, offset: 896)
!444 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event_fd", scope: !361, file: !113, line: 713, baseType: !190, size: 32, offset: 1024)
!445 = !DIDerivedType(tag: DW_TAG_member, name: "ion", scope: !351, file: !113, line: 725, baseType: !361, size: 1088, offset: 1216)
!446 = !DIDerivedType(tag: DW_TAG_member, name: "ion_lock", scope: !351, file: !113, line: 726, baseType: !447, size: 320, offset: 2304)
!447 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutex_t", file: !355, line: 72, baseType: !448)
!448 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !355, line: 67, size: 320, elements: !449)
!449 = !{!450, !469, !473}
!450 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !448, file: !355, line: 69, baseType: !451, size: 320)
!451 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_mutex_s", file: !452, line: 22, size: 320, elements: !453)
!452 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h", directory: "", checksumkind: CSK_MD5, checksum: "6b075eca9ab0e2d761b2afc4ecfab776")
!453 = !{!454, !455, !456, !457, !458, !459, !460, !461}
!454 = !DIDerivedType(tag: DW_TAG_member, name: "__lock", scope: !451, file: !452, line: 24, baseType: !190, size: 32)
!455 = !DIDerivedType(tag: DW_TAG_member, name: "__count", scope: !451, file: !452, line: 25, baseType: !114, size: 32, offset: 32)
!456 = !DIDerivedType(tag: DW_TAG_member, name: "__owner", scope: !451, file: !452, line: 26, baseType: !190, size: 32, offset: 64)
!457 = !DIDerivedType(tag: DW_TAG_member, name: "__nusers", scope: !451, file: !452, line: 28, baseType: !114, size: 32, offset: 96)
!458 = !DIDerivedType(tag: DW_TAG_member, name: "__kind", scope: !451, file: !452, line: 32, baseType: !190, size: 32, offset: 128)
!459 = !DIDerivedType(tag: DW_TAG_member, name: "__spins", scope: !451, file: !452, line: 34, baseType: !377, size: 16, offset: 160)
!460 = !DIDerivedType(tag: DW_TAG_member, name: "__elision", scope: !451, file: !452, line: 35, baseType: !377, size: 16, offset: 176)
!461 = !DIDerivedType(tag: DW_TAG_member, name: "__list", scope: !451, file: !452, line: 36, baseType: !462, size: 128, offset: 192)
!462 = !DIDerivedType(tag: DW_TAG_typedef, name: "__pthread_list_t", file: !463, line: 55, baseType: !464)
!463 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h", directory: "", checksumkind: CSK_MD5, checksum: "b9a7199822bce372686baacd32a9f4f3")
!464 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_internal_list", file: !463, line: 51, size: 128, elements: !465)
!465 = !{!466, !468}
!466 = !DIDerivedType(tag: DW_TAG_member, name: "__prev", scope: !464, file: !463, line: 53, baseType: !467, size: 64)
!467 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !464, size: 64)
!468 = !DIDerivedType(tag: DW_TAG_member, name: "__next", scope: !464, file: !463, line: 54, baseType: !467, size: 64, offset: 64)
!469 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !448, file: !355, line: 70, baseType: !470, size: 320)
!470 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 320, elements: !471)
!471 = !{!472}
!472 = !DISubrange(count: 40)
!473 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !448, file: !355, line: 71, baseType: !427, size: 64)
!474 = !DIDerivedType(tag: DW_TAG_member, name: "ion_head", scope: !351, file: !113, line: 727, baseType: !475, size: 128, offset: 2624)
!475 = !DIDerivedType(tag: DW_TAG_typedef, name: "iop_head_t", file: !113, line: 686, baseType: !476)
!476 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iop_head_s", file: !113, line: 686, size: 128, elements: !477)
!477 = !{!478, !480}
!478 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !476, file: !113, line: 686, baseType: !479, size: 64)
!479 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !345, size: 64)
!480 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !476, file: !113, line: 686, baseType: !481, size: 64, offset: 64)
!481 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !479, size: 64)
!482 = !DIDerivedType(tag: DW_TAG_member, name: "cur_sfd", scope: !351, file: !113, line: 728, baseType: !190, size: 32, offset: 2752)
!483 = !DIDerivedType(tag: DW_TAG_member, name: "thread_baseid", scope: !351, file: !113, line: 729, baseType: !190, size: 32, offset: 2784)
!484 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !351, file: !113, line: 730, baseType: !485, size: 51584, offset: 2816)
!485 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_stats", file: !113, line: 372, size: 51584, elements: !486)
!486 = !{!487, !488, !489, !490, !491, !492, !493, !494, !495, !496, !497, !498, !499, !500, !501, !502, !503, !504, !505, !506, !507, !508, !509, !510, !511, !512, !513, !514, !515, !516, !517, !518, !532, !536, !537, !538}
!487 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !485, file: !113, line: 373, baseType: !447, size: 320)
!488 = !DIDerivedType(tag: DW_TAG_member, name: "get_cmds", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 320)
!489 = !DIDerivedType(tag: DW_TAG_member, name: "get_misses", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 384)
!490 = !DIDerivedType(tag: DW_TAG_member, name: "get_expired", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 448)
!491 = !DIDerivedType(tag: DW_TAG_member, name: "get_flushed", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 512)
!492 = !DIDerivedType(tag: DW_TAG_member, name: "touch_cmds", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 576)
!493 = !DIDerivedType(tag: DW_TAG_member, name: "touch_misses", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 640)
!494 = !DIDerivedType(tag: DW_TAG_member, name: "delete_misses", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 704)
!495 = !DIDerivedType(tag: DW_TAG_member, name: "incr_misses", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 768)
!496 = !DIDerivedType(tag: DW_TAG_member, name: "decr_misses", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 832)
!497 = !DIDerivedType(tag: DW_TAG_member, name: "cas_misses", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 896)
!498 = !DIDerivedType(tag: DW_TAG_member, name: "meta_cmds", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 960)
!499 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_read", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 1024)
!500 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_written", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 1088)
!501 = !DIDerivedType(tag: DW_TAG_member, name: "flush_cmds", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 1152)
!502 = !DIDerivedType(tag: DW_TAG_member, name: "conn_yields", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 1216)
!503 = !DIDerivedType(tag: DW_TAG_member, name: "auth_cmds", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 1280)
!504 = !DIDerivedType(tag: DW_TAG_member, name: "auth_errors", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 1344)
!505 = !DIDerivedType(tag: DW_TAG_member, name: "idle_kicks", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 1408)
!506 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_oom", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 1472)
!507 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_count", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 1536)
!508 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_bytes", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 1600)
!509 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_oom", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 1664)
!510 = !DIDerivedType(tag: DW_TAG_member, name: "store_too_large", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 1728)
!511 = !DIDerivedType(tag: DW_TAG_member, name: "store_no_memory", scope: !485, file: !113, line: 375, baseType: !209, size: 64, offset: 1792)
!512 = !DIDerivedType(tag: DW_TAG_member, name: "get_extstore", scope: !485, file: !113, line: 377, baseType: !209, size: 64, offset: 1856)
!513 = !DIDerivedType(tag: DW_TAG_member, name: "get_aborted_extstore", scope: !485, file: !113, line: 377, baseType: !209, size: 64, offset: 1920)
!514 = !DIDerivedType(tag: DW_TAG_member, name: "get_oom_extstore", scope: !485, file: !113, line: 377, baseType: !209, size: 64, offset: 1984)
!515 = !DIDerivedType(tag: DW_TAG_member, name: "recache_from_extstore", scope: !485, file: !113, line: 377, baseType: !209, size: 64, offset: 2048)
!516 = !DIDerivedType(tag: DW_TAG_member, name: "miss_from_extstore", scope: !485, file: !113, line: 377, baseType: !209, size: 64, offset: 2112)
!517 = !DIDerivedType(tag: DW_TAG_member, name: "badcrc_from_extstore", scope: !485, file: !113, line: 377, baseType: !209, size: 64, offset: 2176)
!518 = !DIDerivedType(tag: DW_TAG_member, name: "slab_stats", scope: !485, file: !113, line: 383, baseType: !519, size: 32768, offset: 2240)
!519 = !DICompositeType(tag: DW_TAG_array_type, baseType: !520, size: 32768, elements: !530)
!520 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "slab_stats", file: !113, line: 318, size: 512, elements: !521)
!521 = !{!522, !523, !524, !525, !526, !527, !528, !529}
!522 = !DIDerivedType(tag: DW_TAG_member, name: "set_cmds", scope: !520, file: !113, line: 320, baseType: !209, size: 64)
!523 = !DIDerivedType(tag: DW_TAG_member, name: "get_hits", scope: !520, file: !113, line: 320, baseType: !209, size: 64, offset: 64)
!524 = !DIDerivedType(tag: DW_TAG_member, name: "touch_hits", scope: !520, file: !113, line: 320, baseType: !209, size: 64, offset: 128)
!525 = !DIDerivedType(tag: DW_TAG_member, name: "delete_hits", scope: !520, file: !113, line: 320, baseType: !209, size: 64, offset: 192)
!526 = !DIDerivedType(tag: DW_TAG_member, name: "cas_hits", scope: !520, file: !113, line: 320, baseType: !209, size: 64, offset: 256)
!527 = !DIDerivedType(tag: DW_TAG_member, name: "cas_badval", scope: !520, file: !113, line: 320, baseType: !209, size: 64, offset: 320)
!528 = !DIDerivedType(tag: DW_TAG_member, name: "incr_hits", scope: !520, file: !113, line: 320, baseType: !209, size: 64, offset: 384)
!529 = !DIDerivedType(tag: DW_TAG_member, name: "decr_hits", scope: !520, file: !113, line: 320, baseType: !209, size: 64, offset: 448)
!530 = !{!531}
!531 = !DISubrange(count: 64)
!532 = !DIDerivedType(tag: DW_TAG_member, name: "lru_hits", scope: !485, file: !113, line: 384, baseType: !533, size: 16384, offset: 35008)
!533 = !DICompositeType(tag: DW_TAG_array_type, baseType: !209, size: 16384, elements: !534)
!534 = !{!535}
!535 = !DISubrange(count: 256)
!536 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_count", scope: !485, file: !113, line: 385, baseType: !209, size: 64, offset: 51392)
!537 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes", scope: !485, file: !113, line: 386, baseType: !209, size: 64, offset: 51456)
!538 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes_free", scope: !485, file: !113, line: 387, baseType: !209, size: 64, offset: 51520)
!539 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !351, file: !113, line: 731, baseType: !540, size: 576, offset: 54400)
!540 = !DICompositeType(tag: DW_TAG_array_type, baseType: !541, size: 576, elements: !27)
!541 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb_t", file: !113, line: 708, baseType: !542)
!542 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_cb_s", file: !113, line: 704, size: 192, elements: !543)
!543 = !{!544, !545, !558}
!544 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !542, file: !113, line: 705, baseType: !191, size: 64)
!545 = !DIDerivedType(tag: DW_TAG_member, name: "submit_cb", scope: !542, file: !113, line: 706, baseType: !546, size: 64, offset: 64)
!546 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_stack_cb", file: !113, line: 689, baseType: !547)
!547 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !548, size: 64)
!548 = !DISubroutineType(types: !549)
!549 = !{null, !550}
!550 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !551, size: 64)
!551 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_t", file: !113, line: 688, baseType: !552)
!552 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_s", file: !113, line: 697, size: 192, elements: !553)
!553 = !{!554, !555, !556, !557}
!554 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !552, file: !113, line: 698, baseType: !191, size: 64)
!555 = !DIDerivedType(tag: DW_TAG_member, name: "stack_ctx", scope: !552, file: !113, line: 699, baseType: !191, size: 64, offset: 64)
!556 = !DIDerivedType(tag: DW_TAG_member, name: "count", scope: !552, file: !113, line: 700, baseType: !190, size: 32, offset: 128)
!557 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !552, file: !113, line: 701, baseType: !190, size: 32, offset: 160)
!558 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !542, file: !113, line: 707, baseType: !190, size: 32, offset: 128)
!559 = !DIDerivedType(tag: DW_TAG_member, name: "ev_queue", scope: !351, file: !113, line: 732, baseType: !560, size: 64, offset: 54976)
!560 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !561, size: 64)
!561 = !DICompositeType(tag: DW_TAG_structure_type, name: "conn_queue", file: !113, line: 732, flags: DIFlagFwdDecl)
!562 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_cache", scope: !351, file: !113, line: 733, baseType: !563, size: 64, offset: 55040)
!563 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !564, size: 64)
!564 = !DIDerivedType(tag: DW_TAG_typedef, name: "cache_t", file: !565, line: 39, baseType: !566)
!565 = !DIFile(filename: "./cache.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d97639c8540587a19d8550d7d7156448")
!566 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !565, line: 22, size: 704, elements: !567)
!567 = !{!568, !569, !570, !583, !586, !587, !588, !589}
!568 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !566, file: !565, line: 24, baseType: !447, size: 320)
!569 = !DIDerivedType(tag: DW_TAG_member, name: "name", scope: !566, file: !565, line: 26, baseType: !193, size: 64, offset: 320)
!570 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !566, file: !565, line: 28, baseType: !571, size: 128, offset: 384)
!571 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_head", file: !565, line: 28, size: 128, elements: !572)
!572 = !{!573, !581}
!573 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !571, file: !565, line: 28, baseType: !574, size: 64)
!574 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !575, size: 64)
!575 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_free_s", file: !565, line: 12, size: 64, elements: !576)
!576 = !{!577}
!577 = !DIDerivedType(tag: DW_TAG_member, name: "c_next", scope: !575, file: !565, line: 13, baseType: !578, size: 64)
!578 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !575, file: !565, line: 13, size: 64, elements: !579)
!579 = !{!580}
!580 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !578, file: !565, line: 13, baseType: !574, size: 64)
!581 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !571, file: !565, line: 28, baseType: !582, size: 64, offset: 64)
!582 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !574, size: 64)
!583 = !DIDerivedType(tag: DW_TAG_member, name: "bufsize", scope: !566, file: !565, line: 30, baseType: !584, size: 64, offset: 512)
!584 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !585, line: 18, baseType: !213)
!585 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!586 = !DIDerivedType(tag: DW_TAG_member, name: "freetotal", scope: !566, file: !565, line: 32, baseType: !190, size: 32, offset: 576)
!587 = !DIDerivedType(tag: DW_TAG_member, name: "total", scope: !566, file: !565, line: 34, baseType: !190, size: 32, offset: 608)
!588 = !DIDerivedType(tag: DW_TAG_member, name: "freecurr", scope: !566, file: !565, line: 36, baseType: !190, size: 32, offset: 640)
!589 = !DIDerivedType(tag: DW_TAG_member, name: "limit", scope: !566, file: !565, line: 38, baseType: !190, size: 32, offset: 672)
!590 = !DIDerivedType(tag: DW_TAG_member, name: "open_bundle", scope: !351, file: !113, line: 734, baseType: !591, size: 64, offset: 55104)
!591 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !592, size: 64)
!592 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp_bundle", file: !113, line: 720, baseType: !593)
!593 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp_bundle", file: !113, line: 804, size: 256, elements: !594)
!594 = !{!595, !596, !597, !598, !600, !601}
!595 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !593, file: !113, line: 805, baseType: !322, size: 8)
!596 = !DIDerivedType(tag: DW_TAG_member, name: "next_check", scope: !593, file: !113, line: 806, baseType: !322, size: 8, offset: 8)
!597 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !593, file: !113, line: 807, baseType: !349, size: 64, offset: 64)
!598 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !593, file: !113, line: 808, baseType: !599, size: 64, offset: 128)
!599 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !593, size: 64)
!600 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !593, file: !113, line: 809, baseType: !599, size: 64, offset: 192)
!601 = !DIDerivedType(tag: DW_TAG_member, name: "r", scope: !593, file: !113, line: 810, baseType: !602, offset: 256)
!602 = !DICompositeType(tag: DW_TAG_array_type, baseType: !603, elements: !332)
!603 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp", file: !113, line: 801, baseType: !604)
!604 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp", file: !113, line: 771, size: 9472, elements: !605)
!605 = !{!606, !607, !609, !610, !611, !612, !613, !616, !625, !626, !627, !628, !630, !631, !632, !633, !634, !657, !661}
!606 = !DIDerivedType(tag: DW_TAG_member, name: "bundle", scope: !604, file: !113, line: 772, baseType: !591, size: 64)
!607 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !604, file: !113, line: 773, baseType: !608, size: 64, offset: 64)
!608 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !604, size: 64)
!609 = !DIDerivedType(tag: DW_TAG_member, name: "wbytes", scope: !604, file: !113, line: 774, baseType: !190, size: 32, offset: 128)
!610 = !DIDerivedType(tag: DW_TAG_member, name: "tosend", scope: !604, file: !113, line: 775, baseType: !190, size: 32, offset: 160)
!611 = !DIDerivedType(tag: DW_TAG_member, name: "write_and_free", scope: !604, file: !113, line: 776, baseType: !191, size: 64, offset: 192)
!612 = !DIDerivedType(tag: DW_TAG_member, name: "io_pending", scope: !604, file: !113, line: 777, baseType: !343, size: 64, offset: 256)
!613 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !604, file: !113, line: 779, baseType: !614, size: 64, offset: 320)
!614 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !615, size: 64)
!615 = !DIDerivedType(tag: DW_TAG_typedef, name: "item", file: !113, line: 616, baseType: !308)
!616 = !DIDerivedType(tag: DW_TAG_member, name: "iov", scope: !604, file: !113, line: 780, baseType: !617, size: 512, offset: 384)
!617 = !DICompositeType(tag: DW_TAG_array_type, baseType: !618, size: 512, elements: !623)
!618 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iovec", file: !619, line: 26, size: 128, elements: !620)
!619 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_iovec.h", directory: "", checksumkind: CSK_MD5, checksum: "a53f2c2488bb0e21e47850624c16538a")
!620 = !{!621, !622}
!621 = !DIDerivedType(tag: DW_TAG_member, name: "iov_base", scope: !618, file: !619, line: 28, baseType: !191, size: 64)
!622 = !DIDerivedType(tag: DW_TAG_member, name: "iov_len", scope: !618, file: !619, line: 29, baseType: !584, size: 64, offset: 64)
!623 = !{!624}
!624 = !DISubrange(count: 4)
!625 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_total", scope: !604, file: !113, line: 781, baseType: !190, size: 32, offset: 896)
!626 = !DIDerivedType(tag: DW_TAG_member, name: "iovcnt", scope: !604, file: !113, line: 782, baseType: !322, size: 8, offset: 928)
!627 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_data_iov", scope: !604, file: !113, line: 783, baseType: !322, size: 8, offset: 936)
!628 = !DIDerivedType(tag: DW_TAG_member, name: "skip", scope: !604, file: !113, line: 788, baseType: !629, size: 8, offset: 944)
!629 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!630 = !DIDerivedType(tag: DW_TAG_member, name: "free", scope: !604, file: !113, line: 789, baseType: !629, size: 8, offset: 952)
!631 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !604, file: !113, line: 794, baseType: !319, size: 16, offset: 960)
!632 = !DIDerivedType(tag: DW_TAG_member, name: "udp_sequence", scope: !604, file: !113, line: 795, baseType: !319, size: 16, offset: 976)
!633 = !DIDerivedType(tag: DW_TAG_member, name: "udp_total", scope: !604, file: !113, line: 796, baseType: !319, size: 16, offset: 992)
!634 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !604, file: !113, line: 797, baseType: !635, size: 224, offset: 1024)
!635 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "sockaddr_in6", file: !636, line: 262, size: 224, elements: !637)
!636 = !DIFile(filename: "/usr/include/netinet/in.h", directory: "", checksumkind: CSK_MD5, checksum: "fbd766480c8cb9a8fe07ee7aa568ee60")
!637 = !{!638, !641, !643, !644, !656}
!638 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_family", scope: !635, file: !636, line: 264, baseType: !639, size: 16)
!639 = !DIDerivedType(tag: DW_TAG_typedef, name: "sa_family_t", file: !640, line: 28, baseType: !293)
!640 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/sockaddr.h", directory: "", checksumkind: CSK_MD5, checksum: "5066b774f0f3cdb5cbbb5467306060db")
!641 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_port", scope: !635, file: !636, line: 265, baseType: !642, size: 16, offset: 16)
!642 = !DIDerivedType(tag: DW_TAG_typedef, name: "in_port_t", file: !636, line: 125, baseType: !319)
!643 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_flowinfo", scope: !635, file: !636, line: 266, baseType: !297, size: 32, offset: 32)
!644 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_addr", scope: !635, file: !636, line: 267, baseType: !645, size: 128, offset: 64)
!645 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "in6_addr", file: !636, line: 221, size: 128, elements: !646)
!646 = !{!647}
!647 = !DIDerivedType(tag: DW_TAG_member, name: "__in6_u", scope: !645, file: !636, line: 228, baseType: !648, size: 128)
!648 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !645, file: !636, line: 223, size: 128, elements: !649)
!649 = !{!650, !652, !654}
!650 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr8", scope: !648, file: !636, line: 225, baseType: !651, size: 128)
!651 = !DICompositeType(tag: DW_TAG_array_type, baseType: !322, size: 128, elements: !234)
!652 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr16", scope: !648, file: !636, line: 226, baseType: !653, size: 128)
!653 = !DICompositeType(tag: DW_TAG_array_type, baseType: !319, size: 128, elements: !10)
!654 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr32", scope: !648, file: !636, line: 227, baseType: !655, size: 128)
!655 = !DICompositeType(tag: DW_TAG_array_type, baseType: !297, size: 128, elements: !623)
!656 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_scope_id", scope: !635, file: !636, line: 268, baseType: !297, size: 32, offset: 192)
!657 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !604, file: !113, line: 798, baseType: !658, size: 32, offset: 1248)
!658 = !DIDerivedType(tag: DW_TAG_typedef, name: "socklen_t", file: !659, line: 33, baseType: !660)
!659 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/socket.h", directory: "", checksumkind: CSK_MD5, checksum: "71a09f67661e8e55cf505c19b5ddbb85")
!660 = !DIDerivedType(tag: DW_TAG_typedef, name: "__socklen_t", file: !212, line: 210, baseType: !114)
!661 = !DIDerivedType(tag: DW_TAG_member, name: "wbuf", scope: !604, file: !113, line: 800, baseType: !662, size: 8192, offset: 1280)
!662 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 8192, elements: !663)
!663 = !{!664}
!664 = !DISubrange(count: 1024)
!665 = !DIDerivedType(tag: DW_TAG_member, name: "io_cache", scope: !351, file: !113, line: 735, baseType: !563, size: 64, offset: 55168)
!666 = !DIDerivedType(tag: DW_TAG_member, name: "storage", scope: !351, file: !113, line: 737, baseType: !191, size: 64, offset: 55232)
!667 = !DIDerivedType(tag: DW_TAG_member, name: "l", scope: !351, file: !113, line: 739, baseType: !668, size: 64, offset: 55296)
!668 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !669, size: 64)
!669 = !DIDerivedType(tag: DW_TAG_typedef, name: "logger", file: !147, line: 193, baseType: !670)
!670 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logger", file: !147, line: 181, size: 832, elements: !671)
!671 = !{!672, !674, !675, !676, !677, !678, !679, !680, !681, !682, !695}
!672 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !670, file: !147, line: 182, baseType: !673, size: 64)
!673 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !670, size: 64)
!674 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !670, file: !147, line: 183, baseType: !673, size: 64, offset: 64)
!675 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !670, file: !147, line: 184, baseType: !447, size: 320, offset: 128)
!676 = !DIDerivedType(tag: DW_TAG_member, name: "written", scope: !670, file: !147, line: 185, baseType: !209, size: 64, offset: 448)
!677 = !DIDerivedType(tag: DW_TAG_member, name: "dropped", scope: !670, file: !147, line: 186, baseType: !209, size: 64, offset: 512)
!678 = !DIDerivedType(tag: DW_TAG_member, name: "blocked", scope: !670, file: !147, line: 187, baseType: !209, size: 64, offset: 576)
!679 = !DIDerivedType(tag: DW_TAG_member, name: "fetcher_ratio", scope: !670, file: !147, line: 188, baseType: !319, size: 16, offset: 640)
!680 = !DIDerivedType(tag: DW_TAG_member, name: "mutation_ratio", scope: !670, file: !147, line: 189, baseType: !319, size: 16, offset: 656)
!681 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !670, file: !147, line: 190, baseType: !319, size: 16, offset: 672)
!682 = !DIDerivedType(tag: DW_TAG_member, name: "buf", scope: !670, file: !147, line: 191, baseType: !683, size: 64, offset: 704)
!683 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !684, size: 64)
!684 = !DIDerivedType(tag: DW_TAG_typedef, name: "bipbuf_t", file: !685, line: 18, baseType: !686)
!685 = !DIFile(filename: "./bipbuffer.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "99606bcb8393045e6bc9eef40115066f")
!686 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !685, line: 4, size: 192, elements: !687)
!687 = !{!688, !689, !690, !691, !692, !693}
!688 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !686, file: !685, line: 6, baseType: !213, size: 64)
!689 = !DIDerivedType(tag: DW_TAG_member, name: "a_start", scope: !686, file: !685, line: 9, baseType: !114, size: 32, offset: 64)
!690 = !DIDerivedType(tag: DW_TAG_member, name: "a_end", scope: !686, file: !685, line: 9, baseType: !114, size: 32, offset: 96)
!691 = !DIDerivedType(tag: DW_TAG_member, name: "b_end", scope: !686, file: !685, line: 12, baseType: !114, size: 32, offset: 128)
!692 = !DIDerivedType(tag: DW_TAG_member, name: "b_inuse", scope: !686, file: !685, line: 15, baseType: !190, size: 32, offset: 160)
!693 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !686, file: !685, line: 17, baseType: !694, offset: 192)
!694 = !DICompositeType(tag: DW_TAG_array_type, baseType: !324, elements: !332)
!695 = !DIDerivedType(tag: DW_TAG_member, name: "entry_map", scope: !670, file: !147, line: 192, baseType: !696, size: 64, offset: 768)
!696 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !697, size: 64)
!697 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !698)
!698 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_details", file: !147, line: 58, baseType: !699)
!699 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_entry_details", file: !147, line: 63, size: 256, elements: !700)
!700 = !{!701, !702, !703, !732, !737}
!701 = !DIDerivedType(tag: DW_TAG_member, name: "reqlen", scope: !699, file: !147, line: 64, baseType: !190, size: 32)
!702 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !699, file: !147, line: 65, baseType: !319, size: 16, offset: 32)
!703 = !DIDerivedType(tag: DW_TAG_member, name: "log_cb", scope: !699, file: !147, line: 66, baseType: !704, size: 64, offset: 64)
!704 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_log_cb", file: !147, line: 60, baseType: !705)
!705 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !706, size: 64)
!706 = !DISubroutineType(types: !707)
!707 = !{null, !708, !696, !723, !725}
!708 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !709, size: 64)
!709 = !DIDerivedType(tag: DW_TAG_typedef, name: "logentry", file: !147, line: 57, baseType: !710)
!710 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logentry", file: !147, line: 156, size: 320, elements: !711)
!711 = !{!712, !713, !714, !715, !716, !717, !718}
!712 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !710, file: !147, line: 157, baseType: !146, size: 32)
!713 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !710, file: !147, line: 158, baseType: !322, size: 8, offset: 32)
!714 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !710, file: !147, line: 159, baseType: !319, size: 16, offset: 48)
!715 = !DIDerivedType(tag: DW_TAG_member, name: "gid", scope: !710, file: !147, line: 160, baseType: !209, size: 64, offset: 64)
!716 = !DIDerivedType(tag: DW_TAG_member, name: "tv", scope: !710, file: !147, line: 161, baseType: !422, size: 128, offset: 128)
!717 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !710, file: !147, line: 162, baseType: !190, size: 32, offset: 256)
!718 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !710, file: !147, line: 165, baseType: !719, offset: 288)
!719 = !DICompositeType(tag: DW_TAG_array_type, baseType: !720, elements: !332)
!720 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !710, file: !147, line: 163, size: 8, elements: !721)
!721 = !{!722}
!722 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !720, file: !147, line: 164, baseType: !4, size: 8)
!723 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !724, size: 64)
!724 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!725 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !726, size: 64)
!726 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !727)
!727 = !{!728, !729, !730, !731}
!728 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !726, file: !2, line: 113, baseType: !114, size: 32)
!729 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !726, file: !2, line: 113, baseType: !114, size: 32, offset: 32)
!730 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !726, file: !2, line: 113, baseType: !191, size: 64, offset: 64)
!731 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !726, file: !2, line: 113, baseType: !191, size: 64, offset: 128)
!732 = !DIDerivedType(tag: DW_TAG_member, name: "parse_cb", scope: !699, file: !147, line: 67, baseType: !733, size: 64, offset: 128)
!733 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_parse_cb", file: !147, line: 61, baseType: !734)
!734 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !735, size: 64)
!735 = !DISubroutineType(types: !736)
!736 = !{!190, !708, !193}
!737 = !DIDerivedType(tag: DW_TAG_member, name: "format", scope: !699, file: !147, line: 68, baseType: !193, size: 64, offset: 192)
!738 = !DIDerivedType(tag: DW_TAG_member, name: "lru_bump_buf", scope: !351, file: !113, line: 740, baseType: !191, size: 64, offset: 55360)
!739 = !DIDerivedType(tag: DW_TAG_member, name: "napi_id", scope: !351, file: !113, line: 744, baseType: !190, size: 32, offset: 55424)
!740 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !345, file: !113, line: 818, baseType: !741, size: 64, offset: 128)
!741 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !742, size: 64)
!742 = !DIDerivedType(tag: DW_TAG_typedef, name: "conn", file: !113, line: 813, baseType: !743)
!743 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "conn", file: !113, line: 829, size: 3968, elements: !744)
!744 = !{!745, !749, !750, !751, !752, !753, !754, !755, !756, !757, !758, !759, !760, !761, !762, !763, !764, !765, !766, !767, !769, !770, !771, !772, !773, !774, !775, !777, !778, !779, !780, !781, !782, !783, !784, !785, !791, !809, !810, !811, !812, !813, !814, !815, !816, !820, !827, !842}
!745 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_conn", scope: !743, file: !113, line: 830, baseType: !746, size: 64)
!746 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !747, size: 64)
!747 = !DIDerivedType(tag: DW_TAG_typedef, name: "sasl_conn_t", file: !748, line: 16, baseType: !191)
!748 = !DIFile(filename: "./sasl_defs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "3a8678a43d09d8e311388b26eedc7a3e")
!749 = !DIDerivedType(tag: DW_TAG_member, name: "sfd", scope: !743, file: !113, line: 831, baseType: !190, size: 32, offset: 64)
!750 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_started", scope: !743, file: !113, line: 832, baseType: !629, size: 8, offset: 96)
!751 = !DIDerivedType(tag: DW_TAG_member, name: "authenticated", scope: !743, file: !113, line: 833, baseType: !629, size: 8, offset: 104)
!752 = !DIDerivedType(tag: DW_TAG_member, name: "set_stale", scope: !743, file: !113, line: 834, baseType: !629, size: 8, offset: 112)
!753 = !DIDerivedType(tag: DW_TAG_member, name: "mset_res", scope: !743, file: !113, line: 835, baseType: !629, size: 8, offset: 120)
!754 = !DIDerivedType(tag: DW_TAG_member, name: "close_after_write", scope: !743, file: !113, line: 836, baseType: !629, size: 8, offset: 128)
!755 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_malloced", scope: !743, file: !113, line: 837, baseType: !629, size: 8, offset: 136)
!756 = !DIDerivedType(tag: DW_TAG_member, name: "item_malloced", scope: !743, file: !113, line: 838, baseType: !629, size: 8, offset: 144)
!757 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !743, file: !113, line: 844, baseType: !112, size: 32, offset: 160)
!758 = !DIDerivedType(tag: DW_TAG_member, name: "substate", scope: !743, file: !113, line: 845, baseType: !132, size: 32, offset: 192)
!759 = !DIDerivedType(tag: DW_TAG_member, name: "last_cmd_time", scope: !743, file: !113, line: 846, baseType: !314, size: 32, offset: 224)
!760 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !743, file: !113, line: 847, baseType: !364, size: 1024, offset: 256)
!761 = !DIDerivedType(tag: DW_TAG_member, name: "ev_flags", scope: !743, file: !113, line: 848, baseType: !377, size: 16, offset: 1280)
!762 = !DIDerivedType(tag: DW_TAG_member, name: "which", scope: !743, file: !113, line: 849, baseType: !377, size: 16, offset: 1296)
!763 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf", scope: !743, file: !113, line: 851, baseType: !193, size: 64, offset: 1344)
!764 = !DIDerivedType(tag: DW_TAG_member, name: "rcurr", scope: !743, file: !113, line: 852, baseType: !193, size: 64, offset: 1408)
!765 = !DIDerivedType(tag: DW_TAG_member, name: "rsize", scope: !743, file: !113, line: 853, baseType: !190, size: 32, offset: 1472)
!766 = !DIDerivedType(tag: DW_TAG_member, name: "rbytes", scope: !743, file: !113, line: 854, baseType: !190, size: 32, offset: 1504)
!767 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !743, file: !113, line: 856, baseType: !768, size: 64, offset: 1536)
!768 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !603, size: 64)
!769 = !DIDerivedType(tag: DW_TAG_member, name: "resp_head", scope: !743, file: !113, line: 857, baseType: !768, size: 64, offset: 1600)
!770 = !DIDerivedType(tag: DW_TAG_member, name: "ritem", scope: !743, file: !113, line: 858, baseType: !193, size: 64, offset: 1664)
!771 = !DIDerivedType(tag: DW_TAG_member, name: "rlbytes", scope: !743, file: !113, line: 859, baseType: !190, size: 32, offset: 1728)
!772 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !743, file: !113, line: 867, baseType: !191, size: 64, offset: 1792)
!773 = !DIDerivedType(tag: DW_TAG_member, name: "sbytes", scope: !743, file: !113, line: 870, baseType: !190, size: 32, offset: 1856)
!774 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues_submitted", scope: !743, file: !113, line: 872, baseType: !190, size: 32, offset: 1888)
!775 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !743, file: !113, line: 873, baseType: !776, size: 576, offset: 1920)
!776 = !DICompositeType(tag: DW_TAG_array_type, baseType: !551, size: 576, elements: !27)
!777 = !DIDerivedType(tag: DW_TAG_member, name: "recache_counter", scope: !743, file: !113, line: 878, baseType: !114, size: 32, offset: 2496)
!778 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !743, file: !113, line: 880, baseType: !165, size: 32, offset: 2528)
!779 = !DIDerivedType(tag: DW_TAG_member, name: "transport", scope: !743, file: !113, line: 881, baseType: !170, size: 32, offset: 2560)
!780 = !DIDerivedType(tag: DW_TAG_member, name: "close_reason", scope: !743, file: !113, line: 882, baseType: !175, size: 32, offset: 2592)
!781 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !743, file: !113, line: 885, baseType: !190, size: 32, offset: 2624)
!782 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !743, file: !113, line: 886, baseType: !635, size: 224, offset: 2656)
!783 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !743, file: !113, line: 887, baseType: !658, size: 32, offset: 2880)
!784 = !DIDerivedType(tag: DW_TAG_member, name: "noreply", scope: !743, file: !113, line: 889, baseType: !629, size: 8, offset: 2912)
!785 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !743, file: !113, line: 895, baseType: !786, size: 192, offset: 2944)
!786 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !743, file: !113, line: 891, size: 192, elements: !787)
!787 = !{!788, !789, !790}
!788 = !DIDerivedType(tag: DW_TAG_member, name: "buffer", scope: !786, file: !113, line: 892, baseType: !193, size: 64)
!789 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !786, file: !113, line: 893, baseType: !584, size: 64, offset: 64)
!790 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !786, file: !113, line: 894, baseType: !584, size: 64, offset: 128)
!791 = !DIDerivedType(tag: DW_TAG_member, name: "binary_header", scope: !743, file: !113, line: 899, baseType: !792, size: 192, offset: 3136)
!792 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_request_header", file: !267, line: 164, baseType: !793)
!793 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !267, line: 151, size: 192, elements: !794)
!794 = !{!795, !807}
!795 = !DIDerivedType(tag: DW_TAG_member, name: "request", scope: !793, file: !267, line: 162, baseType: !796, size: 192)
!796 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !793, file: !267, line: 152, size: 192, elements: !797)
!797 = !{!798, !799, !800, !801, !802, !803, !804, !805, !806}
!798 = !DIDerivedType(tag: DW_TAG_member, name: "magic", scope: !796, file: !267, line: 153, baseType: !322, size: 8)
!799 = !DIDerivedType(tag: DW_TAG_member, name: "opcode", scope: !796, file: !267, line: 154, baseType: !322, size: 8, offset: 8)
!800 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !796, file: !267, line: 155, baseType: !319, size: 16, offset: 16)
!801 = !DIDerivedType(tag: DW_TAG_member, name: "extlen", scope: !796, file: !267, line: 156, baseType: !322, size: 8, offset: 32)
!802 = !DIDerivedType(tag: DW_TAG_member, name: "datatype", scope: !796, file: !267, line: 157, baseType: !322, size: 8, offset: 40)
!803 = !DIDerivedType(tag: DW_TAG_member, name: "reserved", scope: !796, file: !267, line: 158, baseType: !319, size: 16, offset: 48)
!804 = !DIDerivedType(tag: DW_TAG_member, name: "bodylen", scope: !796, file: !267, line: 159, baseType: !297, size: 32, offset: 64)
!805 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !796, file: !267, line: 160, baseType: !297, size: 32, offset: 96)
!806 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !796, file: !267, line: 161, baseType: !209, size: 64, offset: 128)
!807 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !793, file: !267, line: 163, baseType: !808, size: 192)
!808 = !DICompositeType(tag: DW_TAG_array_type, baseType: !322, size: 192, elements: !64)
!809 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !743, file: !113, line: 900, baseType: !209, size: 64, offset: 3328)
!810 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !743, file: !113, line: 901, baseType: !209, size: 64, offset: 3392)
!811 = !DIDerivedType(tag: DW_TAG_member, name: "cmd", scope: !743, file: !113, line: 902, baseType: !377, size: 16, offset: 3456)
!812 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !743, file: !113, line: 903, baseType: !190, size: 32, offset: 3488)
!813 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !743, file: !113, line: 904, baseType: !190, size: 32, offset: 3520)
!814 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !743, file: !113, line: 905, baseType: !741, size: 64, offset: 3584)
!815 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !743, file: !113, line: 906, baseType: !349, size: 64, offset: 3648)
!816 = !DIDerivedType(tag: DW_TAG_member, name: "try_read_command", scope: !743, file: !113, line: 907, baseType: !817, size: 64, offset: 3712)
!817 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !818, size: 64)
!818 = !DISubroutineType(types: !819)
!819 = !{!190, !741}
!820 = !DIDerivedType(tag: DW_TAG_member, name: "read", scope: !743, file: !113, line: 908, baseType: !821, size: 64, offset: 3776)
!821 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !822, size: 64)
!822 = !DISubroutineType(types: !823)
!823 = !{!824, !741, !191, !584}
!824 = !DIDerivedType(tag: DW_TAG_typedef, name: "ssize_t", file: !825, line: 108, baseType: !826)
!825 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/types.h", directory: "", checksumkind: CSK_MD5, checksum: "7fb02a803b0c9b11cb5276b77d21e9d8")
!826 = !DIDerivedType(tag: DW_TAG_typedef, name: "__ssize_t", file: !212, line: 194, baseType: !427)
!827 = !DIDerivedType(tag: DW_TAG_member, name: "sendmsg", scope: !743, file: !113, line: 909, baseType: !828, size: 64, offset: 3840)
!828 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !829, size: 64)
!829 = !DISubroutineType(types: !830)
!830 = !{!824, !741, !831, !190}
!831 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !832, size: 64)
!832 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "msghdr", file: !659, line: 262, size: 448, elements: !833)
!833 = !{!834, !835, !836, !838, !839, !840, !841}
!834 = !DIDerivedType(tag: DW_TAG_member, name: "msg_name", scope: !832, file: !659, line: 264, baseType: !191, size: 64)
!835 = !DIDerivedType(tag: DW_TAG_member, name: "msg_namelen", scope: !832, file: !659, line: 265, baseType: !658, size: 32, offset: 64)
!836 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iov", scope: !832, file: !659, line: 267, baseType: !837, size: 64, offset: 128)
!837 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !618, size: 64)
!838 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iovlen", scope: !832, file: !659, line: 268, baseType: !584, size: 64, offset: 192)
!839 = !DIDerivedType(tag: DW_TAG_member, name: "msg_control", scope: !832, file: !659, line: 270, baseType: !191, size: 64, offset: 256)
!840 = !DIDerivedType(tag: DW_TAG_member, name: "msg_controllen", scope: !832, file: !659, line: 271, baseType: !584, size: 64, offset: 320)
!841 = !DIDerivedType(tag: DW_TAG_member, name: "msg_flags", scope: !832, file: !659, line: 276, baseType: !190, size: 32, offset: 384)
!842 = !DIDerivedType(tag: DW_TAG_member, name: "write", scope: !743, file: !113, line: 910, baseType: !821, size: 64, offset: 3904)
!843 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !345, file: !113, line: 819, baseType: !768, size: 64, offset: 192)
!844 = !DIDerivedType(tag: DW_TAG_member, name: "return_cb", scope: !345, file: !113, line: 820, baseType: !845, size: 64, offset: 256)
!845 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb", file: !113, line: 690, baseType: !846)
!846 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !847, size: 64)
!847 = !DISubroutineType(types: !848)
!848 = !{null, !343}
!849 = !DIDerivedType(tag: DW_TAG_member, name: "finalize_cb", scope: !345, file: !113, line: 821, baseType: !845, size: 64, offset: 320)
!850 = !DIDerivedType(tag: DW_TAG_member, name: "iop_next", scope: !345, file: !113, line: 822, baseType: !851, size: 64, offset: 384)
!851 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !345, file: !113, line: 822, size: 64, elements: !852)
!852 = !{!853}
!853 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !851, file: !113, line: 822, baseType: !479, size: 64)
!854 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !345, file: !113, line: 823, baseType: !855, size: 960, offset: 448)
!855 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 960, elements: !856)
!856 = !{!857}
!857 = !DISubrange(count: 120)
!858 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !859, size: 64)
!859 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_pending_storage_t", file: !2, line: 47, baseType: !860)
!860 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_io_pending_storage_t", file: !2, line: 31, size: 1088, elements: !861)
!861 = !{!862, !863, !864, !865, !866, !867, !868, !874, !875, !896, !897, !898, !899, !900}
!862 = !DIDerivedType(tag: DW_TAG_member, name: "io_queue_type", scope: !860, file: !2, line: 32, baseType: !190, size: 32)
!863 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !860, file: !2, line: 33, baseType: !349, size: 64, offset: 64)
!864 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !860, file: !2, line: 34, baseType: !741, size: 64, offset: 128)
!865 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !860, file: !2, line: 35, baseType: !768, size: 64, offset: 192)
!866 = !DIDerivedType(tag: DW_TAG_member, name: "return_cb", scope: !860, file: !2, line: 36, baseType: !845, size: 64, offset: 256)
!867 = !DIDerivedType(tag: DW_TAG_member, name: "finalize_cb", scope: !860, file: !2, line: 37, baseType: !845, size: 64, offset: 320)
!868 = !DIDerivedType(tag: DW_TAG_member, name: "iop_next", scope: !860, file: !2, line: 38, baseType: !869, size: 64, offset: 384)
!869 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !860, file: !2, line: 38, size: 64, elements: !870)
!870 = !{!871}
!871 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !869, file: !2, line: 38, baseType: !872, size: 64)
!872 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !873, size: 64)
!873 = !DICompositeType(tag: DW_TAG_structure_type, name: "io_pending_t", file: !2, line: 38, flags: DIFlagFwdDecl)
!874 = !DIDerivedType(tag: DW_TAG_member, name: "hdr_it", scope: !860, file: !2, line: 40, baseType: !614, size: 64, offset: 448)
!875 = !DIDerivedType(tag: DW_TAG_member, name: "io_ctx", scope: !860, file: !2, line: 41, baseType: !876, size: 512, offset: 512)
!876 = !DIDerivedType(tag: DW_TAG_typedef, name: "obj_io", file: !182, line: 71, baseType: !877)
!877 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_obj_io", file: !182, line: 78, size: 512, elements: !878)
!878 = !{!879, !880, !882, !883, !884, !885, !886, !887, !888, !889, !890}
!879 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !877, file: !182, line: 79, baseType: !191, size: 64)
!880 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !877, file: !182, line: 80, baseType: !881, size: 64, offset: 64)
!881 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !877, size: 64)
!882 = !DIDerivedType(tag: DW_TAG_member, name: "buf", scope: !877, file: !182, line: 81, baseType: !193, size: 64, offset: 128)
!883 = !DIDerivedType(tag: DW_TAG_member, name: "iov", scope: !877, file: !182, line: 82, baseType: !837, size: 64, offset: 192)
!884 = !DIDerivedType(tag: DW_TAG_member, name: "iovcnt", scope: !877, file: !182, line: 83, baseType: !114, size: 32, offset: 256)
!885 = !DIDerivedType(tag: DW_TAG_member, name: "page_version", scope: !877, file: !182, line: 84, baseType: !114, size: 32, offset: 288)
!886 = !DIDerivedType(tag: DW_TAG_member, name: "len", scope: !877, file: !182, line: 85, baseType: !114, size: 32, offset: 320)
!887 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !877, file: !182, line: 86, baseType: !114, size: 32, offset: 352)
!888 = !DIDerivedType(tag: DW_TAG_member, name: "page_id", scope: !877, file: !182, line: 87, baseType: !293, size: 16, offset: 384)
!889 = !DIDerivedType(tag: DW_TAG_member, name: "mode", scope: !877, file: !182, line: 88, baseType: !181, size: 32, offset: 416)
!890 = !DIDerivedType(tag: DW_TAG_member, name: "cb", scope: !877, file: !182, line: 90, baseType: !891, size: 64, offset: 448)
!891 = !DIDerivedType(tag: DW_TAG_typedef, name: "obj_io_cb", file: !182, line: 72, baseType: !892)
!892 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !893, size: 64)
!893 = !DISubroutineType(types: !894)
!894 = !{null, !191, !895, !190}
!895 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !876, size: 64)
!896 = !DIDerivedType(tag: DW_TAG_member, name: "iovec_data", scope: !860, file: !2, line: 42, baseType: !114, size: 32, offset: 1024)
!897 = !DIDerivedType(tag: DW_TAG_member, name: "noreply", scope: !860, file: !2, line: 43, baseType: !629, size: 8, offset: 1056)
!898 = !DIDerivedType(tag: DW_TAG_member, name: "miss", scope: !860, file: !2, line: 44, baseType: !629, size: 8, offset: 1064)
!899 = !DIDerivedType(tag: DW_TAG_member, name: "badcrc", scope: !860, file: !2, line: 45, baseType: !629, size: 8, offset: 1072)
!900 = !DIDerivedType(tag: DW_TAG_member, name: "active", scope: !860, file: !2, line: 46, baseType: !629, size: 8, offset: 1080)
!901 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !902, size: 64)
!902 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_response_header", file: !267, line: 183, baseType: !903)
!903 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !267, line: 170, size: 192, elements: !904)
!904 = !{!905, !917}
!905 = !DIDerivedType(tag: DW_TAG_member, name: "response", scope: !903, file: !267, line: 181, baseType: !906, size: 192)
!906 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !903, file: !267, line: 171, size: 192, elements: !907)
!907 = !{!908, !909, !910, !911, !912, !913, !914, !915, !916}
!908 = !DIDerivedType(tag: DW_TAG_member, name: "magic", scope: !906, file: !267, line: 172, baseType: !322, size: 8)
!909 = !DIDerivedType(tag: DW_TAG_member, name: "opcode", scope: !906, file: !267, line: 173, baseType: !322, size: 8, offset: 8)
!910 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !906, file: !267, line: 174, baseType: !319, size: 16, offset: 16)
!911 = !DIDerivedType(tag: DW_TAG_member, name: "extlen", scope: !906, file: !267, line: 175, baseType: !322, size: 8, offset: 32)
!912 = !DIDerivedType(tag: DW_TAG_member, name: "datatype", scope: !906, file: !267, line: 176, baseType: !322, size: 8, offset: 40)
!913 = !DIDerivedType(tag: DW_TAG_member, name: "status", scope: !906, file: !267, line: 177, baseType: !319, size: 16, offset: 48)
!914 = !DIDerivedType(tag: DW_TAG_member, name: "bodylen", scope: !906, file: !267, line: 178, baseType: !297, size: 32, offset: 64)
!915 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !906, file: !267, line: 179, baseType: !297, size: 32, offset: 96)
!916 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !906, file: !267, line: 180, baseType: !209, size: 64, offset: 128)
!917 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !903, file: !267, line: 182, baseType: !808, size: 192)
!918 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !919, size: 64)
!919 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "storage_compact_wrap", file: !2, line: 894, size: 896, elements: !920)
!920 = !{!921, !922, !923, !924, !925}
!921 = !DIDerivedType(tag: DW_TAG_member, name: "io", scope: !919, file: !2, line: 895, baseType: !876, size: 512)
!922 = !DIDerivedType(tag: DW_TAG_member, name: "lock", scope: !919, file: !2, line: 896, baseType: !447, size: 320, offset: 512)
!923 = !DIDerivedType(tag: DW_TAG_member, name: "done", scope: !919, file: !2, line: 897, baseType: !629, size: 8, offset: 832)
!924 = !DIDerivedType(tag: DW_TAG_member, name: "submitted", scope: !919, file: !2, line: 898, baseType: !629, size: 8, offset: 840)
!925 = !DIDerivedType(tag: DW_TAG_member, name: "miss", scope: !919, file: !2, line: 899, baseType: !629, size: 8, offset: 848)
!926 = !{!0, !7, !12, !17, !19, !24, !29, !34, !39, !44, !49, !54, !56, !61, !66, !71, !76, !78, !80, !82, !84, !86, !88, !90, !92, !94, !96, !98, !103, !927, !932, !937, !942, !947, !952, !957, !962, !964, !966, !968, !970, !972, !975, !980, !985, !987, !989, !991, !996, !998, !1000, !1002, !1007, !1009, !1011, !1013, !1015, !1018, !1020, !1025, !1030, !1035, !1037, !1039, !1044, !1046, !1051, !1056, !1058, !1060, !1062, !1064, !1066, !1068, !1073, !1078, !1083, !1088, !1093, !1098, !1100, !1102, !1104, !1106, !1108, !1113, !1115, !1120, !1122, !1125, !1130, !1132, !1134, !1136, !1138, !1170, !108, !1172, !1174, !1176, !1181}
!927 = !DIGlobalVariableExpression(var: !928, expr: !DIExpression())
!928 = distinct !DIGlobalVariable(scope: null, file: !2, line: 735, type: !929, isLocal: true, isDefinition: true)
!929 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 312, elements: !930)
!930 = !{!931}
!931 = !DISubrange(count: 39)
!932 = !DIGlobalVariableExpression(var: !933, expr: !DIExpression())
!933 = distinct !DIGlobalVariable(scope: null, file: !2, line: 739, type: !934, isLocal: true, isDefinition: true)
!934 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 104, elements: !935)
!935 = !{!936}
!936 = !DISubrange(count: 13)
!937 = !DIGlobalVariableExpression(var: !938, expr: !DIExpression())
!938 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1178, type: !939, isLocal: true, isDefinition: true)
!939 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 328, elements: !940)
!940 = !{!941}
!941 = !DISubrange(count: 41)
!942 = !DIGlobalVariableExpression(var: !943, expr: !DIExpression())
!943 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1182, type: !944, isLocal: true, isDefinition: true)
!944 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 120, elements: !945)
!945 = !{!946}
!946 = !DISubrange(count: 15)
!947 = !DIGlobalVariableExpression(var: !948, expr: !DIExpression())
!948 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1193, type: !949, isLocal: true, isDefinition: true)
!949 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 16, elements: !950)
!950 = !{!951}
!951 = !DISubrange(count: 2)
!952 = !DIGlobalVariableExpression(var: !953, expr: !DIExpression())
!953 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1205, type: !954, isLocal: true, isDefinition: true)
!954 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 584, elements: !955)
!955 = !{!956}
!956 = !DISubrange(count: 73)
!957 = !DIGlobalVariableExpression(var: !958, expr: !DIExpression())
!958 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1236, type: !959, isLocal: true, isDefinition: true)
!959 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 360, elements: !960)
!960 = !{!961}
!961 = !DISubrange(count: 45)
!962 = !DIGlobalVariableExpression(var: !963, expr: !DIExpression())
!963 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1245, type: !9, isLocal: true, isDefinition: true)
!964 = !DIGlobalVariableExpression(var: !965, expr: !DIExpression())
!965 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1247, type: !21, isLocal: true, isDefinition: true)
!966 = !DIGlobalVariableExpression(var: !967, expr: !DIExpression())
!967 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1249, type: !9, isLocal: true, isDefinition: true)
!968 = !DIGlobalVariableExpression(var: !969, expr: !DIExpression())
!969 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1251, type: !9, isLocal: true, isDefinition: true)
!970 = !DIGlobalVariableExpression(var: !971, expr: !DIExpression())
!971 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1253, type: !31, isLocal: true, isDefinition: true)
!972 = !DIGlobalVariableExpression(var: !973, expr: !DIExpression())
!973 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1255, type: !974, isLocal: true, isDefinition: true)
!974 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 32, elements: !623)
!975 = !DIGlobalVariableExpression(var: !976, expr: !DIExpression())
!976 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1258, type: !977, isLocal: true, isDefinition: true)
!977 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 232, elements: !978)
!978 = !{!979}
!979 = !DISubrange(count: 29)
!980 = !DIGlobalVariableExpression(var: !981, expr: !DIExpression())
!981 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1332, type: !982, isLocal: true, isDefinition: true)
!982 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 112, elements: !983)
!983 = !{!984}
!984 = !DISubrange(count: 14)
!985 = !DIGlobalVariableExpression(var: !986, expr: !DIExpression())
!986 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1333, type: !982, isLocal: true, isDefinition: true)
!987 = !DIGlobalVariableExpression(var: !988, expr: !DIExpression())
!988 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1334, type: !31, isLocal: true, isDefinition: true)
!989 = !DIGlobalVariableExpression(var: !990, expr: !DIExpression())
!990 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1335, type: !934, isLocal: true, isDefinition: true)
!991 = !DIGlobalVariableExpression(var: !992, expr: !DIExpression())
!992 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1336, type: !993, isLocal: true, isDefinition: true)
!993 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 72, elements: !994)
!994 = !{!995}
!995 = !DISubrange(count: 9)
!996 = !DIGlobalVariableExpression(var: !997, expr: !DIExpression())
!997 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1337, type: !982, isLocal: true, isDefinition: true)
!998 = !DIGlobalVariableExpression(var: !999, expr: !DIExpression())
!999 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1338, type: !934, isLocal: true, isDefinition: true)
!1000 = !DIGlobalVariableExpression(var: !1001, expr: !DIExpression())
!1001 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1339, type: !31, isLocal: true, isDefinition: true)
!1002 = !DIGlobalVariableExpression(var: !1003, expr: !DIExpression())
!1003 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1340, type: !1004, isLocal: true, isDefinition: true)
!1004 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 136, elements: !1005)
!1005 = !{!1006}
!1006 = !DISubrange(count: 17)
!1007 = !DIGlobalVariableExpression(var: !1008, expr: !DIExpression())
!1008 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1341, type: !100, isLocal: true, isDefinition: true)
!1009 = !DIGlobalVariableExpression(var: !1010, expr: !DIExpression())
!1010 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1342, type: !944, isLocal: true, isDefinition: true)
!1011 = !DIGlobalVariableExpression(var: !1012, expr: !DIExpression())
!1012 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1343, type: !982, isLocal: true, isDefinition: true)
!1013 = !DIGlobalVariableExpression(var: !1014, expr: !DIExpression())
!1014 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1344, type: !934, isLocal: true, isDefinition: true)
!1015 = !DIGlobalVariableExpression(var: !1016, expr: !DIExpression())
!1016 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1345, type: !1017, isLocal: true, isDefinition: true)
!1017 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 128, elements: !234)
!1018 = !DIGlobalVariableExpression(var: !1019, expr: !DIExpression())
!1019 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1346, type: !63, isLocal: true, isDefinition: true)
!1020 = !DIGlobalVariableExpression(var: !1021, expr: !DIExpression())
!1021 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1353, type: !1022, isLocal: true, isDefinition: true)
!1022 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 464, elements: !1023)
!1023 = !{!1024}
!1024 = !DISubrange(count: 58)
!1025 = !DIGlobalVariableExpression(var: !1026, expr: !DIExpression())
!1026 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1357, type: !1027, isLocal: true, isDefinition: true)
!1027 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 256, elements: !1028)
!1028 = !{!1029}
!1029 = !DISubrange(count: 32)
!1030 = !DIGlobalVariableExpression(var: !1031, expr: !DIExpression())
!1031 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1361, type: !1032, isLocal: true, isDefinition: true)
!1032 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 344, elements: !1033)
!1033 = !{!1034}
!1034 = !DISubrange(count: 43)
!1035 = !DIGlobalVariableExpression(var: !1036, expr: !DIExpression())
!1036 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1368, type: !1027, isLocal: true, isDefinition: true)
!1037 = !DIGlobalVariableExpression(var: !1038, expr: !DIExpression())
!1038 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1372, type: !1032, isLocal: true, isDefinition: true)
!1039 = !DIGlobalVariableExpression(var: !1040, expr: !DIExpression())
!1040 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1380, type: !1041, isLocal: true, isDefinition: true)
!1041 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 240, elements: !1042)
!1042 = !{!1043}
!1043 = !DISubrange(count: 30)
!1044 = !DIGlobalVariableExpression(var: !1045, expr: !DIExpression())
!1045 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1384, type: !939, isLocal: true, isDefinition: true)
!1046 = !DIGlobalVariableExpression(var: !1047, expr: !DIExpression())
!1047 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1390, type: !1048, isLocal: true, isDefinition: true)
!1048 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 248, elements: !1049)
!1049 = !{!1050}
!1050 = !DISubrange(count: 31)
!1051 = !DIGlobalVariableExpression(var: !1052, expr: !DIExpression())
!1052 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1394, type: !1053, isLocal: true, isDefinition: true)
!1053 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 336, elements: !1054)
!1054 = !{!1055}
!1055 = !DISubrange(count: 42)
!1056 = !DIGlobalVariableExpression(var: !1057, expr: !DIExpression())
!1057 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1400, type: !1027, isLocal: true, isDefinition: true)
!1058 = !DIGlobalVariableExpression(var: !1059, expr: !DIExpression())
!1059 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1404, type: !1032, isLocal: true, isDefinition: true)
!1060 = !DIGlobalVariableExpression(var: !1061, expr: !DIExpression())
!1061 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1410, type: !1048, isLocal: true, isDefinition: true)
!1062 = !DIGlobalVariableExpression(var: !1063, expr: !DIExpression())
!1063 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1414, type: !1053, isLocal: true, isDefinition: true)
!1064 = !DIGlobalVariableExpression(var: !1065, expr: !DIExpression())
!1065 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1420, type: !1041, isLocal: true, isDefinition: true)
!1066 = !DIGlobalVariableExpression(var: !1067, expr: !DIExpression())
!1067 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1424, type: !939, isLocal: true, isDefinition: true)
!1068 = !DIGlobalVariableExpression(var: !1069, expr: !DIExpression())
!1069 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1430, type: !1070, isLocal: true, isDefinition: true)
!1070 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 280, elements: !1071)
!1071 = !{!1072}
!1072 = !DISubrange(count: 35)
!1073 = !DIGlobalVariableExpression(var: !1074, expr: !DIExpression())
!1074 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1434, type: !1075, isLocal: true, isDefinition: true)
!1075 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 368, elements: !1076)
!1076 = !{!1077}
!1077 = !DISubrange(count: 46)
!1078 = !DIGlobalVariableExpression(var: !1079, expr: !DIExpression())
!1079 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1440, type: !1080, isLocal: true, isDefinition: true)
!1080 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 288, elements: !1081)
!1081 = !{!1082}
!1082 = !DISubrange(count: 36)
!1083 = !DIGlobalVariableExpression(var: !1084, expr: !DIExpression())
!1084 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1444, type: !1085, isLocal: true, isDefinition: true)
!1085 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 376, elements: !1086)
!1086 = !{!1087}
!1087 = !DISubrange(count: 47)
!1088 = !DIGlobalVariableExpression(var: !1089, expr: !DIExpression())
!1089 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1450, type: !1090, isLocal: true, isDefinition: true)
!1090 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 264, elements: !1091)
!1091 = !{!1092}
!1092 = !DISubrange(count: 33)
!1093 = !DIGlobalVariableExpression(var: !1094, expr: !DIExpression())
!1094 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1454, type: !1095, isLocal: true, isDefinition: true)
!1095 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 352, elements: !1096)
!1096 = !{!1097}
!1097 = !DISubrange(count: 44)
!1098 = !DIGlobalVariableExpression(var: !1099, expr: !DIExpression())
!1099 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1460, type: !1027, isLocal: true, isDefinition: true)
!1100 = !DIGlobalVariableExpression(var: !1101, expr: !DIExpression())
!1101 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1464, type: !1032, isLocal: true, isDefinition: true)
!1102 = !DIGlobalVariableExpression(var: !1103, expr: !DIExpression())
!1103 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1470, type: !1048, isLocal: true, isDefinition: true)
!1104 = !DIGlobalVariableExpression(var: !1105, expr: !DIExpression())
!1105 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1474, type: !1053, isLocal: true, isDefinition: true)
!1106 = !DIGlobalVariableExpression(var: !1107, expr: !DIExpression())
!1107 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1480, type: !1053, isLocal: true, isDefinition: true)
!1108 = !DIGlobalVariableExpression(var: !1109, expr: !DIExpression())
!1109 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1484, type: !1110, isLocal: true, isDefinition: true)
!1110 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 424, elements: !1111)
!1111 = !{!1112}
!1112 = !DISubrange(count: 53)
!1113 = !DIGlobalVariableExpression(var: !1114, expr: !DIExpression())
!1114 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1495, type: !1070, isLocal: true, isDefinition: true)
!1115 = !DIGlobalVariableExpression(var: !1116, expr: !DIExpression())
!1116 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1503, type: !1117, isLocal: true, isDefinition: true)
!1117 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 440, elements: !1118)
!1118 = !{!1119}
!1119 = !DISubrange(count: 55)
!1120 = !DIGlobalVariableExpression(var: !1121, expr: !DIExpression())
!1121 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1508, type: !63, isLocal: true, isDefinition: true)
!1122 = !DIGlobalVariableExpression(var: !1123, expr: !DIExpression())
!1123 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1521, type: !1124, isLocal: true, isDefinition: true)
!1124 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 512, elements: !530)
!1125 = !DIGlobalVariableExpression(var: !1126, expr: !DIExpression())
!1126 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1527, type: !1127, isLocal: true, isDefinition: true)
!1127 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 448, elements: !1128)
!1128 = !{!1129}
!1129 = !DISubrange(count: 56)
!1130 = !DIGlobalVariableExpression(var: !1131, expr: !DIExpression())
!1131 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1559, type: !1032, isLocal: true, isDefinition: true)
!1132 = !DIGlobalVariableExpression(var: !1133, expr: !DIExpression())
!1133 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1562, type: !982, isLocal: true, isDefinition: true)
!1134 = !DIGlobalVariableExpression(var: !1135, expr: !DIExpression())
!1135 = distinct !DIGlobalVariable(name: "storage_compact_tid", scope: !110, file: !2, line: 49, type: !354, isLocal: true, isDefinition: true)
!1136 = !DIGlobalVariableExpression(var: !1137, expr: !DIExpression())
!1137 = distinct !DIGlobalVariable(name: "storage_compact_plock", scope: !110, file: !2, line: 50, type: !447, isLocal: true, isDefinition: true)
!1138 = !DIGlobalVariableExpression(var: !1139, expr: !DIExpression())
!1139 = distinct !DIGlobalVariable(name: "storage_compact_cond", scope: !110, file: !2, line: 51, type: !1140, isLocal: true, isDefinition: true)
!1140 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_cond_t", file: !355, line: 80, baseType: !1141)
!1141 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !355, line: 75, size: 384, elements: !1142)
!1142 = !{!1143, !1164, !1168}
!1143 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !1141, file: !355, line: 77, baseType: !1144, size: 384)
!1144 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_cond_s", file: !463, line: 94, size: 384, elements: !1145)
!1145 = !{!1146, !1157, !1158, !1160, !1161, !1162, !1163}
!1146 = !DIDerivedType(tag: DW_TAG_member, name: "__wseq", scope: !1144, file: !463, line: 96, baseType: !1147, size: 64)
!1147 = !DIDerivedType(tag: DW_TAG_typedef, name: "__atomic_wide_counter", file: !1148, line: 33, baseType: !1149)
!1148 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h", directory: "", checksumkind: CSK_MD5, checksum: "d1ec99b0f6e36c0a42ac284d459cbd38")
!1149 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !1148, line: 25, size: 64, elements: !1150)
!1150 = !{!1151, !1152}
!1151 = !DIDerivedType(tag: DW_TAG_member, name: "__value64", scope: !1149, file: !1148, line: 27, baseType: !294, size: 64)
!1152 = !DIDerivedType(tag: DW_TAG_member, name: "__value32", scope: !1149, file: !1148, line: 32, baseType: !1153, size: 64)
!1153 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !1149, file: !1148, line: 28, size: 64, elements: !1154)
!1154 = !{!1155, !1156}
!1155 = !DIDerivedType(tag: DW_TAG_member, name: "__low", scope: !1153, file: !1148, line: 30, baseType: !114, size: 32)
!1156 = !DIDerivedType(tag: DW_TAG_member, name: "__high", scope: !1153, file: !1148, line: 31, baseType: !114, size: 32, offset: 32)
!1157 = !DIDerivedType(tag: DW_TAG_member, name: "__g1_start", scope: !1144, file: !463, line: 97, baseType: !1147, size: 64, offset: 64)
!1158 = !DIDerivedType(tag: DW_TAG_member, name: "__g_refs", scope: !1144, file: !463, line: 98, baseType: !1159, size: 64, offset: 128)
!1159 = !DICompositeType(tag: DW_TAG_array_type, baseType: !114, size: 64, elements: !950)
!1160 = !DIDerivedType(tag: DW_TAG_member, name: "__g_size", scope: !1144, file: !463, line: 99, baseType: !1159, size: 64, offset: 192)
!1161 = !DIDerivedType(tag: DW_TAG_member, name: "__g1_orig_size", scope: !1144, file: !463, line: 100, baseType: !114, size: 32, offset: 256)
!1162 = !DIDerivedType(tag: DW_TAG_member, name: "__wrefs", scope: !1144, file: !463, line: 101, baseType: !114, size: 32, offset: 288)
!1163 = !DIDerivedType(tag: DW_TAG_member, name: "__g_signals", scope: !1144, file: !463, line: 102, baseType: !1159, size: 64, offset: 320)
!1164 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !1141, file: !355, line: 78, baseType: !1165, size: 384)
!1165 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 384, elements: !1166)
!1166 = !{!1167}
!1167 = !DISubrange(count: 48)
!1168 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !1141, file: !355, line: 79, baseType: !1169, size: 64)
!1169 = !DIBasicType(name: "long long", size: 64, encoding: DW_ATE_signed)
!1170 = !DIGlobalVariableExpression(var: !1171, expr: !DIExpression())
!1171 = distinct !DIGlobalVariable(name: "storage_write_tid", scope: !110, file: !2, line: 587, type: !354, isLocal: true, isDefinition: true)
!1172 = !DIGlobalVariableExpression(var: !1173, expr: !DIExpression())
!1173 = distinct !DIGlobalVariable(scope: null, file: !2, line: 212, type: !974, isLocal: true, isDefinition: true)
!1174 = !DIGlobalVariableExpression(var: !1175, expr: !DIExpression())
!1175 = distinct !DIGlobalVariable(scope: null, file: !2, line: 217, type: !14, isLocal: true, isDefinition: true)
!1176 = !DIGlobalVariableExpression(var: !1177, expr: !DIExpression())
!1177 = distinct !DIGlobalVariable(scope: null, file: !2, line: 600, type: !1178, isLocal: true, isDefinition: true)
!1178 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 456, elements: !1179)
!1179 = !{!1180}
!1180 = !DISubrange(count: 57)
!1181 = !DIGlobalVariableExpression(var: !1182, expr: !DIExpression())
!1182 = distinct !DIGlobalVariable(scope: null, file: !2, line: 1076, type: !1183, isLocal: true, isDefinition: true)
!1183 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 528, elements: !1184)
!1184 = !{!1185}
!1185 = !DISubrange(count: 66)
!1186 = !{i32 7, !"Dwarf Version", i32 5}
!1187 = !{i32 2, !"Debug Info Version", i32 3}
!1188 = !{i32 1, !"wchar_size", i32 4}
!1189 = !{i32 8, !"PIC Level", i32 2}
!1190 = !{i32 7, !"PIE Level", i32 2}
!1191 = !{i32 7, !"uwtable", i32 2}
!1192 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!1193 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!1194 = distinct !DISubprogram(name: "storage_validate_item", scope: !2, file: !2, line: 54, type: !1195, scopeLine: 54, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !1197)
!1195 = !DISubroutineType(types: !1196)
!1196 = !{!629, !191, !614}
!1197 = !{!1198, !1199, !1200}
!1198 = !DILocalVariable(name: "e", arg: 1, scope: !1194, file: !2, line: 54, type: !191)
!1199 = !DILocalVariable(name: "it", arg: 2, scope: !1194, file: !2, line: 54, type: !614)
!1200 = !DILocalVariable(name: "hdr", scope: !1194, file: !2, line: 55, type: !286)
!1201 = !DILocation(line: 0, scope: !1194)
!1202 = !DILocation(line: 55, column: 33, scope: !1194)
!1203 = !{!1204, !1204, i64 0}
!1204 = !{!"omnipotent char", !1205, i64 0}
!1205 = !{!"Simple C/C++ TBAA"}
!1206 = !{!1207, !1207, i64 0}
!1207 = !{!"short", !1204, i64 0}
!1208 = !DILocation(line: 56, column: 32, scope: !1209)
!1209 = distinct !DILexicalBlock(scope: !1194, file: !2, line: 56, column: 9)
!1210 = !{!1211, !1207, i64 8}
!1211 = !{!"", !1212, i64 0, !1212, i64 4, !1207, i64 8}
!1212 = !{!"int", !1204, i64 0}
!1213 = !DILocation(line: 56, column: 27, scope: !1209)
!1214 = !DILocation(line: 56, column: 46, scope: !1209)
!1215 = !{!1211, !1212, i64 0}
!1216 = !DILocation(line: 56, column: 41, scope: !1209)
!1217 = !DILocation(line: 56, column: 9, scope: !1209)
!1218 = !DILocation(line: 56, column: 60, scope: !1209)
!1219 = !DILocation(line: 61, column: 1, scope: !1194)
!1220 = !DISubprogram(name: "extstore_check", scope: !182, file: !182, line: 114, type: !1221, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1221 = !DISubroutineType(types: !1222)
!1222 = !{!190, !191, !114, !209}
!1223 = distinct !DISubprogram(name: "storage_delete", scope: !2, file: !2, line: 63, type: !1224, scopeLine: 63, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !1226)
!1224 = !DISubroutineType(types: !1225)
!1225 = !{null, !191, !614}
!1226 = !{!1227, !1228, !1229}
!1227 = !DILocalVariable(name: "e", arg: 1, scope: !1223, file: !2, line: 63, type: !191)
!1228 = !DILocalVariable(name: "it", arg: 2, scope: !1223, file: !2, line: 63, type: !614)
!1229 = !DILocalVariable(name: "hdr", scope: !1230, file: !2, line: 65, type: !286)
!1230 = distinct !DILexicalBlock(scope: !1231, file: !2, line: 64, column: 34)
!1231 = distinct !DILexicalBlock(scope: !1223, file: !2, line: 64, column: 9)
!1232 = !DILocation(line: 0, scope: !1223)
!1233 = !DILocation(line: 64, column: 13, scope: !1231)
!1234 = !DILocation(line: 64, column: 9, scope: !1231)
!1235 = !DILocation(line: 64, column: 22, scope: !1231)
!1236 = !DILocation(line: 64, column: 9, scope: !1223)
!1237 = !DILocation(line: 65, column: 37, scope: !1230)
!1238 = !DILocation(line: 0, scope: !1230)
!1239 = !DILocation(line: 66, column: 33, scope: !1230)
!1240 = !DILocation(line: 66, column: 28, scope: !1230)
!1241 = !DILocation(line: 66, column: 47, scope: !1230)
!1242 = !DILocation(line: 66, column: 42, scope: !1230)
!1243 = !DILocation(line: 67, column: 20, scope: !1230)
!1244 = !{!1212, !1212, i64 0}
!1245 = !DILocation(line: 66, column: 9, scope: !1230)
!1246 = !DILocation(line: 68, column: 5, scope: !1230)
!1247 = !DILocation(line: 69, column: 1, scope: !1223)
!1248 = !DISubprogram(name: "extstore_delete", scope: !182, file: !182, line: 115, type: !1249, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1249 = !DISubroutineType(types: !1250)
!1250 = !{!190, !191, !114, !209, !114, !114}
!1251 = distinct !DISubprogram(name: "process_extstore_stats", scope: !2, file: !2, line: 77, type: !1252, scopeLine: 77, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !1262)
!1252 = !DISubroutineType(types: !1253)
!1253 = !{null, !1254, !191}
!1254 = !DIDerivedType(tag: DW_TAG_typedef, name: "ADD_STAT", file: !113, line: 194, baseType: !1255)
!1255 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1256, size: 64)
!1256 = !DISubroutineType(types: !1257)
!1257 = !{null, !1258, !1260, !1258, !1261, !723}
!1258 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1259, size: 64)
!1259 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !4)
!1260 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !319)
!1261 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !297)
!1262 = !{!1263, !1264, !1265, !1266, !1270, !1271, !1272, !1273, !1302}
!1263 = !DILocalVariable(name: "add_stats", arg: 1, scope: !1251, file: !2, line: 77, type: !1254)
!1264 = !DILocalVariable(name: "c", arg: 2, scope: !1251, file: !2, line: 77, type: !191)
!1265 = !DILocalVariable(name: "i", scope: !1251, file: !2, line: 78, type: !190)
!1266 = !DILocalVariable(name: "key_str", scope: !1251, file: !2, line: 79, type: !1267)
!1267 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 1024, elements: !1268)
!1268 = !{!1269}
!1269 = !DISubrange(count: 128)
!1270 = !DILocalVariable(name: "val_str", scope: !1251, file: !2, line: 80, type: !1267)
!1271 = !DILocalVariable(name: "klen", scope: !1251, file: !2, line: 81, type: !190)
!1272 = !DILocalVariable(name: "vlen", scope: !1251, file: !2, line: 81, type: !190)
!1273 = !DILocalVariable(name: "st", scope: !1251, file: !2, line: 82, type: !1274)
!1274 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "extstore_stats", file: !182, line: 21, size: 1152, elements: !1275)
!1275 = !{!1276, !1277, !1278, !1279, !1280, !1281, !1282, !1283, !1284, !1285, !1286, !1287, !1288, !1289, !1290, !1291, !1292, !1293}
!1276 = !DIDerivedType(tag: DW_TAG_member, name: "page_allocs", scope: !1274, file: !182, line: 22, baseType: !209, size: 64)
!1277 = !DIDerivedType(tag: DW_TAG_member, name: "page_count", scope: !1274, file: !182, line: 23, baseType: !209, size: 64, offset: 64)
!1278 = !DIDerivedType(tag: DW_TAG_member, name: "page_evictions", scope: !1274, file: !182, line: 24, baseType: !209, size: 64, offset: 128)
!1279 = !DIDerivedType(tag: DW_TAG_member, name: "page_reclaims", scope: !1274, file: !182, line: 25, baseType: !209, size: 64, offset: 192)
!1280 = !DIDerivedType(tag: DW_TAG_member, name: "page_size", scope: !1274, file: !182, line: 26, baseType: !209, size: 64, offset: 256)
!1281 = !DIDerivedType(tag: DW_TAG_member, name: "pages_free", scope: !1274, file: !182, line: 27, baseType: !209, size: 64, offset: 320)
!1282 = !DIDerivedType(tag: DW_TAG_member, name: "pages_used", scope: !1274, file: !182, line: 28, baseType: !209, size: 64, offset: 384)
!1283 = !DIDerivedType(tag: DW_TAG_member, name: "objects_evicted", scope: !1274, file: !182, line: 29, baseType: !209, size: 64, offset: 448)
!1284 = !DIDerivedType(tag: DW_TAG_member, name: "objects_read", scope: !1274, file: !182, line: 30, baseType: !209, size: 64, offset: 512)
!1285 = !DIDerivedType(tag: DW_TAG_member, name: "objects_written", scope: !1274, file: !182, line: 31, baseType: !209, size: 64, offset: 576)
!1286 = !DIDerivedType(tag: DW_TAG_member, name: "objects_used", scope: !1274, file: !182, line: 32, baseType: !209, size: 64, offset: 640)
!1287 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_evicted", scope: !1274, file: !182, line: 33, baseType: !209, size: 64, offset: 704)
!1288 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_written", scope: !1274, file: !182, line: 34, baseType: !209, size: 64, offset: 768)
!1289 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_read", scope: !1274, file: !182, line: 35, baseType: !209, size: 64, offset: 832)
!1290 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_used", scope: !1274, file: !182, line: 36, baseType: !209, size: 64, offset: 896)
!1291 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_fragmented", scope: !1274, file: !182, line: 37, baseType: !209, size: 64, offset: 960)
!1292 = !DIDerivedType(tag: DW_TAG_member, name: "io_queue", scope: !1274, file: !182, line: 38, baseType: !209, size: 64, offset: 1024)
!1293 = !DIDerivedType(tag: DW_TAG_member, name: "page_data", scope: !1274, file: !182, line: 39, baseType: !1294, size: 64, offset: 1088)
!1294 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1295, size: 64)
!1295 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "extstore_page_data", file: !182, line: 7, size: 256, elements: !1296)
!1296 = !{!1297, !1298, !1299, !1300, !1301}
!1297 = !DIDerivedType(tag: DW_TAG_member, name: "version", scope: !1295, file: !182, line: 8, baseType: !209, size: 64)
!1298 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_used", scope: !1295, file: !182, line: 9, baseType: !209, size: 64, offset: 64)
!1299 = !DIDerivedType(tag: DW_TAG_member, name: "bucket", scope: !1295, file: !182, line: 10, baseType: !114, size: 32, offset: 128)
!1300 = !DIDerivedType(tag: DW_TAG_member, name: "free_bucket", scope: !1295, file: !182, line: 11, baseType: !114, size: 32, offset: 160)
!1301 = !DIDerivedType(tag: DW_TAG_member, name: "active", scope: !1295, file: !182, line: 12, baseType: !629, size: 8, offset: 192)
!1302 = !DILocalVariable(name: "storage", scope: !1251, file: !2, line: 86, type: !191)
!1303 = distinct !DIAssignID()
!1304 = !DILocation(line: 0, scope: !1251)
!1305 = distinct !DIAssignID()
!1306 = distinct !DIAssignID()
!1307 = !DILocation(line: 79, column: 5, scope: !1251)
!1308 = !DILocation(line: 80, column: 5, scope: !1251)
!1309 = !DILocation(line: 82, column: 5, scope: !1251)
!1310 = !DILocation(line: 86, column: 21, scope: !1251)
!1311 = !{!1312, !1312, i64 0}
!1312 = !{!"any pointer", !1204, i64 0}
!1313 = !DILocation(line: 87, column: 17, scope: !1314)
!1314 = distinct !DILexicalBlock(scope: !1251, file: !2, line: 87, column: 9)
!1315 = !DILocation(line: 87, column: 9, scope: !1251)
!1316 = !DILocation(line: 90, column: 5, scope: !1251)
!1317 = !DILocation(line: 91, column: 30, scope: !1251)
!1318 = !{!1319, !1320, i64 8}
!1319 = !{!"extstore_stats", !1320, i64 0, !1320, i64 8, !1320, i64 16, !1320, i64 24, !1320, i64 32, !1320, i64 40, !1320, i64 48, !1320, i64 56, !1320, i64 64, !1320, i64 72, !1320, i64 80, !1320, i64 88, !1320, i64 96, !1320, i64 104, !1320, i64 112, !1320, i64 120, !1320, i64 128, !1312, i64 136}
!1320 = !{!"long", !1204, i64 0}
!1321 = !DILocation(line: 91, column: 20, scope: !1251)
!1322 = !DILocation(line: 91, column: 8, scope: !1251)
!1323 = !DILocation(line: 91, column: 18, scope: !1251)
!1324 = !{!1319, !1312, i64 136}
!1325 = distinct !DIAssignID()
!1326 = !DILocation(line: 92, column: 5, scope: !1251)
!1327 = !DILocation(line: 94, column: 24, scope: !1328)
!1328 = distinct !DILexicalBlock(scope: !1329, file: !2, line: 94, column: 5)
!1329 = distinct !DILexicalBlock(scope: !1251, file: !2, line: 94, column: 5)
!1330 = !DILocation(line: 94, column: 19, scope: !1328)
!1331 = !DILocation(line: 94, column: 5, scope: !1329)
!1332 = !DILocation(line: 95, column: 9, scope: !1333)
!1333 = distinct !DILexicalBlock(scope: !1328, file: !2, line: 94, column: 41)
!1334 = !{!1335, !1320, i64 0}
!1335 = !{!"extstore_page_data", !1320, i64 0, !1320, i64 8, !1212, i64 16, !1212, i64 20, !1336, i64 24}
!1336 = !{!"_Bool", !1204, i64 0}
!1337 = !DILocation(line: 97, column: 9, scope: !1333)
!1338 = !{!1335, !1320, i64 8}
!1339 = !DILocation(line: 99, column: 9, scope: !1333)
!1340 = !{!1335, !1212, i64 16}
!1341 = !DILocation(line: 101, column: 9, scope: !1333)
!1342 = !{!1335, !1212, i64 20}
!1343 = !DILocation(line: 94, column: 37, scope: !1328)
!1344 = distinct !{!1344, !1331, !1345, !1346}
!1345 = !DILocation(line: 103, column: 5, scope: !1329)
!1346 = !{!"llvm.loop.mustprogress"}
!1347 = !DILocation(line: 105, column: 13, scope: !1251)
!1348 = !DILocation(line: 105, column: 5, scope: !1251)
!1349 = !DILocation(line: 106, column: 1, scope: !1251)
!1350 = !DISubprogram(name: "extstore_get_stats", scope: !182, file: !182, line: 116, type: !1351, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1351 = !DISubroutineType(types: !1352)
!1352 = !{null, !191, !1353}
!1353 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1274, size: 64)
!1354 = !DISubprogram(name: "calloc", scope: !1355, file: !1355, line: 675, type: !1356, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1355 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!1356 = !DISubroutineType(types: !1357)
!1357 = !{!191, !584, !584}
!1358 = !DISubprogram(name: "extstore_get_page_data", scope: !182, file: !182, line: 120, type: !1351, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1359 = !DISubprogram(name: "snprintf", scope: !1360, file: !1360, line: 385, type: !1361, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1360 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "1e435c46987a169d9f9186f63a512303")
!1361 = !DISubroutineType(types: !1362)
!1362 = !{!190, !1363, !584, !1364, null}
!1363 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !193)
!1364 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1258)
!1365 = !DISubprogram(name: "free", scope: !1355, file: !1355, line: 687, type: !1366, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1366 = !DISubroutineType(types: !1367)
!1367 = !{null, !191}
!1368 = distinct !DISubprogram(name: "storage_stats", scope: !2, file: !2, line: 109, type: !1252, scopeLine: 109, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !1369)
!1369 = !{!1370, !1371, !1372}
!1370 = !DILocalVariable(name: "add_stats", arg: 1, scope: !1368, file: !2, line: 109, type: !1254)
!1371 = !DILocalVariable(name: "c", arg: 2, scope: !1368, file: !2, line: 109, type: !191)
!1372 = !DILocalVariable(name: "st", scope: !1368, file: !2, line: 110, type: !1274)
!1373 = distinct !DIAssignID()
!1374 = !DILocation(line: 0, scope: !1368)
!1375 = !DILocation(line: 110, column: 5, scope: !1368)
!1376 = !DILocation(line: 111, column: 9, scope: !1377)
!1377 = distinct !DILexicalBlock(scope: !1368, file: !2, line: 111, column: 9)
!1378 = !DILocation(line: 111, column: 9, scope: !1368)
!1379 = !DILocation(line: 112, column: 9, scope: !1380)
!1380 = distinct !DILexicalBlock(scope: !1377, file: !2, line: 111, column: 22)
!1381 = !DILocation(line: 113, column: 9, scope: !1380)
!1382 = !{!1383, !1320, i64 152}
!1383 = !{!"stats", !1320, i64 0, !1320, i64 8, !1320, i64 16, !1320, i64 24, !1320, i64 32, !1320, i64 40, !1320, i64 48, !1320, i64 56, !1320, i64 64, !1320, i64 72, !1320, i64 80, !1320, i64 88, !1320, i64 96, !1320, i64 104, !1320, i64 112, !1320, i64 120, !1320, i64 128, !1320, i64 136, !1320, i64 144, !1320, i64 152, !1320, i64 160, !1320, i64 168, !1320, i64 176, !1320, i64 184, !1384, i64 192, !1320, i64 208, !1320, i64 216}
!1384 = !{!"timeval", !1320, i64 0, !1320, i64 8}
!1385 = !DILocation(line: 114, column: 9, scope: !1380)
!1386 = !{!1383, !1320, i64 160}
!1387 = !DILocation(line: 115, column: 9, scope: !1380)
!1388 = !{!1383, !1320, i64 176}
!1389 = !DILocation(line: 116, column: 9, scope: !1380)
!1390 = !{!1383, !1320, i64 184}
!1391 = !DILocation(line: 117, column: 9, scope: !1380)
!1392 = !{!1383, !1320, i64 168}
!1393 = !DILocation(line: 118, column: 9, scope: !1380)
!1394 = !DILocation(line: 119, column: 28, scope: !1380)
!1395 = !DILocation(line: 119, column: 9, scope: !1380)
!1396 = !DILocation(line: 120, column: 9, scope: !1380)
!1397 = !{!1319, !1320, i64 0}
!1398 = !DILocation(line: 121, column: 9, scope: !1380)
!1399 = !{!1319, !1320, i64 16}
!1400 = !DILocation(line: 122, column: 9, scope: !1380)
!1401 = !{!1319, !1320, i64 24}
!1402 = !DILocation(line: 123, column: 9, scope: !1380)
!1403 = !{!1319, !1320, i64 40}
!1404 = !DILocation(line: 124, column: 9, scope: !1380)
!1405 = !{!1319, !1320, i64 48}
!1406 = !DILocation(line: 125, column: 9, scope: !1380)
!1407 = !{!1319, !1320, i64 56}
!1408 = !DILocation(line: 126, column: 9, scope: !1380)
!1409 = !{!1319, !1320, i64 64}
!1410 = !DILocation(line: 127, column: 9, scope: !1380)
!1411 = !{!1319, !1320, i64 72}
!1412 = !DILocation(line: 128, column: 9, scope: !1380)
!1413 = !{!1319, !1320, i64 80}
!1414 = !DILocation(line: 129, column: 9, scope: !1380)
!1415 = !{!1319, !1320, i64 88}
!1416 = !DILocation(line: 130, column: 9, scope: !1380)
!1417 = !{!1319, !1320, i64 96}
!1418 = !DILocation(line: 131, column: 9, scope: !1380)
!1419 = !{!1319, !1320, i64 104}
!1420 = !DILocation(line: 132, column: 9, scope: !1380)
!1421 = !{!1319, !1320, i64 112}
!1422 = !DILocation(line: 133, column: 9, scope: !1380)
!1423 = !{!1319, !1320, i64 120}
!1424 = !DILocation(line: 134, column: 9, scope: !1380)
!1425 = !{!1319, !1320, i64 32}
!1426 = !DILocation(line: 135, column: 9, scope: !1380)
!1427 = !{!1319, !1320, i64 128}
!1428 = !DILocation(line: 136, column: 5, scope: !1380)
!1429 = !DILocation(line: 138, column: 1, scope: !1368)
!1430 = !DISubprogram(name: "STATS_LOCK", scope: !113, file: !113, line: 1026, type: !1431, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1431 = !DISubroutineType(types: !1432)
!1432 = !{null}
!1433 = !DISubprogram(name: "append_stat", scope: !113, file: !113, line: 1037, type: !1434, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1434 = !DISubroutineType(types: !1435)
!1435 = !{null, !1258, !1254, !741, !1258, null}
!1436 = !DISubprogram(name: "STATS_UNLOCK", scope: !113, file: !113, line: 1027, type: !1431, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1437 = distinct !DISubprogram(name: "storage_get_item", scope: !2, file: !2, line: 249, type: !1438, scopeLine: 249, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !1440)
!1438 = !DISubroutineType(types: !1439)
!1439 = !{!190, !741, !614, !768}
!1440 = !{!1441, !1442, !1443, !1444, !1445, !1446, !1447, !1448, !1449, !1450, !1453, !1454, !1455, !1458, !1459, !1460}
!1441 = !DILocalVariable(name: "c", arg: 1, scope: !1437, file: !2, line: 249, type: !741)
!1442 = !DILocalVariable(name: "it", arg: 2, scope: !1437, file: !2, line: 249, type: !614)
!1443 = !DILocalVariable(name: "resp", arg: 3, scope: !1437, file: !2, line: 249, type: !768)
!1444 = !DILocalVariable(name: "hdr", scope: !1437, file: !2, line: 254, type: !286)
!1445 = !DILocalVariable(name: "q", scope: !1437, file: !2, line: 256, type: !550)
!1446 = !DILocalVariable(name: "ntotal", scope: !1437, file: !2, line: 257, type: !584)
!1447 = !DILocalVariable(name: "clsid", scope: !1437, file: !2, line: 258, type: !114)
!1448 = !DILocalVariable(name: "new_it", scope: !1437, file: !2, line: 259, type: !614)
!1449 = !DILocalVariable(name: "chunked", scope: !1437, file: !2, line: 260, type: !629)
!1450 = !DILocalVariable(name: "flags", scope: !1451, file: !2, line: 263, type: !296)
!1451 = distinct !DILexicalBlock(scope: !1452, file: !2, line: 261, column: 48)
!1452 = distinct !DILexicalBlock(scope: !1437, file: !2, line: 261, column: 9)
!1453 = !DILocalVariable(name: "p", scope: !1437, file: !2, line: 276, type: !858)
!1454 = !DILocalVariable(name: "eio", scope: !1437, file: !2, line: 291, type: !895)
!1455 = !DILocalVariable(name: "ciovcnt", scope: !1456, file: !2, line: 295, type: !114)
!1456 = distinct !DILexicalBlock(scope: !1457, file: !2, line: 294, column: 18)
!1457 = distinct !DILexicalBlock(scope: !1437, file: !2, line: 294, column: 9)
!1458 = !DILocalVariable(name: "remain", scope: !1456, file: !2, line: 296, type: !584)
!1459 = !DILocalVariable(name: "chunk", scope: !1456, file: !2, line: 297, type: !299)
!1460 = !DILocalVariable(name: "iovtotal", scope: !1437, file: !2, line: 337, type: !190)
!1461 = !DILocation(line: 0, scope: !1437)
!1462 = !DILocation(line: 254, column: 33, scope: !1437)
!1463 = !DILocation(line: 256, column: 21, scope: !1437)
!1464 = !DILocation(line: 257, column: 21, scope: !1437)
!1465 = !DILocation(line: 258, column: 26, scope: !1437)
!1466 = !DILocation(line: 261, column: 27, scope: !1452)
!1467 = !{!1468, !1212, i64 120}
!1468 = !{!"settings", !1320, i64 0, !1212, i64 8, !1212, i64 12, !1212, i64 16, !1312, i64 24, !1212, i64 32, !1212, i64 36, !1212, i64 40, !1312, i64 48, !1312, i64 56, !1212, i64 64, !1469, i64 72, !1212, i64 80, !1212, i64 84, !1212, i64 88, !1204, i64 92, !1212, i64 96, !1212, i64 100, !1336, i64 104, !1212, i64 108, !1212, i64 112, !1212, i64 116, !1212, i64 120, !1212, i64 124, !1212, i64 128, !1336, i64 132, !1336, i64 133, !1336, i64 134, !1336, i64 135, !1336, i64 136, !1336, i64 137, !1212, i64 140, !1469, i64 144, !1212, i64 152, !1212, i64 156, !1336, i64 160, !1212, i64 164, !1336, i64 168, !1336, i64 169, !1312, i64 176, !1212, i64 184, !1212, i64 188, !1212, i64 192, !1212, i64 196, !1469, i64 200, !1469, i64 208, !1212, i64 216, !1336, i64 220, !1212, i64 224, !1212, i64 228, !1212, i64 232, !1212, i64 236, !1212, i64 240, !1336, i64 244, !1336, i64 245, !1336, i64 246, !1212, i64 248, !1212, i64 252, !1212, i64 256, !1212, i64 260, !1212, i64 264, !1212, i64 268, !1212, i64 272, !1212, i64 276, !1212, i64 280, !1212, i64 284, !1469, i64 288, !1469, i64 296, !1336, i64 304, !1212, i64 308, !1212, i64 312, !1312, i64 320, !1212, i64 328}
!1469 = !{!"double", !1204, i64 0}
!1470 = !DILocation(line: 261, column: 18, scope: !1452)
!1471 = !DILocation(line: 261, column: 16, scope: !1452)
!1472 = !DILocation(line: 261, column: 9, scope: !1437)
!1473 = !DILocation(line: 264, column: 9, scope: !1474)
!1474 = distinct !DILexicalBlock(scope: !1475, file: !2, line: 264, column: 9)
!1475 = distinct !DILexicalBlock(scope: !1451, file: !2, line: 264, column: 9)
!1476 = !DILocation(line: 265, column: 47, scope: !1451)
!1477 = !DILocation(line: 264, column: 9, scope: !1475)
!1478 = !DILocation(line: 264, column: 9, scope: !1479)
!1479 = distinct !DILexicalBlock(scope: !1474, file: !2, line: 264, column: 9)
!1480 = !DILocation(line: 0, scope: !1451)
!1481 = !DILocation(line: 265, column: 29, scope: !1451)
!1482 = !DILocation(line: 265, column: 64, scope: !1451)
!1483 = !DILocation(line: 265, column: 77, scope: !1451)
!1484 = !DILocation(line: 265, column: 18, scope: !1451)
!1485 = !DILocation(line: 268, column: 5, scope: !1451)
!1486 = !DILocation(line: 269, column: 18, scope: !1487)
!1487 = distinct !DILexicalBlock(scope: !1452, file: !2, line: 268, column: 12)
!1488 = !DILocation(line: 0, scope: !1452)
!1489 = !DILocation(line: 271, column: 16, scope: !1490)
!1490 = distinct !DILexicalBlock(scope: !1437, file: !2, line: 271, column: 9)
!1491 = !DILocation(line: 271, column: 9, scope: !1437)
!1492 = !DILocation(line: 274, column: 27, scope: !1437)
!1493 = !DILocation(line: 274, column: 13, scope: !1437)
!1494 = !DILocation(line: 274, column: 25, scope: !1437)
!1495 = !DILocation(line: 276, column: 49, scope: !1437)
!1496 = !{!1497, !1312, i64 456}
!1497 = !{!"conn", !1312, i64 0, !1212, i64 8, !1336, i64 12, !1336, i64 13, !1336, i64 14, !1336, i64 15, !1336, i64 16, !1336, i64 17, !1336, i64 18, !1212, i64 20, !1212, i64 24, !1212, i64 28, !1498, i64 32, !1207, i64 160, !1207, i64 162, !1312, i64 168, !1312, i64 176, !1212, i64 184, !1212, i64 188, !1312, i64 192, !1312, i64 200, !1312, i64 208, !1212, i64 216, !1312, i64 224, !1212, i64 232, !1212, i64 236, !1204, i64 240, !1212, i64 312, !1212, i64 316, !1212, i64 320, !1212, i64 324, !1212, i64 328, !1501, i64 332, !1212, i64 360, !1336, i64 364, !1503, i64 368, !1204, i64 392, !1320, i64 416, !1320, i64 424, !1207, i64 432, !1212, i64 436, !1212, i64 440, !1312, i64 448, !1312, i64 456, !1312, i64 464, !1312, i64 472, !1312, i64 480, !1312, i64 488}
!1498 = !{!"event", !1499, i64 0, !1204, i64 40, !1212, i64 56, !1312, i64 64, !1204, i64 72, !1207, i64 104, !1207, i64 106, !1384, i64 112}
!1499 = !{!"event_callback", !1500, i64 0, !1207, i64 16, !1204, i64 18, !1204, i64 19, !1204, i64 24, !1312, i64 32}
!1500 = !{!"", !1312, i64 0, !1312, i64 8}
!1501 = !{!"sockaddr_in6", !1207, i64 0, !1207, i64 2, !1212, i64 4, !1502, i64 8, !1212, i64 24}
!1502 = !{!"in6_addr", !1204, i64 0}
!1503 = !{!"", !1312, i64 0, !1320, i64 8, !1320, i64 16}
!1504 = !DILocation(line: 276, column: 57, scope: !1437)
!1505 = !{!1506, !1312, i64 6896}
!1506 = !{!"", !1320, i64 0, !1312, i64 8, !1507, i64 16, !1507, i64 152, !1204, i64 288, !1508, i64 328, !1212, i64 344, !1212, i64 348, !1509, i64 352, !1204, i64 6800, !1312, i64 6872, !1312, i64 6880, !1312, i64 6888, !1312, i64 6896, !1312, i64 6904, !1312, i64 6912, !1312, i64 6920, !1212, i64 6928}
!1507 = !{!"thread_notify", !1498, i64 0, !1212, i64 128}
!1508 = !{!"iop_head_s", !1312, i64 0, !1312, i64 8}
!1509 = !{!"thread_stats", !1204, i64 0, !1320, i64 40, !1320, i64 48, !1320, i64 56, !1320, i64 64, !1320, i64 72, !1320, i64 80, !1320, i64 88, !1320, i64 96, !1320, i64 104, !1320, i64 112, !1320, i64 120, !1320, i64 128, !1320, i64 136, !1320, i64 144, !1320, i64 152, !1320, i64 160, !1320, i64 168, !1320, i64 176, !1320, i64 184, !1320, i64 192, !1320, i64 200, !1320, i64 208, !1320, i64 216, !1320, i64 224, !1320, i64 232, !1320, i64 240, !1320, i64 248, !1320, i64 256, !1320, i64 264, !1320, i64 272, !1204, i64 280, !1204, i64 4376, !1320, i64 6424, !1320, i64 6432, !1320, i64 6440}
!1510 = !DILocation(line: 276, column: 31, scope: !1437)
!1511 = !DILocation(line: 279, column: 5, scope: !1437)
!1512 = !DILocation(line: 280, column: 8, scope: !1437)
!1513 = !DILocation(line: 280, column: 15, scope: !1437)
!1514 = !{!1515, !1336, i64 135}
!1515 = !{!"_io_pending_storage_t", !1212, i64 0, !1312, i64 8, !1312, i64 16, !1312, i64 24, !1312, i64 32, !1312, i64 40, !1516, i64 48, !1312, i64 56, !1517, i64 64, !1212, i64 128, !1336, i64 132, !1336, i64 133, !1336, i64 134, !1336, i64 135}
!1516 = !{!"", !1312, i64 0}
!1517 = !{!"_obj_io", !1312, i64 0, !1312, i64 8, !1312, i64 16, !1312, i64 24, !1212, i64 32, !1212, i64 36, !1212, i64 40, !1212, i64 44, !1207, i64 48, !1212, i64 52, !1312, i64 56}
!1518 = !DILocation(line: 282, column: 8, scope: !1437)
!1519 = !DILocation(line: 282, column: 15, scope: !1437)
!1520 = !{!1515, !1336, i64 134}
!1521 = !DILocation(line: 283, column: 21, scope: !1437)
!1522 = !{!1497, !1336, i64 364}
!1523 = !{i8 0, i8 2}
!1524 = !{}
!1525 = !DILocation(line: 283, column: 8, scope: !1437)
!1526 = !DILocation(line: 283, column: 16, scope: !1437)
!1527 = !{!1515, !1336, i64 132}
!1528 = !DILocation(line: 284, column: 20, scope: !1437)
!1529 = !DILocation(line: 284, column: 8, scope: !1437)
!1530 = !DILocation(line: 284, column: 15, scope: !1437)
!1531 = !{!1515, !1312, i64 8}
!1532 = !DILocation(line: 285, column: 8, scope: !1437)
!1533 = !DILocation(line: 285, column: 18, scope: !1437)
!1534 = !{!1515, !1312, i64 32}
!1535 = !DILocation(line: 286, column: 8, scope: !1437)
!1536 = !DILocation(line: 286, column: 20, scope: !1437)
!1537 = !{!1515, !1312, i64 40}
!1538 = !DILocation(line: 288, column: 8, scope: !1437)
!1539 = !DILocation(line: 288, column: 15, scope: !1437)
!1540 = !{!1515, !1312, i64 56}
!1541 = !DILocation(line: 289, column: 8, scope: !1437)
!1542 = !DILocation(line: 289, column: 13, scope: !1437)
!1543 = !{!1515, !1312, i64 24}
!1544 = !DILocation(line: 290, column: 22, scope: !1437)
!1545 = !{!1515, !1212, i64 0}
!1546 = !DILocation(line: 291, column: 23, scope: !1437)
!1547 = !DILocation(line: 294, column: 9, scope: !1437)
!1548 = !DILocation(line: 0, scope: !1456)
!1549 = !DILocation(line: 296, column: 33, scope: !1456)
!1550 = !DILocation(line: 297, column: 44, scope: !1456)
!1551 = !DILocation(line: 302, column: 20, scope: !1456)
!1552 = !DILocation(line: 302, column: 14, scope: !1456)
!1553 = !DILocation(line: 302, column: 18, scope: !1456)
!1554 = !{!1517, !1312, i64 24}
!1555 = !DILocation(line: 303, column: 22, scope: !1556)
!1556 = distinct !DILexicalBlock(scope: !1456, file: !2, line: 303, column: 13)
!1557 = !DILocation(line: 303, column: 13, scope: !1456)
!1558 = !DILocation(line: 304, column: 13, scope: !1559)
!1559 = distinct !DILexicalBlock(scope: !1556, file: !2, line: 303, column: 31)
!1560 = !DILocation(line: 305, column: 30, scope: !1559)
!1561 = !DILocation(line: 305, column: 38, scope: !1559)
!1562 = !DILocation(line: 305, column: 13, scope: !1559)
!1563 = !DILocation(line: 306, column: 13, scope: !1559)
!1564 = !DILocation(line: 310, column: 30, scope: !1456)
!1565 = !{!1566, !1312, i64 0}
!1566 = !{!"iovec", !1312, i64 0, !1320, i64 8}
!1567 = !DILocation(line: 311, column: 31, scope: !1456)
!1568 = !DILocation(line: 311, column: 51, scope: !1456)
!1569 = !DILocation(line: 311, column: 21, scope: !1456)
!1570 = !DILocation(line: 311, column: 29, scope: !1456)
!1571 = !{!1566, !1320, i64 8}
!1572 = !DILocation(line: 314, column: 23, scope: !1456)
!1573 = !DILocation(line: 314, column: 9, scope: !1456)
!1574 = !DILocation(line: 296, column: 25, scope: !1456)
!1575 = !DILocation(line: 315, column: 21, scope: !1576)
!1576 = distinct !DILexicalBlock(scope: !1456, file: !2, line: 314, column: 28)
!1577 = !DILocation(line: 317, column: 23, scope: !1578)
!1578 = distinct !DILexicalBlock(scope: !1576, file: !2, line: 317, column: 17)
!1579 = !DILocation(line: 317, column: 31, scope: !1578)
!1580 = !DILocation(line: 318, column: 17, scope: !1581)
!1581 = distinct !DILexicalBlock(scope: !1578, file: !2, line: 317, column: 55)
!1582 = !DILocation(line: 319, column: 27, scope: !1581)
!1583 = !DILocation(line: 319, column: 17, scope: !1581)
!1584 = !DILocation(line: 321, column: 26, scope: !1581)
!1585 = !DILocation(line: 322, column: 34, scope: !1581)
!1586 = !DILocation(line: 322, column: 42, scope: !1581)
!1587 = !DILocation(line: 322, column: 17, scope: !1581)
!1588 = !DILocation(line: 323, column: 17, scope: !1581)
!1589 = !DILocation(line: 325, column: 49, scope: !1576)
!1590 = !DILocation(line: 325, column: 18, scope: !1576)
!1591 = !DILocation(line: 325, column: 13, scope: !1576)
!1592 = !DILocation(line: 325, column: 40, scope: !1576)
!1593 = !DILocation(line: 326, column: 58, scope: !1576)
!1594 = !DILocation(line: 326, column: 51, scope: !1576)
!1595 = !DILocation(line: 326, column: 41, scope: !1576)
!1596 = !DILocation(line: 326, column: 31, scope: !1576)
!1597 = !DILocation(line: 326, column: 39, scope: !1576)
!1598 = !DILocation(line: 327, column: 27, scope: !1576)
!1599 = !DILocation(line: 327, column: 20, scope: !1576)
!1600 = !DILocation(line: 327, column: 25, scope: !1576)
!1601 = !DILocation(line: 328, column: 20, scope: !1576)
!1602 = !DILocation(line: 329, column: 20, scope: !1576)
!1603 = distinct !{!1603, !1573, !1604, !1346}
!1604 = !DILocation(line: 330, column: 9, scope: !1456)
!1605 = !DILocation(line: 332, column: 14, scope: !1456)
!1606 = !DILocation(line: 332, column: 21, scope: !1456)
!1607 = !{!1517, !1212, i64 32}
!1608 = !DILocation(line: 336, column: 27, scope: !1437)
!1609 = !{!1610, !1204, i64 116}
!1610 = !{!"_mc_resp", !1312, i64 0, !1312, i64 8, !1212, i64 16, !1212, i64 20, !1312, i64 24, !1312, i64 32, !1312, i64 40, !1204, i64 48, !1212, i64 112, !1204, i64 116, !1204, i64 117, !1336, i64 118, !1336, i64 119, !1207, i64 120, !1207, i64 122, !1207, i64 124, !1501, i64 128, !1212, i64 156, !1204, i64 160}
!1611 = !DILocation(line: 336, column: 21, scope: !1437)
!1612 = !DILocation(line: 336, column: 8, scope: !1437)
!1613 = !DILocation(line: 336, column: 19, scope: !1437)
!1614 = !{!1515, !1212, i64 128}
!1615 = !DILocation(line: 337, column: 24, scope: !1437)
!1616 = !{!1497, !1212, i64 316}
!1617 = !DILocation(line: 337, column: 33, scope: !1437)
!1618 = !DILocation(line: 337, scope: !1437)
!1619 = !DILocation(line: 337, column: 20, scope: !1437)
!1620 = !DILocation(line: 338, column: 9, scope: !1437)
!1621 = !DILocation(line: 339, column: 9, scope: !1622)
!1622 = distinct !DILexicalBlock(scope: !1623, file: !2, line: 338, column: 18)
!1623 = distinct !DILexicalBlock(scope: !1437, file: !2, line: 338, column: 9)
!1624 = !DILocation(line: 340, column: 5, scope: !1622)
!1625 = !DILocation(line: 341, column: 9, scope: !1626)
!1626 = distinct !DILexicalBlock(scope: !1623, file: !2, line: 340, column: 12)
!1627 = !DILocation(line: 345, column: 11, scope: !1437)
!1628 = !DILocation(line: 345, column: 22, scope: !1437)
!1629 = !{!1610, !1312, i64 32}
!1630 = !DILocation(line: 347, column: 10, scope: !1437)
!1631 = !DILocation(line: 347, column: 14, scope: !1437)
!1632 = !{!1517, !1312, i64 16}
!1633 = !DILocation(line: 348, column: 8, scope: !1437)
!1634 = !DILocation(line: 348, column: 10, scope: !1437)
!1635 = !{!1515, !1312, i64 16}
!1636 = !DILocation(line: 351, column: 20, scope: !1437)
!1637 = !{!1638, !1312, i64 8}
!1638 = !{!"io_queue_s", !1312, i64 0, !1312, i64 8, !1212, i64 16, !1212, i64 20}
!1639 = !DILocation(line: 351, column: 10, scope: !1437)
!1640 = !DILocation(line: 351, column: 15, scope: !1437)
!1641 = !{!1517, !1312, i64 8}
!1642 = !DILocation(line: 352, column: 18, scope: !1437)
!1643 = !DILocation(line: 356, column: 8, scope: !1437)
!1644 = !DILocation(line: 356, column: 13, scope: !1437)
!1645 = !{!1638, !1212, i64 16}
!1646 = !DILocation(line: 358, column: 15, scope: !1437)
!1647 = !{!1517, !1312, i64 0}
!1648 = !DILocation(line: 366, column: 30, scope: !1437)
!1649 = !DILocation(line: 366, column: 10, scope: !1437)
!1650 = !DILocation(line: 366, column: 23, scope: !1437)
!1651 = !{!1517, !1212, i64 36}
!1652 = !DILocation(line: 367, column: 25, scope: !1437)
!1653 = !DILocation(line: 367, column: 10, scope: !1437)
!1654 = !DILocation(line: 367, column: 18, scope: !1437)
!1655 = !{!1517, !1207, i64 48}
!1656 = !DILocation(line: 368, column: 24, scope: !1437)
!1657 = !{!1211, !1212, i64 4}
!1658 = !DILocation(line: 368, column: 10, scope: !1437)
!1659 = !DILocation(line: 368, column: 17, scope: !1437)
!1660 = !{!1517, !1212, i64 44}
!1661 = !DILocation(line: 370, column: 16, scope: !1437)
!1662 = !DILocation(line: 370, column: 10, scope: !1437)
!1663 = !DILocation(line: 370, column: 14, scope: !1437)
!1664 = !{!1517, !1212, i64 40}
!1665 = !DILocation(line: 371, column: 10, scope: !1437)
!1666 = !DILocation(line: 371, column: 15, scope: !1437)
!1667 = !{!1517, !1212, i64 52}
!1668 = !DILocation(line: 372, column: 10, scope: !1437)
!1669 = !DILocation(line: 372, column: 13, scope: !1437)
!1670 = !{!1517, !1312, i64 56}
!1671 = !DILocation(line: 377, column: 28, scope: !1437)
!1672 = !DILocation(line: 377, column: 36, scope: !1437)
!1673 = !DILocation(line: 377, column: 5, scope: !1437)
!1674 = !DILocation(line: 378, column: 8, scope: !1437)
!1675 = !DILocation(line: 378, column: 22, scope: !1437)
!1676 = !DILocation(line: 378, column: 34, scope: !1437)
!1677 = !{!1506, !1320, i64 584}
!1678 = !DILocation(line: 379, column: 38, scope: !1437)
!1679 = !DILocation(line: 379, column: 5, scope: !1437)
!1680 = !DILocation(line: 382, column: 1, scope: !1437)
!1681 = !DISubprogram(name: "conn_io_queue_get", scope: !113, file: !113, line: 960, type: !1682, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1682 = !DISubroutineType(types: !1683)
!1683 = !{!550, !741, !190}
!1684 = !DISubprogram(name: "slabs_clsid", scope: !1685, file: !1685, line: 21, type: !1686, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1685 = !DIFile(filename: "./slabs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "28867aba1f41c79140864d76faedcb32")
!1686 = !DISubroutineType(types: !1687)
!1687 = !{!114, !1688}
!1688 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !584)
!1689 = !DISubprogram(name: "item_alloc", scope: !113, file: !113, line: 1006, type: !1690, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1690 = !DISubroutineType(types: !1691)
!1691 = !{!614, !1258, !584, !296, !314, !190}
!1692 = !DISubprogram(name: "do_item_alloc_pull", scope: !1693, file: !1693, line: 16, type: !1694, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1693 = !DIFile(filename: "./items.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "5548db7354621bc680fd5812e10230ba")
!1694 = !DISubroutineType(types: !1695)
!1695 = !{!614, !1688, !1696}
!1696 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !114)
!1697 = !DISubprogram(name: "do_cache_alloc", scope: !565, file: !565, line: 79, type: !1698, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1698 = !DISubroutineType(types: !1699)
!1699 = !{!191, !563}
!1700 = distinct !DISubprogram(name: "storage_return_cb", scope: !2, file: !2, line: 467, type: !847, scopeLine: 467, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !1701)
!1701 = !{!1702, !1703}
!1702 = !DILocalVariable(name: "pending", arg: 1, scope: !1700, file: !2, line: 467, type: !343)
!1703 = !DILocalVariable(name: "q", scope: !1700, file: !2, line: 468, type: !550)
!1704 = !DILocation(line: 0, scope: !1700)
!1705 = !DILocation(line: 468, column: 48, scope: !1700)
!1706 = !{!1707, !1312, i64 16}
!1707 = !{!"_io_pending_t", !1212, i64 0, !1312, i64 8, !1312, i64 16, !1312, i64 24, !1312, i64 32, !1312, i64 40, !1516, i64 48, !1204, i64 56}
!1708 = !DILocation(line: 468, column: 60, scope: !1700)
!1709 = !{!1707, !1212, i64 0}
!1710 = !DILocation(line: 468, column: 21, scope: !1700)
!1711 = !DILocation(line: 469, column: 8, scope: !1700)
!1712 = !DILocation(line: 469, column: 13, scope: !1700)
!1713 = !DILocation(line: 470, column: 18, scope: !1714)
!1714 = distinct !DILexicalBlock(scope: !1700, file: !2, line: 470, column: 9)
!1715 = !DILocation(line: 470, column: 9, scope: !1700)
!1716 = !DILocation(line: 471, column: 36, scope: !1717)
!1717 = distinct !DILexicalBlock(scope: !1714, file: !2, line: 470, column: 24)
!1718 = !DILocation(line: 471, column: 9, scope: !1717)
!1719 = !DILocation(line: 472, column: 5, scope: !1717)
!1720 = !DILocation(line: 473, column: 1, scope: !1700)
!1721 = distinct !DISubprogram(name: "storage_finalize_cb", scope: !2, file: !2, line: 476, type: !847, scopeLine: 476, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !1722)
!1722 = !{!1723, !1724, !1725}
!1723 = !DILocalVariable(name: "pending", arg: 1, scope: !1721, file: !2, line: 476, type: !343)
!1724 = !DILocalVariable(name: "p", scope: !1721, file: !2, line: 478, type: !858)
!1725 = !DILocalVariable(name: "io", scope: !1721, file: !2, line: 479, type: !895)
!1726 = !DILocation(line: 0, scope: !1721)
!1727 = !DILocalVariable(name: "pending", arg: 1, scope: !1728, file: !2, line: 393, type: !343)
!1728 = distinct !DISubprogram(name: "recache_or_free", scope: !2, file: !2, line: 393, type: !847, scopeLine: 393, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !1729)
!1729 = !{!1727, !1730, !1731, !1732, !1733, !1734, !1735, !1738, !1739, !1742, !1745, !1746, !1749}
!1730 = !DILocalVariable(name: "p", scope: !1728, file: !2, line: 395, type: !858)
!1731 = !DILocalVariable(name: "c", scope: !1728, file: !2, line: 397, type: !741)
!1732 = !DILocalVariable(name: "io", scope: !1728, file: !2, line: 398, type: !895)
!1733 = !DILocalVariable(name: "it", scope: !1728, file: !2, line: 400, type: !614)
!1734 = !DILocalVariable(name: "do_free", scope: !1728, file: !2, line: 402, type: !629)
!1735 = !DILocalVariable(name: "ntotal", scope: !1736, file: !2, line: 407, type: !584)
!1736 = distinct !DILexicalBlock(scope: !1737, file: !2, line: 403, column: 20)
!1737 = distinct !DILexicalBlock(scope: !1728, file: !2, line: 403, column: 9)
!1738 = !DILocalVariable(name: "q", scope: !1736, file: !2, line: 410, type: !550)
!1739 = !DILocalVariable(name: "ntotal", scope: !1740, file: !2, line: 419, type: !584)
!1740 = distinct !DILexicalBlock(scope: !1741, file: !2, line: 416, column: 25)
!1741 = distinct !DILexicalBlock(scope: !1737, file: !2, line: 416, column: 16)
!1742 = !DILocalVariable(name: "hv", scope: !1743, file: !2, line: 429, type: !297)
!1743 = distinct !DILexicalBlock(scope: !1744, file: !2, line: 427, column: 43)
!1744 = distinct !DILexicalBlock(scope: !1741, file: !2, line: 427, column: 16)
!1745 = !DILocalVariable(name: "hold_lock", scope: !1743, file: !2, line: 431, type: !191)
!1746 = !DILocalVariable(name: "h_it", scope: !1747, file: !2, line: 433, type: !614)
!1747 = distinct !DILexicalBlock(scope: !1748, file: !2, line: 432, column: 32)
!1748 = distinct !DILexicalBlock(scope: !1743, file: !2, line: 432, column: 13)
!1749 = !DILocalVariable(name: "flags", scope: !1747, file: !2, line: 434, type: !322)
!1750 = !DILocation(line: 0, scope: !1728, inlinedAt: !1751)
!1751 = distinct !DILocation(line: 477, column: 5, scope: !1721)
!1752 = !DILocation(line: 397, column: 18, scope: !1728, inlinedAt: !1751)
!1753 = !DILocation(line: 400, column: 28, scope: !1728, inlinedAt: !1751)
!1754 = !DILocation(line: 403, column: 12, scope: !1737, inlinedAt: !1751)
!1755 = !DILocation(line: 403, column: 9, scope: !1728, inlinedAt: !1751)
!1756 = !DILocation(line: 407, column: 25, scope: !1736, inlinedAt: !1751)
!1757 = !DILocation(line: 0, scope: !1736, inlinedAt: !1751)
!1758 = !DILocation(line: 408, column: 32, scope: !1736, inlinedAt: !1751)
!1759 = !DILocation(line: 408, column: 9, scope: !1736, inlinedAt: !1751)
!1760 = !DILocation(line: 410, column: 49, scope: !1736, inlinedAt: !1751)
!1761 = !DILocation(line: 410, column: 25, scope: !1736, inlinedAt: !1751)
!1762 = !DILocation(line: 411, column: 12, scope: !1736, inlinedAt: !1751)
!1763 = !DILocation(line: 411, column: 17, scope: !1736, inlinedAt: !1751)
!1764 = !DILocation(line: 413, column: 32, scope: !1736, inlinedAt: !1751)
!1765 = !DILocation(line: 413, column: 40, scope: !1736, inlinedAt: !1751)
!1766 = !DILocation(line: 413, column: 9, scope: !1736, inlinedAt: !1751)
!1767 = !DILocation(line: 414, column: 12, scope: !1736, inlinedAt: !1751)
!1768 = !DILocation(line: 414, column: 26, scope: !1736, inlinedAt: !1751)
!1769 = !DILocation(line: 414, column: 46, scope: !1736, inlinedAt: !1751)
!1770 = !{!1506, !1320, i64 592}
!1771 = !DILocation(line: 415, column: 42, scope: !1736, inlinedAt: !1751)
!1772 = !DILocation(line: 415, column: 9, scope: !1736, inlinedAt: !1751)
!1773 = !DILocation(line: 416, column: 5, scope: !1736, inlinedAt: !1751)
!1774 = !DILocation(line: 416, column: 19, scope: !1741, inlinedAt: !1751)
!1775 = !{!1515, !1336, i64 133}
!1776 = !DILocation(line: 416, column: 16, scope: !1737, inlinedAt: !1751)
!1777 = !DILocation(line: 419, column: 25, scope: !1740, inlinedAt: !1751)
!1778 = !DILocation(line: 0, scope: !1740, inlinedAt: !1751)
!1779 = !DILocation(line: 420, column: 9, scope: !1740, inlinedAt: !1751)
!1780 = !DILocation(line: 421, column: 32, scope: !1740, inlinedAt: !1751)
!1781 = !DILocation(line: 421, column: 9, scope: !1740, inlinedAt: !1751)
!1782 = !DILocation(line: 422, column: 32, scope: !1740, inlinedAt: !1751)
!1783 = !DILocation(line: 422, column: 40, scope: !1740, inlinedAt: !1751)
!1784 = !DILocation(line: 422, column: 9, scope: !1740, inlinedAt: !1751)
!1785 = !DILocation(line: 423, column: 12, scope: !1740, inlinedAt: !1751)
!1786 = !DILocation(line: 423, column: 26, scope: !1740, inlinedAt: !1751)
!1787 = !DILocation(line: 423, column: 44, scope: !1740, inlinedAt: !1751)
!1788 = !{!1506, !1320, i64 616}
!1789 = !DILocation(line: 424, column: 16, scope: !1790, inlinedAt: !1751)
!1790 = distinct !DILexicalBlock(scope: !1740, file: !2, line: 424, column: 13)
!1791 = !DILocation(line: 424, column: 13, scope: !1740, inlinedAt: !1751)
!1792 = !DILocation(line: 425, column: 30, scope: !1790, inlinedAt: !1751)
!1793 = !DILocation(line: 425, column: 50, scope: !1790, inlinedAt: !1751)
!1794 = !{!1506, !1320, i64 624}
!1795 = !DILocation(line: 425, column: 13, scope: !1790, inlinedAt: !1751)
!1796 = !DILocation(line: 426, column: 42, scope: !1740, inlinedAt: !1751)
!1797 = !DILocation(line: 426, column: 9, scope: !1740, inlinedAt: !1751)
!1798 = !DILocation(line: 427, column: 5, scope: !1740, inlinedAt: !1751)
!1799 = !DILocation(line: 427, column: 25, scope: !1744, inlinedAt: !1751)
!1800 = !{!1468, !1212, i64 268}
!1801 = !DILocation(line: 427, column: 16, scope: !1744, inlinedAt: !1751)
!1802 = !DILocation(line: 427, column: 16, scope: !1741, inlinedAt: !1751)
!1803 = !DILocation(line: 429, column: 37, scope: !1743, inlinedAt: !1751)
!1804 = !DILocation(line: 0, scope: !1743, inlinedAt: !1751)
!1805 = !DILocation(line: 431, column: 27, scope: !1743, inlinedAt: !1751)
!1806 = !DILocation(line: 432, column: 23, scope: !1748, inlinedAt: !1751)
!1807 = !DILocation(line: 432, column: 13, scope: !1743, inlinedAt: !1751)
!1808 = !DILocation(line: 433, column: 29, scope: !1747, inlinedAt: !1751)
!1809 = !DILocation(line: 0, scope: !1747, inlinedAt: !1751)
!1810 = !DILocation(line: 436, column: 25, scope: !1811, inlinedAt: !1751)
!1811 = distinct !DILexicalBlock(scope: !1747, file: !2, line: 436, column: 17)
!1812 = !DILocation(line: 436, column: 34, scope: !1811, inlinedAt: !1751)
!1813 = !DILocation(line: 436, column: 43, scope: !1811, inlinedAt: !1751)
!1814 = !DILocation(line: 436, column: 53, scope: !1811, inlinedAt: !1751)
!1815 = !DILocation(line: 437, column: 27, scope: !1811, inlinedAt: !1751)
!1816 = !DILocation(line: 437, column: 34, scope: !1811, inlinedAt: !1751)
!1817 = !DILocation(line: 437, column: 47, scope: !1811, inlinedAt: !1751)
!1818 = !DILocation(line: 437, column: 32, scope: !1811, inlinedAt: !1751)
!1819 = !DILocation(line: 437, column: 70, scope: !1811, inlinedAt: !1751)
!1820 = !DILocation(line: 438, column: 24, scope: !1811, inlinedAt: !1751)
!1821 = !DILocation(line: 438, column: 39, scope: !1811, inlinedAt: !1751)
!1822 = !{!1497, !1212, i64 312}
!1823 = !DILocation(line: 438, column: 53, scope: !1811, inlinedAt: !1751)
!1824 = !DILocation(line: 438, column: 42, scope: !1811, inlinedAt: !1751)
!1825 = !DILocation(line: 438, column: 70, scope: !1811, inlinedAt: !1751)
!1826 = !DILocation(line: 436, column: 17, scope: !1747, inlinedAt: !1751)
!1827 = !DILocation(line: 441, column: 37, scope: !1828, inlinedAt: !1751)
!1828 = distinct !DILexicalBlock(scope: !1811, file: !2, line: 438, column: 76)
!1829 = !DILocation(line: 441, column: 21, scope: !1828, inlinedAt: !1751)
!1830 = !DILocation(line: 441, column: 29, scope: !1828, inlinedAt: !1751)
!1831 = !DILocation(line: 442, column: 21, scope: !1828, inlinedAt: !1751)
!1832 = !DILocation(line: 442, column: 30, scope: !1828, inlinedAt: !1751)
!1833 = !DILocation(line: 443, column: 21, scope: !1828, inlinedAt: !1751)
!1834 = !DILocation(line: 443, column: 30, scope: !1828, inlinedAt: !1751)
!1835 = !DILocation(line: 444, column: 21, scope: !1828, inlinedAt: !1751)
!1836 = !DILocation(line: 444, column: 28, scope: !1828, inlinedAt: !1751)
!1837 = !DILocation(line: 445, column: 17, scope: !1838, inlinedAt: !1751)
!1838 = distinct !DILexicalBlock(scope: !1828, file: !2, line: 445, column: 17)
!1839 = !{!1506, !1312, i64 6904}
!1840 = !DILocation(line: 446, column: 44, scope: !1828, inlinedAt: !1751)
!1841 = !DILocation(line: 453, column: 13, scope: !1842, inlinedAt: !1751)
!1842 = distinct !DILexicalBlock(scope: !1743, file: !2, line: 452, column: 13)
!1843 = !DILocation(line: 455, column: 9, scope: !1728, inlinedAt: !1751)
!1844 = !DILocation(line: 446, column: 17, scope: !1828, inlinedAt: !1751)
!1845 = !DILocation(line: 447, column: 40, scope: !1828, inlinedAt: !1751)
!1846 = !DILocation(line: 447, column: 48, scope: !1828, inlinedAt: !1751)
!1847 = !DILocation(line: 447, column: 17, scope: !1828, inlinedAt: !1751)
!1848 = !DILocation(line: 448, column: 20, scope: !1828, inlinedAt: !1751)
!1849 = !DILocation(line: 448, column: 34, scope: !1828, inlinedAt: !1751)
!1850 = !DILocation(line: 448, column: 55, scope: !1828, inlinedAt: !1751)
!1851 = !{!1506, !1320, i64 608}
!1852 = !DILocation(line: 449, column: 50, scope: !1828, inlinedAt: !1751)
!1853 = !DILocation(line: 449, column: 17, scope: !1828, inlinedAt: !1751)
!1854 = !DILocation(line: 456, column: 24, scope: !1855, inlinedAt: !1751)
!1855 = distinct !DILexicalBlock(scope: !1728, file: !2, line: 455, column: 9)
!1856 = !DILocation(line: 456, column: 41, scope: !1855, inlinedAt: !1751)
!1857 = !DILocation(line: 456, column: 9, scope: !1855, inlinedAt: !1751)
!1858 = !DILocation(line: 459, column: 15, scope: !1728, inlinedAt: !1751)
!1859 = !DILocation(line: 460, column: 15, scope: !1728, inlinedAt: !1751)
!1860 = !DILocation(line: 463, column: 20, scope: !1728, inlinedAt: !1751)
!1861 = !DILocation(line: 459, column: 20, scope: !1728, inlinedAt: !1751)
!1862 = !DILocation(line: 463, column: 5, scope: !1728, inlinedAt: !1751)
!1863 = !DILocation(line: 481, column: 13, scope: !1864)
!1864 = distinct !DILexicalBlock(scope: !1721, file: !2, line: 481, column: 9)
!1865 = !DILocation(line: 481, column: 9, scope: !1864)
!1866 = !DILocation(line: 481, column: 9, scope: !1721)
!1867 = !DILocation(line: 482, column: 9, scope: !1868)
!1868 = distinct !DILexicalBlock(scope: !1864, file: !2, line: 481, column: 18)
!1869 = !DILocation(line: 483, column: 17, scope: !1868)
!1870 = !DILocation(line: 484, column: 5, scope: !1868)
!1871 = !DILocation(line: 486, column: 1, scope: !1721)
!1872 = !DISubprogram(name: "malloc", scope: !1355, file: !1355, line: 672, type: !1873, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1873 = !DISubroutineType(types: !1874)
!1874 = !{!191, !584}
!1875 = !DISubprogram(name: "item_remove", scope: !113, file: !113, line: 1013, type: !1876, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1876 = !DISubroutineType(types: !1877)
!1877 = !{null, !614}
!1878 = !DISubprogram(name: "do_cache_free", scope: !565, file: !565, line: 90, type: !1879, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1879 = !DISubroutineType(types: !1880)
!1880 = !{null, !563, !191}
!1881 = !DISubprogram(name: "do_item_alloc_chunk", scope: !1693, file: !1693, line: 15, type: !1882, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1882 = !DISubroutineType(types: !1883)
!1883 = !{!299, !299, !1688}
!1884 = !DISubprogram(name: "resp_add_chunked_iov", scope: !113, file: !113, line: 1056, type: !1885, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1885 = !DISubroutineType(types: !1886)
!1886 = !{null, !768, !723, !190}
!1887 = !DISubprogram(name: "resp_add_iov", scope: !113, file: !113, line: 1055, type: !1885, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1888 = distinct !DISubprogram(name: "_storage_get_item_cb", scope: !2, file: !2, line: 144, type: !893, scopeLine: 144, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !1889)
!1889 = !{!1890, !1891, !1892, !1893, !1894, !1895, !1896, !1897, !1898, !1901, !1902, !1903, !1910, !1911, !1912}
!1890 = !DILocalVariable(name: "e", arg: 1, scope: !1888, file: !2, line: 144, type: !191)
!1891 = !DILocalVariable(name: "io", arg: 2, scope: !1888, file: !2, line: 144, type: !895)
!1892 = !DILocalVariable(name: "ret", arg: 3, scope: !1888, file: !2, line: 144, type: !190)
!1893 = !DILocalVariable(name: "p", scope: !1888, file: !2, line: 146, type: !858)
!1894 = !DILocalVariable(name: "resp", scope: !1888, file: !2, line: 147, type: !768)
!1895 = !DILocalVariable(name: "c", scope: !1888, file: !2, line: 148, type: !741)
!1896 = !DILocalVariable(name: "read_it", scope: !1888, file: !2, line: 150, type: !614)
!1897 = !DILocalVariable(name: "miss", scope: !1888, file: !2, line: 151, type: !629)
!1898 = !DILocalVariable(name: "crc2", scope: !1899, file: !2, line: 157, type: !297)
!1899 = distinct !DILexicalBlock(scope: !1900, file: !2, line: 156, column: 12)
!1900 = distinct !DILexicalBlock(scope: !1888, file: !2, line: 154, column: 9)
!1901 = !DILocalVariable(name: "crc", scope: !1899, file: !2, line: 158, type: !297)
!1902 = !DILocalVariable(name: "x", scope: !1899, file: !2, line: 159, type: !190)
!1903 = !DILocalVariable(name: "header", scope: !1904, file: !2, line: 190, type: !901)
!1904 = distinct !DILexicalBlock(scope: !1905, file: !2, line: 189, column: 45)
!1905 = distinct !DILexicalBlock(scope: !1906, file: !2, line: 189, column: 17)
!1906 = distinct !DILexicalBlock(scope: !1907, file: !2, line: 183, column: 16)
!1907 = distinct !DILexicalBlock(scope: !1908, file: !2, line: 180, column: 13)
!1908 = distinct !DILexicalBlock(scope: !1909, file: !2, line: 179, column: 15)
!1909 = distinct !DILexicalBlock(scope: !1888, file: !2, line: 179, column: 9)
!1910 = !DILocalVariable(name: "body_len", scope: !1904, file: !2, line: 194, type: !297)
!1911 = !DILocalVariable(name: "hdr_len", scope: !1904, file: !2, line: 195, type: !322)
!1912 = !DILocalVariable(name: "i", scope: !1913, file: !2, line: 208, type: !190)
!1913 = distinct !DILexicalBlock(scope: !1905, file: !2, line: 207, column: 20)
!1914 = !DILocation(line: 0, scope: !1888)
!1915 = !DILocation(line: 146, column: 59, scope: !1888)
!1916 = !DILocation(line: 147, column: 24, scope: !1888)
!1917 = !DILocation(line: 148, column: 18, scope: !1888)
!1918 = !DILocation(line: 150, column: 33, scope: !1888)
!1919 = !DILocation(line: 154, column: 13, scope: !1900)
!1920 = !DILocation(line: 154, column: 9, scope: !1888)
!1921 = !DILocation(line: 158, column: 44, scope: !1899)
!1922 = !DILocation(line: 0, scope: !1899)
!1923 = !DILocation(line: 161, column: 17, scope: !1924)
!1924 = distinct !DILexicalBlock(scope: !1899, file: !2, line: 161, column: 13)
!1925 = !DILocation(line: 161, column: 21, scope: !1924)
!1926 = !DILocation(line: 0, scope: !1924)
!1927 = !DILocation(line: 161, column: 13, scope: !1899)
!1928 = !DILocation(line: 163, column: 49, scope: !1929)
!1929 = distinct !DILexicalBlock(scope: !1924, file: !2, line: 161, column: 30)
!1930 = !DILocation(line: 163, column: 57, scope: !1929)
!1931 = !DILocation(line: 163, column: 83, scope: !1929)
!1932 = !DILocation(line: 163, column: 90, scope: !1929)
!1933 = !DILocation(line: 163, column: 20, scope: !1929)
!1934 = !DILocation(line: 165, column: 17, scope: !1929)
!1935 = !DILocation(line: 165, column: 24, scope: !1929)
!1936 = !DILocation(line: 165, column: 32, scope: !1929)
!1937 = !DILocation(line: 166, column: 33, scope: !1938)
!1938 = distinct !DILexicalBlock(scope: !1939, file: !2, line: 166, column: 13)
!1939 = distinct !DILexicalBlock(scope: !1929, file: !2, line: 166, column: 13)
!1940 = !DILocation(line: 166, column: 27, scope: !1938)
!1941 = !DILocation(line: 166, column: 13, scope: !1939)
!1942 = !DILocation(line: 167, column: 24, scope: !1943)
!1943 = distinct !DILexicalBlock(scope: !1938, file: !2, line: 166, column: 46)
!1944 = !DILocation(line: 167, column: 49, scope: !1943)
!1945 = !DILocation(line: 167, column: 45, scope: !1943)
!1946 = !DILocation(line: 167, column: 56, scope: !1943)
!1947 = !DILocation(line: 167, column: 77, scope: !1943)
!1948 = !DILocation(line: 166, column: 42, scope: !1938)
!1949 = distinct !{!1949, !1941, !1950, !1346}
!1950 = !DILocation(line: 168, column: 13, scope: !1939)
!1951 = !DILocation(line: 170, column: 45, scope: !1952)
!1952 = distinct !DILexicalBlock(scope: !1924, file: !2, line: 169, column: 16)
!1953 = !DILocation(line: 170, column: 64, scope: !1952)
!1954 = !DILocation(line: 170, column: 60, scope: !1952)
!1955 = !DILocation(line: 170, column: 67, scope: !1952)
!1956 = !DILocation(line: 170, column: 20, scope: !1952)
!1957 = !DILocation(line: 173, column: 17, scope: !1958)
!1958 = distinct !DILexicalBlock(scope: !1899, file: !2, line: 173, column: 13)
!1959 = !DILocation(line: 173, column: 13, scope: !1899)
!1960 = !DILocation(line: 175, column: 16, scope: !1961)
!1961 = distinct !DILexicalBlock(scope: !1958, file: !2, line: 173, column: 26)
!1962 = !DILocation(line: 175, column: 23, scope: !1961)
!1963 = !DILocation(line: 179, column: 9, scope: !1888)
!1964 = !DILocation(line: 180, column: 16, scope: !1907)
!1965 = !DILocation(line: 180, column: 13, scope: !1908)
!1966 = !DILocation(line: 182, column: 19, scope: !1967)
!1967 = distinct !DILexicalBlock(scope: !1907, file: !2, line: 180, column: 25)
!1968 = !DILocation(line: 182, column: 24, scope: !1967)
!1969 = !{!1610, !1336, i64 118}
!1970 = !DILocation(line: 183, column: 9, scope: !1967)
!1971 = !DILocation(line: 189, column: 20, scope: !1905)
!1972 = !DILocation(line: 189, column: 29, scope: !1905)
!1973 = !DILocation(line: 189, column: 17, scope: !1906)
!1974 = !DILocation(line: 0, scope: !1904)
!1975 = !DILocation(line: 194, column: 37, scope: !1904)
!1976 = !DILocalVariable(name: "__bsx", arg: 1, scope: !1977, file: !1978, line: 49, type: !298)
!1977 = distinct !DISubprogram(name: "__bswap_32", scope: !1978, file: !1978, line: 49, type: !1979, scopeLine: 50, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !1981)
!1978 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/byteswap.h", directory: "", checksumkind: CSK_MD5, checksum: "913dc950710c6a0e67c840bea7ac0f08")
!1979 = !DISubroutineType(types: !1980)
!1980 = !{!298, !298}
!1981 = !{!1976}
!1982 = !DILocation(line: 0, scope: !1977, inlinedAt: !1983)
!1983 = distinct !DILocation(line: 194, column: 37, scope: !1904)
!1984 = !DILocation(line: 54, column: 10, scope: !1977, inlinedAt: !1983)
!1985 = !DILocation(line: 195, column: 52, scope: !1904)
!1986 = !DILocation(line: 196, column: 35, scope: !1904)
!1987 = !DILocation(line: 196, column: 42, scope: !1904)
!1988 = !DILocation(line: 196, column: 29, scope: !1904)
!1989 = !DILocation(line: 196, column: 54, scope: !1904)
!1990 = !DILocation(line: 196, column: 64, scope: !1904)
!1991 = !DILocation(line: 196, column: 62, scope: !1904)
!1992 = !DILocation(line: 196, column: 26, scope: !1904)
!1993 = !DILocation(line: 197, column: 23, scope: !1904)
!1994 = !DILocation(line: 197, column: 30, scope: !1904)
!1995 = !{!1610, !1212, i64 20}
!1996 = !DILocation(line: 198, column: 41, scope: !1904)
!1997 = !DILocation(line: 199, column: 34, scope: !1904)
!1998 = !DILocation(line: 199, column: 41, scope: !1904)
!1999 = !DILocation(line: 0, scope: !1977, inlinedAt: !2000)
!2000 = distinct !DILocation(line: 200, column: 44, scope: !1904)
!2001 = !DILocation(line: 54, column: 10, scope: !1977, inlinedAt: !2000)
!2002 = !DILocation(line: 200, column: 42, scope: !1904)
!2003 = !DILocation(line: 203, column: 30, scope: !1904)
!2004 = !DILocation(line: 203, column: 17, scope: !1904)
!2005 = !DILocation(line: 203, column: 42, scope: !1904)
!2006 = !DILocation(line: 203, column: 50, scope: !1904)
!2007 = !DILocation(line: 205, column: 40, scope: !1904)
!2008 = !DILocation(line: 205, column: 17, scope: !1904)
!2009 = !DILocation(line: 205, column: 44, scope: !1904)
!2010 = !DILocation(line: 205, column: 52, scope: !1904)
!2011 = !DILocation(line: 206, column: 23, scope: !1904)
!2012 = !DILocation(line: 206, column: 40, scope: !1904)
!2013 = !{!1610, !1204, i64 117}
!2014 = !DILocation(line: 207, column: 13, scope: !1904)
!2015 = !DILocation(line: 211, column: 27, scope: !2016)
!2016 = distinct !DILexicalBlock(scope: !1913, file: !2, line: 211, column: 21)
!2017 = !DILocation(line: 211, column: 34, scope: !2016)
!2018 = !DILocation(line: 211, column: 42, scope: !2016)
!2019 = !DILocation(line: 212, column: 25, scope: !2016)
!2020 = !DILocation(line: 212, column: 48, scope: !2016)
!2021 = !DILocation(line: 212, column: 28, scope: !2016)
!2022 = !DILocation(line: 212, column: 68, scope: !2016)
!2023 = !DILocation(line: 211, column: 21, scope: !1913)
!2024 = !DILocation(line: 215, column: 27, scope: !2025)
!2025 = distinct !DILexicalBlock(scope: !2016, file: !2, line: 212, column: 74)
!2026 = !DILocation(line: 215, column: 34, scope: !2025)
!2027 = !DILocation(line: 216, column: 42, scope: !2025)
!2028 = !DILocation(line: 217, column: 43, scope: !2025)
!2029 = !DILocation(line: 218, column: 27, scope: !2025)
!2030 = !DILocation(line: 218, column: 34, scope: !2025)
!2031 = !DILocation(line: 219, column: 17, scope: !2025)
!2032 = !DILocation(line: 0, scope: !1913)
!2033 = !DILocation(line: 222, column: 21, scope: !2034)
!2034 = distinct !DILexicalBlock(scope: !2035, file: !2, line: 222, column: 21)
!2035 = distinct !DILexicalBlock(scope: !2016, file: !2, line: 219, column: 24)
!2036 = !DILocation(line: 222, column: 35, scope: !2037)
!2037 = distinct !DILexicalBlock(scope: !2034, file: !2, line: 222, column: 21)
!2038 = !DILocation(line: 223, column: 41, scope: !2039)
!2039 = distinct !DILexicalBlock(scope: !2037, file: !2, line: 222, column: 58)
!2040 = !DILocation(line: 223, column: 54, scope: !2039)
!2041 = !DILocation(line: 223, column: 38, scope: !2039)
!2042 = !DILocation(line: 222, column: 54, scope: !2037)
!2043 = !DILocation(line: 225, column: 47, scope: !2039)
!2044 = distinct !{!2044, !2033, !2045, !1346}
!2045 = !DILocation(line: 226, column: 21, scope: !2034)
!2046 = distinct !{!2046, !2047}
!2047 = !{!"llvm.loop.unroll.disable"}
!2048 = !DILocation(line: 228, column: 23, scope: !1913)
!2049 = !DILocation(line: 228, column: 37, scope: !1913)
!2050 = !{!1610, !1212, i64 112}
!2051 = !DILocation(line: 229, column: 23, scope: !1913)
!2052 = !DILocation(line: 229, column: 40, scope: !1913)
!2053 = !DILocation(line: 237, column: 23, scope: !2054)
!2054 = distinct !DILexicalBlock(scope: !2055, file: !2, line: 237, column: 13)
!2055 = distinct !DILexicalBlock(scope: !1909, file: !2, line: 233, column: 12)
!2056 = !DILocation(line: 237, column: 14, scope: !2054)
!2057 = !DILocation(line: 237, column: 32, scope: !2054)
!2058 = !DILocation(line: 237, column: 48, scope: !2054)
!2059 = !DILocation(line: 237, column: 13, scope: !2055)
!2060 = !DILocation(line: 238, column: 49, scope: !2061)
!2061 = distinct !DILexicalBlock(scope: !2054, file: !2, line: 237, column: 54)
!2062 = !DILocation(line: 238, column: 19, scope: !2061)
!2063 = !DILocation(line: 238, column: 26, scope: !2061)
!2064 = !DILocation(line: 238, column: 13, scope: !2061)
!2065 = !DILocation(line: 238, column: 47, scope: !2061)
!2066 = !DILocation(line: 239, column: 9, scope: !2061)
!2067 = !DILocation(line: 0, scope: !1909)
!2068 = !DILocation(line: 243, column: 8, scope: !1888)
!2069 = !DILocation(line: 243, column: 15, scope: !1888)
!2070 = !DILocation(line: 246, column: 5, scope: !1888)
!2071 = !DILocation(line: 247, column: 1, scope: !1888)
!2072 = !DISubprogram(name: "pthread_mutex_lock", scope: !2073, file: !2073, line: 794, type: !2074, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2073 = !DIFile(filename: "/usr/include/pthread.h", directory: "", checksumkind: CSK_MD5, checksum: "cbcd748b3d3ecaa7356dc2925b45d819")
!2074 = !DISubroutineType(types: !2075)
!2075 = !{!190, !2076}
!2076 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !447, size: 64)
!2077 = !DISubprogram(name: "pthread_mutex_unlock", scope: !2073, file: !2073, line: 835, type: !2074, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2078 = distinct !DISubprogram(name: "storage_submit_cb", scope: !2, file: !2, line: 384, type: !548, scopeLine: 384, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !2079)
!2079 = !{!2080}
!2080 = !DILocalVariable(name: "q", arg: 1, scope: !2078, file: !2, line: 384, type: !550)
!2081 = !DILocation(line: 0, scope: !2078)
!2082 = !DILocation(line: 386, column: 24, scope: !2078)
!2083 = !{!1638, !1312, i64 0}
!2084 = !DILocation(line: 386, column: 32, scope: !2078)
!2085 = !DILocation(line: 386, column: 5, scope: !2078)
!2086 = !DILocation(line: 389, column: 18, scope: !2078)
!2087 = !DILocation(line: 390, column: 1, scope: !2078)
!2088 = !DISubprogram(name: "extstore_submit", scope: !182, file: !182, line: 108, type: !2089, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2089 = !DISubroutineType(types: !2090)
!2090 = !{!190, !191, !895}
!2091 = distinct !DISubprogram(name: "storage_write_pause", scope: !2, file: !2, line: 721, type: !1431, scopeLine: 721, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110)
!2092 = !DILocation(line: 722, column: 5, scope: !2091)
!2093 = !DILocation(line: 723, column: 1, scope: !2091)
!2094 = distinct !DISubprogram(name: "storage_write_resume", scope: !2, file: !2, line: 725, type: !1431, scopeLine: 725, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110)
!2095 = !DILocation(line: 726, column: 5, scope: !2094)
!2096 = !DILocation(line: 727, column: 1, scope: !2094)
!2097 = distinct !DISubprogram(name: "start_storage_write_thread", scope: !2, file: !2, line: 729, type: !2098, scopeLine: 729, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !2100)
!2098 = !DISubroutineType(types: !2099)
!2099 = !{!190, !191}
!2100 = !{!2101, !2102}
!2101 = !DILocalVariable(name: "arg", arg: 1, scope: !2097, file: !2, line: 729, type: !191)
!2102 = !DILocalVariable(name: "ret", scope: !2097, file: !2, line: 730, type: !190)
!2103 = !DILocation(line: 0, scope: !2097)
!2104 = !DILocation(line: 732, column: 5, scope: !2097)
!2105 = !DILocation(line: 733, column: 16, scope: !2106)
!2106 = distinct !DILexicalBlock(scope: !2097, file: !2, line: 733, column: 9)
!2107 = !DILocation(line: 734, column: 37, scope: !2106)
!2108 = !DILocation(line: 733, column: 9, scope: !2097)
!2109 = !DILocation(line: 735, column: 17, scope: !2110)
!2110 = distinct !DILexicalBlock(scope: !2106, file: !2, line: 734, column: 43)
!2111 = !DILocation(line: 736, column: 13, scope: !2110)
!2112 = !DILocation(line: 735, column: 9, scope: !2110)
!2113 = !DILocation(line: 737, column: 9, scope: !2110)
!2114 = !DILocation(line: 739, column: 20, scope: !2097)
!2115 = !{!1320, !1320, i64 0}
!2116 = !DILocation(line: 739, column: 5, scope: !2097)
!2117 = !DILocation(line: 741, column: 5, scope: !2097)
!2118 = !DILocation(line: 742, column: 1, scope: !2097)
!2119 = !DISubprogram(name: "pthread_mutex_init", scope: !2073, file: !2073, line: 781, type: !2120, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2120 = !DISubroutineType(types: !2121)
!2121 = !{!190, !2076, !2122}
!2122 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2123, size: 64)
!2123 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !2124)
!2124 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutexattr_t", file: !355, line: 36, baseType: !2125)
!2125 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !355, line: 32, size: 32, elements: !2126)
!2126 = !{!2127, !2128}
!2127 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !2125, file: !355, line: 34, baseType: !974, size: 32)
!2128 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !2125, file: !355, line: 35, baseType: !190, size: 32)
!2129 = !DISubprogram(name: "pthread_create", scope: !2073, file: !2073, line: 202, type: !2130, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2130 = !DISubroutineType(types: !2131)
!2131 = !{!190, !2132, !2134, !2142, !2145}
!2132 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !2133)
!2133 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !354, size: 64)
!2134 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !2135)
!2135 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2136, size: 64)
!2136 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !2137)
!2137 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_attr_t", file: !355, line: 62, baseType: !2138)
!2138 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "pthread_attr_t", file: !355, line: 56, size: 448, elements: !2139)
!2139 = !{!2140, !2141}
!2140 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !2138, file: !355, line: 58, baseType: !1127, size: 448)
!2141 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !2138, file: !355, line: 59, baseType: !427, size: 64)
!2142 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2143, size: 64)
!2143 = !DISubroutineType(types: !2144)
!2144 = !{!191, !191}
!2145 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !191)
!2146 = distinct !DISubprogram(name: "storage_write_thread", scope: !2, file: !2, line: 591, type: !2143, scopeLine: 591, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !2147)
!2147 = !{!2148, !2149, !2150, !2152, !2153, !2156, !2157, !2158, !2160, !2161, !2162, !2163, !2165, !2168, !2169, !2170, !2171, !2172, !2173, !2174}
!2148 = !DILocalVariable(name: "arg", arg: 1, scope: !2146, file: !2, line: 591, type: !191)
!2149 = !DILocalVariable(name: "storage", scope: !2146, file: !2, line: 592, type: !191)
!2150 = !DILocalVariable(name: "backoff", scope: !2146, file: !2, line: 595, type: !2151)
!2151 = !DICompositeType(tag: DW_TAG_array_type, baseType: !114, size: 2048, elements: !530)
!2152 = !DILocalVariable(name: "counter", scope: !2146, file: !2, line: 596, type: !114)
!2153 = !DILocalVariable(name: "to_sleep", scope: !2146, file: !2, line: 597, type: !2154)
!2154 = !DIDerivedType(tag: DW_TAG_typedef, name: "useconds_t", file: !825, line: 134, baseType: !2155)
!2155 = !DIDerivedType(tag: DW_TAG_typedef, name: "__useconds_t", file: !212, line: 161, baseType: !114)
!2156 = !DILocalVariable(name: "l", scope: !2146, file: !2, line: 598, type: !668)
!2157 = !DILocalVariable(name: "check_compact", scope: !2146, file: !2, line: 610, type: !190)
!2158 = !DILocalVariable(name: "min_class", scope: !2159, file: !2, line: 614, type: !190)
!2159 = distinct !DILexicalBlock(scope: !2146, file: !2, line: 612, column: 15)
!2160 = !DILocalVariable(name: "global_pages", scope: !2159, file: !2, line: 615, type: !114)
!2161 = !DILocalVariable(name: "do_sleep", scope: !2159, file: !2, line: 616, type: !629)
!2162 = !DILocalVariable(name: "target_pages", scope: !2159, file: !2, line: 617, type: !190)
!2163 = !DILocalVariable(name: "x", scope: !2164, file: !2, line: 625, type: !190)
!2164 = distinct !DILexicalBlock(scope: !2159, file: !2, line: 625, column: 9)
!2165 = !DILocalVariable(name: "did_move", scope: !2166, file: !2, line: 626, type: !629)
!2166 = distinct !DILexicalBlock(scope: !2167, file: !2, line: 625, column: 62)
!2167 = distinct !DILexicalBlock(scope: !2164, file: !2, line: 625, column: 9)
!2168 = !DILocalVariable(name: "mem_limit_reached", scope: !2166, file: !2, line: 627, type: !629)
!2169 = !DILocalVariable(name: "chunks_free", scope: !2166, file: !2, line: 628, type: !114)
!2170 = !DILocalVariable(name: "item_age", scope: !2166, file: !2, line: 629, type: !190)
!2171 = !DILocalVariable(name: "chunks_perpage", scope: !2166, file: !2, line: 636, type: !114)
!2172 = !DILocalVariable(name: "target", scope: !2166, file: !2, line: 644, type: !114)
!2173 = !DILocalVariable(name: "chunk_size", scope: !2166, file: !2, line: 646, type: !114)
!2174 = !DILocalVariable(name: "x", scope: !2175, file: !2, line: 685, type: !190)
!2175 = distinct !DILexicalBlock(scope: !2176, file: !2, line: 685, column: 13)
!2176 = distinct !DILexicalBlock(scope: !2177, file: !2, line: 682, column: 23)
!2177 = distinct !DILexicalBlock(scope: !2159, file: !2, line: 682, column: 13)
!2178 = distinct !DIAssignID()
!2179 = !DILocalVariable(name: "it_info", scope: !2180, file: !2, line: 494, type: !2211)
!2180 = distinct !DISubprogram(name: "storage_write", scope: !2, file: !2, line: 492, type: !2181, scopeLine: 492, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !2184)
!2181 = !DISubroutineType(types: !2182)
!2182 = !{!190, !191, !2183, !2183}
!2183 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !190)
!2184 = !{!2185, !2186, !2187, !2188, !2179, !2189, !2190, !2191, !2192, !2193, !2196, !2199, !2202, !2205, !2206, !2207, !2208, !2209}
!2185 = !DILocalVariable(name: "storage", arg: 1, scope: !2180, file: !2, line: 492, type: !191)
!2186 = !DILocalVariable(name: "clsid", arg: 2, scope: !2180, file: !2, line: 492, type: !2183)
!2187 = !DILocalVariable(name: "item_age", arg: 3, scope: !2180, file: !2, line: 492, type: !2183)
!2188 = !DILocalVariable(name: "did_moves", scope: !2180, file: !2, line: 493, type: !190)
!2189 = !DILocalVariable(name: "io", scope: !2180, file: !2, line: 503, type: !876)
!2190 = !DILocalVariable(name: "it", scope: !2180, file: !2, line: 504, type: !614)
!2191 = !DILocalVariable(name: "orig_ntotal", scope: !2180, file: !2, line: 506, type: !584)
!2192 = !DILocalVariable(name: "flags", scope: !2180, file: !2, line: 507, type: !296)
!2193 = !DILocalVariable(name: "hdr_it", scope: !2194, file: !2, line: 511, type: !614)
!2194 = distinct !DILexicalBlock(scope: !2195, file: !2, line: 509, column: 68)
!2195 = distinct !DILexicalBlock(scope: !2180, file: !2, line: 508, column: 9)
!2196 = !DILocalVariable(name: "bucket", scope: !2197, file: !2, line: 516, type: !190)
!2197 = distinct !DILexicalBlock(scope: !2198, file: !2, line: 515, column: 29)
!2198 = distinct !DILexicalBlock(scope: !2194, file: !2, line: 515, column: 13)
!2199 = !DILocalVariable(name: "buf_it", scope: !2200, file: !2, line: 533, type: !614)
!2200 = distinct !DILexicalBlock(scope: !2201, file: !2, line: 530, column: 76)
!2201 = distinct !DILexicalBlock(scope: !2197, file: !2, line: 530, column: 17)
!2202 = !DILocalVariable(name: "sch", scope: !2203, file: !2, line: 539, type: !299)
!2203 = distinct !DILexicalBlock(scope: !2204, file: !2, line: 537, column: 50)
!2204 = distinct !DILexicalBlock(scope: !2200, file: !2, line: 537, column: 21)
!2205 = !DILocalVariable(name: "remain", scope: !2203, file: !2, line: 540, type: !190)
!2206 = !DILocalVariable(name: "copied", scope: !2203, file: !2, line: 541, type: !190)
!2207 = !DILocalVariable(name: "hdrtotal", scope: !2203, file: !2, line: 543, type: !190)
!2208 = !DILocalVariable(name: "hdr", scope: !2200, file: !2, line: 562, type: !286)
!2209 = !DILocalVariable(name: "myl", scope: !2210, file: !2, line: 575, type: !668)
!2210 = distinct !DILexicalBlock(scope: !2200, file: !2, line: 575, column: 17)
!2211 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lru_pull_tail_return", file: !1693, line: 42, size: 128, elements: !2212)
!2212 = !{!2213, !2214}
!2213 = !DIDerivedType(tag: DW_TAG_member, name: "it", scope: !2211, file: !1693, line: 43, baseType: !614, size: 64)
!2214 = !DIDerivedType(tag: DW_TAG_member, name: "hv", scope: !2211, file: !1693, line: 44, baseType: !297, size: 32, offset: 64)
!2215 = !DILocation(line: 0, scope: !2180, inlinedAt: !2216)
!2216 = distinct !DILocation(line: 656, column: 21, scope: !2217)
!2217 = distinct !DILexicalBlock(scope: !2218, file: !2, line: 656, column: 21)
!2218 = distinct !DILexicalBlock(scope: !2166, file: !2, line: 649, column: 23)
!2219 = distinct !DIAssignID()
!2220 = distinct !DIAssignID()
!2221 = !DILocation(line: 0, scope: !2146)
!2222 = distinct !DIAssignID()
!2223 = !DILocation(line: 0, scope: !2166)
!2224 = distinct !DIAssignID()
!2225 = !DILocation(line: 595, column: 5, scope: !2146)
!2226 = !DILocation(line: 595, column: 18, scope: !2146)
!2227 = distinct !DIAssignID()
!2228 = !DILocation(line: 598, column: 17, scope: !2146)
!2229 = !DILocation(line: 599, column: 11, scope: !2230)
!2230 = distinct !DILexicalBlock(scope: !2146, file: !2, line: 599, column: 9)
!2231 = !DILocation(line: 599, column: 9, scope: !2146)
!2232 = !DILocation(line: 600, column: 17, scope: !2233)
!2233 = distinct !DILexicalBlock(scope: !2230, file: !2, line: 599, column: 20)
!2234 = !DILocation(line: 600, column: 9, scope: !2233)
!2235 = !DILocation(line: 601, column: 9, scope: !2233)
!2236 = !DILocation(line: 604, column: 5, scope: !2146)
!2237 = !DILocation(line: 610, column: 34, scope: !2146)
!2238 = !{!1468, !1212, i64 124}
!2239 = !DILocation(line: 612, column: 5, scope: !2146)
!2240 = !DILocation(line: 614, column: 46, scope: !2159)
!2241 = !{!1468, !1212, i64 256}
!2242 = !DILocation(line: 614, column: 37, scope: !2159)
!2243 = !DILocation(line: 614, column: 25, scope: !2159)
!2244 = !DILocation(line: 0, scope: !2159)
!2245 = !DILocation(line: 615, column: 37, scope: !2159)
!2246 = !DILocation(line: 618, column: 37, scope: !2247)
!2247 = distinct !DILexicalBlock(scope: !2159, file: !2, line: 618, column: 13)
!2248 = !{!1468, !1212, i64 308}
!2249 = !DILocation(line: 618, column: 13, scope: !2159)
!2250 = !DILocation(line: 621, column: 16, scope: !2159)
!2251 = !DILocation(line: 622, column: 33, scope: !2252)
!2252 = distinct !DILexicalBlock(scope: !2159, file: !2, line: 622, column: 13)
!2253 = !{!1468, !1212, i64 284}
!2254 = !DILocation(line: 622, column: 13, scope: !2159)
!2255 = !DILocation(line: 0, scope: !2164)
!2256 = !DILocation(line: 625, column: 9, scope: !2164)
!2257 = !DILocation(line: 681, column: 9, scope: !2159)
!2258 = !DILocation(line: 682, column: 13, scope: !2159)
!2259 = !DILocation(line: 686, column: 28, scope: !2260)
!2260 = distinct !DILexicalBlock(scope: !2261, file: !2, line: 685, column: 66)
!2261 = distinct !DILexicalBlock(scope: !2175, file: !2, line: 685, column: 13)
!2262 = !DILocation(line: 691, column: 39, scope: !2176)
!2263 = !DILocation(line: 691, column: 27, scope: !2176)
!2264 = !DILocation(line: 692, column: 31, scope: !2265)
!2265 = distinct !DILexicalBlock(scope: !2176, file: !2, line: 692, column: 17)
!2266 = !DILocation(line: 692, column: 17, scope: !2176)
!2267 = !DILocation(line: 627, column: 13, scope: !2166)
!2268 = !DILocation(line: 627, column: 18, scope: !2166)
!2269 = !{!1336, !1336, i64 0}
!2270 = distinct !DIAssignID()
!2271 = !DILocation(line: 631, column: 27, scope: !2272)
!2272 = distinct !DILexicalBlock(scope: !2166, file: !2, line: 631, column: 17)
!2273 = !DILocation(line: 631, column: 31, scope: !2272)
!2274 = !DILocation(line: 631, column: 35, scope: !2272)
!2275 = !DILocation(line: 631, column: 46, scope: !2272)
!2276 = !DILocation(line: 631, column: 58, scope: !2272)
!2277 = !DILocation(line: 631, column: 71, scope: !2272)
!2278 = !DILocation(line: 631, column: 17, scope: !2166)
!2279 = !DILocation(line: 636, column: 13, scope: !2166)
!2280 = !DILocation(line: 636, column: 26, scope: !2166)
!2281 = distinct !DIAssignID()
!2282 = !DILocation(line: 637, column: 27, scope: !2166)
!2283 = !DILocation(line: 640, column: 17, scope: !2284)
!2284 = distinct !DILexicalBlock(scope: !2166, file: !2, line: 640, column: 17)
!2285 = !DILocation(line: 640, column: 32, scope: !2284)
!2286 = !DILocation(line: 640, column: 17, scope: !2166)
!2287 = !DILocation(line: 644, column: 50, scope: !2166)
!2288 = !DILocation(line: 646, column: 48, scope: !2166)
!2289 = !DILocation(line: 646, column: 63, scope: !2166)
!2290 = !DILocation(line: 649, column: 13, scope: !2166)
!2291 = !DILocation(line: 651, column: 33, scope: !2292)
!2292 = distinct !DILexicalBlock(scope: !2218, file: !2, line: 651, column: 21)
!2293 = !DILocation(line: 651, column: 21, scope: !2218)
!2294 = !DILocation(line: 654, column: 41, scope: !2295)
!2295 = distinct !DILexicalBlock(scope: !2292, file: !2, line: 653, column: 24)
!2296 = !{!1468, !1212, i64 260}
!2297 = !DILocation(line: 0, scope: !2292)
!2298 = !DILocation(line: 494, column: 5, scope: !2180, inlinedAt: !2216)
!2299 = !DILocation(line: 496, column: 16, scope: !2180, inlinedAt: !2216)
!2300 = !{!2301, !1312, i64 0}
!2301 = !{!"lru_pull_tail_return", !1312, i64 0, !1212, i64 8}
!2302 = distinct !DIAssignID()
!2303 = !DILocation(line: 497, column: 5, scope: !2180, inlinedAt: !2216)
!2304 = !DILocation(line: 499, column: 17, scope: !2305, inlinedAt: !2216)
!2305 = distinct !DILexicalBlock(scope: !2180, file: !2, line: 499, column: 9)
!2306 = !DILocation(line: 499, column: 20, scope: !2305, inlinedAt: !2216)
!2307 = !DILocation(line: 499, column: 9, scope: !2180, inlinedAt: !2216)
!2308 = !DILocation(line: 585, column: 1, scope: !2180, inlinedAt: !2216)
!2309 = !DILocation(line: 656, column: 21, scope: !2218)
!2310 = !DILocation(line: 503, column: 5, scope: !2180, inlinedAt: !2216)
!2311 = !DILocation(line: 506, column: 26, scope: !2180, inlinedAt: !2216)
!2312 = !DILocation(line: 508, column: 23, scope: !2195, inlinedAt: !2216)
!2313 = !DILocation(line: 508, column: 35, scope: !2195, inlinedAt: !2216)
!2314 = !DILocation(line: 508, column: 40, scope: !2195, inlinedAt: !2216)
!2315 = !DILocation(line: 509, column: 23, scope: !2195, inlinedAt: !2216)
!2316 = !DILocation(line: 509, column: 28, scope: !2195, inlinedAt: !2216)
!2317 = !DILocation(line: 509, column: 31, scope: !2195, inlinedAt: !2216)
!2318 = !DILocation(line: 509, column: 50, scope: !2195, inlinedAt: !2216)
!2319 = !DILocation(line: 509, column: 44, scope: !2195, inlinedAt: !2216)
!2320 = !DILocation(line: 509, column: 55, scope: !2195, inlinedAt: !2216)
!2321 = !DILocation(line: 508, column: 9, scope: !2180, inlinedAt: !2216)
!2322 = !DILocation(line: 510, column: 9, scope: !2323, inlinedAt: !2216)
!2323 = distinct !DILexicalBlock(scope: !2324, file: !2, line: 510, column: 9)
!2324 = distinct !DILexicalBlock(scope: !2194, file: !2, line: 510, column: 9)
!2325 = !DILocation(line: 510, column: 9, scope: !2324, inlinedAt: !2216)
!2326 = !DILocation(line: 510, column: 9, scope: !2327, inlinedAt: !2216)
!2327 = distinct !DILexicalBlock(scope: !2323, file: !2, line: 510, column: 9)
!2328 = !DILocation(line: 511, column: 38, scope: !2194, inlinedAt: !2216)
!2329 = !DILocation(line: 511, column: 73, scope: !2194, inlinedAt: !2216)
!2330 = !DILocation(line: 511, column: 24, scope: !2194, inlinedAt: !2216)
!2331 = !DILocation(line: 0, scope: !2194, inlinedAt: !2216)
!2332 = !DILocation(line: 515, column: 20, scope: !2198, inlinedAt: !2216)
!2333 = !DILocation(line: 515, column: 13, scope: !2194, inlinedAt: !2216)
!2334 = !DILocation(line: 516, column: 31, scope: !2197, inlinedAt: !2216)
!2335 = !DILocation(line: 516, column: 26, scope: !2197, inlinedAt: !2216)
!2336 = !DILocation(line: 0, scope: !2197, inlinedAt: !2216)
!2337 = !DILocation(line: 519, column: 21, scope: !2338, inlinedAt: !2216)
!2338 = distinct !DILexicalBlock(scope: !2197, file: !2, line: 519, column: 17)
!2339 = !DILocation(line: 519, column: 31, scope: !2338, inlinedAt: !2216)
!2340 = !DILocation(line: 519, column: 29, scope: !2338, inlinedAt: !2216)
!2341 = !DILocation(line: 519, column: 55, scope: !2338, inlinedAt: !2216)
!2342 = !{!1468, !1212, i64 264}
!2343 = !DILocation(line: 519, column: 44, scope: !2338, inlinedAt: !2216)
!2344 = !DILocation(line: 519, column: 17, scope: !2197, inlinedAt: !2216)
!2345 = !DILocation(line: 522, column: 21, scope: !2197, inlinedAt: !2216)
!2346 = !DILocation(line: 522, column: 30, scope: !2197, inlinedAt: !2216)
!2347 = !DILocation(line: 523, column: 22, scope: !2197, inlinedAt: !2216)
!2348 = !DILocation(line: 523, column: 20, scope: !2197, inlinedAt: !2216)
!2349 = distinct !DIAssignID()
!2350 = !DILocation(line: 524, column: 21, scope: !2197, inlinedAt: !2216)
!2351 = distinct !DIAssignID()
!2352 = !DILocation(line: 530, column: 17, scope: !2201, inlinedAt: !2216)
!2353 = !DILocation(line: 530, column: 70, scope: !2201, inlinedAt: !2216)
!2354 = !DILocation(line: 530, column: 17, scope: !2197, inlinedAt: !2216)
!2355 = !DILocation(line: 533, column: 44, scope: !2200, inlinedAt: !2216)
!2356 = !DILocation(line: 0, scope: !2200, inlinedAt: !2216)
!2357 = !DILocation(line: 534, column: 40, scope: !2200, inlinedAt: !2216)
!2358 = !{!2301, !1212, i64 8}
!2359 = !DILocation(line: 534, column: 25, scope: !2200, inlinedAt: !2216)
!2360 = !DILocation(line: 534, column: 30, scope: !2200, inlinedAt: !2216)
!2361 = !DILocation(line: 537, column: 25, scope: !2204, inlinedAt: !2216)
!2362 = !DILocation(line: 537, column: 21, scope: !2204, inlinedAt: !2216)
!2363 = !DILocation(line: 537, column: 34, scope: !2204, inlinedAt: !2216)
!2364 = !DILocation(line: 537, column: 21, scope: !2200, inlinedAt: !2216)
!2365 = !DILocation(line: 539, column: 54, scope: !2203, inlinedAt: !2216)
!2366 = !DILocation(line: 0, scope: !2203, inlinedAt: !2216)
!2367 = !DILocation(line: 543, column: 36, scope: !2203, inlinedAt: !2216)
!2368 = !DILocation(line: 543, column: 52, scope: !2203, inlinedAt: !2216)
!2369 = !DILocation(line: 544, column: 42, scope: !2203, inlinedAt: !2216)
!2370 = !DILocation(line: 544, column: 82, scope: !2203, inlinedAt: !2216)
!2371 = !DILocation(line: 544, column: 91, scope: !2203, inlinedAt: !2216)
!2372 = !DILocation(line: 544, column: 21, scope: !2203, inlinedAt: !2216)
!2373 = !DILocation(line: 547, column: 32, scope: !2203, inlinedAt: !2216)
!2374 = !DILocation(line: 547, column: 21, scope: !2203, inlinedAt: !2216)
!2375 = !DILocation(line: 549, column: 43, scope: !2376, inlinedAt: !2216)
!2376 = distinct !DILexicalBlock(scope: !2203, file: !2, line: 547, column: 43)
!2377 = !DILocation(line: 549, column: 46, scope: !2376, inlinedAt: !2216)
!2378 = !DILocation(line: 549, column: 60, scope: !2376, inlinedAt: !2216)
!2379 = !DILocation(line: 549, column: 71, scope: !2376, inlinedAt: !2216)
!2380 = !DILocation(line: 549, column: 66, scope: !2376, inlinedAt: !2216)
!2381 = !DILocation(line: 549, column: 25, scope: !2376, inlinedAt: !2216)
!2382 = !DILocation(line: 551, column: 40, scope: !2376, inlinedAt: !2216)
!2383 = !DILocation(line: 551, column: 32, scope: !2376, inlinedAt: !2216)
!2384 = !DILocation(line: 552, column: 32, scope: !2376, inlinedAt: !2216)
!2385 = !DILocation(line: 553, column: 36, scope: !2376, inlinedAt: !2216)
!2386 = !DILocation(line: 547, column: 28, scope: !2203, inlinedAt: !2216)
!2387 = distinct !{!2387, !2374, !2388, !1346}
!2388 = !DILocation(line: 554, column: 21, scope: !2203, inlinedAt: !2216)
!2389 = !DILocation(line: 556, column: 42, scope: !2390, inlinedAt: !2216)
!2390 = distinct !DILexicalBlock(scope: !2204, file: !2, line: 555, column: 24)
!2391 = !DILocation(line: 556, column: 85, scope: !2390, inlinedAt: !2216)
!2392 = !DILocation(line: 556, column: 82, scope: !2390, inlinedAt: !2216)
!2393 = !DILocation(line: 556, column: 88, scope: !2390, inlinedAt: !2216)
!2394 = !DILocation(line: 556, column: 21, scope: !2390, inlinedAt: !2216)
!2395 = !DILocation(line: 560, column: 55, scope: !2200, inlinedAt: !2216)
!2396 = !DILocation(line: 559, column: 25, scope: !2200, inlinedAt: !2216)
!2397 = !DILocation(line: 559, column: 34, scope: !2200, inlinedAt: !2216)
!2398 = !DILocation(line: 560, column: 35, scope: !2200, inlinedAt: !2216)
!2399 = !DILocation(line: 560, column: 58, scope: !2200, inlinedAt: !2216)
!2400 = !DILocation(line: 560, column: 84, scope: !2200, inlinedAt: !2216)
!2401 = !DILocation(line: 560, column: 25, scope: !2200, inlinedAt: !2216)
!2402 = !DILocation(line: 560, column: 33, scope: !2200, inlinedAt: !2216)
!2403 = !DILocation(line: 561, column: 17, scope: !2200, inlinedAt: !2216)
!2404 = !DILocation(line: 562, column: 46, scope: !2200, inlinedAt: !2216)
!2405 = !DILocation(line: 563, column: 40, scope: !2200, inlinedAt: !2216)
!2406 = !DILocation(line: 563, column: 35, scope: !2200, inlinedAt: !2216)
!2407 = !DILocation(line: 564, column: 35, scope: !2200, inlinedAt: !2216)
!2408 = !DILocation(line: 564, column: 22, scope: !2200, inlinedAt: !2216)
!2409 = !DILocation(line: 564, column: 30, scope: !2200, inlinedAt: !2216)
!2410 = !DILocation(line: 565, column: 35, scope: !2200, inlinedAt: !2216)
!2411 = !DILocation(line: 565, column: 22, scope: !2200, inlinedAt: !2216)
!2412 = !DILocation(line: 565, column: 30, scope: !2200, inlinedAt: !2216)
!2413 = !DILocation(line: 567, column: 38, scope: !2200, inlinedAt: !2216)
!2414 = !DILocation(line: 567, column: 25, scope: !2200, inlinedAt: !2216)
!2415 = !DILocation(line: 567, column: 32, scope: !2200, inlinedAt: !2216)
!2416 = !DILocation(line: 572, column: 50, scope: !2200, inlinedAt: !2216)
!2417 = !DILocation(line: 572, column: 54, scope: !2200, inlinedAt: !2216)
!2418 = !DILocation(line: 572, column: 17, scope: !2200, inlinedAt: !2216)
!2419 = !DILocation(line: 573, column: 17, scope: !2200, inlinedAt: !2216)
!2420 = !DILocation(line: 0, scope: !2210, inlinedAt: !2216)
!2421 = !DILocation(line: 575, column: 17, scope: !2422, inlinedAt: !2216)
!2422 = distinct !DILexicalBlock(scope: !2210, file: !2, line: 575, column: 17)
!2423 = !DILocation(line: 575, column: 17, scope: !2424, inlinedAt: !2216)
!2424 = distinct !DILexicalBlock(scope: !2210, file: !2, line: 575, column: 17)
!2425 = !{!2426, !1207, i64 84}
!2426 = !{!"_logger", !1312, i64 0, !1312, i64 8, !1204, i64 16, !1320, i64 56, !1320, i64 64, !1320, i64 72, !1207, i64 80, !1207, i64 82, !1207, i64 84, !1312, i64 88, !1312, i64 96}
!2427 = !DILocation(line: 575, column: 17, scope: !2210, inlinedAt: !2216)
!2428 = !DILocation(line: 578, column: 36, scope: !2429, inlinedAt: !2216)
!2429 = distinct !DILexicalBlock(scope: !2201, file: !2, line: 576, column: 20)
!2430 = !DILocation(line: 578, column: 57, scope: !2429, inlinedAt: !2216)
!2431 = !DILocation(line: 578, column: 17, scope: !2429, inlinedAt: !2216)
!2432 = !DILocation(line: 582, column: 5, scope: !2180, inlinedAt: !2216)
!2433 = !DILocation(line: 583, column: 25, scope: !2180, inlinedAt: !2216)
!2434 = !DILocation(line: 583, column: 5, scope: !2180, inlinedAt: !2216)
!2435 = !DILocation(line: 657, column: 32, scope: !2436)
!2436 = distinct !DILexicalBlock(scope: !2217, file: !2, line: 656, column: 58)
!2437 = !DILocation(line: 658, column: 35, scope: !2436)
!2438 = !DILocation(line: 660, column: 39, scope: !2439)
!2439 = distinct !DILexicalBlock(scope: !2436, file: !2, line: 660, column: 25)
!2440 = !DILocation(line: 660, column: 25, scope: !2436)
!2441 = !DILocation(line: 661, column: 25, scope: !2442)
!2442 = distinct !DILexicalBlock(scope: !2439, file: !2, line: 660, column: 44)
!2443 = !DILocation(line: 662, column: 50, scope: !2442)
!2444 = !DILocation(line: 663, column: 21, scope: !2442)
!2445 = !DILocation(line: 0, scope: !2436)
!2446 = !DILocation(line: 666, column: 34, scope: !2447)
!2447 = distinct !DILexicalBlock(scope: !2436, file: !2, line: 666, column: 25)
!2448 = !DILocation(line: 666, column: 25, scope: !2436)
!2449 = distinct !{!2449, !2290, !2450}
!2450 = !DILocation(line: 671, column: 13, scope: !2166)
!2451 = !DILocation(line: 673, column: 17, scope: !2166)
!2452 = !DILocation(line: 674, column: 27, scope: !2453)
!2453 = distinct !DILexicalBlock(scope: !2454, file: !2, line: 673, column: 28)
!2454 = distinct !DILexicalBlock(scope: !2166, file: !2, line: 673, column: 17)
!2455 = !DILocation(line: 675, column: 13, scope: !2453)
!2456 = !DILocation(line: 0, scope: !2454)
!2457 = !DILocation(line: 678, column: 9, scope: !2167)
!2458 = !DILocation(line: 610, column: 9, scope: !2146)
!2459 = !DILocation(line: 616, column: 14, scope: !2159)
!2460 = !DILocation(line: 623, column: 22, scope: !2252)
!2461 = !DILocation(line: 625, column: 58, scope: !2167)
!2462 = !DILocation(line: 625, column: 27, scope: !2167)
!2463 = distinct !{!2463, !2256, !2464, !1346}
!2464 = !DILocation(line: 678, column: 9, scope: !2164)
!2465 = !DILocation(line: 693, column: 17, scope: !2466)
!2466 = distinct !DILexicalBlock(scope: !2265, file: !2, line: 692, column: 36)
!2467 = !DILocation(line: 694, column: 42, scope: !2466)
!2468 = !DILocation(line: 695, column: 13, scope: !2466)
!2469 = !DILocation(line: 0, scope: !2176)
!2470 = !DILocation(line: 697, column: 13, scope: !2176)
!2471 = !DILocation(line: 698, column: 21, scope: !2176)
!2472 = !DILocation(line: 699, column: 9, scope: !2176)
!2473 = !DILocation(line: 700, column: 9, scope: !2159)
!2474 = distinct !{!2474, !2239, !2475}
!2475 = !DILocation(line: 701, column: 5, scope: !2146)
!2476 = !DISubprogram(name: "fprintf", scope: !1360, file: !1360, line: 357, type: !2477, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2477 = !DISubroutineType(types: !2478)
!2478 = !{!190, !2479, !1364, null}
!2479 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !2480)
!2480 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2481, size: 64)
!2481 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !2482, line: 7, baseType: !2483)
!2482 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!2483 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !2484, line: 49, size: 1728, elements: !2485)
!2484 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "7a6d4a00a37ee6b9a40cd04bd01f5d00")
!2485 = !{!2486, !2487, !2488, !2489, !2490, !2491, !2492, !2493, !2494, !2495, !2496, !2497, !2498, !2501, !2503, !2504, !2505, !2507, !2508, !2510, !2511, !2514, !2516, !2519, !2522, !2523, !2524, !2525, !2526}
!2486 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !2483, file: !2484, line: 51, baseType: !190, size: 32)
!2487 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !2483, file: !2484, line: 54, baseType: !193, size: 64, offset: 64)
!2488 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !2483, file: !2484, line: 55, baseType: !193, size: 64, offset: 128)
!2489 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !2483, file: !2484, line: 56, baseType: !193, size: 64, offset: 192)
!2490 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !2483, file: !2484, line: 57, baseType: !193, size: 64, offset: 256)
!2491 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !2483, file: !2484, line: 58, baseType: !193, size: 64, offset: 320)
!2492 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !2483, file: !2484, line: 59, baseType: !193, size: 64, offset: 384)
!2493 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !2483, file: !2484, line: 60, baseType: !193, size: 64, offset: 448)
!2494 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !2483, file: !2484, line: 61, baseType: !193, size: 64, offset: 512)
!2495 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !2483, file: !2484, line: 64, baseType: !193, size: 64, offset: 576)
!2496 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !2483, file: !2484, line: 65, baseType: !193, size: 64, offset: 640)
!2497 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !2483, file: !2484, line: 66, baseType: !193, size: 64, offset: 704)
!2498 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !2483, file: !2484, line: 68, baseType: !2499, size: 64, offset: 768)
!2499 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2500, size: 64)
!2500 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !2484, line: 36, flags: DIFlagFwdDecl)
!2501 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !2483, file: !2484, line: 70, baseType: !2502, size: 64, offset: 832)
!2502 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2483, size: 64)
!2503 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !2483, file: !2484, line: 72, baseType: !190, size: 32, offset: 896)
!2504 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !2483, file: !2484, line: 73, baseType: !190, size: 32, offset: 928)
!2505 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !2483, file: !2484, line: 74, baseType: !2506, size: 64, offset: 960)
!2506 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !212, line: 152, baseType: !427)
!2507 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !2483, file: !2484, line: 77, baseType: !293, size: 16, offset: 1024)
!2508 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !2483, file: !2484, line: 78, baseType: !2509, size: 8, offset: 1040)
!2509 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!2510 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !2483, file: !2484, line: 79, baseType: !105, size: 8, offset: 1048)
!2511 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !2483, file: !2484, line: 81, baseType: !2512, size: 64, offset: 1088)
!2512 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2513, size: 64)
!2513 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !2484, line: 43, baseType: null)
!2514 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !2483, file: !2484, line: 89, baseType: !2515, size: 64, offset: 1152)
!2515 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !212, line: 153, baseType: !427)
!2516 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !2483, file: !2484, line: 91, baseType: !2517, size: 64, offset: 1216)
!2517 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2518, size: 64)
!2518 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !2484, line: 37, flags: DIFlagFwdDecl)
!2519 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !2483, file: !2484, line: 92, baseType: !2520, size: 64, offset: 1280)
!2520 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2521, size: 64)
!2521 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !2484, line: 38, flags: DIFlagFwdDecl)
!2522 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !2483, file: !2484, line: 93, baseType: !2502, size: 64, offset: 1344)
!2523 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !2483, file: !2484, line: 94, baseType: !191, size: 64, offset: 1408)
!2524 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !2483, file: !2484, line: 95, baseType: !584, size: 64, offset: 1472)
!2525 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !2483, file: !2484, line: 96, baseType: !190, size: 32, offset: 1536)
!2526 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !2483, file: !2484, line: 98, baseType: !73, size: 160, offset: 1568)
!2527 = !DISubprogram(name: "strerror", scope: !2528, file: !2528, line: 419, type: !2529, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2528 = !DIFile(filename: "/usr/include/string.h", directory: "", checksumkind: CSK_MD5, checksum: "165db1185644f68894fa9e0d17055d70")
!2529 = !DISubroutineType(types: !2530)
!2530 = !{!193, !190}
!2531 = !DISubprogram(name: "thread_setname", scope: !113, file: !113, line: 1033, type: !2532, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2532 = !DISubroutineType(types: !2533)
!2533 = !{null, !354, !1258}
!2534 = distinct !DISubprogram(name: "storage_compact_pause", scope: !2, file: !2, line: 1163, type: !1431, scopeLine: 1163, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110)
!2535 = !DILocation(line: 1164, column: 5, scope: !2534)
!2536 = !DILocation(line: 1165, column: 1, scope: !2534)
!2537 = distinct !DISubprogram(name: "storage_compact_resume", scope: !2, file: !2, line: 1167, type: !1431, scopeLine: 1167, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110)
!2538 = !DILocation(line: 1168, column: 5, scope: !2537)
!2539 = !DILocation(line: 1169, column: 1, scope: !2537)
!2540 = distinct !DISubprogram(name: "start_storage_compact_thread", scope: !2, file: !2, line: 1171, type: !2098, scopeLine: 1171, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !2541)
!2541 = !{!2542, !2543}
!2542 = !DILocalVariable(name: "arg", arg: 1, scope: !2540, file: !2, line: 1171, type: !191)
!2543 = !DILocalVariable(name: "ret", scope: !2540, file: !2, line: 1172, type: !190)
!2544 = !DILocation(line: 0, scope: !2540)
!2545 = !DILocation(line: 1174, column: 5, scope: !2540)
!2546 = !DILocation(line: 1175, column: 5, scope: !2540)
!2547 = !DILocation(line: 1176, column: 16, scope: !2548)
!2548 = distinct !DILexicalBlock(scope: !2540, file: !2, line: 1176, column: 9)
!2549 = !DILocation(line: 1177, column: 39, scope: !2548)
!2550 = !DILocation(line: 1176, column: 9, scope: !2540)
!2551 = !DILocation(line: 1178, column: 17, scope: !2552)
!2552 = distinct !DILexicalBlock(scope: !2548, file: !2, line: 1177, column: 45)
!2553 = !DILocation(line: 1179, column: 13, scope: !2552)
!2554 = !DILocation(line: 1178, column: 9, scope: !2552)
!2555 = !DILocation(line: 1180, column: 9, scope: !2552)
!2556 = !DILocation(line: 1182, column: 20, scope: !2540)
!2557 = !DILocation(line: 1182, column: 5, scope: !2540)
!2558 = !DILocation(line: 1184, column: 5, scope: !2540)
!2559 = !DILocation(line: 1185, column: 1, scope: !2540)
!2560 = !DISubprogram(name: "pthread_cond_init", scope: !2073, file: !2073, line: 1112, type: !2561, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2561 = !DISubroutineType(types: !2562)
!2562 = !{!190, !2563, !2565}
!2563 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !2564)
!2564 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1140, size: 64)
!2565 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !2566)
!2566 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2567, size: 64)
!2567 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !2568)
!2568 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_condattr_t", file: !355, line: 45, baseType: !2569)
!2569 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !355, line: 41, size: 32, elements: !2570)
!2570 = !{!2571, !2572}
!2571 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !2569, file: !355, line: 43, baseType: !974, size: 32)
!2572 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !2569, file: !355, line: 44, baseType: !190, size: 32)
!2573 = distinct !DISubprogram(name: "storage_compact_thread", scope: !2, file: !2, line: 1056, type: !2143, scopeLine: 1056, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !2574)
!2574 = !{!2575, !2576, !2577, !2578, !2579, !2580, !2581, !2582, !2589, !2590, !2591, !2592, !2597, !2603, !2607}
!2575 = !DILocalVariable(name: "arg", arg: 1, scope: !2573, file: !2, line: 1056, type: !191)
!2576 = !DILocalVariable(name: "storage", scope: !2573, file: !2, line: 1057, type: !191)
!2577 = !DILocalVariable(name: "compacting", scope: !2573, file: !2, line: 1058, type: !629)
!2578 = !DILocalVariable(name: "page_version", scope: !2573, file: !2, line: 1059, type: !209)
!2579 = !DILocalVariable(name: "page_size", scope: !2573, file: !2, line: 1060, type: !209)
!2580 = !DILocalVariable(name: "page_offset", scope: !2573, file: !2, line: 1061, type: !297)
!2581 = !DILocalVariable(name: "page_id", scope: !2573, file: !2, line: 1062, type: !297)
!2582 = !DILocalVariable(name: "flags", scope: !2573, file: !2, line: 1063, type: !2583)
!2583 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_compact_flags", file: !2, line: 759, size: 32, elements: !2584)
!2584 = !{!2585, !2586, !2587, !2588}
!2585 = !DIDerivedType(tag: DW_TAG_member, name: "drop_unread", scope: !2583, file: !2, line: 760, baseType: !114, size: 1, flags: DIFlagBitField, extraData: i64 0)
!2586 = !DIDerivedType(tag: DW_TAG_member, name: "has_coldcompact", scope: !2583, file: !2, line: 761, baseType: !114, size: 1, offset: 1, flags: DIFlagBitField, extraData: i64 0)
!2587 = !DIDerivedType(tag: DW_TAG_member, name: "has_old", scope: !2583, file: !2, line: 762, baseType: !114, size: 1, offset: 2, flags: DIFlagBitField, extraData: i64 0)
!2588 = !DIDerivedType(tag: DW_TAG_member, name: "use_old", scope: !2583, file: !2, line: 763, baseType: !114, size: 1, offset: 3, flags: DIFlagBitField, extraData: i64 0)
!2589 = !DILocalVariable(name: "readback_buf", scope: !2573, file: !2, line: 1064, type: !193)
!2590 = !DILocalVariable(name: "wrap", scope: !2573, file: !2, line: 1065, type: !919)
!2591 = !DILocalVariable(name: "l", scope: !2573, file: !2, line: 1068, type: !668)
!2592 = !DILocalVariable(name: "myl", scope: !2593, file: !2, line: 1097, type: !668)
!2593 = distinct !DILexicalBlock(scope: !2594, file: !2, line: 1097, column: 13)
!2594 = distinct !DILexicalBlock(scope: !2595, file: !2, line: 1094, column: 67)
!2595 = distinct !DILexicalBlock(scope: !2596, file: !2, line: 1093, column: 13)
!2596 = distinct !DILexicalBlock(scope: !2573, file: !2, line: 1092, column: 15)
!2597 = !DILocalVariable(name: "myl", scope: !2598, file: !2, line: 1116, type: !668)
!2598 = distinct !DILexicalBlock(scope: !2599, file: !2, line: 1116, column: 17)
!2599 = distinct !DILexicalBlock(scope: !2600, file: !2, line: 1115, column: 35)
!2600 = distinct !DILexicalBlock(scope: !2601, file: !2, line: 1115, column: 24)
!2601 = distinct !DILexicalBlock(scope: !2602, file: !2, line: 1105, column: 17)
!2602 = distinct !DILexicalBlock(scope: !2596, file: !2, line: 1103, column: 28)
!2603 = !DILocalVariable(name: "myl", scope: !2604, file: !2, line: 1122, type: !668)
!2604 = distinct !DILexicalBlock(scope: !2605, file: !2, line: 1122, column: 17)
!2605 = distinct !DILexicalBlock(scope: !2606, file: !2, line: 1121, column: 53)
!2606 = distinct !DILexicalBlock(scope: !2600, file: !2, line: 1121, column: 24)
!2607 = !DILocalVariable(name: "myl", scope: !2608, file: !2, line: 1135, type: !668)
!2608 = distinct !DILexicalBlock(scope: !2609, file: !2, line: 1135, column: 17)
!2609 = distinct !DILexicalBlock(scope: !2610, file: !2, line: 1130, column: 50)
!2610 = distinct !DILexicalBlock(scope: !2606, file: !2, line: 1130, column: 24)
!2611 = distinct !DIAssignID()
!2612 = distinct !DIAssignID()
!2613 = !DILocalVariable(name: "st", scope: !2614, file: !2, line: 771, type: !1274)
!2614 = distinct !DISubprogram(name: "storage_compact_check", scope: !2, file: !2, line: 768, type: !2615, scopeLine: 770, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !2620)
!2615 = !DISubroutineType(types: !2616)
!2616 = !{!190, !191, !668, !2617, !2618, !2618, !2619}
!2617 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !297, size: 64)
!2618 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !209, size: 64)
!2619 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2583, size: 64)
!2620 = !{!2621, !2622, !2623, !2624, !2625, !2626, !2613, !2627, !2643, !2645, !2646, !2648, !2650, !2652, !2655, !2657}
!2621 = !DILocalVariable(name: "storage", arg: 1, scope: !2614, file: !2, line: 768, type: !191)
!2622 = !DILocalVariable(name: "l", arg: 2, scope: !2614, file: !2, line: 768, type: !668)
!2623 = !DILocalVariable(name: "page_id", arg: 3, scope: !2614, file: !2, line: 769, type: !2617)
!2624 = !DILocalVariable(name: "page_version", arg: 4, scope: !2614, file: !2, line: 769, type: !2618)
!2625 = !DILocalVariable(name: "page_size", arg: 5, scope: !2614, file: !2, line: 770, type: !2618)
!2626 = !DILocalVariable(name: "flags", arg: 6, scope: !2614, file: !2, line: 770, type: !2619)
!2627 = !DILocalVariable(name: "buckets", scope: !2614, file: !2, line: 772, type: !2628)
!2628 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2629, size: 2688, elements: !5)
!2629 = !DIDerivedType(tag: DW_TAG_typedef, name: "_storage_buk", file: !2, line: 757, baseType: !2630)
!2630 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__storage_buk", file: !2, line: 745, size: 448, elements: !2631)
!2631 = !{!2632, !2633, !2634, !2635, !2636, !2637, !2638, !2639, !2640, !2641, !2642}
!2632 = !DIDerivedType(tag: DW_TAG_member, name: "bucket", scope: !2630, file: !2, line: 746, baseType: !114, size: 32)
!2633 = !DIDerivedType(tag: DW_TAG_member, name: "low_page", scope: !2630, file: !2, line: 747, baseType: !114, size: 32, offset: 32)
!2634 = !DIDerivedType(tag: DW_TAG_member, name: "lowest_page", scope: !2630, file: !2, line: 748, baseType: !114, size: 32, offset: 64)
!2635 = !DIDerivedType(tag: DW_TAG_member, name: "low_version", scope: !2630, file: !2, line: 749, baseType: !209, size: 64, offset: 128)
!2636 = !DIDerivedType(tag: DW_TAG_member, name: "lowest_version", scope: !2630, file: !2, line: 750, baseType: !209, size: 64, offset: 192)
!2637 = !DIDerivedType(tag: DW_TAG_member, name: "pages_free", scope: !2630, file: !2, line: 751, baseType: !114, size: 32, offset: 256)
!2638 = !DIDerivedType(tag: DW_TAG_member, name: "pages_used", scope: !2630, file: !2, line: 752, baseType: !114, size: 32, offset: 288)
!2639 = !DIDerivedType(tag: DW_TAG_member, name: "pages_total", scope: !2630, file: !2, line: 753, baseType: !114, size: 32, offset: 320)
!2640 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_fragmented", scope: !2630, file: !2, line: 754, baseType: !114, size: 32, offset: 352)
!2641 = !DIDerivedType(tag: DW_TAG_member, name: "do_compact", scope: !2630, file: !2, line: 755, baseType: !629, size: 8, offset: 384)
!2642 = !DIDerivedType(tag: DW_TAG_member, name: "do_compact_drop", scope: !2630, file: !2, line: 756, baseType: !629, size: 8, offset: 392)
!2643 = !DILocalVariable(name: "buk", scope: !2614, file: !2, line: 773, type: !2644)
!2644 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2629, size: 64)
!2645 = !DILocalVariable(name: "frag_limit", scope: !2614, file: !2, line: 774, type: !209)
!2646 = !DILocalVariable(name: "x", scope: !2647, file: !2, line: 779, type: !190)
!2647 = distinct !DILexicalBlock(scope: !2614, file: !2, line: 779, column: 5)
!2648 = !DILocalVariable(name: "myl", scope: !2649, file: !2, line: 787, type: !668)
!2649 = distinct !DILexicalBlock(scope: !2614, file: !2, line: 787, column: 5)
!2650 = !DILocalVariable(name: "x", scope: !2651, file: !2, line: 793, type: !190)
!2651 = distinct !DILexicalBlock(scope: !2614, file: !2, line: 793, column: 5)
!2652 = !DILocalVariable(name: "frag", scope: !2653, file: !2, line: 814, type: !114)
!2653 = distinct !DILexicalBlock(scope: !2654, file: !2, line: 793, column: 45)
!2654 = distinct !DILexicalBlock(scope: !2651, file: !2, line: 793, column: 5)
!2655 = !DILocalVariable(name: "x", scope: !2656, file: !2, line: 842, type: !190)
!2656 = distinct !DILexicalBlock(scope: !2614, file: !2, line: 842, column: 5)
!2657 = !DILocalVariable(name: "pages_total", scope: !2658, file: !2, line: 845, type: !114)
!2658 = distinct !DILexicalBlock(scope: !2659, file: !2, line: 842, column: 49)
!2659 = distinct !DILexicalBlock(scope: !2656, file: !2, line: 842, column: 5)
!2660 = !DILocation(line: 0, scope: !2614, inlinedAt: !2661)
!2661 = distinct !DILocation(line: 1093, column: 28, scope: !2595)
!2662 = distinct !DIAssignID()
!2663 = distinct !DIAssignID()
!2664 = !DILocation(line: 0, scope: !2573)
!2665 = !DILocation(line: 1065, column: 5, scope: !2573)
!2666 = !DILocation(line: 1068, column: 17, scope: !2573)
!2667 = !DILocation(line: 1069, column: 11, scope: !2668)
!2668 = distinct !DILexicalBlock(scope: !2573, file: !2, line: 1069, column: 9)
!2669 = !DILocation(line: 1069, column: 9, scope: !2573)
!2670 = !DILocation(line: 1070, column: 17, scope: !2671)
!2671 = distinct !DILexicalBlock(scope: !2668, file: !2, line: 1069, column: 20)
!2672 = !DILocation(line: 1070, column: 9, scope: !2671)
!2673 = !DILocation(line: 1071, column: 9, scope: !2671)
!2674 = !DILocation(line: 1074, column: 36, scope: !2573)
!2675 = !{!1468, !1212, i64 272}
!2676 = !DILocation(line: 1074, column: 27, scope: !2573)
!2677 = !DILocation(line: 1074, column: 20, scope: !2573)
!2678 = !DILocation(line: 1075, column: 22, scope: !2679)
!2679 = distinct !DILexicalBlock(scope: !2573, file: !2, line: 1075, column: 9)
!2680 = !DILocation(line: 1075, column: 9, scope: !2573)
!2681 = !DILocation(line: 1076, column: 17, scope: !2682)
!2682 = distinct !DILexicalBlock(scope: !2679, file: !2, line: 1075, column: 31)
!2683 = !DILocation(line: 1076, column: 9, scope: !2682)
!2684 = !DILocation(line: 1077, column: 9, scope: !2682)
!2685 = !DILocation(line: 1080, column: 30, scope: !2573)
!2686 = !DILocation(line: 1080, column: 5, scope: !2573)
!2687 = !DILocation(line: 1081, column: 10, scope: !2573)
!2688 = !DILocation(line: 1081, column: 15, scope: !2573)
!2689 = !{!2690, !1336, i64 104}
!2690 = !{!"storage_compact_wrap", !1517, i64 0, !1204, i64 64, !1336, i64 104, !1336, i64 105, !1336, i64 106}
!2691 = distinct !DIAssignID()
!2692 = !DILocation(line: 1082, column: 10, scope: !2573)
!2693 = !DILocation(line: 1082, column: 20, scope: !2573)
!2694 = !{!2690, !1336, i64 105}
!2695 = distinct !DIAssignID()
!2696 = !DILocation(line: 1083, column: 18, scope: !2573)
!2697 = !{!2690, !1312, i64 0}
!2698 = distinct !DIAssignID()
!2699 = !DILocation(line: 1084, column: 13, scope: !2573)
!2700 = !DILocation(line: 1084, column: 17, scope: !2573)
!2701 = !{!2690, !1312, i64 24}
!2702 = distinct !DIAssignID()
!2703 = !DILocation(line: 1085, column: 13, scope: !2573)
!2704 = !DILocation(line: 1085, column: 17, scope: !2573)
!2705 = !{!2690, !1312, i64 16}
!2706 = distinct !DIAssignID()
!2707 = !DILocation(line: 1087, column: 28, scope: !2573)
!2708 = !DILocation(line: 1087, column: 13, scope: !2573)
!2709 = !DILocation(line: 1087, column: 17, scope: !2573)
!2710 = !{!2690, !1212, i64 40}
!2711 = distinct !DIAssignID()
!2712 = !DILocation(line: 1088, column: 13, scope: !2573)
!2713 = !DILocation(line: 1088, column: 18, scope: !2573)
!2714 = !{!2690, !1212, i64 52}
!2715 = distinct !DIAssignID()
!2716 = !DILocation(line: 1089, column: 13, scope: !2573)
!2717 = !DILocation(line: 1089, column: 16, scope: !2573)
!2718 = !{!2690, !1312, i64 56}
!2719 = distinct !DIAssignID()
!2720 = !DILocation(line: 1090, column: 5, scope: !2573)
!2721 = !DILocation(line: 1092, column: 5, scope: !2573)
!2722 = !DILocation(line: 1061, column: 14, scope: !2573)
!2723 = distinct !{!2723, !2721, !2724}
!2724 = !DILocation(line: 1142, column: 5, scope: !2573)
!2725 = !DILocation(line: 1060, column: 14, scope: !2573)
!2726 = !DILocation(line: 1062, column: 14, scope: !2573)
!2727 = !DILocation(line: 1059, column: 14, scope: !2573)
!2728 = !DILocation(line: 1066, column: 5, scope: !2573)
!2729 = !DILocation(line: 1058, column: 10, scope: !2573)
!2730 = !DILocation(line: 1093, column: 14, scope: !2595)
!2731 = !DILocation(line: 1093, column: 25, scope: !2595)
!2732 = !DILocation(line: 771, column: 5, scope: !2614, inlinedAt: !2661)
!2733 = !DILocation(line: 772, column: 5, scope: !2614, inlinedAt: !2661)
!2734 = !DILocation(line: 775, column: 5, scope: !2614, inlinedAt: !2661)
!2735 = !DILocation(line: 776, column: 12, scope: !2736, inlinedAt: !2661)
!2736 = distinct !DILexicalBlock(scope: !2614, file: !2, line: 776, column: 9)
!2737 = !DILocation(line: 776, column: 23, scope: !2736, inlinedAt: !2661)
!2738 = !DILocation(line: 776, column: 9, scope: !2614, inlinedAt: !2661)
!2739 = !DILocation(line: 0, scope: !2647, inlinedAt: !2661)
!2740 = !DILocation(line: 780, column: 9, scope: !2741, inlinedAt: !2661)
!2741 = distinct !DILexicalBlock(scope: !2742, file: !2, line: 779, column: 49)
!2742 = distinct !DILexicalBlock(scope: !2647, file: !2, line: 779, column: 5)
!2743 = !DILocation(line: 782, column: 35, scope: !2741, inlinedAt: !2661)
!2744 = !DILocation(line: 784, column: 24, scope: !2614, inlinedAt: !2661)
!2745 = !DILocation(line: 786, column: 21, scope: !2614, inlinedAt: !2661)
!2746 = !DILocation(line: 786, column: 18, scope: !2614, inlinedAt: !2661)
!2747 = !DILocation(line: 786, column: 42, scope: !2614, inlinedAt: !2661)
!2748 = !{!1468, !1469, i64 288}
!2749 = !DILocation(line: 786, column: 31, scope: !2614, inlinedAt: !2661)
!2750 = !DILocation(line: 0, scope: !2649, inlinedAt: !2661)
!2751 = !DILocation(line: 787, column: 5, scope: !2752, inlinedAt: !2661)
!2752 = distinct !DILexicalBlock(scope: !2649, file: !2, line: 787, column: 5)
!2753 = !DILocation(line: 787, column: 5, scope: !2649, inlinedAt: !2661)
!2754 = !DILocation(line: 789, column: 30, scope: !2614, inlinedAt: !2661)
!2755 = !DILocation(line: 789, column: 20, scope: !2614, inlinedAt: !2661)
!2756 = !DILocation(line: 789, column: 18, scope: !2614, inlinedAt: !2661)
!2757 = distinct !DIAssignID()
!2758 = !DILocation(line: 790, column: 5, scope: !2614, inlinedAt: !2661)
!2759 = !DILocation(line: 0, scope: !2651, inlinedAt: !2661)
!2760 = !DILocation(line: 793, column: 23, scope: !2654, inlinedAt: !2661)
!2761 = !DILocation(line: 822, column: 13, scope: !2614, inlinedAt: !2661)
!2762 = !DILocation(line: 793, column: 5, scope: !2651, inlinedAt: !2661)
!2763 = !DILocation(line: 821, column: 21, scope: !2614, inlinedAt: !2661)
!2764 = !DILocation(line: 822, column: 5, scope: !2614, inlinedAt: !2661)
!2765 = !DILocation(line: 825, column: 14, scope: !2766, inlinedAt: !2661)
!2766 = distinct !DILexicalBlock(scope: !2614, file: !2, line: 825, column: 9)
!2767 = !{!2768, !1212, i64 40}
!2768 = !{!"__storage_buk", !1212, i64 0, !1212, i64 4, !1212, i64 8, !1320, i64 16, !1320, i64 24, !1212, i64 32, !1212, i64 36, !1212, i64 40, !1212, i64 44, !1336, i64 48, !1336, i64 49}
!2769 = !DILocation(line: 825, column: 26, scope: !2766, inlinedAt: !2661)
!2770 = !DILocation(line: 825, column: 9, scope: !2614, inlinedAt: !2661)
!2771 = !DILocation(line: 794, column: 40, scope: !2653, inlinedAt: !2661)
!2772 = !DILocation(line: 794, column: 16, scope: !2653, inlinedAt: !2661)
!2773 = !DILocation(line: 795, column: 14, scope: !2653, inlinedAt: !2661)
!2774 = !DILocation(line: 795, column: 25, scope: !2653, inlinedAt: !2661)
!2775 = !DILocation(line: 796, column: 13, scope: !2776, inlinedAt: !2661)
!2776 = distinct !DILexicalBlock(scope: !2653, file: !2, line: 796, column: 13)
!2777 = !DILocation(line: 796, column: 29, scope: !2776, inlinedAt: !2661)
!2778 = !DILocation(line: 796, column: 37, scope: !2776, inlinedAt: !2661)
!2779 = !DILocation(line: 796, column: 13, scope: !2653, inlinedAt: !2661)
!2780 = !DILocation(line: 797, column: 18, scope: !2781, inlinedAt: !2661)
!2781 = distinct !DILexicalBlock(scope: !2776, file: !2, line: 796, column: 43)
!2782 = !DILocation(line: 797, column: 28, scope: !2781, inlinedAt: !2661)
!2783 = !{!2768, !1212, i64 32}
!2784 = !DILocation(line: 799, column: 13, scope: !2781, inlinedAt: !2661)
!2785 = !DILocation(line: 801, column: 18, scope: !2786, inlinedAt: !2661)
!2786 = distinct !DILexicalBlock(scope: !2776, file: !2, line: 800, column: 16)
!2787 = !DILocation(line: 801, column: 28, scope: !2786, inlinedAt: !2661)
!2788 = !{!2768, !1212, i64 36}
!2789 = !DILocation(line: 805, column: 29, scope: !2790, inlinedAt: !2661)
!2790 = distinct !DILexicalBlock(scope: !2653, file: !2, line: 805, column: 13)
!2791 = !{!1335, !1336, i64 24}
!2792 = !DILocation(line: 805, column: 13, scope: !2653, inlinedAt: !2661)
!2793 = !DILocation(line: 809, column: 44, scope: !2794, inlinedAt: !2661)
!2794 = distinct !DILexicalBlock(scope: !2653, file: !2, line: 809, column: 13)
!2795 = !{!2768, !1320, i64 24}
!2796 = !DILocation(line: 809, column: 37, scope: !2794, inlinedAt: !2661)
!2797 = !DILocation(line: 809, column: 13, scope: !2653, inlinedAt: !2661)
!2798 = !DILocation(line: 810, column: 18, scope: !2799, inlinedAt: !2661)
!2799 = distinct !DILexicalBlock(scope: !2794, file: !2, line: 809, column: 60)
!2800 = !DILocation(line: 810, column: 30, scope: !2799, inlinedAt: !2661)
!2801 = !{!2768, !1212, i64 8}
!2802 = !DILocation(line: 811, column: 33, scope: !2799, inlinedAt: !2661)
!2803 = !DILocation(line: 812, column: 9, scope: !2799, inlinedAt: !2661)
!2804 = !DILocation(line: 814, column: 32, scope: !2653, inlinedAt: !2661)
!2805 = !DILocation(line: 814, column: 60, scope: !2653, inlinedAt: !2661)
!2806 = !DILocation(line: 814, column: 42, scope: !2653, inlinedAt: !2661)
!2807 = !DILocation(line: 814, column: 29, scope: !2653, inlinedAt: !2661)
!2808 = !DILocation(line: 0, scope: !2653, inlinedAt: !2661)
!2809 = !DILocation(line: 815, column: 40, scope: !2810, inlinedAt: !2661)
!2810 = distinct !DILexicalBlock(scope: !2653, file: !2, line: 815, column: 13)
!2811 = !DILocation(line: 815, column: 53, scope: !2810, inlinedAt: !2661)
!2812 = !DILocation(line: 815, column: 68, scope: !2810, inlinedAt: !2661)
!2813 = !{!2768, !1212, i64 44}
!2814 = !DILocation(line: 815, column: 61, scope: !2810, inlinedAt: !2661)
!2815 = !DILocation(line: 815, column: 13, scope: !2653, inlinedAt: !2661)
!2816 = !DILocation(line: 816, column: 18, scope: !2817, inlinedAt: !2661)
!2817 = distinct !DILexicalBlock(scope: !2810, file: !2, line: 815, column: 86)
!2818 = !DILocation(line: 816, column: 27, scope: !2817, inlinedAt: !2661)
!2819 = !{!2768, !1212, i64 4}
!2820 = !DILocation(line: 817, column: 18, scope: !2817, inlinedAt: !2661)
!2821 = !DILocation(line: 817, column: 30, scope: !2817, inlinedAt: !2661)
!2822 = !{!2768, !1320, i64 16}
!2823 = !DILocation(line: 818, column: 35, scope: !2817, inlinedAt: !2661)
!2824 = !DILocation(line: 819, column: 9, scope: !2817, inlinedAt: !2661)
!2825 = !DILocation(line: 793, column: 41, scope: !2654, inlinedAt: !2661)
!2826 = distinct !{!2826, !2762, !2827, !1346}
!2827 = !DILocation(line: 820, column: 5, scope: !2651, inlinedAt: !2661)
!2828 = !DILocation(line: 826, column: 32, scope: !2829, inlinedAt: !2661)
!2829 = distinct !DILexicalBlock(scope: !2766, file: !2, line: 825, column: 32)
!2830 = !DILocation(line: 827, column: 18, scope: !2831, inlinedAt: !2661)
!2831 = distinct !DILexicalBlock(scope: !2829, file: !2, line: 827, column: 13)
!2832 = !DILocation(line: 827, column: 29, scope: !2831, inlinedAt: !2661)
!2833 = !DILocation(line: 827, column: 34, scope: !2831, inlinedAt: !2661)
!2834 = !DILocation(line: 827, column: 42, scope: !2831, inlinedAt: !2661)
!2835 = !DILocation(line: 827, column: 57, scope: !2831, inlinedAt: !2661)
!2836 = !DILocation(line: 827, column: 13, scope: !2829, inlinedAt: !2661)
!2837 = !DILocation(line: 834, column: 14, scope: !2838, inlinedAt: !2661)
!2838 = distinct !DILexicalBlock(scope: !2614, file: !2, line: 834, column: 9)
!2839 = !DILocation(line: 834, column: 26, scope: !2838, inlinedAt: !2661)
!2840 = !DILocation(line: 834, column: 9, scope: !2614, inlinedAt: !2661)
!2841 = !DILocation(line: 835, column: 24, scope: !2842, inlinedAt: !2661)
!2842 = distinct !DILexicalBlock(scope: !2838, file: !2, line: 834, column: 32)
!2843 = !DILocation(line: 836, column: 18, scope: !2844, inlinedAt: !2661)
!2844 = distinct !DILexicalBlock(scope: !2842, file: !2, line: 836, column: 13)
!2845 = !DILocation(line: 836, column: 29, scope: !2844, inlinedAt: !2661)
!2846 = !DILocation(line: 836, column: 34, scope: !2844, inlinedAt: !2661)
!2847 = !DILocation(line: 836, column: 42, scope: !2844, inlinedAt: !2661)
!2848 = !DILocation(line: 836, column: 57, scope: !2844, inlinedAt: !2661)
!2849 = !DILocation(line: 836, column: 13, scope: !2842, inlinedAt: !2661)
!2850 = !DILocation(line: 0, scope: !2656, inlinedAt: !2661)
!2851 = !DILocation(line: 845, column: 41, scope: !2658, inlinedAt: !2661)
!2852 = !DILocation(line: 0, scope: !2658, inlinedAt: !2661)
!2853 = !DILocation(line: 848, column: 25, scope: !2854, inlinedAt: !2661)
!2854 = distinct !DILexicalBlock(scope: !2658, file: !2, line: 848, column: 13)
!2855 = !DILocation(line: 848, column: 30, scope: !2854, inlinedAt: !2661)
!2856 = !DILocation(line: 851, column: 18, scope: !2857, inlinedAt: !2661)
!2857 = distinct !DILexicalBlock(scope: !2658, file: !2, line: 851, column: 13)
!2858 = !DILocation(line: 851, column: 40, scope: !2857, inlinedAt: !2661)
!2859 = !{!1468, !1212, i64 276}
!2860 = !DILocation(line: 851, column: 29, scope: !2857, inlinedAt: !2661)
!2861 = !DILocation(line: 851, column: 13, scope: !2658, inlinedAt: !2661)
!2862 = !DILocation(line: 852, column: 22, scope: !2863, inlinedAt: !2661)
!2863 = distinct !DILexicalBlock(scope: !2864, file: !2, line: 852, column: 17)
!2864 = distinct !DILexicalBlock(scope: !2857, file: !2, line: 851, column: 59)
!2865 = !DILocation(line: 852, column: 34, scope: !2863, inlinedAt: !2661)
!2866 = !DILocation(line: 852, column: 17, scope: !2864, inlinedAt: !2661)
!2867 = !DILocation(line: 843, column: 16, scope: !2658, inlinedAt: !2661)
!2868 = !DILocation(line: 854, column: 33, scope: !2869, inlinedAt: !2661)
!2869 = distinct !DILexicalBlock(scope: !2863, file: !2, line: 852, column: 49)
!2870 = !DILocation(line: 856, column: 17, scope: !2869, inlinedAt: !2661)
!2871 = !DILocation(line: 857, column: 51, scope: !2872, inlinedAt: !2661)
!2872 = distinct !DILexicalBlock(scope: !2863, file: !2, line: 857, column: 24)
!2873 = !{!1468, !1212, i64 280}
!2874 = !DILocation(line: 857, column: 40, scope: !2872, inlinedAt: !2661)
!2875 = !DILocation(line: 858, column: 21, scope: !2872, inlinedAt: !2661)
!2876 = !DILocation(line: 858, column: 29, scope: !2872, inlinedAt: !2661)
!2877 = !DILocation(line: 858, column: 44, scope: !2872, inlinedAt: !2661)
!2878 = !DILocation(line: 857, column: 24, scope: !2863, inlinedAt: !2661)
!2879 = !DILocation(line: 867, column: 30, scope: !2880, inlinedAt: !2661)
!2880 = distinct !DILexicalBlock(scope: !2881, file: !2, line: 867, column: 21)
!2881 = distinct !DILexicalBlock(scope: !2872, file: !2, line: 858, column: 59)
!2882 = !{!1468, !1336, i64 304}
!2883 = !DILocation(line: 867, column: 21, scope: !2881, inlinedAt: !2661)
!2884 = !DILocation(line: 878, column: 40, scope: !2885, inlinedAt: !2661)
!2885 = distinct !DILexicalBlock(scope: !2881, file: !2, line: 878, column: 21)
!2886 = !DILocation(line: 878, column: 28, scope: !2885, inlinedAt: !2661)
!2887 = !DILocation(line: 880, column: 36, scope: !2888, inlinedAt: !2661)
!2888 = distinct !DILexicalBlock(scope: !2885, file: !2, line: 878, column: 85)
!2889 = !DILocation(line: 881, column: 37, scope: !2888, inlinedAt: !2661)
!2890 = !DILocation(line: 883, column: 21, scope: !2888, inlinedAt: !2661)
!2891 = !DILocation(line: 890, column: 1, scope: !2614, inlinedAt: !2661)
!2892 = !DILocation(line: 1093, column: 13, scope: !2596)
!2893 = !DILocation(line: 0, scope: !2593)
!2894 = !DILocation(line: 1097, column: 13, scope: !2895)
!2895 = distinct !DILexicalBlock(scope: !2593, file: !2, line: 1097, column: 13)
!2896 = !DILocation(line: 1097, column: 13, scope: !2593)
!2897 = !DILocation(line: 1100, column: 13, scope: !2898)
!2898 = distinct !DILexicalBlock(scope: !2595, file: !2, line: 1099, column: 16)
!2899 = !DILocation(line: 1103, column: 16, scope: !2596)
!2900 = !DILocation(line: 1103, column: 9, scope: !2596)
!2901 = !DILocation(line: 1104, column: 13, scope: !2602)
!2902 = !DILocation(line: 1105, column: 17, scope: !2601)
!2903 = !DILocation(line: 1105, column: 29, scope: !2601)
!2904 = !DILocation(line: 1105, column: 41, scope: !2601)
!2905 = !DILocation(line: 1105, column: 50, scope: !2601)
!2906 = !DILocation(line: 1105, column: 55, scope: !2601)
!2907 = !DILocation(line: 1105, column: 64, scope: !2601)
!2908 = !DILocation(line: 1105, column: 17, scope: !2602)
!2909 = !DILocation(line: 1106, column: 38, scope: !2910)
!2910 = distinct !DILexicalBlock(scope: !2601, file: !2, line: 1105, column: 75)
!2911 = !{!2690, !1212, i64 36}
!2912 = distinct !DIAssignID()
!2913 = !DILocation(line: 1107, column: 33, scope: !2910)
!2914 = !{!2690, !1207, i64 48}
!2915 = distinct !DIAssignID()
!2916 = !DILocation(line: 1108, column: 32, scope: !2910)
!2917 = !{!2690, !1212, i64 44}
!2918 = distinct !DIAssignID()
!2919 = !DILocation(line: 1110, column: 30, scope: !2910)
!2920 = !{!2690, !1312, i64 8}
!2921 = distinct !DIAssignID()
!2922 = !DILocation(line: 1111, column: 32, scope: !2910)
!2923 = distinct !DIAssignID()
!2924 = !DILocation(line: 1112, column: 27, scope: !2910)
!2925 = !{!2690, !1336, i64 106}
!2926 = distinct !DIAssignID()
!2927 = !DILocation(line: 1114, column: 17, scope: !2910)
!2928 = !DILocation(line: 1115, column: 13, scope: !2910)
!2929 = !DILocation(line: 1115, column: 29, scope: !2600)
!2930 = !DILocation(line: 1115, column: 24, scope: !2601)
!2931 = !DILocation(line: 0, scope: !2598)
!2932 = !DILocation(line: 1116, column: 17, scope: !2933)
!2933 = distinct !DILexicalBlock(scope: !2598, file: !2, line: 1116, column: 17)
!2934 = !DILocation(line: 1116, column: 17, scope: !2598)
!2935 = !DILocation(line: 1118, column: 27, scope: !2599)
!2936 = distinct !DIAssignID()
!2937 = !DILocation(line: 1119, column: 32, scope: !2599)
!2938 = distinct !DIAssignID()
!2939 = !DILocation(line: 1121, column: 13, scope: !2599)
!2940 = !DILocation(line: 1121, column: 29, scope: !2606)
!2941 = !DILocation(line: 1121, column: 39, scope: !2606)
!2942 = !DILocation(line: 1121, column: 47, scope: !2606)
!2943 = !DILocation(line: 1121, column: 24, scope: !2600)
!2944 = !DILocation(line: 0, scope: !2604)
!2945 = !DILocation(line: 1122, column: 17, scope: !2946)
!2946 = distinct !DILexicalBlock(scope: !2604, file: !2, line: 1122, column: 17)
!2947 = !DILocation(line: 1122, column: 17, scope: !2604)
!2948 = !DILocation(line: 1126, column: 34, scope: !2605)
!2949 = !DILocation(line: 1126, column: 25, scope: !2605)
!2950 = !DILocalVariable(name: "io", scope: !2951, file: !2, line: 957, type: !876)
!2951 = distinct !DILexicalBlock(scope: !2952, file: !2, line: 954, column: 27)
!2952 = distinct !DILexicalBlock(scope: !2953, file: !2, line: 954, column: 17)
!2953 = distinct !DILexicalBlock(scope: !2954, file: !2, line: 927, column: 29)
!2954 = distinct !DILexicalBlock(scope: !2955, file: !2, line: 927, column: 13)
!2955 = distinct !DILexicalBlock(scope: !2956, file: !2, line: 912, column: 32)
!2956 = distinct !DISubprogram(name: "storage_compact_readback", scope: !2, file: !2, line: 902, type: !2957, scopeLine: 904, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !2959)
!2957 = !DISubroutineType(types: !2958)
!2958 = !{null, !191, !668, !2583, !193, !297, !209, !297, !209}
!2959 = !{!2960, !2961, !2962, !2963, !2964, !2965, !2966, !2967, !2968, !2969, !2970, !2971, !2972, !2973, !2974, !2975, !2976, !2977, !2978, !2979, !2980, !2981, !2982, !2950, !2983, !2986, !2989, !2990, !2993}
!2960 = !DILocalVariable(name: "storage", arg: 1, scope: !2956, file: !2, line: 902, type: !191)
!2961 = !DILocalVariable(name: "l", arg: 2, scope: !2956, file: !2, line: 902, type: !668)
!2962 = !DILocalVariable(name: "flags", arg: 3, scope: !2956, file: !2, line: 903, type: !2583)
!2963 = !DILocalVariable(name: "readback_buf", arg: 4, scope: !2956, file: !2, line: 903, type: !193)
!2964 = !DILocalVariable(name: "page_id", arg: 5, scope: !2956, file: !2, line: 904, type: !297)
!2965 = !DILocalVariable(name: "page_version", arg: 6, scope: !2956, file: !2, line: 904, type: !209)
!2966 = !DILocalVariable(name: "page_offset", arg: 7, scope: !2956, file: !2, line: 904, type: !297)
!2967 = !DILocalVariable(name: "read_size", arg: 8, scope: !2956, file: !2, line: 904, type: !209)
!2968 = !DILocalVariable(name: "offset", scope: !2956, file: !2, line: 905, type: !209)
!2969 = !DILocalVariable(name: "rescues", scope: !2956, file: !2, line: 906, type: !114)
!2970 = !DILocalVariable(name: "lost", scope: !2956, file: !2, line: 907, type: !114)
!2971 = !DILocalVariable(name: "skipped", scope: !2956, file: !2, line: 908, type: !114)
!2972 = !DILocalVariable(name: "rescue_cold", scope: !2956, file: !2, line: 909, type: !114)
!2973 = !DILocalVariable(name: "rescue_old", scope: !2956, file: !2, line: 910, type: !114)
!2974 = !DILocalVariable(name: "hdr_it", scope: !2955, file: !2, line: 913, type: !614)
!2975 = !DILocalVariable(name: "hdr", scope: !2955, file: !2, line: 914, type: !286)
!2976 = !DILocalVariable(name: "it", scope: !2955, file: !2, line: 915, type: !614)
!2977 = !DILocalVariable(name: "ntotal", scope: !2955, file: !2, line: 916, type: !114)
!2978 = !DILocalVariable(name: "hv", scope: !2955, file: !2, line: 923, type: !297)
!2979 = !DILocalVariable(name: "do_write", scope: !2953, file: !2, line: 928, type: !629)
!2980 = !DILocalVariable(name: "bucket", scope: !2953, file: !2, line: 929, type: !190)
!2981 = !DILocalVariable(name: "do_update", scope: !2951, file: !2, line: 955, type: !629)
!2982 = !DILocalVariable(name: "tries", scope: !2951, file: !2, line: 956, type: !190)
!2983 = !DILocalVariable(name: "rescued", scope: !2984, file: !2, line: 972, type: !629)
!2984 = distinct !DILexicalBlock(scope: !2985, file: !2, line: 971, column: 32)
!2985 = distinct !DILexicalBlock(scope: !2951, file: !2, line: 971, column: 21)
!2986 = !DILocalVariable(name: "flags", scope: !2987, file: !2, line: 980, type: !296)
!2987 = distinct !DILexicalBlock(scope: !2988, file: !2, line: 978, column: 28)
!2988 = distinct !DILexicalBlock(scope: !2984, file: !2, line: 973, column: 25)
!2989 = !DILocalVariable(name: "new_it", scope: !2987, file: !2, line: 982, type: !614)
!2990 = !DILocalVariable(name: "new_hdr", scope: !2991, file: !2, line: 992, type: !286)
!2991 = distinct !DILexicalBlock(scope: !2992, file: !2, line: 983, column: 37)
!2992 = distinct !DILexicalBlock(scope: !2987, file: !2, line: 983, column: 29)
!2993 = !DILocalVariable(name: "myl", scope: !2994, file: !2, line: 1035, type: !668)
!2994 = distinct !DILexicalBlock(scope: !2956, file: !2, line: 1035, column: 5)
!2995 = !DILocation(line: 0, scope: !2951, inlinedAt: !2996)
!2996 = distinct !DILocation(line: 1124, column: 17, scope: !2605)
!2997 = !DILocation(line: 0, scope: !2956, inlinedAt: !2996)
!2998 = !DILocation(line: 912, column: 5, scope: !2956, inlinedAt: !2996)
!2999 = !DILocation(line: 910, column: 18, scope: !2956, inlinedAt: !2996)
!3000 = !DILocation(line: 909, column: 18, scope: !2956, inlinedAt: !2996)
!3001 = !DILocation(line: 908, column: 18, scope: !2956, inlinedAt: !2996)
!3002 = !DILocation(line: 907, column: 18, scope: !2956, inlinedAt: !2996)
!3003 = !DILocation(line: 906, column: 18, scope: !2956, inlinedAt: !2996)
!3004 = !DILocation(line: 905, column: 14, scope: !2956, inlinedAt: !2996)
!3005 = !DILocation(line: 912, column: 19, scope: !2956, inlinedAt: !2996)
!3006 = !DILocation(line: 0, scope: !2955, inlinedAt: !2996)
!3007 = !DILocation(line: 915, column: 41, scope: !2955, inlinedAt: !2996)
!3008 = !DILocation(line: 918, column: 17, scope: !3009, inlinedAt: !2996)
!3009 = distinct !DILexicalBlock(scope: !2955, file: !2, line: 918, column: 13)
!3010 = !DILocation(line: 918, column: 22, scope: !3009, inlinedAt: !2996)
!3011 = !DILocation(line: 918, column: 13, scope: !2955, inlinedAt: !2996)
!3012 = !DILocation(line: 922, column: 18, scope: !2955, inlinedAt: !2996)
!3013 = !DILocation(line: 923, column: 37, scope: !2955, inlinedAt: !2996)
!3014 = !DILocation(line: 924, column: 9, scope: !2955, inlinedAt: !2996)
!3015 = !DILocation(line: 926, column: 29, scope: !2955, inlinedAt: !2996)
!3016 = !DILocation(line: 926, column: 47, scope: !2955, inlinedAt: !2996)
!3017 = !DILocation(line: 926, column: 43, scope: !2955, inlinedAt: !2996)
!3018 = !DILocation(line: 926, column: 18, scope: !2955, inlinedAt: !2996)
!3019 = !DILocation(line: 927, column: 20, scope: !2954, inlinedAt: !2996)
!3020 = !DILocation(line: 927, column: 13, scope: !2955, inlinedAt: !2996)
!3021 = !DILocation(line: 0, scope: !2953, inlinedAt: !2996)
!3022 = !DILocation(line: 930, column: 13, scope: !2953, inlinedAt: !2996)
!3023 = !DILocation(line: 933, column: 26, scope: !3024, inlinedAt: !2996)
!3024 = distinct !DILexicalBlock(scope: !2953, file: !2, line: 933, column: 17)
!3025 = !DILocation(line: 933, column: 35, scope: !3024, inlinedAt: !2996)
!3026 = !DILocation(line: 933, column: 47, scope: !3024, inlinedAt: !2996)
!3027 = !DILocation(line: 933, column: 51, scope: !3024, inlinedAt: !2996)
!3028 = !DILocation(line: 933, column: 75, scope: !3024, inlinedAt: !2996)
!3029 = !DILocation(line: 934, column: 29, scope: !3024, inlinedAt: !2996)
!3030 = !DILocation(line: 934, column: 37, scope: !3024, inlinedAt: !2996)
!3031 = !DILocation(line: 934, column: 42, scope: !3024, inlinedAt: !2996)
!3032 = !DILocation(line: 934, column: 63, scope: !3024, inlinedAt: !2996)
!3033 = !DILocation(line: 934, column: 61, scope: !3024, inlinedAt: !2996)
!3034 = !DILocation(line: 933, column: 17, scope: !2953, inlinedAt: !2996)
!3035 = !DILocation(line: 935, column: 35, scope: !3036, inlinedAt: !2996)
!3036 = distinct !DILexicalBlock(scope: !3024, file: !2, line: 934, column: 78)
!3037 = !DILocation(line: 936, column: 26, scope: !3038, inlinedAt: !2996)
!3038 = distinct !DILexicalBlock(scope: !3036, file: !2, line: 936, column: 21)
!3039 = !DILocation(line: 936, column: 21, scope: !3038, inlinedAt: !2996)
!3040 = !DILocation(line: 936, column: 34, scope: !3038, inlinedAt: !2996)
!3041 = !DILocation(line: 936, column: 45, scope: !3038, inlinedAt: !2996)
!3042 = !DILocation(line: 936, column: 53, scope: !3038, inlinedAt: !2996)
!3043 = !DILocation(line: 936, column: 48, scope: !3038, inlinedAt: !2996)
!3044 = !DILocation(line: 936, column: 66, scope: !3038, inlinedAt: !2996)
!3045 = !DILocation(line: 937, column: 25, scope: !3038, inlinedAt: !2996)
!3046 = !DILocation(line: 937, column: 33, scope: !3038, inlinedAt: !2996)
!3047 = !DILocation(line: 937, column: 43, scope: !3038, inlinedAt: !2996)
!3048 = !DILocation(line: 937, column: 55, scope: !3038, inlinedAt: !2996)
!3049 = !DILocation(line: 937, column: 40, scope: !3038, inlinedAt: !2996)
!3050 = !DILocation(line: 936, column: 21, scope: !3036, inlinedAt: !2996)
!3051 = !DILocation(line: 939, column: 21, scope: !3052, inlinedAt: !2996)
!3052 = distinct !DILexicalBlock(scope: !3038, file: !2, line: 937, column: 70)
!3053 = !DILocation(line: 942, column: 25, scope: !3054, inlinedAt: !2996)
!3054 = distinct !DILexicalBlock(scope: !3052, file: !2, line: 942, column: 25)
!3055 = !DILocation(line: 942, column: 54, scope: !3054, inlinedAt: !2996)
!3056 = !DILocation(line: 942, column: 25, scope: !3052, inlinedAt: !2996)
!3057 = !DILocation(line: 954, column: 17, scope: !2953, inlinedAt: !2996)
!3058 = !DILocation(line: 957, column: 17, scope: !2951, inlinedAt: !2996)
!3059 = !DILocation(line: 958, column: 24, scope: !2951, inlinedAt: !2996)
!3060 = distinct !DIAssignID()
!3061 = !DILocation(line: 959, column: 25, scope: !2951, inlinedAt: !2996)
!3062 = distinct !DIAssignID()
!3063 = !DILocation(line: 961, column: 25, scope: !3064, inlinedAt: !2996)
!3064 = distinct !DILexicalBlock(scope: !3065, file: !2, line: 961, column: 25)
!3065 = distinct !DILexicalBlock(scope: !3066, file: !2, line: 960, column: 54)
!3066 = distinct !DILexicalBlock(scope: !3067, file: !2, line: 960, column: 17)
!3067 = distinct !DILexicalBlock(scope: !2951, file: !2, line: 960, column: 17)
!3068 = !DILocation(line: 961, column: 78, scope: !3064, inlinedAt: !2996)
!3069 = !DILocation(line: 961, column: 25, scope: !3065, inlinedAt: !2996)
!3070 = !DILocation(line: 967, column: 25, scope: !3071, inlinedAt: !2996)
!3071 = distinct !DILexicalBlock(scope: !3064, file: !2, line: 966, column: 28)
!3072 = !DILocation(line: 1015, column: 25, scope: !3073, inlinedAt: !2996)
!3073 = distinct !DILexicalBlock(scope: !2985, file: !2, line: 1014, column: 24)
!3074 = !DILocation(line: 962, column: 35, scope: !3075, inlinedAt: !2996)
!3075 = distinct !DILexicalBlock(scope: !3064, file: !2, line: 961, column: 84)
!3076 = !DILocation(line: 962, column: 47, scope: !3075, inlinedAt: !2996)
!3077 = !DILocation(line: 962, column: 44, scope: !3075, inlinedAt: !2996)
!3078 = !DILocation(line: 962, column: 25, scope: !3075, inlinedAt: !2996)
!3079 = !DILocation(line: 963, column: 25, scope: !3075, inlinedAt: !2996)
!3080 = !DILocation(line: 0, scope: !2984, inlinedAt: !2996)
!3081 = !DILocation(line: 973, column: 29, scope: !2988, inlinedAt: !2996)
!3082 = !DILocation(line: 973, column: 38, scope: !2988, inlinedAt: !2996)
!3083 = !DILocation(line: 973, column: 25, scope: !2984, inlinedAt: !2996)
!3084 = !DILocation(line: 974, column: 48, scope: !3085, inlinedAt: !2996)
!3085 = distinct !DILexicalBlock(scope: !2988, file: !2, line: 973, column: 44)
!3086 = !DILocation(line: 974, column: 43, scope: !3085, inlinedAt: !2996)
!3087 = !DILocation(line: 975, column: 43, scope: !3085, inlinedAt: !2996)
!3088 = !DILocation(line: 975, column: 38, scope: !3085, inlinedAt: !2996)
!3089 = !DILocation(line: 976, column: 42, scope: !3085, inlinedAt: !2996)
!3090 = !DILocation(line: 976, column: 37, scope: !3085, inlinedAt: !2996)
!3091 = !DILocation(line: 978, column: 21, scope: !3085, inlinedAt: !2996)
!3092 = !DILocation(line: 981, column: 25, scope: !3093, inlinedAt: !2996)
!3093 = distinct !DILexicalBlock(scope: !3094, file: !2, line: 981, column: 25)
!3094 = distinct !DILexicalBlock(scope: !2987, file: !2, line: 981, column: 25)
!3095 = !DILocation(line: 982, column: 80, scope: !2987, inlinedAt: !2996)
!3096 = !DILocation(line: 981, column: 25, scope: !3094, inlinedAt: !2996)
!3097 = !DILocation(line: 981, column: 25, scope: !3098, inlinedAt: !2996)
!3098 = distinct !DILexicalBlock(scope: !3093, file: !2, line: 981, column: 25)
!3099 = !DILocation(line: 0, scope: !2987, inlinedAt: !2996)
!3100 = !DILocation(line: 982, column: 54, scope: !2987, inlinedAt: !2996)
!3101 = !DILocation(line: 982, column: 101, scope: !2987, inlinedAt: !2996)
!3102 = !DILocation(line: 982, column: 40, scope: !2987, inlinedAt: !2996)
!3103 = !DILocation(line: 983, column: 29, scope: !2992, inlinedAt: !2996)
!3104 = !DILocation(line: 983, column: 29, scope: !2987, inlinedAt: !2996)
!3105 = !DILocation(line: 987, column: 56, scope: !2991, inlinedAt: !2996)
!3106 = !DILocation(line: 987, column: 65, scope: !2991, inlinedAt: !2996)
!3107 = !DILocation(line: 987, column: 37, scope: !2991, inlinedAt: !2996)
!3108 = !DILocation(line: 987, column: 46, scope: !2991, inlinedAt: !2996)
!3109 = !DILocation(line: 988, column: 52, scope: !2991, inlinedAt: !2996)
!3110 = !DILocation(line: 988, column: 37, scope: !2991, inlinedAt: !2996)
!3111 = !DILocation(line: 988, column: 42, scope: !2991, inlinedAt: !2996)
!3112 = !DILocation(line: 989, column: 54, scope: !2991, inlinedAt: !2996)
!3113 = !DILocation(line: 989, column: 37, scope: !2991, inlinedAt: !2996)
!3114 = !DILocation(line: 989, column: 44, scope: !2991, inlinedAt: !2996)
!3115 = !DILocation(line: 992, column: 62, scope: !2991, inlinedAt: !2996)
!3116 = !DILocation(line: 0, scope: !2991, inlinedAt: !2996)
!3117 = !DILocation(line: 993, column: 56, scope: !2991, inlinedAt: !2996)
!3118 = !DILocation(line: 993, column: 51, scope: !2991, inlinedAt: !2996)
!3119 = !DILocation(line: 994, column: 51, scope: !2991, inlinedAt: !2996)
!3120 = !DILocation(line: 994, column: 38, scope: !2991, inlinedAt: !2996)
!3121 = !DILocation(line: 994, column: 46, scope: !2991, inlinedAt: !2996)
!3122 = !DILocation(line: 995, column: 50, scope: !2991, inlinedAt: !2996)
!3123 = !DILocation(line: 995, column: 38, scope: !2991, inlinedAt: !2996)
!3124 = !DILocation(line: 995, column: 45, scope: !2991, inlinedAt: !2996)
!3125 = !DILocation(line: 998, column: 62, scope: !2991, inlinedAt: !2996)
!3126 = !DILocation(line: 998, column: 29, scope: !2991, inlinedAt: !2996)
!3127 = !DILocation(line: 999, column: 29, scope: !2991, inlinedAt: !2996)
!3128 = !DILocation(line: 1001, column: 25, scope: !2991, inlinedAt: !2996)
!3129 = !DILocation(line: 1002, column: 33, scope: !3130, inlinedAt: !2996)
!3130 = distinct !DILexicalBlock(scope: !2992, file: !2, line: 1001, column: 32)
!3131 = !DILocation(line: 1006, column: 25, scope: !2984, inlinedAt: !2996)
!3132 = !DILocation(line: 1007, column: 32, scope: !3133, inlinedAt: !2996)
!3133 = distinct !DILexicalBlock(scope: !3134, file: !2, line: 1006, column: 34)
!3134 = distinct !DILexicalBlock(scope: !2984, file: !2, line: 1006, column: 25)
!3135 = !DILocation(line: 1008, column: 29, scope: !3133, inlinedAt: !2996)
!3136 = !DILocation(line: 1009, column: 40, scope: !3137, inlinedAt: !2996)
!3137 = distinct !DILexicalBlock(scope: !3138, file: !2, line: 1008, column: 64)
!3138 = distinct !DILexicalBlock(scope: !3133, file: !2, line: 1008, column: 29)
!3139 = !DILocation(line: 1010, column: 25, scope: !3137, inlinedAt: !2996)
!3140 = !DILocation(line: 1011, column: 39, scope: !3141, inlinedAt: !2996)
!3141 = distinct !DILexicalBlock(scope: !3142, file: !2, line: 1010, column: 63)
!3142 = distinct !DILexicalBlock(scope: !3138, file: !2, line: 1010, column: 36)
!3143 = !DILocation(line: 1012, column: 25, scope: !3141, inlinedAt: !2996)
!3144 = !DILocation(line: 1017, column: 13, scope: !2952, inlinedAt: !2996)
!3145 = !DILocation(line: 1017, column: 13, scope: !2951, inlinedAt: !2996)
!3146 = !DILocation(line: 1019, column: 13, scope: !2953, inlinedAt: !2996)
!3147 = !DILocation(line: 1020, column: 9, scope: !2953, inlinedAt: !2996)
!3148 = !DILocation(line: 1022, column: 9, scope: !2955, inlinedAt: !2996)
!3149 = !DILocation(line: 1023, column: 19, scope: !2955, inlinedAt: !2996)
!3150 = !DILocation(line: 1023, column: 16, scope: !2955, inlinedAt: !2996)
!3151 = !DILocation(line: 1024, column: 23, scope: !3152, inlinedAt: !2996)
!3152 = distinct !DILexicalBlock(scope: !2955, file: !2, line: 1024, column: 13)
!3153 = !DILocation(line: 1024, column: 32, scope: !3152, inlinedAt: !2996)
!3154 = !DILocation(line: 1028, column: 5, scope: !2956, inlinedAt: !2996)
!3155 = !DILocation(line: 1029, column: 36, scope: !2956, inlinedAt: !2996)
!3156 = !DILocation(line: 1029, column: 33, scope: !2956, inlinedAt: !2996)
!3157 = !DILocation(line: 1030, column: 39, scope: !2956, inlinedAt: !2996)
!3158 = !DILocation(line: 1030, column: 36, scope: !2956, inlinedAt: !2996)
!3159 = !DILocation(line: 1031, column: 39, scope: !2956, inlinedAt: !2996)
!3160 = !DILocation(line: 1031, column: 36, scope: !2956, inlinedAt: !2996)
!3161 = !DILocation(line: 1032, column: 41, scope: !2956, inlinedAt: !2996)
!3162 = !DILocation(line: 1032, column: 38, scope: !2956, inlinedAt: !2996)
!3163 = !DILocation(line: 1033, column: 40, scope: !2956, inlinedAt: !2996)
!3164 = !DILocation(line: 1033, column: 37, scope: !2956, inlinedAt: !2996)
!3165 = !DILocation(line: 1034, column: 5, scope: !2956, inlinedAt: !2996)
!3166 = !DILocation(line: 0, scope: !2994, inlinedAt: !2996)
!3167 = !DILocation(line: 1035, column: 5, scope: !3168, inlinedAt: !2996)
!3168 = distinct !DILexicalBlock(scope: !2994, file: !2, line: 1035, column: 5)
!3169 = !DILocation(line: 1035, column: 5, scope: !2994, inlinedAt: !2996)
!3170 = !DILocation(line: 1127, column: 41, scope: !2605)
!3171 = !DILocation(line: 1127, column: 29, scope: !2605)
!3172 = !DILocation(line: 1128, column: 27, scope: !2605)
!3173 = distinct !DIAssignID()
!3174 = !DILocation(line: 1129, column: 32, scope: !2605)
!3175 = distinct !DIAssignID()
!3176 = !DILocation(line: 1130, column: 13, scope: !2605)
!3177 = !DILocation(line: 1130, column: 24, scope: !2606)
!3178 = !DILocation(line: 1132, column: 27, scope: !2609)
!3179 = distinct !DIAssignID()
!3180 = !DILocation(line: 1133, column: 32, scope: !2609)
!3181 = distinct !DIAssignID()
!3182 = !DILocation(line: 1134, column: 17, scope: !2609)
!3183 = !DILocation(line: 0, scope: !2608)
!3184 = !DILocation(line: 1135, column: 17, scope: !3185)
!3185 = distinct !DILexicalBlock(scope: !2608, file: !2, line: 1135, column: 17)
!3186 = !DILocation(line: 1135, column: 17, scope: !2608)
!3187 = !DILocation(line: 1138, column: 17, scope: !2609)
!3188 = !DILocation(line: 1139, column: 13, scope: !2609)
!3189 = !DILocation(line: 1140, column: 13, scope: !2602)
!3190 = distinct !{!3190, !2900, !3191, !1346}
!3191 = !DILocation(line: 1141, column: 9, scope: !2596)
!3192 = distinct !DISubprogram(name: "storage_conf_parse", scope: !2, file: !2, line: 1190, type: !3193, scopeLine: 1190, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !3195)
!3193 = !DISubroutineType(types: !3194)
!3194 = !{!202, !193, !114}
!3195 = !{!3196, !3197, !3198, !3199, !3200, !3201, !3202, !3203, !3204, !3206}
!3196 = !DILocalVariable(name: "arg", arg: 1, scope: !3192, file: !2, line: 1190, type: !193)
!3197 = !DILocalVariable(name: "page_size", arg: 2, scope: !3192, file: !2, line: 1190, type: !114)
!3198 = !DILocalVariable(name: "cf", scope: !3192, file: !2, line: 1191, type: !202)
!3199 = !DILocalVariable(name: "b", scope: !3192, file: !2, line: 1192, type: !193)
!3200 = !DILocalVariable(name: "p", scope: !3192, file: !2, line: 1193, type: !193)
!3201 = !DILocalVariable(name: "unit", scope: !3192, file: !2, line: 1194, type: !4)
!3202 = !DILocalVariable(name: "multiplier", scope: !3192, file: !2, line: 1195, type: !209)
!3203 = !DILocalVariable(name: "base_size", scope: !3192, file: !2, line: 1196, type: !190)
!3204 = !DILocalVariable(name: "__res", scope: !3205, file: !2, line: 1208, type: !190)
!3205 = distinct !DILexicalBlock(scope: !3192, file: !2, line: 1208, column: 12)
!3206 = !DILabel(scope: !3192, name: "error", file: !2, line: 1267)
!3207 = distinct !DIAssignID()
!3208 = !DILocation(line: 0, scope: !3192)
!3209 = !DILocation(line: 1192, column: 5, scope: !3192)
!3210 = !DILocation(line: 1192, column: 11, scope: !3192)
!3211 = distinct !DIAssignID()
!3212 = !DILocation(line: 1193, column: 15, scope: !3192)
!3213 = !DILocation(line: 1197, column: 11, scope: !3214)
!3214 = distinct !DILexicalBlock(scope: !3192, file: !2, line: 1197, column: 9)
!3215 = !DILocation(line: 1197, column: 9, scope: !3192)
!3216 = !DILocation(line: 1200, column: 10, scope: !3192)
!3217 = !DILocation(line: 1201, column: 16, scope: !3192)
!3218 = !DILocation(line: 1201, column: 9, scope: !3192)
!3219 = !DILocation(line: 1201, column: 14, scope: !3192)
!3220 = !{!3221, !1312, i64 8}
!3221 = !{!"extstore_conf_file", !1212, i64 0, !1312, i64 8, !1212, i64 16, !1320, i64 24, !1212, i64 32, !1212, i64 36, !1312, i64 40}
!3222 = !DILocation(line: 1203, column: 9, scope: !3192)
!3223 = !DILocation(line: 1204, column: 11, scope: !3224)
!3224 = distinct !DILexicalBlock(scope: !3192, file: !2, line: 1204, column: 9)
!3225 = !DILocation(line: 1204, column: 9, scope: !3192)
!3226 = !DILocation(line: 1205, column: 17, scope: !3227)
!3227 = distinct !DILexicalBlock(scope: !3224, file: !2, line: 1204, column: 20)
!3228 = !DILocation(line: 1205, column: 9, scope: !3227)
!3229 = !DILocation(line: 1206, column: 9, scope: !3227)
!3230 = !DILocation(line: 1208, column: 12, scope: !3231)
!3231 = distinct !DILexicalBlock(scope: !3205, file: !2, line: 1208, column: 12)
!3232 = !DILocation(line: 0, scope: !3205)
!3233 = !DILocation(line: 1209, column: 20, scope: !3192)
!3234 = !DILocation(line: 1211, column: 13, scope: !3192)
!3235 = !DILocation(line: 1211, column: 5, scope: !3192)
!3236 = !DILocation(line: 1217, column: 13, scope: !3237)
!3237 = distinct !DILexicalBlock(scope: !3192, file: !2, line: 1211, column: 19)
!3238 = !DILocation(line: 1221, column: 13, scope: !3237)
!3239 = !DILocation(line: 1225, column: 13, scope: !3237)
!3240 = !DILocation(line: 1227, column: 21, scope: !3237)
!3241 = !DILocation(line: 1227, column: 13, scope: !3237)
!3242 = !DILocation(line: 1228, column: 13, scope: !3237)
!3243 = !DILocation(line: 0, scope: !3237)
!3244 = !DILocalVariable(name: "__nptr", arg: 1, scope: !3245, file: !1355, line: 481, type: !1258)
!3245 = distinct !DISubprogram(name: "atoi", scope: !1355, file: !1355, line: 481, type: !3246, scopeLine: 482, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !3248)
!3246 = !DISubroutineType(types: !3247)
!3247 = !{!190, !1258}
!3248 = !{!3244}
!3249 = !DILocation(line: 0, scope: !3245, inlinedAt: !3250)
!3250 = distinct !DILocation(line: 1230, column: 17, scope: !3192)
!3251 = !DILocation(line: 483, column: 16, scope: !3245, inlinedAt: !3250)
!3252 = !DILocation(line: 1231, column: 19, scope: !3192)
!3253 = !DILocation(line: 1231, column: 16, scope: !3192)
!3254 = !DILocation(line: 1233, column: 35, scope: !3192)
!3255 = !DILocation(line: 1233, column: 33, scope: !3192)
!3256 = !DILocation(line: 1233, column: 22, scope: !3192)
!3257 = !DILocation(line: 1233, column: 20, scope: !3192)
!3258 = !{!3221, !1212, i64 0}
!3259 = !DILocation(line: 1235, column: 24, scope: !3260)
!3260 = distinct !DILexicalBlock(scope: !3192, file: !2, line: 1235, column: 9)
!3261 = !DILocation(line: 1235, column: 9, scope: !3192)
!3262 = !DILocation(line: 1236, column: 17, scope: !3263)
!3263 = distinct !DILexicalBlock(scope: !3260, file: !2, line: 1235, column: 30)
!3264 = !DILocation(line: 1236, column: 9, scope: !3263)
!3265 = !DILocation(line: 1237, column: 9, scope: !3263)
!3266 = !DILocation(line: 1241, column: 9, scope: !3192)
!3267 = !DILocation(line: 1244, column: 11, scope: !3268)
!3268 = distinct !DILexicalBlock(scope: !3192, file: !2, line: 1244, column: 9)
!3269 = !DILocation(line: 1244, column: 9, scope: !3192)
!3270 = !DILocation(line: 1245, column: 13, scope: !3271)
!3271 = distinct !DILexicalBlock(scope: !3272, file: !2, line: 1245, column: 13)
!3272 = distinct !DILexicalBlock(scope: !3268, file: !2, line: 1244, column: 20)
!3273 = !DILocation(line: 1245, column: 34, scope: !3271)
!3274 = !DILocation(line: 1245, column: 13, scope: !3272)
!3275 = !DILocation(line: 1246, column: 17, scope: !3276)
!3276 = distinct !DILexicalBlock(scope: !3271, file: !2, line: 1245, column: 40)
!3277 = !DILocation(line: 1246, column: 29, scope: !3276)
!3278 = !{!3221, !1212, i64 36}
!3279 = !DILocation(line: 1247, column: 9, scope: !3276)
!3280 = !DILocation(line: 1247, column: 20, scope: !3281)
!3281 = distinct !DILexicalBlock(scope: !3271, file: !2, line: 1247, column: 20)
!3282 = !DILocation(line: 1247, column: 40, scope: !3281)
!3283 = !DILocation(line: 1247, column: 20, scope: !3271)
!3284 = !DILocation(line: 1248, column: 17, scope: !3285)
!3285 = distinct !DILexicalBlock(scope: !3281, file: !2, line: 1247, column: 46)
!3286 = !DILocation(line: 1248, column: 29, scope: !3285)
!3287 = !DILocation(line: 1249, column: 9, scope: !3285)
!3288 = !DILocation(line: 1249, column: 20, scope: !3289)
!3289 = distinct !DILexicalBlock(scope: !3281, file: !2, line: 1249, column: 20)
!3290 = !DILocation(line: 1249, column: 41, scope: !3289)
!3291 = !DILocation(line: 1249, column: 20, scope: !3281)
!3292 = !DILocation(line: 1250, column: 17, scope: !3293)
!3293 = distinct !DILexicalBlock(scope: !3289, file: !2, line: 1249, column: 47)
!3294 = !DILocation(line: 1250, column: 29, scope: !3293)
!3295 = !DILocation(line: 1251, column: 9, scope: !3293)
!3296 = !DILocation(line: 1251, column: 20, scope: !3297)
!3297 = distinct !DILexicalBlock(scope: !3289, file: !2, line: 1251, column: 20)
!3298 = !DILocation(line: 1251, column: 41, scope: !3297)
!3299 = !DILocation(line: 1251, column: 20, scope: !3289)
!3300 = !DILocation(line: 1253, column: 20, scope: !3301)
!3301 = distinct !DILexicalBlock(scope: !3297, file: !2, line: 1253, column: 20)
!3302 = !DILocation(line: 1253, column: 45, scope: !3301)
!3303 = !DILocation(line: 1253, column: 20, scope: !3297)
!3304 = !DILocation(line: 1254, column: 17, scope: !3305)
!3305 = distinct !DILexicalBlock(scope: !3301, file: !2, line: 1253, column: 51)
!3306 = !DILocation(line: 1254, column: 29, scope: !3305)
!3307 = !DILocation(line: 1255, column: 9, scope: !3305)
!3308 = !DILocation(line: 1255, column: 20, scope: !3309)
!3309 = distinct !DILexicalBlock(scope: !3301, file: !2, line: 1255, column: 20)
!3310 = !DILocation(line: 1255, column: 37, scope: !3309)
!3311 = !DILocation(line: 1255, column: 20, scope: !3301)
!3312 = !DILocation(line: 1256, column: 17, scope: !3313)
!3313 = distinct !DILexicalBlock(scope: !3309, file: !2, line: 1255, column: 43)
!3314 = !DILocation(line: 1256, column: 29, scope: !3313)
!3315 = !DILocation(line: 1258, column: 21, scope: !3316)
!3316 = distinct !DILexicalBlock(scope: !3309, file: !2, line: 1257, column: 16)
!3317 = !DILocation(line: 1258, column: 13, scope: !3316)
!3318 = !DILocation(line: 1259, column: 13, scope: !3316)
!3319 = !DILocation(line: 1267, column: 1, scope: !3192)
!3320 = !DILocation(line: 1269, column: 13, scope: !3321)
!3321 = distinct !DILexicalBlock(scope: !3322, file: !2, line: 1269, column: 13)
!3322 = distinct !DILexicalBlock(scope: !3323, file: !2, line: 1268, column: 13)
!3323 = distinct !DILexicalBlock(scope: !3192, file: !2, line: 1268, column: 9)
!3324 = !DILocation(line: 1269, column: 13, scope: !3322)
!3325 = !DILocation(line: 1270, column: 13, scope: !3321)
!3326 = !DILocation(line: 1271, column: 9, scope: !3322)
!3327 = !DILocation(line: 1272, column: 5, scope: !3322)
!3328 = !DILocation(line: 1274, column: 1, scope: !3192)
!3329 = !DISubprogram(name: "strtok_r", scope: !2528, file: !2528, line: 366, type: !3330, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3330 = !DISubroutineType(types: !3331)
!3331 = !{!193, !1363, !1364, !3332}
!3332 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !192)
!3333 = !DISubprogram(name: "strdup", scope: !2528, file: !2528, line: 187, type: !3334, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3334 = !DISubroutineType(types: !3335)
!3335 = !{!193, !1258}
!3336 = !DISubprogram(name: "__ctype_tolower_loc", scope: !3337, file: !3337, line: 81, type: !3338, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3337 = !DIFile(filename: "/usr/include/ctype.h", directory: "", checksumkind: CSK_MD5, checksum: "43fd45dcf96e8fb7d8f14700096497c7")
!3338 = !DISubroutineType(types: !3339)
!3339 = !{!3340}
!3340 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3341, size: 64)
!3341 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3342, size: 64)
!3342 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !3343)
!3343 = !DIDerivedType(tag: DW_TAG_typedef, name: "__int32_t", file: !212, line: 41, baseType: !190)
!3344 = !DISubprogram(name: "strlen", scope: !2528, file: !2528, line: 407, type: !3345, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3345 = !DISubroutineType(types: !3346)
!3346 = !{!213, !1258}
!3347 = !DISubprogram(name: "strcmp", scope: !2528, file: !2528, line: 156, type: !3348, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3348 = !DISubroutineType(types: !3349)
!3349 = !{!190, !1258, !1258}
!3350 = distinct !DISubprogram(name: "storage_init_config", scope: !2, file: !2, line: 1281, type: !3351, scopeLine: 1281, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !3434)
!3351 = !DISubroutineType(types: !3352)
!3352 = !{!191, !3353}
!3353 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3354, size: 64)
!3354 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "settings", file: !113, line: 454, size: 2688, elements: !3355)
!3355 = !{!3356, !3357, !3358, !3359, !3360, !3361, !3362, !3363, !3364, !3365, !3366, !3367, !3369, !3370, !3371, !3372, !3373, !3374, !3375, !3376, !3377, !3378, !3379, !3380, !3381, !3386, !3387, !3388, !3389, !3390, !3391, !3392, !3393, !3394, !3395, !3396, !3397, !3398, !3399, !3400, !3401, !3402, !3403, !3404, !3405, !3406, !3407, !3408, !3409, !3410, !3411, !3412, !3413, !3414, !3415, !3416, !3417, !3418, !3419, !3420, !3421, !3422, !3423, !3424, !3425, !3426, !3427, !3428, !3429, !3430, !3431, !3432, !3433}
!3356 = !DIDerivedType(tag: DW_TAG_member, name: "maxbytes", scope: !3354, file: !113, line: 455, baseType: !584, size: 64)
!3357 = !DIDerivedType(tag: DW_TAG_member, name: "maxconns", scope: !3354, file: !113, line: 456, baseType: !190, size: 32, offset: 64)
!3358 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !3354, file: !113, line: 457, baseType: !190, size: 32, offset: 96)
!3359 = !DIDerivedType(tag: DW_TAG_member, name: "udpport", scope: !3354, file: !113, line: 458, baseType: !190, size: 32, offset: 128)
!3360 = !DIDerivedType(tag: DW_TAG_member, name: "inter", scope: !3354, file: !113, line: 459, baseType: !193, size: 64, offset: 192)
!3361 = !DIDerivedType(tag: DW_TAG_member, name: "verbose", scope: !3354, file: !113, line: 460, baseType: !190, size: 32, offset: 256)
!3362 = !DIDerivedType(tag: DW_TAG_member, name: "oldest_live", scope: !3354, file: !113, line: 461, baseType: !314, size: 32, offset: 288)
!3363 = !DIDerivedType(tag: DW_TAG_member, name: "evict_to_free", scope: !3354, file: !113, line: 462, baseType: !190, size: 32, offset: 320)
!3364 = !DIDerivedType(tag: DW_TAG_member, name: "socketpath", scope: !3354, file: !113, line: 463, baseType: !193, size: 64, offset: 384)
!3365 = !DIDerivedType(tag: DW_TAG_member, name: "auth_file", scope: !3354, file: !113, line: 464, baseType: !193, size: 64, offset: 448)
!3366 = !DIDerivedType(tag: DW_TAG_member, name: "access", scope: !3354, file: !113, line: 465, baseType: !190, size: 32, offset: 512)
!3367 = !DIDerivedType(tag: DW_TAG_member, name: "factor", scope: !3354, file: !113, line: 466, baseType: !3368, size: 64, offset: 576)
!3368 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!3369 = !DIDerivedType(tag: DW_TAG_member, name: "chunk_size", scope: !3354, file: !113, line: 467, baseType: !190, size: 32, offset: 640)
!3370 = !DIDerivedType(tag: DW_TAG_member, name: "num_threads", scope: !3354, file: !113, line: 468, baseType: !190, size: 32, offset: 672)
!3371 = !DIDerivedType(tag: DW_TAG_member, name: "num_threads_per_udp", scope: !3354, file: !113, line: 469, baseType: !190, size: 32, offset: 704)
!3372 = !DIDerivedType(tag: DW_TAG_member, name: "prefix_delimiter", scope: !3354, file: !113, line: 470, baseType: !4, size: 8, offset: 736)
!3373 = !DIDerivedType(tag: DW_TAG_member, name: "detail_enabled", scope: !3354, file: !113, line: 471, baseType: !190, size: 32, offset: 768)
!3374 = !DIDerivedType(tag: DW_TAG_member, name: "reqs_per_event", scope: !3354, file: !113, line: 472, baseType: !190, size: 32, offset: 800)
!3375 = !DIDerivedType(tag: DW_TAG_member, name: "use_cas", scope: !3354, file: !113, line: 474, baseType: !629, size: 8, offset: 832)
!3376 = !DIDerivedType(tag: DW_TAG_member, name: "binding_protocol", scope: !3354, file: !113, line: 475, baseType: !165, size: 32, offset: 864)
!3377 = !DIDerivedType(tag: DW_TAG_member, name: "backlog", scope: !3354, file: !113, line: 476, baseType: !190, size: 32, offset: 896)
!3378 = !DIDerivedType(tag: DW_TAG_member, name: "item_size_max", scope: !3354, file: !113, line: 477, baseType: !190, size: 32, offset: 928)
!3379 = !DIDerivedType(tag: DW_TAG_member, name: "slab_chunk_size_max", scope: !3354, file: !113, line: 478, baseType: !190, size: 32, offset: 960)
!3380 = !DIDerivedType(tag: DW_TAG_member, name: "slab_page_size", scope: !3354, file: !113, line: 479, baseType: !190, size: 32, offset: 992)
!3381 = !DIDerivedType(tag: DW_TAG_member, name: "sig_hup", scope: !3354, file: !113, line: 480, baseType: !3382, size: 32, offset: 1024)
!3382 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !3383)
!3383 = !DIDerivedType(tag: DW_TAG_typedef, name: "sig_atomic_t", file: !3384, line: 8, baseType: !3385)
!3384 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/sig_atomic_t.h", directory: "", checksumkind: CSK_MD5, checksum: "d9236f7e3e7f10f53aa9d4cd97f503cf")
!3385 = !DIDerivedType(tag: DW_TAG_typedef, name: "__sig_atomic_t", file: !212, line: 215, baseType: !190)
!3386 = !DIDerivedType(tag: DW_TAG_member, name: "sasl", scope: !3354, file: !113, line: 481, baseType: !629, size: 8, offset: 1056)
!3387 = !DIDerivedType(tag: DW_TAG_member, name: "maxconns_fast", scope: !3354, file: !113, line: 482, baseType: !629, size: 8, offset: 1064)
!3388 = !DIDerivedType(tag: DW_TAG_member, name: "lru_crawler", scope: !3354, file: !113, line: 483, baseType: !629, size: 8, offset: 1072)
!3389 = !DIDerivedType(tag: DW_TAG_member, name: "lru_maintainer_thread", scope: !3354, file: !113, line: 484, baseType: !629, size: 8, offset: 1080)
!3390 = !DIDerivedType(tag: DW_TAG_member, name: "lru_segmented", scope: !3354, file: !113, line: 485, baseType: !629, size: 8, offset: 1088)
!3391 = !DIDerivedType(tag: DW_TAG_member, name: "slab_reassign", scope: !3354, file: !113, line: 486, baseType: !629, size: 8, offset: 1096)
!3392 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove", scope: !3354, file: !113, line: 487, baseType: !190, size: 32, offset: 1120)
!3393 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove_ratio", scope: !3354, file: !113, line: 488, baseType: !3368, size: 64, offset: 1152)
!3394 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove_window", scope: !3354, file: !113, line: 489, baseType: !114, size: 32, offset: 1216)
!3395 = !DIDerivedType(tag: DW_TAG_member, name: "hashpower_init", scope: !3354, file: !113, line: 490, baseType: !190, size: 32, offset: 1248)
!3396 = !DIDerivedType(tag: DW_TAG_member, name: "shutdown_command", scope: !3354, file: !113, line: 491, baseType: !629, size: 8, offset: 1280)
!3397 = !DIDerivedType(tag: DW_TAG_member, name: "tail_repair_time", scope: !3354, file: !113, line: 492, baseType: !190, size: 32, offset: 1312)
!3398 = !DIDerivedType(tag: DW_TAG_member, name: "flush_enabled", scope: !3354, file: !113, line: 493, baseType: !629, size: 8, offset: 1344)
!3399 = !DIDerivedType(tag: DW_TAG_member, name: "dump_enabled", scope: !3354, file: !113, line: 494, baseType: !629, size: 8, offset: 1352)
!3400 = !DIDerivedType(tag: DW_TAG_member, name: "hash_algorithm", scope: !3354, file: !113, line: 495, baseType: !193, size: 64, offset: 1408)
!3401 = !DIDerivedType(tag: DW_TAG_member, name: "lru_crawler_sleep", scope: !3354, file: !113, line: 496, baseType: !190, size: 32, offset: 1472)
!3402 = !DIDerivedType(tag: DW_TAG_member, name: "lru_crawler_tocrawl", scope: !3354, file: !113, line: 497, baseType: !297, size: 32, offset: 1504)
!3403 = !DIDerivedType(tag: DW_TAG_member, name: "hot_lru_pct", scope: !3354, file: !113, line: 498, baseType: !190, size: 32, offset: 1536)
!3404 = !DIDerivedType(tag: DW_TAG_member, name: "warm_lru_pct", scope: !3354, file: !113, line: 499, baseType: !190, size: 32, offset: 1568)
!3405 = !DIDerivedType(tag: DW_TAG_member, name: "hot_max_factor", scope: !3354, file: !113, line: 500, baseType: !3368, size: 64, offset: 1600)
!3406 = !DIDerivedType(tag: DW_TAG_member, name: "warm_max_factor", scope: !3354, file: !113, line: 501, baseType: !3368, size: 64, offset: 1664)
!3407 = !DIDerivedType(tag: DW_TAG_member, name: "crawls_persleep", scope: !3354, file: !113, line: 502, baseType: !190, size: 32, offset: 1728)
!3408 = !DIDerivedType(tag: DW_TAG_member, name: "temp_lru", scope: !3354, file: !113, line: 503, baseType: !629, size: 8, offset: 1760)
!3409 = !DIDerivedType(tag: DW_TAG_member, name: "temporary_ttl", scope: !3354, file: !113, line: 504, baseType: !297, size: 32, offset: 1792)
!3410 = !DIDerivedType(tag: DW_TAG_member, name: "idle_timeout", scope: !3354, file: !113, line: 505, baseType: !190, size: 32, offset: 1824)
!3411 = !DIDerivedType(tag: DW_TAG_member, name: "logger_watcher_buf_size", scope: !3354, file: !113, line: 506, baseType: !114, size: 32, offset: 1856)
!3412 = !DIDerivedType(tag: DW_TAG_member, name: "logger_buf_size", scope: !3354, file: !113, line: 507, baseType: !114, size: 32, offset: 1888)
!3413 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_mem_limit", scope: !3354, file: !113, line: 508, baseType: !114, size: 32, offset: 1920)
!3414 = !DIDerivedType(tag: DW_TAG_member, name: "drop_privileges", scope: !3354, file: !113, line: 509, baseType: !629, size: 8, offset: 1952)
!3415 = !DIDerivedType(tag: DW_TAG_member, name: "watch_enabled", scope: !3354, file: !113, line: 510, baseType: !629, size: 8, offset: 1960)
!3416 = !DIDerivedType(tag: DW_TAG_member, name: "relaxed_privileges", scope: !3354, file: !113, line: 511, baseType: !629, size: 8, offset: 1968)
!3417 = !DIDerivedType(tag: DW_TAG_member, name: "ext_io_threadcount", scope: !3354, file: !113, line: 513, baseType: !114, size: 32, offset: 1984)
!3418 = !DIDerivedType(tag: DW_TAG_member, name: "ext_page_size", scope: !3354, file: !113, line: 514, baseType: !114, size: 32, offset: 2016)
!3419 = !DIDerivedType(tag: DW_TAG_member, name: "ext_item_size", scope: !3354, file: !113, line: 515, baseType: !114, size: 32, offset: 2048)
!3420 = !DIDerivedType(tag: DW_TAG_member, name: "ext_item_age", scope: !3354, file: !113, line: 516, baseType: !114, size: 32, offset: 2080)
!3421 = !DIDerivedType(tag: DW_TAG_member, name: "ext_low_ttl", scope: !3354, file: !113, line: 517, baseType: !114, size: 32, offset: 2112)
!3422 = !DIDerivedType(tag: DW_TAG_member, name: "ext_recache_rate", scope: !3354, file: !113, line: 518, baseType: !114, size: 32, offset: 2144)
!3423 = !DIDerivedType(tag: DW_TAG_member, name: "ext_wbuf_size", scope: !3354, file: !113, line: 519, baseType: !114, size: 32, offset: 2176)
!3424 = !DIDerivedType(tag: DW_TAG_member, name: "ext_compact_under", scope: !3354, file: !113, line: 520, baseType: !114, size: 32, offset: 2208)
!3425 = !DIDerivedType(tag: DW_TAG_member, name: "ext_drop_under", scope: !3354, file: !113, line: 521, baseType: !114, size: 32, offset: 2240)
!3426 = !DIDerivedType(tag: DW_TAG_member, name: "ext_max_sleep", scope: !3354, file: !113, line: 522, baseType: !114, size: 32, offset: 2272)
!3427 = !DIDerivedType(tag: DW_TAG_member, name: "ext_max_frag", scope: !3354, file: !113, line: 523, baseType: !3368, size: 64, offset: 2304)
!3428 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove_freeratio", scope: !3354, file: !113, line: 524, baseType: !3368, size: 64, offset: 2368)
!3429 = !DIDerivedType(tag: DW_TAG_member, name: "ext_drop_unread", scope: !3354, file: !113, line: 525, baseType: !629, size: 8, offset: 2432)
!3430 = !DIDerivedType(tag: DW_TAG_member, name: "ext_global_pool_min", scope: !3354, file: !113, line: 527, baseType: !114, size: 32, offset: 2464)
!3431 = !DIDerivedType(tag: DW_TAG_member, name: "num_napi_ids", scope: !3354, file: !113, line: 544, baseType: !190, size: 32, offset: 2496)
!3432 = !DIDerivedType(tag: DW_TAG_member, name: "memory_file", scope: !3354, file: !113, line: 545, baseType: !193, size: 64, offset: 2560)
!3433 = !DIDerivedType(tag: DW_TAG_member, name: "sock_cookie_id", scope: !3354, file: !113, line: 555, baseType: !297, size: 32, offset: 2624)
!3434 = !{!3435, !3436}
!3435 = !DILocalVariable(name: "s", arg: 1, scope: !3350, file: !2, line: 1281, type: !3353)
!3436 = !DILocalVariable(name: "cf", scope: !3350, file: !2, line: 1282, type: !198)
!3437 = !DILocation(line: 0, scope: !3350)
!3438 = !DILocation(line: 1282, column: 35, scope: !3350)
!3439 = !DILocation(line: 1284, column: 8, scope: !3350)
!3440 = !DILocation(line: 1284, column: 22, scope: !3350)
!3441 = !DILocation(line: 1288, column: 8, scope: !3350)
!3442 = !DILocation(line: 1289, column: 8, scope: !3350)
!3443 = !DILocation(line: 1289, column: 24, scope: !3350)
!3444 = !DILocation(line: 1290, column: 8, scope: !3350)
!3445 = !DILocation(line: 1290, column: 22, scope: !3350)
!3446 = !DILocation(line: 1288, column: 21, scope: !3350)
!3447 = !{!1469, !1469, i64 0}
!3448 = !DILocation(line: 1295, column: 8, scope: !3350)
!3449 = !DILocation(line: 1295, column: 22, scope: !3350)
!3450 = !{!1468, !1212, i64 252}
!3451 = !DILocation(line: 1296, column: 8, scope: !3350)
!3452 = !DILocation(line: 1296, column: 27, scope: !3350)
!3453 = !{!1468, !1212, i64 248}
!3454 = !DILocation(line: 1297, column: 37, scope: !3350)
!3455 = !DILocation(line: 1297, column: 9, scope: !3350)
!3456 = !DILocation(line: 1297, column: 26, scope: !3350)
!3457 = !{!3458, !1212, i64 8}
!3458 = !{!"storage_settings", !1312, i64 0, !3459, i64 8}
!3459 = !{!"extstore_conf", !1212, i64 0, !1212, i64 4, !1212, i64 8, !1212, i64 12, !1212, i64 16, !1212, i64 20, !1212, i64 24, !1212, i64 28}
!3460 = !DILocation(line: 1298, column: 37, scope: !3350)
!3461 = !DILocation(line: 1298, column: 16, scope: !3350)
!3462 = !DILocation(line: 1298, column: 26, scope: !3350)
!3463 = !{!3458, !1212, i64 24}
!3464 = !DILocation(line: 1299, column: 42, scope: !3350)
!3465 = !DILocation(line: 1299, column: 16, scope: !3350)
!3466 = !DILocation(line: 1299, column: 31, scope: !3350)
!3467 = !{!3458, !1212, i64 32}
!3468 = !DILocation(line: 1300, column: 16, scope: !3350)
!3469 = !DILocation(line: 1300, column: 25, scope: !3350)
!3470 = !{!3458, !1212, i64 36}
!3471 = !DILocation(line: 1301, column: 16, scope: !3350)
!3472 = !DILocation(line: 1301, column: 29, scope: !3350)
!3473 = !{!3458, !1212, i64 16}
!3474 = !DILocation(line: 1302, column: 16, scope: !3350)
!3475 = !DILocation(line: 1302, column: 27, scope: !3350)
!3476 = !{!3458, !1212, i64 28}
!3477 = !DILocation(line: 1304, column: 5, scope: !3350)
!3478 = distinct !DIAssignID()
!3479 = !DILocation(line: 0, scope: !187)
!3480 = distinct !DIAssignID()
!3481 = !DILocation(line: 1310, column: 41, scope: !187)
!3482 = !DILocation(line: 1311, column: 5, scope: !187)
!3483 = !DILocation(line: 1331, column: 5, scope: !187)
!3484 = !DILocation(line: 1331, column: 17, scope: !187)
!3485 = distinct !DIAssignID()
!3486 = !DILocation(line: 1350, column: 13, scope: !187)
!3487 = !DILocation(line: 1350, column: 5, scope: !187)
!3488 = !DILocation(line: 1352, column: 21, scope: !3489)
!3489 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1352, column: 17)
!3490 = !{!3458, !1312, i64 0}
!3491 = !DILocation(line: 1352, column: 17, scope: !3489)
!3492 = !DILocation(line: 1352, column: 17, scope: !239)
!3493 = !DILocation(line: 1353, column: 25, scope: !3494)
!3494 = distinct !DILexicalBlock(scope: !3489, file: !2, line: 1352, column: 35)
!3495 = !DILocation(line: 1353, column: 17, scope: !3494)
!3496 = !DILocation(line: 1354, column: 17, scope: !3494)
!3497 = !DILocation(line: 1356, column: 17, scope: !3498)
!3498 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1356, column: 17)
!3499 = !DILocation(line: 1356, column: 31, scope: !3498)
!3500 = !DILocation(line: 1356, column: 17, scope: !239)
!3501 = !DILocation(line: 1357, column: 25, scope: !3502)
!3502 = distinct !DILexicalBlock(scope: !3498, file: !2, line: 1356, column: 40)
!3503 = !DILocation(line: 1357, column: 17, scope: !3502)
!3504 = !DILocation(line: 1358, column: 17, scope: !3502)
!3505 = !DILocation(line: 1360, column: 18, scope: !3506)
!3506 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1360, column: 17)
!3507 = !DILocation(line: 1360, column: 17, scope: !239)
!3508 = !DILocation(line: 1361, column: 25, scope: !3509)
!3509 = distinct !DILexicalBlock(scope: !3506, file: !2, line: 1360, column: 67)
!3510 = !DILocation(line: 1361, column: 17, scope: !3509)
!3511 = !DILocation(line: 1362, column: 17, scope: !3509)
!3512 = !DILocation(line: 1364, column: 31, scope: !239)
!3513 = !{!3459, !1212, i64 0}
!3514 = !DILocation(line: 1365, column: 13, scope: !239)
!3515 = !DILocation(line: 1367, column: 17, scope: !3516)
!3516 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1367, column: 17)
!3517 = !DILocation(line: 1367, column: 31, scope: !3516)
!3518 = !DILocation(line: 1367, column: 17, scope: !239)
!3519 = !DILocation(line: 1368, column: 25, scope: !3520)
!3520 = distinct !DILexicalBlock(scope: !3516, file: !2, line: 1367, column: 40)
!3521 = !DILocation(line: 1368, column: 17, scope: !3520)
!3522 = !DILocation(line: 1369, column: 17, scope: !3520)
!3523 = !DILocation(line: 1371, column: 55, scope: !3524)
!3524 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1371, column: 17)
!3525 = !DILocation(line: 1371, column: 18, scope: !3524)
!3526 = !DILocation(line: 1371, column: 17, scope: !239)
!3527 = !DILocation(line: 1372, column: 25, scope: !3528)
!3528 = distinct !DILexicalBlock(scope: !3524, file: !2, line: 1371, column: 67)
!3529 = !DILocation(line: 1372, column: 17, scope: !3528)
!3530 = !DILocation(line: 1373, column: 17, scope: !3528)
!3531 = !DILocation(line: 1375, column: 31, scope: !239)
!3532 = !{!3459, !1212, i64 16}
!3533 = !DILocation(line: 1376, column: 36, scope: !239)
!3534 = !DILocation(line: 1377, column: 13, scope: !239)
!3535 = !DILocation(line: 1379, column: 17, scope: !3536)
!3536 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1379, column: 17)
!3537 = !DILocation(line: 1379, column: 31, scope: !3536)
!3538 = !DILocation(line: 1379, column: 17, scope: !239)
!3539 = !DILocation(line: 1380, column: 25, scope: !3540)
!3540 = distinct !DILexicalBlock(scope: !3536, file: !2, line: 1379, column: 40)
!3541 = !DILocation(line: 1380, column: 17, scope: !3540)
!3542 = !DILocation(line: 1381, column: 17, scope: !3540)
!3543 = !DILocation(line: 1383, column: 55, scope: !3544)
!3544 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1383, column: 17)
!3545 = !DILocation(line: 1383, column: 18, scope: !3544)
!3546 = !DILocation(line: 1383, column: 17, scope: !239)
!3547 = !DILocation(line: 1384, column: 25, scope: !3548)
!3548 = distinct !DILexicalBlock(scope: !3544, file: !2, line: 1383, column: 72)
!3549 = !DILocation(line: 1384, column: 17, scope: !3548)
!3550 = !DILocation(line: 1385, column: 17, scope: !3548)
!3551 = !DILocation(line: 1389, column: 17, scope: !3552)
!3552 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1389, column: 17)
!3553 = !DILocation(line: 1389, column: 31, scope: !3552)
!3554 = !DILocation(line: 1389, column: 17, scope: !239)
!3555 = !DILocation(line: 1390, column: 25, scope: !3556)
!3556 = distinct !DILexicalBlock(scope: !3552, file: !2, line: 1389, column: 40)
!3557 = !DILocation(line: 1390, column: 17, scope: !3556)
!3558 = !DILocation(line: 1391, column: 17, scope: !3556)
!3559 = !DILocation(line: 1393, column: 55, scope: !3560)
!3560 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1393, column: 17)
!3561 = !DILocation(line: 1393, column: 18, scope: !3560)
!3562 = !DILocation(line: 1393, column: 17, scope: !239)
!3563 = !DILocation(line: 1394, column: 25, scope: !3564)
!3564 = distinct !DILexicalBlock(scope: !3560, file: !2, line: 1393, column: 66)
!3565 = !DILocation(line: 1394, column: 17, scope: !3564)
!3566 = !DILocation(line: 1395, column: 17, scope: !3564)
!3567 = !DILocation(line: 1399, column: 17, scope: !3568)
!3568 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1399, column: 17)
!3569 = !DILocation(line: 1399, column: 31, scope: !3568)
!3570 = !DILocation(line: 1399, column: 17, scope: !239)
!3571 = !DILocation(line: 1400, column: 25, scope: !3572)
!3572 = distinct !DILexicalBlock(scope: !3568, file: !2, line: 1399, column: 40)
!3573 = !DILocation(line: 1400, column: 17, scope: !3572)
!3574 = !DILocation(line: 1401, column: 17, scope: !3572)
!3575 = !DILocation(line: 1403, column: 18, scope: !3576)
!3576 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1403, column: 17)
!3577 = !DILocation(line: 1403, column: 17, scope: !239)
!3578 = !DILocation(line: 1404, column: 25, scope: !3579)
!3579 = distinct !DILexicalBlock(scope: !3576, file: !2, line: 1403, column: 72)
!3580 = !DILocation(line: 1404, column: 17, scope: !3579)
!3581 = !DILocation(line: 1405, column: 17, scope: !3579)
!3582 = !DILocation(line: 1409, column: 17, scope: !3583)
!3583 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1409, column: 17)
!3584 = !DILocation(line: 1409, column: 31, scope: !3583)
!3585 = !DILocation(line: 1409, column: 17, scope: !239)
!3586 = !DILocation(line: 1410, column: 25, scope: !3587)
!3587 = distinct !DILexicalBlock(scope: !3583, file: !2, line: 1409, column: 40)
!3588 = !DILocation(line: 1410, column: 17, scope: !3587)
!3589 = !DILocation(line: 1411, column: 17, scope: !3587)
!3590 = !DILocation(line: 1413, column: 18, scope: !3591)
!3591 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1413, column: 17)
!3592 = !DILocation(line: 1413, column: 17, scope: !239)
!3593 = !DILocation(line: 1414, column: 25, scope: !3594)
!3594 = distinct !DILexicalBlock(scope: !3591, file: !2, line: 1413, column: 71)
!3595 = !DILocation(line: 1414, column: 17, scope: !3594)
!3596 = !DILocation(line: 1415, column: 17, scope: !3594)
!3597 = !DILocation(line: 1419, column: 17, scope: !3598)
!3598 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1419, column: 17)
!3599 = !DILocation(line: 1419, column: 31, scope: !3598)
!3600 = !DILocation(line: 1419, column: 17, scope: !239)
!3601 = !DILocation(line: 1420, column: 25, scope: !3602)
!3602 = distinct !DILexicalBlock(scope: !3598, file: !2, line: 1419, column: 40)
!3603 = !DILocation(line: 1420, column: 17, scope: !3602)
!3604 = !DILocation(line: 1421, column: 17, scope: !3602)
!3605 = !DILocation(line: 1423, column: 18, scope: !3606)
!3606 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1423, column: 17)
!3607 = !DILocation(line: 1423, column: 17, scope: !239)
!3608 = !DILocation(line: 1424, column: 25, scope: !3609)
!3609 = distinct !DILexicalBlock(scope: !3606, file: !2, line: 1423, column: 70)
!3610 = !DILocation(line: 1424, column: 17, scope: !3609)
!3611 = !DILocation(line: 1425, column: 17, scope: !3609)
!3612 = !DILocation(line: 1429, column: 17, scope: !3613)
!3613 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1429, column: 17)
!3614 = !DILocation(line: 1429, column: 31, scope: !3613)
!3615 = !DILocation(line: 1429, column: 17, scope: !239)
!3616 = !DILocation(line: 1430, column: 25, scope: !3617)
!3617 = distinct !DILexicalBlock(scope: !3613, file: !2, line: 1429, column: 40)
!3618 = !DILocation(line: 1430, column: 17, scope: !3617)
!3619 = !DILocation(line: 1431, column: 17, scope: !3617)
!3620 = !DILocation(line: 1433, column: 18, scope: !3621)
!3621 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1433, column: 17)
!3622 = !DILocation(line: 1433, column: 17, scope: !239)
!3623 = !DILocation(line: 1434, column: 25, scope: !3624)
!3624 = distinct !DILexicalBlock(scope: !3621, file: !2, line: 1433, column: 75)
!3625 = !DILocation(line: 1434, column: 17, scope: !3624)
!3626 = !DILocation(line: 1435, column: 17, scope: !3624)
!3627 = !DILocation(line: 1439, column: 17, scope: !3628)
!3628 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1439, column: 17)
!3629 = !DILocation(line: 1439, column: 31, scope: !3628)
!3630 = !DILocation(line: 1439, column: 17, scope: !239)
!3631 = !DILocation(line: 1440, column: 25, scope: !3632)
!3632 = distinct !DILexicalBlock(scope: !3628, file: !2, line: 1439, column: 40)
!3633 = !DILocation(line: 1440, column: 17, scope: !3632)
!3634 = !DILocation(line: 1441, column: 17, scope: !3632)
!3635 = !DILocation(line: 1443, column: 18, scope: !3636)
!3636 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1443, column: 17)
!3637 = !DILocation(line: 1443, column: 17, scope: !239)
!3638 = !DILocation(line: 1444, column: 25, scope: !3639)
!3639 = distinct !DILexicalBlock(scope: !3636, file: !2, line: 1443, column: 76)
!3640 = !DILocation(line: 1444, column: 17, scope: !3639)
!3641 = !DILocation(line: 1445, column: 17, scope: !3639)
!3642 = !DILocation(line: 1449, column: 17, scope: !3643)
!3643 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1449, column: 17)
!3644 = !DILocation(line: 1449, column: 31, scope: !3643)
!3645 = !DILocation(line: 1449, column: 17, scope: !239)
!3646 = !DILocation(line: 1450, column: 25, scope: !3647)
!3647 = distinct !DILexicalBlock(scope: !3643, file: !2, line: 1449, column: 40)
!3648 = !DILocation(line: 1450, column: 17, scope: !3647)
!3649 = !DILocation(line: 1451, column: 17, scope: !3647)
!3650 = !DILocation(line: 1453, column: 18, scope: !3651)
!3651 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1453, column: 17)
!3652 = !DILocation(line: 1453, column: 17, scope: !239)
!3653 = !DILocation(line: 1454, column: 25, scope: !3654)
!3654 = distinct !DILexicalBlock(scope: !3651, file: !2, line: 1453, column: 73)
!3655 = !DILocation(line: 1454, column: 17, scope: !3654)
!3656 = !DILocation(line: 1455, column: 17, scope: !3654)
!3657 = !DILocation(line: 1459, column: 17, scope: !3658)
!3658 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1459, column: 17)
!3659 = !DILocation(line: 1459, column: 31, scope: !3658)
!3660 = !DILocation(line: 1459, column: 17, scope: !239)
!3661 = !DILocation(line: 1460, column: 25, scope: !3662)
!3662 = distinct !DILexicalBlock(scope: !3658, file: !2, line: 1459, column: 40)
!3663 = !DILocation(line: 1460, column: 17, scope: !3662)
!3664 = !DILocation(line: 1461, column: 17, scope: !3662)
!3665 = !DILocation(line: 1463, column: 18, scope: !3666)
!3666 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1463, column: 17)
!3667 = !DILocation(line: 1463, column: 17, scope: !239)
!3668 = !DILocation(line: 1464, column: 25, scope: !3669)
!3669 = distinct !DILexicalBlock(scope: !3666, file: !2, line: 1463, column: 72)
!3670 = !DILocation(line: 1464, column: 17, scope: !3669)
!3671 = !DILocation(line: 1465, column: 17, scope: !3669)
!3672 = !DILocation(line: 1469, column: 17, scope: !3673)
!3673 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1469, column: 17)
!3674 = !DILocation(line: 1469, column: 31, scope: !3673)
!3675 = !DILocation(line: 1469, column: 17, scope: !239)
!3676 = !DILocation(line: 1470, column: 25, scope: !3677)
!3677 = distinct !DILexicalBlock(scope: !3673, file: !2, line: 1469, column: 40)
!3678 = !DILocation(line: 1470, column: 17, scope: !3677)
!3679 = !DILocation(line: 1471, column: 17, scope: !3677)
!3680 = !DILocation(line: 1473, column: 18, scope: !3681)
!3681 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1473, column: 17)
!3682 = !DILocation(line: 1473, column: 17, scope: !239)
!3683 = !DILocation(line: 1474, column: 25, scope: !3684)
!3684 = distinct !DILexicalBlock(scope: !3681, file: !2, line: 1473, column: 70)
!3685 = !DILocation(line: 1474, column: 17, scope: !3684)
!3686 = !DILocation(line: 1475, column: 17, scope: !3684)
!3687 = !DILocation(line: 1479, column: 17, scope: !3688)
!3688 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1479, column: 17)
!3689 = !DILocation(line: 1479, column: 31, scope: !3688)
!3690 = !DILocation(line: 1479, column: 17, scope: !239)
!3691 = !DILocation(line: 1480, column: 25, scope: !3692)
!3692 = distinct !DILexicalBlock(scope: !3688, file: !2, line: 1479, column: 40)
!3693 = !DILocation(line: 1480, column: 17, scope: !3692)
!3694 = !DILocation(line: 1481, column: 17, scope: !3692)
!3695 = !DILocation(line: 1483, column: 18, scope: !3696)
!3696 = distinct !DILexicalBlock(scope: !239, file: !2, line: 1483, column: 17)
!3697 = !DILocation(line: 1483, column: 17, scope: !239)
!3698 = !DILocation(line: 1484, column: 25, scope: !3699)
!3699 = distinct !DILexicalBlock(scope: !3696, file: !2, line: 1483, column: 81)
!3700 = !DILocation(line: 1484, column: 17, scope: !3699)
!3701 = !DILocation(line: 1485, column: 17, scope: !3699)
!3702 = !DILocation(line: 1489, column: 38, scope: !239)
!3703 = !DILocation(line: 1490, column: 13, scope: !239)
!3704 = !DILocation(line: 1492, column: 17, scope: !238)
!3705 = !DILocation(line: 1492, column: 17, scope: !239)
!3706 = !DILocation(line: 1493, column: 92, scope: !237)
!3707 = !DILocation(line: 1493, column: 50, scope: !237)
!3708 = !DILocation(line: 0, scope: !237)
!3709 = !DILocation(line: 1494, column: 25, scope: !3710)
!3710 = distinct !DILexicalBlock(scope: !237, file: !2, line: 1494, column: 21)
!3711 = !DILocation(line: 1494, column: 21, scope: !237)
!3712 = !DILocation(line: 1495, column: 29, scope: !3713)
!3713 = distinct !DILexicalBlock(scope: !3710, file: !2, line: 1494, column: 34)
!3714 = !DILocation(line: 1495, column: 21, scope: !3713)
!3715 = !DILocation(line: 1498, column: 25, scope: !3716)
!3716 = distinct !DILexicalBlock(scope: !237, file: !2, line: 1498, column: 21)
!3717 = !DILocation(line: 1498, column: 38, scope: !3716)
!3718 = !DILocation(line: 1498, column: 21, scope: !237)
!3719 = !DILocation(line: 1499, column: 26, scope: !3720)
!3720 = distinct !DILexicalBlock(scope: !3716, file: !2, line: 1498, column: 47)
!3721 = !DILocation(line: 1499, column: 31, scope: !3720)
!3722 = !{!3221, !1312, i64 40}
!3723 = !DILocation(line: 1500, column: 17, scope: !3720)
!3724 = !DILocation(line: 1501, column: 34, scope: !237)
!3725 = !DILocation(line: 1503, column: 25, scope: !3726)
!3726 = distinct !DILexicalBlock(scope: !238, file: !2, line: 1502, column: 20)
!3727 = !DILocation(line: 1503, column: 17, scope: !3726)
!3728 = !DILocation(line: 1504, column: 17, scope: !3726)
!3729 = !DILocation(line: 1508, column: 21, scope: !239)
!3730 = !DILocation(line: 1508, column: 59, scope: !239)
!3731 = !DILocation(line: 1508, column: 13, scope: !239)
!3732 = !DILocation(line: 1509, column: 13, scope: !239)
!3733 = !DILocation(line: 1513, column: 1, scope: !187)
!3734 = !DISubprogram(name: "getsubopt", scope: !1355, file: !1355, line: 1099, type: !3735, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3735 = !DISubroutineType(types: !3736)
!3736 = !{!190, !3332, !3737, !3332}
!3737 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !3738)
!3738 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !233, size: 64)
!3739 = !DISubprogram(name: "safe_strtoul", scope: !3740, file: !3740, line: 19, type: !3741, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3740 = !DIFile(filename: "./util.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d1ef68c688867746f50aae7567be079a")
!3741 = !DISubroutineType(types: !3742)
!3742 = !{!629, !1258, !2617}
!3743 = !DISubprogram(name: "safe_strtod", scope: !3740, file: !3740, line: 21, type: !3744, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3744 = !DISubroutineType(types: !3745)
!3745 = !{!629, !1258, !3746}
!3746 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3368, size: 64)
!3747 = distinct !DISubprogram(name: "storage_check_config", scope: !2, file: !2, line: 1515, type: !2098, scopeLine: 1515, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !3748)
!3748 = !{!3749, !3750, !3751}
!3749 = !DILocalVariable(name: "conf", arg: 1, scope: !3747, file: !2, line: 1515, type: !191)
!3750 = !DILocalVariable(name: "cf", scope: !3747, file: !2, line: 1516, type: !198)
!3751 = !DILocalVariable(name: "ext_cf", scope: !3747, file: !2, line: 1517, type: !229)
!3752 = !DILocation(line: 0, scope: !3747)
!3753 = !DILocation(line: 1519, column: 13, scope: !3754)
!3754 = distinct !DILexicalBlock(scope: !3747, file: !2, line: 1519, column: 9)
!3755 = !DILocation(line: 1519, column: 9, scope: !3754)
!3756 = !DILocation(line: 1519, column: 9, scope: !3747)
!3757 = !DILocation(line: 1520, column: 22, scope: !3758)
!3758 = distinct !DILexicalBlock(scope: !3759, file: !2, line: 1520, column: 13)
!3759 = distinct !DILexicalBlock(scope: !3754, file: !2, line: 1519, column: 27)
!3760 = !{!1468, !1212, i64 116}
!3761 = !DILocation(line: 1520, column: 46, scope: !3758)
!3762 = !DILocation(line: 1520, column: 36, scope: !3758)
!3763 = !DILocation(line: 1520, column: 13, scope: !3759)
!3764 = !DILocation(line: 1521, column: 21, scope: !3765)
!3765 = distinct !DILexicalBlock(scope: !3758, file: !2, line: 1520, column: 57)
!3766 = !DILocation(line: 1521, column: 13, scope: !3765)
!3767 = !DILocation(line: 1523, column: 13, scope: !3765)
!3768 = !DILocation(line: 1526, column: 22, scope: !3769)
!3769 = distinct !DILexicalBlock(scope: !3759, file: !2, line: 1526, column: 13)
!3770 = !{!1468, !1212, i64 16}
!3771 = !DILocation(line: 1526, column: 13, scope: !3769)
!3772 = !DILocation(line: 1526, column: 13, scope: !3759)
!3773 = !DILocation(line: 1527, column: 21, scope: !3774)
!3774 = distinct !DILexicalBlock(scope: !3769, file: !2, line: 1526, column: 31)
!3775 = !DILocation(line: 1527, column: 13, scope: !3774)
!3776 = !DILocation(line: 1528, column: 13, scope: !3774)
!3777 = !DILocation(line: 1535, column: 1, scope: !3747)
!3778 = distinct !DISubprogram(name: "storage_init", scope: !2, file: !2, line: 1537, type: !2143, scopeLine: 1537, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !3779)
!3779 = !{!3780, !3781, !3782, !3783, !3784}
!3780 = !DILocalVariable(name: "conf", arg: 1, scope: !3778, file: !2, line: 1537, type: !191)
!3781 = !DILocalVariable(name: "cf", scope: !3778, file: !2, line: 1538, type: !198)
!3782 = !DILocalVariable(name: "ext_cf", scope: !3778, file: !2, line: 1539, type: !229)
!3783 = !DILocalVariable(name: "eres", scope: !3778, file: !2, line: 1541, type: !256)
!3784 = !DILocalVariable(name: "storage", scope: !3778, file: !2, line: 1542, type: !191)
!3785 = distinct !DIAssignID()
!3786 = !DILocation(line: 0, scope: !3778)
!3787 = !DILocation(line: 1539, column: 41, scope: !3778)
!3788 = !DILocation(line: 1541, column: 5, scope: !3778)
!3789 = !DILocation(line: 1543, column: 18, scope: !3790)
!3790 = distinct !DILexicalBlock(scope: !3778, file: !2, line: 1543, column: 9)
!3791 = !DILocation(line: 1543, column: 36, scope: !3790)
!3792 = !DILocation(line: 1543, column: 9, scope: !3778)
!3793 = !DILocation(line: 1545, column: 42, scope: !3794)
!3794 = distinct !DILexicalBlock(scope: !3790, file: !2, line: 1543, column: 42)
!3795 = !DILocation(line: 1545, column: 56, scope: !3794)
!3796 = !DILocation(line: 1545, column: 38, scope: !3794)
!3797 = !DILocation(line: 1545, column: 67, scope: !3794)
!3798 = !DILocation(line: 1545, column: 36, scope: !3794)
!3799 = !DILocation(line: 1546, column: 33, scope: !3794)
!3800 = !DILocation(line: 1547, column: 40, scope: !3801)
!3801 = distinct !DILexicalBlock(scope: !3794, file: !2, line: 1547, column: 13)
!3802 = !DILocation(line: 1547, column: 13, scope: !3794)
!3803 = !DILocation(line: 1548, column: 40, scope: !3804)
!3804 = distinct !DILexicalBlock(scope: !3801, file: !2, line: 1547, column: 45)
!3805 = !DILocation(line: 1551, column: 37, scope: !3806)
!3806 = distinct !DILexicalBlock(scope: !3807, file: !2, line: 1550, column: 42)
!3807 = distinct !DILexicalBlock(scope: !3794, file: !2, line: 1550, column: 13)
!3808 = !DILocation(line: 1552, column: 9, scope: !3806)
!3809 = !DILocation(line: 1554, column: 5, scope: !3778)
!3810 = !DILocation(line: 1556, column: 34, scope: !3778)
!3811 = !DILocation(line: 1557, column: 33, scope: !3778)
!3812 = !DILocation(line: 1557, column: 15, scope: !3778)
!3813 = !DILocation(line: 1558, column: 17, scope: !3814)
!3814 = distinct !DILexicalBlock(scope: !3778, file: !2, line: 1558, column: 9)
!3815 = !DILocation(line: 1558, column: 9, scope: !3778)
!3816 = !DILocation(line: 1559, column: 17, scope: !3817)
!3817 = distinct !DILexicalBlock(scope: !3814, file: !2, line: 1558, column: 26)
!3818 = !DILocation(line: 1560, column: 30, scope: !3817)
!3819 = !DILocation(line: 1560, column: 17, scope: !3817)
!3820 = !DILocation(line: 1559, column: 9, scope: !3817)
!3821 = !DILocation(line: 1561, column: 13, scope: !3822)
!3822 = distinct !DILexicalBlock(scope: !3817, file: !2, line: 1561, column: 13)
!3823 = !DILocation(line: 1561, column: 18, scope: !3822)
!3824 = !DILocation(line: 1561, column: 13, scope: !3817)
!3825 = !DILocation(line: 1562, column: 13, scope: !3826)
!3826 = distinct !DILexicalBlock(scope: !3822, file: !2, line: 1561, column: 46)
!3827 = !DILocation(line: 1563, column: 9, scope: !3826)
!3828 = !DILocation(line: 1568, column: 1, scope: !3778)
!3829 = !DISubprogram(name: "crc32c_init", scope: !3830, file: !3830, line: 18, type: !1431, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3830 = !DIFile(filename: "./crc32c.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "8a48ba9fe4cc0dc3de03e345ef4b0904")
!3831 = !DISubprogram(name: "extstore_init", scope: !182, file: !182, line: 105, type: !3832, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3832 = !DISubroutineType(types: !3833)
!3833 = !{!191, !202, !229, !3834}
!3834 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !256, size: 64)
!3835 = !DISubprogram(name: "extstore_err", scope: !182, file: !182, line: 104, type: !3836, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3836 = !DISubroutineType(types: !3837)
!3837 = !{!1258, !256}
!3838 = !DISubprogram(name: "perror", scope: !1360, file: !1360, line: 878, type: !3839, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3839 = !DISubroutineType(types: !3840)
!3840 = !{null, !1258}
!3841 = !DISubprogram(name: "return_io_pending", scope: !113, file: !113, line: 993, type: !847, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3842 = !DISubprogram(name: "conn_worker_readd", scope: !113, file: !113, line: 966, type: !3843, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3843 = !DISubroutineType(types: !3844)
!3844 = !{null, !741}
!3845 = !DISubprogram(name: "slabs_free", scope: !1685, file: !1685, line: 29, type: !3846, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3846 = !DISubroutineType(types: !3847)
!3847 = !{null, !191, !584, !114}
!3848 = !DISubprogram(name: "item_unlink", scope: !113, file: !113, line: 1015, type: !1876, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3849 = !DISubprogram(name: "item_trylock", scope: !113, file: !113, line: 1018, type: !3850, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3850 = !DISubroutineType(types: !3851)
!3851 = !{!191, !297}
!3852 = !DISubprogram(name: "item_replace", scope: !113, file: !113, line: 1014, type: !3853, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3853 = !DISubroutineType(types: !3854)
!3854 = !{!190, !614, !614, !1261, !3855}
!3855 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !209)
!3856 = !DISubprogram(name: "item_trylock_unlock", scope: !113, file: !113, line: 1019, type: !1366, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3857 = !DISubprogram(name: "logger_create", scope: !147, file: !147, line: 227, type: !3858, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3858 = !DISubroutineType(types: !3859)
!3859 = !{!668}
!3860 = !DISubprogram(name: "abort", scope: !1355, file: !1355, line: 730, type: !1431, flags: DIFlagPrototyped | DIFlagNoReturn, spFlags: DISPFlagOptimized)
!3861 = !DISubprogram(name: "global_page_pool_size", scope: !1685, file: !1685, line: 41, type: !3862, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3862 = !DISubroutineType(types: !3863)
!3863 = !{!114, !3864}
!3864 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !629, size: 64)
!3865 = !DISubprogram(name: "slabs_available_chunks", scope: !1685, file: !1685, line: 47, type: !3866, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3866 = !DISubroutineType(types: !3867)
!3867 = !{!114, !114, !3864, !3868}
!3868 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !114, size: 64)
!3869 = !DISubprogram(name: "pthread_cond_signal", scope: !2073, file: !2073, line: 1121, type: !3870, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3870 = !DISubroutineType(types: !3871)
!3871 = !{!190, !2564}
!3872 = !DISubprogram(name: "usleep", scope: !3873, file: !3873, line: 480, type: !3874, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3873 = !DIFile(filename: "/usr/include/unistd.h", directory: "", checksumkind: CSK_MD5, checksum: "877e832a8bb8424f9180387a13787475")
!3874 = !DISubroutineType(types: !3875)
!3875 = !{!190, !2155}
!3876 = !DISubprogram(name: "lru_pull_tail", scope: !1693, file: !1693, line: 47, type: !3877, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3877 = !DISubroutineType(types: !3878)
!3878 = !{!190, !2183, !2183, !3855, !3879, !3880, !3881}
!3879 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !322)
!3880 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !314)
!3881 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2211, size: 64)
!3882 = !DISubprogram(name: "do_item_alloc", scope: !1693, file: !1693, line: 14, type: !3883, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3883 = !DISubroutineType(types: !3884)
!3884 = !{!614, !1258, !1688, !3885, !3880, !2183}
!3885 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !296)
!3886 = !DISubprogram(name: "extstore_write_request", scope: !182, file: !182, line: 106, type: !3887, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3887 = !DISubroutineType(types: !3888)
!3888 = !{!190, !191, !114, !114, !895}
!3889 = !DISubprogram(name: "extstore_write", scope: !182, file: !182, line: 107, type: !3890, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3890 = !DISubroutineType(types: !3891)
!3891 = !{null, !191, !895}
!3892 = !DISubprogram(name: "do_item_remove", scope: !1693, file: !1693, line: 23, type: !1876, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3893 = !DISubprogram(name: "pthread_getspecific", scope: !2073, file: !2073, line: 1305, type: !3894, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3894 = !DISubroutineType(types: !3895)
!3895 = !{!191, !3896}
!3896 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_key_t", file: !355, line: 49, baseType: !114)
!3897 = !DISubprogram(name: "logger_log", scope: !147, file: !147, line: 238, type: !3898, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3898 = !DISubroutineType(types: !3899)
!3899 = !{!280, !668, !3900, !723, null}
!3900 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !146)
!3901 = !DISubprogram(name: "item_unlock", scope: !113, file: !113, line: 1020, type: !3902, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3902 = !DISubroutineType(types: !3903)
!3903 = !{null, !297}
!3904 = distinct !DISubprogram(name: "_storage_compact_cb", scope: !2, file: !2, line: 1041, type: !893, scopeLine: 1041, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !110, retainedNodes: !3905)
!3905 = !{!3906, !3907, !3908, !3909}
!3906 = !DILocalVariable(name: "e", arg: 1, scope: !3904, file: !2, line: 1041, type: !191)
!3907 = !DILocalVariable(name: "io", arg: 2, scope: !3904, file: !2, line: 1041, type: !895)
!3908 = !DILocalVariable(name: "ret", arg: 3, scope: !3904, file: !2, line: 1041, type: !190)
!3909 = !DILocalVariable(name: "wrap", scope: !3904, file: !2, line: 1042, type: !918)
!3910 = !DILocation(line: 0, scope: !3904)
!3911 = !DILocation(line: 1042, column: 76, scope: !3904)
!3912 = !DILocation(line: 1045, column: 13, scope: !3913)
!3913 = distinct !DILexicalBlock(scope: !3904, file: !2, line: 1045, column: 9)
!3914 = !DILocation(line: 1045, column: 9, scope: !3904)
!3915 = !DILocation(line: 1046, column: 15, scope: !3916)
!3916 = distinct !DILexicalBlock(scope: !3913, file: !2, line: 1045, column: 18)
!3917 = !DILocation(line: 1046, column: 20, scope: !3916)
!3918 = !DILocation(line: 1047, column: 5, scope: !3916)
!3919 = !DILocation(line: 1048, column: 11, scope: !3904)
!3920 = !DILocation(line: 1048, column: 16, scope: !3904)
!3921 = !DILocation(line: 1050, column: 33, scope: !3904)
!3922 = !DILocation(line: 1050, column: 5, scope: !3904)
!3923 = !DILocation(line: 1051, column: 1, scope: !3904)
!3924 = !DISubprogram(name: "pthread_cond_wait", scope: !2073, file: !2073, line: 1133, type: !3925, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3925 = !DISubroutineType(types: !3926)
!3926 = !{!190, !2563, !3927}
!3927 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !2076)
!3928 = !DISubprogram(name: "extstore_submit_bg", scope: !182, file: !182, line: 109, type: !2089, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3929 = !DISubprogram(name: "extstore_close_page", scope: !182, file: !182, line: 121, type: !3930, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3930 = !DISubroutineType(types: !3931)
!3931 = !{null, !191, !114, !209}
!3932 = !DISubprogram(name: "extstore_evict_page", scope: !182, file: !182, line: 122, type: !3930, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3933 = !DISubprogram(name: "item_lock", scope: !113, file: !113, line: 1017, type: !3902, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3934 = !DISubprogram(name: "assoc_find", scope: !3935, file: !3935, line: 4, type: !3936, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3935 = !DIFile(filename: "./assoc.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "07a03bb93725ff477a16ac4bae114cd2")
!3936 = !DISubroutineType(types: !3937)
!3937 = !{!614, !1258, !1688, !1261}
!3938 = !DISubprogram(name: "item_is_flushed", scope: !1693, file: !1693, line: 29, type: !3939, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3939 = !DISubroutineType(types: !3940)
!3940 = !{!190, !614}
!3941 = !DISubprogram(name: "strtol", linkageName: "__isoc23_strtol", scope: !1355, file: !1355, line: 215, type: !3942, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3942 = !DISubroutineType(types: !3943)
!3943 = !{!427, !1364, !3332, !190}
