; ModuleID = 'jenkins_hash.c'
source_filename = "jenkins_hash.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nofree norecurse nosync nounwind sanitize_thread memory(read, inaccessiblemem: none) uwtable
define dso_local i32 @jenkins_hash(ptr noundef %key, i64 noundef %length) local_unnamed_addr #0 !dbg !21 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !30, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i64 %length, metadata !31, metadata !DIExpression()), !dbg !56
  %conv = trunc i64 %length to i32, !dbg !57
  %add = add i32 %conv, -559038737, !dbg !58
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !33, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !32, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !35, metadata !DIExpression()), !dbg !56
  %0 = ptrtoint ptr %key to i64, !dbg !59
  %and = and i64 %0, 3, !dbg !60
  %cmp = icmp eq i64 %and, 0, !dbg !61
  br i1 %cmp, label %while.cond.preheader, label %if.else, !dbg !62

while.cond.preheader:                             ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !40, metadata !DIExpression()), !dbg !63
  tail call void @llvm.dbg.value(metadata i64 %length, metadata !31, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !33, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !32, metadata !DIExpression()), !dbg !56
  %cmp3852 = icmp ugt i64 %length, 12, !dbg !64
  br i1 %cmp3852, label %while.body, label %while.end, !dbg !65

while.body:                                       ; preds = %while.cond.preheader, %while.body
  %k.0857 = phi ptr [ %add.ptr, %while.body ], [ %key, %while.cond.preheader ]
  %length.addr.0856 = phi i64 [ %sub42, %while.body ], [ %length, %while.cond.preheader ]
  %c.0855 = phi i32 [ %xor40, %while.body ], [ %add, %while.cond.preheader ]
  %b.0854 = phi i32 [ %add41, %while.body ], [ %add, %while.cond.preheader ]
  %a.0853 = phi i32 [ %add35, %while.body ], [ %add, %while.cond.preheader ]
  tail call void @llvm.dbg.value(metadata ptr %k.0857, metadata !40, metadata !DIExpression()), !dbg !63
  tail call void @llvm.dbg.value(metadata i64 %length.addr.0856, metadata !31, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %c.0855, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %b.0854, metadata !33, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %a.0853, metadata !32, metadata !DIExpression()), !dbg !56
  %1 = load i32, ptr %k.0857, align 4, !dbg !66, !tbaa !68
  %add5 = add i32 %1, %a.0853, !dbg !72
  tail call void @llvm.dbg.value(metadata i32 %add5, metadata !32, metadata !DIExpression()), !dbg !56
  %arrayidx6 = getelementptr inbounds i8, ptr %k.0857, i64 4, !dbg !73
  %2 = load i32, ptr %arrayidx6, align 4, !dbg !73, !tbaa !68
  %add7 = add i32 %2, %b.0854, !dbg !74
  tail call void @llvm.dbg.value(metadata i32 %add7, metadata !33, metadata !DIExpression()), !dbg !56
  %arrayidx8 = getelementptr inbounds i8, ptr %k.0857, i64 8, !dbg !75
  %3 = load i32, ptr %arrayidx8, align 4, !dbg !75, !tbaa !68
  %add9 = add i32 %3, %c.0855, !dbg !76
  tail call void @llvm.dbg.value(metadata i32 %add9, metadata !34, metadata !DIExpression()), !dbg !56
  %sub = sub i32 %add5, %add9, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %sub, metadata !32, metadata !DIExpression()), !dbg !56
  %xor = tail call i32 @llvm.fshl.i32(i32 %add9, i32 %add9, i32 4), !dbg !77
  %xor10 = xor i32 %sub, %xor, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %xor10, metadata !32, metadata !DIExpression()), !dbg !56
  %add11 = add i32 %add9, %add7, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %add11, metadata !34, metadata !DIExpression()), !dbg !56
  %sub12 = sub i32 %add7, %xor10, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %sub12, metadata !33, metadata !DIExpression()), !dbg !56
  %xor15 = tail call i32 @llvm.fshl.i32(i32 %xor10, i32 %xor10, i32 6), !dbg !77
  %xor16 = xor i32 %sub12, %xor15, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %xor16, metadata !33, metadata !DIExpression()), !dbg !56
  %add17 = add i32 %xor10, %add11, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %add17, metadata !32, metadata !DIExpression()), !dbg !56
  %sub18 = sub i32 %add11, %xor16, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %sub18, metadata !34, metadata !DIExpression()), !dbg !56
  %xor21 = tail call i32 @llvm.fshl.i32(i32 %xor16, i32 %xor16, i32 8), !dbg !77
  %xor22 = xor i32 %sub18, %xor21, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %xor22, metadata !34, metadata !DIExpression()), !dbg !56
  %add23 = add i32 %xor16, %add17, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %add23, metadata !33, metadata !DIExpression()), !dbg !56
  %sub24 = sub i32 %add17, %xor22, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %sub24, metadata !32, metadata !DIExpression()), !dbg !56
  %xor27 = tail call i32 @llvm.fshl.i32(i32 %xor22, i32 %xor22, i32 16), !dbg !77
  %xor28 = xor i32 %sub24, %xor27, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %xor28, metadata !32, metadata !DIExpression()), !dbg !56
  %add29 = add i32 %xor22, %add23, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %add29, metadata !34, metadata !DIExpression()), !dbg !56
  %sub30 = sub i32 %add23, %xor28, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %sub30, metadata !33, metadata !DIExpression()), !dbg !56
  %xor33 = tail call i32 @llvm.fshl.i32(i32 %xor28, i32 %xor28, i32 19), !dbg !77
  %xor34 = xor i32 %sub30, %xor33, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %xor34, metadata !33, metadata !DIExpression()), !dbg !56
  %add35 = add i32 %xor28, %add29, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %add35, metadata !32, metadata !DIExpression()), !dbg !56
  %sub36 = sub i32 %add29, %xor34, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %sub36, metadata !34, metadata !DIExpression()), !dbg !56
  %xor39 = tail call i32 @llvm.fshl.i32(i32 %xor34, i32 %xor34, i32 4), !dbg !77
  %xor40 = xor i32 %sub36, %xor39, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %xor40, metadata !34, metadata !DIExpression()), !dbg !56
  %add41 = add i32 %xor34, %add35, !dbg !77
  tail call void @llvm.dbg.value(metadata i32 %add41, metadata !33, metadata !DIExpression()), !dbg !56
  %sub42 = add i64 %length.addr.0856, -12, !dbg !79
  tail call void @llvm.dbg.value(metadata i64 %sub42, metadata !31, metadata !DIExpression()), !dbg !56
  %add.ptr = getelementptr inbounds i8, ptr %k.0857, i64 12, !dbg !80
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !40, metadata !DIExpression()), !dbg !63
  %cmp3 = icmp ugt i64 %sub42, 12, !dbg !64
  br i1 %cmp3, label %while.body, label %while.end, !dbg !65, !llvm.loop !81

while.end:                                        ; preds = %while.body, %while.cond.preheader
  %a.0.lcssa = phi i32 [ %add, %while.cond.preheader ], [ %add35, %while.body ], !dbg !56
  %b.0.lcssa = phi i32 [ %add, %while.cond.preheader ], [ %add41, %while.body ], !dbg !56
  %c.0.lcssa = phi i32 [ %add, %while.cond.preheader ], [ %xor40, %while.body ], !dbg !56
  %length.addr.0.lcssa = phi i64 [ %length, %while.cond.preheader ], [ %sub42, %while.body ]
  %k.0.lcssa = phi ptr [ %key, %while.cond.preheader ], [ %add.ptr, %while.body ], !dbg !63
  switch i64 %length.addr.0.lcssa, label %default.unreachable [
    i64 12, label %sw.bb
    i64 11, label %sw.bb49
    i64 10, label %sw.bb57
    i64 9, label %sw.bb65
    i64 8, label %sw.bb73
    i64 7, label %sw.bb78
    i64 6, label %sw.bb84
    i64 5, label %sw.bb90
    i64 4, label %sw.bb96
    i64 3, label %sw.bb99
    i64 2, label %sw.bb103
    i64 1, label %sw.bb107
    i64 0, label %cleanup480
  ], !dbg !84

sw.bb:                                            ; preds = %while.end
  %arrayidx43 = getelementptr inbounds i8, ptr %k.0.lcssa, i64 8, !dbg !85
  %4 = load i32, ptr %arrayidx43, align 4, !dbg !85, !tbaa !68
  %add44 = add i32 %4, %c.0.lcssa, !dbg !87
  tail call void @llvm.dbg.value(metadata i32 %add44, metadata !34, metadata !DIExpression()), !dbg !56
  %arrayidx45 = getelementptr inbounds i8, ptr %k.0.lcssa, i64 4, !dbg !88
  %5 = load i32, ptr %arrayidx45, align 4, !dbg !88, !tbaa !68
  %add46 = add i32 %5, %b.0.lcssa, !dbg !89
  tail call void @llvm.dbg.value(metadata i32 %add46, metadata !33, metadata !DIExpression()), !dbg !56
  %6 = load i32, ptr %k.0.lcssa, align 4, !dbg !90, !tbaa !68
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %a.0.lcssa, i32 %6), metadata !32, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value)), !dbg !56
  br label %cleanup.thread, !dbg !91

sw.bb49:                                          ; preds = %while.end
  %arrayidx50 = getelementptr inbounds i8, ptr %k.0.lcssa, i64 8, !dbg !92
  %7 = load i32, ptr %arrayidx50, align 4, !dbg !92, !tbaa !68
  %and51 = and i32 %7, 16777215, !dbg !93
  %add52 = add i32 %and51, %c.0.lcssa, !dbg !94
  tail call void @llvm.dbg.value(metadata i32 %add52, metadata !34, metadata !DIExpression()), !dbg !56
  %arrayidx53 = getelementptr inbounds i8, ptr %k.0.lcssa, i64 4, !dbg !95
  %8 = load i32, ptr %arrayidx53, align 4, !dbg !95, !tbaa !68
  %add54 = add i32 %8, %b.0.lcssa, !dbg !96
  tail call void @llvm.dbg.value(metadata i32 %add54, metadata !33, metadata !DIExpression()), !dbg !56
  %9 = load i32, ptr %k.0.lcssa, align 4, !dbg !97, !tbaa !68
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %a.0.lcssa, i32 %9), metadata !32, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value)), !dbg !56
  br label %cleanup.thread, !dbg !98

sw.bb57:                                          ; preds = %while.end
  %arrayidx58 = getelementptr inbounds i8, ptr %k.0.lcssa, i64 8, !dbg !99
  %10 = load i32, ptr %arrayidx58, align 4, !dbg !99, !tbaa !68
  %and59 = and i32 %10, 65535, !dbg !100
  %add60 = add i32 %and59, %c.0.lcssa, !dbg !101
  tail call void @llvm.dbg.value(metadata i32 %add60, metadata !34, metadata !DIExpression()), !dbg !56
  %arrayidx61 = getelementptr inbounds i8, ptr %k.0.lcssa, i64 4, !dbg !102
  %11 = load i32, ptr %arrayidx61, align 4, !dbg !102, !tbaa !68
  %add62 = add i32 %11, %b.0.lcssa, !dbg !103
  tail call void @llvm.dbg.value(metadata i32 %add62, metadata !33, metadata !DIExpression()), !dbg !56
  %12 = load i32, ptr %k.0.lcssa, align 4, !dbg !104, !tbaa !68
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %a.0.lcssa, i32 %12), metadata !32, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value)), !dbg !56
  br label %cleanup.thread, !dbg !105

sw.bb65:                                          ; preds = %while.end
  %arrayidx66 = getelementptr inbounds i8, ptr %k.0.lcssa, i64 8, !dbg !106
  %13 = load i32, ptr %arrayidx66, align 4, !dbg !106, !tbaa !68
  %and67 = and i32 %13, 255, !dbg !107
  %add68 = add i32 %and67, %c.0.lcssa, !dbg !108
  tail call void @llvm.dbg.value(metadata i32 %add68, metadata !34, metadata !DIExpression()), !dbg !56
  %arrayidx69 = getelementptr inbounds i8, ptr %k.0.lcssa, i64 4, !dbg !109
  %14 = load i32, ptr %arrayidx69, align 4, !dbg !109, !tbaa !68
  %add70 = add i32 %14, %b.0.lcssa, !dbg !110
  tail call void @llvm.dbg.value(metadata i32 %add70, metadata !33, metadata !DIExpression()), !dbg !56
  %15 = load i32, ptr %k.0.lcssa, align 4, !dbg !111, !tbaa !68
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %a.0.lcssa, i32 %15), metadata !32, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value)), !dbg !56
  br label %cleanup.thread, !dbg !112

sw.bb73:                                          ; preds = %while.end
  %arrayidx74 = getelementptr inbounds i8, ptr %k.0.lcssa, i64 4, !dbg !113
  %16 = load i32, ptr %arrayidx74, align 4, !dbg !113, !tbaa !68
  %add75 = add i32 %16, %b.0.lcssa, !dbg !114
  tail call void @llvm.dbg.value(metadata i32 %add75, metadata !33, metadata !DIExpression()), !dbg !56
  %17 = load i32, ptr %k.0.lcssa, align 4, !dbg !115, !tbaa !68
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %a.0.lcssa, i32 %17), metadata !32, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value)), !dbg !56
  br label %cleanup.thread, !dbg !116

sw.bb78:                                          ; preds = %while.end
  %arrayidx79 = getelementptr inbounds i8, ptr %k.0.lcssa, i64 4, !dbg !117
  %18 = load i32, ptr %arrayidx79, align 4, !dbg !117, !tbaa !68
  %and80 = and i32 %18, 16777215, !dbg !118
  %add81 = add i32 %and80, %b.0.lcssa, !dbg !119
  tail call void @llvm.dbg.value(metadata i32 %add81, metadata !33, metadata !DIExpression()), !dbg !56
  %19 = load i32, ptr %k.0.lcssa, align 4, !dbg !120, !tbaa !68
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %a.0.lcssa, i32 %19), metadata !32, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value)), !dbg !56
  br label %cleanup.thread, !dbg !121

sw.bb84:                                          ; preds = %while.end
  %arrayidx85 = getelementptr inbounds i8, ptr %k.0.lcssa, i64 4, !dbg !122
  %20 = load i32, ptr %arrayidx85, align 4, !dbg !122, !tbaa !68
  %and86 = and i32 %20, 65535, !dbg !123
  %add87 = add i32 %and86, %b.0.lcssa, !dbg !124
  tail call void @llvm.dbg.value(metadata i32 %add87, metadata !33, metadata !DIExpression()), !dbg !56
  %21 = load i32, ptr %k.0.lcssa, align 4, !dbg !125, !tbaa !68
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %a.0.lcssa, i32 %21), metadata !32, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value)), !dbg !56
  br label %cleanup.thread, !dbg !126

sw.bb90:                                          ; preds = %while.end
  %arrayidx91 = getelementptr inbounds i8, ptr %k.0.lcssa, i64 4, !dbg !127
  %22 = load i32, ptr %arrayidx91, align 4, !dbg !127, !tbaa !68
  %and92 = and i32 %22, 255, !dbg !128
  %add93 = add i32 %and92, %b.0.lcssa, !dbg !129
  tail call void @llvm.dbg.value(metadata i32 %add93, metadata !33, metadata !DIExpression()), !dbg !56
  %23 = load i32, ptr %k.0.lcssa, align 4, !dbg !130, !tbaa !68
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %a.0.lcssa, i32 %23), metadata !32, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value)), !dbg !56
  br label %cleanup.thread, !dbg !131

sw.bb96:                                          ; preds = %while.end
  %24 = load i32, ptr %k.0.lcssa, align 4, !dbg !132, !tbaa !68
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %a.0.lcssa, i32 %24), metadata !32, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value)), !dbg !56
  br label %cleanup.thread, !dbg !133

sw.bb99:                                          ; preds = %while.end
  %25 = load i32, ptr %k.0.lcssa, align 4, !dbg !134, !tbaa !68
  %and101 = and i32 %25, 16777215, !dbg !135
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %a.0.lcssa, i32 %and101), metadata !32, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value)), !dbg !56
  br label %cleanup.thread, !dbg !136

sw.bb103:                                         ; preds = %while.end
  %26 = load i32, ptr %k.0.lcssa, align 4, !dbg !137, !tbaa !68
  %and105 = and i32 %26, 65535, !dbg !138
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %a.0.lcssa, i32 %and105), metadata !32, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value)), !dbg !56
  br label %cleanup.thread, !dbg !139

sw.bb107:                                         ; preds = %while.end
  %27 = load i32, ptr %k.0.lcssa, align 4, !dbg !140, !tbaa !68
  %and109 = and i32 %27, 255, !dbg !141
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %a.0.lcssa, i32 %and109), metadata !32, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value)), !dbg !56
  br label %cleanup.thread, !dbg !142

default.unreachable:                              ; preds = %while.end381, %while.end180, %while.end
  unreachable

cleanup.thread:                                   ; preds = %sw.bb, %sw.bb49, %sw.bb57, %sw.bb65, %sw.bb73, %sw.bb78, %sw.bb84, %sw.bb90, %sw.bb96, %sw.bb99, %sw.bb103, %sw.bb107
  %and109.pn = phi i32 [ %and109, %sw.bb107 ], [ %and105, %sw.bb103 ], [ %and101, %sw.bb99 ], [ %24, %sw.bb96 ], [ %23, %sw.bb90 ], [ %21, %sw.bb84 ], [ %19, %sw.bb78 ], [ %17, %sw.bb73 ], [ %15, %sw.bb65 ], [ %12, %sw.bb57 ], [ %9, %sw.bb49 ], [ %6, %sw.bb ]
  %b.1 = phi i32 [ %b.0.lcssa, %sw.bb107 ], [ %b.0.lcssa, %sw.bb103 ], [ %b.0.lcssa, %sw.bb99 ], [ %b.0.lcssa, %sw.bb96 ], [ %add93, %sw.bb90 ], [ %add87, %sw.bb84 ], [ %add81, %sw.bb78 ], [ %add75, %sw.bb73 ], [ %add70, %sw.bb65 ], [ %add62, %sw.bb57 ], [ %add54, %sw.bb49 ], [ %add46, %sw.bb ], !dbg !56
  %c.1 = phi i32 [ %c.0.lcssa, %sw.bb107 ], [ %c.0.lcssa, %sw.bb103 ], [ %c.0.lcssa, %sw.bb99 ], [ %c.0.lcssa, %sw.bb96 ], [ %c.0.lcssa, %sw.bb90 ], [ %c.0.lcssa, %sw.bb84 ], [ %c.0.lcssa, %sw.bb78 ], [ %c.0.lcssa, %sw.bb73 ], [ %add68, %sw.bb65 ], [ %add60, %sw.bb57 ], [ %add52, %sw.bb49 ], [ %add44, %sw.bb ], !dbg !56
  %a.1 = add i32 %and109.pn, %a.0.lcssa, !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %c.1, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %b.1, metadata !33, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %a.1, metadata !32, metadata !DIExpression()), !dbg !56
  br label %if.end444

if.else:                                          ; preds = %entry
  %and112 = and i64 %0, 1, !dbg !143
  %cmp113 = icmp eq i64 %and112, 0, !dbg !144
  tail call void @llvm.dbg.value(metadata i64 %length, metadata !31, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i64 %length, metadata !31, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !33, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !33, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !32, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !32, metadata !DIExpression()), !dbg !56
  %cmp118841 = icmp ugt i64 %length, 12, !dbg !145
  br i1 %cmp113, label %while.cond117.preheader, label %while.cond294.preheader, !dbg !146

while.cond294.preheader:                          ; preds = %if.else
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !54, metadata !DIExpression()), !dbg !147
  br i1 %cmp118841, label %while.body297, label %while.end381, !dbg !148

while.cond117.preheader:                          ; preds = %if.else
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !45, metadata !DIExpression()), !dbg !149
  br i1 %cmp118841, label %while.body120, label %while.end180, !dbg !150

while.body120:                                    ; preds = %while.cond117.preheader, %while.body120
  %k116.0846 = phi ptr [ %add.ptr179, %while.body120 ], [ %key, %while.cond117.preheader ]
  %length.addr.1845 = phi i64 [ %sub178, %while.body120 ], [ %length, %while.cond117.preheader ]
  %c.3844 = phi i32 [ %xor176, %while.body120 ], [ %add, %while.cond117.preheader ]
  %b.3843 = phi i32 [ %add177, %while.body120 ], [ %add, %while.cond117.preheader ]
  %a.3842 = phi i32 [ %add171, %while.body120 ], [ %add, %while.cond117.preheader ]
  tail call void @llvm.dbg.value(metadata ptr %k116.0846, metadata !45, metadata !DIExpression()), !dbg !149
  tail call void @llvm.dbg.value(metadata i64 %length.addr.1845, metadata !31, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %c.3844, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %b.3843, metadata !33, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %a.3842, metadata !32, metadata !DIExpression()), !dbg !56
  %28 = load i32, ptr %k116.0846, align 2, !dbg !151
  %add127 = add i32 %28, %a.3842, !dbg !153
  tail call void @llvm.dbg.value(metadata i32 %add127, metadata !32, metadata !DIExpression()), !dbg !56
  %arrayidx128 = getelementptr inbounds i8, ptr %k116.0846, i64 4, !dbg !154
  %29 = load i32, ptr %arrayidx128, align 2, !dbg !154
  %add134 = add i32 %29, %b.3843, !dbg !155
  tail call void @llvm.dbg.value(metadata i32 %add134, metadata !33, metadata !DIExpression()), !dbg !56
  %arrayidx135 = getelementptr inbounds i8, ptr %k116.0846, i64 8, !dbg !156
  %30 = load i32, ptr %arrayidx135, align 2, !dbg !156
  %add141 = add i32 %30, %c.3844, !dbg !157
  tail call void @llvm.dbg.value(metadata i32 %add141, metadata !34, metadata !DIExpression()), !dbg !56
  %sub142 = sub i32 %add127, %add141, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %sub142, metadata !32, metadata !DIExpression()), !dbg !56
  %xor145 = tail call i32 @llvm.fshl.i32(i32 %add141, i32 %add141, i32 4), !dbg !158
  %xor146 = xor i32 %sub142, %xor145, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %xor146, metadata !32, metadata !DIExpression()), !dbg !56
  %add147 = add i32 %add141, %add134, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %add147, metadata !34, metadata !DIExpression()), !dbg !56
  %sub148 = sub i32 %add134, %xor146, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %sub148, metadata !33, metadata !DIExpression()), !dbg !56
  %xor151 = tail call i32 @llvm.fshl.i32(i32 %xor146, i32 %xor146, i32 6), !dbg !158
  %xor152 = xor i32 %sub148, %xor151, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %xor152, metadata !33, metadata !DIExpression()), !dbg !56
  %add153 = add i32 %xor146, %add147, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %add153, metadata !32, metadata !DIExpression()), !dbg !56
  %sub154 = sub i32 %add147, %xor152, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %sub154, metadata !34, metadata !DIExpression()), !dbg !56
  %xor157 = tail call i32 @llvm.fshl.i32(i32 %xor152, i32 %xor152, i32 8), !dbg !158
  %xor158 = xor i32 %sub154, %xor157, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %xor158, metadata !34, metadata !DIExpression()), !dbg !56
  %add159 = add i32 %xor152, %add153, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %add159, metadata !33, metadata !DIExpression()), !dbg !56
  %sub160 = sub i32 %add153, %xor158, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %sub160, metadata !32, metadata !DIExpression()), !dbg !56
  %xor163 = tail call i32 @llvm.fshl.i32(i32 %xor158, i32 %xor158, i32 16), !dbg !158
  %xor164 = xor i32 %sub160, %xor163, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %xor164, metadata !32, metadata !DIExpression()), !dbg !56
  %add165 = add i32 %xor158, %add159, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %add165, metadata !34, metadata !DIExpression()), !dbg !56
  %sub166 = sub i32 %add159, %xor164, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %sub166, metadata !33, metadata !DIExpression()), !dbg !56
  %xor169 = tail call i32 @llvm.fshl.i32(i32 %xor164, i32 %xor164, i32 19), !dbg !158
  %xor170 = xor i32 %sub166, %xor169, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %xor170, metadata !33, metadata !DIExpression()), !dbg !56
  %add171 = add i32 %xor164, %add165, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %add171, metadata !32, metadata !DIExpression()), !dbg !56
  %sub172 = sub i32 %add165, %xor170, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %sub172, metadata !34, metadata !DIExpression()), !dbg !56
  %xor175 = tail call i32 @llvm.fshl.i32(i32 %xor170, i32 %xor170, i32 4), !dbg !158
  %xor176 = xor i32 %sub172, %xor175, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %xor176, metadata !34, metadata !DIExpression()), !dbg !56
  %add177 = add i32 %xor170, %add171, !dbg !158
  tail call void @llvm.dbg.value(metadata i32 %add177, metadata !33, metadata !DIExpression()), !dbg !56
  %sub178 = add i64 %length.addr.1845, -12, !dbg !160
  tail call void @llvm.dbg.value(metadata i64 %sub178, metadata !31, metadata !DIExpression()), !dbg !56
  %add.ptr179 = getelementptr inbounds i8, ptr %k116.0846, i64 12, !dbg !161
  tail call void @llvm.dbg.value(metadata ptr %add.ptr179, metadata !45, metadata !DIExpression()), !dbg !149
  %cmp118 = icmp ugt i64 %sub178, 12, !dbg !162
  br i1 %cmp118, label %while.body120, label %while.end180, !dbg !150, !llvm.loop !163

while.end180:                                     ; preds = %while.body120, %while.cond117.preheader
  %a.3.lcssa = phi i32 [ %add, %while.cond117.preheader ], [ %add171, %while.body120 ], !dbg !56
  %b.3.lcssa = phi i32 [ %add, %while.cond117.preheader ], [ %add177, %while.body120 ], !dbg !56
  %c.3.lcssa = phi i32 [ %add, %while.cond117.preheader ], [ %xor176, %while.body120 ], !dbg !56
  %length.addr.1.lcssa = phi i64 [ %length, %while.cond117.preheader ], [ %sub178, %while.body120 ]
  %k116.0.lcssa = phi ptr [ %key, %while.cond117.preheader ], [ %add.ptr179, %while.body120 ], !dbg !149
  tail call void @llvm.dbg.value(metadata ptr %k116.0.lcssa, metadata !53, metadata !DIExpression()), !dbg !149
  switch i64 %length.addr.1.lcssa, label %default.unreachable [
    i64 12, label %sw.bb181
    i64 11, label %sw.bb203
    i64 10, label %sw.bb208
    i64 9, label %sw.bb226
    i64 8, label %sw.bb230
    i64 7, label %sw.bb245
    i64 6, label %sw.bb250
    i64 5, label %sw.bb261
    i64 4, label %sw.bb265
    i64 3, label %sw.bb273
    i64 2, label %sw.bb278
    i64 1, label %sw.bb282
    i64 0, label %cleanup480
  ], !dbg !165

sw.bb181:                                         ; preds = %while.end180
  %arrayidx182 = getelementptr inbounds i8, ptr %k116.0.lcssa, i64 8, !dbg !166
  %31 = load i32, ptr %arrayidx182, align 2, !dbg !166
  %add188 = add i32 %31, %c.3.lcssa, !dbg !168
  tail call void @llvm.dbg.value(metadata i32 %add188, metadata !34, metadata !DIExpression()), !dbg !56
  %arrayidx189 = getelementptr inbounds i8, ptr %k116.0.lcssa, i64 4, !dbg !169
  %32 = load i32, ptr %arrayidx189, align 2, !dbg !169
  %add195 = add i32 %32, %b.3.lcssa, !dbg !170
  tail call void @llvm.dbg.value(metadata i32 %add195, metadata !33, metadata !DIExpression()), !dbg !56
  %33 = load i32, ptr %k116.0.lcssa, align 2, !dbg !171
  %add202 = add i32 %33, %a.3.lcssa, !dbg !172
  tail call void @llvm.dbg.value(metadata i32 %add202, metadata !32, metadata !DIExpression()), !dbg !56
  br label %if.end444, !dbg !173

sw.bb203:                                         ; preds = %while.end180
  %arrayidx204 = getelementptr inbounds i8, ptr %k116.0.lcssa, i64 10, !dbg !174
  %34 = load i8, ptr %arrayidx204, align 1, !dbg !174, !tbaa !175
  %conv205 = zext i8 %34 to i32, !dbg !176
  %shl206 = shl nuw nsw i32 %conv205, 16, !dbg !177
  %add207 = add i32 %shl206, %c.3.lcssa, !dbg !178
  tail call void @llvm.dbg.value(metadata i32 %add207, metadata !34, metadata !DIExpression()), !dbg !56
  br label %sw.bb208, !dbg !179

sw.bb208:                                         ; preds = %while.end180, %sw.bb203
  %c.4 = phi i32 [ %c.3.lcssa, %while.end180 ], [ %add207, %sw.bb203 ], !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %c.4, metadata !34, metadata !DIExpression()), !dbg !56
  %arrayidx209 = getelementptr inbounds i8, ptr %k116.0.lcssa, i64 8, !dbg !180
  %35 = load i16, ptr %arrayidx209, align 2, !dbg !180, !tbaa !181
  %conv210 = zext i16 %35 to i32, !dbg !180
  %add211 = add i32 %c.4, %conv210, !dbg !183
  tail call void @llvm.dbg.value(metadata i32 %add211, metadata !34, metadata !DIExpression()), !dbg !56
  %arrayidx212 = getelementptr inbounds i8, ptr %k116.0.lcssa, i64 4, !dbg !184
  %36 = load i32, ptr %arrayidx212, align 2, !dbg !184
  %add218 = add i32 %36, %b.3.lcssa, !dbg !185
  tail call void @llvm.dbg.value(metadata i32 %add218, metadata !33, metadata !DIExpression()), !dbg !56
  %37 = load i32, ptr %k116.0.lcssa, align 2, !dbg !186
  %add225 = add i32 %37, %a.3.lcssa, !dbg !187
  tail call void @llvm.dbg.value(metadata i32 %add225, metadata !32, metadata !DIExpression()), !dbg !56
  br label %if.end444, !dbg !188

sw.bb226:                                         ; preds = %while.end180
  %arrayidx227 = getelementptr inbounds i8, ptr %k116.0.lcssa, i64 8, !dbg !189
  %38 = load i8, ptr %arrayidx227, align 1, !dbg !189, !tbaa !175
  %conv228 = zext i8 %38 to i32, !dbg !189
  %add229 = add i32 %c.3.lcssa, %conv228, !dbg !190
  tail call void @llvm.dbg.value(metadata i32 %add229, metadata !34, metadata !DIExpression()), !dbg !56
  br label %sw.bb230, !dbg !191

sw.bb230:                                         ; preds = %while.end180, %sw.bb226
  %c.5 = phi i32 [ %c.3.lcssa, %while.end180 ], [ %add229, %sw.bb226 ], !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %c.5, metadata !34, metadata !DIExpression()), !dbg !56
  %arrayidx231 = getelementptr inbounds i8, ptr %k116.0.lcssa, i64 4, !dbg !192
  %39 = load i32, ptr %arrayidx231, align 2, !dbg !192
  %add237 = add i32 %39, %b.3.lcssa, !dbg !193
  tail call void @llvm.dbg.value(metadata i32 %add237, metadata !33, metadata !DIExpression()), !dbg !56
  %40 = load i32, ptr %k116.0.lcssa, align 2, !dbg !194
  %add244 = add i32 %40, %a.3.lcssa, !dbg !195
  tail call void @llvm.dbg.value(metadata i32 %add244, metadata !32, metadata !DIExpression()), !dbg !56
  br label %if.end444, !dbg !196

sw.bb245:                                         ; preds = %while.end180
  %arrayidx246 = getelementptr inbounds i8, ptr %k116.0.lcssa, i64 6, !dbg !197
  %41 = load i8, ptr %arrayidx246, align 1, !dbg !197, !tbaa !175
  %conv247 = zext i8 %41 to i32, !dbg !198
  %shl248 = shl nuw nsw i32 %conv247, 16, !dbg !199
  %add249 = add i32 %shl248, %b.3.lcssa, !dbg !200
  tail call void @llvm.dbg.value(metadata i32 %add249, metadata !33, metadata !DIExpression()), !dbg !56
  br label %sw.bb250, !dbg !201

sw.bb250:                                         ; preds = %while.end180, %sw.bb245
  %b.4 = phi i32 [ %b.3.lcssa, %while.end180 ], [ %add249, %sw.bb245 ], !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %b.4, metadata !33, metadata !DIExpression()), !dbg !56
  %arrayidx251 = getelementptr inbounds i8, ptr %k116.0.lcssa, i64 4, !dbg !202
  %42 = load i16, ptr %arrayidx251, align 2, !dbg !202, !tbaa !181
  %conv252 = zext i16 %42 to i32, !dbg !202
  %add253 = add i32 %b.4, %conv252, !dbg !203
  tail call void @llvm.dbg.value(metadata i32 %add253, metadata !33, metadata !DIExpression()), !dbg !56
  %43 = load i32, ptr %k116.0.lcssa, align 2, !dbg !204
  %add260 = add i32 %43, %a.3.lcssa, !dbg !205
  tail call void @llvm.dbg.value(metadata i32 %add260, metadata !32, metadata !DIExpression()), !dbg !56
  br label %if.end444, !dbg !206

sw.bb261:                                         ; preds = %while.end180
  %arrayidx262 = getelementptr inbounds i8, ptr %k116.0.lcssa, i64 4, !dbg !207
  %44 = load i8, ptr %arrayidx262, align 1, !dbg !207, !tbaa !175
  %conv263 = zext i8 %44 to i32, !dbg !207
  %add264 = add i32 %b.3.lcssa, %conv263, !dbg !208
  tail call void @llvm.dbg.value(metadata i32 %add264, metadata !33, metadata !DIExpression()), !dbg !56
  br label %sw.bb265, !dbg !209

sw.bb265:                                         ; preds = %while.end180, %sw.bb261
  %b.5 = phi i32 [ %b.3.lcssa, %while.end180 ], [ %add264, %sw.bb261 ], !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %b.5, metadata !33, metadata !DIExpression()), !dbg !56
  %45 = load i32, ptr %k116.0.lcssa, align 2, !dbg !210
  %add272 = add i32 %45, %a.3.lcssa, !dbg !211
  tail call void @llvm.dbg.value(metadata i32 %add272, metadata !32, metadata !DIExpression()), !dbg !56
  br label %if.end444, !dbg !212

sw.bb273:                                         ; preds = %while.end180
  %arrayidx274 = getelementptr inbounds i8, ptr %k116.0.lcssa, i64 2, !dbg !213
  %46 = load i8, ptr %arrayidx274, align 1, !dbg !213, !tbaa !175
  %conv275 = zext i8 %46 to i32, !dbg !214
  %shl276 = shl nuw nsw i32 %conv275, 16, !dbg !215
  %add277 = add i32 %shl276, %a.3.lcssa, !dbg !216
  tail call void @llvm.dbg.value(metadata i32 %add277, metadata !32, metadata !DIExpression()), !dbg !56
  br label %sw.bb278, !dbg !217

sw.bb278:                                         ; preds = %while.end180, %sw.bb273
  %a.4 = phi i32 [ %a.3.lcssa, %while.end180 ], [ %add277, %sw.bb273 ], !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %a.4, metadata !32, metadata !DIExpression()), !dbg !56
  %47 = load i16, ptr %k116.0.lcssa, align 2, !dbg !218, !tbaa !181
  %conv280 = zext i16 %47 to i32, !dbg !218
  %add281 = add i32 %a.4, %conv280, !dbg !219
  tail call void @llvm.dbg.value(metadata i32 %add281, metadata !32, metadata !DIExpression()), !dbg !56
  br label %if.end444, !dbg !220

sw.bb282:                                         ; preds = %while.end180
  %48 = load i8, ptr %k116.0.lcssa, align 1, !dbg !221, !tbaa !175
  %conv284 = zext i8 %48 to i32, !dbg !221
  %add285 = add i32 %a.3.lcssa, %conv284, !dbg !222
  tail call void @llvm.dbg.value(metadata i32 %add285, metadata !32, metadata !DIExpression()), !dbg !56
  br label %if.end444, !dbg !223

while.body297:                                    ; preds = %while.cond294.preheader, %while.body297
  %k293.0836 = phi ptr [ %add.ptr380, %while.body297 ], [ %key, %while.cond294.preheader ]
  %length.addr.2835 = phi i64 [ %sub379, %while.body297 ], [ %length, %while.cond294.preheader ]
  %c.8834 = phi i32 [ %xor377, %while.body297 ], [ %add, %while.cond294.preheader ]
  %b.8833 = phi i32 [ %add378, %while.body297 ], [ %add, %while.cond294.preheader ]
  %a.7832 = phi i32 [ %add372, %while.body297 ], [ %add, %while.cond294.preheader ]
  tail call void @llvm.dbg.value(metadata ptr %k293.0836, metadata !54, metadata !DIExpression()), !dbg !147
  tail call void @llvm.dbg.value(metadata i64 %length.addr.2835, metadata !31, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %c.8834, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %b.8833, metadata !33, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %a.7832, metadata !32, metadata !DIExpression()), !dbg !56
  %49 = load i8, ptr %k293.0836, align 1, !dbg !224, !tbaa !175
  %conv299 = zext i8 %49 to i32, !dbg !224
  %add300 = add i32 %a.7832, %conv299, !dbg !226
  tail call void @llvm.dbg.value(metadata i32 %add300, metadata !32, metadata !DIExpression()), !dbg !56
  %arrayidx301 = getelementptr inbounds i8, ptr %k293.0836, i64 1, !dbg !227
  %50 = load i8, ptr %arrayidx301, align 1, !dbg !227, !tbaa !175
  %conv302 = zext i8 %50 to i32, !dbg !228
  %shl303 = shl nuw nsw i32 %conv302, 8, !dbg !229
  %add304 = add i32 %add300, %shl303, !dbg !230
  tail call void @llvm.dbg.value(metadata i32 %add304, metadata !32, metadata !DIExpression()), !dbg !56
  %arrayidx305 = getelementptr inbounds i8, ptr %k293.0836, i64 2, !dbg !231
  %51 = load i8, ptr %arrayidx305, align 1, !dbg !231, !tbaa !175
  %conv306 = zext i8 %51 to i32, !dbg !232
  %shl307 = shl nuw nsw i32 %conv306, 16, !dbg !233
  %add308 = add i32 %add304, %shl307, !dbg !234
  tail call void @llvm.dbg.value(metadata i32 %add308, metadata !32, metadata !DIExpression()), !dbg !56
  %arrayidx309 = getelementptr inbounds i8, ptr %k293.0836, i64 3, !dbg !235
  %52 = load i8, ptr %arrayidx309, align 1, !dbg !235, !tbaa !175
  %conv310 = zext i8 %52 to i32, !dbg !236
  %shl311 = shl nuw i32 %conv310, 24, !dbg !237
  %add312 = add i32 %add308, %shl311, !dbg !238
  tail call void @llvm.dbg.value(metadata i32 %add312, metadata !32, metadata !DIExpression()), !dbg !56
  %arrayidx313 = getelementptr inbounds i8, ptr %k293.0836, i64 4, !dbg !239
  %53 = load i8, ptr %arrayidx313, align 1, !dbg !239, !tbaa !175
  %conv314 = zext i8 %53 to i32, !dbg !239
  %add315 = add i32 %b.8833, %conv314, !dbg !240
  tail call void @llvm.dbg.value(metadata i32 %add315, metadata !33, metadata !DIExpression()), !dbg !56
  %arrayidx316 = getelementptr inbounds i8, ptr %k293.0836, i64 5, !dbg !241
  %54 = load i8, ptr %arrayidx316, align 1, !dbg !241, !tbaa !175
  %conv317 = zext i8 %54 to i32, !dbg !242
  %shl318 = shl nuw nsw i32 %conv317, 8, !dbg !243
  %add319 = add i32 %add315, %shl318, !dbg !244
  tail call void @llvm.dbg.value(metadata i32 %add319, metadata !33, metadata !DIExpression()), !dbg !56
  %arrayidx320 = getelementptr inbounds i8, ptr %k293.0836, i64 6, !dbg !245
  %55 = load i8, ptr %arrayidx320, align 1, !dbg !245, !tbaa !175
  %conv321 = zext i8 %55 to i32, !dbg !246
  %shl322 = shl nuw nsw i32 %conv321, 16, !dbg !247
  %add323 = add i32 %add319, %shl322, !dbg !248
  tail call void @llvm.dbg.value(metadata i32 %add323, metadata !33, metadata !DIExpression()), !dbg !56
  %arrayidx324 = getelementptr inbounds i8, ptr %k293.0836, i64 7, !dbg !249
  %56 = load i8, ptr %arrayidx324, align 1, !dbg !249, !tbaa !175
  %conv325 = zext i8 %56 to i32, !dbg !250
  %shl326 = shl nuw i32 %conv325, 24, !dbg !251
  %add327 = add i32 %add323, %shl326, !dbg !252
  tail call void @llvm.dbg.value(metadata i32 %add327, metadata !33, metadata !DIExpression()), !dbg !56
  %arrayidx328 = getelementptr inbounds i8, ptr %k293.0836, i64 8, !dbg !253
  %57 = load i8, ptr %arrayidx328, align 1, !dbg !253, !tbaa !175
  %conv329 = zext i8 %57 to i32, !dbg !253
  %add330 = add i32 %c.8834, %conv329, !dbg !254
  tail call void @llvm.dbg.value(metadata i32 %add330, metadata !34, metadata !DIExpression()), !dbg !56
  %arrayidx331 = getelementptr inbounds i8, ptr %k293.0836, i64 9, !dbg !255
  %58 = load i8, ptr %arrayidx331, align 1, !dbg !255, !tbaa !175
  %conv332 = zext i8 %58 to i32, !dbg !256
  %shl333 = shl nuw nsw i32 %conv332, 8, !dbg !257
  %add334 = add i32 %add330, %shl333, !dbg !258
  tail call void @llvm.dbg.value(metadata i32 %add334, metadata !34, metadata !DIExpression()), !dbg !56
  %arrayidx335 = getelementptr inbounds i8, ptr %k293.0836, i64 10, !dbg !259
  %59 = load i8, ptr %arrayidx335, align 1, !dbg !259, !tbaa !175
  %conv336 = zext i8 %59 to i32, !dbg !260
  %shl337 = shl nuw nsw i32 %conv336, 16, !dbg !261
  %add338 = add i32 %add334, %shl337, !dbg !262
  tail call void @llvm.dbg.value(metadata i32 %add338, metadata !34, metadata !DIExpression()), !dbg !56
  %arrayidx339 = getelementptr inbounds i8, ptr %k293.0836, i64 11, !dbg !263
  %60 = load i8, ptr %arrayidx339, align 1, !dbg !263, !tbaa !175
  %conv340 = zext i8 %60 to i32, !dbg !264
  %shl341 = shl nuw i32 %conv340, 24, !dbg !265
  %add342 = add i32 %add338, %shl341, !dbg !266
  tail call void @llvm.dbg.value(metadata i32 %add342, metadata !34, metadata !DIExpression()), !dbg !56
  %sub343 = sub i32 %add312, %add342, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %sub343, metadata !32, metadata !DIExpression()), !dbg !56
  %xor346 = tail call i32 @llvm.fshl.i32(i32 %add342, i32 %add342, i32 4), !dbg !267
  %xor347 = xor i32 %sub343, %xor346, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %xor347, metadata !32, metadata !DIExpression()), !dbg !56
  %add348 = add i32 %add342, %add327, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %add348, metadata !34, metadata !DIExpression()), !dbg !56
  %sub349 = sub i32 %add327, %xor347, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %sub349, metadata !33, metadata !DIExpression()), !dbg !56
  %xor352 = tail call i32 @llvm.fshl.i32(i32 %xor347, i32 %xor347, i32 6), !dbg !267
  %xor353 = xor i32 %sub349, %xor352, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %xor353, metadata !33, metadata !DIExpression()), !dbg !56
  %add354 = add i32 %xor347, %add348, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %add354, metadata !32, metadata !DIExpression()), !dbg !56
  %sub355 = sub i32 %add348, %xor353, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %sub355, metadata !34, metadata !DIExpression()), !dbg !56
  %xor358 = tail call i32 @llvm.fshl.i32(i32 %xor353, i32 %xor353, i32 8), !dbg !267
  %xor359 = xor i32 %sub355, %xor358, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %xor359, metadata !34, metadata !DIExpression()), !dbg !56
  %add360 = add i32 %xor353, %add354, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %add360, metadata !33, metadata !DIExpression()), !dbg !56
  %sub361 = sub i32 %add354, %xor359, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %sub361, metadata !32, metadata !DIExpression()), !dbg !56
  %xor364 = tail call i32 @llvm.fshl.i32(i32 %xor359, i32 %xor359, i32 16), !dbg !267
  %xor365 = xor i32 %sub361, %xor364, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %xor365, metadata !32, metadata !DIExpression()), !dbg !56
  %add366 = add i32 %xor359, %add360, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %add366, metadata !34, metadata !DIExpression()), !dbg !56
  %sub367 = sub i32 %add360, %xor365, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %sub367, metadata !33, metadata !DIExpression()), !dbg !56
  %xor370 = tail call i32 @llvm.fshl.i32(i32 %xor365, i32 %xor365, i32 19), !dbg !267
  %xor371 = xor i32 %sub367, %xor370, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %xor371, metadata !33, metadata !DIExpression()), !dbg !56
  %add372 = add i32 %xor365, %add366, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %add372, metadata !32, metadata !DIExpression()), !dbg !56
  %sub373 = sub i32 %add366, %xor371, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %sub373, metadata !34, metadata !DIExpression()), !dbg !56
  %xor376 = tail call i32 @llvm.fshl.i32(i32 %xor371, i32 %xor371, i32 4), !dbg !267
  %xor377 = xor i32 %sub373, %xor376, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %xor377, metadata !34, metadata !DIExpression()), !dbg !56
  %add378 = add i32 %xor371, %add372, !dbg !267
  tail call void @llvm.dbg.value(metadata i32 %add378, metadata !33, metadata !DIExpression()), !dbg !56
  %sub379 = add i64 %length.addr.2835, -12, !dbg !269
  tail call void @llvm.dbg.value(metadata i64 %sub379, metadata !31, metadata !DIExpression()), !dbg !56
  %add.ptr380 = getelementptr inbounds i8, ptr %k293.0836, i64 12, !dbg !270
  tail call void @llvm.dbg.value(metadata ptr %add.ptr380, metadata !54, metadata !DIExpression()), !dbg !147
  %cmp295 = icmp ugt i64 %sub379, 12, !dbg !271
  br i1 %cmp295, label %while.body297, label %while.end381, !dbg !148, !llvm.loop !272

while.end381:                                     ; preds = %while.body297, %while.cond294.preheader
  %a.7.lcssa = phi i32 [ %add, %while.cond294.preheader ], [ %add372, %while.body297 ], !dbg !56
  %b.8.lcssa = phi i32 [ %add, %while.cond294.preheader ], [ %add378, %while.body297 ], !dbg !56
  %c.8.lcssa = phi i32 [ %add, %while.cond294.preheader ], [ %xor377, %while.body297 ], !dbg !56
  %length.addr.2.lcssa = phi i64 [ %length, %while.cond294.preheader ], [ %sub379, %while.body297 ]
  %k293.0.lcssa = phi ptr [ %key, %while.cond294.preheader ], [ %add.ptr380, %while.body297 ], !dbg !147
  switch i64 %length.addr.2.lcssa, label %default.unreachable [
    i64 12, label %sw.bb382
    i64 11, label %sw.bb387
    i64 10, label %sw.bb392
    i64 9, label %sw.bb397
    i64 8, label %sw.bb401
    i64 7, label %sw.bb406
    i64 6, label %sw.bb411
    i64 5, label %sw.bb416
    i64 4, label %sw.bb420
    i64 3, label %sw.bb425
    i64 2, label %sw.bb430
    i64 1, label %cleanup441.thread
    i64 0, label %cleanup480
  ], !dbg !274

sw.bb382:                                         ; preds = %while.end381
  %arrayidx383 = getelementptr inbounds i8, ptr %k293.0.lcssa, i64 11, !dbg !275
  %61 = load i8, ptr %arrayidx383, align 1, !dbg !275, !tbaa !175
  %conv384 = zext i8 %61 to i32, !dbg !277
  %shl385 = shl nuw i32 %conv384, 24, !dbg !278
  %add386 = add i32 %shl385, %c.8.lcssa, !dbg !279
  tail call void @llvm.dbg.value(metadata i32 %add386, metadata !34, metadata !DIExpression()), !dbg !56
  br label %sw.bb387, !dbg !280

sw.bb387:                                         ; preds = %while.end381, %sw.bb382
  %c.9 = phi i32 [ %c.8.lcssa, %while.end381 ], [ %add386, %sw.bb382 ], !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %c.9, metadata !34, metadata !DIExpression()), !dbg !56
  %arrayidx388 = getelementptr inbounds i8, ptr %k293.0.lcssa, i64 10, !dbg !281
  %62 = load i8, ptr %arrayidx388, align 1, !dbg !281, !tbaa !175
  %conv389 = zext i8 %62 to i32, !dbg !282
  %shl390 = shl nuw nsw i32 %conv389, 16, !dbg !283
  %add391 = add i32 %shl390, %c.9, !dbg !284
  tail call void @llvm.dbg.value(metadata i32 %add391, metadata !34, metadata !DIExpression()), !dbg !56
  br label %sw.bb392, !dbg !285

sw.bb392:                                         ; preds = %while.end381, %sw.bb387
  %c.10 = phi i32 [ %c.8.lcssa, %while.end381 ], [ %add391, %sw.bb387 ], !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %c.10, metadata !34, metadata !DIExpression()), !dbg !56
  %arrayidx393 = getelementptr inbounds i8, ptr %k293.0.lcssa, i64 9, !dbg !286
  %63 = load i8, ptr %arrayidx393, align 1, !dbg !286, !tbaa !175
  %conv394 = zext i8 %63 to i32, !dbg !287
  %shl395 = shl nuw nsw i32 %conv394, 8, !dbg !288
  %add396 = add i32 %shl395, %c.10, !dbg !289
  tail call void @llvm.dbg.value(metadata i32 %add396, metadata !34, metadata !DIExpression()), !dbg !56
  br label %sw.bb397, !dbg !290

sw.bb397:                                         ; preds = %while.end381, %sw.bb392
  %c.11 = phi i32 [ %c.8.lcssa, %while.end381 ], [ %add396, %sw.bb392 ], !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %c.11, metadata !34, metadata !DIExpression()), !dbg !56
  %arrayidx398 = getelementptr inbounds i8, ptr %k293.0.lcssa, i64 8, !dbg !291
  %64 = load i8, ptr %arrayidx398, align 1, !dbg !291, !tbaa !175
  %conv399 = zext i8 %64 to i32, !dbg !291
  %add400 = add i32 %c.11, %conv399, !dbg !292
  tail call void @llvm.dbg.value(metadata i32 %add400, metadata !34, metadata !DIExpression()), !dbg !56
  br label %sw.bb401, !dbg !293

sw.bb401:                                         ; preds = %while.end381, %sw.bb397
  %c.12 = phi i32 [ %c.8.lcssa, %while.end381 ], [ %add400, %sw.bb397 ], !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %c.12, metadata !34, metadata !DIExpression()), !dbg !56
  %arrayidx402 = getelementptr inbounds i8, ptr %k293.0.lcssa, i64 7, !dbg !294
  %65 = load i8, ptr %arrayidx402, align 1, !dbg !294, !tbaa !175
  %conv403 = zext i8 %65 to i32, !dbg !295
  %shl404 = shl nuw i32 %conv403, 24, !dbg !296
  %add405 = add i32 %shl404, %b.8.lcssa, !dbg !297
  tail call void @llvm.dbg.value(metadata i32 %add405, metadata !33, metadata !DIExpression()), !dbg !56
  br label %sw.bb406, !dbg !298

sw.bb406:                                         ; preds = %while.end381, %sw.bb401
  %b.9 = phi i32 [ %b.8.lcssa, %while.end381 ], [ %add405, %sw.bb401 ], !dbg !56
  %c.13 = phi i32 [ %c.8.lcssa, %while.end381 ], [ %c.12, %sw.bb401 ], !dbg !299
  tail call void @llvm.dbg.value(metadata i32 %c.13, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %b.9, metadata !33, metadata !DIExpression()), !dbg !56
  %arrayidx407 = getelementptr inbounds i8, ptr %k293.0.lcssa, i64 6, !dbg !300
  %66 = load i8, ptr %arrayidx407, align 1, !dbg !300, !tbaa !175
  %conv408 = zext i8 %66 to i32, !dbg !301
  %shl409 = shl nuw nsw i32 %conv408, 16, !dbg !302
  %add410 = add i32 %shl409, %b.9, !dbg !303
  tail call void @llvm.dbg.value(metadata i32 %add410, metadata !33, metadata !DIExpression()), !dbg !56
  br label %sw.bb411, !dbg !304

sw.bb411:                                         ; preds = %while.end381, %sw.bb406
  %b.10 = phi i32 [ %b.8.lcssa, %while.end381 ], [ %add410, %sw.bb406 ], !dbg !56
  %c.14 = phi i32 [ %c.8.lcssa, %while.end381 ], [ %c.13, %sw.bb406 ], !dbg !299
  tail call void @llvm.dbg.value(metadata i32 %c.14, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %b.10, metadata !33, metadata !DIExpression()), !dbg !56
  %arrayidx412 = getelementptr inbounds i8, ptr %k293.0.lcssa, i64 5, !dbg !305
  %67 = load i8, ptr %arrayidx412, align 1, !dbg !305, !tbaa !175
  %conv413 = zext i8 %67 to i32, !dbg !306
  %shl414 = shl nuw nsw i32 %conv413, 8, !dbg !307
  %add415 = add i32 %shl414, %b.10, !dbg !308
  tail call void @llvm.dbg.value(metadata i32 %add415, metadata !33, metadata !DIExpression()), !dbg !56
  br label %sw.bb416, !dbg !309

sw.bb416:                                         ; preds = %while.end381, %sw.bb411
  %b.11 = phi i32 [ %b.8.lcssa, %while.end381 ], [ %add415, %sw.bb411 ], !dbg !56
  %c.15 = phi i32 [ %c.8.lcssa, %while.end381 ], [ %c.14, %sw.bb411 ], !dbg !299
  tail call void @llvm.dbg.value(metadata i32 %c.15, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %b.11, metadata !33, metadata !DIExpression()), !dbg !56
  %arrayidx417 = getelementptr inbounds i8, ptr %k293.0.lcssa, i64 4, !dbg !310
  %68 = load i8, ptr %arrayidx417, align 1, !dbg !310, !tbaa !175
  %conv418 = zext i8 %68 to i32, !dbg !310
  %add419 = add i32 %b.11, %conv418, !dbg !311
  tail call void @llvm.dbg.value(metadata i32 %add419, metadata !33, metadata !DIExpression()), !dbg !56
  br label %sw.bb420, !dbg !312

sw.bb420:                                         ; preds = %while.end381, %sw.bb416
  %b.12 = phi i32 [ %b.8.lcssa, %while.end381 ], [ %add419, %sw.bb416 ], !dbg !56
  %c.16 = phi i32 [ %c.8.lcssa, %while.end381 ], [ %c.15, %sw.bb416 ], !dbg !299
  tail call void @llvm.dbg.value(metadata i32 %c.16, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %b.12, metadata !33, metadata !DIExpression()), !dbg !56
  %arrayidx421 = getelementptr inbounds i8, ptr %k293.0.lcssa, i64 3, !dbg !313
  %69 = load i8, ptr %arrayidx421, align 1, !dbg !313, !tbaa !175
  %conv422 = zext i8 %69 to i32, !dbg !314
  %shl423 = shl nuw i32 %conv422, 24, !dbg !315
  %add424 = add i32 %shl423, %a.7.lcssa, !dbg !316
  tail call void @llvm.dbg.value(metadata i32 %add424, metadata !32, metadata !DIExpression()), !dbg !56
  br label %sw.bb425, !dbg !317

sw.bb425:                                         ; preds = %while.end381, %sw.bb420
  %a.8 = phi i32 [ %a.7.lcssa, %while.end381 ], [ %add424, %sw.bb420 ], !dbg !56
  %b.13 = phi i32 [ %b.8.lcssa, %while.end381 ], [ %b.12, %sw.bb420 ], !dbg !318
  %c.17 = phi i32 [ %c.8.lcssa, %while.end381 ], [ %c.16, %sw.bb420 ], !dbg !299
  tail call void @llvm.dbg.value(metadata i32 %c.17, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %b.13, metadata !33, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %a.8, metadata !32, metadata !DIExpression()), !dbg !56
  %arrayidx426 = getelementptr inbounds i8, ptr %k293.0.lcssa, i64 2, !dbg !319
  %70 = load i8, ptr %arrayidx426, align 1, !dbg !319, !tbaa !175
  %conv427 = zext i8 %70 to i32, !dbg !320
  %shl428 = shl nuw nsw i32 %conv427, 16, !dbg !321
  %add429 = add i32 %shl428, %a.8, !dbg !322
  tail call void @llvm.dbg.value(metadata i32 %add429, metadata !32, metadata !DIExpression()), !dbg !56
  br label %sw.bb430, !dbg !323

sw.bb430:                                         ; preds = %while.end381, %sw.bb425
  %a.9 = phi i32 [ %a.7.lcssa, %while.end381 ], [ %add429, %sw.bb425 ], !dbg !56
  %b.14 = phi i32 [ %b.8.lcssa, %while.end381 ], [ %b.13, %sw.bb425 ], !dbg !318
  %c.18 = phi i32 [ %c.8.lcssa, %while.end381 ], [ %c.17, %sw.bb425 ], !dbg !299
  tail call void @llvm.dbg.value(metadata i32 %c.18, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %b.14, metadata !33, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %a.9, metadata !32, metadata !DIExpression()), !dbg !56
  %arrayidx431 = getelementptr inbounds i8, ptr %k293.0.lcssa, i64 1, !dbg !324
  %71 = load i8, ptr %arrayidx431, align 1, !dbg !324, !tbaa !175
  %conv432 = zext i8 %71 to i32, !dbg !325
  %shl433 = shl nuw nsw i32 %conv432, 8, !dbg !326
  %add434 = add i32 %shl433, %a.9, !dbg !327
  tail call void @llvm.dbg.value(metadata i32 %add434, metadata !32, metadata !DIExpression()), !dbg !56
  br label %cleanup441.thread, !dbg !328

cleanup441.thread:                                ; preds = %while.end381, %sw.bb430
  %a.10 = phi i32 [ %a.7.lcssa, %while.end381 ], [ %add434, %sw.bb430 ], !dbg !56
  %b.15 = phi i32 [ %b.8.lcssa, %while.end381 ], [ %b.14, %sw.bb430 ], !dbg !318
  %c.19 = phi i32 [ %c.8.lcssa, %while.end381 ], [ %c.18, %sw.bb430 ], !dbg !299
  tail call void @llvm.dbg.value(metadata i32 %c.19, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %b.15, metadata !33, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i8 poison), metadata !32, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_plus, DW_OP_stack_value)), !dbg !56
  %72 = load i8, ptr %k293.0.lcssa, align 1, !dbg !329, !tbaa !175
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %a.10, i8 %72), metadata !32, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_plus, DW_OP_stack_value)), !dbg !56
  %conv437 = zext i8 %72 to i32, !dbg !329
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %a.10, i32 %conv437), metadata !32, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value)), !dbg !56
  %add438 = add i32 %a.10, %conv437, !dbg !330
  tail call void @llvm.dbg.value(metadata i32 %add438, metadata !32, metadata !DIExpression()), !dbg !56
  br label %if.end444

if.end444:                                        ; preds = %sw.bb181, %sw.bb208, %sw.bb230, %sw.bb250, %sw.bb265, %sw.bb278, %sw.bb282, %cleanup441.thread, %cleanup.thread
  %a.13 = phi i32 [ %a.1, %cleanup.thread ], [ %add438, %cleanup441.thread ], [ %add202, %sw.bb181 ], [ %add225, %sw.bb208 ], [ %add244, %sw.bb230 ], [ %add260, %sw.bb250 ], [ %add272, %sw.bb265 ], [ %add281, %sw.bb278 ], [ %add285, %sw.bb282 ], !dbg !331
  %b.18 = phi i32 [ %b.1, %cleanup.thread ], [ %b.15, %cleanup441.thread ], [ %add195, %sw.bb181 ], [ %add218, %sw.bb208 ], [ %add237, %sw.bb230 ], [ %add253, %sw.bb250 ], [ %b.5, %sw.bb265 ], [ %b.3.lcssa, %sw.bb278 ], [ %b.3.lcssa, %sw.bb282 ], !dbg !318
  %c.22 = phi i32 [ %c.1, %cleanup.thread ], [ %c.19, %cleanup441.thread ], [ %add188, %sw.bb181 ], [ %add211, %sw.bb208 ], [ %c.5, %sw.bb230 ], [ %c.3.lcssa, %sw.bb250 ], [ %c.3.lcssa, %sw.bb265 ], [ %c.3.lcssa, %sw.bb278 ], [ %c.3.lcssa, %sw.bb282 ], !dbg !299
  tail call void @llvm.dbg.value(metadata i32 %c.22, metadata !34, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %b.18, metadata !33, metadata !DIExpression()), !dbg !56
  tail call void @llvm.dbg.value(metadata i32 %a.13, metadata !32, metadata !DIExpression()), !dbg !56
  %xor445 = xor i32 %c.22, %b.18, !dbg !332
  tail call void @llvm.dbg.value(metadata i32 %xor445, metadata !34, metadata !DIExpression()), !dbg !56
  %xor448 = tail call i32 @llvm.fshl.i32(i32 %b.18, i32 %b.18, i32 14), !dbg !332
  %sub449 = sub i32 %xor445, %xor448, !dbg !332
  tail call void @llvm.dbg.value(metadata i32 %sub449, metadata !34, metadata !DIExpression()), !dbg !56
  %xor450 = xor i32 %sub449, %a.13, !dbg !332
  tail call void @llvm.dbg.value(metadata i32 %xor450, metadata !32, metadata !DIExpression()), !dbg !56
  %xor453 = tail call i32 @llvm.fshl.i32(i32 %sub449, i32 %sub449, i32 11), !dbg !332
  %sub454 = sub i32 %xor450, %xor453, !dbg !332
  tail call void @llvm.dbg.value(metadata i32 %sub454, metadata !32, metadata !DIExpression()), !dbg !56
  %xor455 = xor i32 %sub454, %b.18, !dbg !332
  tail call void @llvm.dbg.value(metadata i32 %xor455, metadata !33, metadata !DIExpression()), !dbg !56
  %xor458 = tail call i32 @llvm.fshl.i32(i32 %sub454, i32 %sub454, i32 25), !dbg !332
  %sub459 = sub i32 %xor455, %xor458, !dbg !332
  tail call void @llvm.dbg.value(metadata i32 %sub459, metadata !33, metadata !DIExpression()), !dbg !56
  %xor460 = xor i32 %sub459, %sub449, !dbg !332
  tail call void @llvm.dbg.value(metadata i32 %xor460, metadata !34, metadata !DIExpression()), !dbg !56
  %xor463 = tail call i32 @llvm.fshl.i32(i32 %sub459, i32 %sub459, i32 16), !dbg !332
  %sub464 = sub i32 %xor460, %xor463, !dbg !332
  tail call void @llvm.dbg.value(metadata i32 %sub464, metadata !34, metadata !DIExpression()), !dbg !56
  %xor465 = xor i32 %sub464, %sub454, !dbg !332
  tail call void @llvm.dbg.value(metadata i32 %xor465, metadata !32, metadata !DIExpression()), !dbg !56
  %xor468 = tail call i32 @llvm.fshl.i32(i32 %sub464, i32 %sub464, i32 4), !dbg !332
  %sub469 = sub i32 %xor465, %xor468, !dbg !332
  tail call void @llvm.dbg.value(metadata i32 %sub469, metadata !32, metadata !DIExpression()), !dbg !56
  %xor470 = xor i32 %sub469, %sub459, !dbg !332
  tail call void @llvm.dbg.value(metadata i32 %xor470, metadata !33, metadata !DIExpression()), !dbg !56
  %xor473 = tail call i32 @llvm.fshl.i32(i32 %sub469, i32 %sub469, i32 14), !dbg !332
  %sub474 = sub i32 %xor470, %xor473, !dbg !332
  tail call void @llvm.dbg.value(metadata i32 %sub474, metadata !33, metadata !DIExpression()), !dbg !56
  %xor475 = xor i32 %sub474, %sub464, !dbg !332
  tail call void @llvm.dbg.value(metadata i32 %xor475, metadata !34, metadata !DIExpression()), !dbg !56
  %xor478 = tail call i32 @llvm.fshl.i32(i32 %sub474, i32 %sub474, i32 24), !dbg !332
  %sub479 = sub i32 %xor475, %xor478, !dbg !332
  tail call void @llvm.dbg.value(metadata i32 %sub479, metadata !34, metadata !DIExpression()), !dbg !56
  br label %cleanup480, !dbg !334

cleanup480:                                       ; preds = %while.end381, %while.end180, %while.end, %if.end444
  %retval.3 = phi i32 [ %sub479, %if.end444 ], [ %c.0.lcssa, %while.end ], [ %c.3.lcssa, %while.end180 ], [ %c.8.lcssa, %while.end381 ]
  ret i32 %retval.3, !dbg !335
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fshl.i32(i32, i32, i32) #1

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #2 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { nofree norecurse nosync nounwind sanitize_thread memory(read, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nounwind uwtable }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!13, !14, !15, !16, !17, !18, !19}
!llvm.ident = !{!20}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !2, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "jenkins_hash.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "02a1bc4699ba1ca33271c47b2b9786f2")
!2 = !{!3, !8}
!3 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !4, line: 26, baseType: !5)
!4 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!5 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !6, line: 42, baseType: !7)
!6 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !9, size: 64)
!9 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !10)
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !4, line: 24, baseType: !11)
!11 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !6, line: 38, baseType: !12)
!12 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!13 = !{i32 7, !"Dwarf Version", i32 5}
!14 = !{i32 2, !"Debug Info Version", i32 3}
!15 = !{i32 1, !"wchar_size", i32 4}
!16 = !{i32 8, !"PIC Level", i32 2}
!17 = !{i32 7, !"PIE Level", i32 2}
!18 = !{i32 7, !"uwtable", i32 2}
!19 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!20 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!21 = distinct !DISubprogram(name: "jenkins_hash", scope: !1, file: !1, line: 126, type: !22, scopeLine: 129, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !29)
!22 = !DISubroutineType(types: !23)
!23 = !{!3, !24, !26}
!24 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !25, size: 64)
!25 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!26 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !27, line: 18, baseType: !28)
!27 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!28 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!29 = !{!30, !31, !32, !33, !34, !35, !40, !45, !53, !54}
!30 = !DILocalVariable(name: "key", arg: 1, scope: !21, file: !1, line: 127, type: !24)
!31 = !DILocalVariable(name: "length", arg: 2, scope: !21, file: !1, line: 128, type: !26)
!32 = !DILocalVariable(name: "a", scope: !21, file: !1, line: 130, type: !3)
!33 = !DILocalVariable(name: "b", scope: !21, file: !1, line: 130, type: !3)
!34 = !DILocalVariable(name: "c", scope: !21, file: !1, line: 130, type: !3)
!35 = !DILocalVariable(name: "u", scope: !21, file: !1, line: 131, type: !36)
!36 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !21, file: !1, line: 131, size: 64, elements: !37)
!37 = !{!38, !39}
!38 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !36, file: !1, line: 131, baseType: !24, size: 64)
!39 = !DIDerivedType(tag: DW_TAG_member, name: "i", scope: !36, file: !1, line: 131, baseType: !26, size: 64)
!40 = !DILocalVariable(name: "k", scope: !41, file: !1, line: 138, type: !43)
!41 = distinct !DILexicalBlock(scope: !42, file: !1, line: 137, column: 49)
!42 = distinct !DILexicalBlock(scope: !21, file: !1, line: 137, column: 7)
!43 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !44, size: 64)
!44 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !3)
!45 = !DILocalVariable(name: "k", scope: !46, file: !1, line: 206, type: !48)
!46 = distinct !DILexicalBlock(scope: !47, file: !1, line: 205, column: 56)
!47 = distinct !DILexicalBlock(scope: !42, file: !1, line: 205, column: 14)
!48 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !49, size: 64)
!49 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !50)
!50 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint16_t", file: !4, line: 25, baseType: !51)
!51 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint16_t", file: !6, line: 40, baseType: !52)
!52 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!53 = !DILocalVariable(name: "k8", scope: !46, file: !1, line: 207, type: !8)
!54 = !DILocalVariable(name: "k", scope: !55, file: !1, line: 253, type: !8)
!55 = distinct !DILexicalBlock(scope: !47, file: !1, line: 252, column: 10)
!56 = !DILocation(line: 0, scope: !21)
!57 = !DILocation(line: 134, column: 29, scope: !21)
!58 = !DILocation(line: 134, column: 26, scope: !21)
!59 = !DILocation(line: 137, column: 33, scope: !42)
!60 = !DILocation(line: 137, column: 35, scope: !42)
!61 = !DILocation(line: 137, column: 42, scope: !42)
!62 = !DILocation(line: 137, column: 7, scope: !21)
!63 = !DILocation(line: 0, scope: !41)
!64 = !DILocation(line: 144, column: 19, scope: !41)
!65 = !DILocation(line: 144, column: 5, scope: !41)
!66 = !DILocation(line: 146, column: 12, scope: !67)
!67 = distinct !DILexicalBlock(scope: !41, file: !1, line: 145, column: 5)
!68 = !{!69, !69, i64 0}
!69 = !{!"int", !70, i64 0}
!70 = !{!"omnipotent char", !71, i64 0}
!71 = !{!"Simple C/C++ TBAA"}
!72 = !DILocation(line: 146, column: 9, scope: !67)
!73 = !DILocation(line: 147, column: 12, scope: !67)
!74 = !DILocation(line: 147, column: 9, scope: !67)
!75 = !DILocation(line: 148, column: 12, scope: !67)
!76 = !DILocation(line: 148, column: 9, scope: !67)
!77 = !DILocation(line: 149, column: 7, scope: !78)
!78 = distinct !DILexicalBlock(scope: !67, file: !1, line: 149, column: 7)
!79 = !DILocation(line: 150, column: 14, scope: !67)
!80 = !DILocation(line: 151, column: 9, scope: !67)
!81 = distinct !{!81, !65, !82, !83}
!82 = !DILocation(line: 152, column: 5, scope: !41)
!83 = !{!"llvm.loop.mustprogress"}
!84 = !DILocation(line: 166, column: 5, scope: !41)
!85 = !DILocation(line: 168, column: 17, scope: !86)
!86 = distinct !DILexicalBlock(scope: !41, file: !1, line: 167, column: 5)
!87 = !DILocation(line: 168, column: 15, scope: !86)
!88 = !DILocation(line: 168, column: 26, scope: !86)
!89 = !DILocation(line: 168, column: 24, scope: !86)
!90 = !DILocation(line: 168, column: 35, scope: !86)
!91 = !DILocation(line: 168, column: 41, scope: !86)
!92 = !DILocation(line: 169, column: 17, scope: !86)
!93 = !DILocation(line: 169, column: 21, scope: !86)
!94 = !DILocation(line: 169, column: 15, scope: !86)
!95 = !DILocation(line: 169, column: 35, scope: !86)
!96 = !DILocation(line: 169, column: 33, scope: !86)
!97 = !DILocation(line: 169, column: 44, scope: !86)
!98 = !DILocation(line: 169, column: 50, scope: !86)
!99 = !DILocation(line: 170, column: 17, scope: !86)
!100 = !DILocation(line: 170, column: 21, scope: !86)
!101 = !DILocation(line: 170, column: 15, scope: !86)
!102 = !DILocation(line: 170, column: 33, scope: !86)
!103 = !DILocation(line: 170, column: 31, scope: !86)
!104 = !DILocation(line: 170, column: 42, scope: !86)
!105 = !DILocation(line: 170, column: 48, scope: !86)
!106 = !DILocation(line: 171, column: 17, scope: !86)
!107 = !DILocation(line: 171, column: 21, scope: !86)
!108 = !DILocation(line: 171, column: 15, scope: !86)
!109 = !DILocation(line: 171, column: 31, scope: !86)
!110 = !DILocation(line: 171, column: 29, scope: !86)
!111 = !DILocation(line: 171, column: 40, scope: !86)
!112 = !DILocation(line: 171, column: 46, scope: !86)
!113 = !DILocation(line: 172, column: 17, scope: !86)
!114 = !DILocation(line: 172, column: 15, scope: !86)
!115 = !DILocation(line: 172, column: 26, scope: !86)
!116 = !DILocation(line: 172, column: 32, scope: !86)
!117 = !DILocation(line: 173, column: 17, scope: !86)
!118 = !DILocation(line: 173, column: 21, scope: !86)
!119 = !DILocation(line: 173, column: 15, scope: !86)
!120 = !DILocation(line: 173, column: 35, scope: !86)
!121 = !DILocation(line: 173, column: 41, scope: !86)
!122 = !DILocation(line: 174, column: 17, scope: !86)
!123 = !DILocation(line: 174, column: 21, scope: !86)
!124 = !DILocation(line: 174, column: 15, scope: !86)
!125 = !DILocation(line: 174, column: 33, scope: !86)
!126 = !DILocation(line: 174, column: 39, scope: !86)
!127 = !DILocation(line: 175, column: 17, scope: !86)
!128 = !DILocation(line: 175, column: 21, scope: !86)
!129 = !DILocation(line: 175, column: 15, scope: !86)
!130 = !DILocation(line: 175, column: 31, scope: !86)
!131 = !DILocation(line: 175, column: 37, scope: !86)
!132 = !DILocation(line: 176, column: 17, scope: !86)
!133 = !DILocation(line: 176, column: 23, scope: !86)
!134 = !DILocation(line: 177, column: 17, scope: !86)
!135 = !DILocation(line: 177, column: 21, scope: !86)
!136 = !DILocation(line: 177, column: 32, scope: !86)
!137 = !DILocation(line: 178, column: 17, scope: !86)
!138 = !DILocation(line: 178, column: 21, scope: !86)
!139 = !DILocation(line: 178, column: 30, scope: !86)
!140 = !DILocation(line: 179, column: 17, scope: !86)
!141 = !DILocation(line: 179, column: 21, scope: !86)
!142 = !DILocation(line: 179, column: 28, scope: !86)
!143 = !DILocation(line: 205, column: 42, scope: !47)
!144 = !DILocation(line: 205, column: 49, scope: !47)
!145 = !DILocation(line: 0, scope: !47)
!146 = !DILocation(line: 205, column: 14, scope: !42)
!147 = !DILocation(line: 0, scope: !55)
!148 = !DILocation(line: 256, column: 5, scope: !55)
!149 = !DILocation(line: 0, scope: !46)
!150 = !DILocation(line: 210, column: 5, scope: !46)
!151 = !DILocation(line: 212, column: 12, scope: !152)
!152 = distinct !DILexicalBlock(scope: !46, file: !1, line: 211, column: 5)
!153 = !DILocation(line: 212, column: 9, scope: !152)
!154 = !DILocation(line: 213, column: 12, scope: !152)
!155 = !DILocation(line: 213, column: 9, scope: !152)
!156 = !DILocation(line: 214, column: 12, scope: !152)
!157 = !DILocation(line: 214, column: 9, scope: !152)
!158 = !DILocation(line: 215, column: 7, scope: !159)
!159 = distinct !DILexicalBlock(scope: !152, file: !1, line: 215, column: 7)
!160 = !DILocation(line: 216, column: 14, scope: !152)
!161 = !DILocation(line: 217, column: 9, scope: !152)
!162 = !DILocation(line: 210, column: 19, scope: !46)
!163 = distinct !{!163, !150, !164, !83}
!164 = !DILocation(line: 218, column: 5, scope: !46)
!165 = !DILocation(line: 222, column: 5, scope: !46)
!166 = !DILocation(line: 224, column: 17, scope: !167)
!167 = distinct !DILexicalBlock(scope: !46, file: !1, line: 223, column: 5)
!168 = !DILocation(line: 224, column: 15, scope: !167)
!169 = !DILocation(line: 225, column: 17, scope: !167)
!170 = !DILocation(line: 225, column: 15, scope: !167)
!171 = !DILocation(line: 226, column: 17, scope: !167)
!172 = !DILocation(line: 226, column: 15, scope: !167)
!173 = !DILocation(line: 227, column: 14, scope: !167)
!174 = !DILocation(line: 228, column: 28, scope: !167)
!175 = !{!70, !70, i64 0}
!176 = !DILocation(line: 228, column: 18, scope: !167)
!177 = !DILocation(line: 228, column: 35, scope: !167)
!178 = !DILocation(line: 228, column: 15, scope: !167)
!179 = !DILocation(line: 228, column: 14, scope: !167)
!180 = !DILocation(line: 229, column: 17, scope: !167)
!181 = !{!182, !182, i64 0}
!182 = !{!"short", !70, i64 0}
!183 = !DILocation(line: 229, column: 15, scope: !167)
!184 = !DILocation(line: 230, column: 17, scope: !167)
!185 = !DILocation(line: 230, column: 15, scope: !167)
!186 = !DILocation(line: 231, column: 17, scope: !167)
!187 = !DILocation(line: 231, column: 15, scope: !167)
!188 = !DILocation(line: 232, column: 14, scope: !167)
!189 = !DILocation(line: 233, column: 17, scope: !167)
!190 = !DILocation(line: 233, column: 15, scope: !167)
!191 = !DILocation(line: 233, column: 14, scope: !167)
!192 = !DILocation(line: 234, column: 17, scope: !167)
!193 = !DILocation(line: 234, column: 15, scope: !167)
!194 = !DILocation(line: 235, column: 17, scope: !167)
!195 = !DILocation(line: 235, column: 15, scope: !167)
!196 = !DILocation(line: 236, column: 14, scope: !167)
!197 = !DILocation(line: 237, column: 28, scope: !167)
!198 = !DILocation(line: 237, column: 18, scope: !167)
!199 = !DILocation(line: 237, column: 34, scope: !167)
!200 = !DILocation(line: 237, column: 15, scope: !167)
!201 = !DILocation(line: 237, column: 14, scope: !167)
!202 = !DILocation(line: 238, column: 17, scope: !167)
!203 = !DILocation(line: 238, column: 15, scope: !167)
!204 = !DILocation(line: 239, column: 17, scope: !167)
!205 = !DILocation(line: 239, column: 15, scope: !167)
!206 = !DILocation(line: 240, column: 14, scope: !167)
!207 = !DILocation(line: 241, column: 17, scope: !167)
!208 = !DILocation(line: 241, column: 15, scope: !167)
!209 = !DILocation(line: 241, column: 14, scope: !167)
!210 = !DILocation(line: 242, column: 17, scope: !167)
!211 = !DILocation(line: 242, column: 15, scope: !167)
!212 = !DILocation(line: 243, column: 14, scope: !167)
!213 = !DILocation(line: 244, column: 28, scope: !167)
!214 = !DILocation(line: 244, column: 18, scope: !167)
!215 = !DILocation(line: 244, column: 34, scope: !167)
!216 = !DILocation(line: 244, column: 15, scope: !167)
!217 = !DILocation(line: 244, column: 14, scope: !167)
!218 = !DILocation(line: 245, column: 17, scope: !167)
!219 = !DILocation(line: 245, column: 15, scope: !167)
!220 = !DILocation(line: 246, column: 14, scope: !167)
!221 = !DILocation(line: 247, column: 17, scope: !167)
!222 = !DILocation(line: 247, column: 15, scope: !167)
!223 = !DILocation(line: 248, column: 14, scope: !167)
!224 = !DILocation(line: 258, column: 12, scope: !225)
!225 = distinct !DILexicalBlock(scope: !55, file: !1, line: 257, column: 5)
!226 = !DILocation(line: 258, column: 9, scope: !225)
!227 = !DILocation(line: 259, column: 23, scope: !225)
!228 = !DILocation(line: 259, column: 13, scope: !225)
!229 = !DILocation(line: 259, column: 28, scope: !225)
!230 = !DILocation(line: 259, column: 9, scope: !225)
!231 = !DILocation(line: 260, column: 23, scope: !225)
!232 = !DILocation(line: 260, column: 13, scope: !225)
!233 = !DILocation(line: 260, column: 28, scope: !225)
!234 = !DILocation(line: 260, column: 9, scope: !225)
!235 = !DILocation(line: 261, column: 23, scope: !225)
!236 = !DILocation(line: 261, column: 13, scope: !225)
!237 = !DILocation(line: 261, column: 28, scope: !225)
!238 = !DILocation(line: 261, column: 9, scope: !225)
!239 = !DILocation(line: 262, column: 12, scope: !225)
!240 = !DILocation(line: 262, column: 9, scope: !225)
!241 = !DILocation(line: 263, column: 23, scope: !225)
!242 = !DILocation(line: 263, column: 13, scope: !225)
!243 = !DILocation(line: 263, column: 28, scope: !225)
!244 = !DILocation(line: 263, column: 9, scope: !225)
!245 = !DILocation(line: 264, column: 23, scope: !225)
!246 = !DILocation(line: 264, column: 13, scope: !225)
!247 = !DILocation(line: 264, column: 28, scope: !225)
!248 = !DILocation(line: 264, column: 9, scope: !225)
!249 = !DILocation(line: 265, column: 23, scope: !225)
!250 = !DILocation(line: 265, column: 13, scope: !225)
!251 = !DILocation(line: 265, column: 28, scope: !225)
!252 = !DILocation(line: 265, column: 9, scope: !225)
!253 = !DILocation(line: 266, column: 12, scope: !225)
!254 = !DILocation(line: 266, column: 9, scope: !225)
!255 = !DILocation(line: 267, column: 23, scope: !225)
!256 = !DILocation(line: 267, column: 13, scope: !225)
!257 = !DILocation(line: 267, column: 28, scope: !225)
!258 = !DILocation(line: 267, column: 9, scope: !225)
!259 = !DILocation(line: 268, column: 23, scope: !225)
!260 = !DILocation(line: 268, column: 13, scope: !225)
!261 = !DILocation(line: 268, column: 29, scope: !225)
!262 = !DILocation(line: 268, column: 9, scope: !225)
!263 = !DILocation(line: 269, column: 23, scope: !225)
!264 = !DILocation(line: 269, column: 13, scope: !225)
!265 = !DILocation(line: 269, column: 29, scope: !225)
!266 = !DILocation(line: 269, column: 9, scope: !225)
!267 = !DILocation(line: 270, column: 7, scope: !268)
!268 = distinct !DILexicalBlock(scope: !225, file: !1, line: 270, column: 7)
!269 = !DILocation(line: 271, column: 14, scope: !225)
!270 = !DILocation(line: 272, column: 9, scope: !225)
!271 = !DILocation(line: 256, column: 19, scope: !55)
!272 = distinct !{!272, !148, !273, !83}
!273 = !DILocation(line: 273, column: 5, scope: !55)
!274 = !DILocation(line: 276, column: 5, scope: !55)
!275 = !DILocation(line: 278, column: 28, scope: !276)
!276 = distinct !DILexicalBlock(scope: !55, file: !1, line: 277, column: 5)
!277 = !DILocation(line: 278, column: 18, scope: !276)
!278 = !DILocation(line: 278, column: 34, scope: !276)
!279 = !DILocation(line: 278, column: 15, scope: !276)
!280 = !DILocation(line: 278, column: 14, scope: !276)
!281 = !DILocation(line: 279, column: 28, scope: !276)
!282 = !DILocation(line: 279, column: 18, scope: !276)
!283 = !DILocation(line: 279, column: 34, scope: !276)
!284 = !DILocation(line: 279, column: 15, scope: !276)
!285 = !DILocation(line: 279, column: 14, scope: !276)
!286 = !DILocation(line: 280, column: 28, scope: !276)
!287 = !DILocation(line: 280, column: 18, scope: !276)
!288 = !DILocation(line: 280, column: 33, scope: !276)
!289 = !DILocation(line: 280, column: 15, scope: !276)
!290 = !DILocation(line: 280, column: 14, scope: !276)
!291 = !DILocation(line: 281, column: 17, scope: !276)
!292 = !DILocation(line: 281, column: 15, scope: !276)
!293 = !DILocation(line: 281, column: 14, scope: !276)
!294 = !DILocation(line: 282, column: 28, scope: !276)
!295 = !DILocation(line: 282, column: 18, scope: !276)
!296 = !DILocation(line: 282, column: 33, scope: !276)
!297 = !DILocation(line: 282, column: 15, scope: !276)
!298 = !DILocation(line: 282, column: 14, scope: !276)
!299 = !DILocation(line: 134, column: 13, scope: !21)
!300 = !DILocation(line: 283, column: 28, scope: !276)
!301 = !DILocation(line: 283, column: 18, scope: !276)
!302 = !DILocation(line: 283, column: 33, scope: !276)
!303 = !DILocation(line: 283, column: 15, scope: !276)
!304 = !DILocation(line: 283, column: 14, scope: !276)
!305 = !DILocation(line: 284, column: 28, scope: !276)
!306 = !DILocation(line: 284, column: 18, scope: !276)
!307 = !DILocation(line: 284, column: 33, scope: !276)
!308 = !DILocation(line: 284, column: 15, scope: !276)
!309 = !DILocation(line: 284, column: 14, scope: !276)
!310 = !DILocation(line: 285, column: 17, scope: !276)
!311 = !DILocation(line: 285, column: 15, scope: !276)
!312 = !DILocation(line: 285, column: 14, scope: !276)
!313 = !DILocation(line: 286, column: 28, scope: !276)
!314 = !DILocation(line: 286, column: 18, scope: !276)
!315 = !DILocation(line: 286, column: 33, scope: !276)
!316 = !DILocation(line: 286, column: 15, scope: !276)
!317 = !DILocation(line: 286, column: 14, scope: !276)
!318 = !DILocation(line: 134, column: 9, scope: !21)
!319 = !DILocation(line: 287, column: 28, scope: !276)
!320 = !DILocation(line: 287, column: 18, scope: !276)
!321 = !DILocation(line: 287, column: 33, scope: !276)
!322 = !DILocation(line: 287, column: 15, scope: !276)
!323 = !DILocation(line: 287, column: 14, scope: !276)
!324 = !DILocation(line: 288, column: 28, scope: !276)
!325 = !DILocation(line: 288, column: 18, scope: !276)
!326 = !DILocation(line: 288, column: 33, scope: !276)
!327 = !DILocation(line: 288, column: 15, scope: !276)
!328 = !DILocation(line: 288, column: 14, scope: !276)
!329 = !DILocation(line: 289, column: 17, scope: !276)
!330 = !DILocation(line: 289, column: 15, scope: !276)
!331 = !DILocation(line: 134, column: 5, scope: !21)
!332 = !DILocation(line: 295, column: 3, scope: !333)
!333 = distinct !DILexicalBlock(scope: !21, file: !1, line: 295, column: 3)
!334 = !DILocation(line: 296, column: 3, scope: !21)
!335 = !DILocation(line: 297, column: 1, scope: !21)
