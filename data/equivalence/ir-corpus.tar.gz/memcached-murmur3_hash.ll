; ModuleID = 'murmur3_hash.c'
source_filename = "murmur3_hash.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nofree norecurse nosync nounwind sanitize_thread memory(argmem: read) uwtable
define dso_local i32 @MurmurHash3_x86_32(ptr nocapture noundef readonly %key, i64 noundef %length) local_unnamed_addr #0 !dbg !23 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !32, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata i64 %length, metadata !33, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !34, metadata !DIExpression()), !dbg !49
  %div55 = lshr i64 %length, 2, !dbg !50
  %conv = trunc i64 %div55 to i32, !dbg !51
  tail call void @llvm.dbg.value(metadata i32 %conv, metadata !35, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata i32 0, metadata !38, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata i32 -862048943, metadata !39, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata i32 461845907, metadata !40, metadata !DIExpression()), !dbg !49
  %mul = shl nsw i32 %conv, 2, !dbg !52
  %idx.ext = sext i32 %mul to i64, !dbg !53
  %add.ptr = getelementptr inbounds i8, ptr %key, i64 %idx.ext, !dbg !53
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !41, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 0, i32 %conv), metadata !42, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !54
  tail call void @llvm.dbg.value(metadata i32 0, metadata !38, metadata !DIExpression()), !dbg !49
  %tobool.not63 = icmp eq i32 %conv, 0, !dbg !55
  br i1 %tobool.not63, label %for.cond.cleanup, label %for.body.preheader, !dbg !55

for.body.preheader:                               ; preds = %entry
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 0, i32 %conv), metadata !42, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !54
  %.neg = mul i64 %div55, -4294967296, !dbg !55
  %0 = ashr exact i64 %.neg, 32, !dbg !55
  %1 = trunc nsw i64 %0 to i32, !dbg !55
  %2 = sub i32 0, %1, !dbg !55
  %xtraiter = and i32 %2, 1, !dbg !55
  %3 = icmp eq i32 %1, -1, !dbg !55
  br i1 %3, label %for.cond.cleanup.loopexit.unr-lcssa, label %for.body.preheader.new, !dbg !55

for.body.preheader.new:                           ; preds = %for.body.preheader
  %unroll_iter = and i32 %2, -2, !dbg !55
  %invariant.gep = getelementptr i8, ptr %add.ptr, i64 4, !dbg !55
  br label %for.body, !dbg !55

for.cond.cleanup.loopexit.unr-lcssa:              ; preds = %for.body, %for.body.preheader
  %add.lcssa.ph = phi i32 [ undef, %for.body.preheader ], [ %add.1, %for.body ]
  %indvars.iv.unr = phi i64 [ %0, %for.body.preheader ], [ %indvars.iv.next.1, %for.body ]
  %h1.065.unr = phi i32 [ 0, %for.body.preheader ], [ %add.1, %for.body ]
  %lcmp.mod.not = icmp eq i32 %xtraiter, 0, !dbg !55
  br i1 %lcmp.mod.not, label %for.cond.cleanup, label %for.body.epil, !dbg !55

for.body.epil:                                    ; preds = %for.cond.cleanup.loopexit.unr-lcssa
  tail call void @llvm.dbg.value(metadata i32 %h1.065.unr, metadata !38, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.unr, metadata !42, metadata !DIExpression()), !dbg !54
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !56, metadata !DIExpression()), !dbg !62
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.unr, metadata !61, metadata !DIExpression()), !dbg !62
  %arrayidx.i.epil = getelementptr inbounds i32, ptr %add.ptr, i64 %indvars.iv.unr, !dbg !64
  %4 = load i32, ptr %arrayidx.i.epil, align 4, !dbg !64, !tbaa !65
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !44, metadata !DIExpression()), !dbg !69
  %mul1.epil = mul i32 %4, -862048943, !dbg !70
  tail call void @llvm.dbg.value(metadata i32 %mul1.epil, metadata !44, metadata !DIExpression()), !dbg !69
  tail call void @llvm.dbg.value(metadata i32 %mul1.epil, metadata !71, metadata !DIExpression()), !dbg !81
  tail call void @llvm.dbg.value(metadata i8 15, metadata !80, metadata !DIExpression()), !dbg !81
  %shl.i.epil = mul i32 %4, 380141568, !dbg !83
  %shr.i56.epil = lshr i32 %mul1.epil, 17, !dbg !84
  %or.i.epil = or disjoint i32 %shr.i56.epil, %shl.i.epil, !dbg !85
  tail call void @llvm.dbg.value(metadata i32 %or.i.epil, metadata !44, metadata !DIExpression()), !dbg !69
  %mul3.epil = mul i32 %or.i.epil, 461845907, !dbg !86
  tail call void @llvm.dbg.value(metadata i32 %mul3.epil, metadata !44, metadata !DIExpression()), !dbg !69
  %xor.epil = xor i32 %mul3.epil, %h1.065.unr, !dbg !87
  tail call void @llvm.dbg.value(metadata i32 %xor.epil, metadata !38, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata i32 %xor.epil, metadata !71, metadata !DIExpression()), !dbg !88
  tail call void @llvm.dbg.value(metadata i8 13, metadata !80, metadata !DIExpression()), !dbg !88
  %or.i59.epil = tail call i32 @llvm.fshl.i32(i32 %xor.epil, i32 %xor.epil, i32 13), !dbg !90
  tail call void @llvm.dbg.value(metadata i32 %or.i59.epil, metadata !38, metadata !DIExpression()), !dbg !49
  %mul5.epil = mul i32 %or.i59.epil, 5, !dbg !91
  %add.epil = add i32 %mul5.epil, -430675100, !dbg !92
  tail call void @llvm.dbg.value(metadata i32 %add.epil, metadata !38, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.unr, metadata !42, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !54
  br label %for.cond.cleanup, !dbg !93

for.cond.cleanup:                                 ; preds = %for.body.epil, %for.cond.cleanup.loopexit.unr-lcssa, %entry
  %h1.0.lcssa = phi i32 [ 0, %entry ], [ %add.lcssa.ph, %for.cond.cleanup.loopexit.unr-lcssa ], [ %add.epil, %for.body.epil ], !dbg !49
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !47, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata i32 0, metadata !48, metadata !DIExpression()), !dbg !49
  %and = and i64 %length, 3, !dbg !93
  switch i64 %and, label %sw.epilog [
    i64 3, label %sw.bb
    i64 2, label %sw.bb12
    i64 1, label %sw.bb17
  ], !dbg !94

for.body:                                         ; preds = %for.body, %for.body.preheader.new
  %indvars.iv = phi i64 [ %0, %for.body.preheader.new ], [ %indvars.iv.next.1, %for.body ]
  %h1.065 = phi i32 [ 0, %for.body.preheader.new ], [ %add.1, %for.body ]
  %niter = phi i32 [ 0, %for.body.preheader.new ], [ %niter.next.1, %for.body ]
  tail call void @llvm.dbg.value(metadata i32 %h1.065, metadata !38, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !42, metadata !DIExpression()), !dbg !54
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !56, metadata !DIExpression()), !dbg !62
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !61, metadata !DIExpression()), !dbg !62
  %arrayidx.i = getelementptr inbounds i32, ptr %add.ptr, i64 %indvars.iv, !dbg !64
  %5 = load i32, ptr %arrayidx.i, align 4, !dbg !64, !tbaa !65
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !44, metadata !DIExpression()), !dbg !69
  %mul1 = mul i32 %5, -862048943, !dbg !70
  tail call void @llvm.dbg.value(metadata i32 %mul1, metadata !44, metadata !DIExpression()), !dbg !69
  tail call void @llvm.dbg.value(metadata i32 %mul1, metadata !71, metadata !DIExpression()), !dbg !81
  tail call void @llvm.dbg.value(metadata i8 15, metadata !80, metadata !DIExpression()), !dbg !81
  %shl.i = mul i32 %5, 380141568, !dbg !83
  %shr.i56 = lshr i32 %mul1, 17, !dbg !84
  %or.i = or disjoint i32 %shr.i56, %shl.i, !dbg !85
  tail call void @llvm.dbg.value(metadata i32 %or.i, metadata !44, metadata !DIExpression()), !dbg !69
  %mul3 = mul i32 %or.i, 461845907, !dbg !86
  tail call void @llvm.dbg.value(metadata i32 %mul3, metadata !44, metadata !DIExpression()), !dbg !69
  %xor = xor i32 %mul3, %h1.065, !dbg !87
  tail call void @llvm.dbg.value(metadata i32 %xor, metadata !38, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata i32 %xor, metadata !71, metadata !DIExpression()), !dbg !88
  tail call void @llvm.dbg.value(metadata i8 13, metadata !80, metadata !DIExpression()), !dbg !88
  %or.i59 = tail call i32 @llvm.fshl.i32(i32 %xor, i32 %xor, i32 13), !dbg !90
  tail call void @llvm.dbg.value(metadata i32 %or.i59, metadata !38, metadata !DIExpression()), !dbg !49
  %mul5 = mul i32 %or.i59, 5, !dbg !91
  %add = add i32 %mul5, -430675100, !dbg !92
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !38, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !42, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !54
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !38, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !42, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !54
  tail call void @llvm.dbg.value(metadata ptr %add.ptr, metadata !56, metadata !DIExpression()), !dbg !62
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !61, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !62
  %gep = getelementptr i32, ptr %invariant.gep, i64 %indvars.iv, !dbg !64
  %6 = load i32, ptr %gep, align 4, !dbg !64, !tbaa !65
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !44, metadata !DIExpression()), !dbg !69
  %mul1.1 = mul i32 %6, -862048943, !dbg !70
  tail call void @llvm.dbg.value(metadata i32 %mul1.1, metadata !44, metadata !DIExpression()), !dbg !69
  tail call void @llvm.dbg.value(metadata i32 %mul1.1, metadata !71, metadata !DIExpression()), !dbg !81
  tail call void @llvm.dbg.value(metadata i8 15, metadata !80, metadata !DIExpression()), !dbg !81
  %shl.i.1 = mul i32 %6, 380141568, !dbg !83
  %shr.i56.1 = lshr i32 %mul1.1, 17, !dbg !84
  %or.i.1 = or disjoint i32 %shr.i56.1, %shl.i.1, !dbg !85
  tail call void @llvm.dbg.value(metadata i32 %or.i.1, metadata !44, metadata !DIExpression()), !dbg !69
  %mul3.1 = mul i32 %or.i.1, 461845907, !dbg !86
  tail call void @llvm.dbg.value(metadata i32 %mul3.1, metadata !44, metadata !DIExpression()), !dbg !69
  %xor.1 = xor i32 %mul3.1, %add, !dbg !87
  tail call void @llvm.dbg.value(metadata i32 %xor.1, metadata !38, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata i32 %xor.1, metadata !71, metadata !DIExpression()), !dbg !88
  tail call void @llvm.dbg.value(metadata i8 13, metadata !80, metadata !DIExpression()), !dbg !88
  %or.i59.1 = tail call i32 @llvm.fshl.i32(i32 %xor.1, i32 %xor.1, i32 13), !dbg !90
  tail call void @llvm.dbg.value(metadata i32 %or.i59.1, metadata !38, metadata !DIExpression()), !dbg !49
  %mul5.1 = mul i32 %or.i59.1, 5, !dbg !91
  %add.1 = add i32 %mul5.1, -430675100, !dbg !92
  tail call void @llvm.dbg.value(metadata i32 %add.1, metadata !38, metadata !DIExpression()), !dbg !49
  %indvars.iv.next.1 = add nsw i64 %indvars.iv, 2, !dbg !95
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.1, metadata !42, metadata !DIExpression()), !dbg !54
  %niter.next.1 = add i32 %niter, 2, !dbg !55
  %niter.ncmp.1 = icmp eq i32 %niter.next.1, %unroll_iter, !dbg !55
  br i1 %niter.ncmp.1, label %for.cond.cleanup.loopexit.unr-lcssa, label %for.body, !dbg !55, !llvm.loop !96

sw.bb:                                            ; preds = %for.cond.cleanup
  %arrayidx = getelementptr inbounds i8, ptr %add.ptr, i64 2, !dbg !99
  %7 = load i8, ptr %arrayidx, align 1, !dbg !99, !tbaa !101
  %conv10 = zext i8 %7 to i32, !dbg !99
  %shl = shl nuw nsw i32 %conv10, 16, !dbg !102
  tail call void @llvm.dbg.value(metadata i32 %shl, metadata !48, metadata !DIExpression()), !dbg !49
  br label %sw.bb12, !dbg !103

sw.bb12:                                          ; preds = %for.cond.cleanup, %sw.bb
  %k19.0 = phi i32 [ 0, %for.cond.cleanup ], [ %shl, %sw.bb ], !dbg !49
  tail call void @llvm.dbg.value(metadata i32 %k19.0, metadata !48, metadata !DIExpression()), !dbg !49
  %arrayidx13 = getelementptr inbounds i8, ptr %add.ptr, i64 1, !dbg !104
  %8 = load i8, ptr %arrayidx13, align 1, !dbg !104, !tbaa !101
  %conv14 = zext i8 %8 to i32, !dbg !104
  %shl15 = shl nuw nsw i32 %conv14, 8, !dbg !105
  %xor16 = or disjoint i32 %shl15, %k19.0, !dbg !106
  tail call void @llvm.dbg.value(metadata i32 %xor16, metadata !48, metadata !DIExpression()), !dbg !49
  br label %sw.bb17, !dbg !107

sw.bb17:                                          ; preds = %for.cond.cleanup, %sw.bb12
  %k19.1 = phi i32 [ 0, %for.cond.cleanup ], [ %xor16, %sw.bb12 ], !dbg !49
  tail call void @llvm.dbg.value(metadata i32 %k19.1, metadata !48, metadata !DIExpression()), !dbg !49
  %9 = load i8, ptr %add.ptr, align 1, !dbg !108, !tbaa !101
  %conv19 = zext i8 %9 to i32, !dbg !108
  %xor20 = xor i32 %k19.1, %conv19, !dbg !109
  tail call void @llvm.dbg.value(metadata i32 %xor20, metadata !48, metadata !DIExpression()), !dbg !49
  %mul21 = mul i32 %xor20, -862048943, !dbg !110
  tail call void @llvm.dbg.value(metadata i32 %mul21, metadata !48, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata i32 %mul21, metadata !71, metadata !DIExpression()), !dbg !111
  tail call void @llvm.dbg.value(metadata i8 15, metadata !80, metadata !DIExpression()), !dbg !111
  %shl.i60 = mul i32 %xor20, 380141568, !dbg !113
  %shr.i61 = lshr i32 %mul21, 17, !dbg !114
  %or.i62 = or disjoint i32 %shr.i61, %shl.i60, !dbg !115
  tail call void @llvm.dbg.value(metadata i32 %or.i62, metadata !48, metadata !DIExpression()), !dbg !49
  %mul23 = mul i32 %or.i62, 461845907, !dbg !116
  tail call void @llvm.dbg.value(metadata i32 %mul23, metadata !48, metadata !DIExpression()), !dbg !49
  %xor24 = xor i32 %mul23, %h1.0.lcssa, !dbg !117
  tail call void @llvm.dbg.value(metadata i32 %xor24, metadata !38, metadata !DIExpression()), !dbg !49
  br label %sw.epilog, !dbg !118

sw.epilog:                                        ; preds = %sw.bb17, %for.cond.cleanup
  %h1.1 = phi i32 [ %h1.0.lcssa, %for.cond.cleanup ], [ %xor24, %sw.bb17 ], !dbg !49
  tail call void @llvm.dbg.value(metadata i32 %h1.1, metadata !38, metadata !DIExpression()), !dbg !49
  %10 = trunc i64 %length to i32, !dbg !119
  %conv27 = xor i32 %h1.1, %10, !dbg !119
  tail call void @llvm.dbg.value(metadata i32 %conv27, metadata !38, metadata !DIExpression()), !dbg !49
  tail call void @llvm.dbg.value(metadata i32 %conv27, metadata !120, metadata !DIExpression()), !dbg !125
  %shr.i = lshr i32 %conv27, 16, !dbg !127
  %xor.i = xor i32 %shr.i, %conv27, !dbg !128
  tail call void @llvm.dbg.value(metadata i32 %xor.i, metadata !120, metadata !DIExpression()), !dbg !125
  %mul.i = mul i32 %xor.i, -2048144789, !dbg !129
  tail call void @llvm.dbg.value(metadata i32 %mul.i, metadata !120, metadata !DIExpression()), !dbg !125
  %shr1.i = lshr i32 %mul.i, 13, !dbg !130
  %xor2.i = xor i32 %shr1.i, %mul.i, !dbg !131
  tail call void @llvm.dbg.value(metadata i32 %xor2.i, metadata !120, metadata !DIExpression()), !dbg !125
  %mul3.i = mul i32 %xor2.i, -1028477387, !dbg !132
  tail call void @llvm.dbg.value(metadata i32 %mul3.i, metadata !120, metadata !DIExpression()), !dbg !125
  %shr4.i = lshr i32 %mul3.i, 16, !dbg !133
  %xor5.i = xor i32 %shr4.i, %mul3.i, !dbg !134
  tail call void @llvm.dbg.value(metadata i32 %xor5.i, metadata !120, metadata !DIExpression()), !dbg !125
  tail call void @llvm.dbg.value(metadata i32 %xor5.i, metadata !38, metadata !DIExpression()), !dbg !49
  ret i32 %xor5.i, !dbg !135
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fshl.i32(i32, i32, i32) #1

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #2 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { nofree norecurse nosync nounwind sanitize_thread memory(argmem: read) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nounwind uwtable }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!15, !16, !17, !18, !19, !20, !21}
!llvm.ident = !{!22}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !2, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "murmur3_hash.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "1fa6e622a1efeb68aa8d03d3840e4815")
!2 = !{!3, !10}
!3 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !4, size: 64)
!4 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !5)
!5 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !6, line: 24, baseType: !7)
!6 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!7 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !8, line: 38, baseType: !9)
!8 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!9 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!10 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64)
!11 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !12)
!12 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !6, line: 26, baseType: !13)
!13 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !8, line: 42, baseType: !14)
!14 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!15 = !{i32 7, !"Dwarf Version", i32 5}
!16 = !{i32 2, !"Debug Info Version", i32 3}
!17 = !{i32 1, !"wchar_size", i32 4}
!18 = !{i32 8, !"PIC Level", i32 2}
!19 = !{i32 7, !"PIE Level", i32 2}
!20 = !{i32 7, !"uwtable", i32 2}
!21 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!22 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!23 = distinct !DISubprogram(name: "MurmurHash3_x86_32", scope: !1, file: !1, line: 71, type: !24, scopeLine: 72, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !31)
!24 = !DISubroutineType(types: !25)
!25 = !{!12, !26, !28}
!26 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !27, size: 64)
!27 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!28 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !29, line: 18, baseType: !30)
!29 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!30 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!31 = !{!32, !33, !34, !35, !38, !39, !40, !41, !42, !44, !47, !48}
!32 = !DILocalVariable(name: "key", arg: 1, scope: !23, file: !1, line: 71, type: !26)
!33 = !DILocalVariable(name: "length", arg: 2, scope: !23, file: !1, line: 71, type: !28)
!34 = !DILocalVariable(name: "data", scope: !23, file: !1, line: 73, type: !3)
!35 = !DILocalVariable(name: "nblocks", scope: !23, file: !1, line: 74, type: !36)
!36 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !37)
!37 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!38 = !DILocalVariable(name: "h1", scope: !23, file: !1, line: 76, type: !12)
!39 = !DILocalVariable(name: "c1", scope: !23, file: !1, line: 78, type: !12)
!40 = !DILocalVariable(name: "c2", scope: !23, file: !1, line: 79, type: !12)
!41 = !DILocalVariable(name: "blocks", scope: !23, file: !1, line: 84, type: !10)
!42 = !DILocalVariable(name: "i", scope: !43, file: !1, line: 86, type: !37)
!43 = distinct !DILexicalBlock(scope: !23, file: !1, line: 86, column: 3)
!44 = !DILocalVariable(name: "k1", scope: !45, file: !1, line: 88, type: !12)
!45 = distinct !DILexicalBlock(scope: !46, file: !1, line: 87, column: 3)
!46 = distinct !DILexicalBlock(scope: !43, file: !1, line: 86, column: 3)
!47 = !DILocalVariable(name: "tail", scope: !23, file: !1, line: 102, type: !3)
!48 = !DILocalVariable(name: "k1", scope: !23, file: !1, line: 104, type: !12)
!49 = !DILocation(line: 0, scope: !23)
!50 = !DILocation(line: 74, column: 30, scope: !23)
!51 = !DILocation(line: 74, column: 23, scope: !23)
!52 = !DILocation(line: 84, column: 62, scope: !23)
!53 = !DILocation(line: 84, column: 53, scope: !23)
!54 = !DILocation(line: 0, scope: !43)
!55 = !DILocation(line: 86, column: 3, scope: !43)
!56 = !DILocalVariable(name: "p", arg: 1, scope: !57, file: !1, line: 48, type: !10)
!57 = distinct !DISubprogram(name: "getblock32", scope: !1, file: !1, line: 48, type: !58, scopeLine: 49, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !60)
!58 = !DISubroutineType(types: !59)
!59 = !{!12, !10, !37}
!60 = !{!56, !61}
!61 = !DILocalVariable(name: "i", arg: 2, scope: !57, file: !1, line: 48, type: !37)
!62 = !DILocation(line: 0, scope: !57, inlinedAt: !63)
!63 = distinct !DILocation(line: 88, column: 19, scope: !45)
!64 = !DILocation(line: 50, column: 10, scope: !57, inlinedAt: !63)
!65 = !{!66, !66, i64 0}
!66 = !{!"int", !67, i64 0}
!67 = !{!"omnipotent char", !68, i64 0}
!68 = !{!"Simple C/C++ TBAA"}
!69 = !DILocation(line: 0, scope: !45)
!70 = !DILocation(line: 90, column: 8, scope: !45)
!71 = !DILocalVariable(name: "x", arg: 1, scope: !72, file: !1, line: 33, type: !12)
!72 = distinct !DISubprogram(name: "rotl32", scope: !1, file: !1, line: 33, type: !73, scopeLine: 34, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !79)
!73 = !DISubroutineType(types: !74)
!74 = !{!12, !12, !75}
!75 = !DIDerivedType(tag: DW_TAG_typedef, name: "int8_t", file: !76, line: 24, baseType: !77)
!76 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h", directory: "", checksumkind: CSK_MD5, checksum: "649b383a60bfa3eb90e85840b2b0be20")
!77 = !DIDerivedType(tag: DW_TAG_typedef, name: "__int8_t", file: !8, line: 37, baseType: !78)
!78 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!79 = !{!71, !80}
!80 = !DILocalVariable(name: "r", arg: 2, scope: !72, file: !1, line: 33, type: !75)
!81 = !DILocation(line: 0, scope: !72, inlinedAt: !82)
!82 = distinct !DILocation(line: 91, column: 10, scope: !45)
!83 = !DILocation(line: 35, column: 13, scope: !72, inlinedAt: !82)
!84 = !DILocation(line: 35, column: 24, scope: !72, inlinedAt: !82)
!85 = !DILocation(line: 35, column: 19, scope: !72, inlinedAt: !82)
!86 = !DILocation(line: 92, column: 8, scope: !45)
!87 = !DILocation(line: 94, column: 8, scope: !45)
!88 = !DILocation(line: 0, scope: !72, inlinedAt: !89)
!89 = distinct !DILocation(line: 95, column: 10, scope: !45)
!90 = !DILocation(line: 35, column: 19, scope: !72, inlinedAt: !89)
!91 = !DILocation(line: 96, column: 12, scope: !45)
!92 = !DILocation(line: 96, column: 14, scope: !45)
!93 = !DILocation(line: 106, column: 17, scope: !23)
!94 = !DILocation(line: 106, column: 3, scope: !23)
!95 = !DILocation(line: 86, column: 29, scope: !46)
!96 = distinct !{!96, !55, !97, !98}
!97 = !DILocation(line: 97, column: 3, scope: !43)
!98 = !{!"llvm.loop.mustprogress"}
!99 = !DILocation(line: 108, column: 17, scope: !100)
!100 = distinct !DILexicalBlock(scope: !23, file: !1, line: 107, column: 3)
!101 = !{!67, !67, i64 0}
!102 = !DILocation(line: 108, column: 25, scope: !100)
!103 = !DILocation(line: 108, column: 11, scope: !100)
!104 = !DILocation(line: 109, column: 17, scope: !100)
!105 = !DILocation(line: 109, column: 25, scope: !100)
!106 = !DILocation(line: 109, column: 14, scope: !100)
!107 = !DILocation(line: 109, column: 11, scope: !100)
!108 = !DILocation(line: 110, column: 17, scope: !100)
!109 = !DILocation(line: 110, column: 14, scope: !100)
!110 = !DILocation(line: 111, column: 14, scope: !100)
!111 = !DILocation(line: 0, scope: !72, inlinedAt: !112)
!112 = distinct !DILocation(line: 111, column: 26, scope: !100)
!113 = !DILocation(line: 35, column: 13, scope: !72, inlinedAt: !112)
!114 = !DILocation(line: 35, column: 24, scope: !72, inlinedAt: !112)
!115 = !DILocation(line: 35, column: 19, scope: !72, inlinedAt: !112)
!116 = !DILocation(line: 111, column: 44, scope: !100)
!117 = !DILocation(line: 111, column: 54, scope: !100)
!118 = !DILocation(line: 112, column: 3, scope: !100)
!119 = !DILocation(line: 117, column: 6, scope: !23)
!120 = !DILocalVariable(name: "h", arg: 1, scope: !121, file: !1, line: 56, type: !12)
!121 = distinct !DISubprogram(name: "fmix32", scope: !1, file: !1, line: 56, type: !122, scopeLine: 57, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !124)
!122 = !DISubroutineType(types: !123)
!123 = !{!12, !12}
!124 = !{!120}
!125 = !DILocation(line: 0, scope: !121, inlinedAt: !126)
!126 = distinct !DILocation(line: 119, column: 8, scope: !23)
!127 = !DILocation(line: 58, column: 10, scope: !121, inlinedAt: !126)
!128 = !DILocation(line: 58, column: 5, scope: !121, inlinedAt: !126)
!129 = !DILocation(line: 59, column: 5, scope: !121, inlinedAt: !126)
!130 = !DILocation(line: 60, column: 10, scope: !121, inlinedAt: !126)
!131 = !DILocation(line: 60, column: 5, scope: !121, inlinedAt: !126)
!132 = !DILocation(line: 61, column: 5, scope: !121, inlinedAt: !126)
!133 = !DILocation(line: 62, column: 10, scope: !121, inlinedAt: !126)
!134 = !DILocation(line: 62, column: 5, scope: !121, inlinedAt: !126)
!135 = !DILocation(line: 122, column: 3, scope: !23)
