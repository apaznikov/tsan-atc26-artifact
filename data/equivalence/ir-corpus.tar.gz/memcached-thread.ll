; ModuleID = 'thread.c'
source_filename = "thread.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%union.pthread_mutex_t = type { %struct.__pthread_mutex_s }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i16, i16, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%struct.settings = type { i64, i32, i32, i32, ptr, i32, i32, i32, ptr, ptr, i32, double, i32, i32, i32, i8, i32, i32, i8, i32, i32, i32, i32, i32, i32, i8, i8, i8, i8, i8, i8, i32, double, i32, i32, i8, i32, i8, i8, ptr, i32, i32, i32, i32, double, double, i32, i8, i32, i32, i32, i32, i32, i8, i8, i8, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, double, double, i8, i32, i32, ptr, i32 }
%union.pthread_cond_t = type { %struct.__pthread_cond_s }
%struct.__pthread_cond_s = type { %union.__atomic_wide_counter, %union.__atomic_wide_counter, [2 x i32], [2 x i32], i32, i32, [2 x i32] }
%union.__atomic_wide_counter = type { i64 }
%struct.stats_state = type { i64, i64, i64, i64, i32, i32, i32, i32, i8, i8, i8, i8 }
%struct.stats = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, %struct.timeval, i64, i64 }
%struct.timeval = type { i64, i64 }
%struct.LIBEVENT_THREAD = type { i64, ptr, %struct.thread_notify, %struct.thread_notify, %union.pthread_mutex_t, %struct.iop_head_s, i32, i32, %struct.thread_stats, [3 x %struct.io_queue_cb_s], ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32 }
%struct.thread_notify = type { %struct.event, i32 }
%struct.event = type { %struct.event_callback, %union.anon.0, i32, ptr, %union.anon.2, i16, i16, %struct.timeval }
%struct.event_callback = type { %struct.anon, i16, i8, i8, %union.anon, ptr }
%struct.anon = type { ptr, ptr }
%union.anon = type { ptr }
%union.anon.0 = type { %struct.anon.1 }
%struct.anon.1 = type { ptr, ptr }
%union.anon.2 = type { %struct.anon.3 }
%struct.anon.3 = type { %struct.anon.4, %struct.timeval }
%struct.anon.4 = type { ptr, ptr }
%struct.iop_head_s = type { ptr, ptr }
%struct.thread_stats = type { %union.pthread_mutex_t, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, [64 x %struct.slab_stats], [256 x i64], i64, i64, i64 }
%struct.slab_stats = type { i64, i64, i64, i64, i64, i64, i64, i64 }
%struct.io_queue_cb_s = type { ptr, ptr, i32 }
%union.pthread_attr_t = type { i64, [48 x i8] }

@conn_lock = dso_local global %union.pthread_mutex_t zeroinitializer, align 8, !dbg !0
@item_locks = internal unnamed_addr global ptr null, align 8, !dbg !801
@item_lock_hashpower = internal unnamed_addr global i32 0, align 4, !dbg !805
@worker_hang_lock = internal global %union.pthread_mutex_t zeroinitializer, align 8, !dbg !799
@stderr = external local_unnamed_addr global ptr, align 8
@.str = private unnamed_addr constant [23 x i8] c"Unknown lock type: %d\0A\00", align 1, !dbg !710
@init_lock = internal global %union.pthread_mutex_t zeroinitializer, align 8, !dbg !809
@init_count = internal unnamed_addr global i32 0, align 4, !dbg !846
@settings = external local_unnamed_addr global %struct.settings, align 8
@threads = internal unnamed_addr global ptr null, align 8, !dbg !807
@.str.1 = private unnamed_addr constant [15 x i8] c"stopped assoc\0A\00", align 1, !dbg !715
@.str.2 = private unnamed_addr constant [24 x i8] c"asking workers to stop\0A\00", align 1, !dbg !720
@.str.3 = private unnamed_addr constant [35 x i8] c"asking background threads to stop\0A\00", align 1, !dbg !723
@.str.4 = private unnamed_addr constant [21 x i8] c"stopped lru crawler\0A\00", align 1, !dbg !728
@.str.5 = private unnamed_addr constant [20 x i8] c"stopped maintainer\0A\00", align 1, !dbg !733
@.str.6 = private unnamed_addr constant [20 x i8] c"stopped slab mover\0A\00", align 1, !dbg !738
@.str.7 = private unnamed_addr constant [23 x i8] c"stopped logger thread\0A\00", align 1, !dbg !740
@.str.8 = private unnamed_addr constant [29 x i8] c"stopped idle timeout thread\0A\00", align 1, !dbg !742
@.str.9 = private unnamed_addr constant [21 x i8] c"closing connections\0A\00", align 1, !dbg !747
@.str.10 = private unnamed_addr constant [24 x i8] c"reaping worker threads\0A\00", align 1, !dbg !749
@.str.11 = private unnamed_addr constant [32 x i8] c"all background threads stopped\0A\00", align 1, !dbg !751
@.str.12 = private unnamed_addr constant [49 x i8] c"Failed to allocate memory for connection object\0A\00", align 1, !dbg !756
@.str.13 = private unnamed_addr constant [33 x i8] c"failed writing to worker eventfd\00", align 1, !dbg !761
@.str.14 = private unnamed_addr constant [42 x i8] c"<%d connection closing from side thread.\0A\00", align 1, !dbg !766
@hash = external local_unnamed_addr global ptr, align 8
@stats_lock = internal global %union.pthread_mutex_t zeroinitializer, align 8, !dbg !852
@lru_locks = dso_local global [256 x %union.pthread_mutex_t] zeroinitializer, align 16, !dbg !796
@init_cond = internal global %union.pthread_cond_t zeroinitializer, align 8, !dbg !811
@hashpower = external local_unnamed_addr global i32, align 4
@.str.15 = private unnamed_addr constant [81 x i8] c"Hash table power size (%d) cannot be equal to or less than item lock table (%d)\0A\00", align 1, !dbg !771
@.str.16 = private unnamed_addr constant [56 x i8] c"Item lock table grows with `-t N` (worker threadcount)\0A\00", align 1, !dbg !776
@.str.17 = private unnamed_addr constant [41 x i8] c"Hash table grows with `-o hashpower=N` \0A\00", align 1, !dbg !781
@item_lock_count = internal unnamed_addr global i32 0, align 4, !dbg !803
@.str.18 = private unnamed_addr constant [26 x i8] c"Can't allocate item locks\00", align 1, !dbg !786
@.str.19 = private unnamed_addr constant [34 x i8] c"Can't allocate thread descriptors\00", align 1, !dbg !791
@stats_state = external local_unnamed_addr global %struct.stats_state, align 8
@last_thread = internal unnamed_addr global i32 -1, align 4, !dbg !848
@stats = external local_unnamed_addr global %struct.stats, align 8
@last_thread_by_napi_id = internal unnamed_addr global i32 -1, align 4, !dbg !850
@.str.20 = private unnamed_addr constant [42 x i8] c"failed creating eventfd for worker thread\00", align 1, !dbg !854
@.str.21 = private unnamed_addr constant [27 x i8] c"Can't allocate event base\0A\00", align 1, !dbg !856
@.str.22 = private unnamed_addr constant [47 x i8] c"Failed to allocate memory for connection queue\00", align 1, !dbg !861
@.str.23 = private unnamed_addr constant [27 x i8] c"Failed to initialize mutex\00", align 1, !dbg !866
@.str.24 = private unnamed_addr constant [5 x i8] c"rbuf\00", align 1, !dbg !868
@.str.25 = private unnamed_addr constant [36 x i8] c"Failed to create read buffer cache\0A\00", align 1, !dbg !873
@.str.26 = private unnamed_addr constant [3 x i8] c"io\00", align 1, !dbg !878
@.str.27 = private unnamed_addr constant [34 x i8] c"Failed to create IO object cache\0A\00", align 1, !dbg !881
@.str.28 = private unnamed_addr constant [36 x i8] c"Can't monitor libevent notify pipe\0A\00", align 1, !dbg !883
@.str.29 = private unnamed_addr constant [31 x i8] c"Can't read from libevent pipe\0A\00", align 1, !dbg !885
@.str.30 = private unnamed_addr constant [39 x i8] c"Can't listen for events on UDP socket\0A\00", align 1, !dbg !890
@.str.31 = private unnamed_addr constant [34 x i8] c"Can't listen for events on fd %d\0A\00", align 1, !dbg !895
@conns = external local_unnamed_addr global ptr, align 8
@.str.32 = private unnamed_addr constant [3 x i8] c"cq\00", align 1, !dbg !897
@.str.33 = private unnamed_addr constant [41 x i8] c"Failed to create connection queue cache\0A\00", align 1, !dbg !899
@.str.34 = private unnamed_addr constant [25 x i8] c"Can't create thread: %s\0A\00", align 1, !dbg !901
@.str.35 = private unnamed_addr constant [10 x i8] c"mc-worker\00", align 1, !dbg !906
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @item_lock(i32 noundef %hv) local_unnamed_addr #0 !dbg !919 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !923, metadata !DIExpression()), !dbg !924
  %0 = load ptr, ptr @item_locks, align 8, !dbg !925, !tbaa !926
  %conv = zext i32 %hv to i64, !dbg !925
  %1 = load i32, ptr @item_lock_hashpower, align 4, !dbg !925, !tbaa !930
  %sh_prom = zext nneg i32 %1 to i64, !dbg !925
  %notmask = shl nsw i64 -1, %sh_prom, !dbg !925
  %sub = xor i64 %notmask, -1, !dbg !925
  %and = and i64 %sub, %conv, !dbg !925
  %arrayidx = getelementptr inbounds %union.pthread_mutex_t, ptr %0, i64 %and, !dbg !925
  %call = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx) #16, !dbg !925
  ret void, !dbg !932
}

; Function Attrs: nounwind
declare !dbg !933 i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #1

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local ptr @item_trylock(i32 noundef %hv) local_unnamed_addr #0 !dbg !937 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !941, metadata !DIExpression()), !dbg !943
  %0 = load ptr, ptr @item_locks, align 8, !dbg !944, !tbaa !926
  %conv = zext i32 %hv to i64, !dbg !945
  %1 = load i32, ptr @item_lock_hashpower, align 4, !dbg !946, !tbaa !930
  %sh_prom = zext nneg i32 %1 to i64, !dbg !946
  %notmask = shl nsw i64 -1, %sh_prom, !dbg !946
  %sub = xor i64 %notmask, -1, !dbg !946
  %and = and i64 %sub, %conv, !dbg !947
  %arrayidx = getelementptr inbounds %union.pthread_mutex_t, ptr %0, i64 %and, !dbg !944
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !942, metadata !DIExpression()), !dbg !943
  %call = tail call i32 @pthread_mutex_trylock(ptr noundef %arrayidx) #16, !dbg !948
  %cmp = icmp eq i32 %call, 0, !dbg !950
  %arrayidx. = select i1 %cmp, ptr %arrayidx, ptr null, !dbg !943
  ret ptr %arrayidx., !dbg !951
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: nounwind
declare !dbg !952 i32 @pthread_mutex_trylock(ptr noundef) local_unnamed_addr #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @item_trylock_unlock(ptr noundef %lock) local_unnamed_addr #0 !dbg !953 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %lock, metadata !957, metadata !DIExpression()), !dbg !958
  %call = tail call i32 @pthread_mutex_unlock(ptr noundef %lock) #16, !dbg !959
  ret void, !dbg !960
}

; Function Attrs: nounwind
declare !dbg !961 i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #1

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @item_unlock(i32 noundef %hv) local_unnamed_addr #0 !dbg !962 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !964, metadata !DIExpression()), !dbg !965
  %0 = load ptr, ptr @item_locks, align 8, !dbg !966, !tbaa !926
  %conv = zext i32 %hv to i64, !dbg !966
  %1 = load i32, ptr @item_lock_hashpower, align 4, !dbg !966, !tbaa !930
  %sh_prom = zext nneg i32 %1 to i64, !dbg !966
  %notmask = shl nsw i64 -1, %sh_prom, !dbg !966
  %sub = xor i64 %notmask, -1, !dbg !966
  %and = and i64 %sub, %conv, !dbg !966
  %arrayidx = getelementptr inbounds %union.pthread_mutex_t, ptr %0, i64 %and, !dbg !966
  %call = tail call i32 @pthread_mutex_unlock(ptr noundef %arrayidx) #16, !dbg !966
  ret void, !dbg !967
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @pause_threads(i32 noundef %type) local_unnamed_addr #0 !dbg !968 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %type, metadata !972, metadata !DIExpression()), !dbg !975
  tail call void @llvm.dbg.value(metadata i8 0, metadata !974, metadata !DIExpression()), !dbg !975
  switch i32 %type, label %sw.default [
    i32 1, label %sw.bb
    i32 0, label %sw.bb1
    i32 2, label %sw.bb2
    i32 3, label %sw.bb3
  ], !dbg !976

sw.bb:                                            ; preds = %entry
  tail call void @slabs_rebalancer_pause() #16, !dbg !977
  tail call void @lru_maintainer_pause() #16, !dbg !979
  tail call void @lru_crawler_pause() #16, !dbg !980
  tail call void @storage_compact_pause() #16, !dbg !981
  tail call void @storage_write_pause() #16, !dbg !982
  br label %sw.bb1, !dbg !982

sw.bb1:                                           ; preds = %entry, %sw.bb
  tail call void @llvm.dbg.value(metadata i8 1, metadata !974, metadata !DIExpression()), !dbg !975
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @worker_hang_lock) #16, !dbg !983
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !974, metadata !DIExpression()), !dbg !975
  %call6 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @init_lock) #16, !dbg !984
  store i32 0, ptr @init_count, align 4, !dbg !985, !tbaa !930
  tail call void @llvm.dbg.value(metadata i32 0, metadata !973, metadata !DIExpression()), !dbg !975
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 13), align 4, !dbg !986, !tbaa !989
  %cmp12 = icmp sgt i32 %0, 0, !dbg !994
  br i1 %cmp12, label %for.body, label %for.end, !dbg !995

sw.bb2:                                           ; preds = %entry
  tail call void @slabs_rebalancer_resume() #16, !dbg !996
  tail call void @lru_maintainer_resume() #16, !dbg !997
  tail call void @lru_crawler_resume() #16, !dbg !998
  tail call void @storage_compact_resume() #16, !dbg !999
  tail call void @storage_write_resume() #16, !dbg !1000
  br label %sw.bb3, !dbg !1000

sw.bb3:                                           ; preds = %entry, %sw.bb2
  %call4 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @worker_hang_lock) #16, !dbg !1001
  br label %cleanup, !dbg !1002

sw.default:                                       ; preds = %entry
  %1 = load ptr, ptr @stderr, align 8, !dbg !1003, !tbaa !926
  %call5 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %1, ptr noundef nonnull @.str, i32 noundef %type) #17, !dbg !1004
  br label %cleanup, !dbg !1005

for.body:                                         ; preds = %sw.bb1, %for.body
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.body ], [ 0, %sw.bb1 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !973, metadata !DIExpression()), !dbg !975
  %2 = load ptr, ptr @threads, align 8, !dbg !1006, !tbaa !926
  %arrayidx = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv, !dbg !1006
  tail call fastcc void @notify_worker_fd(ptr noundef %arrayidx, i32 noundef 0, i32 noundef 1), !dbg !1008
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !1009
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !973, metadata !DIExpression()), !dbg !975
  %3 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 13), align 4, !dbg !986, !tbaa !989
  %4 = sext i32 %3 to i64, !dbg !994
  %cmp = icmp slt i64 %indvars.iv.next, %4, !dbg !994
  br i1 %cmp, label %for.body, label %for.end.loopexit, !dbg !995, !llvm.loop !1010

for.end.loopexit:                                 ; preds = %for.body
  %.pre = load i32, ptr @init_count, align 4, !dbg !1013, !tbaa !930
  br label %for.end, !dbg !1013

for.end:                                          ; preds = %for.end.loopexit, %sw.bb1
  %5 = phi i32 [ 0, %sw.bb1 ], [ %.pre, %for.end.loopexit ], !dbg !1013
  %.lcssa = phi i32 [ %0, %sw.bb1 ], [ %3, %for.end.loopexit ], !dbg !986
  tail call void @llvm.dbg.value(metadata i32 %.lcssa, metadata !1018, metadata !DIExpression()), !dbg !1020
  %cmp1.i = icmp slt i32 %5, %.lcssa, !dbg !1021
  br i1 %cmp1.i, label %while.body.i, label %wait_for_thread_registration.exit, !dbg !1022

while.body.i:                                     ; preds = %for.end, %while.body.i
  %call.i = tail call i32 @pthread_cond_wait(ptr noundef nonnull @init_cond, ptr noundef nonnull @init_lock) #16, !dbg !1023
  %6 = load i32, ptr @init_count, align 4, !dbg !1013, !tbaa !930
  %cmp.i = icmp slt i32 %6, %.lcssa, !dbg !1021
  br i1 %cmp.i, label %while.body.i, label %wait_for_thread_registration.exit, !dbg !1022, !llvm.loop !1025

wait_for_thread_registration.exit:                ; preds = %while.body.i, %for.end
  %call7 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @init_lock) #16, !dbg !1027
  br label %cleanup, !dbg !1028

cleanup:                                          ; preds = %sw.default, %sw.bb3, %wait_for_thread_registration.exit
  ret void, !dbg !1028
}

declare !dbg !1029 void @slabs_rebalancer_pause() local_unnamed_addr #3

declare !dbg !1033 void @lru_maintainer_pause() local_unnamed_addr #3

declare !dbg !1035 void @lru_crawler_pause() local_unnamed_addr #3

declare !dbg !1037 void @storage_compact_pause() local_unnamed_addr #3

declare !dbg !1039 void @storage_write_pause() local_unnamed_addr #3

declare !dbg !1040 void @slabs_rebalancer_resume() local_unnamed_addr #3

declare !dbg !1041 void @lru_maintainer_resume() local_unnamed_addr #3

declare !dbg !1042 void @lru_crawler_resume() local_unnamed_addr #3

declare !dbg !1043 void @storage_compact_resume() local_unnamed_addr #3

declare !dbg !1044 void @storage_write_resume() local_unnamed_addr #3

; Function Attrs: nofree nounwind
declare !dbg !1045 noundef i32 @fprintf(ptr nocapture noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #4

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @notify_worker_fd(ptr nocapture noundef readonly %t, i32 noundef %sfd, i32 noundef %mode) unnamed_addr #0 !dbg !1103 {
entry:
  %u.i = alloca i64, align 8, !DIAssignID !1113
  tail call void @llvm.dbg.value(metadata ptr %t, metadata !1107, metadata !DIExpression()), !dbg !1114
  tail call void @llvm.dbg.value(metadata i32 %sfd, metadata !1108, metadata !DIExpression()), !dbg !1114
  tail call void @llvm.dbg.value(metadata i32 %mode, metadata !1109, metadata !DIExpression()), !dbg !1114
  %ev_queue = getelementptr inbounds i8, ptr %t, i64 6872
  %0 = load ptr, ptr %ev_queue, align 8, !dbg !1115, !tbaa !1116
  %cache.i9 = getelementptr inbounds i8, ptr %0, i64 56, !dbg !1126
  %1 = load ptr, ptr %cache.i9, align 8, !dbg !1126, !tbaa !1136
  %call.i10 = tail call ptr @cache_alloc(ptr noundef %1) #16, !dbg !1139
  %cmp.i11 = icmp eq ptr %call.i10, null, !dbg !1140
  br i1 %cmp.i11, label %cqi_new.exit, label %while.end, !dbg !1142

cqi_new.exit:                                     ; preds = %entry, %cqi_new.exit
  %call.i.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @stats_lock) #16, !dbg !1143
  %2 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 3), align 8, !dbg !1147, !tbaa !1148
  %inc.i = add i64 %2, 1, !dbg !1147
  store i64 %inc.i, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 3), align 8, !dbg !1147, !tbaa !1148
  %call.i2.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @stats_lock) #16, !dbg !1150
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !1110, metadata !DIExpression()), !dbg !1114
  %3 = load ptr, ptr %ev_queue, align 8, !dbg !1115, !tbaa !1116
  tail call void @llvm.dbg.value(metadata ptr %3, metadata !1133, metadata !DIExpression()), !dbg !1153
  %cache.i = getelementptr inbounds i8, ptr %3, i64 56, !dbg !1126
  %4 = load ptr, ptr %cache.i, align 8, !dbg !1126, !tbaa !1136
  %call.i = tail call ptr @cache_alloc(ptr noundef %4) #16, !dbg !1139
  tail call void @llvm.dbg.value(metadata ptr %call.i, metadata !1134, metadata !DIExpression()), !dbg !1153
  %cmp.i = icmp eq ptr %call.i, null, !dbg !1140
  br i1 %cmp.i, label %cqi_new.exit, label %while.end, !dbg !1142, !llvm.loop !1154

while.end:                                        ; preds = %cqi_new.exit, %entry
  %call.i.lcssa = phi ptr [ %call.i10, %entry ], [ %call.i, %cqi_new.exit ], !dbg !1139
  tail call void @llvm.dbg.value(metadata ptr %call.i.lcssa, metadata !1110, metadata !DIExpression()), !dbg !1114
  %mode1 = getelementptr inbounds i8, ptr %call.i.lcssa, i64 20, !dbg !1157
  store i32 %mode, ptr %mode1, align 4, !dbg !1158, !tbaa !1159
  store i32 %sfd, ptr %call.i.lcssa, align 8, !dbg !1162, !tbaa !1163
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1164, metadata !DIExpression(), metadata !1113, metadata ptr %u.i, metadata !DIExpression()), !dbg !1171
  tail call void @llvm.dbg.value(metadata ptr %t, metadata !1169, metadata !DIExpression()), !dbg !1171
  tail call void @llvm.dbg.value(metadata ptr %call.i.lcssa, metadata !1170, metadata !DIExpression()), !dbg !1171
  %5 = load ptr, ptr %ev_queue, align 8, !dbg !1173, !tbaa !1116
  tail call void @llvm.dbg.value(metadata ptr %5, metadata !1174, metadata !DIExpression()), !dbg !1180
  tail call void @llvm.dbg.value(metadata ptr %call.i.lcssa, metadata !1179, metadata !DIExpression()), !dbg !1180
  %lock.i.i = getelementptr inbounds i8, ptr %5, i64 16, !dbg !1182
  %call.i.i6 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %lock.i.i) #16, !dbg !1183
  %i_next.i.i = getelementptr inbounds i8, ptr %call.i.lcssa, i64 64, !dbg !1184
  store ptr null, ptr %i_next.i.i, align 8, !dbg !1184, !tbaa !1186
  %stqh_last.i.i = getelementptr inbounds i8, ptr %5, i64 8, !dbg !1184
  %6 = load ptr, ptr %stqh_last.i.i, align 8, !dbg !1184, !tbaa !1187
  store ptr %call.i.lcssa, ptr %6, align 8, !dbg !1184, !tbaa !926
  store ptr %i_next.i.i, ptr %stqh_last.i.i, align 8, !dbg !1184, !tbaa !1187
  %call6.i.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %lock.i.i) #16, !dbg !1188
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %u.i) #16, !dbg !1189
  store i64 1, ptr %u.i, align 8, !dbg !1190, !tbaa !1191, !DIAssignID !1192
  tail call void @llvm.dbg.assign(metadata i64 1, metadata !1164, metadata !DIExpression(), metadata !1192, metadata ptr %u.i, metadata !DIExpression()), !dbg !1171
  %notify_event_fd.i = getelementptr inbounds i8, ptr %t, i64 144, !dbg !1193
  %7 = load i32, ptr %notify_event_fd.i, align 8, !dbg !1193, !tbaa !1195
  %call.i7 = call i64 @write(i32 noundef %7, ptr noundef nonnull %u.i, i64 noundef 8) #16, !dbg !1196
  %cmp.not.i = icmp eq i64 %call.i7, 8, !dbg !1197
  br i1 %cmp.not.i, label %notify_worker.exit, label %if.then.i8, !dbg !1198

if.then.i8:                                       ; preds = %while.end
  tail call void @perror(ptr noundef nonnull @.str.13) #18, !dbg !1199
  br label %notify_worker.exit, !dbg !1201

notify_worker.exit:                               ; preds = %while.end, %if.then.i8
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %u.i) #16, !dbg !1202
  ret void, !dbg !1203
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @stop_threads() local_unnamed_addr #0 !dbg !1204 {
entry:
  tail call void @stop_assoc_maintenance_thread() #16, !dbg !1207
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1208, !tbaa !1210
  %cmp = icmp sgt i32 %0, 0, !dbg !1211
  br i1 %cmp, label %if.end, label %if.end4, !dbg !1212

if.end:                                           ; preds = %entry
  %1 = load ptr, ptr @stderr, align 8, !dbg !1213, !tbaa !926
  %2 = tail call i64 @fwrite(ptr nonnull @.str.1, i64 14, i64 1, ptr %1) #18, !dbg !1214
  %.pr = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1215, !tbaa !1210
  %cmp1 = icmp sgt i32 %.pr, 0, !dbg !1217
  br i1 %cmp1, label %if.then2, label %if.end4, !dbg !1218

if.then2:                                         ; preds = %if.end
  %3 = load ptr, ptr @stderr, align 8, !dbg !1219, !tbaa !926
  %4 = tail call i64 @fwrite(ptr nonnull @.str.2, i64 23, i64 1, ptr %3) #18, !dbg !1220
  br label %if.end4, !dbg !1220

if.end4:                                          ; preds = %entry, %if.then2, %if.end
  %call5 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @worker_hang_lock) #16, !dbg !1221
  %call6 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @init_lock) #16, !dbg !1222
  store i32 0, ptr @init_count, align 4, !dbg !1223, !tbaa !930
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1206, metadata !DIExpression()), !dbg !1224
  %5 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 13), align 4, !dbg !1225, !tbaa !989
  %cmp771 = icmp sgt i32 %5, 0, !dbg !1228
  br i1 %cmp771, label %for.body, label %for.end, !dbg !1229

for.body:                                         ; preds = %if.end4, %for.body
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.body ], [ 0, %if.end4 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1206, metadata !DIExpression()), !dbg !1224
  %6 = load ptr, ptr @threads, align 8, !dbg !1230, !tbaa !926
  %arrayidx = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %6, i64 %indvars.iv, !dbg !1230
  tail call fastcc void @notify_worker_fd(ptr noundef %arrayidx, i32 noundef 0, i32 noundef 4), !dbg !1232
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !1233
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !1206, metadata !DIExpression()), !dbg !1224
  %7 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 13), align 4, !dbg !1225, !tbaa !989
  %8 = sext i32 %7 to i64, !dbg !1228
  %cmp7 = icmp slt i64 %indvars.iv.next, %8, !dbg !1228
  br i1 %cmp7, label %for.body, label %for.end.loopexit, !dbg !1229, !llvm.loop !1234

for.end.loopexit:                                 ; preds = %for.body
  %.pre = load i32, ptr @init_count, align 4, !dbg !1236, !tbaa !930
  br label %for.end, !dbg !1236

for.end:                                          ; preds = %for.end.loopexit, %if.end4
  %9 = phi i32 [ 0, %if.end4 ], [ %.pre, %for.end.loopexit ], !dbg !1236
  %.lcssa = phi i32 [ %5, %if.end4 ], [ %7, %for.end.loopexit ], !dbg !1225
  tail call void @llvm.dbg.value(metadata i32 %.lcssa, metadata !1018, metadata !DIExpression()), !dbg !1238
  %cmp1.i = icmp slt i32 %9, %.lcssa, !dbg !1239
  br i1 %cmp1.i, label %while.body.i, label %wait_for_thread_registration.exit, !dbg !1240

while.body.i:                                     ; preds = %for.end, %while.body.i
  %call.i = tail call i32 @pthread_cond_wait(ptr noundef nonnull @init_cond, ptr noundef nonnull @init_lock) #16, !dbg !1241
  %10 = load i32, ptr @init_count, align 4, !dbg !1236, !tbaa !930
  %cmp.i = icmp slt i32 %10, %.lcssa, !dbg !1239
  br i1 %cmp.i, label %while.body.i, label %wait_for_thread_registration.exit, !dbg !1240, !llvm.loop !1242

wait_for_thread_registration.exit:                ; preds = %while.body.i, %for.end
  %call8 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @init_lock) #16, !dbg !1244
  %11 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1245, !tbaa !1210
  %cmp9 = icmp sgt i32 %11, 0, !dbg !1247
  br i1 %cmp9, label %if.then10, label %if.end12, !dbg !1248

if.then10:                                        ; preds = %wait_for_thread_registration.exit
  %12 = load ptr, ptr @stderr, align 8, !dbg !1249, !tbaa !926
  %13 = tail call i64 @fwrite(ptr nonnull @.str.3, i64 34, i64 1, ptr %12) #18, !dbg !1250
  br label %if.end12, !dbg !1250

if.end12:                                         ; preds = %if.then10, %wait_for_thread_registration.exit
  %call13 = tail call i32 @stop_item_crawler_thread(i1 noundef zeroext true) #16, !dbg !1251
  %14 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1252, !tbaa !1210
  %cmp14 = icmp sgt i32 %14, 0, !dbg !1254
  br i1 %cmp14, label %if.then15, label %if.end17, !dbg !1255

if.then15:                                        ; preds = %if.end12
  %15 = load ptr, ptr @stderr, align 8, !dbg !1256, !tbaa !926
  %16 = tail call i64 @fwrite(ptr nonnull @.str.4, i64 20, i64 1, ptr %15) #18, !dbg !1257
  br label %if.end17, !dbg !1257

if.end17:                                         ; preds = %if.then15, %if.end12
  %17 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 28), align 1, !dbg !1258, !tbaa !1260, !range !1261, !noundef !1262
  %tobool = trunc nuw i8 %17 to i1, !dbg !1258
  br i1 %tobool, label %if.then18, label %if.end24, !dbg !1263

if.then18:                                        ; preds = %if.end17
  %call19 = tail call i32 @stop_lru_maintainer_thread() #16, !dbg !1264
  %18 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1266, !tbaa !1210
  %cmp20 = icmp sgt i32 %18, 0, !dbg !1268
  br i1 %cmp20, label %if.then21, label %if.end24, !dbg !1269

if.then21:                                        ; preds = %if.then18
  %19 = load ptr, ptr @stderr, align 8, !dbg !1270, !tbaa !926
  %20 = tail call i64 @fwrite(ptr nonnull @.str.5, i64 19, i64 1, ptr %19) #18, !dbg !1271
  br label %if.end24, !dbg !1271

if.end24:                                         ; preds = %if.then18, %if.then21, %if.end17
  %21 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 30), align 1, !dbg !1272, !tbaa !1274, !range !1261, !noundef !1262
  %tobool25 = trunc nuw i8 %21 to i1, !dbg !1272
  br i1 %tobool25, label %if.then26, label %if.end31, !dbg !1275

if.then26:                                        ; preds = %if.end24
  tail call void @stop_slab_maintenance_thread() #16, !dbg !1276
  %22 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1278, !tbaa !1210
  %cmp27 = icmp sgt i32 %22, 0, !dbg !1280
  br i1 %cmp27, label %if.then28, label %if.end31, !dbg !1281

if.then28:                                        ; preds = %if.then26
  %23 = load ptr, ptr @stderr, align 8, !dbg !1282, !tbaa !926
  %24 = tail call i64 @fwrite(ptr nonnull @.str.6, i64 19, i64 1, ptr %23) #18, !dbg !1283
  br label %if.end31, !dbg !1283

if.end31:                                         ; preds = %if.then26, %if.then28, %if.end24
  tail call void @logger_stop() #16, !dbg !1284
  %25 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1285, !tbaa !1210
  %cmp32 = icmp sgt i32 %25, 0, !dbg !1287
  br i1 %cmp32, label %if.then33, label %if.end35, !dbg !1288

if.then33:                                        ; preds = %if.end31
  %26 = load ptr, ptr @stderr, align 8, !dbg !1289, !tbaa !926
  %27 = tail call i64 @fwrite(ptr nonnull @.str.7, i64 22, i64 1, ptr %26) #18, !dbg !1290
  br label %if.end35, !dbg !1290

if.end35:                                         ; preds = %if.then33, %if.end31
  %call36 = tail call i32 @stop_conn_timeout_thread() #16, !dbg !1291
  %28 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1292, !tbaa !1210
  %cmp37 = icmp sgt i32 %28, 0, !dbg !1294
  br i1 %cmp37, label %if.end40, label %if.end44, !dbg !1295

if.end40:                                         ; preds = %if.end35
  %29 = load ptr, ptr @stderr, align 8, !dbg !1296, !tbaa !926
  %30 = tail call i64 @fwrite(ptr nonnull @.str.8, i64 28, i64 1, ptr %29) #18, !dbg !1297
  %.pr69 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1298, !tbaa !1210
  %cmp41 = icmp sgt i32 %.pr69, 0, !dbg !1300
  br i1 %cmp41, label %if.then42, label %if.end44, !dbg !1301

if.then42:                                        ; preds = %if.end40
  %31 = load ptr, ptr @stderr, align 8, !dbg !1302, !tbaa !926
  %32 = tail call i64 @fwrite(ptr nonnull @.str.9, i64 20, i64 1, ptr %31) #18, !dbg !1303
  br label %if.end44, !dbg !1303

if.end44:                                         ; preds = %if.end35, %if.then42, %if.end40
  tail call void @conn_close_all() #16, !dbg !1304
  %call45 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @worker_hang_lock) #16, !dbg !1305
  %33 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1306, !tbaa !1210
  %cmp46 = icmp sgt i32 %33, 0, !dbg !1308
  br i1 %cmp46, label %if.then47, label %if.end49, !dbg !1309

if.then47:                                        ; preds = %if.end44
  %34 = load ptr, ptr @stderr, align 8, !dbg !1310, !tbaa !926
  %35 = tail call i64 @fwrite(ptr nonnull @.str.10, i64 23, i64 1, ptr %34) #18, !dbg !1311
  br label %if.end49, !dbg !1311

if.end49:                                         ; preds = %if.then47, %if.end44
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1206, metadata !DIExpression()), !dbg !1224
  %36 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 13), align 4, !dbg !1312, !tbaa !989
  %cmp5173 = icmp sgt i32 %36, 0, !dbg !1315
  br i1 %cmp5173, label %for.body52, label %for.end58, !dbg !1316

for.body52:                                       ; preds = %if.end49, %for.body52
  %indvars.iv77 = phi i64 [ %indvars.iv.next78, %for.body52 ], [ 0, %if.end49 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv77, metadata !1206, metadata !DIExpression()), !dbg !1224
  %37 = load ptr, ptr @threads, align 8, !dbg !1317, !tbaa !926
  %arrayidx54 = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %37, i64 %indvars.iv77, !dbg !1317
  %38 = load i64, ptr %arrayidx54, align 8, !dbg !1319, !tbaa !1320
  %call55 = tail call i32 @pthread_join(i64 noundef %38, ptr noundef null) #16, !dbg !1321
  %indvars.iv.next78 = add nuw nsw i64 %indvars.iv77, 1, !dbg !1322
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next78, metadata !1206, metadata !DIExpression()), !dbg !1224
  %39 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 13), align 4, !dbg !1312, !tbaa !989
  %40 = sext i32 %39 to i64, !dbg !1315
  %cmp51 = icmp slt i64 %indvars.iv.next78, %40, !dbg !1315
  br i1 %cmp51, label %for.body52, label %for.end58, !dbg !1316, !llvm.loop !1323

for.end58:                                        ; preds = %for.body52, %if.end49
  %41 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1325, !tbaa !1210
  %cmp59 = icmp sgt i32 %41, 0, !dbg !1327
  br i1 %cmp59, label %if.then60, label %if.end62, !dbg !1328

if.then60:                                        ; preds = %for.end58
  %42 = load ptr, ptr @stderr, align 8, !dbg !1329, !tbaa !926
  %43 = tail call i64 @fwrite(ptr nonnull @.str.11, i64 31, i64 1, ptr %42) #18, !dbg !1330
  br label %if.end62, !dbg !1330

if.end62:                                         ; preds = %if.then60, %for.end58
  ret void, !dbg !1331
}

declare !dbg !1332 void @stop_assoc_maintenance_thread() local_unnamed_addr #3

declare !dbg !1334 i32 @stop_item_crawler_thread(i1 noundef zeroext) local_unnamed_addr #3

declare !dbg !1337 i32 @stop_lru_maintainer_thread() local_unnamed_addr #3

declare !dbg !1340 void @stop_slab_maintenance_thread() local_unnamed_addr #3

declare !dbg !1341 void @logger_stop() local_unnamed_addr #3

declare !dbg !1342 i32 @stop_conn_timeout_thread() local_unnamed_addr #3

declare !dbg !1343 void @conn_close_all() local_unnamed_addr #3

declare !dbg !1344 i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @accept_new_conns(i1 noundef zeroext %do_accept) local_unnamed_addr #0 !dbg !1348 {
entry:
  tail call void @llvm.dbg.value(metadata i1 %do_accept, metadata !1353, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1354
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @conn_lock) #16, !dbg !1355
  tail call void @do_accept_new_conns(i1 noundef zeroext %do_accept) #16, !dbg !1356
  %call1 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @conn_lock) #16, !dbg !1357
  ret void, !dbg !1358
}

declare !dbg !1359 void @do_accept_new_conns(i1 noundef zeroext) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @thread_setname(i64 noundef %thread, ptr noundef %name) local_unnamed_addr #0 !dbg !1360 {
entry:
  tail call void @llvm.dbg.value(metadata i64 %thread, metadata !1364, metadata !DIExpression()), !dbg !1366
  tail call void @llvm.dbg.value(metadata ptr %name, metadata !1365, metadata !DIExpression()), !dbg !1366
  %call = tail call i32 @pthread_setname_np(i64 noundef %thread, ptr noundef %name) #16, !dbg !1367
  ret void, !dbg !1368
}

; Function Attrs: nounwind
declare !dbg !1369 i32 @pthread_setname_np(i64 noundef, ptr noundef) local_unnamed_addr #1

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @get_worker_thread(i32 noundef %id) local_unnamed_addr #5 !dbg !1372 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %id, metadata !1376, metadata !DIExpression()), !dbg !1377
  %0 = load ptr, ptr @threads, align 8, !dbg !1378, !tbaa !926
  %idxprom = sext i32 %id to i64, !dbg !1378
  %arrayidx = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %0, i64 %idxprom, !dbg !1378
  ret ptr %arrayidx, !dbg !1379
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @dispatch_conn_new(i32 noundef %sfd, i32 noundef %init_state, i32 noundef %event_flags, i32 noundef %read_buffer_size, i32 noundef %transport, ptr noundef %ssl, i64 noundef %conntag, i32 noundef %bproto) local_unnamed_addr #0 !dbg !1380 {
entry:
  %u.i = alloca i64, align 8, !DIAssignID !1394
  %napi_id.i = alloca i32, align 4, !DIAssignID !1395
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1396, metadata !DIExpression(), metadata !1395, metadata ptr %napi_id.i, metadata !DIExpression()), !dbg !1406
  %len.i = alloca i32, align 4, !DIAssignID !1409
  tail call void @llvm.dbg.value(metadata i32 %sfd, metadata !1384, metadata !DIExpression()), !dbg !1410
  tail call void @llvm.dbg.value(metadata i32 %init_state, metadata !1385, metadata !DIExpression()), !dbg !1410
  tail call void @llvm.dbg.value(metadata i32 %event_flags, metadata !1386, metadata !DIExpression()), !dbg !1410
  tail call void @llvm.dbg.value(metadata i32 %read_buffer_size, metadata !1387, metadata !DIExpression()), !dbg !1410
  tail call void @llvm.dbg.value(metadata i32 %transport, metadata !1388, metadata !DIExpression()), !dbg !1410
  tail call void @llvm.dbg.value(metadata ptr %ssl, metadata !1389, metadata !DIExpression()), !dbg !1410
  tail call void @llvm.dbg.value(metadata i64 %conntag, metadata !1390, metadata !DIExpression()), !dbg !1410
  tail call void @llvm.dbg.value(metadata i32 %bproto, metadata !1391, metadata !DIExpression()), !dbg !1410
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1392, metadata !DIExpression()), !dbg !1410
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 70), align 8, !dbg !1411, !tbaa !1412
  %tobool.not = icmp eq i32 %0, 0, !dbg !1413
  br i1 %tobool.not, label %if.then, label %if.else, !dbg !1414

if.then:                                          ; preds = %entry
  %1 = load i32, ptr @last_thread, align 4, !dbg !1415, !tbaa !930
  %add.i = add nsw i32 %1, 1, !dbg !1422
  %2 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 13), align 4, !dbg !1423, !tbaa !989
  %rem.i = srem i32 %add.i, %2, !dbg !1424
  tail call void @llvm.dbg.value(metadata i32 %rem.i, metadata !1420, metadata !DIExpression()), !dbg !1425
  store i32 %rem.i, ptr @last_thread, align 4, !dbg !1426, !tbaa !930
  %3 = load ptr, ptr @threads, align 8, !dbg !1427, !tbaa !926
  %idx.ext.i = sext i32 %rem.i to i64, !dbg !1428
  %add.ptr.i = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %3, i64 %idx.ext.i, !dbg !1428
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !1393, metadata !DIExpression()), !dbg !1410
  br label %if.end, !dbg !1429

if.else:                                          ; preds = %entry
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1403, metadata !DIExpression(), metadata !1409, metadata ptr %len.i, metadata !DIExpression()), !dbg !1406
  tail call void @llvm.dbg.value(metadata i32 %sfd, metadata !1399, metadata !DIExpression()), !dbg !1406
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %napi_id.i) #16, !dbg !1430
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %len.i) #16, !dbg !1431
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !1404, metadata !DIExpression()), !dbg !1406
  store i32 4, ptr %len.i, align 4, !dbg !1432, !tbaa !930, !DIAssignID !1433
  tail call void @llvm.dbg.assign(metadata i32 4, metadata !1403, metadata !DIExpression(), metadata !1433, metadata ptr %len.i, metadata !DIExpression()), !dbg !1406
  %call.i = call i32 @getsockopt(i32 noundef %sfd, i32 noundef 1, i32 noundef 56, ptr noundef nonnull %napi_id.i, ptr noundef nonnull %len.i) #16, !dbg !1434
  tail call void @llvm.dbg.value(metadata i32 %call.i, metadata !1401, metadata !DIExpression()), !dbg !1406
  %cmp.i = icmp eq i32 %call.i, -1, !dbg !1435
  br i1 %cmp.i, label %if.then.i, label %lor.lhs.false.i, !dbg !1437

lor.lhs.false.i:                                  ; preds = %if.else
  %4 = load i32, ptr %napi_id.i, align 4, !dbg !1438, !tbaa !930
  %cmp1.i = icmp eq i32 %4, 0, !dbg !1439
  br i1 %cmp1.i, label %if.then.i, label %select.preheader.i, !dbg !1440

select.preheader.i:                               ; preds = %lor.lhs.false.i
  %.pre.i = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 13), align 4, !tbaa !989
  br label %select.i, !dbg !1441

if.then.i:                                        ; preds = %lor.lhs.false.i, %if.else
  %call.i.i = call i32 @pthread_mutex_lock(ptr noundef nonnull @stats_lock) #16, !dbg !1443
  %5 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 26), align 8, !dbg !1446, !tbaa !1447
  %inc.i = add i64 %5, 1, !dbg !1446
  store i64 %inc.i, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 26), align 8, !dbg !1446, !tbaa !1447
  %call.i32.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull @stats_lock) #16, !dbg !1448
  %6 = load i32, ptr @last_thread, align 4, !dbg !1450, !tbaa !930
  %add.i.i = add nsw i32 %6, 1, !dbg !1452
  %7 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 13), align 4, !dbg !1453, !tbaa !989
  %rem.i.i = srem i32 %add.i.i, %7, !dbg !1454
  tail call void @llvm.dbg.value(metadata i32 %rem.i.i, metadata !1420, metadata !DIExpression()), !dbg !1455
  store i32 %rem.i.i, ptr @last_thread, align 4, !dbg !1456, !tbaa !930
  %8 = load ptr, ptr @threads, align 8, !dbg !1457, !tbaa !926
  %idx.ext.i.i = sext i32 %rem.i.i to i64, !dbg !1458
  %add.ptr.i.i = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %8, i64 %idx.ext.i.i, !dbg !1458
  br label %select_thread_by_napi_id.exit, !dbg !1459

select.i:                                         ; preds = %reset_threads_napi_id.exit.i, %select.preheader.i
  %9 = phi i32 [ %.pre.i, %select.preheader.i ], [ %18, %reset_threads_napi_id.exit.i ]
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !1404, metadata !DIExpression()), !dbg !1406
  tail call void @llvm.dbg.label(metadata !1405), !dbg !1460
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1402, metadata !DIExpression()), !dbg !1406
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1402, metadata !DIExpression()), !dbg !1406
  %cmp342.i = icmp sgt i32 %9, 0, !dbg !1461
  br i1 %cmp342.i, label %for.body.lr.ph.i, label %if.then14.i, !dbg !1441

for.body.lr.ph.i:                                 ; preds = %select.i
  %10 = load ptr, ptr @threads, align 8, !tbaa !926
  %11 = load i32, ptr @last_thread_by_napi_id, align 4, !tbaa !930
  %smax.i = call i32 @llvm.smax.i32(i32 %11, i32 -1), !dbg !1441
  %12 = add i32 %smax.i, 1, !dbg !1441
  %13 = zext i32 %12 to i64, !dbg !1441
  %wide.trip.count50.i = zext nneg i32 %9 to i64, !dbg !1461
  %14 = load i32, ptr %napi_id.i, align 4, !tbaa !930
  br label %for.body.i, !dbg !1441

for.body.i:                                       ; preds = %for.inc.i, %for.body.lr.ph.i
  %indvars.iv.i = phi i64 [ 0, %for.body.lr.ph.i ], [ %indvars.iv.next.i, %for.inc.i ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i, metadata !1402, metadata !DIExpression()), !dbg !1406
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %10, i64 %indvars.iv.i), metadata !1400, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 6936, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1406
  %exitcond.i = icmp eq i64 %indvars.iv.i, %13, !dbg !1463
  br i1 %exitcond.i, label %if.then5.i, label %if.end7.i, !dbg !1466

if.then5.i:                                       ; preds = %for.body.i
  %15 = mul nuw nsw i64 %13, 6936
  %scevgep.le = getelementptr i8, ptr %10, i64 %15
  %napi_id6.i = getelementptr inbounds i8, ptr %scevgep.le, i64 6928, !dbg !1467
  store i32 %14, ptr %napi_id6.i, align 8, !dbg !1469, !tbaa !1470
  store i32 %12, ptr @last_thread_by_napi_id, align 4, !dbg !1471, !tbaa !930
  tail call void @llvm.dbg.value(metadata i32 %12, metadata !1404, metadata !DIExpression()), !dbg !1406
  br label %if.end16.i, !dbg !1472

if.end7.i:                                        ; preds = %for.body.i
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %10, i64 %indvars.iv.i), metadata !1400, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 6936, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1406
  %napi_id8.i = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %10, i64 %indvars.iv.i, i32 17, !dbg !1473
  %16 = load i32, ptr %napi_id8.i, align 8, !dbg !1473, !tbaa !1470
  %cmp9.i = icmp eq i32 %16, %14, !dbg !1475
  br i1 %cmp9.i, label %if.end16.loopexit.i, label %for.inc.i, !dbg !1476

for.inc.i:                                        ; preds = %if.end7.i
  %indvars.iv.next.i = add nuw nsw i64 %indvars.iv.i, 1, !dbg !1477
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !1402, metadata !DIExpression()), !dbg !1406
  %exitcond51.not.i = icmp eq i64 %indvars.iv.next.i, %wide.trip.count50.i, !dbg !1461
  br i1 %exitcond51.not.i, label %if.then14.i, label %for.body.i, !dbg !1441, !llvm.loop !1478

if.then14.i:                                      ; preds = %for.inc.i, %select.i
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !1404, metadata !DIExpression()), !dbg !1406
  %call.i33.i = call i32 @pthread_mutex_lock(ptr noundef nonnull @stats_lock) #16, !dbg !1480
  %17 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 25), align 8, !dbg !1484, !tbaa !1485
  %inc15.i = add i64 %17, 1, !dbg !1484
  store i64 %inc15.i, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 25), align 8, !dbg !1484, !tbaa !1485
  %call.i34.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull @stats_lock) #16, !dbg !1486
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1488, metadata !DIExpression()), !dbg !1492
  %18 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 13), align 4, !tbaa !989
  %cmp3.i.i = icmp sgt i32 %18, 0, !dbg !1494
  br i1 %cmp3.i.i, label %for.body.lr.ph.i.i, label %reset_threads_napi_id.exit.i, !dbg !1497

for.body.lr.ph.i.i:                               ; preds = %if.then14.i
  %19 = load ptr, ptr @threads, align 8, !tbaa !926
  %wide.trip.count.i.i = zext nneg i32 %18 to i64, !dbg !1494
  %xtraiter = and i64 %wide.trip.count.i.i, 3, !dbg !1497
  %20 = icmp ult i32 %18, 4, !dbg !1497
  br i1 %20, label %reset_threads_napi_id.exit.i.loopexit.unr-lcssa, label %for.body.lr.ph.i.i.new, !dbg !1497

for.body.lr.ph.i.i.new:                           ; preds = %for.body.lr.ph.i.i
  %unroll_iter = and i64 %wide.trip.count.i.i, 2147483644, !dbg !1497
  br label %for.body.i.i, !dbg !1497

for.body.i.i:                                     ; preds = %for.body.i.i, %for.body.lr.ph.i.i.new
  %indvars.iv.i.i = phi i64 [ 0, %for.body.lr.ph.i.i.new ], [ %indvars.iv.next.i.i.3, %for.body.i.i ]
  %niter = phi i64 [ 0, %for.body.lr.ph.i.i.new ], [ %niter.next.3, %for.body.i.i ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i.i, metadata !1488, metadata !DIExpression()), !dbg !1492
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %19, i64 %indvars.iv.i.i), metadata !1491, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 6936, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1492
  %napi_id.i.i = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %19, i64 %indvars.iv.i.i, i32 17, !dbg !1498
  store i32 0, ptr %napi_id.i.i, align 8, !dbg !1500, !tbaa !1470
  %indvars.iv.next.i.i = or disjoint i64 %indvars.iv.i.i, 1, !dbg !1501
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.i, metadata !1488, metadata !DIExpression()), !dbg !1492
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.i, metadata !1488, metadata !DIExpression()), !dbg !1492
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %19, i64 %indvars.iv.next.i.i), metadata !1491, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 6936, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1492
  %napi_id.i.i.1 = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %19, i64 %indvars.iv.next.i.i, i32 17, !dbg !1498
  store i32 0, ptr %napi_id.i.i.1, align 8, !dbg !1500, !tbaa !1470
  %indvars.iv.next.i.i.1 = or disjoint i64 %indvars.iv.i.i, 2, !dbg !1501
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.i.1, metadata !1488, metadata !DIExpression()), !dbg !1492
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.i.1, metadata !1488, metadata !DIExpression()), !dbg !1492
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %19, i64 %indvars.iv.next.i.i.1), metadata !1491, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 6936, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1492
  %napi_id.i.i.2 = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %19, i64 %indvars.iv.next.i.i.1, i32 17, !dbg !1498
  store i32 0, ptr %napi_id.i.i.2, align 8, !dbg !1500, !tbaa !1470
  %indvars.iv.next.i.i.2 = or disjoint i64 %indvars.iv.i.i, 3, !dbg !1501
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.i.2, metadata !1488, metadata !DIExpression()), !dbg !1492
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.i.2, metadata !1488, metadata !DIExpression()), !dbg !1492
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %19, i64 %indvars.iv.next.i.i.2), metadata !1491, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 6936, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1492
  %napi_id.i.i.3 = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %19, i64 %indvars.iv.next.i.i.2, i32 17, !dbg !1498
  store i32 0, ptr %napi_id.i.i.3, align 8, !dbg !1500, !tbaa !1470
  %indvars.iv.next.i.i.3 = add nuw nsw i64 %indvars.iv.i.i, 4, !dbg !1501
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.i.3, metadata !1488, metadata !DIExpression()), !dbg !1492
  %niter.next.3 = add i64 %niter, 4, !dbg !1497
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter, !dbg !1497
  br i1 %niter.ncmp.3, label %reset_threads_napi_id.exit.i.loopexit.unr-lcssa, label %for.body.i.i, !dbg !1497, !llvm.loop !1502

reset_threads_napi_id.exit.i.loopexit.unr-lcssa:  ; preds = %for.body.i.i, %for.body.lr.ph.i.i
  %indvars.iv.i.i.unr = phi i64 [ 0, %for.body.lr.ph.i.i ], [ %indvars.iv.next.i.i.3, %for.body.i.i ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0, !dbg !1497
  br i1 %lcmp.mod.not, label %reset_threads_napi_id.exit.i, label %for.body.i.i.epil, !dbg !1497

for.body.i.i.epil:                                ; preds = %reset_threads_napi_id.exit.i.loopexit.unr-lcssa, %for.body.i.i.epil
  %indvars.iv.i.i.epil = phi i64 [ %indvars.iv.next.i.i.epil, %for.body.i.i.epil ], [ %indvars.iv.i.i.unr, %reset_threads_napi_id.exit.i.loopexit.unr-lcssa ]
  %epil.iter = phi i64 [ %epil.iter.next, %for.body.i.i.epil ], [ 0, %reset_threads_napi_id.exit.i.loopexit.unr-lcssa ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i.i.epil, metadata !1488, metadata !DIExpression()), !dbg !1492
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %19, i64 %indvars.iv.i.i.epil), metadata !1491, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 6936, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1492
  %napi_id.i.i.epil = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %19, i64 %indvars.iv.i.i.epil, i32 17, !dbg !1498
  store i32 0, ptr %napi_id.i.i.epil, align 8, !dbg !1500, !tbaa !1470
  %indvars.iv.next.i.i.epil = add nuw nsw i64 %indvars.iv.i.i.epil, 1, !dbg !1501
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.i.epil, metadata !1488, metadata !DIExpression()), !dbg !1492
  %epil.iter.next = add i64 %epil.iter, 1, !dbg !1497
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter, !dbg !1497
  br i1 %epil.iter.cmp.not, label %reset_threads_napi_id.exit.i, label %for.body.i.i.epil, !dbg !1497, !llvm.loop !1504

reset_threads_napi_id.exit.i:                     ; preds = %reset_threads_napi_id.exit.i.loopexit.unr-lcssa, %for.body.i.i.epil, %if.then14.i
  store i32 -1, ptr @last_thread_by_napi_id, align 4, !dbg !1506, !tbaa !930
  br label %select.i, !dbg !1507

if.end16.loopexit.i:                              ; preds = %if.end7.i
  %.pre52.i = and i64 %indvars.iv.i, 4294967295, !dbg !1508
  br label %if.end16.i, !dbg !1509

if.end16.i:                                       ; preds = %if.end16.loopexit.i, %if.then5.i
  %idx.ext17.pre-phi.i = phi i64 [ %.pre52.i, %if.end16.loopexit.i ], [ %13, %if.then5.i ], !dbg !1508
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1404, metadata !DIExpression()), !dbg !1406
  %add.ptr18.i = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %10, i64 %idx.ext17.pre-phi.i, !dbg !1508
  br label %select_thread_by_napi_id.exit, !dbg !1510

select_thread_by_napi_id.exit:                    ; preds = %if.then.i, %if.end16.i
  %retval.0.i = phi ptr [ %add.ptr.i.i, %if.then.i ], [ %add.ptr18.i, %if.end16.i ], !dbg !1406
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %len.i) #16, !dbg !1511
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %napi_id.i) #16, !dbg !1511
  tail call void @llvm.dbg.value(metadata ptr %retval.0.i, metadata !1393, metadata !DIExpression()), !dbg !1410
  br label %if.end

if.end:                                           ; preds = %select_thread_by_napi_id.exit, %if.then
  %thread.0 = phi ptr [ %retval.0.i, %select_thread_by_napi_id.exit ], [ %add.ptr.i, %if.then ], !dbg !1512
  tail call void @llvm.dbg.value(metadata ptr %thread.0, metadata !1393, metadata !DIExpression()), !dbg !1410
  %ev_queue = getelementptr inbounds i8, ptr %thread.0, i64 6872, !dbg !1513
  %21 = load ptr, ptr %ev_queue, align 8, !dbg !1513, !tbaa !1116
  tail call void @llvm.dbg.value(metadata ptr %21, metadata !1133, metadata !DIExpression()), !dbg !1514
  %cache.i = getelementptr inbounds i8, ptr %21, i64 56, !dbg !1516
  %22 = load ptr, ptr %cache.i, align 8, !dbg !1516, !tbaa !1136
  %call.i30 = call ptr @cache_alloc(ptr noundef %22) #16, !dbg !1517
  tail call void @llvm.dbg.value(metadata ptr %call.i30, metadata !1134, metadata !DIExpression()), !dbg !1514
  %cmp.i31 = icmp eq ptr %call.i30, null, !dbg !1518
  br i1 %cmp.i31, label %if.then3, label %if.end6, !dbg !1519

if.then3:                                         ; preds = %if.end
  %call.i.i33 = call i32 @pthread_mutex_lock(ptr noundef nonnull @stats_lock) #16, !dbg !1520
  %23 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 3), align 8, !dbg !1522, !tbaa !1148
  %inc.i34 = add i64 %23, 1, !dbg !1522
  store i64 %inc.i34, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 3), align 8, !dbg !1522, !tbaa !1148
  %call.i2.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull @stats_lock) #16, !dbg !1523
  tail call void @llvm.dbg.value(metadata ptr %call.i30, metadata !1392, metadata !DIExpression()), !dbg !1410
  %call4 = call i32 @close(i32 noundef %sfd) #16, !dbg !1525
  %24 = load ptr, ptr @stderr, align 8, !dbg !1528, !tbaa !926
  %25 = call i64 @fwrite(ptr nonnull @.str.12, i64 48, i64 1, ptr %24) #18, !dbg !1529
  br label %cleanup, !dbg !1530

if.end6:                                          ; preds = %if.end
  tail call void @llvm.dbg.value(metadata ptr %call.i30, metadata !1392, metadata !DIExpression()), !dbg !1410
  store i32 %sfd, ptr %call.i30, align 8, !dbg !1531, !tbaa !1163
  %init_state8 = getelementptr inbounds i8, ptr %call.i30, i64 4, !dbg !1532
  store i32 %init_state, ptr %init_state8, align 4, !dbg !1533, !tbaa !1534
  %event_flags9 = getelementptr inbounds i8, ptr %call.i30, i64 8, !dbg !1535
  store i32 %event_flags, ptr %event_flags9, align 8, !dbg !1536, !tbaa !1537
  %read_buffer_size10 = getelementptr inbounds i8, ptr %call.i30, i64 12, !dbg !1538
  store i32 %read_buffer_size, ptr %read_buffer_size10, align 4, !dbg !1539, !tbaa !1540
  %transport11 = getelementptr inbounds i8, ptr %call.i30, i64 16, !dbg !1541
  store i32 %transport, ptr %transport11, align 8, !dbg !1542, !tbaa !1543
  %mode = getelementptr inbounds i8, ptr %call.i30, i64 20, !dbg !1544
  store i32 0, ptr %mode, align 4, !dbg !1545, !tbaa !1159
  %ssl12 = getelementptr inbounds i8, ptr %call.i30, i64 32, !dbg !1546
  store ptr %ssl, ptr %ssl12, align 8, !dbg !1547, !tbaa !1548
  %conntag13 = getelementptr inbounds i8, ptr %call.i30, i64 40, !dbg !1549
  store i64 %conntag, ptr %conntag13, align 8, !dbg !1550, !tbaa !1551
  %bproto14 = getelementptr inbounds i8, ptr %call.i30, i64 48, !dbg !1552
  store i32 %bproto, ptr %bproto14, align 8, !dbg !1553, !tbaa !1554
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1164, metadata !DIExpression(), metadata !1394, metadata ptr %u.i, metadata !DIExpression()), !dbg !1555
  tail call void @llvm.dbg.value(metadata ptr %thread.0, metadata !1169, metadata !DIExpression()), !dbg !1555
  tail call void @llvm.dbg.value(metadata ptr %call.i30, metadata !1170, metadata !DIExpression()), !dbg !1555
  %26 = load ptr, ptr %ev_queue, align 8, !dbg !1557, !tbaa !1116
  tail call void @llvm.dbg.value(metadata ptr %26, metadata !1174, metadata !DIExpression()), !dbg !1558
  tail call void @llvm.dbg.value(metadata ptr %call.i30, metadata !1179, metadata !DIExpression()), !dbg !1558
  %lock.i.i = getelementptr inbounds i8, ptr %26, i64 16, !dbg !1560
  %call.i.i35 = call i32 @pthread_mutex_lock(ptr noundef nonnull %lock.i.i) #16, !dbg !1561
  %i_next.i.i = getelementptr inbounds i8, ptr %call.i30, i64 64, !dbg !1562
  store ptr null, ptr %i_next.i.i, align 8, !dbg !1562, !tbaa !1186
  %stqh_last.i.i = getelementptr inbounds i8, ptr %26, i64 8, !dbg !1562
  %27 = load ptr, ptr %stqh_last.i.i, align 8, !dbg !1562, !tbaa !1187
  store ptr %call.i30, ptr %27, align 8, !dbg !1562, !tbaa !926
  store ptr %i_next.i.i, ptr %stqh_last.i.i, align 8, !dbg !1562, !tbaa !1187
  %call6.i.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull %lock.i.i) #16, !dbg !1563
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %u.i) #16, !dbg !1564
  store i64 1, ptr %u.i, align 8, !dbg !1565, !tbaa !1191, !DIAssignID !1566
  tail call void @llvm.dbg.assign(metadata i64 1, metadata !1164, metadata !DIExpression(), metadata !1566, metadata ptr %u.i, metadata !DIExpression()), !dbg !1555
  %notify_event_fd.i = getelementptr inbounds i8, ptr %thread.0, i64 144, !dbg !1567
  %28 = load i32, ptr %notify_event_fd.i, align 8, !dbg !1567, !tbaa !1195
  %call.i36 = call i64 @write(i32 noundef %28, ptr noundef nonnull %u.i, i64 noundef 8) #16, !dbg !1568
  %cmp.not.i = icmp eq i64 %call.i36, 8, !dbg !1569
  br i1 %cmp.not.i, label %notify_worker.exit, label %if.then.i37, !dbg !1570

if.then.i37:                                      ; preds = %if.end6
  call void @perror(ptr noundef nonnull @.str.13) #18, !dbg !1571
  br label %notify_worker.exit, !dbg !1572

notify_worker.exit:                               ; preds = %if.end6, %if.then.i37
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %u.i) #16, !dbg !1573
  br label %cleanup, !dbg !1574

cleanup:                                          ; preds = %notify_worker.exit, %if.then3
  ret void, !dbg !1574
}

declare !dbg !1575 i32 @close(i32 noundef) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @redispatch_conn(ptr nocapture noundef readonly %c) local_unnamed_addr #0 !dbg !1579 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1583, metadata !DIExpression()), !dbg !1584
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !1585
  %0 = load ptr, ptr %thread, align 8, !dbg !1585, !tbaa !1586
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1591
  %1 = load i32, ptr %sfd, align 8, !dbg !1591, !tbaa !1592
  tail call fastcc void @notify_worker_fd(ptr noundef %0, i32 noundef %1, i32 noundef 3), !dbg !1593
  ret void, !dbg !1594
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @timeout_conn(ptr nocapture noundef readonly %c) local_unnamed_addr #0 !dbg !1595 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1597, metadata !DIExpression()), !dbg !1598
  %thread = getelementptr inbounds i8, ptr %c, i64 456, !dbg !1599
  %0 = load ptr, ptr %thread, align 8, !dbg !1599, !tbaa !1586
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1600
  %1 = load i32, ptr %sfd, align 8, !dbg !1600, !tbaa !1592
  tail call fastcc void @notify_worker_fd(ptr noundef %0, i32 noundef %1, i32 noundef 2), !dbg !1601
  ret void, !dbg !1602
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @return_io_pending(ptr noundef %io) local_unnamed_addr #0 !dbg !1603 {
entry:
  %u = alloca i64, align 8, !DIAssignID !1611
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1608, metadata !DIExpression(), metadata !1611, metadata ptr %u, metadata !DIExpression()), !dbg !1612
  tail call void @llvm.dbg.value(metadata ptr %io, metadata !1605, metadata !DIExpression()), !dbg !1613
  tail call void @llvm.dbg.value(metadata i8 0, metadata !1606, metadata !DIExpression()), !dbg !1613
  %thread = getelementptr inbounds i8, ptr %io, i64 8, !dbg !1614
  %0 = load ptr, ptr %thread, align 8, !dbg !1614, !tbaa !1615
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1607, metadata !DIExpression()), !dbg !1613
  %ion_lock = getelementptr inbounds i8, ptr %0, i64 288, !dbg !1617
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %ion_lock) #16, !dbg !1618
  %ion_head = getelementptr inbounds i8, ptr %0, i64 328, !dbg !1619
  %1 = load ptr, ptr %ion_head, align 8, !dbg !1619, !tbaa !1621
  %cmp = icmp eq ptr %1, null, !dbg !1619
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !1606, metadata !DIExpression()), !dbg !1613
  %iop_next = getelementptr inbounds i8, ptr %io, i64 48, !dbg !1622
  store ptr null, ptr %iop_next, align 8, !dbg !1622, !tbaa !1624
  %stqh_last = getelementptr inbounds i8, ptr %0, i64 336, !dbg !1622
  %2 = load ptr, ptr %stqh_last, align 8, !dbg !1622, !tbaa !1625
  store ptr %io, ptr %2, align 8, !dbg !1622, !tbaa !926
  store ptr %iop_next, ptr %stqh_last, align 8, !dbg !1622, !tbaa !1625
  %call7 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %ion_lock) #16, !dbg !1626
  br i1 %cmp, label %if.then8, label %if.end13, !dbg !1627

if.then8:                                         ; preds = %entry
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %u) #16, !dbg !1628
  store i64 1, ptr %u, align 8, !dbg !1629, !tbaa !1191, !DIAssignID !1630
  tail call void @llvm.dbg.assign(metadata i64 1, metadata !1608, metadata !DIExpression(), metadata !1630, metadata ptr %u, metadata !DIExpression()), !dbg !1612
  %notify_event_fd = getelementptr inbounds i8, ptr %0, i64 280, !dbg !1631
  %3 = load i32, ptr %notify_event_fd, align 8, !dbg !1631, !tbaa !1633
  %call9 = call i64 @write(i32 noundef %3, ptr noundef nonnull %u, i64 noundef 8) #16, !dbg !1634
  %cmp10.not = icmp eq i64 %call9, 8, !dbg !1635
  br i1 %cmp10.not, label %if.end12, label %if.then11, !dbg !1636

if.then11:                                        ; preds = %if.then8
  tail call void @perror(ptr noundef nonnull @.str.13) #18, !dbg !1637
  br label %if.end12, !dbg !1639

if.end12:                                         ; preds = %if.then11, %if.then8
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %u) #16, !dbg !1640
  br label %if.end13, !dbg !1641

if.end13:                                         ; preds = %if.end12, %entry
  ret void, !dbg !1642
}

; Function Attrs: nofree
declare !dbg !1643 noundef i64 @write(i32 noundef, ptr nocapture noundef readonly, i64 noundef) local_unnamed_addr #6

; Function Attrs: cold nofree nounwind
declare !dbg !1646 void @perror(ptr nocapture noundef readonly) local_unnamed_addr #7

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @sidethread_conn_close(ptr nocapture noundef %c) local_unnamed_addr #0 !dbg !1649 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1651, metadata !DIExpression()), !dbg !1652
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1653, !tbaa !1210
  %cmp = icmp sgt i32 %0, 1, !dbg !1655
  br i1 %cmp, label %if.then, label %if.end, !dbg !1656

if.then:                                          ; preds = %entry
  %1 = load ptr, ptr @stderr, align 8, !dbg !1657, !tbaa !926
  %sfd = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1658
  %2 = load i32, ptr %sfd, align 8, !dbg !1658, !tbaa !1592
  %call = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %1, ptr noundef nonnull @.str.14, i32 noundef %2) #17, !dbg !1659
  br label %if.end, !dbg !1659

if.end:                                           ; preds = %if.then, %entry
  %state = getelementptr inbounds i8, ptr %c, i64 20, !dbg !1660
  store i32 8, ptr %state, align 4, !dbg !1661, !tbaa !1662
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1583, metadata !DIExpression()), !dbg !1663
  %thread.i = getelementptr inbounds i8, ptr %c, i64 456, !dbg !1665
  %3 = load ptr, ptr %thread.i, align 8, !dbg !1665, !tbaa !1586
  %sfd.i = getelementptr inbounds i8, ptr %c, i64 8, !dbg !1666
  %4 = load i32, ptr %sfd.i, align 8, !dbg !1666, !tbaa !1592
  tail call fastcc void @notify_worker_fd(ptr noundef %3, i32 noundef %4, i32 noundef 3), !dbg !1667
  ret void, !dbg !1668
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local ptr @item_alloc(ptr noundef %key, i64 noundef %nkey, i32 noundef %flags, i32 noundef %exptime, i32 noundef %nbytes) local_unnamed_addr #0 !dbg !1669 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !1674, metadata !DIExpression()), !dbg !1680
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !1675, metadata !DIExpression()), !dbg !1680
  tail call void @llvm.dbg.value(metadata i32 %flags, metadata !1676, metadata !DIExpression()), !dbg !1680
  tail call void @llvm.dbg.value(metadata i32 %exptime, metadata !1677, metadata !DIExpression()), !dbg !1680
  tail call void @llvm.dbg.value(metadata i32 %nbytes, metadata !1678, metadata !DIExpression()), !dbg !1680
  %call = tail call ptr @do_item_alloc(ptr noundef %key, i64 noundef %nkey, i32 noundef %flags, i32 noundef %exptime, i32 noundef %nbytes) #16, !dbg !1681
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !1679, metadata !DIExpression()), !dbg !1680
  ret ptr %call, !dbg !1682
}

declare !dbg !1683 ptr @do_item_alloc(ptr noundef, i64 noundef, i32 noundef, i32 noundef, i32 noundef) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local ptr @item_get(ptr noundef %key, i64 noundef %nkey, ptr noundef %t, i1 noundef zeroext %do_update) local_unnamed_addr #0 !dbg !1690 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !1694, metadata !DIExpression()), !dbg !1700
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !1695, metadata !DIExpression()), !dbg !1700
  tail call void @llvm.dbg.value(metadata ptr %t, metadata !1696, metadata !DIExpression()), !dbg !1700
  tail call void @llvm.dbg.value(metadata i1 %do_update, metadata !1697, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1700
  %0 = load ptr, ptr @hash, align 8, !dbg !1701, !tbaa !926
  %call = tail call i32 %0(ptr noundef %key, i64 noundef %nkey) #16, !dbg !1701
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !1699, metadata !DIExpression()), !dbg !1700
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !923, metadata !DIExpression()), !dbg !1702
  %1 = load ptr, ptr @item_locks, align 8, !dbg !1704, !tbaa !926
  %conv.i = zext i32 %call to i64, !dbg !1704
  %2 = load i32, ptr @item_lock_hashpower, align 4, !dbg !1704, !tbaa !930
  %sh_prom.i = zext nneg i32 %2 to i64, !dbg !1704
  %notmask.i = shl nsw i64 -1, %sh_prom.i, !dbg !1704
  %sub.i = xor i64 %notmask.i, -1, !dbg !1704
  %and.i = and i64 %sub.i, %conv.i, !dbg !1704
  %arrayidx.i = getelementptr inbounds %union.pthread_mutex_t, ptr %1, i64 %and.i, !dbg !1704
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx.i) #16, !dbg !1704
  %call1 = tail call ptr @do_item_get(ptr noundef %key, i64 noundef %nkey, i32 noundef %call, ptr noundef %t, i1 noundef zeroext %do_update) #16, !dbg !1705
  tail call void @llvm.dbg.value(metadata ptr %call1, metadata !1698, metadata !DIExpression()), !dbg !1700
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !964, metadata !DIExpression()), !dbg !1706
  %3 = load ptr, ptr @item_locks, align 8, !dbg !1708, !tbaa !926
  %4 = load i32, ptr @item_lock_hashpower, align 4, !dbg !1708, !tbaa !930
  %sh_prom.i7 = zext nneg i32 %4 to i64, !dbg !1708
  %notmask.i8 = shl nsw i64 -1, %sh_prom.i7, !dbg !1708
  %sub.i9 = xor i64 %notmask.i8, -1, !dbg !1708
  %and.i10 = and i64 %sub.i9, %conv.i, !dbg !1708
  %arrayidx.i11 = getelementptr inbounds %union.pthread_mutex_t, ptr %3, i64 %and.i10, !dbg !1708
  %call.i12 = tail call i32 @pthread_mutex_unlock(ptr noundef %arrayidx.i11) #16, !dbg !1708
  ret ptr %call1, !dbg !1709
}

declare !dbg !1710 ptr @do_item_get(ptr noundef, i64 noundef, i32 noundef, ptr noundef, i1 noundef zeroext) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local ptr @item_get_locked(ptr noundef %key, i64 noundef %nkey, ptr noundef %t, i1 noundef zeroext %do_update, ptr nocapture noundef %hv) local_unnamed_addr #0 !dbg !1714 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !1719, metadata !DIExpression()), !dbg !1725
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !1720, metadata !DIExpression()), !dbg !1725
  tail call void @llvm.dbg.value(metadata ptr %t, metadata !1721, metadata !DIExpression()), !dbg !1725
  tail call void @llvm.dbg.value(metadata i1 %do_update, metadata !1722, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1725
  tail call void @llvm.dbg.value(metadata ptr %hv, metadata !1723, metadata !DIExpression()), !dbg !1725
  %0 = load ptr, ptr @hash, align 8, !dbg !1726, !tbaa !926
  %call = tail call i32 %0(ptr noundef %key, i64 noundef %nkey) #16, !dbg !1726
  store i32 %call, ptr %hv, align 4, !dbg !1727, !tbaa !930
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !923, metadata !DIExpression()), !dbg !1728
  %1 = load ptr, ptr @item_locks, align 8, !dbg !1730, !tbaa !926
  %conv.i = zext i32 %call to i64, !dbg !1730
  %2 = load i32, ptr @item_lock_hashpower, align 4, !dbg !1730, !tbaa !930
  %sh_prom.i = zext nneg i32 %2 to i64, !dbg !1730
  %notmask.i = shl nsw i64 -1, %sh_prom.i, !dbg !1730
  %sub.i = xor i64 %notmask.i, -1, !dbg !1730
  %and.i = and i64 %sub.i, %conv.i, !dbg !1730
  %arrayidx.i = getelementptr inbounds %union.pthread_mutex_t, ptr %1, i64 %and.i, !dbg !1730
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx.i) #16, !dbg !1730
  %3 = load i32, ptr %hv, align 4, !dbg !1731, !tbaa !930
  %call1 = tail call ptr @do_item_get(ptr noundef %key, i64 noundef %nkey, i32 noundef %3, ptr noundef %t, i1 noundef zeroext %do_update) #16, !dbg !1732
  tail call void @llvm.dbg.value(metadata ptr %call1, metadata !1724, metadata !DIExpression()), !dbg !1725
  ret ptr %call1, !dbg !1733
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local ptr @item_touch(ptr noundef %key, i64 noundef %nkey, i32 noundef %exptime, ptr noundef %t) local_unnamed_addr #0 !dbg !1734 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !1738, metadata !DIExpression()), !dbg !1744
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !1739, metadata !DIExpression()), !dbg !1744
  tail call void @llvm.dbg.value(metadata i32 %exptime, metadata !1740, metadata !DIExpression()), !dbg !1744
  tail call void @llvm.dbg.value(metadata ptr %t, metadata !1741, metadata !DIExpression()), !dbg !1744
  %0 = load ptr, ptr @hash, align 8, !dbg !1745, !tbaa !926
  %call = tail call i32 %0(ptr noundef %key, i64 noundef %nkey) #16, !dbg !1745
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !1743, metadata !DIExpression()), !dbg !1744
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !923, metadata !DIExpression()), !dbg !1746
  %1 = load ptr, ptr @item_locks, align 8, !dbg !1748, !tbaa !926
  %conv.i = zext i32 %call to i64, !dbg !1748
  %2 = load i32, ptr @item_lock_hashpower, align 4, !dbg !1748, !tbaa !930
  %sh_prom.i = zext nneg i32 %2 to i64, !dbg !1748
  %notmask.i = shl nsw i64 -1, %sh_prom.i, !dbg !1748
  %sub.i = xor i64 %notmask.i, -1, !dbg !1748
  %and.i = and i64 %sub.i, %conv.i, !dbg !1748
  %arrayidx.i = getelementptr inbounds %union.pthread_mutex_t, ptr %1, i64 %and.i, !dbg !1748
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx.i) #16, !dbg !1748
  %call1 = tail call ptr @do_item_touch(ptr noundef %key, i64 noundef %nkey, i32 noundef %exptime, i32 noundef %call, ptr noundef %t) #16, !dbg !1749
  tail call void @llvm.dbg.value(metadata ptr %call1, metadata !1742, metadata !DIExpression()), !dbg !1744
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !964, metadata !DIExpression()), !dbg !1750
  %3 = load ptr, ptr @item_locks, align 8, !dbg !1752, !tbaa !926
  %4 = load i32, ptr @item_lock_hashpower, align 4, !dbg !1752, !tbaa !930
  %sh_prom.i7 = zext nneg i32 %4 to i64, !dbg !1752
  %notmask.i8 = shl nsw i64 -1, %sh_prom.i7, !dbg !1752
  %sub.i9 = xor i64 %notmask.i8, -1, !dbg !1752
  %and.i10 = and i64 %sub.i9, %conv.i, !dbg !1752
  %arrayidx.i11 = getelementptr inbounds %union.pthread_mutex_t, ptr %3, i64 %and.i10, !dbg !1752
  %call.i12 = tail call i32 @pthread_mutex_unlock(ptr noundef %arrayidx.i11) #16, !dbg !1752
  ret ptr %call1, !dbg !1753
}

declare !dbg !1754 ptr @do_item_touch(ptr noundef, i64 noundef, i32 noundef, i32 noundef, ptr noundef) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @item_remove(ptr noundef %item) local_unnamed_addr #0 !dbg !1757 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %item, metadata !1761, metadata !DIExpression()), !dbg !1763
  %0 = load ptr, ptr @hash, align 8, !dbg !1764, !tbaa !926
  %data = getelementptr inbounds i8, ptr %item, i64 48, !dbg !1765
  %it_flags = getelementptr inbounds i8, ptr %item, i64 38, !dbg !1765
  %1 = load i16, ptr %it_flags, align 2, !dbg !1765, !tbaa !1766
  %2 = shl i16 %1, 2, !dbg !1765
  %3 = and i16 %2, 8, !dbg !1765
  %cond = zext nneg i16 %3 to i64, !dbg !1765
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %cond, !dbg !1765
  %nkey = getelementptr inbounds i8, ptr %item, i64 41, !dbg !1767
  %4 = load i8, ptr %nkey, align 1, !dbg !1767, !tbaa !1768
  %conv1 = zext i8 %4 to i64, !dbg !1769
  %call = tail call i32 %0(ptr noundef nonnull %add.ptr, i64 noundef %conv1) #16, !dbg !1764
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !1762, metadata !DIExpression()), !dbg !1763
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !923, metadata !DIExpression()), !dbg !1770
  %5 = load ptr, ptr @item_locks, align 8, !dbg !1772, !tbaa !926
  %conv.i = zext i32 %call to i64, !dbg !1772
  %6 = load i32, ptr @item_lock_hashpower, align 4, !dbg !1772, !tbaa !930
  %sh_prom.i = zext nneg i32 %6 to i64, !dbg !1772
  %notmask.i = shl nsw i64 -1, %sh_prom.i, !dbg !1772
  %sub.i = xor i64 %notmask.i, -1, !dbg !1772
  %and.i = and i64 %sub.i, %conv.i, !dbg !1772
  %arrayidx.i = getelementptr inbounds %union.pthread_mutex_t, ptr %5, i64 %and.i, !dbg !1772
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx.i) #16, !dbg !1772
  tail call void @do_item_remove(ptr noundef %item) #16, !dbg !1773
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !964, metadata !DIExpression()), !dbg !1774
  %7 = load ptr, ptr @item_locks, align 8, !dbg !1776, !tbaa !926
  %8 = load i32, ptr @item_lock_hashpower, align 4, !dbg !1776, !tbaa !930
  %sh_prom.i7 = zext nneg i32 %8 to i64, !dbg !1776
  %notmask.i8 = shl nsw i64 -1, %sh_prom.i7, !dbg !1776
  %sub.i9 = xor i64 %notmask.i8, -1, !dbg !1776
  %and.i10 = and i64 %sub.i9, %conv.i, !dbg !1776
  %arrayidx.i11 = getelementptr inbounds %union.pthread_mutex_t, ptr %7, i64 %and.i10, !dbg !1776
  %call.i12 = tail call i32 @pthread_mutex_unlock(ptr noundef %arrayidx.i11) #16, !dbg !1776
  ret void, !dbg !1777
}

declare !dbg !1778 void @do_item_remove(ptr noundef) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local i32 @item_replace(ptr noundef %old_it, ptr noundef %new_it, i32 noundef %hv, i64 noundef %cas_in) local_unnamed_addr #0 !dbg !1779 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %old_it, metadata !1784, metadata !DIExpression()), !dbg !1788
  tail call void @llvm.dbg.value(metadata ptr %new_it, metadata !1785, metadata !DIExpression()), !dbg !1788
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !1786, metadata !DIExpression()), !dbg !1788
  tail call void @llvm.dbg.value(metadata i64 %cas_in, metadata !1787, metadata !DIExpression()), !dbg !1788
  %call = tail call i32 @do_item_replace(ptr noundef %old_it, ptr noundef %new_it, i32 noundef %hv, i64 noundef %cas_in) #16, !dbg !1789
  ret i32 %call, !dbg !1790
}

declare !dbg !1791 i32 @do_item_replace(ptr noundef, ptr noundef, i32 noundef, i64 noundef) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @item_unlink(ptr noundef %item) local_unnamed_addr #0 !dbg !1792 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %item, metadata !1794, metadata !DIExpression()), !dbg !1796
  %0 = load ptr, ptr @hash, align 8, !dbg !1797, !tbaa !926
  %data = getelementptr inbounds i8, ptr %item, i64 48, !dbg !1798
  %it_flags = getelementptr inbounds i8, ptr %item, i64 38, !dbg !1798
  %1 = load i16, ptr %it_flags, align 2, !dbg !1798, !tbaa !1766
  %2 = shl i16 %1, 2, !dbg !1798
  %3 = and i16 %2, 8, !dbg !1798
  %cond = zext nneg i16 %3 to i64, !dbg !1798
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %cond, !dbg !1798
  %nkey = getelementptr inbounds i8, ptr %item, i64 41, !dbg !1799
  %4 = load i8, ptr %nkey, align 1, !dbg !1799, !tbaa !1768
  %conv1 = zext i8 %4 to i64, !dbg !1800
  %call = tail call i32 %0(ptr noundef nonnull %add.ptr, i64 noundef %conv1) #16, !dbg !1797
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !1795, metadata !DIExpression()), !dbg !1796
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !923, metadata !DIExpression()), !dbg !1801
  %5 = load ptr, ptr @item_locks, align 8, !dbg !1803, !tbaa !926
  %conv.i = zext i32 %call to i64, !dbg !1803
  %6 = load i32, ptr @item_lock_hashpower, align 4, !dbg !1803, !tbaa !930
  %sh_prom.i = zext nneg i32 %6 to i64, !dbg !1803
  %notmask.i = shl nsw i64 -1, %sh_prom.i, !dbg !1803
  %sub.i = xor i64 %notmask.i, -1, !dbg !1803
  %and.i = and i64 %sub.i, %conv.i, !dbg !1803
  %arrayidx.i = getelementptr inbounds %union.pthread_mutex_t, ptr %5, i64 %and.i, !dbg !1803
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx.i) #16, !dbg !1803
  tail call void @do_item_unlink(ptr noundef %item, i32 noundef %call) #16, !dbg !1804
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !964, metadata !DIExpression()), !dbg !1805
  %7 = load ptr, ptr @item_locks, align 8, !dbg !1807, !tbaa !926
  %8 = load i32, ptr @item_lock_hashpower, align 4, !dbg !1807, !tbaa !930
  %sh_prom.i8 = zext nneg i32 %8 to i64, !dbg !1807
  %notmask.i9 = shl nsw i64 -1, %sh_prom.i8, !dbg !1807
  %sub.i10 = xor i64 %notmask.i9, -1, !dbg !1807
  %and.i11 = and i64 %sub.i10, %conv.i, !dbg !1807
  %arrayidx.i12 = getelementptr inbounds %union.pthread_mutex_t, ptr %7, i64 %and.i11, !dbg !1807
  %call.i13 = tail call i32 @pthread_mutex_unlock(ptr noundef %arrayidx.i12) #16, !dbg !1807
  ret void, !dbg !1808
}

declare !dbg !1809 void @do_item_unlink(ptr noundef, i32 noundef) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local i32 @add_delta(ptr noundef %t, ptr noundef %key, i64 noundef %nkey, i1 noundef zeroext %incr, i64 noundef %delta, ptr noundef %buf, ptr noundef %cas) local_unnamed_addr #0 !dbg !1812 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %t, metadata !1821, metadata !DIExpression()), !dbg !1830
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !1822, metadata !DIExpression()), !dbg !1830
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !1823, metadata !DIExpression()), !dbg !1830
  tail call void @llvm.dbg.value(metadata i1 %incr, metadata !1824, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1830
  tail call void @llvm.dbg.value(metadata i64 %delta, metadata !1825, metadata !DIExpression()), !dbg !1830
  tail call void @llvm.dbg.value(metadata ptr %buf, metadata !1826, metadata !DIExpression()), !dbg !1830
  tail call void @llvm.dbg.value(metadata ptr %cas, metadata !1827, metadata !DIExpression()), !dbg !1830
  %0 = load ptr, ptr @hash, align 8, !dbg !1831, !tbaa !926
  %call = tail call i32 %0(ptr noundef %key, i64 noundef %nkey) #16, !dbg !1831
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !1829, metadata !DIExpression()), !dbg !1830
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !923, metadata !DIExpression()), !dbg !1832
  %1 = load ptr, ptr @item_locks, align 8, !dbg !1834, !tbaa !926
  %conv.i = zext i32 %call to i64, !dbg !1834
  %2 = load i32, ptr @item_lock_hashpower, align 4, !dbg !1834, !tbaa !930
  %sh_prom.i = zext nneg i32 %2 to i64, !dbg !1834
  %notmask.i = shl nsw i64 -1, %sh_prom.i, !dbg !1834
  %sub.i = xor i64 %notmask.i, -1, !dbg !1834
  %and.i = and i64 %sub.i, %conv.i, !dbg !1834
  %arrayidx.i = getelementptr inbounds %union.pthread_mutex_t, ptr %1, i64 %and.i, !dbg !1834
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx.i) #16, !dbg !1834
  %call1 = tail call i32 @do_add_delta(ptr noundef %t, ptr noundef %key, i64 noundef %nkey, i1 noundef zeroext %incr, i64 noundef %delta, ptr noundef %buf, ptr noundef %cas, i32 noundef %call, ptr noundef null) #16, !dbg !1835
  tail call void @llvm.dbg.value(metadata i32 %call1, metadata !1828, metadata !DIExpression()), !dbg !1830
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !964, metadata !DIExpression()), !dbg !1836
  %3 = load ptr, ptr @item_locks, align 8, !dbg !1838, !tbaa !926
  %4 = load i32, ptr @item_lock_hashpower, align 4, !dbg !1838, !tbaa !930
  %sh_prom.i7 = zext nneg i32 %4 to i64, !dbg !1838
  %notmask.i8 = shl nsw i64 -1, %sh_prom.i7, !dbg !1838
  %sub.i9 = xor i64 %notmask.i8, -1, !dbg !1838
  %and.i10 = and i64 %sub.i9, %conv.i, !dbg !1838
  %arrayidx.i11 = getelementptr inbounds %union.pthread_mutex_t, ptr %3, i64 %and.i10, !dbg !1838
  %call.i12 = tail call i32 @pthread_mutex_unlock(ptr noundef %arrayidx.i11) #16, !dbg !1838
  ret i32 %call1, !dbg !1839
}

declare !dbg !1840 i32 @do_add_delta(ptr noundef, ptr noundef, i64 noundef, i1 noundef zeroext, i64 noundef, ptr noundef, ptr noundef, i32 noundef, ptr noundef) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local i32 @store_item(ptr noundef %item, i32 noundef %comm, ptr noundef %t, ptr noundef %nbytes, ptr noundef %cas, i64 noundef %cas_in, i1 noundef zeroext %cas_stale) local_unnamed_addr #0 !dbg !1844 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %item, metadata !1849, metadata !DIExpression()), !dbg !1858
  tail call void @llvm.dbg.value(metadata i32 %comm, metadata !1850, metadata !DIExpression()), !dbg !1858
  tail call void @llvm.dbg.value(metadata ptr %t, metadata !1851, metadata !DIExpression()), !dbg !1858
  tail call void @llvm.dbg.value(metadata ptr %nbytes, metadata !1852, metadata !DIExpression()), !dbg !1858
  tail call void @llvm.dbg.value(metadata ptr %cas, metadata !1853, metadata !DIExpression()), !dbg !1858
  tail call void @llvm.dbg.value(metadata i64 %cas_in, metadata !1854, metadata !DIExpression()), !dbg !1858
  tail call void @llvm.dbg.value(metadata i1 %cas_stale, metadata !1855, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1858
  %0 = load ptr, ptr @hash, align 8, !dbg !1859, !tbaa !926
  %data = getelementptr inbounds i8, ptr %item, i64 48, !dbg !1860
  %it_flags = getelementptr inbounds i8, ptr %item, i64 38, !dbg !1860
  %1 = load i16, ptr %it_flags, align 2, !dbg !1860, !tbaa !1766
  %2 = shl i16 %1, 2, !dbg !1860
  %3 = and i16 %2, 8, !dbg !1860
  %cond = zext nneg i16 %3 to i64, !dbg !1860
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %cond, !dbg !1860
  %nkey = getelementptr inbounds i8, ptr %item, i64 41, !dbg !1861
  %4 = load i8, ptr %nkey, align 1, !dbg !1861, !tbaa !1768
  %conv1 = zext i8 %4 to i64, !dbg !1862
  %call = tail call i32 %0(ptr noundef nonnull %add.ptr, i64 noundef %conv1) #16, !dbg !1859
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !1857, metadata !DIExpression()), !dbg !1858
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !923, metadata !DIExpression()), !dbg !1863
  %5 = load ptr, ptr @item_locks, align 8, !dbg !1865, !tbaa !926
  %conv.i = zext i32 %call to i64, !dbg !1865
  %6 = load i32, ptr @item_lock_hashpower, align 4, !dbg !1865, !tbaa !930
  %sh_prom.i = zext nneg i32 %6 to i64, !dbg !1865
  %notmask.i = shl nsw i64 -1, %sh_prom.i, !dbg !1865
  %sub.i = xor i64 %notmask.i, -1, !dbg !1865
  %and.i = and i64 %sub.i, %conv.i, !dbg !1865
  %arrayidx.i = getelementptr inbounds %union.pthread_mutex_t, ptr %5, i64 %and.i, !dbg !1865
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef %arrayidx.i) #16, !dbg !1865
  %call3 = tail call i32 @do_store_item(ptr noundef %item, i32 noundef %comm, ptr noundef %t, i32 noundef %call, ptr noundef %nbytes, ptr noundef %cas, i64 noundef %cas_in, i1 noundef zeroext %cas_stale) #16, !dbg !1866
  tail call void @llvm.dbg.value(metadata i32 %call3, metadata !1856, metadata !DIExpression()), !dbg !1858
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !964, metadata !DIExpression()), !dbg !1867
  %7 = load ptr, ptr @item_locks, align 8, !dbg !1869, !tbaa !926
  %8 = load i32, ptr @item_lock_hashpower, align 4, !dbg !1869, !tbaa !930
  %sh_prom.i10 = zext nneg i32 %8 to i64, !dbg !1869
  %notmask.i11 = shl nsw i64 -1, %sh_prom.i10, !dbg !1869
  %sub.i12 = xor i64 %notmask.i11, -1, !dbg !1869
  %and.i13 = and i64 %sub.i12, %conv.i, !dbg !1869
  %arrayidx.i14 = getelementptr inbounds %union.pthread_mutex_t, ptr %7, i64 %and.i13, !dbg !1869
  %call.i15 = tail call i32 @pthread_mutex_unlock(ptr noundef %arrayidx.i14) #16, !dbg !1869
  ret i32 %call3, !dbg !1870
}

declare !dbg !1871 i32 @do_store_item(ptr noundef, i32 noundef, ptr noundef, i32 noundef, ptr noundef, ptr noundef, i64 noundef, i1 noundef zeroext) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @STATS_LOCK() local_unnamed_addr #0 !dbg !1144 {
entry:
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @stats_lock) #16, !dbg !1874
  ret void, !dbg !1875
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @STATS_UNLOCK() local_unnamed_addr #0 !dbg !1151 {
entry:
  %call = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @stats_lock) #16, !dbg !1876
  ret void, !dbg !1877
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @threadlocal_stats_reset() local_unnamed_addr #0 !dbg !1878 {
entry:
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1880, metadata !DIExpression()), !dbg !1881
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 13), align 4, !dbg !1882, !tbaa !989
  %cmp137 = icmp sgt i32 %0, 0, !dbg !1885
  br i1 %cmp137, label %for.body, label %for.end, !dbg !1886

for.body:                                         ; preds = %entry, %for.body
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.body ], [ 0, %entry ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1880, metadata !DIExpression()), !dbg !1881
  %1 = load ptr, ptr @threads, align 8, !dbg !1887, !tbaa !926
  %stats = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %1, i64 %indvars.iv, i32 8, !dbg !1889
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #16, !dbg !1890
  %2 = load ptr, ptr @threads, align 8, !dbg !1891, !tbaa !926
  %get_cmds = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv, i32 8, i32 1, !dbg !1891
  %stats99 = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv, i32 8, !dbg !1892
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(6384) %get_cmds, i8 0, i64 6384, i1 false), !dbg !1891
  %call101 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats99) #16, !dbg !1893
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !1894
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !1880, metadata !DIExpression()), !dbg !1881
  %3 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 13), align 4, !dbg !1882, !tbaa !989
  %4 = sext i32 %3 to i64, !dbg !1885
  %cmp = icmp slt i64 %indvars.iv.next, %4, !dbg !1885
  br i1 %cmp, label %for.body, label %for.end, !dbg !1886, !llvm.loop !1895

for.end:                                          ; preds = %for.body, %entry
  ret void, !dbg !1897
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #8

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @threadlocal_stats_aggregate(ptr noundef %stats) local_unnamed_addr #0 !dbg !1898 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %stats, metadata !1903, metadata !DIExpression()), !dbg !1906
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(6448) %stats, i8 0, i64 6448, i1 false), !dbg !1907
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1904, metadata !DIExpression()), !dbg !1906
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 13), align 4, !dbg !1908, !tbaa !989
  %cmp404 = icmp sgt i32 %0, 0, !dbg !1911
  br i1 %cmp404, label %for.body.lr.ph, label %for.end289, !dbg !1912

for.body.lr.ph:                                   ; preds = %entry
  %get_cmds5 = getelementptr inbounds i8, ptr %stats, i64 40
  %get_expired14 = getelementptr inbounds i8, ptr %stats, i64 56
  %touch_cmds24 = getelementptr inbounds i8, ptr %stats, i64 72
  %delete_misses34 = getelementptr inbounds i8, ptr %stats, i64 88
  %decr_misses44 = getelementptr inbounds i8, ptr %stats, i64 104
  %meta_cmds54 = getelementptr inbounds i8, ptr %stats, i64 120
  %bytes_written64 = getelementptr inbounds i8, ptr %stats, i64 136
  %conn_yields74 = getelementptr inbounds i8, ptr %stats, i64 152
  %auth_errors84 = getelementptr inbounds i8, ptr %stats, i64 168
  %response_obj_oom94 = getelementptr inbounds i8, ptr %stats, i64 184
  %response_obj_bytes104 = getelementptr inbounds i8, ptr %stats, i64 200
  %store_too_large114 = getelementptr inbounds i8, ptr %stats, i64 216
  %get_extstore124 = getelementptr inbounds i8, ptr %stats, i64 232
  %get_oom_extstore134 = getelementptr inbounds i8, ptr %stats, i64 248
  %miss_from_extstore144 = getelementptr inbounds i8, ptr %stats, i64 264
  %slab_stats159 = getelementptr inbounds i8, ptr %stats, i64 280
  %lru_hits249 = getelementptr inbounds i8, ptr %stats, i64 4376
  %read_buf_count = getelementptr inbounds i8, ptr %stats, i64 6424
  %read_buf_bytes = getelementptr inbounds i8, ptr %stats, i64 6432
  br label %for.body, !dbg !1912

for.body:                                         ; preds = %for.body.lr.ph, %for.end266
  %indvars.iv411 = phi i64 [ 0, %for.body.lr.ph ], [ %indvars.iv.next412, %for.end266 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv411, metadata !1904, metadata !DIExpression()), !dbg !1906
  %1 = load ptr, ptr @threads, align 8, !dbg !1913, !tbaa !926
  %stats1 = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %1, i64 %indvars.iv411, i32 8, !dbg !1915
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats1) #16, !dbg !1916
  %2 = load ptr, ptr @threads, align 8, !dbg !1917, !tbaa !926
  %get_cmds = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 1, !dbg !1917
  %3 = load <2 x i64>, ptr %get_cmds, align 8, !dbg !1917, !tbaa !1191
  %4 = load <2 x i64>, ptr %get_cmds5, align 8, !dbg !1917, !tbaa !1191
  %5 = add <2 x i64> %4, %3, !dbg !1917
  store <2 x i64> %5, ptr %get_cmds5, align 8, !dbg !1917, !tbaa !1191
  %get_expired = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 3, !dbg !1917
  %6 = load <2 x i64>, ptr %get_expired, align 8, !dbg !1917, !tbaa !1191
  %7 = load <2 x i64>, ptr %get_expired14, align 8, !dbg !1917, !tbaa !1191
  %8 = add <2 x i64> %7, %6, !dbg !1917
  store <2 x i64> %8, ptr %get_expired14, align 8, !dbg !1917, !tbaa !1191
  %touch_cmds = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 5, !dbg !1917
  %9 = load <2 x i64>, ptr %touch_cmds, align 8, !dbg !1917, !tbaa !1191
  %10 = load <2 x i64>, ptr %touch_cmds24, align 8, !dbg !1917, !tbaa !1191
  %11 = add <2 x i64> %10, %9, !dbg !1917
  store <2 x i64> %11, ptr %touch_cmds24, align 8, !dbg !1917, !tbaa !1191
  %delete_misses = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 7, !dbg !1917
  %12 = load <2 x i64>, ptr %delete_misses, align 8, !dbg !1917, !tbaa !1191
  %13 = load <2 x i64>, ptr %delete_misses34, align 8, !dbg !1917, !tbaa !1191
  %14 = add <2 x i64> %13, %12, !dbg !1917
  store <2 x i64> %14, ptr %delete_misses34, align 8, !dbg !1917, !tbaa !1191
  %decr_misses = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 9, !dbg !1917
  %15 = load <2 x i64>, ptr %decr_misses, align 8, !dbg !1917, !tbaa !1191
  %16 = load <2 x i64>, ptr %decr_misses44, align 8, !dbg !1917, !tbaa !1191
  %17 = add <2 x i64> %16, %15, !dbg !1917
  store <2 x i64> %17, ptr %decr_misses44, align 8, !dbg !1917, !tbaa !1191
  %meta_cmds = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 11, !dbg !1917
  %18 = load <2 x i64>, ptr %meta_cmds, align 8, !dbg !1917, !tbaa !1191
  %19 = load <2 x i64>, ptr %meta_cmds54, align 8, !dbg !1917, !tbaa !1191
  %20 = add <2 x i64> %19, %18, !dbg !1917
  store <2 x i64> %20, ptr %meta_cmds54, align 8, !dbg !1917, !tbaa !1191
  %bytes_written = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 13, !dbg !1917
  %21 = load <2 x i64>, ptr %bytes_written, align 8, !dbg !1917, !tbaa !1191
  %22 = load <2 x i64>, ptr %bytes_written64, align 8, !dbg !1917, !tbaa !1191
  %23 = add <2 x i64> %22, %21, !dbg !1917
  store <2 x i64> %23, ptr %bytes_written64, align 8, !dbg !1917, !tbaa !1191
  %conn_yields = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 15, !dbg !1917
  %24 = load <2 x i64>, ptr %conn_yields, align 8, !dbg !1917, !tbaa !1191
  %25 = load <2 x i64>, ptr %conn_yields74, align 8, !dbg !1917, !tbaa !1191
  %26 = add <2 x i64> %25, %24, !dbg !1917
  store <2 x i64> %26, ptr %conn_yields74, align 8, !dbg !1917, !tbaa !1191
  %auth_errors = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 17, !dbg !1917
  %27 = load <2 x i64>, ptr %auth_errors, align 8, !dbg !1917, !tbaa !1191
  %28 = load <2 x i64>, ptr %auth_errors84, align 8, !dbg !1917, !tbaa !1191
  %29 = add <2 x i64> %28, %27, !dbg !1917
  store <2 x i64> %29, ptr %auth_errors84, align 8, !dbg !1917, !tbaa !1191
  %response_obj_oom = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 19, !dbg !1917
  %30 = load <2 x i64>, ptr %response_obj_oom, align 8, !dbg !1917, !tbaa !1191
  %31 = load <2 x i64>, ptr %response_obj_oom94, align 8, !dbg !1917, !tbaa !1191
  %32 = add <2 x i64> %31, %30, !dbg !1917
  store <2 x i64> %32, ptr %response_obj_oom94, align 8, !dbg !1917, !tbaa !1191
  %response_obj_bytes = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 21, !dbg !1917
  %33 = load <2 x i64>, ptr %response_obj_bytes, align 8, !dbg !1917, !tbaa !1191
  %34 = load <2 x i64>, ptr %response_obj_bytes104, align 8, !dbg !1917, !tbaa !1191
  %35 = add <2 x i64> %34, %33, !dbg !1917
  store <2 x i64> %35, ptr %response_obj_bytes104, align 8, !dbg !1917, !tbaa !1191
  %store_too_large = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 23, !dbg !1917
  %36 = load <2 x i64>, ptr %store_too_large, align 8, !dbg !1917, !tbaa !1191
  %37 = load <2 x i64>, ptr %store_too_large114, align 8, !dbg !1917, !tbaa !1191
  %38 = add <2 x i64> %37, %36, !dbg !1917
  store <2 x i64> %38, ptr %store_too_large114, align 8, !dbg !1917, !tbaa !1191
  %get_extstore = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 25, !dbg !1918
  %39 = load <2 x i64>, ptr %get_extstore, align 8, !dbg !1918, !tbaa !1191
  %40 = load <2 x i64>, ptr %get_extstore124, align 8, !dbg !1918, !tbaa !1191
  %41 = add <2 x i64> %40, %39, !dbg !1918
  store <2 x i64> %41, ptr %get_extstore124, align 8, !dbg !1918, !tbaa !1191
  %get_oom_extstore = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 27, !dbg !1918
  %42 = load <2 x i64>, ptr %get_oom_extstore, align 8, !dbg !1918, !tbaa !1191
  %43 = load <2 x i64>, ptr %get_oom_extstore134, align 8, !dbg !1918, !tbaa !1191
  %44 = add <2 x i64> %43, %42, !dbg !1918
  store <2 x i64> %44, ptr %get_oom_extstore134, align 8, !dbg !1918, !tbaa !1191
  %miss_from_extstore = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 29, !dbg !1918
  %45 = load <2 x i64>, ptr %miss_from_extstore, align 8, !dbg !1918, !tbaa !1191
  %46 = load <2 x i64>, ptr %miss_from_extstore144, align 8, !dbg !1918, !tbaa !1191
  %47 = add <2 x i64> %46, %45, !dbg !1918
  store <2 x i64> %47, ptr %miss_from_extstore144, align 8, !dbg !1918, !tbaa !1191
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1905, metadata !DIExpression()), !dbg !1906
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1905, metadata !DIExpression()), !dbg !1906
  br label %for.body153, !dbg !1919

for.body153:                                      ; preds = %for.body, %for.body153
  %indvars.iv = phi i64 [ 0, %for.body ], [ %indvars.iv.next, %for.body153 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1905, metadata !DIExpression()), !dbg !1906
  %arrayidx158 = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 31, i64 %indvars.iv, !dbg !1921
  %arrayidx161 = getelementptr inbounds [64 x %struct.slab_stats], ptr %slab_stats159, i64 0, i64 %indvars.iv, !dbg !1921
  %48 = load <2 x i64>, ptr %arrayidx158, align 8, !dbg !1921, !tbaa !1191
  %49 = load <2 x i64>, ptr %arrayidx161, align 8, !dbg !1921, !tbaa !1191
  %50 = add <2 x i64> %49, %48, !dbg !1921
  store <2 x i64> %50, ptr %arrayidx161, align 8, !dbg !1921, !tbaa !1191
  %touch_hits = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 31, i64 %indvars.iv, i32 2, !dbg !1921
  %touch_hits184 = getelementptr inbounds i8, ptr %arrayidx161, i64 16, !dbg !1921
  %51 = load <2 x i64>, ptr %touch_hits, align 8, !dbg !1921, !tbaa !1191
  %52 = load <2 x i64>, ptr %touch_hits184, align 8, !dbg !1921, !tbaa !1191
  %53 = add <2 x i64> %52, %51, !dbg !1921
  store <2 x i64> %53, ptr %touch_hits184, align 8, !dbg !1921, !tbaa !1191
  %cas_hits = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 31, i64 %indvars.iv, i32 4, !dbg !1921
  %cas_hits206 = getelementptr inbounds i8, ptr %arrayidx161, i64 32, !dbg !1921
  %54 = load <2 x i64>, ptr %cas_hits, align 8, !dbg !1921, !tbaa !1191
  %55 = load <2 x i64>, ptr %cas_hits206, align 8, !dbg !1921, !tbaa !1191
  %56 = add <2 x i64> %55, %54, !dbg !1921
  store <2 x i64> %56, ptr %cas_hits206, align 8, !dbg !1921, !tbaa !1191
  %incr_hits = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 31, i64 %indvars.iv, i32 6, !dbg !1921
  %incr_hits228 = getelementptr inbounds i8, ptr %arrayidx161, i64 48, !dbg !1921
  %57 = load <2 x i64>, ptr %incr_hits, align 8, !dbg !1921, !tbaa !1191
  %58 = load <2 x i64>, ptr %incr_hits228, align 8, !dbg !1921, !tbaa !1191
  %59 = add <2 x i64> %58, %57, !dbg !1921
  store <2 x i64> %59, ptr %incr_hits228, align 8, !dbg !1921, !tbaa !1191
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !1924
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !1905, metadata !DIExpression()), !dbg !1906
  %exitcond.not = icmp eq i64 %indvars.iv.next, 64, !dbg !1925
  br i1 %exitcond.not, label %for.body243, label %for.body153, !dbg !1919, !llvm.loop !1926

for.body243:                                      ; preds = %for.body153, %for.body243
  %indvars.iv407 = phi i64 [ %indvars.iv.next408, %for.body243 ], [ 0, %for.body153 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv407, metadata !1905, metadata !DIExpression()), !dbg !1906
  %arrayidx248 = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, i32 32, i64 %indvars.iv407, !dbg !1928
  %60 = load i64, ptr %arrayidx248, align 8, !dbg !1928, !tbaa !1191
  %arrayidx251 = getelementptr inbounds [256 x i64], ptr %lru_hits249, i64 0, i64 %indvars.iv407, !dbg !1932
  %61 = load i64, ptr %arrayidx251, align 8, !dbg !1933, !tbaa !1191
  %add252 = add i64 %61, %60, !dbg !1933
  store i64 %add252, ptr %arrayidx251, align 8, !dbg !1933, !tbaa !1191
  %62 = load i64, ptr %arrayidx248, align 8, !dbg !1934, !tbaa !1191
  %and = and i64 %indvars.iv407, 63, !dbg !1935
  %get_hits262 = getelementptr inbounds [64 x %struct.slab_stats], ptr %slab_stats159, i64 0, i64 %and, i32 1, !dbg !1936
  %63 = load i64, ptr %get_hits262, align 8, !dbg !1937, !tbaa !1938
  %add263 = add i64 %63, %62, !dbg !1937
  store i64 %add263, ptr %get_hits262, align 8, !dbg !1937, !tbaa !1938
  %indvars.iv.next408 = add nuw nsw i64 %indvars.iv407, 1, !dbg !1940
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next408, metadata !1905, metadata !DIExpression()), !dbg !1906
  %exitcond410.not = icmp eq i64 %indvars.iv.next408, 256, !dbg !1941
  br i1 %exitcond410.not, label %for.end266, label %for.body243, !dbg !1942, !llvm.loop !1943

for.end266:                                       ; preds = %for.body243
  %rbuf_cache = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 11, !dbg !1945
  %64 = load ptr, ptr %rbuf_cache, align 8, !dbg !1945, !tbaa !1946
  %total = getelementptr inbounds i8, ptr %64, i64 76, !dbg !1947
  %65 = load i64, ptr %read_buf_count, align 8, !dbg !1948, !tbaa !1949
  %66 = load <2 x i32>, ptr %total, align 4, !dbg !1947, !tbaa !930
  %67 = extractelement <2 x i32> %66, i64 0, !dbg !1950
  %conv = sext i32 %67 to i64, !dbg !1950
  %add269 = add i64 %65, %conv, !dbg !1948
  store i64 %add269, ptr %read_buf_count, align 8, !dbg !1948, !tbaa !1949
  %68 = shl nsw <2 x i32> %66, <i32 14, i32 14>, !dbg !1951
  %69 = sext <2 x i32> %68 to <2 x i64>, !dbg !1952
  %70 = load <2 x i64>, ptr %read_buf_bytes, align 8, !dbg !1953, !tbaa !1191
  %71 = add <2 x i64> %70, %69, !dbg !1953
  store <2 x i64> %71, ptr %read_buf_bytes, align 8, !dbg !1953, !tbaa !1191
  %stats284 = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %2, i64 %indvars.iv411, i32 8, !dbg !1954
  %call286 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats284) #16, !dbg !1955
  %indvars.iv.next412 = add nuw nsw i64 %indvars.iv411, 1, !dbg !1956
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next412, metadata !1904, metadata !DIExpression()), !dbg !1906
  %72 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 13), align 4, !dbg !1908, !tbaa !989
  %73 = sext i32 %72 to i64, !dbg !1911
  %cmp = icmp slt i64 %indvars.iv.next412, %73, !dbg !1911
  br i1 %cmp, label %for.body, label %for.end289, !dbg !1912, !llvm.loop !1957

for.end289:                                       ; preds = %for.end266, %entry
  ret void, !dbg !1959
}

; Function Attrs: nofree norecurse nosync nounwind sanitize_thread memory(argmem: readwrite) uwtable
define dso_local void @slab_stats_aggregate(ptr nocapture noundef readonly %stats, ptr nocapture noundef writeonly %out) local_unnamed_addr #9 !dbg !1960 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %stats, metadata !1965, metadata !DIExpression()), !dbg !1968
  tail call void @llvm.dbg.value(metadata ptr %out, metadata !1966, metadata !DIExpression()), !dbg !1968
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %out, i8 0, i64 64, i1 false), !dbg !1969
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1967, metadata !DIExpression()), !dbg !1968
  %slab_stats = getelementptr inbounds i8, ptr %stats, i64 280
  %touch_hits10 = getelementptr inbounds i8, ptr %out, i64 16
  %cas_hits20 = getelementptr inbounds i8, ptr %out, i64 32
  %incr_hits30 = getelementptr inbounds i8, ptr %out, i64 48
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1967, metadata !DIExpression()), !dbg !1968
  br label %for.body, !dbg !1970

for.body:                                         ; preds = %entry, %for.body
  %indvars.iv = phi i64 [ 0, %entry ], [ %indvars.iv.next, %for.body ]
  %0 = phi <2 x i64> [ zeroinitializer, %entry ], [ %5, %for.body ]
  %1 = phi <2 x i64> [ zeroinitializer, %entry ], [ %7, %for.body ]
  %2 = phi <2 x i64> [ zeroinitializer, %entry ], [ %9, %for.body ]
  %3 = phi <2 x i64> [ zeroinitializer, %entry ], [ %11, %for.body ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1967, metadata !DIExpression()), !dbg !1968
  %arrayidx = getelementptr inbounds [64 x %struct.slab_stats], ptr %slab_stats, i64 0, i64 %indvars.iv, !dbg !1972
  %4 = load <2 x i64>, ptr %arrayidx, align 8, !dbg !1972, !tbaa !1191
  %5 = add <2 x i64> %0, %4, !dbg !1972
  store <2 x i64> %5, ptr %out, align 8, !dbg !1972, !tbaa !1191
  %touch_hits = getelementptr inbounds i8, ptr %arrayidx, i64 16, !dbg !1972
  %6 = load <2 x i64>, ptr %touch_hits, align 8, !dbg !1972, !tbaa !1191
  %7 = add <2 x i64> %1, %6, !dbg !1972
  store <2 x i64> %7, ptr %touch_hits10, align 8, !dbg !1972, !tbaa !1191
  %cas_hits = getelementptr inbounds i8, ptr %arrayidx, i64 32, !dbg !1972
  %8 = load <2 x i64>, ptr %cas_hits, align 8, !dbg !1972, !tbaa !1191
  %9 = add <2 x i64> %2, %8, !dbg !1972
  store <2 x i64> %9, ptr %cas_hits20, align 8, !dbg !1972, !tbaa !1191
  %incr_hits = getelementptr inbounds i8, ptr %arrayidx, i64 48, !dbg !1972
  %10 = load <2 x i64>, ptr %incr_hits, align 8, !dbg !1972, !tbaa !1191
  %11 = add <2 x i64> %3, %10, !dbg !1972
  store <2 x i64> %11, ptr %incr_hits30, align 8, !dbg !1972, !tbaa !1191
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !1975
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !1967, metadata !DIExpression()), !dbg !1968
  %exitcond.not = icmp eq i64 %indvars.iv.next, 64, !dbg !1976
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !1970, !llvm.loop !1977

for.end:                                          ; preds = %for.body
  ret void, !dbg !1979
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @memcached_thread_init(i32 noundef %nthreads, ptr noundef %arg) local_unnamed_addr #0 !dbg !1980 {
entry:
  %attr.i = alloca %union.pthread_attr_t, align 8, !DIAssignID !1988
  tail call void @llvm.dbg.value(metadata i32 %nthreads, metadata !1984, metadata !DIExpression()), !dbg !1989
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !1985, metadata !DIExpression()), !dbg !1989
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1986, metadata !DIExpression()), !dbg !1989
  br label %for.body, !dbg !1990

for.body:                                         ; preds = %entry, %for.body
  %indvars.iv = phi i64 [ 0, %entry ], [ %indvars.iv.next, %for.body ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1986, metadata !DIExpression()), !dbg !1989
  %arrayidx = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %indvars.iv, !dbg !1992
  %call = tail call i32 @pthread_mutex_init(ptr noundef nonnull %arrayidx, ptr noundef null) #16, !dbg !1995
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !1996
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !1986, metadata !DIExpression()), !dbg !1989
  %exitcond.not = icmp eq i64 %indvars.iv.next, 256, !dbg !1997
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !1990, !llvm.loop !1998

for.end:                                          ; preds = %for.body
  %call1 = tail call i32 @pthread_mutex_init(ptr noundef nonnull @worker_hang_lock, ptr noundef null) #16, !dbg !2000
  %call2 = tail call i32 @pthread_mutex_init(ptr noundef nonnull @init_lock, ptr noundef null) #16, !dbg !2001
  %call3 = tail call i32 @pthread_cond_init(ptr noundef nonnull @init_cond, ptr noundef null) #16, !dbg !2002
  %cmp4 = icmp slt i32 %nthreads, 3, !dbg !2003
  br i1 %cmp4, label %if.end20, label %if.else, !dbg !2005

if.else:                                          ; preds = %for.end
  %cmp5 = icmp eq i32 %nthreads, 3, !dbg !2006
  br i1 %cmp5, label %if.end20, label %if.else7, !dbg !2008

if.else7:                                         ; preds = %if.else
  %cmp8 = icmp ult i32 %nthreads, 5, !dbg !2009
  br i1 %cmp8, label %if.end20, label %if.else10, !dbg !2011

if.else10:                                        ; preds = %if.else7
  %cmp11 = icmp ult i32 %nthreads, 11, !dbg !2012
  br i1 %cmp11, label %if.end20, label %if.else13, !dbg !2014

if.else13:                                        ; preds = %if.else10
  %cmp14 = icmp ult i32 %nthreads, 21, !dbg !2015
  %. = select i1 %cmp14, i32 14, i32 15
  br label %if.end20

if.end20:                                         ; preds = %if.else13, %if.else10, %if.else7, %if.else, %for.end
  %power.0 = phi i32 [ 10, %for.end ], [ 11, %if.else ], [ 12, %if.else7 ], [ 13, %if.else10 ], [ %., %if.else13 ], !dbg !2017
  tail call void @llvm.dbg.value(metadata i32 %power.0, metadata !1987, metadata !DIExpression()), !dbg !1989
  %0 = load i32, ptr @hashpower, align 4, !dbg !2018, !tbaa !930
  %cmp21.not = icmp ult i32 %power.0, %0, !dbg !2020
  br i1 %cmp21.not, label %if.end26, label %if.then22, !dbg !2021

if.then22:                                        ; preds = %if.end20
  %1 = load ptr, ptr @stderr, align 8, !dbg !2022, !tbaa !926
  %call23 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %1, ptr noundef nonnull @.str.15, i32 noundef %0, i32 noundef %power.0) #17, !dbg !2024
  %2 = load ptr, ptr @stderr, align 8, !dbg !2025, !tbaa !926
  %3 = tail call i64 @fwrite(ptr nonnull @.str.16, i64 55, i64 1, ptr %2) #18, !dbg !2026
  %4 = load ptr, ptr @stderr, align 8, !dbg !2027, !tbaa !926
  %5 = tail call i64 @fwrite(ptr nonnull @.str.17, i64 40, i64 1, ptr %4) #18, !dbg !2028
  tail call void @exit(i32 noundef 1) #19, !dbg !2029
  unreachable, !dbg !2029

if.end26:                                         ; preds = %if.end20
  %shl = shl nuw nsw i32 1, %power.0, !dbg !2030
  store i32 %shl, ptr @item_lock_count, align 4, !dbg !2031, !tbaa !930
  store i32 %power.0, ptr @item_lock_hashpower, align 4, !dbg !2032, !tbaa !930
  %conv27 = zext nneg i32 %shl to i64, !dbg !2033
  %call28 = tail call noalias ptr @calloc(i64 noundef %conv27, i64 noundef 40) #20, !dbg !2034
  store ptr %call28, ptr @item_locks, align 8, !dbg !2035, !tbaa !926
  %tobool.not = icmp eq ptr %call28, null, !dbg !2036
  br i1 %tobool.not, label %if.then29, label %for.body34, !dbg !2038

if.then29:                                        ; preds = %if.end26
  tail call void @perror(ptr noundef nonnull @.str.18) #18, !dbg !2039
  tail call void @exit(i32 noundef 1) #19, !dbg !2041
  unreachable, !dbg !2041

for.body34:                                       ; preds = %if.end26, %for.body34
  %indvars.iv126 = phi i64 [ %indvars.iv.next127, %for.body34 ], [ 0, %if.end26 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv126, metadata !1986, metadata !DIExpression()), !dbg !1989
  %6 = load ptr, ptr @item_locks, align 8, !dbg !2042, !tbaa !926
  %arrayidx36 = getelementptr inbounds %union.pthread_mutex_t, ptr %6, i64 %indvars.iv126, !dbg !2042
  %call37 = tail call i32 @pthread_mutex_init(ptr noundef %arrayidx36, ptr noundef null) #16, !dbg !2046
  %indvars.iv.next127 = add nuw nsw i64 %indvars.iv126, 1, !dbg !2047
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next127, metadata !1986, metadata !DIExpression()), !dbg !1989
  %7 = load i32, ptr @item_lock_count, align 4, !dbg !2048, !tbaa !930
  %8 = zext i32 %7 to i64, !dbg !2049
  %cmp32 = icmp ult i64 %indvars.iv.next127, %8, !dbg !2049
  br i1 %cmp32, label %for.body34, label %for.end40, !dbg !2050, !llvm.loop !2051

for.end40:                                        ; preds = %for.body34
  %conv41 = sext i32 %nthreads to i64, !dbg !2053
  %call42 = tail call noalias ptr @calloc(i64 noundef %conv41, i64 noundef 6936) #20, !dbg !2054
  store ptr %call42, ptr @threads, align 8, !dbg !2055, !tbaa !926
  %tobool43.not = icmp eq ptr %call42, null, !dbg !2056
  br i1 %tobool43.not, label %if.then44, label %for.cond46.preheader, !dbg !2058

for.cond46.preheader:                             ; preds = %for.end40
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1986, metadata !DIExpression()), !dbg !1989
  %cmp47120 = icmp sgt i32 %nthreads, 0, !dbg !2059
  br i1 %cmp47120, label %for.body49.preheader, label %for.end71, !dbg !2062

for.body49.preheader:                             ; preds = %for.cond46.preheader
  %wide.trip.count = zext nneg i32 %nthreads to i64, !dbg !2059
  br label %for.body49, !dbg !2062

if.then44:                                        ; preds = %for.end40
  tail call void @perror(ptr noundef nonnull @.str.19) #18, !dbg !2063
  tail call void @exit(i32 noundef 1) #19, !dbg !2065
  unreachable, !dbg !2065

for.cond63.preheader:                             ; preds = %setup_thread.exit
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1986, metadata !DIExpression()), !dbg !1989
  br i1 %cmp47120, label %for.body66.preheader, label %for.end71, !dbg !2066

for.body66.preheader:                             ; preds = %for.cond63.preheader
  %wide.trip.count136 = zext nneg i32 %nthreads to i64, !dbg !2068
  br label %for.body66, !dbg !2066

for.body49:                                       ; preds = %for.body49.preheader, %setup_thread.exit
  %indvars.iv129 = phi i64 [ 0, %for.body49.preheader ], [ %indvars.iv.next130, %setup_thread.exit ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv129, metadata !1986, metadata !DIExpression()), !dbg !1989
  %9 = load ptr, ptr @threads, align 8, !dbg !2070, !tbaa !926
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %9, i64 %indvars.iv129), metadata !2072, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 6936, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 16, DW_OP_stack_value)), !dbg !2078
  %call.i = tail call i32 @eventfd(i32 noundef 0, i32 noundef 2048) #16, !dbg !2080
  %notify_event_fd.i = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %9, i64 %indvars.iv129, i32 2, i32 1, !dbg !2081
  store i32 %call.i, ptr %notify_event_fd.i, align 8, !dbg !2082, !tbaa !2083
  %cmp.i = icmp eq i32 %call.i, -1, !dbg !2084
  br i1 %cmp.i, label %if.then.i, label %memcached_thread_notify_init.exit, !dbg !2086

if.then.i:                                        ; preds = %for.body49
  tail call void @perror(ptr noundef nonnull @.str.20) #18, !dbg !2087
  tail call void @exit(i32 noundef 1) #19, !dbg !2089
  unreachable, !dbg !2089

memcached_thread_notify_init.exit:                ; preds = %for.body49
  %10 = load ptr, ptr @threads, align 8, !dbg !2090, !tbaa !926
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %10, i64 %indvars.iv129), metadata !2072, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 6936, DW_OP_mul, DW_OP_plus, DW_OP_plus_uconst, 152, DW_OP_stack_value)), !dbg !2091
  %call.i101 = tail call i32 @eventfd(i32 noundef 0, i32 noundef 2048) #16, !dbg !2093
  %notify_event_fd.i102 = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %10, i64 %indvars.iv129, i32 3, i32 1, !dbg !2094
  store i32 %call.i101, ptr %notify_event_fd.i102, align 8, !dbg !2095, !tbaa !2083
  %cmp.i103 = icmp eq i32 %call.i101, -1, !dbg !2096
  br i1 %cmp.i103, label %if.then.i104, label %memcached_thread_notify_init.exit105, !dbg !2097

if.then.i104:                                     ; preds = %memcached_thread_notify_init.exit
  tail call void @perror(ptr noundef nonnull @.str.20) #18, !dbg !2098
  tail call void @exit(i32 noundef 1) #19, !dbg !2099
  unreachable, !dbg !2099

memcached_thread_notify_init.exit105:             ; preds = %memcached_thread_notify_init.exit
  %11 = load ptr, ptr @threads, align 8, !dbg !2100, !tbaa !926
  %storage = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %11, i64 %indvars.iv129, i32 14, !dbg !2101
  store ptr %arg, ptr %storage, align 8, !dbg !2102, !tbaa !2103
  %thread_baseid = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %11, i64 %indvars.iv129, i32 7, !dbg !2104
  %12 = trunc nuw nsw i64 %indvars.iv129 to i32, !dbg !2105
  store i32 %12, ptr %thread_baseid, align 4, !dbg !2105, !tbaa !2106
  %arrayidx59 = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %11, i64 %indvars.iv129, !dbg !2107
  tail call void @llvm.dbg.value(metadata ptr %arrayidx59, metadata !2108, metadata !DIExpression()), !dbg !2119
  %call.i106 = tail call ptr @event_config_new() #16, !dbg !2121
  tail call void @llvm.dbg.value(metadata ptr %call.i106, metadata !2113, metadata !DIExpression()), !dbg !2119
  %call1.i = tail call i32 @event_config_set_flag(ptr noundef %call.i106, i32 noundef 1) #16, !dbg !2122
  %call2.i = tail call ptr @event_base_new_with_config(ptr noundef %call.i106) #16, !dbg !2123
  %base.i = getelementptr inbounds i8, ptr %arrayidx59, i64 8, !dbg !2124
  store ptr %call2.i, ptr %base.i, align 8, !dbg !2125, !tbaa !2126
  tail call void @event_config_free(ptr noundef %call.i106) #16, !dbg !2127
  %13 = load ptr, ptr %base.i, align 8, !dbg !2128, !tbaa !2126
  %tobool.not.i = icmp eq ptr %13, null, !dbg !2130
  br i1 %tobool.not.i, label %if.then.i108, label %if.end.i, !dbg !2131

if.then.i108:                                     ; preds = %memcached_thread_notify_init.exit105
  %14 = load ptr, ptr @stderr, align 8, !dbg !2132, !tbaa !926
  %15 = tail call i64 @fwrite(ptr nonnull @.str.21, i64 26, i64 1, ptr %14) #18, !dbg !2134
  tail call void @exit(i32 noundef 1) #19, !dbg !2135
  unreachable, !dbg !2135

if.end.i:                                         ; preds = %memcached_thread_notify_init.exit105
  %n.i = getelementptr inbounds i8, ptr %arrayidx59, i64 16, !dbg !2136
  tail call void @llvm.dbg.value(metadata ptr %arrayidx59, metadata !2137, metadata !DIExpression()), !dbg !2144
  tail call void @llvm.dbg.value(metadata ptr %n.i, metadata !2142, metadata !DIExpression()), !dbg !2144
  tail call void @llvm.dbg.value(metadata ptr @thread_libevent_process, metadata !2143, metadata !DIExpression()), !dbg !2144
  %notify_event_fd.i.i = getelementptr inbounds i8, ptr %arrayidx59, i64 144, !dbg !2146
  %16 = load i32, ptr %notify_event_fd.i.i, align 8, !dbg !2146, !tbaa !2083
  tail call void @event_set(ptr noundef nonnull %n.i, i32 noundef %16, i16 noundef signext 18, ptr noundef nonnull @thread_libevent_process, ptr noundef nonnull %arrayidx59) #16, !dbg !2147
  %17 = load ptr, ptr %base.i, align 8, !dbg !2148, !tbaa !2126
  %call.i.i = tail call i32 @event_base_set(ptr noundef %17, ptr noundef nonnull %n.i) #16, !dbg !2149
  %call3.i.i = tail call i32 @event_add(ptr noundef nonnull %n.i, ptr noundef null) #16, !dbg !2150
  %cmp.i.i = icmp eq i32 %call3.i.i, -1, !dbg !2152
  br i1 %cmp.i.i, label %if.then.i.i, label %setup_thread_notify.exit.i, !dbg !2153

if.then.i.i:                                      ; preds = %if.end.i
  %18 = load ptr, ptr @stderr, align 8, !dbg !2154, !tbaa !926
  %19 = tail call i64 @fwrite(ptr nonnull @.str.28, i64 35, i64 1, ptr %18) #18, !dbg !2156
  tail call void @exit(i32 noundef 1) #19, !dbg !2157
  unreachable, !dbg !2157

setup_thread_notify.exit.i:                       ; preds = %if.end.i
  %ion.i = getelementptr inbounds i8, ptr %arrayidx59, i64 152, !dbg !2158
  tail call void @llvm.dbg.value(metadata ptr %arrayidx59, metadata !2137, metadata !DIExpression()), !dbg !2159
  tail call void @llvm.dbg.value(metadata ptr %ion.i, metadata !2142, metadata !DIExpression()), !dbg !2159
  tail call void @llvm.dbg.value(metadata ptr @thread_libevent_ionotify, metadata !2143, metadata !DIExpression()), !dbg !2159
  %notify_event_fd.i70.i = getelementptr inbounds i8, ptr %arrayidx59, i64 280, !dbg !2161
  %20 = load i32, ptr %notify_event_fd.i70.i, align 8, !dbg !2161, !tbaa !2083
  tail call void @event_set(ptr noundef nonnull %ion.i, i32 noundef %20, i16 noundef signext 18, ptr noundef nonnull @thread_libevent_ionotify, ptr noundef nonnull %arrayidx59) #16, !dbg !2162
  %21 = load ptr, ptr %base.i, align 8, !dbg !2163, !tbaa !2126
  %call.i72.i = tail call i32 @event_base_set(ptr noundef %21, ptr noundef nonnull %ion.i) #16, !dbg !2164
  %call3.i73.i = tail call i32 @event_add(ptr noundef nonnull %ion.i, ptr noundef null) #16, !dbg !2165
  %cmp.i74.i = icmp eq i32 %call3.i73.i, -1, !dbg !2166
  br i1 %cmp.i74.i, label %if.then.i75.i, label %setup_thread_notify.exit76.i, !dbg !2167

if.then.i75.i:                                    ; preds = %setup_thread_notify.exit.i
  %22 = load ptr, ptr @stderr, align 8, !dbg !2168, !tbaa !926
  %23 = tail call i64 @fwrite(ptr nonnull @.str.28, i64 35, i64 1, ptr %22) #18, !dbg !2169
  tail call void @exit(i32 noundef 1) #19, !dbg !2170
  unreachable, !dbg !2170

setup_thread_notify.exit76.i:                     ; preds = %setup_thread_notify.exit.i
  %ion_lock.i = getelementptr inbounds i8, ptr %arrayidx59, i64 288, !dbg !2171
  %call5.i = tail call i32 @pthread_mutex_init(ptr noundef nonnull %ion_lock.i, ptr noundef null) #16, !dbg !2172
  %ion_head.i = getelementptr inbounds i8, ptr %arrayidx59, i64 328, !dbg !2173
  store ptr null, ptr %ion_head.i, align 8, !dbg !2173, !tbaa !1621
  %stqh_last.i = getelementptr inbounds i8, ptr %arrayidx59, i64 336, !dbg !2173
  store ptr %ion_head.i, ptr %stqh_last.i, align 8, !dbg !2173, !tbaa !1625
  %call9.i = tail call noalias dereferenceable_or_null(64) ptr @malloc(i64 noundef 64) #21, !dbg !2175
  %ev_queue.i = getelementptr inbounds i8, ptr %arrayidx59, i64 6872, !dbg !2176
  store ptr %call9.i, ptr %ev_queue.i, align 8, !dbg !2177, !tbaa !1116
  %cmp.i107 = icmp eq ptr %call9.i, null, !dbg !2178
  br i1 %cmp.i107, label %if.then11.i, label %if.end12.i, !dbg !2180

if.then11.i:                                      ; preds = %setup_thread_notify.exit76.i
  tail call void @perror(ptr noundef nonnull @.str.22) #18, !dbg !2181
  tail call void @exit(i32 noundef 1) #19, !dbg !2183
  unreachable, !dbg !2183

if.end12.i:                                       ; preds = %setup_thread_notify.exit76.i
  tail call void @llvm.dbg.value(metadata ptr %call9.i, metadata !2184, metadata !DIExpression()), !dbg !2189
  %lock.i.i = getelementptr inbounds i8, ptr %call9.i, i64 16, !dbg !2191
  %call.i77.i = tail call i32 @pthread_mutex_init(ptr noundef nonnull %lock.i.i, ptr noundef null) #16, !dbg !2192
  store ptr null, ptr %call9.i, align 8, !dbg !2193, !tbaa !2195
  %stqh_last.i.i = getelementptr inbounds i8, ptr %call9.i, i64 8, !dbg !2193
  store ptr %call9.i, ptr %stqh_last.i.i, align 8, !dbg !2193, !tbaa !1187
  %call4.i.i = tail call ptr @cache_create(ptr noundef nonnull @.str.32, i64 noundef 72, i64 noundef 8) #16, !dbg !2196
  %cache.i.i = getelementptr inbounds i8, ptr %call9.i, i64 56, !dbg !2197
  store ptr %call4.i.i, ptr %cache.i.i, align 8, !dbg !2198, !tbaa !1136
  %cmp.i78.i = icmp eq ptr %call4.i.i, null, !dbg !2199
  br i1 %cmp.i78.i, label %if.then.i79.i, label %cq_init.exit.i, !dbg !2201

if.then.i79.i:                                    ; preds = %if.end12.i
  %24 = load ptr, ptr @stderr, align 8, !dbg !2202, !tbaa !926
  %25 = tail call i64 @fwrite(ptr nonnull @.str.33, i64 40, i64 1, ptr %24) #18, !dbg !2204
  tail call void @exit(i32 noundef 1) #19, !dbg !2205
  unreachable, !dbg !2205

cq_init.exit.i:                                   ; preds = %if.end12.i
  %stats.i = getelementptr inbounds i8, ptr %arrayidx59, i64 352, !dbg !2206
  %call14.i = tail call i32 @pthread_mutex_init(ptr noundef nonnull %stats.i, ptr noundef null) #16, !dbg !2208
  %cmp15.not.i = icmp eq i32 %call14.i, 0, !dbg !2209
  br i1 %cmp15.not.i, label %if.end17.i, label %if.then16.i, !dbg !2210

if.then16.i:                                      ; preds = %cq_init.exit.i
  tail call void @perror(ptr noundef nonnull @.str.23) #18, !dbg !2211
  tail call void @exit(i32 noundef 1) #19, !dbg !2213
  unreachable, !dbg !2213

if.end17.i:                                       ; preds = %cq_init.exit.i
  %call18.i = tail call ptr @cache_create(ptr noundef nonnull @.str.24, i64 noundef 16384, i64 noundef 8) #16, !dbg !2214
  %rbuf_cache.i = getelementptr inbounds i8, ptr %arrayidx59, i64 6880, !dbg !2215
  store ptr %call18.i, ptr %rbuf_cache.i, align 8, !dbg !2216, !tbaa !1946
  %cmp20.i = icmp eq ptr %call18.i, null, !dbg !2217
  br i1 %cmp20.i, label %if.then21.i, label %if.end23.i, !dbg !2219

if.then21.i:                                      ; preds = %if.end17.i
  %26 = load ptr, ptr @stderr, align 8, !dbg !2220, !tbaa !926
  %27 = tail call i64 @fwrite(ptr nonnull @.str.25, i64 35, i64 1, ptr %26) #18, !dbg !2222
  tail call void @exit(i32 noundef 1) #19, !dbg !2223
  unreachable, !dbg !2223

if.end23.i:                                       ; preds = %if.end17.i
  %28 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 52), align 8, !dbg !2224, !tbaa !2225
  %tobool24.not.i = icmp eq i32 %28, 0, !dbg !2226
  br i1 %tobool24.not.i, label %if.end31.i, label %if.then25.i, !dbg !2227

if.then25.i:                                      ; preds = %if.end23.i
  %29 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 13), align 4, !dbg !2228, !tbaa !989
  %div.i = udiv i32 %28, %29, !dbg !2229
  tail call void @llvm.dbg.value(metadata i32 %div.i, metadata !2116, metadata !DIExpression()), !dbg !2230
  %cmp26.i = icmp slt i32 %div.i, 16384, !dbg !2231
  %div2869.i = lshr i32 %div.i, 14, !dbg !2233
  %limit.0.i = select i1 %cmp26.i, i32 1, i32 %div2869.i, !dbg !2233
  tail call void @llvm.dbg.value(metadata i32 %limit.0.i, metadata !2116, metadata !DIExpression()), !dbg !2230
  tail call void @cache_set_limit(ptr noundef nonnull %call18.i, i32 noundef %limit.0.i) #16, !dbg !2234
  br label %if.end31.i, !dbg !2235

if.end31.i:                                       ; preds = %if.then25.i, %if.end23.i
  %call32.i = tail call ptr @cache_create(ptr noundef nonnull @.str.26, i64 noundef 176, i64 noundef 8) #16, !dbg !2236
  %io_cache.i = getelementptr inbounds i8, ptr %arrayidx59, i64 6896, !dbg !2237
  store ptr %call32.i, ptr %io_cache.i, align 8, !dbg !2238, !tbaa !2239
  %cmp34.i = icmp eq ptr %call32.i, null, !dbg !2240
  br i1 %cmp34.i, label %if.then35.i, label %if.end37.i, !dbg !2242

if.then35.i:                                      ; preds = %if.end31.i
  %30 = load ptr, ptr @stderr, align 8, !dbg !2243, !tbaa !926
  %31 = tail call i64 @fwrite(ptr nonnull @.str.27, i64 33, i64 1, ptr %30) #18, !dbg !2245
  tail call void @exit(i32 noundef 1) #19, !dbg !2246
  unreachable, !dbg !2246

if.end37.i:                                       ; preds = %if.end31.i
  %storage.i = getelementptr inbounds i8, ptr %arrayidx59, i64 6904, !dbg !2247
  %32 = load ptr, ptr %storage.i, align 8, !dbg !2247, !tbaa !2103
  %tobool38.not.i = icmp eq ptr %32, null, !dbg !2249
  br i1 %tobool38.not.i, label %setup_thread.exit, label %if.then39.i, !dbg !2250

if.then39.i:                                      ; preds = %if.end37.i
  tail call void @thread_io_queue_add(ptr noundef nonnull %arrayidx59, i32 noundef 1, ptr noundef nonnull %32, ptr noundef nonnull @storage_submit_cb) #16, !dbg !2251
  br label %setup_thread.exit, !dbg !2253

setup_thread.exit:                                ; preds = %if.end37.i, %if.then39.i
  tail call void @thread_io_queue_add(ptr noundef nonnull %arrayidx59, i32 noundef 0, ptr noundef null, ptr noundef null) #16, !dbg !2254
  %33 = load i32, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 5), align 4, !dbg !2255, !tbaa !2256
  %add = add i32 %33, 5, !dbg !2255
  store i32 %add, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 5), align 4, !dbg !2255, !tbaa !2256
  %indvars.iv.next130 = add nuw nsw i64 %indvars.iv129, 1, !dbg !2258
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next130, metadata !1986, metadata !DIExpression()), !dbg !1989
  %exitcond132.not = icmp eq i64 %indvars.iv.next130, %wide.trip.count, !dbg !2059
  br i1 %exitcond132.not, label %for.cond63.preheader, label %for.body49, !dbg !2062, !llvm.loop !2259

for.body66:                                       ; preds = %for.body66.preheader, %create_worker.exit
  %indvars.iv133 = phi i64 [ 0, %for.body66.preheader ], [ %indvars.iv.next134, %create_worker.exit ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv133, metadata !1986, metadata !DIExpression()), !dbg !1989
  %34 = load ptr, ptr @threads, align 8, !dbg !2261, !tbaa !926
  %arrayidx68 = getelementptr inbounds %struct.LIBEVENT_THREAD, ptr %34, i64 %indvars.iv133, !dbg !2261
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2263, metadata !DIExpression(), metadata !1988, metadata ptr %attr.i, metadata !DIExpression()), !dbg !2279
  tail call void @llvm.dbg.value(metadata ptr @worker_libevent, metadata !2271, metadata !DIExpression()), !dbg !2279
  tail call void @llvm.dbg.value(metadata ptr %arrayidx68, metadata !2272, metadata !DIExpression()), !dbg !2279
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %attr.i) #16, !dbg !2281
  %call.i109 = call i32 @pthread_attr_init(ptr noundef nonnull %attr.i) #16, !dbg !2282
  %call1.i110 = call i32 @pthread_create(ptr noundef %arrayidx68, ptr noundef nonnull %attr.i, ptr noundef nonnull @worker_libevent, ptr noundef %arrayidx68) #16, !dbg !2283
  tail call void @llvm.dbg.value(metadata i32 %call1.i110, metadata !2273, metadata !DIExpression()), !dbg !2279
  %cmp.not.i = icmp eq i32 %call1.i110, 0, !dbg !2285
  br i1 %cmp.not.i, label %create_worker.exit, label %if.then.i111, !dbg !2286

if.then.i111:                                     ; preds = %for.body66
  %35 = load ptr, ptr @stderr, align 8, !dbg !2287, !tbaa !926
  %call2.i112 = call ptr @strerror(i32 noundef %call1.i110) #16, !dbg !2289
  %call3.i = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %35, ptr noundef nonnull @.str.34, ptr noundef %call2.i112) #17, !dbg !2290
  call void @exit(i32 noundef 1) #19, !dbg !2291
  unreachable, !dbg !2291

create_worker.exit:                               ; preds = %for.body66
  %36 = load i64, ptr %arrayidx68, align 8, !dbg !2292, !tbaa !1320
  tail call void @llvm.dbg.value(metadata i64 %36, metadata !1364, metadata !DIExpression()), !dbg !2293
  tail call void @llvm.dbg.value(metadata ptr @.str.35, metadata !1365, metadata !DIExpression()), !dbg !2293
  %call.i.i114 = call i32 @pthread_setname_np(i64 noundef %36, ptr noundef nonnull @.str.35) #16, !dbg !2295
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %attr.i) #16, !dbg !2296
  %indvars.iv.next134 = add nuw nsw i64 %indvars.iv133, 1, !dbg !2297
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next134, metadata !1986, metadata !DIExpression()), !dbg !1989
  %exitcond137.not = icmp eq i64 %indvars.iv.next134, %wide.trip.count136, !dbg !2068
  br i1 %exitcond137.not, label %for.end71, label %for.body66, !dbg !2066, !llvm.loop !2298

for.end71:                                        ; preds = %create_worker.exit, %for.cond46.preheader, %for.cond63.preheader
  %call72 = call i32 @pthread_mutex_lock(ptr noundef nonnull @init_lock) #16, !dbg !2300
  tail call void @llvm.dbg.value(metadata i32 %nthreads, metadata !1018, metadata !DIExpression()), !dbg !2301
  %37 = load i32, ptr @init_count, align 4, !dbg !2303, !tbaa !930
  %cmp1.i = icmp slt i32 %37, %nthreads, !dbg !2304
  br i1 %cmp1.i, label %while.body.i, label %wait_for_thread_registration.exit, !dbg !2305

while.body.i:                                     ; preds = %for.end71, %while.body.i
  %call.i115 = call i32 @pthread_cond_wait(ptr noundef nonnull @init_cond, ptr noundef nonnull @init_lock) #16, !dbg !2306
  %38 = load i32, ptr @init_count, align 4, !dbg !2303, !tbaa !930
  %cmp.i116 = icmp slt i32 %38, %nthreads, !dbg !2304
  br i1 %cmp.i116, label %while.body.i, label %wait_for_thread_registration.exit, !dbg !2305, !llvm.loop !2307

wait_for_thread_registration.exit:                ; preds = %while.body.i, %for.end71
  %call73 = call i32 @pthread_mutex_unlock(ptr noundef nonnull @init_lock) #16, !dbg !2309
  ret void, !dbg !2310
}

; Function Attrs: nounwind
declare !dbg !2311 i32 @pthread_mutex_init(ptr noundef, ptr noundef) local_unnamed_addr #1

; Function Attrs: nounwind
declare !dbg !2322 i32 @pthread_cond_init(ptr noundef, ptr noundef) local_unnamed_addr #1

; Function Attrs: noreturn nounwind
declare !dbg !2335 void @exit(i32 noundef) local_unnamed_addr #10

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite)
declare !dbg !2337 noalias noundef ptr @calloc(i64 noundef, i64 noundef) local_unnamed_addr #11

; Function Attrs: nounwind sanitize_thread uwtable
define internal noalias noundef ptr @worker_libevent(ptr nocapture noundef %arg) #0 !dbg !2340 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2342, metadata !DIExpression()), !dbg !2344
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2343, metadata !DIExpression()), !dbg !2344
  %call = tail call ptr @logger_create() #16, !dbg !2345
  %l = getelementptr inbounds i8, ptr %arg, i64 6912, !dbg !2346
  store ptr %call, ptr %l, align 8, !dbg !2347, !tbaa !2348
  %call1 = tail call ptr @item_lru_bump_buf_create() #16, !dbg !2349
  %lru_bump_buf = getelementptr inbounds i8, ptr %arg, i64 6920, !dbg !2350
  store ptr %call1, ptr %lru_bump_buf, align 8, !dbg !2351, !tbaa !2352
  %0 = load ptr, ptr %l, align 8, !dbg !2353, !tbaa !2348
  %cmp = icmp eq ptr %0, null, !dbg !2355
  %cmp4 = icmp eq ptr %call1, null
  %or.cond = select i1 %cmp, i1 true, i1 %cmp4, !dbg !2356
  br i1 %or.cond, label %if.then, label %if.end, !dbg !2356

if.then:                                          ; preds = %entry
  tail call void @abort() #19, !dbg !2357
  unreachable, !dbg !2357

if.end:                                           ; preds = %entry
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @init_lock) #16, !dbg !2359
  %1 = load i32, ptr @init_count, align 4, !dbg !2362, !tbaa !930
  %inc.i = add nsw i32 %1, 1, !dbg !2362
  store i32 %inc.i, ptr @init_count, align 4, !dbg !2362, !tbaa !930
  %call1.i = tail call i32 @pthread_cond_signal(ptr noundef nonnull @init_cond) #16, !dbg !2363
  %call2.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @init_lock) #16, !dbg !2364
  %call3.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @worker_hang_lock) #16, !dbg !2365
  %call4.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @worker_hang_lock) #16, !dbg !2366
  %base = getelementptr inbounds i8, ptr %arg, i64 8, !dbg !2367
  %2 = load ptr, ptr %base, align 8, !dbg !2367, !tbaa !2126
  %call7 = tail call i32 @event_base_loop(ptr noundef %2, i32 noundef 0) #16, !dbg !2368
  %call.i14 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @init_lock) #16, !dbg !2369
  %3 = load i32, ptr @init_count, align 4, !dbg !2371, !tbaa !930
  %inc.i15 = add nsw i32 %3, 1, !dbg !2371
  store i32 %inc.i15, ptr @init_count, align 4, !dbg !2371, !tbaa !930
  %call1.i16 = tail call i32 @pthread_cond_signal(ptr noundef nonnull @init_cond) #16, !dbg !2372
  %call2.i17 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @init_lock) #16, !dbg !2373
  %call3.i18 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @worker_hang_lock) #16, !dbg !2374
  %call4.i19 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @worker_hang_lock) #16, !dbg !2375
  %4 = load ptr, ptr %base, align 8, !dbg !2376, !tbaa !2126
  tail call void @event_base_free(ptr noundef %4) #16, !dbg !2377
  ret ptr null, !dbg !2378
}

declare !dbg !2379 i32 @pthread_cond_wait(ptr noundef, ptr noundef) local_unnamed_addr #3

; Function Attrs: nounwind
declare !dbg !2383 i32 @getsockopt(i32 noundef, i32 noundef, i32 noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

declare !dbg !2390 ptr @cache_alloc(ptr noundef) local_unnamed_addr #3

; Function Attrs: nounwind
declare !dbg !2393 i32 @eventfd(i32 noundef, i32 noundef) local_unnamed_addr #1

declare !dbg !2397 ptr @event_config_new() local_unnamed_addr #3

declare !dbg !2400 i32 @event_config_set_flag(ptr noundef, i32 noundef) local_unnamed_addr #3

declare !dbg !2403 ptr @event_base_new_with_config(ptr noundef) local_unnamed_addr #3

declare !dbg !2408 void @event_config_free(ptr noundef) local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define internal void @thread_libevent_process(i32 noundef %fd, i16 signext %which, ptr noundef %arg) #0 !dbg !2411 {
entry:
  %ev_count = alloca i64, align 8, !DIAssignID !2422
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2419, metadata !DIExpression(), metadata !2422, metadata ptr %ev_count, metadata !DIExpression()), !dbg !2423
  tail call void @llvm.dbg.value(metadata i32 %fd, metadata !2413, metadata !DIExpression()), !dbg !2423
  tail call void @llvm.dbg.value(metadata i16 poison, metadata !2414, metadata !DIExpression()), !dbg !2423
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2415, metadata !DIExpression()), !dbg !2423
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2416, metadata !DIExpression()), !dbg !2423
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %ev_count) #16, !dbg !2424
  store i64 0, ptr %ev_count, align 8, !dbg !2425, !tbaa !1191, !DIAssignID !2426
  tail call void @llvm.dbg.assign(metadata i64 0, metadata !2419, metadata !DIExpression(), metadata !2426, metadata ptr %ev_count, metadata !DIExpression()), !dbg !2423
  %call = call i64 @read(i32 noundef %fd, ptr noundef nonnull %ev_count, i64 noundef 8) #16, !dbg !2427
  %cmp.not = icmp eq i64 %call, 8, !dbg !2429
  br i1 %cmp.not, label %for.cond.preheader, label %if.then, !dbg !2430

for.cond.preheader:                               ; preds = %entry
  %0 = load i64, ptr %ev_count, align 8, !tbaa !1191
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2420, metadata !DIExpression()), !dbg !2431
  %cmp573.not = icmp eq i64 %0, 0, !dbg !2432
  br i1 %cmp573.not, label %cleanup43, label %for.body.lr.ph, !dbg !2434

for.body.lr.ph:                                   ; preds = %for.cond.preheader
  %ev_queue = getelementptr inbounds i8, ptr %arg, i64 6872
  %base40 = getelementptr inbounds i8, ptr %arg, i64 8
  br label %for.body, !dbg !2434

if.then:                                          ; preds = %entry
  %1 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2435, !tbaa !1210
  %cmp1 = icmp sgt i32 %1, 0, !dbg !2438
  br i1 %cmp1, label %if.then2, label %cleanup43, !dbg !2439

if.then2:                                         ; preds = %if.then
  %2 = load ptr, ptr @stderr, align 8, !dbg !2440, !tbaa !926
  %3 = tail call i64 @fwrite(ptr nonnull @.str.29, i64 30, i64 1, ptr %2) #18, !dbg !2441
  br label %cleanup43, !dbg !2441

for.body:                                         ; preds = %for.body.lr.ph, %sw.epilog
  %indvars.iv = phi i64 [ 0, %for.body.lr.ph ], [ %indvars.iv.next, %sw.epilog ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2420, metadata !DIExpression()), !dbg !2431
  %4 = load ptr, ptr %ev_queue, align 8, !dbg !2442, !tbaa !1116
  tail call void @llvm.dbg.value(metadata ptr %4, metadata !2444, metadata !DIExpression()), !dbg !2448
  %lock.i = getelementptr inbounds i8, ptr %4, i64 16, !dbg !2450
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %lock.i) #16, !dbg !2451
  %5 = load ptr, ptr %4, align 8, !dbg !2452, !tbaa !2195
  tail call void @llvm.dbg.value(metadata ptr %5, metadata !2447, metadata !DIExpression()), !dbg !2448
  %cmp.not.i = icmp eq ptr %5, null, !dbg !2453
  br i1 %cmp.not.i, label %cq_pop.exit, label %do.body.i, !dbg !2455

do.body.i:                                        ; preds = %for.body
  %i_next.i = getelementptr inbounds i8, ptr %5, i64 64, !dbg !2456
  %6 = load ptr, ptr %i_next.i, align 8, !dbg !2456, !tbaa !1186
  store ptr %6, ptr %4, align 8, !dbg !2456, !tbaa !2195
  %cmp5.i = icmp eq ptr %6, null, !dbg !2456
  br i1 %cmp5.i, label %if.then6.i, label %if.end11, !dbg !2460

if.then6.i:                                       ; preds = %do.body.i
  %stqh_last.i = getelementptr inbounds i8, ptr %4, i64 8, !dbg !2456
  store ptr %4, ptr %stqh_last.i, align 8, !dbg !2456, !tbaa !1187
  br label %if.end11, !dbg !2456

cq_pop.exit:                                      ; preds = %for.body
  %call12.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %lock.i) #16, !dbg !2461
  tail call void @llvm.dbg.value(metadata ptr %5, metadata !2417, metadata !DIExpression()), !dbg !2423
  br label %cleanup43, !dbg !2462

if.end11:                                         ; preds = %do.body.i, %if.then6.i
  %call12.i71 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %lock.i) #16, !dbg !2461
  tail call void @llvm.dbg.value(metadata ptr %5, metadata !2417, metadata !DIExpression()), !dbg !2423
  %mode = getelementptr inbounds i8, ptr %5, i64 20, !dbg !2463
  %7 = load i32, ptr %mode, align 4, !dbg !2463, !tbaa !1159
  switch i32 %7, label %sw.epilog [
    i32 0, label %sw.bb
    i32 1, label %sw.bb32
    i32 2, label %sw.bb33
    i32 3, label %sw.bb35
    i32 4, label %sw.bb39
  ], !dbg !2464

sw.bb:                                            ; preds = %if.end11
  %8 = load i32, ptr %5, align 8, !dbg !2465, !tbaa !1163
  %init_state = getelementptr inbounds i8, ptr %5, i64 4, !dbg !2467
  %9 = load i32, ptr %init_state, align 4, !dbg !2467, !tbaa !1534
  %event_flags = getelementptr inbounds i8, ptr %5, i64 8, !dbg !2468
  %10 = load i32, ptr %event_flags, align 8, !dbg !2468, !tbaa !1537
  %read_buffer_size = getelementptr inbounds i8, ptr %5, i64 12, !dbg !2469
  %11 = load i32, ptr %read_buffer_size, align 4, !dbg !2469, !tbaa !1540
  %transport = getelementptr inbounds i8, ptr %5, i64 16, !dbg !2470
  %12 = load i32, ptr %transport, align 8, !dbg !2470, !tbaa !1543
  %13 = load ptr, ptr %base40, align 8, !dbg !2471, !tbaa !2126
  %ssl = getelementptr inbounds i8, ptr %5, i64 32, !dbg !2472
  %14 = load ptr, ptr %ssl, align 8, !dbg !2472, !tbaa !1548
  %conntag = getelementptr inbounds i8, ptr %5, i64 40, !dbg !2473
  %15 = load i64, ptr %conntag, align 8, !dbg !2473, !tbaa !1551
  %bproto = getelementptr inbounds i8, ptr %5, i64 48, !dbg !2474
  %16 = load i32, ptr %bproto, align 8, !dbg !2474, !tbaa !1554
  %call12 = tail call ptr @conn_new(i32 noundef %8, i32 noundef %9, i32 noundef %10, i32 noundef %11, i32 noundef %12, ptr noundef %13, ptr noundef %14, i64 noundef %15, i32 noundef %16) #16, !dbg !2475
  tail call void @llvm.dbg.value(metadata ptr %call12, metadata !2418, metadata !DIExpression()), !dbg !2423
  %cmp13 = icmp eq ptr %call12, null, !dbg !2476
  br i1 %cmp13, label %if.then15, label %if.else30, !dbg !2478

if.then15:                                        ; preds = %sw.bb
  %17 = load i32, ptr %transport, align 8, !dbg !2479, !tbaa !1543
  %cmp17 = icmp eq i32 %17, 2, !dbg !2479
  br i1 %cmp17, label %if.then19, label %if.else, !dbg !2482

if.then19:                                        ; preds = %if.then15
  %18 = load ptr, ptr @stderr, align 8, !dbg !2483, !tbaa !926
  %19 = tail call i64 @fwrite(ptr nonnull @.str.30, i64 38, i64 1, ptr %18) #18, !dbg !2485
  tail call void @exit(i32 noundef 1) #19, !dbg !2486
  unreachable, !dbg !2486

if.else:                                          ; preds = %if.then15
  %20 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2487, !tbaa !1210
  %cmp21 = icmp sgt i32 %20, 0, !dbg !2490
  br i1 %cmp21, label %if.then23, label %if.end26, !dbg !2491

if.then23:                                        ; preds = %if.else
  %21 = load ptr, ptr @stderr, align 8, !dbg !2492, !tbaa !926
  %22 = load i32, ptr %5, align 8, !dbg !2494, !tbaa !1163
  %call25 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %21, ptr noundef nonnull @.str.31, i32 noundef %22) #17, !dbg !2495
  br label %if.end26, !dbg !2496

if.end26:                                         ; preds = %if.then23, %if.else
  %23 = load i32, ptr %5, align 8, !dbg !2497, !tbaa !1163
  %call28 = tail call i32 @close(i32 noundef %23) #16, !dbg !2498
  br label %sw.epilog, !dbg !2499

if.else30:                                        ; preds = %sw.bb
  %thread = getelementptr inbounds i8, ptr %call12, i64 456, !dbg !2500
  store ptr %arg, ptr %thread, align 8, !dbg !2502, !tbaa !1586
  tail call void @conn_io_queue_setup(ptr noundef nonnull %call12) #16, !dbg !2503
  br label %sw.epilog

sw.bb32:                                          ; preds = %if.end11
  %call.i70 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @init_lock) #16, !dbg !2504
  %24 = load i32, ptr @init_count, align 4, !dbg !2506, !tbaa !930
  %inc.i = add nsw i32 %24, 1, !dbg !2506
  store i32 %inc.i, ptr @init_count, align 4, !dbg !2506, !tbaa !930
  %call1.i = tail call i32 @pthread_cond_signal(ptr noundef nonnull @init_cond) #16, !dbg !2507
  %call2.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @init_lock) #16, !dbg !2508
  %call3.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @worker_hang_lock) #16, !dbg !2509
  %call4.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @worker_hang_lock) #16, !dbg !2510
  br label %sw.epilog, !dbg !2511

sw.bb33:                                          ; preds = %if.end11
  %25 = load ptr, ptr @conns, align 8, !dbg !2512, !tbaa !926
  %26 = load i32, ptr %5, align 8, !dbg !2513, !tbaa !1163
  %idxprom = sext i32 %26 to i64, !dbg !2512
  %arrayidx = getelementptr inbounds ptr, ptr %25, i64 %idxprom, !dbg !2512
  %27 = load ptr, ptr %arrayidx, align 8, !dbg !2512, !tbaa !926
  tail call void @conn_close_idle(ptr noundef %27) #16, !dbg !2514
  br label %sw.epilog, !dbg !2515

sw.bb35:                                          ; preds = %if.end11
  %28 = load ptr, ptr @conns, align 8, !dbg !2516, !tbaa !926
  %29 = load i32, ptr %5, align 8, !dbg !2517, !tbaa !1163
  %idxprom37 = sext i32 %29 to i64, !dbg !2516
  %arrayidx38 = getelementptr inbounds ptr, ptr %28, i64 %idxprom37, !dbg !2516
  %30 = load ptr, ptr %arrayidx38, align 8, !dbg !2516, !tbaa !926
  tail call void @conn_worker_readd(ptr noundef %30) #16, !dbg !2518
  br label %sw.epilog, !dbg !2519

sw.bb39:                                          ; preds = %if.end11
  %31 = load ptr, ptr %base40, align 8, !dbg !2520, !tbaa !2126
  %call41 = tail call i32 @event_base_loopexit(ptr noundef %31, ptr noundef null) #16, !dbg !2521
  br label %sw.epilog, !dbg !2522

sw.epilog:                                        ; preds = %if.end26, %if.else30, %if.end11, %sw.bb39, %sw.bb35, %sw.bb33, %sw.bb32
  %32 = load ptr, ptr %ev_queue, align 8, !dbg !2523, !tbaa !1116
  tail call void @llvm.dbg.value(metadata ptr %32, metadata !2524, metadata !DIExpression()), !dbg !2528
  tail call void @llvm.dbg.value(metadata ptr %5, metadata !2527, metadata !DIExpression()), !dbg !2528
  %cache.i = getelementptr inbounds i8, ptr %32, i64 56, !dbg !2530
  %33 = load ptr, ptr %cache.i, align 8, !dbg !2530, !tbaa !1136
  tail call void @cache_free(ptr noundef %33, ptr noundef nonnull %5) #16, !dbg !2531
  %indvars.iv.next = add nuw i64 %indvars.iv, 1, !dbg !2532
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !2420, metadata !DIExpression()), !dbg !2431
  %exitcond.not = icmp eq i64 %indvars.iv.next, %0, !dbg !2432
  br i1 %exitcond.not, label %cleanup43, label %for.body, !dbg !2434, !llvm.loop !2533

cleanup43:                                        ; preds = %sw.epilog, %for.cond.preheader, %cq_pop.exit, %if.then, %if.then2
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %ev_count) #16, !dbg !2535
  ret void, !dbg !2535
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal void @thread_libevent_ionotify(i32 noundef %fd, i16 signext %which, ptr noundef %arg) #0 !dbg !2536 {
entry:
  %ev_count = alloca i64, align 8, !DIAssignID !2546
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2542, metadata !DIExpression(), metadata !2546, metadata ptr %ev_count, metadata !DIExpression()), !dbg !2547
  %head = alloca %struct.iop_head_s, align 8, !DIAssignID !2548
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2543, metadata !DIExpression(), metadata !2548, metadata ptr %head, metadata !DIExpression()), !dbg !2547
  tail call void @llvm.dbg.value(metadata i32 %fd, metadata !2538, metadata !DIExpression()), !dbg !2547
  tail call void @llvm.dbg.value(metadata i16 poison, metadata !2539, metadata !DIExpression()), !dbg !2547
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2540, metadata !DIExpression()), !dbg !2547
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !2541, metadata !DIExpression()), !dbg !2547
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %ev_count) #16, !dbg !2549
  store i64 0, ptr %ev_count, align 8, !dbg !2550, !tbaa !1191, !DIAssignID !2551
  tail call void @llvm.dbg.assign(metadata i64 0, metadata !2542, metadata !DIExpression(), metadata !2551, metadata ptr %ev_count, metadata !DIExpression()), !dbg !2547
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %head) #16, !dbg !2552
  store ptr null, ptr %head, align 8, !dbg !2553, !tbaa !2555, !DIAssignID !2556
  tail call void @llvm.dbg.assign(metadata ptr null, metadata !2543, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2556, metadata ptr %head, metadata !DIExpression()), !dbg !2547
  %stqh_last = getelementptr inbounds i8, ptr %head, i64 8, !dbg !2553
  store ptr %head, ptr %stqh_last, align 8, !dbg !2553, !tbaa !2557, !DIAssignID !2558
  tail call void @llvm.dbg.assign(metadata ptr %head, metadata !2543, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !2558, metadata ptr %stqh_last, metadata !DIExpression()), !dbg !2547
  %call = call i64 @read(i32 noundef %fd, ptr noundef nonnull %ev_count, i64 noundef 8) #16, !dbg !2559
  %cmp.not = icmp eq i64 %call, 8, !dbg !2561
  br i1 %cmp.not, label %if.end5, label %if.then, !dbg !2562

if.then:                                          ; preds = %entry
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2563, !tbaa !1210
  %cmp2 = icmp sgt i32 %0, 0, !dbg !2566
  br i1 %cmp2, label %if.then3, label %cleanup, !dbg !2567

if.then3:                                         ; preds = %if.then
  %1 = load ptr, ptr @stderr, align 8, !dbg !2568, !tbaa !926
  %2 = call i64 @fwrite(ptr nonnull @.str.29, i64 30, i64 1, ptr %1) #18, !dbg !2569
  br label %cleanup, !dbg !2569

if.end5:                                          ; preds = %entry
  %ion_lock = getelementptr inbounds i8, ptr %arg, i64 288, !dbg !2570
  %call6 = call i32 @pthread_mutex_lock(ptr noundef nonnull %ion_lock) #16, !dbg !2571
  %ion_head = getelementptr inbounds i8, ptr %arg, i64 328, !dbg !2572
  %3 = load ptr, ptr %ion_head, align 8, !dbg !2572, !tbaa !1621
  %cmp9 = icmp eq ptr %3, null, !dbg !2572
  br i1 %cmp9, label %do.end28, label %if.then10, !dbg !2575

if.then10:                                        ; preds = %if.end5
  %4 = load ptr, ptr %stqh_last, align 8, !dbg !2576, !tbaa !2557
  store ptr %3, ptr %4, align 8, !dbg !2576, !tbaa !926
  %stqh_last15 = getelementptr inbounds i8, ptr %arg, i64 336, !dbg !2576
  %5 = load ptr, ptr %stqh_last15, align 8, !dbg !2576, !tbaa !1625
  store ptr %5, ptr %stqh_last, align 8, !dbg !2576, !tbaa !2557, !DIAssignID !2578
  tail call void @llvm.dbg.assign(metadata ptr %5, metadata !2543, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !2578, metadata ptr %stqh_last, metadata !DIExpression()), !dbg !2547
  store ptr null, ptr %ion_head, align 8, !dbg !2579, !tbaa !1621
  store ptr %ion_head, ptr %stqh_last15, align 8, !dbg !2579, !tbaa !1625
  br label %do.end28, !dbg !2576

do.end28:                                         ; preds = %if.then10, %if.end5
  %call30 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %ion_lock) #16, !dbg !2581
  %6 = load ptr, ptr %head, align 8, !dbg !2582, !tbaa !2555
  %cmp32.not53 = icmp eq ptr %6, null, !dbg !2582
  br i1 %cmp32.not53, label %cleanup, label %while.body, !dbg !2583

while.body:                                       ; preds = %do.end28, %do.end43
  %7 = phi ptr [ %9, %do.end43 ], [ %6, %do.end28 ]
  tail call void @llvm.dbg.value(metadata ptr %7, metadata !2544, metadata !DIExpression()), !dbg !2584
  %iop_next = getelementptr inbounds i8, ptr %7, i64 48, !dbg !2585
  %8 = load ptr, ptr %iop_next, align 8, !dbg !2585, !tbaa !1624
  store ptr %8, ptr %head, align 8, !dbg !2585, !tbaa !2555, !DIAssignID !2588
  tail call void @llvm.dbg.assign(metadata ptr %8, metadata !2543, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2588, metadata ptr %head, metadata !DIExpression()), !dbg !2547
  %cmp37 = icmp eq ptr %8, null, !dbg !2585
  br i1 %cmp37, label %if.then38, label %do.end43, !dbg !2589

if.then38:                                        ; preds = %while.body
  store ptr %head, ptr %stqh_last, align 8, !dbg !2585, !tbaa !2557, !DIAssignID !2590
  tail call void @llvm.dbg.assign(metadata ptr %head, metadata !2543, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !2590, metadata ptr %stqh_last, metadata !DIExpression()), !dbg !2547
  br label %do.end43, !dbg !2585

do.end43:                                         ; preds = %if.then38, %while.body
  call void @conn_io_queue_return(ptr noundef nonnull %7) #16, !dbg !2591
  %9 = load ptr, ptr %head, align 8, !dbg !2582, !tbaa !2555
  %cmp32.not = icmp eq ptr %9, null, !dbg !2582
  br i1 %cmp32.not, label %cleanup, label %while.body, !dbg !2583, !llvm.loop !2592

cleanup:                                          ; preds = %do.end43, %do.end28, %if.then, %if.then3
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %head) #16, !dbg !2594
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %ev_count) #16, !dbg !2594
  ret void, !dbg !2594
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare !dbg !2595 noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #12

declare !dbg !2598 ptr @cache_create(ptr noundef, i64 noundef, i64 noundef) local_unnamed_addr #3

declare !dbg !2601 void @cache_set_limit(ptr noundef, i32 noundef) local_unnamed_addr #3

declare !dbg !2604 void @thread_io_queue_add(ptr noundef, i32 noundef, ptr noundef, ptr noundef) local_unnamed_addr #3

declare void @storage_submit_cb(ptr noundef) #3

declare !dbg !2607 void @event_set(ptr noundef, i32 noundef, i16 noundef signext, ptr noundef, ptr noundef) local_unnamed_addr #3

declare !dbg !2611 i32 @event_base_set(ptr noundef, ptr noundef) local_unnamed_addr #3

declare !dbg !2614 i32 @event_add(ptr noundef, ptr noundef) local_unnamed_addr #3

; Function Attrs: nofree
declare !dbg !2619 noundef i64 @read(i32 noundef, ptr nocapture noundef, i64 noundef) local_unnamed_addr #6

declare !dbg !2622 ptr @conn_new(i32 noundef, i32 noundef, i32 noundef, i32 noundef, i32 noundef, ptr noundef, ptr noundef, i64 noundef, i32 noundef) local_unnamed_addr #3

declare !dbg !2626 void @conn_io_queue_setup(ptr noundef) local_unnamed_addr #3

declare !dbg !2627 void @conn_close_idle(ptr noundef) local_unnamed_addr #3

declare !dbg !2628 void @conn_worker_readd(ptr noundef) local_unnamed_addr #3

declare !dbg !2629 i32 @event_base_loopexit(ptr noundef, ptr noundef) local_unnamed_addr #3

; Function Attrs: nounwind
declare !dbg !2632 i32 @pthread_cond_signal(ptr noundef) local_unnamed_addr #1

declare !dbg !2635 void @cache_free(ptr noundef, ptr noundef) local_unnamed_addr #3

declare !dbg !2638 void @conn_io_queue_return(ptr noundef) local_unnamed_addr #3

; Function Attrs: nounwind
declare !dbg !2639 i32 @pthread_attr_init(ptr noundef) local_unnamed_addr #1

; Function Attrs: nounwind
declare !dbg !2643 i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #1

; Function Attrs: nounwind
declare !dbg !2651 ptr @strerror(i32 noundef) local_unnamed_addr #1

declare !dbg !2655 ptr @logger_create() local_unnamed_addr #3

declare !dbg !2658 ptr @item_lru_bump_buf_create() local_unnamed_addr #3

; Function Attrs: noreturn nounwind
declare !dbg !2661 void @abort() local_unnamed_addr #10

declare !dbg !2662 i32 @event_base_loop(ptr noundef, i32 noundef) local_unnamed_addr #3

declare !dbg !2665 void @event_base_free(ptr noundef) local_unnamed_addr #3

; Function Attrs: nofree nounwind
declare noundef i64 @fwrite(ptr nocapture noundef, i64 noundef, i64 noundef, ptr nocapture noundef) local_unnamed_addr #13

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #14

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #15 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #14

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #14

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #14

attributes #0 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nofree "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { cold nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #9 = { nofree norecurse nosync nounwind sanitize_thread memory(argmem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { nofree nounwind }
attributes #14 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #15 = { nounwind uwtable }
attributes #16 = { nounwind }
attributes #17 = { cold nounwind }
attributes #18 = { cold }
attributes #19 = { noreturn nounwind }
attributes #20 = { nounwind allocsize(0,1) }
attributes #21 = { nounwind allocsize(0) }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!911, !912, !913, !914, !915, !916, !917}
!llvm.ident = !{!918}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "conn_lock", scope: !2, file: !3, line: 73, type: !121, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !117, globals: !709, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "thread.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "be16ee2b494b98c02621b129bd3be4cc")
!4 = !{!5, !13, !20, !38, !52, !57, !62, !68, !87, !94, !102, !108}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "pause_thread_types", file: !6, line: 253, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "./memcached.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "a52021954a5d6b153b5bc084e2fbff2b")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12}
!9 = !DIEnumerator(name: "PAUSE_WORKER_THREADS", value: 0)
!10 = !DIEnumerator(name: "PAUSE_ALL_THREADS", value: 1)
!11 = !DIEnumerator(name: "RESUME_ALL_THREADS", value: 2)
!12 = !DIEnumerator(name: "RESUME_WORKER_THREADS", value: 3)
!13 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "conn_queue_item_modes", file: !3, line: 35, baseType: !7, size: 32, elements: !14)
!14 = !{!15, !16, !17, !18, !19}
!15 = !DIEnumerator(name: "queue_new_conn", value: 0)
!16 = !DIEnumerator(name: "queue_pause", value: 1)
!17 = !DIEnumerator(name: "queue_timeout", value: 2)
!18 = !DIEnumerator(name: "queue_redispatch", value: 3)
!19 = !DIEnumerator(name: "queue_stop", value: 4)
!20 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "conn_states", file: !6, line: 204, baseType: !7, size: 32, elements: !21)
!21 = !{!22, !23, !24, !25, !26, !27, !28, !29, !30, !31, !32, !33, !34, !35, !36, !37}
!22 = !DIEnumerator(name: "conn_listening", value: 0)
!23 = !DIEnumerator(name: "conn_new_cmd", value: 1)
!24 = !DIEnumerator(name: "conn_waiting", value: 2)
!25 = !DIEnumerator(name: "conn_read", value: 3)
!26 = !DIEnumerator(name: "conn_parse_cmd", value: 4)
!27 = !DIEnumerator(name: "conn_write", value: 5)
!28 = !DIEnumerator(name: "conn_nread", value: 6)
!29 = !DIEnumerator(name: "conn_swallow", value: 7)
!30 = !DIEnumerator(name: "conn_closing", value: 8)
!31 = !DIEnumerator(name: "conn_mwrite", value: 9)
!32 = !DIEnumerator(name: "conn_closed", value: 10)
!33 = !DIEnumerator(name: "conn_watch", value: 11)
!34 = !DIEnumerator(name: "conn_io_queue", value: 12)
!35 = !DIEnumerator(name: "conn_io_resume", value: 13)
!36 = !DIEnumerator(name: "conn_io_pending", value: 14)
!37 = !DIEnumerator(name: "conn_max_state", value: 15)
!38 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "bin_substates", file: !6, line: 223, baseType: !7, size: 32, elements: !39)
!39 = !{!40, !41, !42, !43, !44, !45, !46, !47, !48, !49, !50, !51}
!40 = !DIEnumerator(name: "bin_no_state", value: 0)
!41 = !DIEnumerator(name: "bin_reading_set_header", value: 1)
!42 = !DIEnumerator(name: "bin_reading_cas_header", value: 2)
!43 = !DIEnumerator(name: "bin_read_set_value", value: 3)
!44 = !DIEnumerator(name: "bin_reading_get_key", value: 4)
!45 = !DIEnumerator(name: "bin_reading_stat", value: 5)
!46 = !DIEnumerator(name: "bin_reading_del_header", value: 6)
!47 = !DIEnumerator(name: "bin_reading_incr_header", value: 7)
!48 = !DIEnumerator(name: "bin_read_flush_exptime", value: 8)
!49 = !DIEnumerator(name: "bin_reading_sasl_auth", value: 9)
!50 = !DIEnumerator(name: "bin_reading_sasl_auth_data", value: 10)
!51 = !DIEnumerator(name: "bin_reading_touch_key", value: 11)
!52 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "protocol", file: !6, line: 238, baseType: !7, size: 32, elements: !53)
!53 = !{!54, !55, !56}
!54 = !DIEnumerator(name: "ascii_prot", value: 3)
!55 = !DIEnumerator(name: "binary_prot", value: 4)
!56 = !DIEnumerator(name: "negotiating_prot", value: 5)
!57 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "network_transport", file: !6, line: 247, baseType: !7, size: 32, elements: !58)
!58 = !{!59, !60, !61}
!59 = !DIEnumerator(name: "local_transport", value: 0)
!60 = !DIEnumerator(name: "tcp_transport", value: 1)
!61 = !DIEnumerator(name: "udp_transport", value: 2)
!62 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "close_reasons", file: !6, line: 266, baseType: !7, size: 32, elements: !63)
!63 = !{!64, !65, !66, !67}
!64 = !DIEnumerator(name: "ERROR_CLOSE", value: 0)
!65 = !DIEnumerator(name: "NORMAL_CLOSE", value: 1)
!66 = !DIEnumerator(name: "IDLE_TIMEOUT_CLOSE", value: 2)
!67 = !DIEnumerator(name: "SHUTDOWN_CLOSE", value: 3)
!68 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "log_entry_type", file: !69, line: 16, baseType: !7, size: 32, elements: !70)
!69 = !DIFile(filename: "./logger.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "e743c4228b1e0bc1c91bec9cfd28d5ab")
!70 = !{!71, !72, !73, !74, !75, !76, !77, !78, !79, !80, !81, !82, !83, !84, !85, !86}
!71 = !DIEnumerator(name: "LOGGER_ASCII_CMD", value: 0)
!72 = !DIEnumerator(name: "LOGGER_EVICTION", value: 1)
!73 = !DIEnumerator(name: "LOGGER_ITEM_GET", value: 2)
!74 = !DIEnumerator(name: "LOGGER_ITEM_STORE", value: 3)
!75 = !DIEnumerator(name: "LOGGER_CRAWLER_STATUS", value: 4)
!76 = !DIEnumerator(name: "LOGGER_SLAB_MOVE", value: 5)
!77 = !DIEnumerator(name: "LOGGER_CONNECTION_NEW", value: 6)
!78 = !DIEnumerator(name: "LOGGER_CONNECTION_CLOSE", value: 7)
!79 = !DIEnumerator(name: "LOGGER_DELETIONS", value: 8)
!80 = !DIEnumerator(name: "LOGGER_EXTSTORE_WRITE", value: 9)
!81 = !DIEnumerator(name: "LOGGER_COMPACT_START", value: 10)
!82 = !DIEnumerator(name: "LOGGER_COMPACT_ABORT", value: 11)
!83 = !DIEnumerator(name: "LOGGER_COMPACT_READ_START", value: 12)
!84 = !DIEnumerator(name: "LOGGER_COMPACT_READ_END", value: 13)
!85 = !DIEnumerator(name: "LOGGER_COMPACT_END", value: 14)
!86 = !DIEnumerator(name: "LOGGER_COMPACT_FRAGINFO", value: 15)
!87 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "delta_result_type", file: !6, line: 295, baseType: !7, size: 32, elements: !88)
!88 = !{!89, !90, !91, !92, !93}
!89 = !DIEnumerator(name: "OK", value: 0)
!90 = !DIEnumerator(name: "NON_NUMERIC", value: 1)
!91 = !DIEnumerator(name: "EOM", value: 2)
!92 = !DIEnumerator(name: "DELTA_ITEM_NOT_FOUND", value: 3)
!93 = !DIEnumerator(name: "DELTA_ITEM_CAS_MISMATCH", value: 4)
!94 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "store_item_type", file: !6, line: 291, baseType: !7, size: 32, elements: !95)
!95 = !{!96, !97, !98, !99, !100, !101}
!96 = !DIEnumerator(name: "NOT_STORED", value: 0)
!97 = !DIEnumerator(name: "STORED", value: 1)
!98 = !DIEnumerator(name: "EXISTS", value: 2)
!99 = !DIEnumerator(name: "NOT_FOUND", value: 3)
!100 = !DIEnumerator(name: "TOO_LARGE", value: 4)
!101 = !DIEnumerator(name: "NO_MEMORY", value: 5)
!102 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !103, line: 23, baseType: !7, size: 32, elements: !104)
!103 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/eventfd.h", directory: "", checksumkind: CSK_MD5, checksum: "b3d7ee281ccca9d6d6400fd95e3c5e2a")
!104 = !{!105, !106, !107}
!105 = !DIEnumerator(name: "EFD_SEMAPHORE", value: 1)
!106 = !DIEnumerator(name: "EFD_CLOEXEC", value: 524288)
!107 = !DIEnumerator(name: "EFD_NONBLOCK", value: 2048)
!108 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "event_base_config_flag", file: !109, line: 529, baseType: !7, size: 32, elements: !110)
!109 = !DIFile(filename: "/usr/include/event2/event.h", directory: "", checksumkind: CSK_MD5, checksum: "90db4fa73456052afa8984291985dfd5")
!110 = !{!111, !112, !113, !114, !115, !116}
!111 = !DIEnumerator(name: "EVENT_BASE_FLAG_NOLOCK", value: 1)
!112 = !DIEnumerator(name: "EVENT_BASE_FLAG_IGNORE_ENV", value: 2)
!113 = !DIEnumerator(name: "EVENT_BASE_FLAG_STARTUP_IOCP", value: 4)
!114 = !DIEnumerator(name: "EVENT_BASE_FLAG_NO_CACHE_TIME", value: 8)
!115 = !DIEnumerator(name: "EVENT_BASE_FLAG_EPOLL_USE_CHANGELIST", value: 16)
!116 = !DIEnumerator(name: "EVENT_BASE_FLAG_PRECISE_TIMER", value: 32)
!117 = !{!118, !119, !120, !153, !154}
!118 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!119 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!120 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !121, size: 64)
!121 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutex_t", file: !122, line: 72, baseType: !123)
!122 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h", directory: "", checksumkind: CSK_MD5, checksum: "8a5acdbeec491eca11cf81cb1ef77ea7")
!123 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !122, line: 67, size: 320, elements: !124)
!124 = !{!125, !146, !151}
!125 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !123, file: !122, line: 69, baseType: !126, size: 320)
!126 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_mutex_s", file: !127, line: 22, size: 320, elements: !128)
!127 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h", directory: "", checksumkind: CSK_MD5, checksum: "6b075eca9ab0e2d761b2afc4ecfab776")
!128 = !{!129, !131, !132, !133, !134, !135, !137, !138}
!129 = !DIDerivedType(tag: DW_TAG_member, name: "__lock", scope: !126, file: !127, line: 24, baseType: !130, size: 32)
!130 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!131 = !DIDerivedType(tag: DW_TAG_member, name: "__count", scope: !126, file: !127, line: 25, baseType: !7, size: 32, offset: 32)
!132 = !DIDerivedType(tag: DW_TAG_member, name: "__owner", scope: !126, file: !127, line: 26, baseType: !130, size: 32, offset: 64)
!133 = !DIDerivedType(tag: DW_TAG_member, name: "__nusers", scope: !126, file: !127, line: 28, baseType: !7, size: 32, offset: 96)
!134 = !DIDerivedType(tag: DW_TAG_member, name: "__kind", scope: !126, file: !127, line: 32, baseType: !130, size: 32, offset: 128)
!135 = !DIDerivedType(tag: DW_TAG_member, name: "__spins", scope: !126, file: !127, line: 34, baseType: !136, size: 16, offset: 160)
!136 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!137 = !DIDerivedType(tag: DW_TAG_member, name: "__elision", scope: !126, file: !127, line: 35, baseType: !136, size: 16, offset: 176)
!138 = !DIDerivedType(tag: DW_TAG_member, name: "__list", scope: !126, file: !127, line: 36, baseType: !139, size: 128, offset: 192)
!139 = !DIDerivedType(tag: DW_TAG_typedef, name: "__pthread_list_t", file: !140, line: 55, baseType: !141)
!140 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h", directory: "", checksumkind: CSK_MD5, checksum: "b9a7199822bce372686baacd32a9f4f3")
!141 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_internal_list", file: !140, line: 51, size: 128, elements: !142)
!142 = !{!143, !145}
!143 = !DIDerivedType(tag: DW_TAG_member, name: "__prev", scope: !141, file: !140, line: 53, baseType: !144, size: 64)
!144 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !141, size: 64)
!145 = !DIDerivedType(tag: DW_TAG_member, name: "__next", scope: !141, file: !140, line: 54, baseType: !144, size: 64, offset: 64)
!146 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !123, file: !122, line: 70, baseType: !147, size: 320)
!147 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 320, elements: !149)
!148 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!149 = !{!150}
!150 = !DISubrange(count: 40)
!151 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !123, file: !122, line: 71, baseType: !152, size: 64)
!152 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!153 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !148, size: 64)
!154 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !155, size: 64)
!155 = !DIDerivedType(tag: DW_TAG_typedef, name: "LIBEVENT_THREAD", file: !6, line: 765, baseType: !156)
!156 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !6, line: 721, size: 55488, elements: !157)
!157 = !{!158, !160, !164, !252, !253, !254, !507, !508, !509, !564, !577, !632, !633, !634, !635, !636, !707, !708}
!158 = !DIDerivedType(tag: DW_TAG_member, name: "thread_id", scope: !156, file: !6, line: 722, baseType: !159, size: 64)
!159 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_t", file: !122, line: 27, baseType: !118)
!160 = !DIDerivedType(tag: DW_TAG_member, name: "base", scope: !156, file: !6, line: 723, baseType: !161, size: 64, offset: 64)
!161 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !162, size: 64)
!162 = !DICompositeType(tag: DW_TAG_structure_type, name: "event_base", file: !163, line: 122, flags: DIFlagFwdDecl)
!163 = !DIFile(filename: "/usr/include/event2/event_struct.h", directory: "", checksumkind: CSK_MD5, checksum: "005d89b34bed2ed9e30b0cc3160619c1")
!164 = !DIDerivedType(tag: DW_TAG_member, name: "n", scope: !156, file: !6, line: 724, baseType: !165, size: 1088, offset: 128)
!165 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_notify", file: !6, line: 710, size: 1088, elements: !166)
!166 = !{!167, !251}
!167 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event", scope: !165, file: !6, line: 711, baseType: !168, size: 1024)
!168 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event", file: !163, line: 123, size: 1024, elements: !169)
!169 = !{!170, !206, !216, !217, !218, !248, !249, !250}
!170 = !DIDerivedType(tag: DW_TAG_member, name: "ev_evcallback", scope: !168, file: !163, line: 124, baseType: !171, size: 320)
!171 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event_callback", file: !163, line: 107, size: 320, elements: !172)
!172 = !{!173, !180, !181, !187, !188, !205}
!173 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_active_next", scope: !171, file: !163, line: 108, baseType: !174, size: 128)
!174 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !171, file: !163, line: 108, size: 128, elements: !175)
!175 = !{!176, !178}
!176 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !174, file: !163, line: 108, baseType: !177, size: 64)
!177 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !171, size: 64)
!178 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !174, file: !163, line: 108, baseType: !179, size: 64, offset: 64)
!179 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !177, size: 64)
!180 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_flags", scope: !171, file: !163, line: 109, baseType: !136, size: 16, offset: 128)
!181 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_pri", scope: !171, file: !163, line: 110, baseType: !182, size: 8, offset: 144)
!182 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !183, line: 24, baseType: !184)
!183 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!184 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !185, line: 38, baseType: !186)
!185 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!186 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!187 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_closure", scope: !171, file: !163, line: 111, baseType: !182, size: 8, offset: 152)
!188 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cb_union", scope: !171, file: !163, line: 118, baseType: !189, size: 64, offset: 192)
!189 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !171, file: !163, line: 113, size: 64, elements: !190)
!190 = !{!191, !195, !199, !204}
!191 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_callback", scope: !189, file: !163, line: 114, baseType: !192, size: 64)
!192 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !193, size: 64)
!193 = !DISubroutineType(types: !194)
!194 = !{null, !130, !136, !119}
!195 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_selfcb", scope: !189, file: !163, line: 115, baseType: !196, size: 64)
!196 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !197, size: 64)
!197 = !DISubroutineType(types: !198)
!198 = !{null, !177, !119}
!199 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_evfinalize", scope: !189, file: !163, line: 116, baseType: !200, size: 64)
!200 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !201, size: 64)
!201 = !DISubroutineType(types: !202)
!202 = !{null, !203, !119}
!203 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !168, size: 64)
!204 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cbfinalize", scope: !189, file: !163, line: 117, baseType: !196, size: 64)
!205 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_arg", scope: !171, file: !163, line: 119, baseType: !119, size: 64, offset: 256)
!206 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout_pos", scope: !168, file: !163, line: 130, baseType: !207, size: 128, offset: 320)
!207 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !168, file: !163, line: 127, size: 128, elements: !208)
!208 = !{!209, !215}
!209 = !DIDerivedType(tag: DW_TAG_member, name: "ev_next_with_common_timeout", scope: !207, file: !163, line: 128, baseType: !210, size: 128)
!210 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !207, file: !163, line: 128, size: 128, elements: !211)
!211 = !{!212, !213}
!212 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !210, file: !163, line: 128, baseType: !203, size: 64)
!213 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !210, file: !163, line: 128, baseType: !214, size: 64, offset: 64)
!214 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !203, size: 64)
!215 = !DIDerivedType(tag: DW_TAG_member, name: "min_heap_idx", scope: !207, file: !163, line: 129, baseType: !130, size: 32)
!216 = !DIDerivedType(tag: DW_TAG_member, name: "ev_fd", scope: !168, file: !163, line: 131, baseType: !130, size: 32, offset: 448)
!217 = !DIDerivedType(tag: DW_TAG_member, name: "ev_base", scope: !168, file: !163, line: 133, baseType: !161, size: 64, offset: 512)
!218 = !DIDerivedType(tag: DW_TAG_member, name: "ev_", scope: !168, file: !163, line: 149, baseType: !219, size: 256, offset: 576)
!219 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !168, file: !163, line: 135, size: 256, elements: !220)
!220 = !{!221, !237}
!221 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io", scope: !219, file: !163, line: 140, baseType: !222, size: 256)
!222 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !219, file: !163, line: 137, size: 256, elements: !223)
!223 = !{!224, !229}
!224 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io_next", scope: !222, file: !163, line: 138, baseType: !225, size: 128)
!225 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !222, file: !163, line: 138, size: 128, elements: !226)
!226 = !{!227, !228}
!227 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !225, file: !163, line: 138, baseType: !203, size: 64)
!228 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !225, file: !163, line: 138, baseType: !214, size: 64, offset: 64)
!229 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !222, file: !163, line: 139, baseType: !230, size: 128, offset: 128)
!230 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "timeval", file: !231, line: 8, size: 128, elements: !232)
!231 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h", directory: "", checksumkind: CSK_MD5, checksum: "9b45d950050c215f216850b27bd1e8f3")
!232 = !{!233, !235}
!233 = !DIDerivedType(tag: DW_TAG_member, name: "tv_sec", scope: !230, file: !231, line: 14, baseType: !234, size: 64)
!234 = !DIDerivedType(tag: DW_TAG_typedef, name: "__time_t", file: !185, line: 160, baseType: !152)
!235 = !DIDerivedType(tag: DW_TAG_member, name: "tv_usec", scope: !230, file: !231, line: 15, baseType: !236, size: 64, offset: 64)
!236 = !DIDerivedType(tag: DW_TAG_typedef, name: "__suseconds_t", file: !185, line: 162, baseType: !152)
!237 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal", scope: !219, file: !163, line: 148, baseType: !238, size: 256)
!238 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !219, file: !163, line: 143, size: 256, elements: !239)
!239 = !{!240, !245, !246}
!240 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal_next", scope: !238, file: !163, line: 144, baseType: !241, size: 128)
!241 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !238, file: !163, line: 144, size: 128, elements: !242)
!242 = !{!243, !244}
!243 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !241, file: !163, line: 144, baseType: !203, size: 64)
!244 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !241, file: !163, line: 144, baseType: !214, size: 64, offset: 64)
!245 = !DIDerivedType(tag: DW_TAG_member, name: "ev_ncalls", scope: !238, file: !163, line: 145, baseType: !136, size: 16, offset: 128)
!246 = !DIDerivedType(tag: DW_TAG_member, name: "ev_pncalls", scope: !238, file: !163, line: 147, baseType: !247, size: 64, offset: 192)
!247 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !136, size: 64)
!248 = !DIDerivedType(tag: DW_TAG_member, name: "ev_events", scope: !168, file: !163, line: 151, baseType: !136, size: 16, offset: 832)
!249 = !DIDerivedType(tag: DW_TAG_member, name: "ev_res", scope: !168, file: !163, line: 152, baseType: !136, size: 16, offset: 848)
!250 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !168, file: !163, line: 153, baseType: !230, size: 128, offset: 896)
!251 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event_fd", scope: !165, file: !6, line: 713, baseType: !130, size: 32, offset: 1024)
!252 = !DIDerivedType(tag: DW_TAG_member, name: "ion", scope: !156, file: !6, line: 725, baseType: !165, size: 1088, offset: 1216)
!253 = !DIDerivedType(tag: DW_TAG_member, name: "ion_lock", scope: !156, file: !6, line: 726, baseType: !121, size: 320, offset: 2304)
!254 = !DIDerivedType(tag: DW_TAG_member, name: "ion_head", scope: !156, file: !6, line: 727, baseType: !255, size: 128, offset: 2624)
!255 = !DIDerivedType(tag: DW_TAG_typedef, name: "iop_head_t", file: !6, line: 686, baseType: !256)
!256 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iop_head_s", file: !6, line: 686, size: 128, elements: !257)
!257 = !{!258, !505}
!258 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !256, file: !6, line: 686, baseType: !259, size: 64)
!259 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !260, size: 64)
!260 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_io_pending_t", file: !6, line: 815, size: 1408, elements: !261)
!261 = !{!262, !263, !264, !490, !491, !496, !497, !501}
!262 = !DIDerivedType(tag: DW_TAG_member, name: "io_queue_type", scope: !260, file: !6, line: 816, baseType: !130, size: 32)
!263 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !260, file: !6, line: 817, baseType: !154, size: 64, offset: 64)
!264 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !260, file: !6, line: 818, baseType: !265, size: 64, offset: 128)
!265 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !266, size: 64)
!266 = !DIDerivedType(tag: DW_TAG_typedef, name: "conn", file: !6, line: 813, baseType: !267)
!267 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "conn", file: !6, line: 829, size: 3968, elements: !268)
!268 = !{!269, !273, !274, !276, !277, !278, !279, !280, !281, !282, !283, !284, !286, !287, !288, !289, !290, !291, !292, !293, !404, !405, !406, !407, !408, !409, !410, !421, !422, !423, !424, !425, !426, !427, !428, !429, !435, !456, !457, !458, !459, !460, !461, !462, !463, !467, !474, !489}
!269 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_conn", scope: !267, file: !6, line: 830, baseType: !270, size: 64)
!270 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !271, size: 64)
!271 = !DIDerivedType(tag: DW_TAG_typedef, name: "sasl_conn_t", file: !272, line: 16, baseType: !119)
!272 = !DIFile(filename: "./sasl_defs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "3a8678a43d09d8e311388b26eedc7a3e")
!273 = !DIDerivedType(tag: DW_TAG_member, name: "sfd", scope: !267, file: !6, line: 831, baseType: !130, size: 32, offset: 64)
!274 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_started", scope: !267, file: !6, line: 832, baseType: !275, size: 8, offset: 96)
!275 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!276 = !DIDerivedType(tag: DW_TAG_member, name: "authenticated", scope: !267, file: !6, line: 833, baseType: !275, size: 8, offset: 104)
!277 = !DIDerivedType(tag: DW_TAG_member, name: "set_stale", scope: !267, file: !6, line: 834, baseType: !275, size: 8, offset: 112)
!278 = !DIDerivedType(tag: DW_TAG_member, name: "mset_res", scope: !267, file: !6, line: 835, baseType: !275, size: 8, offset: 120)
!279 = !DIDerivedType(tag: DW_TAG_member, name: "close_after_write", scope: !267, file: !6, line: 836, baseType: !275, size: 8, offset: 128)
!280 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_malloced", scope: !267, file: !6, line: 837, baseType: !275, size: 8, offset: 136)
!281 = !DIDerivedType(tag: DW_TAG_member, name: "item_malloced", scope: !267, file: !6, line: 838, baseType: !275, size: 8, offset: 144)
!282 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !267, file: !6, line: 844, baseType: !20, size: 32, offset: 160)
!283 = !DIDerivedType(tag: DW_TAG_member, name: "substate", scope: !267, file: !6, line: 845, baseType: !38, size: 32, offset: 192)
!284 = !DIDerivedType(tag: DW_TAG_member, name: "last_cmd_time", scope: !267, file: !6, line: 846, baseType: !285, size: 32, offset: 224)
!285 = !DIDerivedType(tag: DW_TAG_typedef, name: "rel_time_t", file: !69, line: 14, baseType: !7)
!286 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !267, file: !6, line: 847, baseType: !168, size: 1024, offset: 256)
!287 = !DIDerivedType(tag: DW_TAG_member, name: "ev_flags", scope: !267, file: !6, line: 848, baseType: !136, size: 16, offset: 1280)
!288 = !DIDerivedType(tag: DW_TAG_member, name: "which", scope: !267, file: !6, line: 849, baseType: !136, size: 16, offset: 1296)
!289 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf", scope: !267, file: !6, line: 851, baseType: !153, size: 64, offset: 1344)
!290 = !DIDerivedType(tag: DW_TAG_member, name: "rcurr", scope: !267, file: !6, line: 852, baseType: !153, size: 64, offset: 1408)
!291 = !DIDerivedType(tag: DW_TAG_member, name: "rsize", scope: !267, file: !6, line: 853, baseType: !130, size: 32, offset: 1472)
!292 = !DIDerivedType(tag: DW_TAG_member, name: "rbytes", scope: !267, file: !6, line: 854, baseType: !130, size: 32, offset: 1504)
!293 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !267, file: !6, line: 856, baseType: !294, size: 64, offset: 1536)
!294 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !295, size: 64)
!295 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp", file: !6, line: 801, baseType: !296)
!296 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp", file: !6, line: 771, size: 9472, elements: !297)
!297 = !{!298, !313, !315, !316, !317, !318, !321, !348, !359, !360, !361, !362, !363, !364, !365, !366, !367, !396, !400}
!298 = !DIDerivedType(tag: DW_TAG_member, name: "bundle", scope: !296, file: !6, line: 772, baseType: !299, size: 64)
!299 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !300, size: 64)
!300 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp_bundle", file: !6, line: 720, baseType: !301)
!301 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp_bundle", file: !6, line: 804, size: 256, elements: !302)
!302 = !{!303, !304, !305, !306, !308, !309}
!303 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !301, file: !6, line: 805, baseType: !182, size: 8)
!304 = !DIDerivedType(tag: DW_TAG_member, name: "next_check", scope: !301, file: !6, line: 806, baseType: !182, size: 8, offset: 8)
!305 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !301, file: !6, line: 807, baseType: !154, size: 64, offset: 64)
!306 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !301, file: !6, line: 808, baseType: !307, size: 64, offset: 128)
!307 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !301, size: 64)
!308 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !301, file: !6, line: 809, baseType: !307, size: 64, offset: 192)
!309 = !DIDerivedType(tag: DW_TAG_member, name: "r", scope: !301, file: !6, line: 810, baseType: !310, offset: 256)
!310 = !DICompositeType(tag: DW_TAG_array_type, baseType: !295, elements: !311)
!311 = !{!312}
!312 = !DISubrange(count: -1)
!313 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !296, file: !6, line: 773, baseType: !314, size: 64, offset: 64)
!314 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !296, size: 64)
!315 = !DIDerivedType(tag: DW_TAG_member, name: "wbytes", scope: !296, file: !6, line: 774, baseType: !130, size: 32, offset: 128)
!316 = !DIDerivedType(tag: DW_TAG_member, name: "tosend", scope: !296, file: !6, line: 775, baseType: !130, size: 32, offset: 160)
!317 = !DIDerivedType(tag: DW_TAG_member, name: "write_and_free", scope: !296, file: !6, line: 776, baseType: !119, size: 64, offset: 192)
!318 = !DIDerivedType(tag: DW_TAG_member, name: "io_pending", scope: !296, file: !6, line: 777, baseType: !319, size: 64, offset: 256)
!319 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !320, size: 64)
!320 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_pending_t", file: !6, line: 687, baseType: !260)
!321 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !296, file: !6, line: 779, baseType: !322, size: 64, offset: 320)
!322 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !323, size: 64)
!323 = !DIDerivedType(tag: DW_TAG_typedef, name: "item", file: !6, line: 616, baseType: !324)
!324 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_stritem", file: !6, line: 593, size: 384, elements: !325)
!325 = !{!326, !328, !329, !330, !331, !332, !333, !335, !338, !339, !340}
!326 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !324, file: !6, line: 595, baseType: !327, size: 64)
!327 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !324, size: 64)
!328 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !324, file: !6, line: 596, baseType: !327, size: 64, offset: 64)
!329 = !DIDerivedType(tag: DW_TAG_member, name: "h_next", scope: !324, file: !6, line: 598, baseType: !327, size: 64, offset: 128)
!330 = !DIDerivedType(tag: DW_TAG_member, name: "time", scope: !324, file: !6, line: 599, baseType: !285, size: 32, offset: 192)
!331 = !DIDerivedType(tag: DW_TAG_member, name: "exptime", scope: !324, file: !6, line: 600, baseType: !285, size: 32, offset: 224)
!332 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !324, file: !6, line: 601, baseType: !130, size: 32, offset: 256)
!333 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !324, file: !6, line: 602, baseType: !334, size: 16, offset: 288)
!334 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!335 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !324, file: !6, line: 603, baseType: !336, size: 16, offset: 304)
!336 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint16_t", file: !183, line: 25, baseType: !337)
!337 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint16_t", file: !185, line: 40, baseType: !334)
!338 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !324, file: !6, line: 604, baseType: !182, size: 8, offset: 320)
!339 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !324, file: !6, line: 605, baseType: !182, size: 8, offset: 328)
!340 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !324, file: !6, line: 611, baseType: !341, offset: 384)
!341 = !DICompositeType(tag: DW_TAG_array_type, baseType: !342, elements: !311)
!342 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !324, file: !6, line: 608, size: 64, elements: !343)
!343 = !{!344, !347}
!344 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !342, file: !6, line: 609, baseType: !345, size: 64)
!345 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !183, line: 27, baseType: !346)
!346 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !185, line: 45, baseType: !118)
!347 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !342, file: !6, line: 610, baseType: !148, size: 8)
!348 = !DIDerivedType(tag: DW_TAG_member, name: "iov", scope: !296, file: !6, line: 780, baseType: !349, size: 512, offset: 384)
!349 = !DICompositeType(tag: DW_TAG_array_type, baseType: !350, size: 512, elements: !357)
!350 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iovec", file: !351, line: 26, size: 128, elements: !352)
!351 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_iovec.h", directory: "", checksumkind: CSK_MD5, checksum: "a53f2c2488bb0e21e47850624c16538a")
!352 = !{!353, !354}
!353 = !DIDerivedType(tag: DW_TAG_member, name: "iov_base", scope: !350, file: !351, line: 28, baseType: !119, size: 64)
!354 = !DIDerivedType(tag: DW_TAG_member, name: "iov_len", scope: !350, file: !351, line: 29, baseType: !355, size: 64, offset: 64)
!355 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !356, line: 18, baseType: !118)
!356 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!357 = !{!358}
!358 = !DISubrange(count: 4)
!359 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_total", scope: !296, file: !6, line: 781, baseType: !130, size: 32, offset: 896)
!360 = !DIDerivedType(tag: DW_TAG_member, name: "iovcnt", scope: !296, file: !6, line: 782, baseType: !182, size: 8, offset: 928)
!361 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_data_iov", scope: !296, file: !6, line: 783, baseType: !182, size: 8, offset: 936)
!362 = !DIDerivedType(tag: DW_TAG_member, name: "skip", scope: !296, file: !6, line: 788, baseType: !275, size: 8, offset: 944)
!363 = !DIDerivedType(tag: DW_TAG_member, name: "free", scope: !296, file: !6, line: 789, baseType: !275, size: 8, offset: 952)
!364 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !296, file: !6, line: 794, baseType: !336, size: 16, offset: 960)
!365 = !DIDerivedType(tag: DW_TAG_member, name: "udp_sequence", scope: !296, file: !6, line: 795, baseType: !336, size: 16, offset: 976)
!366 = !DIDerivedType(tag: DW_TAG_member, name: "udp_total", scope: !296, file: !6, line: 796, baseType: !336, size: 16, offset: 992)
!367 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !296, file: !6, line: 797, baseType: !368, size: 224, offset: 1024)
!368 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "sockaddr_in6", file: !369, line: 262, size: 224, elements: !370)
!369 = !DIFile(filename: "/usr/include/netinet/in.h", directory: "", checksumkind: CSK_MD5, checksum: "fbd766480c8cb9a8fe07ee7aa568ee60")
!370 = !{!371, !374, !376, !379, !395}
!371 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_family", scope: !368, file: !369, line: 264, baseType: !372, size: 16)
!372 = !DIDerivedType(tag: DW_TAG_typedef, name: "sa_family_t", file: !373, line: 28, baseType: !334)
!373 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/sockaddr.h", directory: "", checksumkind: CSK_MD5, checksum: "5066b774f0f3cdb5cbbb5467306060db")
!374 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_port", scope: !368, file: !369, line: 265, baseType: !375, size: 16, offset: 16)
!375 = !DIDerivedType(tag: DW_TAG_typedef, name: "in_port_t", file: !369, line: 125, baseType: !336)
!376 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_flowinfo", scope: !368, file: !369, line: 266, baseType: !377, size: 32, offset: 32)
!377 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !183, line: 26, baseType: !378)
!378 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !185, line: 42, baseType: !7)
!379 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_addr", scope: !368, file: !369, line: 267, baseType: !380, size: 128, offset: 64)
!380 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "in6_addr", file: !369, line: 221, size: 128, elements: !381)
!381 = !{!382}
!382 = !DIDerivedType(tag: DW_TAG_member, name: "__in6_u", scope: !380, file: !369, line: 228, baseType: !383, size: 128)
!383 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !380, file: !369, line: 223, size: 128, elements: !384)
!384 = !{!385, !389, !393}
!385 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr8", scope: !383, file: !369, line: 225, baseType: !386, size: 128)
!386 = !DICompositeType(tag: DW_TAG_array_type, baseType: !182, size: 128, elements: !387)
!387 = !{!388}
!388 = !DISubrange(count: 16)
!389 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr16", scope: !383, file: !369, line: 226, baseType: !390, size: 128)
!390 = !DICompositeType(tag: DW_TAG_array_type, baseType: !336, size: 128, elements: !391)
!391 = !{!392}
!392 = !DISubrange(count: 8)
!393 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr32", scope: !383, file: !369, line: 227, baseType: !394, size: 128)
!394 = !DICompositeType(tag: DW_TAG_array_type, baseType: !377, size: 128, elements: !357)
!395 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_scope_id", scope: !368, file: !369, line: 268, baseType: !377, size: 32, offset: 192)
!396 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !296, file: !6, line: 798, baseType: !397, size: 32, offset: 1248)
!397 = !DIDerivedType(tag: DW_TAG_typedef, name: "socklen_t", file: !398, line: 33, baseType: !399)
!398 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/socket.h", directory: "", checksumkind: CSK_MD5, checksum: "71a09f67661e8e55cf505c19b5ddbb85")
!399 = !DIDerivedType(tag: DW_TAG_typedef, name: "__socklen_t", file: !185, line: 210, baseType: !7)
!400 = !DIDerivedType(tag: DW_TAG_member, name: "wbuf", scope: !296, file: !6, line: 800, baseType: !401, size: 8192, offset: 1280)
!401 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 8192, elements: !402)
!402 = !{!403}
!403 = !DISubrange(count: 1024)
!404 = !DIDerivedType(tag: DW_TAG_member, name: "resp_head", scope: !267, file: !6, line: 857, baseType: !294, size: 64, offset: 1600)
!405 = !DIDerivedType(tag: DW_TAG_member, name: "ritem", scope: !267, file: !6, line: 858, baseType: !153, size: 64, offset: 1664)
!406 = !DIDerivedType(tag: DW_TAG_member, name: "rlbytes", scope: !267, file: !6, line: 859, baseType: !130, size: 32, offset: 1728)
!407 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !267, file: !6, line: 867, baseType: !119, size: 64, offset: 1792)
!408 = !DIDerivedType(tag: DW_TAG_member, name: "sbytes", scope: !267, file: !6, line: 870, baseType: !130, size: 32, offset: 1856)
!409 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues_submitted", scope: !267, file: !6, line: 872, baseType: !130, size: 32, offset: 1888)
!410 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !267, file: !6, line: 873, baseType: !411, size: 576, offset: 1920)
!411 = !DICompositeType(tag: DW_TAG_array_type, baseType: !412, size: 576, elements: !419)
!412 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_t", file: !6, line: 688, baseType: !413)
!413 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_s", file: !6, line: 697, size: 192, elements: !414)
!414 = !{!415, !416, !417, !418}
!415 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !413, file: !6, line: 698, baseType: !119, size: 64)
!416 = !DIDerivedType(tag: DW_TAG_member, name: "stack_ctx", scope: !413, file: !6, line: 699, baseType: !119, size: 64, offset: 64)
!417 = !DIDerivedType(tag: DW_TAG_member, name: "count", scope: !413, file: !6, line: 700, baseType: !130, size: 32, offset: 128)
!418 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !413, file: !6, line: 701, baseType: !130, size: 32, offset: 160)
!419 = !{!420}
!420 = !DISubrange(count: 3)
!421 = !DIDerivedType(tag: DW_TAG_member, name: "recache_counter", scope: !267, file: !6, line: 878, baseType: !7, size: 32, offset: 2496)
!422 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !267, file: !6, line: 880, baseType: !52, size: 32, offset: 2528)
!423 = !DIDerivedType(tag: DW_TAG_member, name: "transport", scope: !267, file: !6, line: 881, baseType: !57, size: 32, offset: 2560)
!424 = !DIDerivedType(tag: DW_TAG_member, name: "close_reason", scope: !267, file: !6, line: 882, baseType: !62, size: 32, offset: 2592)
!425 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !267, file: !6, line: 885, baseType: !130, size: 32, offset: 2624)
!426 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !267, file: !6, line: 886, baseType: !368, size: 224, offset: 2656)
!427 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !267, file: !6, line: 887, baseType: !397, size: 32, offset: 2880)
!428 = !DIDerivedType(tag: DW_TAG_member, name: "noreply", scope: !267, file: !6, line: 889, baseType: !275, size: 8, offset: 2912)
!429 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !267, file: !6, line: 895, baseType: !430, size: 192, offset: 2944)
!430 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !267, file: !6, line: 891, size: 192, elements: !431)
!431 = !{!432, !433, !434}
!432 = !DIDerivedType(tag: DW_TAG_member, name: "buffer", scope: !430, file: !6, line: 892, baseType: !153, size: 64)
!433 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !430, file: !6, line: 893, baseType: !355, size: 64, offset: 64)
!434 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !430, file: !6, line: 894, baseType: !355, size: 64, offset: 128)
!435 = !DIDerivedType(tag: DW_TAG_member, name: "binary_header", scope: !267, file: !6, line: 899, baseType: !436, size: 192, offset: 3136)
!436 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_request_header", file: !437, line: 164, baseType: !438)
!437 = !DIFile(filename: "./protocol_binary.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "7a322a65fa8661e9a597acbeeeb23107")
!438 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !437, line: 151, size: 192, elements: !439)
!439 = !{!440, !452}
!440 = !DIDerivedType(tag: DW_TAG_member, name: "request", scope: !438, file: !437, line: 162, baseType: !441, size: 192)
!441 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !438, file: !437, line: 152, size: 192, elements: !442)
!442 = !{!443, !444, !445, !446, !447, !448, !449, !450, !451}
!443 = !DIDerivedType(tag: DW_TAG_member, name: "magic", scope: !441, file: !437, line: 153, baseType: !182, size: 8)
!444 = !DIDerivedType(tag: DW_TAG_member, name: "opcode", scope: !441, file: !437, line: 154, baseType: !182, size: 8, offset: 8)
!445 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !441, file: !437, line: 155, baseType: !336, size: 16, offset: 16)
!446 = !DIDerivedType(tag: DW_TAG_member, name: "extlen", scope: !441, file: !437, line: 156, baseType: !182, size: 8, offset: 32)
!447 = !DIDerivedType(tag: DW_TAG_member, name: "datatype", scope: !441, file: !437, line: 157, baseType: !182, size: 8, offset: 40)
!448 = !DIDerivedType(tag: DW_TAG_member, name: "reserved", scope: !441, file: !437, line: 158, baseType: !336, size: 16, offset: 48)
!449 = !DIDerivedType(tag: DW_TAG_member, name: "bodylen", scope: !441, file: !437, line: 159, baseType: !377, size: 32, offset: 64)
!450 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !441, file: !437, line: 160, baseType: !377, size: 32, offset: 96)
!451 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !441, file: !437, line: 161, baseType: !345, size: 64, offset: 128)
!452 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !438, file: !437, line: 163, baseType: !453, size: 192)
!453 = !DICompositeType(tag: DW_TAG_array_type, baseType: !182, size: 192, elements: !454)
!454 = !{!455}
!455 = !DISubrange(count: 24)
!456 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !267, file: !6, line: 900, baseType: !345, size: 64, offset: 3328)
!457 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !267, file: !6, line: 901, baseType: !345, size: 64, offset: 3392)
!458 = !DIDerivedType(tag: DW_TAG_member, name: "cmd", scope: !267, file: !6, line: 902, baseType: !136, size: 16, offset: 3456)
!459 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !267, file: !6, line: 903, baseType: !130, size: 32, offset: 3488)
!460 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !267, file: !6, line: 904, baseType: !130, size: 32, offset: 3520)
!461 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !267, file: !6, line: 905, baseType: !265, size: 64, offset: 3584)
!462 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !267, file: !6, line: 906, baseType: !154, size: 64, offset: 3648)
!463 = !DIDerivedType(tag: DW_TAG_member, name: "try_read_command", scope: !267, file: !6, line: 907, baseType: !464, size: 64, offset: 3712)
!464 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !465, size: 64)
!465 = !DISubroutineType(types: !466)
!466 = !{!130, !265}
!467 = !DIDerivedType(tag: DW_TAG_member, name: "read", scope: !267, file: !6, line: 908, baseType: !468, size: 64, offset: 3776)
!468 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !469, size: 64)
!469 = !DISubroutineType(types: !470)
!470 = !{!471, !265, !119, !355}
!471 = !DIDerivedType(tag: DW_TAG_typedef, name: "ssize_t", file: !472, line: 108, baseType: !473)
!472 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/types.h", directory: "", checksumkind: CSK_MD5, checksum: "7fb02a803b0c9b11cb5276b77d21e9d8")
!473 = !DIDerivedType(tag: DW_TAG_typedef, name: "__ssize_t", file: !185, line: 194, baseType: !152)
!474 = !DIDerivedType(tag: DW_TAG_member, name: "sendmsg", scope: !267, file: !6, line: 909, baseType: !475, size: 64, offset: 3840)
!475 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !476, size: 64)
!476 = !DISubroutineType(types: !477)
!477 = !{!471, !265, !478, !130}
!478 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !479, size: 64)
!479 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "msghdr", file: !398, line: 262, size: 448, elements: !480)
!480 = !{!481, !482, !483, !485, !486, !487, !488}
!481 = !DIDerivedType(tag: DW_TAG_member, name: "msg_name", scope: !479, file: !398, line: 264, baseType: !119, size: 64)
!482 = !DIDerivedType(tag: DW_TAG_member, name: "msg_namelen", scope: !479, file: !398, line: 265, baseType: !397, size: 32, offset: 64)
!483 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iov", scope: !479, file: !398, line: 267, baseType: !484, size: 64, offset: 128)
!484 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !350, size: 64)
!485 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iovlen", scope: !479, file: !398, line: 268, baseType: !355, size: 64, offset: 192)
!486 = !DIDerivedType(tag: DW_TAG_member, name: "msg_control", scope: !479, file: !398, line: 270, baseType: !119, size: 64, offset: 256)
!487 = !DIDerivedType(tag: DW_TAG_member, name: "msg_controllen", scope: !479, file: !398, line: 271, baseType: !355, size: 64, offset: 320)
!488 = !DIDerivedType(tag: DW_TAG_member, name: "msg_flags", scope: !479, file: !398, line: 276, baseType: !130, size: 32, offset: 384)
!489 = !DIDerivedType(tag: DW_TAG_member, name: "write", scope: !267, file: !6, line: 910, baseType: !468, size: 64, offset: 3904)
!490 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !260, file: !6, line: 819, baseType: !294, size: 64, offset: 192)
!491 = !DIDerivedType(tag: DW_TAG_member, name: "return_cb", scope: !260, file: !6, line: 820, baseType: !492, size: 64, offset: 256)
!492 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb", file: !6, line: 690, baseType: !493)
!493 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !494, size: 64)
!494 = !DISubroutineType(types: !495)
!495 = !{null, !319}
!496 = !DIDerivedType(tag: DW_TAG_member, name: "finalize_cb", scope: !260, file: !6, line: 821, baseType: !492, size: 64, offset: 320)
!497 = !DIDerivedType(tag: DW_TAG_member, name: "iop_next", scope: !260, file: !6, line: 822, baseType: !498, size: 64, offset: 384)
!498 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !260, file: !6, line: 822, size: 64, elements: !499)
!499 = !{!500}
!500 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !498, file: !6, line: 822, baseType: !259, size: 64)
!501 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !260, file: !6, line: 823, baseType: !502, size: 960, offset: 448)
!502 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 960, elements: !503)
!503 = !{!504}
!504 = !DISubrange(count: 120)
!505 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !256, file: !6, line: 686, baseType: !506, size: 64, offset: 64)
!506 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !259, size: 64)
!507 = !DIDerivedType(tag: DW_TAG_member, name: "cur_sfd", scope: !156, file: !6, line: 728, baseType: !130, size: 32, offset: 2752)
!508 = !DIDerivedType(tag: DW_TAG_member, name: "thread_baseid", scope: !156, file: !6, line: 729, baseType: !130, size: 32, offset: 2784)
!509 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !156, file: !6, line: 730, baseType: !510, size: 51584, offset: 2816)
!510 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_stats", file: !6, line: 372, size: 51584, elements: !511)
!511 = !{!512, !513, !514, !515, !516, !517, !518, !519, !520, !521, !522, !523, !524, !525, !526, !527, !528, !529, !530, !531, !532, !533, !534, !535, !536, !537, !538, !539, !540, !541, !542, !543, !557, !561, !562, !563}
!512 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !510, file: !6, line: 373, baseType: !121, size: 320)
!513 = !DIDerivedType(tag: DW_TAG_member, name: "get_cmds", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 320)
!514 = !DIDerivedType(tag: DW_TAG_member, name: "get_misses", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 384)
!515 = !DIDerivedType(tag: DW_TAG_member, name: "get_expired", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 448)
!516 = !DIDerivedType(tag: DW_TAG_member, name: "get_flushed", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 512)
!517 = !DIDerivedType(tag: DW_TAG_member, name: "touch_cmds", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 576)
!518 = !DIDerivedType(tag: DW_TAG_member, name: "touch_misses", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 640)
!519 = !DIDerivedType(tag: DW_TAG_member, name: "delete_misses", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 704)
!520 = !DIDerivedType(tag: DW_TAG_member, name: "incr_misses", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 768)
!521 = !DIDerivedType(tag: DW_TAG_member, name: "decr_misses", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 832)
!522 = !DIDerivedType(tag: DW_TAG_member, name: "cas_misses", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 896)
!523 = !DIDerivedType(tag: DW_TAG_member, name: "meta_cmds", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 960)
!524 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_read", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 1024)
!525 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_written", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 1088)
!526 = !DIDerivedType(tag: DW_TAG_member, name: "flush_cmds", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 1152)
!527 = !DIDerivedType(tag: DW_TAG_member, name: "conn_yields", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 1216)
!528 = !DIDerivedType(tag: DW_TAG_member, name: "auth_cmds", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 1280)
!529 = !DIDerivedType(tag: DW_TAG_member, name: "auth_errors", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 1344)
!530 = !DIDerivedType(tag: DW_TAG_member, name: "idle_kicks", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 1408)
!531 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_oom", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 1472)
!532 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_count", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 1536)
!533 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_bytes", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 1600)
!534 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_oom", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 1664)
!535 = !DIDerivedType(tag: DW_TAG_member, name: "store_too_large", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 1728)
!536 = !DIDerivedType(tag: DW_TAG_member, name: "store_no_memory", scope: !510, file: !6, line: 375, baseType: !345, size: 64, offset: 1792)
!537 = !DIDerivedType(tag: DW_TAG_member, name: "get_extstore", scope: !510, file: !6, line: 377, baseType: !345, size: 64, offset: 1856)
!538 = !DIDerivedType(tag: DW_TAG_member, name: "get_aborted_extstore", scope: !510, file: !6, line: 377, baseType: !345, size: 64, offset: 1920)
!539 = !DIDerivedType(tag: DW_TAG_member, name: "get_oom_extstore", scope: !510, file: !6, line: 377, baseType: !345, size: 64, offset: 1984)
!540 = !DIDerivedType(tag: DW_TAG_member, name: "recache_from_extstore", scope: !510, file: !6, line: 377, baseType: !345, size: 64, offset: 2048)
!541 = !DIDerivedType(tag: DW_TAG_member, name: "miss_from_extstore", scope: !510, file: !6, line: 377, baseType: !345, size: 64, offset: 2112)
!542 = !DIDerivedType(tag: DW_TAG_member, name: "badcrc_from_extstore", scope: !510, file: !6, line: 377, baseType: !345, size: 64, offset: 2176)
!543 = !DIDerivedType(tag: DW_TAG_member, name: "slab_stats", scope: !510, file: !6, line: 383, baseType: !544, size: 32768, offset: 2240)
!544 = !DICompositeType(tag: DW_TAG_array_type, baseType: !545, size: 32768, elements: !555)
!545 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "slab_stats", file: !6, line: 318, size: 512, elements: !546)
!546 = !{!547, !548, !549, !550, !551, !552, !553, !554}
!547 = !DIDerivedType(tag: DW_TAG_member, name: "set_cmds", scope: !545, file: !6, line: 320, baseType: !345, size: 64)
!548 = !DIDerivedType(tag: DW_TAG_member, name: "get_hits", scope: !545, file: !6, line: 320, baseType: !345, size: 64, offset: 64)
!549 = !DIDerivedType(tag: DW_TAG_member, name: "touch_hits", scope: !545, file: !6, line: 320, baseType: !345, size: 64, offset: 128)
!550 = !DIDerivedType(tag: DW_TAG_member, name: "delete_hits", scope: !545, file: !6, line: 320, baseType: !345, size: 64, offset: 192)
!551 = !DIDerivedType(tag: DW_TAG_member, name: "cas_hits", scope: !545, file: !6, line: 320, baseType: !345, size: 64, offset: 256)
!552 = !DIDerivedType(tag: DW_TAG_member, name: "cas_badval", scope: !545, file: !6, line: 320, baseType: !345, size: 64, offset: 320)
!553 = !DIDerivedType(tag: DW_TAG_member, name: "incr_hits", scope: !545, file: !6, line: 320, baseType: !345, size: 64, offset: 384)
!554 = !DIDerivedType(tag: DW_TAG_member, name: "decr_hits", scope: !545, file: !6, line: 320, baseType: !345, size: 64, offset: 448)
!555 = !{!556}
!556 = !DISubrange(count: 64)
!557 = !DIDerivedType(tag: DW_TAG_member, name: "lru_hits", scope: !510, file: !6, line: 384, baseType: !558, size: 16384, offset: 35008)
!558 = !DICompositeType(tag: DW_TAG_array_type, baseType: !345, size: 16384, elements: !559)
!559 = !{!560}
!560 = !DISubrange(count: 256)
!561 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_count", scope: !510, file: !6, line: 385, baseType: !345, size: 64, offset: 51392)
!562 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes", scope: !510, file: !6, line: 386, baseType: !345, size: 64, offset: 51456)
!563 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes_free", scope: !510, file: !6, line: 387, baseType: !345, size: 64, offset: 51520)
!564 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !156, file: !6, line: 731, baseType: !565, size: 576, offset: 54400)
!565 = !DICompositeType(tag: DW_TAG_array_type, baseType: !566, size: 576, elements: !419)
!566 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb_t", file: !6, line: 708, baseType: !567)
!567 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_cb_s", file: !6, line: 704, size: 192, elements: !568)
!568 = !{!569, !570, !576}
!569 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !567, file: !6, line: 705, baseType: !119, size: 64)
!570 = !DIDerivedType(tag: DW_TAG_member, name: "submit_cb", scope: !567, file: !6, line: 706, baseType: !571, size: 64, offset: 64)
!571 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_stack_cb", file: !6, line: 689, baseType: !572)
!572 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !573, size: 64)
!573 = !DISubroutineType(types: !574)
!574 = !{null, !575}
!575 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !412, size: 64)
!576 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !567, file: !6, line: 707, baseType: !130, size: 32, offset: 128)
!577 = !DIDerivedType(tag: DW_TAG_member, name: "ev_queue", scope: !156, file: !6, line: 732, baseType: !578, size: 64, offset: 54976)
!578 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !579, size: 64)
!579 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "conn_queue", file: !3, line: 63, size: 512, elements: !580)
!580 = !{!581, !605, !606}
!581 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !579, file: !3, line: 64, baseType: !582, size: 128)
!582 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "conn_ev_head", file: !3, line: 64, size: 128, elements: !583)
!583 = !{!584, !603}
!584 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !582, file: !3, line: 64, baseType: !585, size: 64)
!585 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !586, size: 64)
!586 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "conn_queue_item", file: !3, line: 46, size: 576, elements: !587)
!587 = !{!588, !589, !590, !591, !592, !593, !594, !595, !596, !597, !598, !599}
!588 = !DIDerivedType(tag: DW_TAG_member, name: "sfd", scope: !586, file: !3, line: 47, baseType: !130, size: 32)
!589 = !DIDerivedType(tag: DW_TAG_member, name: "init_state", scope: !586, file: !3, line: 48, baseType: !20, size: 32, offset: 32)
!590 = !DIDerivedType(tag: DW_TAG_member, name: "event_flags", scope: !586, file: !3, line: 49, baseType: !130, size: 32, offset: 64)
!591 = !DIDerivedType(tag: DW_TAG_member, name: "read_buffer_size", scope: !586, file: !3, line: 50, baseType: !130, size: 32, offset: 96)
!592 = !DIDerivedType(tag: DW_TAG_member, name: "transport", scope: !586, file: !3, line: 51, baseType: !57, size: 32, offset: 128)
!593 = !DIDerivedType(tag: DW_TAG_member, name: "mode", scope: !586, file: !3, line: 52, baseType: !13, size: 32, offset: 160)
!594 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !586, file: !3, line: 53, baseType: !265, size: 64, offset: 192)
!595 = !DIDerivedType(tag: DW_TAG_member, name: "ssl", scope: !586, file: !3, line: 54, baseType: !119, size: 64, offset: 256)
!596 = !DIDerivedType(tag: DW_TAG_member, name: "conntag", scope: !586, file: !3, line: 55, baseType: !345, size: 64, offset: 320)
!597 = !DIDerivedType(tag: DW_TAG_member, name: "bproto", scope: !586, file: !3, line: 56, baseType: !52, size: 32, offset: 384)
!598 = !DIDerivedType(tag: DW_TAG_member, name: "io", scope: !586, file: !3, line: 57, baseType: !319, size: 64, offset: 448)
!599 = !DIDerivedType(tag: DW_TAG_member, name: "i_next", scope: !586, file: !3, line: 58, baseType: !600, size: 64, offset: 512)
!600 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !586, file: !3, line: 58, size: 64, elements: !601)
!601 = !{!602}
!602 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !600, file: !3, line: 58, baseType: !585, size: 64)
!603 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !582, file: !3, line: 64, baseType: !604, size: 64, offset: 64)
!604 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !585, size: 64)
!605 = !DIDerivedType(tag: DW_TAG_member, name: "lock", scope: !579, file: !3, line: 65, baseType: !121, size: 320, offset: 128)
!606 = !DIDerivedType(tag: DW_TAG_member, name: "cache", scope: !579, file: !3, line: 66, baseType: !607, size: 64, offset: 448)
!607 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !608, size: 64)
!608 = !DIDerivedType(tag: DW_TAG_typedef, name: "cache_t", file: !609, line: 39, baseType: !610)
!609 = !DIFile(filename: "./cache.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d97639c8540587a19d8550d7d7156448")
!610 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !609, line: 22, size: 704, elements: !611)
!611 = !{!612, !613, !614, !627, !628, !629, !630, !631}
!612 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !610, file: !609, line: 24, baseType: !121, size: 320)
!613 = !DIDerivedType(tag: DW_TAG_member, name: "name", scope: !610, file: !609, line: 26, baseType: !153, size: 64, offset: 320)
!614 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !610, file: !609, line: 28, baseType: !615, size: 128, offset: 384)
!615 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_head", file: !609, line: 28, size: 128, elements: !616)
!616 = !{!617, !625}
!617 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !615, file: !609, line: 28, baseType: !618, size: 64)
!618 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !619, size: 64)
!619 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_free_s", file: !609, line: 12, size: 64, elements: !620)
!620 = !{!621}
!621 = !DIDerivedType(tag: DW_TAG_member, name: "c_next", scope: !619, file: !609, line: 13, baseType: !622, size: 64)
!622 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !619, file: !609, line: 13, size: 64, elements: !623)
!623 = !{!624}
!624 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !622, file: !609, line: 13, baseType: !618, size: 64)
!625 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !615, file: !609, line: 28, baseType: !626, size: 64, offset: 64)
!626 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !618, size: 64)
!627 = !DIDerivedType(tag: DW_TAG_member, name: "bufsize", scope: !610, file: !609, line: 30, baseType: !355, size: 64, offset: 512)
!628 = !DIDerivedType(tag: DW_TAG_member, name: "freetotal", scope: !610, file: !609, line: 32, baseType: !130, size: 32, offset: 576)
!629 = !DIDerivedType(tag: DW_TAG_member, name: "total", scope: !610, file: !609, line: 34, baseType: !130, size: 32, offset: 608)
!630 = !DIDerivedType(tag: DW_TAG_member, name: "freecurr", scope: !610, file: !609, line: 36, baseType: !130, size: 32, offset: 640)
!631 = !DIDerivedType(tag: DW_TAG_member, name: "limit", scope: !610, file: !609, line: 38, baseType: !130, size: 32, offset: 672)
!632 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_cache", scope: !156, file: !6, line: 733, baseType: !607, size: 64, offset: 55040)
!633 = !DIDerivedType(tag: DW_TAG_member, name: "open_bundle", scope: !156, file: !6, line: 734, baseType: !299, size: 64, offset: 55104)
!634 = !DIDerivedType(tag: DW_TAG_member, name: "io_cache", scope: !156, file: !6, line: 735, baseType: !607, size: 64, offset: 55168)
!635 = !DIDerivedType(tag: DW_TAG_member, name: "storage", scope: !156, file: !6, line: 737, baseType: !119, size: 64, offset: 55232)
!636 = !DIDerivedType(tag: DW_TAG_member, name: "l", scope: !156, file: !6, line: 739, baseType: !637, size: 64, offset: 55296)
!637 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !638, size: 64)
!638 = !DIDerivedType(tag: DW_TAG_typedef, name: "logger", file: !69, line: 193, baseType: !639)
!639 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logger", file: !69, line: 181, size: 832, elements: !640)
!640 = !{!641, !643, !644, !645, !646, !647, !648, !649, !650, !651, !664}
!641 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !639, file: !69, line: 182, baseType: !642, size: 64)
!642 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !639, size: 64)
!643 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !639, file: !69, line: 183, baseType: !642, size: 64, offset: 64)
!644 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !639, file: !69, line: 184, baseType: !121, size: 320, offset: 128)
!645 = !DIDerivedType(tag: DW_TAG_member, name: "written", scope: !639, file: !69, line: 185, baseType: !345, size: 64, offset: 448)
!646 = !DIDerivedType(tag: DW_TAG_member, name: "dropped", scope: !639, file: !69, line: 186, baseType: !345, size: 64, offset: 512)
!647 = !DIDerivedType(tag: DW_TAG_member, name: "blocked", scope: !639, file: !69, line: 187, baseType: !345, size: 64, offset: 576)
!648 = !DIDerivedType(tag: DW_TAG_member, name: "fetcher_ratio", scope: !639, file: !69, line: 188, baseType: !336, size: 16, offset: 640)
!649 = !DIDerivedType(tag: DW_TAG_member, name: "mutation_ratio", scope: !639, file: !69, line: 189, baseType: !336, size: 16, offset: 656)
!650 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !639, file: !69, line: 190, baseType: !336, size: 16, offset: 672)
!651 = !DIDerivedType(tag: DW_TAG_member, name: "buf", scope: !639, file: !69, line: 191, baseType: !652, size: 64, offset: 704)
!652 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !653, size: 64)
!653 = !DIDerivedType(tag: DW_TAG_typedef, name: "bipbuf_t", file: !654, line: 18, baseType: !655)
!654 = !DIFile(filename: "./bipbuffer.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "99606bcb8393045e6bc9eef40115066f")
!655 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !654, line: 4, size: 192, elements: !656)
!656 = !{!657, !658, !659, !660, !661, !662}
!657 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !655, file: !654, line: 6, baseType: !118, size: 64)
!658 = !DIDerivedType(tag: DW_TAG_member, name: "a_start", scope: !655, file: !654, line: 9, baseType: !7, size: 32, offset: 64)
!659 = !DIDerivedType(tag: DW_TAG_member, name: "a_end", scope: !655, file: !654, line: 9, baseType: !7, size: 32, offset: 96)
!660 = !DIDerivedType(tag: DW_TAG_member, name: "b_end", scope: !655, file: !654, line: 12, baseType: !7, size: 32, offset: 128)
!661 = !DIDerivedType(tag: DW_TAG_member, name: "b_inuse", scope: !655, file: !654, line: 15, baseType: !130, size: 32, offset: 160)
!662 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !655, file: !654, line: 17, baseType: !663, offset: 192)
!663 = !DICompositeType(tag: DW_TAG_array_type, baseType: !186, elements: !311)
!664 = !DIDerivedType(tag: DW_TAG_member, name: "entry_map", scope: !639, file: !69, line: 192, baseType: !665, size: 64, offset: 768)
!665 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !666, size: 64)
!666 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !667)
!667 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_details", file: !69, line: 58, baseType: !668)
!668 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_entry_details", file: !69, line: 63, size: 256, elements: !669)
!669 = !{!670, !671, !672, !701, !706}
!670 = !DIDerivedType(tag: DW_TAG_member, name: "reqlen", scope: !668, file: !69, line: 64, baseType: !130, size: 32)
!671 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !668, file: !69, line: 65, baseType: !336, size: 16, offset: 32)
!672 = !DIDerivedType(tag: DW_TAG_member, name: "log_cb", scope: !668, file: !69, line: 66, baseType: !673, size: 64, offset: 64)
!673 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_log_cb", file: !69, line: 60, baseType: !674)
!674 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !675, size: 64)
!675 = !DISubroutineType(types: !676)
!676 = !{null, !677, !665, !692, !694}
!677 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !678, size: 64)
!678 = !DIDerivedType(tag: DW_TAG_typedef, name: "logentry", file: !69, line: 57, baseType: !679)
!679 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logentry", file: !69, line: 156, size: 320, elements: !680)
!680 = !{!681, !682, !683, !684, !685, !686, !687}
!681 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !679, file: !69, line: 157, baseType: !68, size: 32)
!682 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !679, file: !69, line: 158, baseType: !182, size: 8, offset: 32)
!683 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !679, file: !69, line: 159, baseType: !336, size: 16, offset: 48)
!684 = !DIDerivedType(tag: DW_TAG_member, name: "gid", scope: !679, file: !69, line: 160, baseType: !345, size: 64, offset: 64)
!685 = !DIDerivedType(tag: DW_TAG_member, name: "tv", scope: !679, file: !69, line: 161, baseType: !230, size: 128, offset: 128)
!686 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !679, file: !69, line: 162, baseType: !130, size: 32, offset: 256)
!687 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !679, file: !69, line: 165, baseType: !688, offset: 288)
!688 = !DICompositeType(tag: DW_TAG_array_type, baseType: !689, elements: !311)
!689 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !679, file: !69, line: 163, size: 8, elements: !690)
!690 = !{!691}
!691 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !689, file: !69, line: 164, baseType: !148, size: 8)
!692 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !693, size: 64)
!693 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!694 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !695, size: 64)
!695 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !696)
!696 = !{!697, !698, !699, !700}
!697 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !695, file: !3, line: 690, baseType: !7, size: 32)
!698 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !695, file: !3, line: 690, baseType: !7, size: 32, offset: 32)
!699 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !695, file: !3, line: 690, baseType: !119, size: 64, offset: 64)
!700 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !695, file: !3, line: 690, baseType: !119, size: 64, offset: 128)
!701 = !DIDerivedType(tag: DW_TAG_member, name: "parse_cb", scope: !668, file: !69, line: 67, baseType: !702, size: 64, offset: 128)
!702 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_parse_cb", file: !69, line: 61, baseType: !703)
!703 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !704, size: 64)
!704 = !DISubroutineType(types: !705)
!705 = !{!130, !677, !153}
!706 = !DIDerivedType(tag: DW_TAG_member, name: "format", scope: !668, file: !69, line: 68, baseType: !153, size: 64, offset: 192)
!707 = !DIDerivedType(tag: DW_TAG_member, name: "lru_bump_buf", scope: !156, file: !6, line: 740, baseType: !119, size: 64, offset: 55360)
!708 = !DIDerivedType(tag: DW_TAG_member, name: "napi_id", scope: !156, file: !6, line: 744, baseType: !130, size: 32, offset: 55424)
!709 = !{!0, !710, !715, !720, !723, !728, !733, !738, !740, !742, !747, !749, !751, !756, !761, !766, !771, !776, !781, !786, !791, !796, !799, !801, !803, !805, !807, !809, !811, !846, !848, !850, !852, !854, !856, !861, !866, !868, !873, !878, !881, !883, !885, !890, !895, !897, !899, !901, !906}
!710 = !DIGlobalVariableExpression(var: !711, expr: !DIExpression())
!711 = distinct !DIGlobalVariable(scope: null, file: !3, line: 187, type: !712, isLocal: true, isDefinition: true)
!712 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 184, elements: !713)
!713 = !{!714}
!714 = !DISubrange(count: 23)
!715 = !DIGlobalVariableExpression(var: !716, expr: !DIExpression())
!716 = distinct !DIGlobalVariable(scope: null, file: !3, line: 216, type: !717, isLocal: true, isDefinition: true)
!717 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 120, elements: !718)
!718 = !{!719}
!719 = !DISubrange(count: 15)
!720 = !DIGlobalVariableExpression(var: !721, expr: !DIExpression())
!721 = distinct !DIGlobalVariable(scope: null, file: !3, line: 219, type: !722, isLocal: true, isDefinition: true)
!722 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 192, elements: !454)
!723 = !DIGlobalVariableExpression(var: !724, expr: !DIExpression())
!724 = distinct !DIGlobalVariable(scope: null, file: !3, line: 233, type: !725, isLocal: true, isDefinition: true)
!725 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 280, elements: !726)
!726 = !{!727}
!727 = !DISubrange(count: 35)
!728 = !DIGlobalVariableExpression(var: !729, expr: !DIExpression())
!729 = distinct !DIGlobalVariable(scope: null, file: !3, line: 239, type: !730, isLocal: true, isDefinition: true)
!730 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 168, elements: !731)
!731 = !{!732}
!732 = !DISubrange(count: 21)
!733 = !DIGlobalVariableExpression(var: !734, expr: !DIExpression())
!734 = distinct !DIGlobalVariable(scope: null, file: !3, line: 243, type: !735, isLocal: true, isDefinition: true)
!735 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 160, elements: !736)
!736 = !{!737}
!737 = !DISubrange(count: 20)
!738 = !DIGlobalVariableExpression(var: !739, expr: !DIExpression())
!739 = distinct !DIGlobalVariable(scope: null, file: !3, line: 248, type: !735, isLocal: true, isDefinition: true)
!740 = !DIGlobalVariableExpression(var: !741, expr: !DIExpression())
!741 = distinct !DIGlobalVariable(scope: null, file: !3, line: 252, type: !712, isLocal: true, isDefinition: true)
!742 = !DIGlobalVariableExpression(var: !743, expr: !DIExpression())
!743 = distinct !DIGlobalVariable(scope: null, file: !3, line: 255, type: !744, isLocal: true, isDefinition: true)
!744 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 232, elements: !745)
!745 = !{!746}
!746 = !DISubrange(count: 29)
!747 = !DIGlobalVariableExpression(var: !748, expr: !DIExpression())
!748 = distinct !DIGlobalVariable(scope: null, file: !3, line: 259, type: !730, isLocal: true, isDefinition: true)
!749 = !DIGlobalVariableExpression(var: !750, expr: !DIExpression())
!750 = distinct !DIGlobalVariable(scope: null, file: !3, line: 263, type: !722, isLocal: true, isDefinition: true)
!751 = !DIGlobalVariableExpression(var: !752, expr: !DIExpression())
!752 = distinct !DIGlobalVariable(scope: null, file: !3, line: 269, type: !753, isLocal: true, isDefinition: true)
!753 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 256, elements: !754)
!754 = !{!755}
!755 = !DISubrange(count: 32)
!756 = !DIGlobalVariableExpression(var: !757, expr: !DIExpression())
!757 = distinct !DIGlobalVariable(scope: null, file: !3, line: 793, type: !758, isLocal: true, isDefinition: true)
!758 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 392, elements: !759)
!759 = !{!760}
!760 = !DISubrange(count: 49)
!761 = !DIGlobalVariableExpression(var: !762, expr: !DIExpression())
!762 = distinct !DIGlobalVariable(scope: null, file: !3, line: 844, type: !763, isLocal: true, isDefinition: true)
!763 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 264, elements: !764)
!764 = !{!765}
!765 = !DISubrange(count: 33)
!766 = !DIGlobalVariableExpression(var: !767, expr: !DIExpression())
!767 = distinct !DIGlobalVariable(scope: null, file: !3, line: 860, type: !768, isLocal: true, isDefinition: true)
!768 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 336, elements: !769)
!769 = !{!770}
!770 = !DISubrange(count: 42)
!771 = !DIGlobalVariableExpression(var: !772, expr: !DIExpression())
!772 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1117, type: !773, isLocal: true, isDefinition: true)
!773 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 648, elements: !774)
!774 = !{!775}
!775 = !DISubrange(count: 81)
!776 = !DIGlobalVariableExpression(var: !777, expr: !DIExpression())
!777 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1118, type: !778, isLocal: true, isDefinition: true)
!778 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 448, elements: !779)
!779 = !{!780}
!780 = !DISubrange(count: 56)
!781 = !DIGlobalVariableExpression(var: !782, expr: !DIExpression())
!782 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1119, type: !783, isLocal: true, isDefinition: true)
!783 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 328, elements: !784)
!784 = !{!785}
!785 = !DISubrange(count: 41)
!786 = !DIGlobalVariableExpression(var: !787, expr: !DIExpression())
!787 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1128, type: !788, isLocal: true, isDefinition: true)
!788 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 208, elements: !789)
!789 = !{!790}
!790 = !DISubrange(count: 26)
!791 = !DIGlobalVariableExpression(var: !792, expr: !DIExpression())
!792 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1137, type: !793, isLocal: true, isDefinition: true)
!793 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 272, elements: !794)
!794 = !{!795}
!795 = !DISubrange(count: 34)
!796 = !DIGlobalVariableExpression(var: !797, expr: !DIExpression())
!797 = distinct !DIGlobalVariable(name: "lru_locks", scope: !2, file: !3, line: 70, type: !798, isLocal: false, isDefinition: true)
!798 = !DICompositeType(tag: DW_TAG_array_type, baseType: !121, size: 81920, elements: !559)
!799 = !DIGlobalVariableExpression(var: !800, expr: !DIExpression())
!800 = distinct !DIGlobalVariable(name: "worker_hang_lock", scope: !2, file: !3, line: 83, type: !121, isLocal: true, isDefinition: true)
!801 = !DIGlobalVariableExpression(var: !802, expr: !DIExpression())
!802 = distinct !DIGlobalVariable(name: "item_locks", scope: !2, file: !3, line: 85, type: !120, isLocal: true, isDefinition: true)
!803 = !DIGlobalVariableExpression(var: !804, expr: !DIExpression())
!804 = distinct !DIGlobalVariable(name: "item_lock_count", scope: !2, file: !3, line: 87, type: !377, isLocal: true, isDefinition: true)
!805 = !DIGlobalVariableExpression(var: !806, expr: !DIExpression())
!806 = distinct !DIGlobalVariable(name: "item_lock_hashpower", scope: !2, file: !3, line: 88, type: !7, isLocal: true, isDefinition: true)
!807 = !DIGlobalVariableExpression(var: !808, expr: !DIExpression())
!808 = distinct !DIGlobalVariable(name: "threads", scope: !2, file: !3, line: 96, type: !154, isLocal: true, isDefinition: true)
!809 = !DIGlobalVariableExpression(var: !810, expr: !DIExpression())
!810 = distinct !DIGlobalVariable(name: "init_lock", scope: !2, file: !3, line: 102, type: !121, isLocal: true, isDefinition: true)
!811 = !DIGlobalVariableExpression(var: !812, expr: !DIExpression())
!812 = distinct !DIGlobalVariable(name: "init_cond", scope: !2, file: !3, line: 103, type: !813, isLocal: true, isDefinition: true)
!813 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_cond_t", file: !122, line: 80, baseType: !814)
!814 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !122, line: 75, size: 384, elements: !815)
!815 = !{!816, !840, !844}
!816 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !814, file: !122, line: 77, baseType: !817, size: 384)
!817 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_cond_s", file: !140, line: 94, size: 384, elements: !818)
!818 = !{!819, !831, !832, !836, !837, !838, !839}
!819 = !DIDerivedType(tag: DW_TAG_member, name: "__wseq", scope: !817, file: !140, line: 96, baseType: !820, size: 64)
!820 = !DIDerivedType(tag: DW_TAG_typedef, name: "__atomic_wide_counter", file: !821, line: 33, baseType: !822)
!821 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h", directory: "", checksumkind: CSK_MD5, checksum: "d1ec99b0f6e36c0a42ac284d459cbd38")
!822 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !821, line: 25, size: 64, elements: !823)
!823 = !{!824, !826}
!824 = !DIDerivedType(tag: DW_TAG_member, name: "__value64", scope: !822, file: !821, line: 27, baseType: !825, size: 64)
!825 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!826 = !DIDerivedType(tag: DW_TAG_member, name: "__value32", scope: !822, file: !821, line: 32, baseType: !827, size: 64)
!827 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !822, file: !821, line: 28, size: 64, elements: !828)
!828 = !{!829, !830}
!829 = !DIDerivedType(tag: DW_TAG_member, name: "__low", scope: !827, file: !821, line: 30, baseType: !7, size: 32)
!830 = !DIDerivedType(tag: DW_TAG_member, name: "__high", scope: !827, file: !821, line: 31, baseType: !7, size: 32, offset: 32)
!831 = !DIDerivedType(tag: DW_TAG_member, name: "__g1_start", scope: !817, file: !140, line: 97, baseType: !820, size: 64, offset: 64)
!832 = !DIDerivedType(tag: DW_TAG_member, name: "__g_refs", scope: !817, file: !140, line: 98, baseType: !833, size: 64, offset: 128)
!833 = !DICompositeType(tag: DW_TAG_array_type, baseType: !7, size: 64, elements: !834)
!834 = !{!835}
!835 = !DISubrange(count: 2)
!836 = !DIDerivedType(tag: DW_TAG_member, name: "__g_size", scope: !817, file: !140, line: 99, baseType: !833, size: 64, offset: 192)
!837 = !DIDerivedType(tag: DW_TAG_member, name: "__g1_orig_size", scope: !817, file: !140, line: 100, baseType: !7, size: 32, offset: 256)
!838 = !DIDerivedType(tag: DW_TAG_member, name: "__wrefs", scope: !817, file: !140, line: 101, baseType: !7, size: 32, offset: 288)
!839 = !DIDerivedType(tag: DW_TAG_member, name: "__g_signals", scope: !817, file: !140, line: 102, baseType: !833, size: 64, offset: 320)
!840 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !814, file: !122, line: 78, baseType: !841, size: 384)
!841 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 384, elements: !842)
!842 = !{!843}
!843 = !DISubrange(count: 48)
!844 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !814, file: !122, line: 79, baseType: !845, size: 64)
!845 = !DIBasicType(name: "long long", size: 64, encoding: DW_ATE_signed)
!846 = !DIGlobalVariableExpression(var: !847, expr: !DIExpression())
!847 = distinct !DIGlobalVariable(name: "init_count", scope: !2, file: !3, line: 101, type: !130, isLocal: true, isDefinition: true)
!848 = !DIGlobalVariableExpression(var: !849, expr: !DIExpression())
!849 = distinct !DIGlobalVariable(name: "last_thread", scope: !2, file: !3, line: 700, type: !130, isLocal: true, isDefinition: true)
!850 = !DIGlobalVariableExpression(var: !851, expr: !DIExpression())
!851 = distinct !DIGlobalVariable(name: "last_thread_by_napi_id", scope: !2, file: !3, line: 703, type: !130, isLocal: true, isDefinition: true)
!852 = !DIGlobalVariableExpression(var: !853, expr: !DIExpression())
!853 = distinct !DIGlobalVariable(name: "stats_lock", scope: !2, file: !3, line: 80, type: !121, isLocal: true, isDefinition: true)
!854 = !DIGlobalVariableExpression(var: !855, expr: !DIExpression())
!855 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1068, type: !768, isLocal: true, isDefinition: true)
!856 = !DIGlobalVariableExpression(var: !857, expr: !DIExpression())
!857 = distinct !DIGlobalVariable(scope: null, file: !3, line: 436, type: !858, isLocal: true, isDefinition: true)
!858 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 216, elements: !859)
!859 = !{!860}
!860 = !DISubrange(count: 27)
!861 = !DIGlobalVariableExpression(var: !862, expr: !DIExpression())
!862 = distinct !DIGlobalVariable(scope: null, file: !3, line: 448, type: !863, isLocal: true, isDefinition: true)
!863 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 376, elements: !864)
!864 = !{!865}
!865 = !DISubrange(count: 47)
!866 = !DIGlobalVariableExpression(var: !867, expr: !DIExpression())
!867 = distinct !DIGlobalVariable(scope: null, file: !3, line: 454, type: !858, isLocal: true, isDefinition: true)
!868 = !DIGlobalVariableExpression(var: !869, expr: !DIExpression())
!869 = distinct !DIGlobalVariable(scope: null, file: !3, line: 458, type: !870, isLocal: true, isDefinition: true)
!870 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 40, elements: !871)
!871 = !{!872}
!872 = !DISubrange(count: 5)
!873 = !DIGlobalVariableExpression(var: !874, expr: !DIExpression())
!874 = distinct !DIGlobalVariable(scope: null, file: !3, line: 460, type: !875, isLocal: true, isDefinition: true)
!875 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 288, elements: !876)
!876 = !{!877}
!877 = !DISubrange(count: 36)
!878 = !DIGlobalVariableExpression(var: !879, expr: !DIExpression())
!879 = distinct !DIGlobalVariable(scope: null, file: !3, line: 475, type: !880, isLocal: true, isDefinition: true)
!880 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 24, elements: !419)
!881 = !DIGlobalVariableExpression(var: !882, expr: !DIExpression())
!882 = distinct !DIGlobalVariable(scope: null, file: !3, line: 477, type: !793, isLocal: true, isDefinition: true)
!883 = !DIGlobalVariableExpression(var: !884, expr: !DIExpression())
!884 = distinct !DIGlobalVariable(scope: null, file: !3, line: 416, type: !875, isLocal: true, isDefinition: true)
!885 = !DIGlobalVariableExpression(var: !886, expr: !DIExpression())
!886 = distinct !DIGlobalVariable(scope: null, file: !3, line: 602, type: !887, isLocal: true, isDefinition: true)
!887 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 248, elements: !888)
!888 = !{!889}
!889 = !DISubrange(count: 31)
!890 = !DIGlobalVariableExpression(var: !891, expr: !DIExpression())
!891 = distinct !DIGlobalVariable(scope: null, file: !3, line: 629, type: !892, isLocal: true, isDefinition: true)
!892 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 312, elements: !893)
!893 = !{!894}
!894 = !DISubrange(count: 39)
!895 = !DIGlobalVariableExpression(var: !896, expr: !DIExpression())
!896 = distinct !DIGlobalVariable(scope: null, file: !3, line: 633, type: !793, isLocal: true, isDefinition: true)
!897 = !DIGlobalVariableExpression(var: !898, expr: !DIExpression())
!898 = distinct !DIGlobalVariable(scope: null, file: !3, line: 280, type: !880, isLocal: true, isDefinition: true)
!899 = !DIGlobalVariableExpression(var: !900, expr: !DIExpression())
!900 = distinct !DIGlobalVariable(scope: null, file: !3, line: 282, type: !783, isLocal: true, isDefinition: true)
!901 = !DIGlobalVariableExpression(var: !902, expr: !DIExpression())
!902 = distinct !DIGlobalVariable(scope: null, file: !3, line: 386, type: !903, isLocal: true, isDefinition: true)
!903 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 200, elements: !904)
!904 = !{!905}
!905 = !DISubrange(count: 25)
!906 = !DIGlobalVariableExpression(var: !907, expr: !DIExpression())
!907 = distinct !DIGlobalVariable(scope: null, file: !3, line: 391, type: !908, isLocal: true, isDefinition: true)
!908 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 80, elements: !909)
!909 = !{!910}
!910 = !DISubrange(count: 10)
!911 = !{i32 7, !"Dwarf Version", i32 5}
!912 = !{i32 2, !"Debug Info Version", i32 3}
!913 = !{i32 1, !"wchar_size", i32 4}
!914 = !{i32 8, !"PIC Level", i32 2}
!915 = !{i32 7, !"PIE Level", i32 2}
!916 = !{i32 7, !"uwtable", i32 2}
!917 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!918 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!919 = distinct !DISubprogram(name: "item_lock", scope: !3, file: !3, line: 121, type: !920, scopeLine: 121, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !922)
!920 = !DISubroutineType(types: !921)
!921 = !{null, !377}
!922 = !{!923}
!923 = !DILocalVariable(name: "hv", arg: 1, scope: !919, file: !3, line: 121, type: !377)
!924 = !DILocation(line: 0, scope: !919)
!925 = !DILocation(line: 122, column: 5, scope: !919)
!926 = !{!927, !927, i64 0}
!927 = !{!"any pointer", !928, i64 0}
!928 = !{!"omnipotent char", !929, i64 0}
!929 = !{!"Simple C/C++ TBAA"}
!930 = !{!931, !931, i64 0}
!931 = !{!"int", !928, i64 0}
!932 = !DILocation(line: 123, column: 1, scope: !919)
!933 = !DISubprogram(name: "pthread_mutex_lock", scope: !934, file: !934, line: 794, type: !935, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!934 = !DIFile(filename: "/usr/include/pthread.h", directory: "", checksumkind: CSK_MD5, checksum: "cbcd748b3d3ecaa7356dc2925b45d819")
!935 = !DISubroutineType(types: !936)
!936 = !{!130, !120}
!937 = distinct !DISubprogram(name: "item_trylock", scope: !3, file: !3, line: 125, type: !938, scopeLine: 125, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !940)
!938 = !DISubroutineType(types: !939)
!939 = !{!119, !377}
!940 = !{!941, !942}
!941 = !DILocalVariable(name: "hv", arg: 1, scope: !937, file: !3, line: 125, type: !377)
!942 = !DILocalVariable(name: "lock", scope: !937, file: !3, line: 126, type: !120)
!943 = !DILocation(line: 0, scope: !937)
!944 = !DILocation(line: 126, column: 30, scope: !937)
!945 = !DILocation(line: 126, column: 41, scope: !937)
!946 = !DILocation(line: 126, column: 46, scope: !937)
!947 = !DILocation(line: 126, column: 44, scope: !937)
!948 = !DILocation(line: 127, column: 9, scope: !949)
!949 = distinct !DILexicalBlock(scope: !937, file: !3, line: 127, column: 9)
!950 = !DILocation(line: 127, column: 37, scope: !949)
!951 = !DILocation(line: 131, column: 1, scope: !937)
!952 = !DISubprogram(name: "pthread_mutex_trylock", scope: !934, file: !934, line: 790, type: !935, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!953 = distinct !DISubprogram(name: "item_trylock_unlock", scope: !3, file: !3, line: 133, type: !954, scopeLine: 133, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !956)
!954 = !DISubroutineType(types: !955)
!955 = !{null, !119}
!956 = !{!957}
!957 = !DILocalVariable(name: "lock", arg: 1, scope: !953, file: !3, line: 133, type: !119)
!958 = !DILocation(line: 0, scope: !953)
!959 = !DILocation(line: 134, column: 5, scope: !953)
!960 = !DILocation(line: 135, column: 1, scope: !953)
!961 = !DISubprogram(name: "pthread_mutex_unlock", scope: !934, file: !934, line: 835, type: !935, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!962 = distinct !DISubprogram(name: "item_unlock", scope: !3, file: !3, line: 137, type: !920, scopeLine: 137, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !963)
!963 = !{!964}
!964 = !DILocalVariable(name: "hv", arg: 1, scope: !962, file: !3, line: 137, type: !377)
!965 = !DILocation(line: 0, scope: !962)
!966 = !DILocation(line: 138, column: 5, scope: !962)
!967 = !DILocation(line: 139, column: 1, scope: !962)
!968 = distinct !DISubprogram(name: "pause_threads", scope: !3, file: !3, line: 158, type: !969, scopeLine: 158, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !971)
!969 = !DISubroutineType(types: !970)
!970 = !{null, !5}
!971 = !{!972, !973, !974}
!972 = !DILocalVariable(name: "type", arg: 1, scope: !968, file: !3, line: 158, type: !5)
!973 = !DILocalVariable(name: "i", scope: !968, file: !3, line: 159, type: !130)
!974 = !DILocalVariable(name: "pause_workers", scope: !968, file: !3, line: 160, type: !275)
!975 = !DILocation(line: 0, scope: !968)
!976 = !DILocation(line: 162, column: 5, scope: !968)
!977 = !DILocation(line: 164, column: 13, scope: !978)
!978 = distinct !DILexicalBlock(scope: !968, file: !3, line: 162, column: 19)
!979 = !DILocation(line: 165, column: 13, scope: !978)
!980 = !DILocation(line: 166, column: 13, scope: !978)
!981 = !DILocation(line: 168, column: 13, scope: !978)
!982 = !DILocation(line: 169, column: 13, scope: !978)
!983 = !DILocation(line: 173, column: 13, scope: !978)
!984 = !DILocation(line: 197, column: 5, scope: !968)
!985 = !DILocation(line: 198, column: 16, scope: !968)
!986 = !DILocation(line: 199, column: 30, scope: !987)
!987 = distinct !DILexicalBlock(scope: !988, file: !3, line: 199, column: 5)
!988 = distinct !DILexicalBlock(scope: !968, file: !3, line: 199, column: 5)
!989 = !{!990, !931, i64 84}
!990 = !{!"settings", !991, i64 0, !931, i64 8, !931, i64 12, !931, i64 16, !927, i64 24, !931, i64 32, !931, i64 36, !931, i64 40, !927, i64 48, !927, i64 56, !931, i64 64, !992, i64 72, !931, i64 80, !931, i64 84, !931, i64 88, !928, i64 92, !931, i64 96, !931, i64 100, !993, i64 104, !931, i64 108, !931, i64 112, !931, i64 116, !931, i64 120, !931, i64 124, !931, i64 128, !993, i64 132, !993, i64 133, !993, i64 134, !993, i64 135, !993, i64 136, !993, i64 137, !931, i64 140, !992, i64 144, !931, i64 152, !931, i64 156, !993, i64 160, !931, i64 164, !993, i64 168, !993, i64 169, !927, i64 176, !931, i64 184, !931, i64 188, !931, i64 192, !931, i64 196, !992, i64 200, !992, i64 208, !931, i64 216, !993, i64 220, !931, i64 224, !931, i64 228, !931, i64 232, !931, i64 236, !931, i64 240, !993, i64 244, !993, i64 245, !993, i64 246, !931, i64 248, !931, i64 252, !931, i64 256, !931, i64 260, !931, i64 264, !931, i64 268, !931, i64 272, !931, i64 276, !931, i64 280, !931, i64 284, !992, i64 288, !992, i64 296, !993, i64 304, !931, i64 308, !931, i64 312, !927, i64 320, !931, i64 328}
!991 = !{!"long", !928, i64 0}
!992 = !{!"double", !928, i64 0}
!993 = !{!"_Bool", !928, i64 0}
!994 = !DILocation(line: 199, column: 19, scope: !987)
!995 = !DILocation(line: 199, column: 5, scope: !988)
!996 = !DILocation(line: 176, column: 13, scope: !978)
!997 = !DILocation(line: 177, column: 13, scope: !978)
!998 = !DILocation(line: 178, column: 13, scope: !978)
!999 = !DILocation(line: 180, column: 13, scope: !978)
!1000 = !DILocation(line: 181, column: 13, scope: !978)
!1001 = !DILocation(line: 184, column: 13, scope: !978)
!1002 = !DILocation(line: 185, column: 13, scope: !978)
!1003 = !DILocation(line: 187, column: 21, scope: !978)
!1004 = !DILocation(line: 187, column: 13, scope: !978)
!1005 = !DILocation(line: 189, column: 13, scope: !978)
!1006 = !DILocation(line: 200, column: 27, scope: !1007)
!1007 = distinct !DILexicalBlock(scope: !987, file: !3, line: 199, column: 48)
!1008 = !DILocation(line: 200, column: 9, scope: !1007)
!1009 = !DILocation(line: 199, column: 44, scope: !987)
!1010 = distinct !{!1010, !995, !1011, !1012}
!1011 = !DILocation(line: 201, column: 5, scope: !988)
!1012 = !{!"llvm.loop.mustprogress"}
!1013 = !DILocation(line: 142, column: 12, scope: !1014, inlinedAt: !1019)
!1014 = distinct !DISubprogram(name: "wait_for_thread_registration", scope: !3, file: !3, line: 141, type: !1015, scopeLine: 141, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1017)
!1015 = !DISubroutineType(types: !1016)
!1016 = !{null, !130}
!1017 = !{!1018}
!1018 = !DILocalVariable(name: "nthreads", arg: 1, scope: !1014, file: !3, line: 141, type: !130)
!1019 = distinct !DILocation(line: 202, column: 5, scope: !968)
!1020 = !DILocation(line: 0, scope: !1014, inlinedAt: !1019)
!1021 = !DILocation(line: 142, column: 23, scope: !1014, inlinedAt: !1019)
!1022 = !DILocation(line: 142, column: 5, scope: !1014, inlinedAt: !1019)
!1023 = !DILocation(line: 143, column: 9, scope: !1024, inlinedAt: !1019)
!1024 = distinct !DILexicalBlock(scope: !1014, file: !3, line: 142, column: 35)
!1025 = distinct !{!1025, !1022, !1026, !1012}
!1026 = !DILocation(line: 144, column: 5, scope: !1014, inlinedAt: !1019)
!1027 = !DILocation(line: 203, column: 5, scope: !968)
!1028 = !DILocation(line: 204, column: 1, scope: !968)
!1029 = !DISubprogram(name: "slabs_rebalancer_pause", scope: !1030, file: !1030, line: 62, type: !1031, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1030 = !DIFile(filename: "./slabs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "28867aba1f41c79140864d76faedcb32")
!1031 = !DISubroutineType(types: !1032)
!1032 = !{null}
!1033 = !DISubprogram(name: "lru_maintainer_pause", scope: !1034, file: !1034, line: 81, type: !1031, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1034 = !DIFile(filename: "./items.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "5548db7354621bc680fd5812e10230ba")
!1035 = !DISubprogram(name: "lru_crawler_pause", scope: !1036, file: !1036, line: 40, type: !1031, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1036 = !DIFile(filename: "./crawler.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "4dc9e6e54966538ea20b64490631aef9")
!1037 = !DISubprogram(name: "storage_compact_pause", scope: !1038, file: !1038, line: 28, type: !1031, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1038 = !DIFile(filename: "./storage.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d18dbd8a1337d7561522237d8930ae7f")
!1039 = !DISubprogram(name: "storage_write_pause", scope: !1038, file: !1038, line: 25, type: !1031, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1040 = !DISubprogram(name: "slabs_rebalancer_resume", scope: !1030, file: !1030, line: 63, type: !1031, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1041 = !DISubprogram(name: "lru_maintainer_resume", scope: !1034, file: !1034, line: 82, type: !1031, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1042 = !DISubprogram(name: "lru_crawler_resume", scope: !1036, file: !1036, line: 41, type: !1031, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1043 = !DISubprogram(name: "storage_compact_resume", scope: !1038, file: !1038, line: 29, type: !1031, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1044 = !DISubprogram(name: "storage_write_resume", scope: !1038, file: !1038, line: 26, type: !1031, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1045 = !DISubprogram(name: "fprintf", scope: !1046, file: !1046, line: 357, type: !1047, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1046 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "1e435c46987a169d9f9186f63a512303")
!1047 = !DISubroutineType(types: !1048)
!1048 = !{!130, !1049, !1100, null}
!1049 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1050)
!1050 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1051, size: 64)
!1051 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !1052, line: 7, baseType: !1053)
!1052 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!1053 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !1054, line: 49, size: 1728, elements: !1055)
!1054 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "7a6d4a00a37ee6b9a40cd04bd01f5d00")
!1055 = !{!1056, !1057, !1058, !1059, !1060, !1061, !1062, !1063, !1064, !1065, !1066, !1067, !1068, !1071, !1073, !1074, !1075, !1077, !1078, !1080, !1084, !1087, !1089, !1092, !1095, !1096, !1097, !1098, !1099}
!1056 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !1053, file: !1054, line: 51, baseType: !130, size: 32)
!1057 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !1053, file: !1054, line: 54, baseType: !153, size: 64, offset: 64)
!1058 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !1053, file: !1054, line: 55, baseType: !153, size: 64, offset: 128)
!1059 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !1053, file: !1054, line: 56, baseType: !153, size: 64, offset: 192)
!1060 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !1053, file: !1054, line: 57, baseType: !153, size: 64, offset: 256)
!1061 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !1053, file: !1054, line: 58, baseType: !153, size: 64, offset: 320)
!1062 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !1053, file: !1054, line: 59, baseType: !153, size: 64, offset: 384)
!1063 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !1053, file: !1054, line: 60, baseType: !153, size: 64, offset: 448)
!1064 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !1053, file: !1054, line: 61, baseType: !153, size: 64, offset: 512)
!1065 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !1053, file: !1054, line: 64, baseType: !153, size: 64, offset: 576)
!1066 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !1053, file: !1054, line: 65, baseType: !153, size: 64, offset: 640)
!1067 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !1053, file: !1054, line: 66, baseType: !153, size: 64, offset: 704)
!1068 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !1053, file: !1054, line: 68, baseType: !1069, size: 64, offset: 768)
!1069 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1070, size: 64)
!1070 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !1054, line: 36, flags: DIFlagFwdDecl)
!1071 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !1053, file: !1054, line: 70, baseType: !1072, size: 64, offset: 832)
!1072 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1053, size: 64)
!1073 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !1053, file: !1054, line: 72, baseType: !130, size: 32, offset: 896)
!1074 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !1053, file: !1054, line: 73, baseType: !130, size: 32, offset: 928)
!1075 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !1053, file: !1054, line: 74, baseType: !1076, size: 64, offset: 960)
!1076 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !185, line: 152, baseType: !152)
!1077 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !1053, file: !1054, line: 77, baseType: !334, size: 16, offset: 1024)
!1078 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !1053, file: !1054, line: 78, baseType: !1079, size: 8, offset: 1040)
!1079 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!1080 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !1053, file: !1054, line: 79, baseType: !1081, size: 8, offset: 1048)
!1081 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 8, elements: !1082)
!1082 = !{!1083}
!1083 = !DISubrange(count: 1)
!1084 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !1053, file: !1054, line: 81, baseType: !1085, size: 64, offset: 1088)
!1085 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1086, size: 64)
!1086 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !1054, line: 43, baseType: null)
!1087 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !1053, file: !1054, line: 89, baseType: !1088, size: 64, offset: 1152)
!1088 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !185, line: 153, baseType: !152)
!1089 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !1053, file: !1054, line: 91, baseType: !1090, size: 64, offset: 1216)
!1090 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1091, size: 64)
!1091 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !1054, line: 37, flags: DIFlagFwdDecl)
!1092 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !1053, file: !1054, line: 92, baseType: !1093, size: 64, offset: 1280)
!1093 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1094, size: 64)
!1094 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !1054, line: 38, flags: DIFlagFwdDecl)
!1095 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !1053, file: !1054, line: 93, baseType: !1072, size: 64, offset: 1344)
!1096 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !1053, file: !1054, line: 94, baseType: !119, size: 64, offset: 1408)
!1097 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !1053, file: !1054, line: 95, baseType: !355, size: 64, offset: 1472)
!1098 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !1053, file: !1054, line: 96, baseType: !130, size: 32, offset: 1536)
!1099 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !1053, file: !1054, line: 98, baseType: !735, size: 160, offset: 1568)
!1100 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1101)
!1101 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1102, size: 64)
!1102 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !148)
!1103 = distinct !DISubprogram(name: "notify_worker_fd", scope: !3, file: !3, line: 358, type: !1104, scopeLine: 358, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1106)
!1104 = !DISubroutineType(types: !1105)
!1105 = !{null, !154, !130, !13}
!1106 = !{!1107, !1108, !1109, !1110}
!1107 = !DILocalVariable(name: "t", arg: 1, scope: !1103, file: !3, line: 358, type: !154)
!1108 = !DILocalVariable(name: "sfd", arg: 2, scope: !1103, file: !3, line: 358, type: !130)
!1109 = !DILocalVariable(name: "mode", arg: 3, scope: !1103, file: !3, line: 358, type: !13)
!1110 = !DILocalVariable(name: "item", scope: !1103, file: !3, line: 359, type: !1111)
!1111 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1112, size: 64)
!1112 = !DIDerivedType(tag: DW_TAG_typedef, name: "CQ_ITEM", file: !3, line: 45, baseType: !586)
!1113 = distinct !DIAssignID()
!1114 = !DILocation(line: 0, scope: !1103)
!1115 = !DILocation(line: 360, column: 32, scope: !1103)
!1116 = !{!1117, !927, i64 6872}
!1117 = !{!"", !991, i64 0, !927, i64 8, !1118, i64 16, !1118, i64 152, !928, i64 288, !1124, i64 328, !931, i64 344, !931, i64 348, !1125, i64 352, !928, i64 6800, !927, i64 6872, !927, i64 6880, !927, i64 6888, !927, i64 6896, !927, i64 6904, !927, i64 6912, !927, i64 6920, !931, i64 6928}
!1118 = !{!"thread_notify", !1119, i64 0, !931, i64 128}
!1119 = !{!"event", !1120, i64 0, !928, i64 40, !931, i64 56, !927, i64 64, !928, i64 72, !1122, i64 104, !1122, i64 106, !1123, i64 112}
!1120 = !{!"event_callback", !1121, i64 0, !1122, i64 16, !928, i64 18, !928, i64 19, !928, i64 24, !927, i64 32}
!1121 = !{!"", !927, i64 0, !927, i64 8}
!1122 = !{!"short", !928, i64 0}
!1123 = !{!"timeval", !991, i64 0, !991, i64 8}
!1124 = !{!"iop_head_s", !927, i64 0, !927, i64 8}
!1125 = !{!"thread_stats", !928, i64 0, !991, i64 40, !991, i64 48, !991, i64 56, !991, i64 64, !991, i64 72, !991, i64 80, !991, i64 88, !991, i64 96, !991, i64 104, !991, i64 112, !991, i64 120, !991, i64 128, !991, i64 136, !991, i64 144, !991, i64 152, !991, i64 160, !991, i64 168, !991, i64 176, !991, i64 184, !991, i64 192, !991, i64 200, !991, i64 208, !991, i64 216, !991, i64 224, !991, i64 232, !991, i64 240, !991, i64 248, !991, i64 256, !991, i64 264, !991, i64 272, !928, i64 280, !928, i64 4376, !991, i64 6424, !991, i64 6432, !991, i64 6440}
!1126 = !DILocation(line: 318, column: 37, scope: !1127, inlinedAt: !1135)
!1127 = distinct !DISubprogram(name: "cqi_new", scope: !3, file: !3, line: 317, type: !1128, scopeLine: 317, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1132)
!1128 = !DISubroutineType(types: !1129)
!1129 = !{!1111, !1130}
!1130 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1131, size: 64)
!1131 = !DIDerivedType(tag: DW_TAG_typedef, name: "CQ", file: !3, line: 62, baseType: !579)
!1132 = !{!1133, !1134}
!1133 = !DILocalVariable(name: "cq", arg: 1, scope: !1127, file: !3, line: 317, type: !1130)
!1134 = !DILocalVariable(name: "item", scope: !1127, file: !3, line: 318, type: !1111)
!1135 = distinct !DILocation(line: 360, column: 21, scope: !1103)
!1136 = !{!1137, !927, i64 56}
!1137 = !{!"conn_queue", !1138, i64 0, !928, i64 16, !927, i64 56}
!1138 = !{!"conn_ev_head", !927, i64 0, !927, i64 8}
!1139 = !DILocation(line: 318, column: 21, scope: !1127, inlinedAt: !1135)
!1140 = !DILocation(line: 319, column: 14, scope: !1141, inlinedAt: !1135)
!1141 = distinct !DILexicalBlock(scope: !1127, file: !3, line: 319, column: 9)
!1142 = !DILocation(line: 319, column: 9, scope: !1127, inlinedAt: !1135)
!1143 = !DILocation(line: 982, column: 5, scope: !1144, inlinedAt: !1145)
!1144 = distinct !DISubprogram(name: "STATS_LOCK", scope: !3, file: !3, line: 981, type: !1031, scopeLine: 981, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1145 = distinct !DILocation(line: 320, column: 9, scope: !1146, inlinedAt: !1135)
!1146 = distinct !DILexicalBlock(scope: !1141, file: !3, line: 319, column: 23)
!1147 = !DILocation(line: 321, column: 27, scope: !1146, inlinedAt: !1135)
!1148 = !{!1149, !991, i64 24}
!1149 = !{!"stats", !991, i64 0, !991, i64 8, !991, i64 16, !991, i64 24, !991, i64 32, !991, i64 40, !991, i64 48, !991, i64 56, !991, i64 64, !991, i64 72, !991, i64 80, !991, i64 88, !991, i64 96, !991, i64 104, !991, i64 112, !991, i64 120, !991, i64 128, !991, i64 136, !991, i64 144, !991, i64 152, !991, i64 160, !991, i64 168, !991, i64 176, !991, i64 184, !1123, i64 192, !991, i64 208, !991, i64 216}
!1150 = !DILocation(line: 986, column: 5, scope: !1151, inlinedAt: !1152)
!1151 = distinct !DISubprogram(name: "STATS_UNLOCK", scope: !3, file: !3, line: 985, type: !1031, scopeLine: 985, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1152 = distinct !DILocation(line: 322, column: 9, scope: !1146, inlinedAt: !1135)
!1153 = !DILocation(line: 0, scope: !1127, inlinedAt: !1135)
!1154 = distinct !{!1154, !1155, !1156, !1012}
!1155 = !DILocation(line: 360, column: 5, scope: !1103)
!1156 = !DILocation(line: 369, column: 5, scope: !1103)
!1157 = !DILocation(line: 371, column: 11, scope: !1103)
!1158 = !DILocation(line: 371, column: 16, scope: !1103)
!1159 = !{!1160, !931, i64 20}
!1160 = !{!"conn_queue_item", !931, i64 0, !931, i64 4, !931, i64 8, !931, i64 12, !931, i64 16, !931, i64 20, !927, i64 24, !927, i64 32, !991, i64 40, !931, i64 48, !927, i64 56, !1161, i64 64}
!1161 = !{!"", !927, i64 0}
!1162 = !DILocation(line: 372, column: 15, scope: !1103)
!1163 = !{!1160, !931, i64 0}
!1164 = !DILocalVariable(name: "u", scope: !1165, file: !3, line: 343, type: !345)
!1165 = distinct !DISubprogram(name: "notify_worker", scope: !3, file: !3, line: 340, type: !1166, scopeLine: 340, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1168)
!1166 = !DISubroutineType(types: !1167)
!1167 = !{null, !154, !1111}
!1168 = !{!1169, !1170, !1164}
!1169 = !DILocalVariable(name: "t", arg: 1, scope: !1165, file: !3, line: 340, type: !154)
!1170 = !DILocalVariable(name: "item", arg: 2, scope: !1165, file: !3, line: 340, type: !1111)
!1171 = !DILocation(line: 0, scope: !1165, inlinedAt: !1172)
!1172 = distinct !DILocation(line: 373, column: 5, scope: !1103)
!1173 = !DILocation(line: 341, column: 16, scope: !1165, inlinedAt: !1172)
!1174 = !DILocalVariable(name: "cq", arg: 1, scope: !1175, file: !3, line: 308, type: !1130)
!1175 = distinct !DISubprogram(name: "cq_push", scope: !3, file: !3, line: 308, type: !1176, scopeLine: 308, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1178)
!1176 = !DISubroutineType(types: !1177)
!1177 = !{null, !1130, !1111}
!1178 = !{!1174, !1179}
!1179 = !DILocalVariable(name: "item", arg: 2, scope: !1175, file: !3, line: 308, type: !1111)
!1180 = !DILocation(line: 0, scope: !1175, inlinedAt: !1181)
!1181 = distinct !DILocation(line: 341, column: 5, scope: !1165, inlinedAt: !1172)
!1182 = !DILocation(line: 309, column: 29, scope: !1175, inlinedAt: !1181)
!1183 = !DILocation(line: 309, column: 5, scope: !1175, inlinedAt: !1181)
!1184 = !DILocation(line: 310, column: 5, scope: !1185, inlinedAt: !1181)
!1185 = distinct !DILexicalBlock(scope: !1175, file: !3, line: 310, column: 5)
!1186 = !{!1160, !927, i64 64}
!1187 = !{!1137, !927, i64 8}
!1188 = !DILocation(line: 311, column: 5, scope: !1175, inlinedAt: !1181)
!1189 = !DILocation(line: 343, column: 5, scope: !1165, inlinedAt: !1172)
!1190 = !DILocation(line: 343, column: 14, scope: !1165, inlinedAt: !1172)
!1191 = !{!991, !991, i64 0}
!1192 = distinct !DIAssignID()
!1193 = !DILocation(line: 344, column: 20, scope: !1194, inlinedAt: !1172)
!1194 = distinct !DILexicalBlock(scope: !1165, file: !3, line: 344, column: 9)
!1195 = !{!1117, !931, i64 144}
!1196 = !DILocation(line: 344, column: 9, scope: !1194, inlinedAt: !1172)
!1197 = !DILocation(line: 344, column: 59, scope: !1194, inlinedAt: !1172)
!1198 = !DILocation(line: 344, column: 9, scope: !1165, inlinedAt: !1172)
!1199 = !DILocation(line: 345, column: 9, scope: !1200, inlinedAt: !1172)
!1200 = distinct !DILexicalBlock(scope: !1194, file: !3, line: 344, column: 80)
!1201 = !DILocation(line: 347, column: 5, scope: !1200, inlinedAt: !1172)
!1202 = !DILocation(line: 355, column: 1, scope: !1165, inlinedAt: !1172)
!1203 = !DILocation(line: 374, column: 1, scope: !1103)
!1204 = distinct !DISubprogram(name: "stop_threads", scope: !3, file: !3, line: 210, type: !1031, scopeLine: 210, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1205)
!1205 = !{!1206}
!1206 = !DILocalVariable(name: "i", scope: !1204, file: !3, line: 211, type: !130)
!1207 = !DILocation(line: 214, column: 5, scope: !1204)
!1208 = !DILocation(line: 215, column: 18, scope: !1209)
!1209 = distinct !DILexicalBlock(scope: !1204, file: !3, line: 215, column: 9)
!1210 = !{!990, !931, i64 32}
!1211 = !DILocation(line: 215, column: 26, scope: !1209)
!1212 = !DILocation(line: 215, column: 9, scope: !1204)
!1213 = !DILocation(line: 216, column: 17, scope: !1209)
!1214 = !DILocation(line: 216, column: 9, scope: !1209)
!1215 = !DILocation(line: 218, column: 18, scope: !1216)
!1216 = distinct !DILexicalBlock(scope: !1204, file: !3, line: 218, column: 9)
!1217 = !DILocation(line: 218, column: 26, scope: !1216)
!1218 = !DILocation(line: 218, column: 9, scope: !1204)
!1219 = !DILocation(line: 219, column: 17, scope: !1216)
!1220 = !DILocation(line: 219, column: 9, scope: !1216)
!1221 = !DILocation(line: 221, column: 5, scope: !1204)
!1222 = !DILocation(line: 222, column: 5, scope: !1204)
!1223 = !DILocation(line: 223, column: 16, scope: !1204)
!1224 = !DILocation(line: 0, scope: !1204)
!1225 = !DILocation(line: 224, column: 30, scope: !1226)
!1226 = distinct !DILexicalBlock(scope: !1227, file: !3, line: 224, column: 5)
!1227 = distinct !DILexicalBlock(scope: !1204, file: !3, line: 224, column: 5)
!1228 = !DILocation(line: 224, column: 19, scope: !1226)
!1229 = !DILocation(line: 224, column: 5, scope: !1227)
!1230 = !DILocation(line: 225, column: 27, scope: !1231)
!1231 = distinct !DILexicalBlock(scope: !1226, file: !3, line: 224, column: 48)
!1232 = !DILocation(line: 225, column: 9, scope: !1231)
!1233 = !DILocation(line: 224, column: 44, scope: !1226)
!1234 = distinct !{!1234, !1229, !1235, !1012}
!1235 = !DILocation(line: 226, column: 5, scope: !1227)
!1236 = !DILocation(line: 142, column: 12, scope: !1014, inlinedAt: !1237)
!1237 = distinct !DILocation(line: 227, column: 5, scope: !1204)
!1238 = !DILocation(line: 0, scope: !1014, inlinedAt: !1237)
!1239 = !DILocation(line: 142, column: 23, scope: !1014, inlinedAt: !1237)
!1240 = !DILocation(line: 142, column: 5, scope: !1014, inlinedAt: !1237)
!1241 = !DILocation(line: 143, column: 9, scope: !1024, inlinedAt: !1237)
!1242 = distinct !{!1242, !1240, !1243, !1012}
!1243 = !DILocation(line: 144, column: 5, scope: !1014, inlinedAt: !1237)
!1244 = !DILocation(line: 228, column: 5, scope: !1204)
!1245 = !DILocation(line: 232, column: 18, scope: !1246)
!1246 = distinct !DILexicalBlock(scope: !1204, file: !3, line: 232, column: 9)
!1247 = !DILocation(line: 232, column: 26, scope: !1246)
!1248 = !DILocation(line: 232, column: 9, scope: !1204)
!1249 = !DILocation(line: 233, column: 17, scope: !1246)
!1250 = !DILocation(line: 233, column: 9, scope: !1246)
!1251 = !DILocation(line: 237, column: 5, scope: !1204)
!1252 = !DILocation(line: 238, column: 18, scope: !1253)
!1253 = distinct !DILexicalBlock(scope: !1204, file: !3, line: 238, column: 9)
!1254 = !DILocation(line: 238, column: 26, scope: !1253)
!1255 = !DILocation(line: 238, column: 9, scope: !1204)
!1256 = !DILocation(line: 239, column: 17, scope: !1253)
!1257 = !DILocation(line: 239, column: 9, scope: !1253)
!1258 = !DILocation(line: 240, column: 18, scope: !1259)
!1259 = distinct !DILexicalBlock(scope: !1204, file: !3, line: 240, column: 9)
!1260 = !{!990, !993, i64 135}
!1261 = !{i8 0, i8 2}
!1262 = !{}
!1263 = !DILocation(line: 240, column: 9, scope: !1204)
!1264 = !DILocation(line: 241, column: 9, scope: !1265)
!1265 = distinct !DILexicalBlock(scope: !1259, file: !3, line: 240, column: 41)
!1266 = !DILocation(line: 242, column: 22, scope: !1267)
!1267 = distinct !DILexicalBlock(scope: !1265, file: !3, line: 242, column: 13)
!1268 = !DILocation(line: 242, column: 30, scope: !1267)
!1269 = !DILocation(line: 242, column: 13, scope: !1265)
!1270 = !DILocation(line: 243, column: 21, scope: !1267)
!1271 = !DILocation(line: 243, column: 13, scope: !1267)
!1272 = !DILocation(line: 245, column: 18, scope: !1273)
!1273 = distinct !DILexicalBlock(scope: !1204, file: !3, line: 245, column: 9)
!1274 = !{!990, !993, i64 137}
!1275 = !DILocation(line: 245, column: 9, scope: !1204)
!1276 = !DILocation(line: 246, column: 9, scope: !1277)
!1277 = distinct !DILexicalBlock(scope: !1273, file: !3, line: 245, column: 33)
!1278 = !DILocation(line: 247, column: 22, scope: !1279)
!1279 = distinct !DILexicalBlock(scope: !1277, file: !3, line: 247, column: 13)
!1280 = !DILocation(line: 247, column: 30, scope: !1279)
!1281 = !DILocation(line: 247, column: 13, scope: !1277)
!1282 = !DILocation(line: 248, column: 21, scope: !1279)
!1283 = !DILocation(line: 248, column: 13, scope: !1279)
!1284 = !DILocation(line: 250, column: 5, scope: !1204)
!1285 = !DILocation(line: 251, column: 18, scope: !1286)
!1286 = distinct !DILexicalBlock(scope: !1204, file: !3, line: 251, column: 9)
!1287 = !DILocation(line: 251, column: 26, scope: !1286)
!1288 = !DILocation(line: 251, column: 9, scope: !1204)
!1289 = !DILocation(line: 252, column: 17, scope: !1286)
!1290 = !DILocation(line: 252, column: 9, scope: !1286)
!1291 = !DILocation(line: 253, column: 5, scope: !1204)
!1292 = !DILocation(line: 254, column: 18, scope: !1293)
!1293 = distinct !DILexicalBlock(scope: !1204, file: !3, line: 254, column: 9)
!1294 = !DILocation(line: 254, column: 26, scope: !1293)
!1295 = !DILocation(line: 254, column: 9, scope: !1204)
!1296 = !DILocation(line: 255, column: 17, scope: !1293)
!1297 = !DILocation(line: 255, column: 9, scope: !1293)
!1298 = !DILocation(line: 258, column: 18, scope: !1299)
!1299 = distinct !DILexicalBlock(scope: !1204, file: !3, line: 258, column: 9)
!1300 = !DILocation(line: 258, column: 26, scope: !1299)
!1301 = !DILocation(line: 258, column: 9, scope: !1204)
!1302 = !DILocation(line: 259, column: 17, scope: !1299)
!1303 = !DILocation(line: 259, column: 9, scope: !1299)
!1304 = !DILocation(line: 260, column: 5, scope: !1204)
!1305 = !DILocation(line: 261, column: 5, scope: !1204)
!1306 = !DILocation(line: 262, column: 18, scope: !1307)
!1307 = distinct !DILexicalBlock(scope: !1204, file: !3, line: 262, column: 9)
!1308 = !DILocation(line: 262, column: 26, scope: !1307)
!1309 = !DILocation(line: 262, column: 9, scope: !1204)
!1310 = !DILocation(line: 263, column: 17, scope: !1307)
!1311 = !DILocation(line: 263, column: 9, scope: !1307)
!1312 = !DILocation(line: 264, column: 30, scope: !1313)
!1313 = distinct !DILexicalBlock(scope: !1314, file: !3, line: 264, column: 5)
!1314 = distinct !DILexicalBlock(scope: !1204, file: !3, line: 264, column: 5)
!1315 = !DILocation(line: 264, column: 19, scope: !1313)
!1316 = !DILocation(line: 264, column: 5, scope: !1314)
!1317 = !DILocation(line: 265, column: 22, scope: !1318)
!1318 = distinct !DILexicalBlock(scope: !1313, file: !3, line: 264, column: 48)
!1319 = !DILocation(line: 265, column: 33, scope: !1318)
!1320 = !{!1117, !991, i64 0}
!1321 = !DILocation(line: 265, column: 9, scope: !1318)
!1322 = !DILocation(line: 264, column: 44, scope: !1313)
!1323 = distinct !{!1323, !1316, !1324, !1012}
!1324 = !DILocation(line: 266, column: 5, scope: !1314)
!1325 = !DILocation(line: 268, column: 18, scope: !1326)
!1326 = distinct !DILexicalBlock(scope: !1204, file: !3, line: 268, column: 9)
!1327 = !DILocation(line: 268, column: 26, scope: !1326)
!1328 = !DILocation(line: 268, column: 9, scope: !1204)
!1329 = !DILocation(line: 269, column: 17, scope: !1326)
!1330 = !DILocation(line: 269, column: 9, scope: !1326)
!1331 = !DILocation(line: 272, column: 1, scope: !1204)
!1332 = !DISubprogram(name: "stop_assoc_maintenance_thread", scope: !1333, file: !1333, line: 9, type: !1031, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1333 = !DIFile(filename: "./assoc.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "07a03bb93725ff477a16ac4bae114cd2")
!1334 = !DISubprogram(name: "stop_item_crawler_thread", scope: !1036, file: !1036, line: 33, type: !1335, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1335 = !DISubroutineType(types: !1336)
!1336 = !{!130, !275}
!1337 = !DISubprogram(name: "stop_lru_maintainer_thread", scope: !1034, file: !1034, line: 80, type: !1338, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1338 = !DISubroutineType(types: !1339)
!1339 = !{!130}
!1340 = !DISubprogram(name: "stop_slab_maintenance_thread", scope: !1030, file: !1030, line: 53, type: !1031, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1341 = !DISubprogram(name: "logger_stop", scope: !69, file: !69, line: 226, type: !1031, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1342 = !DISubprogram(name: "stop_conn_timeout_thread", scope: !6, file: !6, line: 1023, type: !1338, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1343 = !DISubprogram(name: "conn_close_all", scope: !6, file: !6, line: 1005, type: !1031, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1344 = !DISubprogram(name: "pthread_join", scope: !934, file: !934, line: 219, type: !1345, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1345 = !DISubroutineType(types: !1346)
!1346 = !{!130, !159, !1347}
!1347 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !119, size: 64)
!1348 = distinct !DISubprogram(name: "accept_new_conns", scope: !3, file: !3, line: 397, type: !1349, scopeLine: 397, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1352)
!1349 = !DISubroutineType(types: !1350)
!1350 = !{null, !1351}
!1351 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !275)
!1352 = !{!1353}
!1353 = !DILocalVariable(name: "do_accept", arg: 1, scope: !1348, file: !3, line: 397, type: !1351)
!1354 = !DILocation(line: 0, scope: !1348)
!1355 = !DILocation(line: 398, column: 5, scope: !1348)
!1356 = !DILocation(line: 399, column: 5, scope: !1348)
!1357 = !DILocation(line: 400, column: 5, scope: !1348)
!1358 = !DILocation(line: 401, column: 1, scope: !1348)
!1359 = !DISubprogram(name: "do_accept_new_conns", scope: !6, file: !6, line: 951, type: !1349, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1360 = distinct !DISubprogram(name: "thread_setname", scope: !3, file: !3, line: 685, type: !1361, scopeLine: 685, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1363)
!1361 = !DISubroutineType(types: !1362)
!1362 = !{null, !159, !1101}
!1363 = !{!1364, !1365}
!1364 = !DILocalVariable(name: "thread", arg: 1, scope: !1360, file: !3, line: 685, type: !159)
!1365 = !DILocalVariable(name: "name", arg: 2, scope: !1360, file: !3, line: 685, type: !1101)
!1366 = !DILocation(line: 0, scope: !1360)
!1367 = !DILocation(line: 688, column: 1, scope: !1360)
!1368 = !DILocation(line: 690, column: 1, scope: !1360)
!1369 = !DISubprogram(name: "pthread_setname_np", scope: !934, file: !934, line: 463, type: !1370, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1370 = !DISubroutineType(types: !1371)
!1371 = !{!130, !159, !1101}
!1372 = distinct !DISubprogram(name: "get_worker_thread", scope: !3, file: !3, line: 695, type: !1373, scopeLine: 695, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1375)
!1373 = !DISubroutineType(types: !1374)
!1374 = !{!154, !130}
!1375 = !{!1376}
!1376 = !DILocalVariable(name: "id", arg: 1, scope: !1372, file: !3, line: 695, type: !130)
!1377 = !DILocation(line: 0, scope: !1372)
!1378 = !DILocation(line: 696, column: 13, scope: !1372)
!1379 = !DILocation(line: 696, column: 5, scope: !1372)
!1380 = distinct !DISubprogram(name: "dispatch_conn_new", scope: !3, file: !3, line: 778, type: !1381, scopeLine: 780, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1383)
!1381 = !DISubroutineType(types: !1382)
!1382 = !{null, !130, !20, !130, !130, !57, !119, !345, !52}
!1383 = !{!1384, !1385, !1386, !1387, !1388, !1389, !1390, !1391, !1392, !1393}
!1384 = !DILocalVariable(name: "sfd", arg: 1, scope: !1380, file: !3, line: 778, type: !130)
!1385 = !DILocalVariable(name: "init_state", arg: 2, scope: !1380, file: !3, line: 778, type: !20)
!1386 = !DILocalVariable(name: "event_flags", arg: 3, scope: !1380, file: !3, line: 778, type: !130)
!1387 = !DILocalVariable(name: "read_buffer_size", arg: 4, scope: !1380, file: !3, line: 779, type: !130)
!1388 = !DILocalVariable(name: "transport", arg: 5, scope: !1380, file: !3, line: 779, type: !57)
!1389 = !DILocalVariable(name: "ssl", arg: 6, scope: !1380, file: !3, line: 779, type: !119)
!1390 = !DILocalVariable(name: "conntag", arg: 7, scope: !1380, file: !3, line: 780, type: !345)
!1391 = !DILocalVariable(name: "bproto", arg: 8, scope: !1380, file: !3, line: 780, type: !52)
!1392 = !DILocalVariable(name: "item", scope: !1380, file: !3, line: 781, type: !1111)
!1393 = !DILocalVariable(name: "thread", scope: !1380, file: !3, line: 782, type: !154)
!1394 = distinct !DIAssignID()
!1395 = distinct !DIAssignID()
!1396 = !DILocalVariable(name: "napi_id", scope: !1397, file: !3, line: 734, type: !130)
!1397 = distinct !DISubprogram(name: "select_thread_by_napi_id", scope: !3, file: !3, line: 731, type: !1373, scopeLine: 732, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1398)
!1398 = !{!1399, !1400, !1396, !1401, !1402, !1403, !1404, !1405}
!1399 = !DILocalVariable(name: "sfd", arg: 1, scope: !1397, file: !3, line: 731, type: !130)
!1400 = !DILocalVariable(name: "thread", scope: !1397, file: !3, line: 733, type: !154)
!1401 = !DILocalVariable(name: "err", scope: !1397, file: !3, line: 734, type: !130)
!1402 = !DILocalVariable(name: "i", scope: !1397, file: !3, line: 734, type: !130)
!1403 = !DILocalVariable(name: "len", scope: !1397, file: !3, line: 735, type: !397)
!1404 = !DILocalVariable(name: "tid", scope: !1397, file: !3, line: 736, type: !130)
!1405 = !DILabel(scope: !1397, name: "select", file: !3, line: 747)
!1406 = !DILocation(line: 0, scope: !1397, inlinedAt: !1407)
!1407 = distinct !DILocation(line: 787, column: 18, scope: !1408)
!1408 = distinct !DILexicalBlock(scope: !1380, file: !3, line: 784, column: 9)
!1409 = distinct !DIAssignID()
!1410 = !DILocation(line: 0, scope: !1380)
!1411 = !DILocation(line: 784, column: 19, scope: !1408)
!1412 = !{!990, !931, i64 312}
!1413 = !DILocation(line: 784, column: 10, scope: !1408)
!1414 = !DILocation(line: 784, column: 9, scope: !1380)
!1415 = !DILocation(line: 707, column: 16, scope: !1416, inlinedAt: !1421)
!1416 = distinct !DISubprogram(name: "select_thread_round_robin", scope: !3, file: !3, line: 705, type: !1417, scopeLine: 706, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1419)
!1417 = !DISubroutineType(types: !1418)
!1418 = !{!154}
!1419 = !{!1420}
!1420 = !DILocalVariable(name: "tid", scope: !1416, file: !3, line: 707, type: !130)
!1421 = distinct !DILocation(line: 785, column: 18, scope: !1408)
!1422 = !DILocation(line: 707, column: 28, scope: !1416, inlinedAt: !1421)
!1423 = !DILocation(line: 707, column: 44, scope: !1416, inlinedAt: !1421)
!1424 = !DILocation(line: 707, column: 33, scope: !1416, inlinedAt: !1421)
!1425 = !DILocation(line: 0, scope: !1416, inlinedAt: !1421)
!1426 = !DILocation(line: 709, column: 17, scope: !1416, inlinedAt: !1421)
!1427 = !DILocation(line: 711, column: 12, scope: !1416, inlinedAt: !1421)
!1428 = !DILocation(line: 711, column: 20, scope: !1416, inlinedAt: !1421)
!1429 = !DILocation(line: 785, column: 9, scope: !1408)
!1430 = !DILocation(line: 734, column: 5, scope: !1397, inlinedAt: !1407)
!1431 = !DILocation(line: 735, column: 5, scope: !1397, inlinedAt: !1407)
!1432 = !DILocation(line: 738, column: 9, scope: !1397, inlinedAt: !1407)
!1433 = distinct !DIAssignID()
!1434 = !DILocation(line: 739, column: 11, scope: !1397, inlinedAt: !1407)
!1435 = !DILocation(line: 740, column: 14, scope: !1436, inlinedAt: !1407)
!1436 = distinct !DILexicalBlock(scope: !1397, file: !3, line: 740, column: 9)
!1437 = !DILocation(line: 740, column: 21, scope: !1436, inlinedAt: !1407)
!1438 = !DILocation(line: 740, column: 25, scope: !1436, inlinedAt: !1407)
!1439 = !DILocation(line: 740, column: 33, scope: !1436, inlinedAt: !1407)
!1440 = !DILocation(line: 740, column: 9, scope: !1397, inlinedAt: !1407)
!1441 = !DILocation(line: 748, column: 5, scope: !1442, inlinedAt: !1407)
!1442 = distinct !DILexicalBlock(scope: !1397, file: !3, line: 748, column: 5)
!1443 = !DILocation(line: 982, column: 5, scope: !1144, inlinedAt: !1444)
!1444 = distinct !DILocation(line: 741, column: 9, scope: !1445, inlinedAt: !1407)
!1445 = distinct !DILexicalBlock(scope: !1436, file: !3, line: 740, column: 40)
!1446 = !DILocation(line: 742, column: 35, scope: !1445, inlinedAt: !1407)
!1447 = !{!1149, !991, i64 216}
!1448 = !DILocation(line: 986, column: 5, scope: !1151, inlinedAt: !1449)
!1449 = distinct !DILocation(line: 743, column: 9, scope: !1445, inlinedAt: !1407)
!1450 = !DILocation(line: 707, column: 16, scope: !1416, inlinedAt: !1451)
!1451 = distinct !DILocation(line: 744, column: 16, scope: !1445, inlinedAt: !1407)
!1452 = !DILocation(line: 707, column: 28, scope: !1416, inlinedAt: !1451)
!1453 = !DILocation(line: 707, column: 44, scope: !1416, inlinedAt: !1451)
!1454 = !DILocation(line: 707, column: 33, scope: !1416, inlinedAt: !1451)
!1455 = !DILocation(line: 0, scope: !1416, inlinedAt: !1451)
!1456 = !DILocation(line: 709, column: 17, scope: !1416, inlinedAt: !1451)
!1457 = !DILocation(line: 711, column: 12, scope: !1416, inlinedAt: !1451)
!1458 = !DILocation(line: 711, column: 20, scope: !1416, inlinedAt: !1451)
!1459 = !DILocation(line: 744, column: 9, scope: !1445, inlinedAt: !1407)
!1460 = !DILocation(line: 747, column: 1, scope: !1397, inlinedAt: !1407)
!1461 = !DILocation(line: 748, column: 19, scope: !1462, inlinedAt: !1407)
!1462 = distinct !DILexicalBlock(scope: !1442, file: !3, line: 748, column: 5)
!1463 = !DILocation(line: 750, column: 37, scope: !1464, inlinedAt: !1407)
!1464 = distinct !DILexicalBlock(scope: !1465, file: !3, line: 750, column: 14)
!1465 = distinct !DILexicalBlock(scope: !1462, file: !3, line: 748, column: 48)
!1466 = !DILocation(line: 750, column: 14, scope: !1465, inlinedAt: !1407)
!1467 = !DILocation(line: 751, column: 22, scope: !1468, inlinedAt: !1407)
!1468 = distinct !DILexicalBlock(scope: !1464, file: !3, line: 750, column: 42)
!1469 = !DILocation(line: 751, column: 30, scope: !1468, inlinedAt: !1407)
!1470 = !{!1117, !931, i64 6928}
!1471 = !DILocation(line: 752, column: 37, scope: !1468, inlinedAt: !1407)
!1472 = !DILocation(line: 754, column: 14, scope: !1468, inlinedAt: !1407)
!1473 = !DILocation(line: 756, column: 22, scope: !1474, inlinedAt: !1407)
!1474 = distinct !DILexicalBlock(scope: !1465, file: !3, line: 756, column: 14)
!1475 = !DILocation(line: 756, column: 30, scope: !1474, inlinedAt: !1407)
!1476 = !DILocation(line: 756, column: 14, scope: !1465, inlinedAt: !1407)
!1477 = !DILocation(line: 748, column: 44, scope: !1462, inlinedAt: !1407)
!1478 = distinct !{!1478, !1441, !1479, !1012}
!1479 = !DILocation(line: 760, column: 5, scope: !1442, inlinedAt: !1407)
!1480 = !DILocation(line: 982, column: 5, scope: !1144, inlinedAt: !1481)
!1481 = distinct !DILocation(line: 763, column: 9, scope: !1482, inlinedAt: !1407)
!1482 = distinct !DILexicalBlock(scope: !1483, file: !3, line: 762, column: 20)
!1483 = distinct !DILexicalBlock(scope: !1397, file: !3, line: 762, column: 9)
!1484 = !DILocation(line: 764, column: 34, scope: !1482, inlinedAt: !1407)
!1485 = !{!1149, !991, i64 208}
!1486 = !DILocation(line: 986, column: 5, scope: !1151, inlinedAt: !1487)
!1487 = distinct !DILocation(line: 765, column: 9, scope: !1482, inlinedAt: !1407)
!1488 = !DILocalVariable(name: "i", scope: !1489, file: !3, line: 717, type: !130)
!1489 = distinct !DISubprogram(name: "reset_threads_napi_id", scope: !3, file: !3, line: 714, type: !1031, scopeLine: 715, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1490)
!1490 = !{!1491, !1488}
!1491 = !DILocalVariable(name: "thread", scope: !1489, file: !3, line: 716, type: !154)
!1492 = !DILocation(line: 0, scope: !1489, inlinedAt: !1493)
!1493 = distinct !DILocation(line: 766, column: 9, scope: !1482, inlinedAt: !1407)
!1494 = !DILocation(line: 719, column: 19, scope: !1495, inlinedAt: !1493)
!1495 = distinct !DILexicalBlock(scope: !1496, file: !3, line: 719, column: 5)
!1496 = distinct !DILexicalBlock(scope: !1489, file: !3, line: 719, column: 5)
!1497 = !DILocation(line: 719, column: 5, scope: !1496, inlinedAt: !1493)
!1498 = !DILocation(line: 721, column: 18, scope: !1499, inlinedAt: !1493)
!1499 = distinct !DILexicalBlock(scope: !1495, file: !3, line: 719, column: 48)
!1500 = !DILocation(line: 721, column: 26, scope: !1499, inlinedAt: !1493)
!1501 = !DILocation(line: 719, column: 44, scope: !1495, inlinedAt: !1493)
!1502 = distinct !{!1502, !1497, !1503, !1012}
!1503 = !DILocation(line: 722, column: 5, scope: !1496, inlinedAt: !1493)
!1504 = distinct !{!1504, !1505}
!1505 = !{!"llvm.loop.unroll.disable"}
!1506 = !DILocation(line: 724, column: 28, scope: !1489, inlinedAt: !1493)
!1507 = !DILocation(line: 767, column: 9, scope: !1482, inlinedAt: !1407)
!1508 = !DILocation(line: 770, column: 20, scope: !1397, inlinedAt: !1407)
!1509 = !DILocation(line: 770, column: 12, scope: !1397, inlinedAt: !1407)
!1510 = !DILocation(line: 770, column: 5, scope: !1397, inlinedAt: !1407)
!1511 = !DILocation(line: 771, column: 1, scope: !1397, inlinedAt: !1407)
!1512 = !DILocation(line: 0, scope: !1408)
!1513 = !DILocation(line: 789, column: 28, scope: !1380)
!1514 = !DILocation(line: 0, scope: !1127, inlinedAt: !1515)
!1515 = distinct !DILocation(line: 789, column: 12, scope: !1380)
!1516 = !DILocation(line: 318, column: 37, scope: !1127, inlinedAt: !1515)
!1517 = !DILocation(line: 318, column: 21, scope: !1127, inlinedAt: !1515)
!1518 = !DILocation(line: 319, column: 14, scope: !1141, inlinedAt: !1515)
!1519 = !DILocation(line: 319, column: 9, scope: !1127, inlinedAt: !1515)
!1520 = !DILocation(line: 982, column: 5, scope: !1144, inlinedAt: !1521)
!1521 = distinct !DILocation(line: 320, column: 9, scope: !1146, inlinedAt: !1515)
!1522 = !DILocation(line: 321, column: 27, scope: !1146, inlinedAt: !1515)
!1523 = !DILocation(line: 986, column: 5, scope: !1151, inlinedAt: !1524)
!1524 = distinct !DILocation(line: 322, column: 9, scope: !1146, inlinedAt: !1515)
!1525 = !DILocation(line: 791, column: 9, scope: !1526)
!1526 = distinct !DILexicalBlock(scope: !1527, file: !3, line: 790, column: 23)
!1527 = distinct !DILexicalBlock(scope: !1380, file: !3, line: 790, column: 9)
!1528 = !DILocation(line: 793, column: 17, scope: !1526)
!1529 = !DILocation(line: 793, column: 9, scope: !1526)
!1530 = !DILocation(line: 794, column: 9, scope: !1526)
!1531 = !DILocation(line: 797, column: 15, scope: !1380)
!1532 = !DILocation(line: 798, column: 11, scope: !1380)
!1533 = !DILocation(line: 798, column: 22, scope: !1380)
!1534 = !{!1160, !931, i64 4}
!1535 = !DILocation(line: 799, column: 11, scope: !1380)
!1536 = !DILocation(line: 799, column: 23, scope: !1380)
!1537 = !{!1160, !931, i64 8}
!1538 = !DILocation(line: 800, column: 11, scope: !1380)
!1539 = !DILocation(line: 800, column: 28, scope: !1380)
!1540 = !{!1160, !931, i64 12}
!1541 = !DILocation(line: 801, column: 11, scope: !1380)
!1542 = !DILocation(line: 801, column: 21, scope: !1380)
!1543 = !{!1160, !931, i64 16}
!1544 = !DILocation(line: 802, column: 11, scope: !1380)
!1545 = !DILocation(line: 802, column: 16, scope: !1380)
!1546 = !DILocation(line: 803, column: 11, scope: !1380)
!1547 = !DILocation(line: 803, column: 15, scope: !1380)
!1548 = !{!1160, !927, i64 32}
!1549 = !DILocation(line: 804, column: 11, scope: !1380)
!1550 = !DILocation(line: 804, column: 19, scope: !1380)
!1551 = !{!1160, !991, i64 40}
!1552 = !DILocation(line: 805, column: 11, scope: !1380)
!1553 = !DILocation(line: 805, column: 18, scope: !1380)
!1554 = !{!1160, !931, i64 48}
!1555 = !DILocation(line: 0, scope: !1165, inlinedAt: !1556)
!1556 = distinct !DILocation(line: 808, column: 5, scope: !1380)
!1557 = !DILocation(line: 341, column: 16, scope: !1165, inlinedAt: !1556)
!1558 = !DILocation(line: 0, scope: !1175, inlinedAt: !1559)
!1559 = distinct !DILocation(line: 341, column: 5, scope: !1165, inlinedAt: !1556)
!1560 = !DILocation(line: 309, column: 29, scope: !1175, inlinedAt: !1559)
!1561 = !DILocation(line: 309, column: 5, scope: !1175, inlinedAt: !1559)
!1562 = !DILocation(line: 310, column: 5, scope: !1185, inlinedAt: !1559)
!1563 = !DILocation(line: 311, column: 5, scope: !1175, inlinedAt: !1559)
!1564 = !DILocation(line: 343, column: 5, scope: !1165, inlinedAt: !1556)
!1565 = !DILocation(line: 343, column: 14, scope: !1165, inlinedAt: !1556)
!1566 = distinct !DIAssignID()
!1567 = !DILocation(line: 344, column: 20, scope: !1194, inlinedAt: !1556)
!1568 = !DILocation(line: 344, column: 9, scope: !1194, inlinedAt: !1556)
!1569 = !DILocation(line: 344, column: 59, scope: !1194, inlinedAt: !1556)
!1570 = !DILocation(line: 344, column: 9, scope: !1165, inlinedAt: !1556)
!1571 = !DILocation(line: 345, column: 9, scope: !1200, inlinedAt: !1556)
!1572 = !DILocation(line: 347, column: 5, scope: !1200, inlinedAt: !1556)
!1573 = !DILocation(line: 355, column: 1, scope: !1165, inlinedAt: !1556)
!1574 = !DILocation(line: 809, column: 1, scope: !1380)
!1575 = !DISubprogram(name: "close", scope: !1576, file: !1576, line: 358, type: !1577, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1576 = !DIFile(filename: "/usr/include/unistd.h", directory: "", checksumkind: CSK_MD5, checksum: "877e832a8bb8424f9180387a13787475")
!1577 = !DISubroutineType(types: !1578)
!1578 = !{!130, !130}
!1579 = distinct !DISubprogram(name: "redispatch_conn", scope: !3, file: !3, line: 815, type: !1580, scopeLine: 815, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1582)
!1580 = !DISubroutineType(types: !1581)
!1581 = !{null, !265}
!1582 = !{!1583}
!1583 = !DILocalVariable(name: "c", arg: 1, scope: !1579, file: !3, line: 815, type: !265)
!1584 = !DILocation(line: 0, scope: !1579)
!1585 = !DILocation(line: 816, column: 25, scope: !1579)
!1586 = !{!1587, !927, i64 456}
!1587 = !{!"conn", !927, i64 0, !931, i64 8, !993, i64 12, !993, i64 13, !993, i64 14, !993, i64 15, !993, i64 16, !993, i64 17, !993, i64 18, !931, i64 20, !931, i64 24, !931, i64 28, !1119, i64 32, !1122, i64 160, !1122, i64 162, !927, i64 168, !927, i64 176, !931, i64 184, !931, i64 188, !927, i64 192, !927, i64 200, !927, i64 208, !931, i64 216, !927, i64 224, !931, i64 232, !931, i64 236, !928, i64 240, !931, i64 312, !931, i64 316, !931, i64 320, !931, i64 324, !931, i64 328, !1588, i64 332, !931, i64 360, !993, i64 364, !1590, i64 368, !928, i64 392, !991, i64 416, !991, i64 424, !1122, i64 432, !931, i64 436, !931, i64 440, !927, i64 448, !927, i64 456, !927, i64 464, !927, i64 472, !927, i64 480, !927, i64 488}
!1588 = !{!"sockaddr_in6", !1122, i64 0, !1122, i64 2, !931, i64 4, !1589, i64 8, !931, i64 24}
!1589 = !{!"in6_addr", !928, i64 0}
!1590 = !{!"", !927, i64 0, !991, i64 8, !991, i64 16}
!1591 = !DILocation(line: 816, column: 36, scope: !1579)
!1592 = !{!1587, !931, i64 8}
!1593 = !DILocation(line: 816, column: 5, scope: !1579)
!1594 = !DILocation(line: 817, column: 1, scope: !1579)
!1595 = distinct !DISubprogram(name: "timeout_conn", scope: !3, file: !3, line: 819, type: !1580, scopeLine: 819, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1596)
!1596 = !{!1597}
!1597 = !DILocalVariable(name: "c", arg: 1, scope: !1595, file: !3, line: 819, type: !265)
!1598 = !DILocation(line: 0, scope: !1595)
!1599 = !DILocation(line: 820, column: 25, scope: !1595)
!1600 = !DILocation(line: 820, column: 36, scope: !1595)
!1601 = !DILocation(line: 820, column: 5, scope: !1595)
!1602 = !DILocation(line: 821, column: 1, scope: !1595)
!1603 = distinct !DISubprogram(name: "return_io_pending", scope: !3, file: !3, line: 828, type: !494, scopeLine: 828, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1604)
!1604 = !{!1605, !1606, !1607, !1608}
!1605 = !DILocalVariable(name: "io", arg: 1, scope: !1603, file: !3, line: 828, type: !319)
!1606 = !DILocalVariable(name: "do_notify", scope: !1603, file: !3, line: 829, type: !275)
!1607 = !DILocalVariable(name: "t", scope: !1603, file: !3, line: 830, type: !154)
!1608 = !DILocalVariable(name: "u", scope: !1609, file: !3, line: 842, type: !345)
!1609 = distinct !DILexicalBlock(scope: !1610, file: !3, line: 840, column: 20)
!1610 = distinct !DILexicalBlock(scope: !1603, file: !3, line: 840, column: 9)
!1611 = distinct !DIAssignID()
!1612 = !DILocation(line: 0, scope: !1609)
!1613 = !DILocation(line: 0, scope: !1603)
!1614 = !DILocation(line: 830, column: 30, scope: !1603)
!1615 = !{!1616, !927, i64 8}
!1616 = !{!"_io_pending_t", !931, i64 0, !927, i64 8, !927, i64 16, !927, i64 24, !927, i64 32, !927, i64 40, !1161, i64 48, !928, i64 56}
!1617 = !DILocation(line: 831, column: 28, scope: !1603)
!1618 = !DILocation(line: 831, column: 5, scope: !1603)
!1619 = !DILocation(line: 832, column: 9, scope: !1620)
!1620 = distinct !DILexicalBlock(scope: !1603, file: !3, line: 832, column: 9)
!1621 = !{!1117, !927, i64 328}
!1622 = !DILocation(line: 835, column: 5, scope: !1623)
!1623 = distinct !DILexicalBlock(scope: !1603, file: !3, line: 835, column: 5)
!1624 = !{!1616, !927, i64 48}
!1625 = !{!1117, !927, i64 336}
!1626 = !DILocation(line: 836, column: 5, scope: !1603)
!1627 = !DILocation(line: 840, column: 9, scope: !1603)
!1628 = !DILocation(line: 842, column: 9, scope: !1609)
!1629 = !DILocation(line: 842, column: 18, scope: !1609)
!1630 = distinct !DIAssignID()
!1631 = !DILocation(line: 843, column: 26, scope: !1632)
!1632 = distinct !DILexicalBlock(scope: !1609, file: !3, line: 843, column: 13)
!1633 = !{!1117, !931, i64 280}
!1634 = !DILocation(line: 843, column: 13, scope: !1632)
!1635 = !DILocation(line: 843, column: 65, scope: !1632)
!1636 = !DILocation(line: 843, column: 13, scope: !1609)
!1637 = !DILocation(line: 844, column: 13, scope: !1638)
!1638 = distinct !DILexicalBlock(scope: !1632, file: !3, line: 843, column: 86)
!1639 = !DILocation(line: 846, column: 9, scope: !1638)
!1640 = !DILocation(line: 854, column: 5, scope: !1610)
!1641 = !DILocation(line: 854, column: 5, scope: !1609)
!1642 = !DILocation(line: 855, column: 1, scope: !1603)
!1643 = !DISubprogram(name: "write", scope: !1576, file: !1576, line: 378, type: !1644, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1644 = !DISubroutineType(types: !1645)
!1645 = !{!471, !130, !692, !355}
!1646 = !DISubprogram(name: "perror", scope: !1046, file: !1046, line: 878, type: !1647, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1647 = !DISubroutineType(types: !1648)
!1648 = !{null, !1101}
!1649 = distinct !DISubprogram(name: "sidethread_conn_close", scope: !3, file: !3, line: 858, type: !1580, scopeLine: 858, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1650)
!1650 = !{!1651}
!1651 = !DILocalVariable(name: "c", arg: 1, scope: !1649, file: !3, line: 858, type: !265)
!1652 = !DILocation(line: 0, scope: !1649)
!1653 = !DILocation(line: 859, column: 18, scope: !1654)
!1654 = distinct !DILexicalBlock(scope: !1649, file: !3, line: 859, column: 9)
!1655 = !DILocation(line: 859, column: 26, scope: !1654)
!1656 = !DILocation(line: 859, column: 9, scope: !1649)
!1657 = !DILocation(line: 860, column: 17, scope: !1654)
!1658 = !DILocation(line: 860, column: 74, scope: !1654)
!1659 = !DILocation(line: 860, column: 9, scope: !1654)
!1660 = !DILocation(line: 862, column: 8, scope: !1649)
!1661 = !DILocation(line: 862, column: 14, scope: !1649)
!1662 = !{!1587, !931, i64 20}
!1663 = !DILocation(line: 0, scope: !1579, inlinedAt: !1664)
!1664 = distinct !DILocation(line: 864, column: 5, scope: !1649)
!1665 = !DILocation(line: 816, column: 25, scope: !1579, inlinedAt: !1664)
!1666 = !DILocation(line: 816, column: 36, scope: !1579, inlinedAt: !1664)
!1667 = !DILocation(line: 816, column: 5, scope: !1579, inlinedAt: !1664)
!1668 = !DILocation(line: 865, column: 5, scope: !1649)
!1669 = distinct !DISubprogram(name: "item_alloc", scope: !3, file: !3, line: 873, type: !1670, scopeLine: 873, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1673)
!1670 = !DISubroutineType(types: !1671)
!1671 = !{!322, !1101, !355, !1672, !285, !130}
!1672 = !DIDerivedType(tag: DW_TAG_typedef, name: "client_flags_t", file: !6, line: 99, baseType: !377)
!1673 = !{!1674, !1675, !1676, !1677, !1678, !1679}
!1674 = !DILocalVariable(name: "key", arg: 1, scope: !1669, file: !3, line: 873, type: !1101)
!1675 = !DILocalVariable(name: "nkey", arg: 2, scope: !1669, file: !3, line: 873, type: !355)
!1676 = !DILocalVariable(name: "flags", arg: 3, scope: !1669, file: !3, line: 873, type: !1672)
!1677 = !DILocalVariable(name: "exptime", arg: 4, scope: !1669, file: !3, line: 873, type: !285)
!1678 = !DILocalVariable(name: "nbytes", arg: 5, scope: !1669, file: !3, line: 873, type: !130)
!1679 = !DILocalVariable(name: "it", scope: !1669, file: !3, line: 874, type: !322)
!1680 = !DILocation(line: 0, scope: !1669)
!1681 = !DILocation(line: 876, column: 10, scope: !1669)
!1682 = !DILocation(line: 877, column: 5, scope: !1669)
!1683 = !DISubprogram(name: "do_item_alloc", scope: !1034, file: !1034, line: 14, type: !1684, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1684 = !DISubroutineType(types: !1685)
!1685 = !{!322, !1101, !1686, !1687, !1688, !1689}
!1686 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !355)
!1687 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !1672)
!1688 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !285)
!1689 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !130)
!1690 = distinct !DISubprogram(name: "item_get", scope: !3, file: !3, line: 884, type: !1691, scopeLine: 884, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1693)
!1691 = !DISubroutineType(types: !1692)
!1692 = !{!322, !1101, !1686, !154, !1351}
!1693 = !{!1694, !1695, !1696, !1697, !1698, !1699}
!1694 = !DILocalVariable(name: "key", arg: 1, scope: !1690, file: !3, line: 884, type: !1101)
!1695 = !DILocalVariable(name: "nkey", arg: 2, scope: !1690, file: !3, line: 884, type: !1686)
!1696 = !DILocalVariable(name: "t", arg: 3, scope: !1690, file: !3, line: 884, type: !154)
!1697 = !DILocalVariable(name: "do_update", arg: 4, scope: !1690, file: !3, line: 884, type: !1351)
!1698 = !DILocalVariable(name: "it", scope: !1690, file: !3, line: 885, type: !322)
!1699 = !DILocalVariable(name: "hv", scope: !1690, file: !3, line: 886, type: !377)
!1700 = !DILocation(line: 0, scope: !1690)
!1701 = !DILocation(line: 887, column: 10, scope: !1690)
!1702 = !DILocation(line: 0, scope: !919, inlinedAt: !1703)
!1703 = distinct !DILocation(line: 888, column: 5, scope: !1690)
!1704 = !DILocation(line: 122, column: 5, scope: !919, inlinedAt: !1703)
!1705 = !DILocation(line: 889, column: 10, scope: !1690)
!1706 = !DILocation(line: 0, scope: !962, inlinedAt: !1707)
!1707 = distinct !DILocation(line: 890, column: 5, scope: !1690)
!1708 = !DILocation(line: 138, column: 5, scope: !962, inlinedAt: !1707)
!1709 = !DILocation(line: 891, column: 5, scope: !1690)
!1710 = !DISubprogram(name: "do_item_get", scope: !1034, file: !1034, line: 73, type: !1711, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1711 = !DISubroutineType(types: !1712)
!1712 = !{!322, !1101, !1686, !1713, !154, !1351}
!1713 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !377)
!1714 = distinct !DISubprogram(name: "item_get_locked", scope: !3, file: !3, line: 897, type: !1715, scopeLine: 897, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1718)
!1715 = !DISubroutineType(types: !1716)
!1716 = !{!322, !1101, !1686, !154, !1351, !1717}
!1717 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !377, size: 64)
!1718 = !{!1719, !1720, !1721, !1722, !1723, !1724}
!1719 = !DILocalVariable(name: "key", arg: 1, scope: !1714, file: !3, line: 897, type: !1101)
!1720 = !DILocalVariable(name: "nkey", arg: 2, scope: !1714, file: !3, line: 897, type: !1686)
!1721 = !DILocalVariable(name: "t", arg: 3, scope: !1714, file: !3, line: 897, type: !154)
!1722 = !DILocalVariable(name: "do_update", arg: 4, scope: !1714, file: !3, line: 897, type: !1351)
!1723 = !DILocalVariable(name: "hv", arg: 5, scope: !1714, file: !3, line: 897, type: !1717)
!1724 = !DILocalVariable(name: "it", scope: !1714, file: !3, line: 898, type: !322)
!1725 = !DILocation(line: 0, scope: !1714)
!1726 = !DILocation(line: 899, column: 11, scope: !1714)
!1727 = !DILocation(line: 899, column: 9, scope: !1714)
!1728 = !DILocation(line: 0, scope: !919, inlinedAt: !1729)
!1729 = distinct !DILocation(line: 900, column: 5, scope: !1714)
!1730 = !DILocation(line: 122, column: 5, scope: !919, inlinedAt: !1729)
!1731 = !DILocation(line: 901, column: 33, scope: !1714)
!1732 = !DILocation(line: 901, column: 10, scope: !1714)
!1733 = !DILocation(line: 902, column: 5, scope: !1714)
!1734 = distinct !DISubprogram(name: "item_touch", scope: !3, file: !3, line: 905, type: !1735, scopeLine: 905, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1737)
!1735 = !DISubroutineType(types: !1736)
!1736 = !{!322, !1101, !355, !377, !154}
!1737 = !{!1738, !1739, !1740, !1741, !1742, !1743}
!1738 = !DILocalVariable(name: "key", arg: 1, scope: !1734, file: !3, line: 905, type: !1101)
!1739 = !DILocalVariable(name: "nkey", arg: 2, scope: !1734, file: !3, line: 905, type: !355)
!1740 = !DILocalVariable(name: "exptime", arg: 3, scope: !1734, file: !3, line: 905, type: !377)
!1741 = !DILocalVariable(name: "t", arg: 4, scope: !1734, file: !3, line: 905, type: !154)
!1742 = !DILocalVariable(name: "it", scope: !1734, file: !3, line: 906, type: !322)
!1743 = !DILocalVariable(name: "hv", scope: !1734, file: !3, line: 907, type: !377)
!1744 = !DILocation(line: 0, scope: !1734)
!1745 = !DILocation(line: 908, column: 10, scope: !1734)
!1746 = !DILocation(line: 0, scope: !919, inlinedAt: !1747)
!1747 = distinct !DILocation(line: 909, column: 5, scope: !1734)
!1748 = !DILocation(line: 122, column: 5, scope: !919, inlinedAt: !1747)
!1749 = !DILocation(line: 910, column: 10, scope: !1734)
!1750 = !DILocation(line: 0, scope: !962, inlinedAt: !1751)
!1751 = distinct !DILocation(line: 911, column: 5, scope: !1734)
!1752 = !DILocation(line: 138, column: 5, scope: !962, inlinedAt: !1751)
!1753 = !DILocation(line: 912, column: 5, scope: !1734)
!1754 = !DISubprogram(name: "do_item_touch", scope: !1034, file: !1034, line: 74, type: !1755, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1755 = !DISubroutineType(types: !1756)
!1756 = !{!322, !1101, !1686, !377, !1713, !154}
!1757 = distinct !DISubprogram(name: "item_remove", scope: !3, file: !3, line: 919, type: !1758, scopeLine: 919, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1760)
!1758 = !DISubroutineType(types: !1759)
!1759 = !{null, !322}
!1760 = !{!1761, !1762}
!1761 = !DILocalVariable(name: "item", arg: 1, scope: !1757, file: !3, line: 919, type: !322)
!1762 = !DILocalVariable(name: "hv", scope: !1757, file: !3, line: 920, type: !377)
!1763 = !DILocation(line: 0, scope: !1757)
!1764 = !DILocation(line: 921, column: 10, scope: !1757)
!1765 = !DILocation(line: 921, column: 15, scope: !1757)
!1766 = !{!1122, !1122, i64 0}
!1767 = !DILocation(line: 921, column: 37, scope: !1757)
!1768 = !{!928, !928, i64 0}
!1769 = !DILocation(line: 921, column: 31, scope: !1757)
!1770 = !DILocation(line: 0, scope: !919, inlinedAt: !1771)
!1771 = distinct !DILocation(line: 923, column: 5, scope: !1757)
!1772 = !DILocation(line: 122, column: 5, scope: !919, inlinedAt: !1771)
!1773 = !DILocation(line: 924, column: 5, scope: !1757)
!1774 = !DILocation(line: 0, scope: !962, inlinedAt: !1775)
!1775 = distinct !DILocation(line: 925, column: 5, scope: !1757)
!1776 = !DILocation(line: 138, column: 5, scope: !962, inlinedAt: !1775)
!1777 = !DILocation(line: 926, column: 1, scope: !1757)
!1778 = !DISubprogram(name: "do_item_remove", scope: !1034, file: !1034, line: 23, type: !1758, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1779 = distinct !DISubprogram(name: "item_replace", scope: !3, file: !3, line: 933, type: !1780, scopeLine: 933, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1783)
!1780 = !DISubroutineType(types: !1781)
!1781 = !{!130, !322, !322, !1713, !1782}
!1782 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !345)
!1783 = !{!1784, !1785, !1786, !1787}
!1784 = !DILocalVariable(name: "old_it", arg: 1, scope: !1779, file: !3, line: 933, type: !322)
!1785 = !DILocalVariable(name: "new_it", arg: 2, scope: !1779, file: !3, line: 933, type: !322)
!1786 = !DILocalVariable(name: "hv", arg: 3, scope: !1779, file: !3, line: 933, type: !1713)
!1787 = !DILocalVariable(name: "cas_in", arg: 4, scope: !1779, file: !3, line: 933, type: !1782)
!1788 = !DILocation(line: 0, scope: !1779)
!1789 = !DILocation(line: 934, column: 12, scope: !1779)
!1790 = !DILocation(line: 934, column: 5, scope: !1779)
!1791 = !DISubprogram(name: "do_item_replace", scope: !1034, file: !1034, line: 26, type: !1780, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1792 = distinct !DISubprogram(name: "item_unlink", scope: !3, file: !3, line: 940, type: !1758, scopeLine: 940, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1793)
!1793 = !{!1794, !1795}
!1794 = !DILocalVariable(name: "item", arg: 1, scope: !1792, file: !3, line: 940, type: !322)
!1795 = !DILocalVariable(name: "hv", scope: !1792, file: !3, line: 941, type: !377)
!1796 = !DILocation(line: 0, scope: !1792)
!1797 = !DILocation(line: 942, column: 10, scope: !1792)
!1798 = !DILocation(line: 942, column: 15, scope: !1792)
!1799 = !DILocation(line: 942, column: 37, scope: !1792)
!1800 = !DILocation(line: 942, column: 31, scope: !1792)
!1801 = !DILocation(line: 0, scope: !919, inlinedAt: !1802)
!1802 = distinct !DILocation(line: 943, column: 5, scope: !1792)
!1803 = !DILocation(line: 122, column: 5, scope: !919, inlinedAt: !1802)
!1804 = !DILocation(line: 944, column: 5, scope: !1792)
!1805 = !DILocation(line: 0, scope: !962, inlinedAt: !1806)
!1806 = distinct !DILocation(line: 945, column: 5, scope: !1792)
!1807 = !DILocation(line: 138, column: 5, scope: !962, inlinedAt: !1806)
!1808 = !DILocation(line: 946, column: 1, scope: !1792)
!1809 = !DISubprogram(name: "do_item_unlink", scope: !1034, file: !1034, line: 21, type: !1810, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1810 = !DISubroutineType(types: !1811)
!1811 = !{null, !322, !1713}
!1812 = distinct !DISubprogram(name: "add_delta", scope: !3, file: !3, line: 951, type: !1813, scopeLine: 954, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1820)
!1813 = !DISubroutineType(types: !1814)
!1814 = !{!87, !154, !1101, !1686, !275, !1815, !153, !1819}
!1815 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !1816)
!1816 = !DIDerivedType(tag: DW_TAG_typedef, name: "int64_t", file: !1817, line: 27, baseType: !1818)
!1817 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h", directory: "", checksumkind: CSK_MD5, checksum: "649b383a60bfa3eb90e85840b2b0be20")
!1818 = !DIDerivedType(tag: DW_TAG_typedef, name: "__int64_t", file: !185, line: 44, baseType: !152)
!1819 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !345, size: 64)
!1820 = !{!1821, !1822, !1823, !1824, !1825, !1826, !1827, !1828, !1829}
!1821 = !DILocalVariable(name: "t", arg: 1, scope: !1812, file: !3, line: 951, type: !154)
!1822 = !DILocalVariable(name: "key", arg: 2, scope: !1812, file: !3, line: 951, type: !1101)
!1823 = !DILocalVariable(name: "nkey", arg: 3, scope: !1812, file: !3, line: 952, type: !1686)
!1824 = !DILocalVariable(name: "incr", arg: 4, scope: !1812, file: !3, line: 952, type: !275)
!1825 = !DILocalVariable(name: "delta", arg: 5, scope: !1812, file: !3, line: 953, type: !1815)
!1826 = !DILocalVariable(name: "buf", arg: 6, scope: !1812, file: !3, line: 953, type: !153)
!1827 = !DILocalVariable(name: "cas", arg: 7, scope: !1812, file: !3, line: 954, type: !1819)
!1828 = !DILocalVariable(name: "ret", scope: !1812, file: !3, line: 955, type: !87)
!1829 = !DILocalVariable(name: "hv", scope: !1812, file: !3, line: 956, type: !377)
!1830 = !DILocation(line: 0, scope: !1812)
!1831 = !DILocation(line: 958, column: 10, scope: !1812)
!1832 = !DILocation(line: 0, scope: !919, inlinedAt: !1833)
!1833 = distinct !DILocation(line: 959, column: 5, scope: !1812)
!1834 = !DILocation(line: 122, column: 5, scope: !919, inlinedAt: !1833)
!1835 = !DILocation(line: 960, column: 11, scope: !1812)
!1836 = !DILocation(line: 0, scope: !962, inlinedAt: !1837)
!1837 = distinct !DILocation(line: 961, column: 5, scope: !1812)
!1838 = !DILocation(line: 138, column: 5, scope: !962, inlinedAt: !1837)
!1839 = !DILocation(line: 962, column: 5, scope: !1812)
!1840 = !DISubprogram(name: "do_add_delta", scope: !6, file: !6, line: 952, type: !1841, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1841 = !DISubroutineType(types: !1842)
!1842 = !{!87, !154, !1101, !1686, !1351, !1815, !153, !1819, !1713, !1843}
!1843 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !322, size: 64)
!1844 = distinct !DISubprogram(name: "store_item", scope: !3, file: !3, line: 968, type: !1845, scopeLine: 968, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1848)
!1845 = !DISubroutineType(types: !1846)
!1846 = !{!94, !322, !130, !154, !1847, !1819, !1782, !275}
!1847 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !130, size: 64)
!1848 = !{!1849, !1850, !1851, !1852, !1853, !1854, !1855, !1856, !1857}
!1849 = !DILocalVariable(name: "item", arg: 1, scope: !1844, file: !3, line: 968, type: !322)
!1850 = !DILocalVariable(name: "comm", arg: 2, scope: !1844, file: !3, line: 968, type: !130)
!1851 = !DILocalVariable(name: "t", arg: 3, scope: !1844, file: !3, line: 968, type: !154)
!1852 = !DILocalVariable(name: "nbytes", arg: 4, scope: !1844, file: !3, line: 968, type: !1847)
!1853 = !DILocalVariable(name: "cas", arg: 5, scope: !1844, file: !3, line: 968, type: !1819)
!1854 = !DILocalVariable(name: "cas_in", arg: 6, scope: !1844, file: !3, line: 968, type: !1782)
!1855 = !DILocalVariable(name: "cas_stale", arg: 7, scope: !1844, file: !3, line: 968, type: !275)
!1856 = !DILocalVariable(name: "ret", scope: !1844, file: !3, line: 969, type: !94)
!1857 = !DILocalVariable(name: "hv", scope: !1844, file: !3, line: 970, type: !377)
!1858 = !DILocation(line: 0, scope: !1844)
!1859 = !DILocation(line: 972, column: 10, scope: !1844)
!1860 = !DILocation(line: 972, column: 15, scope: !1844)
!1861 = !DILocation(line: 972, column: 37, scope: !1844)
!1862 = !DILocation(line: 972, column: 31, scope: !1844)
!1863 = !DILocation(line: 0, scope: !919, inlinedAt: !1864)
!1864 = distinct !DILocation(line: 973, column: 5, scope: !1844)
!1865 = !DILocation(line: 122, column: 5, scope: !919, inlinedAt: !1864)
!1866 = !DILocation(line: 974, column: 11, scope: !1844)
!1867 = !DILocation(line: 0, scope: !962, inlinedAt: !1868)
!1868 = distinct !DILocation(line: 975, column: 5, scope: !1844)
!1869 = !DILocation(line: 138, column: 5, scope: !962, inlinedAt: !1868)
!1870 = !DILocation(line: 976, column: 5, scope: !1844)
!1871 = !DISubprogram(name: "do_store_item", scope: !6, file: !6, line: 957, type: !1872, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1872 = !DISubroutineType(types: !1873)
!1873 = !{!94, !322, !130, !154, !1713, !1847, !1819, !1782, !275}
!1874 = !DILocation(line: 982, column: 5, scope: !1144)
!1875 = !DILocation(line: 983, column: 1, scope: !1144)
!1876 = !DILocation(line: 986, column: 5, scope: !1151)
!1877 = !DILocation(line: 987, column: 1, scope: !1151)
!1878 = distinct !DISubprogram(name: "threadlocal_stats_reset", scope: !3, file: !3, line: 989, type: !1031, scopeLine: 989, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1879)
!1879 = !{!1880}
!1880 = !DILocalVariable(name: "ii", scope: !1878, file: !3, line: 990, type: !130)
!1881 = !DILocation(line: 0, scope: !1878)
!1882 = !DILocation(line: 991, column: 32, scope: !1883)
!1883 = distinct !DILexicalBlock(scope: !1884, file: !3, line: 991, column: 5)
!1884 = distinct !DILexicalBlock(scope: !1878, file: !3, line: 991, column: 5)
!1885 = !DILocation(line: 991, column: 21, scope: !1883)
!1886 = !DILocation(line: 991, column: 5, scope: !1884)
!1887 = !DILocation(line: 992, column: 29, scope: !1888)
!1888 = distinct !DILexicalBlock(scope: !1883, file: !3, line: 991, column: 51)
!1889 = !DILocation(line: 992, column: 41, scope: !1888)
!1890 = !DILocation(line: 992, column: 9, scope: !1888)
!1891 = !DILocation(line: 994, column: 9, scope: !1888)
!1892 = !DILocation(line: 1008, column: 43, scope: !1888)
!1893 = !DILocation(line: 1008, column: 9, scope: !1888)
!1894 = !DILocation(line: 991, column: 45, scope: !1883)
!1895 = distinct !{!1895, !1886, !1896, !1012}
!1896 = !DILocation(line: 1009, column: 5, scope: !1884)
!1897 = !DILocation(line: 1010, column: 1, scope: !1878)
!1898 = distinct !DISubprogram(name: "threadlocal_stats_aggregate", scope: !3, file: !3, line: 1012, type: !1899, scopeLine: 1012, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1902)
!1899 = !DISubroutineType(types: !1900)
!1900 = !{null, !1901}
!1901 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !510, size: 64)
!1902 = !{!1903, !1904, !1905}
!1903 = !DILocalVariable(name: "stats", arg: 1, scope: !1898, file: !3, line: 1012, type: !1901)
!1904 = !DILocalVariable(name: "ii", scope: !1898, file: !3, line: 1013, type: !130)
!1905 = !DILocalVariable(name: "sid", scope: !1898, file: !3, line: 1013, type: !130)
!1906 = !DILocation(line: 0, scope: !1898)
!1907 = !DILocation(line: 1017, column: 5, scope: !1898)
!1908 = !DILocation(line: 1019, column: 32, scope: !1909)
!1909 = distinct !DILexicalBlock(scope: !1910, file: !3, line: 1019, column: 5)
!1910 = distinct !DILexicalBlock(scope: !1898, file: !3, line: 1019, column: 5)
!1911 = !DILocation(line: 1019, column: 21, scope: !1909)
!1912 = !DILocation(line: 1019, column: 5, scope: !1910)
!1913 = !DILocation(line: 1020, column: 29, scope: !1914)
!1914 = distinct !DILexicalBlock(scope: !1909, file: !3, line: 1019, column: 51)
!1915 = !DILocation(line: 1020, column: 41, scope: !1914)
!1916 = !DILocation(line: 1020, column: 9, scope: !1914)
!1917 = !DILocation(line: 1022, column: 9, scope: !1914)
!1918 = !DILocation(line: 1024, column: 9, scope: !1914)
!1919 = !DILocation(line: 1031, column: 9, scope: !1920)
!1920 = distinct !DILexicalBlock(scope: !1914, file: !3, line: 1031, column: 9)
!1921 = !DILocation(line: 1034, column: 13, scope: !1922)
!1922 = distinct !DILexicalBlock(scope: !1923, file: !3, line: 1031, column: 64)
!1923 = distinct !DILexicalBlock(scope: !1920, file: !3, line: 1031, column: 9)
!1924 = !DILocation(line: 1031, column: 60, scope: !1923)
!1925 = !DILocation(line: 1031, column: 27, scope: !1923)
!1926 = distinct !{!1926, !1919, !1927, !1012}
!1927 = !DILocation(line: 1036, column: 9, scope: !1920)
!1928 = !DILocation(line: 1040, column: 17, scope: !1929)
!1929 = distinct !DILexicalBlock(scope: !1930, file: !3, line: 1038, column: 51)
!1930 = distinct !DILexicalBlock(scope: !1931, file: !3, line: 1038, column: 9)
!1931 = distinct !DILexicalBlock(scope: !1914, file: !3, line: 1038, column: 9)
!1932 = !DILocation(line: 1039, column: 13, scope: !1929)
!1933 = !DILocation(line: 1039, column: 34, scope: !1929)
!1934 = !DILocation(line: 1042, column: 17, scope: !1929)
!1935 = !DILocation(line: 1041, column: 31, scope: !1929)
!1936 = !DILocation(line: 1041, column: 47, scope: !1929)
!1937 = !DILocation(line: 1041, column: 56, scope: !1929)
!1938 = !{!1939, !991, i64 8}
!1939 = !{!"slab_stats", !991, i64 0, !991, i64 8, !991, i64 16, !991, i64 24, !991, i64 32, !991, i64 40, !991, i64 48, !991, i64 56}
!1940 = !DILocation(line: 1038, column: 47, scope: !1930)
!1941 = !DILocation(line: 1038, column: 27, scope: !1930)
!1942 = !DILocation(line: 1038, column: 9, scope: !1931)
!1943 = distinct !{!1943, !1942, !1944, !1012}
!1944 = !DILocation(line: 1043, column: 9, scope: !1931)
!1945 = !DILocation(line: 1045, column: 46, scope: !1914)
!1946 = !{!1117, !927, i64 6880}
!1947 = !DILocation(line: 1045, column: 58, scope: !1914)
!1948 = !DILocation(line: 1045, column: 31, scope: !1914)
!1949 = !{!1125, !991, i64 6424}
!1950 = !DILocation(line: 1045, column: 34, scope: !1914)
!1951 = !DILocation(line: 1046, column: 64, scope: !1914)
!1952 = !DILocation(line: 1046, column: 34, scope: !1914)
!1953 = !DILocation(line: 1046, column: 31, scope: !1914)
!1954 = !DILocation(line: 1048, column: 43, scope: !1914)
!1955 = !DILocation(line: 1048, column: 9, scope: !1914)
!1956 = !DILocation(line: 1019, column: 45, scope: !1909)
!1957 = distinct !{!1957, !1912, !1958, !1012}
!1958 = !DILocation(line: 1049, column: 5, scope: !1910)
!1959 = !DILocation(line: 1050, column: 1, scope: !1898)
!1960 = distinct !DISubprogram(name: "slab_stats_aggregate", scope: !3, file: !3, line: 1052, type: !1961, scopeLine: 1052, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1964)
!1961 = !DISubroutineType(types: !1962)
!1962 = !{null, !1901, !1963}
!1963 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !545, size: 64)
!1964 = !{!1965, !1966, !1967}
!1965 = !DILocalVariable(name: "stats", arg: 1, scope: !1960, file: !3, line: 1052, type: !1901)
!1966 = !DILocalVariable(name: "out", arg: 2, scope: !1960, file: !3, line: 1052, type: !1963)
!1967 = !DILocalVariable(name: "sid", scope: !1960, file: !3, line: 1053, type: !130)
!1968 = !DILocation(line: 0, scope: !1960)
!1969 = !DILocation(line: 1055, column: 5, scope: !1960)
!1970 = !DILocation(line: 1057, column: 5, scope: !1971)
!1971 = distinct !DILexicalBlock(scope: !1960, file: !3, line: 1057, column: 5)
!1972 = !DILocation(line: 1059, column: 9, scope: !1973)
!1973 = distinct !DILexicalBlock(scope: !1974, file: !3, line: 1057, column: 60)
!1974 = distinct !DILexicalBlock(scope: !1971, file: !3, line: 1057, column: 5)
!1975 = !DILocation(line: 1057, column: 56, scope: !1974)
!1976 = !DILocation(line: 1057, column: 23, scope: !1974)
!1977 = distinct !{!1977, !1970, !1978, !1012}
!1978 = !DILocation(line: 1061, column: 5, scope: !1971)
!1979 = !DILocation(line: 1062, column: 1, scope: !1960)
!1980 = distinct !DISubprogram(name: "memcached_thread_init", scope: !3, file: !3, line: 1088, type: !1981, scopeLine: 1088, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1983)
!1981 = !DISubroutineType(types: !1982)
!1982 = !{null, !130, !119}
!1983 = !{!1984, !1985, !1986, !1987}
!1984 = !DILocalVariable(name: "nthreads", arg: 1, scope: !1980, file: !3, line: 1088, type: !130)
!1985 = !DILocalVariable(name: "arg", arg: 2, scope: !1980, file: !3, line: 1088, type: !119)
!1986 = !DILocalVariable(name: "i", scope: !1980, file: !3, line: 1089, type: !130)
!1987 = !DILocalVariable(name: "power", scope: !1980, file: !3, line: 1090, type: !130)
!1988 = distinct !DIAssignID()
!1989 = !DILocation(line: 0, scope: !1980)
!1990 = !DILocation(line: 1092, column: 5, scope: !1991)
!1991 = distinct !DILexicalBlock(scope: !1980, file: !3, line: 1092, column: 5)
!1992 = !DILocation(line: 1093, column: 29, scope: !1993)
!1993 = distinct !DILexicalBlock(scope: !1994, file: !3, line: 1092, column: 41)
!1994 = distinct !DILexicalBlock(scope: !1991, file: !3, line: 1092, column: 5)
!1995 = !DILocation(line: 1093, column: 9, scope: !1993)
!1996 = !DILocation(line: 1092, column: 37, scope: !1994)
!1997 = !DILocation(line: 1092, column: 19, scope: !1994)
!1998 = distinct !{!1998, !1990, !1999, !1012}
!1999 = !DILocation(line: 1094, column: 5, scope: !1991)
!2000 = !DILocation(line: 1095, column: 5, scope: !1980)
!2001 = !DILocation(line: 1097, column: 5, scope: !1980)
!2002 = !DILocation(line: 1098, column: 5, scope: !1980)
!2003 = !DILocation(line: 1101, column: 18, scope: !2004)
!2004 = distinct !DILexicalBlock(scope: !1980, file: !3, line: 1101, column: 9)
!2005 = !DILocation(line: 1101, column: 9, scope: !1980)
!2006 = !DILocation(line: 1103, column: 25, scope: !2007)
!2007 = distinct !DILexicalBlock(scope: !2004, file: !3, line: 1103, column: 16)
!2008 = !DILocation(line: 1103, column: 16, scope: !2004)
!2009 = !DILocation(line: 1105, column: 25, scope: !2010)
!2010 = distinct !DILexicalBlock(scope: !2007, file: !3, line: 1105, column: 16)
!2011 = !DILocation(line: 1105, column: 16, scope: !2007)
!2012 = !DILocation(line: 1107, column: 25, scope: !2013)
!2013 = distinct !DILexicalBlock(scope: !2010, file: !3, line: 1107, column: 16)
!2014 = !DILocation(line: 1107, column: 16, scope: !2010)
!2015 = !DILocation(line: 1109, column: 25, scope: !2016)
!2016 = distinct !DILexicalBlock(scope: !2013, file: !3, line: 1109, column: 16)
!2017 = !DILocation(line: 0, scope: !2004)
!2018 = !DILocation(line: 1116, column: 18, scope: !2019)
!2019 = distinct !DILexicalBlock(scope: !1980, file: !3, line: 1116, column: 9)
!2020 = !DILocation(line: 1116, column: 15, scope: !2019)
!2021 = !DILocation(line: 1116, column: 9, scope: !1980)
!2022 = !DILocation(line: 1117, column: 17, scope: !2023)
!2023 = distinct !DILexicalBlock(scope: !2019, file: !3, line: 1116, column: 29)
!2024 = !DILocation(line: 1117, column: 9, scope: !2023)
!2025 = !DILocation(line: 1118, column: 17, scope: !2023)
!2026 = !DILocation(line: 1118, column: 9, scope: !2023)
!2027 = !DILocation(line: 1119, column: 17, scope: !2023)
!2028 = !DILocation(line: 1119, column: 9, scope: !2023)
!2029 = !DILocation(line: 1120, column: 9, scope: !2023)
!2030 = !DILocation(line: 1123, column: 23, scope: !1980)
!2031 = !DILocation(line: 1123, column: 21, scope: !1980)
!2032 = !DILocation(line: 1124, column: 25, scope: !1980)
!2033 = !DILocation(line: 1126, column: 25, scope: !1980)
!2034 = !DILocation(line: 1126, column: 18, scope: !1980)
!2035 = !DILocation(line: 1126, column: 16, scope: !1980)
!2036 = !DILocation(line: 1127, column: 11, scope: !2037)
!2037 = distinct !DILexicalBlock(scope: !1980, file: !3, line: 1127, column: 9)
!2038 = !DILocation(line: 1127, column: 9, scope: !1980)
!2039 = !DILocation(line: 1128, column: 9, scope: !2040)
!2040 = distinct !DILexicalBlock(scope: !2037, file: !3, line: 1127, column: 23)
!2041 = !DILocation(line: 1129, column: 9, scope: !2040)
!2042 = !DILocation(line: 1132, column: 29, scope: !2043)
!2043 = distinct !DILexicalBlock(scope: !2044, file: !3, line: 1131, column: 43)
!2044 = distinct !DILexicalBlock(scope: !2045, file: !3, line: 1131, column: 5)
!2045 = distinct !DILexicalBlock(scope: !1980, file: !3, line: 1131, column: 5)
!2046 = !DILocation(line: 1132, column: 9, scope: !2043)
!2047 = !DILocation(line: 1131, column: 39, scope: !2044)
!2048 = !DILocation(line: 1131, column: 21, scope: !2044)
!2049 = !DILocation(line: 1131, column: 19, scope: !2044)
!2050 = !DILocation(line: 1131, column: 5, scope: !2045)
!2051 = distinct !{!2051, !2050, !2052, !1012}
!2052 = !DILocation(line: 1133, column: 5, scope: !2045)
!2053 = !DILocation(line: 1135, column: 22, scope: !1980)
!2054 = !DILocation(line: 1135, column: 15, scope: !1980)
!2055 = !DILocation(line: 1135, column: 13, scope: !1980)
!2056 = !DILocation(line: 1136, column: 11, scope: !2057)
!2057 = distinct !DILexicalBlock(scope: !1980, file: !3, line: 1136, column: 9)
!2058 = !DILocation(line: 1136, column: 9, scope: !1980)
!2059 = !DILocation(line: 1141, column: 19, scope: !2060)
!2060 = distinct !DILexicalBlock(scope: !2061, file: !3, line: 1141, column: 5)
!2061 = distinct !DILexicalBlock(scope: !1980, file: !3, line: 1141, column: 5)
!2062 = !DILocation(line: 1141, column: 5, scope: !2061)
!2063 = !DILocation(line: 1137, column: 9, scope: !2064)
!2064 = distinct !DILexicalBlock(scope: !2057, file: !3, line: 1136, column: 20)
!2065 = !DILocation(line: 1138, column: 9, scope: !2064)
!2066 = !DILocation(line: 1154, column: 5, scope: !2067)
!2067 = distinct !DILexicalBlock(scope: !1980, file: !3, line: 1154, column: 5)
!2068 = !DILocation(line: 1154, column: 19, scope: !2069)
!2069 = distinct !DILexicalBlock(scope: !2067, file: !3, line: 1154, column: 5)
!2070 = !DILocation(line: 1142, column: 39, scope: !2071)
!2071 = distinct !DILexicalBlock(scope: !2060, file: !3, line: 1141, column: 36)
!2072 = !DILocalVariable(name: "tn", arg: 1, scope: !2073, file: !3, line: 1064, type: !2076)
!2073 = distinct !DISubprogram(name: "memcached_thread_notify_init", scope: !3, file: !3, line: 1064, type: !2074, scopeLine: 1064, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2077)
!2074 = !DISubroutineType(types: !2075)
!2075 = !{null, !2076}
!2076 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !165, size: 64)
!2077 = !{!2072}
!2078 = !DILocation(line: 0, scope: !2073, inlinedAt: !2079)
!2079 = distinct !DILocation(line: 1142, column: 9, scope: !2071)
!2080 = !DILocation(line: 1066, column: 31, scope: !2073, inlinedAt: !2079)
!2081 = !DILocation(line: 1066, column: 13, scope: !2073, inlinedAt: !2079)
!2082 = !DILocation(line: 1066, column: 29, scope: !2073, inlinedAt: !2079)
!2083 = !{!1118, !931, i64 128}
!2084 = !DILocation(line: 1067, column: 33, scope: !2085, inlinedAt: !2079)
!2085 = distinct !DILexicalBlock(scope: !2073, file: !3, line: 1067, column: 13)
!2086 = !DILocation(line: 1067, column: 13, scope: !2073, inlinedAt: !2079)
!2087 = !DILocation(line: 1068, column: 13, scope: !2088, inlinedAt: !2079)
!2088 = distinct !DILexicalBlock(scope: !2085, file: !3, line: 1067, column: 40)
!2089 = !DILocation(line: 1069, column: 13, scope: !2088, inlinedAt: !2079)
!2090 = !DILocation(line: 1143, column: 39, scope: !2071)
!2091 = !DILocation(line: 0, scope: !2073, inlinedAt: !2092)
!2092 = distinct !DILocation(line: 1143, column: 9, scope: !2071)
!2093 = !DILocation(line: 1066, column: 31, scope: !2073, inlinedAt: !2092)
!2094 = !DILocation(line: 1066, column: 13, scope: !2073, inlinedAt: !2092)
!2095 = !DILocation(line: 1066, column: 29, scope: !2073, inlinedAt: !2092)
!2096 = !DILocation(line: 1067, column: 33, scope: !2085, inlinedAt: !2092)
!2097 = !DILocation(line: 1067, column: 13, scope: !2073, inlinedAt: !2092)
!2098 = !DILocation(line: 1068, column: 13, scope: !2088, inlinedAt: !2092)
!2099 = !DILocation(line: 1069, column: 13, scope: !2088, inlinedAt: !2092)
!2100 = !DILocation(line: 1145, column: 9, scope: !2071)
!2101 = !DILocation(line: 1145, column: 20, scope: !2071)
!2102 = !DILocation(line: 1145, column: 28, scope: !2071)
!2103 = !{!1117, !927, i64 6904}
!2104 = !DILocation(line: 1147, column: 20, scope: !2071)
!2105 = !DILocation(line: 1147, column: 34, scope: !2071)
!2106 = !{!1117, !931, i64 348}
!2107 = !DILocation(line: 1148, column: 23, scope: !2071)
!2108 = !DILocalVariable(name: "me", arg: 1, scope: !2109, file: !3, line: 424, type: !154)
!2109 = distinct !DISubprogram(name: "setup_thread", scope: !3, file: !3, line: 424, type: !2110, scopeLine: 424, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2112)
!2110 = !DISubroutineType(types: !2111)
!2111 = !{null, !154}
!2112 = !{!2108, !2113, !2116}
!2113 = !DILocalVariable(name: "ev_config", scope: !2109, file: !3, line: 426, type: !2114)
!2114 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2115, size: 64)
!2115 = !DICompositeType(tag: DW_TAG_structure_type, name: "event_config", file: !109, line: 295, flags: DIFlagFwdDecl)
!2116 = !DILocalVariable(name: "limit", scope: !2117, file: !3, line: 466, type: !130)
!2117 = distinct !DILexicalBlock(scope: !2118, file: !3, line: 465, column: 38)
!2118 = distinct !DILexicalBlock(scope: !2109, file: !3, line: 465, column: 9)
!2119 = !DILocation(line: 0, scope: !2109, inlinedAt: !2120)
!2120 = distinct !DILocation(line: 1148, column: 9, scope: !2071)
!2121 = !DILocation(line: 427, column: 17, scope: !2109, inlinedAt: !2120)
!2122 = !DILocation(line: 428, column: 5, scope: !2109, inlinedAt: !2120)
!2123 = !DILocation(line: 429, column: 16, scope: !2109, inlinedAt: !2120)
!2124 = !DILocation(line: 429, column: 9, scope: !2109, inlinedAt: !2120)
!2125 = !DILocation(line: 429, column: 14, scope: !2109, inlinedAt: !2120)
!2126 = !{!1117, !927, i64 8}
!2127 = !DILocation(line: 430, column: 5, scope: !2109, inlinedAt: !2120)
!2128 = !DILocation(line: 435, column: 15, scope: !2129, inlinedAt: !2120)
!2129 = distinct !DILexicalBlock(scope: !2109, file: !3, line: 435, column: 9)
!2130 = !DILocation(line: 435, column: 11, scope: !2129, inlinedAt: !2120)
!2131 = !DILocation(line: 435, column: 9, scope: !2109, inlinedAt: !2120)
!2132 = !DILocation(line: 436, column: 17, scope: !2133, inlinedAt: !2120)
!2133 = distinct !DILexicalBlock(scope: !2129, file: !3, line: 435, column: 21)
!2134 = !DILocation(line: 436, column: 9, scope: !2133, inlinedAt: !2120)
!2135 = !DILocation(line: 437, column: 9, scope: !2133, inlinedAt: !2120)
!2136 = !DILocation(line: 441, column: 34, scope: !2109, inlinedAt: !2120)
!2137 = !DILocalVariable(name: "me", arg: 1, scope: !2138, file: !3, line: 404, type: !154)
!2138 = distinct !DISubprogram(name: "setup_thread_notify", scope: !3, file: !3, line: 404, type: !2139, scopeLine: 405, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2141)
!2139 = !DISubroutineType(types: !2140)
!2140 = !{null, !154, !2076, !192}
!2141 = !{!2137, !2142, !2143}
!2142 = !DILocalVariable(name: "tn", arg: 2, scope: !2138, file: !3, line: 404, type: !2076)
!2143 = !DILocalVariable(name: "cb", arg: 3, scope: !2138, file: !3, line: 405, type: !192)
!2144 = !DILocation(line: 0, scope: !2138, inlinedAt: !2145)
!2145 = distinct !DILocation(line: 441, column: 5, scope: !2109, inlinedAt: !2120)
!2146 = !DILocation(line: 407, column: 38, scope: !2138, inlinedAt: !2145)
!2147 = !DILocation(line: 407, column: 5, scope: !2138, inlinedAt: !2145)
!2148 = !DILocation(line: 413, column: 24, scope: !2138, inlinedAt: !2145)
!2149 = !DILocation(line: 413, column: 5, scope: !2138, inlinedAt: !2145)
!2150 = !DILocation(line: 415, column: 9, scope: !2151, inlinedAt: !2145)
!2151 = distinct !DILexicalBlock(scope: !2138, file: !3, line: 415, column: 9)
!2152 = !DILocation(line: 415, column: 41, scope: !2151, inlinedAt: !2145)
!2153 = !DILocation(line: 415, column: 9, scope: !2138, inlinedAt: !2145)
!2154 = !DILocation(line: 416, column: 17, scope: !2155, inlinedAt: !2145)
!2155 = distinct !DILexicalBlock(scope: !2151, file: !3, line: 415, column: 48)
!2156 = !DILocation(line: 416, column: 9, scope: !2155, inlinedAt: !2145)
!2157 = !DILocation(line: 417, column: 9, scope: !2155, inlinedAt: !2145)
!2158 = !DILocation(line: 442, column: 34, scope: !2109, inlinedAt: !2120)
!2159 = !DILocation(line: 0, scope: !2138, inlinedAt: !2160)
!2160 = distinct !DILocation(line: 442, column: 5, scope: !2109, inlinedAt: !2120)
!2161 = !DILocation(line: 407, column: 38, scope: !2138, inlinedAt: !2160)
!2162 = !DILocation(line: 407, column: 5, scope: !2138, inlinedAt: !2160)
!2163 = !DILocation(line: 413, column: 24, scope: !2138, inlinedAt: !2160)
!2164 = !DILocation(line: 413, column: 5, scope: !2138, inlinedAt: !2160)
!2165 = !DILocation(line: 415, column: 9, scope: !2151, inlinedAt: !2160)
!2166 = !DILocation(line: 415, column: 41, scope: !2151, inlinedAt: !2160)
!2167 = !DILocation(line: 415, column: 9, scope: !2138, inlinedAt: !2160)
!2168 = !DILocation(line: 416, column: 17, scope: !2155, inlinedAt: !2160)
!2169 = !DILocation(line: 416, column: 9, scope: !2155, inlinedAt: !2160)
!2170 = !DILocation(line: 417, column: 9, scope: !2155, inlinedAt: !2160)
!2171 = !DILocation(line: 443, column: 29, scope: !2109, inlinedAt: !2120)
!2172 = !DILocation(line: 443, column: 5, scope: !2109, inlinedAt: !2120)
!2173 = !DILocation(line: 444, column: 5, scope: !2174, inlinedAt: !2120)
!2174 = distinct !DILexicalBlock(scope: !2109, file: !3, line: 444, column: 5)
!2175 = !DILocation(line: 446, column: 20, scope: !2109, inlinedAt: !2120)
!2176 = !DILocation(line: 446, column: 9, scope: !2109, inlinedAt: !2120)
!2177 = !DILocation(line: 446, column: 18, scope: !2109, inlinedAt: !2120)
!2178 = !DILocation(line: 447, column: 22, scope: !2179, inlinedAt: !2120)
!2179 = distinct !DILexicalBlock(scope: !2109, file: !3, line: 447, column: 9)
!2180 = !DILocation(line: 447, column: 9, scope: !2109, inlinedAt: !2120)
!2181 = !DILocation(line: 448, column: 9, scope: !2182, inlinedAt: !2120)
!2182 = distinct !DILexicalBlock(scope: !2179, file: !3, line: 447, column: 31)
!2183 = !DILocation(line: 449, column: 9, scope: !2182, inlinedAt: !2120)
!2184 = !DILocalVariable(name: "cq", arg: 1, scope: !2185, file: !3, line: 277, type: !1130)
!2185 = distinct !DISubprogram(name: "cq_init", scope: !3, file: !3, line: 277, type: !2186, scopeLine: 277, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2188)
!2186 = !DISubroutineType(types: !2187)
!2187 = !{null, !1130}
!2188 = !{!2184}
!2189 = !DILocation(line: 0, scope: !2185, inlinedAt: !2190)
!2190 = distinct !DILocation(line: 451, column: 5, scope: !2109, inlinedAt: !2120)
!2191 = !DILocation(line: 278, column: 29, scope: !2185, inlinedAt: !2190)
!2192 = !DILocation(line: 278, column: 5, scope: !2185, inlinedAt: !2190)
!2193 = !DILocation(line: 279, column: 5, scope: !2194, inlinedAt: !2190)
!2194 = distinct !DILexicalBlock(scope: !2185, file: !3, line: 279, column: 5)
!2195 = !{!1137, !927, i64 0}
!2196 = !DILocation(line: 280, column: 17, scope: !2185, inlinedAt: !2190)
!2197 = !DILocation(line: 280, column: 9, scope: !2185, inlinedAt: !2190)
!2198 = !DILocation(line: 280, column: 15, scope: !2185, inlinedAt: !2190)
!2199 = !DILocation(line: 281, column: 19, scope: !2200, inlinedAt: !2190)
!2200 = distinct !DILexicalBlock(scope: !2185, file: !3, line: 281, column: 9)
!2201 = !DILocation(line: 281, column: 9, scope: !2185, inlinedAt: !2190)
!2202 = !DILocation(line: 282, column: 17, scope: !2203, inlinedAt: !2190)
!2203 = distinct !DILexicalBlock(scope: !2200, file: !3, line: 281, column: 28)
!2204 = !DILocation(line: 282, column: 9, scope: !2203, inlinedAt: !2190)
!2205 = !DILocation(line: 283, column: 9, scope: !2203, inlinedAt: !2190)
!2206 = !DILocation(line: 453, column: 33, scope: !2207, inlinedAt: !2120)
!2207 = distinct !DILexicalBlock(scope: !2109, file: !3, line: 453, column: 9)
!2208 = !DILocation(line: 453, column: 9, scope: !2207, inlinedAt: !2120)
!2209 = !DILocation(line: 453, column: 52, scope: !2207, inlinedAt: !2120)
!2210 = !DILocation(line: 453, column: 9, scope: !2109, inlinedAt: !2120)
!2211 = !DILocation(line: 454, column: 9, scope: !2212, inlinedAt: !2120)
!2212 = distinct !DILexicalBlock(scope: !2207, file: !3, line: 453, column: 58)
!2213 = !DILocation(line: 455, column: 9, scope: !2212, inlinedAt: !2120)
!2214 = !DILocation(line: 458, column: 22, scope: !2109, inlinedAt: !2120)
!2215 = !DILocation(line: 458, column: 9, scope: !2109, inlinedAt: !2120)
!2216 = !DILocation(line: 458, column: 20, scope: !2109, inlinedAt: !2120)
!2217 = !DILocation(line: 459, column: 24, scope: !2218, inlinedAt: !2120)
!2218 = distinct !DILexicalBlock(scope: !2109, file: !3, line: 459, column: 9)
!2219 = !DILocation(line: 459, column: 9, scope: !2109, inlinedAt: !2120)
!2220 = !DILocation(line: 460, column: 17, scope: !2221, inlinedAt: !2120)
!2221 = distinct !DILexicalBlock(scope: !2218, file: !3, line: 459, column: 33)
!2222 = !DILocation(line: 460, column: 9, scope: !2221, inlinedAt: !2120)
!2223 = !DILocation(line: 461, column: 9, scope: !2221, inlinedAt: !2120)
!2224 = !DILocation(line: 465, column: 18, scope: !2118, inlinedAt: !2120)
!2225 = !{!990, !931, i64 240}
!2226 = !DILocation(line: 465, column: 9, scope: !2118, inlinedAt: !2120)
!2227 = !DILocation(line: 465, column: 9, scope: !2109, inlinedAt: !2120)
!2228 = !DILocation(line: 466, column: 60, scope: !2117, inlinedAt: !2120)
!2229 = !DILocation(line: 466, column: 49, scope: !2117, inlinedAt: !2120)
!2230 = !DILocation(line: 0, scope: !2117, inlinedAt: !2120)
!2231 = !DILocation(line: 467, column: 19, scope: !2232, inlinedAt: !2120)
!2232 = distinct !DILexicalBlock(scope: !2117, file: !3, line: 467, column: 13)
!2233 = !DILocation(line: 467, column: 13, scope: !2117, inlinedAt: !2120)
!2234 = !DILocation(line: 472, column: 9, scope: !2117, inlinedAt: !2120)
!2235 = !DILocation(line: 473, column: 5, scope: !2117, inlinedAt: !2120)
!2236 = !DILocation(line: 475, column: 20, scope: !2109, inlinedAt: !2120)
!2237 = !DILocation(line: 475, column: 9, scope: !2109, inlinedAt: !2120)
!2238 = !DILocation(line: 475, column: 18, scope: !2109, inlinedAt: !2120)
!2239 = !{!1117, !927, i64 6896}
!2240 = !DILocation(line: 476, column: 22, scope: !2241, inlinedAt: !2120)
!2241 = distinct !DILexicalBlock(scope: !2109, file: !3, line: 476, column: 9)
!2242 = !DILocation(line: 476, column: 9, scope: !2109, inlinedAt: !2120)
!2243 = !DILocation(line: 477, column: 17, scope: !2244, inlinedAt: !2120)
!2244 = distinct !DILexicalBlock(scope: !2241, file: !3, line: 476, column: 31)
!2245 = !DILocation(line: 477, column: 9, scope: !2244, inlinedAt: !2120)
!2246 = !DILocation(line: 478, column: 9, scope: !2244, inlinedAt: !2120)
!2247 = !DILocation(line: 491, column: 13, scope: !2248, inlinedAt: !2120)
!2248 = distinct !DILexicalBlock(scope: !2109, file: !3, line: 491, column: 9)
!2249 = !DILocation(line: 491, column: 9, scope: !2248, inlinedAt: !2120)
!2250 = !DILocation(line: 491, column: 9, scope: !2109, inlinedAt: !2120)
!2251 = !DILocation(line: 492, column: 9, scope: !2252, inlinedAt: !2120)
!2252 = distinct !DILexicalBlock(scope: !2248, file: !3, line: 491, column: 22)
!2253 = !DILocation(line: 494, column: 5, scope: !2252, inlinedAt: !2120)
!2254 = !DILocation(line: 505, column: 5, scope: !2109, inlinedAt: !2120)
!2255 = !DILocation(line: 1150, column: 34, scope: !2071)
!2256 = !{!2257, !931, i64 36}
!2257 = !{!"stats_state", !991, i64 0, !991, i64 8, !991, i64 16, !991, i64 24, !931, i64 32, !931, i64 36, !931, i64 40, !931, i64 44, !993, i64 48, !993, i64 49, !993, i64 50, !993, i64 51}
!2258 = !DILocation(line: 1141, column: 32, scope: !2060)
!2259 = distinct !{!2259, !2062, !2260, !1012}
!2260 = !DILocation(line: 1151, column: 5, scope: !2061)
!2261 = !DILocation(line: 1155, column: 41, scope: !2262)
!2262 = distinct !DILexicalBlock(scope: !2069, file: !3, line: 1154, column: 36)
!2263 = !DILocalVariable(name: "attr", scope: !2264, file: !3, line: 380, type: !2274)
!2264 = distinct !DISubprogram(name: "create_worker", scope: !3, file: !3, line: 379, type: !2265, scopeLine: 379, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2270)
!2265 = !DISubroutineType(types: !2266)
!2266 = !{null, !2267, !119}
!2267 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2268, size: 64)
!2268 = !DISubroutineType(types: !2269)
!2269 = !{!119, !119}
!2270 = !{!2271, !2272, !2263, !2273}
!2271 = !DILocalVariable(name: "func", arg: 1, scope: !2264, file: !3, line: 379, type: !2267)
!2272 = !DILocalVariable(name: "arg", arg: 2, scope: !2264, file: !3, line: 379, type: !119)
!2273 = !DILocalVariable(name: "ret", scope: !2264, file: !3, line: 381, type: !130)
!2274 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_attr_t", file: !122, line: 62, baseType: !2275)
!2275 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "pthread_attr_t", file: !122, line: 56, size: 448, elements: !2276)
!2276 = !{!2277, !2278}
!2277 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !2275, file: !122, line: 58, baseType: !778, size: 448)
!2278 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !2275, file: !122, line: 59, baseType: !152, size: 64)
!2279 = !DILocation(line: 0, scope: !2264, inlinedAt: !2280)
!2280 = distinct !DILocation(line: 1155, column: 9, scope: !2262)
!2281 = !DILocation(line: 380, column: 5, scope: !2264, inlinedAt: !2280)
!2282 = !DILocation(line: 383, column: 5, scope: !2264, inlinedAt: !2280)
!2283 = !DILocation(line: 385, column: 16, scope: !2284, inlinedAt: !2280)
!2284 = distinct !DILexicalBlock(scope: !2264, file: !3, line: 385, column: 9)
!2285 = !DILocation(line: 385, column: 87, scope: !2284, inlinedAt: !2280)
!2286 = !DILocation(line: 385, column: 9, scope: !2264, inlinedAt: !2280)
!2287 = !DILocation(line: 386, column: 17, scope: !2288, inlinedAt: !2280)
!2288 = distinct !DILexicalBlock(scope: !2284, file: !3, line: 385, column: 93)
!2289 = !DILocation(line: 387, column: 17, scope: !2288, inlinedAt: !2280)
!2290 = !DILocation(line: 386, column: 9, scope: !2288, inlinedAt: !2280)
!2291 = !DILocation(line: 388, column: 9, scope: !2288, inlinedAt: !2280)
!2292 = !DILocation(line: 391, column: 45, scope: !2264, inlinedAt: !2280)
!2293 = !DILocation(line: 0, scope: !1360, inlinedAt: !2294)
!2294 = distinct !DILocation(line: 391, column: 5, scope: !2264, inlinedAt: !2280)
!2295 = !DILocation(line: 688, column: 1, scope: !1360, inlinedAt: !2294)
!2296 = !DILocation(line: 392, column: 1, scope: !2264, inlinedAt: !2280)
!2297 = !DILocation(line: 1154, column: 32, scope: !2069)
!2298 = distinct !{!2298, !2066, !2299, !1012}
!2299 = !DILocation(line: 1156, column: 5, scope: !2067)
!2300 = !DILocation(line: 1159, column: 5, scope: !1980)
!2301 = !DILocation(line: 0, scope: !1014, inlinedAt: !2302)
!2302 = distinct !DILocation(line: 1160, column: 5, scope: !1980)
!2303 = !DILocation(line: 142, column: 12, scope: !1014, inlinedAt: !2302)
!2304 = !DILocation(line: 142, column: 23, scope: !1014, inlinedAt: !2302)
!2305 = !DILocation(line: 142, column: 5, scope: !1014, inlinedAt: !2302)
!2306 = !DILocation(line: 143, column: 9, scope: !1024, inlinedAt: !2302)
!2307 = distinct !{!2307, !2305, !2308, !1012}
!2308 = !DILocation(line: 144, column: 5, scope: !1014, inlinedAt: !2302)
!2309 = !DILocation(line: 1161, column: 5, scope: !1980)
!2310 = !DILocation(line: 1162, column: 1, scope: !1980)
!2311 = !DISubprogram(name: "pthread_mutex_init", scope: !934, file: !934, line: 781, type: !2312, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2312 = !DISubroutineType(types: !2313)
!2313 = !{!130, !120, !2314}
!2314 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2315, size: 64)
!2315 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !2316)
!2316 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutexattr_t", file: !122, line: 36, baseType: !2317)
!2317 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !122, line: 32, size: 32, elements: !2318)
!2318 = !{!2319, !2321}
!2319 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !2317, file: !122, line: 34, baseType: !2320, size: 32)
!2320 = !DICompositeType(tag: DW_TAG_array_type, baseType: !148, size: 32, elements: !357)
!2321 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !2317, file: !122, line: 35, baseType: !130, size: 32)
!2322 = !DISubprogram(name: "pthread_cond_init", scope: !934, file: !934, line: 1112, type: !2323, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2323 = !DISubroutineType(types: !2324)
!2324 = !{!130, !2325, !2327}
!2325 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !2326)
!2326 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !813, size: 64)
!2327 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !2328)
!2328 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2329, size: 64)
!2329 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !2330)
!2330 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_condattr_t", file: !122, line: 45, baseType: !2331)
!2331 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !122, line: 41, size: 32, elements: !2332)
!2332 = !{!2333, !2334}
!2333 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !2331, file: !122, line: 43, baseType: !2320, size: 32)
!2334 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !2331, file: !122, line: 44, baseType: !130, size: 32)
!2335 = !DISubprogram(name: "exit", scope: !2336, file: !2336, line: 756, type: !1015, flags: DIFlagPrototyped | DIFlagNoReturn, spFlags: DISPFlagOptimized)
!2336 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!2337 = !DISubprogram(name: "calloc", scope: !2336, file: !2336, line: 675, type: !2338, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2338 = !DISubroutineType(types: !2339)
!2339 = !{!119, !355, !355}
!2340 = distinct !DISubprogram(name: "worker_libevent", scope: !3, file: !3, line: 511, type: !2268, scopeLine: 511, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2341)
!2341 = !{!2342, !2343}
!2342 = !DILocalVariable(name: "arg", arg: 1, scope: !2340, file: !3, line: 511, type: !119)
!2343 = !DILocalVariable(name: "me", scope: !2340, file: !3, line: 512, type: !154)
!2344 = !DILocation(line: 0, scope: !2340)
!2345 = !DILocation(line: 517, column: 13, scope: !2340)
!2346 = !DILocation(line: 517, column: 9, scope: !2340)
!2347 = !DILocation(line: 517, column: 11, scope: !2340)
!2348 = !{!1117, !927, i64 6912}
!2349 = !DILocation(line: 518, column: 24, scope: !2340)
!2350 = !DILocation(line: 518, column: 9, scope: !2340)
!2351 = !DILocation(line: 518, column: 22, scope: !2340)
!2352 = !{!1117, !927, i64 6920}
!2353 = !DILocation(line: 519, column: 13, scope: !2354)
!2354 = distinct !DILexicalBlock(scope: !2340, file: !3, line: 519, column: 9)
!2355 = !DILocation(line: 519, column: 15, scope: !2354)
!2356 = !DILocation(line: 519, column: 23, scope: !2354)
!2357 = !DILocation(line: 520, column: 9, scope: !2358)
!2358 = distinct !DILexicalBlock(scope: !2354, file: !3, line: 519, column: 52)
!2359 = !DILocation(line: 148, column: 5, scope: !2360, inlinedAt: !2361)
!2360 = distinct !DISubprogram(name: "register_thread_initialized", scope: !3, file: !3, line: 147, type: !1031, scopeLine: 147, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!2361 = distinct !DILocation(line: 527, column: 5, scope: !2340)
!2362 = !DILocation(line: 149, column: 15, scope: !2360, inlinedAt: !2361)
!2363 = !DILocation(line: 150, column: 5, scope: !2360, inlinedAt: !2361)
!2364 = !DILocation(line: 151, column: 5, scope: !2360, inlinedAt: !2361)
!2365 = !DILocation(line: 153, column: 5, scope: !2360, inlinedAt: !2361)
!2366 = !DILocation(line: 154, column: 5, scope: !2360, inlinedAt: !2361)
!2367 = !DILocation(line: 536, column: 25, scope: !2340)
!2368 = !DILocation(line: 536, column: 5, scope: !2340)
!2369 = !DILocation(line: 148, column: 5, scope: !2360, inlinedAt: !2370)
!2370 = distinct !DILocation(line: 539, column: 5, scope: !2340)
!2371 = !DILocation(line: 149, column: 15, scope: !2360, inlinedAt: !2370)
!2372 = !DILocation(line: 150, column: 5, scope: !2360, inlinedAt: !2370)
!2373 = !DILocation(line: 151, column: 5, scope: !2360, inlinedAt: !2370)
!2374 = !DILocation(line: 153, column: 5, scope: !2360, inlinedAt: !2370)
!2375 = !DILocation(line: 154, column: 5, scope: !2360, inlinedAt: !2370)
!2376 = !DILocation(line: 541, column: 25, scope: !2340)
!2377 = !DILocation(line: 541, column: 5, scope: !2340)
!2378 = !DILocation(line: 542, column: 5, scope: !2340)
!2379 = !DISubprogram(name: "pthread_cond_wait", scope: !934, file: !934, line: 1133, type: !2380, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2380 = !DISubroutineType(types: !2381)
!2381 = !{!130, !2325, !2382}
!2382 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !120)
!2383 = !DISubprogram(name: "getsockopt", scope: !2384, file: !2384, line: 255, type: !2385, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2384 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/socket.h", directory: "", checksumkind: CSK_MD5, checksum: "3beca7d0ab78f16d2e6c5759220f5d99")
!2385 = !DISubroutineType(types: !2386)
!2386 = !{!130, !130, !130, !130, !2387, !2388}
!2387 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !119)
!2388 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !2389)
!2389 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !397, size: 64)
!2390 = !DISubprogram(name: "cache_alloc", scope: !609, file: !609, line: 78, type: !2391, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2391 = !DISubroutineType(types: !2392)
!2392 = !{!119, !607}
!2393 = !DISubprogram(name: "eventfd", scope: !2394, file: !2394, line: 34, type: !2395, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2394 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/eventfd.h", directory: "", checksumkind: CSK_MD5, checksum: "116272a566610165a6c9c0283cad21da")
!2395 = !DISubroutineType(types: !2396)
!2396 = !{!130, !7, !130}
!2397 = !DISubprogram(name: "event_config_new", scope: !109, file: !109, line: 467, type: !2398, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2398 = !DISubroutineType(types: !2399)
!2399 = !{!2114}
!2400 = !DISubprogram(name: "event_config_set_flag", scope: !109, file: !109, line: 618, type: !2401, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2401 = !DISubroutineType(types: !2402)
!2402 = !{!130, !2114, !130}
!2403 = !DISubprogram(name: "event_base_new_with_config", scope: !109, file: !109, line: 678, type: !2404, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2404 = !DISubroutineType(types: !2405)
!2405 = !{!161, !2406}
!2406 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2407, size: 64)
!2407 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !2115)
!2408 = !DISubprogram(name: "event_config_free", scope: !109, file: !109, line: 475, type: !2409, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2409 = !DISubroutineType(types: !2410)
!2410 = !{null, !2114}
!2411 = distinct !DISubprogram(name: "thread_libevent_process", scope: !3, file: !3, line: 591, type: !193, scopeLine: 591, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2412)
!2412 = !{!2413, !2414, !2415, !2416, !2417, !2418, !2419, !2420}
!2413 = !DILocalVariable(name: "fd", arg: 1, scope: !2411, file: !3, line: 591, type: !130)
!2414 = !DILocalVariable(name: "which", arg: 2, scope: !2411, file: !3, line: 591, type: !136)
!2415 = !DILocalVariable(name: "arg", arg: 3, scope: !2411, file: !3, line: 591, type: !119)
!2416 = !DILocalVariable(name: "me", scope: !2411, file: !3, line: 592, type: !154)
!2417 = !DILocalVariable(name: "item", scope: !2411, file: !3, line: 593, type: !1111)
!2418 = !DILocalVariable(name: "c", scope: !2411, file: !3, line: 594, type: !265)
!2419 = !DILocalVariable(name: "ev_count", scope: !2411, file: !3, line: 595, type: !345)
!2420 = !DILocalVariable(name: "x", scope: !2421, file: !3, line: 616, type: !130)
!2421 = distinct !DILexicalBlock(scope: !2411, file: !3, line: 616, column: 5)
!2422 = distinct !DIAssignID()
!2423 = !DILocation(line: 0, scope: !2411)
!2424 = !DILocation(line: 595, column: 5, scope: !2411)
!2425 = !DILocation(line: 595, column: 14, scope: !2411)
!2426 = distinct !DIAssignID()
!2427 = !DILocation(line: 600, column: 9, scope: !2428)
!2428 = distinct !DILexicalBlock(scope: !2411, file: !3, line: 600, column: 9)
!2429 = !DILocation(line: 600, column: 47, scope: !2428)
!2430 = !DILocation(line: 600, column: 9, scope: !2411)
!2431 = !DILocation(line: 0, scope: !2421)
!2432 = !DILocation(line: 616, column: 23, scope: !2433)
!2433 = distinct !DILexicalBlock(scope: !2421, file: !3, line: 616, column: 5)
!2434 = !DILocation(line: 616, column: 5, scope: !2421)
!2435 = !DILocation(line: 601, column: 22, scope: !2436)
!2436 = distinct !DILexicalBlock(scope: !2437, file: !3, line: 601, column: 13)
!2437 = distinct !DILexicalBlock(scope: !2428, file: !3, line: 600, column: 68)
!2438 = !DILocation(line: 601, column: 30, scope: !2436)
!2439 = !DILocation(line: 601, column: 13, scope: !2437)
!2440 = !DILocation(line: 602, column: 21, scope: !2436)
!2441 = !DILocation(line: 602, column: 13, scope: !2436)
!2442 = !DILocation(line: 617, column: 27, scope: !2443)
!2443 = distinct !DILexicalBlock(scope: !2433, file: !3, line: 616, column: 40)
!2444 = !DILocalVariable(name: "cq", arg: 1, scope: !2445, file: !3, line: 292, type: !1130)
!2445 = distinct !DISubprogram(name: "cq_pop", scope: !3, file: !3, line: 292, type: !1128, scopeLine: 292, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2446)
!2446 = !{!2444, !2447}
!2447 = !DILocalVariable(name: "item", scope: !2445, file: !3, line: 293, type: !1111)
!2448 = !DILocation(line: 0, scope: !2445, inlinedAt: !2449)
!2449 = distinct !DILocation(line: 617, column: 16, scope: !2443)
!2450 = !DILocation(line: 295, column: 29, scope: !2445, inlinedAt: !2449)
!2451 = !DILocation(line: 295, column: 5, scope: !2445, inlinedAt: !2449)
!2452 = !DILocation(line: 296, column: 12, scope: !2445, inlinedAt: !2449)
!2453 = !DILocation(line: 297, column: 14, scope: !2454, inlinedAt: !2449)
!2454 = distinct !DILexicalBlock(scope: !2445, file: !3, line: 297, column: 9)
!2455 = !DILocation(line: 297, column: 9, scope: !2445, inlinedAt: !2449)
!2456 = !DILocation(line: 298, column: 9, scope: !2457, inlinedAt: !2449)
!2457 = distinct !DILexicalBlock(scope: !2458, file: !3, line: 298, column: 9)
!2458 = distinct !DILexicalBlock(scope: !2459, file: !3, line: 298, column: 9)
!2459 = distinct !DILexicalBlock(scope: !2454, file: !3, line: 297, column: 23)
!2460 = !DILocation(line: 298, column: 9, scope: !2458, inlinedAt: !2449)
!2461 = !DILocation(line: 300, column: 5, scope: !2445, inlinedAt: !2449)
!2462 = !DILocation(line: 618, column: 13, scope: !2443)
!2463 = !DILocation(line: 622, column: 23, scope: !2443)
!2464 = !DILocation(line: 622, column: 9, scope: !2443)
!2465 = !DILocation(line: 624, column: 36, scope: !2466)
!2466 = distinct !DILexicalBlock(scope: !2443, file: !3, line: 622, column: 29)
!2467 = !DILocation(line: 624, column: 47, scope: !2466)
!2468 = !DILocation(line: 624, column: 65, scope: !2466)
!2469 = !DILocation(line: 625, column: 42, scope: !2466)
!2470 = !DILocation(line: 625, column: 66, scope: !2466)
!2471 = !DILocation(line: 626, column: 40, scope: !2466)
!2472 = !DILocation(line: 626, column: 52, scope: !2466)
!2473 = !DILocation(line: 626, column: 63, scope: !2466)
!2474 = !DILocation(line: 626, column: 78, scope: !2466)
!2475 = !DILocation(line: 624, column: 21, scope: !2466)
!2476 = !DILocation(line: 627, column: 23, scope: !2477)
!2477 = distinct !DILexicalBlock(scope: !2466, file: !3, line: 627, column: 21)
!2478 = !DILocation(line: 627, column: 21, scope: !2466)
!2479 = !DILocation(line: 628, column: 25, scope: !2480)
!2480 = distinct !DILexicalBlock(scope: !2481, file: !3, line: 628, column: 25)
!2481 = distinct !DILexicalBlock(scope: !2477, file: !3, line: 627, column: 32)
!2482 = !DILocation(line: 628, column: 25, scope: !2481)
!2483 = !DILocation(line: 629, column: 33, scope: !2484)
!2484 = distinct !DILexicalBlock(scope: !2480, file: !3, line: 628, column: 50)
!2485 = !DILocation(line: 629, column: 25, scope: !2484)
!2486 = !DILocation(line: 630, column: 25, scope: !2484)
!2487 = !DILocation(line: 632, column: 38, scope: !2488)
!2488 = distinct !DILexicalBlock(scope: !2489, file: !3, line: 632, column: 29)
!2489 = distinct !DILexicalBlock(scope: !2480, file: !3, line: 631, column: 28)
!2490 = !DILocation(line: 632, column: 46, scope: !2488)
!2491 = !DILocation(line: 632, column: 29, scope: !2489)
!2492 = !DILocation(line: 633, column: 37, scope: !2493)
!2493 = distinct !DILexicalBlock(scope: !2488, file: !3, line: 632, column: 51)
!2494 = !DILocation(line: 634, column: 39, scope: !2493)
!2495 = !DILocation(line: 633, column: 29, scope: !2493)
!2496 = !DILocation(line: 635, column: 25, scope: !2493)
!2497 = !DILocation(line: 642, column: 37, scope: !2489)
!2498 = !DILocation(line: 642, column: 25, scope: !2489)
!2499 = !DILocation(line: 644, column: 17, scope: !2481)
!2500 = !DILocation(line: 645, column: 24, scope: !2501)
!2501 = distinct !DILexicalBlock(scope: !2477, file: !3, line: 644, column: 24)
!2502 = !DILocation(line: 645, column: 31, scope: !2501)
!2503 = !DILocation(line: 646, column: 21, scope: !2501)
!2504 = !DILocation(line: 148, column: 5, scope: !2360, inlinedAt: !2505)
!2505 = distinct !DILocation(line: 657, column: 17, scope: !2466)
!2506 = !DILocation(line: 149, column: 15, scope: !2360, inlinedAt: !2505)
!2507 = !DILocation(line: 150, column: 5, scope: !2360, inlinedAt: !2505)
!2508 = !DILocation(line: 151, column: 5, scope: !2360, inlinedAt: !2505)
!2509 = !DILocation(line: 153, column: 5, scope: !2360, inlinedAt: !2505)
!2510 = !DILocation(line: 154, column: 5, scope: !2360, inlinedAt: !2505)
!2511 = !DILocation(line: 658, column: 17, scope: !2466)
!2512 = !DILocation(line: 661, column: 33, scope: !2466)
!2513 = !DILocation(line: 661, column: 45, scope: !2466)
!2514 = !DILocation(line: 661, column: 17, scope: !2466)
!2515 = !DILocation(line: 662, column: 17, scope: !2466)
!2516 = !DILocation(line: 665, column: 35, scope: !2466)
!2517 = !DILocation(line: 665, column: 47, scope: !2466)
!2518 = !DILocation(line: 665, column: 17, scope: !2466)
!2519 = !DILocation(line: 666, column: 17, scope: !2466)
!2520 = !DILocation(line: 669, column: 41, scope: !2466)
!2521 = !DILocation(line: 669, column: 17, scope: !2466)
!2522 = !DILocation(line: 670, column: 17, scope: !2466)
!2523 = !DILocation(line: 678, column: 22, scope: !2443)
!2524 = !DILocalVariable(name: "cq", arg: 1, scope: !2525, file: !3, line: 330, type: !1130)
!2525 = distinct !DISubprogram(name: "cqi_free", scope: !3, file: !3, line: 330, type: !1176, scopeLine: 330, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2526)
!2526 = !{!2524, !2527}
!2527 = !DILocalVariable(name: "item", arg: 2, scope: !2525, file: !3, line: 330, type: !1111)
!2528 = !DILocation(line: 0, scope: !2525, inlinedAt: !2529)
!2529 = distinct !DILocation(line: 678, column: 9, scope: !2443)
!2530 = !DILocation(line: 331, column: 20, scope: !2525, inlinedAt: !2529)
!2531 = !DILocation(line: 331, column: 5, scope: !2525, inlinedAt: !2529)
!2532 = !DILocation(line: 616, column: 36, scope: !2433)
!2533 = distinct !{!2533, !2434, !2534, !1012}
!2534 = !DILocation(line: 679, column: 5, scope: !2421)
!2535 = !DILocation(line: 680, column: 1, scope: !2411)
!2536 = distinct !DISubprogram(name: "thread_libevent_ionotify", scope: !3, file: !3, line: 550, type: !193, scopeLine: 550, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2537)
!2537 = !{!2538, !2539, !2540, !2541, !2542, !2543, !2544}
!2538 = !DILocalVariable(name: "fd", arg: 1, scope: !2536, file: !3, line: 550, type: !130)
!2539 = !DILocalVariable(name: "which", arg: 2, scope: !2536, file: !3, line: 550, type: !136)
!2540 = !DILocalVariable(name: "arg", arg: 3, scope: !2536, file: !3, line: 550, type: !119)
!2541 = !DILocalVariable(name: "me", scope: !2536, file: !3, line: 551, type: !154)
!2542 = !DILocalVariable(name: "ev_count", scope: !2536, file: !3, line: 552, type: !345)
!2543 = !DILocalVariable(name: "head", scope: !2536, file: !3, line: 553, type: !255)
!2544 = !DILocalVariable(name: "io", scope: !2545, file: !3, line: 581, type: !319)
!2545 = distinct !DILexicalBlock(scope: !2536, file: !3, line: 580, column: 34)
!2546 = distinct !DIAssignID()
!2547 = !DILocation(line: 0, scope: !2536)
!2548 = distinct !DIAssignID()
!2549 = !DILocation(line: 552, column: 5, scope: !2536)
!2550 = !DILocation(line: 552, column: 14, scope: !2536)
!2551 = distinct !DIAssignID()
!2552 = !DILocation(line: 553, column: 5, scope: !2536)
!2553 = !DILocation(line: 555, column: 5, scope: !2554)
!2554 = distinct !DILexicalBlock(scope: !2536, file: !3, line: 555, column: 5)
!2555 = !{!1124, !927, i64 0}
!2556 = distinct !DIAssignID()
!2557 = !{!1124, !927, i64 8}
!2558 = distinct !DIAssignID()
!2559 = !DILocation(line: 557, column: 9, scope: !2560)
!2560 = distinct !DILexicalBlock(scope: !2536, file: !3, line: 557, column: 9)
!2561 = !DILocation(line: 557, column: 47, scope: !2560)
!2562 = !DILocation(line: 557, column: 9, scope: !2536)
!2563 = !DILocation(line: 558, column: 22, scope: !2564)
!2564 = distinct !DILexicalBlock(scope: !2565, file: !3, line: 558, column: 13)
!2565 = distinct !DILexicalBlock(scope: !2560, file: !3, line: 557, column: 68)
!2566 = !DILocation(line: 558, column: 30, scope: !2564)
!2567 = !DILocation(line: 558, column: 13, scope: !2565)
!2568 = !DILocation(line: 559, column: 21, scope: !2564)
!2569 = !DILocation(line: 559, column: 13, scope: !2564)
!2570 = !DILocation(line: 576, column: 29, scope: !2536)
!2571 = !DILocation(line: 576, column: 5, scope: !2536)
!2572 = !DILocation(line: 577, column: 5, scope: !2573)
!2573 = distinct !DILexicalBlock(scope: !2574, file: !3, line: 577, column: 5)
!2574 = distinct !DILexicalBlock(scope: !2536, file: !3, line: 577, column: 5)
!2575 = !DILocation(line: 577, column: 5, scope: !2574)
!2576 = !DILocation(line: 577, column: 5, scope: !2577)
!2577 = distinct !DILexicalBlock(scope: !2573, file: !3, line: 577, column: 5)
!2578 = distinct !DIAssignID()
!2579 = !DILocation(line: 577, column: 5, scope: !2580)
!2580 = distinct !DILexicalBlock(scope: !2577, file: !3, line: 577, column: 5)
!2581 = !DILocation(line: 578, column: 5, scope: !2536)
!2582 = !DILocation(line: 580, column: 13, scope: !2536)
!2583 = !DILocation(line: 580, column: 5, scope: !2536)
!2584 = !DILocation(line: 0, scope: !2545)
!2585 = !DILocation(line: 582, column: 9, scope: !2586)
!2586 = distinct !DILexicalBlock(scope: !2587, file: !3, line: 582, column: 9)
!2587 = distinct !DILexicalBlock(scope: !2545, file: !3, line: 582, column: 9)
!2588 = distinct !DIAssignID()
!2589 = !DILocation(line: 582, column: 9, scope: !2587)
!2590 = distinct !DIAssignID()
!2591 = !DILocation(line: 583, column: 9, scope: !2545)
!2592 = distinct !{!2592, !2583, !2593, !1012}
!2593 = !DILocation(line: 584, column: 5, scope: !2536)
!2594 = !DILocation(line: 585, column: 1, scope: !2536)
!2595 = !DISubprogram(name: "malloc", scope: !2336, file: !2336, line: 672, type: !2596, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2596 = !DISubroutineType(types: !2597)
!2597 = !{!119, !355}
!2598 = !DISubprogram(name: "cache_create", scope: !609, file: !609, line: 59, type: !2599, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2599 = !DISubroutineType(types: !2600)
!2600 = !{!607, !1101, !355, !355}
!2601 = !DISubprogram(name: "cache_set_limit", scope: !609, file: !609, line: 97, type: !2602, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2602 = !DISubroutineType(types: !2603)
!2603 = !{null, !607, !130}
!2604 = !DISubprogram(name: "thread_io_queue_add", scope: !6, file: !6, line: 958, type: !2605, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2605 = !DISubroutineType(types: !2606)
!2606 = !{null, !154, !130, !119, !571}
!2607 = !DISubprogram(name: "event_set", scope: !2608, file: !2608, line: 184, type: !2609, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2608 = !DIFile(filename: "/usr/include/event2/event_compat.h", directory: "", checksumkind: CSK_MD5, checksum: "5472349fbd83479f91b432192bf02139")
!2609 = !DISubroutineType(types: !2610)
!2610 = !{null, !203, !130, !136, !192, !119}
!2611 = !DISubprogram(name: "event_base_set", scope: !109, file: !109, line: 787, type: !2612, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2612 = !DISubroutineType(types: !2613)
!2613 = !{!130, !161, !203}
!2614 = !DISubprogram(name: "event_add", scope: !109, file: !109, line: 1233, type: !2615, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2615 = !DISubroutineType(types: !2616)
!2616 = !{!130, !203, !2617}
!2617 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2618, size: 64)
!2618 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !230)
!2619 = !DISubprogram(name: "read", scope: !1576, file: !1576, line: 371, type: !2620, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2620 = !DISubroutineType(types: !2621)
!2621 = !{!471, !130, !119, !355}
!2622 = !DISubprogram(name: "conn_new", scope: !6, file: !6, line: 963, type: !2623, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2623 = !DISubroutineType(types: !2624)
!2624 = !{!265, !1689, !2625, !1689, !1689, !57, !161, !119, !345, !52}
!2625 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!2626 = !DISubprogram(name: "conn_io_queue_setup", scope: !6, file: !6, line: 959, type: !1580, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2627 = !DISubprogram(name: "conn_close_idle", scope: !6, file: !6, line: 1004, type: !1580, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2628 = !DISubprogram(name: "conn_worker_readd", scope: !6, file: !6, line: 966, type: !1580, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2629 = !DISubprogram(name: "event_base_loopexit", scope: !109, file: !109, line: 844, type: !2630, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2630 = !DISubroutineType(types: !2631)
!2631 = !{!130, !161, !2617}
!2632 = !DISubprogram(name: "pthread_cond_signal", scope: !934, file: !934, line: 1121, type: !2633, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2633 = !DISubroutineType(types: !2634)
!2634 = !{!130, !2326}
!2635 = !DISubprogram(name: "cache_free", scope: !609, file: !609, line: 89, type: !2636, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2636 = !DISubroutineType(types: !2637)
!2637 = !{null, !607, !119}
!2638 = !DISubprogram(name: "conn_io_queue_return", scope: !6, file: !6, line: 962, type: !494, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2639 = !DISubprogram(name: "pthread_attr_init", scope: !934, file: !934, line: 285, type: !2640, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2640 = !DISubroutineType(types: !2641)
!2641 = !{!130, !2642}
!2642 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2274, size: 64)
!2643 = !DISubprogram(name: "pthread_create", scope: !934, file: !934, line: 202, type: !2644, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2644 = !DISubroutineType(types: !2645)
!2645 = !{!130, !2646, !2648, !2267, !2387}
!2646 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !2647)
!2647 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !159, size: 64)
!2648 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !2649)
!2649 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2650, size: 64)
!2650 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !2274)
!2651 = !DISubprogram(name: "strerror", scope: !2652, file: !2652, line: 419, type: !2653, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2652 = !DIFile(filename: "/usr/include/string.h", directory: "", checksumkind: CSK_MD5, checksum: "165db1185644f68894fa9e0d17055d70")
!2653 = !DISubroutineType(types: !2654)
!2654 = !{!153, !130}
!2655 = !DISubprogram(name: "logger_create", scope: !69, file: !69, line: 227, type: !2656, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2656 = !DISubroutineType(types: !2657)
!2657 = !{!637}
!2658 = !DISubprogram(name: "item_lru_bump_buf_create", scope: !1034, file: !1034, line: 36, type: !2659, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2659 = !DISubroutineType(types: !2660)
!2660 = !{!119}
!2661 = !DISubprogram(name: "abort", scope: !2336, file: !2336, line: 730, type: !1031, flags: DIFlagPrototyped | DIFlagNoReturn, spFlags: DISPFlagOptimized)
!2662 = !DISubprogram(name: "event_base_loop", scope: !109, file: !109, line: 826, type: !2663, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2663 = !DISubroutineType(types: !2664)
!2664 = !{!130, !161, !130}
!2665 = !DISubprogram(name: "event_base_free", scope: !109, file: !109, line: 692, type: !2666, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2666 = !DISubroutineType(types: !2667)
!2667 = !{null, !161}
