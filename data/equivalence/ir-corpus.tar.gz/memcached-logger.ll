; ModuleID = 'logger.c'
source_filename = "logger.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%union.pthread_mutex_t = type { %struct.__pthread_mutex_s }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i16, i16, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%union.pthread_cond_t = type { %struct.__pthread_cond_s }
%struct.__pthread_cond_s = type { %union.__atomic_wide_counter, %union.__atomic_wide_counter, [2 x i32], [2 x i32], i32, i32, [2 x i32] }
%union.__atomic_wide_counter = type { i64 }
%struct.settings = type { i64, i32, i32, i32, ptr, i32, i32, i32, ptr, ptr, i32, double, i32, i32, i32, i8, i32, i32, i8, i32, i32, i32, i32, i32, i32, i8, i8, i8, i8, i8, i8, i32, double, i32, i32, i8, i32, i8, i8, ptr, i32, i32, i32, i32, double, double, i32, i8, i32, i32, i32, i32, i32, i8, i8, i8, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, double, double, i8, i32, i32, ptr, i32 }
%struct._entry_details = type { i32, i16, ptr, ptr, ptr }
%struct.pollfd = type { i32, i16, i16 }
%struct.stats = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, %struct.timeval, i64, i64 }
%struct.timeval = type { i64, i64 }
%struct.stats_state = type { i64, i64, i64, i64, i32, i32, i32, i32, i8, i8, i8, i8 }
%struct.__va_list_tag = type { i32, i32, ptr, ptr }

@logger_stack_lock = dso_local global %union.pthread_mutex_t zeroinitializer, align 8, !dbg !0
@logger_stack_cond = dso_local global %union.pthread_cond_t zeroinitializer, align 8, !dbg !738
@watcher_count = dso_local local_unnamed_addr global i32 0, align 4, !dbg !771
@logger_gid = internal global i64 0, align 8, !dbg !813
@logger_stack_head = internal unnamed_addr global ptr null, align 8, !dbg !815
@logger_stack_tail = internal unnamed_addr global ptr null, align 8, !dbg !817
@logger_key = dso_local global i32 0, align 4, !dbg !783
@settings = external local_unnamed_addr global %struct.settings, align 8
@default_entries = internal constant [16 x %struct._entry_details] [%struct._entry_details { i32 512, i16 512, ptr @_logger_log_text, ptr @_logger_parse_text, ptr @.str.8 }, %struct._entry_details { i32 512, i16 64, ptr @_logger_log_evictions, ptr @_logger_parse_ee, ptr null }, %struct._entry_details { i32 512, i16 4, ptr @_logger_log_item_get, ptr @_logger_parse_ige, ptr null }, %struct._entry_details { i32 512, i16 8, ptr @_logger_log_item_store, ptr @_logger_parse_ise, ptr null }, %struct._entry_details { i32 512, i16 2, ptr @_logger_log_text, ptr @_logger_parse_text, ptr @.str.9 }, %struct._entry_details { i32 512, i16 2, ptr @_logger_log_text, ptr @_logger_parse_text, ptr @.str.10 }, %struct._entry_details { i32 512, i16 32, ptr @_logger_log_conn_event, ptr @_logger_parse_cne, ptr null }, %struct._entry_details { i32 512, i16 32, ptr @_logger_log_conn_event, ptr @_logger_parse_cce, ptr null }, %struct._entry_details { i32 512, i16 8192, ptr @_logger_log_item_deleted, ptr @_logger_parse_ide, ptr null }, %struct._entry_details { i32 512, i16 64, ptr @_logger_log_ext_write, ptr @_logger_parse_extw, ptr null }, %struct._entry_details { i32 512, i16 2, ptr @_logger_log_text, ptr @_logger_parse_text, ptr @.str.11 }, %struct._entry_details { i32 512, i16 2, ptr @_logger_log_text, ptr @_logger_parse_text, ptr @.str.12 }, %struct._entry_details { i32 512, i16 2, ptr @_logger_log_text, ptr @_logger_parse_text, ptr @.str.13 }, %struct._entry_details { i32 512, i16 2, ptr @_logger_log_text, ptr @_logger_parse_text, ptr @.str.14 }, %struct._entry_details { i32 512, i16 2, ptr @_logger_log_text, ptr @_logger_parse_text, ptr @.str.15 }, %struct._entry_details { i32 512, i16 2, ptr @_logger_log_text, ptr @_logger_parse_text, ptr @.str.16 }], align 16, !dbg !891
@stderr = external local_unnamed_addr global ptr, align 8
@.str = private unnamed_addr constant [44 x i8] c"LOGGER: Failed to bipbuf push a text entry\0A\00", align 1, !dbg !773
@watchers = dso_local local_unnamed_addr global [20 x ptr] zeroinitializer, align 16, !dbg !786
@.str.1 = private unnamed_addr constant [5 x i8] c"OK\0D\0A\00", align 1, !dbg !778
@watchers_pollfds = dso_local global [20 x %struct.pollfd] zeroinitializer, align 16, !dbg !804
@do_run_logger_thread = internal global i32 1, align 4, !dbg !829
@logger_tid = internal global i64 0, align 8, !dbg !832
@.str.2 = private unnamed_addr constant [31 x i8] c"Can't start logger thread: %s\0A\00", align 1, !dbg !819
@.str.3 = private unnamed_addr constant [7 x i8] c"mc-log\00", align 1, !dbg !824
@.str.4 = private unnamed_addr constant [35 x i8] c"LOGGER: Failed to parse log entry\0A\00", align 1, !dbg !834
@.str.5 = private unnamed_addr constant [51 x i8] c"LOGGER: unexpectedly couldn't advance buf pointer\0A\00", align 1, !dbg !839
@.str.6 = private unnamed_addr constant [14 x i8] c"skipped=%llu\0A\00", align 1, !dbg !844
@.str.7 = private unnamed_addr constant [55 x i8] c"something failed with logger thread watcher fd polling\00", align 1, !dbg !849
@stats = external local_unnamed_addr global %struct.stats, align 8
@stats_state = external local_unnamed_addr global %struct.stats_state, align 8
@.str.8 = private unnamed_addr constant [7 x i8] c"<%d %s\00", align 1, !dbg !854
@.str.9 = private unnamed_addr constant [133 x i8] c"type=lru_crawler crawler=%d lru=%s low_mark=%llu next_reclaims=%llu since_run=%u next_run=%d elapsed=%u examined=%llu reclaimed=%llu\00", align 1, !dbg !856
@.str.10 = private unnamed_addr constant [29 x i8] c"type=slab_move src=%d dst=%d\00", align 1, !dbg !861
@.str.11 = private unnamed_addr constant [39 x i8] c"type=compact_start id=%lu version=%llu\00", align 1, !dbg !866
@.str.12 = private unnamed_addr constant [26 x i8] c"type=compact_abort id=%lu\00", align 1, !dbg !871
@.str.13 = private unnamed_addr constant [43 x i8] c"type=compact_read_start id=%lu offset=%llu\00", align 1, !dbg !876
@.str.14 = private unnamed_addr constant [74 x i8] c"type=compact_read_end id=%lu offset=%llu rescues=%lu lost=%lu skipped=%lu\00", align 1, !dbg !881
@.str.15 = private unnamed_addr constant [24 x i8] c"type=compact_end id=%lu\00", align 1, !dbg !886
@.str.16 = private unnamed_addr constant [43 x i8] c"type=compact_fraginfo ratio=%.2f bytes=%lu\00", align 1, !dbg !889
@.str.17 = private unnamed_addr constant [54 x i8] c"LOGGER: Failed to vsnprintf a text entry: (total) %d\0A\00", align 1, !dbg !894
@.str.18 = private unnamed_addr constant [24 x i8] c"ts=%lld.%d gid=%llu %s\0A\00", align 1, !dbg !899
@current_time = external global i32, align 4
@.str.19 = private unnamed_addr constant [83 x i8] c"ts=%lld.%d gid=%llu type=eviction key=%s fetch=%s ttl=%lld la=%d clsid=%u size=%d\0A\00", align 1, !dbg !901
@.str.20 = private unnamed_addr constant [4 x i8] c"yes\00", align 1, !dbg !906
@.str.21 = private unnamed_addr constant [3 x i8] c"no\00", align 1, !dbg !909
@.str.22 = private unnamed_addr constant [10 x i8] c"not_found\00", align 1, !dbg !912
@.str.23 = private unnamed_addr constant [6 x i8] c"found\00", align 1, !dbg !917
@.str.24 = private unnamed_addr constant [8 x i8] c"flushed\00", align 1, !dbg !922
@.str.25 = private unnamed_addr constant [8 x i8] c"expired\00", align 1, !dbg !925
@reltable._logger_parse_ige = private unnamed_addr constant [4 x i32] [i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.22 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ige to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.23 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ige to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.24 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ige to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.25 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ige to i64)) to i32)], align 4
@.str.26 = private unnamed_addr constant [76 x i8] c"ts=%lld.%d gid=%llu type=item_get key=%s status=%s clsid=%u cfd=%d size=%d\0A\00", align 1, !dbg !927
@.str.27 = private unnamed_addr constant [3 x i8] c"na\00", align 1, !dbg !932
@.str.28 = private unnamed_addr constant [11 x i8] c"not_stored\00", align 1, !dbg !934
@.str.29 = private unnamed_addr constant [7 x i8] c"stored\00", align 1, !dbg !939
@.str.30 = private unnamed_addr constant [7 x i8] c"exists\00", align 1, !dbg !941
@.str.31 = private unnamed_addr constant [10 x i8] c"too_large\00", align 1, !dbg !943
@.str.32 = private unnamed_addr constant [10 x i8] c"no_memory\00", align 1, !dbg !945
@reltable._logger_parse_ise = private unnamed_addr constant [6 x i32] [i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.28 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ise to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.29 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ise to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.30 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ise to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.22 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ise to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.31 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ise to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.32 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ise to i64)) to i32)], align 4
@.str.33 = private unnamed_addr constant [5 x i8] c"null\00", align 1, !dbg !947
@.str.34 = private unnamed_addr constant [4 x i8] c"add\00", align 1, !dbg !949
@.str.35 = private unnamed_addr constant [4 x i8] c"set\00", align 1, !dbg !951
@.str.36 = private unnamed_addr constant [8 x i8] c"replace\00", align 1, !dbg !953
@.str.37 = private unnamed_addr constant [7 x i8] c"append\00", align 1, !dbg !955
@.str.38 = private unnamed_addr constant [8 x i8] c"prepend\00", align 1, !dbg !957
@.str.39 = private unnamed_addr constant [4 x i8] c"cas\00", align 1, !dbg !959
@reltable._logger_parse_ise.55 = private unnamed_addr constant [9 x i32] [i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.33 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ise.55 to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.34 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ise.55 to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.35 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ise.55 to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.36 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ise.55 to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.37 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ise.55 to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.38 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ise.55 to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.39 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ise.55 to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.37 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ise.55 to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.38 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ise.55 to i64)) to i32)], align 4
@.str.40 = private unnamed_addr constant [92 x i8] c"ts=%lld.%d gid=%llu type=item_store key=%s status=%s cmd=%s ttl=%u clsid=%u cfd=%d size=%d\0A\00", align 1, !dbg !961
@.str.41 = private unnamed_addr constant [6 x i8] c"local\00", align 1, !dbg !966
@.str.42 = private unnamed_addr constant [4 x i8] c"tcp\00", align 1, !dbg !968
@.str.43 = private unnamed_addr constant [4 x i8] c"udp\00", align 1, !dbg !970
@.str.44 = private unnamed_addr constant [72 x i8] c"ts=%lld.%d gid=%llu type=conn_new rip=%s rport=%hu transport=%s cfd=%d\0A\00", align 1, !dbg !972
@.str.45 = private unnamed_addr constant [5 x i8] c"unix\00", align 1, !dbg !977
@__const._logger_parse_cce.transport_map = private unnamed_addr constant [3 x ptr] [ptr @.str.41, ptr @.str.42, ptr @.str.43], align 16
@.str.46 = private unnamed_addr constant [6 x i8] c"error\00", align 1, !dbg !979
@.str.47 = private unnamed_addr constant [7 x i8] c"normal\00", align 1, !dbg !981
@.str.48 = private unnamed_addr constant [13 x i8] c"idle_timeout\00", align 1, !dbg !983
@.str.49 = private unnamed_addr constant [9 x i8] c"shutdown\00", align 1, !dbg !988
@reltable._logger_parse_cce = private unnamed_addr constant [4 x i32] [i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.46 to i64), i64 ptrtoint (ptr @reltable._logger_parse_cce to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.47 to i64), i64 ptrtoint (ptr @reltable._logger_parse_cce to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.48 to i64), i64 ptrtoint (ptr @reltable._logger_parse_cce to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.49 to i64), i64 ptrtoint (ptr @reltable._logger_parse_cce to i64)) to i32)], align 4
@.str.50 = private unnamed_addr constant [84 x i8] c"ts=%lld.%d gid=%llu type=conn_close rip=%s rport=%hu transport=%s reason=%s cfd=%d\0A\00", align 1, !dbg !993
@.str.51 = private unnamed_addr constant [7 x i8] c"delete\00", align 1, !dbg !998
@.str.52 = private unnamed_addr constant [3 x i8] c"md\00", align 1, !dbg !1000
@reltable._logger_parse_ide = private unnamed_addr constant [3 x i32] [i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.33 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ide to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.51 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ide to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.52 to i64), i64 ptrtoint (ptr @reltable._logger_parse_ide to i64)) to i32)], align 4
@.str.53 = private unnamed_addr constant [63 x i8] c"ts=%d.%d gid=%llu type=deleted key=%s cmd=%s clsid=%u size=%d\0A\00", align 1, !dbg !1002
@.str.54 = private unnamed_addr constant [85 x i8] c"ts=%lld.%d gid=%llu type=extwrite key=%s fetch=%s ttl=%lld la=%d clsid=%u bucket=%u\0A\00", align 1, !dbg !1007
@logger_count = internal unnamed_addr global i32 0, align 4, !dbg !1012
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: mustprogress nofree norecurse nounwind sanitize_thread willreturn memory(readwrite, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @logger_get_gid() local_unnamed_addr #0 !dbg !1022 {
entry:
  %0 = atomicrmw add ptr @logger_gid, i64 1 seq_cst, align 8, !dbg !1025
  %1 = add i64 %0, 1, !dbg !1025
  ret i64 %1, !dbg !1026
}

; Function Attrs: mustprogress nofree norecurse nounwind sanitize_thread willreturn memory(readwrite, argmem: none, inaccessiblemem: none) uwtable
define dso_local void @logger_set_gid(i64 noundef %gid) local_unnamed_addr #0 !dbg !1027 {
entry:
  tail call void @llvm.dbg.value(metadata i64 %gid, metadata !1031, metadata !DIExpression()), !dbg !1032
  %0 = atomicrmw add ptr @logger_gid, i64 %gid seq_cst, align 8, !dbg !1033
  ret void, !dbg !1034
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @logger_init() local_unnamed_addr #1 !dbg !1035 {
entry:
  store ptr null, ptr @logger_stack_head, align 8, !dbg !1038, !tbaa !1039
  store ptr null, ptr @logger_stack_tail, align 8, !dbg !1043, !tbaa !1039
  %call = tail call i32 @pthread_key_create(ptr noundef nonnull @logger_key, ptr noundef null) #21, !dbg !1044
  store volatile i32 1, ptr @do_run_logger_thread, align 4, !dbg !1045, !tbaa !1053
  %call.i = tail call i32 @pthread_create(ptr noundef nonnull @logger_tid, ptr noundef null, ptr noundef nonnull @logger_thread, ptr noundef null) #21, !dbg !1055
  tail call void @llvm.dbg.value(metadata i32 %call.i, metadata !1050, metadata !DIExpression()), !dbg !1057
  %cmp.not.i = icmp eq i32 %call.i, 0, !dbg !1058
  br i1 %cmp.not.i, label %if.end, label %if.then, !dbg !1059

if.then:                                          ; preds = %entry
  %0 = load ptr, ptr @stderr, align 8, !dbg !1060, !tbaa !1039
  %call1.i = tail call ptr @strerror(i32 noundef %call.i) #21, !dbg !1062
  %call2.i = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %0, ptr noundef nonnull @.str.2, ptr noundef %call1.i) #22, !dbg !1063
  tail call void @abort() #23, !dbg !1064
  unreachable, !dbg !1064

if.end:                                           ; preds = %entry
  %1 = load i64, ptr @logger_tid, align 8, !dbg !1066, !tbaa !1067
  tail call void @thread_setname(i64 noundef %1, ptr noundef nonnull @.str.3) #21, !dbg !1069
  ret void, !dbg !1070
}

; Function Attrs: nounwind
declare !dbg !1071 i32 @pthread_key_create(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: noreturn nounwind
declare !dbg !1079 void @abort() local_unnamed_addr #3

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @logger_stop() local_unnamed_addr #1 !dbg !1081 {
entry:
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @logger_stack_lock) #21, !dbg !1082
  store volatile i32 0, ptr @do_run_logger_thread, align 4, !dbg !1085, !tbaa !1053
  %call1.i = tail call i32 @pthread_cond_signal(ptr noundef nonnull @logger_stack_cond) #21, !dbg !1086
  %call2.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @logger_stack_lock) #21, !dbg !1087
  %0 = load i64, ptr @logger_tid, align 8, !dbg !1088, !tbaa !1067
  %call3.i = tail call i32 @pthread_join(i64 noundef %0, ptr noundef null) #21, !dbg !1089
  ret void, !dbg !1090
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef ptr @logger_create() local_unnamed_addr #1 !dbg !1091 {
entry:
  %call = tail call noalias dereferenceable_or_null(104) ptr @calloc(i64 noundef 1, i64 noundef 104) #24, !dbg !1096
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !1095, metadata !DIExpression()), !dbg !1097
  %cmp = icmp eq ptr %call, null, !dbg !1098
  br i1 %cmp, label %cleanup, label %if.end, !dbg !1100

if.end:                                           ; preds = %entry
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 51), align 4, !dbg !1101, !tbaa !1102
  %call1 = tail call ptr @bipbuf_new(i32 noundef %0) #21, !dbg !1106
  %buf = getelementptr inbounds i8, ptr %call, i64 88, !dbg !1107
  store ptr %call1, ptr %buf, align 8, !dbg !1108, !tbaa !1109
  %cmp3 = icmp eq ptr %call1, null, !dbg !1112
  br i1 %cmp3, label %if.then4, label %if.end5, !dbg !1114

if.then4:                                         ; preds = %if.end
  tail call void @free(ptr noundef nonnull %call) #21, !dbg !1115
  br label %cleanup, !dbg !1117

if.end5:                                          ; preds = %if.end
  %entry_map = getelementptr inbounds i8, ptr %call, i64 96, !dbg !1118
  store ptr @default_entries, ptr %entry_map, align 8, !dbg !1119, !tbaa !1120
  %mutex = getelementptr inbounds i8, ptr %call, i64 16, !dbg !1121
  %call6 = tail call i32 @pthread_mutex_init(ptr noundef nonnull %mutex, ptr noundef null) #21, !dbg !1122
  %1 = load i32, ptr @logger_key, align 4, !dbg !1123, !tbaa !1053
  %call7 = tail call i32 @pthread_setspecific(i32 noundef %1, ptr noundef nonnull %call) #21, !dbg !1124
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !1125, metadata !DIExpression()), !dbg !1130
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @logger_stack_lock) #21, !dbg !1132
  store ptr null, ptr %call, align 8, !dbg !1133, !tbaa !1134
  %2 = load ptr, ptr @logger_stack_head, align 8, !dbg !1135, !tbaa !1039
  %next.i = getelementptr inbounds i8, ptr %call, i64 8, !dbg !1136
  store ptr %2, ptr %next.i, align 8, !dbg !1137, !tbaa !1138
  %tobool.not.i = icmp eq ptr %2, null, !dbg !1139
  br i1 %tobool.not.i, label %if.end.i, label %if.then.i, !dbg !1141

if.then.i:                                        ; preds = %if.end5
  store ptr %call, ptr %2, align 8, !dbg !1142, !tbaa !1134
  br label %if.end.i, !dbg !1143

if.end.i:                                         ; preds = %if.then.i, %if.end5
  store ptr %call, ptr @logger_stack_head, align 8, !dbg !1144, !tbaa !1039
  %3 = load ptr, ptr @logger_stack_tail, align 8, !dbg !1145, !tbaa !1039
  %cmp.i = icmp eq ptr %3, null, !dbg !1147
  br i1 %cmp.i, label %if.then4.i, label %logger_link_q.exit, !dbg !1148

if.then4.i:                                       ; preds = %if.end.i
  store ptr %call, ptr @logger_stack_tail, align 8, !dbg !1149, !tbaa !1039
  br label %logger_link_q.exit, !dbg !1150

logger_link_q.exit:                               ; preds = %if.end.i, %if.then4.i
  %4 = load i32, ptr @logger_count, align 4, !dbg !1151, !tbaa !1053
  %inc.i = add i32 %4, 1, !dbg !1151
  store i32 %inc.i, ptr @logger_count, align 4, !dbg !1151, !tbaa !1053
  %call6.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @logger_stack_lock) #21, !dbg !1152
  br label %cleanup, !dbg !1153

cleanup:                                          ; preds = %entry, %logger_link_q.exit, %if.then4
  %retval.0 = phi ptr [ null, %if.then4 ], [ %call, %logger_link_q.exit ], [ null, %entry ], !dbg !1097
  ret ptr %retval.0, !dbg !1154
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #4

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite)
declare !dbg !1155 noalias noundef ptr @calloc(i64 noundef, i64 noundef) local_unnamed_addr #5

declare !dbg !1158 ptr @bipbuf_new(i32 noundef) local_unnamed_addr #6

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !1162 void @free(ptr allocptr nocapture noundef) local_unnamed_addr #7

; Function Attrs: nounwind
declare !dbg !1163 i32 @pthread_mutex_init(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind
declare !dbg !1174 i32 @pthread_setspecific(i32 noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #4

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 0, 3) i32 @logger_log(ptr noundef %l, i32 noundef %event, ptr noundef %entry1, ...) local_unnamed_addr #1 !dbg !1177 {
entry:
  %ap = alloca [1 x %struct.__va_list_tag], align 16, !DIAssignID !1197
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1187, metadata !DIExpression(), metadata !1197, metadata ptr %ap, metadata !DIExpression()), !dbg !1198
  tail call void @llvm.dbg.value(metadata ptr %l, metadata !1182, metadata !DIExpression()), !dbg !1198
  tail call void @llvm.dbg.value(metadata i32 %event, metadata !1183, metadata !DIExpression()), !dbg !1198
  tail call void @llvm.dbg.value(metadata ptr %entry1, metadata !1184, metadata !DIExpression()), !dbg !1198
  %buf2 = getelementptr inbounds i8, ptr %l, i64 88, !dbg !1199
  %0 = load ptr, ptr %buf2, align 8, !dbg !1199, !tbaa !1109
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1185, metadata !DIExpression()), !dbg !1198
  tail call void @llvm.dbg.value(metadata i8 0, metadata !1186, metadata !DIExpression()), !dbg !1198
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %ap) #21, !dbg !1200
  %entry_map = getelementptr inbounds i8, ptr %l, i64 96, !dbg !1201
  %1 = load ptr, ptr %entry_map, align 8, !dbg !1201, !tbaa !1120
  %idxprom = zext i32 %event to i64, !dbg !1202
  %arrayidx = getelementptr inbounds %struct._entry_details, ptr %1, i64 %idxprom, !dbg !1202
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !1195, metadata !DIExpression()), !dbg !1198
  %2 = load i32, ptr %arrayidx, align 8, !dbg !1203, !tbaa !1204
  tail call void @llvm.dbg.value(metadata i32 %2, metadata !1196, metadata !DIExpression()), !dbg !1198
  %mutex = getelementptr inbounds i8, ptr %l, i64 16, !dbg !1206
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %mutex) #21, !dbg !1207
  %add = add i32 %2, 40, !dbg !1208
  %call5 = tail call ptr @bipbuf_request(ptr noundef %0, i32 noundef %add) #21, !dbg !1209
  tail call void @llvm.dbg.value(metadata ptr %call5, metadata !1194, metadata !DIExpression()), !dbg !1198
  %cmp = icmp eq ptr %call5, null, !dbg !1210
  br i1 %cmp, label %if.then, label %if.end, !dbg !1212

if.then:                                          ; preds = %entry
  %dropped = getelementptr inbounds i8, ptr %l, i64 64, !dbg !1213
  %3 = load i64, ptr %dropped, align 8, !dbg !1215, !tbaa !1216
  %inc = add i64 %3, 1, !dbg !1215
  store i64 %inc, ptr %dropped, align 8, !dbg !1215, !tbaa !1216
  %call8 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %mutex) #21, !dbg !1217
  br label %cleanup, !dbg !1218

if.end:                                           ; preds = %entry
  store i32 %event, ptr %call5, align 8, !dbg !1219, !tbaa !1053
  %pad = getelementptr inbounds i8, ptr %call5, i64 4, !dbg !1220
  store i8 0, ptr %pad, align 4, !dbg !1221, !tbaa !1222
  %4 = atomicrmw add ptr @logger_gid, i64 1 seq_cst, align 8, !dbg !1223
  %5 = add i64 %4, 1, !dbg !1223
  %gid = getelementptr inbounds i8, ptr %call5, i64 8, !dbg !1225
  store i64 %5, ptr %gid, align 8, !dbg !1226, !tbaa !1067
  %eflags = getelementptr inbounds i8, ptr %arrayidx, i64 4, !dbg !1227
  %6 = load i16, ptr %eflags, align 4, !dbg !1227, !tbaa !1228
  %eflags11 = getelementptr inbounds i8, ptr %call5, i64 6, !dbg !1229
  store i16 %6, ptr %eflags11, align 2, !dbg !1230, !tbaa !1231
  %tv = getelementptr inbounds i8, ptr %call5, i64 16, !dbg !1232
  %call12 = tail call i32 @gettimeofday(ptr noundef nonnull %tv, ptr noundef null) #21, !dbg !1233
  call void @llvm.va_start.p0(ptr nonnull %ap), !dbg !1234
  %log_cb = getelementptr inbounds i8, ptr %arrayidx, i64 8, !dbg !1235
  %7 = load ptr, ptr %log_cb, align 8, !dbg !1235, !tbaa !1236
  call void %7(ptr noundef nonnull %call5, ptr noundef nonnull %arrayidx, ptr noundef %entry1, ptr noundef nonnull %ap) #21, !dbg !1237
  call void @llvm.va_end.p0(ptr nonnull %ap), !dbg !1238
  %size = getelementptr inbounds i8, ptr %call5, i64 32, !dbg !1239
  %8 = load i32, ptr %size, align 8, !dbg !1239, !tbaa !1053
  %add16 = add i32 %8, 40, !dbg !1241
  %9 = load i8, ptr %pad, align 4, !dbg !1242, !tbaa !1222
  %conv18 = zext i8 %9 to i32, !dbg !1243
  %add19 = add i32 %add16, %conv18, !dbg !1244
  %call21 = call i32 @bipbuf_push(ptr noundef %0, i32 noundef %add19) #21, !dbg !1245
  %cmp22 = icmp eq i32 %call21, 0, !dbg !1246
  br i1 %cmp22, label %if.then24, label %if.end28, !dbg !1247

if.then24:                                        ; preds = %if.end
  %10 = load ptr, ptr @stderr, align 8, !dbg !1248, !tbaa !1039
  %11 = call i64 @fwrite(ptr nonnull @.str, i64 43, i64 1, ptr %10) #25, !dbg !1250
  %call27 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %mutex) #21, !dbg !1251
  br label %cleanup, !dbg !1252

if.end28:                                         ; preds = %if.end
  %written = getelementptr inbounds i8, ptr %l, i64 56, !dbg !1253
  %12 = load i64, ptr %written, align 8, !dbg !1254, !tbaa !1255
  %inc29 = add i64 %12, 1, !dbg !1254
  store i64 %inc29, ptr %written, align 8, !dbg !1254, !tbaa !1255
  %call31 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %mutex) #21, !dbg !1256
  br label %cleanup, !dbg !1257

cleanup:                                          ; preds = %if.end28, %if.then24, %if.then
  %retval.0 = phi i32 [ 1, %if.then ], [ 2, %if.then24 ], [ 0, %if.end28 ], !dbg !1198
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %ap) #21, !dbg !1260
  ret i32 %retval.0, !dbg !1260
}

; Function Attrs: nounwind
declare !dbg !1261 i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #2

declare !dbg !1264 ptr @bipbuf_request(ptr noundef, i32 noundef) local_unnamed_addr #6

; Function Attrs: nounwind
declare !dbg !1268 i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #2

; Function Attrs: nofree nounwind
declare !dbg !1269 noundef i32 @gettimeofday(ptr nocapture noundef, ptr nocapture noundef) local_unnamed_addr #8

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.va_start.p0(ptr) #9

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.va_end.p0(ptr) #9

declare !dbg !1276 i32 @bipbuf_push(ptr noundef, i32 noundef) local_unnamed_addr #6

; Function Attrs: nofree nounwind
declare !dbg !1279 noundef i32 @fprintf(ptr nocapture noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #8

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 0, 3) i32 @logger_add_watcher(ptr noundef %c, i32 noundef %sfd, i16 noundef zeroext %f) local_unnamed_addr #1 !dbg !1336 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1340, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i32 %sfd, metadata !1341, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i16 %f, metadata !1342, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1344, metadata !DIExpression()), !dbg !1345
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @logger_stack_lock) #21, !dbg !1346
  %0 = load i32, ptr @watcher_count, align 4, !dbg !1347, !tbaa !1053
  %cmp = icmp sgt i32 %0, 19, !dbg !1349
  br i1 %cmp, label %cleanup, label %for.body.preheader, !dbg !1350

for.body.preheader:                               ; preds = %entry
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1343, metadata !DIExpression()), !dbg !1345
  %1 = load ptr, ptr @watchers, align 16, !dbg !1351, !tbaa !1039
  %cmp3 = icmp eq ptr %1, null, !dbg !1356
  br i1 %cmp3, label %for.end, label %for.inc, !dbg !1357

for.inc:                                          ; preds = %for.body.preheader
  tail call void @llvm.dbg.value(metadata i64 1, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 1, metadata !1343, metadata !DIExpression()), !dbg !1345
  %2 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 1), align 8, !dbg !1351, !tbaa !1039
  %cmp3.1 = icmp eq ptr %2, null, !dbg !1356
  br i1 %cmp3.1, label %for.end, label %for.inc.1, !dbg !1357

for.inc.1:                                        ; preds = %for.inc
  tail call void @llvm.dbg.value(metadata i64 2, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 2, metadata !1343, metadata !DIExpression()), !dbg !1345
  %3 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 2), align 16, !dbg !1351, !tbaa !1039
  %cmp3.2 = icmp eq ptr %3, null, !dbg !1356
  br i1 %cmp3.2, label %for.end, label %for.inc.2, !dbg !1357

for.inc.2:                                        ; preds = %for.inc.1
  tail call void @llvm.dbg.value(metadata i64 3, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 3, metadata !1343, metadata !DIExpression()), !dbg !1345
  %4 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 3), align 8, !dbg !1351, !tbaa !1039
  %cmp3.3 = icmp eq ptr %4, null, !dbg !1356
  br i1 %cmp3.3, label %for.end, label %for.inc.3, !dbg !1357

for.inc.3:                                        ; preds = %for.inc.2
  tail call void @llvm.dbg.value(metadata i64 4, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 4, metadata !1343, metadata !DIExpression()), !dbg !1345
  %5 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 4), align 16, !dbg !1351, !tbaa !1039
  %cmp3.4 = icmp eq ptr %5, null, !dbg !1356
  br i1 %cmp3.4, label %for.end, label %for.inc.4, !dbg !1357

for.inc.4:                                        ; preds = %for.inc.3
  tail call void @llvm.dbg.value(metadata i64 5, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 5, metadata !1343, metadata !DIExpression()), !dbg !1345
  %6 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 5), align 8, !dbg !1351, !tbaa !1039
  %cmp3.5 = icmp eq ptr %6, null, !dbg !1356
  br i1 %cmp3.5, label %for.end, label %for.inc.5, !dbg !1357

for.inc.5:                                        ; preds = %for.inc.4
  tail call void @llvm.dbg.value(metadata i64 6, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 6, metadata !1343, metadata !DIExpression()), !dbg !1345
  %7 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 6), align 16, !dbg !1351, !tbaa !1039
  %cmp3.6 = icmp eq ptr %7, null, !dbg !1356
  br i1 %cmp3.6, label %for.end, label %for.inc.6, !dbg !1357

for.inc.6:                                        ; preds = %for.inc.5
  tail call void @llvm.dbg.value(metadata i64 7, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 7, metadata !1343, metadata !DIExpression()), !dbg !1345
  %8 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 7), align 8, !dbg !1351, !tbaa !1039
  %cmp3.7 = icmp eq ptr %8, null, !dbg !1356
  br i1 %cmp3.7, label %for.end, label %for.inc.7, !dbg !1357

for.inc.7:                                        ; preds = %for.inc.6
  tail call void @llvm.dbg.value(metadata i64 8, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 8, metadata !1343, metadata !DIExpression()), !dbg !1345
  %9 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 8), align 16, !dbg !1351, !tbaa !1039
  %cmp3.8 = icmp eq ptr %9, null, !dbg !1356
  br i1 %cmp3.8, label %for.end, label %for.inc.8, !dbg !1357

for.inc.8:                                        ; preds = %for.inc.7
  tail call void @llvm.dbg.value(metadata i64 9, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 9, metadata !1343, metadata !DIExpression()), !dbg !1345
  %10 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 9), align 8, !dbg !1351, !tbaa !1039
  %cmp3.9 = icmp eq ptr %10, null, !dbg !1356
  br i1 %cmp3.9, label %for.end, label %for.inc.9, !dbg !1357

for.inc.9:                                        ; preds = %for.inc.8
  tail call void @llvm.dbg.value(metadata i64 10, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 10, metadata !1343, metadata !DIExpression()), !dbg !1345
  %11 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 10), align 16, !dbg !1351, !tbaa !1039
  %cmp3.10 = icmp eq ptr %11, null, !dbg !1356
  br i1 %cmp3.10, label %for.end, label %for.inc.10, !dbg !1357

for.inc.10:                                       ; preds = %for.inc.9
  tail call void @llvm.dbg.value(metadata i64 11, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 11, metadata !1343, metadata !DIExpression()), !dbg !1345
  %12 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 11), align 8, !dbg !1351, !tbaa !1039
  %cmp3.11 = icmp eq ptr %12, null, !dbg !1356
  br i1 %cmp3.11, label %for.end, label %for.inc.11, !dbg !1357

for.inc.11:                                       ; preds = %for.inc.10
  tail call void @llvm.dbg.value(metadata i64 12, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 12, metadata !1343, metadata !DIExpression()), !dbg !1345
  %13 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 12), align 16, !dbg !1351, !tbaa !1039
  %cmp3.12 = icmp eq ptr %13, null, !dbg !1356
  br i1 %cmp3.12, label %for.end, label %for.inc.12, !dbg !1357

for.inc.12:                                       ; preds = %for.inc.11
  tail call void @llvm.dbg.value(metadata i64 13, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 13, metadata !1343, metadata !DIExpression()), !dbg !1345
  %14 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 13), align 8, !dbg !1351, !tbaa !1039
  %cmp3.13 = icmp eq ptr %14, null, !dbg !1356
  br i1 %cmp3.13, label %for.end, label %for.inc.13, !dbg !1357

for.inc.13:                                       ; preds = %for.inc.12
  tail call void @llvm.dbg.value(metadata i64 14, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 14, metadata !1343, metadata !DIExpression()), !dbg !1345
  %15 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 14), align 16, !dbg !1351, !tbaa !1039
  %cmp3.14 = icmp eq ptr %15, null, !dbg !1356
  br i1 %cmp3.14, label %for.end, label %for.inc.14, !dbg !1357

for.inc.14:                                       ; preds = %for.inc.13
  tail call void @llvm.dbg.value(metadata i64 15, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 15, metadata !1343, metadata !DIExpression()), !dbg !1345
  %16 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 15), align 8, !dbg !1351, !tbaa !1039
  %cmp3.15 = icmp eq ptr %16, null, !dbg !1356
  br i1 %cmp3.15, label %for.end, label %for.inc.15, !dbg !1357

for.inc.15:                                       ; preds = %for.inc.14
  tail call void @llvm.dbg.value(metadata i64 16, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 16, metadata !1343, metadata !DIExpression()), !dbg !1345
  %17 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 16), align 16, !dbg !1351, !tbaa !1039
  %cmp3.16 = icmp eq ptr %17, null, !dbg !1356
  br i1 %cmp3.16, label %for.end, label %for.inc.16, !dbg !1357

for.inc.16:                                       ; preds = %for.inc.15
  tail call void @llvm.dbg.value(metadata i64 17, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 17, metadata !1343, metadata !DIExpression()), !dbg !1345
  %18 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 17), align 8, !dbg !1351, !tbaa !1039
  %cmp3.17 = icmp eq ptr %18, null, !dbg !1356
  br i1 %cmp3.17, label %for.end, label %for.inc.17, !dbg !1357

for.inc.17:                                       ; preds = %for.inc.16
  tail call void @llvm.dbg.value(metadata i64 18, metadata !1343, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 18, metadata !1343, metadata !DIExpression()), !dbg !1345
  %19 = load ptr, ptr getelementptr inbounds ([20 x ptr], ptr @watchers, i64 0, i64 18), align 16, !dbg !1351, !tbaa !1039
  %cmp3.18 = icmp eq ptr %19, null, !dbg !1356
  %spec.select = select i1 %cmp3.18, i32 18, i32 19, !dbg !1357
  br label %for.end, !dbg !1357

for.end:                                          ; preds = %for.inc.17, %for.inc.16, %for.inc.15, %for.inc.14, %for.inc.13, %for.inc.12, %for.inc.11, %for.inc.10, %for.inc.9, %for.inc.8, %for.inc.7, %for.inc.6, %for.inc.5, %for.inc.4, %for.inc.3, %for.inc.2, %for.inc.1, %for.inc, %for.body.preheader
  %x.0.lcssa = phi i32 [ 0, %for.body.preheader ], [ 1, %for.inc ], [ 2, %for.inc.1 ], [ 3, %for.inc.2 ], [ 4, %for.inc.3 ], [ 5, %for.inc.4 ], [ 6, %for.inc.5 ], [ 7, %for.inc.6 ], [ 8, %for.inc.7 ], [ 9, %for.inc.8 ], [ 10, %for.inc.9 ], [ 11, %for.inc.10 ], [ 12, %for.inc.11 ], [ 13, %for.inc.12 ], [ 14, %for.inc.13 ], [ 15, %for.inc.14 ], [ 16, %for.inc.15 ], [ 17, %for.inc.16 ], [ %spec.select, %for.inc.17 ], !dbg !1358
  %call6 = tail call noalias dereferenceable_or_null(56) ptr @calloc(i64 noundef 1, i64 noundef 56) #24, !dbg !1359
  tail call void @llvm.dbg.value(metadata ptr %call6, metadata !1344, metadata !DIExpression()), !dbg !1345
  %cmp7 = icmp eq ptr %call6, null, !dbg !1360
  br i1 %cmp7, label %cleanup, label %if.end10, !dbg !1362

if.end10:                                         ; preds = %for.end
  store ptr %c, ptr %call6, align 8, !dbg !1363, !tbaa !1364
  %sfd12 = getelementptr inbounds i8, ptr %call6, i64 8, !dbg !1366
  store i32 %sfd, ptr %sfd12, align 8, !dbg !1367, !tbaa !1368
  %cmp13 = icmp ne i32 %sfd, 0, !dbg !1369
  %cmp14 = icmp ne ptr %c, null
  %or.cond.not = or i1 %cmp14, %cmp13, !dbg !1371
  %spec.select53 = zext i1 %or.cond.not to i32, !dbg !1371
  %20 = getelementptr inbounds i8, ptr %call6, i64 36, !dbg !1372
  store i32 %spec.select53, ptr %20, align 4, !dbg !1372
  %id = getelementptr inbounds i8, ptr %call6, i64 12, !dbg !1373
  store i32 %x.0.lcssa, ptr %id, align 4, !dbg !1374, !tbaa !1375
  %eflags = getelementptr inbounds i8, ptr %call6, i64 40, !dbg !1376
  store i16 %f, ptr %eflags, align 8, !dbg !1377, !tbaa !1378
  %21 = atomicrmw add ptr @logger_gid, i64 1 seq_cst, align 8, !dbg !1379
  %22 = add i64 %21, 1, !dbg !1379
  %min_gid = getelementptr inbounds i8, ptr %call6, i64 24, !dbg !1381
  store i64 %22, ptr %min_gid, align 8, !dbg !1382, !tbaa !1383
  %23 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 50), align 8, !dbg !1384, !tbaa !1385
  %call19 = tail call ptr @bipbuf_new(i32 noundef %23) #21, !dbg !1386
  %buf = getelementptr inbounds i8, ptr %call6, i64 48, !dbg !1387
  store ptr %call19, ptr %buf, align 8, !dbg !1388, !tbaa !1389
  %cmp21 = icmp eq ptr %call19, null, !dbg !1390
  br i1 %cmp21, label %if.then22, label %if.end24, !dbg !1392

if.then22:                                        ; preds = %if.end10
  tail call void @free(ptr noundef nonnull %call6) #21, !dbg !1393
  br label %cleanup, !dbg !1395

if.end24:                                         ; preds = %if.end10
  %call26 = tail call i32 @bipbuf_offer(ptr noundef nonnull %call19, ptr noundef nonnull @.str.1, i32 noundef 4) #21, !dbg !1396
  %idxprom27 = zext nneg i32 %x.0.lcssa to i64, !dbg !1397
  %arrayidx28 = getelementptr inbounds [20 x ptr], ptr @watchers, i64 0, i64 %idxprom27, !dbg !1397
  store ptr %call6, ptr %arrayidx28, align 8, !dbg !1398, !tbaa !1039
  %24 = load i32, ptr @watcher_count, align 4, !dbg !1399, !tbaa !1053
  %inc29 = add nsw i32 %24, 1, !dbg !1399
  store i32 %inc29, ptr @watcher_count, align 4, !dbg !1399, !tbaa !1053
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1400, metadata !DIExpression()), !dbg !1409
  tail call void @llvm.dbg.value(metadata i16 0, metadata !1404, metadata !DIExpression()), !dbg !1409
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1403, metadata !DIExpression()), !dbg !1409
  br label %for.body.i, !dbg !1411

for.cond4.preheader.i:                            ; preds = %cleanup.i.1
  %l.027.i = load ptr, ptr @logger_stack_head, align 8, !dbg !1412, !tbaa !1039
  %cmp5.not28.i = icmp eq ptr %l.027.i, null, !dbg !1414
  br i1 %cmp5.not28.i, label %logger_set_flags.exit, label %for.body7.i, !dbg !1416

for.body.i:                                       ; preds = %cleanup.i.1, %if.end24
  %indvars.iv.i = phi i64 [ 0, %if.end24 ], [ %indvars.iv.next.i.1, %cleanup.i.1 ]
  %f.026.i = phi i16 [ 0, %if.end24 ], [ %f.1.i.1, %cleanup.i.1 ]
  tail call void @llvm.dbg.value(metadata i16 %f.026.i, metadata !1404, metadata !DIExpression()), !dbg !1409
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i, metadata !1403, metadata !DIExpression()), !dbg !1409
  %arrayidx.i = getelementptr inbounds [20 x ptr], ptr @watchers, i64 0, i64 %indvars.iv.i, !dbg !1417
  %25 = load ptr, ptr %arrayidx.i, align 16, !dbg !1417, !tbaa !1039
  tail call void @llvm.dbg.value(metadata ptr %25, metadata !1405, metadata !DIExpression()), !dbg !1418
  %cmp1.i = icmp eq ptr %25, null, !dbg !1419
  br i1 %cmp1.i, label %cleanup.i, label %if.end.i, !dbg !1421

if.end.i:                                         ; preds = %for.body.i
  %eflags.i = getelementptr inbounds i8, ptr %25, i64 40, !dbg !1422
  %26 = load i16, ptr %eflags.i, align 8, !dbg !1422, !tbaa !1378
  %or24.i = or i16 %26, %f.026.i, !dbg !1423
  tail call void @llvm.dbg.value(metadata i16 %or24.i, metadata !1404, metadata !DIExpression()), !dbg !1409
  br label %cleanup.i, !dbg !1424

cleanup.i:                                        ; preds = %if.end.i, %for.body.i
  %f.1.i = phi i16 [ %or24.i, %if.end.i ], [ %f.026.i, %for.body.i ], !dbg !1409
  tail call void @llvm.dbg.value(metadata i16 %f.1.i, metadata !1404, metadata !DIExpression()), !dbg !1409
  %indvars.iv.next.i = or disjoint i64 %indvars.iv.i, 1, !dbg !1425
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !1403, metadata !DIExpression()), !dbg !1409
  tail call void @llvm.dbg.value(metadata i16 %f.1.i, metadata !1404, metadata !DIExpression()), !dbg !1409
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !1403, metadata !DIExpression()), !dbg !1409
  %arrayidx.i.1 = getelementptr inbounds [20 x ptr], ptr @watchers, i64 0, i64 %indvars.iv.next.i, !dbg !1417
  %27 = load ptr, ptr %arrayidx.i.1, align 8, !dbg !1417, !tbaa !1039
  tail call void @llvm.dbg.value(metadata ptr %27, metadata !1405, metadata !DIExpression()), !dbg !1418
  %cmp1.i.1 = icmp eq ptr %27, null, !dbg !1419
  br i1 %cmp1.i.1, label %cleanup.i.1, label %if.end.i.1, !dbg !1421

if.end.i.1:                                       ; preds = %cleanup.i
  %eflags.i.1 = getelementptr inbounds i8, ptr %27, i64 40, !dbg !1422
  %28 = load i16, ptr %eflags.i.1, align 8, !dbg !1422, !tbaa !1378
  %or24.i.1 = or i16 %28, %f.1.i, !dbg !1423
  tail call void @llvm.dbg.value(metadata i16 %or24.i.1, metadata !1404, metadata !DIExpression()), !dbg !1409
  br label %cleanup.i.1, !dbg !1424

cleanup.i.1:                                      ; preds = %if.end.i.1, %cleanup.i
  %f.1.i.1 = phi i16 [ %or24.i.1, %if.end.i.1 ], [ %f.1.i, %cleanup.i ], !dbg !1409
  tail call void @llvm.dbg.value(metadata i16 %f.1.i.1, metadata !1404, metadata !DIExpression()), !dbg !1409
  %indvars.iv.next.i.1 = add nuw nsw i64 %indvars.iv.i, 2, !dbg !1425
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.1, metadata !1403, metadata !DIExpression()), !dbg !1409
  %exitcond.not.i.1 = icmp eq i64 %indvars.iv.next.i.1, 20, !dbg !1426
  br i1 %exitcond.not.i.1, label %for.cond4.preheader.i, label %for.body.i, !dbg !1411, !llvm.loop !1427

for.body7.i:                                      ; preds = %for.cond4.preheader.i, %for.body7.i
  %l.029.i = phi ptr [ %l.0.i, %for.body7.i ], [ %l.027.i, %for.cond4.preheader.i ]
  %mutex.i = getelementptr inbounds i8, ptr %l.029.i, i64 16, !dbg !1430
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %mutex.i) #21, !dbg !1432
  %eflags8.i = getelementptr inbounds i8, ptr %l.029.i, i64 84, !dbg !1433
  store i16 %f.1.i.1, ptr %eflags8.i, align 4, !dbg !1434, !tbaa !1435
  %call10.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %mutex.i) #21, !dbg !1436
  %next.i = getelementptr inbounds i8, ptr %l.029.i, i64 8, !dbg !1437
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1400, metadata !DIExpression()), !dbg !1409
  %l.0.i = load ptr, ptr %next.i, align 8, !dbg !1412, !tbaa !1039
  tail call void @llvm.dbg.value(metadata ptr %l.0.i, metadata !1400, metadata !DIExpression()), !dbg !1409
  %cmp5.not.i = icmp eq ptr %l.0.i, null, !dbg !1414
  br i1 %cmp5.not.i, label %logger_set_flags.exit, label %for.body7.i, !dbg !1416, !llvm.loop !1438

logger_set_flags.exit:                            ; preds = %for.body7.i, %for.cond4.preheader.i
  %call30 = tail call i32 @pthread_cond_signal(ptr noundef nonnull @logger_stack_cond) #21, !dbg !1440
  br label %cleanup, !dbg !1441

cleanup:                                          ; preds = %for.end, %entry, %logger_set_flags.exit, %if.then22
  %retval.0 = phi i32 [ 2, %if.then22 ], [ 1, %logger_set_flags.exit ], [ 0, %entry ], [ 2, %for.end ], !dbg !1345
  %call31 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @logger_stack_lock) #21, !dbg !1345
  ret i32 %retval.0, !dbg !1442
}

declare !dbg !1443 i32 @bipbuf_offer(ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #6

; Function Attrs: nounwind
declare !dbg !1448 i32 @pthread_cond_signal(ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind
declare !dbg !1452 i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind sanitize_thread uwtable
define internal noundef ptr @logger_thread(ptr nocapture readnone %arg) #1 !dbg !1471 {
entry:
  %size.i = alloca i32, align 4, !DIAssignID !1489
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1490, metadata !DIExpression(), metadata !1489, metadata ptr %size.i, metadata !DIExpression()), !dbg !1508
  %scratch.i = alloca [4096 x i8], align 16, !DIAssignID !1513
  %ls.sroa.9 = alloca i64, align 8, !DIAssignID !1514
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64), metadata !1514, metadata ptr %ls.sroa.9, metadata !DIExpression()), !dbg !1515
  %ls.sroa.12 = alloca i64, align 8, !DIAssignID !1516
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64), metadata !1516, metadata ptr %ls.sroa.12, metadata !DIExpression()), !dbg !1515
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1473, metadata !DIExpression()), !dbg !1517
  tail call void @llvm.dbg.value(metadata i32 1000, metadata !1474, metadata !DIExpression()), !dbg !1517
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1515
  %0 = load volatile i32, ptr @do_run_logger_thread, align 4, !dbg !1518, !tbaa !1053
  %tobool.not56 = icmp eq i32 %0, 0, !dbg !1519
  br i1 %tobool.not56, label %while.end, label %while.body, !dbg !1519

while.body:                                       ; preds = %entry, %if.end26
  %to_sleep.057 = phi i32 [ %to_sleep.2, %if.end26 ], [ 1000, %entry ]
  tail call void @llvm.dbg.value(metadata i32 %to_sleep.057, metadata !1474, metadata !DIExpression()), !dbg !1517
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1478, metadata !DIExpression()), !dbg !1515
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %ls.sroa.9), !dbg !1520
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %ls.sroa.12), !dbg !1520
  store i64 0, ptr %ls.sroa.9, align 8, !dbg !1521, !DIAssignID !1522
  store i64 0, ptr %ls.sroa.12, align 8, !dbg !1521, !DIAssignID !1523
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1515
  tail call void @llvm.dbg.assign(metadata i64 0, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64), metadata !1522, metadata ptr %ls.sroa.9, metadata !DIExpression()), !dbg !1515
  tail call void @llvm.dbg.assign(metadata i64 0, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64), metadata !1523, metadata ptr %ls.sroa.12, metadata !DIExpression()), !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !1515
  %cmp = icmp ugt i32 %to_sleep.057, 1000, !dbg !1524
  br i1 %cmp, label %if.then, label %if.end, !dbg !1526

if.then:                                          ; preds = %while.body
  %call = call i32 @usleep(i32 noundef %to_sleep.057) #21, !dbg !1527
  br label %if.end, !dbg !1527

if.end:                                           ; preds = %if.then, %while.body
  %call1 = call i32 @pthread_mutex_lock(ptr noundef nonnull @logger_stack_lock) #21, !dbg !1528
  %1 = load i32, ptr @watcher_count, align 4, !dbg !1529, !tbaa !1053
  %cmp2 = icmp eq i32 %1, 0, !dbg !1531
  br i1 %cmp2, label %if.then3, label %if.end5, !dbg !1532

if.then3:                                         ; preds = %if.end
  %call4 = call i32 @pthread_cond_wait(ptr noundef nonnull @logger_stack_cond, ptr noundef nonnull @logger_stack_lock) #21, !dbg !1533
  br label %if.end5, !dbg !1535

if.end5:                                          ; preds = %if.then3, %if.end
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1480, metadata !DIExpression()), !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1515
  %l.048 = load ptr, ptr @logger_stack_head, align 8, !dbg !1536, !tbaa !1039
  %cmp6.not49 = icmp eq ptr %l.048, null, !dbg !1537
  br i1 %cmp6.not49, label %for.end, label %for.body, !dbg !1538

for.body:                                         ; preds = %if.end5, %logger_thread_read.exit
  %l.053 = phi ptr [ %l.0, %logger_thread_read.exit ], [ %l.048, %if.end5 ]
  %found_logs.052 = phi i32 [ %add, %logger_thread_read.exit ], [ 0, %if.end5 ]
  %2 = phi <2 x i64> [ %38, %logger_thread_read.exit ], [ zeroinitializer, %if.end5 ]
  tail call void @llvm.dbg.value(metadata i32 %found_logs.052, metadata !1478, metadata !DIExpression()), !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1515
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1500, metadata !DIExpression(), metadata !1513, metadata ptr %scratch.i, metadata !DIExpression()), !dbg !1508
  tail call void @llvm.dbg.value(metadata ptr %l.053, metadata !1496, metadata !DIExpression()), !dbg !1508
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !1497, metadata !DIExpression()), !dbg !1508
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %size.i) #21, !dbg !1539
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1498, metadata !DIExpression()), !dbg !1508
  call void @llvm.lifetime.start.p0(i64 4096, ptr nonnull %scratch.i) #21, !dbg !1540
  %mutex.i = getelementptr inbounds i8, ptr %l.053, i64 16, !dbg !1541
  %call.i = call i32 @pthread_mutex_lock(ptr noundef nonnull %mutex.i) #21, !dbg !1542
  %buf.i = getelementptr inbounds i8, ptr %l.053, i64 88, !dbg !1543
  %3 = load ptr, ptr %buf.i, align 8, !dbg !1543, !tbaa !1109
  %call1.i = call ptr @bipbuf_peek_all(ptr noundef %3, ptr noundef nonnull %size.i) #21, !dbg !1544
  tail call void @llvm.dbg.value(metadata ptr %call1.i, metadata !1499, metadata !DIExpression()), !dbg !1508
  %call3.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull %mutex.i) #21, !dbg !1545
  %cmp.i = icmp eq ptr %call1.i, null, !dbg !1546
  br i1 %cmp.i, label %logger_thread_read.exit, label %while.cond.preheader.i, !dbg !1548

while.cond.preheader.i:                           ; preds = %for.body
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1498, metadata !DIExpression()), !dbg !1508
  %4 = load i32, ptr %size.i, align 4, !dbg !1549, !tbaa !1053
  %cmp464.not.i = icmp eq i32 %4, 0, !dbg !1550
  br i1 %cmp464.not.i, label %while.end.i, label %land.rhs.i, !dbg !1551

land.rhs.i:                                       ; preds = %while.cond.preheader.i, %if.end11.i
  %pos.065.i = phi i32 [ %add16.i, %if.end11.i ], [ 0, %while.cond.preheader.i ]
  tail call void @llvm.dbg.value(metadata i32 %pos.065.i, metadata !1498, metadata !DIExpression()), !dbg !1508
  %5 = load i32, ptr @watcher_count, align 4, !dbg !1552, !tbaa !1053
  %cmp5.i = icmp sgt i32 %5, 0, !dbg !1553
  br i1 %cmp5.i, label %while.body.i, label %while.end.i, !dbg !1554

while.body.i:                                     ; preds = %land.rhs.i
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1507, metadata !DIExpression()), !dbg !1555
  %idx.ext.i = zext i32 %pos.065.i to i64, !dbg !1556
  %add.ptr.i = getelementptr inbounds i8, ptr %call1.i, i64 %idx.ext.i, !dbg !1556
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !1504, metadata !DIExpression()), !dbg !1508
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !1557, metadata !DIExpression()), !dbg !1568
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !1563, metadata !DIExpression()), !dbg !1568
  tail call void @llvm.dbg.value(metadata ptr %scratch.i, metadata !1564, metadata !DIExpression()), !dbg !1568
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !1565, metadata !DIExpression()), !dbg !1568
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1566, metadata !DIExpression()), !dbg !1568
  %6 = load i32, ptr %add.ptr.i, align 8, !dbg !1570, !tbaa !1053
  %idxprom.i.i = zext i32 %6 to i64, !dbg !1571
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr @default_entries, i64 %idxprom.i.i), metadata !1567, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 32, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !1568
  %parse_cb.i.i = getelementptr inbounds [16 x %struct._entry_details], ptr @default_entries, i64 0, i64 %idxprom.i.i, i32 3, !dbg !1572
  %7 = load ptr, ptr %parse_cb.i.i, align 16, !dbg !1572, !tbaa !1573
  %call.i.i = call i32 %7(ptr noundef nonnull %add.ptr.i, ptr noundef nonnull %scratch.i) #21, !dbg !1574
  tail call void @llvm.dbg.value(metadata i32 %call.i.i, metadata !1566, metadata !DIExpression()), !dbg !1568
  %8 = add i32 %call.i.i, -4096, !dbg !1575
  %or.cond.i.i = icmp ult i32 %8, -4095, !dbg !1575
  br i1 %or.cond.i.i, label %if.then8.i, label %if.else.i, !dbg !1575

if.then8.i:                                       ; preds = %while.body.i
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1507, metadata !DIExpression()), !dbg !1555
  tail call void @llvm.dbg.value(metadata i32 2, metadata !1505, metadata !DIExpression()), !dbg !1555
  %9 = load ptr, ptr @stderr, align 8, !dbg !1577, !tbaa !1039
  %10 = call i64 @fwrite(ptr nonnull @.str.4, i64 34, i64 1, ptr %9) #25, !dbg !1580
  br label %if.end11.i, !dbg !1581

if.else.i:                                        ; preds = %while.body.i
  tail call void @llvm.dbg.value(metadata i32 %call.i.i, metadata !1507, metadata !DIExpression()), !dbg !1555
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1505, metadata !DIExpression()), !dbg !1555
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i, metadata !1582, metadata !DIExpression()), !dbg !1597
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !1587, metadata !DIExpression()), !dbg !1597
  tail call void @llvm.dbg.value(metadata ptr %scratch.i, metadata !1588, metadata !DIExpression()), !dbg !1597
  tail call void @llvm.dbg.value(metadata i32 %call.i.i, metadata !1589, metadata !DIExpression()), !dbg !1597
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1590, metadata !DIExpression()), !dbg !1597
  %eflags.i.i = getelementptr inbounds i8, ptr %add.ptr.i, i64 6
  %gid.i.i = getelementptr inbounds i8, ptr %add.ptr.i, i64 8
  %add.i.i = add nuw nsw i32 %call.i.i, 128
  br label %for.body.i.i, !dbg !1600

for.body.i.i:                                     ; preds = %cleanup.i.i, %if.else.i
  %indvars.iv.i.i = phi i64 [ 0, %if.else.i ], [ %indvars.iv.next.i.i, %cleanup.i.i ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i.i, metadata !1590, metadata !DIExpression()), !dbg !1597
  %arrayidx.i.i = getelementptr inbounds [20 x ptr], ptr @watchers, i64 0, i64 %indvars.iv.i.i, !dbg !1601
  %11 = load ptr, ptr %arrayidx.i.i, align 8, !dbg !1601, !tbaa !1039
  tail call void @llvm.dbg.value(metadata ptr %11, metadata !1592, metadata !DIExpression()), !dbg !1602
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1596, metadata !DIExpression()), !dbg !1602
  %cmp1.i.i = icmp eq ptr %11, null, !dbg !1603
  br i1 %cmp1.i.i, label %cleanup.i.i, label %lor.lhs.false.i.i, !dbg !1605

lor.lhs.false.i.i:                                ; preds = %for.body.i.i
  %12 = load i16, ptr %eflags.i.i, align 2, !dbg !1606, !tbaa !1231
  %eflags2.i.i = getelementptr inbounds i8, ptr %11, i64 40, !dbg !1607
  %13 = load i16, ptr %eflags2.i.i, align 8, !dbg !1607, !tbaa !1378
  %and71.i.i = and i16 %13, %12, !dbg !1608
  %cmp4.i.i = icmp eq i16 %and71.i.i, 0, !dbg !1609
  br i1 %cmp4.i.i, label %cleanup.i.i, label %lor.lhs.false6.i.i, !dbg !1610

lor.lhs.false6.i.i:                               ; preds = %lor.lhs.false.i.i
  %14 = load i64, ptr %gid.i.i, align 8, !dbg !1611, !tbaa !1067
  %min_gid.i.i = getelementptr inbounds i8, ptr %11, i64 24, !dbg !1612
  %15 = load i64, ptr %min_gid.i.i, align 8, !dbg !1612, !tbaa !1383
  %cmp7.i.i = icmp ult i64 %14, %15, !dbg !1613
  br i1 %cmp7.i.i, label %cleanup.i.i, label %while.cond.preheader.i.i, !dbg !1614

while.cond.preheader.i.i:                         ; preds = %lor.lhs.false6.i.i
  %buf.i.i = getelementptr inbounds i8, ptr %11, i64 48, !dbg !1615
  %failed_flush.i.i = getelementptr inbounds i8, ptr %11, i64 32
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1596, metadata !DIExpression()), !dbg !1602
  %16 = load i8, ptr %failed_flush.i.i, align 8, !dbg !1616, !tbaa !1617, !range !1618, !noundef !1619
  %tobool72.i.i = trunc nuw i8 %16 to i1, !dbg !1616
  br i1 %tobool72.i.i, label %while.end.i.i, label %land.rhs.preheader.i.i, !dbg !1620

land.rhs.preheader.i.i:                           ; preds = %while.cond.preheader.i.i
  %17 = trunc nuw nsw i64 %indvars.iv.i.i to i32
  br label %land.rhs.i.i, !dbg !1621

land.rhs.i.i:                                     ; preds = %if.end16.i.i, %land.rhs.preheader.i.i
  %18 = load ptr, ptr %buf.i.i, align 8, !dbg !1615, !tbaa !1389
  %call.i56.i = call ptr @bipbuf_request(ptr noundef %18, i32 noundef %add.i.i) #21, !dbg !1622
  tail call void @llvm.dbg.value(metadata ptr %call.i56.i, metadata !1596, metadata !DIExpression()), !dbg !1602
  %cmp9.i.i = icmp eq ptr %call.i56.i, null, !dbg !1623
  br i1 %cmp9.i.i, label %while.body.i.i, label %land.rhs.while.end.loopexit_crit_edge.i.i, !dbg !1621

land.rhs.while.end.loopexit_crit_edge.i.i:        ; preds = %land.rhs.i.i
  %.pre78.pre.i.i = load i8, ptr %failed_flush.i.i, align 8, !dbg !1624, !tbaa !1617, !range !1618
  br label %while.end.i.i, !dbg !1621

while.body.i.i:                                   ; preds = %land.rhs.i.i
  %call11.i.i = call fastcc i32 @logger_thread_poll_watchers(i32 noundef 0, i32 noundef %17), !dbg !1626
  %cmp12.i.i = icmp slt i32 %call11.i.i, 1, !dbg !1629
  br i1 %cmp12.i.i, label %while.end.thread.i.i, label %if.end16.i.i, !dbg !1630

while.end.thread.i.i:                             ; preds = %while.body.i.i
  store i8 1, ptr %failed_flush.i.i, align 8, !dbg !1631, !tbaa !1617
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1596, metadata !DIExpression()), !dbg !1602
  br label %if.then19.i.i, !dbg !1633

if.end16.i.i:                                     ; preds = %while.body.i.i
  %.pre.i.i = load i8, ptr %failed_flush.i.i, align 8, !dbg !1616, !tbaa !1617, !range !1618
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1596, metadata !DIExpression()), !dbg !1602
  %tobool.i.i = trunc nuw i8 %.pre.i.i to i1, !dbg !1616
  br i1 %tobool.i.i, label %while.end.i.i, label %land.rhs.i.i, !dbg !1620, !llvm.loop !1634

while.end.i.i:                                    ; preds = %if.end16.i.i, %land.rhs.while.end.loopexit_crit_edge.i.i, %while.cond.preheader.i.i
  %19 = phi i8 [ %16, %while.cond.preheader.i.i ], [ %.pre78.pre.i.i, %land.rhs.while.end.loopexit_crit_edge.i.i ], [ %.pre.i.i, %if.end16.i.i ], !dbg !1624
  %skip_scr.1.i.i = phi ptr [ null, %while.cond.preheader.i.i ], [ %call.i56.i, %land.rhs.while.end.loopexit_crit_edge.i.i ], [ null, %if.end16.i.i ], !dbg !1602
  tail call void @llvm.dbg.value(metadata ptr %skip_scr.1.i.i, metadata !1596, metadata !DIExpression()), !dbg !1602
  %tobool18.i.i = trunc nuw i8 %19 to i1, !dbg !1624
  br i1 %tobool18.i.i, label %if.then19.i.i, label %if.end21.i.i, !dbg !1633

if.then19.i.i:                                    ; preds = %while.end.i.i, %while.end.thread.i.i
  %skipped.i.i = getelementptr inbounds i8, ptr %11, i64 16, !dbg !1636
  %20 = load i64, ptr %skipped.i.i, align 8, !dbg !1638, !tbaa !1639
  %inc.i.i = add i64 %20, 1, !dbg !1638
  store i64 %inc.i.i, ptr %skipped.i.i, align 8, !dbg !1638, !tbaa !1639
  br label %cleanup.sink.split.i.i, !dbg !1640

if.end21.i.i:                                     ; preds = %while.end.i.i
  %skipped22.i.i = getelementptr inbounds i8, ptr %11, i64 16, !dbg !1641
  %21 = load i64, ptr %skipped22.i.i, align 8, !dbg !1641, !tbaa !1639
  %cmp23.not.i.i = icmp eq i64 %21, 0, !dbg !1643
  br i1 %cmp23.not.i.i, label %if.end42.i.i, label %if.then25.i.i, !dbg !1644

if.then25.i.i:                                    ; preds = %if.end21.i.i
  %call27.i.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %skip_scr.1.i.i, i64 noundef 128, ptr noundef nonnull @.str.6, i64 noundef %21) #21, !dbg !1645
  tail call void @llvm.dbg.value(metadata i32 %call27.i.i, metadata !1591, metadata !DIExpression()), !dbg !1597
  %22 = add i32 %call27.i.i, -128, !dbg !1647
  %or.cond.i57.i = icmp ult i32 %22, -127, !dbg !1647
  br i1 %or.cond.i57.i, label %if.then33.i.i, label %if.end38.i.i, !dbg !1647

if.then33.i.i:                                    ; preds = %if.then25.i.i
  %23 = load i64, ptr %skipped22.i.i, align 8, !dbg !1649, !tbaa !1639
  %inc35.i.i = add i64 %23, 1, !dbg !1649
  store i64 %inc35.i.i, ptr %skipped22.i.i, align 8, !dbg !1649, !tbaa !1639
  br label %cleanup.sink.split.i.i, !dbg !1651

if.end38.i.i:                                     ; preds = %if.then25.i.i
  %24 = load ptr, ptr %buf.i.i, align 8, !dbg !1652, !tbaa !1389
  %call40.i.i = call i32 @bipbuf_push(ptr noundef %24, i32 noundef %call27.i.i) #21, !dbg !1653
  store i64 0, ptr %skipped22.i.i, align 8, !dbg !1654, !tbaa !1639
  br label %if.end42.i.i, !dbg !1655

if.end42.i.i:                                     ; preds = %if.end38.i.i, %if.end21.i.i
  %25 = load ptr, ptr %buf.i.i, align 8, !dbg !1656, !tbaa !1389
  %call44.i.i = call i32 @bipbuf_offer(ptr noundef %25, ptr noundef nonnull %scratch.i, i32 noundef %call.i.i) #21, !dbg !1657
  br label %cleanup.sink.split.i.i, !dbg !1658

cleanup.sink.split.i.i:                           ; preds = %if.end42.i.i, %if.then33.i.i, %if.then19.i.i
  %watcher_sent.sink85.i.i = phi ptr [ %ls.sroa.12, %if.end42.i.i ], [ %ls.sroa.9, %if.then33.i.i ], [ %ls.sroa.9, %if.then19.i.i ]
  %26 = load i64, ptr %watcher_sent.sink85.i.i, align 8, !dbg !1602, !tbaa !1067
  %inc45.i.i = add i64 %26, 1, !dbg !1602
  store i64 %inc45.i.i, ptr %watcher_sent.sink85.i.i, align 8, !dbg !1602, !tbaa !1067
  br label %cleanup.i.i, !dbg !1659

cleanup.i.i:                                      ; preds = %cleanup.sink.split.i.i, %lor.lhs.false6.i.i, %lor.lhs.false.i.i, %for.body.i.i
  %indvars.iv.next.i.i = add nuw nsw i64 %indvars.iv.i.i, 1, !dbg !1659
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.i, metadata !1590, metadata !DIExpression()), !dbg !1597
  %exitcond.not.i.i = icmp eq i64 %indvars.iv.next.i.i, 20, !dbg !1660
  br i1 %exitcond.not.i.i, label %if.end11.i, label %for.body.i.i, !dbg !1600, !llvm.loop !1661

if.end11.i:                                       ; preds = %cleanup.i.i, %if.then8.i
  %size12.i = getelementptr inbounds i8, ptr %add.ptr.i, i64 32, !dbg !1663
  %27 = load i32, ptr %size12.i, align 8, !dbg !1663, !tbaa !1053
  %pad.i = getelementptr inbounds i8, ptr %add.ptr.i, i64 4, !dbg !1664
  %28 = load i8, ptr %pad.i, align 4, !dbg !1664, !tbaa !1222
  %conv13.i = zext i8 %28 to i32, !dbg !1665
  %add.i = add i32 %pos.065.i, 40, !dbg !1666
  %add14.i = add i32 %add.i, %27, !dbg !1667
  %add16.i = add i32 %add14.i, %conv13.i, !dbg !1668
  tail call void @llvm.dbg.value(metadata i32 %add16.i, metadata !1498, metadata !DIExpression()), !dbg !1508
  %29 = load i32, ptr %size.i, align 4, !dbg !1549, !tbaa !1053
  %cmp4.i = icmp ult i32 %add16.i, %29, !dbg !1550
  br i1 %cmp4.i, label %land.rhs.i, label %while.end.i, !dbg !1551, !llvm.loop !1669

while.end.i:                                      ; preds = %if.end11.i, %land.rhs.i, %while.cond.preheader.i
  %call19.i = call i32 @pthread_mutex_lock(ptr noundef nonnull %mutex.i) #21, !dbg !1671
  %30 = load ptr, ptr %buf.i, align 8, !dbg !1672, !tbaa !1109
  %31 = load i32, ptr %size.i, align 4, !dbg !1673, !tbaa !1053
  %call21.i = call ptr @bipbuf_poll(ptr noundef %30, i32 noundef %31) #21, !dbg !1674
  tail call void @llvm.dbg.value(metadata ptr %call21.i, metadata !1499, metadata !DIExpression()), !dbg !1508
  %written.i = getelementptr inbounds i8, ptr %l.053, i64 56, !dbg !1675
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1515
  %32 = load <2 x i64>, ptr %written.i, align 8, !dbg !1675, !tbaa !1067
  %33 = shufflevector <2 x i64> %32, <2 x i64> poison, <2 x i32> <i32 1, i32 0>, !dbg !1675
  %34 = add <2 x i64> %33, %2, !dbg !1676
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1515
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %written.i, i8 0, i64 16, i1 false), !dbg !1677
  %call27.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull %mutex.i) #21, !dbg !1678
  %cmp28.i = icmp eq ptr %call21.i, null, !dbg !1679
  br i1 %cmp28.i, label %if.then30.i, label %if.end32.i, !dbg !1681

if.then30.i:                                      ; preds = %while.end.i
  %35 = load ptr, ptr @stderr, align 8, !dbg !1682, !tbaa !1039
  %36 = call i64 @fwrite(ptr nonnull @.str.5, i64 50, i64 1, ptr %35) #25, !dbg !1684
  br label %if.end32.i, !dbg !1685

if.end32.i:                                       ; preds = %if.then30.i, %while.end.i
  %37 = load i32, ptr %size.i, align 4, !dbg !1686, !tbaa !1053
  br label %logger_thread_read.exit, !dbg !1687

logger_thread_read.exit:                          ; preds = %for.body, %if.end32.i
  %retval.0.i = phi i32 [ 0, %for.body ], [ %37, %if.end32.i ], !dbg !1508
  %38 = phi <2 x i64> [ %2, %for.body ], [ %34, %if.end32.i ], !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1515
  call void @llvm.lifetime.end.p0(i64 4096, ptr nonnull %scratch.i) #21, !dbg !1688
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %size.i) #21, !dbg !1688
  %add = add nsw i32 %retval.0.i, %found_logs.052, !dbg !1689
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !1478, metadata !DIExpression()), !dbg !1515
  %next = getelementptr inbounds i8, ptr %l.053, i64 8, !dbg !1690
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1480, metadata !DIExpression()), !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1515
  %l.0 = load ptr, ptr %next, align 8, !dbg !1536, !tbaa !1039
  tail call void @llvm.dbg.value(metadata ptr %l.0, metadata !1480, metadata !DIExpression()), !dbg !1515
  %cmp6.not = icmp eq ptr %l.0, null, !dbg !1537
  br i1 %cmp6.not, label %for.end, label %for.body, !dbg !1538, !llvm.loop !1691

for.end:                                          ; preds = %logger_thread_read.exit, %if.end5
  %found_logs.0.lcssa = phi i32 [ 0, %if.end5 ], [ %add, %logger_thread_read.exit ], !dbg !1515
  %39 = phi <2 x i64> [ zeroinitializer, %if.end5 ], [ %38, %logger_thread_read.exit ], !dbg !1521
  %call8 = call fastcc i32 @logger_thread_poll_watchers(i32 noundef 1, i32 noundef -1), !dbg !1693
  %40 = load i32, ptr @watcher_count, align 4, !dbg !1694, !tbaa !1053
  tail call void @llvm.dbg.value(metadata i32 %40, metadata !1481, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_signed, DW_OP_LLVM_convert, 64, DW_ATE_signed, DW_OP_stack_value, DW_OP_LLVM_fragment, 256, 64)), !dbg !1515
  %call9 = call i32 @pthread_mutex_unlock(ptr noundef nonnull @logger_stack_lock) #21, !dbg !1695
  %tobool10.not = icmp eq i32 %found_logs.0.lcssa, 0, !dbg !1696
  br i1 %tobool10.not, label %if.then11, label %if.else, !dbg !1698

if.then11:                                        ; preds = %for.end
  %cmp12 = icmp ult i32 %to_sleep.057, 1000000, !dbg !1699
  %div38 = lshr i32 %to_sleep.057, 3, !dbg !1702
  %add15 = select i1 %cmp12, i32 %div38, i32 0, !dbg !1702
  %to_sleep.1 = add nuw nsw i32 %add15, %to_sleep.057, !dbg !1702
  tail call void @llvm.dbg.value(metadata i32 %to_sleep.1, metadata !1474, metadata !DIExpression()), !dbg !1517
  %spec.store.select = call i32 @llvm.umin.i32(i32 %to_sleep.1, i32 1000000), !dbg !1703
  tail call void @llvm.dbg.value(metadata i32 %spec.store.select, metadata !1474, metadata !DIExpression()), !dbg !1517
  br label %if.end26, !dbg !1704

if.else:                                          ; preds = %for.end
  %div2139 = lshr i32 %to_sleep.057, 1, !dbg !1705
  tail call void @llvm.dbg.value(metadata i32 %div2139, metadata !1474, metadata !DIExpression()), !dbg !1517
  %spec.store.select27 = call i32 @llvm.umax.i32(i32 %div2139, i32 1000), !dbg !1707
  tail call void @llvm.dbg.value(metadata i32 %spec.store.select27, metadata !1474, metadata !DIExpression()), !dbg !1517
  br label %if.end26

if.end26:                                         ; preds = %if.else, %if.then11
  %to_sleep.2 = phi i32 [ %spec.store.select27, %if.else ], [ %spec.store.select, %if.then11 ], !dbg !1708
  tail call void @llvm.dbg.value(metadata i32 %to_sleep.2, metadata !1474, metadata !DIExpression()), !dbg !1517
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !1709, metadata !DIExpression()), !dbg !1714
  call void @STATS_LOCK() #21, !dbg !1716
  %41 = load <2 x i64>, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 15), align 8, !dbg !1717, !tbaa !1067
  %42 = add <2 x i64> %41, %39, !dbg !1717
  store <2 x i64> %42, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 15), align 8, !dbg !1717, !tbaa !1067
  %ls.sroa.9.0.ls.sroa.9.0.ls.sroa.9.0.ls.sroa.9.16. = load i64, ptr %ls.sroa.9, align 8, !dbg !1718, !tbaa !1719
  %43 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 17), align 8, !dbg !1721, !tbaa !1722
  %add2.i = add i64 %43, %ls.sroa.9.0.ls.sroa.9.0.ls.sroa.9.0.ls.sroa.9.16., !dbg !1721
  store i64 %add2.i, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 17), align 8, !dbg !1721, !tbaa !1722
  %ls.sroa.12.0.ls.sroa.12.0.ls.sroa.12.0.ls.sroa.12.24. = load i64, ptr %ls.sroa.12, align 8, !dbg !1725, !tbaa !1726
  %44 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 18), align 8, !dbg !1727, !tbaa !1728
  %add3.i = add i64 %44, %ls.sroa.12.0.ls.sroa.12.0.ls.sroa.12.0.ls.sroa.12.24., !dbg !1727
  store i64 %add3.i, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 18), align 8, !dbg !1727, !tbaa !1728
  store i32 %40, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 7), align 4, !dbg !1729, !tbaa !1730
  call void @STATS_UNLOCK() #21, !dbg !1732
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %ls.sroa.9), !dbg !1733
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %ls.sroa.12), !dbg !1733
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !1481, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1515
  %45 = load volatile i32, ptr @do_run_logger_thread, align 4, !dbg !1518, !tbaa !1053
  %tobool.not = icmp eq i32 %45, 0, !dbg !1519
  br i1 %tobool.not, label %while.end, label %while.body, !dbg !1519, !llvm.loop !1734

while.end:                                        ; preds = %if.end26, %entry
  ret ptr null, !dbg !1735
}

; Function Attrs: nounwind
declare !dbg !1736 ptr @strerror(i32 noundef) local_unnamed_addr #2

declare !dbg !1740 void @thread_setname(i64 noundef, ptr noundef) local_unnamed_addr #6

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #10

declare !dbg !1743 i32 @usleep(i32 noundef) local_unnamed_addr #6

declare !dbg !1746 i32 @pthread_cond_wait(ptr noundef, ptr noundef) local_unnamed_addr #6

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc i32 @logger_thread_poll_watchers(i32 noundef %force_poll, i32 noundef %watcher) unnamed_addr #1 !dbg !1751 {
entry:
  %data_size = alloca i32, align 4, !DIAssignID !1781
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !1781, metadata ptr %data_size, metadata !DIExpression()), !dbg !1782
  %buf52 = alloca [1 x i8], align 1, !DIAssignID !1783
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !1783, metadata ptr %buf52, metadata !DIExpression()), !dbg !1784
  tail call void @llvm.dbg.value(metadata i32 %force_poll, metadata !1755, metadata !DIExpression()), !dbg !1782
  tail call void @llvm.dbg.value(metadata i32 %watcher, metadata !1756, metadata !DIExpression()), !dbg !1782
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1758, metadata !DIExpression()), !dbg !1782
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %data_size) #21, !dbg !1785
  store i32 0, ptr %data_size, align 4, !dbg !1786, !tbaa !1053, !DIAssignID !1787
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !1760, metadata !DIExpression(), metadata !1787, metadata ptr %data_size, metadata !DIExpression()), !dbg !1782
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1761, metadata !DIExpression()), !dbg !1782
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1757, metadata !DIExpression()), !dbg !1782
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1758, metadata !DIExpression()), !dbg !1782
  %cmp2.not = icmp eq i32 %watcher, -1
  %tobool.not = icmp eq i32 %force_poll, 0
  %0 = zext i32 %watcher to i64, !dbg !1788
  br label %for.body, !dbg !1788

for.body:                                         ; preds = %entry, %cleanup
  %indvars.iv = phi i64 [ 0, %entry ], [ %indvars.iv.next, %cleanup ]
  %nfd.0192 = phi i32 [ 0, %entry ], [ %nfd.2, %cleanup ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !1757, metadata !DIExpression()), !dbg !1782
  tail call void @llvm.dbg.value(metadata i32 %nfd.0192, metadata !1758, metadata !DIExpression()), !dbg !1782
  %arrayidx = getelementptr inbounds [20 x ptr], ptr @watchers, i64 0, i64 %indvars.iv, !dbg !1789
  %1 = load ptr, ptr %arrayidx, align 8, !dbg !1789, !tbaa !1039
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !1762, metadata !DIExpression()), !dbg !1790
  %cmp1 = icmp ne ptr %1, null, !dbg !1791
  %cmp3.not = icmp eq i64 %indvars.iv, %0
  %or.cond = or i1 %cmp2.not, %cmp3.not
  %or.cond197 = and i1 %cmp1, %or.cond, !dbg !1793
  br i1 %or.cond197, label %if.end, label %cleanup, !dbg !1793

if.end:                                           ; preds = %for.body
  %buf = getelementptr inbounds i8, ptr %1, i64 48, !dbg !1794
  %2 = load ptr, ptr %buf, align 8, !dbg !1794, !tbaa !1389
  %call = call ptr @bipbuf_peek_all(ptr noundef %2, ptr noundef nonnull %data_size) #21, !dbg !1795
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !1759, metadata !DIExpression()), !dbg !1782
  %cmp4.not = icmp eq ptr %call, null, !dbg !1796
  %cmp4.not.not = xor i1 %cmp4.not, true, !dbg !1798
  %tobool.not.not = xor i1 %tobool.not, true, !dbg !1798
  %brmerge = or i1 %cmp4.not.not, %tobool.not.not, !dbg !1798
  %.mux = select i1 %cmp4.not.not, i16 4, i16 1, !dbg !1798
  br i1 %brmerge, label %if.end20.sink.split, label %if.end20, !dbg !1798

if.end20.sink.split:                              ; preds = %if.end
  %idxprom6.sink = sext i32 %nfd.0192 to i64, !dbg !1799
  %.sink205.in = getelementptr inbounds i8, ptr %1, i64 8, !dbg !1799
  %.sink205 = load i32, ptr %.sink205.in, align 8, !dbg !1799, !tbaa !1368
  %arrayidx7 = getelementptr inbounds [20 x %struct.pollfd], ptr @watchers_pollfds, i64 0, i64 %idxprom6.sink, !dbg !1799
  store i32 %.sink205, ptr %arrayidx7, align 8, !dbg !1799, !tbaa !1800
  %events17 = getelementptr inbounds [20 x %struct.pollfd], ptr @watchers_pollfds, i64 0, i64 %idxprom6.sink, i32 1, !dbg !1799
  store i16 %.mux, ptr %events17, align 4, !dbg !1799, !tbaa !1802
  %inc18 = add nsw i32 %nfd.0192, 1, !dbg !1799
  br label %if.end20, !dbg !1803

if.end20:                                         ; preds = %if.end, %if.end20.sink.split
  %nfd.1 = phi i32 [ %inc18, %if.end20.sink.split ], [ %nfd.0192, %if.end ], !dbg !1782
  tail call void @llvm.dbg.value(metadata i32 %nfd.1, metadata !1758, metadata !DIExpression()), !dbg !1782
  %failed_flush = getelementptr inbounds i8, ptr %1, i64 32, !dbg !1803
  store i8 0, ptr %failed_flush, align 8, !dbg !1804, !tbaa !1617
  br label %cleanup, !dbg !1805

cleanup:                                          ; preds = %for.body, %if.end20
  %nfd.2 = phi i32 [ %nfd.1, %if.end20 ], [ %nfd.0192, %for.body ], !dbg !1782
  tail call void @llvm.dbg.value(metadata i32 %nfd.2, metadata !1758, metadata !DIExpression()), !dbg !1782
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !1806
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !1757, metadata !DIExpression()), !dbg !1782
  %exitcond.not = icmp eq i64 %indvars.iv.next, 20, !dbg !1807
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !1788, !llvm.loop !1808

for.end:                                          ; preds = %cleanup
  %cmp22 = icmp eq i32 %nfd.2, 0, !dbg !1810
  br i1 %cmp22, label %cleanup138, label %if.end24, !dbg !1812

if.end24:                                         ; preds = %for.end
  %conv = sext i32 %nfd.2 to i64, !dbg !1813
  %call25 = call i32 @poll(ptr noundef nonnull @watchers_pollfds, i64 noundef %conv, i32 noundef 0) #21, !dbg !1814
  tail call void @llvm.dbg.value(metadata i32 %call25, metadata !1766, metadata !DIExpression()), !dbg !1782
  %cmp26 = icmp slt i32 %call25, 0, !dbg !1815
  br i1 %cmp26, label %if.then28, label %for.body33, !dbg !1817

if.then28:                                        ; preds = %if.end24
  call void @perror(ptr noundef nonnull @.str.7) #25, !dbg !1818
  br label %cleanup138, !dbg !1820

for.body33:                                       ; preds = %if.end24, %cleanup131
  %indvars.iv200 = phi i64 [ %indvars.iv.next201, %cleanup131 ], [ 0, %if.end24 ]
  %nfd.3195 = phi i32 [ %nfd.6, %cleanup131 ], [ 0, %if.end24 ]
  %flushed.0194 = phi i32 [ %flushed.3, %cleanup131 ], [ 0, %if.end24 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv200, metadata !1757, metadata !DIExpression()), !dbg !1782
  tail call void @llvm.dbg.value(metadata i32 %nfd.3195, metadata !1758, metadata !DIExpression()), !dbg !1782
  tail call void @llvm.dbg.value(metadata i32 %flushed.0194, metadata !1761, metadata !DIExpression()), !dbg !1782
  %arrayidx36 = getelementptr inbounds [20 x ptr], ptr @watchers, i64 0, i64 %indvars.iv200, !dbg !1821
  %3 = load ptr, ptr %arrayidx36, align 8, !dbg !1821, !tbaa !1039
  tail call void @llvm.dbg.value(metadata ptr %3, metadata !1767, metadata !DIExpression()), !dbg !1822
  %cmp37 = icmp ne ptr %3, null, !dbg !1823
  %cmp43.not = icmp eq i64 %indvars.iv200, %0
  %or.cond188 = or i1 %cmp2.not, %cmp43.not
  %or.cond198 = and i1 %cmp37, %or.cond188, !dbg !1825
  br i1 %or.cond198, label %if.end46, label %cleanup131, !dbg !1825

if.end46:                                         ; preds = %for.body33
  store i32 0, ptr %data_size, align 4, !dbg !1826, !tbaa !1053, !DIAssignID !1827
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !1760, metadata !DIExpression(), metadata !1827, metadata ptr %data_size, metadata !DIExpression()), !dbg !1782
  %idxprom47 = sext i32 %nfd.3195 to i64, !dbg !1828
  %revents = getelementptr inbounds [20 x %struct.pollfd], ptr @watchers_pollfds, i64 0, i64 %idxprom47, i32 2, !dbg !1829
  %4 = load i16, ptr %revents, align 2, !dbg !1829, !tbaa !1830
  %5 = and i16 %4, 1, !dbg !1831
  %tobool50.not = icmp eq i16 %5, 0, !dbg !1831
  br i1 %tobool50.not, label %if.end76, label %if.then51, !dbg !1832

if.then51:                                        ; preds = %if.end46
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %buf52) #21, !dbg !1833
  %6 = load ptr, ptr %3, align 8, !dbg !1834, !tbaa !1364
  %read = getelementptr inbounds i8, ptr %6, i64 472, !dbg !1835
  %7 = load ptr, ptr %read, align 8, !dbg !1835, !tbaa !1836
  %call54 = call i64 %7(ptr noundef %6, ptr noundef nonnull %buf52, i64 noundef 1) #21, !dbg !1844
  %conv55 = trunc i64 %call54 to i32, !dbg !1844
  tail call void @llvm.dbg.value(metadata i32 %conv55, metadata !1774, metadata !DIExpression()), !dbg !1784
  switch i32 %conv55, label %cleanup72.thread [
    i32 0, label %cleanup72
    i32 -1, label %land.lhs.true61
  ], !dbg !1845

land.lhs.true61:                                  ; preds = %if.then51
  %call62 = tail call ptr @__errno_location() #26, !dbg !1847
  %8 = load i32, ptr %call62, align 4, !dbg !1847, !tbaa !1053
  %cmp63.not = icmp eq i32 %8, 11, !dbg !1848
  br i1 %cmp63.not, label %cleanup72.thread, label %cleanup72, !dbg !1849

cleanup72.thread:                                 ; preds = %if.then51, %land.lhs.true61
  tail call void @llvm.dbg.value(metadata i32 %nfd.3195, metadata !1758, metadata !DIExpression()), !dbg !1782
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %buf52) #21, !dbg !1850
  br label %if.end76

cleanup72:                                        ; preds = %if.then51, %land.lhs.true61
  call fastcc void @logger_thread_close_watcher(ptr noundef nonnull %3), !dbg !1851
  %inc70 = add nsw i32 %nfd.3195, 1, !dbg !1853
  tail call void @llvm.dbg.value(metadata i32 %inc70, metadata !1758, metadata !DIExpression()), !dbg !1782
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %buf52) #21, !dbg !1850
  br label %cleanup131

if.end76:                                         ; preds = %cleanup72.thread, %if.end46
  tail call void @llvm.dbg.value(metadata i32 %nfd.3195, metadata !1758, metadata !DIExpression()), !dbg !1782
  %buf77 = getelementptr inbounds i8, ptr %3, i64 48, !dbg !1854
  %9 = load ptr, ptr %buf77, align 8, !dbg !1854, !tbaa !1389
  %call78 = call ptr @bipbuf_peek_all(ptr noundef %9, ptr noundef nonnull %data_size) #21, !dbg !1855
  tail call void @llvm.dbg.value(metadata ptr %call78, metadata !1759, metadata !DIExpression()), !dbg !1782
  %cmp79.not = icmp eq ptr %call78, null, !dbg !1856
  br i1 %cmp79.not, label %if.end129, label %if.then81, !dbg !1857

if.then81:                                        ; preds = %if.end76
  %10 = load i16, ptr %revents, align 2, !dbg !1858, !tbaa !1830
  %conv85204 = zext i16 %10 to i32, !dbg !1859
  %and86 = and i32 %conv85204, 24, !dbg !1860
  %tobool87.not = icmp eq i32 %and86, 0, !dbg !1860
  br i1 %tobool87.not, label %if.else89, label %if.then88, !dbg !1861

if.then88:                                        ; preds = %if.then81
  call fastcc void @logger_thread_close_watcher(ptr noundef nonnull %3), !dbg !1862
  br label %if.end129, !dbg !1864

if.else89:                                        ; preds = %if.then81
  %and94 = and i32 %conv85204, 4, !dbg !1865
  %tobool95.not = icmp eq i32 %and94, 0, !dbg !1865
  br i1 %tobool95.not, label %if.end129, label %if.then96, !dbg !1866

if.then96:                                        ; preds = %if.else89
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1775, metadata !DIExpression()), !dbg !1867
  %t = getelementptr inbounds i8, ptr %3, i64 36, !dbg !1868
  %11 = load i32, ptr %t, align 4, !dbg !1868, !tbaa !1869
  switch i32 %11, label %if.then121 [
    i32 0, label %sw.bb
    i32 1, label %sw.bb100
  ], !dbg !1870

sw.bb:                                            ; preds = %if.then96
  %12 = load i32, ptr %data_size, align 4, !dbg !1871, !tbaa !1053
  %conv97 = zext i32 %12 to i64, !dbg !1871
  %13 = load ptr, ptr @stderr, align 8, !dbg !1873, !tbaa !1039
  %call98 = call i64 @fwrite(ptr noundef nonnull %call78, i64 noundef 1, i64 noundef %conv97, ptr noundef %13) #25, !dbg !1874
  tail call void @llvm.dbg.value(metadata i64 %call98, metadata !1775, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1867
  br label %sw.epilog, !dbg !1875

sw.bb100:                                         ; preds = %if.then96
  %14 = load ptr, ptr %3, align 8, !dbg !1876, !tbaa !1364
  %write = getelementptr inbounds i8, ptr %14, i64 488, !dbg !1877
  %15 = load ptr, ptr %write, align 8, !dbg !1877, !tbaa !1878
  %16 = load i32, ptr %data_size, align 4, !dbg !1879, !tbaa !1053
  %conv103 = zext i32 %16 to i64, !dbg !1879
  %call104 = call i64 %15(ptr noundef %14, ptr noundef nonnull %call78, i64 noundef %conv103) #21, !dbg !1880
  tail call void @llvm.dbg.value(metadata i64 %call104, metadata !1775, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1867
  br label %sw.epilog, !dbg !1881

sw.epilog:                                        ; preds = %sw.bb100, %sw.bb
  %total.0.in = phi i64 [ %call104, %sw.bb100 ], [ %call98, %sw.bb ]
  %total.0 = trunc i64 %total.0.in to i32, !dbg !1867
  tail call void @llvm.dbg.value(metadata i32 %total.0, metadata !1775, metadata !DIExpression()), !dbg !1867
  switch i32 %total.0, label %if.else122 [
    i32 -1, label %if.then108
    i32 0, label %if.then121
  ], !dbg !1882

if.then108:                                       ; preds = %sw.epilog
  %call109 = tail call ptr @__errno_location() #26, !dbg !1883
  %17 = load i32, ptr %call109, align 4, !dbg !1883, !tbaa !1053
  %cmp110.not = icmp eq i32 %17, 11, !dbg !1887
  br i1 %cmp110.not, label %if.end129, label %if.then116, !dbg !1888

if.then116:                                       ; preds = %if.then108
  call fastcc void @logger_thread_close_watcher(ptr noundef nonnull %3), !dbg !1889
  br label %if.end129, !dbg !1891

if.then121:                                       ; preds = %if.then96, %sw.epilog
  call fastcc void @logger_thread_close_watcher(ptr noundef nonnull %3), !dbg !1892
  br label %if.end129, !dbg !1895

if.else122:                                       ; preds = %sw.epilog
  %18 = load ptr, ptr %buf77, align 8, !dbg !1896, !tbaa !1389
  %call124 = call ptr @bipbuf_poll(ptr noundef %18, i32 noundef %total.0) #21, !dbg !1898
  %add = add nsw i32 %flushed.0194, %total.0, !dbg !1899
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !1761, metadata !DIExpression()), !dbg !1782
  br label %if.end129

if.end129:                                        ; preds = %if.then116, %if.then108, %if.else122, %if.then121, %if.then88, %if.else89, %if.end76
  %flushed.2 = phi i32 [ %flushed.0194, %if.then88 ], [ %flushed.0194, %if.else89 ], [ %flushed.0194, %if.end76 ], [ %flushed.0194, %if.then116 ], [ %flushed.0194, %if.then108 ], [ %flushed.0194, %if.then121 ], [ %add, %if.else122 ], !dbg !1900
  tail call void @llvm.dbg.value(metadata i32 %flushed.2, metadata !1761, metadata !DIExpression()), !dbg !1782
  %inc130 = add nsw i32 %nfd.3195, 1, !dbg !1901
  tail call void @llvm.dbg.value(metadata i32 %inc130, metadata !1758, metadata !DIExpression()), !dbg !1782
  br label %cleanup131, !dbg !1902

cleanup131:                                       ; preds = %cleanup72, %for.body33, %if.end129
  %flushed.3 = phi i32 [ %flushed.2, %if.end129 ], [ %flushed.0194, %cleanup72 ], [ %flushed.0194, %for.body33 ], !dbg !1900
  %nfd.6 = phi i32 [ %inc130, %if.end129 ], [ %inc70, %cleanup72 ], [ %nfd.3195, %for.body33 ], !dbg !1782
  tail call void @llvm.dbg.value(metadata i32 %nfd.6, metadata !1758, metadata !DIExpression()), !dbg !1782
  tail call void @llvm.dbg.value(metadata i32 %flushed.3, metadata !1761, metadata !DIExpression()), !dbg !1782
  %indvars.iv.next201 = add nuw nsw i64 %indvars.iv200, 1, !dbg !1903
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next201, metadata !1757, metadata !DIExpression()), !dbg !1782
  %exitcond203.not = icmp eq i64 %indvars.iv.next201, 20, !dbg !1904
  br i1 %exitcond203.not, label %cleanup138, label %for.body33, !dbg !1905, !llvm.loop !1906

cleanup138:                                       ; preds = %cleanup131, %if.then28, %for.end
  %retval.1 = phi i32 [ 0, %for.end ], [ -1, %if.then28 ], [ %flushed.3, %cleanup131 ], !dbg !1782
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %data_size) #21, !dbg !1908
  ret i32 %retval.1, !dbg !1908
}

declare !dbg !1909 ptr @bipbuf_peek_all(ptr noundef, ptr noundef) local_unnamed_addr #6

declare !dbg !1915 ptr @bipbuf_poll(ptr noundef, i32 noundef) local_unnamed_addr #6

; Function Attrs: nofree nounwind
declare !dbg !1918 noundef i32 @snprintf(ptr noalias nocapture noundef writeonly, i64 noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #8

declare !dbg !1922 i32 @poll(ptr noundef, i64 noundef, i32 noundef) local_unnamed_addr #6

; Function Attrs: cold nofree nounwind
declare !dbg !1927 void @perror(ptr nocapture noundef readonly) local_unnamed_addr #11

; Function Attrs: mustprogress nofree nosync nounwind willreturn memory(none)
declare !dbg !1930 ptr @__errno_location() local_unnamed_addr #12

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @logger_thread_close_watcher(ptr nocapture noundef %w) unnamed_addr #1 !dbg !1934 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %w, metadata !1938, metadata !DIExpression()), !dbg !1939
  %id = getelementptr inbounds i8, ptr %w, i64 12, !dbg !1940
  %0 = load i32, ptr %id, align 4, !dbg !1940, !tbaa !1375
  %idxprom = sext i32 %0 to i64, !dbg !1941
  %arrayidx = getelementptr inbounds [20 x ptr], ptr @watchers, i64 0, i64 %idxprom, !dbg !1941
  store ptr null, ptr %arrayidx, align 8, !dbg !1942, !tbaa !1039
  %1 = load ptr, ptr %w, align 8, !dbg !1943, !tbaa !1364
  tail call void @sidethread_conn_close(ptr noundef %1) #21, !dbg !1944
  %2 = load i32, ptr @watcher_count, align 4, !dbg !1945, !tbaa !1053
  %dec = add nsw i32 %2, -1, !dbg !1945
  store i32 %dec, ptr @watcher_count, align 4, !dbg !1945, !tbaa !1053
  %buf = getelementptr inbounds i8, ptr %w, i64 48, !dbg !1946
  %3 = load ptr, ptr %buf, align 8, !dbg !1946, !tbaa !1389
  tail call void @bipbuf_free(ptr noundef %3) #21, !dbg !1947
  tail call void @free(ptr noundef %w) #21, !dbg !1948
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1400, metadata !DIExpression()), !dbg !1949
  tail call void @llvm.dbg.value(metadata i16 0, metadata !1404, metadata !DIExpression()), !dbg !1949
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1403, metadata !DIExpression()), !dbg !1949
  br label %for.body.i, !dbg !1951

for.cond4.preheader.i:                            ; preds = %cleanup.i.1
  %l.027.i = load ptr, ptr @logger_stack_head, align 8, !dbg !1952, !tbaa !1039
  %cmp5.not28.i = icmp eq ptr %l.027.i, null, !dbg !1953
  br i1 %cmp5.not28.i, label %logger_set_flags.exit, label %for.body7.i, !dbg !1954

for.body.i:                                       ; preds = %cleanup.i.1, %entry
  %indvars.iv.i = phi i64 [ 0, %entry ], [ %indvars.iv.next.i.1, %cleanup.i.1 ]
  %f.026.i = phi i16 [ 0, %entry ], [ %f.1.i.1, %cleanup.i.1 ]
  tail call void @llvm.dbg.value(metadata i16 %f.026.i, metadata !1404, metadata !DIExpression()), !dbg !1949
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i, metadata !1403, metadata !DIExpression()), !dbg !1949
  %arrayidx.i = getelementptr inbounds [20 x ptr], ptr @watchers, i64 0, i64 %indvars.iv.i, !dbg !1955
  %4 = load ptr, ptr %arrayidx.i, align 16, !dbg !1955, !tbaa !1039
  tail call void @llvm.dbg.value(metadata ptr %4, metadata !1405, metadata !DIExpression()), !dbg !1956
  %cmp1.i = icmp eq ptr %4, null, !dbg !1957
  br i1 %cmp1.i, label %cleanup.i, label %if.end.i, !dbg !1958

if.end.i:                                         ; preds = %for.body.i
  %eflags.i = getelementptr inbounds i8, ptr %4, i64 40, !dbg !1959
  %5 = load i16, ptr %eflags.i, align 8, !dbg !1959, !tbaa !1378
  %or24.i = or i16 %5, %f.026.i, !dbg !1960
  tail call void @llvm.dbg.value(metadata i16 %or24.i, metadata !1404, metadata !DIExpression()), !dbg !1949
  br label %cleanup.i, !dbg !1961

cleanup.i:                                        ; preds = %if.end.i, %for.body.i
  %f.1.i = phi i16 [ %or24.i, %if.end.i ], [ %f.026.i, %for.body.i ], !dbg !1949
  tail call void @llvm.dbg.value(metadata i16 %f.1.i, metadata !1404, metadata !DIExpression()), !dbg !1949
  %indvars.iv.next.i = or disjoint i64 %indvars.iv.i, 1, !dbg !1962
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !1403, metadata !DIExpression()), !dbg !1949
  tail call void @llvm.dbg.value(metadata i16 %f.1.i, metadata !1404, metadata !DIExpression()), !dbg !1949
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !1403, metadata !DIExpression()), !dbg !1949
  %arrayidx.i.1 = getelementptr inbounds [20 x ptr], ptr @watchers, i64 0, i64 %indvars.iv.next.i, !dbg !1955
  %6 = load ptr, ptr %arrayidx.i.1, align 8, !dbg !1955, !tbaa !1039
  tail call void @llvm.dbg.value(metadata ptr %6, metadata !1405, metadata !DIExpression()), !dbg !1956
  %cmp1.i.1 = icmp eq ptr %6, null, !dbg !1957
  br i1 %cmp1.i.1, label %cleanup.i.1, label %if.end.i.1, !dbg !1958

if.end.i.1:                                       ; preds = %cleanup.i
  %eflags.i.1 = getelementptr inbounds i8, ptr %6, i64 40, !dbg !1959
  %7 = load i16, ptr %eflags.i.1, align 8, !dbg !1959, !tbaa !1378
  %or24.i.1 = or i16 %7, %f.1.i, !dbg !1960
  tail call void @llvm.dbg.value(metadata i16 %or24.i.1, metadata !1404, metadata !DIExpression()), !dbg !1949
  br label %cleanup.i.1, !dbg !1961

cleanup.i.1:                                      ; preds = %if.end.i.1, %cleanup.i
  %f.1.i.1 = phi i16 [ %or24.i.1, %if.end.i.1 ], [ %f.1.i, %cleanup.i ], !dbg !1949
  tail call void @llvm.dbg.value(metadata i16 %f.1.i.1, metadata !1404, metadata !DIExpression()), !dbg !1949
  %indvars.iv.next.i.1 = add nuw nsw i64 %indvars.iv.i, 2, !dbg !1962
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.1, metadata !1403, metadata !DIExpression()), !dbg !1949
  %exitcond.not.i.1 = icmp eq i64 %indvars.iv.next.i.1, 20, !dbg !1963
  br i1 %exitcond.not.i.1, label %for.cond4.preheader.i, label %for.body.i, !dbg !1951, !llvm.loop !1964

for.body7.i:                                      ; preds = %for.cond4.preheader.i, %for.body7.i
  %l.029.i = phi ptr [ %l.0.i, %for.body7.i ], [ %l.027.i, %for.cond4.preheader.i ]
  %mutex.i = getelementptr inbounds i8, ptr %l.029.i, i64 16, !dbg !1966
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %mutex.i) #21, !dbg !1967
  %eflags8.i = getelementptr inbounds i8, ptr %l.029.i, i64 84, !dbg !1968
  store i16 %f.1.i.1, ptr %eflags8.i, align 4, !dbg !1969, !tbaa !1435
  %call10.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %mutex.i) #21, !dbg !1970
  %next.i = getelementptr inbounds i8, ptr %l.029.i, i64 8, !dbg !1971
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1400, metadata !DIExpression()), !dbg !1949
  %l.0.i = load ptr, ptr %next.i, align 8, !dbg !1952, !tbaa !1039
  tail call void @llvm.dbg.value(metadata ptr %l.0.i, metadata !1400, metadata !DIExpression()), !dbg !1949
  %cmp5.not.i = icmp eq ptr %l.0.i, null, !dbg !1953
  br i1 %cmp5.not.i, label %logger_set_flags.exit, label %for.body7.i, !dbg !1954, !llvm.loop !1972

logger_set_flags.exit:                            ; preds = %for.body7.i, %for.cond4.preheader.i
  ret void, !dbg !1974
}

; Function Attrs: nofree nounwind
declare !dbg !1975 noundef i64 @fwrite(ptr nocapture noundef, i64 noundef, i64 noundef, ptr nocapture noundef) local_unnamed_addr #8

declare !dbg !1979 void @sidethread_conn_close(ptr noundef) local_unnamed_addr #6

declare !dbg !1982 void @bipbuf_free(ptr noundef) local_unnamed_addr #6

declare !dbg !1985 void @STATS_LOCK() local_unnamed_addr #6

declare !dbg !1986 void @STATS_UNLOCK() local_unnamed_addr #6

declare !dbg !1987 i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #6

; Function Attrs: nofree nounwind sanitize_thread uwtable
define internal void @_logger_log_text(ptr nocapture noundef %e, ptr nocapture noundef readonly %d, ptr nocapture readnone %entry1, ptr noundef %ap) #13 !dbg !1991 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !1993, metadata !DIExpression()), !dbg !1999
  tail call void @llvm.dbg.value(metadata ptr %d, metadata !1994, metadata !DIExpression()), !dbg !1999
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1995, metadata !DIExpression()), !dbg !1999
  tail call void @llvm.dbg.value(metadata ptr %ap, metadata !1996, metadata !DIExpression()), !dbg !1999
  %0 = load i32, ptr %d, align 8, !dbg !2000, !tbaa !1204
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !1997, metadata !DIExpression()), !dbg !1999
  %data = getelementptr inbounds i8, ptr %e, i64 36, !dbg !2001
  %conv = sext i32 %0 to i64, !dbg !2002
  %format = getelementptr inbounds i8, ptr %d, i64 24, !dbg !2003
  %1 = load ptr, ptr %format, align 8, !dbg !2003, !tbaa !2004
  %call = tail call i32 @vsnprintf(ptr noundef nonnull %data, i64 noundef %conv, ptr noundef %1, ptr noundef %ap) #21, !dbg !2005
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !1998, metadata !DIExpression()), !dbg !1999
  %cmp = icmp slt i32 %call, 1, !dbg !2006
  br i1 %cmp, label %if.then, label %if.end, !dbg !2008

if.then:                                          ; preds = %entry
  %2 = load ptr, ptr @stderr, align 8, !dbg !2009, !tbaa !1039
  %call4 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %2, ptr noundef nonnull @.str.17, i32 noundef %call) #22, !dbg !2011
  br label %if.end, !dbg !2012

if.end:                                           ; preds = %if.then, %entry
  %add = add nsw i32 %call, 1, !dbg !2013
  %size = getelementptr inbounds i8, ptr %e, i64 32, !dbg !2014
  store i32 %add, ptr %size, align 8, !dbg !2015, !tbaa !1053
  ret void, !dbg !2016
}

; Function Attrs: nofree nounwind sanitize_thread uwtable
define internal noundef i32 @_logger_parse_text(ptr noundef %e, ptr nocapture noundef writeonly %scratch) #13 !dbg !2017 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2019, metadata !DIExpression()), !dbg !2021
  tail call void @llvm.dbg.value(metadata ptr %scratch, metadata !2020, metadata !DIExpression()), !dbg !2021
  %tv = getelementptr inbounds i8, ptr %e, i64 16, !dbg !2022
  %0 = load i64, ptr %tv, align 8, !dbg !2023, !tbaa !2024
  %tv_usec = getelementptr inbounds i8, ptr %e, i64 24, !dbg !2025
  %1 = load i64, ptr %tv_usec, align 8, !dbg !2025, !tbaa !2026
  %conv = trunc i64 %1 to i32, !dbg !2027
  %gid = getelementptr inbounds i8, ptr %e, i64 8, !dbg !2028
  %2 = load i64, ptr %gid, align 8, !dbg !2028, !tbaa !1067
  %data = getelementptr inbounds i8, ptr %e, i64 36, !dbg !2029
  %call = tail call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %scratch, i64 noundef 4096, ptr noundef nonnull @.str.18, i64 noundef %0, i32 noundef %conv, i64 noundef %2, ptr noundef nonnull %data) #21, !dbg !2030
  ret i32 %call, !dbg !2031
}

; Function Attrs: mustprogress nofree norecurse nounwind sanitize_thread willreturn uwtable
define internal void @_logger_log_evictions(ptr nocapture noundef writeonly %e, ptr nocapture readnone %d, ptr nocapture noundef readonly %entry1, ptr nocapture readnone %ap) #14 !dbg !2032 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2034, metadata !DIExpression()), !dbg !2040
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2035, metadata !DIExpression()), !dbg !2040
  tail call void @llvm.dbg.value(metadata ptr %entry1, metadata !2036, metadata !DIExpression()), !dbg !2040
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2037, metadata !DIExpression()), !dbg !2040
  tail call void @llvm.dbg.value(metadata ptr %entry1, metadata !2038, metadata !DIExpression()), !dbg !2040
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2039, metadata !DIExpression(DW_OP_plus_uconst, 36, DW_OP_stack_value)), !dbg !2040
  %exptime = getelementptr inbounds i8, ptr %entry1, i64 28, !dbg !2041
  %0 = load i32, ptr %exptime, align 4, !dbg !2041, !tbaa !1053
  %cmp.not = icmp eq i32 %0, 0, !dbg !2042
  br i1 %cmp.not, label %cond.end, label %cond.true, !dbg !2043

cond.true:                                        ; preds = %entry
  %1 = load volatile i32, ptr @current_time, align 4, !dbg !2044, !tbaa !1053
  %sub = sub i32 %0, %1, !dbg !2045
  %conv = zext i32 %sub to i64, !dbg !2046
  br label %cond.end, !dbg !2043

cond.end:                                         ; preds = %entry, %cond.true
  %cond = phi i64 [ %conv, %cond.true ], [ -1, %entry ], !dbg !2043
  %data = getelementptr inbounds i8, ptr %e, i64 36, !dbg !2047
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !2039, metadata !DIExpression()), !dbg !2040
  store i64 %cond, ptr %data, align 8, !dbg !2048, !tbaa !2049
  %2 = load volatile i32, ptr @current_time, align 4, !dbg !2051, !tbaa !1053
  %time = getelementptr inbounds i8, ptr %entry1, i64 24, !dbg !2052
  %3 = load i32, ptr %time, align 8, !dbg !2052, !tbaa !1053
  %sub4 = sub i32 %2, %3, !dbg !2053
  %latime = getelementptr inbounds i8, ptr %e, i64 48, !dbg !2054
  store i32 %sub4, ptr %latime, align 4, !dbg !2055, !tbaa !1053
  %it_flags = getelementptr inbounds i8, ptr %entry1, i64 38, !dbg !2056
  %4 = load i16, ptr %it_flags, align 2, !dbg !2056, !tbaa !1231
  %it_flags5 = getelementptr inbounds i8, ptr %e, i64 52, !dbg !2057
  store i16 %4, ptr %it_flags5, align 8, !dbg !2058, !tbaa !1231
  %nkey = getelementptr inbounds i8, ptr %entry1, i64 41, !dbg !2059
  %5 = load i8, ptr %nkey, align 1, !dbg !2059, !tbaa !1222
  %nkey6 = getelementptr inbounds i8, ptr %e, i64 54, !dbg !2060
  store i8 %5, ptr %nkey6, align 2, !dbg !2061, !tbaa !1222
  %nbytes = getelementptr inbounds i8, ptr %entry1, i64 32, !dbg !2062
  %6 = load i32, ptr %nbytes, align 8, !dbg !2062, !tbaa !1053
  %nbytes7 = getelementptr inbounds i8, ptr %e, i64 44, !dbg !2063
  store i32 %6, ptr %nbytes7, align 8, !dbg !2064, !tbaa !1053
  %slabs_clsid = getelementptr inbounds i8, ptr %entry1, i64 40, !dbg !2065
  %7 = load i8, ptr %slabs_clsid, align 8, !dbg !2065, !tbaa !1222
  %8 = and i8 %7, 63, !dbg !2065
  %clsid = getelementptr inbounds i8, ptr %e, i64 55, !dbg !2066
  store i8 %8, ptr %clsid, align 1, !dbg !2067, !tbaa !1222
  %key = getelementptr inbounds i8, ptr %e, i64 56, !dbg !2068
  %data11 = getelementptr inbounds i8, ptr %entry1, i64 48, !dbg !2069
  %9 = load i16, ptr %it_flags, align 2, !dbg !2069, !tbaa !1231
  %10 = shl i16 %9, 2, !dbg !2069
  %11 = and i16 %10, 8, !dbg !2069
  %cond15 = zext nneg i16 %11 to i64, !dbg !2069
  %add.ptr = getelementptr inbounds i8, ptr %data11, i64 %cond15, !dbg !2069
  %12 = load i8, ptr %nkey, align 1, !dbg !2070, !tbaa !1222
  %conv17 = zext i8 %12 to i64, !dbg !2071
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 4 %key, ptr nonnull align 1 %add.ptr, i64 %conv17, i1 false), !dbg !2072
  %conv19 = zext i8 %5 to i32, !dbg !2073
  %add = add nuw nsw i32 %conv19, 24, !dbg !2074
  %size = getelementptr inbounds i8, ptr %e, i64 32, !dbg !2075
  store i32 %add, ptr %size, align 8, !dbg !2076, !tbaa !1053
  ret void, !dbg !2077
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal noundef i32 @_logger_parse_ee(ptr noundef %e, ptr nocapture noundef writeonly %scratch) #1 !dbg !2078 {
entry:
  %keybuf = alloca [751 x i8], align 16, !DIAssignID !2088
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2083, metadata !DIExpression(), metadata !2088, metadata ptr %keybuf, metadata !DIExpression()), !dbg !2089
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2080, metadata !DIExpression()), !dbg !2089
  tail call void @llvm.dbg.value(metadata ptr %scratch, metadata !2081, metadata !DIExpression()), !dbg !2089
  call void @llvm.lifetime.start.p0(i64 751, ptr nonnull %keybuf) #21, !dbg !2090
  %data = getelementptr inbounds i8, ptr %e, i64 36, !dbg !2091
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !2087, metadata !DIExpression()), !dbg !2089
  %key = getelementptr inbounds i8, ptr %e, i64 56, !dbg !2092
  %nkey = getelementptr inbounds i8, ptr %e, i64 54, !dbg !2093
  %0 = load i8, ptr %nkey, align 2, !dbg !2093, !tbaa !1222
  %conv = zext i8 %0 to i64, !dbg !2094
  %call = call zeroext i1 @uriencode(ptr noundef nonnull %key, ptr noundef nonnull %keybuf, i64 noundef %conv, i64 noundef 751) #21, !dbg !2095
  %tv = getelementptr inbounds i8, ptr %e, i64 16, !dbg !2096
  %1 = load i64, ptr %tv, align 8, !dbg !2097, !tbaa !2024
  %tv_usec = getelementptr inbounds i8, ptr %e, i64 24, !dbg !2098
  %2 = load i64, ptr %tv_usec, align 8, !dbg !2098, !tbaa !2026
  %gid = getelementptr inbounds i8, ptr %e, i64 8, !dbg !2099
  %3 = load i64, ptr %gid, align 8, !dbg !2099, !tbaa !1067
  %it_flags = getelementptr inbounds i8, ptr %e, i64 52, !dbg !2100
  %4 = load i16, ptr %it_flags, align 8, !dbg !2100, !tbaa !1231
  %5 = load i64, ptr %data, align 8, !dbg !2101, !tbaa !2049
  %latime = getelementptr inbounds i8, ptr %e, i64 48, !dbg !2102
  %6 = load i32, ptr %latime, align 4, !dbg !2102, !tbaa !1053
  %clsid = getelementptr inbounds i8, ptr %e, i64 55, !dbg !2103
  %7 = load i8, ptr %clsid, align 1, !dbg !2103, !tbaa !1222
  %nbytes = getelementptr inbounds i8, ptr %e, i64 44, !dbg !2104
  %8 = load i32, ptr %nbytes, align 8, !dbg !2104, !tbaa !1053
  %cmp = icmp sgt i32 %8, 0, !dbg !2105
  %sub = add nsw i32 %8, -2
  %spec.select = select i1 %cmp, i32 %sub, i32 0, !dbg !2106
  %conv7 = zext i8 %7 to i32, !dbg !2107
  %9 = and i16 %4, 8, !dbg !2108
  %tobool.not = icmp eq i16 %9, 0, !dbg !2109
  %cond = select i1 %tobool.not, ptr @.str.21, ptr @.str.20, !dbg !2109
  %conv4 = trunc i64 %2 to i32, !dbg !2110
  %call11 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %scratch, i64 noundef 4096, ptr noundef nonnull @.str.19, i64 noundef %1, i32 noundef %conv4, i64 noundef %3, ptr noundef nonnull %keybuf, ptr noundef nonnull %cond, i64 noundef %5, i32 noundef %6, i32 noundef %conv7, i32 noundef %spec.select) #21, !dbg !2111
  tail call void @llvm.dbg.value(metadata i32 %call11, metadata !2082, metadata !DIExpression()), !dbg !2089
  call void @llvm.lifetime.end.p0(i64 751, ptr nonnull %keybuf) #21, !dbg !2112
  ret i32 %call11, !dbg !2113
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, inaccessiblemem: none) uwtable
define internal void @_logger_log_item_get(ptr nocapture noundef writeonly %e, ptr nocapture readnone %d, ptr nocapture readnone %entry1, ptr nocapture noundef %ap) #15 !dbg !2114 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2116, metadata !DIExpression()), !dbg !2127
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2117, metadata !DIExpression()), !dbg !2127
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2118, metadata !DIExpression()), !dbg !2127
  tail call void @llvm.dbg.value(metadata ptr %ap, metadata !2119, metadata !DIExpression()), !dbg !2127
  %gp_offset = load i32, ptr %ap, align 8, !dbg !2128
  %fits_in_gp = icmp ult i32 %gp_offset, 41, !dbg !2128
  br i1 %fits_in_gp, label %vaarg.end, label %vaarg.end.thread, !dbg !2128

vaarg.end.thread:                                 ; preds = %entry
  %overflow_arg_area_p = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2128
  %overflow_arg_area = load ptr, ptr %overflow_arg_area_p, align 8, !dbg !2128
  %overflow_arg_area.next = getelementptr i8, ptr %overflow_arg_area, i64 8, !dbg !2128
  store ptr %overflow_arg_area.next, ptr %overflow_arg_area_p, align 8, !dbg !2128
  %0 = load i32, ptr %overflow_arg_area, align 4, !dbg !2128
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !2120, metadata !DIExpression()), !dbg !2127
  br label %vaarg.end11.thread, !dbg !2129

vaarg.end:                                        ; preds = %entry
  %1 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2128
  %reg_save_area = load ptr, ptr %1, align 8, !dbg !2128
  %2 = zext nneg i32 %gp_offset to i64, !dbg !2128
  %3 = getelementptr i8, ptr %reg_save_area, i64 %2, !dbg !2128
  %4 = add nuw nsw i32 %gp_offset, 8, !dbg !2128
  store i32 %4, ptr %ap, align 8, !dbg !2128
  %5 = load i32, ptr %3, align 4, !dbg !2128
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !2120, metadata !DIExpression()), !dbg !2127
  %fits_in_gp4 = icmp ult i32 %gp_offset, 33, !dbg !2129
  br i1 %fits_in_gp4, label %vaarg.end11, label %vaarg.end11.thread, !dbg !2129

vaarg.end11.thread:                               ; preds = %vaarg.end, %vaarg.end.thread
  %6 = phi i32 [ %0, %vaarg.end.thread ], [ %5, %vaarg.end ]
  %overflow_arg_area_p8 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2129
  %overflow_arg_area9 = load ptr, ptr %overflow_arg_area_p8, align 8, !dbg !2129
  %overflow_arg_area.next10 = getelementptr i8, ptr %overflow_arg_area9, i64 8, !dbg !2129
  store ptr %overflow_arg_area.next10, ptr %overflow_arg_area_p8, align 8, !dbg !2129
  %7 = load ptr, ptr %overflow_arg_area9, align 8, !dbg !2129
  tail call void @llvm.dbg.value(metadata ptr %7, metadata !2121, metadata !DIExpression()), !dbg !2127
  br label %vaarg.end22.thread, !dbg !2130

vaarg.end11:                                      ; preds = %vaarg.end
  %8 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2129
  %reg_save_area6 = load ptr, ptr %8, align 8, !dbg !2129
  %9 = zext nneg i32 %4 to i64, !dbg !2129
  %10 = getelementptr i8, ptr %reg_save_area6, i64 %9, !dbg !2129
  %11 = add nuw nsw i32 %gp_offset, 16, !dbg !2129
  store i32 %11, ptr %ap, align 8, !dbg !2129
  %12 = load ptr, ptr %10, align 8, !dbg !2129
  tail call void @llvm.dbg.value(metadata ptr %12, metadata !2121, metadata !DIExpression()), !dbg !2127
  %fits_in_gp15 = icmp ult i32 %gp_offset, 25, !dbg !2130
  br i1 %fits_in_gp15, label %vaarg.end22, label %vaarg.end22.thread, !dbg !2130

vaarg.end22.thread:                               ; preds = %vaarg.end11, %vaarg.end11.thread
  %13 = phi ptr [ %7, %vaarg.end11.thread ], [ %12, %vaarg.end11 ]
  %14 = phi i32 [ %6, %vaarg.end11.thread ], [ %5, %vaarg.end11 ]
  %overflow_arg_area_p19 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2130
  %overflow_arg_area20 = load ptr, ptr %overflow_arg_area_p19, align 8, !dbg !2130
  %overflow_arg_area.next21 = getelementptr i8, ptr %overflow_arg_area20, i64 8, !dbg !2130
  store ptr %overflow_arg_area.next21, ptr %overflow_arg_area_p19, align 8, !dbg !2130
  %15 = load i32, ptr %overflow_arg_area20, align 4, !dbg !2130
  tail call void @llvm.dbg.value(metadata i32 %15, metadata !2122, metadata !DIExpression()), !dbg !2127
  br label %vaarg.end33.thread, !dbg !2131

vaarg.end22:                                      ; preds = %vaarg.end11
  %16 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2130
  %reg_save_area17 = load ptr, ptr %16, align 8, !dbg !2130
  %17 = zext nneg i32 %11 to i64, !dbg !2130
  %18 = getelementptr i8, ptr %reg_save_area17, i64 %17, !dbg !2130
  %19 = add nuw nsw i32 %gp_offset, 24, !dbg !2130
  store i32 %19, ptr %ap, align 8, !dbg !2130
  %20 = load i32, ptr %18, align 4, !dbg !2130
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !2122, metadata !DIExpression()), !dbg !2127
  %fits_in_gp26 = icmp ult i32 %gp_offset, 17, !dbg !2131
  br i1 %fits_in_gp26, label %vaarg.end33, label %vaarg.end33.thread, !dbg !2131

vaarg.end33.thread:                               ; preds = %vaarg.end22, %vaarg.end22.thread
  %21 = phi i32 [ %15, %vaarg.end22.thread ], [ %20, %vaarg.end22 ]
  %22 = phi i32 [ %14, %vaarg.end22.thread ], [ %5, %vaarg.end22 ]
  %23 = phi ptr [ %13, %vaarg.end22.thread ], [ %12, %vaarg.end22 ]
  %overflow_arg_area_p30 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2131
  %overflow_arg_area31 = load ptr, ptr %overflow_arg_area_p30, align 8, !dbg !2131
  %overflow_arg_area.next32 = getelementptr i8, ptr %overflow_arg_area31, i64 8, !dbg !2131
  store ptr %overflow_arg_area.next32, ptr %overflow_arg_area_p30, align 8, !dbg !2131
  %24 = load i32, ptr %overflow_arg_area31, align 4, !dbg !2131
  tail call void @llvm.dbg.value(metadata i32 %24, metadata !2123, metadata !DIExpression()), !dbg !2127
  br label %vaarg.end44.thread, !dbg !2132

vaarg.end33:                                      ; preds = %vaarg.end22
  %25 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2131
  %reg_save_area28 = load ptr, ptr %25, align 8, !dbg !2131
  %26 = zext nneg i32 %19 to i64, !dbg !2131
  %27 = getelementptr i8, ptr %reg_save_area28, i64 %26, !dbg !2131
  %28 = or disjoint i32 %gp_offset, 32, !dbg !2131
  store i32 %28, ptr %ap, align 8, !dbg !2131
  %29 = load i32, ptr %27, align 4, !dbg !2131
  tail call void @llvm.dbg.value(metadata i32 %29, metadata !2123, metadata !DIExpression()), !dbg !2127
  %fits_in_gp37 = icmp ult i32 %28, 41, !dbg !2132
  br i1 %fits_in_gp37, label %vaarg.end44, label %vaarg.end44.thread, !dbg !2132

vaarg.end44.thread:                               ; preds = %vaarg.end33, %vaarg.end33.thread
  %30 = phi i32 [ %24, %vaarg.end33.thread ], [ %29, %vaarg.end33 ]
  %31 = phi ptr [ %23, %vaarg.end33.thread ], [ %12, %vaarg.end33 ]
  %32 = phi i32 [ %22, %vaarg.end33.thread ], [ %5, %vaarg.end33 ]
  %33 = phi i32 [ %21, %vaarg.end33.thread ], [ %20, %vaarg.end33 ]
  %overflow_arg_area_p41 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2132
  %overflow_arg_area42 = load ptr, ptr %overflow_arg_area_p41, align 8, !dbg !2132
  %overflow_arg_area.next43 = getelementptr i8, ptr %overflow_arg_area42, i64 8, !dbg !2132
  store ptr %overflow_arg_area.next43, ptr %overflow_arg_area_p41, align 8, !dbg !2132
  %34 = load i32, ptr %overflow_arg_area42, align 4, !dbg !2132
  tail call void @llvm.dbg.value(metadata i32 %34, metadata !2124, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2127
  br label %vaarg.in_mem51, !dbg !2133

vaarg.end44:                                      ; preds = %vaarg.end33
  %35 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2132
  %reg_save_area39 = load ptr, ptr %35, align 8, !dbg !2132
  %36 = zext nneg i32 %28 to i64, !dbg !2132
  %37 = getelementptr i8, ptr %reg_save_area39, i64 %36, !dbg !2132
  %38 = add nuw nsw i32 %gp_offset, 40, !dbg !2132
  store i32 %38, ptr %ap, align 8, !dbg !2132
  %39 = load i32, ptr %37, align 4, !dbg !2132
  tail call void @llvm.dbg.value(metadata i32 %39, metadata !2124, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2127
  %fits_in_gp48 = icmp eq i32 %gp_offset, 0, !dbg !2133
  br i1 %fits_in_gp48, label %vaarg.in_reg49, label %vaarg.in_mem51, !dbg !2133

vaarg.in_reg49:                                   ; preds = %vaarg.end44
  %40 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2133
  %reg_save_area50 = load ptr, ptr %40, align 8, !dbg !2133
  %41 = zext nneg i32 %38 to i64, !dbg !2133
  %42 = getelementptr i8, ptr %reg_save_area50, i64 %41, !dbg !2133
  store i32 48, ptr %ap, align 8, !dbg !2133
  br label %vaarg.end55, !dbg !2133

vaarg.in_mem51:                                   ; preds = %vaarg.end44.thread, %vaarg.end44
  %43 = phi i32 [ %34, %vaarg.end44.thread ], [ %39, %vaarg.end44 ]
  %44 = phi i32 [ %33, %vaarg.end44.thread ], [ %20, %vaarg.end44 ]
  %45 = phi i32 [ %32, %vaarg.end44.thread ], [ %5, %vaarg.end44 ]
  %46 = phi ptr [ %31, %vaarg.end44.thread ], [ %12, %vaarg.end44 ]
  %47 = phi i32 [ %30, %vaarg.end44.thread ], [ %29, %vaarg.end44 ]
  %overflow_arg_area_p52 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2133
  %overflow_arg_area53 = load ptr, ptr %overflow_arg_area_p52, align 8, !dbg !2133
  %overflow_arg_area.next54 = getelementptr i8, ptr %overflow_arg_area53, i64 8, !dbg !2133
  store ptr %overflow_arg_area.next54, ptr %overflow_arg_area_p52, align 8, !dbg !2133
  br label %vaarg.end55, !dbg !2133

vaarg.end55:                                      ; preds = %vaarg.in_mem51, %vaarg.in_reg49
  %48 = phi i32 [ %39, %vaarg.in_reg49 ], [ %43, %vaarg.in_mem51 ]
  %49 = phi i32 [ %20, %vaarg.in_reg49 ], [ %44, %vaarg.in_mem51 ]
  %50 = phi i32 [ %5, %vaarg.in_reg49 ], [ %45, %vaarg.in_mem51 ]
  %51 = phi ptr [ %12, %vaarg.in_reg49 ], [ %46, %vaarg.in_mem51 ]
  %52 = phi i32 [ %29, %vaarg.in_reg49 ], [ %47, %vaarg.in_mem51 ]
  %vaarg.addr56 = phi ptr [ %42, %vaarg.in_reg49 ], [ %overflow_arg_area53, %vaarg.in_mem51 ], !dbg !2133
  %conv = trunc i32 %48 to i8, !dbg !2132
  tail call void @llvm.dbg.value(metadata i8 %conv, metadata !2124, metadata !DIExpression()), !dbg !2127
  %53 = load i32, ptr %vaarg.addr56, align 4, !dbg !2133
  tail call void @llvm.dbg.value(metadata i32 %53, metadata !2125, metadata !DIExpression()), !dbg !2127
  %data = getelementptr inbounds i8, ptr %e, i64 36, !dbg !2134
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !2126, metadata !DIExpression()), !dbg !2127
  %conv57 = trunc i32 %50 to i8, !dbg !2135
  store i8 %conv57, ptr %data, align 4, !dbg !2136, !tbaa !1222
  %conv59 = trunc i32 %49 to i8, !dbg !2137
  %nkey60 = getelementptr inbounds i8, ptr %e, i64 37, !dbg !2138
  store i8 %conv59, ptr %nkey60, align 1, !dbg !2139, !tbaa !1222
  %nbytes61 = getelementptr inbounds i8, ptr %e, i64 40, !dbg !2140
  store i32 %52, ptr %nbytes61, align 4, !dbg !2141, !tbaa !1053
  %clsid62 = getelementptr inbounds i8, ptr %e, i64 38, !dbg !2142
  store i8 %conv, ptr %clsid62, align 2, !dbg !2143, !tbaa !1222
  %key63 = getelementptr inbounds i8, ptr %e, i64 48, !dbg !2144
  %conv65 = sext i32 %49 to i64, !dbg !2145
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 4 %key63, ptr align 1 %51, i64 %conv65, i1 false), !dbg !2146
  %sfd66 = getelementptr inbounds i8, ptr %e, i64 44, !dbg !2147
  store i32 %53, ptr %sfd66, align 4, !dbg !2148, !tbaa !1053
  %add = add i32 %49, 12, !dbg !2149
  %size = getelementptr inbounds i8, ptr %e, i64 32, !dbg !2150
  store i32 %add, ptr %size, align 8, !dbg !2151, !tbaa !1053
  ret void, !dbg !2152
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal noundef i32 @_logger_parse_ige(ptr noundef %e, ptr nocapture noundef writeonly %scratch) #1 !dbg !2153 {
entry:
  %keybuf = alloca [751 x i8], align 16, !DIAssignID !2163
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2159, metadata !DIExpression(), metadata !2163, metadata ptr %keybuf, metadata !DIExpression()), !dbg !2164
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2160, metadata !DIExpression(), metadata !2165, metadata ptr poison, metadata !DIExpression()), !dbg !2164
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2155, metadata !DIExpression()), !dbg !2164
  tail call void @llvm.dbg.value(metadata ptr %scratch, metadata !2156, metadata !DIExpression()), !dbg !2164
  %data = getelementptr inbounds i8, ptr %e, i64 36, !dbg !2166
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !2158, metadata !DIExpression()), !dbg !2164
  call void @llvm.lifetime.start.p0(i64 751, ptr nonnull %keybuf) #21, !dbg !2167
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2160, metadata !DIExpression(), metadata !2168, metadata ptr poison, metadata !DIExpression()), !dbg !2164
  %key = getelementptr inbounds i8, ptr %e, i64 48, !dbg !2169
  %nkey = getelementptr inbounds i8, ptr %e, i64 37, !dbg !2170
  %0 = load i8, ptr %nkey, align 1, !dbg !2170, !tbaa !1222
  %conv = zext i8 %0 to i64, !dbg !2171
  %call = call zeroext i1 @uriencode(ptr noundef nonnull %key, ptr noundef nonnull %keybuf, i64 noundef %conv, i64 noundef 751) #21, !dbg !2172
  %tv = getelementptr inbounds i8, ptr %e, i64 16, !dbg !2173
  %1 = load i64, ptr %tv, align 8, !dbg !2174, !tbaa !2024
  %tv_usec = getelementptr inbounds i8, ptr %e, i64 24, !dbg !2175
  %2 = load i64, ptr %tv_usec, align 8, !dbg !2175, !tbaa !2026
  %gid = getelementptr inbounds i8, ptr %e, i64 8, !dbg !2176
  %3 = load i64, ptr %gid, align 8, !dbg !2176, !tbaa !1067
  %4 = load i8, ptr %data, align 4, !dbg !2177, !tbaa !1222
  %idxprom = zext i8 %4 to i64, !dbg !2178
  %reltable.shift = shl i64 %idxprom, 2, !dbg !2178
  %reltable.intrinsic = call ptr @llvm.load.relative.i64(ptr @reltable._logger_parse_ige, i64 %reltable.shift), !dbg !2178
  %clsid = getelementptr inbounds i8, ptr %e, i64 38, !dbg !2179
  %5 = load i8, ptr %clsid, align 2, !dbg !2179, !tbaa !1222
  %sfd = getelementptr inbounds i8, ptr %e, i64 44, !dbg !2180
  %6 = load i32, ptr %sfd, align 4, !dbg !2180, !tbaa !1053
  %nbytes = getelementptr inbounds i8, ptr %e, i64 40, !dbg !2181
  %7 = load i32, ptr %nbytes, align 4, !dbg !2181, !tbaa !1053
  %cmp = icmp sgt i32 %7, 0, !dbg !2182
  %sub = add nsw i32 %7, -2
  %spec.select = select i1 %cmp, i32 %sub, i32 0, !dbg !2183
  %conv6 = zext i8 %5 to i32, !dbg !2184
  %conv4 = trunc i64 %2 to i32, !dbg !2185
  %call9 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %scratch, i64 noundef 4096, ptr noundef nonnull @.str.26, i64 noundef %1, i32 noundef %conv4, i64 noundef %3, ptr noundef nonnull %keybuf, ptr noundef %reltable.intrinsic, i32 noundef %conv6, i32 noundef %6, i32 noundef %spec.select) #21, !dbg !2186
  tail call void @llvm.dbg.value(metadata i32 %call9, metadata !2157, metadata !DIExpression()), !dbg !2164
  call void @llvm.lifetime.end.p0(i64 751, ptr nonnull %keybuf) #21, !dbg !2187
  ret i32 %call9, !dbg !2188
}

; Function Attrs: mustprogress nofree norecurse nounwind sanitize_thread willreturn uwtable
define internal void @_logger_log_item_store(ptr nocapture noundef writeonly %e, ptr nocapture readnone %d, ptr nocapture readnone %entry1, ptr nocapture noundef %ap) #14 !dbg !2189 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2191, metadata !DIExpression()), !dbg !2204
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2192, metadata !DIExpression()), !dbg !2204
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2193, metadata !DIExpression()), !dbg !2204
  tail call void @llvm.dbg.value(metadata ptr %ap, metadata !2194, metadata !DIExpression()), !dbg !2204
  %gp_offset = load i32, ptr %ap, align 8, !dbg !2205
  %fits_in_gp = icmp ult i32 %gp_offset, 41, !dbg !2205
  br i1 %fits_in_gp, label %vaarg.end, label %vaarg.end.thread, !dbg !2205

vaarg.end.thread:                                 ; preds = %entry
  %overflow_arg_area_p = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2205
  %overflow_arg_area = load ptr, ptr %overflow_arg_area_p, align 8, !dbg !2205
  %overflow_arg_area.next = getelementptr i8, ptr %overflow_arg_area, i64 8, !dbg !2205
  store ptr %overflow_arg_area.next, ptr %overflow_arg_area_p, align 8, !dbg !2205
  %0 = load i32, ptr %overflow_arg_area, align 4, !dbg !2205
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !2195, metadata !DIExpression()), !dbg !2204
  br label %vaarg.end11.thread, !dbg !2206

vaarg.end:                                        ; preds = %entry
  %1 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2205
  %reg_save_area = load ptr, ptr %1, align 8, !dbg !2205
  %2 = zext nneg i32 %gp_offset to i64, !dbg !2205
  %3 = getelementptr i8, ptr %reg_save_area, i64 %2, !dbg !2205
  %4 = add nuw nsw i32 %gp_offset, 8, !dbg !2205
  store i32 %4, ptr %ap, align 8, !dbg !2205
  %5 = load i32, ptr %3, align 4, !dbg !2205
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !2195, metadata !DIExpression()), !dbg !2204
  %fits_in_gp4 = icmp ult i32 %gp_offset, 33, !dbg !2206
  br i1 %fits_in_gp4, label %vaarg.end11, label %vaarg.end11.thread, !dbg !2206

vaarg.end11.thread:                               ; preds = %vaarg.end, %vaarg.end.thread
  %6 = phi i32 [ %0, %vaarg.end.thread ], [ %5, %vaarg.end ]
  %overflow_arg_area_p8 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2206
  %overflow_arg_area9 = load ptr, ptr %overflow_arg_area_p8, align 8, !dbg !2206
  %overflow_arg_area.next10 = getelementptr i8, ptr %overflow_arg_area9, i64 8, !dbg !2206
  store ptr %overflow_arg_area.next10, ptr %overflow_arg_area_p8, align 8, !dbg !2206
  %7 = load i32, ptr %overflow_arg_area9, align 4, !dbg !2206
  tail call void @llvm.dbg.value(metadata i32 %7, metadata !2196, metadata !DIExpression()), !dbg !2204
  br label %vaarg.end22.thread, !dbg !2207

vaarg.end11:                                      ; preds = %vaarg.end
  %8 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2206
  %reg_save_area6 = load ptr, ptr %8, align 8, !dbg !2206
  %9 = zext nneg i32 %4 to i64, !dbg !2206
  %10 = getelementptr i8, ptr %reg_save_area6, i64 %9, !dbg !2206
  %11 = add nuw nsw i32 %gp_offset, 16, !dbg !2206
  store i32 %11, ptr %ap, align 8, !dbg !2206
  %12 = load i32, ptr %10, align 4, !dbg !2206
  tail call void @llvm.dbg.value(metadata i32 %12, metadata !2196, metadata !DIExpression()), !dbg !2204
  %fits_in_gp15 = icmp ult i32 %gp_offset, 25, !dbg !2207
  br i1 %fits_in_gp15, label %vaarg.end22, label %vaarg.end22.thread, !dbg !2207

vaarg.end22.thread:                               ; preds = %vaarg.end11, %vaarg.end11.thread
  %13 = phi i32 [ %7, %vaarg.end11.thread ], [ %12, %vaarg.end11 ]
  %14 = phi i32 [ %6, %vaarg.end11.thread ], [ %5, %vaarg.end11 ]
  %overflow_arg_area_p19 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2207
  %overflow_arg_area20 = load ptr, ptr %overflow_arg_area_p19, align 8, !dbg !2207
  %overflow_arg_area.next21 = getelementptr i8, ptr %overflow_arg_area20, i64 8, !dbg !2207
  store ptr %overflow_arg_area.next21, ptr %overflow_arg_area_p19, align 8, !dbg !2207
  %15 = load ptr, ptr %overflow_arg_area20, align 8, !dbg !2207
  tail call void @llvm.dbg.value(metadata ptr %15, metadata !2197, metadata !DIExpression()), !dbg !2204
  br label %vaarg.end33.thread, !dbg !2208

vaarg.end22:                                      ; preds = %vaarg.end11
  %16 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2207
  %reg_save_area17 = load ptr, ptr %16, align 8, !dbg !2207
  %17 = zext nneg i32 %11 to i64, !dbg !2207
  %18 = getelementptr i8, ptr %reg_save_area17, i64 %17, !dbg !2207
  %19 = add nuw nsw i32 %gp_offset, 24, !dbg !2207
  store i32 %19, ptr %ap, align 8, !dbg !2207
  %20 = load ptr, ptr %18, align 8, !dbg !2207
  tail call void @llvm.dbg.value(metadata ptr %20, metadata !2197, metadata !DIExpression()), !dbg !2204
  %fits_in_gp26 = icmp ult i32 %gp_offset, 17, !dbg !2208
  br i1 %fits_in_gp26, label %vaarg.end33, label %vaarg.end33.thread, !dbg !2208

vaarg.end33.thread:                               ; preds = %vaarg.end22, %vaarg.end22.thread
  %21 = phi ptr [ %15, %vaarg.end22.thread ], [ %20, %vaarg.end22 ]
  %22 = phi i32 [ %14, %vaarg.end22.thread ], [ %5, %vaarg.end22 ]
  %23 = phi i32 [ %13, %vaarg.end22.thread ], [ %12, %vaarg.end22 ]
  %overflow_arg_area_p30 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2208
  %overflow_arg_area31 = load ptr, ptr %overflow_arg_area_p30, align 8, !dbg !2208
  %overflow_arg_area.next32 = getelementptr i8, ptr %overflow_arg_area31, i64 8, !dbg !2208
  store ptr %overflow_arg_area.next32, ptr %overflow_arg_area_p30, align 8, !dbg !2208
  %24 = load i32, ptr %overflow_arg_area31, align 4, !dbg !2208
  tail call void @llvm.dbg.value(metadata i32 %24, metadata !2198, metadata !DIExpression()), !dbg !2204
  br label %vaarg.end44.thread, !dbg !2209

vaarg.end33:                                      ; preds = %vaarg.end22
  %25 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2208
  %reg_save_area28 = load ptr, ptr %25, align 8, !dbg !2208
  %26 = zext nneg i32 %19 to i64, !dbg !2208
  %27 = getelementptr i8, ptr %reg_save_area28, i64 %26, !dbg !2208
  %28 = or disjoint i32 %gp_offset, 32, !dbg !2208
  store i32 %28, ptr %ap, align 8, !dbg !2208
  %29 = load i32, ptr %27, align 4, !dbg !2208
  tail call void @llvm.dbg.value(metadata i32 %29, metadata !2198, metadata !DIExpression()), !dbg !2204
  %fits_in_gp37 = icmp ult i32 %28, 41, !dbg !2209
  br i1 %fits_in_gp37, label %vaarg.end44, label %vaarg.end44.thread, !dbg !2209

vaarg.end44.thread:                               ; preds = %vaarg.end33, %vaarg.end33.thread
  %30 = phi i32 [ %24, %vaarg.end33.thread ], [ %29, %vaarg.end33 ]
  %31 = phi i32 [ %23, %vaarg.end33.thread ], [ %12, %vaarg.end33 ]
  %32 = phi i32 [ %22, %vaarg.end33.thread ], [ %5, %vaarg.end33 ]
  %33 = phi ptr [ %21, %vaarg.end33.thread ], [ %20, %vaarg.end33 ]
  %overflow_arg_area_p41 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2209
  %overflow_arg_area42 = load ptr, ptr %overflow_arg_area_p41, align 8, !dbg !2209
  %overflow_arg_area.next43 = getelementptr i8, ptr %overflow_arg_area42, i64 8, !dbg !2209
  store ptr %overflow_arg_area.next43, ptr %overflow_arg_area_p41, align 8, !dbg !2209
  %34 = load i32, ptr %overflow_arg_area42, align 4, !dbg !2209
  tail call void @llvm.dbg.value(metadata i32 %34, metadata !2199, metadata !DIExpression()), !dbg !2204
  br label %vaarg.in_mem51, !dbg !2210

vaarg.end44:                                      ; preds = %vaarg.end33
  %35 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2209
  %reg_save_area39 = load ptr, ptr %35, align 8, !dbg !2209
  %36 = zext nneg i32 %28 to i64, !dbg !2209
  %37 = getelementptr i8, ptr %reg_save_area39, i64 %36, !dbg !2209
  %38 = add nuw nsw i32 %gp_offset, 40, !dbg !2209
  store i32 %38, ptr %ap, align 8, !dbg !2209
  %39 = load i32, ptr %37, align 4, !dbg !2209
  tail call void @llvm.dbg.value(metadata i32 %39, metadata !2199, metadata !DIExpression()), !dbg !2204
  %fits_in_gp48 = icmp eq i32 %gp_offset, 0, !dbg !2210
  br i1 %fits_in_gp48, label %vaarg.in_reg49, label %vaarg.in_mem51, !dbg !2210

vaarg.in_reg49:                                   ; preds = %vaarg.end44
  %40 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2210
  %reg_save_area50 = load ptr, ptr %40, align 8, !dbg !2210
  %41 = zext nneg i32 %38 to i64, !dbg !2210
  %42 = getelementptr i8, ptr %reg_save_area50, i64 %41, !dbg !2210
  store i32 48, ptr %ap, align 8, !dbg !2210
  br label %vaarg.end77, !dbg !2210

vaarg.in_mem51:                                   ; preds = %vaarg.end44.thread, %vaarg.end44
  %43 = phi i32 [ %34, %vaarg.end44.thread ], [ %39, %vaarg.end44 ]
  %44 = phi ptr [ %33, %vaarg.end44.thread ], [ %20, %vaarg.end44 ]
  %45 = phi i32 [ %32, %vaarg.end44.thread ], [ %5, %vaarg.end44 ]
  %46 = phi i32 [ %31, %vaarg.end44.thread ], [ %12, %vaarg.end44 ]
  %47 = phi i32 [ %30, %vaarg.end44.thread ], [ %29, %vaarg.end44 ]
  %overflow_arg_area_p52 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2210
  %overflow_arg_area53 = load ptr, ptr %overflow_arg_area_p52, align 8, !dbg !2210
  %overflow_arg_area.next54 = getelementptr i8, ptr %overflow_arg_area53, i64 8, !dbg !2210
  store ptr %overflow_arg_area.next54, ptr %overflow_arg_area_p52, align 8, !dbg !2210
  br label %vaarg.end77, !dbg !2210

vaarg.end77:                                      ; preds = %vaarg.in_mem51, %vaarg.in_reg49
  %48 = phi i32 [ %43, %vaarg.in_mem51 ], [ %39, %vaarg.in_reg49 ]
  %49 = phi ptr [ %44, %vaarg.in_mem51 ], [ %20, %vaarg.in_reg49 ]
  %50 = phi i32 [ %45, %vaarg.in_mem51 ], [ %5, %vaarg.in_reg49 ]
  %51 = phi i32 [ %46, %vaarg.in_mem51 ], [ %12, %vaarg.in_reg49 ]
  %52 = phi i32 [ %47, %vaarg.in_mem51 ], [ %29, %vaarg.in_reg49 ]
  %vaarg.addr56 = phi ptr [ %overflow_arg_area53, %vaarg.in_mem51 ], [ %42, %vaarg.in_reg49 ], !dbg !2210
  %53 = load i32, ptr %vaarg.addr56, align 4, !dbg !2210
  tail call void @llvm.dbg.value(metadata i32 %53, metadata !2200, metadata !DIExpression()), !dbg !2204
  %overflow_arg_area_p63 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2211
  %overflow_arg_area64 = load ptr, ptr %overflow_arg_area_p63, align 8, !dbg !2211
  %overflow_arg_area.next65 = getelementptr i8, ptr %overflow_arg_area64, i64 8, !dbg !2211
  store ptr %overflow_arg_area.next65, ptr %overflow_arg_area_p63, align 8, !dbg !2211
  %54 = load i32, ptr %overflow_arg_area64, align 4, !dbg !2211
  %conv = trunc i32 %54 to i8, !dbg !2211
  tail call void @llvm.dbg.value(metadata i8 %conv, metadata !2201, metadata !DIExpression()), !dbg !2204
  %overflow_arg_area_p74 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2212
  %overflow_arg_area.next76 = getelementptr i8, ptr %overflow_arg_area64, i64 16, !dbg !2212
  store ptr %overflow_arg_area.next76, ptr %overflow_arg_area_p74, align 8, !dbg !2212
  %55 = load i32, ptr %overflow_arg_area.next65, align 4, !dbg !2212
  tail call void @llvm.dbg.value(metadata i32 %55, metadata !2202, metadata !DIExpression()), !dbg !2204
  %data = getelementptr inbounds i8, ptr %e, i64 36, !dbg !2213
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !2203, metadata !DIExpression()), !dbg !2204
  store i32 %50, ptr %data, align 4, !dbg !2214, !tbaa !1053
  %cmd = getelementptr inbounds i8, ptr %e, i64 40, !dbg !2215
  store i32 %51, ptr %cmd, align 4, !dbg !2216, !tbaa !1053
  %conv80 = trunc i32 %52 to i8, !dbg !2217
  %nkey81 = getelementptr inbounds i8, ptr %e, i64 48, !dbg !2218
  store i8 %conv80, ptr %nkey81, align 4, !dbg !2219, !tbaa !1222
  %nbytes82 = getelementptr inbounds i8, ptr %e, i64 52, !dbg !2220
  store i32 %48, ptr %nbytes82, align 4, !dbg !2221, !tbaa !1053
  %clsid83 = getelementptr inbounds i8, ptr %e, i64 49, !dbg !2222
  store i8 %conv, ptr %clsid83, align 1, !dbg !2223, !tbaa !1222
  %cmp.not = icmp eq i32 %53, 0, !dbg !2224
  br i1 %cmp.not, label %if.end, label %if.then, !dbg !2226

if.then:                                          ; preds = %vaarg.end77
  %56 = load volatile i32, ptr @current_time, align 4, !dbg !2227, !tbaa !1053
  %sub = sub i32 %53, %56, !dbg !2229
  br label %if.end, !dbg !2230

if.end:                                           ; preds = %vaarg.end77, %if.then
  %sub.sink = phi i32 [ %sub, %if.then ], [ 0, %vaarg.end77 ], !dbg !2231
  %57 = getelementptr inbounds i8, ptr %e, i64 44, !dbg !2231
  store i32 %sub.sink, ptr %57, align 4, !dbg !2231
  %key87 = getelementptr inbounds i8, ptr %e, i64 60, !dbg !2232
  %conv89 = sext i32 %52 to i64, !dbg !2233
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 4 %key87, ptr align 1 %49, i64 %conv89, i1 false), !dbg !2234
  %sfd90 = getelementptr inbounds i8, ptr %e, i64 56, !dbg !2235
  store i32 %55, ptr %sfd90, align 4, !dbg !2236, !tbaa !1053
  %add = add i32 %52, 24, !dbg !2237
  %size = getelementptr inbounds i8, ptr %e, i64 32, !dbg !2238
  store i32 %add, ptr %size, align 8, !dbg !2239, !tbaa !1053
  ret void, !dbg !2240
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal noundef i32 @_logger_parse_ise(ptr noundef %e, ptr nocapture noundef writeonly %scratch) #1 !dbg !2241 {
entry:
  %keybuf = alloca [751 x i8], align 16, !DIAssignID !2253
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2247, metadata !DIExpression(), metadata !2253, metadata ptr %keybuf, metadata !DIExpression()), !dbg !2254
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2249, metadata !DIExpression(), metadata !2255, metadata ptr poison, metadata !DIExpression()), !dbg !2254
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2251, metadata !DIExpression(), metadata !2256, metadata ptr poison, metadata !DIExpression()), !dbg !2254
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2243, metadata !DIExpression()), !dbg !2254
  tail call void @llvm.dbg.value(metadata ptr %scratch, metadata !2244, metadata !DIExpression()), !dbg !2254
  tail call void @llvm.dbg.value(metadata ptr @.str.27, metadata !2246, metadata !DIExpression()), !dbg !2254
  call void @llvm.lifetime.start.p0(i64 751, ptr nonnull %keybuf) #21, !dbg !2257
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2248, metadata !DIExpression(DW_OP_plus_uconst, 36, DW_OP_stack_value)), !dbg !2254
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2249, metadata !DIExpression(), metadata !2258, metadata ptr poison, metadata !DIExpression()), !dbg !2254
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2251, metadata !DIExpression(), metadata !2259, metadata ptr poison, metadata !DIExpression()), !dbg !2254
  %cmd1 = getelementptr inbounds i8, ptr %e, i64 40, !dbg !2260
  %0 = load i32, ptr %cmd1, align 4, !dbg !2260, !tbaa !1053
  %cmp = icmp slt i32 %0, 9, !dbg !2262
  br i1 %cmp, label %if.then, label %if.end, !dbg !2263

if.then:                                          ; preds = %entry
  %idxprom = sext i32 %0 to i64, !dbg !2264
  %reltable.shift28 = shl i64 %idxprom, 2, !dbg !2264
  %reltable.intrinsic29 = call ptr @llvm.load.relative.i64(ptr @reltable._logger_parse_ise.55, i64 %reltable.shift28), !dbg !2264
  tail call void @llvm.dbg.value(metadata ptr %reltable.intrinsic29, metadata !2246, metadata !DIExpression()), !dbg !2254
  br label %if.end, !dbg !2265

if.end:                                           ; preds = %if.then, %entry
  %cmd.0 = phi ptr [ %reltable.intrinsic29, %if.then ], [ @.str.27, %entry ], !dbg !2254
  %data = getelementptr inbounds i8, ptr %e, i64 36, !dbg !2266
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !2248, metadata !DIExpression()), !dbg !2254
  tail call void @llvm.dbg.value(metadata ptr %cmd.0, metadata !2246, metadata !DIExpression()), !dbg !2254
  %key = getelementptr inbounds i8, ptr %e, i64 60, !dbg !2267
  %nkey = getelementptr inbounds i8, ptr %e, i64 48, !dbg !2268
  %1 = load i8, ptr %nkey, align 4, !dbg !2268, !tbaa !1222
  %conv = zext i8 %1 to i64, !dbg !2269
  %call = call zeroext i1 @uriencode(ptr noundef nonnull %key, ptr noundef nonnull %keybuf, i64 noundef %conv, i64 noundef 751) #21, !dbg !2270
  %tv = getelementptr inbounds i8, ptr %e, i64 16, !dbg !2271
  %2 = load i64, ptr %tv, align 8, !dbg !2272, !tbaa !2024
  %tv_usec = getelementptr inbounds i8, ptr %e, i64 24, !dbg !2273
  %3 = load i64, ptr %tv_usec, align 8, !dbg !2273, !tbaa !2026
  %gid = getelementptr inbounds i8, ptr %e, i64 8, !dbg !2274
  %4 = load i64, ptr %gid, align 8, !dbg !2274, !tbaa !1067
  %5 = load i32, ptr %data, align 4, !dbg !2275, !tbaa !1053
  %idxprom8 = sext i32 %5 to i64, !dbg !2276
  %reltable.shift = shl i64 %idxprom8, 2, !dbg !2276
  %reltable.intrinsic = call ptr @llvm.load.relative.i64(ptr @reltable._logger_parse_ise, i64 %reltable.shift), !dbg !2276
  %ttl = getelementptr inbounds i8, ptr %e, i64 44, !dbg !2277
  %6 = load i32, ptr %ttl, align 4, !dbg !2277, !tbaa !1053
  %clsid = getelementptr inbounds i8, ptr %e, i64 49, !dbg !2278
  %7 = load i8, ptr %clsid, align 1, !dbg !2278, !tbaa !1222
  %sfd = getelementptr inbounds i8, ptr %e, i64 56, !dbg !2279
  %8 = load i32, ptr %sfd, align 4, !dbg !2279, !tbaa !1053
  %nbytes = getelementptr inbounds i8, ptr %e, i64 52, !dbg !2280
  %9 = load i32, ptr %nbytes, align 4, !dbg !2280, !tbaa !1053
  %cmp11 = icmp sgt i32 %9, 0, !dbg !2281
  %sub = add nsw i32 %9, -2
  %spec.select = select i1 %cmp11, i32 %sub, i32 0, !dbg !2282
  %conv10 = zext i8 %7 to i32, !dbg !2283
  %conv6 = trunc i64 %3 to i32, !dbg !2284
  %call14 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %scratch, i64 noundef 4096, ptr noundef nonnull @.str.40, i64 noundef %2, i32 noundef %conv6, i64 noundef %4, ptr noundef nonnull %keybuf, ptr noundef %reltable.intrinsic, ptr noundef %cmd.0, i32 noundef %6, i32 noundef %conv10, i32 noundef %8, i32 noundef %spec.select) #21, !dbg !2285
  tail call void @llvm.dbg.value(metadata i32 %call14, metadata !2245, metadata !DIExpression()), !dbg !2254
  call void @llvm.lifetime.end.p0(i64 751, ptr nonnull %keybuf) #21, !dbg !2286
  ret i32 %call14, !dbg !2287
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, inaccessiblemem: none) uwtable
define internal void @_logger_log_conn_event(ptr nocapture noundef writeonly %e, ptr nocapture readnone %d, ptr nocapture readnone %entry1, ptr nocapture noundef %ap) #15 !dbg !2288 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2290, metadata !DIExpression()), !dbg !2300
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2291, metadata !DIExpression()), !dbg !2300
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2292, metadata !DIExpression()), !dbg !2300
  tail call void @llvm.dbg.value(metadata ptr %ap, metadata !2293, metadata !DIExpression()), !dbg !2300
  %gp_offset = load i32, ptr %ap, align 8, !dbg !2301
  %fits_in_gp = icmp ult i32 %gp_offset, 41, !dbg !2301
  br i1 %fits_in_gp, label %vaarg.end, label %vaarg.end.thread, !dbg !2301

vaarg.end.thread:                                 ; preds = %entry
  %overflow_arg_area_p = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2301
  %overflow_arg_area = load ptr, ptr %overflow_arg_area_p, align 8, !dbg !2301
  %overflow_arg_area.next = getelementptr i8, ptr %overflow_arg_area, i64 8, !dbg !2301
  store ptr %overflow_arg_area.next, ptr %overflow_arg_area_p, align 8, !dbg !2301
  %0 = load ptr, ptr %overflow_arg_area, align 8, !dbg !2301
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2294, metadata !DIExpression()), !dbg !2300
  br label %vaarg.end11.thread, !dbg !2302

vaarg.end:                                        ; preds = %entry
  %1 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2301
  %reg_save_area = load ptr, ptr %1, align 8, !dbg !2301
  %2 = zext nneg i32 %gp_offset to i64, !dbg !2301
  %3 = getelementptr i8, ptr %reg_save_area, i64 %2, !dbg !2301
  %4 = add nuw nsw i32 %gp_offset, 8, !dbg !2301
  store i32 %4, ptr %ap, align 8, !dbg !2301
  %5 = load ptr, ptr %3, align 8, !dbg !2301
  tail call void @llvm.dbg.value(metadata ptr %5, metadata !2294, metadata !DIExpression()), !dbg !2300
  %fits_in_gp4 = icmp ult i32 %gp_offset, 33, !dbg !2302
  br i1 %fits_in_gp4, label %vaarg.end11, label %vaarg.end11.thread, !dbg !2302

vaarg.end11.thread:                               ; preds = %vaarg.end, %vaarg.end.thread
  %6 = phi ptr [ %0, %vaarg.end.thread ], [ %5, %vaarg.end ]
  %overflow_arg_area_p8 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2302
  %overflow_arg_area9 = load ptr, ptr %overflow_arg_area_p8, align 8, !dbg !2302
  %overflow_arg_area.next10 = getelementptr i8, ptr %overflow_arg_area9, i64 8, !dbg !2302
  store ptr %overflow_arg_area.next10, ptr %overflow_arg_area_p8, align 8, !dbg !2302
  %7 = load i32, ptr %overflow_arg_area9, align 4, !dbg !2302
  tail call void @llvm.dbg.value(metadata i32 %7, metadata !2295, metadata !DIExpression()), !dbg !2300
  br label %vaarg.end22.thread, !dbg !2303

vaarg.end11:                                      ; preds = %vaarg.end
  %8 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2302
  %reg_save_area6 = load ptr, ptr %8, align 8, !dbg !2302
  %9 = zext nneg i32 %4 to i64, !dbg !2302
  %10 = getelementptr i8, ptr %reg_save_area6, i64 %9, !dbg !2302
  %11 = add nuw nsw i32 %gp_offset, 16, !dbg !2302
  store i32 %11, ptr %ap, align 8, !dbg !2302
  %12 = load i32, ptr %10, align 4, !dbg !2302
  tail call void @llvm.dbg.value(metadata i32 %12, metadata !2295, metadata !DIExpression()), !dbg !2300
  %fits_in_gp15 = icmp ult i32 %gp_offset, 25, !dbg !2303
  br i1 %fits_in_gp15, label %vaarg.end22, label %vaarg.end22.thread, !dbg !2303

vaarg.end22.thread:                               ; preds = %vaarg.end11, %vaarg.end11.thread
  %13 = phi i32 [ %7, %vaarg.end11.thread ], [ %12, %vaarg.end11 ]
  %14 = phi ptr [ %6, %vaarg.end11.thread ], [ %5, %vaarg.end11 ]
  %overflow_arg_area_p19 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2303
  %overflow_arg_area20 = load ptr, ptr %overflow_arg_area_p19, align 8, !dbg !2303
  %overflow_arg_area.next21 = getelementptr i8, ptr %overflow_arg_area20, i64 8, !dbg !2303
  store ptr %overflow_arg_area.next21, ptr %overflow_arg_area_p19, align 8, !dbg !2303
  %15 = load i32, ptr %overflow_arg_area20, align 4, !dbg !2303
  tail call void @llvm.dbg.value(metadata i32 %15, metadata !2296, metadata !DIExpression()), !dbg !2300
  br label %vaarg.end33.thread, !dbg !2304

vaarg.end22:                                      ; preds = %vaarg.end11
  %16 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2303
  %reg_save_area17 = load ptr, ptr %16, align 8, !dbg !2303
  %17 = zext nneg i32 %11 to i64, !dbg !2303
  %18 = getelementptr i8, ptr %reg_save_area17, i64 %17, !dbg !2303
  %19 = add nuw nsw i32 %gp_offset, 24, !dbg !2303
  store i32 %19, ptr %ap, align 8, !dbg !2303
  %20 = load i32, ptr %18, align 4, !dbg !2303
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !2296, metadata !DIExpression()), !dbg !2300
  %fits_in_gp26 = icmp ult i32 %gp_offset, 17, !dbg !2304
  br i1 %fits_in_gp26, label %vaarg.end33, label %vaarg.end33.thread, !dbg !2304

vaarg.end33.thread:                               ; preds = %vaarg.end22, %vaarg.end22.thread
  %21 = phi i32 [ %15, %vaarg.end22.thread ], [ %20, %vaarg.end22 ]
  %22 = phi ptr [ %14, %vaarg.end22.thread ], [ %5, %vaarg.end22 ]
  %23 = phi i32 [ %13, %vaarg.end22.thread ], [ %12, %vaarg.end22 ]
  %overflow_arg_area_p30 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2304
  %overflow_arg_area31 = load ptr, ptr %overflow_arg_area_p30, align 8, !dbg !2304
  %overflow_arg_area.next32 = getelementptr i8, ptr %overflow_arg_area31, i64 8, !dbg !2304
  store ptr %overflow_arg_area.next32, ptr %overflow_arg_area_p30, align 8, !dbg !2304
  %24 = load i32, ptr %overflow_arg_area31, align 4, !dbg !2304
  tail call void @llvm.dbg.value(metadata i32 %24, metadata !2297, metadata !DIExpression()), !dbg !2300
  br label %vaarg.in_mem40, !dbg !2305

vaarg.end33:                                      ; preds = %vaarg.end22
  %25 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2304
  %reg_save_area28 = load ptr, ptr %25, align 8, !dbg !2304
  %26 = zext nneg i32 %19 to i64, !dbg !2304
  %27 = getelementptr i8, ptr %reg_save_area28, i64 %26, !dbg !2304
  %28 = or disjoint i32 %gp_offset, 32, !dbg !2304
  store i32 %28, ptr %ap, align 8, !dbg !2304
  %29 = load i32, ptr %27, align 4, !dbg !2304
  tail call void @llvm.dbg.value(metadata i32 %29, metadata !2297, metadata !DIExpression()), !dbg !2300
  %fits_in_gp37 = icmp ult i32 %28, 41, !dbg !2305
  br i1 %fits_in_gp37, label %vaarg.in_reg38, label %vaarg.in_mem40, !dbg !2305

vaarg.in_reg38:                                   ; preds = %vaarg.end33
  %30 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2305
  %reg_save_area39 = load ptr, ptr %30, align 8, !dbg !2305
  %31 = zext nneg i32 %28 to i64, !dbg !2305
  %32 = getelementptr i8, ptr %reg_save_area39, i64 %31, !dbg !2305
  %33 = add nuw nsw i32 %gp_offset, 40, !dbg !2305
  store i32 %33, ptr %ap, align 8, !dbg !2305
  br label %vaarg.end44, !dbg !2305

vaarg.in_mem40:                                   ; preds = %vaarg.end33.thread, %vaarg.end33
  %34 = phi i32 [ %24, %vaarg.end33.thread ], [ %29, %vaarg.end33 ]
  %35 = phi i32 [ %23, %vaarg.end33.thread ], [ %12, %vaarg.end33 ]
  %36 = phi ptr [ %22, %vaarg.end33.thread ], [ %5, %vaarg.end33 ]
  %37 = phi i32 [ %21, %vaarg.end33.thread ], [ %20, %vaarg.end33 ]
  %overflow_arg_area_p41 = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2305
  %overflow_arg_area42 = load ptr, ptr %overflow_arg_area_p41, align 8, !dbg !2305
  %overflow_arg_area.next43 = getelementptr i8, ptr %overflow_arg_area42, i64 8, !dbg !2305
  store ptr %overflow_arg_area.next43, ptr %overflow_arg_area_p41, align 8, !dbg !2305
  br label %vaarg.end44, !dbg !2305

vaarg.end44:                                      ; preds = %vaarg.in_mem40, %vaarg.in_reg38
  %38 = phi i32 [ %29, %vaarg.in_reg38 ], [ %34, %vaarg.in_mem40 ]
  %39 = phi i32 [ %12, %vaarg.in_reg38 ], [ %35, %vaarg.in_mem40 ]
  %40 = phi ptr [ %5, %vaarg.in_reg38 ], [ %36, %vaarg.in_mem40 ]
  %41 = phi i32 [ %20, %vaarg.in_reg38 ], [ %37, %vaarg.in_mem40 ]
  %vaarg.addr45 = phi ptr [ %32, %vaarg.in_reg38 ], [ %overflow_arg_area42, %vaarg.in_mem40 ], !dbg !2305
  %42 = load i32, ptr %vaarg.addr45, align 4, !dbg !2305
  tail call void @llvm.dbg.value(metadata i32 %42, metadata !2298, metadata !DIExpression()), !dbg !2300
  %data = getelementptr inbounds i8, ptr %e, i64 36, !dbg !2306
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !2299, metadata !DIExpression()), !dbg !2300
  %addr46 = getelementptr inbounds i8, ptr %e, i64 48, !dbg !2307
  %conv = zext i32 %39 to i64, !dbg !2308
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 4 %addr46, ptr align 4 %40, i64 %conv, i1 false), !dbg !2309
  %sfd47 = getelementptr inbounds i8, ptr %e, i64 44, !dbg !2310
  store i32 %42, ptr %sfd47, align 4, !dbg !2311, !tbaa !2312
  store i32 %41, ptr %data, align 4, !dbg !2314, !tbaa !2315
  %reason49 = getelementptr inbounds i8, ptr %e, i64 40, !dbg !2316
  store i32 %38, ptr %reason49, align 4, !dbg !2317, !tbaa !2318
  %size = getelementptr inbounds i8, ptr %e, i64 32, !dbg !2319
  store i32 40, ptr %size, align 8, !dbg !2320, !tbaa !1053
  ret void, !dbg !2321
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal noundef i32 @_logger_parse_cne(ptr noundef %e, ptr nocapture noundef writeonly %scratch) #1 !dbg !2322 {
entry:
  %rip = alloca [64 x i8], align 16, !DIAssignID !2333
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2328, metadata !DIExpression(), metadata !2333, metadata ptr %rip, metadata !DIExpression()), !dbg !2334
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2324, metadata !DIExpression()), !dbg !2334
  tail call void @llvm.dbg.value(metadata ptr %scratch, metadata !2325, metadata !DIExpression()), !dbg !2334
  tail call void @llvm.dbg.value(metadata i16 0, metadata !2327, metadata !DIExpression()), !dbg !2334
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %rip) #21, !dbg !2335
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2330, metadata !DIExpression(DW_OP_plus_uconst, 36, DW_OP_stack_value)), !dbg !2334
  %addr = getelementptr inbounds i8, ptr %e, i64 48, !dbg !2336
  tail call void @llvm.dbg.value(metadata ptr %addr, metadata !2337, metadata !DIExpression()), !dbg !2346
  tail call void @llvm.dbg.value(metadata ptr %rip, metadata !2343, metadata !DIExpression()), !dbg !2346
  tail call void @llvm.dbg.value(metadata i64 64, metadata !2344, metadata !DIExpression()), !dbg !2346
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2345, metadata !DIExpression()), !dbg !2346
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(64) %rip, i8 0, i64 64, i1 false), !dbg !2348, !DIAssignID !2349
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2328, metadata !DIExpression(), metadata !2349, metadata ptr %rip, metadata !DIExpression()), !dbg !2334
  %0 = load i16, ptr %addr, align 4, !dbg !2350, !tbaa !2351
  switch i16 %0, label %_logger_util_addr_endpoint.exit [
    i16 2, label %sw.bb.i
    i16 10, label %sw.bb3.i
    i16 0, label %sw.bb8.i
    i16 1, label %sw.bb8.i
  ], !dbg !2352

sw.bb.i:                                          ; preds = %entry
  %sin_addr.i = getelementptr inbounds i8, ptr %e, i64 52, !dbg !2353
  %call.i = call ptr @inet_ntop(i32 noundef 2, ptr noundef nonnull %sin_addr.i, ptr noundef nonnull %rip, i32 noundef 63) #21, !dbg !2355
  %sin_port.i = getelementptr inbounds i8, ptr %e, i64 50, !dbg !2356
  %1 = load i16, ptr %sin_port.i, align 2, !dbg !2356, !tbaa !2357
  %rev.i.i = call noundef i16 @llvm.bswap.i16(i16 %1)
  tail call void @llvm.dbg.value(metadata i16 %rev.i.i, metadata !2327, metadata !DIExpression()), !dbg !2334
  br label %_logger_util_addr_endpoint.exit, !dbg !2360

sw.bb3.i:                                         ; preds = %entry
  %sin6_addr.i = getelementptr inbounds i8, ptr %e, i64 56, !dbg !2361
  %call6.i = call ptr @inet_ntop(i32 noundef 10, ptr noundef nonnull %sin6_addr.i, ptr noundef nonnull %rip, i32 noundef 63) #21, !dbg !2362
  %sin6_port.i = getelementptr inbounds i8, ptr %e, i64 50, !dbg !2363
  %2 = load i16, ptr %sin6_port.i, align 2, !dbg !2363, !tbaa !2364
  %rev.i21.i = call noundef i16 @llvm.bswap.i16(i16 %2)
  tail call void @llvm.dbg.value(metadata i16 %rev.i21.i, metadata !2327, metadata !DIExpression()), !dbg !2334
  br label %_logger_util_addr_endpoint.exit, !dbg !2365

sw.bb8.i:                                         ; preds = %entry, %entry
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(5) %rip, ptr noundef nonnull align 1 dereferenceable(5) @.str.45, i64 noundef 5, i1 false) #21, !dbg !2366, !DIAssignID !2367
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2328, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 40), metadata !2367, metadata ptr %rip, metadata !DIExpression()), !dbg !2334
  br label %_logger_util_addr_endpoint.exit, !dbg !2368

_logger_util_addr_endpoint.exit:                  ; preds = %entry, %sw.bb.i, %sw.bb3.i, %sw.bb8.i
  %rport.0 = phi i16 [ 0, %entry ], [ 0, %sw.bb8.i ], [ %rev.i21.i, %sw.bb3.i ], [ %rev.i.i, %sw.bb.i ], !dbg !2346
  %data = getelementptr inbounds i8, ptr %e, i64 36, !dbg !2369
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !2330, metadata !DIExpression()), !dbg !2334
  tail call void @llvm.dbg.value(metadata i16 %rport.0, metadata !2327, metadata !DIExpression()), !dbg !2334
  %tv = getelementptr inbounds i8, ptr %e, i64 16, !dbg !2370
  %3 = load i64, ptr %tv, align 8, !dbg !2371, !tbaa !2024
  %tv_usec = getelementptr inbounds i8, ptr %e, i64 24, !dbg !2372
  %4 = load i64, ptr %tv_usec, align 8, !dbg !2372, !tbaa !2026
  %conv = trunc i64 %4 to i32, !dbg !2373
  %gid = getelementptr inbounds i8, ptr %e, i64 8, !dbg !2374
  %5 = load i64, ptr %gid, align 8, !dbg !2374, !tbaa !1067
  %conv4 = zext i16 %rport.0 to i32, !dbg !2375
  %6 = load i32, ptr %data, align 4, !dbg !2376, !tbaa !2315
  %idxprom = sext i32 %6 to i64, !dbg !2377
  %arrayidx = getelementptr inbounds [3 x ptr], ptr @__const._logger_parse_cce.transport_map, i64 0, i64 %idxprom, !dbg !2377
  %7 = load ptr, ptr %arrayidx, align 8, !dbg !2377, !tbaa !1039
  %sfd = getelementptr inbounds i8, ptr %e, i64 44, !dbg !2378
  %8 = load i32, ptr %sfd, align 4, !dbg !2378, !tbaa !2312
  %call5 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %scratch, i64 noundef 4096, ptr noundef nonnull @.str.44, i64 noundef %3, i32 noundef %conv, i64 noundef %5, ptr noundef nonnull %rip, i32 noundef %conv4, ptr noundef %7, i32 noundef %8) #21, !dbg !2379
  tail call void @llvm.dbg.value(metadata i32 %call5, metadata !2326, metadata !DIExpression()), !dbg !2334
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %rip) #21, !dbg !2380
  ret i32 %call5, !dbg !2381
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal noundef i32 @_logger_parse_cce(ptr noundef %e, ptr nocapture noundef writeonly %scratch) #1 !dbg !2382 {
entry:
  %rip = alloca [64 x i8], align 16, !DIAssignID !2392
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2388, metadata !DIExpression(), metadata !2392, metadata ptr %rip, metadata !DIExpression()), !dbg !2393
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2384, metadata !DIExpression()), !dbg !2393
  tail call void @llvm.dbg.value(metadata ptr %scratch, metadata !2385, metadata !DIExpression()), !dbg !2393
  tail call void @llvm.dbg.value(metadata i16 0, metadata !2387, metadata !DIExpression()), !dbg !2393
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %rip) #21, !dbg !2394
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2389, metadata !DIExpression(DW_OP_plus_uconst, 36, DW_OP_stack_value)), !dbg !2393
  %addr = getelementptr inbounds i8, ptr %e, i64 48, !dbg !2395
  tail call void @llvm.dbg.value(metadata ptr %addr, metadata !2337, metadata !DIExpression()), !dbg !2396
  tail call void @llvm.dbg.value(metadata ptr %rip, metadata !2343, metadata !DIExpression()), !dbg !2396
  tail call void @llvm.dbg.value(metadata i64 64, metadata !2344, metadata !DIExpression()), !dbg !2396
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2345, metadata !DIExpression()), !dbg !2396
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(64) %rip, i8 0, i64 64, i1 false), !dbg !2398, !DIAssignID !2399
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2388, metadata !DIExpression(), metadata !2399, metadata ptr %rip, metadata !DIExpression()), !dbg !2393
  %0 = load i16, ptr %addr, align 4, !dbg !2400, !tbaa !2351
  switch i16 %0, label %_logger_util_addr_endpoint.exit [
    i16 2, label %sw.bb.i
    i16 10, label %sw.bb3.i
    i16 0, label %sw.bb8.i
    i16 1, label %sw.bb8.i
  ], !dbg !2401

sw.bb.i:                                          ; preds = %entry
  %sin_addr.i = getelementptr inbounds i8, ptr %e, i64 52, !dbg !2402
  %call.i = call ptr @inet_ntop(i32 noundef 2, ptr noundef nonnull %sin_addr.i, ptr noundef nonnull %rip, i32 noundef 63) #21, !dbg !2403
  %sin_port.i = getelementptr inbounds i8, ptr %e, i64 50, !dbg !2404
  %1 = load i16, ptr %sin_port.i, align 2, !dbg !2404, !tbaa !2357
  %rev.i.i = call noundef i16 @llvm.bswap.i16(i16 %1)
  tail call void @llvm.dbg.value(metadata i16 %rev.i.i, metadata !2387, metadata !DIExpression()), !dbg !2393
  br label %_logger_util_addr_endpoint.exit, !dbg !2405

sw.bb3.i:                                         ; preds = %entry
  %sin6_addr.i = getelementptr inbounds i8, ptr %e, i64 56, !dbg !2406
  %call6.i = call ptr @inet_ntop(i32 noundef 10, ptr noundef nonnull %sin6_addr.i, ptr noundef nonnull %rip, i32 noundef 63) #21, !dbg !2407
  %sin6_port.i = getelementptr inbounds i8, ptr %e, i64 50, !dbg !2408
  %2 = load i16, ptr %sin6_port.i, align 2, !dbg !2408, !tbaa !2364
  %rev.i21.i = call noundef i16 @llvm.bswap.i16(i16 %2)
  tail call void @llvm.dbg.value(metadata i16 %rev.i21.i, metadata !2387, metadata !DIExpression()), !dbg !2393
  br label %_logger_util_addr_endpoint.exit, !dbg !2409

sw.bb8.i:                                         ; preds = %entry, %entry
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(5) %rip, ptr noundef nonnull align 1 dereferenceable(5) @.str.45, i64 noundef 5, i1 false) #21, !dbg !2410, !DIAssignID !2411
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2388, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 40), metadata !2411, metadata ptr %rip, metadata !DIExpression()), !dbg !2393
  br label %_logger_util_addr_endpoint.exit, !dbg !2412

_logger_util_addr_endpoint.exit:                  ; preds = %entry, %sw.bb.i, %sw.bb3.i, %sw.bb8.i
  %rport.0 = phi i16 [ 0, %entry ], [ 0, %sw.bb8.i ], [ %rev.i21.i, %sw.bb3.i ], [ %rev.i.i, %sw.bb.i ], !dbg !2396
  %data = getelementptr inbounds i8, ptr %e, i64 36, !dbg !2413
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !2389, metadata !DIExpression()), !dbg !2393
  tail call void @llvm.dbg.value(metadata i16 %rport.0, metadata !2387, metadata !DIExpression()), !dbg !2393
  %tv = getelementptr inbounds i8, ptr %e, i64 16, !dbg !2414
  %3 = load i64, ptr %tv, align 8, !dbg !2415, !tbaa !2024
  %tv_usec = getelementptr inbounds i8, ptr %e, i64 24, !dbg !2416
  %4 = load i64, ptr %tv_usec, align 8, !dbg !2416, !tbaa !2026
  %conv = trunc i64 %4 to i32, !dbg !2417
  %gid = getelementptr inbounds i8, ptr %e, i64 8, !dbg !2418
  %5 = load i64, ptr %gid, align 8, !dbg !2418, !tbaa !1067
  %conv4 = zext i16 %rport.0 to i32, !dbg !2419
  %6 = load i32, ptr %data, align 4, !dbg !2420, !tbaa !2315
  %idxprom = sext i32 %6 to i64, !dbg !2421
  %arrayidx = getelementptr inbounds [3 x ptr], ptr @__const._logger_parse_cce.transport_map, i64 0, i64 %idxprom, !dbg !2421
  %7 = load ptr, ptr %arrayidx, align 8, !dbg !2421, !tbaa !1039
  %reason = getelementptr inbounds i8, ptr %e, i64 40, !dbg !2422
  %8 = load i32, ptr %reason, align 4, !dbg !2422, !tbaa !2318
  %idxprom5 = sext i32 %8 to i64, !dbg !2423
  %reltable.shift = shl i64 %idxprom5, 2, !dbg !2423
  %reltable.intrinsic = call ptr @llvm.load.relative.i64(ptr @reltable._logger_parse_cce, i64 %reltable.shift), !dbg !2423
  %sfd = getelementptr inbounds i8, ptr %e, i64 44, !dbg !2424
  %9 = load i32, ptr %sfd, align 4, !dbg !2424, !tbaa !2312
  %call7 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %scratch, i64 noundef 4096, ptr noundef nonnull @.str.50, i64 noundef %3, i32 noundef %conv, i64 noundef %5, ptr noundef nonnull %rip, i32 noundef %conv4, ptr noundef %7, ptr noundef %reltable.intrinsic, i32 noundef %9) #21, !dbg !2425
  tail call void @llvm.dbg.value(metadata i32 %call7, metadata !2386, metadata !DIExpression()), !dbg !2393
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %rip) #21, !dbg !2426
  ret i32 %call7, !dbg !2427
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(read, argmem: readwrite, inaccessiblemem: none) uwtable
define internal void @_logger_log_item_deleted(ptr nocapture noundef writeonly %e, ptr nocapture readnone %d, ptr nocapture noundef readonly %entry1, ptr nocapture noundef %ap) #16 !dbg !2428 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2430, metadata !DIExpression()), !dbg !2437
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2431, metadata !DIExpression()), !dbg !2437
  tail call void @llvm.dbg.value(metadata ptr %entry1, metadata !2432, metadata !DIExpression()), !dbg !2437
  tail call void @llvm.dbg.value(metadata ptr %ap, metadata !2433, metadata !DIExpression()), !dbg !2437
  tail call void @llvm.dbg.value(metadata ptr %entry1, metadata !2434, metadata !DIExpression()), !dbg !2437
  %gp_offset = load i32, ptr %ap, align 8, !dbg !2438
  %fits_in_gp = icmp ult i32 %gp_offset, 41, !dbg !2438
  br i1 %fits_in_gp, label %vaarg.in_reg, label %vaarg.in_mem, !dbg !2438

vaarg.in_reg:                                     ; preds = %entry
  %0 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2438
  %reg_save_area = load ptr, ptr %0, align 8, !dbg !2438
  %1 = zext nneg i32 %gp_offset to i64, !dbg !2438
  %2 = getelementptr i8, ptr %reg_save_area, i64 %1, !dbg !2438
  %3 = add nuw nsw i32 %gp_offset, 8, !dbg !2438
  store i32 %3, ptr %ap, align 8, !dbg !2438
  br label %vaarg.end, !dbg !2438

vaarg.in_mem:                                     ; preds = %entry
  %overflow_arg_area_p = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2438
  %overflow_arg_area = load ptr, ptr %overflow_arg_area_p, align 8, !dbg !2438
  %overflow_arg_area.next = getelementptr i8, ptr %overflow_arg_area, i64 8, !dbg !2438
  store ptr %overflow_arg_area.next, ptr %overflow_arg_area_p, align 8, !dbg !2438
  br label %vaarg.end, !dbg !2438

vaarg.end:                                        ; preds = %vaarg.in_mem, %vaarg.in_reg
  %vaarg.addr = phi ptr [ %2, %vaarg.in_reg ], [ %overflow_arg_area, %vaarg.in_mem ], !dbg !2438
  %4 = load i32, ptr %vaarg.addr, align 4, !dbg !2438
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !2435, metadata !DIExpression()), !dbg !2437
  %data = getelementptr inbounds i8, ptr %e, i64 36, !dbg !2439
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !2436, metadata !DIExpression()), !dbg !2437
  %nkey = getelementptr inbounds i8, ptr %entry1, i64 41, !dbg !2440
  %5 = load i8, ptr %nkey, align 1, !dbg !2440, !tbaa !1222
  %nkey2 = getelementptr inbounds i8, ptr %e, i64 44, !dbg !2441
  store i8 %5, ptr %nkey2, align 4, !dbg !2442, !tbaa !1222
  %cmd = getelementptr inbounds i8, ptr %e, i64 40, !dbg !2443
  store i32 %4, ptr %cmd, align 4, !dbg !2444, !tbaa !1053
  %nbytes = getelementptr inbounds i8, ptr %entry1, i64 32, !dbg !2445
  %6 = load i32, ptr %nbytes, align 8, !dbg !2445, !tbaa !1053
  store i32 %6, ptr %data, align 4, !dbg !2446, !tbaa !1053
  %slabs_clsid = getelementptr inbounds i8, ptr %entry1, i64 40, !dbg !2447
  %7 = load i8, ptr %slabs_clsid, align 8, !dbg !2447, !tbaa !1222
  %8 = and i8 %7, 63, !dbg !2447
  %clsid = getelementptr inbounds i8, ptr %e, i64 45, !dbg !2448
  store i8 %8, ptr %clsid, align 1, !dbg !2449, !tbaa !1222
  %key = getelementptr inbounds i8, ptr %e, i64 46, !dbg !2450
  %data6 = getelementptr inbounds i8, ptr %entry1, i64 48, !dbg !2451
  %it_flags = getelementptr inbounds i8, ptr %entry1, i64 38, !dbg !2451
  %9 = load i16, ptr %it_flags, align 2, !dbg !2451, !tbaa !1231
  %10 = shl i16 %9, 2, !dbg !2451
  %11 = and i16 %10, 8, !dbg !2451
  %cond = zext nneg i16 %11 to i64, !dbg !2451
  %add.ptr = getelementptr inbounds i8, ptr %data6, i64 %cond, !dbg !2451
  %12 = load i8, ptr %nkey, align 1, !dbg !2452, !tbaa !1222
  %conv10 = zext i8 %12 to i64, !dbg !2453
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 2 %key, ptr nonnull align 1 %add.ptr, i64 %conv10, i1 false), !dbg !2454
  %conv12 = zext i8 %5 to i32, !dbg !2455
  %add = add nuw nsw i32 %conv12, 12, !dbg !2456
  %size = getelementptr inbounds i8, ptr %e, i64 32, !dbg !2457
  store i32 %add, ptr %size, align 8, !dbg !2458, !tbaa !1053
  ret void, !dbg !2459
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal noundef i32 @_logger_parse_ide(ptr noundef %e, ptr nocapture noundef writeonly %scratch) #1 !dbg !2460 {
entry:
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2466, metadata !DIExpression(), metadata !2469, metadata ptr poison, metadata !DIExpression()), !dbg !2470
  %keybuf = alloca [751 x i8], align 16, !DIAssignID !2471
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2467, metadata !DIExpression(), metadata !2471, metadata ptr %keybuf, metadata !DIExpression()), !dbg !2470
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2462, metadata !DIExpression()), !dbg !2470
  tail call void @llvm.dbg.value(metadata ptr %scratch, metadata !2463, metadata !DIExpression()), !dbg !2470
  tail call void @llvm.dbg.value(metadata ptr @.str.27, metadata !2465, metadata !DIExpression()), !dbg !2470
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2466, metadata !DIExpression(), metadata !2472, metadata ptr poison, metadata !DIExpression()), !dbg !2470
  call void @llvm.lifetime.start.p0(i64 751, ptr nonnull %keybuf) #21, !dbg !2473
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2468, metadata !DIExpression(DW_OP_plus_uconst, 36, DW_OP_stack_value)), !dbg !2470
  %key = getelementptr inbounds i8, ptr %e, i64 46, !dbg !2474
  %nkey = getelementptr inbounds i8, ptr %e, i64 44, !dbg !2475
  %0 = load i8, ptr %nkey, align 4, !dbg !2475, !tbaa !1222
  %conv = zext i8 %0 to i64, !dbg !2476
  %call = call zeroext i1 @uriencode(ptr noundef nonnull %key, ptr noundef nonnull %keybuf, i64 noundef %conv, i64 noundef 751) #21, !dbg !2477
  %cmd3 = getelementptr inbounds i8, ptr %e, i64 40, !dbg !2478
  %1 = load i32, ptr %cmd3, align 4, !dbg !2478, !tbaa !1053
  %cmp = icmp slt i32 %1, 3, !dbg !2480
  br i1 %cmp, label %if.then, label %if.end, !dbg !2481

if.then:                                          ; preds = %entry
  %idxprom = sext i32 %1 to i64, !dbg !2482
  %reltable.shift = shl i64 %idxprom, 2, !dbg !2482
  %reltable.intrinsic = call ptr @llvm.load.relative.i64(ptr @reltable._logger_parse_ide, i64 %reltable.shift), !dbg !2482
  tail call void @llvm.dbg.value(metadata ptr %reltable.intrinsic, metadata !2465, metadata !DIExpression()), !dbg !2470
  br label %if.end, !dbg !2483

if.end:                                           ; preds = %if.then, %entry
  %cmd.0 = phi ptr [ %reltable.intrinsic, %if.then ], [ @.str.27, %entry ], !dbg !2470
  %data = getelementptr inbounds i8, ptr %e, i64 36, !dbg !2484
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !2468, metadata !DIExpression()), !dbg !2470
  tail call void @llvm.dbg.value(metadata ptr %cmd.0, metadata !2465, metadata !DIExpression()), !dbg !2470
  %tv = getelementptr inbounds i8, ptr %e, i64 16, !dbg !2485
  %2 = load i64, ptr %tv, align 8, !dbg !2486, !tbaa !2024
  %tv_usec = getelementptr inbounds i8, ptr %e, i64 24, !dbg !2487
  %3 = load i64, ptr %tv_usec, align 8, !dbg !2487, !tbaa !2026
  %gid = getelementptr inbounds i8, ptr %e, i64 8, !dbg !2488
  %4 = load i64, ptr %gid, align 8, !dbg !2488, !tbaa !1067
  %clsid = getelementptr inbounds i8, ptr %e, i64 45, !dbg !2489
  %5 = load i8, ptr %clsid, align 1, !dbg !2489, !tbaa !1222
  %6 = load i32, ptr %data, align 4, !dbg !2490, !tbaa !1053
  %cmp11 = icmp sgt i32 %6, 0, !dbg !2491
  %sub = add nsw i32 %6, -2
  %spec.select = select i1 %cmp11, i32 %sub, i32 0, !dbg !2492
  %conv10 = zext i8 %5 to i32, !dbg !2493
  %conv8 = trunc i64 %3 to i32, !dbg !2494
  %conv6 = trunc i64 %2 to i32, !dbg !2495
  %call14 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %scratch, i64 noundef 4096, ptr noundef nonnull @.str.53, i32 noundef %conv6, i32 noundef %conv8, i64 noundef %4, ptr noundef nonnull %keybuf, ptr noundef %cmd.0, i32 noundef %conv10, i32 noundef %spec.select) #21, !dbg !2496
  tail call void @llvm.dbg.value(metadata i32 %call14, metadata !2464, metadata !DIExpression()), !dbg !2470
  call void @llvm.lifetime.end.p0(i64 751, ptr nonnull %keybuf) #21, !dbg !2497
  ret i32 %call14, !dbg !2498
}

; Function Attrs: mustprogress nofree norecurse nounwind sanitize_thread willreturn uwtable
define internal void @_logger_log_ext_write(ptr nocapture noundef writeonly %e, ptr nocapture readnone %d, ptr nocapture noundef readonly %entry1, ptr nocapture noundef %ap) #14 !dbg !2499 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2501, metadata !DIExpression()), !dbg !2508
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2502, metadata !DIExpression()), !dbg !2508
  tail call void @llvm.dbg.value(metadata ptr %entry1, metadata !2503, metadata !DIExpression()), !dbg !2508
  tail call void @llvm.dbg.value(metadata ptr %ap, metadata !2504, metadata !DIExpression()), !dbg !2508
  tail call void @llvm.dbg.value(metadata ptr %entry1, metadata !2505, metadata !DIExpression()), !dbg !2508
  %gp_offset = load i32, ptr %ap, align 8, !dbg !2509
  %fits_in_gp = icmp ult i32 %gp_offset, 41, !dbg !2509
  br i1 %fits_in_gp, label %vaarg.in_reg, label %vaarg.in_mem, !dbg !2509

vaarg.in_reg:                                     ; preds = %entry
  %0 = getelementptr inbounds i8, ptr %ap, i64 16, !dbg !2509
  %reg_save_area = load ptr, ptr %0, align 8, !dbg !2509
  %1 = zext nneg i32 %gp_offset to i64, !dbg !2509
  %2 = getelementptr i8, ptr %reg_save_area, i64 %1, !dbg !2509
  %3 = add nuw nsw i32 %gp_offset, 8, !dbg !2509
  store i32 %3, ptr %ap, align 8, !dbg !2509
  br label %vaarg.end, !dbg !2509

vaarg.in_mem:                                     ; preds = %entry
  %overflow_arg_area_p = getelementptr inbounds i8, ptr %ap, i64 8, !dbg !2509
  %overflow_arg_area = load ptr, ptr %overflow_arg_area_p, align 8, !dbg !2509
  %overflow_arg_area.next = getelementptr i8, ptr %overflow_arg_area, i64 8, !dbg !2509
  store ptr %overflow_arg_area.next, ptr %overflow_arg_area_p, align 8, !dbg !2509
  br label %vaarg.end, !dbg !2509

vaarg.end:                                        ; preds = %vaarg.in_mem, %vaarg.in_reg
  %vaarg.addr = phi ptr [ %2, %vaarg.in_reg ], [ %overflow_arg_area, %vaarg.in_mem ], !dbg !2509
  %4 = load i32, ptr %vaarg.addr, align 4, !dbg !2509
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !2506, metadata !DIExpression()), !dbg !2508
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2507, metadata !DIExpression(DW_OP_plus_uconst, 36, DW_OP_stack_value)), !dbg !2508
  %exptime = getelementptr inbounds i8, ptr %entry1, i64 28, !dbg !2510
  %5 = load i32, ptr %exptime, align 4, !dbg !2510, !tbaa !1053
  %cmp.not = icmp eq i32 %5, 0, !dbg !2511
  br i1 %cmp.not, label %cond.end, label %cond.true, !dbg !2512

cond.true:                                        ; preds = %vaarg.end
  %6 = load volatile i32, ptr @current_time, align 4, !dbg !2513, !tbaa !1053
  %sub = sub i32 %5, %6, !dbg !2514
  %conv = zext i32 %sub to i64, !dbg !2515
  br label %cond.end, !dbg !2512

cond.end:                                         ; preds = %vaarg.end, %cond.true
  %cond = phi i64 [ %conv, %cond.true ], [ -1, %vaarg.end ], !dbg !2512
  %data = getelementptr inbounds i8, ptr %e, i64 36, !dbg !2516
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !2507, metadata !DIExpression()), !dbg !2508
  store i64 %cond, ptr %data, align 8, !dbg !2517, !tbaa !2049
  %7 = load volatile i32, ptr @current_time, align 4, !dbg !2518, !tbaa !1053
  %time = getelementptr inbounds i8, ptr %entry1, i64 24, !dbg !2519
  %8 = load i32, ptr %time, align 8, !dbg !2519, !tbaa !1053
  %sub4 = sub i32 %7, %8, !dbg !2520
  %latime = getelementptr inbounds i8, ptr %e, i64 44, !dbg !2521
  store i32 %sub4, ptr %latime, align 8, !dbg !2522, !tbaa !1053
  %it_flags = getelementptr inbounds i8, ptr %entry1, i64 38, !dbg !2523
  %9 = load i16, ptr %it_flags, align 2, !dbg !2523, !tbaa !1231
  %it_flags5 = getelementptr inbounds i8, ptr %e, i64 48, !dbg !2524
  store i16 %9, ptr %it_flags5, align 4, !dbg !2525, !tbaa !1231
  %nkey = getelementptr inbounds i8, ptr %entry1, i64 41, !dbg !2526
  %10 = load i8, ptr %nkey, align 1, !dbg !2526, !tbaa !1222
  %nkey6 = getelementptr inbounds i8, ptr %e, i64 50, !dbg !2527
  store i8 %10, ptr %nkey6, align 2, !dbg !2528, !tbaa !1222
  %slabs_clsid = getelementptr inbounds i8, ptr %entry1, i64 40, !dbg !2529
  %11 = load i8, ptr %slabs_clsid, align 8, !dbg !2529, !tbaa !1222
  %12 = and i8 %11, 63, !dbg !2529
  %clsid = getelementptr inbounds i8, ptr %e, i64 51, !dbg !2530
  store i8 %12, ptr %clsid, align 1, !dbg !2531, !tbaa !1222
  %conv9 = trunc i32 %4 to i8, !dbg !2532
  %bucket = getelementptr inbounds i8, ptr %e, i64 52, !dbg !2533
  store i8 %conv9, ptr %bucket, align 8, !dbg !2534, !tbaa !1222
  %key = getelementptr inbounds i8, ptr %e, i64 53, !dbg !2535
  %data11 = getelementptr inbounds i8, ptr %entry1, i64 48, !dbg !2536
  %13 = load i16, ptr %it_flags, align 2, !dbg !2536, !tbaa !1231
  %14 = shl i16 %13, 2, !dbg !2536
  %15 = and i16 %14, 8, !dbg !2536
  %cond15 = zext nneg i16 %15 to i64, !dbg !2536
  %add.ptr = getelementptr inbounds i8, ptr %data11, i64 %cond15, !dbg !2536
  %16 = load i8, ptr %nkey, align 1, !dbg !2537, !tbaa !1222
  %conv17 = zext i8 %16 to i64, !dbg !2538
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %key, ptr nonnull align 1 %add.ptr, i64 %conv17, i1 false), !dbg !2539
  %conv19 = zext i8 %10 to i32, !dbg !2540
  %add = add nuw nsw i32 %conv19, 24, !dbg !2541
  %size = getelementptr inbounds i8, ptr %e, i64 32, !dbg !2542
  store i32 %add, ptr %size, align 8, !dbg !2543, !tbaa !1053
  ret void, !dbg !2544
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal noundef i32 @_logger_parse_extw(ptr noundef %e, ptr nocapture noundef writeonly %scratch) #1 !dbg !2545 {
entry:
  %keybuf = alloca [751 x i8], align 16, !DIAssignID !2552
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2550, metadata !DIExpression(), metadata !2552, metadata ptr %keybuf, metadata !DIExpression()), !dbg !2553
  tail call void @llvm.dbg.value(metadata ptr %e, metadata !2547, metadata !DIExpression()), !dbg !2553
  tail call void @llvm.dbg.value(metadata ptr %scratch, metadata !2548, metadata !DIExpression()), !dbg !2553
  call void @llvm.lifetime.start.p0(i64 751, ptr nonnull %keybuf) #21, !dbg !2554
  %data = getelementptr inbounds i8, ptr %e, i64 36, !dbg !2555
  tail call void @llvm.dbg.value(metadata ptr %data, metadata !2551, metadata !DIExpression()), !dbg !2553
  %key = getelementptr inbounds i8, ptr %e, i64 53, !dbg !2556
  %nkey = getelementptr inbounds i8, ptr %e, i64 50, !dbg !2557
  %0 = load i8, ptr %nkey, align 2, !dbg !2557, !tbaa !1222
  %conv = zext i8 %0 to i64, !dbg !2558
  %call = call zeroext i1 @uriencode(ptr noundef nonnull %key, ptr noundef nonnull %keybuf, i64 noundef %conv, i64 noundef 751) #21, !dbg !2559
  %tv = getelementptr inbounds i8, ptr %e, i64 16, !dbg !2560
  %1 = load i64, ptr %tv, align 8, !dbg !2561, !tbaa !2024
  %tv_usec = getelementptr inbounds i8, ptr %e, i64 24, !dbg !2562
  %2 = load i64, ptr %tv_usec, align 8, !dbg !2562, !tbaa !2026
  %conv4 = trunc i64 %2 to i32, !dbg !2563
  %gid = getelementptr inbounds i8, ptr %e, i64 8, !dbg !2564
  %3 = load i64, ptr %gid, align 8, !dbg !2564, !tbaa !1067
  %it_flags = getelementptr inbounds i8, ptr %e, i64 48, !dbg !2565
  %4 = load i16, ptr %it_flags, align 4, !dbg !2565, !tbaa !1231
  %5 = and i16 %4, 8, !dbg !2566
  %tobool.not = icmp eq i16 %5, 0, !dbg !2567
  %cond = select i1 %tobool.not, ptr @.str.21, ptr @.str.20, !dbg !2567
  %6 = load i64, ptr %data, align 8, !dbg !2568, !tbaa !2049
  %latime = getelementptr inbounds i8, ptr %e, i64 44, !dbg !2569
  %7 = load i32, ptr %latime, align 8, !dbg !2569, !tbaa !1053
  %clsid = getelementptr inbounds i8, ptr %e, i64 51, !dbg !2570
  %8 = load i8, ptr %clsid, align 1, !dbg !2570, !tbaa !1222
  %conv7 = zext i8 %8 to i32, !dbg !2571
  %bucket = getelementptr inbounds i8, ptr %e, i64 52, !dbg !2572
  %9 = load i8, ptr %bucket, align 8, !dbg !2572, !tbaa !1222
  %conv8 = zext i8 %9 to i32, !dbg !2573
  %call9 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %scratch, i64 noundef 4096, ptr noundef nonnull @.str.54, i64 noundef %1, i32 noundef %conv4, i64 noundef %3, ptr noundef nonnull %keybuf, ptr noundef nonnull %cond, i64 noundef %6, i32 noundef %7, i32 noundef %conv7, i32 noundef %conv8) #21, !dbg !2574
  tail call void @llvm.dbg.value(metadata i32 %call9, metadata !2549, metadata !DIExpression()), !dbg !2553
  call void @llvm.lifetime.end.p0(i64 751, ptr nonnull %keybuf) #21, !dbg !2575
  ret i32 %call9, !dbg !2576
}

; Function Attrs: nofree nounwind
declare !dbg !2577 noundef i32 @vsnprintf(ptr nocapture noundef, i64 noundef, ptr nocapture noundef readonly, ptr noundef) local_unnamed_addr #8

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #17

declare !dbg !2580 zeroext i1 @uriencode(ptr noundef, ptr noundef, i64 noundef, i64 noundef) local_unnamed_addr #6

; Function Attrs: nounwind
declare !dbg !2585 ptr @inet_ntop(i32 noundef, ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #18

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #18

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #18

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #19 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare ptr @llvm.load.relative.i64(ptr, i64) #20

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #18

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #18

attributes #0 = { mustprogress nofree norecurse nounwind sanitize_thread willreturn memory(readwrite, argmem: none, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { mustprogress nocallback nofree nosync nounwind willreturn }
attributes #10 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #11 = { cold nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { mustprogress nofree nosync nounwind willreturn memory(none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { nofree nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { mustprogress nofree norecurse nounwind sanitize_thread willreturn uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #16 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(read, argmem: readwrite, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #17 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #18 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #19 = { nounwind uwtable }
attributes #20 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #21 = { nounwind }
attributes #22 = { cold nounwind }
attributes #23 = { noreturn nounwind }
attributes #24 = { nounwind allocsize(0,1) }
attributes #25 = { cold }
attributes #26 = { nounwind willreturn memory(none) }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!1014, !1015, !1016, !1017, !1018, !1019, !1020}
!llvm.ident = !{!1021}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "logger_stack_lock", scope: !2, file: !3, line: 35, type: !275, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !101, globals: !737, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "logger.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "4c855202781139a578ef530ec2771ae3")
!4 = !{!5, !25, !30, !35, !39, !44, !63, !77, !82, !87, !93}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "log_entry_type", file: !6, line: 16, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "./logger.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "e743c4228b1e0bc1c91bec9cfd28d5ab")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12, !13, !14, !15, !16, !17, !18, !19, !20, !21, !22, !23, !24}
!9 = !DIEnumerator(name: "LOGGER_ASCII_CMD", value: 0)
!10 = !DIEnumerator(name: "LOGGER_EVICTION", value: 1)
!11 = !DIEnumerator(name: "LOGGER_ITEM_GET", value: 2)
!12 = !DIEnumerator(name: "LOGGER_ITEM_STORE", value: 3)
!13 = !DIEnumerator(name: "LOGGER_CRAWLER_STATUS", value: 4)
!14 = !DIEnumerator(name: "LOGGER_SLAB_MOVE", value: 5)
!15 = !DIEnumerator(name: "LOGGER_CONNECTION_NEW", value: 6)
!16 = !DIEnumerator(name: "LOGGER_CONNECTION_CLOSE", value: 7)
!17 = !DIEnumerator(name: "LOGGER_DELETIONS", value: 8)
!18 = !DIEnumerator(name: "LOGGER_EXTSTORE_WRITE", value: 9)
!19 = !DIEnumerator(name: "LOGGER_COMPACT_START", value: 10)
!20 = !DIEnumerator(name: "LOGGER_COMPACT_ABORT", value: 11)
!21 = !DIEnumerator(name: "LOGGER_COMPACT_READ_START", value: 12)
!22 = !DIEnumerator(name: "LOGGER_COMPACT_READ_END", value: 13)
!23 = !DIEnumerator(name: "LOGGER_COMPACT_END", value: 14)
!24 = !DIEnumerator(name: "LOGGER_COMPACT_FRAGINFO", value: 15)
!25 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "logger_ret_type", file: !6, line: 45, baseType: !7, size: 32, elements: !26)
!26 = !{!27, !28, !29}
!27 = !DIEnumerator(name: "LOGGER_RET_OK", value: 0)
!28 = !DIEnumerator(name: "LOGGER_RET_NOSPACE", value: 1)
!29 = !DIEnumerator(name: "LOGGER_RET_ERR", value: 2)
!30 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "logger_add_watcher_ret", file: !6, line: 240, baseType: !7, size: 32, elements: !31)
!31 = !{!32, !33, !34}
!32 = !DIEnumerator(name: "LOGGER_ADD_WATCHER_TOO_MANY", value: 0)
!33 = !DIEnumerator(name: "LOGGER_ADD_WATCHER_OK", value: 1)
!34 = !DIEnumerator(name: "LOGGER_ADD_WATCHER_FAILED", value: 2)
!35 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "logger_watcher_type", file: !6, line: 195, baseType: !7, size: 32, elements: !36)
!36 = !{!37, !38}
!37 = !DIEnumerator(name: "LOGGER_WATCHER_STDERR", value: 0)
!38 = !DIEnumerator(name: "LOGGER_WATCHER_CLIENT", value: 1)
!39 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "logger_parse_entry_ret", file: !6, line: 51, baseType: !7, size: 32, elements: !40)
!40 = !{!41, !42, !43}
!41 = !DIEnumerator(name: "LOGGER_PARSE_ENTRY_OK", value: 0)
!42 = !DIEnumerator(name: "LOGGER_PARSE_ENTRY_FULLBUF", value: 1)
!43 = !DIEnumerator(name: "LOGGER_PARSE_ENTRY_FAILED", value: 2)
!44 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "conn_states", file: !45, line: 204, baseType: !7, size: 32, elements: !46)
!45 = !DIFile(filename: "./memcached.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "a52021954a5d6b153b5bc084e2fbff2b")
!46 = !{!47, !48, !49, !50, !51, !52, !53, !54, !55, !56, !57, !58, !59, !60, !61, !62}
!47 = !DIEnumerator(name: "conn_listening", value: 0)
!48 = !DIEnumerator(name: "conn_new_cmd", value: 1)
!49 = !DIEnumerator(name: "conn_waiting", value: 2)
!50 = !DIEnumerator(name: "conn_read", value: 3)
!51 = !DIEnumerator(name: "conn_parse_cmd", value: 4)
!52 = !DIEnumerator(name: "conn_write", value: 5)
!53 = !DIEnumerator(name: "conn_nread", value: 6)
!54 = !DIEnumerator(name: "conn_swallow", value: 7)
!55 = !DIEnumerator(name: "conn_closing", value: 8)
!56 = !DIEnumerator(name: "conn_mwrite", value: 9)
!57 = !DIEnumerator(name: "conn_closed", value: 10)
!58 = !DIEnumerator(name: "conn_watch", value: 11)
!59 = !DIEnumerator(name: "conn_io_queue", value: 12)
!60 = !DIEnumerator(name: "conn_io_resume", value: 13)
!61 = !DIEnumerator(name: "conn_io_pending", value: 14)
!62 = !DIEnumerator(name: "conn_max_state", value: 15)
!63 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "bin_substates", file: !45, line: 223, baseType: !7, size: 32, elements: !64)
!64 = !{!65, !66, !67, !68, !69, !70, !71, !72, !73, !74, !75, !76}
!65 = !DIEnumerator(name: "bin_no_state", value: 0)
!66 = !DIEnumerator(name: "bin_reading_set_header", value: 1)
!67 = !DIEnumerator(name: "bin_reading_cas_header", value: 2)
!68 = !DIEnumerator(name: "bin_read_set_value", value: 3)
!69 = !DIEnumerator(name: "bin_reading_get_key", value: 4)
!70 = !DIEnumerator(name: "bin_reading_stat", value: 5)
!71 = !DIEnumerator(name: "bin_reading_del_header", value: 6)
!72 = !DIEnumerator(name: "bin_reading_incr_header", value: 7)
!73 = !DIEnumerator(name: "bin_read_flush_exptime", value: 8)
!74 = !DIEnumerator(name: "bin_reading_sasl_auth", value: 9)
!75 = !DIEnumerator(name: "bin_reading_sasl_auth_data", value: 10)
!76 = !DIEnumerator(name: "bin_reading_touch_key", value: 11)
!77 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "protocol", file: !45, line: 238, baseType: !7, size: 32, elements: !78)
!78 = !{!79, !80, !81}
!79 = !DIEnumerator(name: "ascii_prot", value: 3)
!80 = !DIEnumerator(name: "binary_prot", value: 4)
!81 = !DIEnumerator(name: "negotiating_prot", value: 5)
!82 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "network_transport", file: !45, line: 247, baseType: !7, size: 32, elements: !83)
!83 = !{!84, !85, !86}
!84 = !DIEnumerator(name: "local_transport", value: 0)
!85 = !DIEnumerator(name: "tcp_transport", value: 1)
!86 = !DIEnumerator(name: "udp_transport", value: 2)
!87 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "close_reasons", file: !45, line: 266, baseType: !7, size: 32, elements: !88)
!88 = !{!89, !90, !91, !92}
!89 = !DIEnumerator(name: "ERROR_CLOSE", value: 0)
!90 = !DIEnumerator(name: "NORMAL_CLOSE", value: 1)
!91 = !DIEnumerator(name: "IDLE_TIMEOUT_CLOSE", value: 2)
!92 = !DIEnumerator(name: "SHUTDOWN_CLOSE", value: 3)
!93 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "store_item_type", file: !45, line: 291, baseType: !7, size: 32, elements: !94)
!94 = !{!95, !96, !97, !98, !99, !100}
!95 = !DIEnumerator(name: "NOT_STORED", value: 0)
!96 = !DIEnumerator(name: "STORED", value: 1)
!97 = !DIEnumerator(name: "EXISTS", value: 2)
!98 = !DIEnumerator(name: "NOT_FOUND", value: 3)
!99 = !DIEnumerator(name: "TOO_LARGE", value: 4)
!100 = !DIEnumerator(name: "NO_MEMORY", value: 5)
!101 = !{!102, !103, !141, !142, !143, !144, !667, !132, !515, !668, !679, !688, !699, !706, !718, !116, !719, !727, !109}
!102 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!103 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !104, size: 64)
!104 = !DIDerivedType(tag: DW_TAG_typedef, name: "logentry", file: !6, line: 57, baseType: !105)
!105 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logentry", file: !6, line: 156, size: 320, elements: !106)
!106 = !{!107, !108, !114, !118, !122, !131, !133}
!107 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !105, file: !6, line: 157, baseType: !5, size: 32)
!108 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !105, file: !6, line: 158, baseType: !109, size: 8, offset: 32)
!109 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !110, line: 24, baseType: !111)
!110 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!111 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !112, line: 38, baseType: !113)
!112 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!113 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!114 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !105, file: !6, line: 159, baseType: !115, size: 16, offset: 48)
!115 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint16_t", file: !110, line: 25, baseType: !116)
!116 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint16_t", file: !112, line: 40, baseType: !117)
!117 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!118 = !DIDerivedType(tag: DW_TAG_member, name: "gid", scope: !105, file: !6, line: 160, baseType: !119, size: 64, offset: 64)
!119 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !110, line: 27, baseType: !120)
!120 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !112, line: 45, baseType: !121)
!121 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!122 = !DIDerivedType(tag: DW_TAG_member, name: "tv", scope: !105, file: !6, line: 161, baseType: !123, size: 128, offset: 128)
!123 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "timeval", file: !124, line: 8, size: 128, elements: !125)
!124 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h", directory: "", checksumkind: CSK_MD5, checksum: "9b45d950050c215f216850b27bd1e8f3")
!125 = !{!126, !129}
!126 = !DIDerivedType(tag: DW_TAG_member, name: "tv_sec", scope: !123, file: !124, line: 14, baseType: !127, size: 64)
!127 = !DIDerivedType(tag: DW_TAG_typedef, name: "__time_t", file: !112, line: 160, baseType: !128)
!128 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!129 = !DIDerivedType(tag: DW_TAG_member, name: "tv_usec", scope: !123, file: !124, line: 15, baseType: !130, size: 64, offset: 64)
!130 = !DIDerivedType(tag: DW_TAG_typedef, name: "__suseconds_t", file: !112, line: 162, baseType: !128)
!131 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !105, file: !6, line: 162, baseType: !132, size: 32, offset: 256)
!132 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!133 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !105, file: !6, line: 165, baseType: !134, offset: 288)
!134 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, elements: !139)
!135 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !105, file: !6, line: 163, size: 8, elements: !136)
!136 = !{!137}
!137 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !135, file: !6, line: 164, baseType: !138, size: 8)
!138 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!139 = !{!140}
!140 = !DISubrange(count: -1)
!141 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !113, size: 64)
!142 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !138, size: 64)
!143 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!144 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !145, size: 64)
!145 = !DIDerivedType(tag: DW_TAG_typedef, name: "conn", file: !45, line: 813, baseType: !146)
!146 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "conn", file: !45, line: 829, size: 3968, elements: !147)
!147 = !{!148, !152, !153, !155, !156, !157, !158, !159, !160, !161, !162, !163, !165, !241, !242, !243, !244, !245, !246, !247, !590, !591, !592, !593, !594, !595, !596, !598, !599, !600, !601, !602, !603, !604, !605, !606, !612, !633, !634, !635, !636, !637, !638, !639, !640, !644, !651, !666}
!148 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_conn", scope: !146, file: !45, line: 830, baseType: !149, size: 64)
!149 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !150, size: 64)
!150 = !DIDerivedType(tag: DW_TAG_typedef, name: "sasl_conn_t", file: !151, line: 16, baseType: !102)
!151 = !DIFile(filename: "./sasl_defs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "3a8678a43d09d8e311388b26eedc7a3e")
!152 = !DIDerivedType(tag: DW_TAG_member, name: "sfd", scope: !146, file: !45, line: 831, baseType: !132, size: 32, offset: 64)
!153 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_started", scope: !146, file: !45, line: 832, baseType: !154, size: 8, offset: 96)
!154 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!155 = !DIDerivedType(tag: DW_TAG_member, name: "authenticated", scope: !146, file: !45, line: 833, baseType: !154, size: 8, offset: 104)
!156 = !DIDerivedType(tag: DW_TAG_member, name: "set_stale", scope: !146, file: !45, line: 834, baseType: !154, size: 8, offset: 112)
!157 = !DIDerivedType(tag: DW_TAG_member, name: "mset_res", scope: !146, file: !45, line: 835, baseType: !154, size: 8, offset: 120)
!158 = !DIDerivedType(tag: DW_TAG_member, name: "close_after_write", scope: !146, file: !45, line: 836, baseType: !154, size: 8, offset: 128)
!159 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_malloced", scope: !146, file: !45, line: 837, baseType: !154, size: 8, offset: 136)
!160 = !DIDerivedType(tag: DW_TAG_member, name: "item_malloced", scope: !146, file: !45, line: 838, baseType: !154, size: 8, offset: 144)
!161 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !146, file: !45, line: 844, baseType: !44, size: 32, offset: 160)
!162 = !DIDerivedType(tag: DW_TAG_member, name: "substate", scope: !146, file: !45, line: 845, baseType: !63, size: 32, offset: 192)
!163 = !DIDerivedType(tag: DW_TAG_member, name: "last_cmd_time", scope: !146, file: !45, line: 846, baseType: !164, size: 32, offset: 224)
!164 = !DIDerivedType(tag: DW_TAG_typedef, name: "rel_time_t", file: !6, line: 14, baseType: !7)
!165 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !146, file: !45, line: 847, baseType: !166, size: 1024, offset: 256)
!166 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event", file: !167, line: 123, size: 1024, elements: !168)
!167 = !DIFile(filename: "/usr/include/event2/event_struct.h", directory: "", checksumkind: CSK_MD5, checksum: "005d89b34bed2ed9e30b0cc3160619c1")
!168 = !{!169, !201, !211, !212, !215, !238, !239, !240}
!169 = !DIDerivedType(tag: DW_TAG_member, name: "ev_evcallback", scope: !166, file: !167, line: 124, baseType: !170, size: 320)
!170 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event_callback", file: !167, line: 107, size: 320, elements: !171)
!171 = !{!172, !179, !181, !182, !183, !200}
!172 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_active_next", scope: !170, file: !167, line: 108, baseType: !173, size: 128)
!173 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !170, file: !167, line: 108, size: 128, elements: !174)
!174 = !{!175, !177}
!175 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !173, file: !167, line: 108, baseType: !176, size: 64)
!176 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !170, size: 64)
!177 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !173, file: !167, line: 108, baseType: !178, size: 64, offset: 64)
!178 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !176, size: 64)
!179 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_flags", scope: !170, file: !167, line: 109, baseType: !180, size: 16, offset: 128)
!180 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!181 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_pri", scope: !170, file: !167, line: 110, baseType: !109, size: 8, offset: 144)
!182 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_closure", scope: !170, file: !167, line: 111, baseType: !109, size: 8, offset: 152)
!183 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cb_union", scope: !170, file: !167, line: 118, baseType: !184, size: 64, offset: 192)
!184 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !170, file: !167, line: 113, size: 64, elements: !185)
!185 = !{!186, !190, !194, !199}
!186 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_callback", scope: !184, file: !167, line: 114, baseType: !187, size: 64)
!187 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !188, size: 64)
!188 = !DISubroutineType(types: !189)
!189 = !{null, !132, !180, !102}
!190 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_selfcb", scope: !184, file: !167, line: 115, baseType: !191, size: 64)
!191 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !192, size: 64)
!192 = !DISubroutineType(types: !193)
!193 = !{null, !176, !102}
!194 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_evfinalize", scope: !184, file: !167, line: 116, baseType: !195, size: 64)
!195 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !196, size: 64)
!196 = !DISubroutineType(types: !197)
!197 = !{null, !198, !102}
!198 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !166, size: 64)
!199 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cbfinalize", scope: !184, file: !167, line: 117, baseType: !191, size: 64)
!200 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_arg", scope: !170, file: !167, line: 119, baseType: !102, size: 64, offset: 256)
!201 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout_pos", scope: !166, file: !167, line: 130, baseType: !202, size: 128, offset: 320)
!202 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !166, file: !167, line: 127, size: 128, elements: !203)
!203 = !{!204, !210}
!204 = !DIDerivedType(tag: DW_TAG_member, name: "ev_next_with_common_timeout", scope: !202, file: !167, line: 128, baseType: !205, size: 128)
!205 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !202, file: !167, line: 128, size: 128, elements: !206)
!206 = !{!207, !208}
!207 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !205, file: !167, line: 128, baseType: !198, size: 64)
!208 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !205, file: !167, line: 128, baseType: !209, size: 64, offset: 64)
!209 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !198, size: 64)
!210 = !DIDerivedType(tag: DW_TAG_member, name: "min_heap_idx", scope: !202, file: !167, line: 129, baseType: !132, size: 32)
!211 = !DIDerivedType(tag: DW_TAG_member, name: "ev_fd", scope: !166, file: !167, line: 131, baseType: !132, size: 32, offset: 448)
!212 = !DIDerivedType(tag: DW_TAG_member, name: "ev_base", scope: !166, file: !167, line: 133, baseType: !213, size: 64, offset: 512)
!213 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !214, size: 64)
!214 = !DICompositeType(tag: DW_TAG_structure_type, name: "event_base", file: !167, line: 122, flags: DIFlagFwdDecl)
!215 = !DIDerivedType(tag: DW_TAG_member, name: "ev_", scope: !166, file: !167, line: 149, baseType: !216, size: 256, offset: 576)
!216 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !166, file: !167, line: 135, size: 256, elements: !217)
!217 = !{!218, !227}
!218 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io", scope: !216, file: !167, line: 140, baseType: !219, size: 256)
!219 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !216, file: !167, line: 137, size: 256, elements: !220)
!220 = !{!221, !226}
!221 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io_next", scope: !219, file: !167, line: 138, baseType: !222, size: 128)
!222 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !219, file: !167, line: 138, size: 128, elements: !223)
!223 = !{!224, !225}
!224 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !222, file: !167, line: 138, baseType: !198, size: 64)
!225 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !222, file: !167, line: 138, baseType: !209, size: 64, offset: 64)
!226 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !219, file: !167, line: 139, baseType: !123, size: 128, offset: 128)
!227 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal", scope: !216, file: !167, line: 148, baseType: !228, size: 256)
!228 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !216, file: !167, line: 143, size: 256, elements: !229)
!229 = !{!230, !235, !236}
!230 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal_next", scope: !228, file: !167, line: 144, baseType: !231, size: 128)
!231 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !228, file: !167, line: 144, size: 128, elements: !232)
!232 = !{!233, !234}
!233 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !231, file: !167, line: 144, baseType: !198, size: 64)
!234 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !231, file: !167, line: 144, baseType: !209, size: 64, offset: 64)
!235 = !DIDerivedType(tag: DW_TAG_member, name: "ev_ncalls", scope: !228, file: !167, line: 145, baseType: !180, size: 16, offset: 128)
!236 = !DIDerivedType(tag: DW_TAG_member, name: "ev_pncalls", scope: !228, file: !167, line: 147, baseType: !237, size: 64, offset: 192)
!237 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !180, size: 64)
!238 = !DIDerivedType(tag: DW_TAG_member, name: "ev_events", scope: !166, file: !167, line: 151, baseType: !180, size: 16, offset: 832)
!239 = !DIDerivedType(tag: DW_TAG_member, name: "ev_res", scope: !166, file: !167, line: 152, baseType: !180, size: 16, offset: 848)
!240 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !166, file: !167, line: 153, baseType: !123, size: 128, offset: 896)
!241 = !DIDerivedType(tag: DW_TAG_member, name: "ev_flags", scope: !146, file: !45, line: 848, baseType: !180, size: 16, offset: 1280)
!242 = !DIDerivedType(tag: DW_TAG_member, name: "which", scope: !146, file: !45, line: 849, baseType: !180, size: 16, offset: 1296)
!243 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf", scope: !146, file: !45, line: 851, baseType: !142, size: 64, offset: 1344)
!244 = !DIDerivedType(tag: DW_TAG_member, name: "rcurr", scope: !146, file: !45, line: 852, baseType: !142, size: 64, offset: 1408)
!245 = !DIDerivedType(tag: DW_TAG_member, name: "rsize", scope: !146, file: !45, line: 853, baseType: !132, size: 32, offset: 1472)
!246 = !DIDerivedType(tag: DW_TAG_member, name: "rbytes", scope: !146, file: !45, line: 854, baseType: !132, size: 32, offset: 1504)
!247 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !146, file: !45, line: 856, baseType: !248, size: 64, offset: 1536)
!248 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !249, size: 64)
!249 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp", file: !45, line: 801, baseType: !250)
!250 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp", file: !45, line: 771, size: 9472, elements: !251)
!251 = !{!252, !508, !510, !511, !512, !513, !514, !536, !545, !546, !547, !548, !549, !550, !551, !552, !553, !582, !586}
!252 = !DIDerivedType(tag: DW_TAG_member, name: "bundle", scope: !250, file: !45, line: 772, baseType: !253, size: 64)
!253 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !254, size: 64)
!254 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp_bundle", file: !45, line: 720, baseType: !255)
!255 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp_bundle", file: !45, line: 804, size: 256, elements: !256)
!256 = !{!257, !258, !259, !503, !505, !506}
!257 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !255, file: !45, line: 805, baseType: !109, size: 8)
!258 = !DIDerivedType(tag: DW_TAG_member, name: "next_check", scope: !255, file: !45, line: 806, baseType: !109, size: 8, offset: 8)
!259 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !255, file: !45, line: 807, baseType: !260, size: 64, offset: 64)
!260 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !261, size: 64)
!261 = !DIDerivedType(tag: DW_TAG_typedef, name: "LIBEVENT_THREAD", file: !45, line: 765, baseType: !262)
!262 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !45, line: 721, size: 55488, elements: !263)
!263 = !{!264, !267, !268, !273, !274, !302, !332, !333, !334, !389, !411, !414, !442, !443, !444, !445, !501, !502}
!264 = !DIDerivedType(tag: DW_TAG_member, name: "thread_id", scope: !262, file: !45, line: 722, baseType: !265, size: 64)
!265 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_t", file: !266, line: 27, baseType: !121)
!266 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h", directory: "", checksumkind: CSK_MD5, checksum: "8a5acdbeec491eca11cf81cb1ef77ea7")
!267 = !DIDerivedType(tag: DW_TAG_member, name: "base", scope: !262, file: !45, line: 723, baseType: !213, size: 64, offset: 64)
!268 = !DIDerivedType(tag: DW_TAG_member, name: "n", scope: !262, file: !45, line: 724, baseType: !269, size: 1088, offset: 128)
!269 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_notify", file: !45, line: 710, size: 1088, elements: !270)
!270 = !{!271, !272}
!271 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event", scope: !269, file: !45, line: 711, baseType: !166, size: 1024)
!272 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event_fd", scope: !269, file: !45, line: 713, baseType: !132, size: 32, offset: 1024)
!273 = !DIDerivedType(tag: DW_TAG_member, name: "ion", scope: !262, file: !45, line: 725, baseType: !269, size: 1088, offset: 1216)
!274 = !DIDerivedType(tag: DW_TAG_member, name: "ion_lock", scope: !262, file: !45, line: 726, baseType: !275, size: 320, offset: 2304)
!275 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutex_t", file: !266, line: 72, baseType: !276)
!276 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !266, line: 67, size: 320, elements: !277)
!277 = !{!278, !297, !301}
!278 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !276, file: !266, line: 69, baseType: !279, size: 320)
!279 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_mutex_s", file: !280, line: 22, size: 320, elements: !281)
!280 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h", directory: "", checksumkind: CSK_MD5, checksum: "6b075eca9ab0e2d761b2afc4ecfab776")
!281 = !{!282, !283, !284, !285, !286, !287, !288, !289}
!282 = !DIDerivedType(tag: DW_TAG_member, name: "__lock", scope: !279, file: !280, line: 24, baseType: !132, size: 32)
!283 = !DIDerivedType(tag: DW_TAG_member, name: "__count", scope: !279, file: !280, line: 25, baseType: !7, size: 32, offset: 32)
!284 = !DIDerivedType(tag: DW_TAG_member, name: "__owner", scope: !279, file: !280, line: 26, baseType: !132, size: 32, offset: 64)
!285 = !DIDerivedType(tag: DW_TAG_member, name: "__nusers", scope: !279, file: !280, line: 28, baseType: !7, size: 32, offset: 96)
!286 = !DIDerivedType(tag: DW_TAG_member, name: "__kind", scope: !279, file: !280, line: 32, baseType: !132, size: 32, offset: 128)
!287 = !DIDerivedType(tag: DW_TAG_member, name: "__spins", scope: !279, file: !280, line: 34, baseType: !180, size: 16, offset: 160)
!288 = !DIDerivedType(tag: DW_TAG_member, name: "__elision", scope: !279, file: !280, line: 35, baseType: !180, size: 16, offset: 176)
!289 = !DIDerivedType(tag: DW_TAG_member, name: "__list", scope: !279, file: !280, line: 36, baseType: !290, size: 128, offset: 192)
!290 = !DIDerivedType(tag: DW_TAG_typedef, name: "__pthread_list_t", file: !291, line: 55, baseType: !292)
!291 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h", directory: "", checksumkind: CSK_MD5, checksum: "b9a7199822bce372686baacd32a9f4f3")
!292 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_internal_list", file: !291, line: 51, size: 128, elements: !293)
!293 = !{!294, !296}
!294 = !DIDerivedType(tag: DW_TAG_member, name: "__prev", scope: !292, file: !291, line: 53, baseType: !295, size: 64)
!295 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !292, size: 64)
!296 = !DIDerivedType(tag: DW_TAG_member, name: "__next", scope: !292, file: !291, line: 54, baseType: !295, size: 64, offset: 64)
!297 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !276, file: !266, line: 70, baseType: !298, size: 320)
!298 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 320, elements: !299)
!299 = !{!300}
!300 = !DISubrange(count: 40)
!301 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !276, file: !266, line: 71, baseType: !128, size: 64)
!302 = !DIDerivedType(tag: DW_TAG_member, name: "ion_head", scope: !262, file: !45, line: 727, baseType: !303, size: 128, offset: 2624)
!303 = !DIDerivedType(tag: DW_TAG_typedef, name: "iop_head_t", file: !45, line: 686, baseType: !304)
!304 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iop_head_s", file: !45, line: 686, size: 128, elements: !305)
!305 = !{!306, !330}
!306 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !304, file: !45, line: 686, baseType: !307, size: 64)
!307 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !308, size: 64)
!308 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_io_pending_t", file: !45, line: 815, size: 1408, elements: !309)
!309 = !{!310, !311, !312, !313, !314, !321, !322, !326}
!310 = !DIDerivedType(tag: DW_TAG_member, name: "io_queue_type", scope: !308, file: !45, line: 816, baseType: !132, size: 32)
!311 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !308, file: !45, line: 817, baseType: !260, size: 64, offset: 64)
!312 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !308, file: !45, line: 818, baseType: !144, size: 64, offset: 128)
!313 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !308, file: !45, line: 819, baseType: !248, size: 64, offset: 192)
!314 = !DIDerivedType(tag: DW_TAG_member, name: "return_cb", scope: !308, file: !45, line: 820, baseType: !315, size: 64, offset: 256)
!315 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb", file: !45, line: 690, baseType: !316)
!316 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !317, size: 64)
!317 = !DISubroutineType(types: !318)
!318 = !{null, !319}
!319 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !320, size: 64)
!320 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_pending_t", file: !45, line: 687, baseType: !308)
!321 = !DIDerivedType(tag: DW_TAG_member, name: "finalize_cb", scope: !308, file: !45, line: 821, baseType: !315, size: 64, offset: 320)
!322 = !DIDerivedType(tag: DW_TAG_member, name: "iop_next", scope: !308, file: !45, line: 822, baseType: !323, size: 64, offset: 384)
!323 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !308, file: !45, line: 822, size: 64, elements: !324)
!324 = !{!325}
!325 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !323, file: !45, line: 822, baseType: !307, size: 64)
!326 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !308, file: !45, line: 823, baseType: !327, size: 960, offset: 448)
!327 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 960, elements: !328)
!328 = !{!329}
!329 = !DISubrange(count: 120)
!330 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !304, file: !45, line: 686, baseType: !331, size: 64, offset: 64)
!331 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !307, size: 64)
!332 = !DIDerivedType(tag: DW_TAG_member, name: "cur_sfd", scope: !262, file: !45, line: 728, baseType: !132, size: 32, offset: 2752)
!333 = !DIDerivedType(tag: DW_TAG_member, name: "thread_baseid", scope: !262, file: !45, line: 729, baseType: !132, size: 32, offset: 2784)
!334 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !262, file: !45, line: 730, baseType: !335, size: 51584, offset: 2816)
!335 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_stats", file: !45, line: 372, size: 51584, elements: !336)
!336 = !{!337, !338, !339, !340, !341, !342, !343, !344, !345, !346, !347, !348, !349, !350, !351, !352, !353, !354, !355, !356, !357, !358, !359, !360, !361, !362, !363, !364, !365, !366, !367, !368, !382, !386, !387, !388}
!337 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !335, file: !45, line: 373, baseType: !275, size: 320)
!338 = !DIDerivedType(tag: DW_TAG_member, name: "get_cmds", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 320)
!339 = !DIDerivedType(tag: DW_TAG_member, name: "get_misses", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 384)
!340 = !DIDerivedType(tag: DW_TAG_member, name: "get_expired", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 448)
!341 = !DIDerivedType(tag: DW_TAG_member, name: "get_flushed", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 512)
!342 = !DIDerivedType(tag: DW_TAG_member, name: "touch_cmds", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 576)
!343 = !DIDerivedType(tag: DW_TAG_member, name: "touch_misses", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 640)
!344 = !DIDerivedType(tag: DW_TAG_member, name: "delete_misses", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 704)
!345 = !DIDerivedType(tag: DW_TAG_member, name: "incr_misses", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 768)
!346 = !DIDerivedType(tag: DW_TAG_member, name: "decr_misses", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 832)
!347 = !DIDerivedType(tag: DW_TAG_member, name: "cas_misses", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 896)
!348 = !DIDerivedType(tag: DW_TAG_member, name: "meta_cmds", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 960)
!349 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_read", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 1024)
!350 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_written", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 1088)
!351 = !DIDerivedType(tag: DW_TAG_member, name: "flush_cmds", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 1152)
!352 = !DIDerivedType(tag: DW_TAG_member, name: "conn_yields", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 1216)
!353 = !DIDerivedType(tag: DW_TAG_member, name: "auth_cmds", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 1280)
!354 = !DIDerivedType(tag: DW_TAG_member, name: "auth_errors", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 1344)
!355 = !DIDerivedType(tag: DW_TAG_member, name: "idle_kicks", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 1408)
!356 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_oom", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 1472)
!357 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_count", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 1536)
!358 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_bytes", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 1600)
!359 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_oom", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 1664)
!360 = !DIDerivedType(tag: DW_TAG_member, name: "store_too_large", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 1728)
!361 = !DIDerivedType(tag: DW_TAG_member, name: "store_no_memory", scope: !335, file: !45, line: 375, baseType: !119, size: 64, offset: 1792)
!362 = !DIDerivedType(tag: DW_TAG_member, name: "get_extstore", scope: !335, file: !45, line: 377, baseType: !119, size: 64, offset: 1856)
!363 = !DIDerivedType(tag: DW_TAG_member, name: "get_aborted_extstore", scope: !335, file: !45, line: 377, baseType: !119, size: 64, offset: 1920)
!364 = !DIDerivedType(tag: DW_TAG_member, name: "get_oom_extstore", scope: !335, file: !45, line: 377, baseType: !119, size: 64, offset: 1984)
!365 = !DIDerivedType(tag: DW_TAG_member, name: "recache_from_extstore", scope: !335, file: !45, line: 377, baseType: !119, size: 64, offset: 2048)
!366 = !DIDerivedType(tag: DW_TAG_member, name: "miss_from_extstore", scope: !335, file: !45, line: 377, baseType: !119, size: 64, offset: 2112)
!367 = !DIDerivedType(tag: DW_TAG_member, name: "badcrc_from_extstore", scope: !335, file: !45, line: 377, baseType: !119, size: 64, offset: 2176)
!368 = !DIDerivedType(tag: DW_TAG_member, name: "slab_stats", scope: !335, file: !45, line: 383, baseType: !369, size: 32768, offset: 2240)
!369 = !DICompositeType(tag: DW_TAG_array_type, baseType: !370, size: 32768, elements: !380)
!370 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "slab_stats", file: !45, line: 318, size: 512, elements: !371)
!371 = !{!372, !373, !374, !375, !376, !377, !378, !379}
!372 = !DIDerivedType(tag: DW_TAG_member, name: "set_cmds", scope: !370, file: !45, line: 320, baseType: !119, size: 64)
!373 = !DIDerivedType(tag: DW_TAG_member, name: "get_hits", scope: !370, file: !45, line: 320, baseType: !119, size: 64, offset: 64)
!374 = !DIDerivedType(tag: DW_TAG_member, name: "touch_hits", scope: !370, file: !45, line: 320, baseType: !119, size: 64, offset: 128)
!375 = !DIDerivedType(tag: DW_TAG_member, name: "delete_hits", scope: !370, file: !45, line: 320, baseType: !119, size: 64, offset: 192)
!376 = !DIDerivedType(tag: DW_TAG_member, name: "cas_hits", scope: !370, file: !45, line: 320, baseType: !119, size: 64, offset: 256)
!377 = !DIDerivedType(tag: DW_TAG_member, name: "cas_badval", scope: !370, file: !45, line: 320, baseType: !119, size: 64, offset: 320)
!378 = !DIDerivedType(tag: DW_TAG_member, name: "incr_hits", scope: !370, file: !45, line: 320, baseType: !119, size: 64, offset: 384)
!379 = !DIDerivedType(tag: DW_TAG_member, name: "decr_hits", scope: !370, file: !45, line: 320, baseType: !119, size: 64, offset: 448)
!380 = !{!381}
!381 = !DISubrange(count: 64)
!382 = !DIDerivedType(tag: DW_TAG_member, name: "lru_hits", scope: !335, file: !45, line: 384, baseType: !383, size: 16384, offset: 35008)
!383 = !DICompositeType(tag: DW_TAG_array_type, baseType: !119, size: 16384, elements: !384)
!384 = !{!385}
!385 = !DISubrange(count: 256)
!386 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_count", scope: !335, file: !45, line: 385, baseType: !119, size: 64, offset: 51392)
!387 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes", scope: !335, file: !45, line: 386, baseType: !119, size: 64, offset: 51456)
!388 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes_free", scope: !335, file: !45, line: 387, baseType: !119, size: 64, offset: 51520)
!389 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !262, file: !45, line: 731, baseType: !390, size: 576, offset: 54400)
!390 = !DICompositeType(tag: DW_TAG_array_type, baseType: !391, size: 576, elements: !409)
!391 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb_t", file: !45, line: 708, baseType: !392)
!392 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_cb_s", file: !45, line: 704, size: 192, elements: !393)
!393 = !{!394, !395, !408}
!394 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !392, file: !45, line: 705, baseType: !102, size: 64)
!395 = !DIDerivedType(tag: DW_TAG_member, name: "submit_cb", scope: !392, file: !45, line: 706, baseType: !396, size: 64, offset: 64)
!396 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_stack_cb", file: !45, line: 689, baseType: !397)
!397 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !398, size: 64)
!398 = !DISubroutineType(types: !399)
!399 = !{null, !400}
!400 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !401, size: 64)
!401 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_t", file: !45, line: 688, baseType: !402)
!402 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_s", file: !45, line: 697, size: 192, elements: !403)
!403 = !{!404, !405, !406, !407}
!404 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !402, file: !45, line: 698, baseType: !102, size: 64)
!405 = !DIDerivedType(tag: DW_TAG_member, name: "stack_ctx", scope: !402, file: !45, line: 699, baseType: !102, size: 64, offset: 64)
!406 = !DIDerivedType(tag: DW_TAG_member, name: "count", scope: !402, file: !45, line: 700, baseType: !132, size: 32, offset: 128)
!407 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !402, file: !45, line: 701, baseType: !132, size: 32, offset: 160)
!408 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !392, file: !45, line: 707, baseType: !132, size: 32, offset: 128)
!409 = !{!410}
!410 = !DISubrange(count: 3)
!411 = !DIDerivedType(tag: DW_TAG_member, name: "ev_queue", scope: !262, file: !45, line: 732, baseType: !412, size: 64, offset: 54976)
!412 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !413, size: 64)
!413 = !DICompositeType(tag: DW_TAG_structure_type, name: "conn_queue", file: !45, line: 732, flags: DIFlagFwdDecl)
!414 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_cache", scope: !262, file: !45, line: 733, baseType: !415, size: 64, offset: 55040)
!415 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !416, size: 64)
!416 = !DIDerivedType(tag: DW_TAG_typedef, name: "cache_t", file: !417, line: 39, baseType: !418)
!417 = !DIFile(filename: "./cache.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d97639c8540587a19d8550d7d7156448")
!418 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !417, line: 22, size: 704, elements: !419)
!419 = !{!420, !421, !422, !435, !438, !439, !440, !441}
!420 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !418, file: !417, line: 24, baseType: !275, size: 320)
!421 = !DIDerivedType(tag: DW_TAG_member, name: "name", scope: !418, file: !417, line: 26, baseType: !142, size: 64, offset: 320)
!422 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !418, file: !417, line: 28, baseType: !423, size: 128, offset: 384)
!423 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_head", file: !417, line: 28, size: 128, elements: !424)
!424 = !{!425, !433}
!425 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !423, file: !417, line: 28, baseType: !426, size: 64)
!426 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !427, size: 64)
!427 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_free_s", file: !417, line: 12, size: 64, elements: !428)
!428 = !{!429}
!429 = !DIDerivedType(tag: DW_TAG_member, name: "c_next", scope: !427, file: !417, line: 13, baseType: !430, size: 64)
!430 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !427, file: !417, line: 13, size: 64, elements: !431)
!431 = !{!432}
!432 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !430, file: !417, line: 13, baseType: !426, size: 64)
!433 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !423, file: !417, line: 28, baseType: !434, size: 64, offset: 64)
!434 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !426, size: 64)
!435 = !DIDerivedType(tag: DW_TAG_member, name: "bufsize", scope: !418, file: !417, line: 30, baseType: !436, size: 64, offset: 512)
!436 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !437, line: 18, baseType: !121)
!437 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!438 = !DIDerivedType(tag: DW_TAG_member, name: "freetotal", scope: !418, file: !417, line: 32, baseType: !132, size: 32, offset: 576)
!439 = !DIDerivedType(tag: DW_TAG_member, name: "total", scope: !418, file: !417, line: 34, baseType: !132, size: 32, offset: 608)
!440 = !DIDerivedType(tag: DW_TAG_member, name: "freecurr", scope: !418, file: !417, line: 36, baseType: !132, size: 32, offset: 640)
!441 = !DIDerivedType(tag: DW_TAG_member, name: "limit", scope: !418, file: !417, line: 38, baseType: !132, size: 32, offset: 672)
!442 = !DIDerivedType(tag: DW_TAG_member, name: "open_bundle", scope: !262, file: !45, line: 734, baseType: !253, size: 64, offset: 55104)
!443 = !DIDerivedType(tag: DW_TAG_member, name: "io_cache", scope: !262, file: !45, line: 735, baseType: !415, size: 64, offset: 55168)
!444 = !DIDerivedType(tag: DW_TAG_member, name: "storage", scope: !262, file: !45, line: 737, baseType: !102, size: 64, offset: 55232)
!445 = !DIDerivedType(tag: DW_TAG_member, name: "l", scope: !262, file: !45, line: 739, baseType: !446, size: 64, offset: 55296)
!446 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !447, size: 64)
!447 = !DIDerivedType(tag: DW_TAG_typedef, name: "logger", file: !6, line: 193, baseType: !448)
!448 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logger", file: !6, line: 181, size: 832, elements: !449)
!449 = !{!450, !452, !453, !454, !455, !456, !457, !458, !459, !460, !473}
!450 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !448, file: !6, line: 182, baseType: !451, size: 64)
!451 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !448, size: 64)
!452 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !448, file: !6, line: 183, baseType: !451, size: 64, offset: 64)
!453 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !448, file: !6, line: 184, baseType: !275, size: 320, offset: 128)
!454 = !DIDerivedType(tag: DW_TAG_member, name: "written", scope: !448, file: !6, line: 185, baseType: !119, size: 64, offset: 448)
!455 = !DIDerivedType(tag: DW_TAG_member, name: "dropped", scope: !448, file: !6, line: 186, baseType: !119, size: 64, offset: 512)
!456 = !DIDerivedType(tag: DW_TAG_member, name: "blocked", scope: !448, file: !6, line: 187, baseType: !119, size: 64, offset: 576)
!457 = !DIDerivedType(tag: DW_TAG_member, name: "fetcher_ratio", scope: !448, file: !6, line: 188, baseType: !115, size: 16, offset: 640)
!458 = !DIDerivedType(tag: DW_TAG_member, name: "mutation_ratio", scope: !448, file: !6, line: 189, baseType: !115, size: 16, offset: 656)
!459 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !448, file: !6, line: 190, baseType: !115, size: 16, offset: 672)
!460 = !DIDerivedType(tag: DW_TAG_member, name: "buf", scope: !448, file: !6, line: 191, baseType: !461, size: 64, offset: 704)
!461 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !462, size: 64)
!462 = !DIDerivedType(tag: DW_TAG_typedef, name: "bipbuf_t", file: !463, line: 18, baseType: !464)
!463 = !DIFile(filename: "./bipbuffer.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "99606bcb8393045e6bc9eef40115066f")
!464 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !463, line: 4, size: 192, elements: !465)
!465 = !{!466, !467, !468, !469, !470, !471}
!466 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !464, file: !463, line: 6, baseType: !121, size: 64)
!467 = !DIDerivedType(tag: DW_TAG_member, name: "a_start", scope: !464, file: !463, line: 9, baseType: !7, size: 32, offset: 64)
!468 = !DIDerivedType(tag: DW_TAG_member, name: "a_end", scope: !464, file: !463, line: 9, baseType: !7, size: 32, offset: 96)
!469 = !DIDerivedType(tag: DW_TAG_member, name: "b_end", scope: !464, file: !463, line: 12, baseType: !7, size: 32, offset: 128)
!470 = !DIDerivedType(tag: DW_TAG_member, name: "b_inuse", scope: !464, file: !463, line: 15, baseType: !132, size: 32, offset: 160)
!471 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !464, file: !463, line: 17, baseType: !472, offset: 192)
!472 = !DICompositeType(tag: DW_TAG_array_type, baseType: !113, elements: !139)
!473 = !DIDerivedType(tag: DW_TAG_member, name: "entry_map", scope: !448, file: !6, line: 192, baseType: !474, size: 64, offset: 768)
!474 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !475, size: 64)
!475 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !476)
!476 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_details", file: !6, line: 58, baseType: !477)
!477 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_entry_details", file: !6, line: 63, size: 256, elements: !478)
!478 = !{!479, !480, !481, !495, !500}
!479 = !DIDerivedType(tag: DW_TAG_member, name: "reqlen", scope: !477, file: !6, line: 64, baseType: !132, size: 32)
!480 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !477, file: !6, line: 65, baseType: !115, size: 16, offset: 32)
!481 = !DIDerivedType(tag: DW_TAG_member, name: "log_cb", scope: !477, file: !6, line: 66, baseType: !482, size: 64, offset: 64)
!482 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_log_cb", file: !6, line: 60, baseType: !483)
!483 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !484, size: 64)
!484 = !DISubroutineType(types: !485)
!485 = !{null, !103, !474, !486, !488}
!486 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !487, size: 64)
!487 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!488 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !489, size: 64)
!489 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !490)
!490 = !{!491, !492, !493, !494}
!491 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !489, file: !3, line: 983, baseType: !7, size: 32)
!492 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !489, file: !3, line: 983, baseType: !7, size: 32, offset: 32)
!493 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !489, file: !3, line: 983, baseType: !102, size: 64, offset: 64)
!494 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !489, file: !3, line: 983, baseType: !102, size: 64, offset: 128)
!495 = !DIDerivedType(tag: DW_TAG_member, name: "parse_cb", scope: !477, file: !6, line: 67, baseType: !496, size: 64, offset: 128)
!496 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_parse_cb", file: !6, line: 61, baseType: !497)
!497 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !498, size: 64)
!498 = !DISubroutineType(types: !499)
!499 = !{!132, !103, !142}
!500 = !DIDerivedType(tag: DW_TAG_member, name: "format", scope: !477, file: !6, line: 68, baseType: !142, size: 64, offset: 192)
!501 = !DIDerivedType(tag: DW_TAG_member, name: "lru_bump_buf", scope: !262, file: !45, line: 740, baseType: !102, size: 64, offset: 55360)
!502 = !DIDerivedType(tag: DW_TAG_member, name: "napi_id", scope: !262, file: !45, line: 744, baseType: !132, size: 32, offset: 55424)
!503 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !255, file: !45, line: 808, baseType: !504, size: 64, offset: 128)
!504 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !255, size: 64)
!505 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !255, file: !45, line: 809, baseType: !504, size: 64, offset: 192)
!506 = !DIDerivedType(tag: DW_TAG_member, name: "r", scope: !255, file: !45, line: 810, baseType: !507, offset: 256)
!507 = !DICompositeType(tag: DW_TAG_array_type, baseType: !249, elements: !139)
!508 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !250, file: !45, line: 773, baseType: !509, size: 64, offset: 64)
!509 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !250, size: 64)
!510 = !DIDerivedType(tag: DW_TAG_member, name: "wbytes", scope: !250, file: !45, line: 774, baseType: !132, size: 32, offset: 128)
!511 = !DIDerivedType(tag: DW_TAG_member, name: "tosend", scope: !250, file: !45, line: 775, baseType: !132, size: 32, offset: 160)
!512 = !DIDerivedType(tag: DW_TAG_member, name: "write_and_free", scope: !250, file: !45, line: 776, baseType: !102, size: 64, offset: 192)
!513 = !DIDerivedType(tag: DW_TAG_member, name: "io_pending", scope: !250, file: !45, line: 777, baseType: !319, size: 64, offset: 256)
!514 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !250, file: !45, line: 779, baseType: !515, size: 64, offset: 320)
!515 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !516, size: 64)
!516 = !DIDerivedType(tag: DW_TAG_typedef, name: "item", file: !45, line: 616, baseType: !517)
!517 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_stritem", file: !45, line: 593, size: 384, elements: !518)
!518 = !{!519, !521, !522, !523, !524, !525, !526, !527, !528, !529, !530}
!519 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !517, file: !45, line: 595, baseType: !520, size: 64)
!520 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !517, size: 64)
!521 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !517, file: !45, line: 596, baseType: !520, size: 64, offset: 64)
!522 = !DIDerivedType(tag: DW_TAG_member, name: "h_next", scope: !517, file: !45, line: 598, baseType: !520, size: 64, offset: 128)
!523 = !DIDerivedType(tag: DW_TAG_member, name: "time", scope: !517, file: !45, line: 599, baseType: !164, size: 32, offset: 192)
!524 = !DIDerivedType(tag: DW_TAG_member, name: "exptime", scope: !517, file: !45, line: 600, baseType: !164, size: 32, offset: 224)
!525 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !517, file: !45, line: 601, baseType: !132, size: 32, offset: 256)
!526 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !517, file: !45, line: 602, baseType: !117, size: 16, offset: 288)
!527 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !517, file: !45, line: 603, baseType: !115, size: 16, offset: 304)
!528 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !517, file: !45, line: 604, baseType: !109, size: 8, offset: 320)
!529 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !517, file: !45, line: 605, baseType: !109, size: 8, offset: 328)
!530 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !517, file: !45, line: 611, baseType: !531, offset: 384)
!531 = !DICompositeType(tag: DW_TAG_array_type, baseType: !532, elements: !139)
!532 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !517, file: !45, line: 608, size: 64, elements: !533)
!533 = !{!534, !535}
!534 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !532, file: !45, line: 609, baseType: !119, size: 64)
!535 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !532, file: !45, line: 610, baseType: !138, size: 8)
!536 = !DIDerivedType(tag: DW_TAG_member, name: "iov", scope: !250, file: !45, line: 780, baseType: !537, size: 512, offset: 384)
!537 = !DICompositeType(tag: DW_TAG_array_type, baseType: !538, size: 512, elements: !543)
!538 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iovec", file: !539, line: 26, size: 128, elements: !540)
!539 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_iovec.h", directory: "", checksumkind: CSK_MD5, checksum: "a53f2c2488bb0e21e47850624c16538a")
!540 = !{!541, !542}
!541 = !DIDerivedType(tag: DW_TAG_member, name: "iov_base", scope: !538, file: !539, line: 28, baseType: !102, size: 64)
!542 = !DIDerivedType(tag: DW_TAG_member, name: "iov_len", scope: !538, file: !539, line: 29, baseType: !436, size: 64, offset: 64)
!543 = !{!544}
!544 = !DISubrange(count: 4)
!545 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_total", scope: !250, file: !45, line: 781, baseType: !132, size: 32, offset: 896)
!546 = !DIDerivedType(tag: DW_TAG_member, name: "iovcnt", scope: !250, file: !45, line: 782, baseType: !109, size: 8, offset: 928)
!547 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_data_iov", scope: !250, file: !45, line: 783, baseType: !109, size: 8, offset: 936)
!548 = !DIDerivedType(tag: DW_TAG_member, name: "skip", scope: !250, file: !45, line: 788, baseType: !154, size: 8, offset: 944)
!549 = !DIDerivedType(tag: DW_TAG_member, name: "free", scope: !250, file: !45, line: 789, baseType: !154, size: 8, offset: 952)
!550 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !250, file: !45, line: 794, baseType: !115, size: 16, offset: 960)
!551 = !DIDerivedType(tag: DW_TAG_member, name: "udp_sequence", scope: !250, file: !45, line: 795, baseType: !115, size: 16, offset: 976)
!552 = !DIDerivedType(tag: DW_TAG_member, name: "udp_total", scope: !250, file: !45, line: 796, baseType: !115, size: 16, offset: 992)
!553 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !250, file: !45, line: 797, baseType: !554, size: 224, offset: 1024)
!554 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "sockaddr_in6", file: !555, line: 262, size: 224, elements: !556)
!555 = !DIFile(filename: "/usr/include/netinet/in.h", directory: "", checksumkind: CSK_MD5, checksum: "fbd766480c8cb9a8fe07ee7aa568ee60")
!556 = !{!557, !560, !562, !565, !581}
!557 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_family", scope: !554, file: !555, line: 264, baseType: !558, size: 16)
!558 = !DIDerivedType(tag: DW_TAG_typedef, name: "sa_family_t", file: !559, line: 28, baseType: !117)
!559 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/sockaddr.h", directory: "", checksumkind: CSK_MD5, checksum: "5066b774f0f3cdb5cbbb5467306060db")
!560 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_port", scope: !554, file: !555, line: 265, baseType: !561, size: 16, offset: 16)
!561 = !DIDerivedType(tag: DW_TAG_typedef, name: "in_port_t", file: !555, line: 125, baseType: !115)
!562 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_flowinfo", scope: !554, file: !555, line: 266, baseType: !563, size: 32, offset: 32)
!563 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !110, line: 26, baseType: !564)
!564 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !112, line: 42, baseType: !7)
!565 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_addr", scope: !554, file: !555, line: 267, baseType: !566, size: 128, offset: 64)
!566 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "in6_addr", file: !555, line: 221, size: 128, elements: !567)
!567 = !{!568}
!568 = !DIDerivedType(tag: DW_TAG_member, name: "__in6_u", scope: !566, file: !555, line: 228, baseType: !569, size: 128)
!569 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !566, file: !555, line: 223, size: 128, elements: !570)
!570 = !{!571, !575, !579}
!571 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr8", scope: !569, file: !555, line: 225, baseType: !572, size: 128)
!572 = !DICompositeType(tag: DW_TAG_array_type, baseType: !109, size: 128, elements: !573)
!573 = !{!574}
!574 = !DISubrange(count: 16)
!575 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr16", scope: !569, file: !555, line: 226, baseType: !576, size: 128)
!576 = !DICompositeType(tag: DW_TAG_array_type, baseType: !115, size: 128, elements: !577)
!577 = !{!578}
!578 = !DISubrange(count: 8)
!579 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr32", scope: !569, file: !555, line: 227, baseType: !580, size: 128)
!580 = !DICompositeType(tag: DW_TAG_array_type, baseType: !563, size: 128, elements: !543)
!581 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_scope_id", scope: !554, file: !555, line: 268, baseType: !563, size: 32, offset: 192)
!582 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !250, file: !45, line: 798, baseType: !583, size: 32, offset: 1248)
!583 = !DIDerivedType(tag: DW_TAG_typedef, name: "socklen_t", file: !584, line: 33, baseType: !585)
!584 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/socket.h", directory: "", checksumkind: CSK_MD5, checksum: "71a09f67661e8e55cf505c19b5ddbb85")
!585 = !DIDerivedType(tag: DW_TAG_typedef, name: "__socklen_t", file: !112, line: 210, baseType: !7)
!586 = !DIDerivedType(tag: DW_TAG_member, name: "wbuf", scope: !250, file: !45, line: 800, baseType: !587, size: 8192, offset: 1280)
!587 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 8192, elements: !588)
!588 = !{!589}
!589 = !DISubrange(count: 1024)
!590 = !DIDerivedType(tag: DW_TAG_member, name: "resp_head", scope: !146, file: !45, line: 857, baseType: !248, size: 64, offset: 1600)
!591 = !DIDerivedType(tag: DW_TAG_member, name: "ritem", scope: !146, file: !45, line: 858, baseType: !142, size: 64, offset: 1664)
!592 = !DIDerivedType(tag: DW_TAG_member, name: "rlbytes", scope: !146, file: !45, line: 859, baseType: !132, size: 32, offset: 1728)
!593 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !146, file: !45, line: 867, baseType: !102, size: 64, offset: 1792)
!594 = !DIDerivedType(tag: DW_TAG_member, name: "sbytes", scope: !146, file: !45, line: 870, baseType: !132, size: 32, offset: 1856)
!595 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues_submitted", scope: !146, file: !45, line: 872, baseType: !132, size: 32, offset: 1888)
!596 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !146, file: !45, line: 873, baseType: !597, size: 576, offset: 1920)
!597 = !DICompositeType(tag: DW_TAG_array_type, baseType: !401, size: 576, elements: !409)
!598 = !DIDerivedType(tag: DW_TAG_member, name: "recache_counter", scope: !146, file: !45, line: 878, baseType: !7, size: 32, offset: 2496)
!599 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !146, file: !45, line: 880, baseType: !77, size: 32, offset: 2528)
!600 = !DIDerivedType(tag: DW_TAG_member, name: "transport", scope: !146, file: !45, line: 881, baseType: !82, size: 32, offset: 2560)
!601 = !DIDerivedType(tag: DW_TAG_member, name: "close_reason", scope: !146, file: !45, line: 882, baseType: !87, size: 32, offset: 2592)
!602 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !146, file: !45, line: 885, baseType: !132, size: 32, offset: 2624)
!603 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !146, file: !45, line: 886, baseType: !554, size: 224, offset: 2656)
!604 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !146, file: !45, line: 887, baseType: !583, size: 32, offset: 2880)
!605 = !DIDerivedType(tag: DW_TAG_member, name: "noreply", scope: !146, file: !45, line: 889, baseType: !154, size: 8, offset: 2912)
!606 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !146, file: !45, line: 895, baseType: !607, size: 192, offset: 2944)
!607 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !146, file: !45, line: 891, size: 192, elements: !608)
!608 = !{!609, !610, !611}
!609 = !DIDerivedType(tag: DW_TAG_member, name: "buffer", scope: !607, file: !45, line: 892, baseType: !142, size: 64)
!610 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !607, file: !45, line: 893, baseType: !436, size: 64, offset: 64)
!611 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !607, file: !45, line: 894, baseType: !436, size: 64, offset: 128)
!612 = !DIDerivedType(tag: DW_TAG_member, name: "binary_header", scope: !146, file: !45, line: 899, baseType: !613, size: 192, offset: 3136)
!613 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_request_header", file: !614, line: 164, baseType: !615)
!614 = !DIFile(filename: "./protocol_binary.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "7a322a65fa8661e9a597acbeeeb23107")
!615 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !614, line: 151, size: 192, elements: !616)
!616 = !{!617, !629}
!617 = !DIDerivedType(tag: DW_TAG_member, name: "request", scope: !615, file: !614, line: 162, baseType: !618, size: 192)
!618 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !615, file: !614, line: 152, size: 192, elements: !619)
!619 = !{!620, !621, !622, !623, !624, !625, !626, !627, !628}
!620 = !DIDerivedType(tag: DW_TAG_member, name: "magic", scope: !618, file: !614, line: 153, baseType: !109, size: 8)
!621 = !DIDerivedType(tag: DW_TAG_member, name: "opcode", scope: !618, file: !614, line: 154, baseType: !109, size: 8, offset: 8)
!622 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !618, file: !614, line: 155, baseType: !115, size: 16, offset: 16)
!623 = !DIDerivedType(tag: DW_TAG_member, name: "extlen", scope: !618, file: !614, line: 156, baseType: !109, size: 8, offset: 32)
!624 = !DIDerivedType(tag: DW_TAG_member, name: "datatype", scope: !618, file: !614, line: 157, baseType: !109, size: 8, offset: 40)
!625 = !DIDerivedType(tag: DW_TAG_member, name: "reserved", scope: !618, file: !614, line: 158, baseType: !115, size: 16, offset: 48)
!626 = !DIDerivedType(tag: DW_TAG_member, name: "bodylen", scope: !618, file: !614, line: 159, baseType: !563, size: 32, offset: 64)
!627 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !618, file: !614, line: 160, baseType: !563, size: 32, offset: 96)
!628 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !618, file: !614, line: 161, baseType: !119, size: 64, offset: 128)
!629 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !615, file: !614, line: 163, baseType: !630, size: 192)
!630 = !DICompositeType(tag: DW_TAG_array_type, baseType: !109, size: 192, elements: !631)
!631 = !{!632}
!632 = !DISubrange(count: 24)
!633 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !146, file: !45, line: 900, baseType: !119, size: 64, offset: 3328)
!634 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !146, file: !45, line: 901, baseType: !119, size: 64, offset: 3392)
!635 = !DIDerivedType(tag: DW_TAG_member, name: "cmd", scope: !146, file: !45, line: 902, baseType: !180, size: 16, offset: 3456)
!636 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !146, file: !45, line: 903, baseType: !132, size: 32, offset: 3488)
!637 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !146, file: !45, line: 904, baseType: !132, size: 32, offset: 3520)
!638 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !146, file: !45, line: 905, baseType: !144, size: 64, offset: 3584)
!639 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !146, file: !45, line: 906, baseType: !260, size: 64, offset: 3648)
!640 = !DIDerivedType(tag: DW_TAG_member, name: "try_read_command", scope: !146, file: !45, line: 907, baseType: !641, size: 64, offset: 3712)
!641 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !642, size: 64)
!642 = !DISubroutineType(types: !643)
!643 = !{!132, !144}
!644 = !DIDerivedType(tag: DW_TAG_member, name: "read", scope: !146, file: !45, line: 908, baseType: !645, size: 64, offset: 3776)
!645 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !646, size: 64)
!646 = !DISubroutineType(types: !647)
!647 = !{!648, !144, !102, !436}
!648 = !DIDerivedType(tag: DW_TAG_typedef, name: "ssize_t", file: !649, line: 108, baseType: !650)
!649 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/types.h", directory: "", checksumkind: CSK_MD5, checksum: "7fb02a803b0c9b11cb5276b77d21e9d8")
!650 = !DIDerivedType(tag: DW_TAG_typedef, name: "__ssize_t", file: !112, line: 194, baseType: !128)
!651 = !DIDerivedType(tag: DW_TAG_member, name: "sendmsg", scope: !146, file: !45, line: 909, baseType: !652, size: 64, offset: 3840)
!652 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !653, size: 64)
!653 = !DISubroutineType(types: !654)
!654 = !{!648, !144, !655, !132}
!655 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !656, size: 64)
!656 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "msghdr", file: !584, line: 262, size: 448, elements: !657)
!657 = !{!658, !659, !660, !662, !663, !664, !665}
!658 = !DIDerivedType(tag: DW_TAG_member, name: "msg_name", scope: !656, file: !584, line: 264, baseType: !102, size: 64)
!659 = !DIDerivedType(tag: DW_TAG_member, name: "msg_namelen", scope: !656, file: !584, line: 265, baseType: !583, size: 32, offset: 64)
!660 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iov", scope: !656, file: !584, line: 267, baseType: !661, size: 64, offset: 128)
!661 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !538, size: 64)
!662 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iovlen", scope: !656, file: !584, line: 268, baseType: !436, size: 64, offset: 192)
!663 = !DIDerivedType(tag: DW_TAG_member, name: "msg_control", scope: !656, file: !584, line: 270, baseType: !102, size: 64, offset: 256)
!664 = !DIDerivedType(tag: DW_TAG_member, name: "msg_controllen", scope: !656, file: !584, line: 271, baseType: !436, size: 64, offset: 320)
!665 = !DIDerivedType(tag: DW_TAG_member, name: "msg_flags", scope: !656, file: !584, line: 276, baseType: !132, size: 32, offset: 384)
!666 = !DIDerivedType(tag: DW_TAG_member, name: "write", scope: !146, file: !45, line: 910, baseType: !645, size: 64, offset: 3904)
!667 = !DIBasicType(name: "long long", size: 64, encoding: DW_ATE_signed)
!668 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !669, size: 64)
!669 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "logentry_eviction", file: !6, line: 72, size: 192, elements: !670)
!670 = !{!671, !672, !673, !674, !675, !676, !677}
!671 = !DIDerivedType(tag: DW_TAG_member, name: "exptime", scope: !669, file: !6, line: 73, baseType: !667, size: 64)
!672 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !669, file: !6, line: 74, baseType: !132, size: 32, offset: 64)
!673 = !DIDerivedType(tag: DW_TAG_member, name: "latime", scope: !669, file: !6, line: 75, baseType: !563, size: 32, offset: 96)
!674 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !669, file: !6, line: 76, baseType: !115, size: 16, offset: 128)
!675 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !669, file: !6, line: 77, baseType: !109, size: 8, offset: 144)
!676 = !DIDerivedType(tag: DW_TAG_member, name: "clsid", scope: !669, file: !6, line: 78, baseType: !109, size: 8, offset: 152)
!677 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !669, file: !6, line: 79, baseType: !678, offset: 160)
!678 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, elements: !139)
!679 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !680, size: 64)
!680 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "logentry_item_get", file: !6, line: 92, size: 96, elements: !681)
!681 = !{!682, !683, !684, !685, !686, !687}
!682 = !DIDerivedType(tag: DW_TAG_member, name: "was_found", scope: !680, file: !6, line: 93, baseType: !109, size: 8)
!683 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !680, file: !6, line: 94, baseType: !109, size: 8, offset: 8)
!684 = !DIDerivedType(tag: DW_TAG_member, name: "clsid", scope: !680, file: !6, line: 95, baseType: !109, size: 8, offset: 16)
!685 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !680, file: !6, line: 96, baseType: !132, size: 32, offset: 32)
!686 = !DIDerivedType(tag: DW_TAG_member, name: "sfd", scope: !680, file: !6, line: 97, baseType: !132, size: 32, offset: 64)
!687 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !680, file: !6, line: 98, baseType: !678, offset: 96)
!688 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !689, size: 64)
!689 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "logentry_item_store", file: !6, line: 101, size: 192, elements: !690)
!690 = !{!691, !692, !693, !694, !695, !696, !697, !698}
!691 = !DIDerivedType(tag: DW_TAG_member, name: "status", scope: !689, file: !6, line: 102, baseType: !132, size: 32)
!692 = !DIDerivedType(tag: DW_TAG_member, name: "cmd", scope: !689, file: !6, line: 103, baseType: !132, size: 32, offset: 32)
!693 = !DIDerivedType(tag: DW_TAG_member, name: "ttl", scope: !689, file: !6, line: 104, baseType: !164, size: 32, offset: 64)
!694 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !689, file: !6, line: 105, baseType: !109, size: 8, offset: 96)
!695 = !DIDerivedType(tag: DW_TAG_member, name: "clsid", scope: !689, file: !6, line: 106, baseType: !109, size: 8, offset: 104)
!696 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !689, file: !6, line: 107, baseType: !132, size: 32, offset: 128)
!697 = !DIDerivedType(tag: DW_TAG_member, name: "sfd", scope: !689, file: !6, line: 108, baseType: !132, size: 32, offset: 160)
!698 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !689, file: !6, line: 109, baseType: !678, offset: 192)
!699 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !700, size: 64)
!700 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "logentry_conn_event", file: !6, line: 120, size: 320, elements: !701)
!701 = !{!702, !703, !704, !705}
!702 = !DIDerivedType(tag: DW_TAG_member, name: "transport", scope: !700, file: !6, line: 121, baseType: !132, size: 32)
!703 = !DIDerivedType(tag: DW_TAG_member, name: "reason", scope: !700, file: !6, line: 122, baseType: !132, size: 32, offset: 32)
!704 = !DIDerivedType(tag: DW_TAG_member, name: "sfd", scope: !700, file: !6, line: 123, baseType: !132, size: 32, offset: 64)
!705 = !DIDerivedType(tag: DW_TAG_member, name: "addr", scope: !700, file: !6, line: 124, baseType: !554, size: 224, offset: 96)
!706 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !707, size: 64)
!707 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "sockaddr_in", file: !555, line: 247, size: 128, elements: !708)
!708 = !{!709, !710, !711, !716}
!709 = !DIDerivedType(tag: DW_TAG_member, name: "sin_family", scope: !707, file: !555, line: 249, baseType: !558, size: 16)
!710 = !DIDerivedType(tag: DW_TAG_member, name: "sin_port", scope: !707, file: !555, line: 250, baseType: !561, size: 16, offset: 16)
!711 = !DIDerivedType(tag: DW_TAG_member, name: "sin_addr", scope: !707, file: !555, line: 251, baseType: !712, size: 32, offset: 32)
!712 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "in_addr", file: !555, line: 31, size: 32, elements: !713)
!713 = !{!714}
!714 = !DIDerivedType(tag: DW_TAG_member, name: "s_addr", scope: !712, file: !555, line: 33, baseType: !715, size: 32)
!715 = !DIDerivedType(tag: DW_TAG_typedef, name: "in_addr_t", file: !555, line: 30, baseType: !563)
!716 = !DIDerivedType(tag: DW_TAG_member, name: "sin_zero", scope: !707, file: !555, line: 254, baseType: !717, size: 64, offset: 64)
!717 = !DICompositeType(tag: DW_TAG_array_type, baseType: !113, size: 64, elements: !577)
!718 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !554, size: 64)
!719 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !720, size: 64)
!720 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "logentry_deletion", file: !6, line: 112, size: 96, elements: !721)
!721 = !{!722, !723, !724, !725, !726}
!722 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !720, file: !6, line: 113, baseType: !132, size: 32)
!723 = !DIDerivedType(tag: DW_TAG_member, name: "cmd", scope: !720, file: !6, line: 114, baseType: !132, size: 32, offset: 32)
!724 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !720, file: !6, line: 115, baseType: !109, size: 8, offset: 64)
!725 = !DIDerivedType(tag: DW_TAG_member, name: "clsid", scope: !720, file: !6, line: 116, baseType: !109, size: 8, offset: 72)
!726 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !720, file: !6, line: 117, baseType: !678, offset: 80)
!727 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !728, size: 64)
!728 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "logentry_ext_write", file: !6, line: 82, size: 192, elements: !729)
!729 = !{!730, !731, !732, !733, !734, !735, !736}
!730 = !DIDerivedType(tag: DW_TAG_member, name: "exptime", scope: !728, file: !6, line: 83, baseType: !667, size: 64)
!731 = !DIDerivedType(tag: DW_TAG_member, name: "latime", scope: !728, file: !6, line: 84, baseType: !563, size: 32, offset: 64)
!732 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !728, file: !6, line: 85, baseType: !115, size: 16, offset: 96)
!733 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !728, file: !6, line: 86, baseType: !109, size: 8, offset: 112)
!734 = !DIDerivedType(tag: DW_TAG_member, name: "clsid", scope: !728, file: !6, line: 87, baseType: !109, size: 8, offset: 120)
!735 = !DIDerivedType(tag: DW_TAG_member, name: "bucket", scope: !728, file: !6, line: 88, baseType: !109, size: 8, offset: 128)
!736 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !728, file: !6, line: 89, baseType: !678, offset: 136)
!737 = !{!0, !738, !771, !773, !778, !783, !786, !804, !813, !815, !817, !819, !824, !829, !832, !834, !839, !844, !849, !854, !856, !861, !866, !871, !876, !881, !886, !889, !891, !894, !899, !901, !906, !909, !912, !917, !922, !925, !927, !932, !934, !939, !941, !943, !945, !947, !949, !951, !953, !955, !957, !959, !961, !966, !968, !970, !972, !977, !979, !981, !983, !988, !993, !998, !1000, !1002, !1007, !1012}
!738 = !DIGlobalVariableExpression(var: !739, expr: !DIExpression())
!739 = distinct !DIGlobalVariable(name: "logger_stack_cond", scope: !2, file: !3, line: 36, type: !740, isLocal: false, isDefinition: true)
!740 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_cond_t", file: !266, line: 80, baseType: !741)
!741 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !266, line: 75, size: 384, elements: !742)
!742 = !{!743, !766, !770}
!743 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !741, file: !266, line: 77, baseType: !744, size: 384)
!744 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_cond_s", file: !291, line: 94, size: 384, elements: !745)
!745 = !{!746, !757, !758, !762, !763, !764, !765}
!746 = !DIDerivedType(tag: DW_TAG_member, name: "__wseq", scope: !744, file: !291, line: 96, baseType: !747, size: 64)
!747 = !DIDerivedType(tag: DW_TAG_typedef, name: "__atomic_wide_counter", file: !748, line: 33, baseType: !749)
!748 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h", directory: "", checksumkind: CSK_MD5, checksum: "d1ec99b0f6e36c0a42ac284d459cbd38")
!749 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !748, line: 25, size: 64, elements: !750)
!750 = !{!751, !752}
!751 = !DIDerivedType(tag: DW_TAG_member, name: "__value64", scope: !749, file: !748, line: 27, baseType: !143, size: 64)
!752 = !DIDerivedType(tag: DW_TAG_member, name: "__value32", scope: !749, file: !748, line: 32, baseType: !753, size: 64)
!753 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !749, file: !748, line: 28, size: 64, elements: !754)
!754 = !{!755, !756}
!755 = !DIDerivedType(tag: DW_TAG_member, name: "__low", scope: !753, file: !748, line: 30, baseType: !7, size: 32)
!756 = !DIDerivedType(tag: DW_TAG_member, name: "__high", scope: !753, file: !748, line: 31, baseType: !7, size: 32, offset: 32)
!757 = !DIDerivedType(tag: DW_TAG_member, name: "__g1_start", scope: !744, file: !291, line: 97, baseType: !747, size: 64, offset: 64)
!758 = !DIDerivedType(tag: DW_TAG_member, name: "__g_refs", scope: !744, file: !291, line: 98, baseType: !759, size: 64, offset: 128)
!759 = !DICompositeType(tag: DW_TAG_array_type, baseType: !7, size: 64, elements: !760)
!760 = !{!761}
!761 = !DISubrange(count: 2)
!762 = !DIDerivedType(tag: DW_TAG_member, name: "__g_size", scope: !744, file: !291, line: 99, baseType: !759, size: 64, offset: 192)
!763 = !DIDerivedType(tag: DW_TAG_member, name: "__g1_orig_size", scope: !744, file: !291, line: 100, baseType: !7, size: 32, offset: 256)
!764 = !DIDerivedType(tag: DW_TAG_member, name: "__wrefs", scope: !744, file: !291, line: 101, baseType: !7, size: 32, offset: 288)
!765 = !DIDerivedType(tag: DW_TAG_member, name: "__g_signals", scope: !744, file: !291, line: 102, baseType: !759, size: 64, offset: 320)
!766 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !741, file: !266, line: 78, baseType: !767, size: 384)
!767 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 384, elements: !768)
!768 = !{!769}
!769 = !DISubrange(count: 48)
!770 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !741, file: !266, line: 79, baseType: !667, size: 64)
!771 = !DIGlobalVariableExpression(var: !772, expr: !DIExpression())
!772 = distinct !DIGlobalVariable(name: "watcher_count", scope: !2, file: !3, line: 47, type: !132, isLocal: false, isDefinition: true)
!773 = !DIGlobalVariableExpression(var: !774, expr: !DIExpression())
!774 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1057, type: !775, isLocal: true, isDefinition: true)
!775 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 352, elements: !776)
!776 = !{!777}
!777 = !DISubrange(count: 44)
!778 = !DIGlobalVariableExpression(var: !779, expr: !DIExpression())
!779 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1113, type: !780, isLocal: true, isDefinition: true)
!780 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 40, elements: !781)
!781 = !{!782}
!782 = !DISubrange(count: 5)
!783 = !DIGlobalVariableExpression(var: !784, expr: !DIExpression())
!784 = distinct !DIGlobalVariable(name: "logger_key", scope: !2, file: !3, line: 38, type: !785, isLocal: false, isDefinition: true)
!785 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_key_t", file: !266, line: 49, baseType: !7)
!786 = !DIGlobalVariableExpression(var: !787, expr: !DIExpression())
!787 = distinct !DIGlobalVariable(name: "watchers", scope: !2, file: !3, line: 45, type: !788, isLocal: false, isDefinition: true)
!788 = !DICompositeType(tag: DW_TAG_array_type, baseType: !789, size: 1280, elements: !802)
!789 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !790, size: 64)
!790 = !DIDerivedType(tag: DW_TAG_typedef, name: "logger_watcher", file: !6, line: 210, baseType: !791)
!791 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !6, line: 200, size: 448, elements: !792)
!792 = !{!793, !794, !795, !796, !797, !798, !799, !800, !801}
!793 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !791, file: !6, line: 201, baseType: !102, size: 64)
!794 = !DIDerivedType(tag: DW_TAG_member, name: "sfd", scope: !791, file: !6, line: 202, baseType: !132, size: 32, offset: 64)
!795 = !DIDerivedType(tag: DW_TAG_member, name: "id", scope: !791, file: !6, line: 203, baseType: !132, size: 32, offset: 96)
!796 = !DIDerivedType(tag: DW_TAG_member, name: "skipped", scope: !791, file: !6, line: 204, baseType: !119, size: 64, offset: 128)
!797 = !DIDerivedType(tag: DW_TAG_member, name: "min_gid", scope: !791, file: !6, line: 205, baseType: !119, size: 64, offset: 192)
!798 = !DIDerivedType(tag: DW_TAG_member, name: "failed_flush", scope: !791, file: !6, line: 206, baseType: !154, size: 8, offset: 256)
!799 = !DIDerivedType(tag: DW_TAG_member, name: "t", scope: !791, file: !6, line: 207, baseType: !35, size: 32, offset: 288)
!800 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !791, file: !6, line: 208, baseType: !115, size: 16, offset: 320)
!801 = !DIDerivedType(tag: DW_TAG_member, name: "buf", scope: !791, file: !6, line: 209, baseType: !461, size: 64, offset: 384)
!802 = !{!803}
!803 = !DISubrange(count: 20)
!804 = !DIGlobalVariableExpression(var: !805, expr: !DIExpression())
!805 = distinct !DIGlobalVariable(name: "watchers_pollfds", scope: !2, file: !3, line: 46, type: !806, isLocal: false, isDefinition: true)
!806 = !DICompositeType(tag: DW_TAG_array_type, baseType: !807, size: 1280, elements: !802)
!807 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "pollfd", file: !808, line: 36, size: 64, elements: !809)
!808 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/poll.h", directory: "", checksumkind: CSK_MD5, checksum: "1a4eb88ffdcfba173b0f25ae540bbd7b")
!809 = !{!810, !811, !812}
!810 = !DIDerivedType(tag: DW_TAG_member, name: "fd", scope: !807, file: !808, line: 38, baseType: !132, size: 32)
!811 = !DIDerivedType(tag: DW_TAG_member, name: "events", scope: !807, file: !808, line: 39, baseType: !180, size: 16, offset: 32)
!812 = !DIDerivedType(tag: DW_TAG_member, name: "revents", scope: !807, file: !808, line: 40, baseType: !180, size: 16, offset: 48)
!813 = !DIGlobalVariableExpression(var: !814, expr: !DIExpression())
!814 = distinct !DIGlobalVariable(name: "logger_gid", scope: !2, file: !3, line: 547, type: !119, isLocal: true, isDefinition: true)
!815 = !DIGlobalVariableExpression(var: !816, expr: !DIExpression())
!816 = distinct !DIGlobalVariable(name: "logger_stack_head", scope: !2, file: !3, line: 30, type: !446, isLocal: true, isDefinition: true)
!817 = !DIGlobalVariableExpression(var: !818, expr: !DIExpression())
!818 = distinct !DIGlobalVariable(name: "logger_stack_tail", scope: !2, file: !3, line: 31, type: !446, isLocal: true, isDefinition: true)
!819 = !DIGlobalVariableExpression(var: !820, expr: !DIExpression())
!820 = distinct !DIGlobalVariable(scope: null, file: !3, line: 939, type: !821, isLocal: true, isDefinition: true)
!821 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 248, elements: !822)
!822 = !{!823}
!823 = !DISubrange(count: 31)
!824 = !DIGlobalVariableExpression(var: !825, expr: !DIExpression())
!825 = distinct !DIGlobalVariable(scope: null, file: !3, line: 942, type: !826, isLocal: true, isDefinition: true)
!826 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 56, elements: !827)
!827 = !{!828}
!828 = !DISubrange(count: 7)
!829 = !DIGlobalVariableExpression(var: !830, expr: !DIExpression())
!830 = distinct !DIGlobalVariable(name: "do_run_logger_thread", scope: !2, file: !3, line: 33, type: !831, isLocal: true, isDefinition: true)
!831 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !132)
!832 = !DIGlobalVariableExpression(var: !833, expr: !DIExpression())
!833 = distinct !DIGlobalVariable(name: "logger_tid", scope: !2, file: !3, line: 34, type: !265, isLocal: true, isDefinition: true)
!834 = !DIGlobalVariableExpression(var: !835, expr: !DIExpression())
!835 = distinct !DIGlobalVariable(scope: null, file: !3, line: 740, type: !836, isLocal: true, isDefinition: true)
!836 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 280, elements: !837)
!837 = !{!838}
!838 = !DISubrange(count: 35)
!839 = !DIGlobalVariableExpression(var: !840, expr: !DIExpression())
!840 = distinct !DIGlobalVariable(scope: null, file: !3, line: 756, type: !841, isLocal: true, isDefinition: true)
!841 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 408, elements: !842)
!842 = !{!843}
!843 = !DISubrange(count: 51)
!844 = !DIGlobalVariableExpression(var: !845, expr: !DIExpression())
!845 = distinct !DIGlobalVariable(scope: null, file: !3, line: 683, type: !846, isLocal: true, isDefinition: true)
!846 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 112, elements: !847)
!847 = !{!848}
!848 = !DISubrange(count: 14)
!849 = !DIGlobalVariableExpression(var: !850, expr: !DIExpression())
!850 = distinct !DIGlobalVariable(scope: null, file: !3, line: 808, type: !851, isLocal: true, isDefinition: true)
!851 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 440, elements: !852)
!852 = !{!853}
!853 = !DISubrange(count: 55)
!854 = !DIGlobalVariableExpression(var: !855, expr: !DIExpression())
!855 = distinct !DIGlobalVariable(scope: null, file: !3, line: 489, type: !826, isLocal: true, isDefinition: true)
!856 = !DIGlobalVariableExpression(var: !857, expr: !DIExpression())
!857 = distinct !DIGlobalVariable(scope: null, file: !3, line: 494, type: !858, isLocal: true, isDefinition: true)
!858 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 1064, elements: !859)
!859 = !{!860}
!860 = !DISubrange(count: 133)
!861 = !DIGlobalVariableExpression(var: !862, expr: !DIExpression())
!862 = distinct !DIGlobalVariable(scope: null, file: !3, line: 497, type: !863, isLocal: true, isDefinition: true)
!863 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 232, elements: !864)
!864 = !{!865}
!865 = !DISubrange(count: 29)
!866 = !DIGlobalVariableExpression(var: !867, expr: !DIExpression())
!867 = distinct !DIGlobalVariable(scope: null, file: !3, line: 505, type: !868, isLocal: true, isDefinition: true)
!868 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 312, elements: !869)
!869 = !{!870}
!870 = !DISubrange(count: 39)
!871 = !DIGlobalVariableExpression(var: !872, expr: !DIExpression())
!872 = distinct !DIGlobalVariable(scope: null, file: !3, line: 508, type: !873, isLocal: true, isDefinition: true)
!873 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 208, elements: !874)
!874 = !{!875}
!875 = !DISubrange(count: 26)
!876 = !DIGlobalVariableExpression(var: !877, expr: !DIExpression())
!877 = distinct !DIGlobalVariable(scope: null, file: !3, line: 511, type: !878, isLocal: true, isDefinition: true)
!878 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 344, elements: !879)
!879 = !{!880}
!880 = !DISubrange(count: 43)
!881 = !DIGlobalVariableExpression(var: !882, expr: !DIExpression())
!882 = distinct !DIGlobalVariable(scope: null, file: !3, line: 514, type: !883, isLocal: true, isDefinition: true)
!883 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 592, elements: !884)
!884 = !{!885}
!885 = !DISubrange(count: 74)
!886 = !DIGlobalVariableExpression(var: !887, expr: !DIExpression())
!887 = distinct !DIGlobalVariable(scope: null, file: !3, line: 517, type: !888, isLocal: true, isDefinition: true)
!888 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 192, elements: !631)
!889 = !DIGlobalVariableExpression(var: !890, expr: !DIExpression())
!890 = distinct !DIGlobalVariable(scope: null, file: !3, line: 520, type: !878, isLocal: true, isDefinition: true)
!891 = !DIGlobalVariableExpression(var: !892, expr: !DIExpression())
!892 = distinct !DIGlobalVariable(name: "default_entries", scope: !2, file: !3, line: 488, type: !893, isLocal: true, isDefinition: true)
!893 = !DICompositeType(tag: DW_TAG_array_type, baseType: !475, size: 4096, elements: !573)
!894 = !DIGlobalVariableExpression(var: !895, expr: !DIExpression())
!895 = distinct !DIGlobalVariable(scope: null, file: !3, line: 58, type: !896, isLocal: true, isDefinition: true)
!896 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 432, elements: !897)
!897 = !{!898}
!898 = !DISubrange(count: 54)
!899 = !DIGlobalVariableExpression(var: !900, expr: !DIExpression())
!900 = distinct !DIGlobalVariable(scope: null, file: !3, line: 208, type: !888, isLocal: true, isDefinition: true)
!901 = !DIGlobalVariableExpression(var: !902, expr: !DIExpression())
!902 = distinct !DIGlobalVariable(scope: null, file: !3, line: 257, type: !903, isLocal: true, isDefinition: true)
!903 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 664, elements: !904)
!904 = !{!905}
!905 = !DISubrange(count: 83)
!906 = !DIGlobalVariableExpression(var: !907, expr: !DIExpression())
!907 = distinct !DIGlobalVariable(scope: null, file: !3, line: 259, type: !908, isLocal: true, isDefinition: true)
!908 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 32, elements: !543)
!909 = !DIGlobalVariableExpression(var: !910, expr: !DIExpression())
!910 = distinct !DIGlobalVariable(scope: null, file: !3, line: 259, type: !911, isLocal: true, isDefinition: true)
!911 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 24, elements: !409)
!912 = !DIGlobalVariableExpression(var: !913, expr: !DIExpression())
!913 = distinct !DIGlobalVariable(scope: null, file: !3, line: 240, type: !914, isLocal: true, isDefinition: true)
!914 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 80, elements: !915)
!915 = !{!916}
!916 = !DISubrange(count: 10)
!917 = !DIGlobalVariableExpression(var: !918, expr: !DIExpression())
!918 = distinct !DIGlobalVariable(scope: null, file: !3, line: 240, type: !919, isLocal: true, isDefinition: true)
!919 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 48, elements: !920)
!920 = !{!921}
!921 = !DISubrange(count: 6)
!922 = !DIGlobalVariableExpression(var: !923, expr: !DIExpression())
!923 = distinct !DIGlobalVariable(scope: null, file: !3, line: 240, type: !924, isLocal: true, isDefinition: true)
!924 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 64, elements: !577)
!925 = !DIGlobalVariableExpression(var: !926, expr: !DIExpression())
!926 = distinct !DIGlobalVariable(scope: null, file: !3, line: 240, type: !924, isLocal: true, isDefinition: true)
!927 = !DIGlobalVariableExpression(var: !928, expr: !DIExpression())
!928 = distinct !DIGlobalVariable(scope: null, file: !3, line: 244, type: !929, isLocal: true, isDefinition: true)
!929 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 608, elements: !930)
!930 = !{!931}
!931 = !DISubrange(count: 76)
!932 = !DIGlobalVariableExpression(var: !933, expr: !DIExpression())
!933 = distinct !DIGlobalVariable(scope: null, file: !3, line: 215, type: !911, isLocal: true, isDefinition: true)
!934 = !DIGlobalVariableExpression(var: !935, expr: !DIExpression())
!935 = distinct !DIGlobalVariable(scope: null, file: !3, line: 219, type: !936, isLocal: true, isDefinition: true)
!936 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 88, elements: !937)
!937 = !{!938}
!938 = !DISubrange(count: 11)
!939 = !DIGlobalVariableExpression(var: !940, expr: !DIExpression())
!940 = distinct !DIGlobalVariable(scope: null, file: !3, line: 219, type: !826, isLocal: true, isDefinition: true)
!941 = !DIGlobalVariableExpression(var: !942, expr: !DIExpression())
!942 = distinct !DIGlobalVariable(scope: null, file: !3, line: 219, type: !826, isLocal: true, isDefinition: true)
!943 = !DIGlobalVariableExpression(var: !944, expr: !DIExpression())
!944 = distinct !DIGlobalVariable(scope: null, file: !3, line: 219, type: !914, isLocal: true, isDefinition: true)
!945 = !DIGlobalVariableExpression(var: !946, expr: !DIExpression())
!946 = distinct !DIGlobalVariable(scope: null, file: !3, line: 219, type: !914, isLocal: true, isDefinition: true)
!947 = !DIGlobalVariableExpression(var: !948, expr: !DIExpression())
!948 = distinct !DIGlobalVariable(scope: null, file: !3, line: 221, type: !780, isLocal: true, isDefinition: true)
!949 = !DIGlobalVariableExpression(var: !950, expr: !DIExpression())
!950 = distinct !DIGlobalVariable(scope: null, file: !3, line: 221, type: !908, isLocal: true, isDefinition: true)
!951 = !DIGlobalVariableExpression(var: !952, expr: !DIExpression())
!952 = distinct !DIGlobalVariable(scope: null, file: !3, line: 221, type: !908, isLocal: true, isDefinition: true)
!953 = !DIGlobalVariableExpression(var: !954, expr: !DIExpression())
!954 = distinct !DIGlobalVariable(scope: null, file: !3, line: 221, type: !924, isLocal: true, isDefinition: true)
!955 = !DIGlobalVariableExpression(var: !956, expr: !DIExpression())
!956 = distinct !DIGlobalVariable(scope: null, file: !3, line: 221, type: !826, isLocal: true, isDefinition: true)
!957 = !DIGlobalVariableExpression(var: !958, expr: !DIExpression())
!958 = distinct !DIGlobalVariable(scope: null, file: !3, line: 221, type: !924, isLocal: true, isDefinition: true)
!959 = !DIGlobalVariableExpression(var: !960, expr: !DIExpression())
!960 = distinct !DIGlobalVariable(scope: null, file: !3, line: 221, type: !908, isLocal: true, isDefinition: true)
!961 = !DIGlobalVariableExpression(var: !962, expr: !DIExpression())
!962 = distinct !DIGlobalVariable(scope: null, file: !3, line: 228, type: !963, isLocal: true, isDefinition: true)
!963 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 736, elements: !964)
!964 = !{!965}
!965 = !DISubrange(count: 92)
!966 = !DIGlobalVariableExpression(var: !967, expr: !DIExpression())
!967 = distinct !DIGlobalVariable(scope: null, file: !3, line: 307, type: !919, isLocal: true, isDefinition: true)
!968 = !DIGlobalVariableExpression(var: !969, expr: !DIExpression())
!969 = distinct !DIGlobalVariable(scope: null, file: !3, line: 307, type: !908, isLocal: true, isDefinition: true)
!970 = !DIGlobalVariableExpression(var: !971, expr: !DIExpression())
!971 = distinct !DIGlobalVariable(scope: null, file: !3, line: 307, type: !908, isLocal: true, isDefinition: true)
!972 = !DIGlobalVariableExpression(var: !973, expr: !DIExpression())
!973 = distinct !DIGlobalVariable(scope: null, file: !3, line: 312, type: !974, isLocal: true, isDefinition: true)
!974 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 576, elements: !975)
!975 = !{!976}
!976 = !DISubrange(count: 72)
!977 = !DIGlobalVariableExpression(var: !978, expr: !DIExpression())
!978 = distinct !DIGlobalVariable(scope: null, file: !3, line: 192, type: !780, isLocal: true, isDefinition: true)
!979 = !DIGlobalVariableExpression(var: !980, expr: !DIExpression())
!980 = distinct !DIGlobalVariable(scope: null, file: !3, line: 325, type: !919, isLocal: true, isDefinition: true)
!981 = !DIGlobalVariableExpression(var: !982, expr: !DIExpression())
!982 = distinct !DIGlobalVariable(scope: null, file: !3, line: 325, type: !826, isLocal: true, isDefinition: true)
!983 = !DIGlobalVariableExpression(var: !984, expr: !DIExpression())
!984 = distinct !DIGlobalVariable(scope: null, file: !3, line: 325, type: !985, isLocal: true, isDefinition: true)
!985 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 104, elements: !986)
!986 = !{!987}
!987 = !DISubrange(count: 13)
!988 = !DIGlobalVariableExpression(var: !989, expr: !DIExpression())
!989 = distinct !DIGlobalVariable(scope: null, file: !3, line: 325, type: !990, isLocal: true, isDefinition: true)
!990 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 72, elements: !991)
!991 = !{!992}
!992 = !DISubrange(count: 9)
!993 = !DIGlobalVariableExpression(var: !994, expr: !DIExpression())
!994 = distinct !DIGlobalVariable(scope: null, file: !3, line: 330, type: !995, isLocal: true, isDefinition: true)
!995 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 672, elements: !996)
!996 = !{!997}
!997 = !DISubrange(count: 84)
!998 = !DIGlobalVariableExpression(var: !999, expr: !DIExpression())
!999 = distinct !DIGlobalVariable(scope: null, file: !3, line: 270, type: !826, isLocal: true, isDefinition: true)
!1000 = !DIGlobalVariableExpression(var: !1001, expr: !DIExpression())
!1001 = distinct !DIGlobalVariable(scope: null, file: !3, line: 270, type: !911, isLocal: true, isDefinition: true)
!1002 = !DIGlobalVariableExpression(var: !1003, expr: !DIExpression())
!1003 = distinct !DIGlobalVariable(scope: null, file: !3, line: 279, type: !1004, isLocal: true, isDefinition: true)
!1004 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 504, elements: !1005)
!1005 = !{!1006}
!1006 = !DISubrange(count: 63)
!1007 = !DIGlobalVariableExpression(var: !1008, expr: !DIExpression())
!1008 = distinct !DIGlobalVariable(scope: null, file: !3, line: 293, type: !1009, isLocal: true, isDefinition: true)
!1009 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 680, elements: !1010)
!1010 = !{!1011}
!1011 = !DISubrange(count: 85)
!1012 = !DIGlobalVariableExpression(var: !1013, expr: !DIExpression())
!1013 = distinct !DIGlobalVariable(name: "logger_count", scope: !2, file: !3, line: 32, type: !7, isLocal: true, isDefinition: true)
!1014 = !{i32 7, !"Dwarf Version", i32 5}
!1015 = !{i32 2, !"Debug Info Version", i32 3}
!1016 = !{i32 1, !"wchar_size", i32 4}
!1017 = !{i32 8, !"PIC Level", i32 2}
!1018 = !{i32 7, !"PIE Level", i32 2}
!1019 = !{i32 7, !"uwtable", i32 2}
!1020 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!1021 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!1022 = distinct !DISubprogram(name: "logger_get_gid", scope: !3, file: !3, line: 548, type: !1023, scopeLine: 548, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1023 = !DISubroutineType(types: !1024)
!1024 = !{!119}
!1025 = !DILocation(line: 550, column: 12, scope: !1022)
!1026 = !DILocation(line: 550, column: 5, scope: !1022)
!1027 = distinct !DISubprogram(name: "logger_set_gid", scope: !3, file: !3, line: 561, type: !1028, scopeLine: 561, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1030)
!1028 = !DISubroutineType(types: !1029)
!1029 = !{null, !119}
!1030 = !{!1031}
!1031 = !DILocalVariable(name: "gid", arg: 1, scope: !1027, file: !3, line: 561, type: !119)
!1032 = !DILocation(line: 0, scope: !1027)
!1033 = !DILocation(line: 563, column: 5, scope: !1027)
!1034 = !DILocation(line: 571, column: 1, scope: !1027)
!1035 = distinct !DISubprogram(name: "logger_init", scope: !3, file: !3, line: 962, type: !1036, scopeLine: 962, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1036 = !DISubroutineType(types: !1037)
!1037 = !{null}
!1038 = !DILocation(line: 967, column: 23, scope: !1035)
!1039 = !{!1040, !1040, i64 0}
!1040 = !{!"any pointer", !1041, i64 0}
!1041 = !{!"omnipotent char", !1042, i64 0}
!1042 = !{!"Simple C/C++ TBAA"}
!1043 = !DILocation(line: 968, column: 23, scope: !1035)
!1044 = !DILocation(line: 969, column: 5, scope: !1035)
!1045 = !DILocation(line: 936, column: 26, scope: !1046, inlinedAt: !1051)
!1046 = distinct !DISubprogram(name: "start_logger_thread", scope: !3, file: !3, line: 934, type: !1047, scopeLine: 934, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1049)
!1047 = !DISubroutineType(types: !1048)
!1048 = !{!132}
!1049 = !{!1050}
!1050 = !DILocalVariable(name: "ret", scope: !1046, file: !3, line: 935, type: !132)
!1051 = distinct !DILocation(line: 971, column: 9, scope: !1052)
!1052 = distinct !DILexicalBlock(scope: !1035, file: !3, line: 971, column: 9)
!1053 = !{!1054, !1054, i64 0}
!1054 = !{!"int", !1041, i64 0}
!1055 = !DILocation(line: 937, column: 16, scope: !1056, inlinedAt: !1051)
!1056 = distinct !DILexicalBlock(scope: !1046, file: !3, line: 937, column: 9)
!1057 = !DILocation(line: 0, scope: !1046, inlinedAt: !1051)
!1058 = !DILocation(line: 938, column: 53, scope: !1056, inlinedAt: !1051)
!1059 = !DILocation(line: 937, column: 9, scope: !1046, inlinedAt: !1051)
!1060 = !DILocation(line: 939, column: 17, scope: !1061, inlinedAt: !1051)
!1061 = distinct !DILexicalBlock(scope: !1056, file: !3, line: 938, column: 59)
!1062 = !DILocation(line: 939, column: 60, scope: !1061, inlinedAt: !1051)
!1063 = !DILocation(line: 939, column: 9, scope: !1061, inlinedAt: !1051)
!1064 = !DILocation(line: 972, column: 9, scope: !1065)
!1065 = distinct !DILexicalBlock(scope: !1052, file: !3, line: 971, column: 37)
!1066 = !DILocation(line: 942, column: 20, scope: !1046, inlinedAt: !1051)
!1067 = !{!1068, !1068, i64 0}
!1068 = !{!"long", !1041, i64 0}
!1069 = !DILocation(line: 942, column: 5, scope: !1046, inlinedAt: !1051)
!1070 = !DILocation(line: 978, column: 5, scope: !1035)
!1071 = !DISubprogram(name: "pthread_key_create", scope: !1072, file: !1072, line: 1297, type: !1073, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1072 = !DIFile(filename: "/usr/include/pthread.h", directory: "", checksumkind: CSK_MD5, checksum: "cbcd748b3d3ecaa7356dc2925b45d819")
!1073 = !DISubroutineType(types: !1074)
!1074 = !{!132, !1075, !1076}
!1075 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !785, size: 64)
!1076 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1077, size: 64)
!1077 = !DISubroutineType(types: !1078)
!1078 = !{null, !102}
!1079 = !DISubprogram(name: "abort", scope: !1080, file: !1080, line: 730, type: !1036, flags: DIFlagPrototyped | DIFlagNoReturn, spFlags: DISPFlagOptimized)
!1080 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!1081 = distinct !DISubprogram(name: "logger_stop", scope: !3, file: !3, line: 981, type: !1036, scopeLine: 981, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1082 = !DILocation(line: 949, column: 5, scope: !1083, inlinedAt: !1084)
!1083 = distinct !DISubprogram(name: "stop_logger_thread", scope: !3, file: !3, line: 946, type: !1047, scopeLine: 946, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1084 = distinct !DILocation(line: 982, column: 5, scope: !1081)
!1085 = !DILocation(line: 950, column: 26, scope: !1083, inlinedAt: !1084)
!1086 = !DILocation(line: 951, column: 5, scope: !1083, inlinedAt: !1084)
!1087 = !DILocation(line: 952, column: 5, scope: !1083, inlinedAt: !1084)
!1088 = !DILocation(line: 953, column: 18, scope: !1083, inlinedAt: !1084)
!1089 = !DILocation(line: 953, column: 5, scope: !1083, inlinedAt: !1084)
!1090 = !DILocation(line: 983, column: 1, scope: !1081)
!1091 = distinct !DISubprogram(name: "logger_create", scope: !3, file: !3, line: 988, type: !1092, scopeLine: 988, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1094)
!1092 = !DISubroutineType(types: !1093)
!1093 = !{!446}
!1094 = !{!1095}
!1095 = !DILocalVariable(name: "l", scope: !1091, file: !3, line: 990, type: !446)
!1096 = !DILocation(line: 990, column: 17, scope: !1091)
!1097 = !DILocation(line: 0, scope: !1091)
!1098 = !DILocation(line: 991, column: 11, scope: !1099)
!1099 = distinct !DILexicalBlock(scope: !1091, file: !3, line: 991, column: 9)
!1100 = !DILocation(line: 991, column: 9, scope: !1091)
!1101 = !DILocation(line: 995, column: 34, scope: !1091)
!1102 = !{!1103, !1054, i64 236}
!1103 = !{!"settings", !1068, i64 0, !1054, i64 8, !1054, i64 12, !1054, i64 16, !1040, i64 24, !1054, i64 32, !1054, i64 36, !1054, i64 40, !1040, i64 48, !1040, i64 56, !1054, i64 64, !1104, i64 72, !1054, i64 80, !1054, i64 84, !1054, i64 88, !1041, i64 92, !1054, i64 96, !1054, i64 100, !1105, i64 104, !1054, i64 108, !1054, i64 112, !1054, i64 116, !1054, i64 120, !1054, i64 124, !1054, i64 128, !1105, i64 132, !1105, i64 133, !1105, i64 134, !1105, i64 135, !1105, i64 136, !1105, i64 137, !1054, i64 140, !1104, i64 144, !1054, i64 152, !1054, i64 156, !1105, i64 160, !1054, i64 164, !1105, i64 168, !1105, i64 169, !1040, i64 176, !1054, i64 184, !1054, i64 188, !1054, i64 192, !1054, i64 196, !1104, i64 200, !1104, i64 208, !1054, i64 216, !1105, i64 220, !1054, i64 224, !1054, i64 228, !1054, i64 232, !1054, i64 236, !1054, i64 240, !1105, i64 244, !1105, i64 245, !1105, i64 246, !1054, i64 248, !1054, i64 252, !1054, i64 256, !1054, i64 260, !1054, i64 264, !1054, i64 268, !1054, i64 272, !1054, i64 276, !1054, i64 280, !1054, i64 284, !1104, i64 288, !1104, i64 296, !1105, i64 304, !1054, i64 308, !1054, i64 312, !1040, i64 320, !1054, i64 328}
!1104 = !{!"double", !1041, i64 0}
!1105 = !{!"_Bool", !1041, i64 0}
!1106 = !DILocation(line: 995, column: 14, scope: !1091)
!1107 = !DILocation(line: 995, column: 8, scope: !1091)
!1108 = !DILocation(line: 995, column: 12, scope: !1091)
!1109 = !{!1110, !1040, i64 88}
!1110 = !{!"_logger", !1040, i64 0, !1040, i64 8, !1041, i64 16, !1068, i64 56, !1068, i64 64, !1068, i64 72, !1111, i64 80, !1111, i64 82, !1111, i64 84, !1040, i64 88, !1040, i64 96}
!1111 = !{!"short", !1041, i64 0}
!1112 = !DILocation(line: 996, column: 16, scope: !1113)
!1113 = distinct !DILexicalBlock(scope: !1091, file: !3, line: 996, column: 9)
!1114 = !DILocation(line: 996, column: 9, scope: !1091)
!1115 = !DILocation(line: 997, column: 9, scope: !1116)
!1116 = distinct !DILexicalBlock(scope: !1113, file: !3, line: 996, column: 25)
!1117 = !DILocation(line: 998, column: 9, scope: !1116)
!1118 = !DILocation(line: 1001, column: 8, scope: !1091)
!1119 = !DILocation(line: 1001, column: 18, scope: !1091)
!1120 = !{!1110, !1040, i64 96}
!1121 = !DILocation(line: 1003, column: 28, scope: !1091)
!1122 = !DILocation(line: 1003, column: 5, scope: !1091)
!1123 = !DILocation(line: 1004, column: 25, scope: !1091)
!1124 = !DILocation(line: 1004, column: 5, scope: !1091)
!1125 = !DILocalVariable(name: "l", arg: 1, scope: !1126, file: !3, line: 577, type: !446)
!1126 = distinct !DISubprogram(name: "logger_link_q", scope: !3, file: !3, line: 577, type: !1127, scopeLine: 577, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1129)
!1127 = !DISubroutineType(types: !1128)
!1128 = !{null, !446}
!1129 = !{!1125}
!1130 = !DILocation(line: 0, scope: !1126, inlinedAt: !1131)
!1131 = distinct !DILocation(line: 1007, column: 5, scope: !1091)
!1132 = !DILocation(line: 578, column: 5, scope: !1126, inlinedAt: !1131)
!1133 = !DILocation(line: 581, column: 13, scope: !1126, inlinedAt: !1131)
!1134 = !{!1110, !1040, i64 0}
!1135 = !DILocation(line: 582, column: 15, scope: !1126, inlinedAt: !1131)
!1136 = !DILocation(line: 582, column: 8, scope: !1126, inlinedAt: !1131)
!1137 = !DILocation(line: 582, column: 13, scope: !1126, inlinedAt: !1131)
!1138 = !{!1110, !1040, i64 8}
!1139 = !DILocation(line: 583, column: 9, scope: !1140, inlinedAt: !1131)
!1140 = distinct !DILexicalBlock(scope: !1126, file: !3, line: 583, column: 9)
!1141 = !DILocation(line: 583, column: 9, scope: !1126, inlinedAt: !1131)
!1142 = !DILocation(line: 583, column: 32, scope: !1140, inlinedAt: !1131)
!1143 = !DILocation(line: 583, column: 18, scope: !1140, inlinedAt: !1131)
!1144 = !DILocation(line: 584, column: 23, scope: !1126, inlinedAt: !1131)
!1145 = !DILocation(line: 585, column: 9, scope: !1146, inlinedAt: !1131)
!1146 = distinct !DILexicalBlock(scope: !1126, file: !3, line: 585, column: 9)
!1147 = !DILocation(line: 585, column: 27, scope: !1146, inlinedAt: !1131)
!1148 = !DILocation(line: 585, column: 9, scope: !1126, inlinedAt: !1131)
!1149 = !DILocation(line: 585, column: 51, scope: !1146, inlinedAt: !1131)
!1150 = !DILocation(line: 585, column: 33, scope: !1146, inlinedAt: !1131)
!1151 = !DILocation(line: 586, column: 17, scope: !1126, inlinedAt: !1131)
!1152 = !DILocation(line: 587, column: 5, scope: !1126, inlinedAt: !1131)
!1153 = !DILocation(line: 1008, column: 5, scope: !1091)
!1154 = !DILocation(line: 1009, column: 1, scope: !1091)
!1155 = !DISubprogram(name: "calloc", scope: !1080, file: !1080, line: 675, type: !1156, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1156 = !DISubroutineType(types: !1157)
!1157 = !{!102, !436, !436}
!1158 = !DISubprogram(name: "bipbuf_new", scope: !463, file: !463, line: 26, type: !1159, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1159 = !DISubroutineType(types: !1160)
!1160 = !{!461, !1161}
!1161 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !7)
!1162 = !DISubprogram(name: "free", scope: !1080, file: !1080, line: 687, type: !1077, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1163 = !DISubprogram(name: "pthread_mutex_init", scope: !1072, file: !1072, line: 781, type: !1164, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1164 = !DISubroutineType(types: !1165)
!1165 = !{!132, !1166, !1167}
!1166 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !275, size: 64)
!1167 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1168, size: 64)
!1168 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !1169)
!1169 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutexattr_t", file: !266, line: 36, baseType: !1170)
!1170 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !266, line: 32, size: 32, elements: !1171)
!1171 = !{!1172, !1173}
!1172 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !1170, file: !266, line: 34, baseType: !908, size: 32)
!1173 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !1170, file: !266, line: 35, baseType: !132, size: 32)
!1174 = !DISubprogram(name: "pthread_setspecific", scope: !1072, file: !1072, line: 1308, type: !1175, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1175 = !DISubroutineType(types: !1176)
!1176 = !{!132, !785, !486}
!1177 = distinct !DISubprogram(name: "logger_log", scope: !3, file: !3, line: 1015, type: !1178, scopeLine: 1015, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1181)
!1178 = !DISubroutineType(types: !1179)
!1179 = !{!25, !446, !1180, !486, null}
!1180 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !5)
!1181 = !{!1182, !1183, !1184, !1185, !1186, !1187, !1194, !1195, !1196}
!1182 = !DILocalVariable(name: "l", arg: 1, scope: !1177, file: !3, line: 1015, type: !446)
!1183 = !DILocalVariable(name: "event", arg: 2, scope: !1177, file: !3, line: 1015, type: !1180)
!1184 = !DILocalVariable(name: "entry", arg: 3, scope: !1177, file: !3, line: 1015, type: !486)
!1185 = !DILocalVariable(name: "buf", scope: !1177, file: !3, line: 1016, type: !461)
!1186 = !DILocalVariable(name: "nospace", scope: !1177, file: !3, line: 1017, type: !154)
!1187 = !DILocalVariable(name: "ap", scope: !1177, file: !3, line: 1018, type: !1188)
!1188 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !1189, line: 12, baseType: !1190)
!1189 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stdarg_va_list.h", directory: "", checksumkind: CSK_MD5, checksum: "7bd78a282b99fcfe41a9e3c566d14f7d")
!1190 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !3, baseType: !1191)
!1191 = !DICompositeType(tag: DW_TAG_array_type, baseType: !489, size: 192, elements: !1192)
!1192 = !{!1193}
!1193 = !DISubrange(count: 1)
!1194 = !DILocalVariable(name: "e", scope: !1177, file: !3, line: 1019, type: !103)
!1195 = !DILocalVariable(name: "d", scope: !1177, file: !3, line: 1021, type: !474)
!1196 = !DILocalVariable(name: "reqlen", scope: !1177, file: !3, line: 1022, type: !132)
!1197 = distinct !DIAssignID()
!1198 = !DILocation(line: 0, scope: !1177)
!1199 = !DILocation(line: 1016, column: 24, scope: !1177)
!1200 = !DILocation(line: 1018, column: 5, scope: !1177)
!1201 = !DILocation(line: 1021, column: 34, scope: !1177)
!1202 = !DILocation(line: 1021, column: 31, scope: !1177)
!1203 = !DILocation(line: 1022, column: 21, scope: !1177)
!1204 = !{!1205, !1054, i64 0}
!1205 = !{!"_entry_details", !1054, i64 0, !1111, i64 4, !1040, i64 8, !1040, i64 16, !1040, i64 24}
!1206 = !DILocation(line: 1024, column: 28, scope: !1177)
!1207 = !DILocation(line: 1024, column: 5, scope: !1177)
!1208 = !DILocation(line: 1026, column: 60, scope: !1177)
!1209 = !DILocation(line: 1026, column: 22, scope: !1177)
!1210 = !DILocation(line: 1027, column: 11, scope: !1211)
!1211 = distinct !DILexicalBlock(scope: !1177, file: !3, line: 1027, column: 9)
!1212 = !DILocation(line: 1027, column: 9, scope: !1177)
!1213 = !DILocation(line: 1028, column: 12, scope: !1214)
!1214 = distinct !DILexicalBlock(scope: !1211, file: !3, line: 1027, column: 20)
!1215 = !DILocation(line: 1028, column: 19, scope: !1214)
!1216 = !{!1110, !1068, i64 64}
!1217 = !DILocation(line: 1029, column: 9, scope: !1214)
!1218 = !DILocation(line: 1030, column: 9, scope: !1214)
!1219 = !DILocation(line: 1032, column: 14, scope: !1177)
!1220 = !DILocation(line: 1033, column: 8, scope: !1177)
!1221 = !DILocation(line: 1033, column: 12, scope: !1177)
!1222 = !{!1041, !1041, i64 0}
!1223 = !DILocation(line: 550, column: 12, scope: !1022, inlinedAt: !1224)
!1224 = distinct !DILocation(line: 1034, column: 14, scope: !1177)
!1225 = !DILocation(line: 1034, column: 8, scope: !1177)
!1226 = !DILocation(line: 1034, column: 12, scope: !1177)
!1227 = !DILocation(line: 1038, column: 20, scope: !1177)
!1228 = !{!1205, !1111, i64 4}
!1229 = !DILocation(line: 1038, column: 8, scope: !1177)
!1230 = !DILocation(line: 1038, column: 15, scope: !1177)
!1231 = !{!1111, !1111, i64 0}
!1232 = !DILocation(line: 1042, column: 22, scope: !1177)
!1233 = !DILocation(line: 1042, column: 5, scope: !1177)
!1234 = !DILocation(line: 1044, column: 5, scope: !1177)
!1235 = !DILocation(line: 1045, column: 8, scope: !1177)
!1236 = !{!1205, !1040, i64 8}
!1237 = !DILocation(line: 1045, column: 5, scope: !1177)
!1238 = !DILocation(line: 1046, column: 5, scope: !1177)
!1239 = !DILocation(line: 1056, column: 49, scope: !1240)
!1240 = distinct !DILexicalBlock(scope: !1177, file: !3, line: 1056, column: 9)
!1241 = !DILocation(line: 1056, column: 44, scope: !1240)
!1242 = !DILocation(line: 1056, column: 59, scope: !1240)
!1243 = !DILocation(line: 1056, column: 56, scope: !1240)
!1244 = !DILocation(line: 1056, column: 54, scope: !1240)
!1245 = !DILocation(line: 1056, column: 9, scope: !1240)
!1246 = !DILocation(line: 1056, column: 65, scope: !1240)
!1247 = !DILocation(line: 1056, column: 9, scope: !1177)
!1248 = !DILocation(line: 1057, column: 17, scope: !1249)
!1249 = distinct !DILexicalBlock(scope: !1240, file: !3, line: 1056, column: 71)
!1250 = !DILocation(line: 1057, column: 9, scope: !1249)
!1251 = !DILocation(line: 1058, column: 9, scope: !1249)
!1252 = !DILocation(line: 1059, column: 9, scope: !1249)
!1253 = !DILocation(line: 1061, column: 8, scope: !1177)
!1254 = !DILocation(line: 1061, column: 15, scope: !1177)
!1255 = !{!1110, !1068, i64 56}
!1256 = !DILocation(line: 1065, column: 5, scope: !1177)
!1257 = !DILocation(line: 1070, column: 9, scope: !1258)
!1258 = distinct !DILexicalBlock(scope: !1259, file: !3, line: 1069, column: 12)
!1259 = distinct !DILexicalBlock(scope: !1177, file: !3, line: 1067, column: 9)
!1260 = !DILocation(line: 1072, column: 1, scope: !1177)
!1261 = !DISubprogram(name: "pthread_mutex_lock", scope: !1072, file: !1072, line: 794, type: !1262, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1262 = !DISubroutineType(types: !1263)
!1263 = !{!132, !1166}
!1264 = !DISubprogram(name: "bipbuf_request", scope: !463, file: !463, line: 41, type: !1265, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1265 = !DISubroutineType(types: !1266)
!1266 = !{!141, !461, !1267}
!1267 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !132)
!1268 = !DISubprogram(name: "pthread_mutex_unlock", scope: !1072, file: !1072, line: 835, type: !1262, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1269 = !DISubprogram(name: "gettimeofday", scope: !1270, file: !1270, line: 67, type: !1271, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1270 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/time.h", directory: "", checksumkind: CSK_MD5, checksum: "56372c3f0df8d1bebc689293534b3d5f")
!1271 = !DISubroutineType(types: !1272)
!1272 = !{!132, !1273, !1275}
!1273 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1274)
!1274 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !123, size: 64)
!1275 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !102)
!1276 = !DISubprogram(name: "bipbuf_push", scope: !463, file: !463, line: 42, type: !1277, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1277 = !DISubroutineType(types: !1278)
!1278 = !{!132, !461, !1267}
!1279 = !DISubprogram(name: "fprintf", scope: !1280, file: !1280, line: 357, type: !1281, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1280 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "1e435c46987a169d9f9186f63a512303")
!1281 = !DISubroutineType(types: !1282)
!1282 = !{!132, !1283, !1333, null}
!1283 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1284)
!1284 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1285, size: 64)
!1285 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !1286, line: 7, baseType: !1287)
!1286 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!1287 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !1288, line: 49, size: 1728, elements: !1289)
!1288 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "7a6d4a00a37ee6b9a40cd04bd01f5d00")
!1289 = !{!1290, !1291, !1292, !1293, !1294, !1295, !1296, !1297, !1298, !1299, !1300, !1301, !1302, !1305, !1307, !1308, !1309, !1311, !1312, !1314, !1316, !1319, !1321, !1324, !1327, !1328, !1329, !1330, !1331}
!1290 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !1287, file: !1288, line: 51, baseType: !132, size: 32)
!1291 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !1287, file: !1288, line: 54, baseType: !142, size: 64, offset: 64)
!1292 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !1287, file: !1288, line: 55, baseType: !142, size: 64, offset: 128)
!1293 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !1287, file: !1288, line: 56, baseType: !142, size: 64, offset: 192)
!1294 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !1287, file: !1288, line: 57, baseType: !142, size: 64, offset: 256)
!1295 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !1287, file: !1288, line: 58, baseType: !142, size: 64, offset: 320)
!1296 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !1287, file: !1288, line: 59, baseType: !142, size: 64, offset: 384)
!1297 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !1287, file: !1288, line: 60, baseType: !142, size: 64, offset: 448)
!1298 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !1287, file: !1288, line: 61, baseType: !142, size: 64, offset: 512)
!1299 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !1287, file: !1288, line: 64, baseType: !142, size: 64, offset: 576)
!1300 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !1287, file: !1288, line: 65, baseType: !142, size: 64, offset: 640)
!1301 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !1287, file: !1288, line: 66, baseType: !142, size: 64, offset: 704)
!1302 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !1287, file: !1288, line: 68, baseType: !1303, size: 64, offset: 768)
!1303 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1304, size: 64)
!1304 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !1288, line: 36, flags: DIFlagFwdDecl)
!1305 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !1287, file: !1288, line: 70, baseType: !1306, size: 64, offset: 832)
!1306 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1287, size: 64)
!1307 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !1287, file: !1288, line: 72, baseType: !132, size: 32, offset: 896)
!1308 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !1287, file: !1288, line: 73, baseType: !132, size: 32, offset: 928)
!1309 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !1287, file: !1288, line: 74, baseType: !1310, size: 64, offset: 960)
!1310 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !112, line: 152, baseType: !128)
!1311 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !1287, file: !1288, line: 77, baseType: !117, size: 16, offset: 1024)
!1312 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !1287, file: !1288, line: 78, baseType: !1313, size: 8, offset: 1040)
!1313 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!1314 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !1287, file: !1288, line: 79, baseType: !1315, size: 8, offset: 1048)
!1315 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 8, elements: !1192)
!1316 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !1287, file: !1288, line: 81, baseType: !1317, size: 64, offset: 1088)
!1317 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1318, size: 64)
!1318 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !1288, line: 43, baseType: null)
!1319 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !1287, file: !1288, line: 89, baseType: !1320, size: 64, offset: 1152)
!1320 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !112, line: 153, baseType: !128)
!1321 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !1287, file: !1288, line: 91, baseType: !1322, size: 64, offset: 1216)
!1322 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1323, size: 64)
!1323 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !1288, line: 37, flags: DIFlagFwdDecl)
!1324 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !1287, file: !1288, line: 92, baseType: !1325, size: 64, offset: 1280)
!1325 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1326, size: 64)
!1326 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !1288, line: 38, flags: DIFlagFwdDecl)
!1327 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !1287, file: !1288, line: 93, baseType: !1306, size: 64, offset: 1344)
!1328 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !1287, file: !1288, line: 94, baseType: !102, size: 64, offset: 1408)
!1329 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !1287, file: !1288, line: 95, baseType: !436, size: 64, offset: 1472)
!1330 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !1287, file: !1288, line: 96, baseType: !132, size: 32, offset: 1536)
!1331 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !1287, file: !1288, line: 98, baseType: !1332, size: 160, offset: 1568)
!1332 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 160, elements: !802)
!1333 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1334)
!1334 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1335, size: 64)
!1335 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !138)
!1336 = distinct !DISubprogram(name: "logger_add_watcher", scope: !3, file: !3, line: 1078, type: !1337, scopeLine: 1078, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1339)
!1337 = !DISubroutineType(types: !1338)
!1338 = !{!30, !102, !1267, !115}
!1339 = !{!1340, !1341, !1342, !1343, !1344}
!1340 = !DILocalVariable(name: "c", arg: 1, scope: !1336, file: !3, line: 1078, type: !102)
!1341 = !DILocalVariable(name: "sfd", arg: 2, scope: !1336, file: !3, line: 1078, type: !1267)
!1342 = !DILocalVariable(name: "f", arg: 3, scope: !1336, file: !3, line: 1078, type: !115)
!1343 = !DILocalVariable(name: "x", scope: !1336, file: !3, line: 1079, type: !132)
!1344 = !DILocalVariable(name: "w", scope: !1336, file: !3, line: 1080, type: !789)
!1345 = !DILocation(line: 0, scope: !1336)
!1346 = !DILocation(line: 1081, column: 5, scope: !1336)
!1347 = !DILocation(line: 1082, column: 9, scope: !1348)
!1348 = distinct !DILexicalBlock(scope: !1336, file: !3, line: 1082, column: 9)
!1349 = !DILocation(line: 1082, column: 23, scope: !1348)
!1350 = !DILocation(line: 1082, column: 9, scope: !1336)
!1351 = !DILocation(line: 1088, column: 13, scope: !1352)
!1352 = distinct !DILexicalBlock(scope: !1353, file: !3, line: 1088, column: 13)
!1353 = distinct !DILexicalBlock(scope: !1354, file: !3, line: 1087, column: 43)
!1354 = distinct !DILexicalBlock(scope: !1355, file: !3, line: 1087, column: 5)
!1355 = distinct !DILexicalBlock(scope: !1336, file: !3, line: 1087, column: 5)
!1356 = !DILocation(line: 1088, column: 25, scope: !1352)
!1357 = !DILocation(line: 1088, column: 13, scope: !1353)
!1358 = !DILocation(line: 1087, scope: !1355)
!1359 = !DILocation(line: 1092, column: 9, scope: !1336)
!1360 = !DILocation(line: 1093, column: 11, scope: !1361)
!1361 = distinct !DILexicalBlock(scope: !1336, file: !3, line: 1093, column: 9)
!1362 = !DILocation(line: 1093, column: 9, scope: !1336)
!1363 = !DILocation(line: 1097, column: 10, scope: !1336)
!1364 = !{!1365, !1040, i64 0}
!1365 = !{!"", !1040, i64 0, !1054, i64 8, !1054, i64 12, !1068, i64 16, !1068, i64 24, !1105, i64 32, !1054, i64 36, !1111, i64 40, !1040, i64 48}
!1366 = !DILocation(line: 1098, column: 8, scope: !1336)
!1367 = !DILocation(line: 1098, column: 12, scope: !1336)
!1368 = !{!1365, !1054, i64 8}
!1369 = !DILocation(line: 1099, column: 13, scope: !1370)
!1370 = distinct !DILexicalBlock(scope: !1336, file: !3, line: 1099, column: 9)
!1371 = !DILocation(line: 1099, column: 18, scope: !1370)
!1372 = !DILocation(line: 0, scope: !1370)
!1373 = !DILocation(line: 1104, column: 8, scope: !1336)
!1374 = !DILocation(line: 1104, column: 11, scope: !1336)
!1375 = !{!1365, !1054, i64 12}
!1376 = !DILocation(line: 1105, column: 8, scope: !1336)
!1377 = !DILocation(line: 1105, column: 15, scope: !1336)
!1378 = !{!1365, !1111, i64 40}
!1379 = !DILocation(line: 550, column: 12, scope: !1022, inlinedAt: !1380)
!1380 = distinct !DILocation(line: 1106, column: 18, scope: !1336)
!1381 = !DILocation(line: 1106, column: 8, scope: !1336)
!1382 = !DILocation(line: 1106, column: 16, scope: !1336)
!1383 = !{!1365, !1068, i64 24}
!1384 = !DILocation(line: 1107, column: 34, scope: !1336)
!1385 = !{!1103, !1054, i64 232}
!1386 = !DILocation(line: 1107, column: 14, scope: !1336)
!1387 = !DILocation(line: 1107, column: 8, scope: !1336)
!1388 = !DILocation(line: 1107, column: 12, scope: !1336)
!1389 = !{!1365, !1040, i64 48}
!1390 = !DILocation(line: 1108, column: 16, scope: !1391)
!1391 = distinct !DILexicalBlock(scope: !1336, file: !3, line: 1108, column: 9)
!1392 = !DILocation(line: 1108, column: 9, scope: !1336)
!1393 = !DILocation(line: 1109, column: 9, scope: !1394)
!1394 = distinct !DILexicalBlock(scope: !1391, file: !3, line: 1108, column: 25)
!1395 = !DILocation(line: 1111, column: 9, scope: !1394)
!1396 = !DILocation(line: 1113, column: 5, scope: !1336)
!1397 = !DILocation(line: 1115, column: 5, scope: !1336)
!1398 = !DILocation(line: 1115, column: 17, scope: !1336)
!1399 = !DILocation(line: 1116, column: 18, scope: !1336)
!1400 = !DILocalVariable(name: "l", scope: !1401, file: !3, line: 616, type: !446)
!1401 = distinct !DISubprogram(name: "logger_set_flags", scope: !3, file: !3, line: 615, type: !1036, scopeLine: 615, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1402)
!1402 = !{!1400, !1403, !1404, !1405}
!1403 = !DILocalVariable(name: "x", scope: !1401, file: !3, line: 617, type: !132)
!1404 = !DILocalVariable(name: "f", scope: !1401, file: !3, line: 618, type: !115)
!1405 = !DILocalVariable(name: "w", scope: !1406, file: !3, line: 621, type: !789)
!1406 = distinct !DILexicalBlock(scope: !1407, file: !3, line: 620, column: 41)
!1407 = distinct !DILexicalBlock(scope: !1408, file: !3, line: 620, column: 5)
!1408 = distinct !DILexicalBlock(scope: !1401, file: !3, line: 620, column: 5)
!1409 = !DILocation(line: 0, scope: !1401, inlinedAt: !1410)
!1410 = distinct !DILocation(line: 1118, column: 5, scope: !1336)
!1411 = !DILocation(line: 620, column: 5, scope: !1408, inlinedAt: !1410)
!1412 = !DILocation(line: 627, scope: !1413, inlinedAt: !1410)
!1413 = distinct !DILexicalBlock(scope: !1401, file: !3, line: 627, column: 5)
!1414 = !DILocation(line: 627, column: 35, scope: !1415, inlinedAt: !1410)
!1415 = distinct !DILexicalBlock(scope: !1413, file: !3, line: 627, column: 5)
!1416 = !DILocation(line: 627, column: 5, scope: !1413, inlinedAt: !1410)
!1417 = !DILocation(line: 621, column: 29, scope: !1406, inlinedAt: !1410)
!1418 = !DILocation(line: 0, scope: !1406, inlinedAt: !1410)
!1419 = !DILocation(line: 622, column: 15, scope: !1420, inlinedAt: !1410)
!1420 = distinct !DILexicalBlock(scope: !1406, file: !3, line: 622, column: 13)
!1421 = !DILocation(line: 622, column: 13, scope: !1406, inlinedAt: !1410)
!1422 = !DILocation(line: 625, column: 17, scope: !1406, inlinedAt: !1410)
!1423 = !DILocation(line: 625, column: 11, scope: !1406, inlinedAt: !1410)
!1424 = !DILocation(line: 626, column: 5, scope: !1407, inlinedAt: !1410)
!1425 = !DILocation(line: 620, column: 37, scope: !1407, inlinedAt: !1410)
!1426 = !DILocation(line: 620, column: 19, scope: !1407, inlinedAt: !1410)
!1427 = distinct !{!1427, !1411, !1428, !1429}
!1428 = !DILocation(line: 626, column: 5, scope: !1408, inlinedAt: !1410)
!1429 = !{!"llvm.loop.mustprogress"}
!1430 = !DILocation(line: 628, column: 32, scope: !1431, inlinedAt: !1410)
!1431 = distinct !DILexicalBlock(scope: !1415, file: !3, line: 627, column: 55)
!1432 = !DILocation(line: 628, column: 9, scope: !1431, inlinedAt: !1410)
!1433 = !DILocation(line: 629, column: 12, scope: !1431, inlinedAt: !1410)
!1434 = !DILocation(line: 629, column: 19, scope: !1431, inlinedAt: !1410)
!1435 = !{!1110, !1111, i64 84}
!1436 = !DILocation(line: 630, column: 9, scope: !1431, inlinedAt: !1410)
!1437 = !DILocation(line: 627, column: 49, scope: !1415, inlinedAt: !1410)
!1438 = distinct !{!1438, !1416, !1439, !1429}
!1439 = !DILocation(line: 631, column: 5, scope: !1413, inlinedAt: !1410)
!1440 = !DILocation(line: 1119, column: 5, scope: !1336)
!1441 = !DILocation(line: 1122, column: 5, scope: !1336)
!1442 = !DILocation(line: 1123, column: 1, scope: !1336)
!1443 = !DISubprogram(name: "bipbuf_offer", scope: !463, file: !463, line: 48, type: !1444, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1444 = !DISubroutineType(types: !1445)
!1445 = !{!132, !461, !1446, !1267}
!1446 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1447, size: 64)
!1447 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !113)
!1448 = !DISubprogram(name: "pthread_cond_signal", scope: !1072, file: !1072, line: 1121, type: !1449, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1449 = !DISubroutineType(types: !1450)
!1450 = !{!132, !1451}
!1451 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !740, size: 64)
!1452 = !DISubprogram(name: "pthread_create", scope: !1072, file: !1072, line: 202, type: !1453, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1453 = !DISubroutineType(types: !1454)
!1454 = !{!132, !1455, !1457, !1468, !1275}
!1455 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1456)
!1456 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !265, size: 64)
!1457 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1458)
!1458 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1459, size: 64)
!1459 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !1460)
!1460 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_attr_t", file: !266, line: 62, baseType: !1461)
!1461 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "pthread_attr_t", file: !266, line: 56, size: 448, elements: !1462)
!1462 = !{!1463, !1467}
!1463 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !1461, file: !266, line: 58, baseType: !1464, size: 448)
!1464 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 448, elements: !1465)
!1465 = !{!1466}
!1466 = !DISubrange(count: 56)
!1467 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !1461, file: !266, line: 59, baseType: !128, size: 64)
!1468 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1469, size: 64)
!1469 = !DISubroutineType(types: !1470)
!1470 = !{!102, !102}
!1471 = distinct !DISubprogram(name: "logger_thread", scope: !3, file: !3, line: 883, type: !1469, scopeLine: 883, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1472)
!1472 = !{!1473, !1474, !1478, !1480, !1481}
!1473 = !DILocalVariable(name: "arg", arg: 1, scope: !1471, file: !3, line: 883, type: !102)
!1474 = !DILocalVariable(name: "to_sleep", scope: !1471, file: !3, line: 884, type: !1475)
!1475 = !DIDerivedType(tag: DW_TAG_typedef, name: "useconds_t", file: !1476, line: 255, baseType: !1477)
!1476 = !DIFile(filename: "/usr/include/unistd.h", directory: "", checksumkind: CSK_MD5, checksum: "877e832a8bb8424f9180387a13787475")
!1477 = !DIDerivedType(tag: DW_TAG_typedef, name: "__useconds_t", file: !112, line: 161, baseType: !7)
!1478 = !DILocalVariable(name: "found_logs", scope: !1479, file: !3, line: 889, type: !132)
!1479 = distinct !DILexicalBlock(scope: !1471, file: !3, line: 888, column: 34)
!1480 = !DILocalVariable(name: "l", scope: !1479, file: !3, line: 890, type: !446)
!1481 = !DILocalVariable(name: "ls", scope: !1479, file: !3, line: 891, type: !1482)
!1482 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "logger_stats", file: !6, line: 213, size: 320, elements: !1483)
!1483 = !{!1484, !1485, !1486, !1487, !1488}
!1484 = !DIDerivedType(tag: DW_TAG_member, name: "worker_dropped", scope: !1482, file: !6, line: 214, baseType: !119, size: 64)
!1485 = !DIDerivedType(tag: DW_TAG_member, name: "worker_written", scope: !1482, file: !6, line: 215, baseType: !119, size: 64, offset: 64)
!1486 = !DIDerivedType(tag: DW_TAG_member, name: "watcher_skipped", scope: !1482, file: !6, line: 216, baseType: !119, size: 64, offset: 128)
!1487 = !DIDerivedType(tag: DW_TAG_member, name: "watcher_sent", scope: !1482, file: !6, line: 217, baseType: !119, size: 64, offset: 192)
!1488 = !DIDerivedType(tag: DW_TAG_member, name: "watcher_count", scope: !1482, file: !6, line: 218, baseType: !119, size: 64, offset: 256)
!1489 = distinct !DIAssignID()
!1490 = !DILocalVariable(name: "size", scope: !1491, file: !3, line: 718, type: !7)
!1491 = distinct !DISubprogram(name: "logger_thread_read", scope: !3, file: !3, line: 717, type: !1492, scopeLine: 717, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1495)
!1492 = !DISubroutineType(types: !1493)
!1493 = !{!132, !446, !1494}
!1494 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1482, size: 64)
!1495 = !{!1496, !1497, !1490, !1498, !1499, !1500, !1504, !1505, !1507}
!1496 = !DILocalVariable(name: "l", arg: 1, scope: !1491, file: !3, line: 717, type: !446)
!1497 = !DILocalVariable(name: "ls", arg: 2, scope: !1491, file: !3, line: 717, type: !1494)
!1498 = !DILocalVariable(name: "pos", scope: !1491, file: !3, line: 719, type: !7)
!1499 = !DILocalVariable(name: "data", scope: !1491, file: !3, line: 720, type: !141)
!1500 = !DILocalVariable(name: "scratch", scope: !1491, file: !3, line: 721, type: !1501)
!1501 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 32768, elements: !1502)
!1502 = !{!1503}
!1503 = !DISubrange(count: 4096)
!1504 = !DILocalVariable(name: "e", scope: !1491, file: !3, line: 722, type: !103)
!1505 = !DILocalVariable(name: "ret", scope: !1506, file: !3, line: 734, type: !39)
!1506 = distinct !DILexicalBlock(scope: !1491, file: !3, line: 733, column: 45)
!1507 = !DILocalVariable(name: "scratch_len", scope: !1506, file: !3, line: 735, type: !132)
!1508 = !DILocation(line: 0, scope: !1491, inlinedAt: !1509)
!1509 = distinct !DILocation(line: 907, column: 27, scope: !1510)
!1510 = distinct !DILexicalBlock(scope: !1511, file: !3, line: 905, column: 59)
!1511 = distinct !DILexicalBlock(scope: !1512, file: !3, line: 905, column: 9)
!1512 = distinct !DILexicalBlock(scope: !1479, file: !3, line: 905, column: 9)
!1513 = distinct !DIAssignID()
!1514 = distinct !DIAssignID()
!1515 = !DILocation(line: 0, scope: !1479)
!1516 = distinct !DIAssignID()
!1517 = !DILocation(line: 0, scope: !1471)
!1518 = !DILocation(line: 888, column: 12, scope: !1471)
!1519 = !DILocation(line: 888, column: 5, scope: !1471)
!1520 = !DILocation(line: 891, column: 9, scope: !1479)
!1521 = !DILocation(line: 892, column: 9, scope: !1479)
!1522 = distinct !DIAssignID()
!1523 = distinct !DIAssignID()
!1524 = !DILocation(line: 895, column: 22, scope: !1525)
!1525 = distinct !DILexicalBlock(scope: !1479, file: !3, line: 895, column: 13)
!1526 = !DILocation(line: 895, column: 13, scope: !1479)
!1527 = !DILocation(line: 896, column: 13, scope: !1525)
!1528 = !DILocation(line: 899, column: 9, scope: !1479)
!1529 = !DILocation(line: 900, column: 13, scope: !1530)
!1530 = distinct !DILexicalBlock(scope: !1479, file: !3, line: 900, column: 13)
!1531 = !DILocation(line: 900, column: 27, scope: !1530)
!1532 = !DILocation(line: 900, column: 13, scope: !1479)
!1533 = !DILocation(line: 903, column: 13, scope: !1534)
!1534 = distinct !DILexicalBlock(scope: !1530, file: !3, line: 900, column: 33)
!1535 = !DILocation(line: 904, column: 9, scope: !1534)
!1536 = !DILocation(line: 905, scope: !1512)
!1537 = !DILocation(line: 905, column: 39, scope: !1511)
!1538 = !DILocation(line: 905, column: 9, scope: !1512)
!1539 = !DILocation(line: 718, column: 5, scope: !1491, inlinedAt: !1509)
!1540 = !DILocation(line: 721, column: 5, scope: !1491, inlinedAt: !1509)
!1541 = !DILocation(line: 723, column: 28, scope: !1491, inlinedAt: !1509)
!1542 = !DILocation(line: 723, column: 5, scope: !1491, inlinedAt: !1509)
!1543 = !DILocation(line: 724, column: 31, scope: !1491, inlinedAt: !1509)
!1544 = !DILocation(line: 724, column: 12, scope: !1491, inlinedAt: !1509)
!1545 = !DILocation(line: 725, column: 5, scope: !1491, inlinedAt: !1509)
!1546 = !DILocation(line: 727, column: 14, scope: !1547, inlinedAt: !1509)
!1547 = distinct !DILexicalBlock(scope: !1491, file: !3, line: 727, column: 9)
!1548 = !DILocation(line: 727, column: 9, scope: !1491, inlinedAt: !1509)
!1549 = !DILocation(line: 733, column: 18, scope: !1491, inlinedAt: !1509)
!1550 = !DILocation(line: 733, column: 16, scope: !1491, inlinedAt: !1509)
!1551 = !DILocation(line: 733, column: 23, scope: !1491, inlinedAt: !1509)
!1552 = !DILocation(line: 733, column: 26, scope: !1491, inlinedAt: !1509)
!1553 = !DILocation(line: 733, column: 40, scope: !1491, inlinedAt: !1509)
!1554 = !DILocation(line: 733, column: 5, scope: !1491, inlinedAt: !1509)
!1555 = !DILocation(line: 0, scope: !1506, inlinedAt: !1509)
!1556 = !DILocation(line: 736, column: 32, scope: !1506, inlinedAt: !1509)
!1557 = !DILocalVariable(name: "e", arg: 1, scope: !1558, file: !3, line: 636, type: !103)
!1558 = distinct !DISubprogram(name: "logger_thread_parse_entry", scope: !3, file: !3, line: 636, type: !1559, scopeLine: 637, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1562)
!1559 = !DISubroutineType(types: !1560)
!1560 = !{!39, !103, !1494, !142, !1561}
!1561 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !132, size: 64)
!1562 = !{!1557, !1563, !1564, !1565, !1566, !1567}
!1563 = !DILocalVariable(name: "ls", arg: 2, scope: !1558, file: !3, line: 636, type: !1494)
!1564 = !DILocalVariable(name: "scratch", arg: 3, scope: !1558, file: !3, line: 637, type: !142)
!1565 = !DILocalVariable(name: "scratch_len", arg: 4, scope: !1558, file: !3, line: 637, type: !1561)
!1566 = !DILocalVariable(name: "total", scope: !1558, file: !3, line: 638, type: !132)
!1567 = !DILocalVariable(name: "d", scope: !1558, file: !3, line: 639, type: !474)
!1568 = !DILocation(line: 0, scope: !1558, inlinedAt: !1569)
!1569 = distinct !DILocation(line: 737, column: 15, scope: !1506, inlinedAt: !1509)
!1570 = !DILocation(line: 639, column: 50, scope: !1558, inlinedAt: !1569)
!1571 = !DILocation(line: 639, column: 31, scope: !1558, inlinedAt: !1569)
!1572 = !DILocation(line: 641, column: 16, scope: !1558, inlinedAt: !1569)
!1573 = !{!1205, !1040, i64 16}
!1574 = !DILocation(line: 641, column: 13, scope: !1558, inlinedAt: !1569)
!1575 = !DILocation(line: 643, column: 39, scope: !1576, inlinedAt: !1569)
!1576 = distinct !DILexicalBlock(scope: !1558, file: !3, line: 643, column: 9)
!1577 = !DILocation(line: 740, column: 21, scope: !1578, inlinedAt: !1509)
!1578 = distinct !DILexicalBlock(scope: !1579, file: !3, line: 738, column: 43)
!1579 = distinct !DILexicalBlock(scope: !1506, file: !3, line: 738, column: 13)
!1580 = !DILocation(line: 740, column: 13, scope: !1578, inlinedAt: !1509)
!1581 = !DILocation(line: 741, column: 9, scope: !1578, inlinedAt: !1509)
!1582 = !DILocalVariable(name: "e", arg: 1, scope: !1583, file: !3, line: 654, type: !103)
!1583 = distinct !DISubprogram(name: "logger_thread_write_entry", scope: !3, file: !3, line: 654, type: !1584, scopeLine: 655, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1586)
!1584 = !DISubroutineType(types: !1585)
!1585 = !{null, !103, !1494, !142, !132}
!1586 = !{!1582, !1587, !1588, !1589, !1590, !1591, !1592, !1596}
!1587 = !DILocalVariable(name: "ls", arg: 2, scope: !1583, file: !3, line: 654, type: !1494)
!1588 = !DILocalVariable(name: "scratch", arg: 3, scope: !1583, file: !3, line: 655, type: !142)
!1589 = !DILocalVariable(name: "scratch_len", arg: 4, scope: !1583, file: !3, line: 655, type: !132)
!1590 = !DILocalVariable(name: "x", scope: !1583, file: !3, line: 656, type: !132)
!1591 = !DILocalVariable(name: "total", scope: !1583, file: !3, line: 656, type: !132)
!1592 = !DILocalVariable(name: "w", scope: !1593, file: !3, line: 659, type: !789)
!1593 = distinct !DILexicalBlock(scope: !1594, file: !3, line: 658, column: 41)
!1594 = distinct !DILexicalBlock(scope: !1595, file: !3, line: 658, column: 5)
!1595 = distinct !DILexicalBlock(scope: !1583, file: !3, line: 658, column: 5)
!1596 = !DILocalVariable(name: "skip_scr", scope: !1593, file: !3, line: 660, type: !142)
!1597 = !DILocation(line: 0, scope: !1583, inlinedAt: !1598)
!1598 = distinct !DILocation(line: 742, column: 13, scope: !1599, inlinedAt: !1509)
!1599 = distinct !DILexicalBlock(scope: !1579, file: !3, line: 741, column: 16)
!1600 = !DILocation(line: 658, column: 5, scope: !1595, inlinedAt: !1598)
!1601 = !DILocation(line: 659, column: 29, scope: !1593, inlinedAt: !1598)
!1602 = !DILocation(line: 0, scope: !1593, inlinedAt: !1598)
!1603 = !DILocation(line: 661, column: 15, scope: !1604, inlinedAt: !1598)
!1604 = distinct !DILexicalBlock(scope: !1593, file: !3, line: 661, column: 13)
!1605 = !DILocation(line: 661, column: 23, scope: !1604, inlinedAt: !1598)
!1606 = !DILocation(line: 661, column: 30, scope: !1604, inlinedAt: !1598)
!1607 = !DILocation(line: 661, column: 42, scope: !1604, inlinedAt: !1598)
!1608 = !DILocation(line: 661, column: 37, scope: !1604, inlinedAt: !1598)
!1609 = !DILocation(line: 661, column: 50, scope: !1604, inlinedAt: !1598)
!1610 = !DILocation(line: 661, column: 55, scope: !1604, inlinedAt: !1598)
!1611 = !DILocation(line: 661, column: 62, scope: !1604, inlinedAt: !1598)
!1612 = !DILocation(line: 661, column: 71, scope: !1604, inlinedAt: !1598)
!1613 = !DILocation(line: 661, column: 66, scope: !1604, inlinedAt: !1598)
!1614 = !DILocation(line: 661, column: 13, scope: !1593, inlinedAt: !1598)
!1615 = !DILocation(line: 668, column: 56, scope: !1593, inlinedAt: !1598)
!1616 = !DILocation(line: 667, column: 20, scope: !1593, inlinedAt: !1598)
!1617 = !{!1365, !1105, i64 32}
!1618 = !{i8 0, i8 2}
!1619 = !{}
!1620 = !DILocation(line: 667, column: 33, scope: !1593, inlinedAt: !1598)
!1621 = !DILocation(line: 667, column: 9, scope: !1593, inlinedAt: !1598)
!1622 = !DILocation(line: 668, column: 38, scope: !1593, inlinedAt: !1598)
!1623 = !DILocation(line: 668, column: 81, scope: !1593, inlinedAt: !1598)
!1624 = !DILocation(line: 675, column: 16, scope: !1625, inlinedAt: !1598)
!1625 = distinct !DILexicalBlock(scope: !1593, file: !3, line: 675, column: 13)
!1626 = !DILocation(line: 669, column: 17, scope: !1627, inlinedAt: !1598)
!1627 = distinct !DILexicalBlock(scope: !1628, file: !3, line: 669, column: 17)
!1628 = distinct !DILexicalBlock(scope: !1593, file: !3, line: 668, column: 90)
!1629 = !DILocation(line: 669, column: 51, scope: !1627, inlinedAt: !1598)
!1630 = !DILocation(line: 669, column: 17, scope: !1628, inlinedAt: !1598)
!1631 = !DILocation(line: 671, column: 33, scope: !1632, inlinedAt: !1598)
!1632 = distinct !DILexicalBlock(scope: !1627, file: !3, line: 669, column: 57)
!1633 = !DILocation(line: 675, column: 13, scope: !1593, inlinedAt: !1598)
!1634 = distinct !{!1634, !1621, !1635, !1429}
!1635 = !DILocation(line: 673, column: 9, scope: !1593, inlinedAt: !1598)
!1636 = !DILocation(line: 677, column: 16, scope: !1637, inlinedAt: !1598)
!1637 = distinct !DILexicalBlock(scope: !1625, file: !3, line: 675, column: 30)
!1638 = !DILocation(line: 677, column: 23, scope: !1637, inlinedAt: !1598)
!1639 = !{!1365, !1068, i64 16}
!1640 = !DILocation(line: 679, column: 13, scope: !1637, inlinedAt: !1598)
!1641 = !DILocation(line: 682, column: 16, scope: !1642, inlinedAt: !1598)
!1642 = distinct !DILexicalBlock(scope: !1593, file: !3, line: 682, column: 13)
!1643 = !DILocation(line: 682, column: 24, scope: !1642, inlinedAt: !1598)
!1644 = !DILocation(line: 682, column: 13, scope: !1593, inlinedAt: !1598)
!1645 = !DILocation(line: 683, column: 21, scope: !1646, inlinedAt: !1598)
!1646 = distinct !DILexicalBlock(scope: !1642, file: !3, line: 682, column: 29)
!1647 = !DILocation(line: 684, column: 30, scope: !1648, inlinedAt: !1598)
!1648 = distinct !DILexicalBlock(scope: !1646, file: !3, line: 684, column: 17)
!1649 = !DILocation(line: 686, column: 27, scope: !1650, inlinedAt: !1598)
!1650 = distinct !DILexicalBlock(scope: !1648, file: !3, line: 684, column: 45)
!1651 = !DILocation(line: 688, column: 17, scope: !1650, inlinedAt: !1598)
!1652 = !DILocation(line: 690, column: 28, scope: !1646, inlinedAt: !1598)
!1653 = !DILocation(line: 690, column: 13, scope: !1646, inlinedAt: !1598)
!1654 = !DILocation(line: 691, column: 24, scope: !1646, inlinedAt: !1598)
!1655 = !DILocation(line: 692, column: 9, scope: !1646, inlinedAt: !1598)
!1656 = !DILocation(line: 694, column: 25, scope: !1593, inlinedAt: !1598)
!1657 = !DILocation(line: 694, column: 9, scope: !1593, inlinedAt: !1598)
!1658 = !DILocation(line: 696, column: 5, scope: !1594, inlinedAt: !1598)
!1659 = !DILocation(line: 658, column: 37, scope: !1594, inlinedAt: !1598)
!1660 = !DILocation(line: 658, column: 19, scope: !1594, inlinedAt: !1598)
!1661 = distinct !{!1661, !1600, !1662, !1429}
!1662 = !DILocation(line: 696, column: 5, scope: !1595, inlinedAt: !1598)
!1663 = !DILocation(line: 744, column: 38, scope: !1506, inlinedAt: !1509)
!1664 = !DILocation(line: 744, column: 48, scope: !1506, inlinedAt: !1509)
!1665 = !DILocation(line: 744, column: 45, scope: !1506, inlinedAt: !1509)
!1666 = !DILocation(line: 744, column: 33, scope: !1506, inlinedAt: !1509)
!1667 = !DILocation(line: 744, column: 43, scope: !1506, inlinedAt: !1509)
!1668 = !DILocation(line: 744, column: 13, scope: !1506, inlinedAt: !1509)
!1669 = distinct !{!1669, !1554, !1670, !1429}
!1670 = !DILocation(line: 745, column: 5, scope: !1491, inlinedAt: !1509)
!1671 = !DILocation(line: 748, column: 5, scope: !1491, inlinedAt: !1509)
!1672 = !DILocation(line: 749, column: 27, scope: !1491, inlinedAt: !1509)
!1673 = !DILocation(line: 749, column: 32, scope: !1491, inlinedAt: !1509)
!1674 = !DILocation(line: 749, column: 12, scope: !1491, inlinedAt: !1509)
!1675 = !DILocation(line: 750, column: 30, scope: !1491, inlinedAt: !1509)
!1676 = !DILocation(line: 751, column: 24, scope: !1491, inlinedAt: !1509)
!1677 = !DILocation(line: 753, column: 16, scope: !1491, inlinedAt: !1509)
!1678 = !DILocation(line: 754, column: 5, scope: !1491, inlinedAt: !1509)
!1679 = !DILocation(line: 755, column: 14, scope: !1680, inlinedAt: !1509)
!1680 = distinct !DILexicalBlock(scope: !1491, file: !3, line: 755, column: 9)
!1681 = !DILocation(line: 755, column: 9, scope: !1491, inlinedAt: !1509)
!1682 = !DILocation(line: 756, column: 17, scope: !1683, inlinedAt: !1509)
!1683 = distinct !DILexicalBlock(scope: !1680, file: !3, line: 755, column: 23)
!1684 = !DILocation(line: 756, column: 9, scope: !1683, inlinedAt: !1509)
!1685 = !DILocation(line: 758, column: 5, scope: !1683, inlinedAt: !1509)
!1686 = !DILocation(line: 759, column: 12, scope: !1491, inlinedAt: !1509)
!1687 = !DILocation(line: 759, column: 5, scope: !1491, inlinedAt: !1509)
!1688 = !DILocation(line: 760, column: 1, scope: !1491, inlinedAt: !1509)
!1689 = !DILocation(line: 907, column: 24, scope: !1510)
!1690 = !DILocation(line: 905, column: 53, scope: !1511)
!1691 = distinct !{!1691, !1538, !1692, !1429}
!1692 = !DILocation(line: 908, column: 9, scope: !1512)
!1693 = !DILocation(line: 910, column: 9, scope: !1479)
!1694 = !DILocation(line: 913, column: 28, scope: !1479)
!1695 = !DILocation(line: 915, column: 9, scope: !1479)
!1696 = !DILocation(line: 918, column: 14, scope: !1697)
!1697 = distinct !DILexicalBlock(scope: !1479, file: !3, line: 918, column: 13)
!1698 = !DILocation(line: 918, column: 13, scope: !1479)
!1699 = !DILocation(line: 919, column: 26, scope: !1700)
!1700 = distinct !DILexicalBlock(scope: !1701, file: !3, line: 919, column: 17)
!1701 = distinct !DILexicalBlock(scope: !1697, file: !3, line: 918, column: 26)
!1702 = !DILocation(line: 919, column: 17, scope: !1701)
!1703 = !DILocation(line: 921, column: 17, scope: !1701)
!1704 = !DILocation(line: 923, column: 9, scope: !1701)
!1705 = !DILocation(line: 924, column: 22, scope: !1706)
!1706 = distinct !DILexicalBlock(scope: !1697, file: !3, line: 923, column: 16)
!1707 = !DILocation(line: 925, column: 17, scope: !1706)
!1708 = !DILocation(line: 0, scope: !1697)
!1709 = !DILocalVariable(name: "ls", arg: 1, scope: !1710, file: !3, line: 869, type: !1494)
!1710 = distinct !DISubprogram(name: "logger_thread_flush_stats", scope: !3, file: !3, line: 869, type: !1711, scopeLine: 869, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1713)
!1711 = !DISubroutineType(types: !1712)
!1712 = !{null, !1494}
!1713 = !{!1709}
!1714 = !DILocation(line: 0, scope: !1710, inlinedAt: !1715)
!1715 = distinct !DILocation(line: 928, column: 9, scope: !1479)
!1716 = !DILocation(line: 870, column: 5, scope: !1710, inlinedAt: !1715)
!1717 = !DILocation(line: 871, column: 31, scope: !1710, inlinedAt: !1715)
!1718 = !DILocation(line: 873, column: 38, scope: !1710, inlinedAt: !1715)
!1719 = !{!1720, !1068, i64 16}
!1720 = !{!"logger_stats", !1068, i64 0, !1068, i64 8, !1068, i64 16, !1068, i64 24, !1068, i64 32}
!1721 = !DILocation(line: 873, column: 31, scope: !1710, inlinedAt: !1715)
!1722 = !{!1723, !1068, i64 136}
!1723 = !{!"stats", !1068, i64 0, !1068, i64 8, !1068, i64 16, !1068, i64 24, !1068, i64 32, !1068, i64 40, !1068, i64 48, !1068, i64 56, !1068, i64 64, !1068, i64 72, !1068, i64 80, !1068, i64 88, !1068, i64 96, !1068, i64 104, !1068, i64 112, !1068, i64 120, !1068, i64 128, !1068, i64 136, !1068, i64 144, !1068, i64 152, !1068, i64 160, !1068, i64 168, !1068, i64 176, !1068, i64 184, !1724, i64 192, !1068, i64 208, !1068, i64 216}
!1724 = !{!"timeval", !1068, i64 0, !1068, i64 8}
!1725 = !DILocation(line: 874, column: 38, scope: !1710, inlinedAt: !1715)
!1726 = !{!1720, !1068, i64 24}
!1727 = !DILocation(line: 874, column: 31, scope: !1710, inlinedAt: !1715)
!1728 = !{!1723, !1068, i64 144}
!1729 = !DILocation(line: 875, column: 32, scope: !1710, inlinedAt: !1715)
!1730 = !{!1731, !1054, i64 44}
!1731 = !{!"stats_state", !1068, i64 0, !1068, i64 8, !1068, i64 16, !1068, i64 24, !1054, i64 32, !1054, i64 36, !1054, i64 40, !1054, i64 44, !1105, i64 48, !1105, i64 49, !1105, i64 50, !1105, i64 51}
!1732 = !DILocation(line: 876, column: 5, scope: !1710, inlinedAt: !1715)
!1733 = !DILocation(line: 929, column: 5, scope: !1471)
!1734 = distinct !{!1734, !1519, !1733, !1429}
!1735 = !DILocation(line: 931, column: 5, scope: !1471)
!1736 = !DISubprogram(name: "strerror", scope: !1737, file: !1737, line: 419, type: !1738, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1737 = !DIFile(filename: "/usr/include/string.h", directory: "", checksumkind: CSK_MD5, checksum: "165db1185644f68894fa9e0d17055d70")
!1738 = !DISubroutineType(types: !1739)
!1739 = !{!142, !132}
!1740 = !DISubprogram(name: "thread_setname", scope: !45, file: !45, line: 1033, type: !1741, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1741 = !DISubroutineType(types: !1742)
!1742 = !{null, !265, !1334}
!1743 = !DISubprogram(name: "usleep", scope: !1476, file: !1476, line: 480, type: !1744, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1744 = !DISubroutineType(types: !1745)
!1745 = !{!132, !1477}
!1746 = !DISubprogram(name: "pthread_cond_wait", scope: !1072, file: !1072, line: 1133, type: !1747, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1747 = !DISubroutineType(types: !1748)
!1748 = !{!132, !1749, !1750}
!1749 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1451)
!1750 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1166)
!1751 = distinct !DISubprogram(name: "logger_thread_poll_watchers", scope: !3, file: !3, line: 773, type: !1752, scopeLine: 773, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1754)
!1752 = !DISubroutineType(types: !1753)
!1753 = !{!132, !132, !132}
!1754 = !{!1755, !1756, !1757, !1758, !1759, !1760, !1761, !1762, !1766, !1767, !1771, !1774, !1775}
!1755 = !DILocalVariable(name: "force_poll", arg: 1, scope: !1751, file: !3, line: 773, type: !132)
!1756 = !DILocalVariable(name: "watcher", arg: 2, scope: !1751, file: !3, line: 773, type: !132)
!1757 = !DILocalVariable(name: "x", scope: !1751, file: !3, line: 774, type: !132)
!1758 = !DILocalVariable(name: "nfd", scope: !1751, file: !3, line: 775, type: !132)
!1759 = !DILocalVariable(name: "data", scope: !1751, file: !3, line: 776, type: !141)
!1760 = !DILocalVariable(name: "data_size", scope: !1751, file: !3, line: 777, type: !7)
!1761 = !DILocalVariable(name: "flushed", scope: !1751, file: !3, line: 778, type: !132)
!1762 = !DILocalVariable(name: "w", scope: !1763, file: !3, line: 781, type: !789)
!1763 = distinct !DILexicalBlock(scope: !1764, file: !3, line: 780, column: 41)
!1764 = distinct !DILexicalBlock(scope: !1765, file: !3, line: 780, column: 5)
!1765 = distinct !DILexicalBlock(scope: !1751, file: !3, line: 780, column: 5)
!1766 = !DILocalVariable(name: "ret", scope: !1751, file: !3, line: 805, type: !132)
!1767 = !DILocalVariable(name: "w", scope: !1768, file: !3, line: 814, type: !789)
!1768 = distinct !DILexicalBlock(scope: !1769, file: !3, line: 813, column: 41)
!1769 = distinct !DILexicalBlock(scope: !1770, file: !3, line: 813, column: 5)
!1770 = distinct !DILexicalBlock(scope: !1751, file: !3, line: 813, column: 5)
!1771 = !DILocalVariable(name: "buf", scope: !1772, file: !3, line: 823, type: !1315)
!1772 = distinct !DILexicalBlock(scope: !1773, file: !3, line: 822, column: 53)
!1773 = distinct !DILexicalBlock(scope: !1768, file: !3, line: 822, column: 13)
!1774 = !DILocalVariable(name: "res", scope: !1772, file: !3, line: 824, type: !132)
!1775 = !DILocalVariable(name: "total", scope: !1776, file: !3, line: 837, type: !132)
!1776 = distinct !DILexicalBlock(scope: !1777, file: !3, line: 836, column: 65)
!1777 = distinct !DILexicalBlock(scope: !1778, file: !3, line: 836, column: 24)
!1778 = distinct !DILexicalBlock(scope: !1779, file: !3, line: 833, column: 17)
!1779 = distinct !DILexicalBlock(scope: !1780, file: !3, line: 832, column: 67)
!1780 = distinct !DILexicalBlock(scope: !1768, file: !3, line: 832, column: 13)
!1781 = distinct !DIAssignID()
!1782 = !DILocation(line: 0, scope: !1751)
!1783 = distinct !DIAssignID()
!1784 = !DILocation(line: 0, scope: !1772)
!1785 = !DILocation(line: 777, column: 5, scope: !1751)
!1786 = !DILocation(line: 777, column: 18, scope: !1751)
!1787 = distinct !DIAssignID()
!1788 = !DILocation(line: 780, column: 5, scope: !1765)
!1789 = !DILocation(line: 781, column: 29, scope: !1763)
!1790 = !DILocation(line: 0, scope: !1763)
!1791 = !DILocation(line: 782, column: 15, scope: !1792)
!1792 = distinct !DILexicalBlock(scope: !1763, file: !3, line: 782, column: 13)
!1793 = !DILocation(line: 782, column: 23, scope: !1792)
!1794 = !DILocation(line: 785, column: 35, scope: !1763)
!1795 = !DILocation(line: 785, column: 16, scope: !1763)
!1796 = !DILocation(line: 786, column: 18, scope: !1797)
!1797 = distinct !DILexicalBlock(scope: !1763, file: !3, line: 786, column: 13)
!1798 = !DILocation(line: 786, column: 13, scope: !1763)
!1799 = !DILocation(line: 0, scope: !1797)
!1800 = !{!1801, !1054, i64 0}
!1801 = !{!"pollfd", !1054, i64 0, !1111, i64 4, !1111, i64 6}
!1802 = !{!1801, !1111, i64 4}
!1803 = !DILocation(line: 798, column: 12, scope: !1763)
!1804 = !DILocation(line: 798, column: 25, scope: !1763)
!1805 = !DILocation(line: 799, column: 5, scope: !1764)
!1806 = !DILocation(line: 780, column: 37, scope: !1764)
!1807 = !DILocation(line: 780, column: 19, scope: !1764)
!1808 = distinct !{!1808, !1788, !1809, !1429}
!1809 = !DILocation(line: 799, column: 5, scope: !1765)
!1810 = !DILocation(line: 801, column: 13, scope: !1811)
!1811 = distinct !DILexicalBlock(scope: !1751, file: !3, line: 801, column: 9)
!1812 = !DILocation(line: 801, column: 9, scope: !1751)
!1813 = !DILocation(line: 805, column: 38, scope: !1751)
!1814 = !DILocation(line: 805, column: 15, scope: !1751)
!1815 = !DILocation(line: 807, column: 13, scope: !1816)
!1816 = distinct !DILexicalBlock(scope: !1751, file: !3, line: 807, column: 9)
!1817 = !DILocation(line: 807, column: 9, scope: !1751)
!1818 = !DILocation(line: 808, column: 9, scope: !1819)
!1819 = distinct !DILexicalBlock(scope: !1816, file: !3, line: 807, column: 18)
!1820 = !DILocation(line: 809, column: 9, scope: !1819)
!1821 = !DILocation(line: 814, column: 29, scope: !1768)
!1822 = !DILocation(line: 0, scope: !1768)
!1823 = !DILocation(line: 815, column: 15, scope: !1824)
!1824 = distinct !DILexicalBlock(scope: !1768, file: !3, line: 815, column: 13)
!1825 = !DILocation(line: 815, column: 23, scope: !1824)
!1826 = !DILocation(line: 818, column: 19, scope: !1768)
!1827 = distinct !DIAssignID()
!1828 = !DILocation(line: 822, column: 13, scope: !1773)
!1829 = !DILocation(line: 822, column: 35, scope: !1773)
!1830 = !{!1801, !1111, i64 6}
!1831 = !DILocation(line: 822, column: 43, scope: !1773)
!1832 = !DILocation(line: 822, column: 13, scope: !1768)
!1833 = !DILocation(line: 823, column: 13, scope: !1772)
!1834 = !DILocation(line: 824, column: 34, scope: !1772)
!1835 = !DILocation(line: 824, column: 38, scope: !1772)
!1836 = !{!1837, !1040, i64 472}
!1837 = !{!"conn", !1040, i64 0, !1054, i64 8, !1105, i64 12, !1105, i64 13, !1105, i64 14, !1105, i64 15, !1105, i64 16, !1105, i64 17, !1105, i64 18, !1054, i64 20, !1054, i64 24, !1054, i64 28, !1838, i64 32, !1111, i64 160, !1111, i64 162, !1040, i64 168, !1040, i64 176, !1054, i64 184, !1054, i64 188, !1040, i64 192, !1040, i64 200, !1040, i64 208, !1054, i64 216, !1040, i64 224, !1054, i64 232, !1054, i64 236, !1041, i64 240, !1054, i64 312, !1054, i64 316, !1054, i64 320, !1054, i64 324, !1054, i64 328, !1841, i64 332, !1054, i64 360, !1105, i64 364, !1843, i64 368, !1041, i64 392, !1068, i64 416, !1068, i64 424, !1111, i64 432, !1054, i64 436, !1054, i64 440, !1040, i64 448, !1040, i64 456, !1040, i64 464, !1040, i64 472, !1040, i64 480, !1040, i64 488}
!1838 = !{!"event", !1839, i64 0, !1041, i64 40, !1054, i64 56, !1040, i64 64, !1041, i64 72, !1111, i64 104, !1111, i64 106, !1724, i64 112}
!1839 = !{!"event_callback", !1840, i64 0, !1111, i64 16, !1041, i64 18, !1041, i64 19, !1041, i64 24, !1040, i64 32}
!1840 = !{!"", !1040, i64 0, !1040, i64 8}
!1841 = !{!"sockaddr_in6", !1111, i64 0, !1111, i64 2, !1054, i64 4, !1842, i64 8, !1054, i64 24}
!1842 = !{!"in6_addr", !1041, i64 0}
!1843 = !{!"", !1040, i64 0, !1068, i64 8, !1068, i64 16}
!1844 = !DILocation(line: 824, column: 23, scope: !1772)
!1845 = !DILocation(line: 825, column: 26, scope: !1846)
!1846 = distinct !DILexicalBlock(scope: !1772, file: !3, line: 825, column: 17)
!1847 = !DILocation(line: 825, column: 44, scope: !1846)
!1848 = !DILocation(line: 825, column: 50, scope: !1846)
!1849 = !DILocation(line: 825, column: 60, scope: !1846)
!1850 = !DILocation(line: 831, column: 9, scope: !1773)
!1851 = !DILocation(line: 827, column: 17, scope: !1852)
!1852 = distinct !DILexicalBlock(scope: !1846, file: !3, line: 825, column: 87)
!1853 = !DILocation(line: 828, column: 20, scope: !1852)
!1854 = !DILocation(line: 832, column: 40, scope: !1780)
!1855 = !DILocation(line: 832, column: 21, scope: !1780)
!1856 = !DILocation(line: 832, column: 58, scope: !1780)
!1857 = !DILocation(line: 832, column: 13, scope: !1768)
!1858 = !DILocation(line: 833, column: 39, scope: !1778)
!1859 = !DILocation(line: 833, column: 17, scope: !1778)
!1860 = !DILocation(line: 833, column: 47, scope: !1778)
!1861 = !DILocation(line: 833, column: 17, scope: !1779)
!1862 = !DILocation(line: 835, column: 17, scope: !1863)
!1863 = distinct !DILexicalBlock(scope: !1778, file: !3, line: 833, column: 68)
!1864 = !DILocation(line: 836, column: 13, scope: !1863)
!1865 = !DILocation(line: 836, column: 54, scope: !1777)
!1866 = !DILocation(line: 836, column: 24, scope: !1778)
!1867 = !DILocation(line: 0, scope: !1776)
!1868 = !DILocation(line: 840, column: 28, scope: !1776)
!1869 = !{!1365, !1054, i64 36}
!1870 = !DILocation(line: 840, column: 17, scope: !1776)
!1871 = !DILocation(line: 842, column: 49, scope: !1872)
!1872 = distinct !DILexicalBlock(scope: !1776, file: !3, line: 840, column: 31)
!1873 = !DILocation(line: 842, column: 60, scope: !1872)
!1874 = !DILocation(line: 842, column: 33, scope: !1872)
!1875 = !DILocation(line: 843, column: 25, scope: !1872)
!1876 = !DILocation(line: 845, column: 44, scope: !1872)
!1877 = !DILocation(line: 845, column: 48, scope: !1872)
!1878 = !{!1837, !1040, i64 488}
!1879 = !DILocation(line: 845, column: 66, scope: !1872)
!1880 = !DILocation(line: 845, column: 33, scope: !1872)
!1881 = !DILocation(line: 846, column: 25, scope: !1872)
!1882 = !DILocation(line: 851, column: 21, scope: !1776)
!1883 = !DILocation(line: 852, column: 25, scope: !1884)
!1884 = distinct !DILexicalBlock(scope: !1885, file: !3, line: 852, column: 25)
!1885 = distinct !DILexicalBlock(scope: !1886, file: !3, line: 851, column: 34)
!1886 = distinct !DILexicalBlock(scope: !1776, file: !3, line: 851, column: 21)
!1887 = !DILocation(line: 852, column: 31, scope: !1884)
!1888 = !DILocation(line: 852, column: 41, scope: !1884)
!1889 = !DILocation(line: 853, column: 25, scope: !1890)
!1890 = distinct !DILexicalBlock(scope: !1884, file: !3, line: 852, column: 66)
!1891 = !DILocation(line: 854, column: 21, scope: !1890)
!1892 = !DILocation(line: 857, column: 21, scope: !1893)
!1893 = distinct !DILexicalBlock(scope: !1894, file: !3, line: 856, column: 40)
!1894 = distinct !DILexicalBlock(scope: !1886, file: !3, line: 856, column: 28)
!1895 = !DILocation(line: 858, column: 17, scope: !1893)
!1896 = !DILocation(line: 859, column: 36, scope: !1897)
!1897 = distinct !DILexicalBlock(scope: !1894, file: !3, line: 858, column: 24)
!1898 = !DILocation(line: 859, column: 21, scope: !1897)
!1899 = !DILocation(line: 860, column: 29, scope: !1897)
!1900 = !DILocation(line: 778, column: 9, scope: !1751)
!1901 = !DILocation(line: 864, column: 12, scope: !1768)
!1902 = !DILocation(line: 865, column: 5, scope: !1769)
!1903 = !DILocation(line: 813, column: 37, scope: !1769)
!1904 = !DILocation(line: 813, column: 19, scope: !1769)
!1905 = !DILocation(line: 813, column: 5, scope: !1770)
!1906 = distinct !{!1906, !1905, !1907, !1429}
!1907 = !DILocation(line: 865, column: 5, scope: !1770)
!1908 = !DILocation(line: 867, column: 1, scope: !1751)
!1909 = !DISubprogram(name: "bipbuf_peek_all", scope: !463, file: !463, line: 62, type: !1910, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1910 = !DISubroutineType(types: !1911)
!1911 = !{!141, !1912, !1914}
!1912 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1913, size: 64)
!1913 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !462)
!1914 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !7, size: 64)
!1915 = !DISubprogram(name: "bipbuf_poll", scope: !463, file: !463, line: 69, type: !1916, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1916 = !DISubroutineType(types: !1917)
!1917 = !{!141, !461, !1161}
!1918 = !DISubprogram(name: "snprintf", scope: !1280, file: !1280, line: 385, type: !1919, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1919 = !DISubroutineType(types: !1920)
!1920 = !{!132, !1921, !436, !1333, null}
!1921 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !142)
!1922 = !DISubprogram(name: "poll", scope: !808, file: !808, line: 54, type: !1923, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1923 = !DISubroutineType(types: !1924)
!1924 = !{!132, !1925, !1926, !132}
!1925 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !807, size: 64)
!1926 = !DIDerivedType(tag: DW_TAG_typedef, name: "nfds_t", file: !808, line: 33, baseType: !121)
!1927 = !DISubprogram(name: "perror", scope: !1280, file: !1280, line: 878, type: !1928, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1928 = !DISubroutineType(types: !1929)
!1929 = !{null, !1334}
!1930 = !DISubprogram(name: "__errno_location", scope: !1931, file: !1931, line: 37, type: !1932, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1931 = !DIFile(filename: "/usr/include/errno.h", directory: "", checksumkind: CSK_MD5, checksum: "047d5cf117ed2ec1460c1b2e072a4e50")
!1932 = !DISubroutineType(types: !1933)
!1933 = !{!1561}
!1934 = distinct !DISubprogram(name: "logger_thread_close_watcher", scope: !3, file: !3, line: 704, type: !1935, scopeLine: 704, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1937)
!1935 = !DISubroutineType(types: !1936)
!1936 = !{null, !789}
!1937 = !{!1938}
!1938 = !DILocalVariable(name: "w", arg: 1, scope: !1934, file: !3, line: 704, type: !789)
!1939 = !DILocation(line: 0, scope: !1934)
!1940 = !DILocation(line: 706, column: 17, scope: !1934)
!1941 = !DILocation(line: 706, column: 5, scope: !1934)
!1942 = !DILocation(line: 706, column: 21, scope: !1934)
!1943 = !DILocation(line: 707, column: 30, scope: !1934)
!1944 = !DILocation(line: 707, column: 5, scope: !1934)
!1945 = !DILocation(line: 708, column: 18, scope: !1934)
!1946 = !DILocation(line: 709, column: 20, scope: !1934)
!1947 = !DILocation(line: 709, column: 5, scope: !1934)
!1948 = !DILocation(line: 710, column: 5, scope: !1934)
!1949 = !DILocation(line: 0, scope: !1401, inlinedAt: !1950)
!1950 = distinct !DILocation(line: 711, column: 5, scope: !1934)
!1951 = !DILocation(line: 620, column: 5, scope: !1408, inlinedAt: !1950)
!1952 = !DILocation(line: 627, scope: !1413, inlinedAt: !1950)
!1953 = !DILocation(line: 627, column: 35, scope: !1415, inlinedAt: !1950)
!1954 = !DILocation(line: 627, column: 5, scope: !1413, inlinedAt: !1950)
!1955 = !DILocation(line: 621, column: 29, scope: !1406, inlinedAt: !1950)
!1956 = !DILocation(line: 0, scope: !1406, inlinedAt: !1950)
!1957 = !DILocation(line: 622, column: 15, scope: !1420, inlinedAt: !1950)
!1958 = !DILocation(line: 622, column: 13, scope: !1406, inlinedAt: !1950)
!1959 = !DILocation(line: 625, column: 17, scope: !1406, inlinedAt: !1950)
!1960 = !DILocation(line: 625, column: 11, scope: !1406, inlinedAt: !1950)
!1961 = !DILocation(line: 626, column: 5, scope: !1407, inlinedAt: !1950)
!1962 = !DILocation(line: 620, column: 37, scope: !1407, inlinedAt: !1950)
!1963 = !DILocation(line: 620, column: 19, scope: !1407, inlinedAt: !1950)
!1964 = distinct !{!1964, !1951, !1965, !1429}
!1965 = !DILocation(line: 626, column: 5, scope: !1408, inlinedAt: !1950)
!1966 = !DILocation(line: 628, column: 32, scope: !1431, inlinedAt: !1950)
!1967 = !DILocation(line: 628, column: 9, scope: !1431, inlinedAt: !1950)
!1968 = !DILocation(line: 629, column: 12, scope: !1431, inlinedAt: !1950)
!1969 = !DILocation(line: 629, column: 19, scope: !1431, inlinedAt: !1950)
!1970 = !DILocation(line: 630, column: 9, scope: !1431, inlinedAt: !1950)
!1971 = !DILocation(line: 627, column: 49, scope: !1415, inlinedAt: !1950)
!1972 = distinct !{!1972, !1954, !1973, !1429}
!1973 = !DILocation(line: 631, column: 5, scope: !1413, inlinedAt: !1950)
!1974 = !DILocation(line: 712, column: 1, scope: !1934)
!1975 = !DISubprogram(name: "fwrite", scope: !1280, file: !1280, line: 745, type: !1976, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1976 = !DISubroutineType(types: !1977)
!1977 = !{!121, !1978, !436, !436, !1283}
!1978 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !486)
!1979 = !DISubprogram(name: "sidethread_conn_close", scope: !45, file: !45, line: 996, type: !1980, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1980 = !DISubroutineType(types: !1981)
!1981 = !{null, !144}
!1982 = !DISubprogram(name: "bipbuf_free", scope: !463, file: !463, line: 38, type: !1983, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1983 = !DISubroutineType(types: !1984)
!1984 = !{null, !461}
!1985 = !DISubprogram(name: "STATS_LOCK", scope: !45, file: !45, line: 1026, type: !1036, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1986 = !DISubprogram(name: "STATS_UNLOCK", scope: !45, file: !45, line: 1027, type: !1036, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1987 = !DISubprogram(name: "pthread_join", scope: !1072, file: !1072, line: 219, type: !1988, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1988 = !DISubroutineType(types: !1989)
!1989 = !{!132, !265, !1990}
!1990 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !102, size: 64)
!1991 = distinct !DISubprogram(name: "_logger_log_text", scope: !3, file: !3, line: 54, type: !484, scopeLine: 54, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1992)
!1992 = !{!1993, !1994, !1995, !1996, !1997, !1998}
!1993 = !DILocalVariable(name: "e", arg: 1, scope: !1991, file: !3, line: 54, type: !103)
!1994 = !DILocalVariable(name: "d", arg: 2, scope: !1991, file: !3, line: 54, type: !474)
!1995 = !DILocalVariable(name: "entry", arg: 3, scope: !1991, file: !3, line: 54, type: !486)
!1996 = !DILocalVariable(name: "ap", arg: 4, scope: !1991, file: !3, line: 54, type: !488)
!1997 = !DILocalVariable(name: "reqlen", scope: !1991, file: !3, line: 55, type: !132)
!1998 = !DILocalVariable(name: "total", scope: !1991, file: !3, line: 56, type: !132)
!1999 = !DILocation(line: 0, scope: !1991)
!2000 = !DILocation(line: 55, column: 21, scope: !1991)
!2001 = !DILocation(line: 56, column: 39, scope: !1991)
!2002 = !DILocation(line: 56, column: 45, scope: !1991)
!2003 = !DILocation(line: 56, column: 56, scope: !1991)
!2004 = !{!1205, !1040, i64 24}
!2005 = !DILocation(line: 56, column: 17, scope: !1991)
!2006 = !DILocation(line: 57, column: 15, scope: !2007)
!2007 = distinct !DILexicalBlock(scope: !1991, file: !3, line: 57, column: 9)
!2008 = !DILocation(line: 57, column: 9, scope: !1991)
!2009 = !DILocation(line: 58, column: 17, scope: !2010)
!2010 = distinct !DILexicalBlock(scope: !2007, file: !3, line: 57, column: 21)
!2011 = !DILocation(line: 58, column: 9, scope: !2010)
!2012 = !DILocation(line: 59, column: 5, scope: !2010)
!2013 = !DILocation(line: 60, column: 21, scope: !1991)
!2014 = !DILocation(line: 60, column: 8, scope: !1991)
!2015 = !DILocation(line: 60, column: 13, scope: !1991)
!2016 = !DILocation(line: 61, column: 1, scope: !1991)
!2017 = distinct !DISubprogram(name: "_logger_parse_text", scope: !3, file: !3, line: 207, type: !498, scopeLine: 207, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2018)
!2018 = !{!2019, !2020}
!2019 = !DILocalVariable(name: "e", arg: 1, scope: !2017, file: !3, line: 207, type: !103)
!2020 = !DILocalVariable(name: "scratch", arg: 2, scope: !2017, file: !3, line: 207, type: !142)
!2021 = !DILocation(line: 0, scope: !2017)
!2022 = !DILocation(line: 209, column: 31, scope: !2017)
!2023 = !DILocation(line: 209, column: 34, scope: !2017)
!2024 = !{!1724, !1068, i64 0}
!2025 = !DILocation(line: 209, column: 53, scope: !2017)
!2026 = !{!1724, !1068, i64 8}
!2027 = !DILocation(line: 209, column: 42, scope: !2017)
!2028 = !DILocation(line: 210, column: 37, scope: !2017)
!2029 = !DILocation(line: 210, column: 54, scope: !2017)
!2030 = !DILocation(line: 208, column: 12, scope: !2017)
!2031 = !DILocation(line: 208, column: 5, scope: !2017)
!2032 = distinct !DISubprogram(name: "_logger_log_evictions", scope: !3, file: !3, line: 63, type: !484, scopeLine: 63, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2033)
!2033 = !{!2034, !2035, !2036, !2037, !2038, !2039}
!2034 = !DILocalVariable(name: "e", arg: 1, scope: !2032, file: !3, line: 63, type: !103)
!2035 = !DILocalVariable(name: "d", arg: 2, scope: !2032, file: !3, line: 63, type: !474)
!2036 = !DILocalVariable(name: "entry", arg: 3, scope: !2032, file: !3, line: 63, type: !486)
!2037 = !DILocalVariable(name: "ap", arg: 4, scope: !2032, file: !3, line: 63, type: !488)
!2038 = !DILocalVariable(name: "it", scope: !2032, file: !3, line: 64, type: !515)
!2039 = !DILocalVariable(name: "le", scope: !2032, file: !3, line: 65, type: !668)
!2040 = !DILocation(line: 0, scope: !2032)
!2041 = !DILocation(line: 67, column: 24, scope: !2032)
!2042 = !DILocation(line: 67, column: 32, scope: !2032)
!2043 = !DILocation(line: 67, column: 19, scope: !2032)
!2044 = !DILocation(line: 67, column: 69, scope: !2032)
!2045 = !DILocation(line: 67, column: 67, scope: !2032)
!2046 = !DILocation(line: 67, column: 39, scope: !2032)
!2047 = !DILocation(line: 65, column: 68, scope: !2032)
!2048 = !DILocation(line: 67, column: 17, scope: !2032)
!2049 = !{!2050, !2050, i64 0}
!2050 = !{!"long long", !1041, i64 0}
!2051 = !DILocation(line: 68, column: 18, scope: !2032)
!2052 = !DILocation(line: 68, column: 37, scope: !2032)
!2053 = !DILocation(line: 68, column: 31, scope: !2032)
!2054 = !DILocation(line: 68, column: 9, scope: !2032)
!2055 = !DILocation(line: 68, column: 16, scope: !2032)
!2056 = !DILocation(line: 69, column: 24, scope: !2032)
!2057 = !DILocation(line: 69, column: 9, scope: !2032)
!2058 = !DILocation(line: 69, column: 18, scope: !2032)
!2059 = !DILocation(line: 70, column: 20, scope: !2032)
!2060 = !DILocation(line: 70, column: 9, scope: !2032)
!2061 = !DILocation(line: 70, column: 14, scope: !2032)
!2062 = !DILocation(line: 71, column: 22, scope: !2032)
!2063 = !DILocation(line: 71, column: 9, scope: !2032)
!2064 = !DILocation(line: 71, column: 16, scope: !2032)
!2065 = !DILocation(line: 72, column: 17, scope: !2032)
!2066 = !DILocation(line: 72, column: 9, scope: !2032)
!2067 = !DILocation(line: 72, column: 15, scope: !2032)
!2068 = !DILocation(line: 73, column: 16, scope: !2032)
!2069 = !DILocation(line: 73, column: 21, scope: !2032)
!2070 = !DILocation(line: 73, column: 39, scope: !2032)
!2071 = !DILocation(line: 73, column: 35, scope: !2032)
!2072 = !DILocation(line: 73, column: 5, scope: !2032)
!2073 = !DILocation(line: 74, column: 50, scope: !2032)
!2074 = !DILocation(line: 74, column: 48, scope: !2032)
!2075 = !DILocation(line: 74, column: 8, scope: !2032)
!2076 = !DILocation(line: 74, column: 13, scope: !2032)
!2077 = !DILocation(line: 75, column: 1, scope: !2032)
!2078 = distinct !DISubprogram(name: "_logger_parse_ee", scope: !3, file: !3, line: 251, type: !498, scopeLine: 251, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2079)
!2079 = !{!2080, !2081, !2082, !2083, !2087}
!2080 = !DILocalVariable(name: "e", arg: 1, scope: !2078, file: !3, line: 251, type: !103)
!2081 = !DILocalVariable(name: "scratch", arg: 2, scope: !2078, file: !3, line: 251, type: !142)
!2082 = !DILocalVariable(name: "total", scope: !2078, file: !3, line: 252, type: !132)
!2083 = !DILocalVariable(name: "keybuf", scope: !2078, file: !3, line: 253, type: !2084)
!2084 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 6008, elements: !2085)
!2085 = !{!2086}
!2086 = !DISubrange(count: 751)
!2087 = !DILocalVariable(name: "le", scope: !2078, file: !3, line: 254, type: !668)
!2088 = distinct !DIAssignID()
!2089 = !DILocation(line: 0, scope: !2078)
!2090 = !DILocation(line: 253, column: 5, scope: !2078)
!2091 = !DILocation(line: 254, column: 68, scope: !2078)
!2092 = !DILocation(line: 255, column: 19, scope: !2078)
!2093 = !DILocation(line: 255, column: 36, scope: !2078)
!2094 = !DILocation(line: 255, column: 32, scope: !2078)
!2095 = !DILocation(line: 255, column: 5, scope: !2078)
!2096 = !DILocation(line: 258, column: 31, scope: !2078)
!2097 = !DILocation(line: 258, column: 34, scope: !2078)
!2098 = !DILocation(line: 258, column: 53, scope: !2078)
!2099 = !DILocation(line: 258, column: 86, scope: !2078)
!2100 = !DILocation(line: 259, column: 26, scope: !2078)
!2101 = !DILocation(line: 260, column: 32, scope: !2078)
!2102 = !DILocation(line: 260, column: 45, scope: !2078)
!2103 = !DILocation(line: 260, column: 57, scope: !2078)
!2104 = !DILocation(line: 261, column: 17, scope: !2078)
!2105 = !DILocation(line: 261, column: 24, scope: !2078)
!2106 = !DILocation(line: 261, column: 13, scope: !2078)
!2107 = !DILocation(line: 260, column: 53, scope: !2078)
!2108 = !DILocation(line: 259, column: 35, scope: !2078)
!2109 = !DILocation(line: 259, column: 21, scope: !2078)
!2110 = !DILocation(line: 258, column: 42, scope: !2078)
!2111 = !DILocation(line: 256, column: 13, scope: !2078)
!2112 = !DILocation(line: 264, column: 1, scope: !2078)
!2113 = !DILocation(line: 263, column: 5, scope: !2078)
!2114 = distinct !DISubprogram(name: "_logger_log_item_get", scope: !3, file: !3, line: 96, type: !484, scopeLine: 96, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2115)
!2115 = !{!2116, !2117, !2118, !2119, !2120, !2121, !2122, !2123, !2124, !2125, !2126}
!2116 = !DILocalVariable(name: "e", arg: 1, scope: !2114, file: !3, line: 96, type: !103)
!2117 = !DILocalVariable(name: "d", arg: 2, scope: !2114, file: !3, line: 96, type: !474)
!2118 = !DILocalVariable(name: "entry", arg: 3, scope: !2114, file: !3, line: 96, type: !486)
!2119 = !DILocalVariable(name: "ap", arg: 4, scope: !2114, file: !3, line: 96, type: !488)
!2120 = !DILocalVariable(name: "was_found", scope: !2114, file: !3, line: 97, type: !132)
!2121 = !DILocalVariable(name: "key", scope: !2114, file: !3, line: 98, type: !142)
!2122 = !DILocalVariable(name: "nkey", scope: !2114, file: !3, line: 99, type: !132)
!2123 = !DILocalVariable(name: "nbytes", scope: !2114, file: !3, line: 100, type: !132)
!2124 = !DILocalVariable(name: "clsid", scope: !2114, file: !3, line: 101, type: !109)
!2125 = !DILocalVariable(name: "sfd", scope: !2114, file: !3, line: 102, type: !132)
!2126 = !DILocalVariable(name: "le", scope: !2114, file: !3, line: 104, type: !679)
!2127 = !DILocation(line: 0, scope: !2114)
!2128 = !DILocation(line: 97, column: 21, scope: !2114)
!2129 = !DILocation(line: 98, column: 17, scope: !2114)
!2130 = !DILocation(line: 99, column: 16, scope: !2114)
!2131 = !DILocation(line: 100, column: 18, scope: !2114)
!2132 = !DILocation(line: 101, column: 21, scope: !2114)
!2133 = !DILocation(line: 102, column: 15, scope: !2114)
!2134 = !DILocation(line: 104, column: 68, scope: !2114)
!2135 = !DILocation(line: 105, column: 21, scope: !2114)
!2136 = !DILocation(line: 105, column: 19, scope: !2114)
!2137 = !DILocation(line: 106, column: 16, scope: !2114)
!2138 = !DILocation(line: 106, column: 9, scope: !2114)
!2139 = !DILocation(line: 106, column: 14, scope: !2114)
!2140 = !DILocation(line: 107, column: 9, scope: !2114)
!2141 = !DILocation(line: 107, column: 16, scope: !2114)
!2142 = !DILocation(line: 108, column: 9, scope: !2114)
!2143 = !DILocation(line: 108, column: 15, scope: !2114)
!2144 = !DILocation(line: 109, column: 16, scope: !2114)
!2145 = !DILocation(line: 109, column: 26, scope: !2114)
!2146 = !DILocation(line: 109, column: 5, scope: !2114)
!2147 = !DILocation(line: 110, column: 9, scope: !2114)
!2148 = !DILocation(line: 110, column: 13, scope: !2114)
!2149 = !DILocation(line: 111, column: 48, scope: !2114)
!2150 = !DILocation(line: 111, column: 8, scope: !2114)
!2151 = !DILocation(line: 111, column: 13, scope: !2114)
!2152 = !DILocation(line: 112, column: 1, scope: !2114)
!2153 = distinct !DISubprogram(name: "_logger_parse_ige", scope: !3, file: !3, line: 235, type: !498, scopeLine: 235, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2154)
!2154 = !{!2155, !2156, !2157, !2158, !2159, !2160}
!2155 = !DILocalVariable(name: "e", arg: 1, scope: !2153, file: !3, line: 235, type: !103)
!2156 = !DILocalVariable(name: "scratch", arg: 2, scope: !2153, file: !3, line: 235, type: !142)
!2157 = !DILocalVariable(name: "total", scope: !2153, file: !3, line: 236, type: !132)
!2158 = !DILocalVariable(name: "le", scope: !2153, file: !3, line: 237, type: !679)
!2159 = !DILocalVariable(name: "keybuf", scope: !2153, file: !3, line: 238, type: !2084)
!2160 = !DILocalVariable(name: "was_found_map", scope: !2153, file: !3, line: 239, type: !2161)
!2161 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2162, size: 256, elements: !543)
!2162 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !1334)
!2163 = distinct !DIAssignID()
!2164 = !DILocation(line: 0, scope: !2153)
!2165 = distinct !DIAssignID()
!2166 = !DILocation(line: 237, column: 68, scope: !2153)
!2167 = !DILocation(line: 238, column: 5, scope: !2153)
!2168 = distinct !DIAssignID()
!2169 = !DILocation(line: 242, column: 19, scope: !2153)
!2170 = !DILocation(line: 242, column: 36, scope: !2153)
!2171 = !DILocation(line: 242, column: 32, scope: !2153)
!2172 = !DILocation(line: 242, column: 5, scope: !2153)
!2173 = !DILocation(line: 245, column: 31, scope: !2153)
!2174 = !DILocation(line: 245, column: 34, scope: !2153)
!2175 = !DILocation(line: 245, column: 53, scope: !2153)
!2176 = !DILocation(line: 245, column: 86, scope: !2153)
!2177 = !DILocation(line: 246, column: 39, scope: !2153)
!2178 = !DILocation(line: 246, column: 21, scope: !2153)
!2179 = !DILocation(line: 246, column: 55, scope: !2153)
!2180 = !DILocation(line: 246, column: 66, scope: !2153)
!2181 = !DILocation(line: 247, column: 17, scope: !2153)
!2182 = !DILocation(line: 247, column: 24, scope: !2153)
!2183 = !DILocation(line: 247, column: 13, scope: !2153)
!2184 = !DILocation(line: 246, column: 51, scope: !2153)
!2185 = !DILocation(line: 245, column: 42, scope: !2153)
!2186 = !DILocation(line: 243, column: 13, scope: !2153)
!2187 = !DILocation(line: 249, column: 1, scope: !2153)
!2188 = !DILocation(line: 248, column: 5, scope: !2153)
!2189 = distinct !DISubprogram(name: "_logger_log_item_store", scope: !3, file: !3, line: 114, type: !484, scopeLine: 114, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2190)
!2190 = !{!2191, !2192, !2193, !2194, !2195, !2196, !2197, !2198, !2199, !2200, !2201, !2202, !2203}
!2191 = !DILocalVariable(name: "e", arg: 1, scope: !2189, file: !3, line: 114, type: !103)
!2192 = !DILocalVariable(name: "d", arg: 2, scope: !2189, file: !3, line: 114, type: !474)
!2193 = !DILocalVariable(name: "entry", arg: 3, scope: !2189, file: !3, line: 114, type: !486)
!2194 = !DILocalVariable(name: "ap", arg: 4, scope: !2189, file: !3, line: 114, type: !488)
!2195 = !DILocalVariable(name: "status", scope: !2189, file: !3, line: 115, type: !93)
!2196 = !DILocalVariable(name: "comm", scope: !2189, file: !3, line: 116, type: !132)
!2197 = !DILocalVariable(name: "key", scope: !2189, file: !3, line: 117, type: !142)
!2198 = !DILocalVariable(name: "nkey", scope: !2189, file: !3, line: 118, type: !132)
!2199 = !DILocalVariable(name: "nbytes", scope: !2189, file: !3, line: 119, type: !132)
!2200 = !DILocalVariable(name: "ttl", scope: !2189, file: !3, line: 120, type: !164)
!2201 = !DILocalVariable(name: "clsid", scope: !2189, file: !3, line: 121, type: !109)
!2202 = !DILocalVariable(name: "sfd", scope: !2189, file: !3, line: 122, type: !132)
!2203 = !DILocalVariable(name: "le", scope: !2189, file: !3, line: 124, type: !688)
!2204 = !DILocation(line: 0, scope: !2189)
!2205 = !DILocation(line: 115, column: 35, scope: !2189)
!2206 = !DILocation(line: 116, column: 16, scope: !2189)
!2207 = !DILocation(line: 117, column: 17, scope: !2189)
!2208 = !DILocation(line: 118, column: 16, scope: !2189)
!2209 = !DILocation(line: 119, column: 18, scope: !2189)
!2210 = !DILocation(line: 120, column: 22, scope: !2189)
!2211 = !DILocation(line: 121, column: 21, scope: !2189)
!2212 = !DILocation(line: 122, column: 15, scope: !2189)
!2213 = !DILocation(line: 124, column: 72, scope: !2189)
!2214 = !DILocation(line: 125, column: 16, scope: !2189)
!2215 = !DILocation(line: 126, column: 9, scope: !2189)
!2216 = !DILocation(line: 126, column: 13, scope: !2189)
!2217 = !DILocation(line: 127, column: 16, scope: !2189)
!2218 = !DILocation(line: 127, column: 9, scope: !2189)
!2219 = !DILocation(line: 127, column: 14, scope: !2189)
!2220 = !DILocation(line: 128, column: 9, scope: !2189)
!2221 = !DILocation(line: 128, column: 16, scope: !2189)
!2222 = !DILocation(line: 129, column: 9, scope: !2189)
!2223 = !DILocation(line: 129, column: 15, scope: !2189)
!2224 = !DILocation(line: 130, column: 13, scope: !2225)
!2225 = distinct !DILexicalBlock(scope: !2189, file: !3, line: 130, column: 9)
!2226 = !DILocation(line: 130, column: 9, scope: !2189)
!2227 = !DILocation(line: 131, column: 25, scope: !2228)
!2228 = distinct !DILexicalBlock(scope: !2225, file: !3, line: 130, column: 19)
!2229 = !DILocation(line: 131, column: 23, scope: !2228)
!2230 = !DILocation(line: 132, column: 5, scope: !2228)
!2231 = !DILocation(line: 0, scope: !2225)
!2232 = !DILocation(line: 135, column: 16, scope: !2189)
!2233 = !DILocation(line: 135, column: 26, scope: !2189)
!2234 = !DILocation(line: 135, column: 5, scope: !2189)
!2235 = !DILocation(line: 136, column: 9, scope: !2189)
!2236 = !DILocation(line: 136, column: 13, scope: !2189)
!2237 = !DILocation(line: 137, column: 50, scope: !2189)
!2238 = !DILocation(line: 137, column: 8, scope: !2189)
!2239 = !DILocation(line: 137, column: 13, scope: !2189)
!2240 = !DILocation(line: 138, column: 1, scope: !2189)
!2241 = distinct !DISubprogram(name: "_logger_parse_ise", scope: !3, file: !3, line: 213, type: !498, scopeLine: 213, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2242)
!2242 = !{!2243, !2244, !2245, !2246, !2247, !2248, !2249, !2251}
!2243 = !DILocalVariable(name: "e", arg: 1, scope: !2241, file: !3, line: 213, type: !103)
!2244 = !DILocalVariable(name: "scratch", arg: 2, scope: !2241, file: !3, line: 213, type: !142)
!2245 = !DILocalVariable(name: "total", scope: !2241, file: !3, line: 214, type: !132)
!2246 = !DILocalVariable(name: "cmd", scope: !2241, file: !3, line: 215, type: !1334)
!2247 = !DILocalVariable(name: "keybuf", scope: !2241, file: !3, line: 216, type: !2084)
!2248 = !DILocalVariable(name: "le", scope: !2241, file: !3, line: 217, type: !688)
!2249 = !DILocalVariable(name: "status_map", scope: !2241, file: !3, line: 218, type: !2250)
!2250 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2162, size: 384, elements: !920)
!2251 = !DILocalVariable(name: "cmd_map", scope: !2241, file: !3, line: 220, type: !2252)
!2252 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2162, size: 576, elements: !991)
!2253 = distinct !DIAssignID()
!2254 = !DILocation(line: 0, scope: !2241)
!2255 = distinct !DIAssignID()
!2256 = distinct !DIAssignID()
!2257 = !DILocation(line: 216, column: 5, scope: !2241)
!2258 = distinct !DIAssignID()
!2259 = distinct !DIAssignID()
!2260 = !DILocation(line: 223, column: 13, scope: !2261)
!2261 = distinct !DILexicalBlock(scope: !2241, file: !3, line: 223, column: 9)
!2262 = !DILocation(line: 223, column: 17, scope: !2261)
!2263 = !DILocation(line: 223, column: 9, scope: !2241)
!2264 = !DILocation(line: 224, column: 15, scope: !2261)
!2265 = !DILocation(line: 224, column: 9, scope: !2261)
!2266 = !DILocation(line: 217, column: 72, scope: !2241)
!2267 = !DILocation(line: 226, column: 19, scope: !2241)
!2268 = !DILocation(line: 226, column: 36, scope: !2241)
!2269 = !DILocation(line: 226, column: 32, scope: !2241)
!2270 = !DILocation(line: 226, column: 5, scope: !2241)
!2271 = !DILocation(line: 229, column: 31, scope: !2241)
!2272 = !DILocation(line: 229, column: 34, scope: !2241)
!2273 = !DILocation(line: 229, column: 53, scope: !2241)
!2274 = !DILocation(line: 229, column: 86, scope: !2241)
!2275 = !DILocation(line: 230, column: 36, scope: !2241)
!2276 = !DILocation(line: 230, column: 21, scope: !2241)
!2277 = !DILocation(line: 230, column: 54, scope: !2241)
!2278 = !DILocation(line: 230, column: 63, scope: !2241)
!2279 = !DILocation(line: 230, column: 74, scope: !2241)
!2280 = !DILocation(line: 231, column: 17, scope: !2241)
!2281 = !DILocation(line: 231, column: 24, scope: !2241)
!2282 = !DILocation(line: 231, column: 13, scope: !2241)
!2283 = !DILocation(line: 230, column: 59, scope: !2241)
!2284 = !DILocation(line: 229, column: 42, scope: !2241)
!2285 = !DILocation(line: 227, column: 13, scope: !2241)
!2286 = !DILocation(line: 233, column: 1, scope: !2241)
!2287 = !DILocation(line: 232, column: 5, scope: !2241)
!2288 = distinct !DISubprogram(name: "_logger_log_conn_event", scope: !3, file: !3, line: 152, type: !484, scopeLine: 152, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2289)
!2289 = !{!2290, !2291, !2292, !2293, !2294, !2295, !2296, !2297, !2298, !2299}
!2290 = !DILocalVariable(name: "e", arg: 1, scope: !2288, file: !3, line: 152, type: !103)
!2291 = !DILocalVariable(name: "d", arg: 2, scope: !2288, file: !3, line: 152, type: !474)
!2292 = !DILocalVariable(name: "entry", arg: 3, scope: !2288, file: !3, line: 152, type: !486)
!2293 = !DILocalVariable(name: "ap", arg: 4, scope: !2288, file: !3, line: 152, type: !488)
!2294 = !DILocalVariable(name: "addr", scope: !2288, file: !3, line: 153, type: !718)
!2295 = !DILocalVariable(name: "addrlen", scope: !2288, file: !3, line: 154, type: !583)
!2296 = !DILocalVariable(name: "transport", scope: !2288, file: !3, line: 155, type: !82)
!2297 = !DILocalVariable(name: "reason", scope: !2288, file: !3, line: 156, type: !87)
!2298 = !DILocalVariable(name: "sfd", scope: !2288, file: !3, line: 157, type: !132)
!2299 = !DILocalVariable(name: "le", scope: !2288, file: !3, line: 159, type: !699)
!2300 = !DILocation(line: 0, scope: !2288)
!2301 = !DILocation(line: 153, column: 33, scope: !2288)
!2302 = !DILocation(line: 154, column: 25, scope: !2288)
!2303 = !DILocation(line: 155, column: 40, scope: !2288)
!2304 = !DILocation(line: 156, column: 33, scope: !2288)
!2305 = !DILocation(line: 157, column: 15, scope: !2288)
!2306 = !DILocation(line: 159, column: 72, scope: !2288)
!2307 = !DILocation(line: 161, column: 17, scope: !2288)
!2308 = !DILocation(line: 161, column: 29, scope: !2288)
!2309 = !DILocation(line: 161, column: 5, scope: !2288)
!2310 = !DILocation(line: 162, column: 9, scope: !2288)
!2311 = !DILocation(line: 162, column: 13, scope: !2288)
!2312 = !{!2313, !1054, i64 8}
!2313 = !{!"logentry_conn_event", !1054, i64 0, !1054, i64 4, !1054, i64 8, !1841, i64 12}
!2314 = !DILocation(line: 163, column: 19, scope: !2288)
!2315 = !{!2313, !1054, i64 0}
!2316 = !DILocation(line: 164, column: 9, scope: !2288)
!2317 = !DILocation(line: 164, column: 16, scope: !2288)
!2318 = !{!2313, !1054, i64 4}
!2319 = !DILocation(line: 165, column: 8, scope: !2288)
!2320 = !DILocation(line: 165, column: 13, scope: !2288)
!2321 = !DILocation(line: 166, column: 1, scope: !2288)
!2322 = distinct !DISubprogram(name: "_logger_parse_cne", scope: !3, file: !3, line: 302, type: !498, scopeLine: 302, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2323)
!2323 = !{!2324, !2325, !2326, !2327, !2328, !2330, !2331}
!2324 = !DILocalVariable(name: "e", arg: 1, scope: !2322, file: !3, line: 302, type: !103)
!2325 = !DILocalVariable(name: "scratch", arg: 2, scope: !2322, file: !3, line: 302, type: !142)
!2326 = !DILocalVariable(name: "total", scope: !2322, file: !3, line: 303, type: !132)
!2327 = !DILocalVariable(name: "rport", scope: !2322, file: !3, line: 304, type: !117)
!2328 = !DILocalVariable(name: "rip", scope: !2322, file: !3, line: 305, type: !2329)
!2329 = !DICompositeType(tag: DW_TAG_array_type, baseType: !138, size: 512, elements: !380)
!2330 = !DILocalVariable(name: "le", scope: !2322, file: !3, line: 306, type: !699)
!2331 = !DILocalVariable(name: "transport_map", scope: !2322, file: !3, line: 307, type: !2332)
!2332 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2162, size: 192, elements: !409)
!2333 = distinct !DIAssignID()
!2334 = !DILocation(line: 0, scope: !2322)
!2335 = !DILocation(line: 305, column: 5, scope: !2322)
!2336 = !DILocation(line: 309, column: 37, scope: !2322)
!2337 = !DILocalVariable(name: "addr", arg: 1, scope: !2338, file: !3, line: 172, type: !718)
!2338 = distinct !DISubprogram(name: "_logger_util_addr_endpoint", scope: !3, file: !3, line: 172, type: !2339, scopeLine: 173, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2342)
!2339 = !DISubroutineType(types: !2340)
!2340 = !{!132, !718, !142, !436, !2341}
!2341 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !117, size: 64)
!2342 = !{!2337, !2343, !2344, !2345}
!2343 = !DILocalVariable(name: "rip", arg: 2, scope: !2338, file: !3, line: 172, type: !142)
!2344 = !DILocalVariable(name: "riplen", arg: 3, scope: !2338, file: !3, line: 173, type: !436)
!2345 = !DILocalVariable(name: "rport", arg: 4, scope: !2338, file: !3, line: 173, type: !2341)
!2346 = !DILocation(line: 0, scope: !2338, inlinedAt: !2347)
!2347 = distinct !DILocation(line: 309, column: 5, scope: !2322)
!2348 = !DILocation(line: 174, column: 5, scope: !2338, inlinedAt: !2347)
!2349 = distinct !DIAssignID()
!2350 = !DILocation(line: 177, column: 19, scope: !2338, inlinedAt: !2347)
!2351 = !{!1841, !1111, i64 0}
!2352 = !DILocation(line: 177, column: 5, scope: !2338, inlinedAt: !2347)
!2353 = !DILocation(line: 179, column: 64, scope: !2354, inlinedAt: !2347)
!2354 = distinct !DILexicalBlock(scope: !2338, file: !3, line: 177, column: 32)
!2355 = !DILocation(line: 179, column: 13, scope: !2354, inlinedAt: !2347)
!2356 = !DILocation(line: 181, column: 22, scope: !2354, inlinedAt: !2347)
!2357 = !{!2358, !1111, i64 2}
!2358 = !{!"sockaddr_in", !1111, i64 0, !1111, i64 2, !2359, i64 4, !1041, i64 8}
!2359 = !{!"in_addr", !1054, i64 0}
!2360 = !DILocation(line: 182, column: 13, scope: !2354, inlinedAt: !2347)
!2361 = !DILocation(line: 184, column: 66, scope: !2354, inlinedAt: !2347)
!2362 = !DILocation(line: 184, column: 13, scope: !2354, inlinedAt: !2347)
!2363 = !DILocation(line: 186, column: 22, scope: !2354, inlinedAt: !2347)
!2364 = !{!1841, !1111, i64 2}
!2365 = !DILocation(line: 187, column: 13, scope: !2354, inlinedAt: !2347)
!2366 = !DILocation(line: 192, column: 13, scope: !2354, inlinedAt: !2347)
!2367 = distinct !DIAssignID()
!2368 = !DILocation(line: 193, column: 13, scope: !2354, inlinedAt: !2347)
!2369 = !DILocation(line: 306, column: 72, scope: !2322)
!2370 = !DILocation(line: 313, column: 32, scope: !2322)
!2371 = !DILocation(line: 313, column: 35, scope: !2322)
!2372 = !DILocation(line: 313, column: 55, scope: !2322)
!2373 = !DILocation(line: 313, column: 43, scope: !2322)
!2374 = !DILocation(line: 313, column: 88, scope: !2322)
!2375 = !DILocation(line: 314, column: 18, scope: !2322)
!2376 = !DILocation(line: 314, column: 43, scope: !2322)
!2377 = !DILocation(line: 314, column: 25, scope: !2322)
!2378 = !DILocation(line: 314, column: 59, scope: !2322)
!2379 = !DILocation(line: 311, column: 13, scope: !2322)
!2380 = !DILocation(line: 317, column: 1, scope: !2322)
!2381 = !DILocation(line: 316, column: 5, scope: !2322)
!2382 = distinct !DISubprogram(name: "_logger_parse_cce", scope: !3, file: !3, line: 319, type: !498, scopeLine: 319, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2383)
!2383 = !{!2384, !2385, !2386, !2387, !2388, !2389, !2390, !2391}
!2384 = !DILocalVariable(name: "e", arg: 1, scope: !2382, file: !3, line: 319, type: !103)
!2385 = !DILocalVariable(name: "scratch", arg: 2, scope: !2382, file: !3, line: 319, type: !142)
!2386 = !DILocalVariable(name: "total", scope: !2382, file: !3, line: 320, type: !132)
!2387 = !DILocalVariable(name: "rport", scope: !2382, file: !3, line: 321, type: !117)
!2388 = !DILocalVariable(name: "rip", scope: !2382, file: !3, line: 322, type: !2329)
!2389 = !DILocalVariable(name: "le", scope: !2382, file: !3, line: 323, type: !699)
!2390 = !DILocalVariable(name: "transport_map", scope: !2382, file: !3, line: 324, type: !2332)
!2391 = !DILocalVariable(name: "reason_map", scope: !2382, file: !3, line: 325, type: !2161)
!2392 = distinct !DIAssignID()
!2393 = !DILocation(line: 0, scope: !2382)
!2394 = !DILocation(line: 322, column: 5, scope: !2382)
!2395 = !DILocation(line: 327, column: 37, scope: !2382)
!2396 = !DILocation(line: 0, scope: !2338, inlinedAt: !2397)
!2397 = distinct !DILocation(line: 327, column: 5, scope: !2382)
!2398 = !DILocation(line: 174, column: 5, scope: !2338, inlinedAt: !2397)
!2399 = distinct !DIAssignID()
!2400 = !DILocation(line: 177, column: 19, scope: !2338, inlinedAt: !2397)
!2401 = !DILocation(line: 177, column: 5, scope: !2338, inlinedAt: !2397)
!2402 = !DILocation(line: 179, column: 64, scope: !2354, inlinedAt: !2397)
!2403 = !DILocation(line: 179, column: 13, scope: !2354, inlinedAt: !2397)
!2404 = !DILocation(line: 181, column: 22, scope: !2354, inlinedAt: !2397)
!2405 = !DILocation(line: 182, column: 13, scope: !2354, inlinedAt: !2397)
!2406 = !DILocation(line: 184, column: 66, scope: !2354, inlinedAt: !2397)
!2407 = !DILocation(line: 184, column: 13, scope: !2354, inlinedAt: !2397)
!2408 = !DILocation(line: 186, column: 22, scope: !2354, inlinedAt: !2397)
!2409 = !DILocation(line: 187, column: 13, scope: !2354, inlinedAt: !2397)
!2410 = !DILocation(line: 192, column: 13, scope: !2354, inlinedAt: !2397)
!2411 = distinct !DIAssignID()
!2412 = !DILocation(line: 193, column: 13, scope: !2354, inlinedAt: !2397)
!2413 = !DILocation(line: 323, column: 72, scope: !2382)
!2414 = !DILocation(line: 331, column: 32, scope: !2382)
!2415 = !DILocation(line: 331, column: 35, scope: !2382)
!2416 = !DILocation(line: 331, column: 55, scope: !2382)
!2417 = !DILocation(line: 331, column: 43, scope: !2382)
!2418 = !DILocation(line: 331, column: 88, scope: !2382)
!2419 = !DILocation(line: 332, column: 18, scope: !2382)
!2420 = !DILocation(line: 332, column: 43, scope: !2382)
!2421 = !DILocation(line: 332, column: 25, scope: !2382)
!2422 = !DILocation(line: 333, column: 28, scope: !2382)
!2423 = !DILocation(line: 333, column: 13, scope: !2382)
!2424 = !DILocation(line: 333, column: 41, scope: !2382)
!2425 = !DILocation(line: 329, column: 13, scope: !2382)
!2426 = !DILocation(line: 336, column: 1, scope: !2382)
!2427 = !DILocation(line: 335, column: 5, scope: !2382)
!2428 = distinct !DISubprogram(name: "_logger_log_item_deleted", scope: !3, file: !3, line: 140, type: !484, scopeLine: 140, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2429)
!2429 = !{!2430, !2431, !2432, !2433, !2434, !2435, !2436}
!2430 = !DILocalVariable(name: "e", arg: 1, scope: !2428, file: !3, line: 140, type: !103)
!2431 = !DILocalVariable(name: "d", arg: 2, scope: !2428, file: !3, line: 140, type: !474)
!2432 = !DILocalVariable(name: "entry", arg: 3, scope: !2428, file: !3, line: 140, type: !486)
!2433 = !DILocalVariable(name: "ap", arg: 4, scope: !2428, file: !3, line: 140, type: !488)
!2434 = !DILocalVariable(name: "it", scope: !2428, file: !3, line: 141, type: !515)
!2435 = !DILocalVariable(name: "comm", scope: !2428, file: !3, line: 142, type: !132)
!2436 = !DILocalVariable(name: "le", scope: !2428, file: !3, line: 143, type: !719)
!2437 = !DILocation(line: 0, scope: !2428)
!2438 = !DILocation(line: 142, column: 16, scope: !2428)
!2439 = !DILocation(line: 143, column: 68, scope: !2428)
!2440 = !DILocation(line: 144, column: 20, scope: !2428)
!2441 = !DILocation(line: 144, column: 9, scope: !2428)
!2442 = !DILocation(line: 144, column: 14, scope: !2428)
!2443 = !DILocation(line: 145, column: 9, scope: !2428)
!2444 = !DILocation(line: 145, column: 13, scope: !2428)
!2445 = !DILocation(line: 146, column: 22, scope: !2428)
!2446 = !DILocation(line: 146, column: 16, scope: !2428)
!2447 = !DILocation(line: 147, column: 17, scope: !2428)
!2448 = !DILocation(line: 147, column: 9, scope: !2428)
!2449 = !DILocation(line: 147, column: 15, scope: !2428)
!2450 = !DILocation(line: 148, column: 16, scope: !2428)
!2451 = !DILocation(line: 148, column: 21, scope: !2428)
!2452 = !DILocation(line: 148, column: 39, scope: !2428)
!2453 = !DILocation(line: 148, column: 35, scope: !2428)
!2454 = !DILocation(line: 148, column: 5, scope: !2428)
!2455 = !DILocation(line: 149, column: 50, scope: !2428)
!2456 = !DILocation(line: 149, column: 48, scope: !2428)
!2457 = !DILocation(line: 149, column: 8, scope: !2428)
!2458 = !DILocation(line: 149, column: 13, scope: !2428)
!2459 = !DILocation(line: 150, column: 1, scope: !2428)
!2460 = distinct !DISubprogram(name: "_logger_parse_ide", scope: !3, file: !3, line: 266, type: !498, scopeLine: 266, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2461)
!2461 = !{!2462, !2463, !2464, !2465, !2466, !2467, !2468}
!2462 = !DILocalVariable(name: "e", arg: 1, scope: !2460, file: !3, line: 266, type: !103)
!2463 = !DILocalVariable(name: "scratch", arg: 2, scope: !2460, file: !3, line: 266, type: !142)
!2464 = !DILocalVariable(name: "total", scope: !2460, file: !3, line: 267, type: !132)
!2465 = !DILocalVariable(name: "cmd", scope: !2460, file: !3, line: 268, type: !1334)
!2466 = !DILocalVariable(name: "cmd_map", scope: !2460, file: !3, line: 269, type: !2332)
!2467 = !DILocalVariable(name: "keybuf", scope: !2460, file: !3, line: 271, type: !2084)
!2468 = !DILocalVariable(name: "le", scope: !2460, file: !3, line: 272, type: !719)
!2469 = distinct !DIAssignID()
!2470 = !DILocation(line: 0, scope: !2460)
!2471 = distinct !DIAssignID()
!2472 = distinct !DIAssignID()
!2473 = !DILocation(line: 271, column: 5, scope: !2460)
!2474 = !DILocation(line: 273, column: 19, scope: !2460)
!2475 = !DILocation(line: 273, column: 36, scope: !2460)
!2476 = !DILocation(line: 273, column: 32, scope: !2460)
!2477 = !DILocation(line: 273, column: 5, scope: !2460)
!2478 = !DILocation(line: 275, column: 13, scope: !2479)
!2479 = distinct !DILexicalBlock(scope: !2460, file: !3, line: 275, column: 9)
!2480 = !DILocation(line: 275, column: 17, scope: !2479)
!2481 = !DILocation(line: 275, column: 9, scope: !2460)
!2482 = !DILocation(line: 276, column: 15, scope: !2479)
!2483 = !DILocation(line: 276, column: 9, scope: !2479)
!2484 = !DILocation(line: 272, column: 68, scope: !2460)
!2485 = !DILocation(line: 280, column: 30, scope: !2460)
!2486 = !DILocation(line: 280, column: 33, scope: !2460)
!2487 = !DILocation(line: 280, column: 52, scope: !2460)
!2488 = !DILocation(line: 280, column: 85, scope: !2460)
!2489 = !DILocation(line: 281, column: 39, scope: !2460)
!2490 = !DILocation(line: 282, column: 26, scope: !2460)
!2491 = !DILocation(line: 282, column: 33, scope: !2460)
!2492 = !DILocation(line: 282, column: 22, scope: !2460)
!2493 = !DILocation(line: 281, column: 35, scope: !2460)
!2494 = !DILocation(line: 280, column: 41, scope: !2460)
!2495 = !DILocation(line: 280, column: 22, scope: !2460)
!2496 = !DILocation(line: 278, column: 13, scope: !2460)
!2497 = !DILocation(line: 284, column: 1, scope: !2460)
!2498 = !DILocation(line: 283, column: 5, scope: !2460)
!2499 = distinct !DISubprogram(name: "_logger_log_ext_write", scope: !3, file: !3, line: 77, type: !484, scopeLine: 77, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2500)
!2500 = !{!2501, !2502, !2503, !2504, !2505, !2506, !2507}
!2501 = !DILocalVariable(name: "e", arg: 1, scope: !2499, file: !3, line: 77, type: !103)
!2502 = !DILocalVariable(name: "d", arg: 2, scope: !2499, file: !3, line: 77, type: !474)
!2503 = !DILocalVariable(name: "entry", arg: 3, scope: !2499, file: !3, line: 77, type: !486)
!2504 = !DILocalVariable(name: "ap", arg: 4, scope: !2499, file: !3, line: 77, type: !488)
!2505 = !DILocalVariable(name: "it", scope: !2499, file: !3, line: 78, type: !515)
!2506 = !DILocalVariable(name: "ew_bucket", scope: !2499, file: !3, line: 79, type: !132)
!2507 = !DILocalVariable(name: "le", scope: !2499, file: !3, line: 81, type: !727)
!2508 = !DILocation(line: 0, scope: !2499)
!2509 = !DILocation(line: 79, column: 21, scope: !2499)
!2510 = !DILocation(line: 82, column: 24, scope: !2499)
!2511 = !DILocation(line: 82, column: 32, scope: !2499)
!2512 = !DILocation(line: 82, column: 19, scope: !2499)
!2513 = !DILocation(line: 82, column: 69, scope: !2499)
!2514 = !DILocation(line: 82, column: 67, scope: !2499)
!2515 = !DILocation(line: 82, column: 39, scope: !2499)
!2516 = !DILocation(line: 81, column: 70, scope: !2499)
!2517 = !DILocation(line: 82, column: 17, scope: !2499)
!2518 = !DILocation(line: 83, column: 18, scope: !2499)
!2519 = !DILocation(line: 83, column: 37, scope: !2499)
!2520 = !DILocation(line: 83, column: 31, scope: !2499)
!2521 = !DILocation(line: 83, column: 9, scope: !2499)
!2522 = !DILocation(line: 83, column: 16, scope: !2499)
!2523 = !DILocation(line: 84, column: 24, scope: !2499)
!2524 = !DILocation(line: 84, column: 9, scope: !2499)
!2525 = !DILocation(line: 84, column: 18, scope: !2499)
!2526 = !DILocation(line: 85, column: 20, scope: !2499)
!2527 = !DILocation(line: 85, column: 9, scope: !2499)
!2528 = !DILocation(line: 85, column: 14, scope: !2499)
!2529 = !DILocation(line: 86, column: 17, scope: !2499)
!2530 = !DILocation(line: 86, column: 9, scope: !2499)
!2531 = !DILocation(line: 86, column: 15, scope: !2499)
!2532 = !DILocation(line: 87, column: 18, scope: !2499)
!2533 = !DILocation(line: 87, column: 9, scope: !2499)
!2534 = !DILocation(line: 87, column: 16, scope: !2499)
!2535 = !DILocation(line: 88, column: 16, scope: !2499)
!2536 = !DILocation(line: 88, column: 21, scope: !2499)
!2537 = !DILocation(line: 88, column: 39, scope: !2499)
!2538 = !DILocation(line: 88, column: 35, scope: !2499)
!2539 = !DILocation(line: 88, column: 5, scope: !2499)
!2540 = !DILocation(line: 89, column: 51, scope: !2499)
!2541 = !DILocation(line: 89, column: 49, scope: !2499)
!2542 = !DILocation(line: 89, column: 8, scope: !2499)
!2543 = !DILocation(line: 89, column: 13, scope: !2499)
!2544 = !DILocation(line: 90, column: 1, scope: !2499)
!2545 = distinct !DISubprogram(name: "_logger_parse_extw", scope: !3, file: !3, line: 287, type: !498, scopeLine: 287, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2546)
!2546 = !{!2547, !2548, !2549, !2550, !2551}
!2547 = !DILocalVariable(name: "e", arg: 1, scope: !2545, file: !3, line: 287, type: !103)
!2548 = !DILocalVariable(name: "scratch", arg: 2, scope: !2545, file: !3, line: 287, type: !142)
!2549 = !DILocalVariable(name: "total", scope: !2545, file: !3, line: 288, type: !132)
!2550 = !DILocalVariable(name: "keybuf", scope: !2545, file: !3, line: 289, type: !2084)
!2551 = !DILocalVariable(name: "le", scope: !2545, file: !3, line: 290, type: !727)
!2552 = distinct !DIAssignID()
!2553 = !DILocation(line: 0, scope: !2545)
!2554 = !DILocation(line: 289, column: 5, scope: !2545)
!2555 = !DILocation(line: 290, column: 70, scope: !2545)
!2556 = !DILocation(line: 291, column: 19, scope: !2545)
!2557 = !DILocation(line: 291, column: 36, scope: !2545)
!2558 = !DILocation(line: 291, column: 32, scope: !2545)
!2559 = !DILocation(line: 291, column: 5, scope: !2545)
!2560 = !DILocation(line: 294, column: 31, scope: !2545)
!2561 = !DILocation(line: 294, column: 34, scope: !2545)
!2562 = !DILocation(line: 294, column: 53, scope: !2545)
!2563 = !DILocation(line: 294, column: 42, scope: !2545)
!2564 = !DILocation(line: 294, column: 86, scope: !2545)
!2565 = !DILocation(line: 295, column: 26, scope: !2545)
!2566 = !DILocation(line: 295, column: 35, scope: !2545)
!2567 = !DILocation(line: 295, column: 21, scope: !2545)
!2568 = !DILocation(line: 296, column: 32, scope: !2545)
!2569 = !DILocation(line: 296, column: 45, scope: !2545)
!2570 = !DILocation(line: 296, column: 57, scope: !2545)
!2571 = !DILocation(line: 296, column: 53, scope: !2545)
!2572 = !DILocation(line: 296, column: 68, scope: !2545)
!2573 = !DILocation(line: 296, column: 64, scope: !2545)
!2574 = !DILocation(line: 292, column: 13, scope: !2545)
!2575 = !DILocation(line: 299, column: 1, scope: !2545)
!2576 = !DILocation(line: 298, column: 5, scope: !2545)
!2577 = !DISubprogram(name: "vsnprintf", scope: !1280, file: !1280, line: 389, type: !2578, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2578 = !DISubroutineType(types: !2579)
!2579 = !{!132, !1921, !436, !1333, !488}
!2580 = !DISubprogram(name: "uriencode", scope: !2581, file: !2581, line: 5, type: !2582, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2581 = !DIFile(filename: "./util.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d1ef68c688867746f50aae7567be079a")
!2582 = !DISubroutineType(types: !2583)
!2583 = !{!154, !1334, !142, !2584, !2584}
!2584 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !436)
!2585 = !DISubprogram(name: "inet_ntop", scope: !2586, file: !2586, line: 64, type: !2587, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2586 = !DIFile(filename: "/usr/include/arpa/inet.h", directory: "", checksumkind: CSK_MD5, checksum: "b41e79d47594306dd2fedce21a947f9d")
!2587 = !DISubroutineType(types: !2588)
!2588 = !{!1334, !132, !1978, !1921, !583}
