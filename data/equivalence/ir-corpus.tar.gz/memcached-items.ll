; ModuleID = 'items.c'
source_filename = "items.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%union.pthread_mutex_t = type { %struct.__pthread_mutex_s }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i16, i16, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%struct.itemstats_t = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i32 }
%struct.settings = type { i64, i32, i32, i32, ptr, i32, i32, i32, ptr, ptr, i32, double, i32, i32, i32, i8, i32, i32, i8, i32, i32, i32, i32, i32, i32, i8, i8, i8, i8, i8, i8, i32, double, i32, i32, i8, i32, i8, i8, ptr, i32, i32, i32, i32, double, double, i32, i8, i32, i32, i32, i32, i32, i8, i8, i8, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, double, double, i8, i32, i32, ptr, i32 }
%struct.stats_state = type { i64, i64, i64, i64, i32, i32, i32, i32, i8, i8, i8, i8 }
%struct.stats = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, %struct.timeval, i64, i64 }
%struct.timeval = type { i64, i64 }
%struct.slab_automove_reg_t = type { ptr, ptr, ptr }
%struct.item_stats_automove = type { i64, i64, i32 }
%struct.thread_stats = type { %union.pthread_mutex_t, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, [64 x %struct.slab_stats], [256 x i64], i64, i64, i64 }
%struct.slab_stats = type { i64, i64, i64, i64, i64, i64, i64, i64 }
%struct.crawlerstats_t = type { [61 x i64], i64, i64, i64, i64, i32, i32, i8 }

@lru_locks = external global [256 x %union.pthread_mutex_t], align 16
@itemstats = internal unnamed_addr global [256 x %struct.itemstats_t] zeroinitializer, align 16, !dbg !0
@cas_id_lock = internal global %union.pthread_mutex_t zeroinitializer, align 8, !dbg !552
@cas_id = internal unnamed_addr global i64 1, align 8, !dbg !554
@settings = external global %struct.settings, align 8
@current_time = external global i32, align 4
@sizes = internal unnamed_addr global [256 x i32] zeroinitializer, align 16, !dbg !543
@hash = external local_unnamed_addr global ptr, align 8
@heads = internal unnamed_addr global [256 x ptr] zeroinitializer, align 16, !dbg !536
@tails = internal unnamed_addr global [256 x ptr] zeroinitializer, align 16, !dbg !541
@sizes_bytes = internal unnamed_addr global [256 x i64] zeroinitializer, align 16, !dbg !546
@stats_state = external local_unnamed_addr global %struct.stats_state, align 8
@stats = external local_unnamed_addr global %struct.stats, align 8
@ext_storage = external local_unnamed_addr global ptr, align 8
@.str = private unnamed_addr constant [25 x i8] c"ITEM %s [%d b; %llu s]\0D\0A\00", align 1, !dbg !269
@process_started = external local_unnamed_addr global i64, align 8
@.str.1 = private unnamed_addr constant [6 x i8] c"END\0D\0A\00", align 1, !dbg !274
@lru_type_map = internal unnamed_addr constant [4 x i32] [i32 0, i32 64, i32 128, i32 192], align 16, !dbg !556
@.str.2 = private unnamed_addr constant [18 x i8] c"expired_unfetched\00", align 1, !dbg !279
@.str.3 = private unnamed_addr constant [5 x i8] c"%llu\00", align 1, !dbg !284
@.str.4 = private unnamed_addr constant [18 x i8] c"evicted_unfetched\00", align 1, !dbg !289
@.str.5 = private unnamed_addr constant [15 x i8] c"evicted_active\00", align 1, !dbg !291
@.str.6 = private unnamed_addr constant [10 x i8] c"evictions\00", align 1, !dbg !296
@.str.7 = private unnamed_addr constant [10 x i8] c"reclaimed\00", align 1, !dbg !301
@.str.8 = private unnamed_addr constant [18 x i8] c"crawler_reclaimed\00", align 1, !dbg !303
@.str.9 = private unnamed_addr constant [22 x i8] c"crawler_items_checked\00", align 1, !dbg !305
@.str.10 = private unnamed_addr constant [18 x i8] c"lrutail_reflocked\00", align 1, !dbg !310
@.str.11 = private unnamed_addr constant [14 x i8] c"moves_to_cold\00", align 1, !dbg !312
@.str.12 = private unnamed_addr constant [14 x i8] c"moves_to_warm\00", align 1, !dbg !317
@.str.13 = private unnamed_addr constant [17 x i8] c"moves_within_lru\00", align 1, !dbg !319
@.str.14 = private unnamed_addr constant [16 x i8] c"direct_reclaims\00", align 1, !dbg !324
@.str.15 = private unnamed_addr constant [18 x i8] c"lru_bumps_dropped\00", align 1, !dbg !329
@.str.16 = private unnamed_addr constant [12 x i8] c"items:%d:%s\00", align 1, !dbg !331
@.str.17 = private unnamed_addr constant [7 x i8] c"number\00", align 1, !dbg !336
@.str.18 = private unnamed_addr constant [3 x i8] c"%u\00", align 1, !dbg !341
@.str.19 = private unnamed_addr constant [11 x i8] c"number_hot\00", align 1, !dbg !346
@.str.20 = private unnamed_addr constant [12 x i8] c"number_warm\00", align 1, !dbg !351
@.str.21 = private unnamed_addr constant [12 x i8] c"number_cold\00", align 1, !dbg !353
@.str.22 = private unnamed_addr constant [12 x i8] c"number_temp\00", align 1, !dbg !355
@.str.23 = private unnamed_addr constant [8 x i8] c"age_hot\00", align 1, !dbg !357
@.str.24 = private unnamed_addr constant [9 x i8] c"age_warm\00", align 1, !dbg !362
@.str.25 = private unnamed_addr constant [4 x i8] c"age\00", align 1, !dbg !367
@.str.26 = private unnamed_addr constant [14 x i8] c"mem_requested\00", align 1, !dbg !372
@.str.27 = private unnamed_addr constant [8 x i8] c"evicted\00", align 1, !dbg !374
@.str.28 = private unnamed_addr constant [16 x i8] c"evicted_nonzero\00", align 1, !dbg !376
@.str.29 = private unnamed_addr constant [13 x i8] c"evicted_time\00", align 1, !dbg !378
@.str.30 = private unnamed_addr constant [12 x i8] c"outofmemory\00", align 1, !dbg !383
@.str.31 = private unnamed_addr constant [12 x i8] c"tailrepairs\00", align 1, !dbg !385
@.str.32 = private unnamed_addr constant [12 x i8] c"hits_to_hot\00", align 1, !dbg !387
@.str.33 = private unnamed_addr constant [13 x i8] c"hits_to_warm\00", align 1, !dbg !389
@.str.34 = private unnamed_addr constant [13 x i8] c"hits_to_cold\00", align 1, !dbg !391
@.str.35 = private unnamed_addr constant [13 x i8] c"hits_to_temp\00", align 1, !dbg !393
@stats_sizes_hist = internal unnamed_addr global ptr null, align 8, !dbg !559
@stats_sizes_buckets = internal unnamed_addr global i32 0, align 4, !dbg !562
@.str.36 = private unnamed_addr constant [3 x i8] c"%d\00", align 1, !dbg !395
@.str.37 = private unnamed_addr constant [13 x i8] c"sizes_status\00", align 1, !dbg !397
@.str.38 = private unnamed_addr constant [9 x i8] c"disabled\00", align 1, !dbg !399
@.str.39 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1, !dbg !401
@stderr = external local_unnamed_addr global ptr, align 8
@.str.40 = private unnamed_addr constant [13 x i8] c"> NOT FOUND \00", align 1, !dbg !406
@.str.43 = private unnamed_addr constant [17 x i8] c" -nuked by flush\00", align 1, !dbg !412
@.str.44 = private unnamed_addr constant [18 x i8] c" -nuked by expire\00", align 1, !dbg !414
@logger_key = external local_unnamed_addr global i32, align 4
@slab_automove_default = dso_local local_unnamed_addr global %struct.slab_automove_reg_t { ptr @slab_automove_init, ptr @slab_automove_free, ptr @slab_automove_run }, align 8, !dbg !421
@slab_automove_extstore = dso_local local_unnamed_addr global %struct.slab_automove_reg_t { ptr @slab_automove_extstore_init, ptr @slab_automove_extstore_free, ptr @slab_automove_extstore_run }, align 8, !dbg !525
@lru_maintainer_lock = internal global %union.pthread_mutex_t zeroinitializer, align 8, !dbg !580
@do_run_lru_maintainer_thread = internal global i32 0, align 4, !dbg !582
@lru_maintainer_tid = internal global i64 0, align 8, !dbg !549
@.str.46 = private unnamed_addr constant [42 x i8] c"Failed to stop LRU maintainer thread: %s\0A\00", align 1, !dbg !527
@.str.47 = private unnamed_addr constant [40 x i8] c"Can't create LRU maintainer thread: %s\0A\00", align 1, !dbg !532
@.str.48 = private unnamed_addr constant [12 x i8] c"mc-lrumaint\00", align 1, !dbg !534
@bump_buf_lock = internal global %union.pthread_mutex_t zeroinitializer, align 8, !dbg !564
@bump_buf_head = internal unnamed_addr global ptr null, align 8, !dbg !566
@bump_buf_tail = internal unnamed_addr global ptr null, align 8, !dbg !578
@.str.49 = private unnamed_addr constant [59 x i8] c"Failed to allocate crawler data for LRU maintainer thread\0A\00", align 1, !dbg !585
@.str.50 = private unnamed_addr constant [53 x i8] c"Failed to allocate logger for LRU maintainer thread\0A\00", align 1, !dbg !590
@.str.51 = private unnamed_addr constant [43 x i8] c"Starting LRU maintainer background thread\0A\00", align 1, !dbg !595
@.str.52 = private unnamed_addr constant [32 x i8] c"LRU maintainer thread stopping\0A\00", align 1, !dbg !600
@lru_maintainer_crawler_check.next_crawls = internal unnamed_addr global [256 x i32] zeroinitializer, align 16, !dbg !605
@lru_maintainer_crawler_check.next_crawl_wait = internal unnamed_addr global [256 x i32] zeroinitializer, align 16, !dbg !659
@.str.54 = private unnamed_addr constant [4 x i8] c"hot\00", align 1, !dbg !663
@.str.55 = private unnamed_addr constant [5 x i8] c"warm\00", align 1, !dbg !665
@.str.56 = private unnamed_addr constant [5 x i8] c"cold\00", align 1, !dbg !667
@.str.57 = private unnamed_addr constant [5 x i8] c"temp\00", align 1, !dbg !669
@reltable.lru_maintainer_thread = private unnamed_addr constant [4 x i32] [i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.54 to i64), i64 ptrtoint (ptr @reltable.lru_maintainer_thread to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.55 to i64), i64 ptrtoint (ptr @reltable.lru_maintainer_thread to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.56 to i64), i64 ptrtoint (ptr @reltable.lru_maintainer_thread to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.57 to i64), i64 ptrtoint (ptr @reltable.lru_maintainer_thread to i64)) to i32)], align 4
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @item_stats_reset() local_unnamed_addr #0 !dbg !704 {
entry:
  tail call void @llvm.dbg.value(metadata i32 0, metadata !708, metadata !DIExpression()), !dbg !709
  br label %for.body, !dbg !710

for.body:                                         ; preds = %entry, %for.body
  %indvars.iv = phi i64 [ 0, %entry ], [ %indvars.iv.next, %for.body ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !708, metadata !DIExpression()), !dbg !709
  %arrayidx = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %indvars.iv, !dbg !712
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx) #21, !dbg !715
  %arrayidx2 = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %indvars.iv, !dbg !716
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(168) %arrayidx2, i8 0, i64 168, i1 false), !dbg !717
  %call5 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #21, !dbg !718
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !719
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !708, metadata !DIExpression()), !dbg !709
  %exitcond.not = icmp eq i64 %indvars.iv.next, 256, !dbg !720
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !710, !llvm.loop !721

for.end:                                          ; preds = %for.body
  ret void, !dbg !724
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nounwind
declare !dbg !725 i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: nounwind
declare !dbg !730 i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, argmem: none, inaccessiblemem: none) uwtable
define dso_local void @do_item_stats_add_crawl(i32 noundef %i, i64 noundef %reclaimed, i64 noundef %unfetched, i64 noundef %checked) local_unnamed_addr #4 !dbg !731 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %i, metadata !737, metadata !DIExpression()), !dbg !741
  tail call void @llvm.dbg.value(metadata i64 %reclaimed, metadata !738, metadata !DIExpression()), !dbg !741
  tail call void @llvm.dbg.value(metadata i64 %unfetched, metadata !739, metadata !DIExpression()), !dbg !741
  tail call void @llvm.dbg.value(metadata i64 %checked, metadata !740, metadata !DIExpression()), !dbg !741
  %idxprom = sext i32 %i to i64, !dbg !742
  %arrayidx = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %idxprom, !dbg !742
  %crawler_reclaimed = getelementptr inbounds i8, ptr %arrayidx, i64 64, !dbg !743
  %0 = load i64, ptr %crawler_reclaimed, align 8, !dbg !744, !tbaa !745
  %add = add i64 %0, %reclaimed, !dbg !744
  store i64 %add, ptr %crawler_reclaimed, align 8, !dbg !744, !tbaa !745
  %expired_unfetched = getelementptr inbounds i8, ptr %arrayidx, i64 40, !dbg !751
  %1 = load i64, ptr %expired_unfetched, align 8, !dbg !752, !tbaa !753
  %add3 = add i64 %1, %unfetched, !dbg !752
  store i64 %add3, ptr %expired_unfetched, align 8, !dbg !752, !tbaa !753
  %crawler_items_checked = getelementptr inbounds i8, ptr %arrayidx, i64 72, !dbg !754
  %2 = load i64, ptr %crawler_items_checked, align 8, !dbg !755, !tbaa !756
  %add6 = add i64 %2, %checked, !dbg !755
  store i64 %add6, ptr %crawler_items_checked, align 8, !dbg !755, !tbaa !756
  ret void, !dbg !757
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local i64 @get_cas_id() local_unnamed_addr #0 !dbg !758 {
entry:
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @cas_id_lock) #21, !dbg !763
  %0 = load i64, ptr @cas_id, align 8, !dbg !764, !tbaa !765
  %inc = add i64 %0, 1, !dbg !764
  store i64 %inc, ptr @cas_id, align 8, !dbg !764, !tbaa !765
  tail call void @llvm.dbg.value(metadata i64 %inc, metadata !762, metadata !DIExpression()), !dbg !766
  %call1 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @cas_id_lock) #21, !dbg !767
  ret i64 %inc, !dbg !768
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @set_cas_id(i64 noundef %new_cas) local_unnamed_addr #0 !dbg !769 {
entry:
  tail call void @llvm.dbg.value(metadata i64 %new_cas, metadata !773, metadata !DIExpression()), !dbg !774
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @cas_id_lock) #21, !dbg !775
  store i64 %new_cas, ptr @cas_id, align 8, !dbg !776, !tbaa !765
  %call1 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @cas_id_lock) #21, !dbg !777
  ret void, !dbg !778
}

; Function Attrs: mustprogress nofree norecurse nounwind sanitize_thread willreturn memory(readwrite, argmem: read) uwtable
define dso_local range(i32 0, 2) i32 @item_is_flushed(ptr nocapture noundef readonly %it) local_unnamed_addr #5 !dbg !779 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !783, metadata !DIExpression()), !dbg !785
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 6), align 4, !dbg !786, !tbaa !787
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !784, metadata !DIExpression()), !dbg !785
  %time = getelementptr inbounds i8, ptr %it, i64 24, !dbg !792
  %1 = load i32, ptr %time, align 8, !dbg !792, !tbaa !794
  %cmp.not = icmp ugt i32 %1, %0, !dbg !795
  br i1 %cmp.not, label %if.end, label %land.lhs.true, !dbg !796

land.lhs.true:                                    ; preds = %entry
  %2 = load volatile i32, ptr @current_time, align 4, !dbg !797, !tbaa !794
  %cmp1.not = icmp ugt i32 %0, %2, !dbg !798
  br i1 %cmp1.not, label %if.end, label %cleanup, !dbg !799

if.end:                                           ; preds = %land.lhs.true, %entry
  br label %cleanup, !dbg !800

cleanup:                                          ; preds = %land.lhs.true, %if.end
  %retval.0 = phi i32 [ 0, %if.end ], [ 1, %land.lhs.true ], !dbg !785
  ret i32 %retval.0, !dbg !801
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @do_get_lru_size(i32 noundef %id) local_unnamed_addr #6 !dbg !802 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %id, metadata !806, metadata !DIExpression()), !dbg !807
  %idxprom = zext i32 %id to i64, !dbg !808
  %arrayidx = getelementptr inbounds [256 x i32], ptr @sizes, i64 0, i64 %idxprom, !dbg !808
  %0 = load i32, ptr %arrayidx, align 4, !dbg !808, !tbaa !794
  ret i32 %0, !dbg !809
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local ptr @do_item_alloc_pull(i64 noundef %ntotal, i32 noundef %id) local_unnamed_addr #0 !dbg !810 {
entry:
  tail call void @llvm.dbg.value(metadata i64 %ntotal, metadata !816, metadata !DIExpression()), !dbg !820
  tail call void @llvm.dbg.value(metadata i32 %id, metadata !817, metadata !DIExpression()), !dbg !820
  tail call void @llvm.dbg.value(metadata ptr null, metadata !818, metadata !DIExpression()), !dbg !820
  tail call void @llvm.dbg.value(metadata i32 0, metadata !819, metadata !DIExpression()), !dbg !820
  br label %for.body, !dbg !821

for.body:                                         ; preds = %entry, %for.inc
  %i.039 = phi i32 [ 0, %entry ], [ %inc, %for.inc ]
  tail call void @llvm.dbg.value(metadata i32 %i.039, metadata !819, metadata !DIExpression()), !dbg !820
  %0 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 29), align 8, !dbg !823, !tbaa !827, !range !828, !noundef !829
  %tobool = trunc nuw i8 %0 to i1, !dbg !823
  br i1 %tobool, label %if.end, label %if.then, !dbg !830

if.then:                                          ; preds = %for.body
  %call = tail call i32 @lru_pull_tail(i32 noundef %id, i32 noundef 128, i64 noundef 0, i8 noundef zeroext 0, i32 noundef 0, ptr noundef null), !dbg !831
  br label %if.end, !dbg !833

if.end:                                           ; preds = %if.then, %for.body
  %call1 = tail call ptr @slabs_alloc(i64 noundef %ntotal, i32 noundef %id, i32 noundef 0) #21, !dbg !834
  tail call void @llvm.dbg.value(metadata ptr %call1, metadata !818, metadata !DIExpression()), !dbg !820
  %cmp2 = icmp eq ptr %call1, null, !dbg !835
  br i1 %cmp2, label %if.then3, label %for.end, !dbg !837

if.then3:                                         ; preds = %if.end
  %call4 = tail call i32 @lru_pull_tail(i32 noundef %id, i32 noundef 128, i64 noundef 0, i8 noundef zeroext 1, i32 noundef 0, ptr noundef null), !dbg !838
  %cmp5 = icmp slt i32 %call4, 1, !dbg !841
  br i1 %cmp5, label %if.then6, label %for.inc, !dbg !842

if.then6:                                         ; preds = %if.then3
  %1 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 29), align 8, !dbg !843, !tbaa !827, !range !828, !noundef !829
  %tobool7 = trunc nuw i8 %1 to i1, !dbg !843
  br i1 %tobool7, label %if.then8, label %for.end, !dbg !846

if.then8:                                         ; preds = %if.then6
  %call9 = tail call i32 @lru_pull_tail(i32 noundef %id, i32 noundef 0, i64 noundef 0, i8 noundef zeroext 0, i32 noundef 0, ptr noundef null), !dbg !847
  br label %for.inc, !dbg !849

for.inc:                                          ; preds = %if.then8, %if.then3
  %inc = add nuw nsw i32 %i.039, 1, !dbg !850
  tail call void @llvm.dbg.value(metadata i32 %inc, metadata !819, metadata !DIExpression()), !dbg !820
  tail call void @llvm.dbg.value(metadata ptr null, metadata !818, metadata !DIExpression()), !dbg !820
  %exitcond.not = icmp eq i32 %inc, 10, !dbg !851
  br i1 %exitcond.not, label %if.then15, label %for.body, !dbg !821, !llvm.loop !852

for.end:                                          ; preds = %if.end, %if.then6
  tail call void @llvm.dbg.value(metadata ptr %call1, metadata !818, metadata !DIExpression()), !dbg !820
  %cmp14.not = icmp eq i32 %i.039, 0, !dbg !854
  br i1 %cmp14.not, label %if.end22, label %if.then15, !dbg !856

if.then15:                                        ; preds = %for.inc, %for.end
  %i.038 = phi i32 [ %i.039, %for.end ], [ 10, %for.inc ]
  %it.135 = phi ptr [ %call1, %for.end ], [ null, %for.inc ]
  %idxprom = zext i32 %id to i64, !dbg !857
  %arrayidx = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom, !dbg !857
  %call16 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx) #21, !dbg !859
  %conv = zext nneg i32 %i.038 to i64
  %direct_reclaims = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %idxprom, i32 14, !dbg !860
  %2 = load i64, ptr %direct_reclaims, align 8, !dbg !861, !tbaa !862
  %add = add i64 %2, %conv, !dbg !861
  store i64 %add, ptr %direct_reclaims, align 8, !dbg !861, !tbaa !862
  %call21 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #21, !dbg !863
  br label %if.end22, !dbg !864

if.end22:                                         ; preds = %if.then15, %for.end
  %it.136 = phi ptr [ %it.135, %if.then15 ], [ %call1, %for.end ]
  ret ptr %it.136, !dbg !865
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local i32 @lru_pull_tail(i32 noundef %orig_id, i32 noundef %cur_lru, i64 noundef %total_bytes, i8 noundef zeroext %flags, i32 noundef %max_age, ptr nocapture noundef writeonly %ret_it) local_unnamed_addr #0 !dbg !866 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %orig_id, metadata !878, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 %cur_lru, metadata !879, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i64 %total_bytes, metadata !880, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i8 %flags, metadata !881, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 %max_age, metadata !882, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr %ret_it, metadata !883, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr null, metadata !884, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 %orig_id, metadata !885, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 0, metadata !886, metadata !DIExpression()), !dbg !902
  %cmp = icmp eq i32 %orig_id, 0, !dbg !903
  br i1 %cmp, label %cleanup251, label %if.end, !dbg !905

if.end:                                           ; preds = %entry
  tail call void @llvm.dbg.value(metadata i32 5, metadata !887, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr null, metadata !890, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 0, metadata !891, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i64 0, metadata !892, metadata !DIExpression()), !dbg !902
  %or = or i32 %cur_lru, %orig_id, !dbg !906
  tail call void @llvm.dbg.value(metadata i32 %or, metadata !885, metadata !DIExpression()), !dbg !902
  %idxprom = sext i32 %or to i64, !dbg !907
  %arrayidx = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom, !dbg !907
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx) #21, !dbg !908
  %arrayidx2 = getelementptr inbounds [256 x ptr], ptr @tails, i64 0, i64 %idxprom, !dbg !909
  %0 = load ptr, ptr %arrayidx2, align 8, !dbg !909, !tbaa !910
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !888, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i64 0, metadata !892, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 0, metadata !891, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !890, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr null, metadata !884, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 5, metadata !887, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 0, metadata !886, metadata !DIExpression()), !dbg !902
  %cmp4.not453 = icmp eq ptr %0, null
  br i1 %cmp4.not453, label %for.end, label %for.body.lr.ph, !dbg !911

for.body.lr.ph:                                   ; preds = %if.end
  %arrayidx38 = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %idxprom
  %lrutail_reflocked = getelementptr inbounds i8, ptr %arrayidx38, i64 80
  %tailrepairs = getelementptr inbounds i8, ptr %arrayidx38, i64 32
  %reclaimed = getelementptr inbounds i8, ptr %arrayidx38, i64 16
  %expired_unfetched = getelementptr inbounds i8, ptr %arrayidx38, i64 40
  %1 = tail call i32 @llvm.fshl.i32(i32 %cur_lru, i32 %cur_lru, i32 26)
  %cmp98 = icmp eq i32 %cur_lru, 64
  %moves_within_lru = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %idxprom, i32 13
  %2 = and i8 %flags, 2
  %tobool.not = icmp eq i8 %2, 0
  br label %for.body, !dbg !911

for.body:                                         ; preds = %for.body.lr.ph, %for.inc
  %limit.0457 = phi i64 [ 0, %for.body.lr.ph ], [ %limit.5, %for.inc ]
  %search.0456 = phi ptr [ %0, %for.body.lr.ph ], [ %3, %for.inc ]
  %tries.0455 = phi i32 [ 5, %for.body.lr.ph ], [ %dec, %for.inc ]
  %removed.0454 = phi i32 [ 0, %for.body.lr.ph ], [ %removed.3, %for.inc ]
  tail call void @llvm.dbg.value(metadata i64 %limit.0457, metadata !892, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr %search.0456, metadata !888, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 %tries.0455, metadata !887, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 %removed.0454, metadata !886, metadata !DIExpression()), !dbg !902
  %prev = getelementptr inbounds i8, ptr %search.0456, i64 8, !dbg !912
  %3 = load ptr, ptr %prev, align 8, !dbg !912, !tbaa !910
  tail call void @llvm.dbg.value(metadata ptr %3, metadata !889, metadata !DIExpression()), !dbg !902
  %nbytes = getelementptr inbounds i8, ptr %search.0456, i64 32, !dbg !913
  %4 = load i32, ptr %nbytes, align 8, !dbg !913, !tbaa !794
  %cmp5 = icmp eq i32 %4, 0, !dbg !915
  %nkey = getelementptr inbounds i8, ptr %search.0456, i64 41
  %5 = load i8, ptr %nkey, align 1, !dbg !916, !tbaa !917
  %cmp6 = icmp eq i8 %5, 0
  %or.cond545 = select i1 %cmp5, i1 %cmp6, i1 false, !dbg !918
  br i1 %or.cond545, label %land.lhs.true8, label %if.end19, !dbg !918

land.lhs.true8:                                   ; preds = %for.body
  %it_flags = getelementptr inbounds i8, ptr %search.0456, i64 38, !dbg !919
  %6 = load i16, ptr %it_flags, align 2, !dbg !919, !tbaa !920
  %cmp10 = icmp eq i16 %6, 1, !dbg !922
  br i1 %cmp10, label %if.then12, label %if.end19, !dbg !923

if.then12:                                        ; preds = %land.lhs.true8
  br i1 %tobool.not, label %if.end18, label %if.then14, !dbg !924

if.then14:                                        ; preds = %if.then12
  %call17 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #21, !dbg !926
  br label %cleanup251, !dbg !929

if.end18:                                         ; preds = %if.then12
  %inc = add nuw nsw i32 %tries.0455, 1, !dbg !930
  tail call void @llvm.dbg.value(metadata i32 %inc, metadata !887, metadata !DIExpression()), !dbg !902
  br label %for.inc, !dbg !931

if.end19:                                         ; preds = %for.body, %land.lhs.true8
  %7 = phi i8 [ 0, %land.lhs.true8 ], [ %5, %for.body ], !dbg !932
  %8 = load ptr, ptr @hash, align 8, !dbg !933, !tbaa !910
  %data = getelementptr inbounds i8, ptr %search.0456, i64 48, !dbg !934
  %it_flags20 = getelementptr inbounds i8, ptr %search.0456, i64 38, !dbg !934
  %9 = load i16, ptr %it_flags20, align 2, !dbg !934, !tbaa !920
  %10 = shl i16 %9, 2, !dbg !934
  %11 = and i16 %10, 8, !dbg !934
  %cond = zext nneg i16 %11 to i64, !dbg !934
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %cond, !dbg !934
  %nkey24 = getelementptr inbounds i8, ptr %search.0456, i64 41, !dbg !932
  %conv25 = zext i8 %7 to i64, !dbg !935
  %call26 = tail call i32 %8(ptr noundef nonnull %add.ptr, i64 noundef %conv25) #21, !dbg !933
  tail call void @llvm.dbg.value(metadata i32 %call26, metadata !893, metadata !DIExpression()), !dbg !916
  %call27 = tail call ptr @item_trylock(i32 noundef %call26) #21, !dbg !936
  tail call void @llvm.dbg.value(metadata ptr %call27, metadata !890, metadata !DIExpression()), !dbg !902
  %cmp28 = icmp eq ptr %call27, null, !dbg !938
  br i1 %cmp28, label %for.inc, label %if.end31, !dbg !939

if.end31:                                         ; preds = %if.end19
  %refcount = getelementptr inbounds i8, ptr %search.0456, i64 36, !dbg !940
  %12 = load i16, ptr %refcount, align 4, !dbg !940, !tbaa !920
  %inc32 = add i16 %12, 1, !dbg !940
  store i16 %inc32, ptr %refcount, align 4, !dbg !940, !tbaa !920
  %cmp34.not = icmp eq i16 %inc32, 2, !dbg !942
  br i1 %cmp34.not, label %if.end50, label %if.then36, !dbg !943

if.then36:                                        ; preds = %if.end31
  %13 = load i64, ptr %lrutail_reflocked, align 8, !dbg !944, !tbaa !946
  %inc39 = add i64 %13, 1, !dbg !944
  store i64 %inc39, ptr %lrutail_reflocked, align 8, !dbg !944, !tbaa !946
  %14 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 36), align 4, !dbg !947, !tbaa !949
  %tobool40.not = icmp eq i32 %14, 0, !dbg !950
  br i1 %tobool40.not, label %if.end50, label %land.lhs.true41, !dbg !951

land.lhs.true41:                                  ; preds = %if.then36
  %time = getelementptr inbounds i8, ptr %search.0456, i64 24, !dbg !952
  %15 = load i32, ptr %time, align 8, !dbg !952, !tbaa !794
  %add = add i32 %15, %14, !dbg !953
  %16 = load volatile i32, ptr @current_time, align 4, !dbg !954, !tbaa !794
  %cmp42 = icmp ult i32 %add, %16, !dbg !955
  br i1 %cmp42, label %if.then44, label %if.end50, !dbg !956

if.then44:                                        ; preds = %land.lhs.true41
  %17 = load i64, ptr %tailrepairs, align 8, !dbg !957, !tbaa !959
  %inc47 = add i64 %17, 1, !dbg !957
  store i64 %inc47, ptr %tailrepairs, align 8, !dbg !957, !tbaa !959
  store i16 1, ptr %refcount, align 4, !dbg !960, !tbaa !920
  %18 = load ptr, ptr @ext_storage, align 8, !dbg !961, !tbaa !910
  tail call void @storage_delete(ptr noundef %18, ptr noundef nonnull %search.0456) #21, !dbg !961
  tail call void @do_item_unlink_nolock(ptr noundef nonnull %search.0456, i32 noundef %call26), !dbg !963
  tail call void @item_trylock_unlock(ptr noundef nonnull %call27) #21, !dbg !964
  br label %for.inc, !dbg !965

if.end50:                                         ; preds = %if.then36, %land.lhs.true41, %if.end31
  %exptime = getelementptr inbounds i8, ptr %search.0456, i64 28, !dbg !966
  %19 = load i32, ptr %exptime, align 4, !dbg !966, !tbaa !794
  %cmp51.not = icmp eq i32 %19, 0, !dbg !968
  br i1 %cmp51.not, label %lor.lhs.false, label %land.lhs.true53, !dbg !969

land.lhs.true53:                                  ; preds = %if.end50
  %20 = load volatile i32, ptr @current_time, align 4, !dbg !970, !tbaa !794
  %cmp55 = icmp ult i32 %19, %20, !dbg !971
  br i1 %cmp55, label %if.then59, label %lor.lhs.false, !dbg !972

lor.lhs.false:                                    ; preds = %land.lhs.true53, %if.end50
  tail call void @llvm.dbg.value(metadata ptr %search.0456, metadata !783, metadata !DIExpression()), !dbg !973
  %21 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 6), align 4, !dbg !975, !tbaa !787
  tail call void @llvm.dbg.value(metadata i32 %21, metadata !784, metadata !DIExpression()), !dbg !973
  %time.i = getelementptr inbounds i8, ptr %search.0456, i64 24, !dbg !976
  %22 = load i32, ptr %time.i, align 8, !dbg !976, !tbaa !794
  %cmp.not.i = icmp ugt i32 %22, %21, !dbg !977
  br i1 %cmp.not.i, label %if.end77, label %land.lhs.true.i, !dbg !978

land.lhs.true.i:                                  ; preds = %lor.lhs.false
  %23 = load volatile i32, ptr @current_time, align 4, !dbg !979, !tbaa !794
  %cmp1.not.i = icmp ugt i32 %21, %23, !dbg !980
  br i1 %cmp1.not.i, label %if.end77, label %if.then59, !dbg !981

if.then59:                                        ; preds = %land.lhs.true.i, %land.lhs.true53
  %24 = load i64, ptr %reclaimed, align 8, !dbg !982, !tbaa !984
  %inc62 = add i64 %24, 1, !dbg !982
  store i64 %inc62, ptr %reclaimed, align 8, !dbg !982, !tbaa !984
  %25 = load i16, ptr %it_flags20, align 2, !dbg !985, !tbaa !920
  %26 = and i16 %25, 8, !dbg !987
  %cmp66 = icmp eq i16 %26, 0, !dbg !988
  br i1 %cmp66, label %if.then68, label %if.end72, !dbg !989

if.then68:                                        ; preds = %if.then59
  %27 = load i64, ptr %expired_unfetched, align 8, !dbg !990, !tbaa !753
  %inc71 = add i64 %27, 1, !dbg !990
  store i64 %inc71, ptr %expired_unfetched, align 8, !dbg !990, !tbaa !753
  br label %if.end72, !dbg !992

if.end72:                                         ; preds = %if.then68, %if.then59
  tail call void @do_item_unlink_nolock(ptr noundef nonnull %search.0456, i32 noundef %call26), !dbg !993
  %28 = load ptr, ptr @ext_storage, align 8, !dbg !994, !tbaa !910
  tail call void @storage_delete(ptr noundef %28, ptr noundef nonnull %search.0456) #21, !dbg !994
  tail call void @llvm.dbg.value(metadata ptr %search.0456, metadata !996, metadata !DIExpression()), !dbg !1001
  %29 = load i16, ptr %refcount, align 4, !dbg !1003, !tbaa !920
  %dec.i = add i16 %29, -1, !dbg !1003
  store i16 %dec.i, ptr %refcount, align 4, !dbg !1003, !tbaa !920
  %cmp.i = icmp eq i16 %dec.i, 0, !dbg !1005
  br i1 %cmp.i, label %if.then.i, label %do_item_remove.exit, !dbg !1006

if.then.i:                                        ; preds = %if.end72
  tail call void @llvm.dbg.value(metadata ptr %search.0456, metadata !1007, metadata !DIExpression()), !dbg !1012
  %30 = load i8, ptr %nkey24, align 1, !dbg !1015, !tbaa !917
  %conv.i.i = zext i8 %30 to i64, !dbg !1015
  %add1.i.i = add nuw nsw i64 %conv.i.i, 49, !dbg !1015
  %31 = load i32, ptr %nbytes, align 8, !dbg !1015, !tbaa !794
  %conv2.i.i = sext i32 %31 to i64, !dbg !1015
  %add3.i.i = add nsw i64 %add1.i.i, %conv2.i.i, !dbg !1015
  %32 = load i16, ptr %it_flags20, align 2, !dbg !1015, !tbaa !920
  %conv4.i.i = zext i16 %32 to i32, !dbg !1015
  %and.i.i = lshr i32 %conv4.i.i, 6, !dbg !1015
  %33 = and i32 %and.i.i, 4, !dbg !1015
  %cond.i.i = zext nneg i32 %33 to i64, !dbg !1015
  %add5.i.i = add nsw i64 %add3.i.i, %cond.i.i, !dbg !1015
  %and8.i.i = shl nuw nsw i32 %conv4.i.i, 2, !dbg !1015
  %34 = and i32 %and8.i.i, 8, !dbg !1015
  %cond10.i.i = zext nneg i32 %34 to i64, !dbg !1015
  %add11.i.i = add nsw i64 %add5.i.i, %cond10.i.i, !dbg !1015
  tail call void @llvm.dbg.value(metadata i64 %add11.i.i, metadata !1010, metadata !DIExpression()), !dbg !1012
  %slabs_clsid.i.i = getelementptr inbounds i8, ptr %search.0456, i64 40, !dbg !1016
  %35 = load i8, ptr %slabs_clsid.i.i, align 8, !dbg !1016, !tbaa !917
  %36 = and i8 %35, 63, !dbg !1016
  %and13.i.i = zext nneg i8 %36 to i32, !dbg !1016
  tail call void @llvm.dbg.value(metadata i32 %and13.i.i, metadata !1011, metadata !DIExpression()), !dbg !1012
  tail call void @slabs_free(ptr noundef nonnull %search.0456, i64 noundef %add11.i.i, i32 noundef %and13.i.i) #21, !dbg !1017
  br label %do_item_remove.exit, !dbg !1018

do_item_remove.exit:                              ; preds = %if.end72, %if.then.i
  tail call void @item_trylock_unlock(ptr noundef nonnull %call27) #21, !dbg !1019
  %inc76 = add nsw i32 %removed.0454, 1, !dbg !1020
  tail call void @llvm.dbg.value(metadata i32 %inc76, metadata !886, metadata !DIExpression()), !dbg !902
  br label %for.inc, !dbg !1021

if.end77:                                         ; preds = %lor.lhs.false, %land.lhs.true.i
  switch i32 %1, label %for.inc [
    i32 0, label %sw.bb
    i32 1, label %sw.bb79
    i32 2, label %sw.bb125
    i32 3, label %for.end.thread.thread
  ], !dbg !1022

sw.bb:                                            ; preds = %if.end77
  %37 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 42), align 8, !dbg !1023, !tbaa !1024
  %conv78 = sext i32 %37 to i64, !dbg !1025
  %mul = mul i64 %conv78, %total_bytes, !dbg !1026
  %div = udiv i64 %mul, 100, !dbg !1027
  tail call void @llvm.dbg.value(metadata i64 %div, metadata !892, metadata !DIExpression()), !dbg !902
  br label %sw.bb79, !dbg !1028

sw.bb79:                                          ; preds = %if.end77, %sw.bb
  %limit.1 = phi i64 [ %limit.0457, %if.end77 ], [ %div, %sw.bb ], !dbg !902
  tail call void @llvm.dbg.value(metadata i64 %limit.1, metadata !892, metadata !DIExpression()), !dbg !902
  %cmp80 = icmp eq i64 %limit.1, 0, !dbg !1029
  br i1 %cmp80, label %if.then82, label %if.end86, !dbg !1031

if.then82:                                        ; preds = %sw.bb79
  %38 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 43), align 4, !dbg !1032, !tbaa !1033
  %conv83 = sext i32 %38 to i64, !dbg !1034
  %mul84 = mul i64 %conv83, %total_bytes, !dbg !1035
  %div85 = udiv i64 %mul84, 100, !dbg !1036
  tail call void @llvm.dbg.value(metadata i64 %div85, metadata !892, metadata !DIExpression()), !dbg !902
  br label %if.end86, !dbg !1037

if.end86:                                         ; preds = %if.then82, %sw.bb79
  %limit.2 = phi i64 [ %div85, %if.then82 ], [ %limit.1, %sw.bb79 ], !dbg !902
  tail call void @llvm.dbg.value(metadata i64 %limit.2, metadata !892, metadata !DIExpression()), !dbg !902
  %39 = load i16, ptr %it_flags20, align 2, !dbg !1038, !tbaa !920
  %40 = and i16 %39, 16, !dbg !1040
  %cmp90.not = icmp eq i16 %40, 0, !dbg !1041
  br i1 %cmp90.not, label %if.else108, label %if.then92, !dbg !1042

if.then92:                                        ; preds = %if.end86
  %and95 = and i16 %39, -17, !dbg !1043
  store i16 %and95, ptr %it_flags20, align 2, !dbg !1043, !tbaa !920
  %inc97 = add nsw i32 %removed.0454, 1, !dbg !1045
  tail call void @llvm.dbg.value(metadata i32 %inc97, metadata !886, metadata !DIExpression()), !dbg !902
  br i1 %cmp98, label %if.then100, label %if.else, !dbg !1046

if.then100:                                       ; preds = %if.then92
  %41 = load i64, ptr %moves_within_lru, align 8, !dbg !1047, !tbaa !1050
  %inc103 = add i64 %41, 1, !dbg !1047
  store i64 %inc103, ptr %moves_within_lru, align 8, !dbg !1047, !tbaa !1050
  tail call fastcc void @do_item_unlink_q(ptr noundef nonnull %search.0456), !dbg !1051
  tail call void @llvm.dbg.value(metadata ptr %search.0456, metadata !1052, metadata !DIExpression()), !dbg !1058
  %slabs_clsid.i = getelementptr inbounds i8, ptr %search.0456, i64 40, !dbg !1060
  %42 = load i8, ptr %slabs_clsid.i, align 8, !dbg !1060, !tbaa !917
  %idxprom.i = zext i8 %42 to i64, !dbg !1061
  %arrayidx.i = getelementptr inbounds [256 x ptr], ptr @heads, i64 0, i64 %idxprom.i, !dbg !1061
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i, metadata !1055, metadata !DIExpression()), !dbg !1058
  %arrayidx3.i = getelementptr inbounds [256 x ptr], ptr @tails, i64 0, i64 %idxprom.i, !dbg !1062
  tail call void @llvm.dbg.value(metadata ptr %arrayidx3.i, metadata !1057, metadata !DIExpression()), !dbg !1058
  store ptr null, ptr %prev, align 8, !dbg !1063, !tbaa !910
  %43 = load ptr, ptr %arrayidx.i, align 8, !dbg !1064, !tbaa !910
  store ptr %43, ptr %search.0456, align 8, !dbg !1065, !tbaa !910
  %tobool.not.i = icmp eq ptr %43, null, !dbg !1066
  br i1 %tobool.not.i, label %if.end.i350, label %if.then.i349, !dbg !1068

if.then.i349:                                     ; preds = %if.then100
  %prev6.i = getelementptr inbounds i8, ptr %43, i64 8, !dbg !1069
  store ptr %search.0456, ptr %prev6.i, align 8, !dbg !1070, !tbaa !910
  br label %if.end.i350, !dbg !1071

if.end.i350:                                      ; preds = %if.then.i349, %if.then100
  store ptr %search.0456, ptr %arrayidx.i, align 8, !dbg !1072, !tbaa !910
  %44 = load ptr, ptr %arrayidx3.i, align 8, !dbg !1073, !tbaa !910
  %cmp.i351 = icmp eq ptr %44, null, !dbg !1075
  br i1 %cmp.i351, label %if.then7.i, label %if.end8.i, !dbg !1076

if.then7.i:                                       ; preds = %if.end.i350
  store ptr %search.0456, ptr %arrayidx3.i, align 8, !dbg !1077, !tbaa !910
  br label %if.end8.i, !dbg !1078

if.end8.i:                                        ; preds = %if.then7.i, %if.end.i350
  %45 = load i8, ptr %slabs_clsid.i, align 8, !dbg !1079, !tbaa !917
  %idxprom10.i = zext i8 %45 to i64, !dbg !1080
  %arrayidx11.i = getelementptr inbounds [256 x i32], ptr @sizes, i64 0, i64 %idxprom10.i, !dbg !1080
  %46 = load i32, ptr %arrayidx11.i, align 4, !dbg !1081, !tbaa !794
  %inc.i = add i32 %46, 1, !dbg !1081
  store i32 %inc.i, ptr %arrayidx11.i, align 4, !dbg !1081, !tbaa !794
  %47 = load i16, ptr %it_flags20, align 2, !dbg !1082, !tbaa !920
  %conv.i = zext i16 %47 to i32, !dbg !1084
  %and.i = and i32 %conv.i, 128, !dbg !1085
  %tobool12.not.i = icmp eq i32 %and.i, 0, !dbg !1085
  %48 = load i8, ptr %nkey24, align 1, !dbg !1086, !tbaa !917
  %conv37.i = zext i8 %48 to i64, !dbg !1086
  br i1 %tobool12.not.i, label %if.else.i, label %if.then13.i, !dbg !1087

if.then13.i:                                      ; preds = %if.end8.i
  %and20.i = lshr i32 %conv.i, 6, !dbg !1088
  %49 = and i32 %and20.i, 4, !dbg !1088
  %and25.i = shl nuw nsw i32 %conv.i, 2, !dbg !1088
  %50 = and i32 %and25.i, 8, !dbg !1088
  %arrayidx34.i = getelementptr inbounds [256 x i64], ptr @sizes_bytes, i64 0, i64 %idxprom10.i, !dbg !1090
  %51 = load i64, ptr %arrayidx34.i, align 8, !dbg !1091, !tbaa !765
  %narrow.i = add nuw nsw i32 %49, 61, !dbg !1088
  %narrow83.i = add nuw nsw i32 %narrow.i, %50, !dbg !1092
  %sub.i = zext nneg i32 %narrow83.i to i64, !dbg !1092
  %add31.i = add nuw nsw i64 %sub.i, %conv37.i, !dbg !1093
  %add35.i = add i64 %add31.i, %51, !dbg !1091
  store i64 %add35.i, ptr %arrayidx34.i, align 8, !dbg !1091, !tbaa !765
  br label %do_item_link_q.exit, !dbg !1094

if.else.i:                                        ; preds = %if.end8.i
  %52 = load i32, ptr %nbytes, align 8, !dbg !1095, !tbaa !794
  %conv41.i = sext i32 %52 to i64, !dbg !1095
  %and45.i = lshr i32 %conv.i, 6, !dbg !1095
  %53 = and i32 %and45.i, 4, !dbg !1095
  %and51.i = shl nuw nsw i32 %conv.i, 2, !dbg !1095
  %54 = and i32 %and51.i, 8, !dbg !1095
  %arrayidx57.i = getelementptr inbounds [256 x i64], ptr @sizes_bytes, i64 0, i64 %idxprom10.i, !dbg !1097
  %55 = load i64, ptr %arrayidx57.i, align 8, !dbg !1098, !tbaa !765
  %56 = or disjoint i32 %54, %53, !dbg !1095
  %add4284.i = or disjoint i32 %56, 49, !dbg !1095
  %add42.i = zext nneg i32 %add4284.i to i64, !dbg !1095
  %add48.i = add nuw nsw i64 %add42.i, %conv37.i, !dbg !1095
  %add54.i = add nsw i64 %add48.i, %conv41.i, !dbg !1095
  %add58.i = add i64 %add54.i, %55, !dbg !1098
  store i64 %add58.i, ptr %arrayidx57.i, align 8, !dbg !1098, !tbaa !765
  br label %do_item_link_q.exit

do_item_link_q.exit:                              ; preds = %if.then13.i, %if.else.i
  tail call void @llvm.dbg.value(metadata ptr %search.0456, metadata !996, metadata !DIExpression()), !dbg !1099
  %57 = load i16, ptr %refcount, align 4, !dbg !1101, !tbaa !920
  %dec.i353 = add i16 %57, -1, !dbg !1101
  store i16 %dec.i353, ptr %refcount, align 4, !dbg !1101, !tbaa !920
  %cmp.i354 = icmp eq i16 %dec.i353, 0, !dbg !1102
  br i1 %cmp.i354, label %if.then.i356, label %do_item_remove.exit373, !dbg !1103

if.then.i356:                                     ; preds = %do_item_link_q.exit
  tail call void @llvm.dbg.value(metadata ptr %search.0456, metadata !1007, metadata !DIExpression()), !dbg !1104
  %58 = load i8, ptr %nkey24, align 1, !dbg !1106, !tbaa !917
  %conv.i.i358 = zext i8 %58 to i64, !dbg !1106
  %59 = load i32, ptr %nbytes, align 8, !dbg !1106, !tbaa !794
  %conv2.i.i361 = sext i32 %59 to i64, !dbg !1106
  %and.i.i365 = lshr i32 %conv.i, 6, !dbg !1106
  %60 = and i32 %and.i.i365, 4, !dbg !1106
  %and8.i.i368 = shl nuw nsw i32 %conv.i, 2, !dbg !1106
  %61 = and i32 %and8.i.i368, 8, !dbg !1106
  %62 = or disjoint i32 %60, %61, !dbg !1106
  %add3.i.i362458 = or disjoint i32 %62, 49, !dbg !1106
  %add3.i.i362 = zext nneg i32 %add3.i.i362458 to i64, !dbg !1106
  %add5.i.i367 = add nuw nsw i64 %add3.i.i362, %conv.i.i358, !dbg !1106
  %add11.i.i370 = add nsw i64 %add5.i.i367, %conv2.i.i361, !dbg !1106
  tail call void @llvm.dbg.value(metadata i64 %add11.i.i370, metadata !1010, metadata !DIExpression()), !dbg !1104
  %63 = load i8, ptr %slabs_clsid.i, align 8, !dbg !1107, !tbaa !917
  %64 = and i8 %63, 63, !dbg !1107
  %and13.i.i372 = zext nneg i8 %64 to i32, !dbg !1107
  tail call void @llvm.dbg.value(metadata i32 %and13.i.i372, metadata !1011, metadata !DIExpression()), !dbg !1104
  tail call void @slabs_free(ptr noundef nonnull %search.0456, i64 noundef %add11.i.i370, i32 noundef %and13.i.i372) #21, !dbg !1108
  br label %do_item_remove.exit373, !dbg !1109

do_item_remove.exit373:                           ; preds = %do_item_link_q.exit, %if.then.i356
  tail call void @item_trylock_unlock(ptr noundef nonnull %call27) #21, !dbg !1110
  br label %for.inc, !dbg !1111

if.else:                                          ; preds = %if.then92
  %moves_to_warm = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %idxprom, i32 12, !dbg !1112
  %65 = load i64, ptr %moves_to_warm, align 8, !dbg !1114, !tbaa !1115
  %inc106 = add i64 %65, 1, !dbg !1114
  store i64 %inc106, ptr %moves_to_warm, align 8, !dbg !1114, !tbaa !1115
  tail call void @llvm.dbg.value(metadata i32 64, metadata !891, metadata !DIExpression()), !dbg !902
  tail call fastcc void @do_item_unlink_q(ptr noundef nonnull %search.0456), !dbg !1116
  tail call void @llvm.dbg.value(metadata ptr %search.0456, metadata !884, metadata !DIExpression()), !dbg !902
  br label %if.then228

if.else108:                                       ; preds = %if.end86
  %arrayidx110 = getelementptr inbounds [256 x i64], ptr @sizes_bytes, i64 0, i64 %idxprom, !dbg !1117
  %66 = load i64, ptr %arrayidx110, align 8, !dbg !1117, !tbaa !765
  %cmp111 = icmp ugt i64 %66, %limit.2, !dbg !1119
  br i1 %cmp111, label %if.then117, label %lor.lhs.false113, !dbg !1120

lor.lhs.false113:                                 ; preds = %if.else108
  %67 = load volatile i32, ptr @current_time, align 4, !dbg !1121, !tbaa !794
  %sub = sub i32 %67, %22, !dbg !1122
  %cmp115 = icmp ugt i32 %sub, %max_age, !dbg !1123
  br i1 %cmp115, label %if.then117, label %for.end.thread.thread, !dbg !1124

if.then117:                                       ; preds = %lor.lhs.false113, %if.else108
  %moves_to_cold = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %idxprom, i32 11, !dbg !1125
  %68 = load i64, ptr %moves_to_cold, align 8, !dbg !1127, !tbaa !1128
  %inc120 = add i64 %68, 1, !dbg !1127
  store i64 %inc120, ptr %moves_to_cold, align 8, !dbg !1127, !tbaa !1128
  tail call void @llvm.dbg.value(metadata i32 128, metadata !891, metadata !DIExpression()), !dbg !902
  tail call fastcc void @do_item_unlink_q(ptr noundef nonnull %search.0456), !dbg !1129
  tail call void @llvm.dbg.value(metadata ptr %search.0456, metadata !884, metadata !DIExpression()), !dbg !902
  %inc121 = add nsw i32 %removed.0454, 1, !dbg !1130
  tail call void @llvm.dbg.value(metadata i32 %inc121, metadata !886, metadata !DIExpression()), !dbg !902
  br label %if.then228, !dbg !1131

sw.bb125:                                         ; preds = %if.end77
  %exptime.le = getelementptr inbounds i8, ptr %search.0456, i64 28
  tail call void @llvm.dbg.value(metadata ptr %search.0456, metadata !884, metadata !DIExpression()), !dbg !902
  %conv126 = zext i8 %flags to i32, !dbg !1132
  %and127 = and i32 %conv126, 1, !dbg !1133
  %tobool128.not = icmp eq i32 %and127, 0, !dbg !1133
  br i1 %tobool128.not, label %if.else187, label %if.then129, !dbg !1134

if.then129:                                       ; preds = %sw.bb125
  %69 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 7), align 8, !dbg !1135, !tbaa !1137
  %cmp130 = icmp eq i32 %69, 0, !dbg !1138
  br i1 %cmp130, label %for.end.thread.thread, label %if.end133, !dbg !1139

if.end133:                                        ; preds = %if.then129
  %70 = load i64, ptr %arrayidx38, align 8, !dbg !1140, !tbaa !1141
  %inc136 = add i64 %70, 1, !dbg !1140
  store i64 %inc136, ptr %arrayidx38, align 8, !dbg !1140, !tbaa !1141
  %71 = load volatile i32, ptr @current_time, align 4, !dbg !1142, !tbaa !794
  %sub138 = sub i32 %71, %22, !dbg !1143
  %evicted_time = getelementptr inbounds i8, ptr %arrayidx38, i64 160, !dbg !1144
  store i32 %sub138, ptr %evicted_time, align 8, !dbg !1145, !tbaa !1146
  %72 = load i32, ptr %exptime.le, align 4, !dbg !1147, !tbaa !794
  %cmp142.not = icmp eq i32 %72, 0, !dbg !1149
  br i1 %cmp142.not, label %if.end148, label %if.then144, !dbg !1150

if.then144:                                       ; preds = %if.end133
  %evicted_nonzero = getelementptr inbounds i8, ptr %arrayidx38, i64 8, !dbg !1151
  %73 = load i64, ptr %evicted_nonzero, align 8, !dbg !1152, !tbaa !1153
  %inc147 = add i64 %73, 1, !dbg !1152
  store i64 %inc147, ptr %evicted_nonzero, align 8, !dbg !1152, !tbaa !1153
  br label %if.end148, !dbg !1154

if.end148:                                        ; preds = %if.then144, %if.end133
  %74 = load i16, ptr %it_flags20, align 2, !dbg !1155, !tbaa !920
  %75 = and i16 %74, 8, !dbg !1157
  %cmp152 = icmp eq i16 %75, 0, !dbg !1158
  br i1 %cmp152, label %if.then154, label %if.end158, !dbg !1159

if.then154:                                       ; preds = %if.end148
  %evicted_unfetched = getelementptr inbounds i8, ptr %arrayidx38, i64 48, !dbg !1160
  %76 = load i64, ptr %evicted_unfetched, align 8, !dbg !1162, !tbaa !1163
  %inc157 = add i64 %76, 1, !dbg !1162
  store i64 %inc157, ptr %evicted_unfetched, align 8, !dbg !1162, !tbaa !1163
  br label %if.end158, !dbg !1164

if.end158:                                        ; preds = %if.then154, %if.end148
  %77 = and i16 %74, 16, !dbg !1165
  %tobool162.not = icmp eq i16 %77, 0, !dbg !1165
  br i1 %tobool162.not, label %do.body168, label %if.then163, !dbg !1167

if.then163:                                       ; preds = %if.end158
  %evicted_active = getelementptr inbounds i8, ptr %arrayidx38, i64 56, !dbg !1168
  %78 = load i64, ptr %evicted_active, align 8, !dbg !1170, !tbaa !1171
  %inc166 = add i64 %78, 1, !dbg !1170
  store i64 %inc166, ptr %evicted_active, align 8, !dbg !1170, !tbaa !1171
  br label %do.body168, !dbg !1172

do.body168:                                       ; preds = %if.end158, %if.then163
  tail call void @llvm.dbg.value(metadata ptr null, metadata !897, metadata !DIExpression()), !dbg !1173
  %79 = load i32, ptr @logger_key, align 4, !dbg !1174, !tbaa !794
  %call169 = tail call ptr @pthread_getspecific(i32 noundef %79) #21, !dbg !1174
  tail call void @llvm.dbg.value(metadata ptr %call169, metadata !897, metadata !DIExpression()), !dbg !1173
  %eflags = getelementptr inbounds i8, ptr %call169, i64 84, !dbg !1176
  %80 = load i16, ptr %eflags, align 4, !dbg !1176, !tbaa !1178
  %81 = and i16 %80, 64, !dbg !1176
  %tobool172.not = icmp eq i16 %81, 0, !dbg !1176
  br i1 %tobool172.not, label %if.end175, label %if.then173, !dbg !1180

if.then173:                                       ; preds = %do.body168
  %call174 = tail call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %call169, i32 noundef 1, ptr noundef nonnull %search.0456) #21, !dbg !1176
  br label %if.end175, !dbg !1176

if.end175:                                        ; preds = %if.then173, %do.body168
  %82 = load ptr, ptr @ext_storage, align 8, !dbg !1181, !tbaa !910
  tail call void @storage_delete(ptr noundef %82, ptr noundef nonnull %search.0456) #21, !dbg !1181
  tail call void @do_item_unlink_nolock(ptr noundef nonnull %search.0456, i32 noundef %call26), !dbg !1183
  %inc181 = add nsw i32 %removed.0454, 1, !dbg !1184
  tail call void @llvm.dbg.value(metadata i32 %inc181, metadata !886, metadata !DIExpression()), !dbg !902
  %83 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 31), align 4, !dbg !1185, !tbaa !1187
  %cmp182 = icmp eq i32 %83, 2, !dbg !1188
  br i1 %cmp182, label %if.then184, label %for.end.thread.thread, !dbg !1189

if.then184:                                       ; preds = %if.end175
  %call185 = tail call i32 @slabs_reassign(i32 noundef -1, i32 noundef %orig_id) #21, !dbg !1190
  br label %for.end.thread.thread, !dbg !1192

if.else187:                                       ; preds = %sw.bb125
  %and189 = and i32 %conv126, 4, !dbg !1193
  %tobool190.not = icmp eq i32 %and189, 0, !dbg !1193
  br i1 %tobool190.not, label %if.else194, label %if.then191, !dbg !1195

if.then191:                                       ; preds = %if.else187
  store ptr %search.0456, ptr %ret_it, align 8, !dbg !1196, !tbaa !1198
  %hv193 = getelementptr inbounds i8, ptr %ret_it, i64 8, !dbg !1200
  store i32 %call26, ptr %hv193, align 8, !dbg !1201, !tbaa !1202
  br label %for.end.thread.thread, !dbg !1203

if.else194:                                       ; preds = %if.else187
  %84 = load i16, ptr %it_flags20, align 2, !dbg !1204, !tbaa !920
  %85 = and i16 %84, 16, !dbg !1206
  %cmp198.not = icmp eq i16 %85, 0, !dbg !1207
  br i1 %cmp198.not, label %for.end.thread.thread, label %land.lhs.true200, !dbg !1208

land.lhs.true200:                                 ; preds = %if.else194
  %86 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 29), align 8, !dbg !1209, !tbaa !827, !range !828, !noundef !829
  %tobool201 = trunc nuw i8 %86 to i1, !dbg !1209
  br i1 %tobool201, label %if.then203, label %for.end.thread.thread, !dbg !1210

if.then203:                                       ; preds = %land.lhs.true200
  %moves_to_warm206 = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %idxprom, i32 12, !dbg !1211
  %87 = load i64, ptr %moves_to_warm206, align 8, !dbg !1213, !tbaa !1115
  %inc207 = add i64 %87, 1, !dbg !1213
  store i64 %inc207, ptr %moves_to_warm206, align 8, !dbg !1213, !tbaa !1115
  %88 = and i16 %84, -17, !dbg !1214
  store i16 %88, ptr %it_flags20, align 2, !dbg !1214, !tbaa !920
  tail call void @llvm.dbg.value(metadata i32 64, metadata !891, metadata !DIExpression()), !dbg !902
  tail call fastcc void @do_item_unlink_q(ptr noundef nonnull %search.0456), !dbg !1215
  %inc212 = add nsw i32 %removed.0454, 1, !dbg !1216
  tail call void @llvm.dbg.value(metadata i32 %inc212, metadata !886, metadata !DIExpression()), !dbg !902
  br label %if.then228, !dbg !1217

for.end.thread.thread:                            ; preds = %if.end77, %lor.lhs.false113, %if.else194, %land.lhs.true200, %if.then191, %if.end175, %if.then184, %if.then129
  %removed.1.ph.ph = phi i32 [ %removed.0454, %if.then129 ], [ %inc181, %if.then184 ], [ %inc181, %if.end175 ], [ %removed.0454, %if.then191 ], [ %removed.0454, %land.lhs.true200 ], [ %removed.0454, %if.else194 ], [ %removed.0454, %lor.lhs.false113 ], [ %removed.0454, %if.end77 ]
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !892, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !891, metadata !DIExpression(DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr %call27, metadata !890, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr %search.0456, metadata !884, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 %removed.1.ph.ph, metadata !886, metadata !DIExpression()), !dbg !902
  %call223419487 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #21, !dbg !1218
  br label %if.end237, !dbg !1219

for.inc:                                          ; preds = %do_item_remove.exit373, %if.end77, %if.end19, %do_item_remove.exit, %if.then44, %if.end18
  %removed.3 = phi i32 [ %removed.0454, %if.end18 ], [ %removed.0454, %if.end19 ], [ %inc76, %do_item_remove.exit ], [ %removed.0454, %if.then44 ], [ %removed.0454, %if.end77 ], [ %inc97, %do_item_remove.exit373 ], !dbg !1222
  %tries.1 = phi i32 [ %inc, %if.end18 ], [ %tries.0455, %if.end19 ], [ %tries.0455, %do_item_remove.exit ], [ %tries.0455, %if.then44 ], [ %tries.0455, %if.end77 ], [ %tries.0455, %do_item_remove.exit373 ], !dbg !902
  %limit.5 = phi i64 [ %limit.0457, %if.end18 ], [ %limit.0457, %if.end19 ], [ %limit.0457, %do_item_remove.exit ], [ %limit.0457, %if.then44 ], [ %limit.0457, %if.end77 ], [ %limit.2, %do_item_remove.exit373 ], !dbg !1223
  tail call void @llvm.dbg.value(metadata i64 %limit.5, metadata !892, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !891, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !890, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !884, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 %tries.1, metadata !887, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 %removed.3, metadata !886, metadata !DIExpression()), !dbg !902
  %dec = add nsw i32 %tries.1, -1, !dbg !1224
  tail call void @llvm.dbg.value(metadata i32 0, metadata !891, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr null, metadata !884, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr %3, metadata !888, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 %dec, metadata !887, metadata !DIExpression()), !dbg !902
  %cmp3 = icmp slt i32 %tries.1, 2, !dbg !1225
  %cmp4.not = icmp eq ptr %3, null
  %or.cond = select i1 %cmp3, i1 true, i1 %cmp4.not, !dbg !911
  br i1 %or.cond, label %for.end, label %for.body, !dbg !911, !llvm.loop !1226

for.end:                                          ; preds = %for.inc, %if.end
  %removed.0.lcssa = phi i32 [ 0, %if.end ], [ %removed.3, %for.inc ], !dbg !1222
  tail call void @llvm.dbg.value(metadata i32 0, metadata !891, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !890, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr null, metadata !884, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 %removed.0.lcssa, metadata !886, metadata !DIExpression()), !dbg !902
  %call223 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #21, !dbg !1218
  br label %cleanup251, !dbg !1229

if.then228:                                       ; preds = %if.then203, %if.else, %if.then117
  %removed.1.ph = phi i32 [ %inc121, %if.then117 ], [ %inc97, %if.else ], [ %inc212, %if.then203 ]
  %move_to_lru.1.ph = phi i8 [ -128, %if.then117 ], [ 64, %if.else ], [ 64, %if.then203 ]
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !892, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i8 %move_to_lru.1.ph, metadata !891, metadata !DIExpression(DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr %call27, metadata !890, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata ptr %search.0456, metadata !884, metadata !DIExpression()), !dbg !902
  tail call void @llvm.dbg.value(metadata i32 %removed.1.ph, metadata !886, metadata !DIExpression()), !dbg !902
  %call223419 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #21, !dbg !1218
  %slabs_clsid = getelementptr inbounds i8, ptr %search.0456, i64 40, !dbg !1230
  %89 = load i8, ptr %slabs_clsid, align 8, !dbg !1230, !tbaa !917
  %90 = and i8 %89, 63, !dbg !1230
  %conv236 = or disjoint i8 %90, %move_to_lru.1.ph, !dbg !1233
  store i8 %conv236, ptr %slabs_clsid, align 8, !dbg !1233, !tbaa !917
  tail call fastcc void @item_link_q(ptr noundef nonnull %search.0456), !dbg !1234
  br label %if.end237, !dbg !1235

if.end237:                                        ; preds = %for.end.thread.thread, %if.then228
  %removed.1.ph488 = phi i32 [ %removed.1.ph.ph, %for.end.thread.thread ], [ %removed.1.ph, %if.then228 ]
  %91 = and i8 %flags, 4, !dbg !1236
  %cmp240 = icmp eq i8 %91, 0, !dbg !1238
  br i1 %cmp240, label %if.then242, label %cleanup251, !dbg !1239

if.then242:                                       ; preds = %if.end237
  tail call void @llvm.dbg.value(metadata ptr %search.0456, metadata !996, metadata !DIExpression()), !dbg !1240
  %92 = load i16, ptr %refcount, align 4, !dbg !1243, !tbaa !920
  %dec.i375 = add i16 %92, -1, !dbg !1243
  store i16 %dec.i375, ptr %refcount, align 4, !dbg !1243, !tbaa !920
  %cmp.i376 = icmp eq i16 %dec.i375, 0, !dbg !1244
  br i1 %cmp.i376, label %if.then.i378, label %do_item_remove.exit395, !dbg !1245

if.then.i378:                                     ; preds = %if.then242
  tail call void @llvm.dbg.value(metadata ptr %search.0456, metadata !1007, metadata !DIExpression()), !dbg !1246
  %93 = load i8, ptr %nkey24, align 1, !dbg !1248, !tbaa !917
  %conv.i.i380 = zext i8 %93 to i64, !dbg !1248
  %add1.i.i381 = add nuw nsw i64 %conv.i.i380, 49, !dbg !1248
  %94 = load i32, ptr %nbytes, align 8, !dbg !1248, !tbaa !794
  %conv2.i.i383 = sext i32 %94 to i64, !dbg !1248
  %add3.i.i384 = add nsw i64 %add1.i.i381, %conv2.i.i383, !dbg !1248
  %95 = load i16, ptr %it_flags20, align 2, !dbg !1248, !tbaa !920
  %conv4.i.i386 = zext i16 %95 to i32, !dbg !1248
  %and.i.i387 = lshr i32 %conv4.i.i386, 6, !dbg !1248
  %96 = and i32 %and.i.i387, 4, !dbg !1248
  %cond.i.i388 = zext nneg i32 %96 to i64, !dbg !1248
  %add5.i.i389 = add nsw i64 %add3.i.i384, %cond.i.i388, !dbg !1248
  %and8.i.i390 = shl nuw nsw i32 %conv4.i.i386, 2, !dbg !1248
  %97 = and i32 %and8.i.i390, 8, !dbg !1248
  %cond10.i.i391 = zext nneg i32 %97 to i64, !dbg !1248
  %add11.i.i392 = add nsw i64 %add5.i.i389, %cond10.i.i391, !dbg !1248
  tail call void @llvm.dbg.value(metadata i64 %add11.i.i392, metadata !1010, metadata !DIExpression()), !dbg !1246
  %slabs_clsid.i.i393 = getelementptr inbounds i8, ptr %search.0456, i64 40, !dbg !1249
  %98 = load i8, ptr %slabs_clsid.i.i393, align 8, !dbg !1249, !tbaa !917
  %99 = and i8 %98, 63, !dbg !1249
  %and13.i.i394 = zext nneg i8 %99 to i32, !dbg !1249
  tail call void @llvm.dbg.value(metadata i32 %and13.i.i394, metadata !1011, metadata !DIExpression()), !dbg !1246
  tail call void @slabs_free(ptr noundef nonnull %search.0456, i64 noundef %add11.i.i392, i32 noundef %and13.i.i394) #21, !dbg !1250
  br label %do_item_remove.exit395, !dbg !1251

do_item_remove.exit395:                           ; preds = %if.then242, %if.then.i378
  tail call void @item_trylock_unlock(ptr noundef nonnull %call27) #21, !dbg !1252
  br label %cleanup251, !dbg !1253

cleanup251:                                       ; preds = %for.end, %if.then14, %if.end237, %do_item_remove.exit395, %entry
  %retval.1 = phi i32 [ 0, %entry ], [ 0, %if.then14 ], [ %removed.1.ph488, %if.end237 ], [ %removed.1.ph488, %do_item_remove.exit395 ], [ %removed.0.lcssa, %for.end ], !dbg !902
  ret i32 %retval.1, !dbg !1254
}

declare !dbg !1255 ptr @slabs_alloc(i64 noundef, i32 noundef, i32 noundef) local_unnamed_addr #7

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local ptr @do_item_alloc_chunk(ptr noundef %ch, i64 noundef %bytes_remain) local_unnamed_addr #0 !dbg !1258 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %ch, metadata !1262, metadata !DIExpression()), !dbg !1267
  tail call void @llvm.dbg.value(metadata i64 %bytes_remain, metadata !1263, metadata !DIExpression()), !dbg !1267
  %add = add i64 %bytes_remain, 48, !dbg !1268
  tail call void @llvm.dbg.value(metadata i64 %add, metadata !1264, metadata !DIExpression()), !dbg !1267
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 22), align 8, !dbg !1269, !tbaa !1271
  %conv = sext i32 %0 to i64, !dbg !1272
  %spec.select = tail call i64 @llvm.umin.i64(i64 %add, i64 %conv), !dbg !1273
  tail call void @llvm.dbg.value(metadata i64 %spec.select, metadata !1264, metadata !DIExpression()), !dbg !1267
  %call = tail call i32 @slabs_clsid(i64 noundef %spec.select) #21, !dbg !1274
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !1265, metadata !DIExpression()), !dbg !1267
  %call3 = tail call ptr @do_item_alloc_pull(i64 noundef %spec.select, i32 noundef %call), !dbg !1275
  tail call void @llvm.dbg.value(metadata ptr %call3, metadata !1266, metadata !DIExpression()), !dbg !1267
  %cmp4 = icmp eq ptr %call3, null, !dbg !1276
  br i1 %cmp4, label %if.then6, label %if.end19, !dbg !1278

if.then6:                                         ; preds = %entry
  %1 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 22), align 8, !dbg !1279, !tbaa !1271
  %conv7 = sext i32 %1 to i64, !dbg !1282
  %cmp8 = icmp eq i64 %spec.select, %conv7, !dbg !1283
  br i1 %cmp8, label %cleanup, label %if.else, !dbg !1284

if.else:                                          ; preds = %if.then6
  tail call void @llvm.dbg.value(metadata i64 %conv7, metadata !1264, metadata !DIExpression()), !dbg !1267
  %call12 = tail call i32 @slabs_clsid(i64 noundef %conv7) #21, !dbg !1285
  tail call void @llvm.dbg.value(metadata i32 %call12, metadata !1265, metadata !DIExpression()), !dbg !1267
  %call13 = tail call ptr @do_item_alloc_pull(i64 noundef %conv7, i32 noundef %call12), !dbg !1287
  tail call void @llvm.dbg.value(metadata ptr %call13, metadata !1266, metadata !DIExpression()), !dbg !1267
  %cmp14 = icmp eq ptr %call13, null, !dbg !1288
  br i1 %cmp14, label %cleanup, label %if.end19, !dbg !1290

if.end19:                                         ; preds = %if.else, %entry
  %size.1 = phi i64 [ %conv7, %if.else ], [ %spec.select, %entry ], !dbg !1267
  %id.0 = phi i32 [ %call12, %if.else ], [ %call, %entry ], !dbg !1267
  %nch.0 = phi ptr [ %call13, %if.else ], [ %call3, %entry ], !dbg !1267
  tail call void @llvm.dbg.value(metadata ptr %nch.0, metadata !1266, metadata !DIExpression()), !dbg !1267
  tail call void @llvm.dbg.value(metadata i32 %id.0, metadata !1265, metadata !DIExpression()), !dbg !1267
  tail call void @llvm.dbg.value(metadata i64 %size.1, metadata !1264, metadata !DIExpression()), !dbg !1267
  tail call void @slabs_mlock() #21, !dbg !1291
  %head = getelementptr inbounds i8, ptr %ch, i64 16, !dbg !1292
  %2 = load ptr, ptr %head, align 8, !dbg !1292, !tbaa !910
  %head20 = getelementptr inbounds i8, ptr %nch.0, i64 16, !dbg !1293
  store ptr %2, ptr %head20, align 8, !dbg !1294, !tbaa !910
  store ptr %nch.0, ptr %ch, align 8, !dbg !1295, !tbaa !910
  %prev = getelementptr inbounds i8, ptr %nch.0, i64 8, !dbg !1296
  store ptr %ch, ptr %prev, align 8, !dbg !1297, !tbaa !910
  store ptr null, ptr %nch.0, align 8, !dbg !1298, !tbaa !910
  %used = getelementptr inbounds i8, ptr %nch.0, i64 28, !dbg !1299
  store i32 0, ptr %used, align 4, !dbg !1300, !tbaa !794
  %conv22 = trunc i32 %id.0 to i8, !dbg !1301
  %slabs_clsid = getelementptr inbounds i8, ptr %nch.0, i64 40, !dbg !1302
  store i8 %conv22, ptr %slabs_clsid, align 8, !dbg !1303, !tbaa !917
  %3 = trunc i64 %size.1 to i32, !dbg !1304
  %conv23 = add i32 %3, -48, !dbg !1304
  %size24 = getelementptr inbounds i8, ptr %nch.0, i64 24, !dbg !1305
  store i32 %conv23, ptr %size24, align 8, !dbg !1306, !tbaa !794
  %it_flags = getelementptr inbounds i8, ptr %nch.0, i64 38, !dbg !1307
  %4 = load i16, ptr %it_flags, align 2, !dbg !1308, !tbaa !920
  %5 = or i16 %4, 64, !dbg !1308
  store i16 %5, ptr %it_flags, align 2, !dbg !1308, !tbaa !920
  tail call void @slabs_munlock() #21, !dbg !1309
  br label %cleanup, !dbg !1310

cleanup:                                          ; preds = %if.else, %if.then6, %if.end19
  %retval.0 = phi ptr [ %nch.0, %if.end19 ], [ null, %if.then6 ], [ null, %if.else ], !dbg !1267
  ret ptr %retval.0, !dbg !1311
}

declare !dbg !1312 i32 @slabs_clsid(i64 noundef) local_unnamed_addr #7

declare !dbg !1315 void @slabs_mlock() local_unnamed_addr #7

declare !dbg !1316 void @slabs_munlock() local_unnamed_addr #7

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local ptr @do_item_alloc(ptr nocapture noundef readonly %key, i64 noundef %nkey, i32 noundef %flags, i32 noundef %exptime, i32 noundef %nbytes) local_unnamed_addr #0 !dbg !1317 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !1325, metadata !DIExpression()), !dbg !1342
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !1326, metadata !DIExpression()), !dbg !1342
  tail call void @llvm.dbg.value(metadata i32 %flags, metadata !1327, metadata !DIExpression()), !dbg !1342
  tail call void @llvm.dbg.value(metadata i32 %exptime, metadata !1328, metadata !DIExpression()), !dbg !1342
  tail call void @llvm.dbg.value(metadata i32 %nbytes, metadata !1329, metadata !DIExpression()), !dbg !1342
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1331, metadata !DIExpression()), !dbg !1342
  %cmp = icmp slt i32 %nbytes, 2, !dbg !1343
  br i1 %cmp, label %cleanup129, label %if.end, !dbg !1345

if.end:                                           ; preds = %entry
  %add = add i64 %nkey, 1, !dbg !1346
  tail call void @llvm.dbg.value(metadata i64 %add, metadata !1347, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1357
  tail call void @llvm.dbg.value(metadata i32 %flags, metadata !1353, metadata !DIExpression()), !dbg !1357
  tail call void @llvm.dbg.value(metadata i32 %nbytes, metadata !1354, metadata !DIExpression()), !dbg !1357
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !1355, metadata !DIExpression()), !dbg !1357
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !1356, metadata !DIExpression()), !dbg !1357
  %cmp.i = icmp eq i32 %flags, 0, !dbg !1359
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !1330, metadata !DIExpression()), !dbg !1342
  %conv.i = and i64 %add, 255, !dbg !1361
  %add.i = add nuw nsw i64 %conv.i, 48, !dbg !1362
  %conv1.i = select i1 %cmp.i, i64 0, i64 4, !dbg !1363
  %conv3.i = zext nneg i32 %nbytes to i64
  %add2.i = add nuw nsw i64 %add.i, %conv1.i, !dbg !1364
  %add4.i = add nuw nsw i64 %add2.i, %conv3.i, !dbg !1365
  tail call void @llvm.dbg.value(metadata i64 %add4.i, metadata !1333, metadata !DIExpression()), !dbg !1342
  %0 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 18), align 8, !dbg !1366, !tbaa !1368, !range !828, !noundef !829
  %tobool = trunc nuw i8 %0 to i1, !dbg !1366
  %add2 = add nuw nsw i64 %add4.i, 8
  %spec.select = select i1 %tobool, i64 %add2, i64 %add4.i, !dbg !1369
  tail call void @llvm.dbg.value(metadata i64 %spec.select, metadata !1333, metadata !DIExpression()), !dbg !1342
  %call4 = tail call i32 @slabs_clsid(i64 noundef %spec.select) #21, !dbg !1370
  tail call void @llvm.dbg.value(metadata i32 %call4, metadata !1334, metadata !DIExpression()), !dbg !1342
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1335, metadata !DIExpression()), !dbg !1342
  %cmp5 = icmp eq i32 %call4, 0, !dbg !1371
  br i1 %cmp5, label %cleanup129, label %if.end8, !dbg !1373

if.end8:                                          ; preds = %if.end
  %1 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 22), align 8, !dbg !1374, !tbaa !1271
  %conv9 = sext i32 %1 to i64, !dbg !1375
  %cmp10 = icmp ugt i64 %spec.select, %conv9, !dbg !1376
  br i1 %cmp10, label %if.then12, label %if.else, !dbg !1377

if.then12:                                        ; preds = %if.end8
  %add15 = add i64 %conv1.i, %add, !dbg !1378
  tail call void @llvm.dbg.value(metadata i64 %add15, metadata !1336, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_plus_uconst, 96, DW_OP_stack_value)), !dbg !1379
  %2 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 18), align 8, !dbg !1380, !tbaa !1368, !range !828, !noundef !829
  %tobool19 = trunc nuw i8 %2 to i1, !dbg !1380
  %spec.select180.v = select i1 %tobool19, i64 104, i64 96, !dbg !1382
  %spec.select180 = add i64 %add15, %spec.select180.v, !dbg !1382
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1336, metadata !DIExpression()), !dbg !1379
  %sext = shl i64 %spec.select180, 32, !dbg !1383
  %conv25 = ashr exact i64 %sext, 32, !dbg !1383
  %call26 = tail call i32 @slabs_clsid(i64 noundef %conv25) #21, !dbg !1384
  tail call void @llvm.dbg.value(metadata i32 %call26, metadata !1335, metadata !DIExpression()), !dbg !1342
  %call28 = tail call ptr @do_item_alloc_pull(i64 noundef %conv25, i32 noundef %call26), !dbg !1385
  tail call void @llvm.dbg.value(metadata ptr %call28, metadata !1331, metadata !DIExpression()), !dbg !1342
  %cmp29.not = icmp eq ptr %call28, null, !dbg !1386
  br i1 %cmp29.not, label %if.end34, label %if.then31, !dbg !1388

if.then31:                                        ; preds = %if.then12
  %it_flags = getelementptr inbounds i8, ptr %call28, i64 38, !dbg !1389
  %3 = load i16, ptr %it_flags, align 2, !dbg !1390, !tbaa !920
  %4 = or i16 %3, 32, !dbg !1390
  store i16 %4, ptr %it_flags, align 2, !dbg !1390, !tbaa !920
  br label %if.end34, !dbg !1391

if.end34:                                         ; preds = %if.then31, %if.then12
  %5 = trunc i32 %call26 to i8, !dbg !1392
  br label %if.end36, !dbg !1393

if.else:                                          ; preds = %if.end8
  %call35 = tail call ptr @do_item_alloc_pull(i64 noundef %spec.select, i32 noundef %call4), !dbg !1394
  tail call void @llvm.dbg.value(metadata ptr %call35, metadata !1331, metadata !DIExpression()), !dbg !1342
  br label %if.end36

if.end36:                                         ; preds = %if.else, %if.end34
  %it.0 = phi ptr [ %call28, %if.end34 ], [ %call35, %if.else ], !dbg !1396
  %hdr_id.0 = phi i8 [ %5, %if.end34 ], [ 0, %if.else ], !dbg !1342
  tail call void @llvm.dbg.value(metadata i8 %hdr_id.0, metadata !1335, metadata !DIExpression(DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1342
  tail call void @llvm.dbg.value(metadata ptr %it.0, metadata !1331, metadata !DIExpression()), !dbg !1342
  %cmp37 = icmp eq ptr %it.0, null, !dbg !1397
  br i1 %cmp37, label %if.then39, label %if.end46, !dbg !1399

if.then39:                                        ; preds = %if.end36
  %idxprom = zext i32 %call4 to i64, !dbg !1400
  %arrayidx = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom, !dbg !1400
  %call40 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx) #21, !dbg !1402
  %outofmemory = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %idxprom, i32 3, !dbg !1403
  %6 = load i64, ptr %outofmemory, align 8, !dbg !1404, !tbaa !1405
  %inc = add i64 %6, 1, !dbg !1404
  store i64 %inc, ptr %outofmemory, align 8, !dbg !1404, !tbaa !1405
  %call45 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #21, !dbg !1406
  br label %cleanup129, !dbg !1407

if.end46:                                         ; preds = %if.end36
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %it.0, i8 0, i64 16, i1 false), !dbg !1408
  %7 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 47), align 4, !dbg !1409, !tbaa !1411, !range !828, !noundef !829
  %tobool47 = trunc nuw i8 %7 to i1, !dbg !1409
  br i1 %tobool47, label %land.lhs.true, label %if.else53, !dbg !1412

land.lhs.true:                                    ; preds = %if.end46
  %8 = load volatile i32, ptr @current_time, align 4, !dbg !1413, !tbaa !794
  %sub = sub i32 %exptime, %8, !dbg !1414
  %9 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 48), align 8, !dbg !1415, !tbaa !1416
  %cmp49.not = icmp ugt i32 %sub, %9, !dbg !1417
  br i1 %cmp49.not, label %if.else53, label %if.then51, !dbg !1418

if.then51:                                        ; preds = %land.lhs.true
  %or52 = or i32 %call4, 192, !dbg !1419
  tail call void @llvm.dbg.value(metadata i32 %or52, metadata !1334, metadata !DIExpression()), !dbg !1342
  br label %if.end60, !dbg !1421

if.else53:                                        ; preds = %land.lhs.true, %if.end46
  %10 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 29), align 8, !dbg !1422, !tbaa !827, !range !828, !noundef !829
  %tobool54 = trunc nuw i8 %10 to i1, !dbg !1422
  %or58 = or i32 %call4, 128
  %spec.select181 = select i1 %tobool54, i32 %call4, i32 %or58, !dbg !1424
  br label %if.end60, !dbg !1424

if.end60:                                         ; preds = %if.else53, %if.then51
  %id.0 = phi i32 [ %or52, %if.then51 ], [ %spec.select181, %if.else53 ], !dbg !1425
  tail call void @llvm.dbg.value(metadata i32 %id.0, metadata !1334, metadata !DIExpression()), !dbg !1342
  %conv61 = trunc i32 %id.0 to i8, !dbg !1426
  %slabs_clsid = getelementptr inbounds i8, ptr %it.0, i64 40, !dbg !1427
  store i8 %conv61, ptr %slabs_clsid, align 8, !dbg !1428, !tbaa !917
  %11 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 18), align 8, !dbg !1429, !tbaa !1368, !range !828, !noundef !829
  %tobool62 = trunc nuw i8 %11 to i1, !dbg !1429
  %cond = select i1 %tobool62, i16 2, i16 0, !dbg !1430
  %it_flags64 = getelementptr inbounds i8, ptr %it.0, i64 38, !dbg !1431
  %12 = load i16, ptr %it_flags64, align 2, !dbg !1432, !tbaa !920
  %or66 = or i16 %cond, %12, !dbg !1432
  %cond71 = select i1 %cmp.i, i16 0, i16 256, !dbg !1433
  %or74 = or i16 %or66, %cond71, !dbg !1434
  store i16 %or74, ptr %it_flags64, align 2, !dbg !1434, !tbaa !920
  %conv76 = trunc i64 %nkey to i8, !dbg !1435
  %nkey77 = getelementptr inbounds i8, ptr %it.0, i64 41, !dbg !1436
  store i8 %conv76, ptr %nkey77, align 1, !dbg !1437, !tbaa !917
  %nbytes78 = getelementptr inbounds i8, ptr %it.0, i64 32, !dbg !1438
  store i32 %nbytes, ptr %nbytes78, align 8, !dbg !1439, !tbaa !794
  %data = getelementptr inbounds i8, ptr %it.0, i64 48, !dbg !1440
  %13 = shl i16 %or66, 2, !dbg !1440
  %14 = and i16 %13, 8, !dbg !1440
  %cond82 = zext nneg i16 %14 to i64, !dbg !1440
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %cond82, !dbg !1440
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr, ptr align 1 %key, i64 %nkey, i1 false), !dbg !1441
  %exptime83 = getelementptr inbounds i8, ptr %it.0, i64 28, !dbg !1442
  store i32 %exptime, ptr %exptime83, align 4, !dbg !1443, !tbaa !794
  %.pre = load i16, ptr %it_flags64, align 2, !dbg !1444, !tbaa !920
  br i1 %cmp.i, label %if.end99, label %if.then87, !dbg !1445

if.then87:                                        ; preds = %if.end60
  %15 = load i8, ptr %nkey77, align 1, !dbg !1446, !tbaa !917
  %idx.ext = zext i8 %15 to i64
  %add.ptr91 = getelementptr inbounds i8, ptr %data, i64 %idx.ext, !dbg !1446
  %add.ptr92 = getelementptr inbounds i8, ptr %add.ptr91, i64 1, !dbg !1446
  %16 = shl i16 %.pre, 2, !dbg !1446
  %17 = and i16 %16, 8, !dbg !1446
  %cond97 = zext nneg i16 %17 to i64, !dbg !1446
  %add.ptr98 = getelementptr inbounds i8, ptr %add.ptr92, i64 %cond97, !dbg !1446
  store i32 %flags, ptr %add.ptr98, align 1, !dbg !1449
  br label %if.end99, !dbg !1450

if.end99:                                         ; preds = %if.then87, %if.end60
  %conv101 = zext i16 %.pre to i32, !dbg !1451
  %and102 = and i32 %conv101, 32, !dbg !1452
  %tobool103.not = icmp eq i32 %and102, 0, !dbg !1452
  br i1 %tobool103.not, label %if.end126, label %if.then104, !dbg !1453

if.then104:                                       ; preds = %if.end99
  %18 = load i8, ptr %nkey77, align 1, !dbg !1454, !tbaa !917
  %idx.ext108 = zext i8 %18 to i64
  %add.ptr109 = getelementptr inbounds i8, ptr %data, i64 %idx.ext108, !dbg !1454
  %add.ptr110 = getelementptr inbounds i8, ptr %add.ptr109, i64 1, !dbg !1454
  %and113 = lshr i32 %conv101, 6, !dbg !1454
  %19 = and i32 %and113, 4, !dbg !1454
  %cond115 = zext nneg i32 %19 to i64, !dbg !1454
  %add.ptr116 = getelementptr inbounds i8, ptr %add.ptr110, i64 %cond115, !dbg !1454
  %and119 = shl nuw nsw i32 %conv101, 2, !dbg !1454
  %20 = and i32 %and119, 8, !dbg !1454
  %cond121 = zext nneg i32 %20 to i64, !dbg !1454
  %add.ptr122 = getelementptr inbounds i8, ptr %add.ptr116, i64 %cond121, !dbg !1454
  tail call void @llvm.dbg.value(metadata ptr %add.ptr122, metadata !1339, metadata !DIExpression()), !dbg !1455
  %used = getelementptr inbounds i8, ptr %add.ptr122, i64 28, !dbg !1456
  store i32 0, ptr %used, align 4, !dbg !1457, !tbaa !794
  %size = getelementptr inbounds i8, ptr %add.ptr122, i64 24, !dbg !1458
  store i32 0, ptr %size, align 8, !dbg !1459, !tbaa !794
  %head = getelementptr inbounds i8, ptr %add.ptr122, i64 16, !dbg !1460
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %add.ptr122, i8 0, i64 16, i1 false), !dbg !1461
  store ptr %it.0, ptr %head, align 8, !dbg !1462, !tbaa !910
  %orig_clsid = getelementptr inbounds i8, ptr %add.ptr122, i64 41, !dbg !1463
  store i8 %hdr_id.0, ptr %orig_clsid, align 1, !dbg !1464, !tbaa !917
  br label %if.end126, !dbg !1465

if.end126:                                        ; preds = %if.then104, %if.end99
  %h_next = getelementptr inbounds i8, ptr %it.0, i64 16, !dbg !1466
  store ptr null, ptr %h_next, align 8, !dbg !1467, !tbaa !910
  br label %cleanup129, !dbg !1468

cleanup129:                                       ; preds = %if.then39, %if.end126, %if.end, %entry
  %retval.1 = phi ptr [ null, %entry ], [ null, %if.then39 ], [ %it.0, %if.end126 ], [ null, %if.end ], !dbg !1342
  ret ptr %retval.1, !dbg !1469
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #8

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @item_free(ptr noundef %it) local_unnamed_addr #0 !dbg !1008 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1007, metadata !DIExpression()), !dbg !1470
  %nkey = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1471
  %0 = load i8, ptr %nkey, align 1, !dbg !1471, !tbaa !917
  %conv = zext i8 %0 to i64, !dbg !1471
  %add1 = add nuw nsw i64 %conv, 49, !dbg !1471
  %nbytes = getelementptr inbounds i8, ptr %it, i64 32, !dbg !1471
  %1 = load i32, ptr %nbytes, align 8, !dbg !1471, !tbaa !794
  %conv2 = sext i32 %1 to i64, !dbg !1471
  %add3 = add nsw i64 %add1, %conv2, !dbg !1471
  %it_flags = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1471
  %2 = load i16, ptr %it_flags, align 2, !dbg !1471, !tbaa !920
  %conv4 = zext i16 %2 to i32, !dbg !1471
  %and = lshr i32 %conv4, 6, !dbg !1471
  %3 = and i32 %and, 4, !dbg !1471
  %cond = zext nneg i32 %3 to i64, !dbg !1471
  %add5 = add nsw i64 %add3, %cond, !dbg !1471
  %and8 = shl nuw nsw i32 %conv4, 2, !dbg !1471
  %4 = and i32 %and8, 8, !dbg !1471
  %cond10 = zext nneg i32 %4 to i64, !dbg !1471
  %add11 = add nsw i64 %add5, %cond10, !dbg !1471
  tail call void @llvm.dbg.value(metadata i64 %add11, metadata !1010, metadata !DIExpression()), !dbg !1470
  %slabs_clsid = getelementptr inbounds i8, ptr %it, i64 40, !dbg !1472
  %5 = load i8, ptr %slabs_clsid, align 8, !dbg !1472, !tbaa !917
  %6 = and i8 %5, 63, !dbg !1472
  %and13 = zext nneg i8 %6 to i32, !dbg !1472
  tail call void @llvm.dbg.value(metadata i32 %and13, metadata !1011, metadata !DIExpression()), !dbg !1470
  tail call void @slabs_free(ptr noundef %it, i64 noundef %add11, i32 noundef %and13) #21, !dbg !1473
  ret void, !dbg !1474
}

declare !dbg !1475 void @slabs_free(ptr noundef, i64 noundef, i32 noundef) local_unnamed_addr #7

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local zeroext i1 @item_size_ok(i64 noundef %nkey, i32 noundef %flags, i32 noundef %nbytes) local_unnamed_addr #0 !dbg !1478 {
entry:
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !1482, metadata !DIExpression()), !dbg !1488
  tail call void @llvm.dbg.value(metadata i32 %flags, metadata !1483, metadata !DIExpression()), !dbg !1488
  tail call void @llvm.dbg.value(metadata i32 %nbytes, metadata !1484, metadata !DIExpression()), !dbg !1488
  %cmp = icmp slt i32 %nbytes, 2, !dbg !1489
  br i1 %cmp, label %cleanup, label %if.end, !dbg !1491

if.end:                                           ; preds = %entry
  %conv = add i64 %nkey, 1, !dbg !1492
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !1347, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !1493
  tail call void @llvm.dbg.value(metadata i32 %flags, metadata !1353, metadata !DIExpression()), !dbg !1493
  tail call void @llvm.dbg.value(metadata i32 %nbytes, metadata !1354, metadata !DIExpression()), !dbg !1493
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !1355, metadata !DIExpression()), !dbg !1493
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !1356, metadata !DIExpression()), !dbg !1493
  %cmp.i = icmp eq i32 %flags, 0, !dbg !1495
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !1486, metadata !DIExpression()), !dbg !1488
  %conv.i = and i64 %conv, 255, !dbg !1496
  %add.i = add nuw nsw i64 %conv.i, 48, !dbg !1497
  %conv1.i = select i1 %cmp.i, i64 0, i64 4, !dbg !1498
  %conv3.i = zext nneg i32 %nbytes to i64
  %add2.i = add nuw nsw i64 %add.i, %conv3.i, !dbg !1499
  %add4.i = add nuw nsw i64 %add2.i, %conv1.i, !dbg !1500
  tail call void @llvm.dbg.value(metadata i64 %add4.i, metadata !1487, metadata !DIExpression()), !dbg !1488
  %0 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 18), align 8, !dbg !1501, !tbaa !1368, !range !828, !noundef !829
  %tobool = trunc nuw i8 %0 to i1, !dbg !1501
  %add2 = add nuw nsw i64 %add4.i, 8
  %spec.select = select i1 %tobool, i64 %add2, i64 %add4.i, !dbg !1503
  tail call void @llvm.dbg.value(metadata i64 %spec.select, metadata !1487, metadata !DIExpression()), !dbg !1488
  %call4 = tail call i32 @slabs_clsid(i64 noundef %spec.select) #21, !dbg !1504
  %cmp5 = icmp ne i32 %call4, 0, !dbg !1505
  br label %cleanup

cleanup:                                          ; preds = %entry, %if.end
  %retval.0 = phi i1 [ %cmp5, %if.end ], [ false, %entry ], !dbg !1488
  ret i1 %retval.0, !dbg !1506
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @do_item_link_fixup(ptr noundef %it) local_unnamed_addr #0 !dbg !1507 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1509, metadata !DIExpression()), !dbg !1514
  %nkey = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1515
  %0 = load i8, ptr %nkey, align 1, !dbg !1515, !tbaa !917
  %conv = zext i8 %0 to i64, !dbg !1515
  %nbytes = getelementptr inbounds i8, ptr %it, i64 32, !dbg !1515
  %1 = load i32, ptr %nbytes, align 8, !dbg !1515, !tbaa !794
  %it_flags = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1515
  %2 = load i16, ptr %it_flags, align 2, !dbg !1515, !tbaa !920
  %conv4 = zext i16 %2 to i32, !dbg !1515
  %and8 = shl nuw nsw i32 %conv4, 2, !dbg !1515
  %3 = and i32 %and8, 8, !dbg !1515
  %cond10 = zext nneg i32 %3 to i64, !dbg !1515
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %conv, i64 %cond10, i32 %conv4, i32 %1), metadata !1512, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 49, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_plus, DW_OP_LLVM_arg, 2, DW_OP_constu, 6, DW_OP_shr, DW_OP_constu, 4, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1514
  %4 = load ptr, ptr @hash, align 8, !dbg !1516, !tbaa !910
  %data = getelementptr inbounds i8, ptr %it, i64 48, !dbg !1517
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %cond10, !dbg !1517
  %call = tail call i32 %4(ptr noundef nonnull %add.ptr, i64 noundef %conv) #21, !dbg !1516
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !1513, metadata !DIExpression()), !dbg !1514
  %call20 = tail call i32 @assoc_insert(ptr noundef %it, i32 noundef %call) #21, !dbg !1518
  %slabs_clsid = getelementptr inbounds i8, ptr %it, i64 40, !dbg !1519
  %5 = load i8, ptr %slabs_clsid, align 8, !dbg !1519, !tbaa !917
  %idxprom = zext i8 %5 to i64, !dbg !1520
  %arrayidx = getelementptr inbounds [256 x ptr], ptr @heads, i64 0, i64 %idxprom, !dbg !1520
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !1510, metadata !DIExpression()), !dbg !1514
  %arrayidx23 = getelementptr inbounds [256 x ptr], ptr @tails, i64 0, i64 %idxprom, !dbg !1521
  tail call void @llvm.dbg.value(metadata ptr %arrayidx23, metadata !1511, metadata !DIExpression()), !dbg !1514
  %prev = getelementptr inbounds i8, ptr %it, i64 8, !dbg !1522
  %6 = load ptr, ptr %prev, align 8, !dbg !1522, !tbaa !910
  %cmp = icmp eq ptr %6, null, !dbg !1524
  br i1 %cmp, label %land.lhs.true, label %if.end, !dbg !1525

land.lhs.true:                                    ; preds = %entry
  %7 = load ptr, ptr %arrayidx, align 8, !dbg !1526, !tbaa !910
  %cmp25 = icmp eq ptr %7, null, !dbg !1527
  br i1 %cmp25, label %if.then, label %if.end, !dbg !1528

if.then:                                          ; preds = %land.lhs.true
  store ptr %it, ptr %arrayidx, align 8, !dbg !1529, !tbaa !910
  br label %if.end, !dbg !1530

if.end:                                           ; preds = %if.then, %land.lhs.true, %entry
  %8 = load ptr, ptr %it, align 8, !dbg !1531, !tbaa !910
  %cmp27 = icmp eq ptr %8, null, !dbg !1533
  br i1 %cmp27, label %land.lhs.true29, label %if.end33, !dbg !1534

land.lhs.true29:                                  ; preds = %if.end
  %9 = load ptr, ptr %arrayidx23, align 8, !dbg !1535, !tbaa !910
  %cmp30 = icmp eq ptr %9, null, !dbg !1536
  br i1 %cmp30, label %if.then32, label %if.end33, !dbg !1537

if.then32:                                        ; preds = %land.lhs.true29
  store ptr %it, ptr %arrayidx23, align 8, !dbg !1538, !tbaa !910
  br label %if.end33, !dbg !1539

if.end33:                                         ; preds = %if.then32, %land.lhs.true29, %if.end
  %and = lshr i32 %conv4, 6, !dbg !1515
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %conv, i64 %cond10, i32 %and, i32 %1), metadata !1512, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 49, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_plus, DW_OP_LLVM_arg, 2, DW_OP_constu, 4, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1514
  %10 = and i32 %and, 4, !dbg !1515
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %conv, i64 %cond10, i32 %10, i32 %1), metadata !1512, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_plus_uconst, 49, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_plus, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1514
  %11 = zext i8 %0 to i32, !dbg !1515
  %12 = add nuw nsw i32 %11, 49, !dbg !1515
  %13 = add i32 %12, %1, !dbg !1515
  %14 = add i32 %13, %10, !dbg !1515
  %conv12 = add i32 %14, %3, !dbg !1515
  tail call void @llvm.dbg.value(metadata i32 %conv12, metadata !1512, metadata !DIExpression()), !dbg !1514
  %arrayidx36 = getelementptr inbounds [256 x i32], ptr @sizes, i64 0, i64 %idxprom, !dbg !1540
  %15 = load i32, ptr %arrayidx36, align 4, !dbg !1541, !tbaa !794
  %inc = add i32 %15, 1, !dbg !1541
  store i32 %inc, ptr %arrayidx36, align 4, !dbg !1541, !tbaa !794
  %conv37 = sext i32 %conv12 to i64, !dbg !1542
  %arrayidx40 = getelementptr inbounds [256 x i64], ptr @sizes_bytes, i64 0, i64 %idxprom, !dbg !1543
  %16 = load i64, ptr %arrayidx40, align 8, !dbg !1544, !tbaa !765
  %add41 = add i64 %16, %conv37, !dbg !1544
  store i64 %add41, ptr %arrayidx40, align 8, !dbg !1544, !tbaa !765
  tail call void @STATS_LOCK() #21, !dbg !1545
  %17 = load <2 x i64>, ptr @stats_state, align 8, !dbg !1546, !tbaa !765
  %18 = insertelement <2 x i64> <i64 1, i64 poison>, i64 %conv37, i64 1, !dbg !1546
  %19 = add <2 x i64> %17, %18, !dbg !1546
  store <2 x i64> %19, ptr @stats_state, align 8, !dbg !1546, !tbaa !765
  %20 = load i64, ptr @stats, align 8, !dbg !1547, !tbaa !1548
  %add45 = add i64 %20, 1, !dbg !1547
  store i64 %add45, ptr @stats, align 8, !dbg !1547, !tbaa !1548
  tail call void @STATS_UNLOCK() #21, !dbg !1551
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1552, metadata !DIExpression()), !dbg !1557
  %21 = load ptr, ptr @stats_sizes_hist, align 8, !dbg !1559, !tbaa !910
  %cmp.i = icmp eq ptr %21, null, !dbg !1561
  br i1 %cmp.i, label %item_stats_sizes_add.exit, label %if.end.i, !dbg !1562

if.end.i:                                         ; preds = %if.end33
  %22 = load i8, ptr %nkey, align 1, !dbg !1563, !tbaa !917
  %conv.i = zext i8 %22 to i32, !dbg !1563
  %add1.i = add nuw nsw i32 %conv.i, 49, !dbg !1563
  %23 = load i32, ptr %nbytes, align 8, !dbg !1563, !tbaa !794
  %add3.i = add i32 %add1.i, %23, !dbg !1563
  %24 = load i16, ptr %it_flags, align 2, !dbg !1563, !tbaa !920
  %conv4.i = zext i16 %24 to i32, !dbg !1563
  %and.i = lshr i32 %conv4.i, 6, !dbg !1563
  %25 = and i32 %and.i, 4, !dbg !1563
  %add5.i = add i32 %add3.i, %25, !dbg !1563
  %and8.i = shl nuw nsw i32 %conv4.i, 2, !dbg !1563
  %26 = and i32 %and8.i, 8, !dbg !1563
  %add11.i = add i32 %add5.i, %26, !dbg !1563
  tail call void @llvm.dbg.value(metadata i32 %add11.i, metadata !1555, metadata !DIExpression()), !dbg !1557
  %div.i = sdiv i32 %add11.i, 32, !dbg !1564
  tail call void @llvm.dbg.value(metadata i32 %div.i, metadata !1556, metadata !DIExpression()), !dbg !1557
  %27 = and i32 %add11.i, 31, !dbg !1565
  %cmp13.not.i = icmp ne i32 %27, 0, !dbg !1565
  %inc.i = zext i1 %cmp13.not.i to i32, !dbg !1567
  %spec.select.i = add nsw i32 %div.i, %inc.i, !dbg !1567
  tail call void @llvm.dbg.value(metadata i32 %spec.select.i, metadata !1556, metadata !DIExpression()), !dbg !1557
  %28 = load i32, ptr @stats_sizes_buckets, align 4, !dbg !1568, !tbaa !794
  %cmp17.i = icmp slt i32 %spec.select.i, %28, !dbg !1570
  br i1 %cmp17.i, label %if.then19.i, label %item_stats_sizes_add.exit, !dbg !1571

if.then19.i:                                      ; preds = %if.end.i
  %idxprom.i = sext i32 %spec.select.i to i64, !dbg !1572
  %arrayidx.i = getelementptr inbounds i32, ptr %21, i64 %idxprom.i, !dbg !1572
  %29 = load i32, ptr %arrayidx.i, align 4, !dbg !1573, !tbaa !794
  %inc20.i = add i32 %29, 1, !dbg !1573
  store i32 %inc20.i, ptr %arrayidx.i, align 4, !dbg !1573, !tbaa !794
  br label %item_stats_sizes_add.exit, !dbg !1572

item_stats_sizes_add.exit:                        ; preds = %if.end33, %if.end.i, %if.then19.i
  ret void, !dbg !1574
}

declare !dbg !1575 i32 @assoc_insert(ptr noundef, i32 noundef) local_unnamed_addr #7

declare !dbg !1580 void @STATS_LOCK() local_unnamed_addr #7

declare !dbg !1581 void @STATS_UNLOCK() local_unnamed_addr #7

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, inaccessiblemem: none) uwtable
define dso_local void @item_stats_sizes_add(ptr nocapture noundef readonly %it) local_unnamed_addr #9 !dbg !1553 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1552, metadata !DIExpression()), !dbg !1582
  %0 = load ptr, ptr @stats_sizes_hist, align 8, !dbg !1583, !tbaa !910
  %cmp = icmp eq ptr %0, null, !dbg !1584
  br i1 %cmp, label %return, label %if.end, !dbg !1585

if.end:                                           ; preds = %entry
  %nkey = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1586
  %1 = load i8, ptr %nkey, align 1, !dbg !1586, !tbaa !917
  %conv = zext i8 %1 to i32, !dbg !1586
  %add1 = add nuw nsw i32 %conv, 49, !dbg !1586
  %nbytes = getelementptr inbounds i8, ptr %it, i64 32, !dbg !1586
  %2 = load i32, ptr %nbytes, align 8, !dbg !1586, !tbaa !794
  %add3 = add i32 %add1, %2, !dbg !1586
  %it_flags = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1586
  %3 = load i16, ptr %it_flags, align 2, !dbg !1586, !tbaa !920
  %conv4 = zext i16 %3 to i32, !dbg !1586
  %and = lshr i32 %conv4, 6, !dbg !1586
  %4 = and i32 %and, 4, !dbg !1586
  %add5 = add i32 %add3, %4, !dbg !1586
  %and8 = shl nuw nsw i32 %conv4, 2, !dbg !1586
  %5 = and i32 %and8, 8, !dbg !1586
  %add11 = add i32 %add5, %5, !dbg !1586
  tail call void @llvm.dbg.value(metadata i32 %add11, metadata !1555, metadata !DIExpression()), !dbg !1582
  %div = sdiv i32 %add11, 32, !dbg !1587
  tail call void @llvm.dbg.value(metadata i32 %div, metadata !1556, metadata !DIExpression()), !dbg !1582
  %6 = and i32 %add11, 31, !dbg !1588
  %cmp13.not = icmp ne i32 %6, 0, !dbg !1588
  %inc = zext i1 %cmp13.not to i32, !dbg !1589
  %spec.select = add nsw i32 %div, %inc, !dbg !1589
  tail call void @llvm.dbg.value(metadata i32 %spec.select, metadata !1556, metadata !DIExpression()), !dbg !1582
  %7 = load i32, ptr @stats_sizes_buckets, align 4, !dbg !1590, !tbaa !794
  %cmp17 = icmp slt i32 %spec.select, %7, !dbg !1591
  br i1 %cmp17, label %if.then19, label %return, !dbg !1592

if.then19:                                        ; preds = %if.end
  %idxprom = sext i32 %spec.select to i64, !dbg !1593
  %arrayidx = getelementptr inbounds i32, ptr %0, i64 %idxprom, !dbg !1593
  %8 = load i32, ptr %arrayidx, align 4, !dbg !1594, !tbaa !794
  %inc20 = add i32 %8, 1, !dbg !1594
  store i32 %inc20, ptr %arrayidx, align 4, !dbg !1594, !tbaa !794
  br label %return, !dbg !1593

return:                                           ; preds = %if.end, %if.then19, %entry
  ret void, !dbg !1595
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef i32 @do_item_link(ptr noundef %it, i32 noundef %hv, i64 noundef %cas) local_unnamed_addr #0 !dbg !1596 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1600, metadata !DIExpression()), !dbg !1603
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !1601, metadata !DIExpression()), !dbg !1603
  tail call void @llvm.dbg.value(metadata i64 %cas, metadata !1602, metadata !DIExpression()), !dbg !1603
  %it_flags = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1604
  %0 = load i16, ptr %it_flags, align 2, !dbg !1605, !tbaa !920
  %1 = or i16 %0, 1, !dbg !1605
  store i16 %1, ptr %it_flags, align 2, !dbg !1605, !tbaa !920
  %2 = load volatile i32, ptr @current_time, align 4, !dbg !1606, !tbaa !794
  %time = getelementptr inbounds i8, ptr %it, i64 24, !dbg !1607
  store i32 %2, ptr %time, align 8, !dbg !1608, !tbaa !794
  tail call void @STATS_LOCK() #21, !dbg !1609
  %nkey = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1610
  %3 = load i8, ptr %nkey, align 1, !dbg !1610, !tbaa !917
  %conv2 = zext i8 %3 to i64, !dbg !1610
  %add3 = add nuw nsw i64 %conv2, 49, !dbg !1610
  %nbytes = getelementptr inbounds i8, ptr %it, i64 32, !dbg !1610
  %4 = load i32, ptr %nbytes, align 8, !dbg !1610, !tbaa !794
  %conv4 = sext i32 %4 to i64, !dbg !1610
  %add5 = add nsw i64 %add3, %conv4, !dbg !1610
  %5 = load i16, ptr %it_flags, align 2, !dbg !1610, !tbaa !920
  %conv7 = zext i16 %5 to i32, !dbg !1610
  %and = lshr i32 %conv7, 6, !dbg !1610
  %6 = and i32 %and, 4, !dbg !1610
  %cond = zext nneg i32 %6 to i64, !dbg !1610
  %and11 = shl nuw nsw i32 %conv7, 2, !dbg !1610
  %7 = and i32 %and11, 8, !dbg !1610
  %cond13 = zext nneg i32 %7 to i64, !dbg !1610
  %8 = load i64, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 1), align 8, !dbg !1611, !tbaa !1612
  %add8 = add i64 %add5, %8, !dbg !1610
  %add14 = add i64 %add8, %cond, !dbg !1610
  %add15 = add i64 %add14, %cond13, !dbg !1611
  store i64 %add15, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 1), align 8, !dbg !1611, !tbaa !1612
  %9 = load i64, ptr @stats_state, align 8, !dbg !1614, !tbaa !1615
  %add16 = add i64 %9, 1, !dbg !1614
  store i64 %add16, ptr @stats_state, align 8, !dbg !1614, !tbaa !1615
  %10 = load i64, ptr @stats, align 8, !dbg !1616, !tbaa !1548
  %add17 = add i64 %10, 1, !dbg !1616
  store i64 %add17, ptr @stats, align 8, !dbg !1616, !tbaa !1548
  tail call void @STATS_UNLOCK() #21, !dbg !1617
  %11 = load i16, ptr %it_flags, align 2, !dbg !1618, !tbaa !920
  %12 = and i16 %11, 2, !dbg !1618
  %tobool21.not = icmp eq i16 %12, 0, !dbg !1618
  br i1 %tobool21.not, label %if.end, label %if.then, !dbg !1621

if.then:                                          ; preds = %entry
  %data = getelementptr inbounds i8, ptr %it, i64 48, !dbg !1622
  store i64 %cas, ptr %data, align 8, !dbg !1622, !tbaa !917
  br label %if.end, !dbg !1622

if.end:                                           ; preds = %if.then, %entry
  %call = tail call i32 @assoc_insert(ptr noundef nonnull %it, i32 noundef %hv) #21, !dbg !1624
  tail call fastcc void @item_link_q(ptr noundef nonnull %it), !dbg !1625
  %refcount = getelementptr inbounds i8, ptr %it, i64 36, !dbg !1626
  %13 = load i16, ptr %refcount, align 4, !dbg !1626, !tbaa !920
  %inc = add i16 %13, 1, !dbg !1626
  store i16 %inc, ptr %refcount, align 4, !dbg !1626, !tbaa !920
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1552, metadata !DIExpression()), !dbg !1627
  %14 = load ptr, ptr @stats_sizes_hist, align 8, !dbg !1629, !tbaa !910
  %cmp.i = icmp eq ptr %14, null, !dbg !1630
  br i1 %cmp.i, label %item_stats_sizes_add.exit, label %if.end.i, !dbg !1631

if.end.i:                                         ; preds = %if.end
  %15 = load i8, ptr %nkey, align 1, !dbg !1632, !tbaa !917
  %conv.i = zext i8 %15 to i32, !dbg !1632
  %add1.i = add nuw nsw i32 %conv.i, 49, !dbg !1632
  %16 = load i32, ptr %nbytes, align 8, !dbg !1632, !tbaa !794
  %add3.i = add i32 %add1.i, %16, !dbg !1632
  %17 = load i16, ptr %it_flags, align 2, !dbg !1632, !tbaa !920
  %conv4.i = zext i16 %17 to i32, !dbg !1632
  %and.i = lshr i32 %conv4.i, 6, !dbg !1632
  %18 = and i32 %and.i, 4, !dbg !1632
  %add5.i = add i32 %add3.i, %18, !dbg !1632
  %and8.i = shl nuw nsw i32 %conv4.i, 2, !dbg !1632
  %19 = and i32 %and8.i, 8, !dbg !1632
  %add11.i = add i32 %add5.i, %19, !dbg !1632
  tail call void @llvm.dbg.value(metadata i32 %add11.i, metadata !1555, metadata !DIExpression()), !dbg !1627
  %div.i = sdiv i32 %add11.i, 32, !dbg !1633
  tail call void @llvm.dbg.value(metadata i32 %div.i, metadata !1556, metadata !DIExpression()), !dbg !1627
  %20 = and i32 %add11.i, 31, !dbg !1634
  %cmp13.not.i = icmp ne i32 %20, 0, !dbg !1634
  %inc.i = zext i1 %cmp13.not.i to i32, !dbg !1635
  %spec.select.i = add nsw i32 %div.i, %inc.i, !dbg !1635
  tail call void @llvm.dbg.value(metadata i32 %spec.select.i, metadata !1556, metadata !DIExpression()), !dbg !1627
  %21 = load i32, ptr @stats_sizes_buckets, align 4, !dbg !1636, !tbaa !794
  %cmp17.i = icmp slt i32 %spec.select.i, %21, !dbg !1637
  br i1 %cmp17.i, label %if.then19.i, label %item_stats_sizes_add.exit, !dbg !1638

if.then19.i:                                      ; preds = %if.end.i
  %idxprom.i = sext i32 %spec.select.i to i64, !dbg !1639
  %arrayidx.i = getelementptr inbounds i32, ptr %14, i64 %idxprom.i, !dbg !1639
  %22 = load i32, ptr %arrayidx.i, align 4, !dbg !1640, !tbaa !794
  %inc20.i = add i32 %22, 1, !dbg !1640
  store i32 %inc20.i, ptr %arrayidx.i, align 4, !dbg !1640, !tbaa !794
  br label %item_stats_sizes_add.exit, !dbg !1639

item_stats_sizes_add.exit:                        ; preds = %if.end, %if.end.i, %if.then19.i
  ret i32 1, !dbg !1641
}

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc void @item_link_q(ptr noundef %it) unnamed_addr #0 !dbg !1642 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1644, metadata !DIExpression()), !dbg !1645
  %slabs_clsid = getelementptr inbounds i8, ptr %it, i64 40, !dbg !1646
  %0 = load i8, ptr %slabs_clsid, align 8, !dbg !1646, !tbaa !917
  %idxprom = zext i8 %0 to i64, !dbg !1647
  %arrayidx = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom, !dbg !1647
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx) #21, !dbg !1648
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1052, metadata !DIExpression()), !dbg !1649
  %1 = load i8, ptr %slabs_clsid, align 8, !dbg !1651, !tbaa !917
  %idxprom.i = zext i8 %1 to i64, !dbg !1652
  %arrayidx.i = getelementptr inbounds [256 x ptr], ptr @heads, i64 0, i64 %idxprom.i, !dbg !1652
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i, metadata !1055, metadata !DIExpression()), !dbg !1649
  %arrayidx3.i = getelementptr inbounds [256 x ptr], ptr @tails, i64 0, i64 %idxprom.i, !dbg !1653
  tail call void @llvm.dbg.value(metadata ptr %arrayidx3.i, metadata !1057, metadata !DIExpression()), !dbg !1649
  %prev.i = getelementptr inbounds i8, ptr %it, i64 8, !dbg !1654
  store ptr null, ptr %prev.i, align 8, !dbg !1655, !tbaa !910
  %2 = load ptr, ptr %arrayidx.i, align 8, !dbg !1656, !tbaa !910
  store ptr %2, ptr %it, align 8, !dbg !1657, !tbaa !910
  %tobool.not.i = icmp eq ptr %2, null, !dbg !1658
  br i1 %tobool.not.i, label %if.end.i, label %if.then.i, !dbg !1659

if.then.i:                                        ; preds = %entry
  %prev6.i = getelementptr inbounds i8, ptr %2, i64 8, !dbg !1660
  store ptr %it, ptr %prev6.i, align 8, !dbg !1661, !tbaa !910
  br label %if.end.i, !dbg !1662

if.end.i:                                         ; preds = %if.then.i, %entry
  store ptr %it, ptr %arrayidx.i, align 8, !dbg !1663, !tbaa !910
  %3 = load ptr, ptr %arrayidx3.i, align 8, !dbg !1664, !tbaa !910
  %cmp.i = icmp eq ptr %3, null, !dbg !1665
  br i1 %cmp.i, label %if.then7.i, label %if.end8.i, !dbg !1666

if.then7.i:                                       ; preds = %if.end.i
  store ptr %it, ptr %arrayidx3.i, align 8, !dbg !1667, !tbaa !910
  br label %if.end8.i, !dbg !1668

if.end8.i:                                        ; preds = %if.then7.i, %if.end.i
  %4 = load i8, ptr %slabs_clsid, align 8, !dbg !1669, !tbaa !917
  %idxprom10.i = zext i8 %4 to i64, !dbg !1670
  %arrayidx11.i = getelementptr inbounds [256 x i32], ptr @sizes, i64 0, i64 %idxprom10.i, !dbg !1670
  %5 = load i32, ptr %arrayidx11.i, align 4, !dbg !1671, !tbaa !794
  %inc.i = add i32 %5, 1, !dbg !1671
  store i32 %inc.i, ptr %arrayidx11.i, align 4, !dbg !1671, !tbaa !794
  %it_flags.i = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1672
  %6 = load i16, ptr %it_flags.i, align 2, !dbg !1672, !tbaa !920
  %conv.i = zext i16 %6 to i32, !dbg !1673
  %and.i = and i32 %conv.i, 128, !dbg !1674
  %tobool12.not.i = icmp eq i32 %and.i, 0, !dbg !1674
  %nkey36.i = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1675
  %7 = load i8, ptr %nkey36.i, align 1, !dbg !1675, !tbaa !917
  %conv37.i = zext i8 %7 to i64, !dbg !1675
  br i1 %tobool12.not.i, label %if.else.i, label %if.then13.i, !dbg !1676

if.then13.i:                                      ; preds = %if.end8.i
  %and20.i = lshr i32 %conv.i, 6, !dbg !1677
  %8 = and i32 %and20.i, 4, !dbg !1677
  %and25.i = shl nuw nsw i32 %conv.i, 2, !dbg !1677
  %9 = and i32 %and25.i, 8, !dbg !1677
  %arrayidx34.i = getelementptr inbounds [256 x i64], ptr @sizes_bytes, i64 0, i64 %idxprom10.i, !dbg !1678
  %10 = load i64, ptr %arrayidx34.i, align 8, !dbg !1679, !tbaa !765
  %narrow.i = add nuw nsw i32 %8, 61, !dbg !1677
  %narrow83.i = add nuw nsw i32 %narrow.i, %9, !dbg !1680
  %sub.i = zext nneg i32 %narrow83.i to i64, !dbg !1680
  %add31.i = add nuw nsw i64 %sub.i, %conv37.i, !dbg !1681
  %add35.i = add i64 %add31.i, %10, !dbg !1679
  store i64 %add35.i, ptr %arrayidx34.i, align 8, !dbg !1679, !tbaa !765
  br label %do_item_link_q.exit, !dbg !1682

if.else.i:                                        ; preds = %if.end8.i
  %nbytes40.i = getelementptr inbounds i8, ptr %it, i64 32, !dbg !1683
  %11 = load i32, ptr %nbytes40.i, align 8, !dbg !1683, !tbaa !794
  %conv41.i = sext i32 %11 to i64, !dbg !1683
  %and45.i = lshr i32 %conv.i, 6, !dbg !1683
  %12 = and i32 %and45.i, 4, !dbg !1683
  %and51.i = shl nuw nsw i32 %conv.i, 2, !dbg !1683
  %13 = and i32 %and51.i, 8, !dbg !1683
  %arrayidx57.i = getelementptr inbounds [256 x i64], ptr @sizes_bytes, i64 0, i64 %idxprom10.i, !dbg !1684
  %14 = load i64, ptr %arrayidx57.i, align 8, !dbg !1685, !tbaa !765
  %15 = or disjoint i32 %13, %12, !dbg !1683
  %add4284.i = or disjoint i32 %15, 49, !dbg !1683
  %add42.i = zext nneg i32 %add4284.i to i64, !dbg !1683
  %add48.i = add nuw nsw i64 %add42.i, %conv37.i, !dbg !1683
  %add54.i = add nsw i64 %add48.i, %conv41.i, !dbg !1683
  %add58.i = add i64 %add54.i, %14, !dbg !1685
  store i64 %add58.i, ptr %arrayidx57.i, align 8, !dbg !1685, !tbaa !765
  br label %do_item_link_q.exit

do_item_link_q.exit:                              ; preds = %if.then13.i, %if.else.i
  %arrayidx3 = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom10.i, !dbg !1686
  %call4 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx3) #21, !dbg !1687
  ret void, !dbg !1688
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @do_item_unlink(ptr noundef %it, i32 noundef %hv) local_unnamed_addr #0 !dbg !1689 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1693, metadata !DIExpression()), !dbg !1695
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !1694, metadata !DIExpression()), !dbg !1695
  %it_flags = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1696
  %0 = load i16, ptr %it_flags, align 2, !dbg !1696, !tbaa !920
  %1 = and i16 %0, 1, !dbg !1698
  %cmp.not = icmp eq i16 %1, 0, !dbg !1699
  br i1 %cmp.not, label %if.end, label %if.then, !dbg !1700

if.then:                                          ; preds = %entry
  %and4 = and i16 %0, -2, !dbg !1701
  store i16 %and4, ptr %it_flags, align 2, !dbg !1701, !tbaa !920
  tail call void @STATS_LOCK() #21, !dbg !1703
  %nkey = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1704
  %2 = load i8, ptr %nkey, align 1, !dbg !1704, !tbaa !917
  %conv6 = zext i8 %2 to i64, !dbg !1704
  %nbytes = getelementptr inbounds i8, ptr %it, i64 32, !dbg !1704
  %3 = load i32, ptr %nbytes, align 8, !dbg !1704, !tbaa !794
  %conv8 = sext i32 %3 to i64, !dbg !1704
  %4 = load i16, ptr %it_flags, align 2, !dbg !1704, !tbaa !920
  %conv11 = zext i16 %4 to i32, !dbg !1704
  %and12 = lshr i32 %conv11, 6, !dbg !1704
  %5 = and i32 %and12, 4, !dbg !1704
  %cond = zext nneg i32 %5 to i64, !dbg !1704
  %and16 = shl nuw nsw i32 %conv11, 2, !dbg !1704
  %6 = and i32 %and16, 8, !dbg !1704
  %cond18 = zext nneg i32 %6 to i64, !dbg !1704
  %7 = load i64, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 1), align 8, !dbg !1705, !tbaa !1612
  %8 = add nsw i64 %conv6, %conv8, !dbg !1704
  %9 = add i64 %7, -49, !dbg !1704
  %10 = add nsw i64 %8, %cond, !dbg !1704
  %11 = add nsw i64 %10, %cond18, !dbg !1705
  %sub = sub i64 %9, %11, !dbg !1705
  store i64 %sub, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 1), align 8, !dbg !1705, !tbaa !1612
  %12 = load i64, ptr @stats_state, align 8, !dbg !1706, !tbaa !1615
  %sub20 = add i64 %12, -1, !dbg !1706
  store i64 %sub20, ptr @stats_state, align 8, !dbg !1706, !tbaa !1615
  tail call void @STATS_UNLOCK() #21, !dbg !1707
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1708, metadata !DIExpression()), !dbg !1713
  %13 = load ptr, ptr @stats_sizes_hist, align 8, !dbg !1715, !tbaa !910
  %cmp.i = icmp eq ptr %13, null, !dbg !1717
  %.pre = load i16, ptr %it_flags, align 2, !dbg !1718, !tbaa !920
  %.pre45 = load i8, ptr %nkey, align 1, !dbg !1719, !tbaa !917
  br i1 %cmp.i, label %item_stats_sizes_remove.exit, label %if.end.i, !dbg !1720

if.end.i:                                         ; preds = %if.then
  %conv.i = zext i8 %.pre45 to i32, !dbg !1721
  %add1.i = add nuw nsw i32 %conv.i, 49, !dbg !1721
  %14 = load i32, ptr %nbytes, align 8, !dbg !1721, !tbaa !794
  %add3.i = add i32 %add1.i, %14, !dbg !1721
  %conv4.i = zext i16 %.pre to i32, !dbg !1721
  %and.i = lshr i32 %conv4.i, 6, !dbg !1721
  %15 = and i32 %and.i, 4, !dbg !1721
  %add5.i = add i32 %add3.i, %15, !dbg !1721
  %and8.i = shl nuw nsw i32 %conv4.i, 2, !dbg !1721
  %16 = and i32 %and8.i, 8, !dbg !1721
  %add11.i = add i32 %add5.i, %16, !dbg !1721
  tail call void @llvm.dbg.value(metadata i32 %add11.i, metadata !1711, metadata !DIExpression()), !dbg !1713
  %div.i = sdiv i32 %add11.i, 32, !dbg !1722
  tail call void @llvm.dbg.value(metadata i32 %div.i, metadata !1712, metadata !DIExpression()), !dbg !1713
  %17 = and i32 %add11.i, 31, !dbg !1723
  %cmp13.not.i = icmp ne i32 %17, 0, !dbg !1723
  %inc.i = zext i1 %cmp13.not.i to i32, !dbg !1725
  %spec.select.i = add nsw i32 %div.i, %inc.i, !dbg !1725
  tail call void @llvm.dbg.value(metadata i32 %spec.select.i, metadata !1712, metadata !DIExpression()), !dbg !1713
  %18 = load i32, ptr @stats_sizes_buckets, align 4, !dbg !1726, !tbaa !794
  %cmp17.i = icmp slt i32 %spec.select.i, %18, !dbg !1728
  br i1 %cmp17.i, label %if.then19.i, label %item_stats_sizes_remove.exit, !dbg !1729

if.then19.i:                                      ; preds = %if.end.i
  %idxprom.i = sext i32 %spec.select.i to i64, !dbg !1730
  %arrayidx.i = getelementptr inbounds i32, ptr %13, i64 %idxprom.i, !dbg !1730
  %19 = load i32, ptr %arrayidx.i, align 4, !dbg !1731, !tbaa !794
  %dec.i = add i32 %19, -1, !dbg !1731
  store i32 %dec.i, ptr %arrayidx.i, align 4, !dbg !1731, !tbaa !794
  %.pre44 = load i8, ptr %nkey, align 1, !dbg !1719, !tbaa !917
  br label %item_stats_sizes_remove.exit, !dbg !1730

item_stats_sizes_remove.exit:                     ; preds = %if.then, %if.end.i, %if.then19.i
  %20 = phi i8 [ %.pre45, %if.then ], [ %.pre45, %if.end.i ], [ %.pre44, %if.then19.i ], !dbg !1719
  %data = getelementptr inbounds i8, ptr %it, i64 48, !dbg !1718
  %21 = shl i16 %.pre, 2, !dbg !1718
  %22 = and i16 %21, 8, !dbg !1718
  %cond25 = zext nneg i16 %22 to i64, !dbg !1718
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %cond25, !dbg !1718
  %conv27 = zext i8 %20 to i64, !dbg !1732
  tail call void @assoc_delete(ptr noundef nonnull %add.ptr, i64 noundef %conv27, i32 noundef %hv) #21, !dbg !1733
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1734, metadata !DIExpression()), !dbg !1737
  %slabs_clsid.i = getelementptr inbounds i8, ptr %it, i64 40, !dbg !1739
  %23 = load i8, ptr %slabs_clsid.i, align 8, !dbg !1739, !tbaa !917
  %idxprom.i39 = zext i8 %23 to i64, !dbg !1740
  %arrayidx.i40 = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom.i39, !dbg !1740
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx.i40) #21, !dbg !1741
  tail call fastcc void @do_item_unlink_q(ptr noundef nonnull %it), !dbg !1742
  %24 = load i8, ptr %slabs_clsid.i, align 8, !dbg !1743, !tbaa !917
  %idxprom2.i = zext i8 %24 to i64, !dbg !1744
  %arrayidx3.i = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom2.i, !dbg !1744
  %call4.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx3.i) #21, !dbg !1745
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !996, metadata !DIExpression()), !dbg !1746
  %refcount.i = getelementptr inbounds i8, ptr %it, i64 36, !dbg !1748
  %25 = load i16, ptr %refcount.i, align 4, !dbg !1748, !tbaa !920
  %dec.i41 = add i16 %25, -1, !dbg !1748
  store i16 %dec.i41, ptr %refcount.i, align 4, !dbg !1748, !tbaa !920
  %cmp.i42 = icmp eq i16 %dec.i41, 0, !dbg !1749
  br i1 %cmp.i42, label %if.then.i, label %if.end, !dbg !1750

if.then.i:                                        ; preds = %item_stats_sizes_remove.exit
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1007, metadata !DIExpression()), !dbg !1751
  %26 = load i8, ptr %nkey, align 1, !dbg !1753, !tbaa !917
  %conv.i.i = zext i8 %26 to i64, !dbg !1753
  %add1.i.i = add nuw nsw i64 %conv.i.i, 49, !dbg !1753
  %27 = load i32, ptr %nbytes, align 8, !dbg !1753, !tbaa !794
  %conv2.i.i = sext i32 %27 to i64, !dbg !1753
  %add3.i.i = add nsw i64 %add1.i.i, %conv2.i.i, !dbg !1753
  %28 = load i16, ptr %it_flags, align 2, !dbg !1753, !tbaa !920
  %conv4.i.i = zext i16 %28 to i32, !dbg !1753
  %and.i.i = lshr i32 %conv4.i.i, 6, !dbg !1753
  %29 = and i32 %and.i.i, 4, !dbg !1753
  %cond.i.i = zext nneg i32 %29 to i64, !dbg !1753
  %add5.i.i = add nsw i64 %add3.i.i, %cond.i.i, !dbg !1753
  %and8.i.i = shl nuw nsw i32 %conv4.i.i, 2, !dbg !1753
  %30 = and i32 %and8.i.i, 8, !dbg !1753
  %cond10.i.i = zext nneg i32 %30 to i64, !dbg !1753
  %add11.i.i = add nsw i64 %add5.i.i, %cond10.i.i, !dbg !1753
  tail call void @llvm.dbg.value(metadata i64 %add11.i.i, metadata !1010, metadata !DIExpression()), !dbg !1751
  %31 = load i8, ptr %slabs_clsid.i, align 8, !dbg !1754, !tbaa !917
  %32 = and i8 %31, 63, !dbg !1754
  %and13.i.i = zext nneg i8 %32 to i32, !dbg !1754
  tail call void @llvm.dbg.value(metadata i32 %and13.i.i, metadata !1011, metadata !DIExpression()), !dbg !1751
  tail call void @slabs_free(ptr noundef nonnull %it, i64 noundef %add11.i.i, i32 noundef %and13.i.i) #21, !dbg !1755
  br label %if.end, !dbg !1756

if.end:                                           ; preds = %if.then.i, %item_stats_sizes_remove.exit, %entry
  ret void, !dbg !1757
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, inaccessiblemem: none) uwtable
define dso_local void @item_stats_sizes_remove(ptr nocapture noundef readonly %it) local_unnamed_addr #9 !dbg !1709 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1708, metadata !DIExpression()), !dbg !1758
  %0 = load ptr, ptr @stats_sizes_hist, align 8, !dbg !1759, !tbaa !910
  %cmp = icmp eq ptr %0, null, !dbg !1760
  br i1 %cmp, label %return, label %if.end, !dbg !1761

if.end:                                           ; preds = %entry
  %nkey = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1762
  %1 = load i8, ptr %nkey, align 1, !dbg !1762, !tbaa !917
  %conv = zext i8 %1 to i32, !dbg !1762
  %add1 = add nuw nsw i32 %conv, 49, !dbg !1762
  %nbytes = getelementptr inbounds i8, ptr %it, i64 32, !dbg !1762
  %2 = load i32, ptr %nbytes, align 8, !dbg !1762, !tbaa !794
  %add3 = add i32 %add1, %2, !dbg !1762
  %it_flags = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1762
  %3 = load i16, ptr %it_flags, align 2, !dbg !1762, !tbaa !920
  %conv4 = zext i16 %3 to i32, !dbg !1762
  %and = lshr i32 %conv4, 6, !dbg !1762
  %4 = and i32 %and, 4, !dbg !1762
  %add5 = add i32 %add3, %4, !dbg !1762
  %and8 = shl nuw nsw i32 %conv4, 2, !dbg !1762
  %5 = and i32 %and8, 8, !dbg !1762
  %add11 = add i32 %add5, %5, !dbg !1762
  tail call void @llvm.dbg.value(metadata i32 %add11, metadata !1711, metadata !DIExpression()), !dbg !1758
  %div = sdiv i32 %add11, 32, !dbg !1763
  tail call void @llvm.dbg.value(metadata i32 %div, metadata !1712, metadata !DIExpression()), !dbg !1758
  %6 = and i32 %add11, 31, !dbg !1764
  %cmp13.not = icmp ne i32 %6, 0, !dbg !1764
  %inc = zext i1 %cmp13.not to i32, !dbg !1765
  %spec.select = add nsw i32 %div, %inc, !dbg !1765
  tail call void @llvm.dbg.value(metadata i32 %spec.select, metadata !1712, metadata !DIExpression()), !dbg !1758
  %7 = load i32, ptr @stats_sizes_buckets, align 4, !dbg !1766, !tbaa !794
  %cmp17 = icmp slt i32 %spec.select, %7, !dbg !1767
  br i1 %cmp17, label %if.then19, label %return, !dbg !1768

if.then19:                                        ; preds = %if.end
  %idxprom = sext i32 %spec.select to i64, !dbg !1769
  %arrayidx = getelementptr inbounds i32, ptr %0, i64 %idxprom, !dbg !1769
  %8 = load i32, ptr %arrayidx, align 4, !dbg !1770, !tbaa !794
  %dec = add i32 %8, -1, !dbg !1770
  store i32 %dec, ptr %arrayidx, align 4, !dbg !1770, !tbaa !794
  br label %return, !dbg !1769

return:                                           ; preds = %if.end, %if.then19, %entry
  ret void, !dbg !1771
}

declare !dbg !1772 void @assoc_delete(ptr noundef, i64 noundef, i32 noundef) local_unnamed_addr #7

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @do_item_remove(ptr noundef %it) local_unnamed_addr #0 !dbg !997 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !996, metadata !DIExpression()), !dbg !1775
  %refcount = getelementptr inbounds i8, ptr %it, i64 36, !dbg !1776
  %0 = load i16, ptr %refcount, align 4, !dbg !1776, !tbaa !920
  %dec = add i16 %0, -1, !dbg !1776
  store i16 %dec, ptr %refcount, align 4, !dbg !1776, !tbaa !920
  %cmp = icmp eq i16 %dec, 0, !dbg !1777
  br i1 %cmp, label %if.then, label %if.end, !dbg !1778

if.then:                                          ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1007, metadata !DIExpression()), !dbg !1779
  %nkey.i = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1781
  %1 = load i8, ptr %nkey.i, align 1, !dbg !1781, !tbaa !917
  %conv.i = zext i8 %1 to i64, !dbg !1781
  %add1.i = add nuw nsw i64 %conv.i, 49, !dbg !1781
  %nbytes.i = getelementptr inbounds i8, ptr %it, i64 32, !dbg !1781
  %2 = load i32, ptr %nbytes.i, align 8, !dbg !1781, !tbaa !794
  %conv2.i = sext i32 %2 to i64, !dbg !1781
  %add3.i = add nsw i64 %add1.i, %conv2.i, !dbg !1781
  %it_flags.i = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1781
  %3 = load i16, ptr %it_flags.i, align 2, !dbg !1781, !tbaa !920
  %conv4.i = zext i16 %3 to i32, !dbg !1781
  %and.i = lshr i32 %conv4.i, 6, !dbg !1781
  %4 = and i32 %and.i, 4, !dbg !1781
  %cond.i = zext nneg i32 %4 to i64, !dbg !1781
  %add5.i = add nsw i64 %add3.i, %cond.i, !dbg !1781
  %and8.i = shl nuw nsw i32 %conv4.i, 2, !dbg !1781
  %5 = and i32 %and8.i, 8, !dbg !1781
  %cond10.i = zext nneg i32 %5 to i64, !dbg !1781
  %add11.i = add nsw i64 %add5.i, %cond10.i, !dbg !1781
  tail call void @llvm.dbg.value(metadata i64 %add11.i, metadata !1010, metadata !DIExpression()), !dbg !1779
  %slabs_clsid.i = getelementptr inbounds i8, ptr %it, i64 40, !dbg !1782
  %6 = load i8, ptr %slabs_clsid.i, align 8, !dbg !1782, !tbaa !917
  %7 = and i8 %6, 63, !dbg !1782
  %and13.i = zext nneg i8 %7 to i32, !dbg !1782
  tail call void @llvm.dbg.value(metadata i32 %and13.i, metadata !1011, metadata !DIExpression()), !dbg !1779
  tail call void @slabs_free(ptr noundef nonnull %it, i64 noundef %add11.i, i32 noundef %and13.i) #21, !dbg !1783
  br label %if.end, !dbg !1784

if.end:                                           ; preds = %if.then, %entry
  ret void, !dbg !1785
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @do_item_unlink_nolock(ptr noundef %it, i32 noundef %hv) local_unnamed_addr #0 !dbg !1786 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1788, metadata !DIExpression()), !dbg !1790
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !1789, metadata !DIExpression()), !dbg !1790
  %it_flags = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1791
  %0 = load i16, ptr %it_flags, align 2, !dbg !1791, !tbaa !920
  %1 = and i16 %0, 1, !dbg !1793
  %cmp.not = icmp eq i16 %1, 0, !dbg !1794
  br i1 %cmp.not, label %if.end, label %if.then, !dbg !1795

if.then:                                          ; preds = %entry
  %and4 = and i16 %0, -2, !dbg !1796
  store i16 %and4, ptr %it_flags, align 2, !dbg !1796, !tbaa !920
  tail call void @STATS_LOCK() #21, !dbg !1798
  %nkey = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1799
  %2 = load i8, ptr %nkey, align 1, !dbg !1799, !tbaa !917
  %conv6 = zext i8 %2 to i64, !dbg !1799
  %nbytes = getelementptr inbounds i8, ptr %it, i64 32, !dbg !1799
  %3 = load i32, ptr %nbytes, align 8, !dbg !1799, !tbaa !794
  %conv8 = sext i32 %3 to i64, !dbg !1799
  %4 = load i16, ptr %it_flags, align 2, !dbg !1799, !tbaa !920
  %conv11 = zext i16 %4 to i32, !dbg !1799
  %and12 = lshr i32 %conv11, 6, !dbg !1799
  %5 = and i32 %and12, 4, !dbg !1799
  %cond = zext nneg i32 %5 to i64, !dbg !1799
  %and16 = shl nuw nsw i32 %conv11, 2, !dbg !1799
  %6 = and i32 %and16, 8, !dbg !1799
  %cond18 = zext nneg i32 %6 to i64, !dbg !1799
  %7 = load i64, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 1), align 8, !dbg !1800, !tbaa !1612
  %8 = add nsw i64 %conv6, %conv8, !dbg !1799
  %9 = add i64 %7, -49, !dbg !1799
  %10 = add nsw i64 %8, %cond, !dbg !1799
  %11 = add nsw i64 %10, %cond18, !dbg !1800
  %sub = sub i64 %9, %11, !dbg !1800
  store i64 %sub, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 1), align 8, !dbg !1800, !tbaa !1612
  %12 = load i64, ptr @stats_state, align 8, !dbg !1801, !tbaa !1615
  %sub20 = add i64 %12, -1, !dbg !1801
  store i64 %sub20, ptr @stats_state, align 8, !dbg !1801, !tbaa !1615
  tail call void @STATS_UNLOCK() #21, !dbg !1802
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1708, metadata !DIExpression()), !dbg !1803
  %13 = load ptr, ptr @stats_sizes_hist, align 8, !dbg !1805, !tbaa !910
  %cmp.i = icmp eq ptr %13, null, !dbg !1806
  %.pre = load i16, ptr %it_flags, align 2, !dbg !1807, !tbaa !920
  %.pre43 = load i8, ptr %nkey, align 1, !dbg !1808, !tbaa !917
  br i1 %cmp.i, label %item_stats_sizes_remove.exit, label %if.end.i, !dbg !1809

if.end.i:                                         ; preds = %if.then
  %conv.i = zext i8 %.pre43 to i32, !dbg !1810
  %add1.i = add nuw nsw i32 %conv.i, 49, !dbg !1810
  %14 = load i32, ptr %nbytes, align 8, !dbg !1810, !tbaa !794
  %add3.i = add i32 %add1.i, %14, !dbg !1810
  %conv4.i = zext i16 %.pre to i32, !dbg !1810
  %and.i = lshr i32 %conv4.i, 6, !dbg !1810
  %15 = and i32 %and.i, 4, !dbg !1810
  %add5.i = add i32 %add3.i, %15, !dbg !1810
  %and8.i = shl nuw nsw i32 %conv4.i, 2, !dbg !1810
  %16 = and i32 %and8.i, 8, !dbg !1810
  %add11.i = add i32 %add5.i, %16, !dbg !1810
  tail call void @llvm.dbg.value(metadata i32 %add11.i, metadata !1711, metadata !DIExpression()), !dbg !1803
  %div.i = sdiv i32 %add11.i, 32, !dbg !1811
  tail call void @llvm.dbg.value(metadata i32 %div.i, metadata !1712, metadata !DIExpression()), !dbg !1803
  %17 = and i32 %add11.i, 31, !dbg !1812
  %cmp13.not.i = icmp ne i32 %17, 0, !dbg !1812
  %inc.i = zext i1 %cmp13.not.i to i32, !dbg !1813
  %spec.select.i = add nsw i32 %div.i, %inc.i, !dbg !1813
  tail call void @llvm.dbg.value(metadata i32 %spec.select.i, metadata !1712, metadata !DIExpression()), !dbg !1803
  %18 = load i32, ptr @stats_sizes_buckets, align 4, !dbg !1814, !tbaa !794
  %cmp17.i = icmp slt i32 %spec.select.i, %18, !dbg !1815
  br i1 %cmp17.i, label %if.then19.i, label %item_stats_sizes_remove.exit, !dbg !1816

if.then19.i:                                      ; preds = %if.end.i
  %idxprom.i = sext i32 %spec.select.i to i64, !dbg !1817
  %arrayidx.i = getelementptr inbounds i32, ptr %13, i64 %idxprom.i, !dbg !1817
  %19 = load i32, ptr %arrayidx.i, align 4, !dbg !1818, !tbaa !794
  %dec.i = add i32 %19, -1, !dbg !1818
  store i32 %dec.i, ptr %arrayidx.i, align 4, !dbg !1818, !tbaa !794
  %.pre42 = load i8, ptr %nkey, align 1, !dbg !1808, !tbaa !917
  br label %item_stats_sizes_remove.exit, !dbg !1817

item_stats_sizes_remove.exit:                     ; preds = %if.then, %if.end.i, %if.then19.i
  %20 = phi i8 [ %.pre43, %if.then ], [ %.pre43, %if.end.i ], [ %.pre42, %if.then19.i ], !dbg !1808
  %data = getelementptr inbounds i8, ptr %it, i64 48, !dbg !1807
  %21 = shl i16 %.pre, 2, !dbg !1807
  %22 = and i16 %21, 8, !dbg !1807
  %cond25 = zext nneg i16 %22 to i64, !dbg !1807
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %cond25, !dbg !1807
  %conv27 = zext i8 %20 to i64, !dbg !1819
  tail call void @assoc_delete(ptr noundef nonnull %add.ptr, i64 noundef %conv27, i32 noundef %hv) #21, !dbg !1820
  tail call fastcc void @do_item_unlink_q(ptr noundef nonnull %it), !dbg !1821
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !996, metadata !DIExpression()), !dbg !1822
  %refcount.i = getelementptr inbounds i8, ptr %it, i64 36, !dbg !1824
  %23 = load i16, ptr %refcount.i, align 4, !dbg !1824, !tbaa !920
  %dec.i39 = add i16 %23, -1, !dbg !1824
  store i16 %dec.i39, ptr %refcount.i, align 4, !dbg !1824, !tbaa !920
  %cmp.i40 = icmp eq i16 %dec.i39, 0, !dbg !1825
  br i1 %cmp.i40, label %if.then.i, label %if.end, !dbg !1826

if.then.i:                                        ; preds = %item_stats_sizes_remove.exit
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1007, metadata !DIExpression()), !dbg !1827
  %24 = load i8, ptr %nkey, align 1, !dbg !1829, !tbaa !917
  %conv.i.i = zext i8 %24 to i64, !dbg !1829
  %add1.i.i = add nuw nsw i64 %conv.i.i, 49, !dbg !1829
  %25 = load i32, ptr %nbytes, align 8, !dbg !1829, !tbaa !794
  %conv2.i.i = sext i32 %25 to i64, !dbg !1829
  %add3.i.i = add nsw i64 %add1.i.i, %conv2.i.i, !dbg !1829
  %26 = load i16, ptr %it_flags, align 2, !dbg !1829, !tbaa !920
  %conv4.i.i = zext i16 %26 to i32, !dbg !1829
  %and.i.i = lshr i32 %conv4.i.i, 6, !dbg !1829
  %27 = and i32 %and.i.i, 4, !dbg !1829
  %cond.i.i = zext nneg i32 %27 to i64, !dbg !1829
  %add5.i.i = add nsw i64 %add3.i.i, %cond.i.i, !dbg !1829
  %and8.i.i = shl nuw nsw i32 %conv4.i.i, 2, !dbg !1829
  %28 = and i32 %and8.i.i, 8, !dbg !1829
  %cond10.i.i = zext nneg i32 %28 to i64, !dbg !1829
  %add11.i.i = add nsw i64 %add5.i.i, %cond10.i.i, !dbg !1829
  tail call void @llvm.dbg.value(metadata i64 %add11.i.i, metadata !1010, metadata !DIExpression()), !dbg !1827
  %slabs_clsid.i.i = getelementptr inbounds i8, ptr %it, i64 40, !dbg !1830
  %29 = load i8, ptr %slabs_clsid.i.i, align 8, !dbg !1830, !tbaa !917
  %30 = and i8 %29, 63, !dbg !1830
  %and13.i.i = zext nneg i8 %30 to i32, !dbg !1830
  tail call void @llvm.dbg.value(metadata i32 %and13.i.i, metadata !1011, metadata !DIExpression()), !dbg !1827
  tail call void @slabs_free(ptr noundef nonnull %it, i64 noundef %add11.i.i, i32 noundef %and13.i.i) #21, !dbg !1831
  br label %if.end, !dbg !1832

if.end:                                           ; preds = %if.then.i, %item_stats_sizes_remove.exit, %entry
  ret void, !dbg !1833
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, inaccessiblemem: none) uwtable
define internal fastcc void @do_item_unlink_q(ptr noundef readonly %it) unnamed_addr #9 !dbg !1834 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1836, metadata !DIExpression()), !dbg !1839
  %slabs_clsid = getelementptr inbounds i8, ptr %it, i64 40, !dbg !1840
  %0 = load i8, ptr %slabs_clsid, align 8, !dbg !1840, !tbaa !917
  %idxprom = zext i8 %0 to i64, !dbg !1841
  %arrayidx = getelementptr inbounds [256 x ptr], ptr @heads, i64 0, i64 %idxprom, !dbg !1841
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !1837, metadata !DIExpression()), !dbg !1839
  %arrayidx3 = getelementptr inbounds [256 x ptr], ptr @tails, i64 0, i64 %idxprom, !dbg !1842
  tail call void @llvm.dbg.value(metadata ptr %arrayidx3, metadata !1838, metadata !DIExpression()), !dbg !1839
  %1 = load ptr, ptr %arrayidx, align 8, !dbg !1843, !tbaa !910
  %cmp = icmp eq ptr %1, %it, !dbg !1845
  br i1 %cmp, label %if.then, label %if.end, !dbg !1846

if.then:                                          ; preds = %entry
  %2 = load ptr, ptr %it, align 8, !dbg !1847, !tbaa !910
  store ptr %2, ptr %arrayidx, align 8, !dbg !1849, !tbaa !910
  br label %if.end, !dbg !1850

if.end:                                           ; preds = %if.then, %entry
  %3 = load ptr, ptr %arrayidx3, align 8, !dbg !1851, !tbaa !910
  %cmp4 = icmp eq ptr %3, %it, !dbg !1853
  br i1 %cmp4, label %if.then5, label %if.end6, !dbg !1854

if.then5:                                         ; preds = %if.end
  %prev = getelementptr inbounds i8, ptr %it, i64 8, !dbg !1855
  %4 = load ptr, ptr %prev, align 8, !dbg !1855, !tbaa !910
  store ptr %4, ptr %arrayidx3, align 8, !dbg !1857, !tbaa !910
  br label %if.end6, !dbg !1858

if.end6:                                          ; preds = %if.then5, %if.end
  %5 = load ptr, ptr %it, align 8, !dbg !1859, !tbaa !910
  %tobool.not = icmp eq ptr %5, null, !dbg !1861
  %prev13.phi.trans.insert = getelementptr inbounds i8, ptr %it, i64 8
  %.pre = load ptr, ptr %prev13.phi.trans.insert, align 8, !dbg !1839, !tbaa !910
  br i1 %tobool.not, label %if.end12, label %if.then8, !dbg !1862

if.then8:                                         ; preds = %if.end6
  %prev11 = getelementptr inbounds i8, ptr %5, i64 8, !dbg !1863
  store ptr %.pre, ptr %prev11, align 8, !dbg !1864, !tbaa !910
  br label %if.end12, !dbg !1865

if.end12:                                         ; preds = %if.end6, %if.then8
  %tobool14.not = icmp eq ptr %.pre, null, !dbg !1866
  br i1 %tobool14.not, label %if.end19, label %if.then15, !dbg !1868

if.then15:                                        ; preds = %if.end12
  %6 = load ptr, ptr %it, align 8, !dbg !1869, !tbaa !910
  store ptr %6, ptr %.pre, align 8, !dbg !1870, !tbaa !910
  br label %if.end19, !dbg !1871

if.end19:                                         ; preds = %if.then15, %if.end12
  %7 = load i8, ptr %slabs_clsid, align 8, !dbg !1872, !tbaa !917
  %idxprom21 = zext i8 %7 to i64, !dbg !1873
  %arrayidx22 = getelementptr inbounds [256 x i32], ptr @sizes, i64 0, i64 %idxprom21, !dbg !1873
  %8 = load i32, ptr %arrayidx22, align 4, !dbg !1874, !tbaa !794
  %dec = add i32 %8, -1, !dbg !1874
  store i32 %dec, ptr %arrayidx22, align 4, !dbg !1874, !tbaa !794
  %it_flags = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1875
  %9 = load i16, ptr %it_flags, align 2, !dbg !1875, !tbaa !920
  %conv = zext i16 %9 to i32, !dbg !1877
  %and = and i32 %conv, 128, !dbg !1878
  %tobool23.not = icmp eq i32 %and, 0, !dbg !1878
  %nkey47 = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1879
  %10 = load i8, ptr %nkey47, align 1, !dbg !1879, !tbaa !917
  %conv48 = zext i8 %10 to i64, !dbg !1879
  br i1 %tobool23.not, label %if.else, label %if.then24, !dbg !1880

if.then24:                                        ; preds = %if.end19
  %and31 = lshr i32 %conv, 6, !dbg !1881
  %11 = and i32 %and31, 4, !dbg !1881
  %and36 = shl nuw nsw i32 %conv, 2, !dbg !1881
  %12 = and i32 %and36, 8, !dbg !1881
  %arrayidx45 = getelementptr inbounds [256 x i64], ptr @sizes_bytes, i64 0, i64 %idxprom21, !dbg !1883
  %13 = load i64, ptr %arrayidx45, align 8, !dbg !1884, !tbaa !765
  %14 = or disjoint i32 %11, %12, !dbg !1885
  %15 = zext nneg i32 %14 to i64, !dbg !1885
  %16 = add nuw nsw i64 %15, %conv48, !dbg !1886
  %reass.sub = sub i64 %13, %16, !dbg !1884
  %sub46 = add i64 %reass.sub, -61, !dbg !1884
  store i64 %sub46, ptr %arrayidx45, align 8, !dbg !1884, !tbaa !765
  br label %if.end70, !dbg !1887

if.else:                                          ; preds = %if.end19
  %nbytes51 = getelementptr inbounds i8, ptr %it, i64 32, !dbg !1888
  %17 = load i32, ptr %nbytes51, align 8, !dbg !1888, !tbaa !794
  %conv52 = sext i32 %17 to i64, !dbg !1888
  %and56 = lshr i32 %conv, 6, !dbg !1888
  %18 = and i32 %and56, 4, !dbg !1888
  %and62 = shl nuw nsw i32 %conv, 2, !dbg !1888
  %19 = and i32 %and62, 8, !dbg !1888
  %arrayidx68 = getelementptr inbounds [256 x i64], ptr @sizes_bytes, i64 0, i64 %idxprom21, !dbg !1890
  %20 = load i64, ptr %arrayidx68, align 8, !dbg !1891, !tbaa !765
  %21 = or disjoint i32 %18, %19, !dbg !1888
  %22 = zext nneg i32 %21 to i64, !dbg !1888
  %23 = add nuw nsw i64 %22, %conv48, !dbg !1888
  %24 = add nsw i64 %23, %conv52, !dbg !1888
  %reass.sub98 = sub i64 %20, %24, !dbg !1891
  %sub69 = add i64 %reass.sub98, -49, !dbg !1891
  store i64 %sub69, ptr %arrayidx68, align 8, !dbg !1891, !tbaa !765
  br label %if.end70

if.end70:                                         ; preds = %if.else, %if.then24
  ret void, !dbg !1892
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @do_item_update(ptr noundef %it) local_unnamed_addr #0 !dbg !1893 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1895, metadata !DIExpression()), !dbg !1896
  %0 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 29), align 8, !dbg !1897, !tbaa !827, !range !828, !noundef !829
  %tobool = trunc nuw i8 %0 to i1, !dbg !1897
  br i1 %tobool, label %if.then, label %if.else26, !dbg !1899

if.then:                                          ; preds = %entry
  %it_flags = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1900
  %1 = load i16, ptr %it_flags, align 2, !dbg !1900, !tbaa !920
  %conv = zext i16 %1 to i32, !dbg !1903
  %and = and i32 %conv, 1, !dbg !1904
  %cmp.not = icmp eq i32 %and, 0, !dbg !1905
  br i1 %cmp.not, label %if.end40, label %if.then2, !dbg !1906

if.then2:                                         ; preds = %if.then
  %slabs_clsid = getelementptr inbounds i8, ptr %it, i64 40, !dbg !1907
  %2 = load i8, ptr %slabs_clsid, align 8, !dbg !1907, !tbaa !917
  %3 = and i8 %2, -64, !dbg !1907
  %cmp5 = icmp ne i8 %3, -128, !dbg !1910
  %and9 = and i32 %conv, 16
  %tobool10.not = icmp eq i32 %and9, 0
  %or.cond = or i1 %tobool10.not, %cmp5, !dbg !1911
  %4 = load volatile i32, ptr @current_time, align 4, !dbg !1912, !tbaa !794
  %time24 = getelementptr inbounds i8, ptr %it, i64 24, !dbg !1912
  store i32 %4, ptr %time24, align 8, !dbg !1912, !tbaa !794
  br i1 %or.cond, label %if.end40, label %if.then11, !dbg !1911

if.then11:                                        ; preds = %if.then2
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1734, metadata !DIExpression()), !dbg !1913
  %idxprom.i = zext i8 %2 to i64, !dbg !1916
  %arrayidx.i = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom.i, !dbg !1916
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx.i) #21, !dbg !1917
  tail call fastcc void @do_item_unlink_q(ptr noundef nonnull %it), !dbg !1918
  %5 = load i8, ptr %slabs_clsid, align 8, !dbg !1919, !tbaa !917
  %idxprom2.i = zext i8 %5 to i64, !dbg !1920
  %arrayidx3.i = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom2.i, !dbg !1920
  %call4.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx3.i) #21, !dbg !1921
  %6 = load i8, ptr %slabs_clsid, align 8, !dbg !1922, !tbaa !917
  %7 = and i8 %6, 63, !dbg !1922
  %8 = or disjoint i8 %7, 64, !dbg !1923
  store i8 %8, ptr %slabs_clsid, align 8, !dbg !1923, !tbaa !917
  %9 = load i16, ptr %it_flags, align 2, !dbg !1924, !tbaa !920
  %10 = and i16 %9, -17, !dbg !1924
  store i16 %10, ptr %it_flags, align 2, !dbg !1924, !tbaa !920
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1925, metadata !DIExpression()), !dbg !1928
  %idxprom.i57 = zext nneg i8 %8 to i64, !dbg !1930
  %arrayidx.i58 = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom.i57, !dbg !1930
  %call.i59 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx.i58) #21, !dbg !1931
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1052, metadata !DIExpression()), !dbg !1932
  %11 = load i8, ptr %slabs_clsid, align 8, !dbg !1934, !tbaa !917
  %idxprom.i.i = zext i8 %11 to i64, !dbg !1935
  %arrayidx.i.i = getelementptr inbounds [256 x ptr], ptr @heads, i64 0, i64 %idxprom.i.i, !dbg !1935
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i.i, metadata !1055, metadata !DIExpression()), !dbg !1932
  %arrayidx3.i.i = getelementptr inbounds [256 x ptr], ptr @tails, i64 0, i64 %idxprom.i.i, !dbg !1936
  tail call void @llvm.dbg.value(metadata ptr %arrayidx3.i.i, metadata !1057, metadata !DIExpression()), !dbg !1932
  %prev.i.i = getelementptr inbounds i8, ptr %it, i64 8, !dbg !1937
  store ptr null, ptr %prev.i.i, align 8, !dbg !1938, !tbaa !910
  %12 = load ptr, ptr %arrayidx.i.i, align 8, !dbg !1939, !tbaa !910
  store ptr %12, ptr %it, align 8, !dbg !1940, !tbaa !910
  %tobool.not.i.i = icmp eq ptr %12, null, !dbg !1941
  br i1 %tobool.not.i.i, label %if.end.i.i, label %if.then.i.i, !dbg !1942

if.then.i.i:                                      ; preds = %if.then11
  %prev6.i.i = getelementptr inbounds i8, ptr %12, i64 8, !dbg !1943
  store ptr %it, ptr %prev6.i.i, align 8, !dbg !1944, !tbaa !910
  br label %if.end.i.i, !dbg !1945

if.end.i.i:                                       ; preds = %if.then.i.i, %if.then11
  store ptr %it, ptr %arrayidx.i.i, align 8, !dbg !1946, !tbaa !910
  %13 = load ptr, ptr %arrayidx3.i.i, align 8, !dbg !1947, !tbaa !910
  %cmp.i.i = icmp eq ptr %13, null, !dbg !1948
  br i1 %cmp.i.i, label %if.then7.i.i, label %if.end8.i.i, !dbg !1949

if.then7.i.i:                                     ; preds = %if.end.i.i
  store ptr %it, ptr %arrayidx3.i.i, align 8, !dbg !1950, !tbaa !910
  br label %if.end8.i.i, !dbg !1951

if.end8.i.i:                                      ; preds = %if.then7.i.i, %if.end.i.i
  %14 = load i8, ptr %slabs_clsid, align 8, !dbg !1952, !tbaa !917
  %idxprom10.i.i = zext i8 %14 to i64, !dbg !1953
  %arrayidx11.i.i = getelementptr inbounds [256 x i32], ptr @sizes, i64 0, i64 %idxprom10.i.i, !dbg !1953
  %15 = load i32, ptr %arrayidx11.i.i, align 4, !dbg !1954, !tbaa !794
  %inc.i.i = add i32 %15, 1, !dbg !1954
  store i32 %inc.i.i, ptr %arrayidx11.i.i, align 4, !dbg !1954, !tbaa !794
  %16 = load i16, ptr %it_flags, align 2, !dbg !1955, !tbaa !920
  %conv.i.i = zext i16 %16 to i32, !dbg !1956
  %and.i.i = and i32 %conv.i.i, 128, !dbg !1957
  %tobool12.not.i.i = icmp eq i32 %and.i.i, 0, !dbg !1957
  %nkey36.i.i = getelementptr inbounds i8, ptr %it, i64 41, !dbg !1958
  %17 = load i8, ptr %nkey36.i.i, align 1, !dbg !1958, !tbaa !917
  %conv37.i.i = zext i8 %17 to i64, !dbg !1958
  br i1 %tobool12.not.i.i, label %if.else.i.i, label %if.then13.i.i, !dbg !1959

if.then13.i.i:                                    ; preds = %if.end8.i.i
  %and20.i.i = lshr i32 %conv.i.i, 6, !dbg !1960
  %18 = and i32 %and20.i.i, 4, !dbg !1960
  %and25.i.i = shl nuw nsw i32 %conv.i.i, 2, !dbg !1960
  %19 = and i32 %and25.i.i, 8, !dbg !1960
  %arrayidx34.i.i = getelementptr inbounds [256 x i64], ptr @sizes_bytes, i64 0, i64 %idxprom10.i.i, !dbg !1961
  %20 = load i64, ptr %arrayidx34.i.i, align 8, !dbg !1962, !tbaa !765
  %narrow.i.i = add nuw nsw i32 %18, 61, !dbg !1960
  %narrow83.i.i = add nuw nsw i32 %narrow.i.i, %19, !dbg !1963
  %sub.i.i = zext nneg i32 %narrow83.i.i to i64, !dbg !1963
  %add31.i.i = add nuw nsw i64 %sub.i.i, %conv37.i.i, !dbg !1964
  %add35.i.i = add i64 %add31.i.i, %20, !dbg !1962
  store i64 %add35.i.i, ptr %arrayidx34.i.i, align 8, !dbg !1962, !tbaa !765
  br label %item_link_q_warm.exit, !dbg !1965

if.else.i.i:                                      ; preds = %if.end8.i.i
  %nbytes40.i.i = getelementptr inbounds i8, ptr %it, i64 32, !dbg !1966
  %21 = load i32, ptr %nbytes40.i.i, align 8, !dbg !1966, !tbaa !794
  %conv41.i.i = sext i32 %21 to i64, !dbg !1966
  %and45.i.i = lshr i32 %conv.i.i, 6, !dbg !1966
  %22 = and i32 %and45.i.i, 4, !dbg !1966
  %and51.i.i = shl nuw nsw i32 %conv.i.i, 2, !dbg !1966
  %23 = and i32 %and51.i.i, 8, !dbg !1966
  %arrayidx57.i.i = getelementptr inbounds [256 x i64], ptr @sizes_bytes, i64 0, i64 %idxprom10.i.i, !dbg !1967
  %24 = load i64, ptr %arrayidx57.i.i, align 8, !dbg !1968, !tbaa !765
  %25 = or disjoint i32 %22, %23, !dbg !1966
  %add4284.i.i = or disjoint i32 %25, 49, !dbg !1966
  %add42.i.i = zext nneg i32 %add4284.i.i to i64, !dbg !1966
  %add48.i.i = add nuw nsw i64 %add42.i.i, %conv37.i.i, !dbg !1966
  %add54.i.i = add nsw i64 %add48.i.i, %conv41.i.i, !dbg !1966
  %add58.i.i = add i64 %add54.i.i, %24, !dbg !1968
  store i64 %add58.i.i, ptr %arrayidx57.i.i, align 8, !dbg !1968, !tbaa !765
  br label %item_link_q_warm.exit

item_link_q_warm.exit:                            ; preds = %if.then13.i.i, %if.else.i.i
  %moves_to_warm.i = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %idxprom10.i.i, i32 12, !dbg !1969
  %26 = load i64, ptr %moves_to_warm.i, align 8, !dbg !1970, !tbaa !1115
  %inc.i = add i64 %26, 1, !dbg !1970
  store i64 %inc.i, ptr %moves_to_warm.i, align 8, !dbg !1970, !tbaa !1115
  %arrayidx6.i = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom10.i.i, !dbg !1971
  %call7.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx6.i) #21, !dbg !1972
  br label %if.end40, !dbg !1973

if.else26:                                        ; preds = %entry
  %time27 = getelementptr inbounds i8, ptr %it, i64 24, !dbg !1974
  %27 = load i32, ptr %time27, align 8, !dbg !1974, !tbaa !794
  %28 = load volatile i32, ptr @current_time, align 4, !dbg !1976, !tbaa !794
  %sub = add i32 %28, -60, !dbg !1977
  %cmp28 = icmp ult i32 %27, %sub, !dbg !1978
  br i1 %cmp28, label %if.then30, label %if.end40, !dbg !1979

if.then30:                                        ; preds = %if.else26
  %it_flags31 = getelementptr inbounds i8, ptr %it, i64 38, !dbg !1980
  %29 = load i16, ptr %it_flags31, align 2, !dbg !1980, !tbaa !920
  %30 = and i16 %29, 1, !dbg !1983
  %cmp34.not = icmp eq i16 %30, 0, !dbg !1984
  br i1 %cmp34.not, label %if.end40, label %if.then36, !dbg !1985

if.then36:                                        ; preds = %if.then30
  %31 = load volatile i32, ptr @current_time, align 4, !dbg !1986, !tbaa !794
  store i32 %31, ptr %time27, align 8, !dbg !1988, !tbaa !794
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !1734, metadata !DIExpression()), !dbg !1989
  %slabs_clsid.i60 = getelementptr inbounds i8, ptr %it, i64 40, !dbg !1991
  %32 = load i8, ptr %slabs_clsid.i60, align 8, !dbg !1991, !tbaa !917
  %idxprom.i61 = zext i8 %32 to i64, !dbg !1992
  %arrayidx.i62 = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom.i61, !dbg !1992
  %call.i63 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx.i62) #21, !dbg !1993
  tail call fastcc void @do_item_unlink_q(ptr noundef nonnull %it), !dbg !1994
  %33 = load i8, ptr %slabs_clsid.i60, align 8, !dbg !1995, !tbaa !917
  %idxprom2.i64 = zext i8 %33 to i64, !dbg !1996
  %arrayidx3.i65 = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom2.i64, !dbg !1996
  %call4.i66 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx3.i65) #21, !dbg !1997
  tail call fastcc void @item_link_q(ptr noundef nonnull %it), !dbg !1998
  br label %if.end40, !dbg !1999

if.end40:                                         ; preds = %if.then2, %if.else26, %if.then36, %if.then30, %if.then, %item_link_q_warm.exit
  ret void, !dbg !2000
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef i32 @do_item_replace(ptr noundef %it, ptr noundef %new_it, i32 noundef %hv, i64 noundef %cas) local_unnamed_addr #0 !dbg !2001 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !2005, metadata !DIExpression()), !dbg !2009
  tail call void @llvm.dbg.value(metadata ptr %new_it, metadata !2006, metadata !DIExpression()), !dbg !2009
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !2007, metadata !DIExpression()), !dbg !2009
  tail call void @llvm.dbg.value(metadata i64 %cas, metadata !2008, metadata !DIExpression()), !dbg !2009
  tail call void @do_item_unlink(ptr noundef %it, i32 noundef %hv), !dbg !2010
  %call = tail call i32 @do_item_link(ptr noundef %new_it, i32 noundef %hv, i64 noundef %cas), !dbg !2011
  ret i32 1, !dbg !2012
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @item_flush_expired() local_unnamed_addr #0 !dbg !2013 {
entry:
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 6), align 4, !dbg !2026, !tbaa !787
  %cmp = icmp eq i32 %0, 0, !dbg !2028
  br i1 %cmp, label %cleanup55, label %for.body, !dbg !2029

for.body:                                         ; preds = %entry, %for.end
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.end ], [ 0, %entry ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2015, metadata !DIExpression()), !dbg !2030
  %arrayidx = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %indvars.iv, !dbg !2031
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx) #21, !dbg !2032
  %arrayidx3 = getelementptr inbounds [256 x ptr], ptr @heads, i64 0, i64 %indvars.iv, !dbg !2033
  %1 = load ptr, ptr %arrayidx3, align 8, !dbg !2033, !tbaa !910
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !2016, metadata !DIExpression()), !dbg !2030
  %cmp5.not82 = icmp eq ptr %1, null, !dbg !2034
  br i1 %cmp5.not82, label %for.end, label %for.body6, !dbg !2035

for.body6:                                        ; preds = %for.body, %cleanup49
  %iter.083 = phi ptr [ %2, %cleanup49 ], [ %1, %for.body ]
  tail call void @llvm.dbg.value(metadata ptr %iter.083, metadata !2016, metadata !DIExpression()), !dbg !2030
  tail call void @llvm.dbg.value(metadata ptr null, metadata !2018, metadata !DIExpression()), !dbg !2036
  %2 = load ptr, ptr %iter.083, align 8, !dbg !2037, !tbaa !910
  tail call void @llvm.dbg.value(metadata ptr %2, metadata !2017, metadata !DIExpression()), !dbg !2030
  %time = getelementptr inbounds i8, ptr %iter.083, i64 24, !dbg !2038
  %3 = load i32, ptr %time, align 8, !dbg !2038, !tbaa !794
  %cmp8 = icmp eq i32 %3, 0, !dbg !2040
  %nkey = getelementptr inbounds i8, ptr %iter.083, i64 41
  %4 = load i8, ptr %nkey, align 1, !dbg !2036, !tbaa !917
  %cmp9 = icmp eq i8 %4, 0
  %or.cond = select i1 %cmp8, i1 %cmp9, i1 false, !dbg !2041
  br i1 %or.cond, label %land.lhs.true11, label %if.end16, !dbg !2041

land.lhs.true11:                                  ; preds = %for.body6
  %it_flags = getelementptr inbounds i8, ptr %iter.083, i64 38, !dbg !2042
  %5 = load i16, ptr %it_flags, align 2, !dbg !2042, !tbaa !920
  %cmp13 = icmp eq i16 %5, 1, !dbg !2043
  br i1 %cmp13, label %cleanup49, label %if.end16, !dbg !2044

if.end16:                                         ; preds = %for.body6, %land.lhs.true11
  %6 = phi i8 [ 0, %land.lhs.true11 ], [ %4, %for.body6 ], !dbg !2045
  %7 = load ptr, ptr @hash, align 8, !dbg !2046, !tbaa !910
  %data = getelementptr inbounds i8, ptr %iter.083, i64 48, !dbg !2047
  %it_flags17 = getelementptr inbounds i8, ptr %iter.083, i64 38, !dbg !2047
  %8 = load i16, ptr %it_flags17, align 2, !dbg !2047, !tbaa !920
  %9 = shl i16 %8, 2, !dbg !2047
  %10 = and i16 %9, 8, !dbg !2047
  %cond = zext nneg i16 %10 to i64, !dbg !2047
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %cond, !dbg !2047
  %nkey19 = getelementptr inbounds i8, ptr %iter.083, i64 41, !dbg !2045
  %conv20 = zext i8 %6 to i64, !dbg !2048
  %call21 = tail call i32 %7(ptr noundef nonnull %add.ptr, i64 noundef %conv20) #21, !dbg !2046
  tail call void @llvm.dbg.value(metadata i32 %call21, metadata !2025, metadata !DIExpression()), !dbg !2036
  %call22 = tail call ptr @item_trylock(i32 noundef %call21) #21, !dbg !2049
  tail call void @llvm.dbg.value(metadata ptr %call22, metadata !2018, metadata !DIExpression()), !dbg !2036
  %cmp23 = icmp eq ptr %call22, null, !dbg !2051
  br i1 %cmp23, label %cleanup49, label %if.end26, !dbg !2052

if.end26:                                         ; preds = %if.end16
  %11 = load i32, ptr %time, align 8, !dbg !2053, !tbaa !794
  %12 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 6), align 4, !dbg !2055, !tbaa !787
  %cmp28.not = icmp ult i32 %11, %12, !dbg !2056
  br i1 %cmp28.not, label %cleanup49.thread, label %if.then30, !dbg !2057

if.then30:                                        ; preds = %if.end26
  %13 = load i16, ptr %it_flags17, align 2, !dbg !2058, !tbaa !920
  %14 = and i16 %13, 4, !dbg !2061
  %cmp34 = icmp eq i16 %14, 0, !dbg !2062
  br i1 %cmp34, label %do.body, label %if.end47, !dbg !2063

do.body:                                          ; preds = %if.then30
  %15 = load ptr, ptr @ext_storage, align 8, !dbg !2064, !tbaa !910
  tail call void @storage_delete(ptr noundef %15, ptr noundef nonnull %iter.083) #21, !dbg !2064
  %16 = load ptr, ptr @hash, align 8, !dbg !2067, !tbaa !910
  %17 = load i16, ptr %it_flags17, align 2, !dbg !2068, !tbaa !920
  %18 = shl i16 %17, 2, !dbg !2068
  %19 = and i16 %18, 8, !dbg !2068
  %cond42 = zext nneg i16 %19 to i64, !dbg !2068
  %add.ptr43 = getelementptr inbounds i8, ptr %data, i64 %cond42, !dbg !2068
  %20 = load i8, ptr %nkey19, align 1, !dbg !2069, !tbaa !917
  %conv45 = zext i8 %20 to i64, !dbg !2070
  %call46 = tail call i32 %16(ptr noundef nonnull %add.ptr43, i64 noundef %conv45) #21, !dbg !2067
  tail call void @do_item_unlink_nolock(ptr noundef nonnull %iter.083, i32 noundef %call46), !dbg !2071
  br label %if.end47, !dbg !2072

if.end47:                                         ; preds = %do.body, %if.then30
  tail call void @item_trylock_unlock(ptr noundef nonnull %call22) #21, !dbg !2073
  br label %cleanup49, !dbg !2074

cleanup49.thread:                                 ; preds = %if.end26
  tail call void @item_trylock_unlock(ptr noundef nonnull %call22) #21, !dbg !2075
  br label %for.end

cleanup49:                                        ; preds = %if.end47, %if.end16, %land.lhs.true11
  tail call void @llvm.dbg.value(metadata ptr %2, metadata !2016, metadata !DIExpression()), !dbg !2030
  %cmp5.not = icmp eq ptr %2, null, !dbg !2034
  br i1 %cmp5.not, label %for.end, label %for.body6, !dbg !2035

for.end:                                          ; preds = %cleanup49, %for.body, %cleanup49.thread
  %call52 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #21, !dbg !2077
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !2078
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !2015, metadata !DIExpression()), !dbg !2030
  %exitcond.not = icmp eq i64 %indvars.iv.next, 256, !dbg !2079
  br i1 %exitcond.not, label %cleanup55, label %for.body, !dbg !2080, !llvm.loop !2081

cleanup55:                                        ; preds = %for.end, %entry
  ret void, !dbg !2083
}

declare !dbg !2084 ptr @item_trylock(i32 noundef) local_unnamed_addr #7

declare !dbg !2087 void @storage_delete(ptr noundef, ptr noundef) local_unnamed_addr #7

declare !dbg !2091 void @item_trylock_unlock(ptr noundef) local_unnamed_addr #7

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noalias noundef ptr @item_cachedump(i32 noundef %slabs_clsid, i32 noundef %limit, ptr nocapture noundef writeonly %bytes) local_unnamed_addr #0 !dbg !2092 {
entry:
  %key_temp = alloca [251 x i8], align 16, !DIAssignID !2114
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2105, metadata !DIExpression(), metadata !2114, metadata ptr %key_temp, metadata !DIExpression()), !dbg !2115
  %temp = alloca [512 x i8], align 16, !DIAssignID !2116
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2109, metadata !DIExpression(), metadata !2116, metadata ptr %temp, metadata !DIExpression()), !dbg !2115
  tail call void @llvm.dbg.value(metadata i32 %slabs_clsid, metadata !2096, metadata !DIExpression()), !dbg !2115
  tail call void @llvm.dbg.value(metadata i32 %limit, metadata !2097, metadata !DIExpression()), !dbg !2115
  tail call void @llvm.dbg.value(metadata ptr %bytes, metadata !2098, metadata !DIExpression()), !dbg !2115
  tail call void @llvm.dbg.value(metadata i32 2097152, metadata !2099, metadata !DIExpression()), !dbg !2115
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2104, metadata !DIExpression()), !dbg !2115
  call void @llvm.lifetime.start.p0(i64 251, ptr nonnull %key_temp) #21, !dbg !2117
  call void @llvm.lifetime.start.p0(i64 512, ptr nonnull %temp) #21, !dbg !2118
  tail call void @llvm.dbg.value(metadata i32 %slabs_clsid, metadata !2113, metadata !DIExpression()), !dbg !2115
  %or = or i32 %slabs_clsid, 128, !dbg !2119
  tail call void @llvm.dbg.value(metadata i32 %or, metadata !2113, metadata !DIExpression()), !dbg !2115
  %idxprom = zext i32 %or to i64, !dbg !2120
  %arrayidx = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom, !dbg !2120
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx) #21, !dbg !2121
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2102, metadata !DIExpression()), !dbg !2115
  %call3 = tail call noalias dereferenceable_or_null(2097152) ptr @malloc(i64 noundef 2097152) #22, !dbg !2122
  tail call void @llvm.dbg.value(metadata ptr %call3, metadata !2100, metadata !DIExpression()), !dbg !2115
  %cmp = icmp eq ptr %call3, null, !dbg !2123
  br i1 %cmp, label %if.then, label %while.cond.preheader, !dbg !2125

while.cond.preheader:                             ; preds = %entry
  %arrayidx2 = getelementptr inbounds [256 x ptr], ptr @heads, i64 0, i64 %idxprom, !dbg !2126
  %0 = add i32 %limit, -1
  %it.099104 = load ptr, ptr %arrayidx2, align 8, !dbg !2115, !tbaa !910
  %cmp8.not100105 = icmp eq ptr %it.099104, null, !dbg !2127
  br i1 %cmp8.not100105, label %while.end, label %while.body.lr.ph, !dbg !2128

if.then:                                          ; preds = %entry
  %call7 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #21, !dbg !2129
  br label %cleanup, !dbg !2131

while.body:                                       ; preds = %while.body.lr.ph, %if.then20
  %it.0102 = phi ptr [ %it.099109, %while.body.lr.ph ], [ %it.0, %if.then20 ]
  %nbytes = getelementptr inbounds i8, ptr %it.0102, i64 32, !dbg !2132
  %1 = load i32, ptr %nbytes, align 8, !dbg !2132, !tbaa !794
  %cmp14 = icmp eq i32 %1, 0, !dbg !2135
  br i1 %cmp14, label %land.lhs.true, label %lor.lhs.false, !dbg !2136

land.lhs.true:                                    ; preds = %while.body
  %nkey = getelementptr inbounds i8, ptr %it.0102, i64 41, !dbg !2137
  %2 = load i8, ptr %nkey, align 1, !dbg !2137, !tbaa !917
  %cmp17 = icmp eq i8 %2, 0, !dbg !2138
  br i1 %cmp17, label %if.then20, label %lor.lhs.false, !dbg !2139

lor.lhs.false:                                    ; preds = %land.lhs.true, %while.body
  %it_flags = getelementptr inbounds i8, ptr %it.0102, i64 38, !dbg !2140
  %3 = load i16, ptr %it_flags, align 2, !dbg !2140, !tbaa !920
  %conv19 = zext i16 %3 to i32, !dbg !2141
  %and = and i32 %conv19, 4096, !dbg !2142
  %tobool.not = icmp eq i32 %and, 0, !dbg !2142
  br i1 %tobool.not, label %if.end21, label %if.then20, !dbg !2143

if.then20:                                        ; preds = %lor.lhs.false, %land.lhs.true
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2102, metadata !DIExpression()), !dbg !2115
  %it.0 = load ptr, ptr %it.0102, align 8, !dbg !2115, !tbaa !910
  tail call void @llvm.dbg.value(metadata i32 %shown.0.ph107, metadata !2104, metadata !DIExpression()), !dbg !2115
  tail call void @llvm.dbg.value(metadata ptr %it.0, metadata !2102, metadata !DIExpression()), !dbg !2115
  tail call void @llvm.dbg.value(metadata i32 %bufcurr.0.ph106, metadata !2101, metadata !DIExpression()), !dbg !2115
  %cmp8.not = icmp eq ptr %it.0, null, !dbg !2127
  br i1 %cmp8.not, label %while.end, label %while.body, !dbg !2128, !llvm.loop !2144

if.end21:                                         ; preds = %lor.lhs.false
  %nbytes.le = getelementptr inbounds i8, ptr %it.0102, i64 32
  %data = getelementptr inbounds i8, ptr %it.0102, i64 48, !dbg !2147
  %and24 = shl nuw nsw i32 %conv19, 2, !dbg !2147
  %4 = and i32 %and24, 8, !dbg !2147
  %cond = zext nneg i32 %4 to i64, !dbg !2147
  %add.ptr = getelementptr inbounds i8, ptr %data, i64 %cond, !dbg !2147
  %nkey26 = getelementptr inbounds i8, ptr %it.0102, i64 41, !dbg !2148
  %5 = load i8, ptr %nkey26, align 1, !dbg !2148, !tbaa !917
  %conv27 = zext i8 %5 to i64, !dbg !2149
  %call28 = call ptr @strncpy(ptr noundef nonnull %key_temp, ptr noundef nonnull %add.ptr, i64 noundef %conv27) #21, !dbg !2150
  %6 = load i8, ptr %nkey26, align 1, !dbg !2151, !tbaa !917
  %idxprom30 = zext i8 %6 to i64, !dbg !2152
  %arrayidx31 = getelementptr inbounds [251 x i8], ptr %key_temp, i64 0, i64 %idxprom30, !dbg !2152
  store i8 0, ptr %arrayidx31, align 1, !dbg !2153, !tbaa !917
  %7 = load i32, ptr %nbytes.le, align 8, !dbg !2154, !tbaa !794
  %sub = add nsw i32 %7, -2, !dbg !2155
  %exptime = getelementptr inbounds i8, ptr %it.0102, i64 28, !dbg !2156
  %8 = load i32, ptr %exptime, align 4, !dbg !2156, !tbaa !794
  %cmp35 = icmp eq i32 %8, 0, !dbg !2157
  br i1 %cmp35, label %cond.end, label %cond.false, !dbg !2158

cond.false:                                       ; preds = %if.end21
  %conv38 = zext i32 %8 to i64, !dbg !2159
  %9 = load i64, ptr @process_started, align 8, !dbg !2160, !tbaa !765
  %add = add i64 %9, %conv38, !dbg !2161
  br label %cond.end, !dbg !2158

cond.end:                                         ; preds = %if.end21, %cond.false
  %cond39 = phi i64 [ %add, %cond.false ], [ 0, %if.end21 ], !dbg !2158
  %call40 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %temp, i64 noundef 512, ptr noundef nonnull @.str, ptr noundef nonnull %key_temp, i32 noundef %sub, i64 noundef %cond39) #21, !dbg !2162
  tail call void @llvm.dbg.value(metadata i32 %call40, metadata !2103, metadata !DIExpression()), !dbg !2115
  %add41 = add i32 %call40, %bufcurr.0.ph106, !dbg !2163
  %10 = add i32 %add41, -2097147, !dbg !2165
  %cmp43 = icmp ult i32 %10, -2097153, !dbg !2165
  br i1 %cmp43, label %while.end, label %if.end46, !dbg !2166

if.end46:                                         ; preds = %cond.end
  %idx.ext = zext i32 %bufcurr.0.ph106 to i64, !dbg !2167
  %add.ptr47 = getelementptr inbounds i8, ptr %call3, i64 %idx.ext, !dbg !2167
  %conv49 = zext i32 %call40 to i64, !dbg !2168
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %add.ptr47, ptr nonnull align 16 %temp, i64 %conv49, i1 false), !dbg !2169
  tail call void @llvm.dbg.value(metadata i32 %add41, metadata !2101, metadata !DIExpression()), !dbg !2115
  %inc = add i32 %shown.0.ph107, 1, !dbg !2170
  tail call void @llvm.dbg.value(metadata i32 %inc, metadata !2104, metadata !DIExpression()), !dbg !2115
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2102, metadata !DIExpression()), !dbg !2115
  %or.cond.not = icmp ult i32 %0, %inc
  %it.099 = load ptr, ptr %it.0102, align 8, !dbg !2115, !tbaa !910
  %cmp8.not100 = icmp eq ptr %it.099, null, !dbg !2127
  %or.cond101 = select i1 %cmp8.not100, i1 true, i1 %or.cond.not, !dbg !2128
  br i1 %or.cond101, label %while.end, label %while.body.lr.ph, !dbg !2128, !llvm.loop !2144

while.body.lr.ph:                                 ; preds = %while.cond.preheader, %if.end46
  %it.099109 = phi ptr [ %it.099, %if.end46 ], [ %it.099104, %while.cond.preheader ]
  %shown.0.ph107 = phi i32 [ %inc, %if.end46 ], [ 0, %while.cond.preheader ]
  %bufcurr.0.ph106 = phi i32 [ %add41, %if.end46 ], [ 0, %while.cond.preheader ]
  br label %while.body, !dbg !2128

while.end:                                        ; preds = %cond.end, %if.end46, %if.then20, %while.cond.preheader
  %bufcurr.0.ph98 = phi i32 [ 0, %while.cond.preheader ], [ %bufcurr.0.ph106, %if.then20 ], [ %add41, %if.end46 ], [ %bufcurr.0.ph106, %cond.end ]
  %idx.ext52 = zext i32 %bufcurr.0.ph98 to i64, !dbg !2171
  %add.ptr53 = getelementptr inbounds i8, ptr %call3, i64 %idx.ext52, !dbg !2171
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(6) %add.ptr53, ptr noundef nonnull align 1 dereferenceable(6) @.str.1, i64 6, i1 false), !dbg !2172
  %add54 = add i32 %bufcurr.0.ph98, 5, !dbg !2173
  tail call void @llvm.dbg.value(metadata i32 %add54, metadata !2101, metadata !DIExpression()), !dbg !2115
  store i32 %add54, ptr %bytes, align 4, !dbg !2174, !tbaa !794
  %call57 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx) #21, !dbg !2175
  br label %cleanup, !dbg !2176

cleanup:                                          ; preds = %while.end, %if.then
  call void @llvm.lifetime.end.p0(i64 512, ptr nonnull %temp) #21, !dbg !2177
  call void @llvm.lifetime.end.p0(i64 251, ptr nonnull %key_temp) #21, !dbg !2177
  ret ptr %call3, !dbg !2177
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare !dbg !2178 noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #10

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: readwrite)
declare !dbg !2182 ptr @strncpy(ptr noalias noundef returned writeonly, ptr noalias nocapture noundef readonly, i64 noundef) local_unnamed_addr #11

; Function Attrs: nofree nounwind
declare !dbg !2188 noundef i32 @snprintf(ptr noalias nocapture noundef writeonly, i64 noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #12

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @fill_item_stats_automove(ptr nocapture noundef writeonly %am) local_unnamed_addr #0 !dbg !2192 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %am, metadata !2206, metadata !DIExpression()), !dbg !2213
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2207, metadata !DIExpression()), !dbg !2213
  br label %for.body, !dbg !2214

for.body:                                         ; preds = %entry, %if.end49
  %indvars.iv = phi i64 [ 0, %entry ], [ %indvars.iv.next, %if.end49 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2207, metadata !DIExpression()), !dbg !2213
  %arrayidx = getelementptr inbounds %struct.item_stats_automove, ptr %am, i64 %indvars.iv, !dbg !2215
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !2208, metadata !DIExpression()), !dbg !2216
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2212, metadata !DIExpression()), !dbg !2216
  %arrayidx2 = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %indvars.iv, !dbg !2217
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx2) #21, !dbg !2218
  %outofmemory = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %indvars.iv, i32 3, !dbg !2219
  %0 = load i64, ptr %outofmemory, align 8, !dbg !2219, !tbaa !1405
  %outofmemory5 = getelementptr inbounds i8, ptr %arrayidx, i64 8, !dbg !2220
  store i64 %0, ptr %outofmemory5, align 8, !dbg !2221, !tbaa !2222
  %call8 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx2) #21, !dbg !2224
  %1 = or disjoint i64 %indvars.iv, 128, !dbg !2225
  tail call void @llvm.dbg.value(metadata i64 %1, metadata !2212, metadata !DIExpression()), !dbg !2216
  %arrayidx11 = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %1, !dbg !2226
  %call12 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx11) #21, !dbg !2227
  %arrayidx14 = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %1, !dbg !2228
  %2 = load i64, ptr %arrayidx14, align 8, !dbg !2229, !tbaa !1141
  store i64 %2, ptr %arrayidx, align 8, !dbg !2230, !tbaa !2231
  %arrayidx17 = getelementptr inbounds [256 x ptr], ptr @tails, i64 0, i64 %1, !dbg !2232
  %3 = load ptr, ptr %arrayidx17, align 8, !dbg !2232, !tbaa !910
  %tobool.not = icmp eq ptr %3, null, !dbg !2232
  br i1 %tobool.not, label %if.end49, label %if.else, !dbg !2234

if.else:                                          ; preds = %for.body
  %nbytes = getelementptr inbounds i8, ptr %3, i64 32, !dbg !2235
  %4 = load i32, ptr %nbytes, align 8, !dbg !2235, !tbaa !794
  %cmp20 = icmp eq i32 %4, 0, !dbg !2237
  br i1 %cmp20, label %land.lhs.true, label %if.end49.sink.split, !dbg !2238

land.lhs.true:                                    ; preds = %if.else
  %nkey = getelementptr inbounds i8, ptr %3, i64 41, !dbg !2239
  %5 = load i8, ptr %nkey, align 1, !dbg !2239, !tbaa !917
  %cmp23 = icmp eq i8 %5, 0, !dbg !2240
  br i1 %cmp23, label %land.lhs.true25, label %if.end49.sink.split, !dbg !2241

land.lhs.true25:                                  ; preds = %land.lhs.true
  %it_flags = getelementptr inbounds i8, ptr %3, i64 38, !dbg !2242
  %6 = load i16, ptr %it_flags, align 2, !dbg !2242, !tbaa !920
  %cmp29 = icmp eq i16 %6, 1, !dbg !2243
  br i1 %cmp29, label %if.then31, label %if.end49.sink.split, !dbg !2244

if.then31:                                        ; preds = %land.lhs.true25
  %prev = getelementptr inbounds i8, ptr %3, i64 8, !dbg !2245
  %7 = load ptr, ptr %prev, align 8, !dbg !2245, !tbaa !910
  %tobool34.not = icmp eq ptr %7, null, !dbg !2248
  br i1 %tobool34.not, label %if.end49, label %if.end49.sink.split, !dbg !2249

if.end49.sink.split:                              ; preds = %if.else, %land.lhs.true, %land.lhs.true25, %if.then31
  %.sink78 = phi ptr [ %7, %if.then31 ], [ %3, %land.lhs.true25 ], [ %3, %land.lhs.true ], [ %3, %if.else ]
  %8 = load volatile i32, ptr @current_time, align 4, !dbg !2250, !tbaa !794
  %time45 = getelementptr inbounds i8, ptr %.sink78, i64 24, !dbg !2250
  %9 = load i32, ptr %time45, align 8, !dbg !2250, !tbaa !794
  %sub46 = sub i32 %8, %9, !dbg !2250
  br label %if.end49, !dbg !2251

if.end49:                                         ; preds = %if.end49.sink.split, %if.then31, %for.body
  %sub46.sink = phi i32 [ 0, %for.body ], [ 0, %if.then31 ], [ %sub46, %if.end49.sink.split ]
  %age47 = getelementptr inbounds i8, ptr %arrayidx, i64 16, !dbg !2251
  store i32 %sub46.sink, ptr %age47, align 8, !dbg !2251, !tbaa !2252
  %call52 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx11) #21, !dbg !2253
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !2254
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !2207, metadata !DIExpression()), !dbg !2213
  %exitcond.not = icmp eq i64 %indvars.iv.next, 64, !dbg !2255
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !2214, !llvm.loop !2256

for.end:                                          ; preds = %if.end49
  ret void, !dbg !2258
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @item_stats_totals(ptr noundef %add_stats, ptr noundef %c) local_unnamed_addr #0 !dbg !2259 {
entry:
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 128), metadata !2277, metadata ptr undef, metadata !DIExpression()), !dbg !2278
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 960, 384), metadata !2279, metadata ptr undef, metadata !DIExpression()), !dbg !2278
  tail call void @llvm.dbg.value(metadata ptr %add_stats, metadata !2268, metadata !DIExpression()), !dbg !2278
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2269, metadata !DIExpression()), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 128), metadata !2280, metadata ptr undef, metadata !DIExpression()), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 960, 384), metadata !2281, metadata ptr undef, metadata !DIExpression()), !dbg !2278
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2271, metadata !DIExpression()), !dbg !2278
  br label %for.cond1.preheader, !dbg !2282

for.cond1.preheader:                              ; preds = %entry, %for.cond1.preheader
  %indvars.iv = phi i64 [ 0, %entry ], [ %indvars.iv.next, %for.cond1.preheader ]
  %totals.sroa.0.0167 = phi i64 [ 0, %entry ], [ %add.3, %for.cond1.preheader ]
  %totals.sroa.12.0157 = phi i64 [ 0, %entry ], [ %add20.3, %for.cond1.preheader ]
  %totals.sroa.995.0156 = phi i64 [ 0, %entry ], [ %add16.3, %for.cond1.preheader ]
  %totals.sroa.693.0155 = phi i64 [ 0, %entry ], [ %add12.3, %for.cond1.preheader ]
  %0 = phi <8 x i64> [ zeroinitializer, %entry ], [ %24, %for.cond1.preheader ]
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.0.0167, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2271, metadata !DIExpression()), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.12.0157, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.995.0156, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.693.0155, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.0.0167, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2272, metadata !DIExpression()), !dbg !2283
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.12.0157, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.995.0156, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.693.0155, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.0.0167, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2272, metadata !DIExpression()), !dbg !2283
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.12.0157, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.995.0156, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.693.0155, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2276, metadata !DIExpression()), !dbg !2283
  %arrayidx5 = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %indvars.iv, !dbg !2284
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx5) #21, !dbg !2288
  %arrayidx7 = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %indvars.iv, !dbg !2289
  %1 = load i64, ptr %arrayidx7, align 8, !dbg !2290, !tbaa !1141
  %add = add i64 %1, %totals.sroa.0.0167, !dbg !2291
  tail call void @llvm.dbg.value(metadata i64 %add, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  %reclaimed = getelementptr inbounds i8, ptr %arrayidx7, i64 16, !dbg !2292
  %2 = load i64, ptr %reclaimed, align 8, !dbg !2292, !tbaa !984
  %add12 = add i64 %2, %totals.sroa.693.0155, !dbg !2293
  tail call void @llvm.dbg.value(metadata i64 %add12, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  %expired_unfetched = getelementptr inbounds i8, ptr %arrayidx7, i64 40, !dbg !2294
  %3 = load i64, ptr %expired_unfetched, align 8, !dbg !2294, !tbaa !753
  %add16 = add i64 %3, %totals.sroa.995.0156, !dbg !2295
  tail call void @llvm.dbg.value(metadata i64 %add16, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  %evicted_unfetched = getelementptr inbounds i8, ptr %arrayidx7, i64 48, !dbg !2296
  %4 = load i64, ptr %evicted_unfetched, align 8, !dbg !2296, !tbaa !1163
  %add20 = add i64 %4, %totals.sroa.12.0157, !dbg !2297
  tail call void @llvm.dbg.value(metadata i64 %add20, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  %evicted_active = getelementptr inbounds i8, ptr %arrayidx7, i64 56, !dbg !2298
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 1, metadata !2272, metadata !DIExpression()), !dbg !2283
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add20, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add16, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add12, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 1, metadata !2272, metadata !DIExpression()), !dbg !2283
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add20, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add16, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add12, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2276, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 64, DW_OP_or, DW_OP_stack_value)), !dbg !2283
  %or.1 = shl i64 %indvars.iv, 32, !dbg !2284
  %sext = ashr exact i64 %or.1, 32, !dbg !2284
  %idxprom4.1 = or i64 %sext, 64, !dbg !2284
  %arrayidx5.1 = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom4.1, !dbg !2284
  %arrayidx7.1 = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %idxprom4.1, !dbg !2289
  tail call void @llvm.dbg.value(metadata i64 %add.1, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  %reclaimed.1 = getelementptr inbounds i8, ptr %arrayidx7.1, i64 16, !dbg !2292
  tail call void @llvm.dbg.value(metadata i64 %add12.1, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  %expired_unfetched.1 = getelementptr inbounds i8, ptr %arrayidx7.1, i64 40, !dbg !2294
  tail call void @llvm.dbg.value(metadata i64 %add16.1, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  %evicted_unfetched.1 = getelementptr inbounds i8, ptr %arrayidx7.1, i64 48, !dbg !2296
  tail call void @llvm.dbg.value(metadata i64 %add20.1, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  %evicted_active.1 = getelementptr inbounds i8, ptr %arrayidx7.1, i64 56, !dbg !2298
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add.1, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 2, metadata !2272, metadata !DIExpression()), !dbg !2283
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add20.1, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add16.1, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add12.1, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add.1, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 2, metadata !2272, metadata !DIExpression()), !dbg !2283
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add20.1, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add16.1, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add12.1, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2276, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 128, DW_OP_or, DW_OP_stack_value)), !dbg !2283
  %or.2 = shl i64 %indvars.iv, 32, !dbg !2284
  %sext170 = ashr exact i64 %or.2, 32, !dbg !2284
  %idxprom4.2 = or i64 %sext170, 128, !dbg !2284
  %arrayidx5.2 = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom4.2, !dbg !2284
  %arrayidx7.2 = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %idxprom4.2, !dbg !2289
  tail call void @llvm.dbg.value(metadata i64 %add.2, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  %reclaimed.2 = getelementptr inbounds i8, ptr %arrayidx7.2, i64 16, !dbg !2292
  tail call void @llvm.dbg.value(metadata i64 %add12.2, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  %expired_unfetched.2 = getelementptr inbounds i8, ptr %arrayidx7.2, i64 40, !dbg !2294
  tail call void @llvm.dbg.value(metadata i64 %add16.2, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  %evicted_unfetched.2 = getelementptr inbounds i8, ptr %arrayidx7.2, i64 48, !dbg !2296
  tail call void @llvm.dbg.value(metadata i64 %add20.2, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  %evicted_active.2 = getelementptr inbounds i8, ptr %arrayidx7.2, i64 56, !dbg !2298
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add.2, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 3, metadata !2272, metadata !DIExpression()), !dbg !2283
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add20.2, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add16.2, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add12.2, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add.2, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 3, metadata !2272, metadata !DIExpression()), !dbg !2283
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add20.2, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add16.2, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add12.2, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2276, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 192, DW_OP_or, DW_OP_stack_value)), !dbg !2283
  %or.3 = shl i64 %indvars.iv, 32, !dbg !2284
  %sext171 = ashr exact i64 %or.3, 32, !dbg !2284
  %idxprom4.3 = or i64 %sext171, 192, !dbg !2284
  %arrayidx5.3 = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom4.3, !dbg !2284
  %arrayidx7.3 = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %idxprom4.3, !dbg !2289
  tail call void @llvm.dbg.value(metadata i64 %add.3, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  %reclaimed.3 = getelementptr inbounds i8, ptr %arrayidx7.3, i64 16, !dbg !2292
  tail call void @llvm.dbg.value(metadata i64 %add12.3, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  %expired_unfetched.3 = getelementptr inbounds i8, ptr %arrayidx7.3, i64 40, !dbg !2294
  tail call void @llvm.dbg.value(metadata i64 %add16.3, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  %evicted_unfetched.3 = getelementptr inbounds i8, ptr %arrayidx7.3, i64 48, !dbg !2296
  tail call void @llvm.dbg.value(metadata i64 %add20.3, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  %evicted_active.3 = getelementptr inbounds i8, ptr %arrayidx7.3, i64 56, !dbg !2298
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  %5 = load <8 x i64>, ptr %evicted_active, align 8, !dbg !2298, !tbaa !765
  %6 = add <8 x i64> %5, %0, !dbg !2299
  %call55 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx5) #21, !dbg !2300
  %call.1 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx5.1) #21, !dbg !2288
  %7 = load i64, ptr %arrayidx7.1, align 8, !dbg !2290, !tbaa !1141
  %add.1 = add i64 %7, %add, !dbg !2291
  %8 = load i64, ptr %reclaimed.1, align 8, !dbg !2292, !tbaa !984
  %add12.1 = add i64 %8, %add12, !dbg !2293
  %9 = load i64, ptr %expired_unfetched.1, align 8, !dbg !2294, !tbaa !753
  %add16.1 = add i64 %9, %add16, !dbg !2295
  %10 = load i64, ptr %evicted_unfetched.1, align 8, !dbg !2296, !tbaa !1163
  %add20.1 = add i64 %10, %add20, !dbg !2297
  %11 = load <8 x i64>, ptr %evicted_active.1, align 8, !dbg !2298, !tbaa !765
  %12 = add <8 x i64> %11, %6, !dbg !2299
  %call55.1 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx5.1) #21, !dbg !2300
  %call.2 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx5.2) #21, !dbg !2288
  %13 = load i64, ptr %arrayidx7.2, align 8, !dbg !2290, !tbaa !1141
  %add.2 = add i64 %13, %add.1, !dbg !2291
  %14 = load i64, ptr %reclaimed.2, align 8, !dbg !2292, !tbaa !984
  %add12.2 = add i64 %14, %add12.1, !dbg !2293
  %15 = load i64, ptr %expired_unfetched.2, align 8, !dbg !2294, !tbaa !753
  %add16.2 = add i64 %15, %add16.1, !dbg !2295
  %16 = load i64, ptr %evicted_unfetched.2, align 8, !dbg !2296, !tbaa !1163
  %add20.2 = add i64 %16, %add20.1, !dbg !2297
  %17 = load <8 x i64>, ptr %evicted_active.2, align 8, !dbg !2298, !tbaa !765
  %18 = add <8 x i64> %17, %12, !dbg !2299
  %call55.2 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx5.2) #21, !dbg !2300
  %call.3 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx5.3) #21, !dbg !2288
  %19 = load i64, ptr %arrayidx7.3, align 8, !dbg !2290, !tbaa !1141
  %add.3 = add i64 %19, %add.2, !dbg !2291
  %20 = load i64, ptr %reclaimed.3, align 8, !dbg !2292, !tbaa !984
  %add12.3 = add i64 %20, %add12.2, !dbg !2293
  %21 = load i64, ptr %expired_unfetched.3, align 8, !dbg !2294, !tbaa !753
  %add16.3 = add i64 %21, %add16.2, !dbg !2295
  %22 = load i64, ptr %evicted_unfetched.3, align 8, !dbg !2296, !tbaa !1163
  %add20.3 = add i64 %22, %add20.2, !dbg !2297
  %23 = load <8 x i64>, ptr %evicted_active.3, align 8, !dbg !2298, !tbaa !765
  %24 = add <8 x i64> %23, %18, !dbg !2299
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  %call55.3 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx5.3) #21, !dbg !2300
  tail call void @llvm.dbg.value(metadata i64 %add.3, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 4, metadata !2272, metadata !DIExpression()), !dbg !2283
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add20.3, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add16.3, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add12.3, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !2301
  tail call void @llvm.dbg.value(metadata i64 %add.3, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !2271, metadata !DIExpression()), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 undef, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add20.3, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add16.3, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2278
  tail call void @llvm.dbg.value(metadata i64 %add12.3, metadata !2270, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2278
  %exitcond.not = icmp eq i64 %indvars.iv.next, 64, !dbg !2302
  br i1 %exitcond.not, label %for.end58, label %for.cond1.preheader, !dbg !2282, !llvm.loop !2303

for.end58:                                        ; preds = %for.cond1.preheader
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.2, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.3, i64 noundef %add16.3) #21, !dbg !2305
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.4, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.3, i64 noundef %add20.3) #21, !dbg !2306
  %25 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 28), align 1, !dbg !2307, !tbaa !2309, !range !828, !noundef !829
  %tobool = trunc nuw i8 %25 to i1, !dbg !2307
  br i1 %tobool, label %if.then, label %if.end, !dbg !2310

if.then:                                          ; preds = %for.end58
  %26 = extractelement <8 x i64> %24, i64 0, !dbg !2311
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.5, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.3, i64 noundef %26) #21, !dbg !2311
  br label %if.end, !dbg !2313

if.end:                                           ; preds = %if.then, %for.end58
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.6, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.3, i64 noundef %add.3) #21, !dbg !2314
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.7, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.3, i64 noundef %add12.3) #21, !dbg !2315
  %27 = extractelement <8 x i64> %24, i64 1, !dbg !2316
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.8, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.3, i64 noundef %27) #21, !dbg !2316
  %28 = extractelement <8 x i64> %24, i64 2, !dbg !2317
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.9, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.3, i64 noundef %28) #21, !dbg !2317
  %29 = extractelement <8 x i64> %24, i64 3, !dbg !2318
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.10, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.3, i64 noundef %29) #21, !dbg !2318
  %30 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 28), align 1, !dbg !2319, !tbaa !2309, !range !828, !noundef !829
  %tobool67 = trunc nuw i8 %30 to i1, !dbg !2319
  br i1 %tobool67, label %if.then68, label %if.end74, !dbg !2321

if.then68:                                        ; preds = %if.end
  %31 = extractelement <8 x i64> %24, i64 4, !dbg !2322
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.11, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.3, i64 noundef %31) #21, !dbg !2322
  %32 = extractelement <8 x i64> %24, i64 5, !dbg !2324
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.12, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.3, i64 noundef %32) #21, !dbg !2324
  %33 = extractelement <8 x i64> %24, i64 6, !dbg !2325
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.13, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.3, i64 noundef %33) #21, !dbg !2325
  %34 = extractelement <8 x i64> %24, i64 7, !dbg !2326
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.14, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.3, i64 noundef %34) #21, !dbg !2326
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2327, metadata !DIExpression()), !dbg !2331
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @bump_buf_lock) #21, !dbg !2333
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2330, metadata !DIExpression()), !dbg !2331
  %b.010.i = load ptr, ptr @bump_buf_head, align 8, !dbg !2334, !tbaa !910
  %cmp.not11.i = icmp eq ptr %b.010.i, null, !dbg !2336
  br i1 %cmp.not11.i, label %lru_total_bumps_dropped.exit, label %for.body.i, !dbg !2338

for.body.i:                                       ; preds = %if.then68, %for.body.i
  %b.013.i = phi ptr [ %b.0.i, %for.body.i ], [ %b.010.i, %if.then68 ]
  %total.012.i = phi i64 [ %add.i, %for.body.i ], [ 0, %if.then68 ]
  tail call void @llvm.dbg.value(metadata i64 %total.012.i, metadata !2327, metadata !DIExpression()), !dbg !2331
  %mutex.i = getelementptr inbounds i8, ptr %b.013.i, i64 16, !dbg !2339
  %call1.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %mutex.i) #21, !dbg !2341
  %dropped.i = getelementptr inbounds i8, ptr %b.013.i, i64 64, !dbg !2342
  %35 = load i64, ptr %dropped.i, align 8, !dbg !2342, !tbaa !2343
  %add.i = add i64 %35, %total.012.i, !dbg !2345
  tail call void @llvm.dbg.value(metadata i64 %add.i, metadata !2327, metadata !DIExpression()), !dbg !2331
  %call3.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %mutex.i) #21, !dbg !2346
  %next.i = getelementptr inbounds i8, ptr %b.013.i, i64 8, !dbg !2347
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2330, metadata !DIExpression()), !dbg !2331
  %b.0.i = load ptr, ptr %next.i, align 8, !dbg !2334, !tbaa !910
  tail call void @llvm.dbg.value(metadata ptr %b.0.i, metadata !2330, metadata !DIExpression()), !dbg !2331
  %cmp.not.i = icmp eq ptr %b.0.i, null, !dbg !2336
  br i1 %cmp.not.i, label %lru_total_bumps_dropped.exit, label %for.body.i, !dbg !2338, !llvm.loop !2348

lru_total_bumps_dropped.exit:                     ; preds = %for.body.i, %if.then68
  %total.0.lcssa.i = phi i64 [ 0, %if.then68 ], [ %add.i, %for.body.i ], !dbg !2331
  %call4.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @bump_buf_lock) #21, !dbg !2350
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.15, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.3, i64 noundef %total.0.lcssa.i) #21, !dbg !2351
  br label %if.end74, !dbg !2352

if.end74:                                         ; preds = %lru_total_bumps_dropped.exit, %if.end
  ret void, !dbg !2353
}

declare !dbg !2354 void @append_stat(ptr noundef, ptr noundef, ptr noundef, ptr noundef, ...) local_unnamed_addr #7

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @item_stats(ptr nocapture noundef readonly %add_stats, ptr noundef %c) local_unnamed_addr #0 !dbg !2757 {
entry:
  %thread_stats = alloca %struct.thread_stats, align 8, !DIAssignID !2782
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2761, metadata !DIExpression(), metadata !2782, metadata ptr %thread_stats, metadata !DIExpression()), !dbg !2783
  %lru_size_map = alloca [4 x i32], align 16, !DIAssignID !2784
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2773, metadata !DIExpression(), metadata !2784, metadata ptr %lru_size_map, metadata !DIExpression()), !dbg !2785
  %key_str = alloca [128 x i8], align 16, !DIAssignID !2786
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2775, metadata !DIExpression(), metadata !2786, metadata ptr %key_str, metadata !DIExpression()), !dbg !2785
  %val_str = alloca [128 x i8], align 16, !DIAssignID !2787
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2779, metadata !DIExpression(), metadata !2787, metadata ptr %val_str, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata ptr %add_stats, metadata !2759, metadata !DIExpression()), !dbg !2783
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2760, metadata !DIExpression()), !dbg !2783
  call void @llvm.lifetime.start.p0(i64 6448, ptr nonnull %thread_stats) #21, !dbg !2788
  call void @threadlocal_stats_aggregate(ptr noundef nonnull %thread_stats) #21, !dbg !2789
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2763, metadata !DIExpression()), !dbg !2783
  %lru_hits131 = getelementptr inbounds i8, ptr %thread_stats, i64 4376
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2763, metadata !DIExpression()), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1280, 32)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1216, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1152, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1088, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1024, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 960, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !2783
  %arrayidx157 = getelementptr inbounds i8, ptr %lru_size_map, i64 4
  %arrayidx165 = getelementptr inbounds i8, ptr %lru_size_map, i64 8
  %arrayidx175 = getelementptr inbounds i8, ptr %lru_size_map, i64 12
  br label %for.body, !dbg !2790

for.body:                                         ; preds = %entry, %cleanup
  %n.0678 = phi i32 [ 0, %entry ], [ %inc389, %cleanup ]
  tail call void @llvm.dbg.value(metadata i32 %n.0678, metadata !2763, metadata !DIExpression()), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 960, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1024, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1088, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1152, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1216, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1280, 32)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1312, 32)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2769, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2770, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2771, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2772, metadata !DIExpression()), !dbg !2785
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %lru_size_map) #21, !dbg !2791
  tail call void @llvm.dbg.value(metadata ptr @.str.16, metadata !2774, metadata !DIExpression()), !dbg !2785
  call void @llvm.lifetime.start.p0(i64 128, ptr nonnull %key_str) #21, !dbg !2792
  call void @llvm.lifetime.start.p0(i64 128, ptr nonnull %val_str) #21, !dbg !2793
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2780, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2781, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2764, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2772, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2771, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2770, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2769, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1280, 32)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1216, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1152, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1088, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1024, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 960, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !2783
  br label %for.body3, !dbg !2794

for.body3:                                        ; preds = %for.body, %sw.epilog
  %indvars.iv = phi i64 [ 0, %for.body ], [ %indvars.iv.next, %sw.epilog ]
  %totals.sroa.0.1677 = phi i64 [ 0, %for.body ], [ %add, %sw.epilog ]
  %age_warm.0676 = phi i32 [ 0, %for.body ], [ %age_warm.1642, %sw.epilog ]
  %age_hot.0675 = phi i32 [ 0, %for.body ], [ %age_hot.1641, %sw.epilog ]
  %age.0674 = phi i32 [ 0, %for.body ], [ %age.1640, %sw.epilog ]
  %size.0673 = phi i32 [ 0, %for.body ], [ %add70, %sw.epilog ]
  %totals.sroa.6.1672 = phi i64 [ 0, %for.body ], [ %add12, %sw.epilog ]
  %totals.sroa.9.1670 = phi i64 [ 0, %for.body ], [ %add16, %sw.epilog ]
  %totals.sroa.59.1669 = phi i32 [ 0, %for.body ], [ %totals.sroa.59.2, %sw.epilog ]
  %totals.sroa.56.1668 = phi i64 [ 0, %for.body ], [ %add67, %sw.epilog ]
  %totals.sroa.54.1667 = phi i64 [ 0, %for.body ], [ %totals.sroa.54.2, %sw.epilog ]
  %totals.sroa.52.1666 = phi i64 [ 0, %for.body ], [ %totals.sroa.52.2, %sw.epilog ]
  %totals.sroa.50.1665 = phi i64 [ 0, %for.body ], [ %totals.sroa.50.2, %sw.epilog ]
  %totals.sroa.48.1664 = phi i64 [ 0, %for.body ], [ %totals.sroa.48.2, %sw.epilog ]
  %totals.sroa.45.1663 = phi i64 [ 0, %for.body ], [ %add64, %sw.epilog ]
  %totals.sroa.42.1662 = phi i64 [ 0, %for.body ], [ %add60, %sw.epilog ]
  %totals.sroa.39.1661 = phi i64 [ 0, %for.body ], [ %add56, %sw.epilog ]
  %totals.sroa.36.1660 = phi i64 [ 0, %for.body ], [ %add52, %sw.epilog ]
  %totals.sroa.33.1659 = phi i64 [ 0, %for.body ], [ %add48, %sw.epilog ]
  %totals.sroa.30.1658 = phi i64 [ 0, %for.body ], [ %add44, %sw.epilog ]
  %totals.sroa.27.1657 = phi i64 [ 0, %for.body ], [ %add40, %sw.epilog ]
  %totals.sroa.24.1656 = phi i64 [ 0, %for.body ], [ %add36, %sw.epilog ]
  %totals.sroa.21.1655 = phi i64 [ 0, %for.body ], [ %add32, %sw.epilog ]
  %totals.sroa.18.1654 = phi i64 [ 0, %for.body ], [ %add28, %sw.epilog ]
  %totals.sroa.15.1653 = phi i64 [ 0, %for.body ], [ %add24, %sw.epilog ]
  %totals.sroa.12.1652 = phi i64 [ 0, %for.body ], [ %add20, %sw.epilog ]
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.0.1677, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i32 %age_warm.0676, metadata !2772, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 %age_hot.0675, metadata !2771, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 %age.0674, metadata !2770, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 %size.0673, metadata !2769, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.6.1672, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2764, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.9.1670, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i32 %totals.sroa.59.1669, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1280, 32)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.56.1668, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1216, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.54.1667, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1152, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.52.1666, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1088, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.50.1665, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1024, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.48.1664, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 960, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.45.1663, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.42.1662, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.39.1661, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.36.1660, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.33.1659, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.30.1658, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.27.1657, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.24.1656, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.21.1655, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.18.1654, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.15.1653, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.12.1652, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !2783
  %arrayidx = getelementptr inbounds [4 x i32], ptr @lru_type_map, i64 0, i64 %indvars.iv, !dbg !2796
  %0 = load i32, ptr %arrayidx, align 4, !dbg !2796, !tbaa !794
  %or = or i32 %0, %n.0678, !dbg !2799
  tail call void @llvm.dbg.value(metadata i32 %or, metadata !2768, metadata !DIExpression()), !dbg !2785
  %idxprom4 = sext i32 %or to i64, !dbg !2800
  %arrayidx5 = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %idxprom4, !dbg !2800
  %call = call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx5) #21, !dbg !2801
  %arrayidx7 = getelementptr inbounds [256 x %struct.itemstats_t], ptr @itemstats, i64 0, i64 %idxprom4, !dbg !2802
  %1 = load i64, ptr %arrayidx7, align 8, !dbg !2803, !tbaa !1141
  %add = add i64 %1, %totals.sroa.0.1677, !dbg !2804
  tail call void @llvm.dbg.value(metadata i64 %add, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2783
  %evicted_nonzero = getelementptr inbounds i8, ptr %arrayidx7, i64 8, !dbg !2805
  %2 = load i64, ptr %evicted_nonzero, align 8, !dbg !2805, !tbaa !1153
  %add12 = add i64 %2, %totals.sroa.6.1672, !dbg !2806
  tail call void @llvm.dbg.value(metadata i64 %add12, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2783
  %reclaimed = getelementptr inbounds i8, ptr %arrayidx7, i64 16, !dbg !2807
  %3 = load i64, ptr %reclaimed, align 8, !dbg !2807, !tbaa !984
  %add16 = add i64 %3, %totals.sroa.9.1670, !dbg !2808
  tail call void @llvm.dbg.value(metadata i64 %add16, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2783
  %outofmemory = getelementptr inbounds i8, ptr %arrayidx7, i64 24, !dbg !2809
  %4 = load i64, ptr %outofmemory, align 8, !dbg !2809, !tbaa !1405
  %add20 = add i64 %4, %totals.sroa.12.1652, !dbg !2810
  tail call void @llvm.dbg.value(metadata i64 %add20, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !2783
  %tailrepairs = getelementptr inbounds i8, ptr %arrayidx7, i64 32, !dbg !2811
  %5 = load i64, ptr %tailrepairs, align 8, !dbg !2811, !tbaa !959
  %add24 = add i64 %5, %totals.sroa.15.1653, !dbg !2812
  tail call void @llvm.dbg.value(metadata i64 %add24, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !2783
  %expired_unfetched = getelementptr inbounds i8, ptr %arrayidx7, i64 40, !dbg !2813
  %6 = load i64, ptr %expired_unfetched, align 8, !dbg !2813, !tbaa !753
  %add28 = add i64 %6, %totals.sroa.18.1654, !dbg !2814
  tail call void @llvm.dbg.value(metadata i64 %add28, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2783
  %evicted_unfetched = getelementptr inbounds i8, ptr %arrayidx7, i64 48, !dbg !2815
  %7 = load i64, ptr %evicted_unfetched, align 8, !dbg !2815, !tbaa !1163
  %add32 = add i64 %7, %totals.sroa.21.1655, !dbg !2816
  tail call void @llvm.dbg.value(metadata i64 %add32, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2783
  %evicted_active = getelementptr inbounds i8, ptr %arrayidx7, i64 56, !dbg !2817
  %8 = load i64, ptr %evicted_active, align 8, !dbg !2817, !tbaa !1171
  %add36 = add i64 %8, %totals.sroa.24.1656, !dbg !2818
  tail call void @llvm.dbg.value(metadata i64 %add36, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2783
  %crawler_reclaimed = getelementptr inbounds i8, ptr %arrayidx7, i64 64, !dbg !2819
  %9 = load i64, ptr %crawler_reclaimed, align 8, !dbg !2819, !tbaa !745
  %add40 = add i64 %9, %totals.sroa.27.1657, !dbg !2820
  tail call void @llvm.dbg.value(metadata i64 %add40, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2783
  %crawler_items_checked = getelementptr inbounds i8, ptr %arrayidx7, i64 72, !dbg !2821
  %10 = load i64, ptr %crawler_items_checked, align 8, !dbg !2821, !tbaa !756
  %add44 = add i64 %10, %totals.sroa.30.1658, !dbg !2822
  tail call void @llvm.dbg.value(metadata i64 %add44, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2783
  %lrutail_reflocked = getelementptr inbounds i8, ptr %arrayidx7, i64 80, !dbg !2823
  %11 = load i64, ptr %lrutail_reflocked, align 8, !dbg !2823, !tbaa !946
  %add48 = add i64 %11, %totals.sroa.33.1659, !dbg !2824
  tail call void @llvm.dbg.value(metadata i64 %add48, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2783
  %moves_to_cold = getelementptr inbounds i8, ptr %arrayidx7, i64 88, !dbg !2825
  %12 = load i64, ptr %moves_to_cold, align 8, !dbg !2825, !tbaa !1128
  %add52 = add i64 %12, %totals.sroa.36.1660, !dbg !2826
  tail call void @llvm.dbg.value(metadata i64 %add52, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2783
  %moves_to_warm = getelementptr inbounds i8, ptr %arrayidx7, i64 96, !dbg !2827
  %13 = load i64, ptr %moves_to_warm, align 8, !dbg !2827, !tbaa !1115
  %add56 = add i64 %13, %totals.sroa.39.1661, !dbg !2828
  tail call void @llvm.dbg.value(metadata i64 %add56, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2783
  %moves_within_lru = getelementptr inbounds i8, ptr %arrayidx7, i64 104, !dbg !2829
  %14 = load i64, ptr %moves_within_lru, align 8, !dbg !2829, !tbaa !1050
  %add60 = add i64 %14, %totals.sroa.42.1662, !dbg !2830
  tail call void @llvm.dbg.value(metadata i64 %add60, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2783
  %direct_reclaims = getelementptr inbounds i8, ptr %arrayidx7, i64 112, !dbg !2831
  %15 = load i64, ptr %direct_reclaims, align 8, !dbg !2831, !tbaa !862
  %add64 = add i64 %15, %totals.sroa.45.1663, !dbg !2832
  tail call void @llvm.dbg.value(metadata i64 %add64, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2783
  %arrayidx66 = getelementptr inbounds [256 x i64], ptr @sizes_bytes, i64 0, i64 %idxprom4, !dbg !2833
  %16 = load i64, ptr %arrayidx66, align 8, !dbg !2833, !tbaa !765
  %add67 = add i64 %16, %totals.sroa.56.1668, !dbg !2834
  tail call void @llvm.dbg.value(metadata i64 %add67, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1216, 64)), !dbg !2783
  %arrayidx69 = getelementptr inbounds [256 x i32], ptr @sizes, i64 0, i64 %idxprom4, !dbg !2835
  %17 = load i32, ptr %arrayidx69, align 4, !dbg !2835, !tbaa !794
  %add70 = add i32 %17, %size.0673, !dbg !2836
  tail call void @llvm.dbg.value(metadata i32 %add70, metadata !2769, metadata !DIExpression()), !dbg !2785
  %arrayidx74 = getelementptr inbounds [4 x i32], ptr %lru_size_map, i64 0, i64 %indvars.iv, !dbg !2837
  store i32 %17, ptr %arrayidx74, align 4, !dbg !2838, !tbaa !794
  %18 = trunc nuw nsw i64 %indvars.iv to i32, !dbg !2839
  switch i32 %18, label %if.end117 [
    i32 2, label %land.lhs.true
    i32 0, label %land.lhs.true86
    i32 1, label %land.lhs.true99
  ], !dbg !2839

land.lhs.true:                                    ; preds = %for.body3
  %arrayidx79 = getelementptr inbounds [256 x ptr], ptr @tails, i64 0, i64 %idxprom4, !dbg !2841
  %19 = load ptr, ptr %arrayidx79, align 8, !dbg !2841, !tbaa !910
  %cmp80.not = icmp eq ptr %19, null, !dbg !2842
  br i1 %cmp80.not, label %if.then113, label %if.then, !dbg !2843

if.then:                                          ; preds = %land.lhs.true
  %20 = load volatile i32, ptr @current_time, align 4, !dbg !2844, !tbaa !794
  %time = getelementptr inbounds i8, ptr %19, i64 24, !dbg !2846
  %21 = load i32, ptr %time, align 8, !dbg !2846, !tbaa !794
  %sub = sub i32 %20, %21, !dbg !2847
  tail call void @llvm.dbg.value(metadata i32 %sub, metadata !2770, metadata !DIExpression()), !dbg !2785
  br label %if.then113, !dbg !2848

land.lhs.true86:                                  ; preds = %for.body3
  %arrayidx88 = getelementptr inbounds [256 x ptr], ptr @tails, i64 0, i64 %idxprom4, !dbg !2849
  %22 = load ptr, ptr %arrayidx88, align 8, !dbg !2849, !tbaa !910
  %cmp89.not = icmp eq ptr %22, null, !dbg !2851
  br i1 %cmp89.not, label %if.end117, label %if.then90, !dbg !2852

if.then90:                                        ; preds = %land.lhs.true86
  %23 = load volatile i32, ptr @current_time, align 4, !dbg !2853, !tbaa !794
  %time93 = getelementptr inbounds i8, ptr %22, i64 24, !dbg !2855
  %24 = load i32, ptr %time93, align 8, !dbg !2855, !tbaa !794
  %sub94 = sub i32 %23, %24, !dbg !2856
  tail call void @llvm.dbg.value(metadata i32 %sub94, metadata !2771, metadata !DIExpression()), !dbg !2785
  br label %if.end117, !dbg !2857

land.lhs.true99:                                  ; preds = %for.body3
  %arrayidx101 = getelementptr inbounds [256 x ptr], ptr @tails, i64 0, i64 %idxprom4, !dbg !2858
  %25 = load ptr, ptr %arrayidx101, align 8, !dbg !2858, !tbaa !910
  %cmp102.not = icmp eq ptr %25, null, !dbg !2860
  br i1 %cmp102.not, label %if.end117, label %if.then103, !dbg !2861

if.then103:                                       ; preds = %land.lhs.true99
  %26 = load volatile i32, ptr @current_time, align 4, !dbg !2862, !tbaa !794
  %time106 = getelementptr inbounds i8, ptr %25, i64 24, !dbg !2864
  %27 = load i32, ptr %time106, align 8, !dbg !2864, !tbaa !794
  %sub107 = sub i32 %26, %27, !dbg !2865
  tail call void @llvm.dbg.value(metadata i32 %sub107, metadata !2772, metadata !DIExpression()), !dbg !2785
  br label %if.end117, !dbg !2866

if.then113:                                       ; preds = %if.then, %land.lhs.true
  %age.1649 = phi i32 [ %age.0674, %land.lhs.true ], [ %sub, %if.then ]
  %evicted_time = getelementptr inbounds i8, ptr %arrayidx7, i64 160, !dbg !2867
  %28 = load i32, ptr %evicted_time, align 8, !dbg !2867, !tbaa !1146
  tail call void @llvm.dbg.value(metadata i32 %28, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1280, 32)), !dbg !2783
  br label %if.end117, !dbg !2869

if.end117:                                        ; preds = %for.body3, %land.lhs.true99, %if.then103, %if.then90, %land.lhs.true86, %if.then113
  %age_warm.1642 = phi i32 [ %age_warm.0676, %if.then113 ], [ %age_warm.0676, %land.lhs.true86 ], [ %age_warm.0676, %land.lhs.true99 ], [ %sub107, %if.then103 ], [ %age_warm.0676, %if.then90 ], [ %age_warm.0676, %for.body3 ]
  %age_hot.1641 = phi i32 [ %age_hot.0675, %if.then113 ], [ %age_hot.0675, %land.lhs.true86 ], [ %age_hot.0675, %land.lhs.true99 ], [ %age_hot.0675, %if.then103 ], [ %sub94, %if.then90 ], [ %age_hot.0675, %for.body3 ]
  %age.1640 = phi i32 [ %age.1649, %if.then113 ], [ %age.0674, %land.lhs.true86 ], [ %age.0674, %land.lhs.true99 ], [ %age.0674, %if.then103 ], [ %age.0674, %if.then90 ], [ %age.0674, %for.body3 ]
  %totals.sroa.59.2 = phi i32 [ %28, %if.then113 ], [ %totals.sroa.59.1669, %land.lhs.true86 ], [ %totals.sroa.59.1669, %land.lhs.true99 ], [ %totals.sroa.59.1669, %if.then103 ], [ %totals.sroa.59.1669, %if.then90 ], [ %totals.sroa.59.1669, %for.body3 ], !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 %totals.sroa.59.2, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1280, 32)), !dbg !2783
  %29 = call i32 @llvm.fshl.i32(i32 %0, i32 %0, i32 26), !dbg !2870
  switch i32 %29, label %sw.epilog [
    i32 0, label %sw.bb
    i32 1, label %sw.bb122
    i32 2, label %sw.bb126
    i32 3, label %sw.bb130
  ], !dbg !2870

sw.bb:                                            ; preds = %if.end117
  %arrayidx121 = getelementptr inbounds [256 x i64], ptr %lru_hits131, i64 0, i64 %idxprom4, !dbg !2871
  %30 = load i64, ptr %arrayidx121, align 8, !dbg !2871, !tbaa !765
  tail call void @llvm.dbg.value(metadata i64 %30, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 960, 64)), !dbg !2783
  br label %sw.epilog, !dbg !2873

sw.bb122:                                         ; preds = %if.end117
  %arrayidx125 = getelementptr inbounds [256 x i64], ptr %lru_hits131, i64 0, i64 %idxprom4, !dbg !2874
  %31 = load i64, ptr %arrayidx125, align 8, !dbg !2874, !tbaa !765
  tail call void @llvm.dbg.value(metadata i64 %31, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1024, 64)), !dbg !2783
  br label %sw.epilog, !dbg !2875

sw.bb126:                                         ; preds = %if.end117
  %arrayidx129 = getelementptr inbounds [256 x i64], ptr %lru_hits131, i64 0, i64 %idxprom4, !dbg !2876
  %32 = load i64, ptr %arrayidx129, align 8, !dbg !2876, !tbaa !765
  tail call void @llvm.dbg.value(metadata i64 %32, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1088, 64)), !dbg !2783
  br label %sw.epilog, !dbg !2877

sw.bb130:                                         ; preds = %if.end117
  %arrayidx133 = getelementptr inbounds [256 x i64], ptr %lru_hits131, i64 0, i64 %idxprom4, !dbg !2878
  %33 = load i64, ptr %arrayidx133, align 8, !dbg !2878, !tbaa !765
  tail call void @llvm.dbg.value(metadata i64 %33, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1152, 64)), !dbg !2783
  br label %sw.epilog, !dbg !2879

sw.epilog:                                        ; preds = %if.end117, %sw.bb130, %sw.bb126, %sw.bb122, %sw.bb
  %totals.sroa.48.2 = phi i64 [ %totals.sroa.48.1664, %if.end117 ], [ %totals.sroa.48.1664, %sw.bb130 ], [ %totals.sroa.48.1664, %sw.bb126 ], [ %totals.sroa.48.1664, %sw.bb122 ], [ %30, %sw.bb ], !dbg !2785
  %totals.sroa.50.2 = phi i64 [ %totals.sroa.50.1665, %if.end117 ], [ %totals.sroa.50.1665, %sw.bb130 ], [ %totals.sroa.50.1665, %sw.bb126 ], [ %31, %sw.bb122 ], [ %totals.sroa.50.1665, %sw.bb ], !dbg !2785
  %totals.sroa.52.2 = phi i64 [ %totals.sroa.52.1666, %if.end117 ], [ %totals.sroa.52.1666, %sw.bb130 ], [ %32, %sw.bb126 ], [ %totals.sroa.52.1666, %sw.bb122 ], [ %totals.sroa.52.1666, %sw.bb ], !dbg !2785
  %totals.sroa.54.2 = phi i64 [ %totals.sroa.54.1667, %if.end117 ], [ %33, %sw.bb130 ], [ %totals.sroa.54.1667, %sw.bb126 ], [ %totals.sroa.54.1667, %sw.bb122 ], [ %totals.sroa.54.1667, %sw.bb ], !dbg !2785
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.54.2, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1152, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.52.2, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1088, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.50.2, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1024, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.48.2, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 960, 64)), !dbg !2783
  %call136 = call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx5) #21, !dbg !2880
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !2881
  tail call void @llvm.dbg.value(metadata i64 %add, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i32 %age_warm.1642, metadata !2772, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 %age_hot.1641, metadata !2771, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 %age.1640, metadata !2770, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 %add70, metadata !2769, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i64 %add12, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !2764, metadata !DIExpression()), !dbg !2785
  tail call void @llvm.dbg.value(metadata i64 %add16, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i32 %totals.sroa.59.2, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1280, 32)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %add67, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1216, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.54.2, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1152, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.52.2, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1088, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.50.2, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1024, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %totals.sroa.48.2, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 960, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %add64, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %add60, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %add56, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %add52, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %add48, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %add44, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %add40, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %add36, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %add32, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %add28, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %add24, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 %add20, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !2783
  %exitcond.not = icmp eq i64 %indvars.iv.next, 4, !dbg !2882
  br i1 %exitcond.not, label %for.end, label %for.body3, !dbg !2794, !llvm.loop !2883

for.end:                                          ; preds = %sw.epilog
  %cmp137 = icmp eq i32 %add70, 0, !dbg !2885
  br i1 %cmp137, label %cleanup, label %if.end139, !dbg !2887

if.end139:                                        ; preds = %for.end
  %call140 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.17) #21, !dbg !2888
  tail call void @llvm.dbg.value(metadata i32 %call140, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call142 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.18, i32 noundef %add70) #21, !dbg !2888
  tail call void @llvm.dbg.value(metadata i32 %call142, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv = trunc i32 %call140 to i16, !dbg !2888
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv, ptr noundef nonnull %val_str, i32 noundef %call142, ptr noundef %c) #21, !dbg !2888
  %34 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 28), align 1, !dbg !2889, !tbaa !2309, !range !828, !noundef !829
  %tobool = trunc nuw i8 %34 to i1, !dbg !2889
  br i1 %tobool, label %if.then145, label %if.end195, !dbg !2891

if.then145:                                       ; preds = %if.end139
  %call147 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.19) #21, !dbg !2892
  tail call void @llvm.dbg.value(metadata i32 %call147, metadata !2780, metadata !DIExpression()), !dbg !2785
  %35 = load i32, ptr %lru_size_map, align 16, !dbg !2892, !tbaa !794
  %call150 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.18, i32 noundef %35) #21, !dbg !2892
  tail call void @llvm.dbg.value(metadata i32 %call150, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv152 = trunc i32 %call147 to i16, !dbg !2892
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv152, ptr noundef nonnull %val_str, i32 noundef %call150, ptr noundef %c) #21, !dbg !2892
  %call155 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.20) #21, !dbg !2894
  tail call void @llvm.dbg.value(metadata i32 %call155, metadata !2780, metadata !DIExpression()), !dbg !2785
  %36 = load i32, ptr %arrayidx157, align 4, !dbg !2894, !tbaa !794
  %call158 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.18, i32 noundef %36) #21, !dbg !2894
  tail call void @llvm.dbg.value(metadata i32 %call158, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv160 = trunc i32 %call155 to i16, !dbg !2894
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv160, ptr noundef nonnull %val_str, i32 noundef %call158, ptr noundef %c) #21, !dbg !2894
  %call163 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.21) #21, !dbg !2895
  tail call void @llvm.dbg.value(metadata i32 %call163, metadata !2780, metadata !DIExpression()), !dbg !2785
  %37 = load i32, ptr %arrayidx165, align 8, !dbg !2895, !tbaa !794
  %call166 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.18, i32 noundef %37) #21, !dbg !2895
  tail call void @llvm.dbg.value(metadata i32 %call166, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv168 = trunc i32 %call163 to i16, !dbg !2895
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv168, ptr noundef nonnull %val_str, i32 noundef %call166, ptr noundef %c) #21, !dbg !2895
  %38 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 47), align 4, !dbg !2896, !tbaa !1411, !range !828, !noundef !829
  %tobool170 = trunc nuw i8 %38 to i1, !dbg !2896
  br i1 %tobool170, label %if.then171, label %if.end180, !dbg !2898

if.then171:                                       ; preds = %if.then145
  %call173 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.22) #21, !dbg !2899
  tail call void @llvm.dbg.value(metadata i32 %call173, metadata !2780, metadata !DIExpression()), !dbg !2785
  %39 = load i32, ptr %arrayidx175, align 4, !dbg !2899, !tbaa !794
  %call176 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.18, i32 noundef %39) #21, !dbg !2899
  tail call void @llvm.dbg.value(metadata i32 %call176, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv178 = trunc i32 %call173 to i16, !dbg !2899
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv178, ptr noundef nonnull %val_str, i32 noundef %call176, ptr noundef %c) #21, !dbg !2899
  br label %if.end180, !dbg !2901

if.end180:                                        ; preds = %if.then171, %if.then145
  %call182 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.23) #21, !dbg !2902
  tail call void @llvm.dbg.value(metadata i32 %call182, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call184 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.18, i32 noundef %age_hot.1641) #21, !dbg !2902
  tail call void @llvm.dbg.value(metadata i32 %call184, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv186 = trunc i32 %call182 to i16, !dbg !2902
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv186, ptr noundef nonnull %val_str, i32 noundef %call184, ptr noundef %c) #21, !dbg !2902
  %call189 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.24) #21, !dbg !2903
  tail call void @llvm.dbg.value(metadata i32 %call189, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call191 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.18, i32 noundef %age_warm.1642) #21, !dbg !2903
  tail call void @llvm.dbg.value(metadata i32 %call191, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv193 = trunc i32 %call189 to i16, !dbg !2903
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv193, ptr noundef nonnull %val_str, i32 noundef %call191, ptr noundef %c) #21, !dbg !2903
  br label %if.end195, !dbg !2904

if.end195:                                        ; preds = %if.end180, %if.end139
  %call197 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.25) #21, !dbg !2905
  tail call void @llvm.dbg.value(metadata i32 %call197, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call199 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.18, i32 noundef %age.1640) #21, !dbg !2905
  tail call void @llvm.dbg.value(metadata i32 %call199, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv201 = trunc i32 %call197 to i16, !dbg !2905
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv201, ptr noundef nonnull %val_str, i32 noundef %call199, ptr noundef %c) #21, !dbg !2905
  %call204 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.26) #21, !dbg !2906
  tail call void @llvm.dbg.value(metadata i32 %call204, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call207 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add67) #21, !dbg !2906
  tail call void @llvm.dbg.value(metadata i32 %call207, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv209 = trunc i32 %call204 to i16, !dbg !2906
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv209, ptr noundef nonnull %val_str, i32 noundef %call207, ptr noundef %c) #21, !dbg !2906
  %call212 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.27) #21, !dbg !2907
  tail call void @llvm.dbg.value(metadata i32 %call212, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call215 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add) #21, !dbg !2907
  tail call void @llvm.dbg.value(metadata i32 %call215, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv217 = trunc i32 %call212 to i16, !dbg !2907
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv217, ptr noundef nonnull %val_str, i32 noundef %call215, ptr noundef %c) #21, !dbg !2907
  %call220 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.28) #21, !dbg !2908
  tail call void @llvm.dbg.value(metadata i32 %call220, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call223 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add12) #21, !dbg !2908
  tail call void @llvm.dbg.value(metadata i32 %call223, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv225 = trunc i32 %call220 to i16, !dbg !2908
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv225, ptr noundef nonnull %val_str, i32 noundef %call223, ptr noundef %c) #21, !dbg !2908
  %call228 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.29) #21, !dbg !2909
  tail call void @llvm.dbg.value(metadata i32 %call228, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call231 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.18, i32 noundef %totals.sroa.59.2) #21, !dbg !2909
  tail call void @llvm.dbg.value(metadata i32 %call231, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv233 = trunc i32 %call228 to i16, !dbg !2909
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv233, ptr noundef nonnull %val_str, i32 noundef %call231, ptr noundef %c) #21, !dbg !2909
  %call236 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.30) #21, !dbg !2910
  tail call void @llvm.dbg.value(metadata i32 %call236, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call239 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add20) #21, !dbg !2910
  tail call void @llvm.dbg.value(metadata i32 %call239, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv241 = trunc i32 %call236 to i16, !dbg !2910
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv241, ptr noundef nonnull %val_str, i32 noundef %call239, ptr noundef %c) #21, !dbg !2910
  %call244 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.31) #21, !dbg !2911
  tail call void @llvm.dbg.value(metadata i32 %call244, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call247 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add24) #21, !dbg !2911
  tail call void @llvm.dbg.value(metadata i32 %call247, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv249 = trunc i32 %call244 to i16, !dbg !2911
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv249, ptr noundef nonnull %val_str, i32 noundef %call247, ptr noundef %c) #21, !dbg !2911
  %call252 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.7) #21, !dbg !2912
  tail call void @llvm.dbg.value(metadata i32 %call252, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call255 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add16) #21, !dbg !2912
  tail call void @llvm.dbg.value(metadata i32 %call255, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv257 = trunc i32 %call252 to i16, !dbg !2912
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv257, ptr noundef nonnull %val_str, i32 noundef %call255, ptr noundef %c) #21, !dbg !2912
  %call260 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.2) #21, !dbg !2913
  tail call void @llvm.dbg.value(metadata i32 %call260, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call263 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add28) #21, !dbg !2913
  tail call void @llvm.dbg.value(metadata i32 %call263, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv265 = trunc i32 %call260 to i16, !dbg !2913
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv265, ptr noundef nonnull %val_str, i32 noundef %call263, ptr noundef %c) #21, !dbg !2913
  %call268 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.4) #21, !dbg !2914
  tail call void @llvm.dbg.value(metadata i32 %call268, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call271 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add32) #21, !dbg !2914
  tail call void @llvm.dbg.value(metadata i32 %call271, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv273 = trunc i32 %call268 to i16, !dbg !2914
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv273, ptr noundef nonnull %val_str, i32 noundef %call271, ptr noundef %c) #21, !dbg !2914
  %40 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 28), align 1, !dbg !2915, !tbaa !2309, !range !828, !noundef !829
  %tobool275 = trunc nuw i8 %40 to i1, !dbg !2915
  br i1 %tobool275, label %if.then276, label %if.end285, !dbg !2917

if.then276:                                       ; preds = %if.end195
  %call278 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.5) #21, !dbg !2918
  tail call void @llvm.dbg.value(metadata i32 %call278, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call281 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add36) #21, !dbg !2918
  tail call void @llvm.dbg.value(metadata i32 %call281, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv283 = trunc i32 %call278 to i16, !dbg !2918
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv283, ptr noundef nonnull %val_str, i32 noundef %call281, ptr noundef %c) #21, !dbg !2918
  br label %if.end285, !dbg !2920

if.end285:                                        ; preds = %if.then276, %if.end195
  %call287 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.8) #21, !dbg !2921
  tail call void @llvm.dbg.value(metadata i32 %call287, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call290 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add40) #21, !dbg !2921
  tail call void @llvm.dbg.value(metadata i32 %call290, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv292 = trunc i32 %call287 to i16, !dbg !2921
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv292, ptr noundef nonnull %val_str, i32 noundef %call290, ptr noundef %c) #21, !dbg !2921
  %call295 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.9) #21, !dbg !2922
  tail call void @llvm.dbg.value(metadata i32 %call295, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call298 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add44) #21, !dbg !2922
  tail call void @llvm.dbg.value(metadata i32 %call298, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv300 = trunc i32 %call295 to i16, !dbg !2922
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv300, ptr noundef nonnull %val_str, i32 noundef %call298, ptr noundef %c) #21, !dbg !2922
  %call303 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.10) #21, !dbg !2923
  tail call void @llvm.dbg.value(metadata i32 %call303, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call306 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add48) #21, !dbg !2923
  tail call void @llvm.dbg.value(metadata i32 %call306, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv308 = trunc i32 %call303 to i16, !dbg !2923
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv308, ptr noundef nonnull %val_str, i32 noundef %call306, ptr noundef %c) #21, !dbg !2923
  %41 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 28), align 1, !dbg !2924, !tbaa !2309, !range !828, !noundef !829
  %tobool310 = trunc nuw i8 %41 to i1, !dbg !2924
  br i1 %tobool310, label %if.then311, label %cleanup, !dbg !2926

if.then311:                                       ; preds = %if.end285
  %call313 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.11) #21, !dbg !2927
  tail call void @llvm.dbg.value(metadata i32 %call313, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call316 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add52) #21, !dbg !2927
  tail call void @llvm.dbg.value(metadata i32 %call316, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv318 = trunc i32 %call313 to i16, !dbg !2927
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv318, ptr noundef nonnull %val_str, i32 noundef %call316, ptr noundef %c) #21, !dbg !2927
  %call321 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.12) #21, !dbg !2929
  tail call void @llvm.dbg.value(metadata i32 %call321, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call324 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add56) #21, !dbg !2929
  tail call void @llvm.dbg.value(metadata i32 %call324, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv326 = trunc i32 %call321 to i16, !dbg !2929
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv326, ptr noundef nonnull %val_str, i32 noundef %call324, ptr noundef %c) #21, !dbg !2929
  %call329 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.13) #21, !dbg !2930
  tail call void @llvm.dbg.value(metadata i32 %call329, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call332 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add60) #21, !dbg !2930
  tail call void @llvm.dbg.value(metadata i32 %call332, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv334 = trunc i32 %call329 to i16, !dbg !2930
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv334, ptr noundef nonnull %val_str, i32 noundef %call332, ptr noundef %c) #21, !dbg !2930
  %call337 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.14) #21, !dbg !2931
  tail call void @llvm.dbg.value(metadata i32 %call337, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call340 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %add64) #21, !dbg !2931
  tail call void @llvm.dbg.value(metadata i32 %call340, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv342 = trunc i32 %call337 to i16, !dbg !2931
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv342, ptr noundef nonnull %val_str, i32 noundef %call340, ptr noundef %c) #21, !dbg !2931
  %call345 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.32) #21, !dbg !2932
  tail call void @llvm.dbg.value(metadata i32 %call345, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call348 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %totals.sroa.48.2) #21, !dbg !2932
  tail call void @llvm.dbg.value(metadata i32 %call348, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv350 = trunc i32 %call345 to i16, !dbg !2932
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv350, ptr noundef nonnull %val_str, i32 noundef %call348, ptr noundef %c) #21, !dbg !2932
  %call353 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.33) #21, !dbg !2933
  tail call void @llvm.dbg.value(metadata i32 %call353, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call356 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %totals.sroa.50.2) #21, !dbg !2933
  tail call void @llvm.dbg.value(metadata i32 %call356, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv358 = trunc i32 %call353 to i16, !dbg !2933
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv358, ptr noundef nonnull %val_str, i32 noundef %call356, ptr noundef %c) #21, !dbg !2933
  %call361 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.34) #21, !dbg !2934
  tail call void @llvm.dbg.value(metadata i32 %call361, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call364 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %totals.sroa.52.2) #21, !dbg !2934
  tail call void @llvm.dbg.value(metadata i32 %call364, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv366 = trunc i32 %call361 to i16, !dbg !2934
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv366, ptr noundef nonnull %val_str, i32 noundef %call364, ptr noundef %c) #21, !dbg !2934
  %call369 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %n.0678, ptr noundef nonnull @.str.35) #21, !dbg !2935
  tail call void @llvm.dbg.value(metadata i32 %call369, metadata !2780, metadata !DIExpression()), !dbg !2785
  %call372 = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str, i64 noundef 128, ptr noundef nonnull @.str.3, i64 noundef %totals.sroa.54.2) #21, !dbg !2935
  tail call void @llvm.dbg.value(metadata i32 %call372, metadata !2781, metadata !DIExpression()), !dbg !2785
  %conv374 = trunc i32 %call369 to i16, !dbg !2935
  call void %add_stats(ptr noundef nonnull %key_str, i16 noundef zeroext %conv374, ptr noundef nonnull %val_str, i32 noundef %call372, ptr noundef %c) #21, !dbg !2935
  br label %cleanup, !dbg !2936

cleanup:                                          ; preds = %if.end285, %if.then311, %for.end
  call void @llvm.lifetime.end.p0(i64 128, ptr nonnull %val_str) #21, !dbg !2937
  call void @llvm.lifetime.end.p0(i64 128, ptr nonnull %key_str) #21, !dbg !2937
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %lru_size_map) #21, !dbg !2937
  %inc389 = add nuw nsw i32 %n.0678, 1, !dbg !2938
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i32 %inc389, metadata !2763, metadata !DIExpression()), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1280, 32)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1216, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1152, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1088, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 1024, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 960, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !2783
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2762, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !2783
  %exitcond680.not = icmp eq i32 %inc389, 64, !dbg !2939
  br i1 %exitcond680.not, label %for.end390, label %for.body, !dbg !2790, !llvm.loop !2940

for.end390:                                       ; preds = %cleanup
  call void %add_stats(ptr noundef null, i16 noundef zeroext 0, ptr noundef null, i32 noundef 0, ptr noundef %c) #21, !dbg !2942
  call void @llvm.lifetime.end.p0(i64 6448, ptr nonnull %thread_stats) #21, !dbg !2943
  ret void, !dbg !2943
}

declare !dbg !2944 void @threadlocal_stats_aggregate(ptr noundef) local_unnamed_addr #7

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i1 @item_stats_sizes_status() local_unnamed_addr #6 !dbg !2948 {
entry:
  tail call void @llvm.dbg.value(metadata i8 0, metadata !2952, metadata !DIExpression()), !dbg !2953
  %0 = load ptr, ptr @stats_sizes_hist, align 8, !dbg !2954, !tbaa !910
  %cmp.not = icmp ne ptr %0, null, !dbg !2956
  tail call void @llvm.dbg.value(metadata i1 %cmp.not, metadata !2952, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2953
  ret i1 %cmp.not, !dbg !2957
}

; Function Attrs: mustprogress nofree nounwind sanitize_thread willreturn memory(readwrite, argmem: none) uwtable
define dso_local void @item_stats_sizes_init() local_unnamed_addr #13 !dbg !2958 {
entry:
  %0 = load ptr, ptr @stats_sizes_hist, align 8, !dbg !2959, !tbaa !910
  %cmp.not = icmp eq ptr %0, null, !dbg !2961
  br i1 %cmp.not, label %if.end, label %return, !dbg !2962

if.end:                                           ; preds = %entry
  %1 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 21), align 4, !dbg !2963, !tbaa !2964
  %div = sdiv i32 %1, 32, !dbg !2965
  %add = add nsw i32 %div, 1, !dbg !2966
  store i32 %add, ptr @stats_sizes_buckets, align 4, !dbg !2967, !tbaa !794
  %conv = sext i32 %add to i64, !dbg !2968
  %call = tail call noalias ptr @calloc(i64 noundef %conv, i64 noundef 4) #23, !dbg !2969
  store ptr %call, ptr @stats_sizes_hist, align 8, !dbg !2970, !tbaa !910
  br label %return, !dbg !2971

return:                                           ; preds = %entry, %if.end
  ret void, !dbg !2971
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite)
declare !dbg !2972 noalias noundef ptr @calloc(i64 noundef, i64 noundef) local_unnamed_addr #14

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @item_stats_sizes(ptr noundef %add_stats, ptr noundef %c) local_unnamed_addr #0 !dbg !2975 {
entry:
  %key = alloca [12 x i8], align 1, !DIAssignID !2988
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !2982, metadata !DIExpression(), metadata !2988, metadata ptr %key, metadata !DIExpression()), !dbg !2989
  tail call void @llvm.dbg.value(metadata ptr %add_stats, metadata !2977, metadata !DIExpression()), !dbg !2990
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !2978, metadata !DIExpression()), !dbg !2990
  %0 = load ptr, ptr @stats_sizes_hist, align 8, !dbg !2991, !tbaa !910
  %cmp.not = icmp eq ptr %0, null, !dbg !2992
  br i1 %cmp.not, label %if.else, label %for.cond.preheader, !dbg !2993

for.cond.preheader:                               ; preds = %entry
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2979, metadata !DIExpression()), !dbg !2994
  %1 = load i32, ptr @stats_sizes_buckets, align 4, !dbg !2995, !tbaa !794
  %cmp116 = icmp sgt i32 %1, 0, !dbg !2996
  br i1 %cmp116, label %for.body, label %if.end7, !dbg !2997

for.body:                                         ; preds = %for.cond.preheader, %for.inc
  %2 = phi i32 [ %8, %for.inc ], [ %1, %for.cond.preheader ]
  %3 = phi ptr [ %9, %for.inc ], [ %0, %for.cond.preheader ], !dbg !2998
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.inc ], [ 0, %for.cond.preheader ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !2979, metadata !DIExpression()), !dbg !2994
  %arrayidx = getelementptr inbounds i32, ptr %3, i64 %indvars.iv, !dbg !2998
  %4 = load i32, ptr %arrayidx, align 4, !dbg !2998, !tbaa !794
  %cmp2.not = icmp eq i32 %4, 0, !dbg !2999
  br i1 %cmp2.not, label %for.inc, label %if.then3, !dbg !3000

if.then3:                                         ; preds = %for.body
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %key) #21, !dbg !3001
  %indvars.iv.tr = trunc i64 %indvars.iv to i32, !dbg !3002
  %5 = shl i32 %indvars.iv.tr, 5, !dbg !3002
  %call = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key, i64 noundef 12, ptr noundef nonnull @.str.36, i32 noundef %5) #21, !dbg !3002
  %6 = load ptr, ptr @stats_sizes_hist, align 8, !dbg !3003, !tbaa !910
  %arrayidx6 = getelementptr inbounds i32, ptr %6, i64 %indvars.iv, !dbg !3003
  %7 = load i32, ptr %arrayidx6, align 4, !dbg !3003, !tbaa !794
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull %key, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.18, i32 noundef %7) #21, !dbg !3003
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %key) #21, !dbg !3004
  %.pre = load ptr, ptr @stats_sizes_hist, align 8, !dbg !2998, !tbaa !910
  %.pre21 = load i32, ptr @stats_sizes_buckets, align 4, !dbg !2995, !tbaa !794
  br label %for.inc, !dbg !3005

for.inc:                                          ; preds = %for.body, %if.then3
  %8 = phi i32 [ %2, %for.body ], [ %.pre21, %if.then3 ], !dbg !2995
  %9 = phi ptr [ %3, %for.body ], [ %.pre, %if.then3 ]
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !3006
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !2979, metadata !DIExpression()), !dbg !2994
  %10 = sext i32 %8 to i64, !dbg !2996
  %cmp1 = icmp slt i64 %indvars.iv.next, %10, !dbg !2996
  br i1 %cmp1, label %for.body, label %if.end7, !dbg !2997, !llvm.loop !3007

if.else:                                          ; preds = %entry
  tail call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.37, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.38, ptr noundef nonnull @.str.39) #21, !dbg !3009
  br label %if.end7

if.end7:                                          ; preds = %for.inc, %for.cond.preheader, %if.else
  call void %add_stats(ptr noundef null, i16 noundef zeroext 0, ptr noundef null, i32 noundef 0, ptr noundef %c) #21, !dbg !3011
  ret void, !dbg !3012
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local ptr @do_item_get(ptr noundef %key, i64 noundef %nkey, i32 noundef %hv, ptr noundef %t, i1 noundef zeroext %do_update) local_unnamed_addr #0 !dbg !3013 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !3018, metadata !DIExpression()), !dbg !3030
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !3019, metadata !DIExpression()), !dbg !3030
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !3020, metadata !DIExpression()), !dbg !3030
  tail call void @llvm.dbg.value(metadata ptr %t, metadata !3021, metadata !DIExpression()), !dbg !3030
  tail call void @llvm.dbg.value(metadata i1 %do_update, metadata !3022, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3030
  %call = tail call ptr @assoc_find(ptr noundef %key, i64 noundef %nkey, i32 noundef %hv) #21, !dbg !3031
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !3023, metadata !DIExpression()), !dbg !3030
  %cmp.not = icmp eq ptr %call, null, !dbg !3032
  br i1 %cmp.not, label %if.end, label %if.end.thread, !dbg !3034

if.end:                                           ; preds = %entry
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3024, metadata !DIExpression()), !dbg !3030
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !3035, !tbaa !3036
  %cmp1 = icmp sgt i32 %0, 2, !dbg !3037
  br i1 %cmp1, label %if.then4, label %do.body69, !dbg !3038

if.end.thread:                                    ; preds = %entry
  %refcount = getelementptr inbounds i8, ptr %call, i64 36, !dbg !3039
  %1 = load i16, ptr %refcount, align 4, !dbg !3039, !tbaa !920
  %inc = add i16 %1, 1, !dbg !3039
  store i16 %inc, ptr %refcount, align 4, !dbg !3039, !tbaa !920
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3024, metadata !DIExpression()), !dbg !3030
  %2 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !3035, !tbaa !3036
  %cmp1156 = icmp sgt i32 %2, 2, !dbg !3037
  br i1 %cmp1156, label %if.end9, label %if.then18, !dbg !3038

if.then4:                                         ; preds = %if.end
  %3 = load ptr, ptr @stderr, align 8, !dbg !3041, !tbaa !910
  %4 = tail call i64 @fwrite(ptr nonnull @.str.40, i64 12, i64 1, ptr %3) #24, !dbg !3044
  br label %if.end9, !dbg !3045

if.end9:                                          ; preds = %if.end.thread, %if.then4
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3025, metadata !DIExpression()), !dbg !3046
  %cmp10167.not = icmp eq i64 %nkey, 0, !dbg !3047
  br i1 %cmp10167.not, label %if.end15, label %for.body, !dbg !3050

for.body:                                         ; preds = %if.end9, %for.body
  %indvars.iv = phi i64 [ %indvars.iv.next, %for.body ], [ 0, %if.end9 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !3025, metadata !DIExpression()), !dbg !3046
  %5 = load ptr, ptr @stderr, align 8, !dbg !3051, !tbaa !910
  %arrayidx = getelementptr inbounds i8, ptr %key, i64 %indvars.iv, !dbg !3053
  %6 = load i8, ptr %arrayidx, align 1, !dbg !3053, !tbaa !917
  %conv12 = sext i8 %6 to i32, !dbg !3053
  %fputc132 = tail call i32 @fputc(i32 %conv12, ptr %5), !dbg !3054
  %indvars.iv.next = add nuw i64 %indvars.iv, 1, !dbg !3055
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !3025, metadata !DIExpression()), !dbg !3046
  %exitcond.not = icmp eq i64 %indvars.iv.next, %nkey, !dbg !3047
  br i1 %exitcond.not, label %if.end15, label %for.body, !dbg !3050, !llvm.loop !3056

if.end15:                                         ; preds = %for.body, %if.end9
  br i1 %cmp.not, label %if.end63, label %if.then18, !dbg !3058

if.then18:                                        ; preds = %if.end.thread, %if.end15
  tail call void @llvm.dbg.value(metadata i32 1, metadata !3024, metadata !DIExpression()), !dbg !3030
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !783, metadata !DIExpression()), !dbg !3059
  %7 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 6), align 4, !dbg !3064, !tbaa !787
  tail call void @llvm.dbg.value(metadata i32 %7, metadata !784, metadata !DIExpression()), !dbg !3059
  %time.i = getelementptr inbounds i8, ptr %call, i64 24, !dbg !3065
  %8 = load i32, ptr %time.i, align 8, !dbg !3065, !tbaa !794
  %cmp.not.i = icmp ugt i32 %8, %7, !dbg !3066
  br i1 %cmp.not.i, label %if.else33, label %land.lhs.true.i, !dbg !3067

land.lhs.true.i:                                  ; preds = %if.then18
  %9 = load volatile i32, ptr @current_time, align 4, !dbg !3068, !tbaa !794
  %cmp1.not.i = icmp ugt i32 %7, %9, !dbg !3069
  br i1 %cmp1.not.i, label %if.else33, label %if.then21, !dbg !3070

if.then21:                                        ; preds = %land.lhs.true.i
  tail call void @do_item_unlink(ptr noundef nonnull %call, i32 noundef %hv), !dbg !3071
  %storage = getelementptr inbounds i8, ptr %t, i64 6904, !dbg !3073
  %10 = load ptr, ptr %storage, align 8, !dbg !3073, !tbaa !3075
  tail call void @storage_delete(ptr noundef %10, ptr noundef nonnull %call) #21, !dbg !3073
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !996, metadata !DIExpression()), !dbg !3083
  %refcount.i = getelementptr inbounds i8, ptr %call, i64 36, !dbg !3085
  %11 = load i16, ptr %refcount.i, align 4, !dbg !3085, !tbaa !920
  %dec.i = add i16 %11, -1, !dbg !3085
  store i16 %dec.i, ptr %refcount.i, align 4, !dbg !3085, !tbaa !920
  %cmp.i = icmp eq i16 %dec.i, 0, !dbg !3086
  br i1 %cmp.i, label %if.then.i, label %do_item_remove.exit, !dbg !3087

if.then.i:                                        ; preds = %if.then21
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !1007, metadata !DIExpression()), !dbg !3088
  %nkey.i.i = getelementptr inbounds i8, ptr %call, i64 41, !dbg !3090
  %12 = load i8, ptr %nkey.i.i, align 1, !dbg !3090, !tbaa !917
  %conv.i.i = zext i8 %12 to i64, !dbg !3090
  %add1.i.i = add nuw nsw i64 %conv.i.i, 49, !dbg !3090
  %nbytes.i.i = getelementptr inbounds i8, ptr %call, i64 32, !dbg !3090
  %13 = load i32, ptr %nbytes.i.i, align 8, !dbg !3090, !tbaa !794
  %conv2.i.i = sext i32 %13 to i64, !dbg !3090
  %add3.i.i = add nsw i64 %add1.i.i, %conv2.i.i, !dbg !3090
  %it_flags.i.i = getelementptr inbounds i8, ptr %call, i64 38, !dbg !3090
  %14 = load i16, ptr %it_flags.i.i, align 2, !dbg !3090, !tbaa !920
  %conv4.i.i = zext i16 %14 to i32, !dbg !3090
  %and.i.i = lshr i32 %conv4.i.i, 6, !dbg !3090
  %15 = and i32 %and.i.i, 4, !dbg !3090
  %cond.i.i = zext nneg i32 %15 to i64, !dbg !3090
  %add5.i.i = add nsw i64 %add3.i.i, %cond.i.i, !dbg !3090
  %and8.i.i = shl nuw nsw i32 %conv4.i.i, 2, !dbg !3090
  %16 = and i32 %and8.i.i, 8, !dbg !3090
  %cond10.i.i = zext nneg i32 %16 to i64, !dbg !3090
  %add11.i.i = add nsw i64 %add5.i.i, %cond10.i.i, !dbg !3090
  tail call void @llvm.dbg.value(metadata i64 %add11.i.i, metadata !1010, metadata !DIExpression()), !dbg !3088
  %slabs_clsid.i.i = getelementptr inbounds i8, ptr %call, i64 40, !dbg !3091
  %17 = load i8, ptr %slabs_clsid.i.i, align 8, !dbg !3091, !tbaa !917
  %18 = and i8 %17, 63, !dbg !3091
  %and13.i.i = zext nneg i8 %18 to i32, !dbg !3091
  tail call void @llvm.dbg.value(metadata i32 %and13.i.i, metadata !1011, metadata !DIExpression()), !dbg !3088
  tail call void @slabs_free(ptr noundef nonnull %call, i64 noundef %add11.i.i, i32 noundef %and13.i.i) #21, !dbg !3092
  br label %do_item_remove.exit, !dbg !3093

do_item_remove.exit:                              ; preds = %if.then21, %if.then.i
  tail call void @llvm.dbg.value(metadata ptr null, metadata !3023, metadata !DIExpression()), !dbg !3030
  %stats = getelementptr inbounds i8, ptr %t, i64 352, !dbg !3094
  %call22 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats) #21, !dbg !3095
  %get_flushed = getelementptr inbounds i8, ptr %t, i64 416, !dbg !3096
  %19 = load i64, ptr %get_flushed, align 8, !dbg !3097, !tbaa !3098
  %inc24 = add i64 %19, 1, !dbg !3097
  store i64 %inc24, ptr %get_flushed, align 8, !dbg !3097, !tbaa !3098
  %call27 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats) #21, !dbg !3099
  %20 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !3100, !tbaa !3036
  %cmp28 = icmp sgt i32 %20, 2, !dbg !3102
  br i1 %cmp28, label %if.then30, label %do.body69, !dbg !3103

if.then30:                                        ; preds = %do_item_remove.exit
  %21 = load ptr, ptr @stderr, align 8, !dbg !3104, !tbaa !910
  %22 = tail call i64 @fwrite(ptr nonnull @.str.43, i64 16, i64 1, ptr %21) #24, !dbg !3106
  br label %if.end63, !dbg !3107

if.else33:                                        ; preds = %if.then18, %land.lhs.true.i
  %exptime = getelementptr inbounds i8, ptr %call, i64 28, !dbg !3108
  %23 = load i32, ptr %exptime, align 4, !dbg !3108, !tbaa !794
  %cmp34.not = icmp eq i32 %23, 0, !dbg !3110
  br i1 %cmp34.not, label %if.else57, label %land.lhs.true, !dbg !3111

land.lhs.true:                                    ; preds = %if.else33
  %24 = load volatile i32, ptr @current_time, align 4, !dbg !3112, !tbaa !794
  %cmp37.not = icmp ugt i32 %23, %24, !dbg !3113
  br i1 %cmp37.not, label %if.else57, label %if.then39, !dbg !3114

if.then39:                                        ; preds = %land.lhs.true
  tail call void @do_item_unlink(ptr noundef nonnull %call, i32 noundef %hv), !dbg !3115
  %storage41 = getelementptr inbounds i8, ptr %t, i64 6904, !dbg !3117
  %25 = load ptr, ptr %storage41, align 8, !dbg !3117, !tbaa !3075
  tail call void @storage_delete(ptr noundef %25, ptr noundef nonnull %call) #21, !dbg !3117
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !996, metadata !DIExpression()), !dbg !3119
  %refcount.i134 = getelementptr inbounds i8, ptr %call, i64 36, !dbg !3121
  %26 = load i16, ptr %refcount.i134, align 4, !dbg !3121, !tbaa !920
  %dec.i135 = add i16 %26, -1, !dbg !3121
  store i16 %dec.i135, ptr %refcount.i134, align 4, !dbg !3121, !tbaa !920
  %cmp.i136 = icmp eq i16 %dec.i135, 0, !dbg !3122
  br i1 %cmp.i136, label %if.then.i138, label %do_item_remove.exit155, !dbg !3123

if.then.i138:                                     ; preds = %if.then39
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !1007, metadata !DIExpression()), !dbg !3124
  %nkey.i.i139 = getelementptr inbounds i8, ptr %call, i64 41, !dbg !3126
  %27 = load i8, ptr %nkey.i.i139, align 1, !dbg !3126, !tbaa !917
  %conv.i.i140 = zext i8 %27 to i64, !dbg !3126
  %add1.i.i141 = add nuw nsw i64 %conv.i.i140, 49, !dbg !3126
  %nbytes.i.i142 = getelementptr inbounds i8, ptr %call, i64 32, !dbg !3126
  %28 = load i32, ptr %nbytes.i.i142, align 8, !dbg !3126, !tbaa !794
  %conv2.i.i143 = sext i32 %28 to i64, !dbg !3126
  %add3.i.i144 = add nsw i64 %add1.i.i141, %conv2.i.i143, !dbg !3126
  %it_flags.i.i145 = getelementptr inbounds i8, ptr %call, i64 38, !dbg !3126
  %29 = load i16, ptr %it_flags.i.i145, align 2, !dbg !3126, !tbaa !920
  %conv4.i.i146 = zext i16 %29 to i32, !dbg !3126
  %and.i.i147 = lshr i32 %conv4.i.i146, 6, !dbg !3126
  %30 = and i32 %and.i.i147, 4, !dbg !3126
  %cond.i.i148 = zext nneg i32 %30 to i64, !dbg !3126
  %add5.i.i149 = add nsw i64 %add3.i.i144, %cond.i.i148, !dbg !3126
  %and8.i.i150 = shl nuw nsw i32 %conv4.i.i146, 2, !dbg !3126
  %31 = and i32 %and8.i.i150, 8, !dbg !3126
  %cond10.i.i151 = zext nneg i32 %31 to i64, !dbg !3126
  %add11.i.i152 = add nsw i64 %add5.i.i149, %cond10.i.i151, !dbg !3126
  tail call void @llvm.dbg.value(metadata i64 %add11.i.i152, metadata !1010, metadata !DIExpression()), !dbg !3124
  %slabs_clsid.i.i153 = getelementptr inbounds i8, ptr %call, i64 40, !dbg !3127
  %32 = load i8, ptr %slabs_clsid.i.i153, align 8, !dbg !3127, !tbaa !917
  %33 = and i8 %32, 63, !dbg !3127
  %and13.i.i154 = zext nneg i8 %33 to i32, !dbg !3127
  tail call void @llvm.dbg.value(metadata i32 %and13.i.i154, metadata !1011, metadata !DIExpression()), !dbg !3124
  tail call void @slabs_free(ptr noundef nonnull %call, i64 noundef %add11.i.i152, i32 noundef %and13.i.i154) #21, !dbg !3128
  br label %do_item_remove.exit155, !dbg !3129

do_item_remove.exit155:                           ; preds = %if.then39, %if.then.i138
  tail call void @llvm.dbg.value(metadata ptr null, metadata !3023, metadata !DIExpression()), !dbg !3030
  %stats44 = getelementptr inbounds i8, ptr %t, i64 352, !dbg !3130
  %call46 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %stats44) #21, !dbg !3131
  %get_expired = getelementptr inbounds i8, ptr %t, i64 408, !dbg !3132
  %34 = load i64, ptr %get_expired, align 8, !dbg !3133, !tbaa !3134
  %inc48 = add i64 %34, 1, !dbg !3133
  store i64 %inc48, ptr %get_expired, align 8, !dbg !3133, !tbaa !3134
  %call51 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %stats44) #21, !dbg !3135
  %35 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !3136, !tbaa !3036
  %cmp52 = icmp sgt i32 %35, 2, !dbg !3138
  br i1 %cmp52, label %if.then54, label %do.body69, !dbg !3139

if.then54:                                        ; preds = %do_item_remove.exit155
  %36 = load ptr, ptr @stderr, align 8, !dbg !3140, !tbaa !910
  %37 = tail call i64 @fwrite(ptr nonnull @.str.44, i64 17, i64 1, ptr %36) #24, !dbg !3142
  br label %if.end63, !dbg !3143

if.else57:                                        ; preds = %land.lhs.true, %if.else33
  br i1 %do_update, label %if.then59, label %if.end63, !dbg !3144

if.then59:                                        ; preds = %if.else57
  tail call void @do_item_bump(ptr noundef %t, ptr noundef nonnull %call, i32 noundef %hv), !dbg !3146
  br label %if.end63, !dbg !3149

if.end63:                                         ; preds = %if.then54, %if.then30, %if.else57, %if.then59, %if.end15
  %it.0.ph.ph = phi ptr [ %call, %if.then59 ], [ %call, %if.else57 ], [ null, %if.end15 ], [ null, %if.then30 ], [ null, %if.then54 ]
  %was_found.0.ph.ph = phi i32 [ 1, %if.then59 ], [ 1, %if.else57 ], [ 0, %if.end15 ], [ 2, %if.then30 ], [ 3, %if.then54 ]
  %.pr.pr = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !3150, !tbaa !3036
  tail call void @llvm.dbg.value(metadata i32 %was_found.0.ph.ph, metadata !3024, metadata !DIExpression()), !dbg !3030
  tail call void @llvm.dbg.value(metadata ptr %it.0.ph.ph, metadata !3023, metadata !DIExpression()), !dbg !3030
  %cmp64 = icmp sgt i32 %.pr.pr, 2, !dbg !3152
  br i1 %cmp64, label %if.then66, label %do.body69, !dbg !3153

if.then66:                                        ; preds = %if.end63
  %38 = load ptr, ptr @stderr, align 8, !dbg !3154, !tbaa !910
  %fputc = tail call i32 @fputc(i32 10, ptr %38), !dbg !3155
  br label %do.body69, !dbg !3155

do.body69:                                        ; preds = %if.end, %do_item_remove.exit, %do_item_remove.exit155, %if.end63, %if.then66
  %was_found.0164 = phi i32 [ %was_found.0.ph.ph, %if.end63 ], [ %was_found.0.ph.ph, %if.then66 ], [ 3, %do_item_remove.exit155 ], [ 2, %do_item_remove.exit ], [ 0, %if.end ]
  %it.0163 = phi ptr [ %it.0.ph.ph, %if.end63 ], [ %it.0.ph.ph, %if.then66 ], [ null, %do_item_remove.exit155 ], [ null, %do_item_remove.exit ], [ null, %if.end ]
  %l = getelementptr inbounds i8, ptr %t, i64 6912, !dbg !3156
  %39 = load ptr, ptr %l, align 8, !dbg !3156, !tbaa !3157
  tail call void @llvm.dbg.value(metadata ptr %39, metadata !3028, metadata !DIExpression()), !dbg !3158
  %cmp71 = icmp eq ptr %39, null, !dbg !3159
  br i1 %cmp71, label %if.then73, label %if.end75, !dbg !3156

if.then73:                                        ; preds = %do.body69
  %40 = load i32, ptr @logger_key, align 4, !dbg !3159, !tbaa !794
  %call74 = tail call ptr @pthread_getspecific(i32 noundef %40) #21, !dbg !3159
  tail call void @llvm.dbg.value(metadata ptr %call74, metadata !3028, metadata !DIExpression()), !dbg !3158
  br label %if.end75, !dbg !3159

if.end75:                                         ; preds = %if.then73, %do.body69
  %myl.0 = phi ptr [ %call74, %if.then73 ], [ %39, %do.body69 ], !dbg !3156
  tail call void @llvm.dbg.value(metadata ptr %myl.0, metadata !3028, metadata !DIExpression()), !dbg !3158
  %eflags = getelementptr inbounds i8, ptr %myl.0, i64 84, !dbg !3161
  %41 = load i16, ptr %eflags, align 4, !dbg !3161, !tbaa !1178
  %42 = and i16 %41, 4, !dbg !3161
  %tobool77.not = icmp eq i16 %42, 0, !dbg !3161
  br i1 %tobool77.not, label %if.end88, label %if.then78, !dbg !3156

if.then78:                                        ; preds = %if.end75
  %tobool79.not = icmp eq ptr %it.0163, null, !dbg !3161
  br i1 %tobool79.not, label %cond.end85, label %cond.true81, !dbg !3161

cond.true81:                                      ; preds = %if.then78
  %nbytes = getelementptr inbounds i8, ptr %it.0163, i64 32, !dbg !3161
  %43 = load i32, ptr %nbytes, align 8, !dbg !3161, !tbaa !794
  %slabs_clsid = getelementptr inbounds i8, ptr %it.0163, i64 40, !dbg !3161
  %44 = load i8, ptr %slabs_clsid, align 8, !dbg !3161, !tbaa !917
  %45 = and i8 %44, 63, !dbg !3161
  %and83 = zext nneg i8 %45 to i32, !dbg !3161
  br label %cond.end85, !dbg !3161

cond.end85:                                       ; preds = %if.then78, %cond.true81
  %cond166 = phi i32 [ %43, %cond.true81 ], [ 0, %if.then78 ]
  %cond86 = phi i32 [ %and83, %cond.true81 ], [ 0, %if.then78 ], !dbg !3161
  %cur_sfd = getelementptr inbounds i8, ptr %t, i64 344, !dbg !3161
  %46 = load i32, ptr %cur_sfd, align 8, !dbg !3161, !tbaa !3163
  %call87 = tail call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %myl.0, i32 noundef 2, ptr noundef null, i32 noundef %was_found.0164, ptr noundef %key, i64 noundef %nkey, i32 noundef %cond166, i32 noundef %cond86, i32 noundef %46) #21, !dbg !3161
  br label %if.end88, !dbg !3161

if.end88:                                         ; preds = %cond.end85, %if.end75
  ret ptr %it.0163, !dbg !3164
}

declare !dbg !3165 ptr @assoc_find(ptr noundef, i64 noundef, i32 noundef) local_unnamed_addr #7

; Function Attrs: nofree nounwind
declare !dbg !3168 noundef i32 @fprintf(ptr nocapture noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #12

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @do_item_bump(ptr nocapture noundef readonly %t, ptr noundef %it, i32 noundef %hv) local_unnamed_addr #0 !dbg !3222 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %t, metadata !3226, metadata !DIExpression()), !dbg !3229
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !3227, metadata !DIExpression()), !dbg !3229
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !3228, metadata !DIExpression()), !dbg !3229
  %0 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 29), align 8, !dbg !3230, !tbaa !827, !range !828, !noundef !829
  %tobool = trunc nuw i8 %0 to i1, !dbg !3230
  %it_flags = getelementptr inbounds i8, ptr %it, i64 38, !dbg !3232
  %1 = load i16, ptr %it_flags, align 2, !dbg !3232, !tbaa !920
  br i1 %tobool, label %if.then, label %if.else30, !dbg !3233

if.then:                                          ; preds = %entry
  %conv = zext i16 %1 to i32, !dbg !3234
  %and = and i32 %conv, 16, !dbg !3237
  %cmp = icmp eq i32 %and, 0, !dbg !3238
  br i1 %cmp, label %if.then2, label %if.end35, !dbg !3239

if.then2:                                         ; preds = %if.then
  %and5 = and i32 %conv, 8, !dbg !3240
  %cmp6 = icmp eq i32 %and5, 0, !dbg !3243
  br i1 %cmp6, label %if.then8, label %if.else, !dbg !3244

if.then8:                                         ; preds = %if.then2
  %or = or i16 %1, 8, !dbg !3245
  store i16 %or, ptr %it_flags, align 2, !dbg !3245, !tbaa !920
  br label %if.end35, !dbg !3247

if.else:                                          ; preds = %if.then2
  %or14 = or i16 %1, 16, !dbg !3248
  store i16 %or14, ptr %it_flags, align 2, !dbg !3248, !tbaa !920
  %slabs_clsid = getelementptr inbounds i8, ptr %it, i64 40, !dbg !3250
  %2 = load i8, ptr %slabs_clsid, align 8, !dbg !3250, !tbaa !917
  %3 = and i8 %2, -64, !dbg !3250
  %cmp18.not = icmp eq i8 %3, -128, !dbg !3252
  br i1 %cmp18.not, label %if.else21, label %if.then20, !dbg !3253

if.then20:                                        ; preds = %if.else
  %4 = load volatile i32, ptr @current_time, align 4, !dbg !3254, !tbaa !794
  %time = getelementptr inbounds i8, ptr %it, i64 24, !dbg !3256
  store i32 %4, ptr %time, align 8, !dbg !3257, !tbaa !794
  br label %if.end35, !dbg !3258

if.else21:                                        ; preds = %if.else
  %lru_bump_buf = getelementptr inbounds i8, ptr %t, i64 6920, !dbg !3259
  %5 = load ptr, ptr %lru_bump_buf, align 8, !dbg !3259, !tbaa !3261
  tail call void @llvm.dbg.value(metadata ptr %5, metadata !3262, metadata !DIExpression()), !dbg !3271
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !3267, metadata !DIExpression()), !dbg !3271
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !3268, metadata !DIExpression()), !dbg !3271
  tail call void @llvm.dbg.value(metadata i8 1, metadata !3269, metadata !DIExpression()), !dbg !3271
  %refcount.i = getelementptr inbounds i8, ptr %it, i64 36, !dbg !3273
  %6 = load i16, ptr %refcount.i, align 4, !dbg !3273, !tbaa !920
  %inc.i = add i16 %6, 1, !dbg !3273
  store i16 %inc.i, ptr %refcount.i, align 4, !dbg !3273, !tbaa !920
  %mutex.i = getelementptr inbounds i8, ptr %5, i64 16, !dbg !3274
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull %mutex.i) #21, !dbg !3275
  %buf.i = getelementptr inbounds i8, ptr %5, i64 56, !dbg !3276
  %7 = load ptr, ptr %buf.i, align 8, !dbg !3276, !tbaa !3277
  %call1.i = tail call ptr @bipbuf_request(ptr noundef %7, i32 noundef 16) #21, !dbg !3278
  tail call void @llvm.dbg.value(metadata ptr %call1.i, metadata !3270, metadata !DIExpression()), !dbg !3271
  %cmp.not.i = icmp eq ptr %call1.i, null, !dbg !3279
  br i1 %cmp.not.i, label %if.then22, label %if.then.i, !dbg !3281

if.then.i:                                        ; preds = %if.else21
  store ptr %it, ptr %call1.i, align 8, !dbg !3282, !tbaa !3284
  %hv3.i = getelementptr inbounds i8, ptr %call1.i, i64 8, !dbg !3286
  store i32 %hv, ptr %hv3.i, align 8, !dbg !3287, !tbaa !3288
  %8 = load ptr, ptr %buf.i, align 8, !dbg !3289, !tbaa !3277
  %call5.i = tail call i32 @bipbuf_push(ptr noundef %8, i32 noundef 16) #21, !dbg !3291
  %cmp6.i = icmp eq i32 %call5.i, 0, !dbg !3292
  br i1 %cmp6.i, label %if.then22, label %lru_bump_async.exit.thread, !dbg !3293

lru_bump_async.exit.thread:                       ; preds = %if.then.i
  %call16.i46 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %mutex.i) #21, !dbg !3294
  br label %if.end35, !dbg !3295

if.then22:                                        ; preds = %if.then.i, %if.else21
  %dropped.i = getelementptr inbounds i8, ptr %5, i64 64, !dbg !3296
  %9 = load i64, ptr %dropped.i, align 8, !dbg !3296, !tbaa !2343
  %inc8.i = add i64 %9, 1, !dbg !3296
  store i64 %inc8.i, ptr %dropped.i, align 8, !dbg !3296, !tbaa !2343
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !3269, metadata !DIExpression()), !dbg !3271
  %10 = load i16, ptr %refcount.i, align 4, !dbg !3297, !tbaa !920
  %dec.i = add i16 %10, -1, !dbg !3297
  store i16 %dec.i, ptr %refcount.i, align 4, !dbg !3297, !tbaa !920
  %call16.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull %mutex.i) #21, !dbg !3294
  %11 = load i16, ptr %it_flags, align 2, !dbg !3300, !tbaa !920
  %12 = and i16 %11, -17, !dbg !3300
  store i16 %12, ptr %it_flags, align 2, !dbg !3300, !tbaa !920
  br label %if.end35, !dbg !3302

if.else30:                                        ; preds = %entry
  %13 = or i16 %1, 8, !dbg !3303
  store i16 %13, ptr %it_flags, align 2, !dbg !3303, !tbaa !920
  tail call void @do_item_update(ptr noundef %it), !dbg !3305
  br label %if.end35

if.end35:                                         ; preds = %lru_bump_async.exit.thread, %if.then, %if.then20, %if.then22, %if.then8, %if.else30
  ret void, !dbg !3306
}

; Function Attrs: nounwind
declare !dbg !3307 ptr @pthread_getspecific(i32 noundef) local_unnamed_addr #2

declare !dbg !3311 i32 @logger_log(ptr noundef, i32 noundef, ptr noundef, ...) local_unnamed_addr #7

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local ptr @do_item_touch(ptr noundef %key, i64 noundef %nkey, i32 noundef %exptime, i32 noundef %hv, ptr noundef %t) local_unnamed_addr #0 !dbg !3315 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %key, metadata !3319, metadata !DIExpression()), !dbg !3325
  tail call void @llvm.dbg.value(metadata i64 %nkey, metadata !3320, metadata !DIExpression()), !dbg !3325
  tail call void @llvm.dbg.value(metadata i32 %exptime, metadata !3321, metadata !DIExpression()), !dbg !3325
  tail call void @llvm.dbg.value(metadata i32 %hv, metadata !3322, metadata !DIExpression()), !dbg !3325
  tail call void @llvm.dbg.value(metadata ptr %t, metadata !3323, metadata !DIExpression()), !dbg !3325
  %call = tail call ptr @do_item_get(ptr noundef %key, i64 noundef %nkey, i32 noundef %hv, ptr noundef %t, i1 noundef zeroext true), !dbg !3326
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !3324, metadata !DIExpression()), !dbg !3325
  %cmp.not = icmp eq ptr %call, null, !dbg !3327
  br i1 %cmp.not, label %if.end, label %if.then, !dbg !3329

if.then:                                          ; preds = %entry
  %exptime1 = getelementptr inbounds i8, ptr %call, i64 28, !dbg !3330
  store i32 %exptime, ptr %exptime1, align 4, !dbg !3332, !tbaa !794
  br label %if.end, !dbg !3333

if.end:                                           ; preds = %if.then, %entry
  ret ptr %call, !dbg !3334
}

declare !dbg !3335 i32 @slabs_reassign(i32 noundef, i32 noundef) local_unnamed_addr #7

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef ptr @item_lru_bump_buf_create() local_unnamed_addr #0 !dbg !3338 {
entry:
  %call = tail call noalias dereferenceable_or_null(72) ptr @calloc(i64 noundef 1, i64 noundef 72) #23, !dbg !3343
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !3342, metadata !DIExpression()), !dbg !3344
  %cmp = icmp eq ptr %call, null, !dbg !3345
  br i1 %cmp, label %cleanup, label %if.end, !dbg !3347

if.end:                                           ; preds = %entry
  %call1 = tail call ptr @bipbuf_new(i32 noundef 131072) #21, !dbg !3348
  %buf = getelementptr inbounds i8, ptr %call, i64 56, !dbg !3349
  store ptr %call1, ptr %buf, align 8, !dbg !3350, !tbaa !3277
  %cmp3 = icmp eq ptr %call1, null, !dbg !3351
  br i1 %cmp3, label %if.then4, label %if.end5, !dbg !3353

if.then4:                                         ; preds = %if.end
  tail call void @free(ptr noundef nonnull %call) #21, !dbg !3354
  br label %cleanup, !dbg !3356

if.end5:                                          ; preds = %if.end
  %mutex = getelementptr inbounds i8, ptr %call, i64 16, !dbg !3357
  %call6 = tail call i32 @pthread_mutex_init(ptr noundef nonnull %mutex, ptr noundef null) #21, !dbg !3358
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !3359, metadata !DIExpression()), !dbg !3364
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @bump_buf_lock) #21, !dbg !3366
  store ptr null, ptr %call, align 8, !dbg !3367, !tbaa !3368
  %0 = load ptr, ptr @bump_buf_head, align 8, !dbg !3369, !tbaa !910
  %next.i = getelementptr inbounds i8, ptr %call, i64 8, !dbg !3370
  store ptr %0, ptr %next.i, align 8, !dbg !3371, !tbaa !3372
  %tobool.not.i = icmp eq ptr %0, null, !dbg !3373
  br i1 %tobool.not.i, label %if.end.i, label %if.then.i, !dbg !3375

if.then.i:                                        ; preds = %if.end5
  store ptr %call, ptr %0, align 8, !dbg !3376, !tbaa !3368
  br label %if.end.i, !dbg !3377

if.end.i:                                         ; preds = %if.then.i, %if.end5
  store ptr %call, ptr @bump_buf_head, align 8, !dbg !3378, !tbaa !910
  %1 = load ptr, ptr @bump_buf_tail, align 8, !dbg !3379, !tbaa !910
  %cmp.i = icmp eq ptr %1, null, !dbg !3381
  br i1 %cmp.i, label %if.then4.i, label %lru_bump_buf_link_q.exit, !dbg !3382

if.then4.i:                                       ; preds = %if.end.i
  store ptr %call, ptr @bump_buf_tail, align 8, !dbg !3383, !tbaa !910
  br label %lru_bump_buf_link_q.exit, !dbg !3384

lru_bump_buf_link_q.exit:                         ; preds = %if.end.i, %if.then4.i
  %call6.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @bump_buf_lock) #21, !dbg !3385
  br label %cleanup, !dbg !3386

cleanup:                                          ; preds = %entry, %lru_bump_buf_link_q.exit, %if.then4
  %retval.0 = phi ptr [ null, %if.then4 ], [ %call, %lru_bump_buf_link_q.exit ], [ null, %entry ], !dbg !3344
  ret ptr %retval.0, !dbg !3387
}

declare !dbg !3388 ptr @bipbuf_new(i32 noundef) local_unnamed_addr #7

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !3391 void @free(ptr allocptr nocapture noundef) local_unnamed_addr #15

; Function Attrs: nounwind
declare !dbg !3392 i32 @pthread_mutex_init(ptr noundef, ptr noundef) local_unnamed_addr #2

declare ptr @slab_automove_init(ptr noundef) #7

declare void @slab_automove_free(ptr noundef) #7

declare void @slab_automove_run(ptr noundef, ptr noundef, ptr noundef) #7

declare ptr @slab_automove_extstore_init(ptr noundef) #7

declare void @slab_automove_extstore_free(ptr noundef) #7

declare void @slab_automove_extstore_run(ptr noundef, ptr noundef, ptr noundef) #7

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 -1, 1) i32 @stop_lru_maintainer_thread() local_unnamed_addr #0 !dbg !3402 {
entry:
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @lru_maintainer_lock) #21, !dbg !3407
  store volatile i32 0, ptr @do_run_lru_maintainer_thread, align 4, !dbg !3408, !tbaa !794
  %call1 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_maintainer_lock) #21, !dbg !3409
  %0 = load i64, ptr @lru_maintainer_tid, align 8, !dbg !3410, !tbaa !765
  %call2 = tail call i32 @pthread_join(i64 noundef %0, ptr noundef null) #21, !dbg !3412
  tail call void @llvm.dbg.value(metadata i32 %call2, metadata !3406, metadata !DIExpression()), !dbg !3413
  %cmp.not = icmp eq i32 %call2, 0, !dbg !3414
  br i1 %cmp.not, label %if.end, label %if.then, !dbg !3415

if.then:                                          ; preds = %entry
  %1 = load ptr, ptr @stderr, align 8, !dbg !3416, !tbaa !910
  %call3 = tail call ptr @strerror(i32 noundef %call2) #21, !dbg !3418
  %call4 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %1, ptr noundef nonnull @.str.46, ptr noundef %call3) #25, !dbg !3419
  br label %cleanup, !dbg !3420

if.end:                                           ; preds = %entry
  store i8 0, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 28), align 1, !dbg !3421, !tbaa !2309
  br label %cleanup, !dbg !3422

cleanup:                                          ; preds = %if.end, %if.then
  %retval.0 = phi i32 [ -1, %if.then ], [ 0, %if.end ], !dbg !3413
  ret i32 %retval.0, !dbg !3423
}

declare !dbg !3424 i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #7

; Function Attrs: nounwind
declare !dbg !3428 ptr @strerror(i32 noundef) local_unnamed_addr #2

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 -1, 1) i32 @start_lru_maintainer_thread(ptr noundef %arg) local_unnamed_addr #0 !dbg !3431 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !3435, metadata !DIExpression()), !dbg !3437
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @lru_maintainer_lock) #21, !dbg !3438
  store volatile i32 1, ptr @do_run_lru_maintainer_thread, align 4, !dbg !3439, !tbaa !794
  store i8 1, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 28), align 1, !dbg !3440, !tbaa !2309
  %call1 = tail call i32 @pthread_create(ptr noundef nonnull @lru_maintainer_tid, ptr noundef null, ptr noundef nonnull @lru_maintainer_thread, ptr noundef %arg) #21, !dbg !3441
  tail call void @llvm.dbg.value(metadata i32 %call1, metadata !3436, metadata !DIExpression()), !dbg !3437
  %cmp.not = icmp eq i32 %call1, 0, !dbg !3443
  br i1 %cmp.not, label %if.end, label %if.then, !dbg !3444

if.then:                                          ; preds = %entry
  %0 = load ptr, ptr @stderr, align 8, !dbg !3445, !tbaa !910
  %call2 = tail call ptr @strerror(i32 noundef %call1) #21, !dbg !3447
  %call3 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %0, ptr noundef nonnull @.str.47, ptr noundef %call2) #25, !dbg !3448
  br label %cleanup, !dbg !3449

if.end:                                           ; preds = %entry
  %1 = load i64, ptr @lru_maintainer_tid, align 8, !dbg !3450, !tbaa !765
  tail call void @thread_setname(i64 noundef %1, ptr noundef nonnull @.str.48) #21, !dbg !3451
  br label %cleanup, !dbg !3452

cleanup:                                          ; preds = %if.end, %if.then
  %retval.0 = phi i32 [ -1, %if.then ], [ 0, %if.end ], !dbg !3437
  %call5 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_maintainer_lock) #21, !dbg !3437
  ret i32 %retval.0, !dbg !3453
}

; Function Attrs: nounwind
declare !dbg !3454 i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind sanitize_thread uwtable
define internal noundef ptr @lru_maintainer_thread(ptr noundef readnone %arg) #0 !dbg !3474 {
entry:
  %todo.i = alloca [256 x i8], align 16, !DIAssignID !3507
  %size.i = alloca i32, align 4, !DIAssignID !3508
  %chunks_perslab.i = alloca i32, align 4, !DIAssignID !3509
  %next_juggles = alloca [64 x i32], align 16, !DIAssignID !3510
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3487, metadata !DIExpression(), metadata !3510, metadata ptr %next_juggles, metadata !DIExpression()), !dbg !3511
  %backoff_juggles = alloca [64 x i32], align 16, !DIAssignID !3512
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3489, metadata !DIExpression(), metadata !3512, metadata ptr %backoff_juggles, metadata !DIExpression()), !dbg !3511
  %src = alloca i32, align 4, !DIAssignID !3513
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3499, metadata !DIExpression(), metadata !3513, metadata ptr %src, metadata !DIExpression()), !dbg !3514
  %dst = alloca i32, align 4, !DIAssignID !3515
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3502, metadata !DIExpression(), metadata !3515, metadata ptr %dst, metadata !DIExpression()), !dbg !3514
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !3476, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata ptr @slab_automove_default, metadata !3477, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !3479, metadata !DIExpression()), !dbg !3511
  %cmp.not = icmp eq ptr %arg, null, !dbg !3516
  %spec.select = select i1 %cmp.not, ptr @slab_automove_default, ptr @slab_automove_extstore, !dbg !3518
  tail call void @llvm.dbg.value(metadata ptr %spec.select, metadata !3477, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 1000, metadata !3481, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 1000, metadata !3484, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3485, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3486, metadata !DIExpression()), !dbg !3511
  call void @llvm.lifetime.start.p0(i64 256, ptr nonnull %next_juggles) #21, !dbg !3519
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(256) %next_juggles, i8 0, i64 256, i1 false), !dbg !3520, !DIAssignID !3521
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !3487, metadata !DIExpression(), metadata !3521, metadata ptr %next_juggles, metadata !DIExpression()), !dbg !3511
  call void @llvm.lifetime.start.p0(i64 256, ptr nonnull %backoff_juggles) #21, !dbg !3522
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(256) %backoff_juggles, i8 0, i64 256, i1 false), !dbg !3523, !DIAssignID !3524
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !3489, metadata !DIExpression(), metadata !3524, metadata ptr %backoff_juggles, metadata !DIExpression()), !dbg !3511
  %call = tail call noalias dereferenceable_or_null(137272) ptr @calloc(i64 noundef 1, i64 noundef 137272) #23, !dbg !3525
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !3490, metadata !DIExpression()), !dbg !3511
  %cmp1 = icmp eq ptr %call, null, !dbg !3526
  br i1 %cmp1, label %if.then2, label %if.end4, !dbg !3528

if.then2:                                         ; preds = %entry
  %0 = load ptr, ptr @stderr, align 8, !dbg !3529, !tbaa !910
  %1 = tail call i64 @fwrite(ptr nonnull @.str.49, i64 58, i64 1, ptr %0) #24, !dbg !3531
  tail call void @abort() #26, !dbg !3532
  unreachable, !dbg !3532

if.end4:                                          ; preds = %entry
  %call5 = tail call i32 @pthread_mutex_init(ptr noundef nonnull %call, ptr noundef null) #21, !dbg !3533
  %crawl_complete = getelementptr inbounds i8, ptr %call, i64 137264, !dbg !3534
  store i8 1, ptr %crawl_complete, align 8, !dbg !3535, !tbaa !3536
  %call6 = tail call ptr @logger_create() #21, !dbg !3538
  tail call void @llvm.dbg.value(metadata ptr %call6, metadata !3491, metadata !DIExpression()), !dbg !3511
  %cmp7 = icmp eq ptr %call6, null, !dbg !3539
  br i1 %cmp7, label %if.then8, label %if.end10, !dbg !3541

if.then8:                                         ; preds = %if.end4
  %2 = load ptr, ptr @stderr, align 8, !dbg !3542, !tbaa !910
  %3 = tail call i64 @fwrite(ptr nonnull @.str.50, i64 52, i64 1, ptr %2) #24, !dbg !3544
  tail call void @abort() #26, !dbg !3545
  unreachable, !dbg !3545

if.end10:                                         ; preds = %if.end4
  %4 = load double, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 32), align 8, !dbg !3546, !tbaa !3547
  tail call void @llvm.dbg.value(metadata double %4, metadata !3492, metadata !DIExpression()), !dbg !3511
  %5 = load ptr, ptr %spec.select, align 8, !dbg !3548, !tbaa !3549
  %call11 = tail call ptr %5(ptr noundef nonnull @settings) #21, !dbg !3551
  tail call void @llvm.dbg.value(metadata ptr %call11, metadata !3493, metadata !DIExpression()), !dbg !3511
  %call12 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @lru_maintainer_lock) #21, !dbg !3552
  %6 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !3553, !tbaa !3036
  %cmp13 = icmp sgt i32 %6, 2, !dbg !3555
  br i1 %cmp13, label %if.then14, label %if.end16, !dbg !3556

if.then14:                                        ; preds = %if.end10
  %7 = load ptr, ptr @stderr, align 8, !dbg !3557, !tbaa !910
  %8 = tail call i64 @fwrite(ptr nonnull @.str.51, i64 42, i64 1, ptr %7) #24, !dbg !3558
  br label %if.end16, !dbg !3558

if.end16:                                         ; preds = %if.then14, %if.end10
  tail call void @llvm.dbg.value(metadata ptr %call11, metadata !3493, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata double %4, metadata !3492, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 1000, metadata !3481, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3486, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3485, metadata !DIExpression()), !dbg !3511
  %9 = load volatile i32, ptr @do_run_lru_maintainer_thread, align 4, !dbg !3559, !tbaa !794
  %tobool.not246 = icmp eq i32 %9, 0, !dbg !3560
  br i1 %tobool.not246, label %while.end, label %while.body.lr.ph, !dbg !3560

while.body.lr.ph:                                 ; preds = %if.end16
  %crawlerstats.i = getelementptr inbounds i8, ptr %call, i64 40
  %eflags.i = getelementptr inbounds i8, ptr %call6, i64 84
  br label %while.body, !dbg !3560

while.body:                                       ; preds = %while.body.lr.ph, %if.end139
  %am.0251 = phi ptr [ %call11, %while.body.lr.ph ], [ %am.2, %if.end139 ]
  %last_ratio.0250 = phi double [ %4, %while.body.lr.ph ], [ %last_ratio.2, %if.end139 ]
  %to_sleep.0249 = phi i32 [ 1000, %while.body.lr.ph ], [ %to_sleep.6, %if.end139 ]
  %last_automove_check.0248 = phi i32 [ 0, %while.body.lr.ph ], [ %last_automove_check.2, %if.end139 ]
  %last_crawler_check.0247 = phi i32 [ 0, %while.body.lr.ph ], [ %last_crawler_check.1, %if.end139 ]
  tail call void @llvm.dbg.value(metadata ptr %am.0251, metadata !3493, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata double %last_ratio.0250, metadata !3492, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 %to_sleep.0249, metadata !3481, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 %last_automove_check.0248, metadata !3486, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 %last_crawler_check.0247, metadata !3485, metadata !DIExpression()), !dbg !3511
  %call17 = call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_maintainer_lock) #21, !dbg !3561
  %tobool18.not = icmp eq i32 %to_sleep.0249, 0, !dbg !3562
  br i1 %tobool18.not, label %if.end21, label %if.then19, !dbg !3564

if.then19:                                        ; preds = %while.body
  %call20 = call i32 @usleep(i32 noundef %to_sleep.0249) #21, !dbg !3565
  br label %if.end21, !dbg !3565

if.end21:                                         ; preds = %if.then19, %while.body
  %call22 = call i32 @pthread_mutex_lock(ptr noundef nonnull @lru_maintainer_lock) #21, !dbg !3566
  %spec.select197 = call i32 @llvm.umax.i32(i32 %to_sleep.0249, i32 1000), !dbg !3567
  tail call void @llvm.dbg.value(metadata i32 %spec.select197, metadata !3484, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 1000000, metadata !3481, metadata !DIExpression()), !dbg !3511
  call void @STATS_LOCK() #21, !dbg !3568
  %10 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 13), align 8, !dbg !3569, !tbaa !3570
  %inc = add i64 %10, 1, !dbg !3569
  store i64 %inc, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 13), align 8, !dbg !3569, !tbaa !3570
  call void @STATS_UNLOCK() #21, !dbg !3571
  tail call void @llvm.dbg.value(metadata i32 1, metadata !3480, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 1000000, metadata !3481, metadata !DIExpression()), !dbg !3511
  br label %for.body, !dbg !3572

for.body:                                         ; preds = %if.end21, %for.inc
  %indvars.iv = phi i64 [ 1, %if.end21 ], [ %indvars.iv.next, %for.inc ]
  %to_sleep.1242 = phi i32 [ 1000000, %if.end21 ], [ %spec.select199, %for.inc ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !3480, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 %to_sleep.1242, metadata !3481, metadata !DIExpression()), !dbg !3511
  %arrayidx = getelementptr inbounds [64 x i32], ptr %next_juggles, i64 0, i64 %indvars.iv, !dbg !3573
  %11 = load i32, ptr %arrayidx, align 4, !dbg !3573, !tbaa !794
  %spec.select198 = call i32 @llvm.usub.sat.i32(i32 %11, i32 %spec.select197), !dbg !3573
  store i32 %spec.select198, ptr %arrayidx, align 4, !dbg !3574, !tbaa !794
  %cmp36.not.not = icmp ugt i32 %11, %spec.select197, !dbg !3575
  br i1 %cmp36.not.not, label %for.inc, label %if.end45, !dbg !3577

if.end45:                                         ; preds = %for.body
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3578, metadata !DIExpression(), metadata !3509, metadata ptr %chunks_perslab.i, metadata !DIExpression()), !dbg !3594
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !3583, metadata !DIExpression()), !dbg !3594
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3585, metadata !DIExpression()), !dbg !3594
  tail call void @llvm.dbg.value(metadata i64 0, metadata !3586, metadata !DIExpression()), !dbg !3594
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %chunks_perslab.i) #21, !dbg !3596
  store i32 0, ptr %chunks_perslab.i, align 4, !dbg !3597, !tbaa !794, !DIAssignID !3598
  tail call void @llvm.dbg.assign(metadata i32 0, metadata !3578, metadata !DIExpression(), metadata !3598, metadata ptr %chunks_perslab.i, metadata !DIExpression()), !dbg !3594
  %12 = trunc nuw nsw i64 %indvars.iv to i32, !dbg !3599
  %call.i = call i32 @slabs_available_chunks(i32 noundef %12, ptr noundef null, ptr noundef nonnull %chunks_perslab.i) #21, !dbg !3599
  %13 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 47), align 4, !dbg !3600, !tbaa !1411, !range !828, !noundef !829
  %tobool.i = trunc nuw i8 %13 to i1, !dbg !3600
  br i1 %tobool.i, label %for.body.i, label %if.end5.i, !dbg !3602

for.body.i:                                       ; preds = %if.end45, %if.else.i
  %did_moves.0114.i = phi i32 [ %inc.i, %if.else.i ], [ 0, %if.end45 ]
  tail call void @llvm.dbg.value(metadata i32 %did_moves.0114.i, metadata !3585, metadata !DIExpression()), !dbg !3594
  tail call void @llvm.dbg.value(metadata i32 %did_moves.0114.i, metadata !3584, metadata !DIExpression()), !dbg !3594
  %call1.i = call i32 @lru_pull_tail(i32 noundef %12, i32 noundef 192, i64 noundef 0, i8 noundef zeroext 0, i32 noundef 0, ptr noundef null), !dbg !3603
  %cmp2.i = icmp slt i32 %call1.i, 1, !dbg !3609
  br i1 %cmp2.i, label %if.end5.i, label %if.else.i, !dbg !3610

if.else.i:                                        ; preds = %for.body.i
  %inc.i = add nuw nsw i32 %did_moves.0114.i, 1, !dbg !3611
  tail call void @llvm.dbg.value(metadata i32 %inc.i, metadata !3585, metadata !DIExpression()), !dbg !3594
  tail call void @llvm.dbg.value(metadata i32 %inc.i, metadata !3584, metadata !DIExpression()), !dbg !3594
  %exitcond.not.i = icmp eq i32 %inc.i, 500, !dbg !3613
  br i1 %exitcond.not.i, label %if.end5.i, label %for.body.i, !dbg !3614, !llvm.loop !3615

if.end5.i:                                        ; preds = %if.else.i, %for.body.i, %if.end45
  %did_moves.1.i = phi i32 [ 0, %if.end45 ], [ 500, %if.else.i ], [ %did_moves.0114.i, %for.body.i ], !dbg !3617
  tail call void @llvm.dbg.value(metadata i32 %did_moves.1.i, metadata !3585, metadata !DIExpression()), !dbg !3594
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3587, metadata !DIExpression()), !dbg !3594
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3588, metadata !DIExpression()), !dbg !3594
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3589, metadata !DIExpression()), !dbg !3594
  %14 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 29), align 8, !dbg !3618, !tbaa !827, !range !828, !noundef !829
  %tobool6.i = trunc nuw i8 %14 to i1, !dbg !3618
  br i1 %tobool6.i, label %if.then7.i, label %if.end53.i, !dbg !3620

if.then7.i:                                       ; preds = %if.end5.i
  %15 = or disjoint i64 %indvars.iv, 128, !dbg !3621
  %arrayidx.i = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %15, !dbg !3623
  %call8.i = call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx.i) #21, !dbg !3624
  %arrayidx11.i = getelementptr inbounds [256 x ptr], ptr @tails, i64 0, i64 %15, !dbg !3625
  %16 = load ptr, ptr %arrayidx11.i, align 8, !dbg !3625, !tbaa !910
  %tobool12.not.i = icmp eq ptr %16, null, !dbg !3625
  br i1 %tobool12.not.i, label %if.end17.i, label %if.then13.i, !dbg !3627

if.then13.i:                                      ; preds = %if.then7.i
  %17 = load volatile i32, ptr @current_time, align 4, !dbg !3628, !tbaa !794
  %time.i = getelementptr inbounds i8, ptr %16, i64 24, !dbg !3630
  %18 = load i32, ptr %time.i, align 8, !dbg !3630, !tbaa !794
  %sub.i = sub i32 %17, %18, !dbg !3631
  tail call void @llvm.dbg.value(metadata i32 %sub.i, metadata !3587, metadata !DIExpression()), !dbg !3594
  %19 = uitofp i32 %sub.i to double, !dbg !3632
  br label %if.end17.i, !dbg !3633

if.end17.i:                                       ; preds = %if.then13.i, %if.then7.i
  %cold_age.0.i = phi double [ %19, %if.then13.i ], [ 0.000000e+00, %if.then7.i ], !dbg !3594
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !3587, metadata !DIExpression()), !dbg !3594
  %arrayidx20.i = getelementptr inbounds [256 x i64], ptr @sizes_bytes, i64 0, i64 %15, !dbg !3634
  %20 = load i64, ptr %arrayidx20.i, align 8, !dbg !3634, !tbaa !765
  tail call void @llvm.dbg.value(metadata i64 %20, metadata !3586, metadata !DIExpression()), !dbg !3594
  %call24.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx.i) #21, !dbg !3635
  %21 = load double, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 44), align 8, !dbg !3636, !tbaa !3637
  %mul.i = fmul double %cold_age.0.i, %21, !dbg !3638
  %conv25.i = fptoui double %mul.i to i32, !dbg !3632
  tail call void @llvm.dbg.value(metadata i32 %conv25.i, metadata !3588, metadata !DIExpression()), !dbg !3594
  %22 = load double, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 45), align 8, !dbg !3639, !tbaa !3640
  %mul27.i = fmul double %cold_age.0.i, %22, !dbg !3641
  %conv28.i = fptoui double %mul27.i to i32, !dbg !3642
  tail call void @llvm.dbg.value(metadata i32 %conv28.i, metadata !3589, metadata !DIExpression()), !dbg !3594
  %arrayidx31.i = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %indvars.iv, !dbg !3643
  %call32.i = call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx31.i) #21, !dbg !3644
  %arrayidx35.i = getelementptr inbounds [256 x i64], ptr @sizes_bytes, i64 0, i64 %indvars.iv, !dbg !3645
  %23 = load i64, ptr %arrayidx35.i, align 8, !dbg !3645, !tbaa !765
  %add36.i = add i64 %23, %20, !dbg !3646
  tail call void @llvm.dbg.value(metadata i64 %add36.i, metadata !3586, metadata !DIExpression()), !dbg !3594
  %call40.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx31.i) #21, !dbg !3647
  %24 = or disjoint i64 %indvars.iv, 64, !dbg !3648
  %arrayidx43.i = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %24, !dbg !3649
  %call44.i = call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx43.i) #21, !dbg !3650
  %arrayidx47.i = getelementptr inbounds [256 x i64], ptr @sizes_bytes, i64 0, i64 %24, !dbg !3651
  %25 = load i64, ptr %arrayidx47.i, align 8, !dbg !3651, !tbaa !765
  %add48.i = add i64 %add36.i, %25, !dbg !3652
  tail call void @llvm.dbg.value(metadata i64 %add48.i, metadata !3586, metadata !DIExpression()), !dbg !3594
  %call52.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx43.i) #21, !dbg !3653
  br label %if.end53.i, !dbg !3654

if.end53.i:                                       ; preds = %if.end17.i, %if.end5.i
  %total_bytes.0.i = phi i64 [ %add48.i, %if.end17.i ], [ 0, %if.end5.i ], !dbg !3594
  %hot_age.0.i = phi i32 [ %conv25.i, %if.end17.i ], [ 0, %if.end5.i ], !dbg !3594
  %warm_age.0.i = phi i32 [ %conv28.i, %if.end17.i ], [ 0, %if.end5.i ], !dbg !3594
  tail call void @llvm.dbg.value(metadata i32 %warm_age.0.i, metadata !3589, metadata !DIExpression()), !dbg !3594
  tail call void @llvm.dbg.value(metadata i32 %hot_age.0.i, metadata !3588, metadata !DIExpression()), !dbg !3594
  tail call void @llvm.dbg.value(metadata i64 %total_bytes.0.i, metadata !3586, metadata !DIExpression()), !dbg !3594
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3584, metadata !DIExpression()), !dbg !3594
  tail call void @llvm.dbg.value(metadata i32 %did_moves.1.i, metadata !3585, metadata !DIExpression()), !dbg !3594
  %26 = add nuw nsw i32 %did_moves.1.i, 499
  br label %for.body57.i, !dbg !3655

for.body57.i:                                     ; preds = %for.inc75.i, %if.end53.i
  %did_moves.2116.i = phi i32 [ %did_moves.1.i, %if.end53.i ], [ %inc74.i, %for.inc75.i ]
  tail call void @llvm.dbg.value(metadata i32 %did_moves.2116.i, metadata !3585, metadata !DIExpression()), !dbg !3594
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !3584, metadata !DIExpression()), !dbg !3594
  tail call void @llvm.dbg.value(metadata i32 0, metadata !3590, metadata !DIExpression()), !dbg !3656
  %call58.i = call i32 @lru_pull_tail(i32 noundef %12, i32 noundef 0, i64 noundef %total_bytes.0.i, i8 noundef zeroext 2, i32 noundef %hot_age.0.i, ptr noundef null), !dbg !3657
  %tobool59.not.i = icmp eq i32 %call58.i, 0, !dbg !3657
  br i1 %tobool59.not.i, label %lor.lhs.false.i, label %if.then62.i, !dbg !3659

lor.lhs.false.i:                                  ; preds = %for.body57.i
  %call60.i = call i32 @lru_pull_tail(i32 noundef %12, i32 noundef 64, i64 noundef %total_bytes.0.i, i8 noundef zeroext 2, i32 noundef %warm_age.0.i, ptr noundef null), !dbg !3660
  %tobool61.not.i = icmp eq i32 %call60.i, 0, !dbg !3660
  br i1 %tobool61.not.i, label %if.end64.i, label %if.then62.i, !dbg !3661

if.then62.i:                                      ; preds = %lor.lhs.false.i, %for.body57.i
  tail call void @llvm.dbg.value(metadata i32 1, metadata !3590, metadata !DIExpression()), !dbg !3656
  br label %if.end64.i, !dbg !3662

if.end64.i:                                       ; preds = %if.then62.i, %lor.lhs.false.i
  %do_more.0.i = phi i32 [ 1, %if.then62.i ], [ 0, %lor.lhs.false.i ], !dbg !3656
  tail call void @llvm.dbg.value(metadata i32 %do_more.0.i, metadata !3590, metadata !DIExpression()), !dbg !3656
  %27 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 29), align 8, !dbg !3664, !tbaa !827, !range !828, !noundef !829
  %tobool65.i = trunc nuw i8 %27 to i1, !dbg !3664
  br i1 %tobool65.i, label %if.then66.i, label %if.end69.i, !dbg !3666

if.then66.i:                                      ; preds = %if.end64.i
  %call67.i = call i32 @lru_pull_tail(i32 noundef %12, i32 noundef 128, i64 noundef %total_bytes.0.i, i8 noundef zeroext 2, i32 noundef 0, ptr noundef null), !dbg !3667
  %add68.i = add nsw i32 %call67.i, %do_more.0.i, !dbg !3669
  tail call void @llvm.dbg.value(metadata i32 %add68.i, metadata !3590, metadata !DIExpression()), !dbg !3656
  br label %if.end69.i, !dbg !3670

if.end69.i:                                       ; preds = %if.then66.i, %if.end64.i
  %do_more.1.i = phi i32 [ %add68.i, %if.then66.i ], [ %do_more.0.i, %if.end64.i ], !dbg !3656
  tail call void @llvm.dbg.value(metadata i32 %do_more.1.i, metadata !3590, metadata !DIExpression()), !dbg !3656
  %cmp70.i = icmp eq i32 %do_more.1.i, 0, !dbg !3671
  tail call void @llvm.dbg.value(metadata i32 undef, metadata !3585, metadata !DIExpression()), !dbg !3594
  br i1 %cmp70.i, label %lru_maintainer_juggle.exit, label %for.inc75.i

for.inc75.i:                                      ; preds = %if.end69.i
  %inc74.i = add nuw nsw i32 %did_moves.2116.i, 1, !dbg !3673
  tail call void @llvm.dbg.value(metadata i32 %inc74.i, metadata !3585, metadata !DIExpression()), !dbg !3594
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !3584, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !3594
  %exitcond117.not.i = icmp eq i32 %did_moves.2116.i, %26, !dbg !3674
  br i1 %exitcond117.not.i, label %lru_maintainer_juggle.exit.thread, label %for.body57.i, !dbg !3655, !llvm.loop !3675

lru_maintainer_juggle.exit.thread:                ; preds = %for.inc75.i
  tail call void @llvm.dbg.value(metadata i32 %did_moves.1.i, metadata !3585, metadata !DIExpression(DW_OP_plus_uconst, 500, DW_OP_stack_value)), !dbg !3594
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %chunks_perslab.i) #21, !dbg !3677
  tail call void @llvm.dbg.value(metadata i32 %did_moves.1.i, metadata !3494, metadata !DIExpression(DW_OP_plus_uconst, 500, DW_OP_stack_value)), !dbg !3678
  br label %if.else67, !dbg !3679

lru_maintainer_juggle.exit:                       ; preds = %if.end69.i
  tail call void @llvm.dbg.value(metadata i32 %did_moves.2116.i, metadata !3585, metadata !DIExpression()), !dbg !3594
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %chunks_perslab.i) #21, !dbg !3677
  tail call void @llvm.dbg.value(metadata i32 %did_moves.2116.i, metadata !3494, metadata !DIExpression()), !dbg !3678
  %cmp47 = icmp eq i32 %did_moves.2116.i, 0, !dbg !3680
  br i1 %cmp47, label %if.then48, label %if.else67, !dbg !3679

if.then48:                                        ; preds = %lru_maintainer_juggle.exit
  %arrayidx50 = getelementptr inbounds [64 x i32], ptr %backoff_juggles, i64 0, i64 %indvars.iv, !dbg !3682
  %28 = load i32, ptr %arrayidx50, align 4, !dbg !3682, !tbaa !794
  %cmp51.not = icmp eq i32 %28, 0, !dbg !3685
  %div196 = lshr i32 %28, 3, !dbg !3686
  %add = add i32 %div196, %28, !dbg !3686
  %29 = call i32 @llvm.umin.i32(i32 %add, i32 1000000), !dbg !3687
  %spec.store.select202 = select i1 %cmp51.not, i32 1000, i32 %29, !dbg !3687
  store i32 %spec.store.select202, ptr %arrayidx50, align 4, !dbg !3688
  br label %if.end83, !dbg !3687

if.else67:                                        ; preds = %lru_maintainer_juggle.exit.thread, %lru_maintainer_juggle.exit
  %arrayidx69 = getelementptr inbounds [64 x i32], ptr %backoff_juggles, i64 0, i64 %indvars.iv, !dbg !3689
  %30 = load i32, ptr %arrayidx69, align 4, !dbg !3689, !tbaa !794
  %cmp70.not = icmp eq i32 %30, 0, !dbg !3691
  br i1 %cmp70.not, label %if.end83, label %if.then71, !dbg !3692

if.then71:                                        ; preds = %if.else67
  %div74195 = lshr i32 %30, 1, !dbg !3693
  %cmp77 = icmp ult i32 %30, 2000, !dbg !3695
  %spec.store.select200 = select i1 %cmp77, i32 0, i32 %div74195, !dbg !3697
  store i32 %spec.store.select200, ptr %arrayidx69, align 4, !dbg !3698
  br label %if.end83, !dbg !3697

if.end83:                                         ; preds = %if.then48, %if.then71, %if.else67
  %31 = phi i32 [ %spec.store.select202, %if.then48 ], [ %spec.store.select200, %if.then71 ], [ 0, %if.else67 ], !dbg !3699
  store i32 %31, ptr %arrayidx, align 4, !dbg !3700, !tbaa !794
  tail call void @llvm.dbg.value(metadata i32 %spec.select199, metadata !3481, metadata !DIExpression()), !dbg !3511
  br label %for.inc, !dbg !3701

for.inc:                                          ; preds = %for.body, %if.end83
  %spec.select198.sink = phi i32 [ %31, %if.end83 ], [ %spec.select198, %for.body ]
  %spec.select199 = call i32 @llvm.umin.i32(i32 %spec.select198.sink, i32 %to_sleep.1242), !dbg !3678
  tail call void @llvm.dbg.value(metadata i32 %spec.select199, metadata !3481, metadata !DIExpression()), !dbg !3511
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !3702
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !3480, metadata !DIExpression()), !dbg !3511
  %exitcond.not = icmp eq i64 %indvars.iv.next, 64, !dbg !3703
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !3572, !llvm.loop !3704

for.end:                                          ; preds = %for.inc
  %32 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 29), align 8, !dbg !3706, !tbaa !827, !range !828, !noundef !829
  %tobool96 = trunc nuw i8 %32 to i1, !dbg !3706
  br i1 %tobool96, label %land.lhs.true, label %if.end101, !dbg !3708

land.lhs.true:                                    ; preds = %for.end
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !3709, metadata !DIExpression(), metadata !3508, metadata ptr %size.i, metadata !DIExpression()), !dbg !3716
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %size.i) #21, !dbg !3718
  tail call void @llvm.dbg.value(metadata i8 0, metadata !3715, metadata !DIExpression()), !dbg !3716
  %call.i203 = call i32 @pthread_mutex_lock(ptr noundef nonnull @bump_buf_lock) #21, !dbg !3719
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !3712, metadata !DIExpression()), !dbg !3716
  %b.033.i = load ptr, ptr @bump_buf_head, align 8, !dbg !3720, !tbaa !910
  %cmp.not34.i = icmp eq ptr %b.033.i, null, !dbg !3722
  br i1 %cmp.not34.i, label %lru_maintainer_bumps.exit.thread, label %for.body.i204.outer, !dbg !3724

for.body.i204.outer:                              ; preds = %land.lhs.true, %for.inc.i.thread
  %b.036.i.ph = phi ptr [ %b.0.i269, %for.inc.i.thread ], [ %b.033.i, %land.lhs.true ]
  %bumped.035.i.ph = phi i1 [ true, %for.inc.i.thread ], [ false, %land.lhs.true ]
  br label %for.body.i204, !dbg !3724

lru_maintainer_bumps.exit.thread:                 ; preds = %land.lhs.true
  %call15.i222 = call i32 @pthread_mutex_unlock(ptr noundef nonnull @bump_buf_lock) #21, !dbg !3725
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %size.i) #21, !dbg !3726
  br label %if.end101, !dbg !3727

for.body.i204:                                    ; preds = %for.body.i204.outer, %for.inc.i
  %b.036.i = phi ptr [ %b.0.i, %for.inc.i ], [ %b.036.i.ph, %for.body.i204.outer ]
  %mutex.i = getelementptr inbounds i8, ptr %b.036.i, i64 16, !dbg !3728
  %call1.i205 = call i32 @pthread_mutex_lock(ptr noundef nonnull %mutex.i) #21, !dbg !3730
  %buf.i = getelementptr inbounds i8, ptr %b.036.i, i64 56, !dbg !3731
  %33 = load ptr, ptr %buf.i, align 8, !dbg !3731, !tbaa !3277
  %call2.i = call ptr @bipbuf_peek_all(ptr noundef %33, ptr noundef nonnull %size.i) #21, !dbg !3732
  tail call void @llvm.dbg.value(metadata ptr %call2.i, metadata !3713, metadata !DIExpression()), !dbg !3716
  %call4.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull %mutex.i) #21, !dbg !3733
  %cmp5.i = icmp eq ptr %call2.i, null, !dbg !3734
  br i1 %cmp5.i, label %for.inc.i, label %if.end.i, !dbg !3736

if.end.i:                                         ; preds = %for.body.i204
  %buf.i.le = getelementptr inbounds i8, ptr %b.036.i, i64 56
  %34 = load i32, ptr %size.i, align 4, !dbg !3737, !tbaa !794
  tail call void @llvm.dbg.value(metadata i32 %34, metadata !3714, metadata !DIExpression()), !dbg !3716
  tail call void @llvm.dbg.value(metadata i8 1, metadata !3715, metadata !DIExpression()), !dbg !3716
  tail call void @llvm.dbg.value(metadata ptr %call2.i, metadata !3713, metadata !DIExpression()), !dbg !3716
  %tobool.not30.i = icmp eq i32 %34, 0, !dbg !3738
  br i1 %tobool.not30.i, label %for.inc.i.thread, label %while.body.i, !dbg !3738

while.body.i:                                     ; preds = %if.end.i, %do_item_remove.exit.i
  %todo.032.i = phi i32 [ %sub.i206, %do_item_remove.exit.i ], [ %34, %if.end.i ]
  %be.031.i = phi ptr [ %incdec.ptr.i, %do_item_remove.exit.i ], [ %call2.i, %if.end.i ]
  tail call void @llvm.dbg.value(metadata i32 %todo.032.i, metadata !3714, metadata !DIExpression()), !dbg !3716
  tail call void @llvm.dbg.value(metadata ptr %be.031.i, metadata !3713, metadata !DIExpression()), !dbg !3716
  %hv.i = getelementptr inbounds i8, ptr %be.031.i, i64 8, !dbg !3739
  %35 = load i32, ptr %hv.i, align 8, !dbg !3739, !tbaa !3288
  call void @item_lock(i32 noundef %35) #21, !dbg !3741
  %36 = load ptr, ptr %be.031.i, align 8, !dbg !3742, !tbaa !3284
  call void @do_item_update(ptr noundef %36), !dbg !3743
  %37 = load ptr, ptr %be.031.i, align 8, !dbg !3744, !tbaa !3284
  tail call void @llvm.dbg.value(metadata ptr %37, metadata !996, metadata !DIExpression()), !dbg !3745
  %refcount.i.i = getelementptr inbounds i8, ptr %37, i64 36, !dbg !3747
  %38 = load i16, ptr %refcount.i.i, align 4, !dbg !3747, !tbaa !920
  %dec.i.i = add i16 %38, -1, !dbg !3747
  store i16 %dec.i.i, ptr %refcount.i.i, align 4, !dbg !3747, !tbaa !920
  %cmp.i.i = icmp eq i16 %dec.i.i, 0, !dbg !3748
  br i1 %cmp.i.i, label %if.then.i.i, label %do_item_remove.exit.i, !dbg !3749

if.then.i.i:                                      ; preds = %while.body.i
  tail call void @llvm.dbg.value(metadata ptr %37, metadata !1007, metadata !DIExpression()), !dbg !3750
  %nkey.i.i.i = getelementptr inbounds i8, ptr %37, i64 41, !dbg !3752
  %39 = load i8, ptr %nkey.i.i.i, align 1, !dbg !3752, !tbaa !917
  %conv.i.i.i = zext i8 %39 to i64, !dbg !3752
  %add1.i.i.i = add nuw nsw i64 %conv.i.i.i, 49, !dbg !3752
  %nbytes.i.i.i = getelementptr inbounds i8, ptr %37, i64 32, !dbg !3752
  %40 = load i32, ptr %nbytes.i.i.i, align 8, !dbg !3752, !tbaa !794
  %conv2.i.i.i = sext i32 %40 to i64, !dbg !3752
  %add3.i.i.i = add nsw i64 %add1.i.i.i, %conv2.i.i.i, !dbg !3752
  %it_flags.i.i.i = getelementptr inbounds i8, ptr %37, i64 38, !dbg !3752
  %41 = load i16, ptr %it_flags.i.i.i, align 2, !dbg !3752, !tbaa !920
  %conv4.i.i.i = zext i16 %41 to i32, !dbg !3752
  %and.i.i.i = lshr i32 %conv4.i.i.i, 6, !dbg !3752
  %42 = and i32 %and.i.i.i, 4, !dbg !3752
  %cond.i.i.i = zext nneg i32 %42 to i64, !dbg !3752
  %add5.i.i.i = add nsw i64 %add3.i.i.i, %cond.i.i.i, !dbg !3752
  %and8.i.i.i = shl nuw nsw i32 %conv4.i.i.i, 2, !dbg !3752
  %43 = and i32 %and8.i.i.i, 8, !dbg !3752
  %cond10.i.i.i = zext nneg i32 %43 to i64, !dbg !3752
  %add11.i.i.i = add nsw i64 %add5.i.i.i, %cond10.i.i.i, !dbg !3752
  tail call void @llvm.dbg.value(metadata i64 %add11.i.i.i, metadata !1010, metadata !DIExpression()), !dbg !3750
  %slabs_clsid.i.i.i = getelementptr inbounds i8, ptr %37, i64 40, !dbg !3753
  %44 = load i8, ptr %slabs_clsid.i.i.i, align 8, !dbg !3753, !tbaa !917
  %45 = and i8 %44, 63, !dbg !3753
  %and13.i.i.i = zext nneg i8 %45 to i32, !dbg !3753
  tail call void @llvm.dbg.value(metadata i32 %and13.i.i.i, metadata !1011, metadata !DIExpression()), !dbg !3750
  call void @slabs_free(ptr noundef nonnull %37, i64 noundef %add11.i.i.i, i32 noundef %and13.i.i.i) #21, !dbg !3754
  br label %do_item_remove.exit.i, !dbg !3755

do_item_remove.exit.i:                            ; preds = %if.then.i.i, %while.body.i
  %46 = load i32, ptr %hv.i, align 8, !dbg !3756, !tbaa !3288
  call void @item_unlock(i32 noundef %46) #21, !dbg !3757
  %incdec.ptr.i = getelementptr inbounds i8, ptr %be.031.i, i64 16, !dbg !3758
  tail call void @llvm.dbg.value(metadata ptr %incdec.ptr.i, metadata !3713, metadata !DIExpression()), !dbg !3716
  %sub.i206 = add i32 %todo.032.i, -16, !dbg !3759
  tail call void @llvm.dbg.value(metadata i32 %sub.i206, metadata !3714, metadata !DIExpression()), !dbg !3716
  %tobool.not.i = icmp eq i32 %sub.i206, 0, !dbg !3738
  br i1 %tobool.not.i, label %for.inc.i.thread, label %while.body.i, !dbg !3738, !llvm.loop !3760

for.inc.i:                                        ; preds = %for.body.i204
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !3715, metadata !DIExpression()), !dbg !3716
  %next.i = getelementptr inbounds i8, ptr %b.036.i, i64 8, !dbg !3762
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !3712, metadata !DIExpression()), !dbg !3716
  %b.0.i = load ptr, ptr %next.i, align 8, !dbg !3720, !tbaa !910
  tail call void @llvm.dbg.value(metadata ptr %b.0.i, metadata !3712, metadata !DIExpression()), !dbg !3716
  %cmp.not.i = icmp eq ptr %b.0.i, null, !dbg !3722
  br i1 %cmp.not.i, label %lru_maintainer_bumps.exit, label %for.body.i204, !dbg !3724, !llvm.loop !3763

for.inc.i.thread:                                 ; preds = %do_item_remove.exit.i, %if.end.i
  %call10.i = call i32 @pthread_mutex_lock(ptr noundef nonnull %mutex.i) #21, !dbg !3765
  %47 = load ptr, ptr %buf.i.le, align 8, !dbg !3766, !tbaa !3277
  %48 = load i32, ptr %size.i, align 4, !dbg !3767, !tbaa !794
  %call12.i = call ptr @bipbuf_poll(ptr noundef %47, i32 noundef %48) #21, !dbg !3768
  tail call void @llvm.dbg.value(metadata ptr %call12.i, metadata !3713, metadata !DIExpression()), !dbg !3716
  %call14.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull %mutex.i) #21, !dbg !3769
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !3715, metadata !DIExpression()), !dbg !3716
  %next.i268 = getelementptr inbounds i8, ptr %b.036.i, i64 8, !dbg !3762
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !3712, metadata !DIExpression()), !dbg !3716
  %b.0.i269 = load ptr, ptr %next.i268, align 8, !dbg !3720, !tbaa !910
  tail call void @llvm.dbg.value(metadata ptr %b.0.i269, metadata !3712, metadata !DIExpression()), !dbg !3716
  %cmp.not.i270 = icmp eq ptr %b.0.i269, null, !dbg !3722
  br i1 %cmp.not.i270, label %lru_maintainer_bumps.exit.thread272, label %for.body.i204.outer, !dbg !3724, !llvm.loop !3763

lru_maintainer_bumps.exit.thread272:              ; preds = %for.inc.i.thread
  %call15.i274 = call i32 @pthread_mutex_unlock(ptr noundef nonnull @bump_buf_lock) #21, !dbg !3725
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %size.i) #21, !dbg !3726
  br label %land.lhs.true98, !dbg !3727

lru_maintainer_bumps.exit:                        ; preds = %for.inc.i
  %call15.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull @bump_buf_lock) #21, !dbg !3725
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %size.i) #21, !dbg !3726
  br i1 %bumped.035.i.ph, label %land.lhs.true98, label %if.end101, !dbg !3727

land.lhs.true98:                                  ; preds = %lru_maintainer_bumps.exit.thread272, %lru_maintainer_bumps.exit
  %spec.store.select = call i32 @llvm.umin.i32(i32 %spec.select199, i32 1000), !dbg !3770
  tail call void @llvm.dbg.value(metadata i32 %spec.store.select, metadata !3481, metadata !DIExpression()), !dbg !3511
  br label %if.end101, !dbg !3770

if.end101:                                        ; preds = %lru_maintainer_bumps.exit.thread, %land.lhs.true98, %lru_maintainer_bumps.exit, %for.end
  %to_sleep.4 = phi i32 [ %spec.store.select, %land.lhs.true98 ], [ %spec.select199, %lru_maintainer_bumps.exit ], [ %spec.select199, %for.end ], [ %spec.select199, %lru_maintainer_bumps.exit.thread ], !dbg !3771
  tail call void @llvm.dbg.value(metadata i32 %to_sleep.4, metadata !3481, metadata !DIExpression()), !dbg !3511
  %49 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 27), align 2, !dbg !3772, !tbaa !3774, !range !828, !noundef !829
  %tobool102 = trunc nuw i8 %49 to i1, !dbg !3772
  br i1 %tobool102, label %land.lhs.true103, label %if.end106, !dbg !3775

land.lhs.true103:                                 ; preds = %if.end101
  %50 = load volatile i32, ptr @current_time, align 4, !dbg !3776, !tbaa !794
  %cmp104.not = icmp eq i32 %last_crawler_check.0247, %50, !dbg !3777
  br i1 %cmp104.not, label %if.end106, label %if.then105, !dbg !3778

if.then105:                                       ; preds = %land.lhs.true103
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !639, metadata !DIExpression(), metadata !3507, metadata ptr %todo.i, metadata !DIExpression()), !dbg !3779
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !636, metadata !DIExpression()), !dbg !3779
  tail call void @llvm.dbg.value(metadata ptr %call6, metadata !637, metadata !DIExpression()), !dbg !3779
  call void @llvm.lifetime.start.p0(i64 256, ptr nonnull %todo.i) #21, !dbg !3782
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(256) %todo.i, i8 0, i64 256, i1 false), !dbg !3783, !DIAssignID !3784
  tail call void @llvm.dbg.assign(metadata i8 0, metadata !639, metadata !DIExpression(), metadata !3784, metadata ptr %todo.i, metadata !DIExpression()), !dbg !3779
  tail call void @llvm.dbg.value(metadata i32 0, metadata !642, metadata !DIExpression()), !dbg !3779
  tail call void @llvm.dbg.value(metadata i32 1, metadata !638, metadata !DIExpression()), !dbg !3779
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !641, metadata !DIExpression()), !dbg !3779
  br label %for.body.outer.i, !dbg !3785

for.body.outer.i:                                 ; preds = %if.end92.thread.i, %if.then105
  %indvars.iv168.ph.i = phi i64 [ %indvars.iv.next169176.i, %if.end92.thread.i ], [ 1, %if.then105 ]
  %do_run.0162.ph.i = phi i1 [ true, %if.end92.thread.i ], [ false, %if.then105 ]
  %tocrawl_limit.0161.ph.i = phi i32 [ %spec.select.i, %if.end92.thread.i ], [ 0, %if.then105 ]
  br label %for.body.i207, !dbg !3785

for.body.i207:                                    ; preds = %if.end92.i, %for.body.outer.i
  %indvars.iv168.i = phi i64 [ %indvars.iv.next169.i, %if.end92.i ], [ %indvars.iv168.ph.i, %for.body.outer.i ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv168.i, metadata !638, metadata !DIExpression()), !dbg !3779
  tail call void @llvm.dbg.value(metadata i32 %tocrawl_limit.0161.ph.i, metadata !642, metadata !DIExpression()), !dbg !3779
  %arrayidx.i208 = getelementptr inbounds [256 x %struct.crawlerstats_t], ptr %crawlerstats.i, i64 0, i64 %indvars.iv168.i, !dbg !3786
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i208, metadata !643, metadata !DIExpression()), !dbg !3787
  %run_complete.i = getelementptr inbounds i8, ptr %arrayidx.i208, i64 528, !dbg !3788
  %51 = load i8, ptr %run_complete.i, align 8, !dbg !3788, !tbaa !3789, !range !828, !noundef !829
  %tobool.i209 = trunc nuw i8 %51 to i1, !dbg !3788
  br i1 %tobool.i209, label %if.then.i, label %if.end67.i, !dbg !3791

if.then.i:                                        ; preds = %for.body.i207
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !648, metadata !DIExpression()), !dbg !3792
  %call.i211 = call i32 @pthread_mutex_lock(ptr noundef nonnull %call) #21, !dbg !3793
  %seen.i = getelementptr inbounds i8, ptr %arrayidx.i208, i64 512, !dbg !3794
  %52 = load i64, ptr %seen.i, align 8, !dbg !3794, !tbaa !3795
  %noexp.i = getelementptr inbounds i8, ptr %arrayidx.i208, i64 496, !dbg !3796
  %53 = load i64, ptr %noexp.i, align 8, !dbg !3796, !tbaa !3797
  %sub.i212 = sub i64 %52, %53, !dbg !3798
  tail call void @llvm.dbg.value(metadata i64 %sub.i212, metadata !652, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i64 0, metadata !653, metadata !DIExpression()), !dbg !3792
  %div.i = udiv i64 %sub.i212, 100, !dbg !3799
  %add.i = add nuw nsw i64 %div.i, 1, !dbg !3800
  tail call void @llvm.dbg.value(metadata i64 %add.i, metadata !654, metadata !DIExpression()), !dbg !3792
  %54 = load volatile i32, ptr @current_time, align 4, !dbg !3801, !tbaa !794
  %end_time.i = getelementptr inbounds i8, ptr %arrayidx.i208, i64 524, !dbg !3802
  %55 = load i32, ptr %end_time.i, align 4, !dbg !3802, !tbaa !3803
  %sub1.i = sub i32 %54, %55, !dbg !3804
  tail call void @llvm.dbg.value(metadata i32 %sub1.i, metadata !655, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i32 0, metadata !651, metadata !DIExpression()), !dbg !3792
  br label %for.body4.i, !dbg !3805

for.body4.i:                                      ; preds = %for.inc.i213.4, %if.then.i
  %indvars.iv.i = phi i64 [ 0, %if.then.i ], [ %indvars.iv.next.i.4, %for.inc.i213.4 ]
  %available_reclaims.0160.i = phi i64 [ 0, %if.then.i ], [ %add7.i.4, %for.inc.i213.4 ]
  tail call void @llvm.dbg.value(metadata i64 %available_reclaims.0160.i, metadata !653, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i, metadata !651, metadata !DIExpression()), !dbg !3792
  %arrayidx6.i = getelementptr inbounds [61 x i64], ptr %arrayidx.i208, i64 0, i64 %indvars.iv.i, !dbg !3807
  %56 = load i64, ptr %arrayidx6.i, align 8, !dbg !3807, !tbaa !765
  %add7.i = add i64 %56, %available_reclaims.0160.i, !dbg !3810
  tail call void @llvm.dbg.value(metadata i64 %add7.i, metadata !653, metadata !DIExpression()), !dbg !3792
  %cmp8.i = icmp ugt i64 %add7.i, %add.i, !dbg !3811
  br i1 %cmp8.i, label %if.then9.i, label %for.inc.i213, !dbg !3813

if.then9.i:                                       ; preds = %for.inc.i213.3, %for.inc.i213.2, %for.inc.i213.1, %for.inc.i213, %for.body4.i
  %indvars.iv.i.lcssa = phi i64 [ %indvars.iv.i, %for.body4.i ], [ %indvars.iv.next.i, %for.inc.i213 ], [ %indvars.iv.next.i.1, %for.inc.i213.1 ], [ %indvars.iv.next.i.2, %for.inc.i213.2 ], [ %indvars.iv.next.i.3, %for.inc.i213.3 ]
  %add7.i.lcssa = phi i64 [ %add7.i, %for.body4.i ], [ %add7.i.1, %for.inc.i213 ], [ %add7.i.2, %for.inc.i213.1 ], [ %add7.i.3, %for.inc.i213.2 ], [ %add7.i.4, %for.inc.i213.3 ], !dbg !3810
  %57 = trunc nuw nsw i64 %indvars.iv.i.lcssa to i32, !dbg !3814
  %arrayidx11.i215 = getelementptr inbounds [256 x i32], ptr @lru_maintainer_crawler_check.next_crawl_wait, i64 0, i64 %indvars.iv168.i, !dbg !3814
  %58 = load i32, ptr %arrayidx11.i215, align 4, !dbg !3814, !tbaa !794
  %mul.i216 = mul nuw nsw i32 %57, 60, !dbg !3817
  %cmp12.i = icmp ult i32 %58, %mul.i216, !dbg !3818
  br i1 %cmp12.i, label %if.then13.i218, label %if.else.i217, !dbg !3819

if.then13.i218:                                   ; preds = %if.then9.i
  %add16.i = add nuw nsw i32 %58, 60, !dbg !3820
  store i32 %add16.i, ptr %arrayidx11.i215, align 4, !dbg !3820, !tbaa !794
  br label %if.end31.i, !dbg !3822

if.else.i217:                                     ; preds = %if.then9.i
  %cmp19.i = icmp ugt i32 %58, 59, !dbg !3823
  br i1 %cmp19.i, label %if.then20.i, label %if.end38.i, !dbg !3825

if.then20.i:                                      ; preds = %if.else.i217
  %sub23.i = add i32 %58, -60, !dbg !3826
  store i32 %sub23.i, ptr %arrayidx11.i215, align 4, !dbg !3826, !tbaa !794
  br label %if.end31.i, !dbg !3828

for.inc.i213:                                     ; preds = %for.body4.i
  %indvars.iv.next.i = add nuw nsw i64 %indvars.iv.i, 1, !dbg !3829
  tail call void @llvm.dbg.value(metadata i64 %add7.i, metadata !653, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !651, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i64 %add7.i, metadata !653, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !651, metadata !DIExpression()), !dbg !3792
  %arrayidx6.i.1 = getelementptr inbounds [61 x i64], ptr %arrayidx.i208, i64 0, i64 %indvars.iv.next.i, !dbg !3807
  %59 = load i64, ptr %arrayidx6.i.1, align 8, !dbg !3807, !tbaa !765
  %add7.i.1 = add i64 %59, %add7.i, !dbg !3810
  tail call void @llvm.dbg.value(metadata i64 %add7.i.1, metadata !653, metadata !DIExpression()), !dbg !3792
  %cmp8.i.1 = icmp ugt i64 %add7.i.1, %add.i, !dbg !3811
  br i1 %cmp8.i.1, label %if.then9.i, label %for.inc.i213.1, !dbg !3813

for.inc.i213.1:                                   ; preds = %for.inc.i213
  %indvars.iv.next.i.1 = add nuw nsw i64 %indvars.iv.i, 2, !dbg !3829
  tail call void @llvm.dbg.value(metadata i64 %add7.i.1, metadata !653, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.1, metadata !651, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i64 %add7.i.1, metadata !653, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.1, metadata !651, metadata !DIExpression()), !dbg !3792
  %arrayidx6.i.2 = getelementptr inbounds [61 x i64], ptr %arrayidx.i208, i64 0, i64 %indvars.iv.next.i.1, !dbg !3807
  %60 = load i64, ptr %arrayidx6.i.2, align 8, !dbg !3807, !tbaa !765
  %add7.i.2 = add i64 %60, %add7.i.1, !dbg !3810
  tail call void @llvm.dbg.value(metadata i64 %add7.i.2, metadata !653, metadata !DIExpression()), !dbg !3792
  %cmp8.i.2 = icmp ugt i64 %add7.i.2, %add.i, !dbg !3811
  br i1 %cmp8.i.2, label %if.then9.i, label %for.inc.i213.2, !dbg !3813

for.inc.i213.2:                                   ; preds = %for.inc.i213.1
  %indvars.iv.next.i.2 = add nuw nsw i64 %indvars.iv.i, 3, !dbg !3829
  tail call void @llvm.dbg.value(metadata i64 %add7.i.2, metadata !653, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.2, metadata !651, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i64 %add7.i.2, metadata !653, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.2, metadata !651, metadata !DIExpression()), !dbg !3792
  %arrayidx6.i.3 = getelementptr inbounds [61 x i64], ptr %arrayidx.i208, i64 0, i64 %indvars.iv.next.i.2, !dbg !3807
  %61 = load i64, ptr %arrayidx6.i.3, align 8, !dbg !3807, !tbaa !765
  %add7.i.3 = add i64 %61, %add7.i.2, !dbg !3810
  tail call void @llvm.dbg.value(metadata i64 %add7.i.3, metadata !653, metadata !DIExpression()), !dbg !3792
  %cmp8.i.3 = icmp ugt i64 %add7.i.3, %add.i, !dbg !3811
  br i1 %cmp8.i.3, label %if.then9.i, label %for.inc.i213.3, !dbg !3813

for.inc.i213.3:                                   ; preds = %for.inc.i213.2
  %indvars.iv.next.i.3 = add nuw nsw i64 %indvars.iv.i, 4, !dbg !3829
  tail call void @llvm.dbg.value(metadata i64 %add7.i.3, metadata !653, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.3, metadata !651, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i64 %add7.i.3, metadata !653, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.3, metadata !651, metadata !DIExpression()), !dbg !3792
  %arrayidx6.i.4 = getelementptr inbounds [61 x i64], ptr %arrayidx.i208, i64 0, i64 %indvars.iv.next.i.3, !dbg !3807
  %62 = load i64, ptr %arrayidx6.i.4, align 8, !dbg !3807, !tbaa !765
  %add7.i.4 = add i64 %62, %add7.i.3, !dbg !3810
  tail call void @llvm.dbg.value(metadata i64 %add7.i.4, metadata !653, metadata !DIExpression()), !dbg !3792
  %cmp8.i.4 = icmp ugt i64 %add7.i.4, %add.i, !dbg !3811
  br i1 %cmp8.i.4, label %if.then9.i, label %for.inc.i213.4, !dbg !3813

for.inc.i213.4:                                   ; preds = %for.inc.i213.3
  %indvars.iv.next.i.4 = add nuw nsw i64 %indvars.iv.i, 5, !dbg !3829
  tail call void @llvm.dbg.value(metadata i64 %add7.i.4, metadata !653, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.4, metadata !651, metadata !DIExpression()), !dbg !3792
  %exitcond.not.i214.4 = icmp eq i64 %indvars.iv.next.i.4, 60, !dbg !3830
  br i1 %exitcond.not.i214.4, label %for.end.i, label %for.body4.i, !dbg !3805, !llvm.loop !3831

for.end.i:                                        ; preds = %for.inc.i213.4
  tail call void @llvm.dbg.value(metadata i64 %add7.i.4, metadata !653, metadata !DIExpression()), !dbg !3792
  %cmp26.i = icmp eq i64 %add7.i.4, 0, !dbg !3833
  %arrayidx29.i = getelementptr inbounds [256 x i32], ptr @lru_maintainer_crawler_check.next_crawl_wait, i64 0, i64 %indvars.iv168.i
  %63 = load i32, ptr %arrayidx29.i, align 4, !dbg !3792, !tbaa !794
  br i1 %cmp26.i, label %if.then27.i, label %if.end31.i, !dbg !3835

if.then27.i:                                      ; preds = %for.end.i
  %add30.i = add i32 %63, 60, !dbg !3836
  store i32 %add30.i, ptr %arrayidx29.i, align 4, !dbg !3836, !tbaa !794
  br label %if.end31.i, !dbg !3838

if.end31.i:                                       ; preds = %if.then27.i, %for.end.i, %if.then20.i, %if.then13.i218
  %add7.i316 = phi i64 [ %add7.i.4, %if.then27.i ], [ %add7.i.lcssa, %if.then13.i218 ], [ %add7.i.lcssa, %if.then20.i ], [ %add7.i.4, %for.end.i ]
  %64 = phi i32 [ %add30.i, %if.then27.i ], [ %add16.i, %if.then13.i218 ], [ %sub23.i, %if.then20.i ], [ %63, %for.end.i ], !dbg !3839
  %cmp34.i = icmp ugt i32 %64, 3600, !dbg !3841
  br i1 %cmp34.i, label %if.then35.i, label %if.end38.i, !dbg !3842

if.then35.i:                                      ; preds = %if.end31.i
  %arrayidx33.i = getelementptr inbounds [256 x i32], ptr @lru_maintainer_crawler_check.next_crawl_wait, i64 0, i64 %indvars.iv168.i, !dbg !3839
  store i32 3600, ptr %arrayidx33.i, align 4, !dbg !3843, !tbaa !794
  br label %if.end38.i, !dbg !3845

if.end38.i:                                       ; preds = %if.then35.i, %if.end31.i, %if.else.i217
  %add7.i315 = phi i64 [ %add7.i316, %if.then35.i ], [ %add7.i316, %if.end31.i ], [ %add7.i.lcssa, %if.else.i217 ]
  %65 = phi i32 [ 3600, %if.then35.i ], [ %64, %if.end31.i ], [ %58, %if.else.i217 ], !dbg !3846
  %66 = load volatile i32, ptr @current_time, align 4, !dbg !3847, !tbaa !794
  %add41.i = add nuw nsw i32 %65, 5, !dbg !3848
  %add42.i = add i32 %add41.i, %66, !dbg !3849
  %arrayidx44.i = getelementptr inbounds [256 x i32], ptr @lru_maintainer_crawler_check.next_crawls, i64 0, i64 %indvars.iv168.i, !dbg !3850
  store i32 %add42.i, ptr %arrayidx44.i, align 4, !dbg !3851, !tbaa !794
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !648, metadata !DIExpression()), !dbg !3792
  tail call void @llvm.dbg.value(metadata ptr %call6, metadata !656, metadata !DIExpression()), !dbg !3852
  %67 = load i16, ptr %eflags.i, align 4, !dbg !3853, !tbaa !1178
  %68 = and i16 %67, 2, !dbg !3853
  %tobool53.not.i = icmp eq i16 %68, 0, !dbg !3853
  br i1 %tobool53.not.i, label %if.end63.i, label %if.then54.i, !dbg !3855

if.then54.i:                                      ; preds = %if.end38.i
  %69 = lshr i64 %indvars.iv168.i, 6, !dbg !3856
  %70 = and i64 %69, 67108863, !dbg !3856
  %reltable.shift = shl i64 %70, 2, !dbg !3856
  %reltable.intrinsic = call ptr @llvm.load.relative.i64(ptr @reltable.lru_maintainer_thread, i64 %reltable.shift), !dbg !3856
  tail call void @llvm.dbg.value(metadata ptr %reltable.intrinsic, metadata !648, metadata !DIExpression()), !dbg !3792
  %71 = trunc nuw nsw i64 %indvars.iv168.i to i32, !dbg !3856
  %and55.i = and i32 %71, 63, !dbg !3853
  %72 = load volatile i32, ptr @current_time, align 4, !dbg !3853, !tbaa !794
  %sub58.i = sub i32 %add42.i, %72, !dbg !3853
  %start_time.i = getelementptr inbounds i8, ptr %arrayidx.i208, i64 520, !dbg !3853
  %73 = load i32, ptr %start_time.i, align 8, !dbg !3853, !tbaa !3857
  %sub60.i = sub i32 %55, %73, !dbg !3853
  %reclaimed.i = getelementptr inbounds i8, ptr %arrayidx.i208, i64 504, !dbg !3853
  %74 = load i64, ptr %reclaimed.i, align 8, !dbg !3853, !tbaa !3858
  %call62.i = call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %call6, i32 noundef 4, ptr noundef null, i32 noundef %and55.i, ptr noundef nonnull %reltable.intrinsic, i64 noundef %add.i, i64 noundef %add7.i315, i32 noundef %sub1.i, i32 noundef %sub58.i, i32 noundef %sub60.i, i64 noundef %52, i64 noundef %74) #21, !dbg !3853
  br label %if.end63.i, !dbg !3853

if.end63.i:                                       ; preds = %if.then54.i, %if.end38.i
  store i8 0, ptr %run_complete.i, align 8, !dbg !3859, !tbaa !3789
  %call66.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull %call) #21, !dbg !3860
  br label %if.end67.i, !dbg !3861

if.end67.i:                                       ; preds = %if.end63.i, %for.body.i207
  %75 = load volatile i32, ptr @current_time, align 4, !dbg !3862, !tbaa !794
  %arrayidx69.i = getelementptr inbounds [256 x i32], ptr @lru_maintainer_crawler_check.next_crawls, i64 0, i64 %indvars.iv168.i, !dbg !3864
  %76 = load i32, ptr %arrayidx69.i, align 4, !dbg !3864, !tbaa !794
  %cmp70.i210 = icmp ugt i32 %75, %76, !dbg !3865
  br i1 %cmp70.i210, label %if.end92.thread.i, label %if.end92.i, !dbg !3866

if.end92.i:                                       ; preds = %if.end67.i
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !641, metadata !DIExpression()), !dbg !3779
  tail call void @llvm.dbg.value(metadata i32 %tocrawl_limit.0161.ph.i, metadata !642, metadata !DIExpression()), !dbg !3779
  %indvars.iv.next169.i = add nuw nsw i64 %indvars.iv168.i, 1, !dbg !3867
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next169.i, metadata !638, metadata !DIExpression()), !dbg !3779
  %exitcond170.not.i = icmp eq i64 %indvars.iv.next169.i, 256, !dbg !3868
  br i1 %exitcond170.not.i, label %for.end95.i, label %for.body.i207, !dbg !3785, !llvm.loop !3869

if.end92.thread.i:                                ; preds = %if.end67.i
  %arrayidx74.i = getelementptr inbounds [256 x %union.pthread_mutex_t], ptr @lru_locks, i64 0, i64 %indvars.iv168.i, !dbg !3871
  %call75.i = call i32 @pthread_mutex_lock(ptr noundef nonnull %arrayidx74.i) #21, !dbg !3873
  %arrayidx77.i = getelementptr inbounds [256 x i32], ptr @sizes, i64 0, i64 %indvars.iv168.i, !dbg !3874
  %77 = load i32, ptr %arrayidx77.i, align 4, !dbg !3874, !tbaa !794
  %spec.select.i = call i32 @llvm.umax.i32(i32 %77, i32 %tocrawl_limit.0161.ph.i), !dbg !3876
  tail call void @llvm.dbg.value(metadata i32 %spec.select.i, metadata !642, metadata !DIExpression()), !dbg !3779
  %call86.i = call i32 @pthread_mutex_unlock(ptr noundef nonnull %arrayidx74.i) #21, !dbg !3877
  %arrayidx88.i = getelementptr inbounds [256 x i8], ptr %todo.i, i64 0, i64 %indvars.iv168.i, !dbg !3878
  store i8 1, ptr %arrayidx88.i, align 1, !dbg !3879, !tbaa !917
  tail call void @llvm.dbg.value(metadata i8 1, metadata !641, metadata !DIExpression()), !dbg !3779
  %78 = load volatile i32, ptr @current_time, align 4, !dbg !3880, !tbaa !794
  %add89.i = add i32 %78, 5, !dbg !3881
  store i32 %add89.i, ptr %arrayidx69.i, align 4, !dbg !3882, !tbaa !794
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !641, metadata !DIExpression()), !dbg !3779
  %indvars.iv.next169176.i = add nuw nsw i64 %indvars.iv168.i, 1, !dbg !3867
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next169176.i, metadata !638, metadata !DIExpression()), !dbg !3779
  %exitcond170.not177.i = icmp eq i64 %indvars.iv.next169176.i, 256, !dbg !3868
  br i1 %exitcond170.not177.i, label %if.then97.i, label %for.body.outer.i, !dbg !3785, !llvm.loop !3883

for.end95.i:                                      ; preds = %if.end92.i
  br i1 %do_run.0162.ph.i, label %if.then97.i, label %lru_maintainer_crawler_check.exit, !dbg !3884

if.then97.i:                                      ; preds = %if.end92.thread.i, %for.end95.i
  %tocrawl_limit.2178182.i = phi i32 [ %tocrawl_limit.0161.ph.i, %for.end95.i ], [ %spec.select.i, %if.end92.thread.i ]
  %79 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 41), align 4, !dbg !3885, !tbaa !3889
  %tobool98.not.not.i = icmp eq i32 %79, 0, !dbg !3890
  %80 = call i32 @llvm.umin.i32(i32 %79, i32 %tocrawl_limit.2178182.i), !dbg !3891
  %tocrawl_limit.3.i = select i1 %tobool98.not.not.i, i32 %tocrawl_limit.2178182.i, i32 %80, !dbg !3891
  tail call void @llvm.dbg.value(metadata i32 %tocrawl_limit.3.i, metadata !642, metadata !DIExpression()), !dbg !3779
  %call104.i = call i32 @lru_crawler_start(ptr noundef nonnull %todo.i, i32 noundef %tocrawl_limit.3.i, i32 noundef 0, ptr noundef nonnull %call, ptr noundef null, i32 noundef 0) #21, !dbg !3892
  br label %lru_maintainer_crawler_check.exit, !dbg !3893

lru_maintainer_crawler_check.exit:                ; preds = %for.end95.i, %if.then97.i
  call void @llvm.lifetime.end.p0(i64 256, ptr nonnull %todo.i) #21, !dbg !3894
  %81 = load volatile i32, ptr @current_time, align 4, !dbg !3895, !tbaa !794
  tail call void @llvm.dbg.value(metadata i32 %81, metadata !3485, metadata !DIExpression()), !dbg !3511
  br label %if.end106, !dbg !3896

if.end106:                                        ; preds = %lru_maintainer_crawler_check.exit, %land.lhs.true103, %if.end101
  %last_crawler_check.1 = phi i32 [ %81, %lru_maintainer_crawler_check.exit ], [ %last_crawler_check.0247, %land.lhs.true103 ], [ %last_crawler_check.0247, %if.end101 ], !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 %last_crawler_check.1, metadata !3485, metadata !DIExpression()), !dbg !3511
  %82 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 31), align 4, !dbg !3897, !tbaa !1187
  %cmp107 = icmp eq i32 %82, 1, !dbg !3898
  br i1 %cmp107, label %land.lhs.true108, label %if.end139, !dbg !3899

land.lhs.true108:                                 ; preds = %if.end106
  %83 = load volatile i32, ptr @current_time, align 4, !dbg !3900, !tbaa !794
  %cmp109.not = icmp eq i32 %last_automove_check.0248, %83, !dbg !3901
  br i1 %cmp109.not, label %if.end139, label %if.then110, !dbg !3902

if.then110:                                       ; preds = %land.lhs.true108
  %84 = load double, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 32), align 8, !dbg !3903, !tbaa !3547
  %cmp111 = fcmp une double %last_ratio.0250, %84, !dbg !3905
  br i1 %cmp111, label %if.then112, label %if.end115, !dbg !3906

if.then112:                                       ; preds = %if.then110
  %.val = load ptr, ptr getelementptr inbounds (%struct.slab_automove_reg_t, ptr @slab_automove_default, i64 0, i32 1), align 8, !dbg !3907
  %.val224 = load ptr, ptr getelementptr inbounds (%struct.slab_automove_reg_t, ptr @slab_automove_extstore, i64 0, i32 1), align 8, !dbg !3907
  %85 = select i1 %cmp.not, ptr %.val, ptr %.val224, !dbg !3907
  call void %85(ptr noundef %am.0251) #21, !dbg !3909
  %86 = load ptr, ptr %spec.select, align 8, !dbg !3910, !tbaa !3549
  %call114 = call ptr %86(ptr noundef nonnull @settings) #21, !dbg !3911
  tail call void @llvm.dbg.value(metadata ptr %call114, metadata !3493, metadata !DIExpression()), !dbg !3511
  %87 = load double, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 32), align 8, !dbg !3912, !tbaa !3547
  tail call void @llvm.dbg.value(metadata double %87, metadata !3492, metadata !DIExpression()), !dbg !3511
  br label %if.end115, !dbg !3913

if.end115:                                        ; preds = %if.then112, %if.then110
  %last_ratio.1 = phi double [ %87, %if.then112 ], [ %last_ratio.0250, %if.then110 ], !dbg !3511
  %am.1 = phi ptr [ %call114, %if.then112 ], [ %am.0251, %if.then110 ], !dbg !3511
  tail call void @llvm.dbg.value(metadata ptr %am.1, metadata !3493, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata double %last_ratio.1, metadata !3492, metadata !DIExpression()), !dbg !3511
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %src) #21, !dbg !3914
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %dst) #21, !dbg !3914
  %.val225 = load ptr, ptr getelementptr inbounds (%struct.slab_automove_reg_t, ptr @slab_automove_default, i64 0, i32 2), align 8, !dbg !3915
  %.val226 = load ptr, ptr getelementptr inbounds (%struct.slab_automove_reg_t, ptr @slab_automove_extstore, i64 0, i32 2), align 8, !dbg !3915
  %88 = select i1 %cmp.not, ptr %.val225, ptr %.val226, !dbg !3915
  call void %88(ptr noundef %am.1, ptr noundef nonnull %src, ptr noundef nonnull %dst) #21, !dbg !3916
  %89 = load i32, ptr %src, align 4, !dbg !3917, !tbaa !794
  %cmp116.not = icmp eq i32 %89, -1, !dbg !3918
  br i1 %cmp116.not, label %if.end129, label %land.lhs.true117, !dbg !3919

land.lhs.true117:                                 ; preds = %if.end115
  %90 = load i32, ptr %dst, align 4, !dbg !3920, !tbaa !794
  %cmp118.not = icmp eq i32 %90, -1, !dbg !3921
  br i1 %cmp118.not, label %if.then132, label %if.then119, !dbg !3922

if.then119:                                       ; preds = %land.lhs.true117
  %call120 = call i32 @slabs_reassign(i32 noundef %89, i32 noundef %90) #21, !dbg !3923
  tail call void @llvm.dbg.value(metadata ptr %call6, metadata !3503, metadata !DIExpression()), !dbg !3924
  %91 = load i16, ptr %eflags.i, align 4, !dbg !3925, !tbaa !1178
  %92 = and i16 %91, 2, !dbg !3925
  %tobool125.not = icmp eq i16 %92, 0, !dbg !3925
  br i1 %tobool125.not, label %if.end129, label %if.then126, !dbg !3927

if.then126:                                       ; preds = %if.then119
  %93 = load i32, ptr %src, align 4, !dbg !3925, !tbaa !794
  %94 = load i32, ptr %dst, align 4, !dbg !3925, !tbaa !794
  %call127 = call i32 (ptr, i32, ptr, ...) @logger_log(ptr noundef nonnull %call6, i32 noundef 5, ptr noundef null, i32 noundef %93, i32 noundef %94) #21, !dbg !3925
  br label %if.end129, !dbg !3925

if.end129:                                        ; preds = %if.then119, %if.then126, %if.end115
  %.pr = load i32, ptr %dst, align 4, !dbg !3928, !tbaa !794
  %cmp130.not = icmp eq i32 %.pr, 0, !dbg !3930
  br i1 %cmp130.not, label %if.end138, label %if.then132, !dbg !3931

if.then132:                                       ; preds = %land.lhs.true117, %if.end129
  %95 = load volatile i32, ptr @current_time, align 4, !dbg !3932, !tbaa !794
  tail call void @llvm.dbg.value(metadata i32 %95, metadata !3486, metadata !DIExpression()), !dbg !3511
  br label %if.end138, !dbg !3934

if.end138:                                        ; preds = %if.end129, %if.then132
  %last_automove_check.1 = phi i32 [ %95, %if.then132 ], [ %last_automove_check.0248, %if.end129 ], !dbg !3511
  %to_sleep.5 = phi i32 [ %to_sleep.4, %if.then132 ], [ 1000, %if.end129 ], !dbg !3771
  tail call void @llvm.dbg.value(metadata i32 %to_sleep.5, metadata !3481, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 %last_automove_check.1, metadata !3486, metadata !DIExpression()), !dbg !3511
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %dst) #21, !dbg !3935
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %src) #21, !dbg !3935
  br label %if.end139, !dbg !3936

if.end139:                                        ; preds = %if.end138, %land.lhs.true108, %if.end106
  %last_automove_check.2 = phi i32 [ %last_automove_check.1, %if.end138 ], [ %last_automove_check.0248, %land.lhs.true108 ], [ %last_automove_check.0248, %if.end106 ], !dbg !3511
  %to_sleep.6 = phi i32 [ %to_sleep.5, %if.end138 ], [ %to_sleep.4, %land.lhs.true108 ], [ %to_sleep.4, %if.end106 ], !dbg !3771
  %last_ratio.2 = phi double [ %last_ratio.1, %if.end138 ], [ %last_ratio.0250, %land.lhs.true108 ], [ %last_ratio.0250, %if.end106 ], !dbg !3511
  %am.2 = phi ptr [ %am.1, %if.end138 ], [ %am.0251, %land.lhs.true108 ], [ %am.0251, %if.end106 ], !dbg !3511
  tail call void @llvm.dbg.value(metadata ptr %am.2, metadata !3493, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata double %last_ratio.2, metadata !3492, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 %to_sleep.6, metadata !3481, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 %last_automove_check.2, metadata !3486, metadata !DIExpression()), !dbg !3511
  tail call void @llvm.dbg.value(metadata i32 %last_crawler_check.1, metadata !3485, metadata !DIExpression()), !dbg !3511
  %96 = load volatile i32, ptr @do_run_lru_maintainer_thread, align 4, !dbg !3559, !tbaa !794
  %tobool.not = icmp eq i32 %96, 0, !dbg !3560
  br i1 %tobool.not, label %while.end, label %while.body, !dbg !3560, !llvm.loop !3937

while.end:                                        ; preds = %if.end139, %if.end16
  %am.0.lcssa = phi ptr [ %call11, %if.end16 ], [ %am.2, %if.end139 ], !dbg !3511
  %call140 = call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_maintainer_lock) #21, !dbg !3939
  %.val227 = load ptr, ptr getelementptr inbounds (%struct.slab_automove_reg_t, ptr @slab_automove_default, i64 0, i32 1), align 8, !dbg !3940
  %.val228 = load ptr, ptr getelementptr inbounds (%struct.slab_automove_reg_t, ptr @slab_automove_extstore, i64 0, i32 1), align 8, !dbg !3940
  %97 = select i1 %cmp.not, ptr %.val227, ptr %.val228, !dbg !3940
  call void %97(ptr noundef %am.0.lcssa) #21, !dbg !3941
  call void @free(ptr noundef %call) #21, !dbg !3942
  %98 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !3943, !tbaa !3036
  %cmp142 = icmp sgt i32 %98, 2, !dbg !3945
  br i1 %cmp142, label %if.then144, label %if.end146, !dbg !3946

if.then144:                                       ; preds = %while.end
  %99 = load ptr, ptr @stderr, align 8, !dbg !3947, !tbaa !910
  %100 = call i64 @fwrite(ptr nonnull @.str.52, i64 31, i64 1, ptr %99) #24, !dbg !3948
  br label %if.end146, !dbg !3948

if.end146:                                        ; preds = %if.then144, %while.end
  call void @llvm.lifetime.end.p0(i64 256, ptr nonnull %backoff_juggles) #21, !dbg !3949
  call void @llvm.lifetime.end.p0(i64 256, ptr nonnull %next_juggles) #21, !dbg !3949
  ret ptr null, !dbg !3950
}

declare !dbg !3951 void @thread_setname(i64 noundef, ptr noundef) local_unnamed_addr #7

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @lru_maintainer_pause() local_unnamed_addr #0 !dbg !3954 {
entry:
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @lru_maintainer_lock) #21, !dbg !3955
  ret void, !dbg !3956
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @lru_maintainer_resume() local_unnamed_addr #0 !dbg !3957 {
entry:
  %call = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @lru_maintainer_lock) #21, !dbg !3958
  ret void, !dbg !3959
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, inaccessiblemem: none) uwtable
define dso_local void @do_item_linktail_q(ptr noundef %it) local_unnamed_addr #9 !dbg !3960 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !3962, metadata !DIExpression()), !dbg !3965
  %slabs_clsid = getelementptr inbounds i8, ptr %it, i64 40, !dbg !3966
  %0 = load i8, ptr %slabs_clsid, align 8, !dbg !3966, !tbaa !917
  %idxprom = zext i8 %0 to i64, !dbg !3967
  %arrayidx = getelementptr inbounds [256 x ptr], ptr @heads, i64 0, i64 %idxprom, !dbg !3967
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !3963, metadata !DIExpression()), !dbg !3965
  %arrayidx3 = getelementptr inbounds [256 x ptr], ptr @tails, i64 0, i64 %idxprom, !dbg !3968
  tail call void @llvm.dbg.value(metadata ptr %arrayidx3, metadata !3964, metadata !DIExpression()), !dbg !3965
  %1 = load ptr, ptr %arrayidx3, align 8, !dbg !3969, !tbaa !910
  %prev = getelementptr inbounds i8, ptr %it, i64 8, !dbg !3970
  store ptr %1, ptr %prev, align 8, !dbg !3971, !tbaa !910
  store ptr null, ptr %it, align 8, !dbg !3972, !tbaa !910
  %tobool.not = icmp eq ptr %1, null, !dbg !3973
  br i1 %tobool.not, label %if.end, label %if.then, !dbg !3975

if.then:                                          ; preds = %entry
  store ptr %it, ptr %1, align 8, !dbg !3976, !tbaa !910
  br label %if.end, !dbg !3978

if.end:                                           ; preds = %if.then, %entry
  store ptr %it, ptr %arrayidx3, align 8, !dbg !3979, !tbaa !910
  %2 = load ptr, ptr %arrayidx, align 8, !dbg !3980, !tbaa !910
  %cmp = icmp eq ptr %2, null, !dbg !3982
  br i1 %cmp, label %if.then7, label %if.end8, !dbg !3983

if.then7:                                         ; preds = %if.end
  store ptr %it, ptr %arrayidx, align 8, !dbg !3984, !tbaa !910
  br label %if.end8, !dbg !3985

if.end8:                                          ; preds = %if.then7, %if.end
  ret void, !dbg !3986
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, inaccessiblemem: none) uwtable
define dso_local void @do_item_unlinktail_q(ptr noundef readonly %it) local_unnamed_addr #9 !dbg !3987 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !3989, metadata !DIExpression()), !dbg !3992
  %slabs_clsid = getelementptr inbounds i8, ptr %it, i64 40, !dbg !3993
  %0 = load i8, ptr %slabs_clsid, align 8, !dbg !3993, !tbaa !917
  %idxprom = zext i8 %0 to i64, !dbg !3994
  %arrayidx = getelementptr inbounds [256 x ptr], ptr @heads, i64 0, i64 %idxprom, !dbg !3994
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !3990, metadata !DIExpression()), !dbg !3992
  %arrayidx3 = getelementptr inbounds [256 x ptr], ptr @tails, i64 0, i64 %idxprom, !dbg !3995
  tail call void @llvm.dbg.value(metadata ptr %arrayidx3, metadata !3991, metadata !DIExpression()), !dbg !3992
  %1 = load ptr, ptr %arrayidx, align 8, !dbg !3996, !tbaa !910
  %cmp = icmp eq ptr %1, %it, !dbg !3998
  br i1 %cmp, label %if.then, label %if.end, !dbg !3999

if.then:                                          ; preds = %entry
  %2 = load ptr, ptr %it, align 8, !dbg !4000, !tbaa !910
  store ptr %2, ptr %arrayidx, align 8, !dbg !4002, !tbaa !910
  br label %if.end, !dbg !4003

if.end:                                           ; preds = %if.then, %entry
  %3 = load ptr, ptr %arrayidx3, align 8, !dbg !4004, !tbaa !910
  %cmp4 = icmp eq ptr %3, %it, !dbg !4006
  br i1 %cmp4, label %if.then5, label %if.end6, !dbg !4007

if.then5:                                         ; preds = %if.end
  %prev = getelementptr inbounds i8, ptr %it, i64 8, !dbg !4008
  %4 = load ptr, ptr %prev, align 8, !dbg !4008, !tbaa !910
  store ptr %4, ptr %arrayidx3, align 8, !dbg !4010, !tbaa !910
  br label %if.end6, !dbg !4011

if.end6:                                          ; preds = %if.then5, %if.end
  %5 = load ptr, ptr %it, align 8, !dbg !4012, !tbaa !910
  %tobool.not = icmp eq ptr %5, null, !dbg !4014
  %prev13.phi.trans.insert = getelementptr inbounds i8, ptr %it, i64 8
  %.pre = load ptr, ptr %prev13.phi.trans.insert, align 8, !dbg !3992, !tbaa !910
  br i1 %tobool.not, label %if.end12, label %if.then8, !dbg !4015

if.then8:                                         ; preds = %if.end6
  %prev11 = getelementptr inbounds i8, ptr %5, i64 8, !dbg !4016
  store ptr %.pre, ptr %prev11, align 8, !dbg !4017, !tbaa !910
  br label %if.end12, !dbg !4018

if.end12:                                         ; preds = %if.end6, %if.then8
  %tobool14.not = icmp eq ptr %.pre, null, !dbg !4019
  br i1 %tobool14.not, label %if.end19, label %if.then15, !dbg !4021

if.then15:                                        ; preds = %if.end12
  %6 = load ptr, ptr %it, align 8, !dbg !4022, !tbaa !910
  store ptr %6, ptr %.pre, align 8, !dbg !4023, !tbaa !910
  br label %if.end19, !dbg !4024

if.end19:                                         ; preds = %if.then15, %if.end12
  ret void, !dbg !4025
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, inaccessiblemem: none) uwtable
define dso_local ptr @do_item_crawl_q(ptr noundef %it) local_unnamed_addr #9 !dbg !4026 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %it, metadata !4030, metadata !DIExpression()), !dbg !4033
  %slabs_clsid = getelementptr inbounds i8, ptr %it, i64 40, !dbg !4034
  %0 = load i8, ptr %slabs_clsid, align 8, !dbg !4034, !tbaa !917
  %idxprom = zext i8 %0 to i64, !dbg !4035
  %arrayidx = getelementptr inbounds [256 x ptr], ptr @heads, i64 0, i64 %idxprom, !dbg !4035
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !4031, metadata !DIExpression()), !dbg !4033
  %arrayidx3 = getelementptr inbounds [256 x ptr], ptr @tails, i64 0, i64 %idxprom, !dbg !4036
  tail call void @llvm.dbg.value(metadata ptr %arrayidx3, metadata !4032, metadata !DIExpression()), !dbg !4033
  %prev = getelementptr inbounds i8, ptr %it, i64 8, !dbg !4037
  %1 = load ptr, ptr %prev, align 8, !dbg !4037, !tbaa !910
  %cmp = icmp eq ptr %1, null, !dbg !4039
  br i1 %cmp, label %if.then, label %if.then11, !dbg !4040

if.then:                                          ; preds = %entry
  %2 = load ptr, ptr %it, align 8, !dbg !4041, !tbaa !910
  %tobool.not = icmp eq ptr %2, null, !dbg !4044
  br i1 %tobool.not, label %cleanup, label %if.then4, !dbg !4045

if.then4:                                         ; preds = %if.then
  store ptr %2, ptr %arrayidx, align 8, !dbg !4046, !tbaa !910
  %prev7 = getelementptr inbounds i8, ptr %2, i64 8, !dbg !4048
  store ptr null, ptr %prev7, align 8, !dbg !4049, !tbaa !910
  br label %cleanup, !dbg !4050

if.then11:                                        ; preds = %entry
  %3 = load ptr, ptr %arrayidx, align 8, !dbg !4051, !tbaa !910
  %cmp13 = icmp eq ptr %3, %1, !dbg !4055
  br i1 %cmp13, label %if.then14, label %if.end15, !dbg !4056

if.then14:                                        ; preds = %if.then11
  store ptr %it, ptr %arrayidx, align 8, !dbg !4057, !tbaa !910
  br label %if.end15, !dbg !4059

if.end15:                                         ; preds = %if.then14, %if.then11
  %4 = load ptr, ptr %arrayidx3, align 8, !dbg !4060, !tbaa !910
  %cmp16 = icmp eq ptr %4, %it, !dbg !4062
  br i1 %cmp16, label %if.then17, label %if.end19, !dbg !4063

if.then17:                                        ; preds = %if.end15
  store ptr %1, ptr %arrayidx3, align 8, !dbg !4064, !tbaa !910
  br label %if.end19, !dbg !4066

if.end19:                                         ; preds = %if.then17, %if.end15
  %5 = load ptr, ptr %it, align 8, !dbg !4067, !tbaa !910
  %tobool21.not = icmp eq ptr %5, null, !dbg !4069
  br i1 %tobool21.not, label %if.else, label %if.then22, !dbg !4070

if.then22:                                        ; preds = %if.end19
  store ptr %5, ptr %1, align 8, !dbg !4071, !tbaa !910
  %6 = load ptr, ptr %prev, align 8, !dbg !4073, !tbaa !910
  %7 = load ptr, ptr %it, align 8, !dbg !4074, !tbaa !910
  %prev28 = getelementptr inbounds i8, ptr %7, i64 8, !dbg !4075
  store ptr %6, ptr %prev28, align 8, !dbg !4076, !tbaa !910
  br label %if.end31, !dbg !4077

if.else:                                          ; preds = %if.end19
  store ptr null, ptr %1, align 8, !dbg !4078, !tbaa !910
  %.pre = load ptr, ptr %prev, align 8, !dbg !4080, !tbaa !910
  br label %if.end31

if.end31:                                         ; preds = %if.else, %if.then22
  %8 = phi ptr [ %.pre, %if.else ], [ %6, %if.then22 ], !dbg !4080
  store ptr %8, ptr %it, align 8, !dbg !4081, !tbaa !910
  %prev35 = getelementptr inbounds i8, ptr %8, i64 8, !dbg !4082
  %9 = load ptr, ptr %prev35, align 8, !dbg !4082, !tbaa !910
  store ptr %9, ptr %prev, align 8, !dbg !4083, !tbaa !910
  store ptr %it, ptr %prev35, align 8, !dbg !4084, !tbaa !910
  %10 = load ptr, ptr %prev, align 8, !dbg !4085, !tbaa !910
  %tobool40.not = icmp eq ptr %10, null, !dbg !4087
  br i1 %tobool40.not, label %if.end45, label %if.then41, !dbg !4088

if.then41:                                        ; preds = %if.end31
  store ptr %it, ptr %10, align 8, !dbg !4089, !tbaa !910
  br label %if.end45, !dbg !4091

if.end45:                                         ; preds = %if.end31, %if.then41
  %11 = load ptr, ptr %it, align 8, !dbg !4092, !tbaa !910
  br label %cleanup, !dbg !4093

cleanup:                                          ; preds = %if.then, %if.then4, %if.end45
  %retval.0 = phi ptr [ %11, %if.end45 ], [ null, %if.then4 ], [ null, %if.then ], !dbg !4033
  ret ptr %retval.0, !dbg !4094
}

declare !dbg !4095 ptr @bipbuf_request(ptr noundef, i32 noundef) local_unnamed_addr #7

declare !dbg !4099 i32 @bipbuf_push(ptr noundef, i32 noundef) local_unnamed_addr #7

; Function Attrs: noreturn nounwind
declare !dbg !4102 void @abort() local_unnamed_addr #16

declare !dbg !4103 ptr @logger_create() local_unnamed_addr #7

declare !dbg !4106 i32 @usleep(i32 noundef) local_unnamed_addr #7

declare !dbg !4110 i32 @slabs_available_chunks(i32 noundef, ptr noundef, ptr noundef) local_unnamed_addr #7

declare !dbg !4114 ptr @bipbuf_peek_all(ptr noundef, ptr noundef) local_unnamed_addr #7

declare !dbg !4119 void @item_lock(i32 noundef) local_unnamed_addr #7

declare !dbg !4122 void @item_unlock(i32 noundef) local_unnamed_addr #7

declare !dbg !4123 ptr @bipbuf_poll(ptr noundef, i32 noundef) local_unnamed_addr #7

declare !dbg !4126 i32 @lru_crawler_start(ptr noundef, i32 noundef, i32 noundef, ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #7

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fshl.i32(i32, i32, i32) #17

; Function Attrs: nofree nounwind
declare noundef i64 @fwrite(ptr nocapture noundef, i64 noundef, i64 noundef, ptr nocapture noundef) local_unnamed_addr #18

; Function Attrs: nofree nounwind
declare noundef i32 @fputc(i32 noundef, ptr nocapture noundef) local_unnamed_addr #18

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #17

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #17

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #17

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.usub.sat.i32(i32, i32) #17

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #19 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare ptr @llvm.load.relative.i64(ptr, i64) #20

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #17

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #17

attributes #0 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, argmem: none, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nofree norecurse nounwind sanitize_thread willreturn memory(readwrite, argmem: read) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #9 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(readwrite, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { mustprogress nofree nounwind willreturn memory(argmem: readwrite) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { mustprogress nofree nounwind sanitize_thread willreturn memory(readwrite, argmem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #16 = { noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #17 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #18 = { nofree nounwind }
attributes #19 = { nounwind uwtable }
attributes #20 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #21 = { nounwind }
attributes #22 = { nounwind allocsize(0) }
attributes #23 = { nounwind allocsize(0,1) }
attributes #24 = { cold }
attributes #25 = { cold nounwind }
attributes #26 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!696, !697, !698, !699, !700, !701, !702}
!llvm.ident = !{!703}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "itemstats", scope: !2, file: !3, line: 57, type: !671, isLocal: true, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !93, globals: !268, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "items.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "de12972ea84c104ebba2e1cc6546cd05")
!4 = !{!5, !25, !39, !58, !63, !68, !74, !79, !87}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "conn_states", file: !6, line: 204, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "./memcached.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "a52021954a5d6b153b5bc084e2fbff2b")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12, !13, !14, !15, !16, !17, !18, !19, !20, !21, !22, !23, !24}
!9 = !DIEnumerator(name: "conn_listening", value: 0)
!10 = !DIEnumerator(name: "conn_new_cmd", value: 1)
!11 = !DIEnumerator(name: "conn_waiting", value: 2)
!12 = !DIEnumerator(name: "conn_read", value: 3)
!13 = !DIEnumerator(name: "conn_parse_cmd", value: 4)
!14 = !DIEnumerator(name: "conn_write", value: 5)
!15 = !DIEnumerator(name: "conn_nread", value: 6)
!16 = !DIEnumerator(name: "conn_swallow", value: 7)
!17 = !DIEnumerator(name: "conn_closing", value: 8)
!18 = !DIEnumerator(name: "conn_mwrite", value: 9)
!19 = !DIEnumerator(name: "conn_closed", value: 10)
!20 = !DIEnumerator(name: "conn_watch", value: 11)
!21 = !DIEnumerator(name: "conn_io_queue", value: 12)
!22 = !DIEnumerator(name: "conn_io_resume", value: 13)
!23 = !DIEnumerator(name: "conn_io_pending", value: 14)
!24 = !DIEnumerator(name: "conn_max_state", value: 15)
!25 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "bin_substates", file: !6, line: 223, baseType: !7, size: 32, elements: !26)
!26 = !{!27, !28, !29, !30, !31, !32, !33, !34, !35, !36, !37, !38}
!27 = !DIEnumerator(name: "bin_no_state", value: 0)
!28 = !DIEnumerator(name: "bin_reading_set_header", value: 1)
!29 = !DIEnumerator(name: "bin_reading_cas_header", value: 2)
!30 = !DIEnumerator(name: "bin_read_set_value", value: 3)
!31 = !DIEnumerator(name: "bin_reading_get_key", value: 4)
!32 = !DIEnumerator(name: "bin_reading_stat", value: 5)
!33 = !DIEnumerator(name: "bin_reading_del_header", value: 6)
!34 = !DIEnumerator(name: "bin_reading_incr_header", value: 7)
!35 = !DIEnumerator(name: "bin_read_flush_exptime", value: 8)
!36 = !DIEnumerator(name: "bin_reading_sasl_auth", value: 9)
!37 = !DIEnumerator(name: "bin_reading_sasl_auth_data", value: 10)
!38 = !DIEnumerator(name: "bin_reading_touch_key", value: 11)
!39 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "log_entry_type", file: !40, line: 16, baseType: !7, size: 32, elements: !41)
!40 = !DIFile(filename: "./logger.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "e743c4228b1e0bc1c91bec9cfd28d5ab")
!41 = !{!42, !43, !44, !45, !46, !47, !48, !49, !50, !51, !52, !53, !54, !55, !56, !57}
!42 = !DIEnumerator(name: "LOGGER_ASCII_CMD", value: 0)
!43 = !DIEnumerator(name: "LOGGER_EVICTION", value: 1)
!44 = !DIEnumerator(name: "LOGGER_ITEM_GET", value: 2)
!45 = !DIEnumerator(name: "LOGGER_ITEM_STORE", value: 3)
!46 = !DIEnumerator(name: "LOGGER_CRAWLER_STATUS", value: 4)
!47 = !DIEnumerator(name: "LOGGER_SLAB_MOVE", value: 5)
!48 = !DIEnumerator(name: "LOGGER_CONNECTION_NEW", value: 6)
!49 = !DIEnumerator(name: "LOGGER_CONNECTION_CLOSE", value: 7)
!50 = !DIEnumerator(name: "LOGGER_DELETIONS", value: 8)
!51 = !DIEnumerator(name: "LOGGER_EXTSTORE_WRITE", value: 9)
!52 = !DIEnumerator(name: "LOGGER_COMPACT_START", value: 10)
!53 = !DIEnumerator(name: "LOGGER_COMPACT_ABORT", value: 11)
!54 = !DIEnumerator(name: "LOGGER_COMPACT_READ_START", value: 12)
!55 = !DIEnumerator(name: "LOGGER_COMPACT_READ_END", value: 13)
!56 = !DIEnumerator(name: "LOGGER_COMPACT_END", value: 14)
!57 = !DIEnumerator(name: "LOGGER_COMPACT_FRAGINFO", value: 15)
!58 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "protocol", file: !6, line: 238, baseType: !7, size: 32, elements: !59)
!59 = !{!60, !61, !62}
!60 = !DIEnumerator(name: "ascii_prot", value: 3)
!61 = !DIEnumerator(name: "binary_prot", value: 4)
!62 = !DIEnumerator(name: "negotiating_prot", value: 5)
!63 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "network_transport", file: !6, line: 247, baseType: !7, size: 32, elements: !64)
!64 = !{!65, !66, !67}
!65 = !DIEnumerator(name: "local_transport", value: 0)
!66 = !DIEnumerator(name: "tcp_transport", value: 1)
!67 = !DIEnumerator(name: "udp_transport", value: 2)
!68 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "close_reasons", file: !6, line: 266, baseType: !7, size: 32, elements: !69)
!69 = !{!70, !71, !72, !73}
!70 = !DIEnumerator(name: "ERROR_CLOSE", value: 0)
!71 = !DIEnumerator(name: "NORMAL_CLOSE", value: 1)
!72 = !DIEnumerator(name: "IDLE_TIMEOUT_CLOSE", value: 2)
!73 = !DIEnumerator(name: "SHUTDOWN_CLOSE", value: 3)
!74 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "logger_ret_type", file: !40, line: 45, baseType: !7, size: 32, elements: !75)
!75 = !{!76, !77, !78}
!76 = !DIEnumerator(name: "LOGGER_RET_OK", value: 0)
!77 = !DIEnumerator(name: "LOGGER_RET_NOSPACE", value: 1)
!78 = !DIEnumerator(name: "LOGGER_RET_ERR", value: 2)
!79 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "reassign_result_type", file: !80, line: 55, baseType: !7, size: 32, elements: !81)
!80 = !DIFile(filename: "./slabs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "28867aba1f41c79140864d76faedcb32")
!81 = !{!82, !83, !84, !85, !86}
!82 = !DIEnumerator(name: "REASSIGN_OK", value: 0)
!83 = !DIEnumerator(name: "REASSIGN_RUNNING", value: 1)
!84 = !DIEnumerator(name: "REASSIGN_BADCLASS", value: 2)
!85 = !DIEnumerator(name: "REASSIGN_NOSPARE", value: 3)
!86 = !DIEnumerator(name: "REASSIGN_SRC_DST_SAME", value: 4)
!87 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "crawler_run_type", file: !6, line: 619, baseType: !7, size: 32, elements: !88)
!88 = !{!89, !90, !91, !92}
!89 = !DIEnumerator(name: "CRAWLER_AUTOEXPIRE", value: 0)
!90 = !DIEnumerator(name: "CRAWLER_EXPIRED", value: 1)
!91 = !DIEnumerator(name: "CRAWLER_METADUMP", value: 2)
!92 = !DIEnumerator(name: "CRAWLER_MGDUMP", value: 3)
!93 = !{!94, !95, !147, !148, !150, !151, !258, !7}
!94 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!95 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !96, size: 64)
!96 = !DIDerivedType(tag: DW_TAG_typedef, name: "item_chunk", file: !6, line: 653, baseType: !97)
!97 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_strchunk", file: !6, line: 641, size: 384, elements: !98)
!98 = !{!99, !101, !102, !138, !139, !140, !141, !142, !143, !144, !145}
!99 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !97, file: !6, line: 642, baseType: !100, size: 64)
!100 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !97, size: 64)
!101 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !97, file: !6, line: 643, baseType: !100, size: 64, offset: 64)
!102 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !97, file: !6, line: 644, baseType: !103, size: 64, offset: 128)
!103 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !104, size: 64)
!104 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_stritem", file: !6, line: 593, size: 384, elements: !105)
!105 = !{!106, !107, !108, !109, !111, !112, !114, !116, !121, !125, !126}
!106 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !104, file: !6, line: 595, baseType: !103, size: 64)
!107 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !104, file: !6, line: 596, baseType: !103, size: 64, offset: 64)
!108 = !DIDerivedType(tag: DW_TAG_member, name: "h_next", scope: !104, file: !6, line: 598, baseType: !103, size: 64, offset: 128)
!109 = !DIDerivedType(tag: DW_TAG_member, name: "time", scope: !104, file: !6, line: 599, baseType: !110, size: 32, offset: 192)
!110 = !DIDerivedType(tag: DW_TAG_typedef, name: "rel_time_t", file: !40, line: 14, baseType: !7)
!111 = !DIDerivedType(tag: DW_TAG_member, name: "exptime", scope: !104, file: !6, line: 600, baseType: !110, size: 32, offset: 224)
!112 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !104, file: !6, line: 601, baseType: !113, size: 32, offset: 256)
!113 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!114 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !104, file: !6, line: 602, baseType: !115, size: 16, offset: 288)
!115 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!116 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !104, file: !6, line: 603, baseType: !117, size: 16, offset: 304)
!117 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint16_t", file: !118, line: 25, baseType: !119)
!118 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!119 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint16_t", file: !120, line: 40, baseType: !115)
!120 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!121 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !104, file: !6, line: 604, baseType: !122, size: 8, offset: 320)
!122 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !118, line: 24, baseType: !123)
!123 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !120, line: 38, baseType: !124)
!124 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!125 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !104, file: !6, line: 605, baseType: !122, size: 8, offset: 328)
!126 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !104, file: !6, line: 611, baseType: !127, offset: 384)
!127 = !DICompositeType(tag: DW_TAG_array_type, baseType: !128, elements: !136)
!128 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !104, file: !6, line: 608, size: 64, elements: !129)
!129 = !{!130, !134}
!130 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !128, file: !6, line: 609, baseType: !131, size: 64)
!131 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !118, line: 27, baseType: !132)
!132 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !120, line: 45, baseType: !133)
!133 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!134 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !128, file: !6, line: 610, baseType: !135, size: 8)
!135 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!136 = !{!137}
!137 = !DISubrange(count: -1)
!138 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !97, file: !6, line: 645, baseType: !113, size: 32, offset: 192)
!139 = !DIDerivedType(tag: DW_TAG_member, name: "used", scope: !97, file: !6, line: 646, baseType: !113, size: 32, offset: 224)
!140 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !97, file: !6, line: 647, baseType: !113, size: 32, offset: 256)
!141 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !97, file: !6, line: 648, baseType: !115, size: 16, offset: 288)
!142 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !97, file: !6, line: 649, baseType: !117, size: 16, offset: 304)
!143 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !97, file: !6, line: 650, baseType: !122, size: 8, offset: 320)
!144 = !DIDerivedType(tag: DW_TAG_member, name: "orig_clsid", scope: !97, file: !6, line: 651, baseType: !122, size: 8, offset: 328)
!145 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !97, file: !6, line: 652, baseType: !146, offset: 336)
!146 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, elements: !136)
!147 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !135, size: 64)
!148 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !149, line: 18, baseType: !133)
!149 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!150 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!151 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !152, size: 64)
!152 = !DIDerivedType(tag: DW_TAG_typedef, name: "logger", file: !40, line: 193, baseType: !153)
!153 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logger", file: !40, line: 181, size: 832, elements: !154)
!154 = !{!155, !157, !158, !189, !190, !191, !192, !193, !194, !195, !208}
!155 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !153, file: !40, line: 182, baseType: !156, size: 64)
!156 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !153, size: 64)
!157 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !153, file: !40, line: 183, baseType: !156, size: 64, offset: 64)
!158 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !153, file: !40, line: 184, baseType: !159, size: 320, offset: 128)
!159 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutex_t", file: !160, line: 72, baseType: !161)
!160 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h", directory: "", checksumkind: CSK_MD5, checksum: "8a5acdbeec491eca11cf81cb1ef77ea7")
!161 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !160, line: 67, size: 320, elements: !162)
!162 = !{!163, !183, !187}
!163 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !161, file: !160, line: 69, baseType: !164, size: 320)
!164 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_mutex_s", file: !165, line: 22, size: 320, elements: !166)
!165 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h", directory: "", checksumkind: CSK_MD5, checksum: "6b075eca9ab0e2d761b2afc4ecfab776")
!166 = !{!167, !168, !169, !170, !171, !172, !174, !175}
!167 = !DIDerivedType(tag: DW_TAG_member, name: "__lock", scope: !164, file: !165, line: 24, baseType: !113, size: 32)
!168 = !DIDerivedType(tag: DW_TAG_member, name: "__count", scope: !164, file: !165, line: 25, baseType: !7, size: 32, offset: 32)
!169 = !DIDerivedType(tag: DW_TAG_member, name: "__owner", scope: !164, file: !165, line: 26, baseType: !113, size: 32, offset: 64)
!170 = !DIDerivedType(tag: DW_TAG_member, name: "__nusers", scope: !164, file: !165, line: 28, baseType: !7, size: 32, offset: 96)
!171 = !DIDerivedType(tag: DW_TAG_member, name: "__kind", scope: !164, file: !165, line: 32, baseType: !113, size: 32, offset: 128)
!172 = !DIDerivedType(tag: DW_TAG_member, name: "__spins", scope: !164, file: !165, line: 34, baseType: !173, size: 16, offset: 160)
!173 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!174 = !DIDerivedType(tag: DW_TAG_member, name: "__elision", scope: !164, file: !165, line: 35, baseType: !173, size: 16, offset: 176)
!175 = !DIDerivedType(tag: DW_TAG_member, name: "__list", scope: !164, file: !165, line: 36, baseType: !176, size: 128, offset: 192)
!176 = !DIDerivedType(tag: DW_TAG_typedef, name: "__pthread_list_t", file: !177, line: 55, baseType: !178)
!177 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h", directory: "", checksumkind: CSK_MD5, checksum: "b9a7199822bce372686baacd32a9f4f3")
!178 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_internal_list", file: !177, line: 51, size: 128, elements: !179)
!179 = !{!180, !182}
!180 = !DIDerivedType(tag: DW_TAG_member, name: "__prev", scope: !178, file: !177, line: 53, baseType: !181, size: 64)
!181 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !178, size: 64)
!182 = !DIDerivedType(tag: DW_TAG_member, name: "__next", scope: !178, file: !177, line: 54, baseType: !181, size: 64, offset: 64)
!183 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !161, file: !160, line: 70, baseType: !184, size: 320)
!184 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 320, elements: !185)
!185 = !{!186}
!186 = !DISubrange(count: 40)
!187 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !161, file: !160, line: 71, baseType: !188, size: 64)
!188 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!189 = !DIDerivedType(tag: DW_TAG_member, name: "written", scope: !153, file: !40, line: 185, baseType: !131, size: 64, offset: 448)
!190 = !DIDerivedType(tag: DW_TAG_member, name: "dropped", scope: !153, file: !40, line: 186, baseType: !131, size: 64, offset: 512)
!191 = !DIDerivedType(tag: DW_TAG_member, name: "blocked", scope: !153, file: !40, line: 187, baseType: !131, size: 64, offset: 576)
!192 = !DIDerivedType(tag: DW_TAG_member, name: "fetcher_ratio", scope: !153, file: !40, line: 188, baseType: !117, size: 16, offset: 640)
!193 = !DIDerivedType(tag: DW_TAG_member, name: "mutation_ratio", scope: !153, file: !40, line: 189, baseType: !117, size: 16, offset: 656)
!194 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !153, file: !40, line: 190, baseType: !117, size: 16, offset: 672)
!195 = !DIDerivedType(tag: DW_TAG_member, name: "buf", scope: !153, file: !40, line: 191, baseType: !196, size: 64, offset: 704)
!196 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !197, size: 64)
!197 = !DIDerivedType(tag: DW_TAG_typedef, name: "bipbuf_t", file: !198, line: 18, baseType: !199)
!198 = !DIFile(filename: "./bipbuffer.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "99606bcb8393045e6bc9eef40115066f")
!199 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !198, line: 4, size: 192, elements: !200)
!200 = !{!201, !202, !203, !204, !205, !206}
!201 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !199, file: !198, line: 6, baseType: !133, size: 64)
!202 = !DIDerivedType(tag: DW_TAG_member, name: "a_start", scope: !199, file: !198, line: 9, baseType: !7, size: 32, offset: 64)
!203 = !DIDerivedType(tag: DW_TAG_member, name: "a_end", scope: !199, file: !198, line: 9, baseType: !7, size: 32, offset: 96)
!204 = !DIDerivedType(tag: DW_TAG_member, name: "b_end", scope: !199, file: !198, line: 12, baseType: !7, size: 32, offset: 128)
!205 = !DIDerivedType(tag: DW_TAG_member, name: "b_inuse", scope: !199, file: !198, line: 15, baseType: !113, size: 32, offset: 160)
!206 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !199, file: !198, line: 17, baseType: !207, offset: 192)
!207 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, elements: !136)
!208 = !DIDerivedType(tag: DW_TAG_member, name: "entry_map", scope: !153, file: !40, line: 192, baseType: !209, size: 64, offset: 768)
!209 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !210, size: 64)
!210 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !211)
!211 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_details", file: !40, line: 58, baseType: !212)
!212 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_entry_details", file: !40, line: 63, size: 256, elements: !213)
!213 = !{!214, !215, !216, !252, !257}
!214 = !DIDerivedType(tag: DW_TAG_member, name: "reqlen", scope: !212, file: !40, line: 64, baseType: !113, size: 32)
!215 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !212, file: !40, line: 65, baseType: !117, size: 16, offset: 32)
!216 = !DIDerivedType(tag: DW_TAG_member, name: "log_cb", scope: !212, file: !40, line: 66, baseType: !217, size: 64, offset: 64)
!217 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_log_cb", file: !40, line: 60, baseType: !218)
!218 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !219, size: 64)
!219 = !DISubroutineType(types: !220)
!220 = !{null, !221, !209, !243, !245}
!221 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !222, size: 64)
!222 = !DIDerivedType(tag: DW_TAG_typedef, name: "logentry", file: !40, line: 57, baseType: !223)
!223 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logentry", file: !40, line: 156, size: 320, elements: !224)
!224 = !{!225, !226, !227, !228, !229, !237, !238}
!225 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !223, file: !40, line: 157, baseType: !39, size: 32)
!226 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !223, file: !40, line: 158, baseType: !122, size: 8, offset: 32)
!227 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !223, file: !40, line: 159, baseType: !117, size: 16, offset: 48)
!228 = !DIDerivedType(tag: DW_TAG_member, name: "gid", scope: !223, file: !40, line: 160, baseType: !131, size: 64, offset: 64)
!229 = !DIDerivedType(tag: DW_TAG_member, name: "tv", scope: !223, file: !40, line: 161, baseType: !230, size: 128, offset: 128)
!230 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "timeval", file: !231, line: 8, size: 128, elements: !232)
!231 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h", directory: "", checksumkind: CSK_MD5, checksum: "9b45d950050c215f216850b27bd1e8f3")
!232 = !{!233, !235}
!233 = !DIDerivedType(tag: DW_TAG_member, name: "tv_sec", scope: !230, file: !231, line: 14, baseType: !234, size: 64)
!234 = !DIDerivedType(tag: DW_TAG_typedef, name: "__time_t", file: !120, line: 160, baseType: !188)
!235 = !DIDerivedType(tag: DW_TAG_member, name: "tv_usec", scope: !230, file: !231, line: 15, baseType: !236, size: 64, offset: 64)
!236 = !DIDerivedType(tag: DW_TAG_typedef, name: "__suseconds_t", file: !120, line: 162, baseType: !188)
!237 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !223, file: !40, line: 162, baseType: !113, size: 32, offset: 256)
!238 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !223, file: !40, line: 165, baseType: !239, offset: 288)
!239 = !DICompositeType(tag: DW_TAG_array_type, baseType: !240, elements: !136)
!240 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !223, file: !40, line: 163, size: 8, elements: !241)
!241 = !{!242}
!242 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !240, file: !40, line: 164, baseType: !135, size: 8)
!243 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !244, size: 64)
!244 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!245 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !246, size: 64)
!246 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !247)
!247 = !{!248, !249, !250, !251}
!248 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !246, file: !3, line: 756, baseType: !7, size: 32)
!249 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !246, file: !3, line: 756, baseType: !7, size: 32, offset: 32)
!250 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !246, file: !3, line: 756, baseType: !94, size: 64, offset: 64)
!251 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !246, file: !3, line: 756, baseType: !94, size: 64, offset: 128)
!252 = !DIDerivedType(tag: DW_TAG_member, name: "parse_cb", scope: !212, file: !40, line: 67, baseType: !253, size: 64, offset: 128)
!253 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_parse_cb", file: !40, line: 61, baseType: !254)
!254 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !255, size: 64)
!255 = !DISubroutineType(types: !256)
!256 = !{!113, !221, !147}
!257 = !DIDerivedType(tag: DW_TAG_member, name: "format", scope: !212, file: !40, line: 68, baseType: !147, size: 64, offset: 192)
!258 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !259, size: 64)
!259 = !DIDerivedType(tag: DW_TAG_typedef, name: "lru_bump_entry", file: !3, line: 96, baseType: !260)
!260 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 93, size: 128, elements: !261)
!261 = !{!262, !265}
!262 = !DIDerivedType(tag: DW_TAG_member, name: "it", scope: !260, file: !3, line: 94, baseType: !263, size: 64)
!263 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !264, size: 64)
!264 = !DIDerivedType(tag: DW_TAG_typedef, name: "item", file: !6, line: 616, baseType: !104)
!265 = !DIDerivedType(tag: DW_TAG_member, name: "hv", scope: !260, file: !3, line: 95, baseType: !266, size: 32, offset: 64)
!266 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !118, line: 26, baseType: !267)
!267 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !120, line: 42, baseType: !7)
!268 = !{!269, !274, !279, !284, !289, !291, !296, !301, !303, !305, !310, !312, !317, !319, !324, !329, !331, !336, !341, !346, !351, !353, !355, !357, !362, !367, !372, !374, !376, !378, !383, !385, !387, !389, !391, !393, !395, !397, !399, !401, !406, !408, !410, !412, !414, !416, !421, !525, !527, !532, !534, !536, !541, !0, !543, !546, !549, !552, !554, !556, !559, !562, !564, !566, !578, !580, !582, !585, !590, !595, !600, !605, !659, !661, !663, !665, !667, !669}
!269 = !DIGlobalVariableExpression(var: !270, expr: !DIExpression())
!270 = distinct !DIGlobalVariable(scope: null, file: !3, line: 677, type: !271, isLocal: true, isDefinition: true)
!271 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 200, elements: !272)
!272 = !{!273}
!273 = !DISubrange(count: 25)
!274 = !DIGlobalVariableExpression(var: !275, expr: !DIExpression())
!275 = distinct !DIGlobalVariable(scope: null, file: !3, line: 689, type: !276, isLocal: true, isDefinition: true)
!276 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 48, elements: !277)
!277 = !{!278}
!278 = !DISubrange(count: 6)
!279 = !DIGlobalVariableExpression(var: !280, expr: !DIExpression())
!280 = distinct !DIGlobalVariable(scope: null, file: !3, line: 756, type: !281, isLocal: true, isDefinition: true)
!281 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 144, elements: !282)
!282 = !{!283}
!283 = !DISubrange(count: 18)
!284 = !DIGlobalVariableExpression(var: !285, expr: !DIExpression())
!285 = distinct !DIGlobalVariable(scope: null, file: !3, line: 756, type: !286, isLocal: true, isDefinition: true)
!286 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 40, elements: !287)
!287 = !{!288}
!288 = !DISubrange(count: 5)
!289 = !DIGlobalVariableExpression(var: !290, expr: !DIExpression())
!290 = distinct !DIGlobalVariable(scope: null, file: !3, line: 758, type: !281, isLocal: true, isDefinition: true)
!291 = !DIGlobalVariableExpression(var: !292, expr: !DIExpression())
!292 = distinct !DIGlobalVariable(scope: null, file: !3, line: 761, type: !293, isLocal: true, isDefinition: true)
!293 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 120, elements: !294)
!294 = !{!295}
!295 = !DISubrange(count: 15)
!296 = !DIGlobalVariableExpression(var: !297, expr: !DIExpression())
!297 = distinct !DIGlobalVariable(scope: null, file: !3, line: 764, type: !298, isLocal: true, isDefinition: true)
!298 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 80, elements: !299)
!299 = !{!300}
!300 = !DISubrange(count: 10)
!301 = !DIGlobalVariableExpression(var: !302, expr: !DIExpression())
!302 = distinct !DIGlobalVariable(scope: null, file: !3, line: 766, type: !298, isLocal: true, isDefinition: true)
!303 = !DIGlobalVariableExpression(var: !304, expr: !DIExpression())
!304 = distinct !DIGlobalVariable(scope: null, file: !3, line: 768, type: !281, isLocal: true, isDefinition: true)
!305 = !DIGlobalVariableExpression(var: !306, expr: !DIExpression())
!306 = distinct !DIGlobalVariable(scope: null, file: !3, line: 770, type: !307, isLocal: true, isDefinition: true)
!307 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 176, elements: !308)
!308 = !{!309}
!309 = !DISubrange(count: 22)
!310 = !DIGlobalVariableExpression(var: !311, expr: !DIExpression())
!311 = distinct !DIGlobalVariable(scope: null, file: !3, line: 772, type: !281, isLocal: true, isDefinition: true)
!312 = !DIGlobalVariableExpression(var: !313, expr: !DIExpression())
!313 = distinct !DIGlobalVariable(scope: null, file: !3, line: 775, type: !314, isLocal: true, isDefinition: true)
!314 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 112, elements: !315)
!315 = !{!316}
!316 = !DISubrange(count: 14)
!317 = !DIGlobalVariableExpression(var: !318, expr: !DIExpression())
!318 = distinct !DIGlobalVariable(scope: null, file: !3, line: 777, type: !314, isLocal: true, isDefinition: true)
!319 = !DIGlobalVariableExpression(var: !320, expr: !DIExpression())
!320 = distinct !DIGlobalVariable(scope: null, file: !3, line: 779, type: !321, isLocal: true, isDefinition: true)
!321 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 136, elements: !322)
!322 = !{!323}
!323 = !DISubrange(count: 17)
!324 = !DIGlobalVariableExpression(var: !325, expr: !DIExpression())
!325 = distinct !DIGlobalVariable(scope: null, file: !3, line: 781, type: !326, isLocal: true, isDefinition: true)
!326 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 128, elements: !327)
!327 = !{!328}
!328 = !DISubrange(count: 16)
!329 = !DIGlobalVariableExpression(var: !330, expr: !DIExpression())
!330 = distinct !DIGlobalVariable(scope: null, file: !3, line: 783, type: !281, isLocal: true, isDefinition: true)
!331 = !DIGlobalVariableExpression(var: !332, expr: !DIExpression())
!332 = distinct !DIGlobalVariable(scope: null, file: !3, line: 802, type: !333, isLocal: true, isDefinition: true)
!333 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 96, elements: !334)
!334 = !{!335}
!335 = !DISubrange(count: 12)
!336 = !DIGlobalVariableExpression(var: !337, expr: !DIExpression())
!337 = distinct !DIGlobalVariable(scope: null, file: !3, line: 854, type: !338, isLocal: true, isDefinition: true)
!338 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 56, elements: !339)
!339 = !{!340}
!340 = !DISubrange(count: 7)
!341 = !DIGlobalVariableExpression(var: !342, expr: !DIExpression())
!342 = distinct !DIGlobalVariable(scope: null, file: !3, line: 854, type: !343, isLocal: true, isDefinition: true)
!343 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 24, elements: !344)
!344 = !{!345}
!345 = !DISubrange(count: 3)
!346 = !DIGlobalVariableExpression(var: !347, expr: !DIExpression())
!347 = distinct !DIGlobalVariable(scope: null, file: !3, line: 856, type: !348, isLocal: true, isDefinition: true)
!348 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 88, elements: !349)
!349 = !{!350}
!350 = !DISubrange(count: 11)
!351 = !DIGlobalVariableExpression(var: !352, expr: !DIExpression())
!352 = distinct !DIGlobalVariable(scope: null, file: !3, line: 857, type: !333, isLocal: true, isDefinition: true)
!353 = !DIGlobalVariableExpression(var: !354, expr: !DIExpression())
!354 = distinct !DIGlobalVariable(scope: null, file: !3, line: 858, type: !333, isLocal: true, isDefinition: true)
!355 = !DIGlobalVariableExpression(var: !356, expr: !DIExpression())
!356 = distinct !DIGlobalVariable(scope: null, file: !3, line: 860, type: !333, isLocal: true, isDefinition: true)
!357 = !DIGlobalVariableExpression(var: !358, expr: !DIExpression())
!358 = distinct !DIGlobalVariable(scope: null, file: !3, line: 862, type: !359, isLocal: true, isDefinition: true)
!359 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 64, elements: !360)
!360 = !{!361}
!361 = !DISubrange(count: 8)
!362 = !DIGlobalVariableExpression(var: !363, expr: !DIExpression())
!363 = distinct !DIGlobalVariable(scope: null, file: !3, line: 863, type: !364, isLocal: true, isDefinition: true)
!364 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 72, elements: !365)
!365 = !{!366}
!366 = !DISubrange(count: 9)
!367 = !DIGlobalVariableExpression(var: !368, expr: !DIExpression())
!368 = distinct !DIGlobalVariable(scope: null, file: !3, line: 865, type: !369, isLocal: true, isDefinition: true)
!369 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 32, elements: !370)
!370 = !{!371}
!371 = !DISubrange(count: 4)
!372 = !DIGlobalVariableExpression(var: !373, expr: !DIExpression())
!373 = distinct !DIGlobalVariable(scope: null, file: !3, line: 866, type: !314, isLocal: true, isDefinition: true)
!374 = !DIGlobalVariableExpression(var: !375, expr: !DIExpression())
!375 = distinct !DIGlobalVariable(scope: null, file: !3, line: 867, type: !359, isLocal: true, isDefinition: true)
!376 = !DIGlobalVariableExpression(var: !377, expr: !DIExpression())
!377 = distinct !DIGlobalVariable(scope: null, file: !3, line: 869, type: !326, isLocal: true, isDefinition: true)
!378 = !DIGlobalVariableExpression(var: !379, expr: !DIExpression())
!379 = distinct !DIGlobalVariable(scope: null, file: !3, line: 871, type: !380, isLocal: true, isDefinition: true)
!380 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 104, elements: !381)
!381 = !{!382}
!382 = !DISubrange(count: 13)
!383 = !DIGlobalVariableExpression(var: !384, expr: !DIExpression())
!384 = distinct !DIGlobalVariable(scope: null, file: !3, line: 873, type: !333, isLocal: true, isDefinition: true)
!385 = !DIGlobalVariableExpression(var: !386, expr: !DIExpression())
!386 = distinct !DIGlobalVariable(scope: null, file: !3, line: 875, type: !333, isLocal: true, isDefinition: true)
!387 = !DIGlobalVariableExpression(var: !388, expr: !DIExpression())
!388 = distinct !DIGlobalVariable(scope: null, file: !3, line: 902, type: !333, isLocal: true, isDefinition: true)
!389 = !DIGlobalVariableExpression(var: !390, expr: !DIExpression())
!390 = distinct !DIGlobalVariable(scope: null, file: !3, line: 905, type: !380, isLocal: true, isDefinition: true)
!391 = !DIGlobalVariableExpression(var: !392, expr: !DIExpression())
!392 = distinct !DIGlobalVariable(scope: null, file: !3, line: 908, type: !380, isLocal: true, isDefinition: true)
!393 = !DIGlobalVariableExpression(var: !394, expr: !DIExpression())
!394 = distinct !DIGlobalVariable(scope: null, file: !3, line: 911, type: !380, isLocal: true, isDefinition: true)
!395 = !DIGlobalVariableExpression(var: !396, expr: !DIExpression())
!396 = distinct !DIGlobalVariable(scope: null, file: !3, line: 968, type: !343, isLocal: true, isDefinition: true)
!397 = !DIGlobalVariableExpression(var: !398, expr: !DIExpression())
!398 = distinct !DIGlobalVariable(scope: null, file: !3, line: 973, type: !380, isLocal: true, isDefinition: true)
!399 = !DIGlobalVariableExpression(var: !400, expr: !DIExpression())
!400 = distinct !DIGlobalVariable(scope: null, file: !3, line: 973, type: !364, isLocal: true, isDefinition: true)
!401 = !DIGlobalVariableExpression(var: !402, expr: !DIExpression())
!402 = distinct !DIGlobalVariable(scope: null, file: !3, line: 973, type: !403, isLocal: true, isDefinition: true)
!403 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 8, elements: !404)
!404 = !{!405}
!405 = !DISubrange(count: 1)
!406 = !DIGlobalVariableExpression(var: !407, expr: !DIExpression())
!407 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1010, type: !380, isLocal: true, isDefinition: true)
!408 = !DIGlobalVariableExpression(var: !409, expr: !DIExpression())
!409 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1012, type: !380, isLocal: true, isDefinition: true)
!410 = !DIGlobalVariableExpression(var: !411, expr: !DIExpression())
!411 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1015, type: !343, isLocal: true, isDefinition: true)
!412 = !DIGlobalVariableExpression(var: !413, expr: !DIExpression())
!413 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1030, type: !321, isLocal: true, isDefinition: true)
!414 = !DIGlobalVariableExpression(var: !415, expr: !DIExpression())
!415 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1042, type: !281, isLocal: true, isDefinition: true)
!416 = !DIGlobalVariableExpression(var: !417, expr: !DIExpression())
!417 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1054, type: !418, isLocal: true, isDefinition: true)
!418 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 16, elements: !419)
!419 = !{!420}
!420 = !DISubrange(count: 2)
!421 = !DIGlobalVariableExpression(var: !422, expr: !DIExpression())
!422 = distinct !DIGlobalVariable(name: "slab_automove_default", scope: !2, file: !3, line: 1570, type: !423, isLocal: false, isDefinition: true)
!423 = !DIDerivedType(tag: DW_TAG_typedef, name: "slab_automove_reg_t", file: !424, line: 17, baseType: !425)
!424 = !DIFile(filename: "./slab_automove.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "6e7f28420ac5e26e1c021dee6706e0c0")
!425 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !424, line: 13, size: 192, elements: !426)
!426 = !{!427, !514, !519}
!427 = !DIDerivedType(tag: DW_TAG_member, name: "init", scope: !425, file: !424, line: 14, baseType: !428, size: 64)
!428 = !DIDerivedType(tag: DW_TAG_typedef, name: "slab_automove_init_func", file: !424, line: 9, baseType: !429)
!429 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !430, size: 64)
!430 = !DISubroutineType(types: !431)
!431 = !{!94, !432}
!432 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !433, size: 64)
!433 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "settings", file: !6, line: 454, size: 2688, elements: !434)
!434 = !{!435, !436, !437, !438, !439, !440, !441, !442, !443, !444, !445, !446, !448, !449, !450, !451, !452, !453, !454, !456, !457, !458, !459, !460, !461, !466, !467, !468, !469, !470, !471, !472, !473, !474, !475, !476, !477, !478, !479, !480, !481, !482, !483, !484, !485, !486, !487, !488, !489, !490, !491, !492, !493, !494, !495, !496, !497, !498, !499, !500, !501, !502, !503, !504, !505, !506, !507, !508, !509, !510, !511, !512, !513}
!435 = !DIDerivedType(tag: DW_TAG_member, name: "maxbytes", scope: !433, file: !6, line: 455, baseType: !148, size: 64)
!436 = !DIDerivedType(tag: DW_TAG_member, name: "maxconns", scope: !433, file: !6, line: 456, baseType: !113, size: 32, offset: 64)
!437 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !433, file: !6, line: 457, baseType: !113, size: 32, offset: 96)
!438 = !DIDerivedType(tag: DW_TAG_member, name: "udpport", scope: !433, file: !6, line: 458, baseType: !113, size: 32, offset: 128)
!439 = !DIDerivedType(tag: DW_TAG_member, name: "inter", scope: !433, file: !6, line: 459, baseType: !147, size: 64, offset: 192)
!440 = !DIDerivedType(tag: DW_TAG_member, name: "verbose", scope: !433, file: !6, line: 460, baseType: !113, size: 32, offset: 256)
!441 = !DIDerivedType(tag: DW_TAG_member, name: "oldest_live", scope: !433, file: !6, line: 461, baseType: !110, size: 32, offset: 288)
!442 = !DIDerivedType(tag: DW_TAG_member, name: "evict_to_free", scope: !433, file: !6, line: 462, baseType: !113, size: 32, offset: 320)
!443 = !DIDerivedType(tag: DW_TAG_member, name: "socketpath", scope: !433, file: !6, line: 463, baseType: !147, size: 64, offset: 384)
!444 = !DIDerivedType(tag: DW_TAG_member, name: "auth_file", scope: !433, file: !6, line: 464, baseType: !147, size: 64, offset: 448)
!445 = !DIDerivedType(tag: DW_TAG_member, name: "access", scope: !433, file: !6, line: 465, baseType: !113, size: 32, offset: 512)
!446 = !DIDerivedType(tag: DW_TAG_member, name: "factor", scope: !433, file: !6, line: 466, baseType: !447, size: 64, offset: 576)
!447 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!448 = !DIDerivedType(tag: DW_TAG_member, name: "chunk_size", scope: !433, file: !6, line: 467, baseType: !113, size: 32, offset: 640)
!449 = !DIDerivedType(tag: DW_TAG_member, name: "num_threads", scope: !433, file: !6, line: 468, baseType: !113, size: 32, offset: 672)
!450 = !DIDerivedType(tag: DW_TAG_member, name: "num_threads_per_udp", scope: !433, file: !6, line: 469, baseType: !113, size: 32, offset: 704)
!451 = !DIDerivedType(tag: DW_TAG_member, name: "prefix_delimiter", scope: !433, file: !6, line: 470, baseType: !135, size: 8, offset: 736)
!452 = !DIDerivedType(tag: DW_TAG_member, name: "detail_enabled", scope: !433, file: !6, line: 471, baseType: !113, size: 32, offset: 768)
!453 = !DIDerivedType(tag: DW_TAG_member, name: "reqs_per_event", scope: !433, file: !6, line: 472, baseType: !113, size: 32, offset: 800)
!454 = !DIDerivedType(tag: DW_TAG_member, name: "use_cas", scope: !433, file: !6, line: 474, baseType: !455, size: 8, offset: 832)
!455 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!456 = !DIDerivedType(tag: DW_TAG_member, name: "binding_protocol", scope: !433, file: !6, line: 475, baseType: !58, size: 32, offset: 864)
!457 = !DIDerivedType(tag: DW_TAG_member, name: "backlog", scope: !433, file: !6, line: 476, baseType: !113, size: 32, offset: 896)
!458 = !DIDerivedType(tag: DW_TAG_member, name: "item_size_max", scope: !433, file: !6, line: 477, baseType: !113, size: 32, offset: 928)
!459 = !DIDerivedType(tag: DW_TAG_member, name: "slab_chunk_size_max", scope: !433, file: !6, line: 478, baseType: !113, size: 32, offset: 960)
!460 = !DIDerivedType(tag: DW_TAG_member, name: "slab_page_size", scope: !433, file: !6, line: 479, baseType: !113, size: 32, offset: 992)
!461 = !DIDerivedType(tag: DW_TAG_member, name: "sig_hup", scope: !433, file: !6, line: 480, baseType: !462, size: 32, offset: 1024)
!462 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !463)
!463 = !DIDerivedType(tag: DW_TAG_typedef, name: "sig_atomic_t", file: !464, line: 8, baseType: !465)
!464 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/sig_atomic_t.h", directory: "", checksumkind: CSK_MD5, checksum: "d9236f7e3e7f10f53aa9d4cd97f503cf")
!465 = !DIDerivedType(tag: DW_TAG_typedef, name: "__sig_atomic_t", file: !120, line: 215, baseType: !113)
!466 = !DIDerivedType(tag: DW_TAG_member, name: "sasl", scope: !433, file: !6, line: 481, baseType: !455, size: 8, offset: 1056)
!467 = !DIDerivedType(tag: DW_TAG_member, name: "maxconns_fast", scope: !433, file: !6, line: 482, baseType: !455, size: 8, offset: 1064)
!468 = !DIDerivedType(tag: DW_TAG_member, name: "lru_crawler", scope: !433, file: !6, line: 483, baseType: !455, size: 8, offset: 1072)
!469 = !DIDerivedType(tag: DW_TAG_member, name: "lru_maintainer_thread", scope: !433, file: !6, line: 484, baseType: !455, size: 8, offset: 1080)
!470 = !DIDerivedType(tag: DW_TAG_member, name: "lru_segmented", scope: !433, file: !6, line: 485, baseType: !455, size: 8, offset: 1088)
!471 = !DIDerivedType(tag: DW_TAG_member, name: "slab_reassign", scope: !433, file: !6, line: 486, baseType: !455, size: 8, offset: 1096)
!472 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove", scope: !433, file: !6, line: 487, baseType: !113, size: 32, offset: 1120)
!473 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove_ratio", scope: !433, file: !6, line: 488, baseType: !447, size: 64, offset: 1152)
!474 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove_window", scope: !433, file: !6, line: 489, baseType: !7, size: 32, offset: 1216)
!475 = !DIDerivedType(tag: DW_TAG_member, name: "hashpower_init", scope: !433, file: !6, line: 490, baseType: !113, size: 32, offset: 1248)
!476 = !DIDerivedType(tag: DW_TAG_member, name: "shutdown_command", scope: !433, file: !6, line: 491, baseType: !455, size: 8, offset: 1280)
!477 = !DIDerivedType(tag: DW_TAG_member, name: "tail_repair_time", scope: !433, file: !6, line: 492, baseType: !113, size: 32, offset: 1312)
!478 = !DIDerivedType(tag: DW_TAG_member, name: "flush_enabled", scope: !433, file: !6, line: 493, baseType: !455, size: 8, offset: 1344)
!479 = !DIDerivedType(tag: DW_TAG_member, name: "dump_enabled", scope: !433, file: !6, line: 494, baseType: !455, size: 8, offset: 1352)
!480 = !DIDerivedType(tag: DW_TAG_member, name: "hash_algorithm", scope: !433, file: !6, line: 495, baseType: !147, size: 64, offset: 1408)
!481 = !DIDerivedType(tag: DW_TAG_member, name: "lru_crawler_sleep", scope: !433, file: !6, line: 496, baseType: !113, size: 32, offset: 1472)
!482 = !DIDerivedType(tag: DW_TAG_member, name: "lru_crawler_tocrawl", scope: !433, file: !6, line: 497, baseType: !266, size: 32, offset: 1504)
!483 = !DIDerivedType(tag: DW_TAG_member, name: "hot_lru_pct", scope: !433, file: !6, line: 498, baseType: !113, size: 32, offset: 1536)
!484 = !DIDerivedType(tag: DW_TAG_member, name: "warm_lru_pct", scope: !433, file: !6, line: 499, baseType: !113, size: 32, offset: 1568)
!485 = !DIDerivedType(tag: DW_TAG_member, name: "hot_max_factor", scope: !433, file: !6, line: 500, baseType: !447, size: 64, offset: 1600)
!486 = !DIDerivedType(tag: DW_TAG_member, name: "warm_max_factor", scope: !433, file: !6, line: 501, baseType: !447, size: 64, offset: 1664)
!487 = !DIDerivedType(tag: DW_TAG_member, name: "crawls_persleep", scope: !433, file: !6, line: 502, baseType: !113, size: 32, offset: 1728)
!488 = !DIDerivedType(tag: DW_TAG_member, name: "temp_lru", scope: !433, file: !6, line: 503, baseType: !455, size: 8, offset: 1760)
!489 = !DIDerivedType(tag: DW_TAG_member, name: "temporary_ttl", scope: !433, file: !6, line: 504, baseType: !266, size: 32, offset: 1792)
!490 = !DIDerivedType(tag: DW_TAG_member, name: "idle_timeout", scope: !433, file: !6, line: 505, baseType: !113, size: 32, offset: 1824)
!491 = !DIDerivedType(tag: DW_TAG_member, name: "logger_watcher_buf_size", scope: !433, file: !6, line: 506, baseType: !7, size: 32, offset: 1856)
!492 = !DIDerivedType(tag: DW_TAG_member, name: "logger_buf_size", scope: !433, file: !6, line: 507, baseType: !7, size: 32, offset: 1888)
!493 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_mem_limit", scope: !433, file: !6, line: 508, baseType: !7, size: 32, offset: 1920)
!494 = !DIDerivedType(tag: DW_TAG_member, name: "drop_privileges", scope: !433, file: !6, line: 509, baseType: !455, size: 8, offset: 1952)
!495 = !DIDerivedType(tag: DW_TAG_member, name: "watch_enabled", scope: !433, file: !6, line: 510, baseType: !455, size: 8, offset: 1960)
!496 = !DIDerivedType(tag: DW_TAG_member, name: "relaxed_privileges", scope: !433, file: !6, line: 511, baseType: !455, size: 8, offset: 1968)
!497 = !DIDerivedType(tag: DW_TAG_member, name: "ext_io_threadcount", scope: !433, file: !6, line: 513, baseType: !7, size: 32, offset: 1984)
!498 = !DIDerivedType(tag: DW_TAG_member, name: "ext_page_size", scope: !433, file: !6, line: 514, baseType: !7, size: 32, offset: 2016)
!499 = !DIDerivedType(tag: DW_TAG_member, name: "ext_item_size", scope: !433, file: !6, line: 515, baseType: !7, size: 32, offset: 2048)
!500 = !DIDerivedType(tag: DW_TAG_member, name: "ext_item_age", scope: !433, file: !6, line: 516, baseType: !7, size: 32, offset: 2080)
!501 = !DIDerivedType(tag: DW_TAG_member, name: "ext_low_ttl", scope: !433, file: !6, line: 517, baseType: !7, size: 32, offset: 2112)
!502 = !DIDerivedType(tag: DW_TAG_member, name: "ext_recache_rate", scope: !433, file: !6, line: 518, baseType: !7, size: 32, offset: 2144)
!503 = !DIDerivedType(tag: DW_TAG_member, name: "ext_wbuf_size", scope: !433, file: !6, line: 519, baseType: !7, size: 32, offset: 2176)
!504 = !DIDerivedType(tag: DW_TAG_member, name: "ext_compact_under", scope: !433, file: !6, line: 520, baseType: !7, size: 32, offset: 2208)
!505 = !DIDerivedType(tag: DW_TAG_member, name: "ext_drop_under", scope: !433, file: !6, line: 521, baseType: !7, size: 32, offset: 2240)
!506 = !DIDerivedType(tag: DW_TAG_member, name: "ext_max_sleep", scope: !433, file: !6, line: 522, baseType: !7, size: 32, offset: 2272)
!507 = !DIDerivedType(tag: DW_TAG_member, name: "ext_max_frag", scope: !433, file: !6, line: 523, baseType: !447, size: 64, offset: 2304)
!508 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove_freeratio", scope: !433, file: !6, line: 524, baseType: !447, size: 64, offset: 2368)
!509 = !DIDerivedType(tag: DW_TAG_member, name: "ext_drop_unread", scope: !433, file: !6, line: 525, baseType: !455, size: 8, offset: 2432)
!510 = !DIDerivedType(tag: DW_TAG_member, name: "ext_global_pool_min", scope: !433, file: !6, line: 527, baseType: !7, size: 32, offset: 2464)
!511 = !DIDerivedType(tag: DW_TAG_member, name: "num_napi_ids", scope: !433, file: !6, line: 544, baseType: !113, size: 32, offset: 2496)
!512 = !DIDerivedType(tag: DW_TAG_member, name: "memory_file", scope: !433, file: !6, line: 545, baseType: !147, size: 64, offset: 2560)
!513 = !DIDerivedType(tag: DW_TAG_member, name: "sock_cookie_id", scope: !433, file: !6, line: 555, baseType: !266, size: 32, offset: 2624)
!514 = !DIDerivedType(tag: DW_TAG_member, name: "free", scope: !425, file: !424, line: 15, baseType: !515, size: 64, offset: 64)
!515 = !DIDerivedType(tag: DW_TAG_typedef, name: "slab_automove_free_func", file: !424, line: 10, baseType: !516)
!516 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !517, size: 64)
!517 = !DISubroutineType(types: !518)
!518 = !{null, !94}
!519 = !DIDerivedType(tag: DW_TAG_member, name: "run", scope: !425, file: !424, line: 16, baseType: !520, size: 64, offset: 128)
!520 = !DIDerivedType(tag: DW_TAG_typedef, name: "slab_automove_run_func", file: !424, line: 11, baseType: !521)
!521 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !522, size: 64)
!522 = !DISubroutineType(types: !523)
!523 = !{null, !94, !524, !524}
!524 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !113, size: 64)
!525 = !DIGlobalVariableExpression(var: !526, expr: !DIExpression())
!526 = distinct !DIGlobalVariable(name: "slab_automove_extstore", scope: !2, file: !3, line: 1576, type: !423, isLocal: false, isDefinition: true)
!527 = !DIGlobalVariableExpression(var: !528, expr: !DIExpression())
!528 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1715, type: !529, isLocal: true, isDefinition: true)
!529 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 336, elements: !530)
!530 = !{!531}
!531 = !DISubrange(count: 42)
!532 = !DIGlobalVariableExpression(var: !533, expr: !DIExpression())
!533 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1730, type: !184, isLocal: true, isDefinition: true)
!534 = !DIGlobalVariableExpression(var: !535, expr: !DIExpression())
!535 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1735, type: !333, isLocal: true, isDefinition: true)
!536 = !DIGlobalVariableExpression(var: !537, expr: !DIExpression())
!537 = distinct !DIGlobalVariable(name: "heads", scope: !2, file: !3, line: 55, type: !538, isLocal: true, isDefinition: true)
!538 = !DICompositeType(tag: DW_TAG_array_type, baseType: !263, size: 16384, elements: !539)
!539 = !{!540}
!540 = !DISubrange(count: 256)
!541 = !DIGlobalVariableExpression(var: !542, expr: !DIExpression())
!542 = distinct !DIGlobalVariable(name: "tails", scope: !2, file: !3, line: 56, type: !538, isLocal: true, isDefinition: true)
!543 = !DIGlobalVariableExpression(var: !544, expr: !DIExpression())
!544 = distinct !DIGlobalVariable(name: "sizes", scope: !2, file: !3, line: 58, type: !545, isLocal: true, isDefinition: true)
!545 = !DICompositeType(tag: DW_TAG_array_type, baseType: !7, size: 8192, elements: !539)
!546 = !DIGlobalVariableExpression(var: !547, expr: !DIExpression())
!547 = distinct !DIGlobalVariable(name: "sizes_bytes", scope: !2, file: !3, line: 59, type: !548, isLocal: true, isDefinition: true)
!548 = !DICompositeType(tag: DW_TAG_array_type, baseType: !131, size: 16384, elements: !539)
!549 = !DIGlobalVariableExpression(var: !550, expr: !DIExpression())
!550 = distinct !DIGlobalVariable(name: "lru_maintainer_tid", scope: !2, file: !3, line: 1582, type: !551, isLocal: true, isDefinition: true)
!551 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_t", file: !160, line: 27, baseType: !133)
!552 = !DIGlobalVariableExpression(var: !553, expr: !DIExpression())
!553 = distinct !DIGlobalVariable(name: "cas_id_lock", scope: !2, file: !3, line: 66, type: !159, isLocal: true, isDefinition: true)
!554 = !DIGlobalVariableExpression(var: !555, expr: !DIExpression())
!555 = distinct !DIGlobalVariable(name: "cas_id", scope: !2, file: !3, line: 62, type: !131, isLocal: true, isDefinition: true)
!556 = !DIGlobalVariableExpression(var: !557, expr: !DIExpression())
!557 = distinct !DIGlobalVariable(name: "lru_type_map", scope: !2, file: !3, line: 28, type: !558, isLocal: true, isDefinition: true)
!558 = !DICompositeType(tag: DW_TAG_array_type, baseType: !7, size: 128, elements: !370)
!559 = !DIGlobalVariableExpression(var: !560, expr: !DIExpression())
!560 = distinct !DIGlobalVariable(name: "stats_sizes_hist", scope: !2, file: !3, line: 60, type: !561, isLocal: true, isDefinition: true)
!561 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !7, size: 64)
!562 = !DIGlobalVariableExpression(var: !563, expr: !DIExpression())
!563 = distinct !DIGlobalVariable(name: "stats_sizes_buckets", scope: !2, file: !3, line: 61, type: !113, isLocal: true, isDefinition: true)
!564 = !DIGlobalVariableExpression(var: !565, expr: !DIExpression())
!565 = distinct !DIGlobalVariable(name: "bump_buf_lock", scope: !2, file: !3, line: 100, type: !159, isLocal: true, isDefinition: true)
!566 = !DIGlobalVariableExpression(var: !567, expr: !DIExpression())
!567 = distinct !DIGlobalVariable(name: "bump_buf_head", scope: !2, file: !3, line: 98, type: !568, isLocal: true, isDefinition: true)
!568 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !569, size: 64)
!569 = !DIDerivedType(tag: DW_TAG_typedef, name: "lru_bump_buf", file: !3, line: 91, baseType: !570)
!570 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_lru_bump_buf", file: !3, line: 85, size: 576, elements: !571)
!571 = !{!572, !574, !575, !576, !577}
!572 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !570, file: !3, line: 86, baseType: !573, size: 64)
!573 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !570, size: 64)
!574 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !570, file: !3, line: 87, baseType: !573, size: 64, offset: 64)
!575 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !570, file: !3, line: 88, baseType: !159, size: 320, offset: 128)
!576 = !DIDerivedType(tag: DW_TAG_member, name: "buf", scope: !570, file: !3, line: 89, baseType: !196, size: 64, offset: 448)
!577 = !DIDerivedType(tag: DW_TAG_member, name: "dropped", scope: !570, file: !3, line: 90, baseType: !131, size: 64, offset: 512)
!578 = !DIGlobalVariableExpression(var: !579, expr: !DIExpression())
!579 = distinct !DIGlobalVariable(name: "bump_buf_tail", scope: !2, file: !3, line: 99, type: !568, isLocal: true, isDefinition: true)
!580 = !DIGlobalVariableExpression(var: !581, expr: !DIExpression())
!581 = distinct !DIGlobalVariable(name: "lru_maintainer_lock", scope: !2, file: !3, line: 65, type: !159, isLocal: true, isDefinition: true)
!582 = !DIGlobalVariableExpression(var: !583, expr: !DIExpression())
!583 = distinct !DIGlobalVariable(name: "do_run_lru_maintainer_thread", scope: !2, file: !3, line: 64, type: !584, isLocal: true, isDefinition: true)
!584 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !113)
!585 = !DIGlobalVariableExpression(var: !586, expr: !DIExpression())
!586 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1604, type: !587, isLocal: true, isDefinition: true)
!587 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 472, elements: !588)
!588 = !{!589}
!589 = !DISubrange(count: 59)
!590 = !DIGlobalVariableExpression(var: !591, expr: !DIExpression())
!591 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1611, type: !592, isLocal: true, isDefinition: true)
!592 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 424, elements: !593)
!593 = !{!594}
!594 = !DISubrange(count: 53)
!595 = !DIGlobalVariableExpression(var: !596, expr: !DIExpression())
!596 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1620, type: !597, isLocal: true, isDefinition: true)
!597 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 344, elements: !598)
!598 = !{!599}
!599 = !DISubrange(count: 43)
!600 = !DIGlobalVariableExpression(var: !601, expr: !DIExpression())
!601 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1703, type: !602, isLocal: true, isDefinition: true)
!602 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 256, elements: !603)
!603 = !{!604}
!604 = !DISubrange(count: 32)
!605 = !DIGlobalVariableExpression(var: !606, expr: !DIExpression())
!606 = distinct !DIGlobalVariable(name: "next_crawls", scope: !607, file: !3, line: 1478, type: !658, isLocal: true, isDefinition: true)
!607 = distinct !DISubprogram(name: "lru_maintainer_crawler_check", scope: !3, file: !3, line: 1476, type: !608, scopeLine: 1476, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !635)
!608 = !DISubroutineType(types: !609)
!609 = !{null, !610, !151}
!610 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !611, size: 64)
!611 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "crawler_expired_data", file: !612, line: 17, size: 1098176, elements: !613)
!612 = !DIFile(filename: "./crawler.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "4dc9e6e54966538ea20b64490631aef9")
!613 = !{!614, !615, !631, !632, !633, !634}
!614 = !DIDerivedType(tag: DW_TAG_member, name: "lock", scope: !611, file: !612, line: 18, baseType: !159, size: 320)
!615 = !DIDerivedType(tag: DW_TAG_member, name: "crawlerstats", scope: !611, file: !612, line: 19, baseType: !616, size: 1097728, offset: 320)
!616 = !DICompositeType(tag: DW_TAG_array_type, baseType: !617, size: 1097728, elements: !539)
!617 = !DIDerivedType(tag: DW_TAG_typedef, name: "crawlerstats_t", file: !612, line: 15, baseType: !618)
!618 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !612, line: 6, size: 4288, elements: !619)
!619 = !{!620, !624, !625, !626, !627, !628, !629, !630}
!620 = !DIDerivedType(tag: DW_TAG_member, name: "histo", scope: !618, file: !612, line: 7, baseType: !621, size: 3904)
!621 = !DICompositeType(tag: DW_TAG_array_type, baseType: !131, size: 3904, elements: !622)
!622 = !{!623}
!623 = !DISubrange(count: 61)
!624 = !DIDerivedType(tag: DW_TAG_member, name: "ttl_hourplus", scope: !618, file: !612, line: 8, baseType: !131, size: 64, offset: 3904)
!625 = !DIDerivedType(tag: DW_TAG_member, name: "noexp", scope: !618, file: !612, line: 9, baseType: !131, size: 64, offset: 3968)
!626 = !DIDerivedType(tag: DW_TAG_member, name: "reclaimed", scope: !618, file: !612, line: 10, baseType: !131, size: 64, offset: 4032)
!627 = !DIDerivedType(tag: DW_TAG_member, name: "seen", scope: !618, file: !612, line: 11, baseType: !131, size: 64, offset: 4096)
!628 = !DIDerivedType(tag: DW_TAG_member, name: "start_time", scope: !618, file: !612, line: 12, baseType: !110, size: 32, offset: 4160)
!629 = !DIDerivedType(tag: DW_TAG_member, name: "end_time", scope: !618, file: !612, line: 13, baseType: !110, size: 32, offset: 4192)
!630 = !DIDerivedType(tag: DW_TAG_member, name: "run_complete", scope: !618, file: !612, line: 14, baseType: !455, size: 8, offset: 4224)
!631 = !DIDerivedType(tag: DW_TAG_member, name: "start_time", scope: !611, file: !612, line: 21, baseType: !110, size: 32, offset: 1098048)
!632 = !DIDerivedType(tag: DW_TAG_member, name: "end_time", scope: !611, file: !612, line: 22, baseType: !110, size: 32, offset: 1098080)
!633 = !DIDerivedType(tag: DW_TAG_member, name: "crawl_complete", scope: !611, file: !612, line: 23, baseType: !455, size: 8, offset: 1098112)
!634 = !DIDerivedType(tag: DW_TAG_member, name: "is_external", scope: !611, file: !612, line: 24, baseType: !455, size: 8, offset: 1098120)
!635 = !{!636, !637, !638, !639, !641, !642, !643, !648, !651, !652, !653, !654, !655, !656}
!636 = !DILocalVariable(name: "cdata", arg: 1, scope: !607, file: !3, line: 1476, type: !610)
!637 = !DILocalVariable(name: "l", arg: 2, scope: !607, file: !3, line: 1476, type: !151)
!638 = !DILocalVariable(name: "i", scope: !607, file: !3, line: 1477, type: !113)
!639 = !DILocalVariable(name: "todo", scope: !607, file: !3, line: 1480, type: !640)
!640 = !DICompositeType(tag: DW_TAG_array_type, baseType: !122, size: 2048, elements: !539)
!641 = !DILocalVariable(name: "do_run", scope: !607, file: !3, line: 1482, type: !455)
!642 = !DILocalVariable(name: "tocrawl_limit", scope: !607, file: !3, line: 1483, type: !7)
!643 = !DILocalVariable(name: "s", scope: !644, file: !3, line: 1487, type: !647)
!644 = distinct !DILexicalBlock(scope: !645, file: !3, line: 1486, column: 54)
!645 = distinct !DILexicalBlock(scope: !646, file: !3, line: 1486, column: 5)
!646 = distinct !DILexicalBlock(scope: !607, file: !3, line: 1486, column: 5)
!647 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !617, size: 64)
!648 = !DILocalVariable(name: "lru_name", scope: !649, file: !3, line: 1490, type: !147)
!649 = distinct !DILexicalBlock(scope: !650, file: !3, line: 1489, column: 30)
!650 = distinct !DILexicalBlock(scope: !644, file: !3, line: 1489, column: 13)
!651 = !DILocalVariable(name: "x", scope: !649, file: !3, line: 1492, type: !113)
!652 = !DILocalVariable(name: "possible_reclaims", scope: !649, file: !3, line: 1494, type: !131)
!653 = !DILocalVariable(name: "available_reclaims", scope: !649, file: !3, line: 1495, type: !131)
!654 = !DILocalVariable(name: "low_watermark", scope: !649, file: !3, line: 1499, type: !131)
!655 = !DILocalVariable(name: "since_run", scope: !649, file: !3, line: 1500, type: !110)
!656 = !DILocalVariable(name: "myl", scope: !657, file: !3, line: 1537, type: !151)
!657 = distinct !DILexicalBlock(scope: !649, file: !3, line: 1537, column: 13)
!658 = !DICompositeType(tag: DW_TAG_array_type, baseType: !110, size: 8192, elements: !539)
!659 = !DIGlobalVariableExpression(var: !660, expr: !DIExpression())
!660 = distinct !DIGlobalVariable(name: "next_crawl_wait", scope: !607, file: !3, line: 1479, type: !658, isLocal: true, isDefinition: true)
!661 = !DIGlobalVariableExpression(var: !662, expr: !DIExpression())
!662 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1490, type: !343, isLocal: true, isDefinition: true)
!663 = !DIGlobalVariableExpression(var: !664, expr: !DIExpression())
!664 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1525, type: !369, isLocal: true, isDefinition: true)
!665 = !DIGlobalVariableExpression(var: !666, expr: !DIExpression())
!666 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1528, type: !286, isLocal: true, isDefinition: true)
!667 = !DIGlobalVariableExpression(var: !668, expr: !DIExpression())
!668 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1531, type: !286, isLocal: true, isDefinition: true)
!669 = !DIGlobalVariableExpression(var: !670, expr: !DIExpression())
!670 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1534, type: !286, isLocal: true, isDefinition: true)
!671 = !DICompositeType(tag: DW_TAG_array_type, baseType: !672, size: 344064, elements: !539)
!672 = !DIDerivedType(tag: DW_TAG_typedef, name: "itemstats_t", file: !3, line: 53, baseType: !673)
!673 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 31, size: 1344, elements: !674)
!674 = !{!675, !676, !677, !678, !679, !680, !681, !682, !683, !684, !685, !686, !687, !688, !689, !690, !691, !692, !693, !694, !695}
!675 = !DIDerivedType(tag: DW_TAG_member, name: "evicted", scope: !673, file: !3, line: 32, baseType: !131, size: 64)
!676 = !DIDerivedType(tag: DW_TAG_member, name: "evicted_nonzero", scope: !673, file: !3, line: 33, baseType: !131, size: 64, offset: 64)
!677 = !DIDerivedType(tag: DW_TAG_member, name: "reclaimed", scope: !673, file: !3, line: 34, baseType: !131, size: 64, offset: 128)
!678 = !DIDerivedType(tag: DW_TAG_member, name: "outofmemory", scope: !673, file: !3, line: 35, baseType: !131, size: 64, offset: 192)
!679 = !DIDerivedType(tag: DW_TAG_member, name: "tailrepairs", scope: !673, file: !3, line: 36, baseType: !131, size: 64, offset: 256)
!680 = !DIDerivedType(tag: DW_TAG_member, name: "expired_unfetched", scope: !673, file: !3, line: 37, baseType: !131, size: 64, offset: 320)
!681 = !DIDerivedType(tag: DW_TAG_member, name: "evicted_unfetched", scope: !673, file: !3, line: 38, baseType: !131, size: 64, offset: 384)
!682 = !DIDerivedType(tag: DW_TAG_member, name: "evicted_active", scope: !673, file: !3, line: 39, baseType: !131, size: 64, offset: 448)
!683 = !DIDerivedType(tag: DW_TAG_member, name: "crawler_reclaimed", scope: !673, file: !3, line: 40, baseType: !131, size: 64, offset: 512)
!684 = !DIDerivedType(tag: DW_TAG_member, name: "crawler_items_checked", scope: !673, file: !3, line: 41, baseType: !131, size: 64, offset: 576)
!685 = !DIDerivedType(tag: DW_TAG_member, name: "lrutail_reflocked", scope: !673, file: !3, line: 42, baseType: !131, size: 64, offset: 640)
!686 = !DIDerivedType(tag: DW_TAG_member, name: "moves_to_cold", scope: !673, file: !3, line: 43, baseType: !131, size: 64, offset: 704)
!687 = !DIDerivedType(tag: DW_TAG_member, name: "moves_to_warm", scope: !673, file: !3, line: 44, baseType: !131, size: 64, offset: 768)
!688 = !DIDerivedType(tag: DW_TAG_member, name: "moves_within_lru", scope: !673, file: !3, line: 45, baseType: !131, size: 64, offset: 832)
!689 = !DIDerivedType(tag: DW_TAG_member, name: "direct_reclaims", scope: !673, file: !3, line: 46, baseType: !131, size: 64, offset: 896)
!690 = !DIDerivedType(tag: DW_TAG_member, name: "hits_to_hot", scope: !673, file: !3, line: 47, baseType: !131, size: 64, offset: 960)
!691 = !DIDerivedType(tag: DW_TAG_member, name: "hits_to_warm", scope: !673, file: !3, line: 48, baseType: !131, size: 64, offset: 1024)
!692 = !DIDerivedType(tag: DW_TAG_member, name: "hits_to_cold", scope: !673, file: !3, line: 49, baseType: !131, size: 64, offset: 1088)
!693 = !DIDerivedType(tag: DW_TAG_member, name: "hits_to_temp", scope: !673, file: !3, line: 50, baseType: !131, size: 64, offset: 1152)
!694 = !DIDerivedType(tag: DW_TAG_member, name: "mem_requested", scope: !673, file: !3, line: 51, baseType: !131, size: 64, offset: 1216)
!695 = !DIDerivedType(tag: DW_TAG_member, name: "evicted_time", scope: !673, file: !3, line: 52, baseType: !110, size: 32, offset: 1280)
!696 = !{i32 7, !"Dwarf Version", i32 5}
!697 = !{i32 2, !"Debug Info Version", i32 3}
!698 = !{i32 1, !"wchar_size", i32 4}
!699 = !{i32 8, !"PIC Level", i32 2}
!700 = !{i32 7, !"PIE Level", i32 2}
!701 = !{i32 7, !"uwtable", i32 2}
!702 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!703 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!704 = distinct !DISubprogram(name: "item_stats_reset", scope: !3, file: !3, line: 68, type: !705, scopeLine: 68, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !707)
!705 = !DISubroutineType(types: !706)
!706 = !{null}
!707 = !{!708}
!708 = !DILocalVariable(name: "i", scope: !704, file: !3, line: 69, type: !113)
!709 = !DILocation(line: 0, scope: !704)
!710 = !DILocation(line: 70, column: 5, scope: !711)
!711 = distinct !DILexicalBlock(scope: !704, file: !3, line: 70, column: 5)
!712 = !DILocation(line: 71, column: 29, scope: !713)
!713 = distinct !DILexicalBlock(scope: !714, file: !3, line: 70, column: 38)
!714 = distinct !DILexicalBlock(scope: !711, file: !3, line: 70, column: 5)
!715 = !DILocation(line: 71, column: 9, scope: !713)
!716 = !DILocation(line: 72, column: 17, scope: !713)
!717 = !DILocation(line: 72, column: 9, scope: !713)
!718 = !DILocation(line: 73, column: 9, scope: !713)
!719 = !DILocation(line: 70, column: 34, scope: !714)
!720 = !DILocation(line: 70, column: 19, scope: !714)
!721 = distinct !{!721, !710, !722, !723}
!722 = !DILocation(line: 74, column: 5, scope: !711)
!723 = !{!"llvm.loop.mustprogress"}
!724 = !DILocation(line: 75, column: 1, scope: !704)
!725 = !DISubprogram(name: "pthread_mutex_lock", scope: !726, file: !726, line: 794, type: !727, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!726 = !DIFile(filename: "/usr/include/pthread.h", directory: "", checksumkind: CSK_MD5, checksum: "cbcd748b3d3ecaa7356dc2925b45d819")
!727 = !DISubroutineType(types: !728)
!728 = !{!113, !729}
!729 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !159, size: 64)
!730 = !DISubprogram(name: "pthread_mutex_unlock", scope: !726, file: !726, line: 835, type: !727, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!731 = distinct !DISubprogram(name: "do_item_stats_add_crawl", scope: !3, file: !3, line: 78, type: !732, scopeLine: 79, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !736)
!732 = !DISubroutineType(types: !733)
!733 = !{null, !734, !735, !735, !735}
!734 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !113)
!735 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !131)
!736 = !{!737, !738, !739, !740}
!737 = !DILocalVariable(name: "i", arg: 1, scope: !731, file: !3, line: 78, type: !734)
!738 = !DILocalVariable(name: "reclaimed", arg: 2, scope: !731, file: !3, line: 78, type: !735)
!739 = !DILocalVariable(name: "unfetched", arg: 3, scope: !731, file: !3, line: 79, type: !735)
!740 = !DILocalVariable(name: "checked", arg: 4, scope: !731, file: !3, line: 79, type: !735)
!741 = !DILocation(line: 0, scope: !731)
!742 = !DILocation(line: 80, column: 5, scope: !731)
!743 = !DILocation(line: 80, column: 18, scope: !731)
!744 = !DILocation(line: 80, column: 36, scope: !731)
!745 = !{!746, !747, i64 64}
!746 = !{!"", !747, i64 0, !747, i64 8, !747, i64 16, !747, i64 24, !747, i64 32, !747, i64 40, !747, i64 48, !747, i64 56, !747, i64 64, !747, i64 72, !747, i64 80, !747, i64 88, !747, i64 96, !747, i64 104, !747, i64 112, !747, i64 120, !747, i64 128, !747, i64 136, !747, i64 144, !747, i64 152, !750, i64 160}
!747 = !{!"long", !748, i64 0}
!748 = !{!"omnipotent char", !749, i64 0}
!749 = !{!"Simple C/C++ TBAA"}
!750 = !{!"int", !748, i64 0}
!751 = !DILocation(line: 81, column: 18, scope: !731)
!752 = !DILocation(line: 81, column: 36, scope: !731)
!753 = !{!746, !747, i64 40}
!754 = !DILocation(line: 82, column: 18, scope: !731)
!755 = !DILocation(line: 82, column: 40, scope: !731)
!756 = !{!746, !747, i64 72}
!757 = !DILocation(line: 83, column: 1, scope: !731)
!758 = distinct !DISubprogram(name: "get_cas_id", scope: !3, file: !3, line: 109, type: !759, scopeLine: 109, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !761)
!759 = !DISubroutineType(types: !760)
!760 = !{!131}
!761 = !{!762}
!762 = !DILocalVariable(name: "next_id", scope: !758, file: !3, line: 111, type: !131)
!763 = !DILocation(line: 110, column: 5, scope: !758)
!764 = !DILocation(line: 111, column: 24, scope: !758)
!765 = !{!747, !747, i64 0}
!766 = !DILocation(line: 0, scope: !758)
!767 = !DILocation(line: 112, column: 5, scope: !758)
!768 = !DILocation(line: 113, column: 5, scope: !758)
!769 = distinct !DISubprogram(name: "set_cas_id", scope: !3, file: !3, line: 116, type: !770, scopeLine: 116, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !772)
!770 = !DISubroutineType(types: !771)
!771 = !{null, !131}
!772 = !{!773}
!773 = !DILocalVariable(name: "new_cas", arg: 1, scope: !769, file: !3, line: 116, type: !131)
!774 = !DILocation(line: 0, scope: !769)
!775 = !DILocation(line: 117, column: 5, scope: !769)
!776 = !DILocation(line: 118, column: 12, scope: !769)
!777 = !DILocation(line: 119, column: 5, scope: !769)
!778 = !DILocation(line: 120, column: 1, scope: !769)
!779 = distinct !DISubprogram(name: "item_is_flushed", scope: !3, file: !3, line: 122, type: !780, scopeLine: 122, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !782)
!780 = !DISubroutineType(types: !781)
!781 = !{!113, !263}
!782 = !{!783, !784}
!783 = !DILocalVariable(name: "it", arg: 1, scope: !779, file: !3, line: 122, type: !263)
!784 = !DILocalVariable(name: "oldest_live", scope: !779, file: !3, line: 123, type: !110)
!785 = !DILocation(line: 0, scope: !779)
!786 = !DILocation(line: 123, column: 39, scope: !779)
!787 = !{!788, !750, i64 36}
!788 = !{!"settings", !747, i64 0, !750, i64 8, !750, i64 12, !750, i64 16, !789, i64 24, !750, i64 32, !750, i64 36, !750, i64 40, !789, i64 48, !789, i64 56, !750, i64 64, !790, i64 72, !750, i64 80, !750, i64 84, !750, i64 88, !748, i64 92, !750, i64 96, !750, i64 100, !791, i64 104, !750, i64 108, !750, i64 112, !750, i64 116, !750, i64 120, !750, i64 124, !750, i64 128, !791, i64 132, !791, i64 133, !791, i64 134, !791, i64 135, !791, i64 136, !791, i64 137, !750, i64 140, !790, i64 144, !750, i64 152, !750, i64 156, !791, i64 160, !750, i64 164, !791, i64 168, !791, i64 169, !789, i64 176, !750, i64 184, !750, i64 188, !750, i64 192, !750, i64 196, !790, i64 200, !790, i64 208, !750, i64 216, !791, i64 220, !750, i64 224, !750, i64 228, !750, i64 232, !750, i64 236, !750, i64 240, !791, i64 244, !791, i64 245, !791, i64 246, !750, i64 248, !750, i64 252, !750, i64 256, !750, i64 260, !750, i64 264, !750, i64 268, !750, i64 272, !750, i64 276, !750, i64 280, !750, i64 284, !790, i64 288, !790, i64 296, !791, i64 304, !750, i64 308, !750, i64 312, !789, i64 320, !750, i64 328}
!789 = !{!"any pointer", !748, i64 0}
!790 = !{!"double", !748, i64 0}
!791 = !{!"_Bool", !748, i64 0}
!792 = !DILocation(line: 124, column: 13, scope: !793)
!793 = distinct !DILexicalBlock(scope: !779, file: !3, line: 124, column: 9)
!794 = !{!750, !750, i64 0}
!795 = !DILocation(line: 124, column: 18, scope: !793)
!796 = !DILocation(line: 124, column: 33, scope: !793)
!797 = !DILocation(line: 124, column: 51, scope: !793)
!798 = !DILocation(line: 124, column: 48, scope: !793)
!799 = !DILocation(line: 124, column: 9, scope: !779)
!800 = !DILocation(line: 127, column: 5, scope: !779)
!801 = !DILocation(line: 128, column: 1, scope: !779)
!802 = distinct !DISubprogram(name: "do_get_lru_size", scope: !3, file: !3, line: 131, type: !803, scopeLine: 131, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !805)
!803 = !DISubroutineType(types: !804)
!804 = !{!7, !266}
!805 = !{!806}
!806 = !DILocalVariable(name: "id", arg: 1, scope: !802, file: !3, line: 131, type: !266)
!807 = !DILocation(line: 0, scope: !802)
!808 = !DILocation(line: 132, column: 12, scope: !802)
!809 = !DILocation(line: 132, column: 5, scope: !802)
!810 = distinct !DISubprogram(name: "do_item_alloc_pull", scope: !3, file: !3, line: 167, type: !811, scopeLine: 167, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !815)
!811 = !DISubroutineType(types: !812)
!812 = !{!263, !813, !814}
!813 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !148)
!814 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !7)
!815 = !{!816, !817, !818, !819}
!816 = !DILocalVariable(name: "ntotal", arg: 1, scope: !810, file: !3, line: 167, type: !813)
!817 = !DILocalVariable(name: "id", arg: 2, scope: !810, file: !3, line: 167, type: !814)
!818 = !DILocalVariable(name: "it", scope: !810, file: !3, line: 168, type: !263)
!819 = !DILocalVariable(name: "i", scope: !810, file: !3, line: 169, type: !113)
!820 = !DILocation(line: 0, scope: !810)
!821 = !DILocation(line: 176, column: 5, scope: !822)
!822 = distinct !DILexicalBlock(scope: !810, file: !3, line: 176, column: 5)
!823 = !DILocation(line: 178, column: 23, scope: !824)
!824 = distinct !DILexicalBlock(scope: !825, file: !3, line: 178, column: 13)
!825 = distinct !DILexicalBlock(scope: !826, file: !3, line: 176, column: 30)
!826 = distinct !DILexicalBlock(scope: !822, file: !3, line: 176, column: 5)
!827 = !{!788, !791, i64 136}
!828 = !{i8 0, i8 2}
!829 = !{}
!830 = !DILocation(line: 178, column: 13, scope: !825)
!831 = !DILocation(line: 179, column: 13, scope: !832)
!832 = distinct !DILexicalBlock(scope: !824, file: !3, line: 178, column: 38)
!833 = !DILocation(line: 180, column: 9, scope: !832)
!834 = !DILocation(line: 181, column: 14, scope: !825)
!835 = !DILocation(line: 183, column: 16, scope: !836)
!836 = distinct !DILexicalBlock(scope: !825, file: !3, line: 183, column: 13)
!837 = !DILocation(line: 183, column: 13, scope: !825)
!838 = !DILocation(line: 187, column: 17, scope: !839)
!839 = distinct !DILexicalBlock(scope: !840, file: !3, line: 187, column: 17)
!840 = distinct !DILexicalBlock(scope: !836, file: !3, line: 183, column: 25)
!841 = !DILocation(line: 187, column: 73, scope: !839)
!842 = !DILocation(line: 187, column: 17, scope: !840)
!843 = !DILocation(line: 188, column: 30, scope: !844)
!844 = distinct !DILexicalBlock(scope: !845, file: !3, line: 188, column: 21)
!845 = distinct !DILexicalBlock(scope: !839, file: !3, line: 187, column: 79)
!846 = !DILocation(line: 188, column: 21, scope: !845)
!847 = !DILocation(line: 189, column: 21, scope: !848)
!848 = distinct !DILexicalBlock(scope: !844, file: !3, line: 188, column: 45)
!849 = !DILocation(line: 193, column: 13, scope: !845)
!850 = !DILocation(line: 176, column: 26, scope: !826)
!851 = !DILocation(line: 176, column: 19, scope: !826)
!852 = distinct !{!852, !821, !853, !723}
!853 = !DILocation(line: 197, column: 5, scope: !822)
!854 = !DILocation(line: 199, column: 11, scope: !855)
!855 = distinct !DILexicalBlock(scope: !810, file: !3, line: 199, column: 9)
!856 = !DILocation(line: 199, column: 9, scope: !810)
!857 = !DILocation(line: 200, column: 29, scope: !858)
!858 = distinct !DILexicalBlock(scope: !855, file: !3, line: 199, column: 16)
!859 = !DILocation(line: 200, column: 9, scope: !858)
!860 = !DILocation(line: 201, column: 23, scope: !858)
!861 = !DILocation(line: 201, column: 39, scope: !858)
!862 = !{!746, !747, i64 112}
!863 = !DILocation(line: 202, column: 9, scope: !858)
!864 = !DILocation(line: 203, column: 5, scope: !858)
!865 = !DILocation(line: 205, column: 5, scope: !810)
!866 = distinct !DISubprogram(name: "lru_pull_tail", scope: !3, file: !3, line: 1105, type: !867, scopeLine: 1107, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !877)
!867 = !DISubroutineType(types: !868)
!868 = !{!113, !734, !734, !735, !869, !870, !871}
!869 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !122)
!870 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !110)
!871 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !872, size: 64)
!872 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lru_pull_tail_return", file: !873, line: 42, size: 128, elements: !874)
!873 = !DIFile(filename: "./items.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "5548db7354621bc680fd5812e10230ba")
!874 = !{!875, !876}
!875 = !DIDerivedType(tag: DW_TAG_member, name: "it", scope: !872, file: !873, line: 43, baseType: !263, size: 64)
!876 = !DIDerivedType(tag: DW_TAG_member, name: "hv", scope: !872, file: !873, line: 44, baseType: !266, size: 32, offset: 64)
!877 = !{!878, !879, !880, !881, !882, !883, !884, !885, !886, !887, !888, !889, !890, !891, !892, !893, !897}
!878 = !DILocalVariable(name: "orig_id", arg: 1, scope: !866, file: !3, line: 1105, type: !734)
!879 = !DILocalVariable(name: "cur_lru", arg: 2, scope: !866, file: !3, line: 1105, type: !734)
!880 = !DILocalVariable(name: "total_bytes", arg: 3, scope: !866, file: !3, line: 1106, type: !735)
!881 = !DILocalVariable(name: "flags", arg: 4, scope: !866, file: !3, line: 1106, type: !869)
!882 = !DILocalVariable(name: "max_age", arg: 5, scope: !866, file: !3, line: 1106, type: !870)
!883 = !DILocalVariable(name: "ret_it", arg: 6, scope: !866, file: !3, line: 1107, type: !871)
!884 = !DILocalVariable(name: "it", scope: !866, file: !3, line: 1108, type: !263)
!885 = !DILocalVariable(name: "id", scope: !866, file: !3, line: 1109, type: !113)
!886 = !DILocalVariable(name: "removed", scope: !866, file: !3, line: 1110, type: !113)
!887 = !DILocalVariable(name: "tries", scope: !866, file: !3, line: 1114, type: !113)
!888 = !DILocalVariable(name: "search", scope: !866, file: !3, line: 1115, type: !263)
!889 = !DILocalVariable(name: "next_it", scope: !866, file: !3, line: 1116, type: !263)
!890 = !DILocalVariable(name: "hold_lock", scope: !866, file: !3, line: 1117, type: !94)
!891 = !DILocalVariable(name: "move_to_lru", scope: !866, file: !3, line: 1118, type: !7)
!892 = !DILocalVariable(name: "limit", scope: !866, file: !3, line: 1119, type: !131)
!893 = !DILocalVariable(name: "hv", scope: !894, file: !3, line: 1137, type: !266)
!894 = distinct !DILexicalBlock(scope: !895, file: !3, line: 1125, column: 66)
!895 = distinct !DILexicalBlock(scope: !896, file: !3, line: 1125, column: 5)
!896 = distinct !DILexicalBlock(scope: !866, file: !3, line: 1125, column: 5)
!897 = !DILocalVariable(name: "myl", scope: !898, file: !3, line: 1236, type: !151)
!898 = distinct !DILexicalBlock(scope: !899, file: !3, line: 1236, column: 21)
!899 = distinct !DILexicalBlock(scope: !900, file: !3, line: 1221, column: 45)
!900 = distinct !DILexicalBlock(scope: !901, file: !3, line: 1221, column: 21)
!901 = distinct !DILexicalBlock(scope: !894, file: !3, line: 1183, column: 26)
!902 = !DILocation(line: 0, scope: !866)
!903 = !DILocation(line: 1111, column: 12, scope: !904)
!904 = distinct !DILexicalBlock(scope: !866, file: !3, line: 1111, column: 9)
!905 = !DILocation(line: 1111, column: 9, scope: !866)
!906 = !DILocation(line: 1121, column: 8, scope: !866)
!907 = !DILocation(line: 1122, column: 25, scope: !866)
!908 = !DILocation(line: 1122, column: 5, scope: !866)
!909 = !DILocation(line: 1123, column: 14, scope: !866)
!910 = !{!789, !789, i64 0}
!911 = !DILocation(line: 1125, column: 22, scope: !895)
!912 = !DILocation(line: 1127, column: 27, scope: !894)
!913 = !DILocation(line: 1128, column: 21, scope: !914)
!914 = distinct !DILexicalBlock(scope: !894, file: !3, line: 1128, column: 13)
!915 = !DILocation(line: 1128, column: 28, scope: !914)
!916 = !DILocation(line: 0, scope: !894)
!917 = !{!748, !748, i64 0}
!918 = !DILocation(line: 1128, column: 33, scope: !914)
!919 = !DILocation(line: 1128, column: 65, scope: !914)
!920 = !{!921, !921, i64 0}
!921 = !{!"short", !748, i64 0}
!922 = !DILocation(line: 1128, column: 74, scope: !914)
!923 = !DILocation(line: 1128, column: 13, scope: !894)
!924 = !DILocation(line: 1130, column: 17, scope: !925)
!925 = distinct !DILexicalBlock(scope: !914, file: !3, line: 1128, column: 80)
!926 = !DILocation(line: 1131, column: 17, scope: !927)
!927 = distinct !DILexicalBlock(scope: !928, file: !3, line: 1130, column: 48)
!928 = distinct !DILexicalBlock(scope: !925, file: !3, line: 1130, column: 17)
!929 = !DILocation(line: 1132, column: 17, scope: !927)
!930 = !DILocation(line: 1134, column: 18, scope: !925)
!931 = !DILocation(line: 1135, column: 13, scope: !925)
!932 = !DILocation(line: 1137, column: 54, scope: !894)
!933 = !DILocation(line: 1137, column: 23, scope: !894)
!934 = !DILocation(line: 1137, column: 28, scope: !894)
!935 = !DILocation(line: 1137, column: 46, scope: !894)
!936 = !DILocation(line: 1140, column: 26, scope: !937)
!937 = distinct !DILexicalBlock(scope: !894, file: !3, line: 1140, column: 13)
!938 = !DILocation(line: 1140, column: 44, scope: !937)
!939 = !DILocation(line: 1140, column: 13, scope: !894)
!940 = !DILocation(line: 1143, column: 13, scope: !941)
!941 = distinct !DILexicalBlock(scope: !894, file: !3, line: 1143, column: 13)
!942 = !DILocation(line: 1143, column: 35, scope: !941)
!943 = !DILocation(line: 1143, column: 13, scope: !894)
!944 = !DILocation(line: 1146, column: 44, scope: !945)
!945 = distinct !DILexicalBlock(scope: !941, file: !3, line: 1143, column: 41)
!946 = !{!746, !747, i64 80}
!947 = !DILocation(line: 1149, column: 26, scope: !948)
!948 = distinct !DILexicalBlock(scope: !945, file: !3, line: 1149, column: 17)
!949 = !{!788, !750, i64 164}
!950 = !DILocation(line: 1149, column: 17, scope: !948)
!951 = !DILocation(line: 1149, column: 43, scope: !948)
!952 = !DILocation(line: 1150, column: 29, scope: !948)
!953 = !DILocation(line: 1150, column: 34, scope: !948)
!954 = !DILocation(line: 1150, column: 64, scope: !948)
!955 = !DILocation(line: 1150, column: 62, scope: !948)
!956 = !DILocation(line: 1149, column: 17, scope: !945)
!957 = !DILocation(line: 1151, column: 42, scope: !958)
!958 = distinct !DILexicalBlock(scope: !948, file: !3, line: 1150, column: 78)
!959 = !{!746, !747, i64 32}
!960 = !DILocation(line: 1152, column: 34, scope: !958)
!961 = !DILocation(line: 1154, column: 17, scope: !962)
!962 = distinct !DILexicalBlock(scope: !958, file: !3, line: 1154, column: 17)
!963 = !DILocation(line: 1155, column: 17, scope: !958)
!964 = !DILocation(line: 1156, column: 17, scope: !958)
!965 = !DILocation(line: 1157, column: 17, scope: !958)
!966 = !DILocation(line: 1162, column: 22, scope: !967)
!967 = distinct !DILexicalBlock(scope: !894, file: !3, line: 1162, column: 13)
!968 = !DILocation(line: 1162, column: 30, scope: !967)
!969 = !DILocation(line: 1162, column: 35, scope: !967)
!970 = !DILocation(line: 1162, column: 56, scope: !967)
!971 = !DILocation(line: 1162, column: 54, scope: !967)
!972 = !DILocation(line: 1163, column: 13, scope: !967)
!973 = !DILocation(line: 0, scope: !779, inlinedAt: !974)
!974 = distinct !DILocation(line: 1163, column: 16, scope: !967)
!975 = !DILocation(line: 123, column: 39, scope: !779, inlinedAt: !974)
!976 = !DILocation(line: 124, column: 13, scope: !793, inlinedAt: !974)
!977 = !DILocation(line: 124, column: 18, scope: !793, inlinedAt: !974)
!978 = !DILocation(line: 124, column: 33, scope: !793, inlinedAt: !974)
!979 = !DILocation(line: 124, column: 51, scope: !793, inlinedAt: !974)
!980 = !DILocation(line: 124, column: 48, scope: !793, inlinedAt: !974)
!981 = !DILocation(line: 124, column: 9, scope: !779, inlinedAt: !974)
!982 = !DILocation(line: 1164, column: 36, scope: !983)
!983 = distinct !DILexicalBlock(scope: !967, file: !3, line: 1163, column: 41)
!984 = !{!746, !747, i64 16}
!985 = !DILocation(line: 1165, column: 26, scope: !986)
!986 = distinct !DILexicalBlock(scope: !983, file: !3, line: 1165, column: 17)
!987 = !DILocation(line: 1165, column: 35, scope: !986)
!988 = !DILocation(line: 1165, column: 51, scope: !986)
!989 = !DILocation(line: 1165, column: 17, scope: !983)
!990 = !DILocation(line: 1166, column: 48, scope: !991)
!991 = distinct !DILexicalBlock(scope: !986, file: !3, line: 1165, column: 57)
!992 = !DILocation(line: 1167, column: 13, scope: !991)
!993 = !DILocation(line: 1169, column: 13, scope: !983)
!994 = !DILocation(line: 1170, column: 13, scope: !995)
!995 = distinct !DILexicalBlock(scope: !983, file: !3, line: 1170, column: 13)
!996 = !DILocalVariable(name: "it", arg: 1, scope: !997, file: !3, line: 544, type: !263)
!997 = distinct !DISubprogram(name: "do_item_remove", scope: !3, file: !3, line: 544, type: !998, scopeLine: 544, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1000)
!998 = !DISubroutineType(types: !999)
!999 = !{null, !263}
!1000 = !{!996}
!1001 = !DILocation(line: 0, scope: !997, inlinedAt: !1002)
!1002 = distinct !DILocation(line: 1172, column: 13, scope: !983)
!1003 = !DILocation(line: 549, column: 9, scope: !1004, inlinedAt: !1002)
!1004 = distinct !DILexicalBlock(scope: !997, file: !3, line: 549, column: 9)
!1005 = !DILocation(line: 549, column: 27, scope: !1004, inlinedAt: !1002)
!1006 = !DILocation(line: 549, column: 9, scope: !997, inlinedAt: !1002)
!1007 = !DILocalVariable(name: "it", arg: 1, scope: !1008, file: !3, line: 355, type: !263)
!1008 = distinct !DISubprogram(name: "item_free", scope: !3, file: !3, line: 355, type: !998, scopeLine: 355, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1009)
!1009 = !{!1007, !1010, !1011}
!1010 = !DILocalVariable(name: "ntotal", scope: !1008, file: !3, line: 356, type: !148)
!1011 = !DILocalVariable(name: "clsid", scope: !1008, file: !3, line: 357, type: !7)
!1012 = !DILocation(line: 0, scope: !1008, inlinedAt: !1013)
!1013 = distinct !DILocation(line: 550, column: 9, scope: !1014, inlinedAt: !1002)
!1014 = distinct !DILexicalBlock(scope: !1004, file: !3, line: 549, column: 33)
!1015 = !DILocation(line: 356, column: 21, scope: !1008, inlinedAt: !1013)
!1016 = !DILocation(line: 364, column: 13, scope: !1008, inlinedAt: !1013)
!1017 = !DILocation(line: 366, column: 5, scope: !1008, inlinedAt: !1013)
!1018 = !DILocation(line: 551, column: 5, scope: !1014, inlinedAt: !1002)
!1019 = !DILocation(line: 1173, column: 13, scope: !983)
!1020 = !DILocation(line: 1174, column: 20, scope: !983)
!1021 = !DILocation(line: 1177, column: 13, scope: !983)
!1022 = !DILocation(line: 1183, column: 9, scope: !894)
!1023 = !DILocation(line: 1185, column: 48, scope: !901)
!1024 = !{!788, !750, i64 192}
!1025 = !DILocation(line: 1185, column: 39, scope: !901)
!1026 = !DILocation(line: 1185, column: 37, scope: !901)
!1027 = !DILocation(line: 1185, column: 60, scope: !901)
!1028 = !DILocation(line: 1185, column: 17, scope: !901)
!1029 = !DILocation(line: 1187, column: 27, scope: !1030)
!1030 = distinct !DILexicalBlock(scope: !901, file: !3, line: 1187, column: 21)
!1031 = !DILocation(line: 1187, column: 21, scope: !901)
!1032 = !DILocation(line: 1188, column: 52, scope: !1030)
!1033 = !{!788, !750, i64 196}
!1034 = !DILocation(line: 1188, column: 43, scope: !1030)
!1035 = !DILocation(line: 1188, column: 41, scope: !1030)
!1036 = !DILocation(line: 1188, column: 65, scope: !1030)
!1037 = !DILocation(line: 1188, column: 21, scope: !1030)
!1038 = !DILocation(line: 1190, column: 30, scope: !1039)
!1039 = distinct !DILexicalBlock(scope: !901, file: !3, line: 1190, column: 21)
!1040 = !DILocation(line: 1190, column: 39, scope: !1039)
!1041 = !DILocation(line: 1190, column: 54, scope: !1039)
!1042 = !DILocation(line: 1190, column: 21, scope: !901)
!1043 = !DILocation(line: 1191, column: 38, scope: !1044)
!1044 = distinct !DILexicalBlock(scope: !1039, file: !3, line: 1190, column: 60)
!1045 = !DILocation(line: 1192, column: 28, scope: !1044)
!1046 = !DILocation(line: 1193, column: 25, scope: !1044)
!1047 = !DILocation(line: 1194, column: 55, scope: !1048)
!1048 = distinct !DILexicalBlock(scope: !1049, file: !3, line: 1193, column: 46)
!1049 = distinct !DILexicalBlock(scope: !1044, file: !3, line: 1193, column: 25)
!1050 = !{!746, !747, i64 104}
!1051 = !DILocation(line: 1195, column: 25, scope: !1048)
!1052 = !DILocalVariable(name: "it", arg: 1, scope: !1053, file: !3, line: 413, type: !263)
!1053 = distinct !DISubprogram(name: "do_item_link_q", scope: !3, file: !3, line: 413, type: !998, scopeLine: 413, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1054)
!1054 = !{!1052, !1055, !1057}
!1055 = !DILocalVariable(name: "head", scope: !1053, file: !3, line: 414, type: !1056)
!1056 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !263, size: 64)
!1057 = !DILocalVariable(name: "tail", scope: !1053, file: !3, line: 414, type: !1056)
!1058 = !DILocation(line: 0, scope: !1053, inlinedAt: !1059)
!1059 = distinct !DILocation(line: 1196, column: 25, scope: !1048)
!1060 = !DILocation(line: 417, column: 23, scope: !1053, inlinedAt: !1059)
!1061 = !DILocation(line: 417, column: 13, scope: !1053, inlinedAt: !1059)
!1062 = !DILocation(line: 418, column: 13, scope: !1053, inlinedAt: !1059)
!1063 = !DILocation(line: 421, column: 14, scope: !1053, inlinedAt: !1059)
!1064 = !DILocation(line: 422, column: 16, scope: !1053, inlinedAt: !1059)
!1065 = !DILocation(line: 422, column: 14, scope: !1053, inlinedAt: !1059)
!1066 = !DILocation(line: 423, column: 9, scope: !1067, inlinedAt: !1059)
!1067 = distinct !DILexicalBlock(scope: !1053, file: !3, line: 423, column: 9)
!1068 = !DILocation(line: 423, column: 9, scope: !1053, inlinedAt: !1059)
!1069 = !DILocation(line: 423, column: 29, scope: !1067, inlinedAt: !1059)
!1070 = !DILocation(line: 423, column: 34, scope: !1067, inlinedAt: !1059)
!1071 = !DILocation(line: 423, column: 19, scope: !1067, inlinedAt: !1059)
!1072 = !DILocation(line: 424, column: 11, scope: !1053, inlinedAt: !1059)
!1073 = !DILocation(line: 425, column: 9, scope: !1074, inlinedAt: !1059)
!1074 = distinct !DILexicalBlock(scope: !1053, file: !3, line: 425, column: 9)
!1075 = !DILocation(line: 425, column: 15, scope: !1074, inlinedAt: !1059)
!1076 = !DILocation(line: 425, column: 9, scope: !1053, inlinedAt: !1059)
!1077 = !DILocation(line: 425, column: 27, scope: !1074, inlinedAt: !1059)
!1078 = !DILocation(line: 425, column: 21, scope: !1074, inlinedAt: !1059)
!1079 = !DILocation(line: 426, column: 15, scope: !1053, inlinedAt: !1059)
!1080 = !DILocation(line: 426, column: 5, scope: !1053, inlinedAt: !1059)
!1081 = !DILocation(line: 426, column: 27, scope: !1053, inlinedAt: !1059)
!1082 = !DILocation(line: 428, column: 13, scope: !1083, inlinedAt: !1059)
!1083 = distinct !DILexicalBlock(scope: !1053, file: !3, line: 428, column: 9)
!1084 = !DILocation(line: 428, column: 9, scope: !1083, inlinedAt: !1059)
!1085 = !DILocation(line: 428, column: 22, scope: !1083, inlinedAt: !1059)
!1086 = !DILocation(line: 0, scope: !1083, inlinedAt: !1059)
!1087 = !DILocation(line: 428, column: 9, scope: !1053, inlinedAt: !1059)
!1088 = !DILocation(line: 429, column: 42, scope: !1089, inlinedAt: !1059)
!1089 = distinct !DILexicalBlock(scope: !1083, file: !3, line: 428, column: 34)
!1090 = !DILocation(line: 429, column: 9, scope: !1089, inlinedAt: !1059)
!1091 = !DILocation(line: 429, column: 38, scope: !1089, inlinedAt: !1059)
!1092 = !DILocation(line: 429, column: 58, scope: !1089, inlinedAt: !1059)
!1093 = !DILocation(line: 429, column: 72, scope: !1089, inlinedAt: !1059)
!1094 = !DILocation(line: 430, column: 5, scope: !1089, inlinedAt: !1059)
!1095 = !DILocation(line: 431, column: 41, scope: !1096, inlinedAt: !1059)
!1096 = distinct !DILexicalBlock(scope: !1083, file: !3, line: 430, column: 12)
!1097 = !DILocation(line: 431, column: 9, scope: !1096, inlinedAt: !1059)
!1098 = !DILocation(line: 431, column: 38, scope: !1096, inlinedAt: !1059)
!1099 = !DILocation(line: 0, scope: !997, inlinedAt: !1100)
!1100 = distinct !DILocation(line: 1197, column: 25, scope: !1048)
!1101 = !DILocation(line: 549, column: 9, scope: !1004, inlinedAt: !1100)
!1102 = !DILocation(line: 549, column: 27, scope: !1004, inlinedAt: !1100)
!1103 = !DILocation(line: 549, column: 9, scope: !997, inlinedAt: !1100)
!1104 = !DILocation(line: 0, scope: !1008, inlinedAt: !1105)
!1105 = distinct !DILocation(line: 550, column: 9, scope: !1014, inlinedAt: !1100)
!1106 = !DILocation(line: 356, column: 21, scope: !1008, inlinedAt: !1105)
!1107 = !DILocation(line: 364, column: 13, scope: !1008, inlinedAt: !1105)
!1108 = !DILocation(line: 366, column: 5, scope: !1008, inlinedAt: !1105)
!1109 = !DILocation(line: 551, column: 5, scope: !1014, inlinedAt: !1100)
!1110 = !DILocation(line: 1198, column: 25, scope: !1048)
!1111 = !DILocation(line: 1199, column: 21, scope: !1048)
!1112 = !DILocation(line: 1201, column: 39, scope: !1113)
!1113 = distinct !DILexicalBlock(scope: !1049, file: !3, line: 1199, column: 28)
!1114 = !DILocation(line: 1201, column: 52, scope: !1113)
!1115 = !{!746, !747, i64 96}
!1116 = !DILocation(line: 1203, column: 25, scope: !1113)
!1117 = !DILocation(line: 1206, column: 28, scope: !1118)
!1118 = distinct !DILexicalBlock(scope: !1039, file: !3, line: 1206, column: 28)
!1119 = !DILocation(line: 1206, column: 44, scope: !1118)
!1120 = !DILocation(line: 1206, column: 52, scope: !1118)
!1121 = !DILocation(line: 1207, column: 28, scope: !1118)
!1122 = !DILocation(line: 1207, column: 41, scope: !1118)
!1123 = !DILocation(line: 1207, column: 56, scope: !1118)
!1124 = !DILocation(line: 1206, column: 28, scope: !1039)
!1125 = !DILocation(line: 1208, column: 35, scope: !1126)
!1126 = distinct !DILexicalBlock(scope: !1118, file: !3, line: 1207, column: 67)
!1127 = !DILocation(line: 1208, column: 48, scope: !1126)
!1128 = !{!746, !747, i64 88}
!1129 = !DILocation(line: 1210, column: 21, scope: !1126)
!1130 = !DILocation(line: 1212, column: 28, scope: !1126)
!1131 = !DILocation(line: 1213, column: 21, scope: !1126)
!1132 = !DILocation(line: 1221, column: 21, scope: !900)
!1133 = !DILocation(line: 1221, column: 27, scope: !900)
!1134 = !DILocation(line: 1221, column: 21, scope: !901)
!1135 = !DILocation(line: 1222, column: 34, scope: !1136)
!1136 = distinct !DILexicalBlock(scope: !899, file: !3, line: 1222, column: 25)
!1137 = !{!788, !750, i64 40}
!1138 = !DILocation(line: 1222, column: 48, scope: !1136)
!1139 = !DILocation(line: 1222, column: 25, scope: !899)
!1140 = !DILocation(line: 1226, column: 42, scope: !899)
!1141 = !{!746, !747, i64 0}
!1142 = !DILocation(line: 1227, column: 50, scope: !899)
!1143 = !DILocation(line: 1227, column: 63, scope: !899)
!1144 = !DILocation(line: 1227, column: 35, scope: !899)
!1145 = !DILocation(line: 1227, column: 48, scope: !899)
!1146 = !{!746, !750, i64 160}
!1147 = !DILocation(line: 1228, column: 33, scope: !1148)
!1148 = distinct !DILexicalBlock(scope: !899, file: !3, line: 1228, column: 25)
!1149 = !DILocation(line: 1228, column: 41, scope: !1148)
!1150 = !DILocation(line: 1228, column: 25, scope: !899)
!1151 = !DILocation(line: 1229, column: 39, scope: !1148)
!1152 = !DILocation(line: 1229, column: 54, scope: !1148)
!1153 = !{!746, !747, i64 8}
!1154 = !DILocation(line: 1229, column: 25, scope: !1148)
!1155 = !DILocation(line: 1230, column: 34, scope: !1156)
!1156 = distinct !DILexicalBlock(scope: !899, file: !3, line: 1230, column: 25)
!1157 = !DILocation(line: 1230, column: 43, scope: !1156)
!1158 = !DILocation(line: 1230, column: 59, scope: !1156)
!1159 = !DILocation(line: 1230, column: 25, scope: !899)
!1160 = !DILocation(line: 1231, column: 39, scope: !1161)
!1161 = distinct !DILexicalBlock(scope: !1156, file: !3, line: 1230, column: 65)
!1162 = !DILocation(line: 1231, column: 56, scope: !1161)
!1163 = !{!746, !747, i64 48}
!1164 = !DILocation(line: 1232, column: 21, scope: !1161)
!1165 = !DILocation(line: 1233, column: 43, scope: !1166)
!1166 = distinct !DILexicalBlock(scope: !899, file: !3, line: 1233, column: 25)
!1167 = !DILocation(line: 1233, column: 25, scope: !899)
!1168 = !DILocation(line: 1234, column: 39, scope: !1169)
!1169 = distinct !DILexicalBlock(scope: !1166, file: !3, line: 1233, column: 59)
!1170 = !DILocation(line: 1234, column: 53, scope: !1169)
!1171 = !{!746, !747, i64 56}
!1172 = !DILocation(line: 1235, column: 21, scope: !1169)
!1173 = !DILocation(line: 0, scope: !898)
!1174 = !DILocation(line: 1236, column: 21, scope: !1175)
!1175 = distinct !DILexicalBlock(scope: !898, file: !3, line: 1236, column: 21)
!1176 = !DILocation(line: 1236, column: 21, scope: !1177)
!1177 = distinct !DILexicalBlock(scope: !898, file: !3, line: 1236, column: 21)
!1178 = !{!1179, !921, i64 84}
!1179 = !{!"_logger", !789, i64 0, !789, i64 8, !748, i64 16, !747, i64 56, !747, i64 64, !747, i64 72, !921, i64 80, !921, i64 82, !921, i64 84, !789, i64 88, !789, i64 96}
!1180 = !DILocation(line: 1236, column: 21, scope: !898)
!1181 = !DILocation(line: 1237, column: 21, scope: !1182)
!1182 = distinct !DILexicalBlock(scope: !899, file: !3, line: 1237, column: 21)
!1183 = !DILocation(line: 1238, column: 21, scope: !899)
!1184 = !DILocation(line: 1239, column: 28, scope: !899)
!1185 = !DILocation(line: 1240, column: 34, scope: !1186)
!1186 = distinct !DILexicalBlock(scope: !899, file: !3, line: 1240, column: 25)
!1187 = !{!788, !750, i64 140}
!1188 = !DILocation(line: 1240, column: 48, scope: !1186)
!1189 = !DILocation(line: 1240, column: 25, scope: !899)
!1190 = !DILocation(line: 1241, column: 25, scope: !1191)
!1191 = distinct !DILexicalBlock(scope: !1186, file: !3, line: 1240, column: 54)
!1192 = !DILocation(line: 1242, column: 21, scope: !1191)
!1193 = !DILocation(line: 1243, column: 34, scope: !1194)
!1194 = distinct !DILexicalBlock(scope: !900, file: !3, line: 1243, column: 28)
!1195 = !DILocation(line: 1243, column: 28, scope: !900)
!1196 = !DILocation(line: 1245, column: 32, scope: !1197)
!1197 = distinct !DILexicalBlock(scope: !1194, file: !3, line: 1243, column: 58)
!1198 = !{!1199, !789, i64 0}
!1199 = !{!"lru_pull_tail_return", !789, i64 0, !750, i64 8}
!1200 = !DILocation(line: 1246, column: 29, scope: !1197)
!1201 = !DILocation(line: 1246, column: 32, scope: !1197)
!1202 = !{!1199, !750, i64 8}
!1203 = !DILocation(line: 1247, column: 17, scope: !1197)
!1204 = !DILocation(line: 1247, column: 37, scope: !1205)
!1205 = distinct !DILexicalBlock(scope: !1194, file: !3, line: 1247, column: 28)
!1206 = !DILocation(line: 1247, column: 46, scope: !1205)
!1207 = !DILocation(line: 1247, column: 61, scope: !1205)
!1208 = !DILocation(line: 1248, column: 25, scope: !1205)
!1209 = !DILocation(line: 1248, column: 37, scope: !1205)
!1210 = !DILocation(line: 1247, column: 28, scope: !1194)
!1211 = !DILocation(line: 1249, column: 35, scope: !1212)
!1212 = distinct !DILexicalBlock(scope: !1205, file: !3, line: 1248, column: 52)
!1213 = !DILocation(line: 1249, column: 48, scope: !1212)
!1214 = !DILocation(line: 1250, column: 38, scope: !1212)
!1215 = !DILocation(line: 1252, column: 21, scope: !1212)
!1216 = !DILocation(line: 1253, column: 28, scope: !1212)
!1217 = !DILocation(line: 1254, column: 17, scope: !1212)
!1218 = !DILocation(line: 1264, column: 5, scope: !866)
!1219 = !DILocation(line: 1267, column: 13, scope: !1220)
!1220 = distinct !DILexicalBlock(scope: !1221, file: !3, line: 1266, column: 21)
!1221 = distinct !DILexicalBlock(scope: !866, file: !3, line: 1266, column: 9)
!1222 = !DILocation(line: 1110, column: 9, scope: !866)
!1223 = !DILocation(line: 1119, column: 14, scope: !866)
!1224 = !DILocation(line: 1125, column: 46, scope: !895)
!1225 = !DILocation(line: 1125, column: 18, scope: !895)
!1226 = distinct !{!1226, !1227, !1228, !723}
!1227 = !DILocation(line: 1125, column: 5, scope: !896)
!1228 = !DILocation(line: 1262, column: 5, scope: !896)
!1229 = !DILocation(line: 1266, column: 9, scope: !866)
!1230 = !DILocation(line: 1268, column: 31, scope: !1231)
!1231 = distinct !DILexicalBlock(scope: !1232, file: !3, line: 1267, column: 26)
!1232 = distinct !DILexicalBlock(scope: !1220, file: !3, line: 1267, column: 13)
!1233 = !DILocation(line: 1269, column: 29, scope: !1231)
!1234 = !DILocation(line: 1270, column: 13, scope: !1231)
!1235 = !DILocation(line: 1271, column: 9, scope: !1231)
!1236 = !DILocation(line: 1272, column: 20, scope: !1237)
!1237 = distinct !DILexicalBlock(scope: !1220, file: !3, line: 1272, column: 13)
!1238 = !DILocation(line: 1272, column: 44, scope: !1237)
!1239 = !DILocation(line: 1272, column: 13, scope: !1220)
!1240 = !DILocation(line: 0, scope: !997, inlinedAt: !1241)
!1241 = distinct !DILocation(line: 1273, column: 13, scope: !1242)
!1242 = distinct !DILexicalBlock(scope: !1237, file: !3, line: 1272, column: 50)
!1243 = !DILocation(line: 549, column: 9, scope: !1004, inlinedAt: !1241)
!1244 = !DILocation(line: 549, column: 27, scope: !1004, inlinedAt: !1241)
!1245 = !DILocation(line: 549, column: 9, scope: !997, inlinedAt: !1241)
!1246 = !DILocation(line: 0, scope: !1008, inlinedAt: !1247)
!1247 = distinct !DILocation(line: 550, column: 9, scope: !1014, inlinedAt: !1241)
!1248 = !DILocation(line: 356, column: 21, scope: !1008, inlinedAt: !1247)
!1249 = !DILocation(line: 364, column: 13, scope: !1008, inlinedAt: !1247)
!1250 = !DILocation(line: 366, column: 5, scope: !1008, inlinedAt: !1247)
!1251 = !DILocation(line: 551, column: 5, scope: !1014, inlinedAt: !1241)
!1252 = !DILocation(line: 1274, column: 13, scope: !1242)
!1253 = !DILocation(line: 1275, column: 9, scope: !1242)
!1254 = !DILocation(line: 1279, column: 1, scope: !866)
!1255 = !DISubprogram(name: "slabs_alloc", scope: !80, file: !80, line: 26, type: !1256, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1256 = !DISubroutineType(types: !1257)
!1257 = !{!94, !813, !7, !7}
!1258 = distinct !DISubprogram(name: "do_item_alloc_chunk", scope: !3, file: !3, line: 213, type: !1259, scopeLine: 213, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1261)
!1259 = !DISubroutineType(types: !1260)
!1260 = !{!95, !95, !813}
!1261 = !{!1262, !1263, !1264, !1265, !1266}
!1262 = !DILocalVariable(name: "ch", arg: 1, scope: !1258, file: !3, line: 213, type: !95)
!1263 = !DILocalVariable(name: "bytes_remain", arg: 2, scope: !1258, file: !3, line: 213, type: !813)
!1264 = !DILocalVariable(name: "size", scope: !1258, file: !3, line: 215, type: !148)
!1265 = !DILocalVariable(name: "id", scope: !1258, file: !3, line: 218, type: !7)
!1266 = !DILocalVariable(name: "nch", scope: !1258, file: !3, line: 220, type: !95)
!1267 = !DILocation(line: 0, scope: !1258)
!1268 = !DILocation(line: 215, column: 32, scope: !1258)
!1269 = !DILocation(line: 216, column: 25, scope: !1270)
!1270 = distinct !DILexicalBlock(scope: !1258, file: !3, line: 216, column: 9)
!1271 = !{!788, !750, i64 120}
!1272 = !DILocation(line: 216, column: 16, scope: !1270)
!1273 = !DILocation(line: 216, column: 9, scope: !1258)
!1274 = !DILocation(line: 218, column: 23, scope: !1258)
!1275 = !DILocation(line: 220, column: 38, scope: !1258)
!1276 = !DILocation(line: 221, column: 13, scope: !1277)
!1277 = distinct !DILexicalBlock(scope: !1258, file: !3, line: 221, column: 9)
!1278 = !DILocation(line: 221, column: 9, scope: !1258)
!1279 = !DILocation(line: 227, column: 30, scope: !1280)
!1280 = distinct !DILexicalBlock(scope: !1281, file: !3, line: 227, column: 13)
!1281 = distinct !DILexicalBlock(scope: !1277, file: !3, line: 221, column: 22)
!1282 = !DILocation(line: 227, column: 21, scope: !1280)
!1283 = !DILocation(line: 227, column: 18, scope: !1280)
!1284 = !DILocation(line: 227, column: 13, scope: !1281)
!1285 = !DILocation(line: 231, column: 18, scope: !1286)
!1286 = distinct !DILexicalBlock(scope: !1280, file: !3, line: 229, column: 16)
!1287 = !DILocation(line: 232, column: 34, scope: !1286)
!1288 = !DILocation(line: 234, column: 21, scope: !1289)
!1289 = distinct !DILexicalBlock(scope: !1286, file: !3, line: 234, column: 17)
!1290 = !DILocation(line: 234, column: 17, scope: !1286)
!1291 = !DILocation(line: 241, column: 5, scope: !1258)
!1292 = !DILocation(line: 242, column: 21, scope: !1258)
!1293 = !DILocation(line: 242, column: 10, scope: !1258)
!1294 = !DILocation(line: 242, column: 15, scope: !1258)
!1295 = !DILocation(line: 243, column: 14, scope: !1258)
!1296 = !DILocation(line: 244, column: 10, scope: !1258)
!1297 = !DILocation(line: 244, column: 15, scope: !1258)
!1298 = !DILocation(line: 245, column: 15, scope: !1258)
!1299 = !DILocation(line: 246, column: 10, scope: !1258)
!1300 = !DILocation(line: 246, column: 15, scope: !1258)
!1301 = !DILocation(line: 247, column: 24, scope: !1258)
!1302 = !DILocation(line: 247, column: 10, scope: !1258)
!1303 = !DILocation(line: 247, column: 22, scope: !1258)
!1304 = !DILocation(line: 248, column: 17, scope: !1258)
!1305 = !DILocation(line: 248, column: 10, scope: !1258)
!1306 = !DILocation(line: 248, column: 15, scope: !1258)
!1307 = !DILocation(line: 249, column: 10, scope: !1258)
!1308 = !DILocation(line: 249, column: 19, scope: !1258)
!1309 = !DILocation(line: 250, column: 5, scope: !1258)
!1310 = !DILocation(line: 251, column: 5, scope: !1258)
!1311 = !DILocation(line: 252, column: 1, scope: !1258)
!1312 = !DISubprogram(name: "slabs_clsid", scope: !80, file: !80, line: 21, type: !1313, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1313 = !DISubroutineType(types: !1314)
!1314 = !{!7, !813}
!1315 = !DISubprogram(name: "slabs_mlock", scope: !80, file: !80, line: 49, type: !705, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1316 = !DISubprogram(name: "slabs_munlock", scope: !80, file: !80, line: 50, type: !705, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1317 = distinct !DISubprogram(name: "do_item_alloc", scope: !3, file: !3, line: 254, type: !1318, scopeLine: 255, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1324)
!1318 = !DISubroutineType(types: !1319)
!1319 = !{!263, !1320, !813, !1322, !870, !734}
!1320 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1321, size: 64)
!1321 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !135)
!1322 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !1323)
!1323 = !DIDerivedType(tag: DW_TAG_typedef, name: "client_flags_t", file: !6, line: 99, baseType: !266)
!1324 = !{!1325, !1326, !1327, !1328, !1329, !1330, !1331, !1332, !1333, !1334, !1335, !1336, !1339}
!1325 = !DILocalVariable(name: "key", arg: 1, scope: !1317, file: !3, line: 254, type: !1320)
!1326 = !DILocalVariable(name: "nkey", arg: 2, scope: !1317, file: !3, line: 254, type: !813)
!1327 = !DILocalVariable(name: "flags", arg: 3, scope: !1317, file: !3, line: 254, type: !1322)
!1328 = !DILocalVariable(name: "exptime", arg: 4, scope: !1317, file: !3, line: 255, type: !870)
!1329 = !DILocalVariable(name: "nbytes", arg: 5, scope: !1317, file: !3, line: 255, type: !734)
!1330 = !DILocalVariable(name: "nsuffix", scope: !1317, file: !3, line: 256, type: !122)
!1331 = !DILocalVariable(name: "it", scope: !1317, file: !3, line: 257, type: !263)
!1332 = !DILocalVariable(name: "suffix", scope: !1317, file: !3, line: 258, type: !184)
!1333 = !DILocalVariable(name: "ntotal", scope: !1317, file: !3, line: 263, type: !148)
!1334 = !DILocalVariable(name: "id", scope: !1317, file: !3, line: 268, type: !7)
!1335 = !DILocalVariable(name: "hdr_id", scope: !1317, file: !3, line: 269, type: !7)
!1336 = !DILocalVariable(name: "htotal", scope: !1337, file: !3, line: 281, type: !113)
!1337 = distinct !DILexicalBlock(scope: !1338, file: !3, line: 276, column: 48)
!1338 = distinct !DILexicalBlock(scope: !1317, file: !3, line: 276, column: 9)
!1339 = !DILocalVariable(name: "chunk", scope: !1340, file: !3, line: 341, type: !95)
!1340 = distinct !DILexicalBlock(scope: !1341, file: !3, line: 340, column: 38)
!1341 = distinct !DILexicalBlock(scope: !1317, file: !3, line: 340, column: 9)
!1342 = !DILocation(line: 0, scope: !1317)
!1343 = !DILocation(line: 260, column: 16, scope: !1344)
!1344 = distinct !DILexicalBlock(scope: !1317, file: !3, line: 260, column: 9)
!1345 = !DILocation(line: 260, column: 9, scope: !1317)
!1346 = !DILocation(line: 263, column: 43, scope: !1317)
!1347 = !DILocalVariable(name: "nkey", arg: 1, scope: !1348, file: !3, line: 157, type: !869)
!1348 = distinct !DISubprogram(name: "item_make_header", scope: !3, file: !3, line: 157, type: !1349, scopeLine: 158, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1352)
!1349 = !DISubroutineType(types: !1350)
!1350 = !{!148, !869, !1322, !734, !147, !1351}
!1351 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !122, size: 64)
!1352 = !{!1347, !1353, !1354, !1355, !1356}
!1353 = !DILocalVariable(name: "flags", arg: 2, scope: !1348, file: !3, line: 157, type: !1322)
!1354 = !DILocalVariable(name: "nbytes", arg: 3, scope: !1348, file: !3, line: 157, type: !734)
!1355 = !DILocalVariable(name: "suffix", arg: 4, scope: !1348, file: !3, line: 158, type: !147)
!1356 = !DILocalVariable(name: "nsuffix", arg: 5, scope: !1348, file: !3, line: 158, type: !1351)
!1357 = !DILocation(line: 0, scope: !1348, inlinedAt: !1358)
!1358 = distinct !DILocation(line: 263, column: 21, scope: !1317)
!1359 = !DILocation(line: 159, column: 15, scope: !1360, inlinedAt: !1358)
!1360 = distinct !DILexicalBlock(scope: !1348, file: !3, line: 159, column: 9)
!1361 = !DILocation(line: 164, column: 27, scope: !1348, inlinedAt: !1358)
!1362 = !DILocation(line: 164, column: 25, scope: !1348, inlinedAt: !1358)
!1363 = !DILocation(line: 164, column: 34, scope: !1348, inlinedAt: !1358)
!1364 = !DILocation(line: 164, column: 32, scope: !1348, inlinedAt: !1358)
!1365 = !DILocation(line: 164, column: 43, scope: !1348, inlinedAt: !1358)
!1366 = !DILocation(line: 264, column: 18, scope: !1367)
!1367 = distinct !DILexicalBlock(scope: !1317, file: !3, line: 264, column: 9)
!1368 = !{!788, !791, i64 104}
!1369 = !DILocation(line: 264, column: 9, scope: !1317)
!1370 = !DILocation(line: 268, column: 23, scope: !1317)
!1371 = !DILocation(line: 270, column: 12, scope: !1372)
!1372 = distinct !DILexicalBlock(scope: !1317, file: !3, line: 270, column: 9)
!1373 = !DILocation(line: 270, column: 9, scope: !1317)
!1374 = !DILocation(line: 276, column: 27, scope: !1338)
!1375 = !DILocation(line: 276, column: 18, scope: !1338)
!1376 = !DILocation(line: 276, column: 16, scope: !1338)
!1377 = !DILocation(line: 276, column: 9, scope: !1317)
!1378 = !DILocation(line: 281, column: 31, scope: !1337)
!1379 = !DILocation(line: 0, scope: !1337)
!1380 = !DILocation(line: 282, column: 22, scope: !1381)
!1381 = distinct !DILexicalBlock(scope: !1337, file: !3, line: 282, column: 13)
!1382 = !DILocation(line: 282, column: 13, scope: !1337)
!1383 = !DILocation(line: 292, column: 30, scope: !1337)
!1384 = !DILocation(line: 292, column: 18, scope: !1337)
!1385 = !DILocation(line: 293, column: 14, scope: !1337)
!1386 = !DILocation(line: 295, column: 16, scope: !1387)
!1387 = distinct !DILexicalBlock(scope: !1337, file: !3, line: 295, column: 13)
!1388 = !DILocation(line: 295, column: 13, scope: !1337)
!1389 = !DILocation(line: 296, column: 17, scope: !1387)
!1390 = !DILocation(line: 296, column: 26, scope: !1387)
!1391 = !DILocation(line: 296, column: 13, scope: !1387)
!1392 = !DILocation(line: 348, column: 29, scope: !1340)
!1393 = !DILocation(line: 297, column: 5, scope: !1337)
!1394 = !DILocation(line: 298, column: 14, scope: !1395)
!1395 = distinct !DILexicalBlock(scope: !1338, file: !3, line: 297, column: 12)
!1396 = !DILocation(line: 0, scope: !1338)
!1397 = !DILocation(line: 301, column: 12, scope: !1398)
!1398 = distinct !DILexicalBlock(scope: !1317, file: !3, line: 301, column: 9)
!1399 = !DILocation(line: 301, column: 9, scope: !1317)
!1400 = !DILocation(line: 302, column: 29, scope: !1401)
!1401 = distinct !DILexicalBlock(scope: !1398, file: !3, line: 301, column: 21)
!1402 = !DILocation(line: 302, column: 9, scope: !1401)
!1403 = !DILocation(line: 303, column: 23, scope: !1401)
!1404 = !DILocation(line: 303, column: 34, scope: !1401)
!1405 = !{!746, !747, i64 24}
!1406 = !DILocation(line: 304, column: 9, scope: !1401)
!1407 = !DILocation(line: 305, column: 9, scope: !1401)
!1408 = !DILocation(line: 312, column: 14, scope: !1317)
!1409 = !DILocation(line: 317, column: 18, scope: !1410)
!1410 = distinct !DILexicalBlock(scope: !1317, file: !3, line: 317, column: 9)
!1411 = !{!788, !791, i64 220}
!1412 = !DILocation(line: 317, column: 27, scope: !1410)
!1413 = !DILocation(line: 318, column: 23, scope: !1410)
!1414 = !DILocation(line: 318, column: 21, scope: !1410)
!1415 = !DILocation(line: 318, column: 48, scope: !1410)
!1416 = !{!788, !750, i64 224}
!1417 = !DILocation(line: 318, column: 36, scope: !1410)
!1418 = !DILocation(line: 317, column: 9, scope: !1317)
!1419 = !DILocation(line: 319, column: 12, scope: !1420)
!1420 = distinct !DILexicalBlock(scope: !1410, file: !3, line: 318, column: 63)
!1421 = !DILocation(line: 320, column: 5, scope: !1420)
!1422 = !DILocation(line: 320, column: 25, scope: !1423)
!1423 = distinct !DILexicalBlock(scope: !1410, file: !3, line: 320, column: 16)
!1424 = !DILocation(line: 320, column: 16, scope: !1410)
!1425 = !DILocation(line: 0, scope: !1410)
!1426 = !DILocation(line: 326, column: 23, scope: !1317)
!1427 = !DILocation(line: 326, column: 9, scope: !1317)
!1428 = !DILocation(line: 326, column: 21, scope: !1317)
!1429 = !DILocation(line: 329, column: 30, scope: !1317)
!1430 = !DILocation(line: 329, column: 21, scope: !1317)
!1431 = !DILocation(line: 329, column: 9, scope: !1317)
!1432 = !DILocation(line: 329, column: 18, scope: !1317)
!1433 = !DILocation(line: 330, column: 21, scope: !1317)
!1434 = !DILocation(line: 330, column: 18, scope: !1317)
!1435 = !DILocation(line: 331, column: 16, scope: !1317)
!1436 = !DILocation(line: 331, column: 9, scope: !1317)
!1437 = !DILocation(line: 331, column: 14, scope: !1317)
!1438 = !DILocation(line: 332, column: 9, scope: !1317)
!1439 = !DILocation(line: 332, column: 16, scope: !1317)
!1440 = !DILocation(line: 333, column: 12, scope: !1317)
!1441 = !DILocation(line: 333, column: 5, scope: !1317)
!1442 = !DILocation(line: 334, column: 9, scope: !1317)
!1443 = !DILocation(line: 334, column: 17, scope: !1317)
!1444 = !DILocation(line: 340, column: 13, scope: !1341)
!1445 = !DILocation(line: 335, column: 9, scope: !1317)
!1446 = !DILocation(line: 336, column: 16, scope: !1447)
!1447 = distinct !DILexicalBlock(scope: !1448, file: !3, line: 335, column: 22)
!1448 = distinct !DILexicalBlock(scope: !1317, file: !3, line: 335, column: 9)
!1449 = !DILocation(line: 336, column: 9, scope: !1447)
!1450 = !DILocation(line: 337, column: 5, scope: !1447)
!1451 = !DILocation(line: 340, column: 9, scope: !1341)
!1452 = !DILocation(line: 340, column: 22, scope: !1341)
!1453 = !DILocation(line: 340, column: 9, scope: !1317)
!1454 = !DILocation(line: 341, column: 44, scope: !1340)
!1455 = !DILocation(line: 0, scope: !1340)
!1456 = !DILocation(line: 345, column: 16, scope: !1340)
!1457 = !DILocation(line: 345, column: 21, scope: !1340)
!1458 = !DILocation(line: 346, column: 16, scope: !1340)
!1459 = !DILocation(line: 346, column: 21, scope: !1340)
!1460 = !DILocation(line: 347, column: 16, scope: !1340)
!1461 = !DILocation(line: 344, column: 21, scope: !1340)
!1462 = !DILocation(line: 347, column: 21, scope: !1340)
!1463 = !DILocation(line: 348, column: 16, scope: !1340)
!1464 = !DILocation(line: 348, column: 27, scope: !1340)
!1465 = !DILocation(line: 349, column: 5, scope: !1340)
!1466 = !DILocation(line: 350, column: 9, scope: !1317)
!1467 = !DILocation(line: 350, column: 16, scope: !1317)
!1468 = !DILocation(line: 352, column: 5, scope: !1317)
!1469 = !DILocation(line: 353, column: 1, scope: !1317)
!1470 = !DILocation(line: 0, scope: !1008)
!1471 = !DILocation(line: 356, column: 21, scope: !1008)
!1472 = !DILocation(line: 364, column: 13, scope: !1008)
!1473 = !DILocation(line: 366, column: 5, scope: !1008)
!1474 = !DILocation(line: 367, column: 1, scope: !1008)
!1475 = !DISubprogram(name: "slabs_free", scope: !80, file: !80, line: 29, type: !1476, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1476 = !DISubroutineType(types: !1477)
!1477 = !{null, !94, !148, !7}
!1478 = distinct !DISubprogram(name: "item_size_ok", scope: !3, file: !3, line: 373, type: !1479, scopeLine: 373, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1481)
!1479 = !DISubroutineType(types: !1480)
!1480 = !{!455, !813, !1322, !734}
!1481 = !{!1482, !1483, !1484, !1485, !1486, !1487}
!1482 = !DILocalVariable(name: "nkey", arg: 1, scope: !1478, file: !3, line: 373, type: !813)
!1483 = !DILocalVariable(name: "flags", arg: 2, scope: !1478, file: !3, line: 373, type: !1322)
!1484 = !DILocalVariable(name: "nbytes", arg: 3, scope: !1478, file: !3, line: 373, type: !734)
!1485 = !DILocalVariable(name: "prefix", scope: !1478, file: !3, line: 374, type: !184)
!1486 = !DILocalVariable(name: "nsuffix", scope: !1478, file: !3, line: 375, type: !122)
!1487 = !DILocalVariable(name: "ntotal", scope: !1478, file: !3, line: 379, type: !148)
!1488 = !DILocation(line: 0, scope: !1478)
!1489 = !DILocation(line: 376, column: 16, scope: !1490)
!1490 = distinct !DILexicalBlock(scope: !1478, file: !3, line: 376, column: 9)
!1491 = !DILocation(line: 376, column: 9, scope: !1478)
!1492 = !DILocation(line: 379, column: 38, scope: !1478)
!1493 = !DILocation(line: 0, scope: !1348, inlinedAt: !1494)
!1494 = distinct !DILocation(line: 379, column: 21, scope: !1478)
!1495 = !DILocation(line: 159, column: 15, scope: !1360, inlinedAt: !1494)
!1496 = !DILocation(line: 164, column: 27, scope: !1348, inlinedAt: !1494)
!1497 = !DILocation(line: 164, column: 25, scope: !1348, inlinedAt: !1494)
!1498 = !DILocation(line: 164, column: 34, scope: !1348, inlinedAt: !1494)
!1499 = !DILocation(line: 164, column: 32, scope: !1348, inlinedAt: !1494)
!1500 = !DILocation(line: 164, column: 43, scope: !1348, inlinedAt: !1494)
!1501 = !DILocation(line: 381, column: 18, scope: !1502)
!1502 = distinct !DILexicalBlock(scope: !1478, file: !3, line: 381, column: 9)
!1503 = !DILocation(line: 381, column: 9, scope: !1478)
!1504 = !DILocation(line: 385, column: 12, scope: !1478)
!1505 = !DILocation(line: 385, column: 32, scope: !1478)
!1506 = !DILocation(line: 386, column: 1, scope: !1478)
!1507 = distinct !DISubprogram(name: "do_item_link_fixup", scope: !3, file: !3, line: 389, type: !998, scopeLine: 389, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1508)
!1508 = !{!1509, !1510, !1511, !1512, !1513}
!1509 = !DILocalVariable(name: "it", arg: 1, scope: !1507, file: !3, line: 389, type: !263)
!1510 = !DILocalVariable(name: "head", scope: !1507, file: !3, line: 390, type: !1056)
!1511 = !DILocalVariable(name: "tail", scope: !1507, file: !3, line: 390, type: !1056)
!1512 = !DILocalVariable(name: "ntotal", scope: !1507, file: !3, line: 391, type: !113)
!1513 = !DILocalVariable(name: "hv", scope: !1507, file: !3, line: 392, type: !266)
!1514 = !DILocation(line: 0, scope: !1507)
!1515 = !DILocation(line: 391, column: 18, scope: !1507)
!1516 = !DILocation(line: 392, column: 19, scope: !1507)
!1517 = !DILocation(line: 392, column: 24, scope: !1507)
!1518 = !DILocation(line: 393, column: 5, scope: !1507)
!1519 = !DILocation(line: 395, column: 23, scope: !1507)
!1520 = !DILocation(line: 395, column: 13, scope: !1507)
!1521 = !DILocation(line: 396, column: 13, scope: !1507)
!1522 = !DILocation(line: 397, column: 13, scope: !1523)
!1523 = distinct !DILexicalBlock(scope: !1507, file: !3, line: 397, column: 9)
!1524 = !DILocation(line: 397, column: 18, scope: !1523)
!1525 = !DILocation(line: 397, column: 23, scope: !1523)
!1526 = !DILocation(line: 397, column: 26, scope: !1523)
!1527 = !DILocation(line: 397, column: 32, scope: !1523)
!1528 = !DILocation(line: 397, column: 9, scope: !1507)
!1529 = !DILocation(line: 397, column: 44, scope: !1523)
!1530 = !DILocation(line: 397, column: 38, scope: !1523)
!1531 = !DILocation(line: 398, column: 13, scope: !1532)
!1532 = distinct !DILexicalBlock(scope: !1507, file: !3, line: 398, column: 9)
!1533 = !DILocation(line: 398, column: 18, scope: !1532)
!1534 = !DILocation(line: 398, column: 23, scope: !1532)
!1535 = !DILocation(line: 398, column: 26, scope: !1532)
!1536 = !DILocation(line: 398, column: 32, scope: !1532)
!1537 = !DILocation(line: 398, column: 9, scope: !1507)
!1538 = !DILocation(line: 398, column: 44, scope: !1532)
!1539 = !DILocation(line: 398, column: 38, scope: !1532)
!1540 = !DILocation(line: 399, column: 5, scope: !1507)
!1541 = !DILocation(line: 399, column: 27, scope: !1507)
!1542 = !DILocation(line: 400, column: 37, scope: !1507)
!1543 = !DILocation(line: 400, column: 5, scope: !1507)
!1544 = !DILocation(line: 400, column: 34, scope: !1507)
!1545 = !DILocation(line: 402, column: 5, scope: !1507)
!1546 = !DILocation(line: 404, column: 28, scope: !1507)
!1547 = !DILocation(line: 405, column: 23, scope: !1507)
!1548 = !{!1549, !747, i64 0}
!1549 = !{!"stats", !747, i64 0, !747, i64 8, !747, i64 16, !747, i64 24, !747, i64 32, !747, i64 40, !747, i64 48, !747, i64 56, !747, i64 64, !747, i64 72, !747, i64 80, !747, i64 88, !747, i64 96, !747, i64 104, !747, i64 112, !747, i64 120, !747, i64 128, !747, i64 136, !747, i64 144, !747, i64 152, !747, i64 160, !747, i64 168, !747, i64 176, !747, i64 184, !1550, i64 192, !747, i64 208, !747, i64 216}
!1550 = !{!"timeval", !747, i64 0, !747, i64 8}
!1551 = !DILocation(line: 406, column: 5, scope: !1507)
!1552 = !DILocalVariable(name: "it", arg: 1, scope: !1553, file: !3, line: 935, type: !263)
!1553 = distinct !DISubprogram(name: "item_stats_sizes_add", scope: !3, file: !3, line: 935, type: !998, scopeLine: 935, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1554)
!1554 = !{!1552, !1555, !1556}
!1555 = !DILocalVariable(name: "ntotal", scope: !1553, file: !3, line: 938, type: !113)
!1556 = !DILocalVariable(name: "bucket", scope: !1553, file: !3, line: 939, type: !113)
!1557 = !DILocation(line: 0, scope: !1553, inlinedAt: !1558)
!1558 = distinct !DILocation(line: 408, column: 5, scope: !1507)
!1559 = !DILocation(line: 936, column: 9, scope: !1560, inlinedAt: !1558)
!1560 = distinct !DILexicalBlock(scope: !1553, file: !3, line: 936, column: 9)
!1561 = !DILocation(line: 936, column: 26, scope: !1560, inlinedAt: !1558)
!1562 = !DILocation(line: 936, column: 9, scope: !1553, inlinedAt: !1558)
!1563 = !DILocation(line: 938, column: 18, scope: !1553, inlinedAt: !1558)
!1564 = !DILocation(line: 939, column: 25, scope: !1553, inlinedAt: !1558)
!1565 = !DILocation(line: 940, column: 23, scope: !1566, inlinedAt: !1558)
!1566 = distinct !DILexicalBlock(scope: !1553, file: !3, line: 940, column: 9)
!1567 = !DILocation(line: 940, column: 9, scope: !1553, inlinedAt: !1558)
!1568 = !DILocation(line: 941, column: 18, scope: !1569, inlinedAt: !1558)
!1569 = distinct !DILexicalBlock(scope: !1553, file: !3, line: 941, column: 9)
!1570 = !DILocation(line: 941, column: 16, scope: !1569, inlinedAt: !1558)
!1571 = !DILocation(line: 941, column: 9, scope: !1553, inlinedAt: !1558)
!1572 = !DILocation(line: 941, column: 39, scope: !1569, inlinedAt: !1558)
!1573 = !DILocation(line: 941, column: 63, scope: !1569, inlinedAt: !1558)
!1574 = !DILocation(line: 411, column: 1, scope: !1507)
!1575 = !DISubprogram(name: "assoc_insert", scope: !1576, file: !1576, line: 5, type: !1577, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1576 = !DIFile(filename: "./assoc.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "07a03bb93725ff477a16ac4bae114cd2")
!1577 = !DISubroutineType(types: !1578)
!1578 = !{!113, !263, !1579}
!1579 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !266)
!1580 = !DISubprogram(name: "STATS_LOCK", scope: !6, file: !6, line: 1026, type: !705, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1581 = !DISubprogram(name: "STATS_UNLOCK", scope: !6, file: !6, line: 1027, type: !705, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1582 = !DILocation(line: 0, scope: !1553)
!1583 = !DILocation(line: 936, column: 9, scope: !1560)
!1584 = !DILocation(line: 936, column: 26, scope: !1560)
!1585 = !DILocation(line: 936, column: 9, scope: !1553)
!1586 = !DILocation(line: 938, column: 18, scope: !1553)
!1587 = !DILocation(line: 939, column: 25, scope: !1553)
!1588 = !DILocation(line: 940, column: 23, scope: !1566)
!1589 = !DILocation(line: 940, column: 9, scope: !1553)
!1590 = !DILocation(line: 941, column: 18, scope: !1569)
!1591 = !DILocation(line: 941, column: 16, scope: !1569)
!1592 = !DILocation(line: 941, column: 9, scope: !1553)
!1593 = !DILocation(line: 941, column: 39, scope: !1569)
!1594 = !DILocation(line: 941, column: 63, scope: !1569)
!1595 = !DILocation(line: 942, column: 1, scope: !1553)
!1596 = distinct !DISubprogram(name: "do_item_link", scope: !3, file: !3, line: 491, type: !1597, scopeLine: 491, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1599)
!1597 = !DISubroutineType(types: !1598)
!1598 = !{!113, !263, !1579, !735}
!1599 = !{!1600, !1601, !1602}
!1600 = !DILocalVariable(name: "it", arg: 1, scope: !1596, file: !3, line: 491, type: !263)
!1601 = !DILocalVariable(name: "hv", arg: 2, scope: !1596, file: !3, line: 491, type: !1579)
!1602 = !DILocalVariable(name: "cas", arg: 3, scope: !1596, file: !3, line: 491, type: !735)
!1603 = !DILocation(line: 0, scope: !1596)
!1604 = !DILocation(line: 494, column: 9, scope: !1596)
!1605 = !DILocation(line: 494, column: 18, scope: !1596)
!1606 = !DILocation(line: 495, column: 16, scope: !1596)
!1607 = !DILocation(line: 495, column: 9, scope: !1596)
!1608 = !DILocation(line: 495, column: 14, scope: !1596)
!1609 = !DILocation(line: 497, column: 5, scope: !1596)
!1610 = !DILocation(line: 498, column: 31, scope: !1596)
!1611 = !DILocation(line: 498, column: 28, scope: !1596)
!1612 = !{!1613, !747, i64 8}
!1613 = !{!"stats_state", !747, i64 0, !747, i64 8, !747, i64 16, !747, i64 24, !750, i64 32, !750, i64 36, !750, i64 40, !750, i64 44, !791, i64 48, !791, i64 49, !791, i64 50, !791, i64 51}
!1614 = !DILocation(line: 499, column: 28, scope: !1596)
!1615 = !{!1613, !747, i64 0}
!1616 = !DILocation(line: 500, column: 23, scope: !1596)
!1617 = !DILocation(line: 501, column: 5, scope: !1596)
!1618 = !DILocation(line: 504, column: 5, scope: !1619)
!1619 = distinct !DILexicalBlock(scope: !1620, file: !3, line: 504, column: 5)
!1620 = distinct !DILexicalBlock(scope: !1596, file: !3, line: 504, column: 5)
!1621 = !DILocation(line: 504, column: 5, scope: !1620)
!1622 = !DILocation(line: 504, column: 5, scope: !1623)
!1623 = distinct !DILexicalBlock(scope: !1619, file: !3, line: 504, column: 5)
!1624 = !DILocation(line: 505, column: 5, scope: !1596)
!1625 = !DILocation(line: 506, column: 5, scope: !1596)
!1626 = !DILocation(line: 507, column: 5, scope: !1596)
!1627 = !DILocation(line: 0, scope: !1553, inlinedAt: !1628)
!1628 = distinct !DILocation(line: 508, column: 5, scope: !1596)
!1629 = !DILocation(line: 936, column: 9, scope: !1560, inlinedAt: !1628)
!1630 = !DILocation(line: 936, column: 26, scope: !1560, inlinedAt: !1628)
!1631 = !DILocation(line: 936, column: 9, scope: !1553, inlinedAt: !1628)
!1632 = !DILocation(line: 938, column: 18, scope: !1553, inlinedAt: !1628)
!1633 = !DILocation(line: 939, column: 25, scope: !1553, inlinedAt: !1628)
!1634 = !DILocation(line: 940, column: 23, scope: !1566, inlinedAt: !1628)
!1635 = !DILocation(line: 940, column: 9, scope: !1553, inlinedAt: !1628)
!1636 = !DILocation(line: 941, column: 18, scope: !1569, inlinedAt: !1628)
!1637 = !DILocation(line: 941, column: 16, scope: !1569, inlinedAt: !1628)
!1638 = !DILocation(line: 941, column: 9, scope: !1553, inlinedAt: !1628)
!1639 = !DILocation(line: 941, column: 39, scope: !1569, inlinedAt: !1628)
!1640 = !DILocation(line: 941, column: 63, scope: !1569, inlinedAt: !1628)
!1641 = !DILocation(line: 510, column: 5, scope: !1596)
!1642 = distinct !DISubprogram(name: "item_link_q", scope: !3, file: !3, line: 440, type: !998, scopeLine: 440, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1643)
!1643 = !{!1644}
!1644 = !DILocalVariable(name: "it", arg: 1, scope: !1642, file: !3, line: 440, type: !263)
!1645 = !DILocation(line: 0, scope: !1642)
!1646 = !DILocation(line: 441, column: 39, scope: !1642)
!1647 = !DILocation(line: 441, column: 25, scope: !1642)
!1648 = !DILocation(line: 441, column: 5, scope: !1642)
!1649 = !DILocation(line: 0, scope: !1053, inlinedAt: !1650)
!1650 = distinct !DILocation(line: 442, column: 5, scope: !1642)
!1651 = !DILocation(line: 417, column: 23, scope: !1053, inlinedAt: !1650)
!1652 = !DILocation(line: 417, column: 13, scope: !1053, inlinedAt: !1650)
!1653 = !DILocation(line: 418, column: 13, scope: !1053, inlinedAt: !1650)
!1654 = !DILocation(line: 421, column: 9, scope: !1053, inlinedAt: !1650)
!1655 = !DILocation(line: 421, column: 14, scope: !1053, inlinedAt: !1650)
!1656 = !DILocation(line: 422, column: 16, scope: !1053, inlinedAt: !1650)
!1657 = !DILocation(line: 422, column: 14, scope: !1053, inlinedAt: !1650)
!1658 = !DILocation(line: 423, column: 9, scope: !1067, inlinedAt: !1650)
!1659 = !DILocation(line: 423, column: 9, scope: !1053, inlinedAt: !1650)
!1660 = !DILocation(line: 423, column: 29, scope: !1067, inlinedAt: !1650)
!1661 = !DILocation(line: 423, column: 34, scope: !1067, inlinedAt: !1650)
!1662 = !DILocation(line: 423, column: 19, scope: !1067, inlinedAt: !1650)
!1663 = !DILocation(line: 424, column: 11, scope: !1053, inlinedAt: !1650)
!1664 = !DILocation(line: 425, column: 9, scope: !1074, inlinedAt: !1650)
!1665 = !DILocation(line: 425, column: 15, scope: !1074, inlinedAt: !1650)
!1666 = !DILocation(line: 425, column: 9, scope: !1053, inlinedAt: !1650)
!1667 = !DILocation(line: 425, column: 27, scope: !1074, inlinedAt: !1650)
!1668 = !DILocation(line: 425, column: 21, scope: !1074, inlinedAt: !1650)
!1669 = !DILocation(line: 426, column: 15, scope: !1053, inlinedAt: !1650)
!1670 = !DILocation(line: 426, column: 5, scope: !1053, inlinedAt: !1650)
!1671 = !DILocation(line: 426, column: 27, scope: !1053, inlinedAt: !1650)
!1672 = !DILocation(line: 428, column: 13, scope: !1083, inlinedAt: !1650)
!1673 = !DILocation(line: 428, column: 9, scope: !1083, inlinedAt: !1650)
!1674 = !DILocation(line: 428, column: 22, scope: !1083, inlinedAt: !1650)
!1675 = !DILocation(line: 0, scope: !1083, inlinedAt: !1650)
!1676 = !DILocation(line: 428, column: 9, scope: !1053, inlinedAt: !1650)
!1677 = !DILocation(line: 429, column: 42, scope: !1089, inlinedAt: !1650)
!1678 = !DILocation(line: 429, column: 9, scope: !1089, inlinedAt: !1650)
!1679 = !DILocation(line: 429, column: 38, scope: !1089, inlinedAt: !1650)
!1680 = !DILocation(line: 429, column: 58, scope: !1089, inlinedAt: !1650)
!1681 = !DILocation(line: 429, column: 72, scope: !1089, inlinedAt: !1650)
!1682 = !DILocation(line: 430, column: 5, scope: !1089, inlinedAt: !1650)
!1683 = !DILocation(line: 431, column: 41, scope: !1096, inlinedAt: !1650)
!1684 = !DILocation(line: 431, column: 9, scope: !1096, inlinedAt: !1650)
!1685 = !DILocation(line: 431, column: 38, scope: !1096, inlinedAt: !1650)
!1686 = !DILocation(line: 443, column: 27, scope: !1642)
!1687 = !DILocation(line: 443, column: 5, scope: !1642)
!1688 = !DILocation(line: 444, column: 1, scope: !1642)
!1689 = distinct !DISubprogram(name: "do_item_unlink", scope: !3, file: !3, line: 513, type: !1690, scopeLine: 513, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1692)
!1690 = !DISubroutineType(types: !1691)
!1691 = !{null, !263, !1579}
!1692 = !{!1693, !1694}
!1693 = !DILocalVariable(name: "it", arg: 1, scope: !1689, file: !3, line: 513, type: !263)
!1694 = !DILocalVariable(name: "hv", arg: 2, scope: !1689, file: !3, line: 513, type: !1579)
!1695 = !DILocation(line: 0, scope: !1689)
!1696 = !DILocation(line: 515, column: 14, scope: !1697)
!1697 = distinct !DILexicalBlock(scope: !1689, file: !3, line: 515, column: 9)
!1698 = !DILocation(line: 515, column: 23, scope: !1697)
!1699 = !DILocation(line: 515, column: 38, scope: !1697)
!1700 = !DILocation(line: 515, column: 9, scope: !1689)
!1701 = !DILocation(line: 516, column: 22, scope: !1702)
!1702 = distinct !DILexicalBlock(scope: !1697, file: !3, line: 515, column: 44)
!1703 = !DILocation(line: 517, column: 9, scope: !1702)
!1704 = !DILocation(line: 518, column: 35, scope: !1702)
!1705 = !DILocation(line: 518, column: 32, scope: !1702)
!1706 = !DILocation(line: 519, column: 32, scope: !1702)
!1707 = !DILocation(line: 520, column: 9, scope: !1702)
!1708 = !DILocalVariable(name: "it", arg: 1, scope: !1709, file: !3, line: 947, type: !263)
!1709 = distinct !DISubprogram(name: "item_stats_sizes_remove", scope: !3, file: !3, line: 947, type: !998, scopeLine: 947, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1710)
!1710 = !{!1708, !1711, !1712}
!1711 = !DILocalVariable(name: "ntotal", scope: !1709, file: !3, line: 950, type: !113)
!1712 = !DILocalVariable(name: "bucket", scope: !1709, file: !3, line: 951, type: !113)
!1713 = !DILocation(line: 0, scope: !1709, inlinedAt: !1714)
!1714 = distinct !DILocation(line: 521, column: 9, scope: !1702)
!1715 = !DILocation(line: 948, column: 9, scope: !1716, inlinedAt: !1714)
!1716 = distinct !DILexicalBlock(scope: !1709, file: !3, line: 948, column: 9)
!1717 = !DILocation(line: 948, column: 26, scope: !1716, inlinedAt: !1714)
!1718 = !DILocation(line: 522, column: 22, scope: !1702)
!1719 = !DILocation(line: 522, column: 40, scope: !1702)
!1720 = !DILocation(line: 948, column: 9, scope: !1709, inlinedAt: !1714)
!1721 = !DILocation(line: 950, column: 18, scope: !1709, inlinedAt: !1714)
!1722 = !DILocation(line: 951, column: 25, scope: !1709, inlinedAt: !1714)
!1723 = !DILocation(line: 952, column: 23, scope: !1724, inlinedAt: !1714)
!1724 = distinct !DILexicalBlock(scope: !1709, file: !3, line: 952, column: 9)
!1725 = !DILocation(line: 952, column: 9, scope: !1709, inlinedAt: !1714)
!1726 = !DILocation(line: 953, column: 18, scope: !1727, inlinedAt: !1714)
!1727 = distinct !DILexicalBlock(scope: !1709, file: !3, line: 953, column: 9)
!1728 = !DILocation(line: 953, column: 16, scope: !1727, inlinedAt: !1714)
!1729 = !DILocation(line: 953, column: 9, scope: !1709, inlinedAt: !1714)
!1730 = !DILocation(line: 953, column: 39, scope: !1727, inlinedAt: !1714)
!1731 = !DILocation(line: 953, column: 63, scope: !1727, inlinedAt: !1714)
!1732 = !DILocation(line: 522, column: 36, scope: !1702)
!1733 = !DILocation(line: 522, column: 9, scope: !1702)
!1734 = !DILocalVariable(name: "it", arg: 1, scope: !1735, file: !3, line: 485, type: !263)
!1735 = distinct !DISubprogram(name: "item_unlink_q", scope: !3, file: !3, line: 485, type: !998, scopeLine: 485, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1736)
!1736 = !{!1734}
!1737 = !DILocation(line: 0, scope: !1735, inlinedAt: !1738)
!1738 = distinct !DILocation(line: 523, column: 9, scope: !1702)
!1739 = !DILocation(line: 486, column: 39, scope: !1735, inlinedAt: !1738)
!1740 = !DILocation(line: 486, column: 25, scope: !1735, inlinedAt: !1738)
!1741 = !DILocation(line: 486, column: 5, scope: !1735, inlinedAt: !1738)
!1742 = !DILocation(line: 487, column: 5, scope: !1735, inlinedAt: !1738)
!1743 = !DILocation(line: 488, column: 41, scope: !1735, inlinedAt: !1738)
!1744 = !DILocation(line: 488, column: 27, scope: !1735, inlinedAt: !1738)
!1745 = !DILocation(line: 488, column: 5, scope: !1735, inlinedAt: !1738)
!1746 = !DILocation(line: 0, scope: !997, inlinedAt: !1747)
!1747 = distinct !DILocation(line: 524, column: 9, scope: !1702)
!1748 = !DILocation(line: 549, column: 9, scope: !1004, inlinedAt: !1747)
!1749 = !DILocation(line: 549, column: 27, scope: !1004, inlinedAt: !1747)
!1750 = !DILocation(line: 549, column: 9, scope: !997, inlinedAt: !1747)
!1751 = !DILocation(line: 0, scope: !1008, inlinedAt: !1752)
!1752 = distinct !DILocation(line: 550, column: 9, scope: !1014, inlinedAt: !1747)
!1753 = !DILocation(line: 356, column: 21, scope: !1008, inlinedAt: !1752)
!1754 = !DILocation(line: 364, column: 13, scope: !1008, inlinedAt: !1752)
!1755 = !DILocation(line: 366, column: 5, scope: !1008, inlinedAt: !1752)
!1756 = !DILocation(line: 551, column: 5, scope: !1014, inlinedAt: !1747)
!1757 = !DILocation(line: 526, column: 1, scope: !1689)
!1758 = !DILocation(line: 0, scope: !1709)
!1759 = !DILocation(line: 948, column: 9, scope: !1716)
!1760 = !DILocation(line: 948, column: 26, scope: !1716)
!1761 = !DILocation(line: 948, column: 9, scope: !1709)
!1762 = !DILocation(line: 950, column: 18, scope: !1709)
!1763 = !DILocation(line: 951, column: 25, scope: !1709)
!1764 = !DILocation(line: 952, column: 23, scope: !1724)
!1765 = !DILocation(line: 952, column: 9, scope: !1709)
!1766 = !DILocation(line: 953, column: 18, scope: !1727)
!1767 = !DILocation(line: 953, column: 16, scope: !1727)
!1768 = !DILocation(line: 953, column: 9, scope: !1709)
!1769 = !DILocation(line: 953, column: 39, scope: !1727)
!1770 = !DILocation(line: 953, column: 63, scope: !1727)
!1771 = !DILocation(line: 954, column: 1, scope: !1709)
!1772 = !DISubprogram(name: "assoc_delete", scope: !1576, file: !1576, line: 6, type: !1773, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1773 = !DISubroutineType(types: !1774)
!1774 = !{null, !1320, !813, !1579}
!1775 = !DILocation(line: 0, scope: !997)
!1776 = !DILocation(line: 549, column: 9, scope: !1004)
!1777 = !DILocation(line: 549, column: 27, scope: !1004)
!1778 = !DILocation(line: 549, column: 9, scope: !997)
!1779 = !DILocation(line: 0, scope: !1008, inlinedAt: !1780)
!1780 = distinct !DILocation(line: 550, column: 9, scope: !1014)
!1781 = !DILocation(line: 356, column: 21, scope: !1008, inlinedAt: !1780)
!1782 = !DILocation(line: 364, column: 13, scope: !1008, inlinedAt: !1780)
!1783 = !DILocation(line: 366, column: 5, scope: !1008, inlinedAt: !1780)
!1784 = !DILocation(line: 551, column: 5, scope: !1014)
!1785 = !DILocation(line: 552, column: 1, scope: !997)
!1786 = distinct !DISubprogram(name: "do_item_unlink_nolock", scope: !3, file: !3, line: 529, type: !1690, scopeLine: 529, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1787)
!1787 = !{!1788, !1789}
!1788 = !DILocalVariable(name: "it", arg: 1, scope: !1786, file: !3, line: 529, type: !263)
!1789 = !DILocalVariable(name: "hv", arg: 2, scope: !1786, file: !3, line: 529, type: !1579)
!1790 = !DILocation(line: 0, scope: !1786)
!1791 = !DILocation(line: 531, column: 14, scope: !1792)
!1792 = distinct !DILexicalBlock(scope: !1786, file: !3, line: 531, column: 9)
!1793 = !DILocation(line: 531, column: 23, scope: !1792)
!1794 = !DILocation(line: 531, column: 38, scope: !1792)
!1795 = !DILocation(line: 531, column: 9, scope: !1786)
!1796 = !DILocation(line: 532, column: 22, scope: !1797)
!1797 = distinct !DILexicalBlock(scope: !1792, file: !3, line: 531, column: 44)
!1798 = !DILocation(line: 533, column: 9, scope: !1797)
!1799 = !DILocation(line: 534, column: 35, scope: !1797)
!1800 = !DILocation(line: 534, column: 32, scope: !1797)
!1801 = !DILocation(line: 535, column: 32, scope: !1797)
!1802 = !DILocation(line: 536, column: 9, scope: !1797)
!1803 = !DILocation(line: 0, scope: !1709, inlinedAt: !1804)
!1804 = distinct !DILocation(line: 537, column: 9, scope: !1797)
!1805 = !DILocation(line: 948, column: 9, scope: !1716, inlinedAt: !1804)
!1806 = !DILocation(line: 948, column: 26, scope: !1716, inlinedAt: !1804)
!1807 = !DILocation(line: 538, column: 22, scope: !1797)
!1808 = !DILocation(line: 538, column: 40, scope: !1797)
!1809 = !DILocation(line: 948, column: 9, scope: !1709, inlinedAt: !1804)
!1810 = !DILocation(line: 950, column: 18, scope: !1709, inlinedAt: !1804)
!1811 = !DILocation(line: 951, column: 25, scope: !1709, inlinedAt: !1804)
!1812 = !DILocation(line: 952, column: 23, scope: !1724, inlinedAt: !1804)
!1813 = !DILocation(line: 952, column: 9, scope: !1709, inlinedAt: !1804)
!1814 = !DILocation(line: 953, column: 18, scope: !1727, inlinedAt: !1804)
!1815 = !DILocation(line: 953, column: 16, scope: !1727, inlinedAt: !1804)
!1816 = !DILocation(line: 953, column: 9, scope: !1709, inlinedAt: !1804)
!1817 = !DILocation(line: 953, column: 39, scope: !1727, inlinedAt: !1804)
!1818 = !DILocation(line: 953, column: 63, scope: !1727, inlinedAt: !1804)
!1819 = !DILocation(line: 538, column: 36, scope: !1797)
!1820 = !DILocation(line: 538, column: 9, scope: !1797)
!1821 = !DILocation(line: 539, column: 9, scope: !1797)
!1822 = !DILocation(line: 0, scope: !997, inlinedAt: !1823)
!1823 = distinct !DILocation(line: 540, column: 9, scope: !1797)
!1824 = !DILocation(line: 549, column: 9, scope: !1004, inlinedAt: !1823)
!1825 = !DILocation(line: 549, column: 27, scope: !1004, inlinedAt: !1823)
!1826 = !DILocation(line: 549, column: 9, scope: !997, inlinedAt: !1823)
!1827 = !DILocation(line: 0, scope: !1008, inlinedAt: !1828)
!1828 = distinct !DILocation(line: 550, column: 9, scope: !1014, inlinedAt: !1823)
!1829 = !DILocation(line: 356, column: 21, scope: !1008, inlinedAt: !1828)
!1830 = !DILocation(line: 364, column: 13, scope: !1008, inlinedAt: !1828)
!1831 = !DILocation(line: 366, column: 5, scope: !1008, inlinedAt: !1828)
!1832 = !DILocation(line: 551, column: 5, scope: !1014, inlinedAt: !1823)
!1833 = !DILocation(line: 542, column: 1, scope: !1786)
!1834 = distinct !DISubprogram(name: "do_item_unlink_q", scope: !3, file: !3, line: 453, type: !998, scopeLine: 453, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1835)
!1835 = !{!1836, !1837, !1838}
!1836 = !DILocalVariable(name: "it", arg: 1, scope: !1834, file: !3, line: 453, type: !263)
!1837 = !DILocalVariable(name: "head", scope: !1834, file: !3, line: 454, type: !1056)
!1838 = !DILocalVariable(name: "tail", scope: !1834, file: !3, line: 454, type: !1056)
!1839 = !DILocation(line: 0, scope: !1834)
!1840 = !DILocation(line: 455, column: 23, scope: !1834)
!1841 = !DILocation(line: 455, column: 13, scope: !1834)
!1842 = !DILocation(line: 456, column: 13, scope: !1834)
!1843 = !DILocation(line: 458, column: 9, scope: !1844)
!1844 = distinct !DILexicalBlock(scope: !1834, file: !3, line: 458, column: 9)
!1845 = !DILocation(line: 458, column: 15, scope: !1844)
!1846 = !DILocation(line: 458, column: 9, scope: !1834)
!1847 = !DILocation(line: 460, column: 21, scope: !1848)
!1848 = distinct !DILexicalBlock(scope: !1844, file: !3, line: 458, column: 22)
!1849 = !DILocation(line: 460, column: 15, scope: !1848)
!1850 = !DILocation(line: 461, column: 5, scope: !1848)
!1851 = !DILocation(line: 462, column: 9, scope: !1852)
!1852 = distinct !DILexicalBlock(scope: !1834, file: !3, line: 462, column: 9)
!1853 = !DILocation(line: 462, column: 15, scope: !1852)
!1854 = !DILocation(line: 462, column: 9, scope: !1834)
!1855 = !DILocation(line: 464, column: 21, scope: !1856)
!1856 = distinct !DILexicalBlock(scope: !1852, file: !3, line: 462, column: 22)
!1857 = !DILocation(line: 464, column: 15, scope: !1856)
!1858 = !DILocation(line: 465, column: 5, scope: !1856)
!1859 = !DILocation(line: 469, column: 13, scope: !1860)
!1860 = distinct !DILexicalBlock(scope: !1834, file: !3, line: 469, column: 9)
!1861 = !DILocation(line: 469, column: 9, scope: !1860)
!1862 = !DILocation(line: 469, column: 9, scope: !1834)
!1863 = !DILocation(line: 469, column: 29, scope: !1860)
!1864 = !DILocation(line: 469, column: 34, scope: !1860)
!1865 = !DILocation(line: 469, column: 19, scope: !1860)
!1866 = !DILocation(line: 470, column: 9, scope: !1867)
!1867 = distinct !DILexicalBlock(scope: !1834, file: !3, line: 470, column: 9)
!1868 = !DILocation(line: 470, column: 9, scope: !1834)
!1869 = !DILocation(line: 470, column: 40, scope: !1867)
!1870 = !DILocation(line: 470, column: 34, scope: !1867)
!1871 = !DILocation(line: 470, column: 19, scope: !1867)
!1872 = !DILocation(line: 471, column: 15, scope: !1834)
!1873 = !DILocation(line: 471, column: 5, scope: !1834)
!1874 = !DILocation(line: 471, column: 27, scope: !1834)
!1875 = !DILocation(line: 473, column: 13, scope: !1876)
!1876 = distinct !DILexicalBlock(scope: !1834, file: !3, line: 473, column: 9)
!1877 = !DILocation(line: 473, column: 9, scope: !1876)
!1878 = !DILocation(line: 473, column: 22, scope: !1876)
!1879 = !DILocation(line: 0, scope: !1876)
!1880 = !DILocation(line: 473, column: 9, scope: !1834)
!1881 = !DILocation(line: 474, column: 42, scope: !1882)
!1882 = distinct !DILexicalBlock(scope: !1876, file: !3, line: 473, column: 34)
!1883 = !DILocation(line: 474, column: 9, scope: !1882)
!1884 = !DILocation(line: 474, column: 38, scope: !1882)
!1885 = !DILocation(line: 474, column: 58, scope: !1882)
!1886 = !DILocation(line: 474, column: 72, scope: !1882)
!1887 = !DILocation(line: 475, column: 5, scope: !1882)
!1888 = !DILocation(line: 476, column: 41, scope: !1889)
!1889 = distinct !DILexicalBlock(scope: !1876, file: !3, line: 475, column: 12)
!1890 = !DILocation(line: 476, column: 9, scope: !1889)
!1891 = !DILocation(line: 476, column: 38, scope: !1889)
!1892 = !DILocation(line: 483, column: 1, scope: !1834)
!1893 = distinct !DISubprogram(name: "do_item_update", scope: !3, file: !3, line: 555, type: !998, scopeLine: 555, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1894)
!1894 = !{!1895}
!1895 = !DILocalVariable(name: "it", arg: 1, scope: !1893, file: !3, line: 555, type: !263)
!1896 = !DILocation(line: 0, scope: !1893)
!1897 = !DILocation(line: 559, column: 18, scope: !1898)
!1898 = distinct !DILexicalBlock(scope: !1893, file: !3, line: 559, column: 9)
!1899 = !DILocation(line: 559, column: 9, scope: !1893)
!1900 = !DILocation(line: 561, column: 18, scope: !1901)
!1901 = distinct !DILexicalBlock(scope: !1902, file: !3, line: 561, column: 13)
!1902 = distinct !DILexicalBlock(scope: !1898, file: !3, line: 559, column: 33)
!1903 = !DILocation(line: 561, column: 14, scope: !1901)
!1904 = !DILocation(line: 561, column: 27, scope: !1901)
!1905 = !DILocation(line: 561, column: 42, scope: !1901)
!1906 = !DILocation(line: 561, column: 13, scope: !1902)
!1907 = !DILocation(line: 562, column: 17, scope: !1908)
!1908 = distinct !DILexicalBlock(scope: !1909, file: !3, line: 562, column: 17)
!1909 = distinct !DILexicalBlock(scope: !1901, file: !3, line: 561, column: 48)
!1910 = !DILocation(line: 562, column: 32, scope: !1908)
!1911 = !DILocation(line: 562, column: 44, scope: !1908)
!1912 = !DILocation(line: 0, scope: !1908)
!1913 = !DILocation(line: 0, scope: !1735, inlinedAt: !1914)
!1914 = distinct !DILocation(line: 564, column: 17, scope: !1915)
!1915 = distinct !DILexicalBlock(scope: !1908, file: !3, line: 562, column: 77)
!1916 = !DILocation(line: 486, column: 25, scope: !1735, inlinedAt: !1914)
!1917 = !DILocation(line: 486, column: 5, scope: !1735, inlinedAt: !1914)
!1918 = !DILocation(line: 487, column: 5, scope: !1735, inlinedAt: !1914)
!1919 = !DILocation(line: 488, column: 41, scope: !1735, inlinedAt: !1914)
!1920 = !DILocation(line: 488, column: 27, scope: !1735, inlinedAt: !1914)
!1921 = !DILocation(line: 488, column: 5, scope: !1735, inlinedAt: !1914)
!1922 = !DILocation(line: 565, column: 35, scope: !1915)
!1923 = !DILocation(line: 566, column: 33, scope: !1915)
!1924 = !DILocation(line: 567, column: 30, scope: !1915)
!1925 = !DILocalVariable(name: "it", arg: 1, scope: !1926, file: !3, line: 446, type: !263)
!1926 = distinct !DISubprogram(name: "item_link_q_warm", scope: !3, file: !3, line: 446, type: !998, scopeLine: 446, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1927)
!1927 = !{!1925}
!1928 = !DILocation(line: 0, scope: !1926, inlinedAt: !1929)
!1929 = distinct !DILocation(line: 568, column: 17, scope: !1915)
!1930 = !DILocation(line: 447, column: 25, scope: !1926, inlinedAt: !1929)
!1931 = !DILocation(line: 447, column: 5, scope: !1926, inlinedAt: !1929)
!1932 = !DILocation(line: 0, scope: !1053, inlinedAt: !1933)
!1933 = distinct !DILocation(line: 448, column: 5, scope: !1926, inlinedAt: !1929)
!1934 = !DILocation(line: 417, column: 23, scope: !1053, inlinedAt: !1933)
!1935 = !DILocation(line: 417, column: 13, scope: !1053, inlinedAt: !1933)
!1936 = !DILocation(line: 418, column: 13, scope: !1053, inlinedAt: !1933)
!1937 = !DILocation(line: 421, column: 9, scope: !1053, inlinedAt: !1933)
!1938 = !DILocation(line: 421, column: 14, scope: !1053, inlinedAt: !1933)
!1939 = !DILocation(line: 422, column: 16, scope: !1053, inlinedAt: !1933)
!1940 = !DILocation(line: 422, column: 14, scope: !1053, inlinedAt: !1933)
!1941 = !DILocation(line: 423, column: 9, scope: !1067, inlinedAt: !1933)
!1942 = !DILocation(line: 423, column: 9, scope: !1053, inlinedAt: !1933)
!1943 = !DILocation(line: 423, column: 29, scope: !1067, inlinedAt: !1933)
!1944 = !DILocation(line: 423, column: 34, scope: !1067, inlinedAt: !1933)
!1945 = !DILocation(line: 423, column: 19, scope: !1067, inlinedAt: !1933)
!1946 = !DILocation(line: 424, column: 11, scope: !1053, inlinedAt: !1933)
!1947 = !DILocation(line: 425, column: 9, scope: !1074, inlinedAt: !1933)
!1948 = !DILocation(line: 425, column: 15, scope: !1074, inlinedAt: !1933)
!1949 = !DILocation(line: 425, column: 9, scope: !1053, inlinedAt: !1933)
!1950 = !DILocation(line: 425, column: 27, scope: !1074, inlinedAt: !1933)
!1951 = !DILocation(line: 425, column: 21, scope: !1074, inlinedAt: !1933)
!1952 = !DILocation(line: 426, column: 15, scope: !1053, inlinedAt: !1933)
!1953 = !DILocation(line: 426, column: 5, scope: !1053, inlinedAt: !1933)
!1954 = !DILocation(line: 426, column: 27, scope: !1053, inlinedAt: !1933)
!1955 = !DILocation(line: 428, column: 13, scope: !1083, inlinedAt: !1933)
!1956 = !DILocation(line: 428, column: 9, scope: !1083, inlinedAt: !1933)
!1957 = !DILocation(line: 428, column: 22, scope: !1083, inlinedAt: !1933)
!1958 = !DILocation(line: 0, scope: !1083, inlinedAt: !1933)
!1959 = !DILocation(line: 428, column: 9, scope: !1053, inlinedAt: !1933)
!1960 = !DILocation(line: 429, column: 42, scope: !1089, inlinedAt: !1933)
!1961 = !DILocation(line: 429, column: 9, scope: !1089, inlinedAt: !1933)
!1962 = !DILocation(line: 429, column: 38, scope: !1089, inlinedAt: !1933)
!1963 = !DILocation(line: 429, column: 58, scope: !1089, inlinedAt: !1933)
!1964 = !DILocation(line: 429, column: 72, scope: !1089, inlinedAt: !1933)
!1965 = !DILocation(line: 430, column: 5, scope: !1089, inlinedAt: !1933)
!1966 = !DILocation(line: 431, column: 41, scope: !1096, inlinedAt: !1933)
!1967 = !DILocation(line: 431, column: 9, scope: !1096, inlinedAt: !1933)
!1968 = !DILocation(line: 431, column: 38, scope: !1096, inlinedAt: !1933)
!1969 = !DILocation(line: 449, column: 32, scope: !1926, inlinedAt: !1929)
!1970 = !DILocation(line: 449, column: 45, scope: !1926, inlinedAt: !1929)
!1971 = !DILocation(line: 450, column: 27, scope: !1926, inlinedAt: !1929)
!1972 = !DILocation(line: 450, column: 5, scope: !1926, inlinedAt: !1929)
!1973 = !DILocation(line: 569, column: 13, scope: !1915)
!1974 = !DILocation(line: 573, column: 20, scope: !1975)
!1975 = distinct !DILexicalBlock(scope: !1898, file: !3, line: 573, column: 16)
!1976 = !DILocation(line: 573, column: 27, scope: !1975)
!1977 = !DILocation(line: 573, column: 40, scope: !1975)
!1978 = !DILocation(line: 573, column: 25, scope: !1975)
!1979 = !DILocation(line: 573, column: 16, scope: !1898)
!1980 = !DILocation(line: 576, column: 18, scope: !1981)
!1981 = distinct !DILexicalBlock(scope: !1982, file: !3, line: 576, column: 13)
!1982 = distinct !DILexicalBlock(scope: !1975, file: !3, line: 573, column: 64)
!1983 = !DILocation(line: 576, column: 27, scope: !1981)
!1984 = !DILocation(line: 576, column: 42, scope: !1981)
!1985 = !DILocation(line: 576, column: 13, scope: !1982)
!1986 = !DILocation(line: 577, column: 24, scope: !1987)
!1987 = distinct !DILexicalBlock(scope: !1981, file: !3, line: 576, column: 48)
!1988 = !DILocation(line: 577, column: 22, scope: !1987)
!1989 = !DILocation(line: 0, scope: !1735, inlinedAt: !1990)
!1990 = distinct !DILocation(line: 578, column: 13, scope: !1987)
!1991 = !DILocation(line: 486, column: 39, scope: !1735, inlinedAt: !1990)
!1992 = !DILocation(line: 486, column: 25, scope: !1735, inlinedAt: !1990)
!1993 = !DILocation(line: 486, column: 5, scope: !1735, inlinedAt: !1990)
!1994 = !DILocation(line: 487, column: 5, scope: !1735, inlinedAt: !1990)
!1995 = !DILocation(line: 488, column: 41, scope: !1735, inlinedAt: !1990)
!1996 = !DILocation(line: 488, column: 27, scope: !1735, inlinedAt: !1990)
!1997 = !DILocation(line: 488, column: 5, scope: !1735, inlinedAt: !1990)
!1998 = !DILocation(line: 579, column: 13, scope: !1987)
!1999 = !DILocation(line: 580, column: 9, scope: !1987)
!2000 = !DILocation(line: 582, column: 1, scope: !1893)
!2001 = distinct !DISubprogram(name: "do_item_replace", scope: !3, file: !3, line: 584, type: !2002, scopeLine: 584, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2004)
!2002 = !DISubroutineType(types: !2003)
!2003 = !{!113, !263, !263, !1579, !735}
!2004 = !{!2005, !2006, !2007, !2008}
!2005 = !DILocalVariable(name: "it", arg: 1, scope: !2001, file: !3, line: 584, type: !263)
!2006 = !DILocalVariable(name: "new_it", arg: 2, scope: !2001, file: !3, line: 584, type: !263)
!2007 = !DILocalVariable(name: "hv", arg: 3, scope: !2001, file: !3, line: 584, type: !1579)
!2008 = !DILocalVariable(name: "cas", arg: 4, scope: !2001, file: !3, line: 584, type: !735)
!2009 = !DILocation(line: 0, scope: !2001)
!2010 = !DILocation(line: 589, column: 5, scope: !2001)
!2011 = !DILocation(line: 590, column: 12, scope: !2001)
!2012 = !DILocation(line: 590, column: 5, scope: !2001)
!2013 = distinct !DISubprogram(name: "item_flush_expired", scope: !3, file: !3, line: 593, type: !705, scopeLine: 593, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2014)
!2014 = !{!2015, !2016, !2017, !2018, !2025}
!2015 = !DILocalVariable(name: "i", scope: !2013, file: !3, line: 594, type: !113)
!2016 = !DILocalVariable(name: "iter", scope: !2013, file: !3, line: 595, type: !263)
!2017 = !DILocalVariable(name: "next", scope: !2013, file: !3, line: 595, type: !263)
!2018 = !DILocalVariable(name: "hold_lock", scope: !2019, file: !3, line: 606, type: !94)
!2019 = distinct !DILexicalBlock(scope: !2020, file: !3, line: 605, column: 58)
!2020 = distinct !DILexicalBlock(scope: !2021, file: !3, line: 605, column: 9)
!2021 = distinct !DILexicalBlock(scope: !2022, file: !3, line: 605, column: 9)
!2022 = distinct !DILexicalBlock(scope: !2023, file: !3, line: 598, column: 38)
!2023 = distinct !DILexicalBlock(scope: !2024, file: !3, line: 598, column: 5)
!2024 = distinct !DILexicalBlock(scope: !2013, file: !3, line: 598, column: 5)
!2025 = !DILocalVariable(name: "hv", scope: !2019, file: !3, line: 611, type: !266)
!2026 = !DILocation(line: 596, column: 18, scope: !2027)
!2027 = distinct !DILexicalBlock(scope: !2013, file: !3, line: 596, column: 9)
!2028 = !DILocation(line: 596, column: 30, scope: !2027)
!2029 = !DILocation(line: 596, column: 9, scope: !2013)
!2030 = !DILocation(line: 0, scope: !2013)
!2031 = !DILocation(line: 604, column: 29, scope: !2022)
!2032 = !DILocation(line: 604, column: 9, scope: !2022)
!2033 = !DILocation(line: 605, column: 21, scope: !2021)
!2034 = !DILocation(line: 605, column: 36, scope: !2020)
!2035 = !DILocation(line: 605, column: 9, scope: !2021)
!2036 = !DILocation(line: 0, scope: !2019)
!2037 = !DILocation(line: 607, column: 26, scope: !2019)
!2038 = !DILocation(line: 608, column: 23, scope: !2039)
!2039 = distinct !DILexicalBlock(scope: !2019, file: !3, line: 608, column: 17)
!2040 = !DILocation(line: 608, column: 28, scope: !2039)
!2041 = !DILocation(line: 608, column: 33, scope: !2039)
!2042 = !DILocation(line: 608, column: 61, scope: !2039)
!2043 = !DILocation(line: 608, column: 70, scope: !2039)
!2044 = !DILocation(line: 608, column: 17, scope: !2019)
!2045 = !DILocation(line: 611, column: 54, scope: !2019)
!2046 = !DILocation(line: 611, column: 27, scope: !2019)
!2047 = !DILocation(line: 611, column: 32, scope: !2019)
!2048 = !DILocation(line: 611, column: 48, scope: !2019)
!2049 = !DILocation(line: 614, column: 30, scope: !2050)
!2050 = distinct !DILexicalBlock(scope: !2019, file: !3, line: 614, column: 17)
!2051 = !DILocation(line: 614, column: 48, scope: !2050)
!2052 = !DILocation(line: 614, column: 17, scope: !2019)
!2053 = !DILocation(line: 618, column: 23, scope: !2054)
!2054 = distinct !DILexicalBlock(scope: !2019, file: !3, line: 618, column: 17)
!2055 = !DILocation(line: 618, column: 40, scope: !2054)
!2056 = !DILocation(line: 618, column: 28, scope: !2054)
!2057 = !DILocation(line: 618, column: 17, scope: !2019)
!2058 = !DILocation(line: 622, column: 28, scope: !2059)
!2059 = distinct !DILexicalBlock(scope: !2060, file: !3, line: 622, column: 21)
!2060 = distinct !DILexicalBlock(scope: !2054, file: !3, line: 618, column: 53)
!2061 = !DILocation(line: 622, column: 37, scope: !2059)
!2062 = !DILocation(line: 622, column: 53, scope: !2059)
!2063 = !DILocation(line: 622, column: 21, scope: !2060)
!2064 = !DILocation(line: 623, column: 21, scope: !2065)
!2065 = distinct !DILexicalBlock(scope: !2066, file: !3, line: 623, column: 21)
!2066 = distinct !DILexicalBlock(scope: !2059, file: !3, line: 622, column: 59)
!2067 = !DILocation(line: 625, column: 49, scope: !2066)
!2068 = !DILocation(line: 625, column: 54, scope: !2066)
!2069 = !DILocation(line: 625, column: 76, scope: !2066)
!2070 = !DILocation(line: 625, column: 70, scope: !2066)
!2071 = !DILocation(line: 625, column: 21, scope: !2066)
!2072 = !DILocation(line: 626, column: 17, scope: !2066)
!2073 = !DILocation(line: 627, column: 17, scope: !2060)
!2074 = !DILocation(line: 633, column: 9, scope: !2020)
!2075 = !DILocation(line: 630, column: 17, scope: !2076)
!2076 = distinct !DILexicalBlock(scope: !2054, file: !3, line: 628, column: 20)
!2077 = !DILocation(line: 634, column: 9, scope: !2022)
!2078 = !DILocation(line: 598, column: 34, scope: !2023)
!2079 = !DILocation(line: 598, column: 19, scope: !2023)
!2080 = !DILocation(line: 598, column: 5, scope: !2024)
!2081 = distinct !{!2081, !2080, !2082, !723}
!2082 = !DILocation(line: 635, column: 5, scope: !2024)
!2083 = !DILocation(line: 636, column: 1, scope: !2013)
!2084 = !DISubprogram(name: "item_trylock", scope: !6, file: !6, line: 1018, type: !2085, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2085 = !DISubroutineType(types: !2086)
!2086 = !{!94, !266}
!2087 = !DISubprogram(name: "storage_delete", scope: !2088, file: !2088, line: 4, type: !2089, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2088 = !DIFile(filename: "./storage.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d18dbd8a1337d7561522237d8930ae7f")
!2089 = !DISubroutineType(types: !2090)
!2090 = !{null, !94, !263}
!2091 = !DISubprogram(name: "item_trylock_unlock", scope: !6, file: !6, line: 1019, type: !517, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2092 = distinct !DISubprogram(name: "item_cachedump", scope: !3, file: !3, line: 645, type: !2093, scopeLine: 645, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2095)
!2093 = !DISubroutineType(types: !2094)
!2094 = !{!147, !814, !814, !561}
!2095 = !{!2096, !2097, !2098, !2099, !2100, !2101, !2102, !2103, !2104, !2105, !2109, !2113}
!2096 = !DILocalVariable(name: "slabs_clsid", arg: 1, scope: !2092, file: !3, line: 645, type: !814)
!2097 = !DILocalVariable(name: "limit", arg: 2, scope: !2092, file: !3, line: 645, type: !814)
!2098 = !DILocalVariable(name: "bytes", arg: 3, scope: !2092, file: !3, line: 645, type: !561)
!2099 = !DILocalVariable(name: "memlimit", scope: !2092, file: !3, line: 646, type: !7)
!2100 = !DILocalVariable(name: "buffer", scope: !2092, file: !3, line: 647, type: !147)
!2101 = !DILocalVariable(name: "bufcurr", scope: !2092, file: !3, line: 648, type: !7)
!2102 = !DILocalVariable(name: "it", scope: !2092, file: !3, line: 649, type: !263)
!2103 = !DILocalVariable(name: "len", scope: !2092, file: !3, line: 650, type: !7)
!2104 = !DILocalVariable(name: "shown", scope: !2092, file: !3, line: 651, type: !7)
!2105 = !DILocalVariable(name: "key_temp", scope: !2092, file: !3, line: 652, type: !2106)
!2106 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 2008, elements: !2107)
!2107 = !{!2108}
!2108 = !DISubrange(count: 251)
!2109 = !DILocalVariable(name: "temp", scope: !2092, file: !3, line: 653, type: !2110)
!2110 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 4096, elements: !2111)
!2111 = !{!2112}
!2112 = !DISubrange(count: 512)
!2113 = !DILocalVariable(name: "id", scope: !2092, file: !3, line: 654, type: !7)
!2114 = distinct !DIAssignID()
!2115 = !DILocation(line: 0, scope: !2092)
!2116 = distinct !DIAssignID()
!2117 = !DILocation(line: 652, column: 5, scope: !2092)
!2118 = !DILocation(line: 653, column: 5, scope: !2092)
!2119 = !DILocation(line: 655, column: 8, scope: !2092)
!2120 = !DILocation(line: 657, column: 25, scope: !2092)
!2121 = !DILocation(line: 657, column: 5, scope: !2092)
!2122 = !DILocation(line: 660, column: 14, scope: !2092)
!2123 = !DILocation(line: 661, column: 16, scope: !2124)
!2124 = distinct !DILexicalBlock(scope: !2092, file: !3, line: 661, column: 9)
!2125 = !DILocation(line: 661, column: 9, scope: !2092)
!2126 = !DILocation(line: 658, column: 10, scope: !2092)
!2127 = !DILocation(line: 667, column: 15, scope: !2092)
!2128 = !DILocation(line: 667, column: 23, scope: !2092)
!2129 = !DILocation(line: 662, column: 9, scope: !2130)
!2130 = distinct !DILexicalBlock(scope: !2124, file: !3, line: 661, column: 22)
!2131 = !DILocation(line: 663, column: 9, scope: !2130)
!2132 = !DILocation(line: 670, column: 18, scope: !2133)
!2133 = distinct !DILexicalBlock(scope: !2134, file: !3, line: 670, column: 13)
!2134 = distinct !DILexicalBlock(scope: !2092, file: !3, line: 667, column: 57)
!2135 = !DILocation(line: 670, column: 25, scope: !2133)
!2136 = !DILocation(line: 670, column: 30, scope: !2133)
!2137 = !DILocation(line: 670, column: 37, scope: !2133)
!2138 = !DILocation(line: 670, column: 42, scope: !2133)
!2139 = !DILocation(line: 670, column: 48, scope: !2133)
!2140 = !DILocation(line: 670, column: 56, scope: !2133)
!2141 = !DILocation(line: 670, column: 52, scope: !2133)
!2142 = !DILocation(line: 670, column: 65, scope: !2133)
!2143 = !DILocation(line: 670, column: 13, scope: !2134)
!2144 = distinct !{!2144, !2145, !2146, !723}
!2145 = !DILocation(line: 667, column: 5, scope: !2092)
!2146 = !DILocation(line: 687, column: 5, scope: !2092)
!2147 = !DILocation(line: 675, column: 27, scope: !2134)
!2148 = !DILocation(line: 675, column: 45, scope: !2134)
!2149 = !DILocation(line: 675, column: 41, scope: !2134)
!2150 = !DILocation(line: 675, column: 9, scope: !2134)
!2151 = !DILocation(line: 676, column: 22, scope: !2134)
!2152 = !DILocation(line: 676, column: 9, scope: !2134)
!2153 = !DILocation(line: 676, column: 28, scope: !2134)
!2154 = !DILocation(line: 678, column: 38, scope: !2134)
!2155 = !DILocation(line: 678, column: 45, scope: !2134)
!2156 = !DILocation(line: 679, column: 28, scope: !2134)
!2157 = !DILocation(line: 679, column: 36, scope: !2134)
!2158 = !DILocation(line: 679, column: 24, scope: !2134)
!2159 = !DILocation(line: 680, column: 24, scope: !2134)
!2160 = !DILocation(line: 680, column: 58, scope: !2134)
!2161 = !DILocation(line: 680, column: 56, scope: !2134)
!2162 = !DILocation(line: 677, column: 15, scope: !2134)
!2163 = !DILocation(line: 681, column: 21, scope: !2164)
!2164 = distinct !DILexicalBlock(scope: !2134, file: !3, line: 681, column: 13)
!2165 = !DILocation(line: 681, column: 31, scope: !2164)
!2166 = !DILocation(line: 681, column: 13, scope: !2134)
!2167 = !DILocation(line: 683, column: 23, scope: !2134)
!2168 = !DILocation(line: 683, column: 40, scope: !2134)
!2169 = !DILocation(line: 683, column: 9, scope: !2134)
!2170 = !DILocation(line: 685, column: 14, scope: !2134)
!2171 = !DILocation(line: 689, column: 19, scope: !2092)
!2172 = !DILocation(line: 689, column: 5, scope: !2092)
!2173 = !DILocation(line: 690, column: 13, scope: !2092)
!2174 = !DILocation(line: 692, column: 12, scope: !2092)
!2175 = !DILocation(line: 693, column: 5, scope: !2092)
!2176 = !DILocation(line: 694, column: 5, scope: !2092)
!2177 = !DILocation(line: 695, column: 1, scope: !2092)
!2178 = !DISubprogram(name: "malloc", scope: !2179, file: !2179, line: 672, type: !2180, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2179 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!2180 = !DISubroutineType(types: !2181)
!2181 = !{!94, !148}
!2182 = !DISubprogram(name: "strncpy", scope: !2183, file: !2183, line: 144, type: !2184, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2183 = !DIFile(filename: "/usr/include/string.h", directory: "", checksumkind: CSK_MD5, checksum: "165db1185644f68894fa9e0d17055d70")
!2184 = !DISubroutineType(types: !2185)
!2185 = !{!147, !2186, !2187, !148}
!2186 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !147)
!2187 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1320)
!2188 = !DISubprogram(name: "snprintf", scope: !2189, file: !2189, line: 385, type: !2190, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2189 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "1e435c46987a169d9f9186f63a512303")
!2190 = !DISubroutineType(types: !2191)
!2191 = !{!113, !2186, !148, !2187, null}
!2192 = distinct !DISubprogram(name: "fill_item_stats_automove", scope: !3, file: !3, line: 700, type: !2193, scopeLine: 700, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2205)
!2193 = !DISubroutineType(types: !2194)
!2194 = !{null, !2195}
!2195 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2196, size: 64)
!2196 = !DIDerivedType(tag: DW_TAG_typedef, name: "item_stats_automove", file: !873, line: 70, baseType: !2197)
!2197 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !873, line: 66, size: 192, elements: !2198)
!2198 = !{!2199, !2203, !2204}
!2199 = !DIDerivedType(tag: DW_TAG_member, name: "evicted", scope: !2197, file: !873, line: 67, baseType: !2200, size: 64)
!2200 = !DIDerivedType(tag: DW_TAG_typedef, name: "int64_t", file: !2201, line: 27, baseType: !2202)
!2201 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h", directory: "", checksumkind: CSK_MD5, checksum: "649b383a60bfa3eb90e85840b2b0be20")
!2202 = !DIDerivedType(tag: DW_TAG_typedef, name: "__int64_t", file: !120, line: 44, baseType: !188)
!2203 = !DIDerivedType(tag: DW_TAG_member, name: "outofmemory", scope: !2197, file: !873, line: 68, baseType: !2200, size: 64, offset: 64)
!2204 = !DIDerivedType(tag: DW_TAG_member, name: "age", scope: !2197, file: !873, line: 69, baseType: !266, size: 32, offset: 128)
!2205 = !{!2206, !2207, !2208, !2212}
!2206 = !DILocalVariable(name: "am", arg: 1, scope: !2192, file: !3, line: 700, type: !2195)
!2207 = !DILocalVariable(name: "n", scope: !2192, file: !3, line: 701, type: !113)
!2208 = !DILocalVariable(name: "cur", scope: !2209, file: !3, line: 703, type: !2195)
!2209 = distinct !DILexicalBlock(scope: !2210, file: !3, line: 702, column: 54)
!2210 = distinct !DILexicalBlock(scope: !2211, file: !3, line: 702, column: 5)
!2211 = distinct !DILexicalBlock(scope: !2192, file: !3, line: 702, column: 5)
!2212 = !DILocalVariable(name: "i", scope: !2209, file: !3, line: 706, type: !113)
!2213 = !DILocation(line: 0, scope: !2192)
!2214 = !DILocation(line: 702, column: 5, scope: !2211)
!2215 = !DILocation(line: 703, column: 37, scope: !2209)
!2216 = !DILocation(line: 0, scope: !2209)
!2217 = !DILocation(line: 707, column: 29, scope: !2209)
!2218 = !DILocation(line: 707, column: 9, scope: !2209)
!2219 = !DILocation(line: 708, column: 41, scope: !2209)
!2220 = !DILocation(line: 708, column: 14, scope: !2209)
!2221 = !DILocation(line: 708, column: 26, scope: !2209)
!2222 = !{!2223, !747, i64 8}
!2223 = !{!"", !747, i64 0, !747, i64 8, !750, i64 16}
!2224 = !DILocation(line: 709, column: 9, scope: !2209)
!2225 = !DILocation(line: 712, column: 15, scope: !2209)
!2226 = !DILocation(line: 713, column: 29, scope: !2209)
!2227 = !DILocation(line: 713, column: 9, scope: !2209)
!2228 = !DILocation(line: 714, column: 24, scope: !2209)
!2229 = !DILocation(line: 714, column: 37, scope: !2209)
!2230 = !DILocation(line: 714, column: 22, scope: !2209)
!2231 = !{!2223, !747, i64 0}
!2232 = !DILocation(line: 715, column: 14, scope: !2233)
!2233 = distinct !DILexicalBlock(scope: !2209, file: !3, line: 715, column: 13)
!2234 = !DILocation(line: 715, column: 13, scope: !2209)
!2235 = !DILocation(line: 717, column: 30, scope: !2236)
!2236 = distinct !DILexicalBlock(scope: !2233, file: !3, line: 717, column: 20)
!2237 = !DILocation(line: 717, column: 37, scope: !2236)
!2238 = !DILocation(line: 717, column: 42, scope: !2236)
!2239 = !DILocation(line: 717, column: 55, scope: !2236)
!2240 = !DILocation(line: 717, column: 60, scope: !2236)
!2241 = !DILocation(line: 717, column: 65, scope: !2236)
!2242 = !DILocation(line: 717, column: 78, scope: !2236)
!2243 = !DILocation(line: 717, column: 87, scope: !2236)
!2244 = !DILocation(line: 717, column: 20, scope: !2233)
!2245 = !DILocation(line: 719, column: 27, scope: !2246)
!2246 = distinct !DILexicalBlock(scope: !2247, file: !3, line: 719, column: 17)
!2247 = distinct !DILexicalBlock(scope: !2236, file: !3, line: 717, column: 93)
!2248 = !DILocation(line: 719, column: 17, scope: !2246)
!2249 = !DILocation(line: 719, column: 17, scope: !2247)
!2250 = !DILocation(line: 0, scope: !2236)
!2251 = !DILocation(line: 0, scope: !2233)
!2252 = !{!2223, !750, i64 16}
!2253 = !DILocation(line: 727, column: 9, scope: !2209)
!2254 = !DILocation(line: 702, column: 50, scope: !2210)
!2255 = !DILocation(line: 702, column: 19, scope: !2210)
!2256 = distinct !{!2256, !2214, !2257, !723}
!2257 = !DILocation(line: 728, column: 6, scope: !2211)
!2258 = !DILocation(line: 729, column: 1, scope: !2192)
!2259 = distinct !DISubprogram(name: "item_stats_totals", scope: !3, file: !3, line: 731, type: !2260, scopeLine: 731, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2267)
!2260 = !DISubroutineType(types: !2261)
!2261 = !{null, !2262, !94}
!2262 = !DIDerivedType(tag: DW_TAG_typedef, name: "ADD_STAT", file: !6, line: 194, baseType: !2263)
!2263 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2264, size: 64)
!2264 = !DISubroutineType(types: !2265)
!2265 = !{null, !1320, !2266, !1320, !1579, !243}
!2266 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !117)
!2267 = !{!2268, !2269, !2270, !2271, !2272, !2276}
!2268 = !DILocalVariable(name: "add_stats", arg: 1, scope: !2259, file: !3, line: 731, type: !2262)
!2269 = !DILocalVariable(name: "c", arg: 2, scope: !2259, file: !3, line: 731, type: !94)
!2270 = !DILocalVariable(name: "totals", scope: !2259, file: !3, line: 732, type: !672)
!2271 = !DILocalVariable(name: "n", scope: !2259, file: !3, line: 734, type: !113)
!2272 = !DILocalVariable(name: "x", scope: !2273, file: !3, line: 736, type: !113)
!2273 = distinct !DILexicalBlock(scope: !2274, file: !3, line: 735, column: 54)
!2274 = distinct !DILexicalBlock(scope: !2275, file: !3, line: 735, column: 5)
!2275 = distinct !DILexicalBlock(scope: !2259, file: !3, line: 735, column: 5)
!2276 = !DILocalVariable(name: "i", scope: !2273, file: !3, line: 737, type: !113)
!2277 = distinct !DIAssignID()
!2278 = !DILocation(line: 0, scope: !2259)
!2279 = distinct !DIAssignID()
!2280 = distinct !DIAssignID()
!2281 = distinct !DIAssignID()
!2282 = !DILocation(line: 735, column: 5, scope: !2275)
!2283 = !DILocation(line: 0, scope: !2273)
!2284 = !DILocation(line: 740, column: 33, scope: !2285)
!2285 = distinct !DILexicalBlock(scope: !2286, file: !3, line: 738, column: 33)
!2286 = distinct !DILexicalBlock(scope: !2287, file: !3, line: 738, column: 9)
!2287 = distinct !DILexicalBlock(scope: !2273, file: !3, line: 738, column: 9)
!2288 = !DILocation(line: 740, column: 13, scope: !2285)
!2289 = !DILocation(line: 741, column: 31, scope: !2285)
!2290 = !DILocation(line: 741, column: 44, scope: !2285)
!2291 = !DILocation(line: 741, column: 28, scope: !2285)
!2292 = !DILocation(line: 742, column: 46, scope: !2285)
!2293 = !DILocation(line: 742, column: 30, scope: !2285)
!2294 = !DILocation(line: 743, column: 54, scope: !2285)
!2295 = !DILocation(line: 743, column: 38, scope: !2285)
!2296 = !DILocation(line: 744, column: 54, scope: !2285)
!2297 = !DILocation(line: 744, column: 38, scope: !2285)
!2298 = !DILocation(line: 745, column: 51, scope: !2285)
!2299 = !DILocation(line: 752, column: 36, scope: !2285)
!2300 = !DILocation(line: 753, column: 13, scope: !2285)
!2301 = !DILocation(line: 735, column: 50, scope: !2274)
!2302 = !DILocation(line: 735, column: 19, scope: !2274)
!2303 = distinct !{!2303, !2282, !2304, !723}
!2304 = !DILocation(line: 755, column: 5, scope: !2275)
!2305 = !DILocation(line: 756, column: 5, scope: !2259)
!2306 = !DILocation(line: 758, column: 5, scope: !2259)
!2307 = !DILocation(line: 760, column: 18, scope: !2308)
!2308 = distinct !DILexicalBlock(scope: !2259, file: !3, line: 760, column: 9)
!2309 = !{!788, !791, i64 135}
!2310 = !DILocation(line: 760, column: 9, scope: !2259)
!2311 = !DILocation(line: 761, column: 9, scope: !2312)
!2312 = distinct !DILexicalBlock(scope: !2308, file: !3, line: 760, column: 41)
!2313 = !DILocation(line: 763, column: 5, scope: !2312)
!2314 = !DILocation(line: 764, column: 5, scope: !2259)
!2315 = !DILocation(line: 766, column: 5, scope: !2259)
!2316 = !DILocation(line: 768, column: 5, scope: !2259)
!2317 = !DILocation(line: 770, column: 5, scope: !2259)
!2318 = !DILocation(line: 772, column: 5, scope: !2259)
!2319 = !DILocation(line: 774, column: 18, scope: !2320)
!2320 = distinct !DILexicalBlock(scope: !2259, file: !3, line: 774, column: 9)
!2321 = !DILocation(line: 774, column: 9, scope: !2259)
!2322 = !DILocation(line: 775, column: 9, scope: !2323)
!2323 = distinct !DILexicalBlock(scope: !2320, file: !3, line: 774, column: 41)
!2324 = !DILocation(line: 777, column: 9, scope: !2323)
!2325 = !DILocation(line: 779, column: 9, scope: !2323)
!2326 = !DILocation(line: 781, column: 9, scope: !2323)
!2327 = !DILocalVariable(name: "total", scope: !2328, file: !3, line: 1379, type: !131)
!2328 = distinct !DISubprogram(name: "lru_total_bumps_dropped", scope: !3, file: !3, line: 1378, type: !759, scopeLine: 1378, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2329)
!2329 = !{!2327, !2330}
!2330 = !DILocalVariable(name: "b", scope: !2328, file: !3, line: 1380, type: !568)
!2331 = !DILocation(line: 0, scope: !2328, inlinedAt: !2332)
!2332 = distinct !DILocation(line: 783, column: 9, scope: !2323)
!2333 = !DILocation(line: 1381, column: 5, scope: !2328, inlinedAt: !2332)
!2334 = !DILocation(line: 1382, scope: !2335, inlinedAt: !2332)
!2335 = distinct !DILexicalBlock(scope: !2328, file: !3, line: 1382, column: 5)
!2336 = !DILocation(line: 1382, column: 31, scope: !2337, inlinedAt: !2332)
!2337 = distinct !DILexicalBlock(scope: !2335, file: !3, line: 1382, column: 5)
!2338 = !DILocation(line: 1382, column: 5, scope: !2335, inlinedAt: !2332)
!2339 = !DILocation(line: 1383, column: 32, scope: !2340, inlinedAt: !2332)
!2340 = distinct !DILexicalBlock(scope: !2337, file: !3, line: 1382, column: 51)
!2341 = !DILocation(line: 1383, column: 9, scope: !2340, inlinedAt: !2332)
!2342 = !DILocation(line: 1384, column: 21, scope: !2340, inlinedAt: !2332)
!2343 = !{!2344, !747, i64 64}
!2344 = !{!"_lru_bump_buf", !789, i64 0, !789, i64 8, !748, i64 16, !789, i64 56, !747, i64 64}
!2345 = !DILocation(line: 1384, column: 15, scope: !2340, inlinedAt: !2332)
!2346 = !DILocation(line: 1385, column: 9, scope: !2340, inlinedAt: !2332)
!2347 = !DILocation(line: 1382, column: 45, scope: !2337, inlinedAt: !2332)
!2348 = distinct !{!2348, !2338, !2349, !723}
!2349 = !DILocation(line: 1386, column: 5, scope: !2335, inlinedAt: !2332)
!2350 = !DILocation(line: 1387, column: 5, scope: !2328, inlinedAt: !2332)
!2351 = !DILocation(line: 783, column: 9, scope: !2323)
!2352 = !DILocation(line: 785, column: 5, scope: !2323)
!2353 = !DILocation(line: 786, column: 1, scope: !2259)
!2354 = !DISubprogram(name: "append_stat", scope: !6, file: !6, line: 1037, type: !2355, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2355 = !DISubroutineType(types: !2356)
!2356 = !{null, !1320, !2262, !2357, !1320, null}
!2357 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2358, size: 64)
!2358 = !DIDerivedType(tag: DW_TAG_typedef, name: "conn", file: !6, line: 813, baseType: !2359)
!2359 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "conn", file: !6, line: 829, size: 3968, elements: !2360)
!2360 = !{!2361, !2365, !2366, !2367, !2368, !2369, !2370, !2371, !2372, !2373, !2374, !2375, !2376, !2451, !2452, !2453, !2454, !2455, !2456, !2457, !2680, !2681, !2682, !2683, !2684, !2685, !2686, !2688, !2689, !2690, !2691, !2692, !2693, !2694, !2695, !2696, !2702, !2723, !2724, !2725, !2726, !2727, !2728, !2729, !2730, !2734, !2741, !2756}
!2361 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_conn", scope: !2359, file: !6, line: 830, baseType: !2362, size: 64)
!2362 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2363, size: 64)
!2363 = !DIDerivedType(tag: DW_TAG_typedef, name: "sasl_conn_t", file: !2364, line: 16, baseType: !94)
!2364 = !DIFile(filename: "./sasl_defs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "3a8678a43d09d8e311388b26eedc7a3e")
!2365 = !DIDerivedType(tag: DW_TAG_member, name: "sfd", scope: !2359, file: !6, line: 831, baseType: !113, size: 32, offset: 64)
!2366 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_started", scope: !2359, file: !6, line: 832, baseType: !455, size: 8, offset: 96)
!2367 = !DIDerivedType(tag: DW_TAG_member, name: "authenticated", scope: !2359, file: !6, line: 833, baseType: !455, size: 8, offset: 104)
!2368 = !DIDerivedType(tag: DW_TAG_member, name: "set_stale", scope: !2359, file: !6, line: 834, baseType: !455, size: 8, offset: 112)
!2369 = !DIDerivedType(tag: DW_TAG_member, name: "mset_res", scope: !2359, file: !6, line: 835, baseType: !455, size: 8, offset: 120)
!2370 = !DIDerivedType(tag: DW_TAG_member, name: "close_after_write", scope: !2359, file: !6, line: 836, baseType: !455, size: 8, offset: 128)
!2371 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_malloced", scope: !2359, file: !6, line: 837, baseType: !455, size: 8, offset: 136)
!2372 = !DIDerivedType(tag: DW_TAG_member, name: "item_malloced", scope: !2359, file: !6, line: 838, baseType: !455, size: 8, offset: 144)
!2373 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !2359, file: !6, line: 844, baseType: !5, size: 32, offset: 160)
!2374 = !DIDerivedType(tag: DW_TAG_member, name: "substate", scope: !2359, file: !6, line: 845, baseType: !25, size: 32, offset: 192)
!2375 = !DIDerivedType(tag: DW_TAG_member, name: "last_cmd_time", scope: !2359, file: !6, line: 846, baseType: !110, size: 32, offset: 224)
!2376 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !2359, file: !6, line: 847, baseType: !2377, size: 1024, offset: 256)
!2377 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event", file: !2378, line: 123, size: 1024, elements: !2379)
!2378 = !DIFile(filename: "/usr/include/event2/event_struct.h", directory: "", checksumkind: CSK_MD5, checksum: "005d89b34bed2ed9e30b0cc3160619c1")
!2379 = !{!2380, !2411, !2421, !2422, !2425, !2448, !2449, !2450}
!2380 = !DIDerivedType(tag: DW_TAG_member, name: "ev_evcallback", scope: !2377, file: !2378, line: 124, baseType: !2381, size: 320)
!2381 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event_callback", file: !2378, line: 107, size: 320, elements: !2382)
!2382 = !{!2383, !2390, !2391, !2392, !2393, !2410}
!2383 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_active_next", scope: !2381, file: !2378, line: 108, baseType: !2384, size: 128)
!2384 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2381, file: !2378, line: 108, size: 128, elements: !2385)
!2385 = !{!2386, !2388}
!2386 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !2384, file: !2378, line: 108, baseType: !2387, size: 64)
!2387 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2381, size: 64)
!2388 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !2384, file: !2378, line: 108, baseType: !2389, size: 64, offset: 64)
!2389 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2387, size: 64)
!2390 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_flags", scope: !2381, file: !2378, line: 109, baseType: !173, size: 16, offset: 128)
!2391 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_pri", scope: !2381, file: !2378, line: 110, baseType: !122, size: 8, offset: 144)
!2392 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_closure", scope: !2381, file: !2378, line: 111, baseType: !122, size: 8, offset: 152)
!2393 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cb_union", scope: !2381, file: !2378, line: 118, baseType: !2394, size: 64, offset: 192)
!2394 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !2381, file: !2378, line: 113, size: 64, elements: !2395)
!2395 = !{!2396, !2400, !2404, !2409}
!2396 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_callback", scope: !2394, file: !2378, line: 114, baseType: !2397, size: 64)
!2397 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2398, size: 64)
!2398 = !DISubroutineType(types: !2399)
!2399 = !{null, !113, !173, !94}
!2400 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_selfcb", scope: !2394, file: !2378, line: 115, baseType: !2401, size: 64)
!2401 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2402, size: 64)
!2402 = !DISubroutineType(types: !2403)
!2403 = !{null, !2387, !94}
!2404 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_evfinalize", scope: !2394, file: !2378, line: 116, baseType: !2405, size: 64)
!2405 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2406, size: 64)
!2406 = !DISubroutineType(types: !2407)
!2407 = !{null, !2408, !94}
!2408 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2377, size: 64)
!2409 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cbfinalize", scope: !2394, file: !2378, line: 117, baseType: !2401, size: 64)
!2410 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_arg", scope: !2381, file: !2378, line: 119, baseType: !94, size: 64, offset: 256)
!2411 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout_pos", scope: !2377, file: !2378, line: 130, baseType: !2412, size: 128, offset: 320)
!2412 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !2377, file: !2378, line: 127, size: 128, elements: !2413)
!2413 = !{!2414, !2420}
!2414 = !DIDerivedType(tag: DW_TAG_member, name: "ev_next_with_common_timeout", scope: !2412, file: !2378, line: 128, baseType: !2415, size: 128)
!2415 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2412, file: !2378, line: 128, size: 128, elements: !2416)
!2416 = !{!2417, !2418}
!2417 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !2415, file: !2378, line: 128, baseType: !2408, size: 64)
!2418 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !2415, file: !2378, line: 128, baseType: !2419, size: 64, offset: 64)
!2419 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2408, size: 64)
!2420 = !DIDerivedType(tag: DW_TAG_member, name: "min_heap_idx", scope: !2412, file: !2378, line: 129, baseType: !113, size: 32)
!2421 = !DIDerivedType(tag: DW_TAG_member, name: "ev_fd", scope: !2377, file: !2378, line: 131, baseType: !113, size: 32, offset: 448)
!2422 = !DIDerivedType(tag: DW_TAG_member, name: "ev_base", scope: !2377, file: !2378, line: 133, baseType: !2423, size: 64, offset: 512)
!2423 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2424, size: 64)
!2424 = !DICompositeType(tag: DW_TAG_structure_type, name: "event_base", file: !2378, line: 122, flags: DIFlagFwdDecl)
!2425 = !DIDerivedType(tag: DW_TAG_member, name: "ev_", scope: !2377, file: !2378, line: 149, baseType: !2426, size: 256, offset: 576)
!2426 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !2377, file: !2378, line: 135, size: 256, elements: !2427)
!2427 = !{!2428, !2437}
!2428 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io", scope: !2426, file: !2378, line: 140, baseType: !2429, size: 256)
!2429 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2426, file: !2378, line: 137, size: 256, elements: !2430)
!2430 = !{!2431, !2436}
!2431 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io_next", scope: !2429, file: !2378, line: 138, baseType: !2432, size: 128)
!2432 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2429, file: !2378, line: 138, size: 128, elements: !2433)
!2433 = !{!2434, !2435}
!2434 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !2432, file: !2378, line: 138, baseType: !2408, size: 64)
!2435 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !2432, file: !2378, line: 138, baseType: !2419, size: 64, offset: 64)
!2436 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !2429, file: !2378, line: 139, baseType: !230, size: 128, offset: 128)
!2437 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal", scope: !2426, file: !2378, line: 148, baseType: !2438, size: 256)
!2438 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2426, file: !2378, line: 143, size: 256, elements: !2439)
!2439 = !{!2440, !2445, !2446}
!2440 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal_next", scope: !2438, file: !2378, line: 144, baseType: !2441, size: 128)
!2441 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2438, file: !2378, line: 144, size: 128, elements: !2442)
!2442 = !{!2443, !2444}
!2443 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !2441, file: !2378, line: 144, baseType: !2408, size: 64)
!2444 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !2441, file: !2378, line: 144, baseType: !2419, size: 64, offset: 64)
!2445 = !DIDerivedType(tag: DW_TAG_member, name: "ev_ncalls", scope: !2438, file: !2378, line: 145, baseType: !173, size: 16, offset: 128)
!2446 = !DIDerivedType(tag: DW_TAG_member, name: "ev_pncalls", scope: !2438, file: !2378, line: 147, baseType: !2447, size: 64, offset: 192)
!2447 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !173, size: 64)
!2448 = !DIDerivedType(tag: DW_TAG_member, name: "ev_events", scope: !2377, file: !2378, line: 151, baseType: !173, size: 16, offset: 832)
!2449 = !DIDerivedType(tag: DW_TAG_member, name: "ev_res", scope: !2377, file: !2378, line: 152, baseType: !173, size: 16, offset: 848)
!2450 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !2377, file: !2378, line: 153, baseType: !230, size: 128, offset: 896)
!2451 = !DIDerivedType(tag: DW_TAG_member, name: "ev_flags", scope: !2359, file: !6, line: 848, baseType: !173, size: 16, offset: 1280)
!2452 = !DIDerivedType(tag: DW_TAG_member, name: "which", scope: !2359, file: !6, line: 849, baseType: !173, size: 16, offset: 1296)
!2453 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf", scope: !2359, file: !6, line: 851, baseType: !147, size: 64, offset: 1344)
!2454 = !DIDerivedType(tag: DW_TAG_member, name: "rcurr", scope: !2359, file: !6, line: 852, baseType: !147, size: 64, offset: 1408)
!2455 = !DIDerivedType(tag: DW_TAG_member, name: "rsize", scope: !2359, file: !6, line: 853, baseType: !113, size: 32, offset: 1472)
!2456 = !DIDerivedType(tag: DW_TAG_member, name: "rbytes", scope: !2359, file: !6, line: 854, baseType: !113, size: 32, offset: 1504)
!2457 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !2359, file: !6, line: 856, baseType: !2458, size: 64, offset: 1536)
!2458 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2459, size: 64)
!2459 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp", file: !6, line: 801, baseType: !2460)
!2460 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp", file: !6, line: 771, size: 9472, elements: !2461)
!2461 = !{!2462, !2627, !2629, !2630, !2631, !2632, !2633, !2634, !2641, !2642, !2643, !2644, !2645, !2646, !2647, !2648, !2649, !2672, !2676}
!2462 = !DIDerivedType(tag: DW_TAG_member, name: "bundle", scope: !2460, file: !6, line: 772, baseType: !2463, size: 64)
!2463 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2464, size: 64)
!2464 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp_bundle", file: !6, line: 720, baseType: !2465)
!2465 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp_bundle", file: !6, line: 804, size: 256, elements: !2466)
!2466 = !{!2467, !2468, !2469, !2622, !2624, !2625}
!2467 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !2465, file: !6, line: 805, baseType: !122, size: 8)
!2468 = !DIDerivedType(tag: DW_TAG_member, name: "next_check", scope: !2465, file: !6, line: 806, baseType: !122, size: 8, offset: 8)
!2469 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !2465, file: !6, line: 807, baseType: !2470, size: 64, offset: 64)
!2470 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2471, size: 64)
!2471 = !DIDerivedType(tag: DW_TAG_typedef, name: "LIBEVENT_THREAD", file: !6, line: 765, baseType: !2472)
!2472 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !6, line: 721, size: 55488, elements: !2473)
!2473 = !{!2474, !2475, !2476, !2481, !2482, !2483, !2513, !2514, !2515, !2567, !2587, !2590, !2616, !2617, !2618, !2619, !2620, !2621}
!2474 = !DIDerivedType(tag: DW_TAG_member, name: "thread_id", scope: !2472, file: !6, line: 722, baseType: !551, size: 64)
!2475 = !DIDerivedType(tag: DW_TAG_member, name: "base", scope: !2472, file: !6, line: 723, baseType: !2423, size: 64, offset: 64)
!2476 = !DIDerivedType(tag: DW_TAG_member, name: "n", scope: !2472, file: !6, line: 724, baseType: !2477, size: 1088, offset: 128)
!2477 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_notify", file: !6, line: 710, size: 1088, elements: !2478)
!2478 = !{!2479, !2480}
!2479 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event", scope: !2477, file: !6, line: 711, baseType: !2377, size: 1024)
!2480 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event_fd", scope: !2477, file: !6, line: 713, baseType: !113, size: 32, offset: 1024)
!2481 = !DIDerivedType(tag: DW_TAG_member, name: "ion", scope: !2472, file: !6, line: 725, baseType: !2477, size: 1088, offset: 1216)
!2482 = !DIDerivedType(tag: DW_TAG_member, name: "ion_lock", scope: !2472, file: !6, line: 726, baseType: !159, size: 320, offset: 2304)
!2483 = !DIDerivedType(tag: DW_TAG_member, name: "ion_head", scope: !2472, file: !6, line: 727, baseType: !2484, size: 128, offset: 2624)
!2484 = !DIDerivedType(tag: DW_TAG_typedef, name: "iop_head_t", file: !6, line: 686, baseType: !2485)
!2485 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iop_head_s", file: !6, line: 686, size: 128, elements: !2486)
!2486 = !{!2487, !2511}
!2487 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !2485, file: !6, line: 686, baseType: !2488, size: 64)
!2488 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2489, size: 64)
!2489 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_io_pending_t", file: !6, line: 815, size: 1408, elements: !2490)
!2490 = !{!2491, !2492, !2493, !2494, !2495, !2502, !2503, !2507}
!2491 = !DIDerivedType(tag: DW_TAG_member, name: "io_queue_type", scope: !2489, file: !6, line: 816, baseType: !113, size: 32)
!2492 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !2489, file: !6, line: 817, baseType: !2470, size: 64, offset: 64)
!2493 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !2489, file: !6, line: 818, baseType: !2357, size: 64, offset: 128)
!2494 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !2489, file: !6, line: 819, baseType: !2458, size: 64, offset: 192)
!2495 = !DIDerivedType(tag: DW_TAG_member, name: "return_cb", scope: !2489, file: !6, line: 820, baseType: !2496, size: 64, offset: 256)
!2496 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb", file: !6, line: 690, baseType: !2497)
!2497 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2498, size: 64)
!2498 = !DISubroutineType(types: !2499)
!2499 = !{null, !2500}
!2500 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2501, size: 64)
!2501 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_pending_t", file: !6, line: 687, baseType: !2489)
!2502 = !DIDerivedType(tag: DW_TAG_member, name: "finalize_cb", scope: !2489, file: !6, line: 821, baseType: !2496, size: 64, offset: 320)
!2503 = !DIDerivedType(tag: DW_TAG_member, name: "iop_next", scope: !2489, file: !6, line: 822, baseType: !2504, size: 64, offset: 384)
!2504 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2489, file: !6, line: 822, size: 64, elements: !2505)
!2505 = !{!2506}
!2506 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !2504, file: !6, line: 822, baseType: !2488, size: 64)
!2507 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !2489, file: !6, line: 823, baseType: !2508, size: 960, offset: 448)
!2508 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 960, elements: !2509)
!2509 = !{!2510}
!2510 = !DISubrange(count: 120)
!2511 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !2485, file: !6, line: 686, baseType: !2512, size: 64, offset: 64)
!2512 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2488, size: 64)
!2513 = !DIDerivedType(tag: DW_TAG_member, name: "cur_sfd", scope: !2472, file: !6, line: 728, baseType: !113, size: 32, offset: 2752)
!2514 = !DIDerivedType(tag: DW_TAG_member, name: "thread_baseid", scope: !2472, file: !6, line: 729, baseType: !113, size: 32, offset: 2784)
!2515 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !2472, file: !6, line: 730, baseType: !2516, size: 51584, offset: 2816)
!2516 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_stats", file: !6, line: 372, size: 51584, elements: !2517)
!2517 = !{!2518, !2519, !2520, !2521, !2522, !2523, !2524, !2525, !2526, !2527, !2528, !2529, !2530, !2531, !2532, !2533, !2534, !2535, !2536, !2537, !2538, !2539, !2540, !2541, !2542, !2543, !2544, !2545, !2546, !2547, !2548, !2549, !2563, !2564, !2565, !2566}
!2518 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !2516, file: !6, line: 373, baseType: !159, size: 320)
!2519 = !DIDerivedType(tag: DW_TAG_member, name: "get_cmds", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 320)
!2520 = !DIDerivedType(tag: DW_TAG_member, name: "get_misses", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 384)
!2521 = !DIDerivedType(tag: DW_TAG_member, name: "get_expired", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 448)
!2522 = !DIDerivedType(tag: DW_TAG_member, name: "get_flushed", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 512)
!2523 = !DIDerivedType(tag: DW_TAG_member, name: "touch_cmds", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 576)
!2524 = !DIDerivedType(tag: DW_TAG_member, name: "touch_misses", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 640)
!2525 = !DIDerivedType(tag: DW_TAG_member, name: "delete_misses", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 704)
!2526 = !DIDerivedType(tag: DW_TAG_member, name: "incr_misses", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 768)
!2527 = !DIDerivedType(tag: DW_TAG_member, name: "decr_misses", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 832)
!2528 = !DIDerivedType(tag: DW_TAG_member, name: "cas_misses", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 896)
!2529 = !DIDerivedType(tag: DW_TAG_member, name: "meta_cmds", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 960)
!2530 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_read", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 1024)
!2531 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_written", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 1088)
!2532 = !DIDerivedType(tag: DW_TAG_member, name: "flush_cmds", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 1152)
!2533 = !DIDerivedType(tag: DW_TAG_member, name: "conn_yields", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 1216)
!2534 = !DIDerivedType(tag: DW_TAG_member, name: "auth_cmds", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 1280)
!2535 = !DIDerivedType(tag: DW_TAG_member, name: "auth_errors", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 1344)
!2536 = !DIDerivedType(tag: DW_TAG_member, name: "idle_kicks", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 1408)
!2537 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_oom", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 1472)
!2538 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_count", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 1536)
!2539 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_bytes", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 1600)
!2540 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_oom", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 1664)
!2541 = !DIDerivedType(tag: DW_TAG_member, name: "store_too_large", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 1728)
!2542 = !DIDerivedType(tag: DW_TAG_member, name: "store_no_memory", scope: !2516, file: !6, line: 375, baseType: !131, size: 64, offset: 1792)
!2543 = !DIDerivedType(tag: DW_TAG_member, name: "get_extstore", scope: !2516, file: !6, line: 377, baseType: !131, size: 64, offset: 1856)
!2544 = !DIDerivedType(tag: DW_TAG_member, name: "get_aborted_extstore", scope: !2516, file: !6, line: 377, baseType: !131, size: 64, offset: 1920)
!2545 = !DIDerivedType(tag: DW_TAG_member, name: "get_oom_extstore", scope: !2516, file: !6, line: 377, baseType: !131, size: 64, offset: 1984)
!2546 = !DIDerivedType(tag: DW_TAG_member, name: "recache_from_extstore", scope: !2516, file: !6, line: 377, baseType: !131, size: 64, offset: 2048)
!2547 = !DIDerivedType(tag: DW_TAG_member, name: "miss_from_extstore", scope: !2516, file: !6, line: 377, baseType: !131, size: 64, offset: 2112)
!2548 = !DIDerivedType(tag: DW_TAG_member, name: "badcrc_from_extstore", scope: !2516, file: !6, line: 377, baseType: !131, size: 64, offset: 2176)
!2549 = !DIDerivedType(tag: DW_TAG_member, name: "slab_stats", scope: !2516, file: !6, line: 383, baseType: !2550, size: 32768, offset: 2240)
!2550 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2551, size: 32768, elements: !2561)
!2551 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "slab_stats", file: !6, line: 318, size: 512, elements: !2552)
!2552 = !{!2553, !2554, !2555, !2556, !2557, !2558, !2559, !2560}
!2553 = !DIDerivedType(tag: DW_TAG_member, name: "set_cmds", scope: !2551, file: !6, line: 320, baseType: !131, size: 64)
!2554 = !DIDerivedType(tag: DW_TAG_member, name: "get_hits", scope: !2551, file: !6, line: 320, baseType: !131, size: 64, offset: 64)
!2555 = !DIDerivedType(tag: DW_TAG_member, name: "touch_hits", scope: !2551, file: !6, line: 320, baseType: !131, size: 64, offset: 128)
!2556 = !DIDerivedType(tag: DW_TAG_member, name: "delete_hits", scope: !2551, file: !6, line: 320, baseType: !131, size: 64, offset: 192)
!2557 = !DIDerivedType(tag: DW_TAG_member, name: "cas_hits", scope: !2551, file: !6, line: 320, baseType: !131, size: 64, offset: 256)
!2558 = !DIDerivedType(tag: DW_TAG_member, name: "cas_badval", scope: !2551, file: !6, line: 320, baseType: !131, size: 64, offset: 320)
!2559 = !DIDerivedType(tag: DW_TAG_member, name: "incr_hits", scope: !2551, file: !6, line: 320, baseType: !131, size: 64, offset: 384)
!2560 = !DIDerivedType(tag: DW_TAG_member, name: "decr_hits", scope: !2551, file: !6, line: 320, baseType: !131, size: 64, offset: 448)
!2561 = !{!2562}
!2562 = !DISubrange(count: 64)
!2563 = !DIDerivedType(tag: DW_TAG_member, name: "lru_hits", scope: !2516, file: !6, line: 384, baseType: !548, size: 16384, offset: 35008)
!2564 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_count", scope: !2516, file: !6, line: 385, baseType: !131, size: 64, offset: 51392)
!2565 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes", scope: !2516, file: !6, line: 386, baseType: !131, size: 64, offset: 51456)
!2566 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes_free", scope: !2516, file: !6, line: 387, baseType: !131, size: 64, offset: 51520)
!2567 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !2472, file: !6, line: 731, baseType: !2568, size: 576, offset: 54400)
!2568 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2569, size: 576, elements: !344)
!2569 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb_t", file: !6, line: 708, baseType: !2570)
!2570 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_cb_s", file: !6, line: 704, size: 192, elements: !2571)
!2571 = !{!2572, !2573, !2586}
!2572 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !2570, file: !6, line: 705, baseType: !94, size: 64)
!2573 = !DIDerivedType(tag: DW_TAG_member, name: "submit_cb", scope: !2570, file: !6, line: 706, baseType: !2574, size: 64, offset: 64)
!2574 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_stack_cb", file: !6, line: 689, baseType: !2575)
!2575 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2576, size: 64)
!2576 = !DISubroutineType(types: !2577)
!2577 = !{null, !2578}
!2578 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2579, size: 64)
!2579 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_t", file: !6, line: 688, baseType: !2580)
!2580 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_s", file: !6, line: 697, size: 192, elements: !2581)
!2581 = !{!2582, !2583, !2584, !2585}
!2582 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !2580, file: !6, line: 698, baseType: !94, size: 64)
!2583 = !DIDerivedType(tag: DW_TAG_member, name: "stack_ctx", scope: !2580, file: !6, line: 699, baseType: !94, size: 64, offset: 64)
!2584 = !DIDerivedType(tag: DW_TAG_member, name: "count", scope: !2580, file: !6, line: 700, baseType: !113, size: 32, offset: 128)
!2585 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !2580, file: !6, line: 701, baseType: !113, size: 32, offset: 160)
!2586 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !2570, file: !6, line: 707, baseType: !113, size: 32, offset: 128)
!2587 = !DIDerivedType(tag: DW_TAG_member, name: "ev_queue", scope: !2472, file: !6, line: 732, baseType: !2588, size: 64, offset: 54976)
!2588 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2589, size: 64)
!2589 = !DICompositeType(tag: DW_TAG_structure_type, name: "conn_queue", file: !6, line: 732, flags: DIFlagFwdDecl)
!2590 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_cache", scope: !2472, file: !6, line: 733, baseType: !2591, size: 64, offset: 55040)
!2591 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2592, size: 64)
!2592 = !DIDerivedType(tag: DW_TAG_typedef, name: "cache_t", file: !2593, line: 39, baseType: !2594)
!2593 = !DIFile(filename: "./cache.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d97639c8540587a19d8550d7d7156448")
!2594 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !2593, line: 22, size: 704, elements: !2595)
!2595 = !{!2596, !2597, !2598, !2611, !2612, !2613, !2614, !2615}
!2596 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !2594, file: !2593, line: 24, baseType: !159, size: 320)
!2597 = !DIDerivedType(tag: DW_TAG_member, name: "name", scope: !2594, file: !2593, line: 26, baseType: !147, size: 64, offset: 320)
!2598 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !2594, file: !2593, line: 28, baseType: !2599, size: 128, offset: 384)
!2599 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_head", file: !2593, line: 28, size: 128, elements: !2600)
!2600 = !{!2601, !2609}
!2601 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !2599, file: !2593, line: 28, baseType: !2602, size: 64)
!2602 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2603, size: 64)
!2603 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_free_s", file: !2593, line: 12, size: 64, elements: !2604)
!2604 = !{!2605}
!2605 = !DIDerivedType(tag: DW_TAG_member, name: "c_next", scope: !2603, file: !2593, line: 13, baseType: !2606, size: 64)
!2606 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2603, file: !2593, line: 13, size: 64, elements: !2607)
!2607 = !{!2608}
!2608 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !2606, file: !2593, line: 13, baseType: !2602, size: 64)
!2609 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !2599, file: !2593, line: 28, baseType: !2610, size: 64, offset: 64)
!2610 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2602, size: 64)
!2611 = !DIDerivedType(tag: DW_TAG_member, name: "bufsize", scope: !2594, file: !2593, line: 30, baseType: !148, size: 64, offset: 512)
!2612 = !DIDerivedType(tag: DW_TAG_member, name: "freetotal", scope: !2594, file: !2593, line: 32, baseType: !113, size: 32, offset: 576)
!2613 = !DIDerivedType(tag: DW_TAG_member, name: "total", scope: !2594, file: !2593, line: 34, baseType: !113, size: 32, offset: 608)
!2614 = !DIDerivedType(tag: DW_TAG_member, name: "freecurr", scope: !2594, file: !2593, line: 36, baseType: !113, size: 32, offset: 640)
!2615 = !DIDerivedType(tag: DW_TAG_member, name: "limit", scope: !2594, file: !2593, line: 38, baseType: !113, size: 32, offset: 672)
!2616 = !DIDerivedType(tag: DW_TAG_member, name: "open_bundle", scope: !2472, file: !6, line: 734, baseType: !2463, size: 64, offset: 55104)
!2617 = !DIDerivedType(tag: DW_TAG_member, name: "io_cache", scope: !2472, file: !6, line: 735, baseType: !2591, size: 64, offset: 55168)
!2618 = !DIDerivedType(tag: DW_TAG_member, name: "storage", scope: !2472, file: !6, line: 737, baseType: !94, size: 64, offset: 55232)
!2619 = !DIDerivedType(tag: DW_TAG_member, name: "l", scope: !2472, file: !6, line: 739, baseType: !151, size: 64, offset: 55296)
!2620 = !DIDerivedType(tag: DW_TAG_member, name: "lru_bump_buf", scope: !2472, file: !6, line: 740, baseType: !94, size: 64, offset: 55360)
!2621 = !DIDerivedType(tag: DW_TAG_member, name: "napi_id", scope: !2472, file: !6, line: 744, baseType: !113, size: 32, offset: 55424)
!2622 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !2465, file: !6, line: 808, baseType: !2623, size: 64, offset: 128)
!2623 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2465, size: 64)
!2624 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !2465, file: !6, line: 809, baseType: !2623, size: 64, offset: 192)
!2625 = !DIDerivedType(tag: DW_TAG_member, name: "r", scope: !2465, file: !6, line: 810, baseType: !2626, offset: 256)
!2626 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2459, elements: !136)
!2627 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !2460, file: !6, line: 773, baseType: !2628, size: 64, offset: 64)
!2628 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2460, size: 64)
!2629 = !DIDerivedType(tag: DW_TAG_member, name: "wbytes", scope: !2460, file: !6, line: 774, baseType: !113, size: 32, offset: 128)
!2630 = !DIDerivedType(tag: DW_TAG_member, name: "tosend", scope: !2460, file: !6, line: 775, baseType: !113, size: 32, offset: 160)
!2631 = !DIDerivedType(tag: DW_TAG_member, name: "write_and_free", scope: !2460, file: !6, line: 776, baseType: !94, size: 64, offset: 192)
!2632 = !DIDerivedType(tag: DW_TAG_member, name: "io_pending", scope: !2460, file: !6, line: 777, baseType: !2500, size: 64, offset: 256)
!2633 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !2460, file: !6, line: 779, baseType: !263, size: 64, offset: 320)
!2634 = !DIDerivedType(tag: DW_TAG_member, name: "iov", scope: !2460, file: !6, line: 780, baseType: !2635, size: 512, offset: 384)
!2635 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2636, size: 512, elements: !370)
!2636 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iovec", file: !2637, line: 26, size: 128, elements: !2638)
!2637 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_iovec.h", directory: "", checksumkind: CSK_MD5, checksum: "a53f2c2488bb0e21e47850624c16538a")
!2638 = !{!2639, !2640}
!2639 = !DIDerivedType(tag: DW_TAG_member, name: "iov_base", scope: !2636, file: !2637, line: 28, baseType: !94, size: 64)
!2640 = !DIDerivedType(tag: DW_TAG_member, name: "iov_len", scope: !2636, file: !2637, line: 29, baseType: !148, size: 64, offset: 64)
!2641 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_total", scope: !2460, file: !6, line: 781, baseType: !113, size: 32, offset: 896)
!2642 = !DIDerivedType(tag: DW_TAG_member, name: "iovcnt", scope: !2460, file: !6, line: 782, baseType: !122, size: 8, offset: 928)
!2643 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_data_iov", scope: !2460, file: !6, line: 783, baseType: !122, size: 8, offset: 936)
!2644 = !DIDerivedType(tag: DW_TAG_member, name: "skip", scope: !2460, file: !6, line: 788, baseType: !455, size: 8, offset: 944)
!2645 = !DIDerivedType(tag: DW_TAG_member, name: "free", scope: !2460, file: !6, line: 789, baseType: !455, size: 8, offset: 952)
!2646 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !2460, file: !6, line: 794, baseType: !117, size: 16, offset: 960)
!2647 = !DIDerivedType(tag: DW_TAG_member, name: "udp_sequence", scope: !2460, file: !6, line: 795, baseType: !117, size: 16, offset: 976)
!2648 = !DIDerivedType(tag: DW_TAG_member, name: "udp_total", scope: !2460, file: !6, line: 796, baseType: !117, size: 16, offset: 992)
!2649 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !2460, file: !6, line: 797, baseType: !2650, size: 224, offset: 1024)
!2650 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "sockaddr_in6", file: !2651, line: 262, size: 224, elements: !2652)
!2651 = !DIFile(filename: "/usr/include/netinet/in.h", directory: "", checksumkind: CSK_MD5, checksum: "fbd766480c8cb9a8fe07ee7aa568ee60")
!2652 = !{!2653, !2656, !2658, !2659, !2671}
!2653 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_family", scope: !2650, file: !2651, line: 264, baseType: !2654, size: 16)
!2654 = !DIDerivedType(tag: DW_TAG_typedef, name: "sa_family_t", file: !2655, line: 28, baseType: !115)
!2655 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/sockaddr.h", directory: "", checksumkind: CSK_MD5, checksum: "5066b774f0f3cdb5cbbb5467306060db")
!2656 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_port", scope: !2650, file: !2651, line: 265, baseType: !2657, size: 16, offset: 16)
!2657 = !DIDerivedType(tag: DW_TAG_typedef, name: "in_port_t", file: !2651, line: 125, baseType: !117)
!2658 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_flowinfo", scope: !2650, file: !2651, line: 266, baseType: !266, size: 32, offset: 32)
!2659 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_addr", scope: !2650, file: !2651, line: 267, baseType: !2660, size: 128, offset: 64)
!2660 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "in6_addr", file: !2651, line: 221, size: 128, elements: !2661)
!2661 = !{!2662}
!2662 = !DIDerivedType(tag: DW_TAG_member, name: "__in6_u", scope: !2660, file: !2651, line: 228, baseType: !2663, size: 128)
!2663 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !2660, file: !2651, line: 223, size: 128, elements: !2664)
!2664 = !{!2665, !2667, !2669}
!2665 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr8", scope: !2663, file: !2651, line: 225, baseType: !2666, size: 128)
!2666 = !DICompositeType(tag: DW_TAG_array_type, baseType: !122, size: 128, elements: !327)
!2667 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr16", scope: !2663, file: !2651, line: 226, baseType: !2668, size: 128)
!2668 = !DICompositeType(tag: DW_TAG_array_type, baseType: !117, size: 128, elements: !360)
!2669 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr32", scope: !2663, file: !2651, line: 227, baseType: !2670, size: 128)
!2670 = !DICompositeType(tag: DW_TAG_array_type, baseType: !266, size: 128, elements: !370)
!2671 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_scope_id", scope: !2650, file: !2651, line: 268, baseType: !266, size: 32, offset: 192)
!2672 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !2460, file: !6, line: 798, baseType: !2673, size: 32, offset: 1248)
!2673 = !DIDerivedType(tag: DW_TAG_typedef, name: "socklen_t", file: !2674, line: 33, baseType: !2675)
!2674 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/socket.h", directory: "", checksumkind: CSK_MD5, checksum: "71a09f67661e8e55cf505c19b5ddbb85")
!2675 = !DIDerivedType(tag: DW_TAG_typedef, name: "__socklen_t", file: !120, line: 210, baseType: !7)
!2676 = !DIDerivedType(tag: DW_TAG_member, name: "wbuf", scope: !2460, file: !6, line: 800, baseType: !2677, size: 8192, offset: 1280)
!2677 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 8192, elements: !2678)
!2678 = !{!2679}
!2679 = !DISubrange(count: 1024)
!2680 = !DIDerivedType(tag: DW_TAG_member, name: "resp_head", scope: !2359, file: !6, line: 857, baseType: !2458, size: 64, offset: 1600)
!2681 = !DIDerivedType(tag: DW_TAG_member, name: "ritem", scope: !2359, file: !6, line: 858, baseType: !147, size: 64, offset: 1664)
!2682 = !DIDerivedType(tag: DW_TAG_member, name: "rlbytes", scope: !2359, file: !6, line: 859, baseType: !113, size: 32, offset: 1728)
!2683 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !2359, file: !6, line: 867, baseType: !94, size: 64, offset: 1792)
!2684 = !DIDerivedType(tag: DW_TAG_member, name: "sbytes", scope: !2359, file: !6, line: 870, baseType: !113, size: 32, offset: 1856)
!2685 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues_submitted", scope: !2359, file: !6, line: 872, baseType: !113, size: 32, offset: 1888)
!2686 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !2359, file: !6, line: 873, baseType: !2687, size: 576, offset: 1920)
!2687 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2579, size: 576, elements: !344)
!2688 = !DIDerivedType(tag: DW_TAG_member, name: "recache_counter", scope: !2359, file: !6, line: 878, baseType: !7, size: 32, offset: 2496)
!2689 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !2359, file: !6, line: 880, baseType: !58, size: 32, offset: 2528)
!2690 = !DIDerivedType(tag: DW_TAG_member, name: "transport", scope: !2359, file: !6, line: 881, baseType: !63, size: 32, offset: 2560)
!2691 = !DIDerivedType(tag: DW_TAG_member, name: "close_reason", scope: !2359, file: !6, line: 882, baseType: !68, size: 32, offset: 2592)
!2692 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !2359, file: !6, line: 885, baseType: !113, size: 32, offset: 2624)
!2693 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !2359, file: !6, line: 886, baseType: !2650, size: 224, offset: 2656)
!2694 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !2359, file: !6, line: 887, baseType: !2673, size: 32, offset: 2880)
!2695 = !DIDerivedType(tag: DW_TAG_member, name: "noreply", scope: !2359, file: !6, line: 889, baseType: !455, size: 8, offset: 2912)
!2696 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !2359, file: !6, line: 895, baseType: !2697, size: 192, offset: 2944)
!2697 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2359, file: !6, line: 891, size: 192, elements: !2698)
!2698 = !{!2699, !2700, !2701}
!2699 = !DIDerivedType(tag: DW_TAG_member, name: "buffer", scope: !2697, file: !6, line: 892, baseType: !147, size: 64)
!2700 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !2697, file: !6, line: 893, baseType: !148, size: 64, offset: 64)
!2701 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !2697, file: !6, line: 894, baseType: !148, size: 64, offset: 128)
!2702 = !DIDerivedType(tag: DW_TAG_member, name: "binary_header", scope: !2359, file: !6, line: 899, baseType: !2703, size: 192, offset: 3136)
!2703 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_request_header", file: !2704, line: 164, baseType: !2705)
!2704 = !DIFile(filename: "./protocol_binary.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "7a322a65fa8661e9a597acbeeeb23107")
!2705 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !2704, line: 151, size: 192, elements: !2706)
!2706 = !{!2707, !2719}
!2707 = !DIDerivedType(tag: DW_TAG_member, name: "request", scope: !2705, file: !2704, line: 162, baseType: !2708, size: 192)
!2708 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2705, file: !2704, line: 152, size: 192, elements: !2709)
!2709 = !{!2710, !2711, !2712, !2713, !2714, !2715, !2716, !2717, !2718}
!2710 = !DIDerivedType(tag: DW_TAG_member, name: "magic", scope: !2708, file: !2704, line: 153, baseType: !122, size: 8)
!2711 = !DIDerivedType(tag: DW_TAG_member, name: "opcode", scope: !2708, file: !2704, line: 154, baseType: !122, size: 8, offset: 8)
!2712 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !2708, file: !2704, line: 155, baseType: !117, size: 16, offset: 16)
!2713 = !DIDerivedType(tag: DW_TAG_member, name: "extlen", scope: !2708, file: !2704, line: 156, baseType: !122, size: 8, offset: 32)
!2714 = !DIDerivedType(tag: DW_TAG_member, name: "datatype", scope: !2708, file: !2704, line: 157, baseType: !122, size: 8, offset: 40)
!2715 = !DIDerivedType(tag: DW_TAG_member, name: "reserved", scope: !2708, file: !2704, line: 158, baseType: !117, size: 16, offset: 48)
!2716 = !DIDerivedType(tag: DW_TAG_member, name: "bodylen", scope: !2708, file: !2704, line: 159, baseType: !266, size: 32, offset: 64)
!2717 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !2708, file: !2704, line: 160, baseType: !266, size: 32, offset: 96)
!2718 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !2708, file: !2704, line: 161, baseType: !131, size: 64, offset: 128)
!2719 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !2705, file: !2704, line: 163, baseType: !2720, size: 192)
!2720 = !DICompositeType(tag: DW_TAG_array_type, baseType: !122, size: 192, elements: !2721)
!2721 = !{!2722}
!2722 = !DISubrange(count: 24)
!2723 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !2359, file: !6, line: 900, baseType: !131, size: 64, offset: 3328)
!2724 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !2359, file: !6, line: 901, baseType: !131, size: 64, offset: 3392)
!2725 = !DIDerivedType(tag: DW_TAG_member, name: "cmd", scope: !2359, file: !6, line: 902, baseType: !173, size: 16, offset: 3456)
!2726 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !2359, file: !6, line: 903, baseType: !113, size: 32, offset: 3488)
!2727 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !2359, file: !6, line: 904, baseType: !113, size: 32, offset: 3520)
!2728 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !2359, file: !6, line: 905, baseType: !2357, size: 64, offset: 3584)
!2729 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !2359, file: !6, line: 906, baseType: !2470, size: 64, offset: 3648)
!2730 = !DIDerivedType(tag: DW_TAG_member, name: "try_read_command", scope: !2359, file: !6, line: 907, baseType: !2731, size: 64, offset: 3712)
!2731 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2732, size: 64)
!2732 = !DISubroutineType(types: !2733)
!2733 = !{!113, !2357}
!2734 = !DIDerivedType(tag: DW_TAG_member, name: "read", scope: !2359, file: !6, line: 908, baseType: !2735, size: 64, offset: 3776)
!2735 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2736, size: 64)
!2736 = !DISubroutineType(types: !2737)
!2737 = !{!2738, !2357, !94, !148}
!2738 = !DIDerivedType(tag: DW_TAG_typedef, name: "ssize_t", file: !2739, line: 108, baseType: !2740)
!2739 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/types.h", directory: "", checksumkind: CSK_MD5, checksum: "7fb02a803b0c9b11cb5276b77d21e9d8")
!2740 = !DIDerivedType(tag: DW_TAG_typedef, name: "__ssize_t", file: !120, line: 194, baseType: !188)
!2741 = !DIDerivedType(tag: DW_TAG_member, name: "sendmsg", scope: !2359, file: !6, line: 909, baseType: !2742, size: 64, offset: 3840)
!2742 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2743, size: 64)
!2743 = !DISubroutineType(types: !2744)
!2744 = !{!2738, !2357, !2745, !113}
!2745 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2746, size: 64)
!2746 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "msghdr", file: !2674, line: 262, size: 448, elements: !2747)
!2747 = !{!2748, !2749, !2750, !2752, !2753, !2754, !2755}
!2748 = !DIDerivedType(tag: DW_TAG_member, name: "msg_name", scope: !2746, file: !2674, line: 264, baseType: !94, size: 64)
!2749 = !DIDerivedType(tag: DW_TAG_member, name: "msg_namelen", scope: !2746, file: !2674, line: 265, baseType: !2673, size: 32, offset: 64)
!2750 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iov", scope: !2746, file: !2674, line: 267, baseType: !2751, size: 64, offset: 128)
!2751 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2636, size: 64)
!2752 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iovlen", scope: !2746, file: !2674, line: 268, baseType: !148, size: 64, offset: 192)
!2753 = !DIDerivedType(tag: DW_TAG_member, name: "msg_control", scope: !2746, file: !2674, line: 270, baseType: !94, size: 64, offset: 256)
!2754 = !DIDerivedType(tag: DW_TAG_member, name: "msg_controllen", scope: !2746, file: !2674, line: 271, baseType: !148, size: 64, offset: 320)
!2755 = !DIDerivedType(tag: DW_TAG_member, name: "msg_flags", scope: !2746, file: !2674, line: 276, baseType: !113, size: 32, offset: 384)
!2756 = !DIDerivedType(tag: DW_TAG_member, name: "write", scope: !2359, file: !6, line: 910, baseType: !2735, size: 64, offset: 3904)
!2757 = distinct !DISubprogram(name: "item_stats", scope: !3, file: !3, line: 788, type: !2260, scopeLine: 788, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2758)
!2758 = !{!2759, !2760, !2761, !2762, !2763, !2764, !2768, !2769, !2770, !2771, !2772, !2773, !2774, !2775, !2779, !2780, !2781}
!2759 = !DILocalVariable(name: "add_stats", arg: 1, scope: !2757, file: !3, line: 788, type: !2262)
!2760 = !DILocalVariable(name: "c", arg: 2, scope: !2757, file: !3, line: 788, type: !94)
!2761 = !DILocalVariable(name: "thread_stats", scope: !2757, file: !3, line: 789, type: !2516)
!2762 = !DILocalVariable(name: "totals", scope: !2757, file: !3, line: 791, type: !672)
!2763 = !DILocalVariable(name: "n", scope: !2757, file: !3, line: 792, type: !113)
!2764 = !DILocalVariable(name: "x", scope: !2765, file: !3, line: 795, type: !113)
!2765 = distinct !DILexicalBlock(scope: !2766, file: !3, line: 793, column: 54)
!2766 = distinct !DILexicalBlock(scope: !2767, file: !3, line: 793, column: 5)
!2767 = distinct !DILexicalBlock(scope: !2757, file: !3, line: 793, column: 5)
!2768 = !DILocalVariable(name: "i", scope: !2765, file: !3, line: 796, type: !113)
!2769 = !DILocalVariable(name: "size", scope: !2765, file: !3, line: 797, type: !7)
!2770 = !DILocalVariable(name: "age", scope: !2765, file: !3, line: 798, type: !7)
!2771 = !DILocalVariable(name: "age_hot", scope: !2765, file: !3, line: 799, type: !7)
!2772 = !DILocalVariable(name: "age_warm", scope: !2765, file: !3, line: 800, type: !7)
!2773 = !DILocalVariable(name: "lru_size_map", scope: !2765, file: !3, line: 801, type: !558)
!2774 = !DILocalVariable(name: "fmt", scope: !2765, file: !3, line: 802, type: !1320)
!2775 = !DILocalVariable(name: "key_str", scope: !2765, file: !3, line: 803, type: !2776)
!2776 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 1024, elements: !2777)
!2777 = !{!2778}
!2778 = !DISubrange(count: 128)
!2779 = !DILocalVariable(name: "val_str", scope: !2765, file: !3, line: 804, type: !2776)
!2780 = !DILocalVariable(name: "klen", scope: !2765, file: !3, line: 805, type: !113)
!2781 = !DILocalVariable(name: "vlen", scope: !2765, file: !3, line: 805, type: !113)
!2782 = distinct !DIAssignID()
!2783 = !DILocation(line: 0, scope: !2757)
!2784 = distinct !DIAssignID()
!2785 = !DILocation(line: 0, scope: !2765)
!2786 = distinct !DIAssignID()
!2787 = distinct !DIAssignID()
!2788 = !DILocation(line: 789, column: 5, scope: !2757)
!2789 = !DILocation(line: 790, column: 5, scope: !2757)
!2790 = !DILocation(line: 793, column: 5, scope: !2767)
!2791 = !DILocation(line: 801, column: 9, scope: !2765)
!2792 = !DILocation(line: 803, column: 9, scope: !2765)
!2793 = !DILocation(line: 804, column: 9, scope: !2765)
!2794 = !DILocation(line: 806, column: 9, scope: !2795)
!2795 = distinct !DILexicalBlock(scope: !2765, file: !3, line: 806, column: 9)
!2796 = !DILocation(line: 807, column: 21, scope: !2797)
!2797 = distinct !DILexicalBlock(scope: !2798, file: !3, line: 806, column: 33)
!2798 = distinct !DILexicalBlock(scope: !2795, file: !3, line: 806, column: 9)
!2799 = !DILocation(line: 807, column: 19, scope: !2797)
!2800 = !DILocation(line: 808, column: 33, scope: !2797)
!2801 = !DILocation(line: 808, column: 13, scope: !2797)
!2802 = !DILocation(line: 809, column: 31, scope: !2797)
!2803 = !DILocation(line: 809, column: 44, scope: !2797)
!2804 = !DILocation(line: 809, column: 28, scope: !2797)
!2805 = !DILocation(line: 810, column: 52, scope: !2797)
!2806 = !DILocation(line: 810, column: 36, scope: !2797)
!2807 = !DILocation(line: 811, column: 46, scope: !2797)
!2808 = !DILocation(line: 811, column: 30, scope: !2797)
!2809 = !DILocation(line: 812, column: 48, scope: !2797)
!2810 = !DILocation(line: 812, column: 32, scope: !2797)
!2811 = !DILocation(line: 813, column: 48, scope: !2797)
!2812 = !DILocation(line: 813, column: 32, scope: !2797)
!2813 = !DILocation(line: 814, column: 54, scope: !2797)
!2814 = !DILocation(line: 814, column: 38, scope: !2797)
!2815 = !DILocation(line: 815, column: 54, scope: !2797)
!2816 = !DILocation(line: 815, column: 38, scope: !2797)
!2817 = !DILocation(line: 816, column: 51, scope: !2797)
!2818 = !DILocation(line: 816, column: 35, scope: !2797)
!2819 = !DILocation(line: 817, column: 54, scope: !2797)
!2820 = !DILocation(line: 817, column: 38, scope: !2797)
!2821 = !DILocation(line: 818, column: 58, scope: !2797)
!2822 = !DILocation(line: 818, column: 42, scope: !2797)
!2823 = !DILocation(line: 819, column: 54, scope: !2797)
!2824 = !DILocation(line: 819, column: 38, scope: !2797)
!2825 = !DILocation(line: 820, column: 50, scope: !2797)
!2826 = !DILocation(line: 820, column: 34, scope: !2797)
!2827 = !DILocation(line: 821, column: 50, scope: !2797)
!2828 = !DILocation(line: 821, column: 34, scope: !2797)
!2829 = !DILocation(line: 822, column: 53, scope: !2797)
!2830 = !DILocation(line: 822, column: 37, scope: !2797)
!2831 = !DILocation(line: 823, column: 52, scope: !2797)
!2832 = !DILocation(line: 823, column: 36, scope: !2797)
!2833 = !DILocation(line: 824, column: 37, scope: !2797)
!2834 = !DILocation(line: 824, column: 34, scope: !2797)
!2835 = !DILocation(line: 825, column: 21, scope: !2797)
!2836 = !DILocation(line: 825, column: 18, scope: !2797)
!2837 = !DILocation(line: 826, column: 13, scope: !2797)
!2838 = !DILocation(line: 826, column: 29, scope: !2797)
!2839 = !DILocation(line: 827, column: 45, scope: !2840)
!2840 = distinct !DILexicalBlock(scope: !2797, file: !3, line: 827, column: 17)
!2841 = !DILocation(line: 827, column: 48, scope: !2840)
!2842 = !DILocation(line: 827, column: 57, scope: !2840)
!2843 = !DILocation(line: 827, column: 17, scope: !2797)
!2844 = !DILocation(line: 828, column: 23, scope: !2845)
!2845 = distinct !DILexicalBlock(scope: !2840, file: !3, line: 827, column: 66)
!2846 = !DILocation(line: 828, column: 48, scope: !2845)
!2847 = !DILocation(line: 828, column: 36, scope: !2845)
!2848 = !DILocation(line: 829, column: 13, scope: !2845)
!2849 = !DILocation(line: 829, column: 54, scope: !2850)
!2850 = distinct !DILexicalBlock(scope: !2840, file: !3, line: 829, column: 24)
!2851 = !DILocation(line: 829, column: 63, scope: !2850)
!2852 = !DILocation(line: 829, column: 24, scope: !2840)
!2853 = !DILocation(line: 830, column: 27, scope: !2854)
!2854 = distinct !DILexicalBlock(scope: !2850, file: !3, line: 829, column: 72)
!2855 = !DILocation(line: 830, column: 52, scope: !2854)
!2856 = !DILocation(line: 830, column: 40, scope: !2854)
!2857 = !DILocation(line: 831, column: 13, scope: !2854)
!2858 = !DILocation(line: 831, column: 55, scope: !2859)
!2859 = distinct !DILexicalBlock(scope: !2850, file: !3, line: 831, column: 24)
!2860 = !DILocation(line: 831, column: 64, scope: !2859)
!2861 = !DILocation(line: 831, column: 24, scope: !2850)
!2862 = !DILocation(line: 832, column: 28, scope: !2863)
!2863 = distinct !DILexicalBlock(scope: !2859, file: !3, line: 831, column: 73)
!2864 = !DILocation(line: 832, column: 53, scope: !2863)
!2865 = !DILocation(line: 832, column: 41, scope: !2863)
!2866 = !DILocation(line: 833, column: 13, scope: !2863)
!2867 = !DILocation(line: 835, column: 52, scope: !2868)
!2868 = distinct !DILexicalBlock(scope: !2797, file: !3, line: 834, column: 17)
!2869 = !DILocation(line: 835, column: 17, scope: !2868)
!2870 = !DILocation(line: 836, column: 13, scope: !2797)
!2871 = !DILocation(line: 838, column: 42, scope: !2872)
!2872 = distinct !DILexicalBlock(scope: !2797, file: !3, line: 836, column: 38)
!2873 = !DILocation(line: 839, column: 21, scope: !2872)
!2874 = !DILocation(line: 841, column: 43, scope: !2872)
!2875 = !DILocation(line: 842, column: 21, scope: !2872)
!2876 = !DILocation(line: 844, column: 43, scope: !2872)
!2877 = !DILocation(line: 845, column: 21, scope: !2872)
!2878 = !DILocation(line: 847, column: 43, scope: !2872)
!2879 = !DILocation(line: 848, column: 21, scope: !2872)
!2880 = !DILocation(line: 850, column: 13, scope: !2797)
!2881 = !DILocation(line: 806, column: 29, scope: !2798)
!2882 = !DILocation(line: 806, column: 23, scope: !2798)
!2883 = distinct !{!2883, !2794, !2884, !723}
!2884 = !DILocation(line: 851, column: 9, scope: !2795)
!2885 = !DILocation(line: 852, column: 18, scope: !2886)
!2886 = distinct !DILexicalBlock(scope: !2765, file: !3, line: 852, column: 13)
!2887 = !DILocation(line: 852, column: 13, scope: !2765)
!2888 = !DILocation(line: 854, column: 9, scope: !2765)
!2889 = !DILocation(line: 855, column: 22, scope: !2890)
!2890 = distinct !DILexicalBlock(scope: !2765, file: !3, line: 855, column: 13)
!2891 = !DILocation(line: 855, column: 13, scope: !2765)
!2892 = !DILocation(line: 856, column: 13, scope: !2893)
!2893 = distinct !DILexicalBlock(scope: !2890, file: !3, line: 855, column: 45)
!2894 = !DILocation(line: 857, column: 13, scope: !2893)
!2895 = !DILocation(line: 858, column: 13, scope: !2893)
!2896 = !DILocation(line: 859, column: 26, scope: !2897)
!2897 = distinct !DILexicalBlock(scope: !2893, file: !3, line: 859, column: 17)
!2898 = !DILocation(line: 859, column: 17, scope: !2893)
!2899 = !DILocation(line: 860, column: 17, scope: !2900)
!2900 = distinct !DILexicalBlock(scope: !2897, file: !3, line: 859, column: 36)
!2901 = !DILocation(line: 861, column: 13, scope: !2900)
!2902 = !DILocation(line: 862, column: 13, scope: !2893)
!2903 = !DILocation(line: 863, column: 13, scope: !2893)
!2904 = !DILocation(line: 864, column: 9, scope: !2893)
!2905 = !DILocation(line: 865, column: 9, scope: !2765)
!2906 = !DILocation(line: 866, column: 9, scope: !2765)
!2907 = !DILocation(line: 867, column: 9, scope: !2765)
!2908 = !DILocation(line: 869, column: 9, scope: !2765)
!2909 = !DILocation(line: 871, column: 9, scope: !2765)
!2910 = !DILocation(line: 873, column: 9, scope: !2765)
!2911 = !DILocation(line: 875, column: 9, scope: !2765)
!2912 = !DILocation(line: 877, column: 9, scope: !2765)
!2913 = !DILocation(line: 879, column: 9, scope: !2765)
!2914 = !DILocation(line: 881, column: 9, scope: !2765)
!2915 = !DILocation(line: 883, column: 22, scope: !2916)
!2916 = distinct !DILexicalBlock(scope: !2765, file: !3, line: 883, column: 13)
!2917 = !DILocation(line: 883, column: 13, scope: !2765)
!2918 = !DILocation(line: 884, column: 13, scope: !2919)
!2919 = distinct !DILexicalBlock(scope: !2916, file: !3, line: 883, column: 45)
!2920 = !DILocation(line: 886, column: 9, scope: !2919)
!2921 = !DILocation(line: 887, column: 9, scope: !2765)
!2922 = !DILocation(line: 889, column: 9, scope: !2765)
!2923 = !DILocation(line: 891, column: 9, scope: !2765)
!2924 = !DILocation(line: 893, column: 22, scope: !2925)
!2925 = distinct !DILexicalBlock(scope: !2765, file: !3, line: 893, column: 13)
!2926 = !DILocation(line: 893, column: 13, scope: !2765)
!2927 = !DILocation(line: 894, column: 13, scope: !2928)
!2928 = distinct !DILexicalBlock(scope: !2925, file: !3, line: 893, column: 45)
!2929 = !DILocation(line: 896, column: 13, scope: !2928)
!2930 = !DILocation(line: 898, column: 13, scope: !2928)
!2931 = !DILocation(line: 900, column: 13, scope: !2928)
!2932 = !DILocation(line: 902, column: 13, scope: !2928)
!2933 = !DILocation(line: 905, column: 13, scope: !2928)
!2934 = !DILocation(line: 908, column: 13, scope: !2928)
!2935 = !DILocation(line: 911, column: 13, scope: !2928)
!2936 = !DILocation(line: 914, column: 9, scope: !2928)
!2937 = !DILocation(line: 915, column: 5, scope: !2766)
!2938 = !DILocation(line: 793, column: 50, scope: !2766)
!2939 = !DILocation(line: 793, column: 19, scope: !2766)
!2940 = distinct !{!2940, !2790, !2941, !723}
!2941 = !DILocation(line: 915, column: 5, scope: !2767)
!2942 = !DILocation(line: 918, column: 5, scope: !2757)
!2943 = !DILocation(line: 919, column: 1, scope: !2757)
!2944 = !DISubprogram(name: "threadlocal_stats_aggregate", scope: !6, file: !6, line: 1031, type: !2945, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2945 = !DISubroutineType(types: !2946)
!2946 = !{null, !2947}
!2947 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2516, size: 64)
!2948 = distinct !DISubprogram(name: "item_stats_sizes_status", scope: !3, file: !3, line: 921, type: !2949, scopeLine: 921, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2951)
!2949 = !DISubroutineType(types: !2950)
!2950 = !{!455}
!2951 = !{!2952}
!2952 = !DILocalVariable(name: "ret", scope: !2948, file: !3, line: 922, type: !455)
!2953 = !DILocation(line: 0, scope: !2948)
!2954 = !DILocation(line: 923, column: 9, scope: !2955)
!2955 = distinct !DILexicalBlock(scope: !2948, file: !3, line: 923, column: 9)
!2956 = !DILocation(line: 923, column: 26, scope: !2955)
!2957 = !DILocation(line: 925, column: 5, scope: !2948)
!2958 = distinct !DISubprogram(name: "item_stats_sizes_init", scope: !3, file: !3, line: 928, type: !705, scopeLine: 928, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!2959 = !DILocation(line: 929, column: 9, scope: !2960)
!2960 = distinct !DILexicalBlock(scope: !2958, file: !3, line: 929, column: 9)
!2961 = !DILocation(line: 929, column: 26, scope: !2960)
!2962 = !DILocation(line: 929, column: 9, scope: !2958)
!2963 = !DILocation(line: 931, column: 36, scope: !2958)
!2964 = !{!788, !750, i64 116}
!2965 = !DILocation(line: 931, column: 50, scope: !2958)
!2966 = !DILocation(line: 931, column: 55, scope: !2958)
!2967 = !DILocation(line: 931, column: 25, scope: !2958)
!2968 = !DILocation(line: 932, column: 31, scope: !2958)
!2969 = !DILocation(line: 932, column: 24, scope: !2958)
!2970 = !DILocation(line: 932, column: 22, scope: !2958)
!2971 = !DILocation(line: 933, column: 1, scope: !2958)
!2972 = !DISubprogram(name: "calloc", scope: !2179, file: !2179, line: 675, type: !2973, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2973 = !DISubroutineType(types: !2974)
!2974 = !{!94, !148, !148}
!2975 = distinct !DISubprogram(name: "item_stats_sizes", scope: !3, file: !3, line: 962, type: !2260, scopeLine: 962, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2976)
!2976 = !{!2977, !2978, !2979, !2982}
!2977 = !DILocalVariable(name: "add_stats", arg: 1, scope: !2975, file: !3, line: 962, type: !2262)
!2978 = !DILocalVariable(name: "c", arg: 2, scope: !2975, file: !3, line: 962, type: !94)
!2979 = !DILocalVariable(name: "i", scope: !2980, file: !3, line: 964, type: !113)
!2980 = distinct !DILexicalBlock(scope: !2981, file: !3, line: 963, column: 35)
!2981 = distinct !DILexicalBlock(scope: !2975, file: !3, line: 963, column: 9)
!2982 = !DILocalVariable(name: "key", scope: !2983, file: !3, line: 967, type: !333)
!2983 = distinct !DILexicalBlock(scope: !2984, file: !3, line: 966, column: 43)
!2984 = distinct !DILexicalBlock(scope: !2985, file: !3, line: 966, column: 17)
!2985 = distinct !DILexicalBlock(scope: !2986, file: !3, line: 965, column: 51)
!2986 = distinct !DILexicalBlock(scope: !2987, file: !3, line: 965, column: 9)
!2987 = distinct !DILexicalBlock(scope: !2980, file: !3, line: 965, column: 9)
!2988 = distinct !DIAssignID()
!2989 = !DILocation(line: 0, scope: !2983)
!2990 = !DILocation(line: 0, scope: !2975)
!2991 = !DILocation(line: 963, column: 9, scope: !2981)
!2992 = !DILocation(line: 963, column: 26, scope: !2981)
!2993 = !DILocation(line: 963, column: 9, scope: !2975)
!2994 = !DILocation(line: 0, scope: !2980)
!2995 = !DILocation(line: 965, column: 25, scope: !2986)
!2996 = !DILocation(line: 965, column: 23, scope: !2986)
!2997 = !DILocation(line: 965, column: 9, scope: !2987)
!2998 = !DILocation(line: 966, column: 17, scope: !2984)
!2999 = !DILocation(line: 966, column: 37, scope: !2984)
!3000 = !DILocation(line: 966, column: 17, scope: !2985)
!3001 = !DILocation(line: 967, column: 17, scope: !2983)
!3002 = !DILocation(line: 968, column: 17, scope: !2983)
!3003 = !DILocation(line: 969, column: 17, scope: !2983)
!3004 = !DILocation(line: 970, column: 13, scope: !2984)
!3005 = !DILocation(line: 970, column: 13, scope: !2983)
!3006 = !DILocation(line: 965, column: 47, scope: !2986)
!3007 = distinct !{!3007, !2997, !3008, !723}
!3008 = !DILocation(line: 971, column: 9, scope: !2987)
!3009 = !DILocation(line: 973, column: 9, scope: !3010)
!3010 = distinct !DILexicalBlock(scope: !2981, file: !3, line: 972, column: 12)
!3011 = !DILocation(line: 976, column: 5, scope: !2975)
!3012 = !DILocation(line: 977, column: 1, scope: !2975)
!3013 = distinct !DISubprogram(name: "do_item_get", scope: !3, file: !3, line: 980, type: !3014, scopeLine: 980, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3017)
!3014 = !DISubroutineType(types: !3015)
!3015 = !{!263, !1320, !813, !1579, !2470, !3016}
!3016 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !455)
!3017 = !{!3018, !3019, !3020, !3021, !3022, !3023, !3024, !3025, !3028}
!3018 = !DILocalVariable(name: "key", arg: 1, scope: !3013, file: !3, line: 980, type: !1320)
!3019 = !DILocalVariable(name: "nkey", arg: 2, scope: !3013, file: !3, line: 980, type: !813)
!3020 = !DILocalVariable(name: "hv", arg: 3, scope: !3013, file: !3, line: 980, type: !1579)
!3021 = !DILocalVariable(name: "t", arg: 4, scope: !3013, file: !3, line: 980, type: !2470)
!3022 = !DILocalVariable(name: "do_update", arg: 5, scope: !3013, file: !3, line: 980, type: !3016)
!3023 = !DILocalVariable(name: "it", scope: !3013, file: !3, line: 981, type: !263)
!3024 = !DILocalVariable(name: "was_found", scope: !3013, file: !3, line: 1005, type: !113)
!3025 = !DILocalVariable(name: "ii", scope: !3026, file: !3, line: 1008, type: !113)
!3026 = distinct !DILexicalBlock(scope: !3027, file: !3, line: 1007, column: 31)
!3027 = distinct !DILexicalBlock(scope: !3013, file: !3, line: 1007, column: 9)
!3028 = !DILocalVariable(name: "myl", scope: !3029, file: !3, line: 1056, type: !151)
!3029 = distinct !DILexicalBlock(scope: !3013, file: !3, line: 1056, column: 5)
!3030 = !DILocation(line: 0, scope: !3013)
!3031 = !DILocation(line: 981, column: 16, scope: !3013)
!3032 = !DILocation(line: 982, column: 12, scope: !3033)
!3033 = distinct !DILexicalBlock(scope: !3013, file: !3, line: 982, column: 9)
!3034 = !DILocation(line: 982, column: 9, scope: !3013)
!3035 = !DILocation(line: 1007, column: 18, scope: !3027)
!3036 = !{!788, !750, i64 32}
!3037 = !DILocation(line: 1007, column: 26, scope: !3027)
!3038 = !DILocation(line: 1007, column: 9, scope: !3013)
!3039 = !DILocation(line: 983, column: 9, scope: !3040)
!3040 = distinct !DILexicalBlock(scope: !3033, file: !3, line: 982, column: 21)
!3041 = !DILocation(line: 1010, column: 21, scope: !3042)
!3042 = distinct !DILexicalBlock(scope: !3043, file: !3, line: 1009, column: 25)
!3043 = distinct !DILexicalBlock(scope: !3026, file: !3, line: 1009, column: 13)
!3044 = !DILocation(line: 1010, column: 13, scope: !3042)
!3045 = !DILocation(line: 1011, column: 9, scope: !3042)
!3046 = !DILocation(line: 0, scope: !3026)
!3047 = !DILocation(line: 1014, column: 25, scope: !3048)
!3048 = distinct !DILexicalBlock(scope: !3049, file: !3, line: 1014, column: 9)
!3049 = distinct !DILexicalBlock(scope: !3026, file: !3, line: 1014, column: 9)
!3050 = !DILocation(line: 1014, column: 9, scope: !3049)
!3051 = !DILocation(line: 1015, column: 21, scope: !3052)
!3052 = distinct !DILexicalBlock(scope: !3048, file: !3, line: 1014, column: 39)
!3053 = !DILocation(line: 1015, column: 35, scope: !3052)
!3054 = !DILocation(line: 1015, column: 13, scope: !3052)
!3055 = !DILocation(line: 1014, column: 33, scope: !3048)
!3056 = distinct !{!3056, !3050, !3057, !723}
!3057 = !DILocation(line: 1016, column: 9, scope: !3049)
!3058 = !DILocation(line: 1019, column: 9, scope: !3013)
!3059 = !DILocation(line: 0, scope: !779, inlinedAt: !3060)
!3060 = distinct !DILocation(line: 1021, column: 13, scope: !3061)
!3061 = distinct !DILexicalBlock(scope: !3062, file: !3, line: 1021, column: 13)
!3062 = distinct !DILexicalBlock(scope: !3063, file: !3, line: 1019, column: 21)
!3063 = distinct !DILexicalBlock(scope: !3013, file: !3, line: 1019, column: 9)
!3064 = !DILocation(line: 123, column: 39, scope: !779, inlinedAt: !3060)
!3065 = !DILocation(line: 124, column: 13, scope: !793, inlinedAt: !3060)
!3066 = !DILocation(line: 124, column: 18, scope: !793, inlinedAt: !3060)
!3067 = !DILocation(line: 124, column: 33, scope: !793, inlinedAt: !3060)
!3068 = !DILocation(line: 124, column: 51, scope: !793, inlinedAt: !3060)
!3069 = !DILocation(line: 124, column: 48, scope: !793, inlinedAt: !3060)
!3070 = !DILocation(line: 124, column: 9, scope: !779, inlinedAt: !3060)
!3071 = !DILocation(line: 1022, column: 13, scope: !3072)
!3072 = distinct !DILexicalBlock(scope: !3061, file: !3, line: 1021, column: 34)
!3073 = !DILocation(line: 1023, column: 13, scope: !3074)
!3074 = distinct !DILexicalBlock(scope: !3072, file: !3, line: 1023, column: 13)
!3075 = !{!3076, !789, i64 6904}
!3076 = !{!"", !747, i64 0, !789, i64 8, !3077, i64 16, !3077, i64 152, !748, i64 288, !3081, i64 328, !750, i64 344, !750, i64 348, !3082, i64 352, !748, i64 6800, !789, i64 6872, !789, i64 6880, !789, i64 6888, !789, i64 6896, !789, i64 6904, !789, i64 6912, !789, i64 6920, !750, i64 6928}
!3077 = !{!"thread_notify", !3078, i64 0, !750, i64 128}
!3078 = !{!"event", !3079, i64 0, !748, i64 40, !750, i64 56, !789, i64 64, !748, i64 72, !921, i64 104, !921, i64 106, !1550, i64 112}
!3079 = !{!"event_callback", !3080, i64 0, !921, i64 16, !748, i64 18, !748, i64 19, !748, i64 24, !789, i64 32}
!3080 = !{!"", !789, i64 0, !789, i64 8}
!3081 = !{!"iop_head_s", !789, i64 0, !789, i64 8}
!3082 = !{!"thread_stats", !748, i64 0, !747, i64 40, !747, i64 48, !747, i64 56, !747, i64 64, !747, i64 72, !747, i64 80, !747, i64 88, !747, i64 96, !747, i64 104, !747, i64 112, !747, i64 120, !747, i64 128, !747, i64 136, !747, i64 144, !747, i64 152, !747, i64 160, !747, i64 168, !747, i64 176, !747, i64 184, !747, i64 192, !747, i64 200, !747, i64 208, !747, i64 216, !747, i64 224, !747, i64 232, !747, i64 240, !747, i64 248, !747, i64 256, !747, i64 264, !747, i64 272, !748, i64 280, !748, i64 4376, !747, i64 6424, !747, i64 6432, !747, i64 6440}
!3083 = !DILocation(line: 0, scope: !997, inlinedAt: !3084)
!3084 = distinct !DILocation(line: 1024, column: 13, scope: !3072)
!3085 = !DILocation(line: 549, column: 9, scope: !1004, inlinedAt: !3084)
!3086 = !DILocation(line: 549, column: 27, scope: !1004, inlinedAt: !3084)
!3087 = !DILocation(line: 549, column: 9, scope: !997, inlinedAt: !3084)
!3088 = !DILocation(line: 0, scope: !1008, inlinedAt: !3089)
!3089 = distinct !DILocation(line: 550, column: 9, scope: !1014, inlinedAt: !3084)
!3090 = !DILocation(line: 356, column: 21, scope: !1008, inlinedAt: !3089)
!3091 = !DILocation(line: 364, column: 13, scope: !1008, inlinedAt: !3089)
!3092 = !DILocation(line: 366, column: 5, scope: !1008, inlinedAt: !3089)
!3093 = !DILocation(line: 551, column: 5, scope: !1014, inlinedAt: !3084)
!3094 = !DILocation(line: 1026, column: 36, scope: !3072)
!3095 = !DILocation(line: 1026, column: 13, scope: !3072)
!3096 = !DILocation(line: 1027, column: 22, scope: !3072)
!3097 = !DILocation(line: 1027, column: 33, scope: !3072)
!3098 = !{!3076, !747, i64 416}
!3099 = !DILocation(line: 1028, column: 13, scope: !3072)
!3100 = !DILocation(line: 1029, column: 26, scope: !3101)
!3101 = distinct !DILexicalBlock(scope: !3072, file: !3, line: 1029, column: 17)
!3102 = !DILocation(line: 1029, column: 34, scope: !3101)
!3103 = !DILocation(line: 1029, column: 17, scope: !3072)
!3104 = !DILocation(line: 1030, column: 25, scope: !3105)
!3105 = distinct !DILexicalBlock(scope: !3101, file: !3, line: 1029, column: 39)
!3106 = !DILocation(line: 1030, column: 17, scope: !3105)
!3107 = !DILocation(line: 1031, column: 13, scope: !3105)
!3108 = !DILocation(line: 1033, column: 24, scope: !3109)
!3109 = distinct !DILexicalBlock(scope: !3061, file: !3, line: 1033, column: 20)
!3110 = !DILocation(line: 1033, column: 32, scope: !3109)
!3111 = !DILocation(line: 1033, column: 37, scope: !3109)
!3112 = !DILocation(line: 1033, column: 55, scope: !3109)
!3113 = !DILocation(line: 1033, column: 52, scope: !3109)
!3114 = !DILocation(line: 1033, column: 20, scope: !3061)
!3115 = !DILocation(line: 1034, column: 13, scope: !3116)
!3116 = distinct !DILexicalBlock(scope: !3109, file: !3, line: 1033, column: 69)
!3117 = !DILocation(line: 1035, column: 13, scope: !3118)
!3118 = distinct !DILexicalBlock(scope: !3116, file: !3, line: 1035, column: 13)
!3119 = !DILocation(line: 0, scope: !997, inlinedAt: !3120)
!3120 = distinct !DILocation(line: 1036, column: 13, scope: !3116)
!3121 = !DILocation(line: 549, column: 9, scope: !1004, inlinedAt: !3120)
!3122 = !DILocation(line: 549, column: 27, scope: !1004, inlinedAt: !3120)
!3123 = !DILocation(line: 549, column: 9, scope: !997, inlinedAt: !3120)
!3124 = !DILocation(line: 0, scope: !1008, inlinedAt: !3125)
!3125 = distinct !DILocation(line: 550, column: 9, scope: !1014, inlinedAt: !3120)
!3126 = !DILocation(line: 356, column: 21, scope: !1008, inlinedAt: !3125)
!3127 = !DILocation(line: 364, column: 13, scope: !1008, inlinedAt: !3125)
!3128 = !DILocation(line: 366, column: 5, scope: !1008, inlinedAt: !3125)
!3129 = !DILocation(line: 551, column: 5, scope: !1014, inlinedAt: !3120)
!3130 = !DILocation(line: 1038, column: 36, scope: !3116)
!3131 = !DILocation(line: 1038, column: 13, scope: !3116)
!3132 = !DILocation(line: 1039, column: 22, scope: !3116)
!3133 = !DILocation(line: 1039, column: 33, scope: !3116)
!3134 = !{!3076, !747, i64 408}
!3135 = !DILocation(line: 1040, column: 13, scope: !3116)
!3136 = !DILocation(line: 1041, column: 26, scope: !3137)
!3137 = distinct !DILexicalBlock(scope: !3116, file: !3, line: 1041, column: 17)
!3138 = !DILocation(line: 1041, column: 34, scope: !3137)
!3139 = !DILocation(line: 1041, column: 17, scope: !3116)
!3140 = !DILocation(line: 1042, column: 25, scope: !3141)
!3141 = distinct !DILexicalBlock(scope: !3137, file: !3, line: 1041, column: 39)
!3142 = !DILocation(line: 1042, column: 17, scope: !3141)
!3143 = !DILocation(line: 1043, column: 13, scope: !3141)
!3144 = !DILocation(line: 1046, column: 17, scope: !3145)
!3145 = distinct !DILexicalBlock(scope: !3109, file: !3, line: 1045, column: 16)
!3146 = !DILocation(line: 1047, column: 17, scope: !3147)
!3147 = distinct !DILexicalBlock(scope: !3148, file: !3, line: 1046, column: 28)
!3148 = distinct !DILexicalBlock(scope: !3145, file: !3, line: 1046, column: 17)
!3149 = !DILocation(line: 1048, column: 13, scope: !3147)
!3150 = !DILocation(line: 1053, column: 18, scope: !3151)
!3151 = distinct !DILexicalBlock(scope: !3013, file: !3, line: 1053, column: 9)
!3152 = !DILocation(line: 1053, column: 26, scope: !3151)
!3153 = !DILocation(line: 1053, column: 9, scope: !3013)
!3154 = !DILocation(line: 1054, column: 17, scope: !3151)
!3155 = !DILocation(line: 1054, column: 9, scope: !3151)
!3156 = !DILocation(line: 1056, column: 5, scope: !3029)
!3157 = !{!3076, !789, i64 6912}
!3158 = !DILocation(line: 0, scope: !3029)
!3159 = !DILocation(line: 1056, column: 5, scope: !3160)
!3160 = distinct !DILexicalBlock(scope: !3029, file: !3, line: 1056, column: 5)
!3161 = !DILocation(line: 1056, column: 5, scope: !3162)
!3162 = distinct !DILexicalBlock(scope: !3029, file: !3, line: 1056, column: 5)
!3163 = !{!3076, !750, i64 344}
!3164 = !DILocation(line: 1059, column: 5, scope: !3013)
!3165 = !DISubprogram(name: "assoc_find", scope: !1576, file: !1576, line: 4, type: !3166, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3166 = !DISubroutineType(types: !3167)
!3167 = !{!263, !1320, !813, !1579}
!3168 = !DISubprogram(name: "fprintf", scope: !2189, file: !2189, line: 357, type: !3169, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3169 = !DISubroutineType(types: !3170)
!3170 = !{!113, !3171, !2187, null}
!3171 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !3172)
!3172 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3173, size: 64)
!3173 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !3174, line: 7, baseType: !3175)
!3174 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!3175 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !3176, line: 49, size: 1728, elements: !3177)
!3176 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "7a6d4a00a37ee6b9a40cd04bd01f5d00")
!3177 = !{!3178, !3179, !3180, !3181, !3182, !3183, !3184, !3185, !3186, !3187, !3188, !3189, !3190, !3193, !3195, !3196, !3197, !3199, !3200, !3202, !3203, !3206, !3208, !3211, !3214, !3215, !3216, !3217, !3218}
!3178 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !3175, file: !3176, line: 51, baseType: !113, size: 32)
!3179 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !3175, file: !3176, line: 54, baseType: !147, size: 64, offset: 64)
!3180 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !3175, file: !3176, line: 55, baseType: !147, size: 64, offset: 128)
!3181 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !3175, file: !3176, line: 56, baseType: !147, size: 64, offset: 192)
!3182 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !3175, file: !3176, line: 57, baseType: !147, size: 64, offset: 256)
!3183 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !3175, file: !3176, line: 58, baseType: !147, size: 64, offset: 320)
!3184 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !3175, file: !3176, line: 59, baseType: !147, size: 64, offset: 384)
!3185 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !3175, file: !3176, line: 60, baseType: !147, size: 64, offset: 448)
!3186 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !3175, file: !3176, line: 61, baseType: !147, size: 64, offset: 512)
!3187 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !3175, file: !3176, line: 64, baseType: !147, size: 64, offset: 576)
!3188 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !3175, file: !3176, line: 65, baseType: !147, size: 64, offset: 640)
!3189 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !3175, file: !3176, line: 66, baseType: !147, size: 64, offset: 704)
!3190 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !3175, file: !3176, line: 68, baseType: !3191, size: 64, offset: 768)
!3191 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3192, size: 64)
!3192 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !3176, line: 36, flags: DIFlagFwdDecl)
!3193 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !3175, file: !3176, line: 70, baseType: !3194, size: 64, offset: 832)
!3194 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3175, size: 64)
!3195 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !3175, file: !3176, line: 72, baseType: !113, size: 32, offset: 896)
!3196 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !3175, file: !3176, line: 73, baseType: !113, size: 32, offset: 928)
!3197 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !3175, file: !3176, line: 74, baseType: !3198, size: 64, offset: 960)
!3198 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !120, line: 152, baseType: !188)
!3199 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !3175, file: !3176, line: 77, baseType: !115, size: 16, offset: 1024)
!3200 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !3175, file: !3176, line: 78, baseType: !3201, size: 8, offset: 1040)
!3201 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!3202 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !3175, file: !3176, line: 79, baseType: !403, size: 8, offset: 1048)
!3203 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !3175, file: !3176, line: 81, baseType: !3204, size: 64, offset: 1088)
!3204 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3205, size: 64)
!3205 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !3176, line: 43, baseType: null)
!3206 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !3175, file: !3176, line: 89, baseType: !3207, size: 64, offset: 1152)
!3207 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !120, line: 153, baseType: !188)
!3208 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !3175, file: !3176, line: 91, baseType: !3209, size: 64, offset: 1216)
!3209 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3210, size: 64)
!3210 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !3176, line: 37, flags: DIFlagFwdDecl)
!3211 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !3175, file: !3176, line: 92, baseType: !3212, size: 64, offset: 1280)
!3212 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3213, size: 64)
!3213 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !3176, line: 38, flags: DIFlagFwdDecl)
!3214 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !3175, file: !3176, line: 93, baseType: !3194, size: 64, offset: 1344)
!3215 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !3175, file: !3176, line: 94, baseType: !94, size: 64, offset: 1408)
!3216 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !3175, file: !3176, line: 95, baseType: !148, size: 64, offset: 1472)
!3217 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !3175, file: !3176, line: 96, baseType: !113, size: 32, offset: 1536)
!3218 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !3175, file: !3176, line: 98, baseType: !3219, size: 160, offset: 1568)
!3219 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 160, elements: !3220)
!3220 = !{!3221}
!3221 = !DISubrange(count: 20)
!3222 = distinct !DISubprogram(name: "do_item_bump", scope: !3, file: !3, line: 1065, type: !3223, scopeLine: 1065, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3225)
!3223 = !DISubroutineType(types: !3224)
!3224 = !{null, !2470, !263, !1579}
!3225 = !{!3226, !3227, !3228}
!3226 = !DILocalVariable(name: "t", arg: 1, scope: !3222, file: !3, line: 1065, type: !2470)
!3227 = !DILocalVariable(name: "it", arg: 2, scope: !3222, file: !3, line: 1065, type: !263)
!3228 = !DILocalVariable(name: "hv", arg: 3, scope: !3222, file: !3, line: 1065, type: !1579)
!3229 = !DILocation(line: 0, scope: !3222)
!3230 = !DILocation(line: 1072, column: 18, scope: !3231)
!3231 = distinct !DILexicalBlock(scope: !3222, file: !3, line: 1072, column: 9)
!3232 = !DILocation(line: 0, scope: !3231)
!3233 = !DILocation(line: 1072, column: 9, scope: !3222)
!3234 = !DILocation(line: 1073, column: 14, scope: !3235)
!3235 = distinct !DILexicalBlock(scope: !3236, file: !3, line: 1073, column: 13)
!3236 = distinct !DILexicalBlock(scope: !3231, file: !3, line: 1072, column: 33)
!3237 = !DILocation(line: 1073, column: 27, scope: !3235)
!3238 = !DILocation(line: 1073, column: 42, scope: !3235)
!3239 = !DILocation(line: 1073, column: 13, scope: !3236)
!3240 = !DILocation(line: 1074, column: 31, scope: !3241)
!3241 = distinct !DILexicalBlock(scope: !3242, file: !3, line: 1074, column: 17)
!3242 = distinct !DILexicalBlock(scope: !3235, file: !3, line: 1073, column: 48)
!3243 = !DILocation(line: 1074, column: 47, scope: !3241)
!3244 = !DILocation(line: 1074, column: 17, scope: !3242)
!3245 = !DILocation(line: 1075, column: 30, scope: !3246)
!3246 = distinct !DILexicalBlock(scope: !3241, file: !3, line: 1074, column: 53)
!3247 = !DILocation(line: 1076, column: 13, scope: !3246)
!3248 = !DILocation(line: 1077, column: 30, scope: !3249)
!3249 = distinct !DILexicalBlock(scope: !3241, file: !3, line: 1076, column: 20)
!3250 = !DILocation(line: 1078, column: 21, scope: !3251)
!3251 = distinct !DILexicalBlock(scope: !3249, file: !3, line: 1078, column: 21)
!3252 = !DILocation(line: 1078, column: 36, scope: !3251)
!3253 = !DILocation(line: 1078, column: 21, scope: !3249)
!3254 = !DILocation(line: 1079, column: 32, scope: !3255)
!3255 = distinct !DILexicalBlock(scope: !3251, file: !3, line: 1078, column: 49)
!3256 = !DILocation(line: 1079, column: 25, scope: !3255)
!3257 = !DILocation(line: 1079, column: 30, scope: !3255)
!3258 = !DILocation(line: 1080, column: 17, scope: !3255)
!3259 = !DILocation(line: 1080, column: 47, scope: !3260)
!3260 = distinct !DILexicalBlock(scope: !3251, file: !3, line: 1080, column: 28)
!3261 = !{!3076, !789, i64 6920}
!3262 = !DILocalVariable(name: "b", arg: 1, scope: !3263, file: !3, line: 1314, type: !568)
!3263 = distinct !DISubprogram(name: "lru_bump_async", scope: !3, file: !3, line: 1314, type: !3264, scopeLine: 1314, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3266)
!3264 = !DISubroutineType(types: !3265)
!3265 = !{!455, !568, !263, !266}
!3266 = !{!3262, !3267, !3268, !3269, !3270}
!3267 = !DILocalVariable(name: "it", arg: 2, scope: !3263, file: !3, line: 1314, type: !263)
!3268 = !DILocalVariable(name: "hv", arg: 3, scope: !3263, file: !3, line: 1314, type: !266)
!3269 = !DILocalVariable(name: "ret", scope: !3263, file: !3, line: 1315, type: !455)
!3270 = !DILocalVariable(name: "be", scope: !3263, file: !3, line: 1318, type: !258)
!3271 = !DILocation(line: 0, scope: !3263, inlinedAt: !3272)
!3272 = distinct !DILocation(line: 1080, column: 29, scope: !3260)
!3273 = !DILocation(line: 1316, column: 5, scope: !3263, inlinedAt: !3272)
!3274 = !DILocation(line: 1317, column: 28, scope: !3263, inlinedAt: !3272)
!3275 = !DILocation(line: 1317, column: 5, scope: !3263, inlinedAt: !3272)
!3276 = !DILocation(line: 1318, column: 63, scope: !3263, inlinedAt: !3272)
!3277 = !{!2344, !789, i64 56}
!3278 = !DILocation(line: 1318, column: 45, scope: !3263, inlinedAt: !3272)
!3279 = !DILocation(line: 1319, column: 12, scope: !3280, inlinedAt: !3272)
!3280 = distinct !DILexicalBlock(scope: !3263, file: !3, line: 1319, column: 9)
!3281 = !DILocation(line: 1319, column: 9, scope: !3263, inlinedAt: !3272)
!3282 = !DILocation(line: 1320, column: 16, scope: !3283, inlinedAt: !3272)
!3283 = distinct !DILexicalBlock(scope: !3280, file: !3, line: 1319, column: 21)
!3284 = !{!3285, !789, i64 0}
!3285 = !{!"", !789, i64 0, !750, i64 8}
!3286 = !DILocation(line: 1321, column: 13, scope: !3283, inlinedAt: !3272)
!3287 = !DILocation(line: 1321, column: 16, scope: !3283, inlinedAt: !3272)
!3288 = !{!3285, !750, i64 8}
!3289 = !DILocation(line: 1322, column: 28, scope: !3290, inlinedAt: !3272)
!3290 = distinct !DILexicalBlock(scope: !3283, file: !3, line: 1322, column: 13)
!3291 = !DILocation(line: 1322, column: 13, scope: !3290, inlinedAt: !3272)
!3292 = !DILocation(line: 1322, column: 57, scope: !3290, inlinedAt: !3272)
!3293 = !DILocation(line: 1322, column: 13, scope: !3283, inlinedAt: !3272)
!3294 = !DILocation(line: 1333, column: 5, scope: !3263, inlinedAt: !3272)
!3295 = !DILocation(line: 1080, column: 28, scope: !3251)
!3296 = !DILocation(line: 0, scope: !3280, inlinedAt: !3272)
!3297 = !DILocation(line: 1331, column: 9, scope: !3298, inlinedAt: !3272)
!3298 = distinct !DILexicalBlock(scope: !3299, file: !3, line: 1330, column: 15)
!3299 = distinct !DILexicalBlock(scope: !3263, file: !3, line: 1330, column: 9)
!3300 = !DILocation(line: 1082, column: 34, scope: !3301)
!3301 = distinct !DILexicalBlock(scope: !3260, file: !3, line: 1080, column: 70)
!3302 = !DILocation(line: 1083, column: 17, scope: !3301)
!3303 = !DILocation(line: 1087, column: 22, scope: !3304)
!3304 = distinct !DILexicalBlock(scope: !3231, file: !3, line: 1086, column: 12)
!3305 = !DILocation(line: 1088, column: 9, scope: !3304)
!3306 = !DILocation(line: 1090, column: 1, scope: !3222)
!3307 = !DISubprogram(name: "pthread_getspecific", scope: !726, file: !726, line: 1305, type: !3308, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3308 = !DISubroutineType(types: !3309)
!3309 = !{!94, !3310}
!3310 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_key_t", file: !160, line: 49, baseType: !7)
!3311 = !DISubprogram(name: "logger_log", scope: !40, file: !40, line: 238, type: !3312, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3312 = !DISubroutineType(types: !3313)
!3313 = !{!74, !151, !3314, !243, null}
!3314 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !39)
!3315 = distinct !DISubprogram(name: "do_item_touch", scope: !3, file: !3, line: 1092, type: !3316, scopeLine: 1093, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3318)
!3316 = !DISubroutineType(types: !3317)
!3317 = !{!263, !1320, !148, !266, !1579, !2470}
!3318 = !{!3319, !3320, !3321, !3322, !3323, !3324}
!3319 = !DILocalVariable(name: "key", arg: 1, scope: !3315, file: !3, line: 1092, type: !1320)
!3320 = !DILocalVariable(name: "nkey", arg: 2, scope: !3315, file: !3, line: 1092, type: !148)
!3321 = !DILocalVariable(name: "exptime", arg: 3, scope: !3315, file: !3, line: 1092, type: !266)
!3322 = !DILocalVariable(name: "hv", arg: 4, scope: !3315, file: !3, line: 1093, type: !1579)
!3323 = !DILocalVariable(name: "t", arg: 5, scope: !3315, file: !3, line: 1093, type: !2470)
!3324 = !DILocalVariable(name: "it", scope: !3315, file: !3, line: 1094, type: !263)
!3325 = !DILocation(line: 0, scope: !3315)
!3326 = !DILocation(line: 1094, column: 16, scope: !3315)
!3327 = !DILocation(line: 1095, column: 12, scope: !3328)
!3328 = distinct !DILexicalBlock(scope: !3315, file: !3, line: 1095, column: 9)
!3329 = !DILocation(line: 1095, column: 9, scope: !3315)
!3330 = !DILocation(line: 1096, column: 13, scope: !3331)
!3331 = distinct !DILexicalBlock(scope: !3328, file: !3, line: 1095, column: 21)
!3332 = !DILocation(line: 1096, column: 21, scope: !3331)
!3333 = !DILocation(line: 1097, column: 5, scope: !3331)
!3334 = !DILocation(line: 1098, column: 5, scope: !3315)
!3335 = !DISubprogram(name: "slabs_reassign", scope: !80, file: !80, line: 60, type: !3336, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3336 = !DISubroutineType(types: !3337)
!3337 = !{!79, !113, !113}
!3338 = distinct !DISubprogram(name: "item_lru_bump_buf_create", scope: !3, file: !3, line: 1296, type: !3339, scopeLine: 1296, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3341)
!3339 = !DISubroutineType(types: !3340)
!3340 = !{!94}
!3341 = !{!3342}
!3342 = !DILocalVariable(name: "b", scope: !3338, file: !3, line: 1297, type: !568)
!3343 = !DILocation(line: 1297, column: 23, scope: !3338)
!3344 = !DILocation(line: 0, scope: !3338)
!3345 = !DILocation(line: 1298, column: 11, scope: !3346)
!3346 = distinct !DILexicalBlock(scope: !3338, file: !3, line: 1298, column: 9)
!3347 = !DILocation(line: 1298, column: 9, scope: !3338)
!3348 = !DILocation(line: 1302, column: 14, scope: !3338)
!3349 = !DILocation(line: 1302, column: 8, scope: !3338)
!3350 = !DILocation(line: 1302, column: 12, scope: !3338)
!3351 = !DILocation(line: 1303, column: 16, scope: !3352)
!3352 = distinct !DILexicalBlock(scope: !3338, file: !3, line: 1303, column: 9)
!3353 = !DILocation(line: 1303, column: 9, scope: !3338)
!3354 = !DILocation(line: 1304, column: 9, scope: !3355)
!3355 = distinct !DILexicalBlock(scope: !3352, file: !3, line: 1303, column: 25)
!3356 = !DILocation(line: 1305, column: 9, scope: !3355)
!3357 = !DILocation(line: 1308, column: 28, scope: !3338)
!3358 = !DILocation(line: 1308, column: 5, scope: !3338)
!3359 = !DILocalVariable(name: "b", arg: 1, scope: !3360, file: !3, line: 1283, type: !568)
!3360 = distinct !DISubprogram(name: "lru_bump_buf_link_q", scope: !3, file: !3, line: 1283, type: !3361, scopeLine: 1283, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3363)
!3361 = !DISubroutineType(types: !3362)
!3362 = !{null, !568}
!3363 = !{!3359}
!3364 = !DILocation(line: 0, scope: !3360, inlinedAt: !3365)
!3365 = distinct !DILocation(line: 1310, column: 5, scope: !3338)
!3366 = !DILocation(line: 1284, column: 5, scope: !3360, inlinedAt: !3365)
!3367 = !DILocation(line: 1287, column: 13, scope: !3360, inlinedAt: !3365)
!3368 = !{!2344, !789, i64 0}
!3369 = !DILocation(line: 1288, column: 15, scope: !3360, inlinedAt: !3365)
!3370 = !DILocation(line: 1288, column: 8, scope: !3360, inlinedAt: !3365)
!3371 = !DILocation(line: 1288, column: 13, scope: !3360, inlinedAt: !3365)
!3372 = !{!2344, !789, i64 8}
!3373 = !DILocation(line: 1289, column: 9, scope: !3374, inlinedAt: !3365)
!3374 = distinct !DILexicalBlock(scope: !3360, file: !3, line: 1289, column: 9)
!3375 = !DILocation(line: 1289, column: 9, scope: !3360, inlinedAt: !3365)
!3376 = !DILocation(line: 1289, column: 32, scope: !3374, inlinedAt: !3365)
!3377 = !DILocation(line: 1289, column: 18, scope: !3374, inlinedAt: !3365)
!3378 = !DILocation(line: 1290, column: 19, scope: !3360, inlinedAt: !3365)
!3379 = !DILocation(line: 1291, column: 9, scope: !3380, inlinedAt: !3365)
!3380 = distinct !DILexicalBlock(scope: !3360, file: !3, line: 1291, column: 9)
!3381 = !DILocation(line: 1291, column: 23, scope: !3380, inlinedAt: !3365)
!3382 = !DILocation(line: 1291, column: 9, scope: !3360, inlinedAt: !3365)
!3383 = !DILocation(line: 1291, column: 43, scope: !3380, inlinedAt: !3365)
!3384 = !DILocation(line: 1291, column: 29, scope: !3380, inlinedAt: !3365)
!3385 = !DILocation(line: 1292, column: 5, scope: !3360, inlinedAt: !3365)
!3386 = !DILocation(line: 1311, column: 5, scope: !3338)
!3387 = !DILocation(line: 1312, column: 1, scope: !3338)
!3388 = !DISubprogram(name: "bipbuf_new", scope: !198, file: !198, line: 26, type: !3389, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3389 = !DISubroutineType(types: !3390)
!3390 = !{!196, !814}
!3391 = !DISubprogram(name: "free", scope: !2179, file: !2179, line: 687, type: !517, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3392 = !DISubprogram(name: "pthread_mutex_init", scope: !726, file: !726, line: 781, type: !3393, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3393 = !DISubroutineType(types: !3394)
!3394 = !{!113, !729, !3395}
!3395 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3396, size: 64)
!3396 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !3397)
!3397 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutexattr_t", file: !160, line: 36, baseType: !3398)
!3398 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !160, line: 32, size: 32, elements: !3399)
!3399 = !{!3400, !3401}
!3400 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !3398, file: !160, line: 34, baseType: !369, size: 32)
!3401 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !3398, file: !160, line: 35, baseType: !113, size: 32)
!3402 = distinct !DISubprogram(name: "stop_lru_maintainer_thread", scope: !3, file: !3, line: 1708, type: !3403, scopeLine: 1708, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3405)
!3403 = !DISubroutineType(types: !3404)
!3404 = !{!113}
!3405 = !{!3406}
!3406 = !DILocalVariable(name: "ret", scope: !3402, file: !3, line: 1709, type: !113)
!3407 = !DILocation(line: 1710, column: 5, scope: !3402)
!3408 = !DILocation(line: 1712, column: 34, scope: !3402)
!3409 = !DILocation(line: 1713, column: 5, scope: !3402)
!3410 = !DILocation(line: 1714, column: 29, scope: !3411)
!3411 = distinct !DILexicalBlock(scope: !3402, file: !3, line: 1714, column: 9)
!3412 = !DILocation(line: 1714, column: 16, scope: !3411)
!3413 = !DILocation(line: 0, scope: !3402)
!3414 = !DILocation(line: 1714, column: 56, scope: !3411)
!3415 = !DILocation(line: 1714, column: 9, scope: !3402)
!3416 = !DILocation(line: 1715, column: 17, scope: !3417)
!3417 = distinct !DILexicalBlock(scope: !3411, file: !3, line: 1714, column: 62)
!3418 = !DILocation(line: 1715, column: 71, scope: !3417)
!3419 = !DILocation(line: 1715, column: 9, scope: !3417)
!3420 = !DILocation(line: 1716, column: 9, scope: !3417)
!3421 = !DILocation(line: 1718, column: 36, scope: !3402)
!3422 = !DILocation(line: 1719, column: 5, scope: !3402)
!3423 = !DILocation(line: 1720, column: 1, scope: !3402)
!3424 = !DISubprogram(name: "pthread_join", scope: !726, file: !726, line: 219, type: !3425, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3425 = !DISubroutineType(types: !3426)
!3426 = !{!113, !551, !3427}
!3427 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !94, size: 64)
!3428 = !DISubprogram(name: "strerror", scope: !2183, file: !2183, line: 419, type: !3429, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3429 = !DISubroutineType(types: !3430)
!3430 = !{!147, !113}
!3431 = distinct !DISubprogram(name: "start_lru_maintainer_thread", scope: !3, file: !3, line: 1722, type: !3432, scopeLine: 1722, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3434)
!3432 = !DISubroutineType(types: !3433)
!3433 = !{!113, !94}
!3434 = !{!3435, !3436}
!3435 = !DILocalVariable(name: "arg", arg: 1, scope: !3431, file: !3, line: 1722, type: !94)
!3436 = !DILocalVariable(name: "ret", scope: !3431, file: !3, line: 1723, type: !113)
!3437 = !DILocation(line: 0, scope: !3431)
!3438 = !DILocation(line: 1725, column: 5, scope: !3431)
!3439 = !DILocation(line: 1726, column: 34, scope: !3431)
!3440 = !DILocation(line: 1727, column: 36, scope: !3431)
!3441 = !DILocation(line: 1728, column: 16, scope: !3442)
!3442 = distinct !DILexicalBlock(scope: !3431, file: !3, line: 1728, column: 9)
!3443 = !DILocation(line: 1729, column: 38, scope: !3442)
!3444 = !DILocation(line: 1728, column: 9, scope: !3431)
!3445 = !DILocation(line: 1730, column: 17, scope: !3446)
!3446 = distinct !DILexicalBlock(scope: !3442, file: !3, line: 1729, column: 44)
!3447 = !DILocation(line: 1731, column: 13, scope: !3446)
!3448 = !DILocation(line: 1730, column: 9, scope: !3446)
!3449 = !DILocation(line: 1733, column: 9, scope: !3446)
!3450 = !DILocation(line: 1735, column: 20, scope: !3431)
!3451 = !DILocation(line: 1735, column: 5, scope: !3431)
!3452 = !DILocation(line: 1738, column: 5, scope: !3431)
!3453 = !DILocation(line: 1739, column: 1, scope: !3431)
!3454 = !DISubprogram(name: "pthread_create", scope: !726, file: !726, line: 202, type: !3455, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3455 = !DISubroutineType(types: !3456)
!3456 = !{!113, !3457, !3459, !3470, !3473}
!3457 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !3458)
!3458 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !551, size: 64)
!3459 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !3460)
!3460 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3461, size: 64)
!3461 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !3462)
!3462 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_attr_t", file: !160, line: 62, baseType: !3463)
!3463 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "pthread_attr_t", file: !160, line: 56, size: 448, elements: !3464)
!3464 = !{!3465, !3469}
!3465 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !3463, file: !160, line: 58, baseType: !3466, size: 448)
!3466 = !DICompositeType(tag: DW_TAG_array_type, baseType: !135, size: 448, elements: !3467)
!3467 = !{!3468}
!3468 = !DISubrange(count: 56)
!3469 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !3463, file: !160, line: 59, baseType: !188, size: 64)
!3470 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3471, size: 64)
!3471 = !DISubroutineType(types: !3472)
!3472 = !{!94, !94}
!3473 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !94)
!3474 = distinct !DISubprogram(name: "lru_maintainer_thread", scope: !3, file: !3, line: 1587, type: !3471, scopeLine: 1587, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3475)
!3475 = !{!3476, !3477, !3479, !3480, !3481, !3484, !3485, !3486, !3487, !3489, !3490, !3491, !3492, !3493, !3494, !3499, !3502, !3503}
!3476 = !DILocalVariable(name: "arg", arg: 1, scope: !3474, file: !3, line: 1587, type: !94)
!3477 = !DILocalVariable(name: "sam", scope: !3474, file: !3, line: 1588, type: !3478)
!3478 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !423, size: 64)
!3479 = !DILocalVariable(name: "storage", scope: !3474, file: !3, line: 1590, type: !94)
!3480 = !DILocalVariable(name: "i", scope: !3474, file: !3, line: 1594, type: !113)
!3481 = !DILocalVariable(name: "to_sleep", scope: !3474, file: !3, line: 1595, type: !3482)
!3482 = !DIDerivedType(tag: DW_TAG_typedef, name: "useconds_t", file: !2739, line: 134, baseType: !3483)
!3483 = !DIDerivedType(tag: DW_TAG_typedef, name: "__useconds_t", file: !120, line: 161, baseType: !7)
!3484 = !DILocalVariable(name: "last_sleep", scope: !3474, file: !3, line: 1596, type: !3482)
!3485 = !DILocalVariable(name: "last_crawler_check", scope: !3474, file: !3, line: 1597, type: !110)
!3486 = !DILocalVariable(name: "last_automove_check", scope: !3474, file: !3, line: 1598, type: !110)
!3487 = !DILocalVariable(name: "next_juggles", scope: !3474, file: !3, line: 1599, type: !3488)
!3488 = !DICompositeType(tag: DW_TAG_array_type, baseType: !3482, size: 2048, elements: !2561)
!3489 = !DILocalVariable(name: "backoff_juggles", scope: !3474, file: !3, line: 1600, type: !3488)
!3490 = !DILocalVariable(name: "cdata", scope: !3474, file: !3, line: 1601, type: !610)
!3491 = !DILocalVariable(name: "l", scope: !3474, file: !3, line: 1609, type: !151)
!3492 = !DILocalVariable(name: "last_ratio", scope: !3474, file: !3, line: 1615, type: !447)
!3493 = !DILocalVariable(name: "am", scope: !3474, file: !3, line: 1616, type: !94)
!3494 = !DILocalVariable(name: "did_moves", scope: !3495, file: !3, line: 1645, type: !113)
!3495 = distinct !DILexicalBlock(scope: !3496, file: !3, line: 1635, column: 71)
!3496 = distinct !DILexicalBlock(scope: !3497, file: !3, line: 1635, column: 9)
!3497 = distinct !DILexicalBlock(scope: !3498, file: !3, line: 1635, column: 9)
!3498 = distinct !DILexicalBlock(scope: !3474, file: !3, line: 1621, column: 42)
!3499 = !DILocalVariable(name: "src", scope: !3500, file: !3, line: 1682, type: !113)
!3500 = distinct !DILexicalBlock(scope: !3501, file: !3, line: 1676, column: 81)
!3501 = distinct !DILexicalBlock(scope: !3498, file: !3, line: 1676, column: 13)
!3502 = !DILocalVariable(name: "dst", scope: !3500, file: !3, line: 1682, type: !113)
!3503 = !DILocalVariable(name: "myl", scope: !3504, file: !3, line: 1686, type: !151)
!3504 = distinct !DILexicalBlock(scope: !3505, file: !3, line: 1686, column: 17)
!3505 = distinct !DILexicalBlock(scope: !3506, file: !3, line: 1684, column: 41)
!3506 = distinct !DILexicalBlock(scope: !3500, file: !3, line: 1684, column: 17)
!3507 = distinct !DIAssignID()
!3508 = distinct !DIAssignID()
!3509 = distinct !DIAssignID()
!3510 = distinct !DIAssignID()
!3511 = !DILocation(line: 0, scope: !3474)
!3512 = distinct !DIAssignID()
!3513 = distinct !DIAssignID()
!3514 = !DILocation(line: 0, scope: !3500)
!3515 = distinct !DIAssignID()
!3516 = !DILocation(line: 1591, column: 17, scope: !3517)
!3517 = distinct !DILexicalBlock(scope: !3474, file: !3, line: 1591, column: 9)
!3518 = !DILocation(line: 1591, column: 9, scope: !3474)
!3519 = !DILocation(line: 1599, column: 5, scope: !3474)
!3520 = !DILocation(line: 1599, column: 16, scope: !3474)
!3521 = distinct !DIAssignID()
!3522 = !DILocation(line: 1600, column: 5, scope: !3474)
!3523 = !DILocation(line: 1600, column: 16, scope: !3474)
!3524 = distinct !DIAssignID()
!3525 = !DILocation(line: 1602, column: 9, scope: !3474)
!3526 = !DILocation(line: 1603, column: 15, scope: !3527)
!3527 = distinct !DILexicalBlock(scope: !3474, file: !3, line: 1603, column: 9)
!3528 = !DILocation(line: 1603, column: 9, scope: !3474)
!3529 = !DILocation(line: 1604, column: 17, scope: !3530)
!3530 = distinct !DILexicalBlock(scope: !3527, file: !3, line: 1603, column: 24)
!3531 = !DILocation(line: 1604, column: 9, scope: !3530)
!3532 = !DILocation(line: 1605, column: 9, scope: !3530)
!3533 = !DILocation(line: 1607, column: 5, scope: !3474)
!3534 = !DILocation(line: 1608, column: 12, scope: !3474)
!3535 = !DILocation(line: 1608, column: 27, scope: !3474)
!3536 = !{!3537, !791, i64 137264}
!3537 = !{!"crawler_expired_data", !748, i64 0, !748, i64 40, !750, i64 137256, !750, i64 137260, !791, i64 137264, !791, i64 137265}
!3538 = !DILocation(line: 1609, column: 17, scope: !3474)
!3539 = !DILocation(line: 1610, column: 11, scope: !3540)
!3540 = distinct !DILexicalBlock(scope: !3474, file: !3, line: 1610, column: 9)
!3541 = !DILocation(line: 1610, column: 9, scope: !3474)
!3542 = !DILocation(line: 1611, column: 17, scope: !3543)
!3543 = distinct !DILexicalBlock(scope: !3540, file: !3, line: 1610, column: 20)
!3544 = !DILocation(line: 1611, column: 9, scope: !3543)
!3545 = !DILocation(line: 1612, column: 9, scope: !3543)
!3546 = !DILocation(line: 1615, column: 34, scope: !3474)
!3547 = !{!788, !790, i64 144}
!3548 = !DILocation(line: 1616, column: 21, scope: !3474)
!3549 = !{!3550, !789, i64 0}
!3550 = !{!"", !789, i64 0, !789, i64 8, !789, i64 16}
!3551 = !DILocation(line: 1616, column: 16, scope: !3474)
!3552 = !DILocation(line: 1618, column: 5, scope: !3474)
!3553 = !DILocation(line: 1619, column: 18, scope: !3554)
!3554 = distinct !DILexicalBlock(scope: !3474, file: !3, line: 1619, column: 9)
!3555 = !DILocation(line: 1619, column: 26, scope: !3554)
!3556 = !DILocation(line: 1619, column: 9, scope: !3474)
!3557 = !DILocation(line: 1620, column: 17, scope: !3554)
!3558 = !DILocation(line: 1620, column: 9, scope: !3554)
!3559 = !DILocation(line: 1621, column: 12, scope: !3474)
!3560 = !DILocation(line: 1621, column: 5, scope: !3474)
!3561 = !DILocation(line: 1622, column: 9, scope: !3498)
!3562 = !DILocation(line: 1623, column: 13, scope: !3563)
!3563 = distinct !DILexicalBlock(scope: !3498, file: !3, line: 1623, column: 13)
!3564 = !DILocation(line: 1623, column: 13, scope: !3498)
!3565 = !DILocation(line: 1624, column: 13, scope: !3563)
!3566 = !DILocation(line: 1625, column: 9, scope: !3498)
!3567 = !DILocation(line: 1627, column: 22, scope: !3498)
!3568 = !DILocation(line: 1630, column: 9, scope: !3498)
!3569 = !DILocation(line: 1631, column: 37, scope: !3498)
!3570 = !{!1549, !747, i64 104}
!3571 = !DILocation(line: 1632, column: 9, scope: !3498)
!3572 = !DILocation(line: 1635, column: 9, scope: !3497)
!3573 = !DILocation(line: 1636, column: 31, scope: !3495)
!3574 = !DILocation(line: 1636, column: 29, scope: !3495)
!3575 = !DILocation(line: 1638, column: 33, scope: !3576)
!3576 = distinct !DILexicalBlock(scope: !3495, file: !3, line: 1638, column: 17)
!3577 = !DILocation(line: 1638, column: 17, scope: !3495)
!3578 = !DILocalVariable(name: "chunks_perslab", scope: !3579, file: !3, line: 1403, type: !7)
!3579 = distinct !DISubprogram(name: "lru_maintainer_juggle", scope: !3, file: !3, line: 1399, type: !3580, scopeLine: 1399, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3582)
!3580 = !DISubroutineType(types: !3581)
!3581 = !{!113, !734}
!3582 = !{!3583, !3584, !3585, !3586, !3578, !3587, !3588, !3589, !3590}
!3583 = !DILocalVariable(name: "slabs_clsid", arg: 1, scope: !3579, file: !3, line: 1399, type: !734)
!3584 = !DILocalVariable(name: "i", scope: !3579, file: !3, line: 1400, type: !113)
!3585 = !DILocalVariable(name: "did_moves", scope: !3579, file: !3, line: 1401, type: !113)
!3586 = !DILocalVariable(name: "total_bytes", scope: !3579, file: !3, line: 1402, type: !131)
!3587 = !DILocalVariable(name: "cold_age", scope: !3579, file: !3, line: 1419, type: !110)
!3588 = !DILocalVariable(name: "hot_age", scope: !3579, file: !3, line: 1420, type: !110)
!3589 = !DILocalVariable(name: "warm_age", scope: !3579, file: !3, line: 1421, type: !110)
!3590 = !DILocalVariable(name: "do_more", scope: !3591, file: !3, line: 1447, type: !113)
!3591 = distinct !DILexicalBlock(scope: !3592, file: !3, line: 1446, column: 31)
!3592 = distinct !DILexicalBlock(scope: !3593, file: !3, line: 1446, column: 5)
!3593 = distinct !DILexicalBlock(scope: !3579, file: !3, line: 1446, column: 5)
!3594 = !DILocation(line: 0, scope: !3579, inlinedAt: !3595)
!3595 = distinct !DILocation(line: 1645, column: 29, scope: !3495)
!3596 = !DILocation(line: 1403, column: 5, scope: !3579, inlinedAt: !3595)
!3597 = !DILocation(line: 1403, column: 18, scope: !3579, inlinedAt: !3595)
!3598 = distinct !DIAssignID()
!3599 = !DILocation(line: 1406, column: 5, scope: !3579, inlinedAt: !3595)
!3600 = !DILocation(line: 1408, column: 18, scope: !3601, inlinedAt: !3595)
!3601 = distinct !DILexicalBlock(scope: !3579, file: !3, line: 1408, column: 9)
!3602 = !DILocation(line: 1408, column: 9, scope: !3579, inlinedAt: !3595)
!3603 = !DILocation(line: 1411, column: 17, scope: !3604, inlinedAt: !3595)
!3604 = distinct !DILexicalBlock(scope: !3605, file: !3, line: 1411, column: 17)
!3605 = distinct !DILexicalBlock(scope: !3606, file: !3, line: 1410, column: 35)
!3606 = distinct !DILexicalBlock(scope: !3607, file: !3, line: 1410, column: 9)
!3607 = distinct !DILexicalBlock(scope: !3608, file: !3, line: 1410, column: 9)
!3608 = distinct !DILexicalBlock(scope: !3601, file: !3, line: 1408, column: 28)
!3609 = !DILocation(line: 1411, column: 69, scope: !3604, inlinedAt: !3595)
!3610 = !DILocation(line: 1411, column: 17, scope: !3605, inlinedAt: !3595)
!3611 = !DILocation(line: 1414, column: 26, scope: !3612, inlinedAt: !3595)
!3612 = distinct !DILexicalBlock(scope: !3604, file: !3, line: 1413, column: 20)
!3613 = !DILocation(line: 1410, column: 23, scope: !3606, inlinedAt: !3595)
!3614 = !DILocation(line: 1410, column: 9, scope: !3607, inlinedAt: !3595)
!3615 = distinct !{!3615, !3614, !3616, !723}
!3616 = !DILocation(line: 1416, column: 9, scope: !3607, inlinedAt: !3595)
!3617 = !DILocation(line: 1401, column: 9, scope: !3579, inlinedAt: !3595)
!3618 = !DILocation(line: 1423, column: 18, scope: !3619, inlinedAt: !3595)
!3619 = distinct !DILexicalBlock(scope: !3579, file: !3, line: 1423, column: 9)
!3620 = !DILocation(line: 1423, column: 9, scope: !3579, inlinedAt: !3595)
!3621 = !DILocation(line: 1424, column: 50, scope: !3622, inlinedAt: !3595)
!3622 = distinct !DILexicalBlock(scope: !3619, file: !3, line: 1423, column: 33)
!3623 = !DILocation(line: 1424, column: 29, scope: !3622, inlinedAt: !3595)
!3624 = !DILocation(line: 1424, column: 9, scope: !3622, inlinedAt: !3595)
!3625 = !DILocation(line: 1425, column: 13, scope: !3626, inlinedAt: !3595)
!3626 = distinct !DILexicalBlock(scope: !3622, file: !3, line: 1425, column: 13)
!3627 = !DILocation(line: 1425, column: 13, scope: !3622, inlinedAt: !3595)
!3628 = !DILocation(line: 1426, column: 24, scope: !3629, inlinedAt: !3595)
!3629 = distinct !DILexicalBlock(scope: !3626, file: !3, line: 1425, column: 42)
!3630 = !DILocation(line: 1426, column: 68, scope: !3629, inlinedAt: !3595)
!3631 = !DILocation(line: 1426, column: 37, scope: !3629, inlinedAt: !3595)
!3632 = !DILocation(line: 1432, column: 19, scope: !3622, inlinedAt: !3595)
!3633 = !DILocation(line: 1427, column: 9, scope: !3629, inlinedAt: !3595)
!3634 = !DILocation(line: 1429, column: 24, scope: !3622, inlinedAt: !3595)
!3635 = !DILocation(line: 1430, column: 9, scope: !3622, inlinedAt: !3595)
!3636 = !DILocation(line: 1432, column: 39, scope: !3622, inlinedAt: !3595)
!3637 = !{!788, !790, i64 200}
!3638 = !DILocation(line: 1432, column: 28, scope: !3622, inlinedAt: !3595)
!3639 = !DILocation(line: 1433, column: 40, scope: !3622, inlinedAt: !3595)
!3640 = !{!788, !790, i64 208}
!3641 = !DILocation(line: 1433, column: 29, scope: !3622, inlinedAt: !3595)
!3642 = !DILocation(line: 1433, column: 20, scope: !3622, inlinedAt: !3595)
!3643 = !DILocation(line: 1436, column: 29, scope: !3622, inlinedAt: !3595)
!3644 = !DILocation(line: 1436, column: 9, scope: !3622, inlinedAt: !3595)
!3645 = !DILocation(line: 1437, column: 24, scope: !3622, inlinedAt: !3595)
!3646 = !DILocation(line: 1437, column: 21, scope: !3622, inlinedAt: !3595)
!3647 = !DILocation(line: 1438, column: 9, scope: !3622, inlinedAt: !3595)
!3648 = !DILocation(line: 1440, column: 50, scope: !3622, inlinedAt: !3595)
!3649 = !DILocation(line: 1440, column: 29, scope: !3622, inlinedAt: !3595)
!3650 = !DILocation(line: 1440, column: 9, scope: !3622, inlinedAt: !3595)
!3651 = !DILocation(line: 1441, column: 24, scope: !3622, inlinedAt: !3595)
!3652 = !DILocation(line: 1441, column: 21, scope: !3622, inlinedAt: !3595)
!3653 = !DILocation(line: 1442, column: 9, scope: !3622, inlinedAt: !3595)
!3654 = !DILocation(line: 1443, column: 5, scope: !3622, inlinedAt: !3595)
!3655 = !DILocation(line: 1446, column: 5, scope: !3593, inlinedAt: !3595)
!3656 = !DILocation(line: 0, scope: !3591, inlinedAt: !3595)
!3657 = !DILocation(line: 1448, column: 13, scope: !3658, inlinedAt: !3595)
!3658 = distinct !DILexicalBlock(scope: !3591, file: !3, line: 1448, column: 13)
!3659 = !DILocation(line: 1448, column: 100, scope: !3658, inlinedAt: !3595)
!3660 = !DILocation(line: 1449, column: 13, scope: !3658, inlinedAt: !3595)
!3661 = !DILocation(line: 1448, column: 13, scope: !3591, inlinedAt: !3595)
!3662 = !DILocation(line: 1451, column: 9, scope: !3663, inlinedAt: !3595)
!3663 = distinct !DILexicalBlock(scope: !3658, file: !3, line: 1449, column: 103)
!3664 = !DILocation(line: 1452, column: 22, scope: !3665, inlinedAt: !3595)
!3665 = distinct !DILexicalBlock(scope: !3591, file: !3, line: 1452, column: 13)
!3666 = !DILocation(line: 1452, column: 13, scope: !3591, inlinedAt: !3595)
!3667 = !DILocation(line: 1453, column: 24, scope: !3668, inlinedAt: !3595)
!3668 = distinct !DILexicalBlock(scope: !3665, file: !3, line: 1452, column: 37)
!3669 = !DILocation(line: 1453, column: 21, scope: !3668, inlinedAt: !3595)
!3670 = !DILocation(line: 1454, column: 9, scope: !3668, inlinedAt: !3595)
!3671 = !DILocation(line: 1455, column: 21, scope: !3672, inlinedAt: !3595)
!3672 = distinct !DILexicalBlock(scope: !3591, file: !3, line: 1455, column: 13)
!3673 = !DILocation(line: 1455, column: 13, scope: !3591, inlinedAt: !3595)
!3674 = !DILocation(line: 1446, column: 19, scope: !3592, inlinedAt: !3595)
!3675 = distinct !{!3675, !3655, !3676, !723}
!3676 = !DILocation(line: 1458, column: 5, scope: !3593, inlinedAt: !3595)
!3677 = !DILocation(line: 1460, column: 1, scope: !3579, inlinedAt: !3595)
!3678 = !DILocation(line: 0, scope: !3495)
!3679 = !DILocation(line: 1646, column: 17, scope: !3495)
!3680 = !DILocation(line: 1646, column: 27, scope: !3681)
!3681 = distinct !DILexicalBlock(scope: !3495, file: !3, line: 1646, column: 17)
!3682 = !DILocation(line: 1647, column: 21, scope: !3683)
!3683 = distinct !DILexicalBlock(scope: !3684, file: !3, line: 1647, column: 21)
!3684 = distinct !DILexicalBlock(scope: !3681, file: !3, line: 1646, column: 33)
!3685 = !DILocation(line: 1647, column: 40, scope: !3683)
!3686 = !DILocation(line: 1647, column: 21, scope: !3684)
!3687 = !DILocation(line: 1652, column: 21, scope: !3684)
!3688 = !DILocation(line: 0, scope: !3684)
!3689 = !DILocation(line: 1654, column: 24, scope: !3690)
!3690 = distinct !DILexicalBlock(scope: !3681, file: !3, line: 1654, column: 24)
!3691 = !DILocation(line: 1654, column: 43, scope: !3690)
!3692 = !DILocation(line: 1654, column: 24, scope: !3681)
!3693 = !DILocation(line: 1655, column: 36, scope: !3694)
!3694 = distinct !DILexicalBlock(scope: !3690, file: !3, line: 1654, column: 48)
!3695 = !DILocation(line: 1656, column: 40, scope: !3696)
!3696 = distinct !DILexicalBlock(scope: !3694, file: !3, line: 1656, column: 21)
!3697 = !DILocation(line: 1656, column: 21, scope: !3694)
!3698 = !DILocation(line: 0, scope: !3694)
!3699 = !DILocation(line: 1660, column: 31, scope: !3495)
!3700 = !DILocation(line: 1660, column: 29, scope: !3495)
!3701 = !DILocation(line: 1663, column: 9, scope: !3495)
!3702 = !DILocation(line: 1635, column: 67, scope: !3496)
!3703 = !DILocation(line: 1635, column: 36, scope: !3496)
!3704 = distinct !{!3704, !3572, !3705, !723}
!3705 = !DILocation(line: 1663, column: 9, scope: !3497)
!3706 = !DILocation(line: 1666, column: 22, scope: !3707)
!3707 = distinct !DILexicalBlock(scope: !3498, file: !3, line: 1666, column: 13)
!3708 = !DILocation(line: 1666, column: 36, scope: !3707)
!3709 = !DILocalVariable(name: "size", scope: !3710, file: !3, line: 1346, type: !7)
!3710 = distinct !DISubprogram(name: "lru_maintainer_bumps", scope: !3, file: !3, line: 1343, type: !2949, scopeLine: 1343, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3711)
!3711 = !{!3712, !3713, !3709, !3714, !3715}
!3712 = !DILocalVariable(name: "b", scope: !3710, file: !3, line: 1344, type: !568)
!3713 = !DILocalVariable(name: "be", scope: !3710, file: !3, line: 1345, type: !258)
!3714 = !DILocalVariable(name: "todo", scope: !3710, file: !3, line: 1347, type: !7)
!3715 = !DILocalVariable(name: "bumped", scope: !3710, file: !3, line: 1348, type: !455)
!3716 = !DILocation(line: 0, scope: !3710, inlinedAt: !3717)
!3717 = distinct !DILocation(line: 1666, column: 39, scope: !3707)
!3718 = !DILocation(line: 1346, column: 5, scope: !3710, inlinedAt: !3717)
!3719 = !DILocation(line: 1349, column: 5, scope: !3710, inlinedAt: !3717)
!3720 = !DILocation(line: 1350, scope: !3721, inlinedAt: !3717)
!3721 = distinct !DILexicalBlock(scope: !3710, file: !3, line: 1350, column: 5)
!3722 = !DILocation(line: 1350, column: 31, scope: !3723, inlinedAt: !3717)
!3723 = distinct !DILexicalBlock(scope: !3721, file: !3, line: 1350, column: 5)
!3724 = !DILocation(line: 1350, column: 5, scope: !3721, inlinedAt: !3717)
!3725 = !DILocation(line: 1374, column: 5, scope: !3710, inlinedAt: !3717)
!3726 = !DILocation(line: 1376, column: 1, scope: !3710, inlinedAt: !3717)
!3727 = !DILocation(line: 1666, column: 62, scope: !3707)
!3728 = !DILocation(line: 1351, column: 32, scope: !3729, inlinedAt: !3717)
!3729 = distinct !DILexicalBlock(scope: !3723, file: !3, line: 1350, column: 51)
!3730 = !DILocation(line: 1351, column: 9, scope: !3729, inlinedAt: !3717)
!3731 = !DILocation(line: 1352, column: 52, scope: !3729, inlinedAt: !3717)
!3732 = !DILocation(line: 1352, column: 33, scope: !3729, inlinedAt: !3717)
!3733 = !DILocation(line: 1353, column: 9, scope: !3729, inlinedAt: !3717)
!3734 = !DILocation(line: 1355, column: 16, scope: !3735, inlinedAt: !3717)
!3735 = distinct !DILexicalBlock(scope: !3729, file: !3, line: 1355, column: 13)
!3736 = !DILocation(line: 1355, column: 13, scope: !3729, inlinedAt: !3717)
!3737 = !DILocation(line: 1358, column: 16, scope: !3729, inlinedAt: !3717)
!3738 = !DILocation(line: 1361, column: 9, scope: !3729, inlinedAt: !3717)
!3739 = !DILocation(line: 1362, column: 27, scope: !3740, inlinedAt: !3717)
!3740 = distinct !DILexicalBlock(scope: !3729, file: !3, line: 1361, column: 22)
!3741 = !DILocation(line: 1362, column: 13, scope: !3740, inlinedAt: !3717)
!3742 = !DILocation(line: 1363, column: 32, scope: !3740, inlinedAt: !3717)
!3743 = !DILocation(line: 1363, column: 13, scope: !3740, inlinedAt: !3717)
!3744 = !DILocation(line: 1364, column: 32, scope: !3740, inlinedAt: !3717)
!3745 = !DILocation(line: 0, scope: !997, inlinedAt: !3746)
!3746 = distinct !DILocation(line: 1364, column: 13, scope: !3740, inlinedAt: !3717)
!3747 = !DILocation(line: 549, column: 9, scope: !1004, inlinedAt: !3746)
!3748 = !DILocation(line: 549, column: 27, scope: !1004, inlinedAt: !3746)
!3749 = !DILocation(line: 549, column: 9, scope: !997, inlinedAt: !3746)
!3750 = !DILocation(line: 0, scope: !1008, inlinedAt: !3751)
!3751 = distinct !DILocation(line: 550, column: 9, scope: !1014, inlinedAt: !3746)
!3752 = !DILocation(line: 356, column: 21, scope: !1008, inlinedAt: !3751)
!3753 = !DILocation(line: 364, column: 13, scope: !1008, inlinedAt: !3751)
!3754 = !DILocation(line: 366, column: 5, scope: !1008, inlinedAt: !3751)
!3755 = !DILocation(line: 551, column: 5, scope: !1014, inlinedAt: !3746)
!3756 = !DILocation(line: 1365, column: 29, scope: !3740, inlinedAt: !3717)
!3757 = !DILocation(line: 1365, column: 13, scope: !3740, inlinedAt: !3717)
!3758 = !DILocation(line: 1366, column: 15, scope: !3740, inlinedAt: !3717)
!3759 = !DILocation(line: 1367, column: 18, scope: !3740, inlinedAt: !3717)
!3760 = distinct !{!3760, !3738, !3761, !723}
!3761 = !DILocation(line: 1368, column: 9, scope: !3729, inlinedAt: !3717)
!3762 = !DILocation(line: 1350, column: 45, scope: !3723, inlinedAt: !3717)
!3763 = distinct !{!3763, !3724, !3764, !723}
!3764 = !DILocation(line: 1373, column: 5, scope: !3721, inlinedAt: !3717)
!3765 = !DILocation(line: 1370, column: 9, scope: !3729, inlinedAt: !3717)
!3766 = !DILocation(line: 1371, column: 48, scope: !3729, inlinedAt: !3717)
!3767 = !DILocation(line: 1371, column: 53, scope: !3729, inlinedAt: !3717)
!3768 = !DILocation(line: 1371, column: 33, scope: !3729, inlinedAt: !3717)
!3769 = !DILocation(line: 1372, column: 9, scope: !3729, inlinedAt: !3717)
!3770 = !DILocation(line: 1666, column: 13, scope: !3498)
!3771 = !DILocation(line: 0, scope: !3498)
!3772 = !DILocation(line: 1671, column: 22, scope: !3773)
!3773 = distinct !DILexicalBlock(scope: !3498, file: !3, line: 1671, column: 13)
!3774 = !{!788, !791, i64 134}
!3775 = !DILocation(line: 1671, column: 34, scope: !3773)
!3776 = !DILocation(line: 1671, column: 59, scope: !3773)
!3777 = !DILocation(line: 1671, column: 56, scope: !3773)
!3778 = !DILocation(line: 1671, column: 13, scope: !3498)
!3779 = !DILocation(line: 0, scope: !607, inlinedAt: !3780)
!3780 = distinct !DILocation(line: 1672, column: 13, scope: !3781)
!3781 = distinct !DILexicalBlock(scope: !3773, file: !3, line: 1671, column: 73)
!3782 = !DILocation(line: 1480, column: 5, scope: !607, inlinedAt: !3780)
!3783 = !DILocation(line: 1481, column: 5, scope: !607, inlinedAt: !3780)
!3784 = distinct !DIAssignID()
!3785 = !DILocation(line: 1486, column: 5, scope: !646, inlinedAt: !3780)
!3786 = !DILocation(line: 1487, column: 30, scope: !644, inlinedAt: !3780)
!3787 = !DILocation(line: 0, scope: !644, inlinedAt: !3780)
!3788 = !DILocation(line: 1489, column: 16, scope: !650, inlinedAt: !3780)
!3789 = !{!3790, !791, i64 528}
!3790 = !{!"", !748, i64 0, !747, i64 488, !747, i64 496, !747, i64 504, !747, i64 512, !750, i64 520, !750, i64 524, !791, i64 528}
!3791 = !DILocation(line: 1489, column: 13, scope: !644, inlinedAt: !3780)
!3792 = !DILocation(line: 0, scope: !649, inlinedAt: !3780)
!3793 = !DILocation(line: 1491, column: 13, scope: !649, inlinedAt: !3780)
!3794 = !DILocation(line: 1494, column: 45, scope: !649, inlinedAt: !3780)
!3795 = !{!3790, !747, i64 512}
!3796 = !DILocation(line: 1494, column: 55, scope: !649, inlinedAt: !3780)
!3797 = !{!3790, !747, i64 496}
!3798 = !DILocation(line: 1494, column: 50, scope: !649, inlinedAt: !3780)
!3799 = !DILocation(line: 1499, column: 57, scope: !649, inlinedAt: !3780)
!3800 = !DILocation(line: 1499, column: 64, scope: !649, inlinedAt: !3780)
!3801 = !DILocation(line: 1500, column: 36, scope: !649, inlinedAt: !3780)
!3802 = !DILocation(line: 1500, column: 54, scope: !649, inlinedAt: !3780)
!3803 = !{!3790, !750, i64 524}
!3804 = !DILocation(line: 1500, column: 49, scope: !649, inlinedAt: !3780)
!3805 = !DILocation(line: 1502, column: 13, scope: !3806, inlinedAt: !3780)
!3806 = distinct !DILexicalBlock(scope: !649, file: !3, line: 1502, column: 13)
!3807 = !DILocation(line: 1503, column: 39, scope: !3808, inlinedAt: !3780)
!3808 = distinct !DILexicalBlock(scope: !3809, file: !3, line: 1502, column: 38)
!3809 = distinct !DILexicalBlock(scope: !3806, file: !3, line: 1502, column: 13)
!3810 = !DILocation(line: 1503, column: 36, scope: !3808, inlinedAt: !3780)
!3811 = !DILocation(line: 1504, column: 40, scope: !3812, inlinedAt: !3780)
!3812 = distinct !DILexicalBlock(scope: !3808, file: !3, line: 1504, column: 21)
!3813 = !DILocation(line: 1504, column: 21, scope: !3808, inlinedAt: !3780)
!3814 = !DILocation(line: 1505, column: 25, scope: !3815, inlinedAt: !3780)
!3815 = distinct !DILexicalBlock(scope: !3816, file: !3, line: 1505, column: 25)
!3816 = distinct !DILexicalBlock(scope: !3812, file: !3, line: 1504, column: 57)
!3817 = !DILocation(line: 1505, column: 49, scope: !3815, inlinedAt: !3780)
!3818 = !DILocation(line: 1505, column: 44, scope: !3815, inlinedAt: !3780)
!3819 = !DILocation(line: 1505, column: 25, scope: !3816, inlinedAt: !3780)
!3820 = !DILocation(line: 1506, column: 44, scope: !3821, inlinedAt: !3780)
!3821 = distinct !DILexicalBlock(scope: !3815, file: !3, line: 1505, column: 56)
!3822 = !DILocation(line: 1507, column: 21, scope: !3821, inlinedAt: !3780)
!3823 = !DILocation(line: 1507, column: 51, scope: !3824, inlinedAt: !3780)
!3824 = distinct !DILexicalBlock(scope: !3815, file: !3, line: 1507, column: 32)
!3825 = !DILocation(line: 1507, column: 32, scope: !3815, inlinedAt: !3780)
!3826 = !DILocation(line: 1508, column: 44, scope: !3827, inlinedAt: !3780)
!3827 = distinct !DILexicalBlock(scope: !3824, file: !3, line: 1507, column: 58)
!3828 = !DILocation(line: 1509, column: 21, scope: !3827, inlinedAt: !3780)
!3829 = !DILocation(line: 1502, column: 34, scope: !3809, inlinedAt: !3780)
!3830 = !DILocation(line: 1502, column: 27, scope: !3809, inlinedAt: !3780)
!3831 = distinct !{!3831, !3805, !3832, !723}
!3832 = !DILocation(line: 1512, column: 13, scope: !3806, inlinedAt: !3780)
!3833 = !DILocation(line: 1514, column: 36, scope: !3834, inlinedAt: !3780)
!3834 = distinct !DILexicalBlock(scope: !649, file: !3, line: 1514, column: 17)
!3835 = !DILocation(line: 1514, column: 17, scope: !649, inlinedAt: !3780)
!3836 = !DILocation(line: 1515, column: 36, scope: !3837, inlinedAt: !3780)
!3837 = distinct !DILexicalBlock(scope: !3834, file: !3, line: 1514, column: 42)
!3838 = !DILocation(line: 1516, column: 13, scope: !3837, inlinedAt: !3780)
!3839 = !DILocation(line: 1518, column: 17, scope: !3840, inlinedAt: !3780)
!3840 = distinct !DILexicalBlock(scope: !649, file: !3, line: 1518, column: 17)
!3841 = !DILocation(line: 1518, column: 36, scope: !3840, inlinedAt: !3780)
!3842 = !DILocation(line: 1518, column: 17, scope: !649, inlinedAt: !3780)
!3843 = !DILocation(line: 1519, column: 36, scope: !3844, inlinedAt: !3780)
!3844 = distinct !DILexicalBlock(scope: !3840, file: !3, line: 1518, column: 59)
!3845 = !DILocation(line: 1520, column: 13, scope: !3844, inlinedAt: !3780)
!3846 = !DILocation(line: 1522, column: 45, scope: !649, inlinedAt: !3780)
!3847 = !DILocation(line: 1522, column: 30, scope: !649, inlinedAt: !3780)
!3848 = !DILocation(line: 1522, column: 43, scope: !649, inlinedAt: !3780)
!3849 = !DILocation(line: 1522, column: 64, scope: !649, inlinedAt: !3780)
!3850 = !DILocation(line: 1522, column: 13, scope: !649, inlinedAt: !3780)
!3851 = !DILocation(line: 1522, column: 28, scope: !649, inlinedAt: !3780)
!3852 = !DILocation(line: 0, scope: !657, inlinedAt: !3780)
!3853 = !DILocation(line: 1537, column: 13, scope: !3854, inlinedAt: !3780)
!3854 = distinct !DILexicalBlock(scope: !657, file: !3, line: 1537, column: 13)
!3855 = !DILocation(line: 1537, column: 13, scope: !657, inlinedAt: !3780)
!3856 = !DILocation(line: 1523, column: 13, scope: !649, inlinedAt: !3780)
!3857 = !{!3790, !750, i64 520}
!3858 = !{!3790, !747, i64 504}
!3859 = !DILocation(line: 1548, column: 29, scope: !649, inlinedAt: !3780)
!3860 = !DILocation(line: 1549, column: 13, scope: !649, inlinedAt: !3780)
!3861 = !DILocation(line: 1550, column: 9, scope: !649, inlinedAt: !3780)
!3862 = !DILocation(line: 1551, column: 13, scope: !3863, inlinedAt: !3780)
!3863 = distinct !DILexicalBlock(scope: !644, file: !3, line: 1551, column: 13)
!3864 = !DILocation(line: 1551, column: 28, scope: !3863, inlinedAt: !3780)
!3865 = !DILocation(line: 1551, column: 26, scope: !3863, inlinedAt: !3780)
!3866 = !DILocation(line: 1551, column: 13, scope: !644, inlinedAt: !3780)
!3867 = !DILocation(line: 1486, column: 50, scope: !645, inlinedAt: !3780)
!3868 = !DILocation(line: 1486, column: 32, scope: !645, inlinedAt: !3780)
!3869 = distinct !{!3869, !3785, !3870, !723}
!3870 = !DILocation(line: 1561, column: 5, scope: !646, inlinedAt: !3780)
!3871 = !DILocation(line: 1552, column: 33, scope: !3872, inlinedAt: !3780)
!3872 = distinct !DILexicalBlock(scope: !3863, file: !3, line: 1551, column: 44)
!3873 = !DILocation(line: 1552, column: 13, scope: !3872, inlinedAt: !3780)
!3874 = !DILocation(line: 1553, column: 17, scope: !3875, inlinedAt: !3780)
!3875 = distinct !DILexicalBlock(scope: !3872, file: !3, line: 1553, column: 17)
!3876 = !DILocation(line: 1553, column: 17, scope: !3872, inlinedAt: !3780)
!3877 = !DILocation(line: 1556, column: 13, scope: !3872, inlinedAt: !3780)
!3878 = !DILocation(line: 1557, column: 13, scope: !3872, inlinedAt: !3780)
!3879 = !DILocation(line: 1557, column: 21, scope: !3872, inlinedAt: !3780)
!3880 = !DILocation(line: 1559, column: 30, scope: !3872, inlinedAt: !3780)
!3881 = !DILocation(line: 1559, column: 43, scope: !3872, inlinedAt: !3780)
!3882 = !DILocation(line: 1559, column: 28, scope: !3872, inlinedAt: !3780)
!3883 = distinct !{!3883, !3785, !3870, !723}
!3884 = !DILocation(line: 1562, column: 9, scope: !607, inlinedAt: !3780)
!3885 = !DILocation(line: 1563, column: 22, scope: !3886, inlinedAt: !3780)
!3886 = distinct !DILexicalBlock(scope: !3887, file: !3, line: 1563, column: 13)
!3887 = distinct !DILexicalBlock(scope: !3888, file: !3, line: 1562, column: 17)
!3888 = distinct !DILexicalBlock(scope: !607, file: !3, line: 1562, column: 9)
!3889 = !{!788, !750, i64 188}
!3890 = !DILocation(line: 1563, column: 13, scope: !3886, inlinedAt: !3780)
!3891 = !DILocation(line: 1563, column: 42, scope: !3886, inlinedAt: !3780)
!3892 = !DILocation(line: 1566, column: 9, scope: !3887, inlinedAt: !3780)
!3893 = !DILocation(line: 1567, column: 5, scope: !3887, inlinedAt: !3780)
!3894 = !DILocation(line: 1568, column: 1, scope: !607, inlinedAt: !3780)
!3895 = !DILocation(line: 1673, column: 34, scope: !3781)
!3896 = !DILocation(line: 1674, column: 9, scope: !3781)
!3897 = !DILocation(line: 1676, column: 22, scope: !3501)
!3898 = !DILocation(line: 1676, column: 36, scope: !3501)
!3899 = !DILocation(line: 1676, column: 41, scope: !3501)
!3900 = !DILocation(line: 1676, column: 67, scope: !3501)
!3901 = !DILocation(line: 1676, column: 64, scope: !3501)
!3902 = !DILocation(line: 1676, column: 13, scope: !3498)
!3903 = !DILocation(line: 1677, column: 40, scope: !3904)
!3904 = distinct !DILexicalBlock(scope: !3500, file: !3, line: 1677, column: 17)
!3905 = !DILocation(line: 1677, column: 28, scope: !3904)
!3906 = !DILocation(line: 1677, column: 17, scope: !3500)
!3907 = !DILocation(line: 1678, column: 22, scope: !3908)
!3908 = distinct !DILexicalBlock(scope: !3904, file: !3, line: 1677, column: 61)
!3909 = !DILocation(line: 1678, column: 17, scope: !3908)
!3910 = !DILocation(line: 1679, column: 27, scope: !3908)
!3911 = !DILocation(line: 1679, column: 22, scope: !3908)
!3912 = !DILocation(line: 1680, column: 39, scope: !3908)
!3913 = !DILocation(line: 1681, column: 13, scope: !3908)
!3914 = !DILocation(line: 1682, column: 13, scope: !3500)
!3915 = !DILocation(line: 1683, column: 18, scope: !3500)
!3916 = !DILocation(line: 1683, column: 13, scope: !3500)
!3917 = !DILocation(line: 1684, column: 17, scope: !3506)
!3918 = !DILocation(line: 1684, column: 21, scope: !3506)
!3919 = !DILocation(line: 1684, column: 27, scope: !3506)
!3920 = !DILocation(line: 1684, column: 30, scope: !3506)
!3921 = !DILocation(line: 1684, column: 34, scope: !3506)
!3922 = !DILocation(line: 1684, column: 17, scope: !3500)
!3923 = !DILocation(line: 1685, column: 17, scope: !3505)
!3924 = !DILocation(line: 0, scope: !3504)
!3925 = !DILocation(line: 1686, column: 17, scope: !3926)
!3926 = distinct !DILexicalBlock(scope: !3504, file: !3, line: 1686, column: 17)
!3927 = !DILocation(line: 1686, column: 17, scope: !3504)
!3928 = !DILocation(line: 1690, column: 17, scope: !3929)
!3929 = distinct !DILexicalBlock(scope: !3500, file: !3, line: 1690, column: 17)
!3930 = !DILocation(line: 1690, column: 21, scope: !3929)
!3931 = !DILocation(line: 1690, column: 17, scope: !3500)
!3932 = !DILocation(line: 1691, column: 39, scope: !3933)
!3933 = distinct !DILexicalBlock(scope: !3929, file: !3, line: 1690, column: 27)
!3934 = !DILocation(line: 1692, column: 13, scope: !3933)
!3935 = !DILocation(line: 1696, column: 9, scope: !3501)
!3936 = !DILocation(line: 1696, column: 9, scope: !3500)
!3937 = distinct !{!3937, !3560, !3938, !723}
!3938 = !DILocation(line: 1697, column: 5, scope: !3474)
!3939 = !DILocation(line: 1698, column: 5, scope: !3474)
!3940 = !DILocation(line: 1699, column: 10, scope: !3474)
!3941 = !DILocation(line: 1699, column: 5, scope: !3474)
!3942 = !DILocation(line: 1701, column: 5, scope: !3474)
!3943 = !DILocation(line: 1702, column: 18, scope: !3944)
!3944 = distinct !DILexicalBlock(scope: !3474, file: !3, line: 1702, column: 9)
!3945 = !DILocation(line: 1702, column: 26, scope: !3944)
!3946 = !DILocation(line: 1702, column: 9, scope: !3474)
!3947 = !DILocation(line: 1703, column: 17, scope: !3944)
!3948 = !DILocation(line: 1703, column: 9, scope: !3944)
!3949 = !DILocation(line: 1706, column: 1, scope: !3474)
!3950 = !DILocation(line: 1705, column: 5, scope: !3474)
!3951 = !DISubprogram(name: "thread_setname", scope: !6, file: !6, line: 1033, type: !3952, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3952 = !DISubroutineType(types: !3953)
!3953 = !{null, !551, !1320}
!3954 = distinct !DISubprogram(name: "lru_maintainer_pause", scope: !3, file: !3, line: 1742, type: !705, scopeLine: 1742, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!3955 = !DILocation(line: 1743, column: 5, scope: !3954)
!3956 = !DILocation(line: 1744, column: 1, scope: !3954)
!3957 = distinct !DISubprogram(name: "lru_maintainer_resume", scope: !3, file: !3, line: 1746, type: !705, scopeLine: 1746, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!3958 = !DILocation(line: 1747, column: 5, scope: !3957)
!3959 = !DILocation(line: 1748, column: 1, scope: !3957)
!3960 = distinct !DISubprogram(name: "do_item_linktail_q", scope: !3, file: !3, line: 1751, type: !998, scopeLine: 1751, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3961)
!3961 = !{!3962, !3963, !3964}
!3962 = !DILocalVariable(name: "it", arg: 1, scope: !3960, file: !3, line: 1751, type: !263)
!3963 = !DILocalVariable(name: "head", scope: !3960, file: !3, line: 1752, type: !1056)
!3964 = !DILocalVariable(name: "tail", scope: !3960, file: !3, line: 1752, type: !1056)
!3965 = !DILocation(line: 0, scope: !3960)
!3966 = !DILocation(line: 1756, column: 23, scope: !3960)
!3967 = !DILocation(line: 1756, column: 13, scope: !3960)
!3968 = !DILocation(line: 1757, column: 13, scope: !3960)
!3969 = !DILocation(line: 1761, column: 16, scope: !3960)
!3970 = !DILocation(line: 1761, column: 9, scope: !3960)
!3971 = !DILocation(line: 1761, column: 14, scope: !3960)
!3972 = !DILocation(line: 1762, column: 14, scope: !3960)
!3973 = !DILocation(line: 1763, column: 9, scope: !3974)
!3974 = distinct !DILexicalBlock(scope: !3960, file: !3, line: 1763, column: 9)
!3975 = !DILocation(line: 1763, column: 9, scope: !3960)
!3976 = !DILocation(line: 1765, column: 24, scope: !3977)
!3977 = distinct !DILexicalBlock(scope: !3974, file: !3, line: 1763, column: 19)
!3978 = !DILocation(line: 1766, column: 5, scope: !3977)
!3979 = !DILocation(line: 1767, column: 11, scope: !3960)
!3980 = !DILocation(line: 1768, column: 9, scope: !3981)
!3981 = distinct !DILexicalBlock(scope: !3960, file: !3, line: 1768, column: 9)
!3982 = !DILocation(line: 1768, column: 15, scope: !3981)
!3983 = !DILocation(line: 1768, column: 9, scope: !3960)
!3984 = !DILocation(line: 1768, column: 27, scope: !3981)
!3985 = !DILocation(line: 1768, column: 21, scope: !3981)
!3986 = !DILocation(line: 1770, column: 1, scope: !3960)
!3987 = distinct !DISubprogram(name: "do_item_unlinktail_q", scope: !3, file: !3, line: 1772, type: !998, scopeLine: 1772, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3988)
!3988 = !{!3989, !3990, !3991}
!3989 = !DILocalVariable(name: "it", arg: 1, scope: !3987, file: !3, line: 1772, type: !263)
!3990 = !DILocalVariable(name: "head", scope: !3987, file: !3, line: 1773, type: !1056)
!3991 = !DILocalVariable(name: "tail", scope: !3987, file: !3, line: 1773, type: !1056)
!3992 = !DILocation(line: 0, scope: !3987)
!3993 = !DILocation(line: 1774, column: 23, scope: !3987)
!3994 = !DILocation(line: 1774, column: 13, scope: !3987)
!3995 = !DILocation(line: 1775, column: 13, scope: !3987)
!3996 = !DILocation(line: 1777, column: 9, scope: !3997)
!3997 = distinct !DILexicalBlock(scope: !3987, file: !3, line: 1777, column: 9)
!3998 = !DILocation(line: 1777, column: 15, scope: !3997)
!3999 = !DILocation(line: 1777, column: 9, scope: !3987)
!4000 = !DILocation(line: 1779, column: 21, scope: !4001)
!4001 = distinct !DILexicalBlock(scope: !3997, file: !3, line: 1777, column: 22)
!4002 = !DILocation(line: 1779, column: 15, scope: !4001)
!4003 = !DILocation(line: 1780, column: 5, scope: !4001)
!4004 = !DILocation(line: 1781, column: 9, scope: !4005)
!4005 = distinct !DILexicalBlock(scope: !3987, file: !3, line: 1781, column: 9)
!4006 = !DILocation(line: 1781, column: 15, scope: !4005)
!4007 = !DILocation(line: 1781, column: 9, scope: !3987)
!4008 = !DILocation(line: 1783, column: 21, scope: !4009)
!4009 = distinct !DILexicalBlock(scope: !4005, file: !3, line: 1781, column: 22)
!4010 = !DILocation(line: 1783, column: 15, scope: !4009)
!4011 = !DILocation(line: 1784, column: 5, scope: !4009)
!4012 = !DILocation(line: 1788, column: 13, scope: !4013)
!4013 = distinct !DILexicalBlock(scope: !3987, file: !3, line: 1788, column: 9)
!4014 = !DILocation(line: 1788, column: 9, scope: !4013)
!4015 = !DILocation(line: 1788, column: 9, scope: !3987)
!4016 = !DILocation(line: 1788, column: 29, scope: !4013)
!4017 = !DILocation(line: 1788, column: 34, scope: !4013)
!4018 = !DILocation(line: 1788, column: 19, scope: !4013)
!4019 = !DILocation(line: 1789, column: 9, scope: !4020)
!4020 = distinct !DILexicalBlock(scope: !3987, file: !3, line: 1789, column: 9)
!4021 = !DILocation(line: 1789, column: 9, scope: !3987)
!4022 = !DILocation(line: 1789, column: 40, scope: !4020)
!4023 = !DILocation(line: 1789, column: 34, scope: !4020)
!4024 = !DILocation(line: 1789, column: 19, scope: !4020)
!4025 = !DILocation(line: 1791, column: 1, scope: !3987)
!4026 = distinct !DISubprogram(name: "do_item_crawl_q", scope: !3, file: !3, line: 1795, type: !4027, scopeLine: 1795, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !4029)
!4027 = !DISubroutineType(types: !4028)
!4028 = !{!263, !263}
!4029 = !{!4030, !4031, !4032}
!4030 = !DILocalVariable(name: "it", arg: 1, scope: !4026, file: !3, line: 1795, type: !263)
!4031 = !DILocalVariable(name: "head", scope: !4026, file: !3, line: 1796, type: !1056)
!4032 = !DILocalVariable(name: "tail", scope: !4026, file: !3, line: 1796, type: !1056)
!4033 = !DILocation(line: 0, scope: !4026)
!4034 = !DILocation(line: 1799, column: 23, scope: !4026)
!4035 = !DILocation(line: 1799, column: 13, scope: !4026)
!4036 = !DILocation(line: 1800, column: 13, scope: !4026)
!4037 = !DILocation(line: 1803, column: 13, scope: !4038)
!4038 = distinct !DILexicalBlock(scope: !4026, file: !3, line: 1803, column: 9)
!4039 = !DILocation(line: 1803, column: 18, scope: !4038)
!4040 = !DILocation(line: 1803, column: 9, scope: !4026)
!4041 = !DILocation(line: 1805, column: 17, scope: !4042)
!4042 = distinct !DILexicalBlock(scope: !4043, file: !3, line: 1805, column: 13)
!4043 = distinct !DILexicalBlock(scope: !4038, file: !3, line: 1803, column: 24)
!4044 = !DILocation(line: 1805, column: 13, scope: !4042)
!4045 = !DILocation(line: 1805, column: 13, scope: !4043)
!4046 = !DILocation(line: 1806, column: 19, scope: !4047)
!4047 = distinct !DILexicalBlock(scope: !4042, file: !3, line: 1805, column: 23)
!4048 = !DILocation(line: 1808, column: 23, scope: !4047)
!4049 = !DILocation(line: 1808, column: 28, scope: !4047)
!4050 = !DILocation(line: 1809, column: 9, scope: !4047)
!4051 = !DILocation(line: 1817, column: 13, scope: !4052)
!4052 = distinct !DILexicalBlock(scope: !4053, file: !3, line: 1817, column: 13)
!4053 = distinct !DILexicalBlock(scope: !4054, file: !3, line: 1816, column: 19)
!4054 = distinct !DILexicalBlock(scope: !4026, file: !3, line: 1816, column: 9)
!4055 = !DILocation(line: 1817, column: 19, scope: !4052)
!4056 = !DILocation(line: 1817, column: 13, scope: !4053)
!4057 = !DILocation(line: 1819, column: 19, scope: !4058)
!4058 = distinct !DILexicalBlock(scope: !4052, file: !3, line: 1817, column: 32)
!4059 = !DILocation(line: 1820, column: 9, scope: !4058)
!4060 = !DILocation(line: 1821, column: 13, scope: !4061)
!4061 = distinct !DILexicalBlock(scope: !4053, file: !3, line: 1821, column: 13)
!4062 = !DILocation(line: 1821, column: 19, scope: !4061)
!4063 = !DILocation(line: 1821, column: 13, scope: !4053)
!4064 = !DILocation(line: 1823, column: 19, scope: !4065)
!4065 = distinct !DILexicalBlock(scope: !4061, file: !3, line: 1821, column: 26)
!4066 = !DILocation(line: 1824, column: 9, scope: !4065)
!4067 = !DILocation(line: 1826, column: 17, scope: !4068)
!4068 = distinct !DILexicalBlock(scope: !4053, file: !3, line: 1826, column: 13)
!4069 = !DILocation(line: 1826, column: 13, scope: !4068)
!4070 = !DILocation(line: 1826, column: 13, scope: !4053)
!4071 = !DILocation(line: 1828, column: 28, scope: !4072)
!4072 = distinct !DILexicalBlock(scope: !4068, file: !3, line: 1826, column: 23)
!4073 = !DILocation(line: 1829, column: 34, scope: !4072)
!4074 = !DILocation(line: 1829, column: 17, scope: !4072)
!4075 = !DILocation(line: 1829, column: 23, scope: !4072)
!4076 = !DILocation(line: 1829, column: 28, scope: !4072)
!4077 = !DILocation(line: 1830, column: 9, scope: !4072)
!4078 = !DILocation(line: 1832, column: 28, scope: !4079)
!4079 = distinct !DILexicalBlock(scope: !4068, file: !3, line: 1830, column: 16)
!4080 = !DILocation(line: 1835, column: 24, scope: !4053)
!4081 = !DILocation(line: 1835, column: 18, scope: !4053)
!4082 = !DILocation(line: 1836, column: 30, scope: !4053)
!4083 = !DILocation(line: 1836, column: 18, scope: !4053)
!4084 = !DILocation(line: 1837, column: 24, scope: !4053)
!4085 = !DILocation(line: 1839, column: 17, scope: !4086)
!4086 = distinct !DILexicalBlock(scope: !4053, file: !3, line: 1839, column: 13)
!4087 = !DILocation(line: 1839, column: 13, scope: !4086)
!4088 = !DILocation(line: 1839, column: 13, scope: !4053)
!4089 = !DILocation(line: 1840, column: 28, scope: !4090)
!4090 = distinct !DILexicalBlock(scope: !4086, file: !3, line: 1839, column: 23)
!4091 = !DILocation(line: 1841, column: 9, scope: !4090)
!4092 = !DILocation(line: 1846, column: 16, scope: !4026)
!4093 = !DILocation(line: 1846, column: 5, scope: !4026)
!4094 = !DILocation(line: 1847, column: 1, scope: !4026)
!4095 = !DISubprogram(name: "bipbuf_request", scope: !198, file: !198, line: 41, type: !4096, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!4096 = !DISubroutineType(types: !4097)
!4097 = !{!4098, !196, !734}
!4098 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !124, size: 64)
!4099 = !DISubprogram(name: "bipbuf_push", scope: !198, file: !198, line: 42, type: !4100, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!4100 = !DISubroutineType(types: !4101)
!4101 = !{!113, !196, !734}
!4102 = !DISubprogram(name: "abort", scope: !2179, file: !2179, line: 730, type: !705, flags: DIFlagPrototyped | DIFlagNoReturn, spFlags: DISPFlagOptimized)
!4103 = !DISubprogram(name: "logger_create", scope: !40, file: !40, line: 227, type: !4104, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!4104 = !DISubroutineType(types: !4105)
!4105 = !{!151}
!4106 = !DISubprogram(name: "usleep", scope: !4107, file: !4107, line: 480, type: !4108, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!4107 = !DIFile(filename: "/usr/include/unistd.h", directory: "", checksumkind: CSK_MD5, checksum: "877e832a8bb8424f9180387a13787475")
!4108 = !DISubroutineType(types: !4109)
!4109 = !{!113, !3483}
!4110 = !DISubprogram(name: "slabs_available_chunks", scope: !80, file: !80, line: 47, type: !4111, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!4111 = !DISubroutineType(types: !4112)
!4112 = !{!7, !7, !4113, !561}
!4113 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !455, size: 64)
!4114 = !DISubprogram(name: "bipbuf_peek_all", scope: !198, file: !198, line: 62, type: !4115, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!4115 = !DISubroutineType(types: !4116)
!4116 = !{!4098, !4117, !561}
!4117 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !4118, size: 64)
!4118 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !197)
!4119 = !DISubprogram(name: "item_lock", scope: !6, file: !6, line: 1017, type: !4120, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!4120 = !DISubroutineType(types: !4121)
!4121 = !{null, !266}
!4122 = !DISubprogram(name: "item_unlock", scope: !6, file: !6, line: 1020, type: !4120, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!4123 = !DISubprogram(name: "bipbuf_poll", scope: !198, file: !198, line: 69, type: !4124, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!4124 = !DISubroutineType(types: !4125)
!4125 = !{!4098, !196, !814}
!4126 = !DISubprogram(name: "lru_crawler_start", scope: !612, file: !612, line: 37, type: !4127, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!4127 = !DISubroutineType(types: !4128)
!4128 = !{!113, !1351, !266, !4129, !94, !94, !734}
!4129 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !87)
