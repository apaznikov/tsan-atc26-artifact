; ModuleID = 'slab_automove_extstore.c'
source_filename = "slab_automove_extstore.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.settings = type { i64, i32, i32, i32, ptr, i32, i32, i32, ptr, ptr, i32, double, i32, i32, i32, i8, i32, i32, i8, i32, i32, i32, i32, i32, i32, i8, i8, i8, i8, i8, i8, i32, double, i32, i32, i8, i32, i8, i8, ptr, i32, i32, i32, i32, double, double, i32, i8, i32, i32, i32, i32, i32, i8, i8, i8, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, double, double, i8, i32, i32, ptr, i32 }
%struct.slab_stats_automove = type { i32, i32, i64, i64 }
%struct.window_data = type { i64, i64, i64, i32, i32 }
%struct.item_stats_automove = type { i64, i64, i32 }

@settings = external local_unnamed_addr global %struct.settings, align 8
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef ptr @slab_automove_extstore_init(ptr noundef %settings) local_unnamed_addr #0 !dbg !164 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %settings, metadata !168, metadata !DIExpression()), !dbg !172
  %slab_automove_window = getelementptr inbounds i8, ptr %settings, i64 152, !dbg !173
  %0 = load i32, ptr %slab_automove_window, align 8, !dbg !173, !tbaa !174
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !169, metadata !DIExpression()), !dbg !172
  %slab_automove_ratio = getelementptr inbounds i8, ptr %settings, i64 144, !dbg !183
  %1 = load double, ptr %slab_automove_ratio, align 8, !dbg !183, !tbaa !184
  tail call void @llvm.dbg.value(metadata double %1, metadata !170, metadata !DIExpression()), !dbg !172
  %call = tail call noalias dereferenceable_or_null(6200) ptr @calloc(i64 noundef 1, i64 noundef 6200) #10, !dbg !185
  tail call void @llvm.dbg.value(metadata ptr %call, metadata !171, metadata !DIExpression()), !dbg !172
  %cmp = icmp eq ptr %call, null, !dbg !186
  br i1 %cmp, label %cleanup, label %if.end, !dbg !188

if.end:                                           ; preds = %entry
  %mul = shl i32 %0, 6, !dbg !189
  %conv = zext i32 %mul to i64, !dbg !190
  %call1 = tail call noalias ptr @calloc(i64 noundef %conv, i64 noundef 32) #10, !dbg !191
  store ptr %call1, ptr %call, align 8, !dbg !192, !tbaa !193
  %window_size2 = getelementptr inbounds i8, ptr %call, i64 16, !dbg !195
  store i32 %0, ptr %window_size2, align 8, !dbg !196, !tbaa !197
  %max_age_ratio3 = getelementptr inbounds i8, ptr %call, i64 32, !dbg !198
  store double %1, ptr %max_age_ratio3, align 8, !dbg !199, !tbaa !200
  %slab_automove_freeratio = getelementptr inbounds i8, ptr %settings, i64 296, !dbg !201
  %2 = load double, ptr %slab_automove_freeratio, align 8, !dbg !201, !tbaa !202
  %free_ratio = getelementptr inbounds i8, ptr %call, i64 40, !dbg !203
  store double %2, ptr %free_ratio, align 8, !dbg !204, !tbaa !205
  %ext_item_size = getelementptr inbounds i8, ptr %settings, i64 256, !dbg !206
  %3 = load i32, ptr %ext_item_size, align 8, !dbg !206, !tbaa !207
  %item_size = getelementptr inbounds i8, ptr %call, i64 24, !dbg !208
  store i32 %3, ptr %item_size, align 8, !dbg !209, !tbaa !210
  %settings4 = getelementptr inbounds i8, ptr %call, i64 8, !dbg !211
  store ptr %settings, ptr %settings4, align 8, !dbg !212, !tbaa !213
  %cmp6 = icmp eq ptr %call1, null, !dbg !214
  br i1 %cmp6, label %if.end12, label %if.end13, !dbg !216

if.end12:                                         ; preds = %if.end
  tail call void @free(ptr noundef nonnull %call) #11, !dbg !217
  br label %cleanup, !dbg !219

if.end13:                                         ; preds = %if.end
  %iam_before = getelementptr inbounds i8, ptr %call, i64 56, !dbg !220
  tail call void @fill_item_stats_automove(ptr noundef nonnull %iam_before) #11, !dbg !221
  %sam_before = getelementptr inbounds i8, ptr %call, i64 3128, !dbg !222
  tail call void @fill_slab_stats_automove(ptr noundef nonnull %sam_before) #11, !dbg !223
  br label %cleanup, !dbg !224

cleanup:                                          ; preds = %entry, %if.end13, %if.end12
  %retval.0 = phi ptr [ null, %if.end12 ], [ %call, %if.end13 ], [ null, %entry ], !dbg !172
  ret ptr %retval.0, !dbg !225
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite)
declare !dbg !226 noalias noundef ptr @calloc(i64 noundef, i64 noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !230 void @free(ptr allocptr nocapture noundef) local_unnamed_addr #3

declare !dbg !233 void @fill_item_stats_automove(ptr noundef) local_unnamed_addr #4

declare !dbg !237 void @fill_slab_stats_automove(ptr noundef) local_unnamed_addr #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nounwind sanitize_thread willreturn uwtable
define dso_local void @slab_automove_extstore_free(ptr nocapture noundef %arg) local_unnamed_addr #5 !dbg !241 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !243, metadata !DIExpression()), !dbg !245
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !244, metadata !DIExpression()), !dbg !245
  %0 = load ptr, ptr %arg, align 8, !dbg !246, !tbaa !193
  tail call void @free(ptr noundef %0) #11, !dbg !247
  tail call void @free(ptr noundef %arg) #11, !dbg !248
  ret void, !dbg !249
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @slab_automove_extstore_run(ptr noundef %arg, ptr nocapture noundef writeonly %src, ptr nocapture noundef writeonly %dst) local_unnamed_addr #0 !dbg !250 {
entry:
  %mem_limit_reached.i = alloca i8, align 1, !DIAssignID !273
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !255, metadata !DIExpression()), !dbg !274
  tail call void @llvm.dbg.value(metadata ptr %src, metadata !256, metadata !DIExpression()), !dbg !274
  tail call void @llvm.dbg.value(metadata ptr %dst, metadata !257, metadata !DIExpression()), !dbg !274
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !258, metadata !DIExpression()), !dbg !274
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !261, metadata !DIExpression()), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 0, metadata !262, metadata !DIExpression()), !dbg !274
  tail call void @llvm.dbg.value(metadata i8 0, metadata !263, metadata !DIExpression()), !dbg !274
  store i32 -1, ptr %src, align 4, !dbg !275, !tbaa !276
  store i32 -1, ptr %dst, align 4, !dbg !277, !tbaa !276
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !278, metadata !DIExpression(), metadata !273, metadata ptr %mem_limit_reached.i, metadata !DIExpression()), !dbg !286
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !283, metadata !DIExpression()), !dbg !286
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %mem_limit_reached.i) #11, !dbg !288
  %global_pool_watermark.i = getelementptr inbounds i8, ptr %arg, i64 52, !dbg !289
  %0 = load i32, ptr %global_pool_watermark.i, align 4, !dbg !289, !tbaa !290
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !284, metadata !DIExpression()), !dbg !286
  %call.i = call i32 @global_page_pool_size(ptr noundef nonnull %mem_limit_reached.i) #11, !dbg !291
  tail call void @llvm.dbg.value(metadata i32 %call.i, metadata !285, metadata !DIExpression()), !dbg !286
  %1 = load i8, ptr %mem_limit_reached.i, align 1, !dbg !292, !tbaa !294, !range !295, !noundef !296
  %tobool.i = trunc nuw i8 %1 to i1, !dbg !292
  br i1 %tobool.i, label %if.end.i, label %global_pool_check.exit, !dbg !297

if.end.i:                                         ; preds = %entry
  %cmp.i = icmp uge i32 %call.i, %0, !dbg !298
  %pool_filled_once.i = getelementptr inbounds i8, ptr %arg, i64 48, !dbg !300
  store i8 1, ptr %pool_filled_once.i, align 8, !dbg !300, !tbaa !301
  br label %global_pool_check.exit, !dbg !286

global_pool_check.exit:                           ; preds = %entry, %if.end.i
  %retval.0.i = phi i1 [ true, %entry ], [ %cmp.i, %if.end.i ], !dbg !286
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %mem_limit_reached.i) #11, !dbg !302
  tail call void @llvm.dbg.value(metadata i1 %retval.0.i, metadata !264, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_signed, DW_OP_LLVM_convert, 32, DW_ATE_signed, DW_OP_stack_value)), !dbg !274
  %iam_after = getelementptr inbounds i8, ptr %arg, i64 1592, !dbg !303
  call void @fill_item_stats_automove(ptr noundef nonnull %iam_after) #11, !dbg !304
  %sam_after = getelementptr inbounds i8, ptr %arg, i64 4664, !dbg !305
  call void @fill_slab_stats_automove(ptr noundef nonnull %sam_after) #11, !dbg !306
  %window_cur = getelementptr inbounds i8, ptr %arg, i64 20, !dbg !307
  %2 = load i32, ptr %window_cur, align 4, !dbg !308, !tbaa !309
  %inc = add i32 %2, 1, !dbg !308
  store i32 %inc, ptr %window_cur, align 4, !dbg !308, !tbaa !309
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !310, metadata !DIExpression()), !dbg !321
  tail call void @llvm.dbg.value(metadata i32 0, metadata !315, metadata !DIExpression()), !dbg !321
  tail call void @llvm.dbg.value(metadata i32 1, metadata !316, metadata !DIExpression()), !dbg !323
  br label %for.body.i, !dbg !324

for.body.i:                                       ; preds = %for.body.i, %global_pool_check.exit
  %indvars.iv.i = phi i64 [ 1, %global_pool_check.exit ], [ %indvars.iv.next.i.2, %for.body.i ]
  %total_pages.027.i = phi i32 [ 0, %global_pool_check.exit ], [ %conv2.i.2, %for.body.i ]
  tail call void @llvm.dbg.value(metadata i32 %total_pages.027.i, metadata !315, metadata !DIExpression()), !dbg !321
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i, metadata !316, metadata !DIExpression()), !dbg !323
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %sam_after, i64 %indvars.iv.i), metadata !318, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 24, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !325
  %total_pages1.i = getelementptr inbounds [64 x %struct.slab_stats_automove], ptr %sam_after, i64 0, i64 %indvars.iv.i, i32 3, !dbg !326
  %3 = load i64, ptr %total_pages1.i, align 8, !dbg !326, !tbaa !327
  %4 = trunc i64 %3 to i32, !dbg !329
  %conv2.i = add i32 %total_pages.027.i, %4, !dbg !329
  tail call void @llvm.dbg.value(metadata i32 %conv2.i, metadata !315, metadata !DIExpression()), !dbg !321
  %indvars.iv.next.i = add nuw nsw i64 %indvars.iv.i, 1, !dbg !330
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !316, metadata !DIExpression()), !dbg !323
  tail call void @llvm.dbg.value(metadata i32 %conv2.i, metadata !315, metadata !DIExpression()), !dbg !321
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !316, metadata !DIExpression()), !dbg !323
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %sam_after, i64 %indvars.iv.next.i), metadata !318, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 24, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !325
  %total_pages1.i.1 = getelementptr inbounds [64 x %struct.slab_stats_automove], ptr %sam_after, i64 0, i64 %indvars.iv.next.i, i32 3, !dbg !326
  %5 = load i64, ptr %total_pages1.i.1, align 8, !dbg !326, !tbaa !327
  %6 = trunc i64 %5 to i32, !dbg !329
  %conv2.i.1 = add i32 %conv2.i, %6, !dbg !329
  tail call void @llvm.dbg.value(metadata i32 %conv2.i.1, metadata !315, metadata !DIExpression()), !dbg !321
  %indvars.iv.next.i.1 = add nuw nsw i64 %indvars.iv.i, 2, !dbg !330
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.1, metadata !316, metadata !DIExpression()), !dbg !323
  tail call void @llvm.dbg.value(metadata i32 %conv2.i.1, metadata !315, metadata !DIExpression()), !dbg !321
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.1, metadata !316, metadata !DIExpression()), !dbg !323
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr %sam_after, i64 %indvars.iv.next.i.1), metadata !318, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 24, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !325
  %total_pages1.i.2 = getelementptr inbounds [64 x %struct.slab_stats_automove], ptr %sam_after, i64 0, i64 %indvars.iv.next.i.1, i32 3, !dbg !326
  %7 = load i64, ptr %total_pages1.i.2, align 8, !dbg !326, !tbaa !327
  %8 = trunc i64 %7 to i32, !dbg !329
  %conv2.i.2 = add i32 %conv2.i.1, %8, !dbg !329
  tail call void @llvm.dbg.value(metadata i32 %conv2.i.2, metadata !315, metadata !DIExpression()), !dbg !321
  %indvars.iv.next.i.2 = add nuw nsw i64 %indvars.iv.i, 3, !dbg !330
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.2, metadata !316, metadata !DIExpression()), !dbg !323
  %exitcond.not.i.2 = icmp eq i64 %indvars.iv.next.i.2, 64, !dbg !331
  br i1 %exitcond.not.i.2, label %memcheck.exit, label %for.body.i, !dbg !324, !llvm.loop !332

memcheck.exit:                                    ; preds = %for.body.i
  %total_pages5.i = getelementptr inbounds i8, ptr %arg, i64 4680, !dbg !335
  %9 = load i64, ptr %total_pages5.i, align 8, !dbg !335, !tbaa !327
  %10 = trunc i64 %9 to i32, !dbg !336
  %conv8.i = add i32 %conv2.i.2, %10, !dbg !336
  tail call void @llvm.dbg.value(metadata i32 %conv8.i, metadata !315, metadata !DIExpression()), !dbg !321
  %conv9.i = uitofp i32 %conv8.i to double, !dbg !337
  %free_ratio.i = getelementptr inbounds i8, ptr %arg, i64 40, !dbg !338
  %11 = load double, ptr %free_ratio.i, align 8, !dbg !338, !tbaa !205
  %mul.i = fmul double %11, %conv9.i, !dbg !339
  %conv10.i = fptoui double %mul.i to i32, !dbg !337
  %spec.select.i = call i32 @llvm.umax.i32(i32 %conv10.i, i32 2), !dbg !340
  store i32 %spec.select.i, ptr %global_pool_watermark.i, align 4, !dbg !321, !tbaa !290
  store i32 %spec.select.i, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 69), align 4, !dbg !341, !tbaa !342
  tail call void @llvm.dbg.value(metadata i32 1, metadata !259, metadata !DIExpression()), !dbg !274
  %sam_before = getelementptr inbounds i8, ptr %arg, i64 3128
  %item_size = getelementptr inbounds i8, ptr %arg, i64 24
  %window_size.i = getelementptr inbounds i8, ptr %arg, i64 16
  %iam_before = getelementptr inbounds i8, ptr %arg, i64 56
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 224, 32)), !dbg !274
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 32)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata i32 1, metadata !259, metadata !DIExpression()), !dbg !274
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !261, metadata !DIExpression()), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 0, metadata !262, metadata !DIExpression()), !dbg !274
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !263, metadata !DIExpression()), !dbg !274
  %.pre = load ptr, ptr %arg, align 8, !dbg !343, !tbaa !193
  br label %for.body, !dbg !352

for.body:                                         ; preds = %memcheck.exit, %if.end104
  %12 = phi ptr [ %.pre, %memcheck.exit ], [ %27, %if.end104 ], !dbg !343
  %indvars.iv = phi i64 [ 1, %memcheck.exit ], [ %indvars.iv.next, %if.end104 ]
  %oldest.0249 = phi i32 [ -1, %memcheck.exit ], [ %oldest.1, %if.end104 ]
  %oldest_age.0247 = phi i64 [ 0, %memcheck.exit ], [ %oldest_age.1, %if.end104 ]
  %too_free.0246 = phi i1 [ false, %memcheck.exit ], [ %too_free.1244, %if.end104 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !259, metadata !DIExpression()), !dbg !274
  tail call void @llvm.dbg.value(metadata i32 %oldest.0249, metadata !261, metadata !DIExpression()), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 %oldest_age.0247, metadata !262, metadata !DIExpression()), !dbg !274
  %arrayidx = getelementptr inbounds [64 x %struct.slab_stats_automove], ptr %sam_before, i64 0, i64 %indvars.iv, !dbg !353
  %chunk_size = getelementptr inbounds i8, ptr %arrayidx, i64 4, !dbg !354
  %13 = load i32, ptr %chunk_size, align 4, !dbg !354, !tbaa !355
  %14 = load i32, ptr %item_size, align 8, !dbg !356, !tbaa !210
  %cmp2 = icmp uge i32 %13, %14, !dbg !357
  tail call void @llvm.dbg.value(metadata i1 %cmp2, metadata !265, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !358
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !348, metadata !DIExpression()), !dbg !359
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !349, metadata !DIExpression()), !dbg !359
  %15 = load i32, ptr %window_size.i, align 8, !dbg !360, !tbaa !197
  %16 = trunc nuw nsw i64 %indvars.iv to i32, !dbg !361
  %mul.i202 = mul i32 %15, %16, !dbg !361
  tail call void @llvm.dbg.value(metadata i32 %mul.i202, metadata !350, metadata !DIExpression()), !dbg !359
  %17 = load i32, ptr %window_cur, align 4, !dbg !362, !tbaa !309
  %rem.i = urem i32 %17, %15, !dbg !363
  %add.i = add i32 %rem.i, %mul.i202, !dbg !364
  %idxprom.i = zext i32 %add.i to i64, !dbg !365
  %arrayidx.i = getelementptr inbounds %struct.window_data, ptr %12, i64 %idxprom.i, !dbg !365
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i, metadata !269, metadata !DIExpression()), !dbg !358
  tail call void @llvm.dbg.value(metadata i32 %mul.i202, metadata !270, metadata !DIExpression()), !dbg !358
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %arrayidx.i, i8 0, i64 32, i1 false), !dbg !366
  %arrayidx6 = getelementptr inbounds [64 x %struct.slab_stats_automove], ptr %sam_after, i64 0, i64 %indvars.iv, !dbg !367
  %18 = load i32, ptr %arrayidx6, align 8, !dbg !368, !tbaa !369
  %conv = uitofp i32 %18 to double, !dbg !367
  %mul7 = fmul double %conv, 1.500000e+00, !dbg !370
  %conv8 = fptoui double %mul7 to i32, !dbg !367
  tail call void @llvm.dbg.value(metadata i32 %conv8, metadata !271, metadata !DIExpression()), !dbg !358
  %arrayidx11 = getelementptr inbounds [64 x %struct.item_stats_automove], ptr %iam_after, i64 0, i64 %indvars.iv, !dbg !371
  %19 = load i64, ptr %arrayidx11, align 8, !dbg !373, !tbaa !374
  %arrayidx13 = getelementptr inbounds [64 x %struct.item_stats_automove], ptr %iam_before, i64 0, i64 %indvars.iv, !dbg !376
  %20 = load i64, ptr %arrayidx13, align 8, !dbg !377, !tbaa !374
  %cmp15 = icmp sgt i64 %19, %20, !dbg !378
  br i1 %cmp15, label %if.then, label %lor.lhs.false, !dbg !379

lor.lhs.false:                                    ; preds = %for.body
  %outofmemory = getelementptr inbounds i8, ptr %arrayidx11, i64 8, !dbg !380
  %21 = load i64, ptr %outofmemory, align 8, !dbg !380, !tbaa !381
  %outofmemory23 = getelementptr inbounds i8, ptr %arrayidx13, i64 8, !dbg !382
  %22 = load i64, ptr %outofmemory23, align 8, !dbg !382, !tbaa !381
  %cmp25 = icmp sgt i64 %21, %22, !dbg !383
  br i1 %cmp25, label %if.then, label %if.end, !dbg !384

if.then:                                          ; preds = %lor.lhs.false, %for.body
  %evicted27 = getelementptr inbounds i8, ptr %arrayidx.i, i64 16, !dbg !385
  store i64 1, ptr %evicted27, align 8, !dbg !387, !tbaa !388
  %dirty = getelementptr inbounds i8, ptr %arrayidx.i, i64 8, !dbg !390
  store i64 1, ptr %dirty, align 8, !dbg !391, !tbaa !392
  br label %if.end, !dbg !393

if.end:                                           ; preds = %if.then, %lor.lhs.false
  %total_pages = getelementptr inbounds i8, ptr %arrayidx6, i64 16, !dbg !394
  %23 = load i64, ptr %total_pages, align 8, !dbg !394, !tbaa !327
  %total_pages34 = getelementptr inbounds i8, ptr %arrayidx, i64 16, !dbg !396
  %24 = load i64, ptr %total_pages34, align 8, !dbg !396, !tbaa !327
  %cmp36 = icmp sgt i64 %23, %24, !dbg !397
  br i1 %cmp36, label %if.then38, label %if.end40, !dbg !398

if.then38:                                        ; preds = %if.end
  %dirty39 = getelementptr inbounds i8, ptr %arrayidx.i, i64 8, !dbg !399
  store i64 1, ptr %dirty39, align 8, !dbg !401, !tbaa !392
  br label %if.end40, !dbg !402

if.end40:                                         ; preds = %if.then38, %if.end
  %free_chunks = getelementptr inbounds i8, ptr %arrayidx6, i64 8, !dbg !403
  %25 = load i64, ptr %free_chunks, align 8, !dbg !403, !tbaa !405
  %mul44 = shl i32 %conv8, 1, !dbg !406
  %conv45 = zext i32 %mul44 to i64, !dbg !407
  %cmp46 = icmp sgt i64 %25, %conv45, !dbg !408
  br i1 %cmp46, label %if.then48, label %if.end49, !dbg !409

if.then48:                                        ; preds = %if.end40
  %excess_free = getelementptr inbounds i8, ptr %arrayidx.i, i64 24, !dbg !410
  store i32 1, ptr %excess_free, align 8, !dbg !412, !tbaa !413
  br label %if.end49, !dbg !414

if.end49:                                         ; preds = %if.then48, %if.end40
  %age = getelementptr inbounds i8, ptr %arrayidx11, i64 16, !dbg !415
  %26 = load i32, ptr %age, align 8, !dbg !415, !tbaa !416
  %conv53 = zext i32 %26 to i64, !dbg !417
  store i64 %conv53, ptr %arrayidx.i, align 8, !dbg !418, !tbaa !419
  tail call void @llvm.dbg.value(metadata i64 0, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 0, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 0, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata i32 0, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 32)), !dbg !274
  tail call void @llvm.dbg.value(metadata i32 0, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 224, 32)), !dbg !274
  %27 = load ptr, ptr %arg, align 8, !dbg !420, !tbaa !193
  %idxprom55 = sext i32 %mul.i202 to i64, !dbg !421
  %arrayidx56 = getelementptr inbounds %struct.window_data, ptr %27, i64 %idxprom55, !dbg !421
  %28 = load i32, ptr %window_size.i, align 8, !dbg !422, !tbaa !197
  tail call void @llvm.dbg.value(metadata ptr %arrayidx56, metadata !423, metadata !DIExpression()), !dbg !435
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !428, metadata !DIExpression()), !dbg !435
  tail call void @llvm.dbg.value(metadata i32 %28, metadata !429, metadata !DIExpression()), !dbg !435
  tail call void @llvm.dbg.value(metadata i32 0, metadata !430, metadata !DIExpression()), !dbg !437
  %cmp20.not.i = icmp eq i32 %28, 0, !dbg !438
  br i1 %cmp20.not.i, label %window_sum.exit.thread, label %for.body.lr.ph.i, !dbg !439

for.body.lr.ph.i:                                 ; preds = %if.end49
  %wide.trip.count.i = zext i32 %28 to i64, !dbg !438
  %xtraiter = and i64 %wide.trip.count.i, 1, !dbg !439
  %29 = icmp eq i32 %28, 1, !dbg !439
  br i1 %29, label %window_sum.exit.unr-lcssa, label %for.body.lr.ph.i.new, !dbg !439

for.body.lr.ph.i.new:                             ; preds = %for.body.lr.ph.i
  %unroll_iter = and i64 %wide.trip.count.i, 4294967294, !dbg !439
  br label %for.body.i203, !dbg !439

for.body.i203:                                    ; preds = %for.body.i203, %for.body.lr.ph.i.new
  %indvars.iv.i204 = phi i64 [ 0, %for.body.lr.ph.i.new ], [ %indvars.iv.next.i207.1, %for.body.i203 ], !dbg !440
  %30 = phi i32 [ 0, %for.body.lr.ph.i.new ], [ %add7.i.1, %for.body.i203 ], !dbg !440
  %31 = phi i64 [ 0, %for.body.lr.ph.i.new ], [ %add3.i.1, %for.body.i203 ], !dbg !440
  %32 = phi i64 [ 0, %for.body.lr.ph.i.new ], [ %add.i206.1, %for.body.i203 ], !dbg !440
  %niter = phi i64 [ 0, %for.body.lr.ph.i.new ], [ %niter.next.1, %for.body.i203 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i204, metadata !430, metadata !DIExpression()), !dbg !437
  %arrayidx.i205 = getelementptr inbounds %struct.window_data, ptr %arrayidx56, i64 %indvars.iv.i204, !dbg !440
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i205, metadata !432, metadata !DIExpression()), !dbg !441
  %33 = load i64, ptr %arrayidx.i205, align 8, !dbg !442, !tbaa !419
  %add.i206 = add i64 %33, %32, !dbg !443
  tail call void @llvm.dbg.value(metadata i64 %add.i206, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !274
  %dirty.i = getelementptr inbounds i8, ptr %arrayidx.i205, i64 8, !dbg !444
  %34 = load i64, ptr %dirty.i, align 8, !dbg !444, !tbaa !392
  %add3.i = add i64 %34, %31, !dbg !445
  tail call void @llvm.dbg.value(metadata i64 %add3.i, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison), metadata !260, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value, DW_OP_LLVM_fragment, 128, 64)), !dbg !274
  %excess_free.i = getelementptr inbounds i8, ptr %arrayidx.i205, i64 24, !dbg !446
  %35 = load i32, ptr %excess_free.i, align 8, !dbg !446, !tbaa !413
  %add7.i = add i32 %35, %30, !dbg !447
  tail call void @llvm.dbg.value(metadata i32 %add7.i, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 32)), !dbg !274
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !260, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value, DW_OP_LLVM_fragment, 224, 32)), !dbg !274
  %indvars.iv.next.i207 = or disjoint i64 %indvars.iv.i204, 1, !dbg !448
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i207, metadata !430, metadata !DIExpression()), !dbg !437
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i207, metadata !430, metadata !DIExpression()), !dbg !437
  %arrayidx.i205.1 = getelementptr inbounds %struct.window_data, ptr %arrayidx56, i64 %indvars.iv.next.i207, !dbg !440
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i205.1, metadata !432, metadata !DIExpression()), !dbg !441
  %36 = load i64, ptr %arrayidx.i205.1, align 8, !dbg !442, !tbaa !419
  %add.i206.1 = add i64 %36, %add.i206, !dbg !443
  tail call void @llvm.dbg.value(metadata i64 %add.i206.1, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !274
  %dirty.i.1 = getelementptr inbounds i8, ptr %arrayidx.i205.1, i64 8, !dbg !444
  %37 = load i64, ptr %dirty.i.1, align 8, !dbg !444, !tbaa !392
  %add3.i.1 = add i64 %37, %add3.i, !dbg !445
  tail call void @llvm.dbg.value(metadata i64 %add3.i.1, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison), metadata !260, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value, DW_OP_LLVM_fragment, 128, 64)), !dbg !274
  %excess_free.i.1 = getelementptr inbounds i8, ptr %arrayidx.i205.1, i64 24, !dbg !446
  %38 = load i32, ptr %excess_free.i.1, align 8, !dbg !446, !tbaa !413
  %add7.i.1 = add i32 %38, %add7.i, !dbg !447
  tail call void @llvm.dbg.value(metadata i32 %add7.i.1, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 32)), !dbg !274
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !260, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value, DW_OP_LLVM_fragment, 224, 32)), !dbg !274
  %indvars.iv.next.i207.1 = add nuw nsw i64 %indvars.iv.i204, 2, !dbg !448
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i207.1, metadata !430, metadata !DIExpression()), !dbg !437
  %niter.next.1 = add i64 %niter, 2, !dbg !439
  %niter.ncmp.1 = icmp eq i64 %niter.next.1, %unroll_iter, !dbg !439
  br i1 %niter.ncmp.1, label %window_sum.exit.unr-lcssa, label %for.body.i203, !dbg !439, !llvm.loop !449

window_sum.exit.unr-lcssa:                        ; preds = %for.body.i203, %for.body.lr.ph.i
  %add.i206.lcssa.ph = phi i64 [ undef, %for.body.lr.ph.i ], [ %add.i206.1, %for.body.i203 ]
  %add3.i.lcssa.ph = phi i64 [ undef, %for.body.lr.ph.i ], [ %add3.i.1, %for.body.i203 ]
  %add7.i.lcssa.ph = phi i32 [ undef, %for.body.lr.ph.i ], [ %add7.i.1, %for.body.i203 ]
  %indvars.iv.i204.unr = phi i64 [ 0, %for.body.lr.ph.i ], [ %indvars.iv.next.i207.1, %for.body.i203 ]
  %.unr = phi i32 [ 0, %for.body.lr.ph.i ], [ %add7.i.1, %for.body.i203 ]
  %.unr252 = phi i64 [ 0, %for.body.lr.ph.i ], [ %add3.i.1, %for.body.i203 ]
  %.unr253 = phi i64 [ 0, %for.body.lr.ph.i ], [ %add.i206.1, %for.body.i203 ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0, !dbg !439
  br i1 %lcmp.mod.not, label %window_sum.exit, label %for.body.i203.epil, !dbg !439

for.body.i203.epil:                               ; preds = %window_sum.exit.unr-lcssa
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i204.unr, metadata !430, metadata !DIExpression()), !dbg !437
  %arrayidx.i205.epil = getelementptr inbounds %struct.window_data, ptr %arrayidx56, i64 %indvars.iv.i204.unr, !dbg !440
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i205.epil, metadata !432, metadata !DIExpression()), !dbg !441
  %39 = load i64, ptr %arrayidx.i205.epil, align 8, !dbg !442, !tbaa !419
  %add.i206.epil = add i64 %39, %.unr253, !dbg !443
  tail call void @llvm.dbg.value(metadata i64 %add.i206.epil, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !274
  %dirty.i.epil = getelementptr inbounds i8, ptr %arrayidx.i205.epil, i64 8, !dbg !444
  %40 = load i64, ptr %dirty.i.epil, align 8, !dbg !444, !tbaa !392
  %add3.i.epil = add i64 %40, %.unr252, !dbg !445
  tail call void @llvm.dbg.value(metadata i64 %add3.i.epil, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison), metadata !260, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value, DW_OP_LLVM_fragment, 128, 64)), !dbg !274
  %excess_free.i.epil = getelementptr inbounds i8, ptr %arrayidx.i205.epil, i64 24, !dbg !446
  %41 = load i32, ptr %excess_free.i.epil, align 8, !dbg !446, !tbaa !413
  %add7.i.epil = add i32 %41, %.unr, !dbg !447
  tail call void @llvm.dbg.value(metadata i32 %add7.i.epil, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 32)), !dbg !274
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !260, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value, DW_OP_LLVM_fragment, 224, 32)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i204.unr, metadata !430, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !437
  br label %window_sum.exit, !dbg !451

window_sum.exit:                                  ; preds = %window_sum.exit.unr-lcssa, %for.body.i203.epil
  %add.i206.lcssa = phi i64 [ %add.i206.lcssa.ph, %window_sum.exit.unr-lcssa ], [ %add.i206.epil, %for.body.i203.epil ], !dbg !443
  %add3.i.lcssa = phi i64 [ %add3.i.lcssa.ph, %window_sum.exit.unr-lcssa ], [ %add3.i.epil, %for.body.i203.epil ], !dbg !445
  %add7.i.lcssa = phi i32 [ %add7.i.lcssa.ph, %window_sum.exit.unr-lcssa ], [ %add7.i.epil, %for.body.i203.epil ], !dbg !447
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 224, 32)), !dbg !274
  tail call void @llvm.dbg.value(metadata i32 %add7.i.lcssa, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 32)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 %add3.i.lcssa, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 %add.i206.lcssa, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !274
  %div = udiv i64 %add.i206.lcssa, %wide.trip.count.i, !dbg !451
  tail call void @llvm.dbg.value(metadata i64 %div, metadata !272, metadata !DIExpression()), !dbg !358
  %conv66 = sitofp i64 %25 to double, !dbg !452
  %mul72 = fmul double %conv, 2.500000e+00, !dbg !454
  %cmp73 = fcmp olt double %mul72, %conv66, !dbg !455
  %cmp76 = icmp eq i64 %add3.i.lcssa, 0
  %or.cond245 = select i1 %cmp73, i1 %cmp76, i1 false, !dbg !456
  br i1 %or.cond245, label %if.then78, label %if.end90, !dbg !456

window_sum.exit.thread:                           ; preds = %if.end49
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 224, 32)), !dbg !274
  tail call void @llvm.dbg.value(metadata i32 0, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 32)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 0, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 0, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 0, metadata !272, metadata !DIExpression()), !dbg !358
  %conv66217 = sitofp i64 %25 to double, !dbg !452
  %mul72218 = fmul double %conv, 2.500000e+00, !dbg !454
  %cmp73219 = fcmp olt double %mul72218, %conv66217, !dbg !455
  br i1 %cmp73219, label %if.then78.thread, label %if.end104, !dbg !456

if.then78:                                        ; preds = %window_sum.exit
  br i1 %cmp2, label %land.lhs.true82, label %if.then80, !dbg !457

if.then78.thread:                                 ; preds = %window_sum.exit.thread
  br i1 %cmp2, label %if.then87, label %if.then80, !dbg !457

if.then80:                                        ; preds = %if.then78.thread, %if.then78
  store i32 %16, ptr %src, align 4, !dbg !459, !tbaa !276
  store i32 0, ptr %dst, align 4, !dbg !462, !tbaa !276
  tail call void @llvm.dbg.value(metadata i8 1, metadata !263, metadata !DIExpression()), !dbg !274
  br label %if.end104, !dbg !463

land.lhs.true82:                                  ; preds = %if.then78
  %cmp85.not = icmp ult i32 %add7.i.lcssa, %28, !dbg !464
  br i1 %cmp85.not, label %if.end90, label %if.then87, !dbg !466

if.then87:                                        ; preds = %if.then78.thread, %land.lhs.true82
  %div223228234238 = phi i64 [ %div, %land.lhs.true82 ], [ 0, %if.then78.thread ]
  store i32 %16, ptr %src, align 4, !dbg !467, !tbaa !276
  store i32 0, ptr %dst, align 4, !dbg !469, !tbaa !276
  tail call void @llvm.dbg.value(metadata i8 1, metadata !263, metadata !DIExpression()), !dbg !274
  br label %if.end90, !dbg !470

if.end90:                                         ; preds = %if.then87, %land.lhs.true82, %window_sum.exit
  %div222 = phi i64 [ %div223228234238, %if.then87 ], [ %div, %land.lhs.true82 ], [ %div, %window_sum.exit ]
  %too_free.1 = phi i1 [ true, %if.then87 ], [ %too_free.0246, %land.lhs.true82 ], [ %too_free.0246, %window_sum.exit ], !dbg !274
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !263, metadata !DIExpression()), !dbg !274
  %cmp93 = icmp ugt i64 %div222, %oldest_age.0247
  %or.cond = select i1 %cmp2, i1 %cmp93, i1 false, !dbg !471
  br i1 %or.cond, label %land.lhs.true95, label %if.end104, !dbg !471

land.lhs.true95:                                  ; preds = %if.end90
  %cmp100 = icmp sgt i64 %23, 2, !dbg !472
  %spec.select = select i1 %cmp100, i64 %div222, i64 %oldest_age.0247, !dbg !476
  %spec.select198 = select i1 %cmp100, i32 %16, i32 %oldest.0249, !dbg !476
  br label %if.end104, !dbg !476

if.end104:                                        ; preds = %window_sum.exit.thread, %if.then80, %land.lhs.true95, %if.end90
  %too_free.1244 = phi i1 [ %too_free.1, %if.end90 ], [ %too_free.1, %land.lhs.true95 ], [ %too_free.0246, %window_sum.exit.thread ], [ true, %if.then80 ]
  %oldest_age.1 = phi i64 [ %oldest_age.0247, %if.end90 ], [ %spec.select, %land.lhs.true95 ], [ %oldest_age.0247, %window_sum.exit.thread ], [ %oldest_age.0247, %if.then80 ], !dbg !274
  %oldest.1 = phi i32 [ %oldest.0249, %if.end90 ], [ %spec.select198, %land.lhs.true95 ], [ %oldest.0249, %window_sum.exit.thread ], [ %oldest.0249, %if.then80 ], !dbg !274
  tail call void @llvm.dbg.value(metadata i32 %oldest.1, metadata !261, metadata !DIExpression()), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 %oldest_age.1, metadata !262, metadata !DIExpression()), !dbg !274
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !477
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 224, 32)), !dbg !274
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 32)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !260, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !274
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !259, metadata !DIExpression()), !dbg !274
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !263, metadata !DIExpression()), !dbg !274
  %exitcond.not = icmp eq i64 %indvars.iv.next, 64, !dbg !478
  br i1 %exitcond.not, label %for.end, label %for.body, !dbg !352, !llvm.loop !479

for.end:                                          ; preds = %if.end104
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(1536) %iam_before, ptr noundef nonnull align 8 dereferenceable(1536) %iam_after, i64 1536, i1 false), !dbg !481
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(1536) %sam_before, ptr noundef nonnull align 8 dereferenceable(1536) %sam_after, i64 1536, i1 false), !dbg !482
  %42 = load i32, ptr %window_cur, align 4, !dbg !483, !tbaa !309
  %43 = load i32, ptr %window_size.i, align 8, !dbg !485, !tbaa !197
  %cmp116 = icmp ult i32 %42, %43, !dbg !486
  br i1 %cmp116, label %cleanup, label %if.end119, !dbg !487

if.end119:                                        ; preds = %for.end
  %or.cond199 = select i1 %too_free.1244, i1 true, i1 %retval.0.i, !dbg !488
  %cmp124.not = icmp eq i32 %oldest.1, -1
  %or.cond200 = select i1 %or.cond199, i1 true, i1 %cmp124.not, !dbg !488
  br i1 %or.cond200, label %cleanup, label %if.then126, !dbg !488

if.then126:                                       ; preds = %if.end119
  store i32 %oldest.1, ptr %src, align 4, !dbg !490, !tbaa !276
  store i32 0, ptr %dst, align 4, !dbg !492, !tbaa !276
  br label %cleanup, !dbg !493

cleanup:                                          ; preds = %if.end119, %if.then126, %for.end
  ret void, !dbg !494
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #6

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #7

declare !dbg !495 i32 @global_page_pool_size(ptr noundef) local_unnamed_addr #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #8

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #9 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #8

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #8

attributes #0 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nounwind sanitize_thread willreturn uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #7 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { nounwind uwtable }
attributes #10 = { nounwind allocsize(0,1) }
attributes #11 = { nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!156, !157, !158, !159, !160, !161, !162}
!llvm.ident = !{!163}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !2, retainedTypes: !10, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "slab_automove_extstore.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "5ac442847ae9d5d39daa212c51ba7d9f")
!2 = !{!3}
!3 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "protocol", file: !4, line: 238, baseType: !5, size: 32, elements: !6)
!4 = !DIFile(filename: "./memcached.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "a52021954a5d6b153b5bc084e2fbff2b")
!5 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!6 = !{!7, !8, !9}
!7 = !DIEnumerator(name: "ascii_prot", value: 3)
!8 = !DIEnumerator(name: "binary_prot", value: 4)
!9 = !DIEnumerator(name: "negotiating_prot", value: 5)
!10 = !{!11, !12}
!11 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!12 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !13, size: 64)
!13 = !DIDerivedType(tag: DW_TAG_typedef, name: "slab_automove", file: !1, line: 39, baseType: !14)
!14 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !1, line: 25, size: 49600, elements: !15)
!15 = !{!16, !30, !122, !123, !124, !125, !126, !127, !128, !129, !144, !145, !155}
!16 = !DIDerivedType(tag: DW_TAG_member, name: "window_data", scope: !14, file: !1, line: 26, baseType: !17, size: 64)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "window_data", file: !1, line: 17, size: 256, elements: !19)
!19 = !{!20, !26, !27, !28, !29}
!20 = !DIDerivedType(tag: DW_TAG_member, name: "age", scope: !18, file: !1, line: 18, baseType: !21, size: 64)
!21 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !22, line: 27, baseType: !23)
!22 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!23 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !24, line: 45, baseType: !25)
!24 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!25 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!26 = !DIDerivedType(tag: DW_TAG_member, name: "dirty", scope: !18, file: !1, line: 19, baseType: !21, size: 64, offset: 64)
!27 = !DIDerivedType(tag: DW_TAG_member, name: "evicted", scope: !18, file: !1, line: 20, baseType: !21, size: 64, offset: 128)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "excess_free", scope: !18, file: !1, line: 21, baseType: !5, size: 32, offset: 192)
!29 = !DIDerivedType(tag: DW_TAG_member, name: "relaxed", scope: !18, file: !1, line: 22, baseType: !5, size: 32, offset: 224)
!30 = !DIDerivedType(tag: DW_TAG_member, name: "settings", scope: !14, file: !1, line: 27, baseType: !31, size: 64, offset: 64)
!31 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !32, size: 64)
!32 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "settings", file: !4, line: 454, size: 2688, elements: !33)
!33 = !{!34, !37, !39, !40, !41, !44, !45, !48, !49, !50, !51, !52, !54, !55, !56, !57, !58, !59, !60, !62, !63, !64, !65, !66, !67, !72, !73, !74, !75, !76, !77, !78, !79, !80, !81, !82, !83, !84, !85, !86, !87, !88, !91, !92, !93, !94, !95, !96, !97, !98, !99, !100, !101, !102, !103, !104, !105, !106, !107, !108, !109, !110, !111, !112, !113, !114, !115, !116, !117, !118, !119, !120, !121}
!34 = !DIDerivedType(tag: DW_TAG_member, name: "maxbytes", scope: !32, file: !4, line: 455, baseType: !35, size: 64)
!35 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !36, line: 18, baseType: !25)
!36 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!37 = !DIDerivedType(tag: DW_TAG_member, name: "maxconns", scope: !32, file: !4, line: 456, baseType: !38, size: 32, offset: 64)
!38 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!39 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !32, file: !4, line: 457, baseType: !38, size: 32, offset: 96)
!40 = !DIDerivedType(tag: DW_TAG_member, name: "udpport", scope: !32, file: !4, line: 458, baseType: !38, size: 32, offset: 128)
!41 = !DIDerivedType(tag: DW_TAG_member, name: "inter", scope: !32, file: !4, line: 459, baseType: !42, size: 64, offset: 192)
!42 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !43, size: 64)
!43 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!44 = !DIDerivedType(tag: DW_TAG_member, name: "verbose", scope: !32, file: !4, line: 460, baseType: !38, size: 32, offset: 256)
!45 = !DIDerivedType(tag: DW_TAG_member, name: "oldest_live", scope: !32, file: !4, line: 461, baseType: !46, size: 32, offset: 288)
!46 = !DIDerivedType(tag: DW_TAG_typedef, name: "rel_time_t", file: !47, line: 14, baseType: !5)
!47 = !DIFile(filename: "./logger.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "e743c4228b1e0bc1c91bec9cfd28d5ab")
!48 = !DIDerivedType(tag: DW_TAG_member, name: "evict_to_free", scope: !32, file: !4, line: 462, baseType: !38, size: 32, offset: 320)
!49 = !DIDerivedType(tag: DW_TAG_member, name: "socketpath", scope: !32, file: !4, line: 463, baseType: !42, size: 64, offset: 384)
!50 = !DIDerivedType(tag: DW_TAG_member, name: "auth_file", scope: !32, file: !4, line: 464, baseType: !42, size: 64, offset: 448)
!51 = !DIDerivedType(tag: DW_TAG_member, name: "access", scope: !32, file: !4, line: 465, baseType: !38, size: 32, offset: 512)
!52 = !DIDerivedType(tag: DW_TAG_member, name: "factor", scope: !32, file: !4, line: 466, baseType: !53, size: 64, offset: 576)
!53 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!54 = !DIDerivedType(tag: DW_TAG_member, name: "chunk_size", scope: !32, file: !4, line: 467, baseType: !38, size: 32, offset: 640)
!55 = !DIDerivedType(tag: DW_TAG_member, name: "num_threads", scope: !32, file: !4, line: 468, baseType: !38, size: 32, offset: 672)
!56 = !DIDerivedType(tag: DW_TAG_member, name: "num_threads_per_udp", scope: !32, file: !4, line: 469, baseType: !38, size: 32, offset: 704)
!57 = !DIDerivedType(tag: DW_TAG_member, name: "prefix_delimiter", scope: !32, file: !4, line: 470, baseType: !43, size: 8, offset: 736)
!58 = !DIDerivedType(tag: DW_TAG_member, name: "detail_enabled", scope: !32, file: !4, line: 471, baseType: !38, size: 32, offset: 768)
!59 = !DIDerivedType(tag: DW_TAG_member, name: "reqs_per_event", scope: !32, file: !4, line: 472, baseType: !38, size: 32, offset: 800)
!60 = !DIDerivedType(tag: DW_TAG_member, name: "use_cas", scope: !32, file: !4, line: 474, baseType: !61, size: 8, offset: 832)
!61 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!62 = !DIDerivedType(tag: DW_TAG_member, name: "binding_protocol", scope: !32, file: !4, line: 475, baseType: !3, size: 32, offset: 864)
!63 = !DIDerivedType(tag: DW_TAG_member, name: "backlog", scope: !32, file: !4, line: 476, baseType: !38, size: 32, offset: 896)
!64 = !DIDerivedType(tag: DW_TAG_member, name: "item_size_max", scope: !32, file: !4, line: 477, baseType: !38, size: 32, offset: 928)
!65 = !DIDerivedType(tag: DW_TAG_member, name: "slab_chunk_size_max", scope: !32, file: !4, line: 478, baseType: !38, size: 32, offset: 960)
!66 = !DIDerivedType(tag: DW_TAG_member, name: "slab_page_size", scope: !32, file: !4, line: 479, baseType: !38, size: 32, offset: 992)
!67 = !DIDerivedType(tag: DW_TAG_member, name: "sig_hup", scope: !32, file: !4, line: 480, baseType: !68, size: 32, offset: 1024)
!68 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !69)
!69 = !DIDerivedType(tag: DW_TAG_typedef, name: "sig_atomic_t", file: !70, line: 8, baseType: !71)
!70 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/sig_atomic_t.h", directory: "", checksumkind: CSK_MD5, checksum: "d9236f7e3e7f10f53aa9d4cd97f503cf")
!71 = !DIDerivedType(tag: DW_TAG_typedef, name: "__sig_atomic_t", file: !24, line: 215, baseType: !38)
!72 = !DIDerivedType(tag: DW_TAG_member, name: "sasl", scope: !32, file: !4, line: 481, baseType: !61, size: 8, offset: 1056)
!73 = !DIDerivedType(tag: DW_TAG_member, name: "maxconns_fast", scope: !32, file: !4, line: 482, baseType: !61, size: 8, offset: 1064)
!74 = !DIDerivedType(tag: DW_TAG_member, name: "lru_crawler", scope: !32, file: !4, line: 483, baseType: !61, size: 8, offset: 1072)
!75 = !DIDerivedType(tag: DW_TAG_member, name: "lru_maintainer_thread", scope: !32, file: !4, line: 484, baseType: !61, size: 8, offset: 1080)
!76 = !DIDerivedType(tag: DW_TAG_member, name: "lru_segmented", scope: !32, file: !4, line: 485, baseType: !61, size: 8, offset: 1088)
!77 = !DIDerivedType(tag: DW_TAG_member, name: "slab_reassign", scope: !32, file: !4, line: 486, baseType: !61, size: 8, offset: 1096)
!78 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove", scope: !32, file: !4, line: 487, baseType: !38, size: 32, offset: 1120)
!79 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove_ratio", scope: !32, file: !4, line: 488, baseType: !53, size: 64, offset: 1152)
!80 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove_window", scope: !32, file: !4, line: 489, baseType: !5, size: 32, offset: 1216)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "hashpower_init", scope: !32, file: !4, line: 490, baseType: !38, size: 32, offset: 1248)
!82 = !DIDerivedType(tag: DW_TAG_member, name: "shutdown_command", scope: !32, file: !4, line: 491, baseType: !61, size: 8, offset: 1280)
!83 = !DIDerivedType(tag: DW_TAG_member, name: "tail_repair_time", scope: !32, file: !4, line: 492, baseType: !38, size: 32, offset: 1312)
!84 = !DIDerivedType(tag: DW_TAG_member, name: "flush_enabled", scope: !32, file: !4, line: 493, baseType: !61, size: 8, offset: 1344)
!85 = !DIDerivedType(tag: DW_TAG_member, name: "dump_enabled", scope: !32, file: !4, line: 494, baseType: !61, size: 8, offset: 1352)
!86 = !DIDerivedType(tag: DW_TAG_member, name: "hash_algorithm", scope: !32, file: !4, line: 495, baseType: !42, size: 64, offset: 1408)
!87 = !DIDerivedType(tag: DW_TAG_member, name: "lru_crawler_sleep", scope: !32, file: !4, line: 496, baseType: !38, size: 32, offset: 1472)
!88 = !DIDerivedType(tag: DW_TAG_member, name: "lru_crawler_tocrawl", scope: !32, file: !4, line: 497, baseType: !89, size: 32, offset: 1504)
!89 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !22, line: 26, baseType: !90)
!90 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !24, line: 42, baseType: !5)
!91 = !DIDerivedType(tag: DW_TAG_member, name: "hot_lru_pct", scope: !32, file: !4, line: 498, baseType: !38, size: 32, offset: 1536)
!92 = !DIDerivedType(tag: DW_TAG_member, name: "warm_lru_pct", scope: !32, file: !4, line: 499, baseType: !38, size: 32, offset: 1568)
!93 = !DIDerivedType(tag: DW_TAG_member, name: "hot_max_factor", scope: !32, file: !4, line: 500, baseType: !53, size: 64, offset: 1600)
!94 = !DIDerivedType(tag: DW_TAG_member, name: "warm_max_factor", scope: !32, file: !4, line: 501, baseType: !53, size: 64, offset: 1664)
!95 = !DIDerivedType(tag: DW_TAG_member, name: "crawls_persleep", scope: !32, file: !4, line: 502, baseType: !38, size: 32, offset: 1728)
!96 = !DIDerivedType(tag: DW_TAG_member, name: "temp_lru", scope: !32, file: !4, line: 503, baseType: !61, size: 8, offset: 1760)
!97 = !DIDerivedType(tag: DW_TAG_member, name: "temporary_ttl", scope: !32, file: !4, line: 504, baseType: !89, size: 32, offset: 1792)
!98 = !DIDerivedType(tag: DW_TAG_member, name: "idle_timeout", scope: !32, file: !4, line: 505, baseType: !38, size: 32, offset: 1824)
!99 = !DIDerivedType(tag: DW_TAG_member, name: "logger_watcher_buf_size", scope: !32, file: !4, line: 506, baseType: !5, size: 32, offset: 1856)
!100 = !DIDerivedType(tag: DW_TAG_member, name: "logger_buf_size", scope: !32, file: !4, line: 507, baseType: !5, size: 32, offset: 1888)
!101 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_mem_limit", scope: !32, file: !4, line: 508, baseType: !5, size: 32, offset: 1920)
!102 = !DIDerivedType(tag: DW_TAG_member, name: "drop_privileges", scope: !32, file: !4, line: 509, baseType: !61, size: 8, offset: 1952)
!103 = !DIDerivedType(tag: DW_TAG_member, name: "watch_enabled", scope: !32, file: !4, line: 510, baseType: !61, size: 8, offset: 1960)
!104 = !DIDerivedType(tag: DW_TAG_member, name: "relaxed_privileges", scope: !32, file: !4, line: 511, baseType: !61, size: 8, offset: 1968)
!105 = !DIDerivedType(tag: DW_TAG_member, name: "ext_io_threadcount", scope: !32, file: !4, line: 513, baseType: !5, size: 32, offset: 1984)
!106 = !DIDerivedType(tag: DW_TAG_member, name: "ext_page_size", scope: !32, file: !4, line: 514, baseType: !5, size: 32, offset: 2016)
!107 = !DIDerivedType(tag: DW_TAG_member, name: "ext_item_size", scope: !32, file: !4, line: 515, baseType: !5, size: 32, offset: 2048)
!108 = !DIDerivedType(tag: DW_TAG_member, name: "ext_item_age", scope: !32, file: !4, line: 516, baseType: !5, size: 32, offset: 2080)
!109 = !DIDerivedType(tag: DW_TAG_member, name: "ext_low_ttl", scope: !32, file: !4, line: 517, baseType: !5, size: 32, offset: 2112)
!110 = !DIDerivedType(tag: DW_TAG_member, name: "ext_recache_rate", scope: !32, file: !4, line: 518, baseType: !5, size: 32, offset: 2144)
!111 = !DIDerivedType(tag: DW_TAG_member, name: "ext_wbuf_size", scope: !32, file: !4, line: 519, baseType: !5, size: 32, offset: 2176)
!112 = !DIDerivedType(tag: DW_TAG_member, name: "ext_compact_under", scope: !32, file: !4, line: 520, baseType: !5, size: 32, offset: 2208)
!113 = !DIDerivedType(tag: DW_TAG_member, name: "ext_drop_under", scope: !32, file: !4, line: 521, baseType: !5, size: 32, offset: 2240)
!114 = !DIDerivedType(tag: DW_TAG_member, name: "ext_max_sleep", scope: !32, file: !4, line: 522, baseType: !5, size: 32, offset: 2272)
!115 = !DIDerivedType(tag: DW_TAG_member, name: "ext_max_frag", scope: !32, file: !4, line: 523, baseType: !53, size: 64, offset: 2304)
!116 = !DIDerivedType(tag: DW_TAG_member, name: "slab_automove_freeratio", scope: !32, file: !4, line: 524, baseType: !53, size: 64, offset: 2368)
!117 = !DIDerivedType(tag: DW_TAG_member, name: "ext_drop_unread", scope: !32, file: !4, line: 525, baseType: !61, size: 8, offset: 2432)
!118 = !DIDerivedType(tag: DW_TAG_member, name: "ext_global_pool_min", scope: !32, file: !4, line: 527, baseType: !5, size: 32, offset: 2464)
!119 = !DIDerivedType(tag: DW_TAG_member, name: "num_napi_ids", scope: !32, file: !4, line: 544, baseType: !38, size: 32, offset: 2496)
!120 = !DIDerivedType(tag: DW_TAG_member, name: "memory_file", scope: !32, file: !4, line: 545, baseType: !42, size: 64, offset: 2560)
!121 = !DIDerivedType(tag: DW_TAG_member, name: "sock_cookie_id", scope: !32, file: !4, line: 555, baseType: !89, size: 32, offset: 2624)
!122 = !DIDerivedType(tag: DW_TAG_member, name: "window_size", scope: !14, file: !1, line: 28, baseType: !89, size: 32, offset: 128)
!123 = !DIDerivedType(tag: DW_TAG_member, name: "window_cur", scope: !14, file: !1, line: 29, baseType: !89, size: 32, offset: 160)
!124 = !DIDerivedType(tag: DW_TAG_member, name: "item_size", scope: !14, file: !1, line: 30, baseType: !89, size: 32, offset: 192)
!125 = !DIDerivedType(tag: DW_TAG_member, name: "max_age_ratio", scope: !14, file: !1, line: 31, baseType: !53, size: 64, offset: 256)
!126 = !DIDerivedType(tag: DW_TAG_member, name: "free_ratio", scope: !14, file: !1, line: 32, baseType: !53, size: 64, offset: 320)
!127 = !DIDerivedType(tag: DW_TAG_member, name: "pool_filled_once", scope: !14, file: !1, line: 33, baseType: !61, size: 8, offset: 384)
!128 = !DIDerivedType(tag: DW_TAG_member, name: "global_pool_watermark", scope: !14, file: !1, line: 34, baseType: !5, size: 32, offset: 416)
!129 = !DIDerivedType(tag: DW_TAG_member, name: "iam_before", scope: !14, file: !1, line: 35, baseType: !130, size: 12288, offset: 448)
!130 = !DICompositeType(tag: DW_TAG_array_type, baseType: !131, size: 12288, elements: !142)
!131 = !DIDerivedType(tag: DW_TAG_typedef, name: "item_stats_automove", file: !132, line: 70, baseType: !133)
!132 = !DIFile(filename: "./items.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "5548db7354621bc680fd5812e10230ba")
!133 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !132, line: 66, size: 192, elements: !134)
!134 = !{!135, !140, !141}
!135 = !DIDerivedType(tag: DW_TAG_member, name: "evicted", scope: !133, file: !132, line: 67, baseType: !136, size: 64)
!136 = !DIDerivedType(tag: DW_TAG_typedef, name: "int64_t", file: !137, line: 27, baseType: !138)
!137 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h", directory: "", checksumkind: CSK_MD5, checksum: "649b383a60bfa3eb90e85840b2b0be20")
!138 = !DIDerivedType(tag: DW_TAG_typedef, name: "__int64_t", file: !24, line: 44, baseType: !139)
!139 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!140 = !DIDerivedType(tag: DW_TAG_member, name: "outofmemory", scope: !133, file: !132, line: 68, baseType: !136, size: 64, offset: 64)
!141 = !DIDerivedType(tag: DW_TAG_member, name: "age", scope: !133, file: !132, line: 69, baseType: !89, size: 32, offset: 128)
!142 = !{!143}
!143 = !DISubrange(count: 64)
!144 = !DIDerivedType(tag: DW_TAG_member, name: "iam_after", scope: !14, file: !1, line: 36, baseType: !130, size: 12288, offset: 12736)
!145 = !DIDerivedType(tag: DW_TAG_member, name: "sam_before", scope: !14, file: !1, line: 37, baseType: !146, size: 12288, offset: 25024)
!146 = !DICompositeType(tag: DW_TAG_array_type, baseType: !147, size: 12288, elements: !142)
!147 = !DIDerivedType(tag: DW_TAG_typedef, name: "slab_stats_automove", file: !148, line: 39, baseType: !149)
!148 = !DIFile(filename: "./slabs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "28867aba1f41c79140864d76faedcb32")
!149 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !148, line: 34, size: 192, elements: !150)
!150 = !{!151, !152, !153, !154}
!151 = !DIDerivedType(tag: DW_TAG_member, name: "chunks_per_page", scope: !149, file: !148, line: 35, baseType: !5, size: 32)
!152 = !DIDerivedType(tag: DW_TAG_member, name: "chunk_size", scope: !149, file: !148, line: 36, baseType: !5, size: 32, offset: 32)
!153 = !DIDerivedType(tag: DW_TAG_member, name: "free_chunks", scope: !149, file: !148, line: 37, baseType: !139, size: 64, offset: 64)
!154 = !DIDerivedType(tag: DW_TAG_member, name: "total_pages", scope: !149, file: !148, line: 38, baseType: !139, size: 64, offset: 128)
!155 = !DIDerivedType(tag: DW_TAG_member, name: "sam_after", scope: !14, file: !1, line: 38, baseType: !146, size: 12288, offset: 37312)
!156 = !{i32 7, !"Dwarf Version", i32 5}
!157 = !{i32 2, !"Debug Info Version", i32 3}
!158 = !{i32 1, !"wchar_size", i32 4}
!159 = !{i32 8, !"PIC Level", i32 2}
!160 = !{i32 7, !"PIE Level", i32 2}
!161 = !{i32 7, !"uwtable", i32 2}
!162 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!163 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!164 = distinct !DISubprogram(name: "slab_automove_extstore_init", scope: !1, file: !1, line: 41, type: !165, scopeLine: 41, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !167)
!165 = !DISubroutineType(types: !166)
!166 = !{!11, !31}
!167 = !{!168, !169, !170, !171}
!168 = !DILocalVariable(name: "settings", arg: 1, scope: !164, file: !1, line: 41, type: !31)
!169 = !DILocalVariable(name: "window_size", scope: !164, file: !1, line: 42, type: !89)
!170 = !DILocalVariable(name: "max_age_ratio", scope: !164, file: !1, line: 43, type: !53)
!171 = !DILocalVariable(name: "a", scope: !164, file: !1, line: 44, type: !12)
!172 = !DILocation(line: 0, scope: !164)
!173 = !DILocation(line: 42, column: 38, scope: !164)
!174 = !{!175, !179, i64 152}
!175 = !{!"settings", !176, i64 0, !179, i64 8, !179, i64 12, !179, i64 16, !180, i64 24, !179, i64 32, !179, i64 36, !179, i64 40, !180, i64 48, !180, i64 56, !179, i64 64, !181, i64 72, !179, i64 80, !179, i64 84, !179, i64 88, !177, i64 92, !179, i64 96, !179, i64 100, !182, i64 104, !179, i64 108, !179, i64 112, !179, i64 116, !179, i64 120, !179, i64 124, !179, i64 128, !182, i64 132, !182, i64 133, !182, i64 134, !182, i64 135, !182, i64 136, !182, i64 137, !179, i64 140, !181, i64 144, !179, i64 152, !179, i64 156, !182, i64 160, !179, i64 164, !182, i64 168, !182, i64 169, !180, i64 176, !179, i64 184, !179, i64 188, !179, i64 192, !179, i64 196, !181, i64 200, !181, i64 208, !179, i64 216, !182, i64 220, !179, i64 224, !179, i64 228, !179, i64 232, !179, i64 236, !179, i64 240, !182, i64 244, !182, i64 245, !182, i64 246, !179, i64 248, !179, i64 252, !179, i64 256, !179, i64 260, !179, i64 264, !179, i64 268, !179, i64 272, !179, i64 276, !179, i64 280, !179, i64 284, !181, i64 288, !181, i64 296, !182, i64 304, !179, i64 308, !179, i64 312, !180, i64 320, !179, i64 328}
!176 = !{!"long", !177, i64 0}
!177 = !{!"omnipotent char", !178, i64 0}
!178 = !{!"Simple C/C++ TBAA"}
!179 = !{!"int", !177, i64 0}
!180 = !{!"any pointer", !177, i64 0}
!181 = !{!"double", !177, i64 0}
!182 = !{!"_Bool", !177, i64 0}
!183 = !DILocation(line: 43, column: 38, scope: !164)
!184 = !{!175, !181, i64 144}
!185 = !DILocation(line: 44, column: 24, scope: !164)
!186 = !DILocation(line: 45, column: 11, scope: !187)
!187 = distinct !DILexicalBlock(scope: !164, file: !1, line: 45, column: 9)
!188 = !DILocation(line: 45, column: 9, scope: !164)
!189 = !DILocation(line: 47, column: 41, scope: !164)
!190 = !DILocation(line: 47, column: 29, scope: !164)
!191 = !DILocation(line: 47, column: 22, scope: !164)
!192 = !DILocation(line: 47, column: 20, scope: !164)
!193 = !{!194, !180, i64 0}
!194 = !{!"", !180, i64 0, !180, i64 8, !179, i64 16, !179, i64 20, !179, i64 24, !181, i64 32, !181, i64 40, !182, i64 48, !179, i64 52, !177, i64 56, !177, i64 1592, !177, i64 3128, !177, i64 4664}
!195 = !DILocation(line: 48, column: 8, scope: !164)
!196 = !DILocation(line: 48, column: 20, scope: !164)
!197 = !{!194, !179, i64 16}
!198 = !DILocation(line: 49, column: 8, scope: !164)
!199 = !DILocation(line: 49, column: 22, scope: !164)
!200 = !{!194, !181, i64 32}
!201 = !DILocation(line: 50, column: 31, scope: !164)
!202 = !{!175, !181, i64 296}
!203 = !DILocation(line: 50, column: 8, scope: !164)
!204 = !DILocation(line: 50, column: 19, scope: !164)
!205 = !{!194, !181, i64 40}
!206 = !DILocation(line: 51, column: 30, scope: !164)
!207 = !{!175, !179, i64 256}
!208 = !DILocation(line: 51, column: 8, scope: !164)
!209 = !DILocation(line: 51, column: 18, scope: !164)
!210 = !{!194, !179, i64 24}
!211 = !DILocation(line: 52, column: 8, scope: !164)
!212 = !DILocation(line: 52, column: 17, scope: !164)
!213 = !{!194, !180, i64 8}
!214 = !DILocation(line: 54, column: 24, scope: !215)
!215 = distinct !DILexicalBlock(scope: !164, file: !1, line: 54, column: 9)
!216 = !DILocation(line: 54, column: 9, scope: !164)
!217 = !DILocation(line: 57, column: 9, scope: !218)
!218 = distinct !DILexicalBlock(scope: !215, file: !1, line: 54, column: 33)
!219 = !DILocation(line: 58, column: 9, scope: !218)
!220 = !DILocation(line: 62, column: 33, scope: !164)
!221 = !DILocation(line: 62, column: 5, scope: !164)
!222 = !DILocation(line: 63, column: 33, scope: !164)
!223 = !DILocation(line: 63, column: 5, scope: !164)
!224 = !DILocation(line: 65, column: 5, scope: !164)
!225 = !DILocation(line: 66, column: 1, scope: !164)
!226 = !DISubprogram(name: "calloc", scope: !227, file: !227, line: 675, type: !228, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!227 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!228 = !DISubroutineType(types: !229)
!229 = !{!11, !35, !35}
!230 = !DISubprogram(name: "free", scope: !227, file: !227, line: 687, type: !231, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!231 = !DISubroutineType(types: !232)
!232 = !{null, !11}
!233 = !DISubprogram(name: "fill_item_stats_automove", scope: !132, file: !132, line: 71, type: !234, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!234 = !DISubroutineType(types: !235)
!235 = !{null, !236}
!236 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !131, size: 64)
!237 = !DISubprogram(name: "fill_slab_stats_automove", scope: !148, file: !148, line: 40, type: !238, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!238 = !DISubroutineType(types: !239)
!239 = !{null, !240}
!240 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !147, size: 64)
!241 = distinct !DISubprogram(name: "slab_automove_extstore_free", scope: !1, file: !1, line: 68, type: !231, scopeLine: 68, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !242)
!242 = !{!243, !244}
!243 = !DILocalVariable(name: "arg", arg: 1, scope: !241, file: !1, line: 68, type: !11)
!244 = !DILocalVariable(name: "a", scope: !241, file: !1, line: 69, type: !12)
!245 = !DILocation(line: 0, scope: !241)
!246 = !DILocation(line: 70, column: 13, scope: !241)
!247 = !DILocation(line: 70, column: 5, scope: !241)
!248 = !DILocation(line: 71, column: 5, scope: !241)
!249 = !DILocation(line: 72, column: 1, scope: !241)
!250 = distinct !DISubprogram(name: "slab_automove_extstore_run", scope: !1, file: !1, line: 133, type: !251, scopeLine: 133, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !254)
!251 = !DISubroutineType(types: !252)
!252 = !{null, !11, !253, !253}
!253 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !38, size: 64)
!254 = !{!255, !256, !257, !258, !259, !260, !261, !262, !263, !264, !265, !269, !270, !271, !272}
!255 = !DILocalVariable(name: "arg", arg: 1, scope: !250, file: !1, line: 133, type: !11)
!256 = !DILocalVariable(name: "src", arg: 2, scope: !250, file: !1, line: 133, type: !253)
!257 = !DILocalVariable(name: "dst", arg: 3, scope: !250, file: !1, line: 133, type: !253)
!258 = !DILocalVariable(name: "a", scope: !250, file: !1, line: 134, type: !12)
!259 = !DILocalVariable(name: "n", scope: !250, file: !1, line: 135, type: !38)
!260 = !DILocalVariable(name: "w_sum", scope: !250, file: !1, line: 136, type: !18)
!261 = !DILocalVariable(name: "oldest", scope: !250, file: !1, line: 137, type: !38)
!262 = !DILocalVariable(name: "oldest_age", scope: !250, file: !1, line: 138, type: !21)
!263 = !DILocalVariable(name: "too_free", scope: !250, file: !1, line: 139, type: !61)
!264 = !DILocalVariable(name: "global_low", scope: !250, file: !1, line: 143, type: !38)
!265 = !DILocalVariable(name: "small_slab", scope: !266, file: !1, line: 153, type: !61)
!266 = distinct !DILexicalBlock(scope: !267, file: !1, line: 152, column: 67)
!267 = distinct !DILexicalBlock(scope: !268, file: !1, line: 152, column: 5)
!268 = distinct !DILexicalBlock(scope: !250, file: !1, line: 152, column: 5)
!269 = !DILocalVariable(name: "wd", scope: !266, file: !1, line: 155, type: !17)
!270 = !DILocalVariable(name: "w_offset", scope: !266, file: !1, line: 156, type: !38)
!271 = !DILocalVariable(name: "free_target", scope: !266, file: !1, line: 158, type: !5)
!272 = !DILocalVariable(name: "age", scope: !266, file: !1, line: 184, type: !21)
!273 = distinct !DIAssignID()
!274 = !DILocation(line: 0, scope: !250)
!275 = !DILocation(line: 140, column: 10, scope: !250)
!276 = !{!179, !179, i64 0}
!277 = !DILocation(line: 141, column: 10, scope: !250)
!278 = !DILocalVariable(name: "mem_limit_reached", scope: !279, file: !1, line: 87, type: !61)
!279 = distinct !DISubprogram(name: "global_pool_check", scope: !1, file: !1, line: 86, type: !280, scopeLine: 86, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !282)
!280 = !DISubroutineType(types: !281)
!281 = !{!38, !12}
!282 = !{!283, !278, !284, !285}
!283 = !DILocalVariable(name: "a", arg: 1, scope: !279, file: !1, line: 86, type: !12)
!284 = !DILocalVariable(name: "free", scope: !279, file: !1, line: 88, type: !5)
!285 = !DILocalVariable(name: "count", scope: !279, file: !1, line: 89, type: !5)
!286 = !DILocation(line: 0, scope: !279, inlinedAt: !287)
!287 = distinct !DILocation(line: 143, column: 22, scope: !250)
!288 = !DILocation(line: 87, column: 5, scope: !279, inlinedAt: !287)
!289 = !DILocation(line: 88, column: 28, scope: !279, inlinedAt: !287)
!290 = !{!194, !179, i64 52}
!291 = !DILocation(line: 89, column: 26, scope: !279, inlinedAt: !287)
!292 = !DILocation(line: 90, column: 10, scope: !293, inlinedAt: !287)
!293 = distinct !DILexicalBlock(scope: !279, file: !1, line: 90, column: 9)
!294 = !{!182, !182, i64 0}
!295 = !{i8 0, i8 2}
!296 = !{}
!297 = !DILocation(line: 90, column: 9, scope: !279, inlinedAt: !287)
!298 = !DILocation(line: 92, column: 15, scope: !299, inlinedAt: !287)
!299 = distinct !DILexicalBlock(scope: !279, file: !1, line: 92, column: 9)
!300 = !DILocation(line: 0, scope: !299, inlinedAt: !287)
!301 = !{!194, !182, i64 48}
!302 = !DILocation(line: 99, column: 1, scope: !279, inlinedAt: !287)
!303 = !DILocation(line: 145, column: 33, scope: !250)
!304 = !DILocation(line: 145, column: 5, scope: !250)
!305 = !DILocation(line: 146, column: 33, scope: !250)
!306 = !DILocation(line: 146, column: 5, scope: !250)
!307 = !DILocation(line: 147, column: 8, scope: !250)
!308 = !DILocation(line: 147, column: 18, scope: !250)
!309 = !{!194, !179, i64 20}
!310 = !DILocalVariable(name: "a", arg: 1, scope: !311, file: !1, line: 110, type: !12)
!311 = distinct !DISubprogram(name: "memcheck", scope: !1, file: !1, line: 110, type: !312, scopeLine: 110, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !314)
!312 = !DISubroutineType(types: !313)
!313 = !{null, !12}
!314 = !{!310, !315, !316, !318}
!315 = !DILocalVariable(name: "total_pages", scope: !311, file: !1, line: 111, type: !5)
!316 = !DILocalVariable(name: "n", scope: !317, file: !1, line: 116, type: !38)
!317 = distinct !DILexicalBlock(scope: !311, file: !1, line: 116, column: 5)
!318 = !DILocalVariable(name: "sam", scope: !319, file: !1, line: 117, type: !240)
!319 = distinct !DILexicalBlock(scope: !320, file: !1, line: 116, column: 58)
!320 = distinct !DILexicalBlock(scope: !317, file: !1, line: 116, column: 5)
!321 = !DILocation(line: 0, scope: !311, inlinedAt: !322)
!322 = distinct !DILocation(line: 149, column: 5, scope: !250)
!323 = !DILocation(line: 0, scope: !317, inlinedAt: !322)
!324 = !DILocation(line: 116, column: 5, scope: !317, inlinedAt: !322)
!325 = !DILocation(line: 0, scope: !319, inlinedAt: !322)
!326 = !DILocation(line: 118, column: 29, scope: !319, inlinedAt: !322)
!327 = !{!328, !176, i64 16}
!328 = !{!"", !179, i64 0, !179, i64 4, !176, i64 8, !176, i64 16}
!329 = !DILocation(line: 118, column: 21, scope: !319, inlinedAt: !322)
!330 = !DILocation(line: 116, column: 54, scope: !320, inlinedAt: !322)
!331 = !DILocation(line: 116, column: 23, scope: !320, inlinedAt: !322)
!332 = distinct !{!332, !324, !333, !334}
!333 = !DILocation(line: 119, column: 5, scope: !317, inlinedAt: !322)
!334 = !{!"llvm.loop.mustprogress"}
!335 = !DILocation(line: 121, column: 36, scope: !311, inlinedAt: !322)
!336 = !DILocation(line: 121, column: 17, scope: !311, inlinedAt: !322)
!337 = !DILocation(line: 122, column: 32, scope: !311, inlinedAt: !322)
!338 = !DILocation(line: 122, column: 49, scope: !311, inlinedAt: !322)
!339 = !DILocation(line: 122, column: 44, scope: !311, inlinedAt: !322)
!340 = !DILocation(line: 123, column: 9, scope: !311, inlinedAt: !322)
!341 = !DILocation(line: 125, column: 34, scope: !311, inlinedAt: !322)
!342 = !{!175, !179, i64 308}
!343 = !DILocation(line: 130, column: 16, scope: !344, inlinedAt: !351)
!344 = distinct !DISubprogram(name: "get_window_data", scope: !1, file: !1, line: 128, type: !345, scopeLine: 128, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !347)
!345 = !DISubroutineType(types: !346)
!346 = !{!17, !12, !38}
!347 = !{!348, !349, !350}
!348 = !DILocalVariable(name: "a", arg: 1, scope: !344, file: !1, line: 128, type: !12)
!349 = !DILocalVariable(name: "class", arg: 2, scope: !344, file: !1, line: 128, type: !38)
!350 = !DILocalVariable(name: "w_offset", scope: !344, file: !1, line: 129, type: !38)
!351 = distinct !DILocation(line: 155, column: 34, scope: !266)
!352 = !DILocation(line: 152, column: 5, scope: !268)
!353 = !DILocation(line: 153, column: 27, scope: !266)
!354 = !DILocation(line: 153, column: 44, scope: !266)
!355 = !{!328, !179, i64 4}
!356 = !DILocation(line: 153, column: 60, scope: !266)
!357 = !DILocation(line: 153, column: 55, scope: !266)
!358 = !DILocation(line: 0, scope: !266)
!359 = !DILocation(line: 0, scope: !344, inlinedAt: !351)
!360 = !DILocation(line: 129, column: 31, scope: !344, inlinedAt: !351)
!361 = !DILocation(line: 129, column: 26, scope: !344, inlinedAt: !351)
!362 = !DILocation(line: 130, column: 43, scope: !344, inlinedAt: !351)
!363 = !DILocation(line: 130, column: 54, scope: !344, inlinedAt: !351)
!364 = !DILocation(line: 130, column: 37, scope: !344, inlinedAt: !351)
!365 = !DILocation(line: 130, column: 13, scope: !344, inlinedAt: !351)
!366 = !DILocation(line: 157, column: 9, scope: !266)
!367 = !DILocation(line: 158, column: 36, scope: !266)
!368 = !DILocation(line: 158, column: 52, scope: !266)
!369 = !{!328, !179, i64 0}
!370 = !DILocation(line: 158, column: 68, scope: !266)
!371 = !DILocation(line: 162, column: 13, scope: !372)
!372 = distinct !DILexicalBlock(scope: !266, file: !1, line: 162, column: 13)
!373 = !DILocation(line: 162, column: 29, scope: !372)
!374 = !{!375, !176, i64 0}
!375 = !{!"", !176, i64 0, !176, i64 8, !179, i64 16}
!376 = !DILocation(line: 162, column: 39, scope: !372)
!377 = !DILocation(line: 162, column: 56, scope: !372)
!378 = !DILocation(line: 162, column: 64, scope: !372)
!379 = !DILocation(line: 162, column: 68, scope: !372)
!380 = !DILocation(line: 163, column: 29, scope: !372)
!381 = !{!375, !176, i64 8}
!382 = !DILocation(line: 163, column: 60, scope: !372)
!383 = !DILocation(line: 163, column: 72, scope: !372)
!384 = !DILocation(line: 162, column: 13, scope: !266)
!385 = !DILocation(line: 164, column: 17, scope: !386)
!386 = distinct !DILexicalBlock(scope: !372, file: !1, line: 163, column: 77)
!387 = !DILocation(line: 164, column: 25, scope: !386)
!388 = !{!389, !176, i64 16}
!389 = !{!"window_data", !176, i64 0, !176, i64 8, !176, i64 16, !179, i64 24, !179, i64 28}
!390 = !DILocation(line: 165, column: 17, scope: !386)
!391 = !DILocation(line: 165, column: 23, scope: !386)
!392 = !{!389, !176, i64 8}
!393 = !DILocation(line: 166, column: 9, scope: !386)
!394 = !DILocation(line: 167, column: 29, scope: !395)
!395 = distinct !DILexicalBlock(scope: !266, file: !1, line: 167, column: 13)
!396 = !DILocation(line: 167, column: 60, scope: !395)
!397 = !DILocation(line: 167, column: 72, scope: !395)
!398 = !DILocation(line: 167, column: 13, scope: !266)
!399 = !DILocation(line: 168, column: 17, scope: !400)
!400 = distinct !DILexicalBlock(scope: !395, file: !1, line: 167, column: 77)
!401 = !DILocation(line: 168, column: 23, scope: !400)
!402 = !DILocation(line: 169, column: 9, scope: !400)
!403 = !DILocation(line: 172, column: 29, scope: !404)
!404 = distinct !DILexicalBlock(scope: !266, file: !1, line: 172, column: 13)
!405 = !{!328, !176, i64 8}
!406 = !DILocation(line: 172, column: 56, scope: !404)
!407 = !DILocation(line: 172, column: 43, scope: !404)
!408 = !DILocation(line: 172, column: 41, scope: !404)
!409 = !DILocation(line: 172, column: 13, scope: !266)
!410 = !DILocation(line: 173, column: 17, scope: !411)
!411 = distinct !DILexicalBlock(scope: !404, file: !1, line: 172, column: 62)
!412 = !DILocation(line: 173, column: 29, scope: !411)
!413 = !{!389, !179, i64 24}
!414 = !DILocation(line: 174, column: 9, scope: !411)
!415 = !DILocation(line: 177, column: 35, scope: !266)
!416 = !{!375, !179, i64 16}
!417 = !DILocation(line: 177, column: 19, scope: !266)
!418 = !DILocation(line: 177, column: 17, scope: !266)
!419 = !{!389, !176, i64 0}
!420 = !DILocation(line: 181, column: 24, scope: !266)
!421 = !DILocation(line: 181, column: 21, scope: !266)
!422 = !DILocation(line: 181, column: 58, scope: !266)
!423 = !DILocalVariable(name: "wd", arg: 1, scope: !424, file: !1, line: 74, type: !17)
!424 = distinct !DISubprogram(name: "window_sum", scope: !1, file: !1, line: 74, type: !425, scopeLine: 75, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !427)
!425 = !DISubroutineType(types: !426)
!426 = !{null, !17, !17, !89}
!427 = !{!423, !428, !429, !430, !432}
!428 = !DILocalVariable(name: "w", arg: 2, scope: !424, file: !1, line: 74, type: !17)
!429 = !DILocalVariable(name: "size", arg: 3, scope: !424, file: !1, line: 75, type: !89)
!430 = !DILocalVariable(name: "x", scope: !431, file: !1, line: 76, type: !38)
!431 = distinct !DILexicalBlock(scope: !424, file: !1, line: 76, column: 5)
!432 = !DILocalVariable(name: "d", scope: !433, file: !1, line: 77, type: !17)
!433 = distinct !DILexicalBlock(scope: !434, file: !1, line: 76, column: 36)
!434 = distinct !DILexicalBlock(scope: !431, file: !1, line: 76, column: 5)
!435 = !DILocation(line: 0, scope: !424, inlinedAt: !436)
!436 = distinct !DILocation(line: 181, column: 9, scope: !266)
!437 = !DILocation(line: 0, scope: !431, inlinedAt: !436)
!438 = !DILocation(line: 76, column: 23, scope: !434, inlinedAt: !436)
!439 = !DILocation(line: 76, column: 5, scope: !431, inlinedAt: !436)
!440 = !DILocation(line: 77, column: 34, scope: !433, inlinedAt: !436)
!441 = !DILocation(line: 0, scope: !433, inlinedAt: !436)
!442 = !DILocation(line: 78, column: 22, scope: !433, inlinedAt: !436)
!443 = !DILocation(line: 78, column: 16, scope: !433, inlinedAt: !436)
!444 = !DILocation(line: 79, column: 24, scope: !433, inlinedAt: !436)
!445 = !DILocation(line: 79, column: 18, scope: !433, inlinedAt: !436)
!446 = !DILocation(line: 81, column: 30, scope: !433, inlinedAt: !436)
!447 = !DILocation(line: 81, column: 24, scope: !433, inlinedAt: !436)
!448 = !DILocation(line: 76, column: 32, scope: !434, inlinedAt: !436)
!449 = distinct !{!449, !439, !450, !334}
!450 = !DILocation(line: 83, column: 5, scope: !431, inlinedAt: !436)
!451 = !DILocation(line: 184, column: 34, scope: !266)
!452 = !DILocation(line: 189, column: 13, scope: !453)
!453 = distinct !DILexicalBlock(scope: !266, file: !1, line: 189, column: 13)
!454 = !DILocation(line: 189, column: 75, scope: !453)
!455 = !DILocation(line: 189, column: 41, scope: !453)
!456 = !DILocation(line: 190, column: 17, scope: !453)
!457 = !DILocation(line: 191, column: 17, scope: !458)
!458 = distinct !DILexicalBlock(scope: !453, file: !1, line: 190, column: 38)
!459 = !DILocation(line: 192, column: 22, scope: !460)
!460 = distinct !DILexicalBlock(scope: !461, file: !1, line: 191, column: 29)
!461 = distinct !DILexicalBlock(scope: !458, file: !1, line: 191, column: 17)
!462 = !DILocation(line: 193, column: 22, scope: !460)
!463 = !DILocation(line: 195, column: 13, scope: !460)
!464 = !DILocation(line: 195, column: 57, scope: !465)
!465 = distinct !DILexicalBlock(scope: !461, file: !1, line: 195, column: 24)
!466 = !DILocation(line: 195, column: 24, scope: !461)
!467 = !DILocation(line: 198, column: 22, scope: !468)
!468 = distinct !DILexicalBlock(scope: !465, file: !1, line: 195, column: 76)
!469 = !DILocation(line: 199, column: 22, scope: !468)
!470 = !DILocation(line: 201, column: 13, scope: !468)
!471 = !DILocation(line: 204, column: 13, scope: !266)
!472 = !DILocation(line: 207, column: 52, scope: !473)
!473 = distinct !DILexicalBlock(scope: !474, file: !1, line: 206, column: 17)
!474 = distinct !DILexicalBlock(scope: !475, file: !1, line: 204, column: 26)
!475 = distinct !DILexicalBlock(scope: !266, file: !1, line: 204, column: 13)
!476 = !DILocation(line: 206, column: 17, scope: !474)
!477 = !DILocation(line: 152, column: 63, scope: !267)
!478 = !DILocation(line: 152, column: 32, scope: !267)
!479 = distinct !{!479, !352, !480, !334}
!480 = !DILocation(line: 213, column: 5, scope: !268)
!481 = !DILocation(line: 215, column: 5, scope: !250)
!482 = !DILocation(line: 217, column: 5, scope: !250)
!483 = !DILocation(line: 220, column: 12, scope: !484)
!484 = distinct !DILexicalBlock(scope: !250, file: !1, line: 220, column: 9)
!485 = !DILocation(line: 220, column: 28, scope: !484)
!486 = !DILocation(line: 220, column: 23, scope: !484)
!487 = !DILocation(line: 220, column: 9, scope: !250)
!488 = !DILocation(line: 223, column: 19, scope: !489)
!489 = distinct !DILexicalBlock(scope: !250, file: !1, line: 223, column: 9)
!490 = !DILocation(line: 224, column: 14, scope: !491)
!491 = distinct !DILexicalBlock(scope: !489, file: !1, line: 223, column: 50)
!492 = !DILocation(line: 225, column: 14, scope: !491)
!493 = !DILocation(line: 226, column: 5, scope: !491)
!494 = !DILocation(line: 228, column: 1, scope: !250)
!495 = !DISubprogram(name: "global_page_pool_size", scope: !148, file: !148, line: 41, type: !496, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!496 = !DISubroutineType(types: !497)
!497 = !{!5, !498}
!498 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !61, size: 64)
