; ModuleID = 'slabs.c'
source_filename = "slabs.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.settings = type { i64, i32, i32, i32, ptr, i32, i32, i32, ptr, ptr, i32, double, i32, i32, i32, i8, i32, i32, i8, i32, i32, i32, i32, i32, i32, i8, i8, i8, i8, i8, i8, i32, double, i32, i32, i8, i32, i8, i8, ptr, i32, i32, i32, i32, double, double, i32, i8, i32, i32, i32, i32, i32, i8, i8, i8, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, double, double, i8, i32, i32, ptr, i32 }
%struct.slabclass_t = type { i32, i32, ptr, i32, i32, ptr, i32 }
%union.pthread_mutex_t = type { %struct.__pthread_mutex_s }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i16, i16, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%struct.slab_rebalance = type { ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32, i32, i8, ptr }
%union.pthread_cond_t = type { %struct.__pthread_cond_s }
%struct.__pthread_cond_s = type { %union.__atomic_wide_counter, %union.__atomic_wide_counter, [2 x i32], [2 x i32], i32, i32, [2 x i32] }
%union.__atomic_wide_counter = type { i64 }
%struct.stats_state = type { i64, i64, i64, i64, i32, i32, i32, i32, i8, i8, i8, i8 }
%struct.stats = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, %struct.timeval, i64, i64 }
%struct.timeval = type { i64, i64 }
%struct.slab_stats_automove = type { i32, i32, i64, i64 }
%struct.thread_stats = type { %union.pthread_mutex_t, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, [64 x %struct.slab_stats], [256 x i64], i64, i64, i64 }
%struct.slab_stats = type { i64, i64, i64, i64, i64, i64, i64, i64 }

@storage = internal unnamed_addr global ptr null, align 8, !dbg !0
@settings = external local_unnamed_addr global %struct.settings, align 8
@slabclass = internal unnamed_addr global [64 x %struct.slabclass_t] zeroinitializer, align 16, !dbg !178
@power_largest = internal unnamed_addr global i32 0, align 4, !dbg !194
@mem_limit = internal unnamed_addr global i64 0, align 8, !dbg !200
@mem_base = internal unnamed_addr global ptr null, align 8, !dbg !236
@mem_current = internal unnamed_addr global ptr null, align 8, !dbg !238
@mem_avail = internal unnamed_addr global i64 0, align 8, !dbg !240
@stderr = external local_unnamed_addr global ptr, align 8
@.str = private unnamed_addr constant [98 x i8] c"Warning: Failed to allocate requested memory in one large chunk.\0AWill allocate in smaller chunks\0A\00", align 1, !dbg !153
@.str.1 = private unnamed_addr constant [44 x i8] c"slab class %3d: chunk size %9u perslab %7u\0A\00", align 1, !dbg !158
@.str.2 = private unnamed_addr constant [22 x i8] c"T_MEMD_INITIAL_MALLOC\00", align 1, !dbg !163
@mem_malloced = internal unnamed_addr global i64 0, align 8, !dbg !242
@slabs_lock = internal global %union.pthread_mutex_t zeroinitializer, align 8, !dbg !252
@slabs_rebalance_lock = internal global %union.pthread_mutex_t zeroinitializer, align 8, !dbg !349
@slab_rebalance_signal = external global i32, align 4
@slab_rebal = external local_unnamed_addr global %struct.slab_rebalance, align 8
@rebalance_tid = internal global i64 0, align 8, !dbg !196
@.str.3 = private unnamed_addr constant [31 x i8] c"Can't create rebal thread: %s\0A\00", align 1, !dbg !168
@.str.4 = private unnamed_addr constant [13 x i8] c"mc-slabmaint\00", align 1, !dbg !173
@do_run_slab_rebalance_thread = internal global i32 1, align 4, !dbg !371
@slab_rebalance_cond = internal global %union.pthread_cond_t zeroinitializer, align 8, !dbg !374
@.str.5 = private unnamed_addr constant [14 x i8] c"/proc/meminfo\00", align 1, !dbg !202
@.str.6 = private unnamed_addr constant [2 x i8] c"r\00", align 1, !dbg !207
@.str.7 = private unnamed_addr constant [14 x i8] c"Hugepagesize:\00", align 1, !dbg !212
@.str.8 = private unnamed_addr constant [5 x i8] c"%zu\0A\00", align 1, !dbg !214
@.str.9 = private unnamed_addr constant [40 x i8] c"Failed to get supported huge page size\0A\00", align 1, !dbg !219
@.str.10 = private unnamed_addr constant [21 x i8] c"huge page size: %zu\0A\00", align 1, !dbg !224
@.str.11 = private unnamed_addr constant [40 x i8] c"Failed to get aligned memory chunk: %d\0A\00", align 1, !dbg !229
@.str.12 = private unnamed_addr constant [45 x i8] c"Failed to set transparent hugepage hint: %d\0A\00", align 1, !dbg !231
@.str.13 = private unnamed_addr constant [121 x i8] c"Error while preallocating slab memory!\0AIf using -L or other prealloc options, max memory must be at least %d megabytes.\0A\00", align 1, !dbg !247
@.str.14 = private unnamed_addr constant [6 x i8] c"%d:%s\00", align 1, !dbg !280
@.str.15 = private unnamed_addr constant [11 x i8] c"chunk_size\00", align 1, !dbg !285
@.str.16 = private unnamed_addr constant [3 x i8] c"%u\00", align 1, !dbg !290
@.str.17 = private unnamed_addr constant [16 x i8] c"chunks_per_page\00", align 1, !dbg !295
@.str.18 = private unnamed_addr constant [12 x i8] c"total_pages\00", align 1, !dbg !300
@.str.19 = private unnamed_addr constant [13 x i8] c"total_chunks\00", align 1, !dbg !305
@.str.20 = private unnamed_addr constant [12 x i8] c"used_chunks\00", align 1, !dbg !307
@.str.21 = private unnamed_addr constant [12 x i8] c"free_chunks\00", align 1, !dbg !309
@.str.22 = private unnamed_addr constant [16 x i8] c"free_chunks_end\00", align 1, !dbg !311
@.str.23 = private unnamed_addr constant [9 x i8] c"get_hits\00", align 1, !dbg !313
@.str.24 = private unnamed_addr constant [5 x i8] c"%llu\00", align 1, !dbg !318
@.str.25 = private unnamed_addr constant [8 x i8] c"cmd_set\00", align 1, !dbg !320
@.str.26 = private unnamed_addr constant [12 x i8] c"delete_hits\00", align 1, !dbg !325
@.str.27 = private unnamed_addr constant [10 x i8] c"incr_hits\00", align 1, !dbg !327
@.str.28 = private unnamed_addr constant [10 x i8] c"decr_hits\00", align 1, !dbg !332
@.str.29 = private unnamed_addr constant [9 x i8] c"cas_hits\00", align 1, !dbg !334
@.str.30 = private unnamed_addr constant [11 x i8] c"cas_badval\00", align 1, !dbg !336
@.str.31 = private unnamed_addr constant [11 x i8] c"touch_hits\00", align 1, !dbg !338
@.str.32 = private unnamed_addr constant [13 x i8] c"active_slabs\00", align 1, !dbg !340
@.str.33 = private unnamed_addr constant [3 x i8] c"%d\00", align 1, !dbg !342
@.str.34 = private unnamed_addr constant [15 x i8] c"total_malloced\00", align 1, !dbg !344
@slabs_reassign_pick_any.cur = internal unnamed_addr global i32 0, align 4, !dbg !351
@.str.35 = private unnamed_addr constant [26 x i8] c"Started a slab rebalance\0A\00", align 1, !dbg !359
@stats_state = external local_unnamed_addr global %struct.stats_state, align 8
@hash = external local_unnamed_addr global ptr, align 8
@.str.36 = private unnamed_addr constant [56 x i8] c"Slab reassign hit a busy item: refcount: %d (%d -> %d)\0A\00", align 1, !dbg !364
@current_time = external global i32, align 4
@stats = external local_unnamed_addr global %struct.stats, align 8
@.str.37 = private unnamed_addr constant [22 x i8] c"finished a slab move\0A\00", align 1, !dbg !369
@llvm.used = appending global [1 x ptr] [ptr @tsan.module_ctor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 0, ptr @tsan.module_ctor, ptr null }]

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local void @slabs_set_storage(ptr noundef %arg) local_unnamed_addr #0 !dbg !414 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %arg, metadata !418, metadata !DIExpression()), !dbg !419
  store ptr %arg, ptr @storage, align 8, !dbg !420, !tbaa !421
  ret void, !dbg !425
}

; Function Attrs: nofree norecurse nosync nounwind sanitize_thread memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @slabs_clsid(i64 noundef %size) local_unnamed_addr #1 !dbg !426 {
entry:
  tail call void @llvm.dbg.value(metadata i64 %size, metadata !431, metadata !DIExpression()), !dbg !433
  tail call void @llvm.dbg.value(metadata i32 1, metadata !432, metadata !DIExpression()), !dbg !433
  %cmp = icmp eq i64 %size, 0, !dbg !434
  br i1 %cmp, label %cleanup, label %lor.lhs.false, !dbg !436

lor.lhs.false:                                    ; preds = %entry
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 21), align 4, !dbg !437, !tbaa !438
  %conv = sext i32 %0 to i64, !dbg !444
  %cmp1 = icmp ult i64 %conv, %size, !dbg !445
  br i1 %cmp1, label %cleanup, label %while.cond, !dbg !446

while.cond:                                       ; preds = %lor.lhs.false, %while.body
  %indvars.iv = phi i64 [ %indvars.iv.next, %while.body ], [ 1, %lor.lhs.false ], !dbg !433
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !432, metadata !DIExpression()), !dbg !433
  %arrayidx = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %indvars.iv, !dbg !447
  %1 = load i32, ptr %arrayidx, align 8, !dbg !448, !tbaa !449
  %conv4 = zext i32 %1 to i64, !dbg !447
  %cmp5 = icmp ult i64 %conv4, %size, !dbg !451
  br i1 %cmp5, label %while.body, label %cleanup.loopexit.split.loop.exit16, !dbg !452

while.body:                                       ; preds = %while.cond
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !453
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !432, metadata !DIExpression()), !dbg !433
  %2 = load i32, ptr @power_largest, align 4, !dbg !455, !tbaa !456
  %3 = zext i32 %2 to i64, !dbg !457
  %cmp7 = icmp eq i64 %indvars.iv, %3, !dbg !457
  br i1 %cmp7, label %cleanup, label %while.cond, !dbg !458, !llvm.loop !459

cleanup.loopexit.split.loop.exit16:               ; preds = %while.cond
  %4 = trunc nuw nsw i64 %indvars.iv to i32
  br label %cleanup, !dbg !462

cleanup:                                          ; preds = %while.body, %cleanup.loopexit.split.loop.exit16, %entry, %lor.lhs.false
  %retval.0 = phi i32 [ 0, %lor.lhs.false ], [ 0, %entry ], [ %4, %cleanup.loopexit.split.loop.exit16 ], [ %2, %while.body ], !dbg !433
  ret i32 %retval.0, !dbg !462
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @slabs_size(i32 noundef %clsid) local_unnamed_addr #3 !dbg !463 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %clsid, metadata !468, metadata !DIExpression()), !dbg !469
  %idxprom = sext i32 %clsid to i64, !dbg !470
  %arrayidx = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom, !dbg !470
  %0 = load i32, ptr %arrayidx, align 8, !dbg !471, !tbaa !449
  ret i32 %0, !dbg !472
}

; Function Attrs: mustprogress nounwind sanitize_thread willreturn uwtable
define dso_local i32 @slabs_fixup(ptr noundef %chunk, i32 noundef %border) local_unnamed_addr #4 !dbg !473 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %chunk, metadata !477, metadata !DIExpression()), !dbg !483
  tail call void @llvm.dbg.value(metadata i32 %border, metadata !478, metadata !DIExpression()), !dbg !483
  tail call void @llvm.dbg.value(metadata ptr %chunk, metadata !481, metadata !DIExpression()), !dbg !483
  %slabs_clsid = getelementptr inbounds i8, ptr %chunk, i64 40, !dbg !484
  %0 = load i8, ptr %slabs_clsid, align 8, !dbg !484, !tbaa !485
  %1 = and i8 %0, 63, !dbg !484
  tail call void @llvm.dbg.value(metadata i8 %1, metadata !482, metadata !DIExpression(DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !483
  %cmp = icmp eq i8 %1, 0, !dbg !486
  br i1 %cmp, label %if.then, label %if.end, !dbg !488

if.then:                                          ; preds = %entry
  tail call void @llvm.dbg.value(metadata ptr @slabclass, metadata !479, metadata !DIExpression()), !dbg !483
  tail call void @llvm.dbg.value(metadata i32 0, metadata !489, metadata !DIExpression()), !dbg !500
  tail call void @llvm.dbg.value(metadata ptr @slabclass, metadata !495, metadata !DIExpression()), !dbg !500
  %2 = load i32, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 4), align 4, !dbg !503, !tbaa !504
  %3 = load i32, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 6), align 16, !dbg !505, !tbaa !506
  %cmp.i = icmp eq i32 %2, %3, !dbg !507
  %.pre58 = load ptr, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 5), align 8, !dbg !508, !tbaa !509
  br i1 %cmp.i, label %if.then.i, label %grow_slab_list.exit, !dbg !510

if.then.i:                                        ; preds = %if.then
  %cmp2.not.i = icmp eq i32 %2, 0, !dbg !511
  %mul.i = shl i32 %2, 1
  %spec.select.i = select i1 %cmp2.not.i, i32 16, i32 %mul.i, !dbg !512
  %conv.i = zext i32 %spec.select.i to i64, !dbg !512
  tail call void @llvm.dbg.value(metadata i64 %conv.i, metadata !496, metadata !DIExpression()), !dbg !513
  %mul4.i = shl nuw nsw i64 %conv.i, 3, !dbg !514
  %call.i = tail call ptr @realloc(ptr noundef %.pre58, i64 noundef %mul4.i) #22, !dbg !515
  tail call void @llvm.dbg.value(metadata ptr %call.i, metadata !499, metadata !DIExpression()), !dbg !513
  %cmp5.not.i = icmp eq ptr %call.i, null, !dbg !516
  br i1 %cmp5.not.i, label %if.then.i.grow_slab_list.exit_crit_edge, label %if.end.i, !dbg !518

if.then.i.grow_slab_list.exit_crit_edge:          ; preds = %if.then.i
  %.pre = load ptr, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 5), align 8, !dbg !508, !tbaa !509
  br label %grow_slab_list.exit, !dbg !518

if.end.i:                                         ; preds = %if.then.i
  store i32 %spec.select.i, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 6), align 16, !dbg !519, !tbaa !506
  store ptr %call.i, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 5), align 8, !dbg !520, !tbaa !509
  br label %grow_slab_list.exit

grow_slab_list.exit:                              ; preds = %if.then.i.grow_slab_list.exit_crit_edge, %if.then, %if.end.i
  %4 = phi ptr [ %.pre, %if.then.i.grow_slab_list.exit_crit_edge ], [ %.pre58, %if.then ], [ %call.i, %if.end.i ], !dbg !508
  %5 = load i32, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 4), align 4, !dbg !521, !tbaa !504
  %inc = add i32 %5, 1, !dbg !521
  store i32 %inc, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 4), align 4, !dbg !521, !tbaa !504
  %idxprom = zext i32 %5 to i64, !dbg !522
  %arrayidx = getelementptr inbounds ptr, ptr %4, i64 %idxprom, !dbg !522
  store ptr %chunk, ptr %arrayidx, align 8, !dbg !523, !tbaa !421
  br label %cleanup, !dbg !524

if.end:                                           ; preds = %entry
  %idxprom2 = zext nneg i8 %1 to i64
  %arrayidx3 = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom2, !dbg !525
  tail call void @llvm.dbg.value(metadata ptr %arrayidx3, metadata !479, metadata !DIExpression()), !dbg !483
  %cmp4 = icmp eq i32 %border, 0, !dbg !526
  br i1 %cmp4, label %if.then6, label %if.end13, !dbg !528

if.then6:                                         ; preds = %if.end
  tail call void @llvm.dbg.value(metadata i8 %1, metadata !489, metadata !DIExpression(DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !529
  tail call void @llvm.dbg.value(metadata ptr %arrayidx3, metadata !495, metadata !DIExpression()), !dbg !529
  %slabs.i = getelementptr inbounds i8, ptr %arrayidx3, i64 20, !dbg !532
  %6 = load i32, ptr %slabs.i, align 4, !dbg !532, !tbaa !504
  %list_size.i = getelementptr inbounds i8, ptr %arrayidx3, i64 32, !dbg !533
  %7 = load i32, ptr %list_size.i, align 8, !dbg !533, !tbaa !506
  %cmp.i46 = icmp eq i32 %6, %7, !dbg !534
  br i1 %cmp.i46, label %if.then.i48, label %grow_slab_list.exit57, !dbg !535

if.then.i48:                                      ; preds = %if.then6
  %cmp2.not.i49 = icmp eq i32 %6, 0, !dbg !536
  %mul.i50 = shl i32 %6, 1
  %spec.select.i51 = select i1 %cmp2.not.i49, i32 16, i32 %mul.i50, !dbg !537
  %conv.i52 = zext i32 %spec.select.i51 to i64, !dbg !537
  tail call void @llvm.dbg.value(metadata i64 %conv.i52, metadata !496, metadata !DIExpression()), !dbg !538
  %slab_list.i = getelementptr inbounds i8, ptr %arrayidx3, i64 24, !dbg !539
  %8 = load ptr, ptr %slab_list.i, align 8, !dbg !539, !tbaa !509
  %mul4.i53 = shl nuw nsw i64 %conv.i52, 3, !dbg !540
  %call.i54 = tail call ptr @realloc(ptr noundef %8, i64 noundef %mul4.i53) #22, !dbg !541
  tail call void @llvm.dbg.value(metadata ptr %call.i54, metadata !499, metadata !DIExpression()), !dbg !538
  %cmp5.not.i55 = icmp eq ptr %call.i54, null, !dbg !542
  br i1 %cmp5.not.i55, label %grow_slab_list.exit57, label %if.end.i56, !dbg !543

if.end.i56:                                       ; preds = %if.then.i48
  store i32 %spec.select.i51, ptr %list_size.i, align 8, !dbg !544, !tbaa !506
  store ptr %call.i54, ptr %slab_list.i, align 8, !dbg !545, !tbaa !509
  br label %grow_slab_list.exit57

grow_slab_list.exit57:                            ; preds = %if.then6, %if.then.i48, %if.end.i56
  %slab_list8 = getelementptr inbounds i8, ptr %arrayidx3, i64 24, !dbg !546
  %9 = load ptr, ptr %slab_list8, align 8, !dbg !546, !tbaa !509
  %10 = load i32, ptr %slabs.i, align 4, !dbg !547, !tbaa !504
  %inc10 = add i32 %10, 1, !dbg !547
  store i32 %inc10, ptr %slabs.i, align 4, !dbg !547, !tbaa !504
  %idxprom11 = zext i32 %10 to i64, !dbg !548
  %arrayidx12 = getelementptr inbounds ptr, ptr %9, i64 %idxprom11, !dbg !548
  store ptr %chunk, ptr %arrayidx12, align 8, !dbg !549, !tbaa !421
  br label %if.end13, !dbg !550

if.end13:                                         ; preds = %grow_slab_list.exit57, %if.end
  %it_flags = getelementptr inbounds i8, ptr %chunk, i64 38, !dbg !551
  %11 = load i16, ptr %it_flags, align 2, !dbg !551, !tbaa !553
  %cmp15 = icmp eq i16 %11, 4, !dbg !555
  br i1 %cmp15, label %if.then17, label %if.end25, !dbg !556

if.then17:                                        ; preds = %if.end13
  %prev = getelementptr inbounds i8, ptr %chunk, i64 8, !dbg !557
  store ptr null, ptr %prev, align 8, !dbg !559, !tbaa !421
  %slots = getelementptr inbounds i8, ptr %arrayidx3, i64 8, !dbg !560
  %12 = load ptr, ptr %slots, align 8, !dbg !560, !tbaa !561
  store ptr %12, ptr %chunk, align 8, !dbg !562, !tbaa !421
  %tobool.not = icmp eq ptr %12, null, !dbg !563
  br i1 %tobool.not, label %if.end22, label %if.then19, !dbg !565

if.then19:                                        ; preds = %if.then17
  %prev21 = getelementptr inbounds i8, ptr %12, i64 8, !dbg !566
  store ptr %chunk, ptr %prev21, align 8, !dbg !567, !tbaa !421
  br label %if.end22, !dbg !568

if.end22:                                         ; preds = %if.then19, %if.then17
  store ptr %chunk, ptr %slots, align 8, !dbg !569, !tbaa !561
  %sl_curr = getelementptr inbounds i8, ptr %arrayidx3, i64 16, !dbg !570
  %13 = load i32, ptr %sl_curr, align 8, !dbg !571, !tbaa !572
  %inc24 = add i32 %13, 1, !dbg !571
  store i32 %inc24, ptr %sl_curr, align 8, !dbg !571, !tbaa !572
  br label %if.end25, !dbg !573

if.end25:                                         ; preds = %if.end22, %if.end13
  %14 = load i32, ptr %arrayidx3, align 8, !dbg !574, !tbaa !449
  br label %cleanup, !dbg !575

cleanup:                                          ; preds = %if.end25, %grow_slab_list.exit
  %retval.0 = phi i32 [ -1, %grow_slab_list.exit ], [ %14, %if.end25 ], !dbg !483
  ret i32 %retval.0, !dbg !576
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @slabs_init(i64 noundef %limit, double noundef %factor, i1 noundef zeroext %prealloc, ptr noundef readonly %slab_sizes, ptr noundef %mem_base_external, i1 noundef zeroext %reuse_mem) local_unnamed_addr #5 !dbg !577 {
entry:
  %ptr.i = alloca ptr, align 8, !DIAssignID !605
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !606, metadata !DIExpression(), metadata !605, metadata ptr %ptr.i, metadata !DIExpression()), !dbg !672
  %pagesize.i = alloca i64, align 8, !DIAssignID !676
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !612, metadata !DIExpression(), metadata !676, metadata ptr %pagesize.i, metadata !DIExpression()), !dbg !672
  %buf.i = alloca [64 x i8], align 16, !DIAssignID !677
  %env_malloced = alloca i64, align 8, !DIAssignID !678
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !599, metadata !DIExpression(), metadata !678, metadata ptr %env_malloced, metadata !DIExpression()), !dbg !679
  tail call void @llvm.dbg.value(metadata i64 %limit, metadata !588, metadata !DIExpression()), !dbg !680
  tail call void @llvm.dbg.value(metadata double %factor, metadata !589, metadata !DIExpression()), !dbg !680
  tail call void @llvm.dbg.value(metadata i1 %prealloc, metadata !590, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !680
  tail call void @llvm.dbg.value(metadata ptr %slab_sizes, metadata !591, metadata !DIExpression()), !dbg !680
  tail call void @llvm.dbg.value(metadata ptr %mem_base_external, metadata !592, metadata !DIExpression()), !dbg !680
  tail call void @llvm.dbg.value(metadata i1 %reuse_mem, metadata !593, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !680
  tail call void @llvm.dbg.value(metadata i32 0, metadata !594, metadata !DIExpression()), !dbg !680
  %0 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 12), align 8, !dbg !681, !tbaa !682
  %add = add i32 %0, 48, !dbg !683
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !595, metadata !DIExpression()), !dbg !680
  tail call void @llvm.dbg.value(metadata i8 0, metadata !596, metadata !DIExpression()), !dbg !680
  store i64 %limit, ptr @mem_limit, align 8, !dbg !684, !tbaa !685
  %cmp = icmp eq ptr %mem_base_external, null
  %or.cond = and i1 %cmp, %prealloc, !dbg !686
  br i1 %or.cond, label %if.then, label %if.else8, !dbg !686

if.then:                                          ; preds = %entry
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !668, metadata !DIExpression(), metadata !677, metadata ptr %buf.i, metadata !DIExpression()), !dbg !687
  tail call void @llvm.dbg.value(metadata i64 %limit, metadata !611, metadata !DIExpression()), !dbg !672
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %ptr.i) #23, !dbg !688
  store ptr null, ptr %ptr.i, align 8, !dbg !689, !tbaa !421, !DIAssignID !690
  tail call void @llvm.dbg.assign(metadata ptr null, metadata !606, metadata !DIExpression(), metadata !690, metadata ptr %ptr.i, metadata !DIExpression()), !dbg !672
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %pagesize.i) #23, !dbg !691
  store i64 0, ptr %pagesize.i, align 8, !dbg !692, !tbaa !685, !DIAssignID !693
  tail call void @llvm.dbg.assign(metadata i64 0, metadata !612, metadata !DIExpression(), metadata !693, metadata ptr %pagesize.i, metadata !DIExpression()), !dbg !672
  %call.i = tail call noalias ptr @fopen(ptr noundef nonnull @.str.5, ptr noundef nonnull @.str.6), !dbg !694
  tail call void @llvm.dbg.value(metadata ptr %call.i, metadata !613, metadata !DIExpression()), !dbg !672
  %cmp.not.i = icmp eq ptr %call.i, null, !dbg !695
  br i1 %cmp.not.i, label %if.then11.i, label %if.then.i, !dbg !696

if.then.i:                                        ; preds = %if.then
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %buf.i) #23, !dbg !697
  %call137.i = call ptr @fgets(ptr noundef nonnull %buf.i, i32 noundef 64, ptr noundef nonnull %call.i), !dbg !698
  %tobool.not38.i = icmp eq ptr %call137.i, null, !dbg !699
  br i1 %tobool.not38.i, label %if.end9.i, label %while.body.lr.ph.i, !dbg !699

while.body.lr.ph.i:                               ; preds = %if.then.i
  %add.ptr.i = getelementptr inbounds i8, ptr %buf.i, i64 13
  br label %while.body.i, !dbg !699

while.body.i:                                     ; preds = %if.end.i, %while.body.lr.ph.i
  %bcmp.i = call i32 @bcmp(ptr noundef nonnull dereferenceable(13) %buf.i, ptr noundef nonnull dereferenceable(13) @.str.7, i64 13) #24, !dbg !700
  %tobool4.not.i = icmp eq i32 %bcmp.i, 0, !dbg !700
  br i1 %tobool4.not.i, label %if.then5.i, label %if.end.i, !dbg !702

if.then5.i:                                       ; preds = %while.body.i
  %call7.i = call i32 (ptr, ptr, ...) @__isoc23_sscanf(ptr noundef nonnull %add.ptr.i, ptr noundef nonnull @.str.8, ptr noundef nonnull %pagesize.i) #23, !dbg !703
  tail call void @llvm.dbg.value(metadata i32 %call7.i, metadata !667, metadata !DIExpression()), !dbg !672
  %1 = load i64, ptr %pagesize.i, align 8, !dbg !705, !tbaa !685
  %shl.i = shl i64 %1, 10, !dbg !705
  store i64 %shl.i, ptr %pagesize.i, align 8, !dbg !705, !tbaa !685, !DIAssignID !706
  tail call void @llvm.dbg.assign(metadata i64 %shl.i, metadata !612, metadata !DIExpression(), metadata !706, metadata ptr %pagesize.i, metadata !DIExpression()), !dbg !672
  br label %if.end.i, !dbg !707

if.end.i:                                         ; preds = %if.then5.i, %while.body.i
  %call1.i = call ptr @fgets(ptr noundef nonnull %buf.i, i32 noundef 64, ptr noundef nonnull %call.i), !dbg !698
  %tobool.not.i = icmp eq ptr %call1.i, null, !dbg !699
  br i1 %tobool.not.i, label %if.end9.i, label %while.body.i, !dbg !699, !llvm.loop !708

if.end9.i:                                        ; preds = %if.end.i, %if.then.i
  %call8.i = call i32 @fclose(ptr noundef nonnull %call.i), !dbg !710
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %buf.i) #23, !dbg !711
  %.pre.i = load i64, ptr %pagesize.i, align 8, !dbg !712, !tbaa !685
  %tobool10.not.i = icmp eq i64 %.pre.i, 0, !dbg !712
  br i1 %tobool10.not.i, label %if.then11.i, label %if.end13.i, !dbg !714

if.then11.i:                                      ; preds = %if.end9.i, %if.then
  %2 = load ptr, ptr @stderr, align 8, !dbg !715, !tbaa !421
  %3 = call i64 @fwrite(ptr nonnull @.str.9, i64 39, i64 1, ptr %2) #25, !dbg !717
  br label %alloc_large_chunk.exit.thread, !dbg !718

if.end13.i:                                       ; preds = %if.end9.i
  %4 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !719, !tbaa !721
  %cmp14.i = icmp sgt i32 %4, 1, !dbg !722
  br i1 %cmp14.i, label %if.then15.i, label %if.end17.i, !dbg !723

if.then15.i:                                      ; preds = %if.end13.i
  %5 = load ptr, ptr @stderr, align 8, !dbg !724, !tbaa !421
  %call16.i = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %5, ptr noundef nonnull @.str.10, i64 noundef %.pre.i) #26, !dbg !725
  %.pre39.i = load i64, ptr %pagesize.i, align 8, !dbg !726, !tbaa !685
  br label %if.end17.i, !dbg !725

if.end17.i:                                       ; preds = %if.then15.i, %if.end13.i
  %6 = phi i64 [ %.pre39.i, %if.then15.i ], [ %.pre.i, %if.end13.i ], !dbg !726
  %call18.i = call i32 @posix_memalign(ptr noundef nonnull %ptr.i, i64 noundef %6, i64 noundef %limit) #23, !dbg !727
  tail call void @llvm.dbg.value(metadata i32 %call18.i, metadata !667, metadata !DIExpression()), !dbg !672
  %cmp19.not.i = icmp eq i32 %call18.i, 0, !dbg !728
  br i1 %cmp19.not.i, label %if.end22.i, label %if.then20.i, !dbg !730

if.then20.i:                                      ; preds = %if.end17.i
  %7 = load ptr, ptr @stderr, align 8, !dbg !731, !tbaa !421
  %call21.i = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %7, ptr noundef nonnull @.str.11, i32 noundef %call18.i) #26, !dbg !733
  br label %alloc_large_chunk.exit.thread, !dbg !734

if.end22.i:                                       ; preds = %if.end17.i
  %8 = load ptr, ptr %ptr.i, align 8, !dbg !735, !tbaa !421
  %call23.i = call i32 @madvise(ptr noundef %8, i64 noundef %limit, i32 noundef 14) #23, !dbg !736
  tail call void @llvm.dbg.value(metadata i32 %call23.i, metadata !667, metadata !DIExpression()), !dbg !672
  %cmp24.i = icmp slt i32 %call23.i, 0, !dbg !737
  br i1 %cmp24.i, label %if.then25.i, label %alloc_large_chunk.exit, !dbg !739

if.then25.i:                                      ; preds = %if.end22.i
  %9 = load ptr, ptr @stderr, align 8, !dbg !740, !tbaa !421
  %call26.i = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %9, ptr noundef nonnull @.str.12, i32 noundef %call23.i) #26, !dbg !742
  %10 = load ptr, ptr %ptr.i, align 8, !dbg !743, !tbaa !421
  call void @free(ptr noundef %10) #23, !dbg !744
  tail call void @llvm.dbg.assign(metadata ptr null, metadata !606, metadata !DIExpression(), metadata !745, metadata ptr %ptr.i, metadata !DIExpression()), !dbg !672
  br label %alloc_large_chunk.exit.thread, !dbg !746

alloc_large_chunk.exit.thread:                    ; preds = %if.then20.i, %if.then11.i, %if.then25.i
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %pagesize.i) #23, !dbg !747
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %ptr.i) #23, !dbg !747
  store ptr null, ptr @mem_base, align 8, !dbg !748, !tbaa !421
  br label %if.else, !dbg !749

alloc_large_chunk.exit:                           ; preds = %if.end22.i
  %.pre40.i = load ptr, ptr %ptr.i, align 8, !dbg !750, !tbaa !421
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %pagesize.i) #23, !dbg !747
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %ptr.i) #23, !dbg !747
  store ptr %.pre40.i, ptr @mem_base, align 8, !dbg !748, !tbaa !421
  %tobool5.not = icmp eq ptr %.pre40.i, null, !dbg !751
  br i1 %tobool5.not, label %if.else, label %if.then6, !dbg !749

if.then6:                                         ; preds = %alloc_large_chunk.exit
  tail call void @llvm.dbg.value(metadata i8 1, metadata !596, metadata !DIExpression()), !dbg !680
  store ptr %.pre40.i, ptr @mem_current, align 8, !dbg !753, !tbaa !421
  %11 = load i64, ptr @mem_limit, align 8, !dbg !755, !tbaa !685
  store i64 %11, ptr @mem_avail, align 8, !dbg !756, !tbaa !685
  br label %if.end20, !dbg !757

if.else:                                          ; preds = %alloc_large_chunk.exit.thread, %alloc_large_chunk.exit
  %12 = load ptr, ptr @stderr, align 8, !dbg !758, !tbaa !421
  %13 = call i64 @fwrite(ptr nonnull @.str, i64 97, i64 1, ptr %12) #25, !dbg !760
  br label %if.end20

if.else8:                                         ; preds = %entry
  %prealloc.not = xor i1 %prealloc, true, !dbg !761
  %or.cond130 = or i1 %cmp, %prealloc.not, !dbg !761
  br i1 %or.cond130, label %if.end20, label %if.then14, !dbg !761

if.then14:                                        ; preds = %if.else8
  tail call void @llvm.dbg.value(metadata i8 1, metadata !596, metadata !DIExpression()), !dbg !680
  store ptr %mem_base_external, ptr @mem_base, align 8, !dbg !763, !tbaa !421
  br i1 %reuse_mem, label %if.then16, label %if.else17, !dbg !765

if.then16:                                        ; preds = %if.then14
  %add.ptr = getelementptr inbounds i8, ptr %mem_base_external, i64 %limit, !dbg !766
  store ptr %add.ptr, ptr @mem_current, align 8, !dbg !769, !tbaa !421
  store i64 0, ptr @mem_avail, align 8, !dbg !770, !tbaa !685
  br label %if.end20, !dbg !771

if.else17:                                        ; preds = %if.then14
  store ptr %mem_base_external, ptr @mem_current, align 8, !dbg !772, !tbaa !421
  store i64 %limit, ptr @mem_avail, align 8, !dbg !774, !tbaa !685
  br label %if.end20

if.end20:                                         ; preds = %if.else8, %if.else17, %if.then16, %if.then6, %if.else
  %do_slab_prealloc.0.not = phi i1 [ false, %if.then6 ], [ true, %if.else ], [ false, %if.then16 ], [ false, %if.else17 ], [ true, %if.else8 ], !dbg !680
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !596, metadata !DIExpression()), !dbg !680
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(2560) @slabclass, i8 0, i64 2560, i1 false), !dbg !775
  tail call void @llvm.dbg.value(metadata i32 0, metadata !594, metadata !DIExpression()), !dbg !680
  tail call void @llvm.dbg.value(metadata i32 %add, metadata !595, metadata !DIExpression()), !dbg !680
  %cmp23.not = icmp eq ptr %slab_sizes, null
  br label %while.body, !dbg !776

while.body:                                       ; preds = %if.end20, %if.end72
  %indvars.iv138 = phi i64 [ 0, %if.end20 ], [ %indvars.iv.next139, %if.end72 ]
  %indvars.iv = phi i64 [ 1, %if.end20 ], [ %indvars.iv.next, %if.end72 ]
  %size.0135 = phi i32 [ %add, %if.end20 ], [ %size.3, %if.end72 ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv138, metadata !594, metadata !DIExpression()), !dbg !680
  tail call void @llvm.dbg.value(metadata i32 %size.0135, metadata !595, metadata !DIExpression()), !dbg !680
  %14 = trunc nuw nsw i64 %indvars.iv to i32, !dbg !777
  br i1 %cmp23.not, label %if.else33, label %if.then25, !dbg !777

if.then25:                                        ; preds = %while.body
  %arrayidx = getelementptr inbounds i32, ptr %slab_sizes, i64 %indvars.iv138, !dbg !779
  %15 = load i32, ptr %arrayidx, align 4, !dbg !779, !tbaa !456
  %cmp26 = icmp eq i32 %15, 0, !dbg !783
  br i1 %cmp26, label %while.end, label %if.end40, !dbg !784

if.else33:                                        ; preds = %while.body
  %conv34 = uitofp i32 %size.0135 to double, !dbg !785
  %16 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 22), align 8, !dbg !787, !tbaa !788
  %conv35 = sitofp i32 %16 to double, !dbg !789
  %div = fdiv double %conv35, %factor, !dbg !790
  %cmp36 = fcmp ugt double %div, %conv34, !dbg !791
  br i1 %cmp36, label %if.end40, label %while.end, !dbg !792

if.end40:                                         ; preds = %if.then25, %if.else33
  %size.1 = phi i32 [ %size.0135, %if.else33 ], [ %15, %if.then25 ], !dbg !680
  tail call void @llvm.dbg.value(metadata i32 %size.1, metadata !595, metadata !DIExpression()), !dbg !680
  %size.1.biased = add i32 %size.1, 7, !dbg !793
  %size.2 = and i32 %size.1.biased, -8, !dbg !793
  tail call void @llvm.dbg.value(metadata i32 %size.2, metadata !595, metadata !DIExpression()), !dbg !680
  %arrayidx48 = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %indvars.iv, !dbg !794
  store i32 %size.2, ptr %arrayidx48, align 8, !dbg !795, !tbaa !449
  %17 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 23), align 4, !dbg !796, !tbaa !797
  %div53 = udiv i32 %17, %size.2, !dbg !798
  %perslab = getelementptr inbounds i8, ptr %arrayidx48, i64 4, !dbg !799
  store i32 %div53, ptr %perslab, align 4, !dbg !800, !tbaa !801
  %conv59 = uitofp i32 %size.2 to double, !dbg !802
  %mul = fmul double %conv59, %factor, !dbg !802
  %conv60 = fptoui double %mul to i32, !dbg !802
  %size.3 = select i1 %cmp23.not, i32 %conv60, i32 %size.2, !dbg !802
  tail call void @llvm.dbg.value(metadata i32 %size.3, metadata !595, metadata !DIExpression()), !dbg !680
  %18 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !803, !tbaa !721
  %cmp62 = icmp sgt i32 %18, 1, !dbg !805
  br i1 %cmp62, label %if.then64, label %if.end72, !dbg !806

if.then64:                                        ; preds = %if.end40
  %19 = load ptr, ptr @stderr, align 8, !dbg !807, !tbaa !421
  %call71 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %19, ptr noundef nonnull @.str.1, i32 noundef %14, i32 noundef %size.2, i32 noundef %div53) #26, !dbg !809
  br label %if.end72, !dbg !810

if.end72:                                         ; preds = %if.then64, %if.end40
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !594, metadata !DIExpression()), !dbg !680
  tail call void @llvm.dbg.value(metadata i32 %size.3, metadata !595, metadata !DIExpression()), !dbg !680
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1, !dbg !811
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !594, metadata !DIExpression()), !dbg !680
  %indvars.iv.next139 = add nuw nsw i64 %indvars.iv138, 1, !dbg !776
  %exitcond.not = icmp eq i64 %indvars.iv.next139, 62, !dbg !812
  br i1 %exitcond.not, label %while.end, label %while.body, !dbg !776, !llvm.loop !813

while.end:                                        ; preds = %if.else33, %if.then25, %if.end72
  %inc.lcssa = phi i32 [ %14, %if.else33 ], [ %14, %if.then25 ], [ 63, %if.end72 ], !dbg !811
  store i32 %inc.lcssa, ptr @power_largest, align 4, !dbg !815, !tbaa !456
  %20 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 22), align 8, !dbg !816, !tbaa !788
  %idxprom73 = zext nneg i32 %inc.lcssa to i64, !dbg !817
  %arrayidx74 = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom73, !dbg !817
  store i32 %20, ptr %arrayidx74, align 8, !dbg !818, !tbaa !449
  %21 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 23), align 4, !dbg !819, !tbaa !797
  %div76 = sdiv i32 %21, %20, !dbg !820
  %perslab79 = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom73, i32 1, !dbg !821
  store i32 %div76, ptr %perslab79, align 4, !dbg !822, !tbaa !801
  %22 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !823, !tbaa !721
  %cmp80 = icmp sgt i32 %22, 1, !dbg !825
  br i1 %cmp80, label %if.then82, label %if.end90, !dbg !826

if.then82:                                        ; preds = %while.end
  %23 = load ptr, ptr @stderr, align 8, !dbg !827, !tbaa !421
  %call89 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %23, ptr noundef nonnull @.str.1, i32 noundef %inc.lcssa, i32 noundef %20, i32 noundef %div76) #26, !dbg !829
  br label %if.end90, !dbg !830

if.end90:                                         ; preds = %if.then82, %while.end
  %call91 = call ptr @getenv(ptr noundef nonnull @.str.2) #23, !dbg !831
  tail call void @llvm.dbg.value(metadata ptr %call91, metadata !597, metadata !DIExpression()), !dbg !832
  %tobool92.not = icmp eq ptr %call91, null, !dbg !833
  br i1 %tobool92.not, label %if.end97, label %if.then93, !dbg !834

if.then93:                                        ; preds = %if.end90
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %env_malloced) #23, !dbg !835
  %call94 = call zeroext i1 @safe_strtoll(ptr noundef nonnull %call91, ptr noundef nonnull %env_malloced) #23, !dbg !836
  br i1 %call94, label %if.then95, label %if.end96, !dbg !838

if.then95:                                        ; preds = %if.then93
  %24 = load i64, ptr %env_malloced, align 8, !dbg !839, !tbaa !685
  store i64 %24, ptr @mem_malloced, align 8, !dbg !841, !tbaa !685
  br label %if.end96, !dbg !842

if.end96:                                         ; preds = %if.then95, %if.then93
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %env_malloced) #23, !dbg !843
  br label %if.end97, !dbg !844

if.end97:                                         ; preds = %if.end96, %if.end90
  %brmerge = or i1 %do_slab_prealloc.0.not, %reuse_mem, !dbg !845
  br i1 %brmerge, label %if.end103, label %if.then101, !dbg !845

if.then101:                                       ; preds = %if.end97
  %25 = load i32, ptr @power_largest, align 4, !dbg !846, !tbaa !456
  tail call void @llvm.dbg.value(metadata i32 %25, metadata !851, metadata !DIExpression()), !dbg !858
  tail call void @llvm.dbg.value(metadata i32 0, metadata !857, metadata !DIExpression()), !dbg !858
  tail call void @llvm.dbg.value(metadata i32 1, metadata !856, metadata !DIExpression()), !dbg !858
  br label %for.body.i, !dbg !860

for.cond.i:                                       ; preds = %if.end.i131
  %inc6.i = add nuw nsw i32 %i.09.i, 1, !dbg !862
  tail call void @llvm.dbg.value(metadata i32 %inc.i, metadata !857, metadata !DIExpression()), !dbg !858
  tail call void @llvm.dbg.value(metadata i32 %inc6.i, metadata !856, metadata !DIExpression()), !dbg !858
  %exitcond.not.i = icmp eq i32 %inc.i, 63, !dbg !864
  br i1 %exitcond.not.i, label %if.end103, label %for.body.i, !dbg !860, !llvm.loop !865

for.body.i:                                       ; preds = %for.cond.i, %if.then101
  %prealloc.010.i = phi i32 [ 0, %if.then101 ], [ %inc.i, %for.cond.i ]
  %i.09.i = phi i32 [ 1, %if.then101 ], [ %inc6.i, %for.cond.i ]
  tail call void @llvm.dbg.value(metadata i32 %prealloc.010.i, metadata !857, metadata !DIExpression()), !dbg !858
  tail call void @llvm.dbg.value(metadata i32 %i.09.i, metadata !856, metadata !DIExpression()), !dbg !858
  %inc.i = add nuw nsw i32 %prealloc.010.i, 1, !dbg !867
  tail call void @llvm.dbg.value(metadata i32 %inc.i, metadata !857, metadata !DIExpression()), !dbg !858
  %exitcond143.not = icmp eq i32 %prealloc.010.i, %25, !dbg !870
  br i1 %exitcond143.not, label %if.end103, label %if.end.i131, !dbg !871

if.end.i131:                                      ; preds = %for.body.i
  %call.i132 = call fastcc i32 @do_slabs_newslab(i32 noundef %i.09.i), !dbg !872
  %cmp2.i = icmp eq i32 %call.i132, 0, !dbg !874
  tail call void @llvm.dbg.value(metadata i32 %i.09.i, metadata !856, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !858
  br i1 %cmp2.i, label %if.then3.i, label %for.cond.i, !dbg !875

if.then3.i:                                       ; preds = %if.end.i131
  %26 = load ptr, ptr @stderr, align 8, !dbg !876, !tbaa !421
  %27 = load i32, ptr @power_largest, align 4, !dbg !878, !tbaa !456
  %call4.i = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %26, ptr noundef nonnull @.str.13, i32 noundef %27) #26, !dbg !879
  call void @exit(i32 noundef 1) #27, !dbg !880
  unreachable, !dbg !880

if.end103:                                        ; preds = %for.body.i, %for.cond.i, %if.end97
  ret void, !dbg !881
}

; Function Attrs: nofree nounwind
declare !dbg !882 noundef i32 @fprintf(ptr nocapture noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #6

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #7

; Function Attrs: nofree nounwind memory(read)
declare !dbg !888 noundef ptr @getenv(ptr nocapture noundef) local_unnamed_addr #8

declare !dbg !892 zeroext i1 @safe_strtoll(ptr noundef, ptr noundef) local_unnamed_addr #9

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @slabs_prefill_global() local_unnamed_addr #5 !dbg !897 {
entry:
  tail call void @llvm.dbg.value(metadata ptr @slabclass, metadata !902, metadata !DIExpression()), !dbg !904
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !903, metadata !DIExpression()), !dbg !904
  %0 = load i64, ptr @mem_limit, align 8, !tbaa !685
  %mem_malloced.promoted = load i64, ptr @mem_malloced, align 8, !tbaa !685
  %cmp17 = icmp ult i64 %mem_malloced.promoted, %0, !dbg !905
  br i1 %cmp17, label %land.rhs.lr.ph, label %while.end, !dbg !906

land.rhs.lr.ph:                                   ; preds = %entry
  %mem_avail.promoted = load i64, ptr @mem_avail, align 8, !tbaa !685
  %mem_current.promoted = load ptr, ptr @mem_current, align 8, !tbaa !421
  %1 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 23), align 4, !dbg !907, !tbaa !797
  tail call void @llvm.dbg.value(metadata i32 %1, metadata !903, metadata !DIExpression()), !dbg !904
  %conv = sext i32 %1 to i64
  %2 = load ptr, ptr @mem_base, align 8, !tbaa !421
  %cmp.i = icmp eq ptr %2, null
  %size.biased.i = add nsw i64 %conv, 7
  %size.addr.0.i = and i64 %size.biased.i, -8
  %.promoted = load i32, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 4), align 1, !tbaa !504
  %.promoted21 = load i32, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 6), align 1, !tbaa !506
  %.promoted24 = load ptr, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 5), align 1, !tbaa !509
  br label %land.rhs, !dbg !906

land.rhs:                                         ; preds = %land.rhs.lr.ph, %grow_slab_list.exit
  %call.i826 = phi ptr [ %.promoted24, %land.rhs.lr.ph ], [ %call.i825, %grow_slab_list.exit ]
  %spec.select.i23 = phi i32 [ %.promoted21, %land.rhs.lr.ph ], [ %spec.select.i22, %grow_slab_list.exit ]
  %3 = phi i32 [ %.promoted, %land.rhs.lr.ph ], [ %inc, %grow_slab_list.exit ]
  %add12.i1220 = phi i64 [ %mem_malloced.promoted, %land.rhs.lr.ph ], [ %add12.i, %grow_slab_list.exit ]
  %add.ptr.i1419 = phi ptr [ %mem_current.promoted, %land.rhs.lr.ph ], [ %add.ptr.i13, %grow_slab_list.exit ]
  %sub8.i1618 = phi i64 [ %mem_avail.promoted, %land.rhs.lr.ph ], [ %sub8.i15, %grow_slab_list.exit ]
  tail call void @llvm.dbg.value(metadata i64 %conv, metadata !908, metadata !DIExpression()), !dbg !914
  br i1 %cmp.i, label %if.then.i, label %if.else.i, !dbg !916

if.then.i:                                        ; preds = %land.rhs
  %call.i = tail call noalias ptr @malloc(i64 noundef %conv) #28, !dbg !917
  tail call void @llvm.dbg.value(metadata ptr %call.i, metadata !913, metadata !DIExpression()), !dbg !914
  br label %memory_allocate.exit, !dbg !920

if.else.i:                                        ; preds = %land.rhs
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i1419, metadata !913, metadata !DIExpression()), !dbg !914
  %cmp1.i = icmp ult i64 %sub8.i1618, %conv, !dbg !921
  br i1 %cmp1.i, label %while.end, label %if.end.i, !dbg !924

if.end.i:                                         ; preds = %if.else.i
  tail call void @llvm.dbg.value(metadata i64 %size.addr.0.i, metadata !908, metadata !DIExpression()), !dbg !914
  %add.ptr.i = getelementptr inbounds i8, ptr %add.ptr.i1419, i64 %size.addr.0.i, !dbg !925
  store ptr %add.ptr.i, ptr @mem_current, align 8, !dbg !926, !tbaa !421
  %cmp6.i = icmp ult i64 %size.addr.0.i, %sub8.i1618, !dbg !927
  br i1 %cmp6.i, label %if.then7.i, label %if.else9.i, !dbg !929

if.then7.i:                                       ; preds = %if.end.i
  %sub8.i = sub i64 %sub8.i1618, %size.addr.0.i, !dbg !930
  store i64 %sub8.i, ptr @mem_avail, align 8, !dbg !930, !tbaa !685
  br label %memory_allocate.exit, !dbg !932

if.else9.i:                                       ; preds = %if.end.i
  store i64 0, ptr @mem_avail, align 8, !dbg !933, !tbaa !685
  br label %memory_allocate.exit

memory_allocate.exit:                             ; preds = %if.then.i, %if.then7.i, %if.else9.i
  %sub8.i15 = phi i64 [ %sub8.i1618, %if.then.i ], [ %sub8.i, %if.then7.i ], [ 0, %if.else9.i ]
  %add.ptr.i13 = phi ptr [ %add.ptr.i1419, %if.then.i ], [ %add.ptr.i, %if.then7.i ], [ %add.ptr.i, %if.else9.i ]
  %size.addr.1.i = phi i64 [ %conv, %if.then.i ], [ %size.addr.0.i, %if.then7.i ], [ %size.addr.0.i, %if.else9.i ]
  %ret.0.i = phi ptr [ %call.i, %if.then.i ], [ %add.ptr.i1419, %if.then7.i ], [ %add.ptr.i1419, %if.else9.i ], !dbg !935
  tail call void @llvm.dbg.value(metadata ptr %ret.0.i, metadata !913, metadata !DIExpression()), !dbg !914
  tail call void @llvm.dbg.value(metadata i64 %size.addr.1.i, metadata !908, metadata !DIExpression()), !dbg !914
  %add12.i = add i64 %size.addr.1.i, %add12.i1220, !dbg !936
  store i64 %add12.i, ptr @mem_malloced, align 8, !dbg !936, !tbaa !685
  tail call void @llvm.dbg.value(metadata ptr %ret.0.i, metadata !901, metadata !DIExpression()), !dbg !904
  %cmp1.not = icmp eq ptr %ret.0.i, null, !dbg !937
  br i1 %cmp1.not, label %while.end, label %while.body, !dbg !938

while.body:                                       ; preds = %memory_allocate.exit
  tail call void @llvm.dbg.value(metadata i32 0, metadata !489, metadata !DIExpression()), !dbg !939
  tail call void @llvm.dbg.value(metadata ptr @slabclass, metadata !495, metadata !DIExpression()), !dbg !939
  %cmp.i6 = icmp eq i32 %3, %spec.select.i23, !dbg !942
  br i1 %cmp.i6, label %if.then.i7, label %grow_slab_list.exit, !dbg !943

if.then.i7:                                       ; preds = %while.body
  %cmp2.not.i = icmp eq i32 %3, 0, !dbg !944
  %mul.i = shl i32 %3, 1
  %spec.select.i = select i1 %cmp2.not.i, i32 16, i32 %mul.i, !dbg !945
  %conv.i = zext i32 %spec.select.i to i64, !dbg !945
  tail call void @llvm.dbg.value(metadata i64 %conv.i, metadata !496, metadata !DIExpression()), !dbg !946
  %mul4.i = shl nuw nsw i64 %conv.i, 3, !dbg !947
  %call.i8 = tail call ptr @realloc(ptr noundef %call.i826, i64 noundef %mul4.i) #22, !dbg !948
  tail call void @llvm.dbg.value(metadata ptr %call.i8, metadata !499, metadata !DIExpression()), !dbg !946
  %cmp5.not.i = icmp eq ptr %call.i8, null, !dbg !949
  br i1 %cmp5.not.i, label %grow_slab_list.exit, label %if.end.i9, !dbg !950

if.end.i9:                                        ; preds = %if.then.i7
  store i32 %spec.select.i, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 6), align 16, !dbg !951, !tbaa !506
  store ptr %call.i8, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 5), align 8, !dbg !952, !tbaa !509
  br label %grow_slab_list.exit

grow_slab_list.exit:                              ; preds = %while.body, %if.then.i7, %if.end.i9
  %call.i825 = phi ptr [ %call.i826, %while.body ], [ %call.i826, %if.then.i7 ], [ %call.i8, %if.end.i9 ]
  %spec.select.i22 = phi i32 [ %spec.select.i23, %while.body ], [ %spec.select.i23, %if.then.i7 ], [ %spec.select.i, %if.end.i9 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(48) %ret.0.i, i8 0, i64 48, i1 false), !dbg !953
  %inc = add i32 %3, 1, !dbg !954
  store i32 %inc, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 4), align 4, !dbg !954, !tbaa !504
  %idxprom = zext i32 %3 to i64, !dbg !955
  %arrayidx = getelementptr inbounds ptr, ptr %call.i825, i64 %idxprom, !dbg !955
  store ptr %ret.0.i, ptr %arrayidx, align 8, !dbg !956, !tbaa !421
  %cmp = icmp ult i64 %add12.i, %0, !dbg !905
  br i1 %cmp, label %land.rhs, label %while.end, !dbg !906, !llvm.loop !957

while.end:                                        ; preds = %memory_allocate.exit, %grow_slab_list.exit, %if.else.i, %entry
  ret void, !dbg !959
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @fill_slab_stats_automove(ptr nocapture noundef writeonly %am) local_unnamed_addr #5 !dbg !960 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %am, metadata !972, metadata !DIExpression()), !dbg !979
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_lock) #23, !dbg !980
  tail call void @llvm.dbg.value(metadata i32 0, metadata !973, metadata !DIExpression()), !dbg !979
  br label %for.body, !dbg !981

for.body:                                         ; preds = %for.body, %entry
  %indvars.iv = phi i64 [ 0, %entry ], [ %indvars.iv.next.1, %for.body ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv, metadata !973, metadata !DIExpression()), !dbg !979
  %arrayidx = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %indvars.iv, !dbg !982
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !974, metadata !DIExpression()), !dbg !983
  %arrayidx2 = getelementptr inbounds %struct.slab_stats_automove, ptr %am, i64 %indvars.iv, !dbg !984
  tail call void @llvm.dbg.value(metadata ptr %arrayidx2, metadata !978, metadata !DIExpression()), !dbg !983
  %sl_curr = getelementptr inbounds i8, ptr %arrayidx, i64 16, !dbg !985
  %free_chunks = getelementptr inbounds i8, ptr %arrayidx2, i64 8, !dbg !986
  %0 = load <2 x i32>, ptr %sl_curr, align 16, !dbg !985, !tbaa !456
  %1 = zext <2 x i32> %0 to <2 x i64>, !dbg !987
  store <2 x i64> %1, ptr %free_chunks, align 8, !dbg !988, !tbaa !685
  %2 = load <2 x i32>, ptr %arrayidx, align 16, !dbg !989, !tbaa !456
  %3 = shufflevector <2 x i32> %2, <2 x i32> poison, <2 x i32> <i32 1, i32 0>, !dbg !990
  store <2 x i32> %3, ptr %arrayidx2, align 8, !dbg !990, !tbaa !456
  %indvars.iv.next = or disjoint i64 %indvars.iv, 1, !dbg !991
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !973, metadata !DIExpression()), !dbg !979
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next, metadata !973, metadata !DIExpression()), !dbg !979
  %arrayidx.1 = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %indvars.iv.next, !dbg !982
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.1, metadata !974, metadata !DIExpression()), !dbg !983
  %arrayidx2.1 = getelementptr inbounds %struct.slab_stats_automove, ptr %am, i64 %indvars.iv.next, !dbg !984
  tail call void @llvm.dbg.value(metadata ptr %arrayidx2.1, metadata !978, metadata !DIExpression()), !dbg !983
  %sl_curr.1 = getelementptr inbounds i8, ptr %arrayidx.1, i64 16, !dbg !985
  %free_chunks.1 = getelementptr inbounds i8, ptr %arrayidx2.1, i64 8, !dbg !986
  %4 = load <2 x i32>, ptr %sl_curr.1, align 8, !dbg !985, !tbaa !456
  %5 = zext <2 x i32> %4 to <2 x i64>, !dbg !987
  store <2 x i64> %5, ptr %free_chunks.1, align 8, !dbg !988, !tbaa !685
  %6 = load <2 x i32>, ptr %arrayidx.1, align 8, !dbg !989, !tbaa !456
  %7 = shufflevector <2 x i32> %6, <2 x i32> poison, <2 x i32> <i32 1, i32 0>, !dbg !990
  store <2 x i32> %7, ptr %arrayidx2.1, align 8, !dbg !990, !tbaa !456
  %indvars.iv.next.1 = add nuw nsw i64 %indvars.iv, 2, !dbg !991
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.1, metadata !973, metadata !DIExpression()), !dbg !979
  %exitcond.not.1 = icmp eq i64 %indvars.iv.next.1, 64, !dbg !992
  br i1 %exitcond.not.1, label %for.end, label %for.body, !dbg !981, !llvm.loop !993

for.end:                                          ; preds = %for.body
  %call4 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !995
  ret void, !dbg !996
}

; Function Attrs: nounwind
declare !dbg !997 i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #10

; Function Attrs: nounwind
declare !dbg !1002 i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #10

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local i32 @global_page_pool_size(ptr noundef writeonly %mem_flag) local_unnamed_addr #5 !dbg !1003 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %mem_flag, metadata !1008, metadata !DIExpression()), !dbg !1010
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1009, metadata !DIExpression()), !dbg !1010
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_lock) #23, !dbg !1011
  %cmp.not = icmp eq ptr %mem_flag, null, !dbg !1012
  br i1 %cmp.not, label %if.end, label %if.then, !dbg !1014

if.then:                                          ; preds = %entry
  %0 = load i64, ptr @mem_malloced, align 8, !dbg !1015, !tbaa !685
  %1 = load i64, ptr @mem_limit, align 8, !dbg !1016, !tbaa !685
  %cmp1 = icmp uge i64 %0, %1, !dbg !1017
  %frombool = zext i1 %cmp1 to i8, !dbg !1018
  store i8 %frombool, ptr %mem_flag, align 1, !dbg !1018, !tbaa !1019
  br label %if.end, !dbg !1020

if.end:                                           ; preds = %if.then, %entry
  %2 = load i32, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 4), align 4, !dbg !1021, !tbaa !504
  tail call void @llvm.dbg.value(metadata i32 %2, metadata !1009, metadata !DIExpression()), !dbg !1010
  %call2 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1022
  ret i32 %2, !dbg !1023
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef ptr @slabs_alloc(i64 noundef %size, i32 noundef %id, i32 noundef %flags) local_unnamed_addr #5 !dbg !1024 {
entry:
  tail call void @llvm.dbg.value(metadata i64 %size, metadata !1028, metadata !DIExpression()), !dbg !1032
  tail call void @llvm.dbg.value(metadata i32 %id, metadata !1029, metadata !DIExpression()), !dbg !1032
  tail call void @llvm.dbg.value(metadata i32 %flags, metadata !1030, metadata !DIExpression()), !dbg !1032
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_lock) #23, !dbg !1033
  tail call void @llvm.dbg.value(metadata i64 %size, metadata !1034, metadata !DIExpression()), !dbg !1044
  tail call void @llvm.dbg.value(metadata i32 %id, metadata !1039, metadata !DIExpression()), !dbg !1044
  tail call void @llvm.dbg.value(metadata i32 %flags, metadata !1040, metadata !DIExpression()), !dbg !1044
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1042, metadata !DIExpression()), !dbg !1044
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1043, metadata !DIExpression()), !dbg !1044
  %cmp.i = icmp eq i32 %id, 0, !dbg !1046
  br i1 %cmp.i, label %do_slabs_alloc.exit, label %lor.lhs.false.i, !dbg !1048

lor.lhs.false.i:                                  ; preds = %entry
  %0 = load i32, ptr @power_largest, align 4, !dbg !1049, !tbaa !456
  %cmp1.i = icmp ult i32 %0, %id, !dbg !1050
  br i1 %cmp1.i, label %do_slabs_alloc.exit, label %if.end.i, !dbg !1051

if.end.i:                                         ; preds = %lor.lhs.false.i
  %idxprom.i = zext i32 %id to i64, !dbg !1052
  %arrayidx.i = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom.i, !dbg !1052
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i, metadata !1041, metadata !DIExpression()), !dbg !1044
  %sl_curr.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 16, !dbg !1053
  %1 = load i32, ptr %sl_curr.i, align 8, !dbg !1053, !tbaa !572
  %cmp2.i = icmp ne i32 %1, 0, !dbg !1055
  %cmp3.not.i = icmp eq i32 %flags, 1
  %or.cond.i = or i1 %cmp3.not.i, %cmp2.i, !dbg !1056
  br i1 %or.cond.i, label %if.end5.i, label %if.then4.i, !dbg !1056

if.then4.i:                                       ; preds = %if.end.i
  %call.i = tail call fastcc i32 @do_slabs_newslab(i32 noundef %id), !dbg !1057
  %.pr.i = load i32, ptr %sl_curr.i, align 8, !dbg !1059, !tbaa !572
  br label %if.end5.i, !dbg !1061

if.end5.i:                                        ; preds = %if.then4.i, %if.end.i
  %2 = phi i32 [ %.pr.i, %if.then4.i ], [ %1, %if.end.i ], !dbg !1059
  %cmp7.not.i = icmp eq i32 %2, 0, !dbg !1062
  br i1 %cmp7.not.i, label %do_slabs_alloc.exit, label %if.then8.i, !dbg !1063

if.then8.i:                                       ; preds = %if.end5.i
  %slots.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 8, !dbg !1064
  %3 = load ptr, ptr %slots.i, align 8, !dbg !1064, !tbaa !561
  tail call void @llvm.dbg.value(metadata ptr %3, metadata !1043, metadata !DIExpression()), !dbg !1044
  %4 = load ptr, ptr %3, align 8, !dbg !1066, !tbaa !421
  store ptr %4, ptr %slots.i, align 8, !dbg !1067, !tbaa !561
  %tobool.not.i = icmp eq ptr %4, null, !dbg !1068
  br i1 %tobool.not.i, label %if.end13.i, label %if.then11.i, !dbg !1070

if.then11.i:                                      ; preds = %if.then8.i
  %prev.i = getelementptr inbounds i8, ptr %4, i64 8, !dbg !1071
  store ptr null, ptr %prev.i, align 8, !dbg !1072, !tbaa !421
  br label %if.end13.i, !dbg !1073

if.end13.i:                                       ; preds = %if.then11.i, %if.then8.i
  %it_flags.i = getelementptr inbounds i8, ptr %3, i64 38, !dbg !1074
  %5 = load i16, ptr %it_flags.i, align 2, !dbg !1075, !tbaa !553
  %6 = and i16 %5, -5, !dbg !1075
  store i16 %6, ptr %it_flags.i, align 2, !dbg !1075, !tbaa !553
  %refcount.i = getelementptr inbounds i8, ptr %3, i64 36, !dbg !1076
  store i16 1, ptr %refcount.i, align 4, !dbg !1077, !tbaa !553
  %dec.i = add i32 %2, -1, !dbg !1078
  store i32 %dec.i, ptr %sl_curr.i, align 8, !dbg !1078, !tbaa !572
  tail call void @llvm.dbg.value(metadata ptr %3, metadata !1042, metadata !DIExpression()), !dbg !1044
  br label %do_slabs_alloc.exit, !dbg !1079

do_slabs_alloc.exit:                              ; preds = %entry, %lor.lhs.false.i, %if.end5.i, %if.end13.i
  %retval.0.i = phi ptr [ null, %lor.lhs.false.i ], [ null, %entry ], [ %3, %if.end13.i ], [ null, %if.end5.i ], !dbg !1044
  tail call void @llvm.dbg.value(metadata ptr %retval.0.i, metadata !1031, metadata !DIExpression()), !dbg !1032
  %call2 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1080
  ret ptr %retval.0.i, !dbg !1081
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @slabs_free(ptr noundef %ptr, i64 noundef %size, i32 noundef %id) local_unnamed_addr #5 !dbg !1082 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1086, metadata !DIExpression()), !dbg !1089
  tail call void @llvm.dbg.value(metadata i64 %size, metadata !1087, metadata !DIExpression()), !dbg !1089
  tail call void @llvm.dbg.value(metadata i32 %id, metadata !1088, metadata !DIExpression()), !dbg !1089
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_lock) #23, !dbg !1090
  tail call fastcc void @do_slabs_free(ptr noundef %ptr, i32 noundef %id), !dbg !1091
  %call1 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1092
  ret void, !dbg !1093
}

; Function Attrs: nofree norecurse nosync nounwind sanitize_thread memory(readwrite, inaccessiblemem: none) uwtable
define internal fastcc void @do_slabs_free(ptr noundef %ptr, i32 noundef %id) unnamed_addr #11 !dbg !1094 {
entry:
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1098, metadata !DIExpression()), !dbg !1103
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !1099, metadata !DIExpression()), !dbg !1103
  tail call void @llvm.dbg.value(metadata i32 %id, metadata !1100, metadata !DIExpression()), !dbg !1103
  %cmp = icmp eq i32 %id, 0, !dbg !1104
  br i1 %cmp, label %cleanup, label %lor.lhs.false, !dbg !1106

lor.lhs.false:                                    ; preds = %entry
  %0 = load i32, ptr @power_largest, align 4, !dbg !1107, !tbaa !456
  %cmp1 = icmp ult i32 %0, %id, !dbg !1108
  br i1 %cmp1, label %cleanup, label %if.end, !dbg !1109

if.end:                                           ; preds = %lor.lhs.false
  %idxprom = zext i32 %id to i64, !dbg !1110
  %arrayidx = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom, !dbg !1110
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !1101, metadata !DIExpression()), !dbg !1103
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1102, metadata !DIExpression()), !dbg !1103
  %it_flags = getelementptr inbounds i8, ptr %ptr, i64 38, !dbg !1111
  %1 = load i16, ptr %it_flags, align 2, !dbg !1111, !tbaa !553
  %2 = and i16 %1, 32, !dbg !1113
  %cmp2 = icmp eq i16 %2, 0, !dbg !1114
  br i1 %cmp2, label %if.then4, label %if.else, !dbg !1115

if.then4:                                         ; preds = %if.end
  store i16 4, ptr %it_flags, align 2, !dbg !1116, !tbaa !553
  %conv6 = trunc i32 %id to i8, !dbg !1118
  %slabs_clsid = getelementptr inbounds i8, ptr %ptr, i64 40, !dbg !1119
  store i8 %conv6, ptr %slabs_clsid, align 8, !dbg !1120, !tbaa !485
  %prev = getelementptr inbounds i8, ptr %ptr, i64 8, !dbg !1121
  store ptr null, ptr %prev, align 8, !dbg !1122, !tbaa !421
  %slots = getelementptr inbounds i8, ptr %arrayidx, i64 8, !dbg !1123
  %3 = load ptr, ptr %slots, align 8, !dbg !1123, !tbaa !561
  store ptr %3, ptr %ptr, align 8, !dbg !1124, !tbaa !421
  %tobool.not = icmp eq ptr %3, null, !dbg !1125
  br i1 %tobool.not, label %if.end11, label %if.then8, !dbg !1127

if.then8:                                         ; preds = %if.then4
  %prev10 = getelementptr inbounds i8, ptr %3, i64 8, !dbg !1128
  store ptr %ptr, ptr %prev10, align 8, !dbg !1129, !tbaa !421
  br label %if.end11, !dbg !1130

if.end11:                                         ; preds = %if.then8, %if.then4
  store ptr %ptr, ptr %slots, align 8, !dbg !1131, !tbaa !561
  %sl_curr = getelementptr inbounds i8, ptr %arrayidx, i64 16, !dbg !1132
  %4 = load i32, ptr %sl_curr, align 8, !dbg !1133, !tbaa !572
  %inc = add i32 %4, 1, !dbg !1133
  store i32 %inc, ptr %sl_curr, align 8, !dbg !1133, !tbaa !572
  br label %cleanup, !dbg !1134

if.else:                                          ; preds = %if.end
  tail call void @llvm.dbg.value(metadata ptr %ptr, metadata !1135, metadata !DIExpression()), !dbg !1144
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !1140, metadata !DIExpression()), !dbg !1144
  %data.i = getelementptr inbounds i8, ptr %ptr, i64 48, !dbg !1147
  %nkey.i = getelementptr inbounds i8, ptr %ptr, i64 41, !dbg !1147
  %5 = load i8, ptr %nkey.i, align 1, !dbg !1147, !tbaa !485
  %idx.ext.i = zext i8 %5 to i64
  %add.ptr.i = getelementptr inbounds i8, ptr %data.i, i64 %idx.ext.i, !dbg !1147
  %add.ptr1.i = getelementptr inbounds i8, ptr %add.ptr.i, i64 1, !dbg !1147
  %conv2.i = zext i16 %1 to i32, !dbg !1147
  %and.i = lshr i32 %conv2.i, 6, !dbg !1147
  %6 = and i32 %and.i, 4, !dbg !1147
  %cond.i = zext nneg i32 %6 to i64, !dbg !1147
  %add.ptr3.i = getelementptr inbounds i8, ptr %add.ptr1.i, i64 %cond.i, !dbg !1147
  %and6.i = shl nuw nsw i32 %conv2.i, 2, !dbg !1147
  %7 = and i32 %and6.i, 8, !dbg !1147
  %cond8.i = zext nneg i32 %7 to i64, !dbg !1147
  %add.ptr9.i = getelementptr inbounds i8, ptr %add.ptr3.i, i64 %cond8.i, !dbg !1147
  tail call void @llvm.dbg.value(metadata ptr %add.ptr9.i, metadata !1141, metadata !DIExpression()), !dbg !1144
  store i16 4, ptr %it_flags, align 2, !dbg !1148, !tbaa !553
  %prev.i = getelementptr inbounds i8, ptr %ptr, i64 8, !dbg !1149
  %orig_clsid.i = getelementptr inbounds i8, ptr %add.ptr9.i, i64 41, !dbg !1150
  %8 = load i8, ptr %orig_clsid.i, align 1, !dbg !1150, !tbaa !485
  %idxprom.i = zext i8 %8 to i64, !dbg !1151
  %arrayidx.i = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom.i, !dbg !1151
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i, metadata !1142, metadata !DIExpression()), !dbg !1144
  %slabs_clsid.i = getelementptr inbounds i8, ptr %ptr, i64 40, !dbg !1152
  store i8 %8, ptr %slabs_clsid.i, align 8, !dbg !1153, !tbaa !485
  %9 = load ptr, ptr %add.ptr9.i, align 8, !dbg !1154, !tbaa !421
  %tobool12.not.i = icmp eq ptr %9, null, !dbg !1156
  br i1 %tobool12.not.i, label %if.end.i, label %if.then.i, !dbg !1157

if.then.i:                                        ; preds = %if.else
  tail call void @llvm.dbg.value(metadata ptr %9, metadata !1141, metadata !DIExpression()), !dbg !1144
  %prev14.i = getelementptr inbounds i8, ptr %9, i64 8, !dbg !1158
  store ptr null, ptr %prev14.i, align 8, !dbg !1160, !tbaa !421
  br label %if.end.i, !dbg !1161

if.end.i:                                         ; preds = %if.then.i, %if.else
  tail call void @llvm.dbg.value(metadata ptr %9, metadata !1141, metadata !DIExpression()), !dbg !1144
  store ptr null, ptr %prev.i, align 8, !dbg !1162, !tbaa !421
  %slots.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 8, !dbg !1163
  %10 = load ptr, ptr %slots.i, align 8, !dbg !1163, !tbaa !561
  store ptr %10, ptr %ptr, align 8, !dbg !1164, !tbaa !421
  %tobool18.not.i = icmp eq ptr %10, null, !dbg !1165
  br i1 %tobool18.not.i, label %if.end22.i, label %if.then19.i, !dbg !1167

if.then19.i:                                      ; preds = %if.end.i
  %prev21.i = getelementptr inbounds i8, ptr %10, i64 8, !dbg !1168
  store ptr %ptr, ptr %prev21.i, align 8, !dbg !1169, !tbaa !421
  br label %if.end22.i, !dbg !1170

if.end22.i:                                       ; preds = %if.then19.i, %if.end.i
  store ptr %ptr, ptr %slots.i, align 8, !dbg !1171, !tbaa !561
  %sl_curr.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 16, !dbg !1172
  %11 = load i32, ptr %sl_curr.i, align 8, !dbg !1173, !tbaa !572
  %inc.i = add i32 %11, 1, !dbg !1173
  store i32 %inc.i, ptr %sl_curr.i, align 8, !dbg !1173, !tbaa !572
  tail call void @llvm.dbg.value(metadata ptr %9, metadata !1141, metadata !DIExpression()), !dbg !1144
  br i1 %tobool12.not.i, label %cleanup, label %while.body.i, !dbg !1174

while.body.i:                                     ; preds = %if.end22.i, %if.end38.i
  %chunk.176.i = phi ptr [ %13, %if.end38.i ], [ %9, %if.end22.i ]
  tail call void @llvm.dbg.value(metadata ptr %chunk.176.i, metadata !1141, metadata !DIExpression()), !dbg !1144
  %it_flags25.i = getelementptr inbounds i8, ptr %chunk.176.i, i64 38, !dbg !1175
  store i16 4, ptr %it_flags25.i, align 2, !dbg !1177, !tbaa !553
  %slabs_clsid26.i = getelementptr inbounds i8, ptr %chunk.176.i, i64 40, !dbg !1178
  %12 = load i8, ptr %slabs_clsid26.i, align 8, !dbg !1178, !tbaa !485
  %idxprom27.i = zext i8 %12 to i64, !dbg !1179
  %arrayidx28.i = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom27.i, !dbg !1179
  tail call void @llvm.dbg.value(metadata ptr %arrayidx28.i, metadata !1142, metadata !DIExpression()), !dbg !1144
  %13 = load ptr, ptr %chunk.176.i, align 8, !dbg !1180, !tbaa !421
  tail call void @llvm.dbg.value(metadata ptr %13, metadata !1143, metadata !DIExpression()), !dbg !1144
  %prev30.i = getelementptr inbounds i8, ptr %chunk.176.i, i64 8, !dbg !1181
  store ptr null, ptr %prev30.i, align 8, !dbg !1182, !tbaa !421
  %slots31.i = getelementptr inbounds i8, ptr %arrayidx28.i, i64 8, !dbg !1183
  %14 = load ptr, ptr %slots31.i, align 8, !dbg !1183, !tbaa !561
  store ptr %14, ptr %chunk.176.i, align 8, !dbg !1184, !tbaa !421
  %tobool34.not.i = icmp eq ptr %14, null, !dbg !1185
  br i1 %tobool34.not.i, label %if.end38.i, label %if.then35.i, !dbg !1187

if.then35.i:                                      ; preds = %while.body.i
  %prev37.i = getelementptr inbounds i8, ptr %14, i64 8, !dbg !1188
  store ptr %chunk.176.i, ptr %prev37.i, align 8, !dbg !1189, !tbaa !421
  br label %if.end38.i, !dbg !1190

if.end38.i:                                       ; preds = %if.then35.i, %while.body.i
  store ptr %chunk.176.i, ptr %slots31.i, align 8, !dbg !1191, !tbaa !561
  %sl_curr40.i = getelementptr inbounds i8, ptr %arrayidx28.i, i64 16, !dbg !1192
  %15 = load i32, ptr %sl_curr40.i, align 8, !dbg !1193, !tbaa !572
  %inc41.i = add i32 %15, 1, !dbg !1193
  store i32 %inc41.i, ptr %sl_curr40.i, align 8, !dbg !1193, !tbaa !572
  tail call void @llvm.dbg.value(metadata ptr %13, metadata !1141, metadata !DIExpression()), !dbg !1144
  %tobool24.not.i = icmp eq ptr %13, null, !dbg !1174
  br i1 %tobool24.not.i, label %cleanup, label %while.body.i, !dbg !1174, !llvm.loop !1194

cleanup:                                          ; preds = %if.end38.i, %if.end22.i, %if.end11, %entry, %lor.lhs.false
  ret void, !dbg !1196
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @slabs_stats(ptr noundef %add_stats, ptr noundef %c) local_unnamed_addr #5 !dbg !1197 {
entry:
  %thread_stats.i = alloca %struct.thread_stats, align 8, !DIAssignID !1210
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1211, metadata !DIExpression(), metadata !1210, metadata ptr %thread_stats.i, metadata !DIExpression()), !dbg !1285
  %key_str.i = alloca [128 x i8], align 16, !DIAssignID !1287
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1226, metadata !DIExpression(), metadata !1287, metadata ptr %key_str.i, metadata !DIExpression()), !dbg !1288
  %val_str.i = alloca [128 x i8], align 16, !DIAssignID !1289
  tail call void @llvm.dbg.value(metadata ptr %add_stats, metadata !1208, metadata !DIExpression()), !dbg !1290
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1209, metadata !DIExpression()), !dbg !1290
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_lock) #23, !dbg !1291
  tail call void @llvm.dbg.assign(metadata i1 undef, metadata !1230, metadata !DIExpression(), metadata !1289, metadata ptr %val_str.i, metadata !DIExpression()), !dbg !1288
  tail call void @llvm.dbg.value(metadata ptr %add_stats, metadata !1214, metadata !DIExpression()), !dbg !1285
  tail call void @llvm.dbg.value(metadata ptr %c, metadata !1215, metadata !DIExpression()), !dbg !1285
  call void @llvm.lifetime.start.p0(i64 6448, ptr nonnull %thread_stats.i) #23, !dbg !1292
  call void @threadlocal_stats_aggregate(ptr noundef nonnull %thread_stats.i) #23, !dbg !1293
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1217, metadata !DIExpression()), !dbg !1285
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1216, metadata !DIExpression()), !dbg !1285
  %0 = load i32, ptr @power_largest, align 4, !dbg !1294, !tbaa !456
  %cmp.not230.i = icmp slt i32 %0, 1, !dbg !1295
  br i1 %cmp.not230.i, label %do_slabs_stats.exit, label %for.body.lr.ph.i, !dbg !1296

for.body.lr.ph.i:                                 ; preds = %entry
  %slab_stats.i = getelementptr inbounds i8, ptr %thread_stats.i, i64 280
  br label %for.body.i, !dbg !1296

for.body.i:                                       ; preds = %if.end.i, %for.body.lr.ph.i
  %1 = phi i32 [ %0, %for.body.lr.ph.i ], [ %16, %if.end.i ]
  %indvars.iv.i = phi i64 [ 1, %for.body.lr.ph.i ], [ %indvars.iv.next.i, %if.end.i ]
  %total.0231.i = phi i32 [ 0, %for.body.lr.ph.i ], [ %total.1.i, %if.end.i ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i, metadata !1216, metadata !DIExpression()), !dbg !1285
  tail call void @llvm.dbg.value(metadata i32 %total.0231.i, metadata !1217, metadata !DIExpression()), !dbg !1285
  %arrayidx.i = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %indvars.iv.i, !dbg !1297
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i, metadata !1218, metadata !DIExpression()), !dbg !1298
  %slabs.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 20, !dbg !1299
  %2 = load i32, ptr %slabs.i, align 4, !dbg !1299, !tbaa !504
  %cmp1.not.i = icmp eq i32 %2, 0, !dbg !1300
  br i1 %cmp1.not.i, label %if.end.i, label %if.then.i, !dbg !1301

if.then.i:                                        ; preds = %for.body.i
  tail call void @llvm.dbg.value(metadata i32 %2, metadata !1225, metadata !DIExpression()), !dbg !1288
  %perslab4.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 4, !dbg !1302
  %3 = load i32, ptr %perslab4.i, align 4, !dbg !1302, !tbaa !801
  tail call void @llvm.dbg.value(metadata i32 %3, metadata !1222, metadata !DIExpression()), !dbg !1288
  call void @llvm.lifetime.start.p0(i64 128, ptr nonnull %key_str.i) #23, !dbg !1303
  call void @llvm.lifetime.start.p0(i64 128, ptr nonnull %val_str.i) #23, !dbg !1304
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1231, metadata !DIExpression()), !dbg !1288
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1232, metadata !DIExpression()), !dbg !1288
  %4 = trunc nuw nsw i64 %indvars.iv.i to i32, !dbg !1305
  %call.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str.i, i64 noundef 128, ptr noundef nonnull @.str.14, i32 noundef %4, ptr noundef nonnull @.str.15) #23, !dbg !1305
  tail call void @llvm.dbg.value(metadata i32 %call.i, metadata !1231, metadata !DIExpression()), !dbg !1288
  %5 = load i32, ptr %arrayidx.i, align 8, !dbg !1305, !tbaa !449
  %call6.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str.i, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %5) #23, !dbg !1305
  tail call void @llvm.dbg.value(metadata i32 %call6.i, metadata !1232, metadata !DIExpression()), !dbg !1288
  %conv.i = trunc i32 %call.i to i16, !dbg !1305
  call void %add_stats(ptr noundef nonnull %key_str.i, i16 noundef zeroext %conv.i, ptr noundef nonnull %val_str.i, i32 noundef %call6.i, ptr noundef %c) #23, !dbg !1305
  %call10.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str.i, i64 noundef 128, ptr noundef nonnull @.str.14, i32 noundef %4, ptr noundef nonnull @.str.17) #23, !dbg !1306
  tail call void @llvm.dbg.value(metadata i32 %call10.i, metadata !1231, metadata !DIExpression()), !dbg !1288
  %call12.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str.i, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %3) #23, !dbg !1306
  tail call void @llvm.dbg.value(metadata i32 %call12.i, metadata !1232, metadata !DIExpression()), !dbg !1288
  %conv14.i = trunc i32 %call10.i to i16, !dbg !1306
  call void %add_stats(ptr noundef nonnull %key_str.i, i16 noundef zeroext %conv14.i, ptr noundef nonnull %val_str.i, i32 noundef %call12.i, ptr noundef %c) #23, !dbg !1306
  %call17.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str.i, i64 noundef 128, ptr noundef nonnull @.str.14, i32 noundef %4, ptr noundef nonnull @.str.18) #23, !dbg !1307
  tail call void @llvm.dbg.value(metadata i32 %call17.i, metadata !1231, metadata !DIExpression()), !dbg !1288
  %call19.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str.i, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %2) #23, !dbg !1307
  tail call void @llvm.dbg.value(metadata i32 %call19.i, metadata !1232, metadata !DIExpression()), !dbg !1288
  %conv21.i = trunc i32 %call17.i to i16, !dbg !1307
  call void %add_stats(ptr noundef nonnull %key_str.i, i16 noundef zeroext %conv21.i, ptr noundef nonnull %val_str.i, i32 noundef %call19.i, ptr noundef %c) #23, !dbg !1307
  %call24.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str.i, i64 noundef 128, ptr noundef nonnull @.str.14, i32 noundef %4, ptr noundef nonnull @.str.19) #23, !dbg !1308
  tail call void @llvm.dbg.value(metadata i32 %call24.i, metadata !1231, metadata !DIExpression()), !dbg !1288
  %mul.i = mul i32 %3, %2, !dbg !1308
  %call26.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str.i, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %mul.i) #23, !dbg !1308
  tail call void @llvm.dbg.value(metadata i32 %call26.i, metadata !1232, metadata !DIExpression()), !dbg !1288
  %conv28.i = trunc i32 %call24.i to i16, !dbg !1308
  call void %add_stats(ptr noundef nonnull %key_str.i, i16 noundef zeroext %conv28.i, ptr noundef nonnull %val_str.i, i32 noundef %call26.i, ptr noundef %c) #23, !dbg !1308
  %call31.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str.i, i64 noundef 128, ptr noundef nonnull @.str.14, i32 noundef %4, ptr noundef nonnull @.str.20) #23, !dbg !1309
  tail call void @llvm.dbg.value(metadata i32 %call31.i, metadata !1231, metadata !DIExpression()), !dbg !1288
  %sl_curr.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 16, !dbg !1309
  %6 = load i32, ptr %sl_curr.i, align 8, !dbg !1309, !tbaa !572
  %sub.i = sub i32 %mul.i, %6, !dbg !1309
  %call34.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str.i, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %sub.i) #23, !dbg !1309
  tail call void @llvm.dbg.value(metadata i32 %call34.i, metadata !1232, metadata !DIExpression()), !dbg !1288
  %conv36.i = trunc i32 %call31.i to i16, !dbg !1309
  call void %add_stats(ptr noundef nonnull %key_str.i, i16 noundef zeroext %conv36.i, ptr noundef nonnull %val_str.i, i32 noundef %call34.i, ptr noundef %c) #23, !dbg !1309
  %call39.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str.i, i64 noundef 128, ptr noundef nonnull @.str.14, i32 noundef %4, ptr noundef nonnull @.str.21) #23, !dbg !1310
  tail call void @llvm.dbg.value(metadata i32 %call39.i, metadata !1231, metadata !DIExpression()), !dbg !1288
  %7 = load i32, ptr %sl_curr.i, align 8, !dbg !1310, !tbaa !572
  %call42.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str.i, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef %7) #23, !dbg !1310
  tail call void @llvm.dbg.value(metadata i32 %call42.i, metadata !1232, metadata !DIExpression()), !dbg !1288
  %conv44.i = trunc i32 %call39.i to i16, !dbg !1310
  call void %add_stats(ptr noundef nonnull %key_str.i, i16 noundef zeroext %conv44.i, ptr noundef nonnull %val_str.i, i32 noundef %call42.i, ptr noundef %c) #23, !dbg !1310
  %call47.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str.i, i64 noundef 128, ptr noundef nonnull @.str.14, i32 noundef %4, ptr noundef nonnull @.str.22) #23, !dbg !1311
  tail call void @llvm.dbg.value(metadata i32 %call47.i, metadata !1231, metadata !DIExpression()), !dbg !1288
  %call49.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str.i, i64 noundef 128, ptr noundef nonnull @.str.16, i32 noundef 0) #23, !dbg !1311
  tail call void @llvm.dbg.value(metadata i32 %call49.i, metadata !1232, metadata !DIExpression()), !dbg !1288
  %conv51.i = trunc i32 %call47.i to i16, !dbg !1311
  call void %add_stats(ptr noundef nonnull %key_str.i, i16 noundef zeroext %conv51.i, ptr noundef nonnull %val_str.i, i32 noundef %call49.i, ptr noundef %c) #23, !dbg !1311
  %call54.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str.i, i64 noundef 128, ptr noundef nonnull @.str.14, i32 noundef %4, ptr noundef nonnull @.str.23) #23, !dbg !1312
  tail call void @llvm.dbg.value(metadata i32 %call54.i, metadata !1231, metadata !DIExpression()), !dbg !1288
  %arrayidx57.i = getelementptr inbounds [64 x %struct.slab_stats], ptr %slab_stats.i, i64 0, i64 %indvars.iv.i, !dbg !1312
  %get_hits.i = getelementptr inbounds i8, ptr %arrayidx57.i, i64 8, !dbg !1312
  %8 = load i64, ptr %get_hits.i, align 8, !dbg !1312, !tbaa !1313
  %call58.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str.i, i64 noundef 128, ptr noundef nonnull @.str.24, i64 noundef %8) #23, !dbg !1312
  tail call void @llvm.dbg.value(metadata i32 %call58.i, metadata !1232, metadata !DIExpression()), !dbg !1288
  %conv60.i = trunc i32 %call54.i to i16, !dbg !1312
  call void %add_stats(ptr noundef nonnull %key_str.i, i16 noundef zeroext %conv60.i, ptr noundef nonnull %val_str.i, i32 noundef %call58.i, ptr noundef %c) #23, !dbg !1312
  %call63.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str.i, i64 noundef 128, ptr noundef nonnull @.str.14, i32 noundef %4, ptr noundef nonnull @.str.25) #23, !dbg !1315
  tail call void @llvm.dbg.value(metadata i32 %call63.i, metadata !1231, metadata !DIExpression()), !dbg !1288
  %9 = load i64, ptr %arrayidx57.i, align 8, !dbg !1315, !tbaa !1316
  %call68.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str.i, i64 noundef 128, ptr noundef nonnull @.str.24, i64 noundef %9) #23, !dbg !1315
  tail call void @llvm.dbg.value(metadata i32 %call68.i, metadata !1232, metadata !DIExpression()), !dbg !1288
  %conv70.i = trunc i32 %call63.i to i16, !dbg !1315
  call void %add_stats(ptr noundef nonnull %key_str.i, i16 noundef zeroext %conv70.i, ptr noundef nonnull %val_str.i, i32 noundef %call68.i, ptr noundef %c) #23, !dbg !1315
  %call73.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str.i, i64 noundef 128, ptr noundef nonnull @.str.14, i32 noundef %4, ptr noundef nonnull @.str.26) #23, !dbg !1317
  tail call void @llvm.dbg.value(metadata i32 %call73.i, metadata !1231, metadata !DIExpression()), !dbg !1288
  %delete_hits.i = getelementptr inbounds i8, ptr %arrayidx57.i, i64 24, !dbg !1317
  %10 = load i64, ptr %delete_hits.i, align 8, !dbg !1317, !tbaa !1318
  %call78.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str.i, i64 noundef 128, ptr noundef nonnull @.str.24, i64 noundef %10) #23, !dbg !1317
  tail call void @llvm.dbg.value(metadata i32 %call78.i, metadata !1232, metadata !DIExpression()), !dbg !1288
  %conv80.i = trunc i32 %call73.i to i16, !dbg !1317
  call void %add_stats(ptr noundef nonnull %key_str.i, i16 noundef zeroext %conv80.i, ptr noundef nonnull %val_str.i, i32 noundef %call78.i, ptr noundef %c) #23, !dbg !1317
  %call83.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str.i, i64 noundef 128, ptr noundef nonnull @.str.14, i32 noundef %4, ptr noundef nonnull @.str.27) #23, !dbg !1319
  tail call void @llvm.dbg.value(metadata i32 %call83.i, metadata !1231, metadata !DIExpression()), !dbg !1288
  %incr_hits.i = getelementptr inbounds i8, ptr %arrayidx57.i, i64 48, !dbg !1319
  %11 = load i64, ptr %incr_hits.i, align 8, !dbg !1319, !tbaa !1320
  %call88.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str.i, i64 noundef 128, ptr noundef nonnull @.str.24, i64 noundef %11) #23, !dbg !1319
  tail call void @llvm.dbg.value(metadata i32 %call88.i, metadata !1232, metadata !DIExpression()), !dbg !1288
  %conv90.i = trunc i32 %call83.i to i16, !dbg !1319
  call void %add_stats(ptr noundef nonnull %key_str.i, i16 noundef zeroext %conv90.i, ptr noundef nonnull %val_str.i, i32 noundef %call88.i, ptr noundef %c) #23, !dbg !1319
  %call93.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str.i, i64 noundef 128, ptr noundef nonnull @.str.14, i32 noundef %4, ptr noundef nonnull @.str.28) #23, !dbg !1321
  tail call void @llvm.dbg.value(metadata i32 %call93.i, metadata !1231, metadata !DIExpression()), !dbg !1288
  %decr_hits.i = getelementptr inbounds i8, ptr %arrayidx57.i, i64 56, !dbg !1321
  %12 = load i64, ptr %decr_hits.i, align 8, !dbg !1321, !tbaa !1322
  %call98.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str.i, i64 noundef 128, ptr noundef nonnull @.str.24, i64 noundef %12) #23, !dbg !1321
  tail call void @llvm.dbg.value(metadata i32 %call98.i, metadata !1232, metadata !DIExpression()), !dbg !1288
  %conv100.i = trunc i32 %call93.i to i16, !dbg !1321
  call void %add_stats(ptr noundef nonnull %key_str.i, i16 noundef zeroext %conv100.i, ptr noundef nonnull %val_str.i, i32 noundef %call98.i, ptr noundef %c) #23, !dbg !1321
  %call103.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str.i, i64 noundef 128, ptr noundef nonnull @.str.14, i32 noundef %4, ptr noundef nonnull @.str.29) #23, !dbg !1323
  tail call void @llvm.dbg.value(metadata i32 %call103.i, metadata !1231, metadata !DIExpression()), !dbg !1288
  %cas_hits.i = getelementptr inbounds i8, ptr %arrayidx57.i, i64 32, !dbg !1323
  %13 = load i64, ptr %cas_hits.i, align 8, !dbg !1323, !tbaa !1324
  %call108.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str.i, i64 noundef 128, ptr noundef nonnull @.str.24, i64 noundef %13) #23, !dbg !1323
  tail call void @llvm.dbg.value(metadata i32 %call108.i, metadata !1232, metadata !DIExpression()), !dbg !1288
  %conv110.i = trunc i32 %call103.i to i16, !dbg !1323
  call void %add_stats(ptr noundef nonnull %key_str.i, i16 noundef zeroext %conv110.i, ptr noundef nonnull %val_str.i, i32 noundef %call108.i, ptr noundef %c) #23, !dbg !1323
  %call113.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str.i, i64 noundef 128, ptr noundef nonnull @.str.14, i32 noundef %4, ptr noundef nonnull @.str.30) #23, !dbg !1325
  tail call void @llvm.dbg.value(metadata i32 %call113.i, metadata !1231, metadata !DIExpression()), !dbg !1288
  %cas_badval.i = getelementptr inbounds i8, ptr %arrayidx57.i, i64 40, !dbg !1325
  %14 = load i64, ptr %cas_badval.i, align 8, !dbg !1325, !tbaa !1326
  %call118.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str.i, i64 noundef 128, ptr noundef nonnull @.str.24, i64 noundef %14) #23, !dbg !1325
  tail call void @llvm.dbg.value(metadata i32 %call118.i, metadata !1232, metadata !DIExpression()), !dbg !1288
  %conv120.i = trunc i32 %call113.i to i16, !dbg !1325
  call void %add_stats(ptr noundef nonnull %key_str.i, i16 noundef zeroext %conv120.i, ptr noundef nonnull %val_str.i, i32 noundef %call118.i, ptr noundef %c) #23, !dbg !1325
  %call123.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %key_str.i, i64 noundef 128, ptr noundef nonnull @.str.14, i32 noundef %4, ptr noundef nonnull @.str.31) #23, !dbg !1327
  tail call void @llvm.dbg.value(metadata i32 %call123.i, metadata !1231, metadata !DIExpression()), !dbg !1288
  %touch_hits.i = getelementptr inbounds i8, ptr %arrayidx57.i, i64 16, !dbg !1327
  %15 = load i64, ptr %touch_hits.i, align 8, !dbg !1327, !tbaa !1328
  %call128.i = call i32 (ptr, i64, ptr, ...) @snprintf(ptr noundef nonnull dereferenceable(1) %val_str.i, i64 noundef 128, ptr noundef nonnull @.str.24, i64 noundef %15) #23, !dbg !1327
  tail call void @llvm.dbg.value(metadata i32 %call128.i, metadata !1232, metadata !DIExpression()), !dbg !1288
  %conv130.i = trunc i32 %call123.i to i16, !dbg !1327
  call void %add_stats(ptr noundef nonnull %key_str.i, i16 noundef zeroext %conv130.i, ptr noundef nonnull %val_str.i, i32 noundef %call128.i, ptr noundef %c) #23, !dbg !1327
  %inc.i = add nsw i32 %total.0231.i, 1, !dbg !1329
  tail call void @llvm.dbg.value(metadata i32 %inc.i, metadata !1217, metadata !DIExpression()), !dbg !1285
  call void @llvm.lifetime.end.p0(i64 128, ptr nonnull %val_str.i) #23, !dbg !1330
  call void @llvm.lifetime.end.p0(i64 128, ptr nonnull %key_str.i) #23, !dbg !1330
  %.pre.i = load i32, ptr @power_largest, align 4, !dbg !1294, !tbaa !456
  br label %if.end.i, !dbg !1331

if.end.i:                                         ; preds = %if.then.i, %for.body.i
  %16 = phi i32 [ %.pre.i, %if.then.i ], [ %1, %for.body.i ], !dbg !1294
  %total.1.i = phi i32 [ %inc.i, %if.then.i ], [ %total.0231.i, %for.body.i ], !dbg !1285
  tail call void @llvm.dbg.value(metadata i32 %total.1.i, metadata !1217, metadata !DIExpression()), !dbg !1285
  %indvars.iv.next.i = add nuw nsw i64 %indvars.iv.i, 1, !dbg !1332
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !1216, metadata !DIExpression()), !dbg !1285
  %17 = sext i32 %16 to i64, !dbg !1295
  %cmp.not.not.i = icmp slt i64 %indvars.iv.i, %17, !dbg !1295
  br i1 %cmp.not.not.i, label %for.body.i, label %do_slabs_stats.exit, !dbg !1296, !llvm.loop !1333

do_slabs_stats.exit:                              ; preds = %if.end.i, %entry
  %total.0.lcssa.i = phi i32 [ 0, %entry ], [ %total.1.i, %if.end.i ], !dbg !1285
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.32, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.33, i32 noundef %total.0.lcssa.i) #23, !dbg !1335
  %18 = load i64, ptr @mem_malloced, align 8, !dbg !1336, !tbaa !685
  call void (ptr, ptr, ptr, ptr, ...) @append_stat(ptr noundef nonnull @.str.34, ptr noundef %add_stats, ptr noundef %c, ptr noundef nonnull @.str.24, i64 noundef %18) #23, !dbg !1336
  call void %add_stats(ptr noundef null, i16 noundef zeroext 0, ptr noundef null, i32 noundef 0, ptr noundef %c) #23, !dbg !1337
  call void @llvm.lifetime.end.p0(i64 6448, ptr nonnull %thread_stats.i) #23, !dbg !1338
  %call1 = call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1339
  ret void, !dbg !1340
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local noundef zeroext i1 @slabs_adjust_mem_limit(i64 noundef %new_mem_limit) local_unnamed_addr #5 !dbg !1341 {
entry:
  tail call void @llvm.dbg.value(metadata i64 %new_mem_limit, metadata !1345, metadata !DIExpression()), !dbg !1347
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_lock) #23, !dbg !1348
  tail call void @llvm.dbg.value(metadata i64 %new_mem_limit, metadata !1349, metadata !DIExpression()), !dbg !1352
  %0 = load ptr, ptr @mem_base, align 8, !dbg !1354, !tbaa !421
  %cmp.not.i = icmp eq ptr %0, null, !dbg !1356
  br i1 %cmp.not.i, label %if.end.i.i, label %do_slabs_adjust_mem_limit.exit, !dbg !1357

if.end.i.i:                                       ; preds = %entry
  store i64 %new_mem_limit, ptr @settings, align 8, !dbg !1358, !tbaa !1359
  store i64 %new_mem_limit, ptr @mem_limit, align 8, !dbg !1360, !tbaa !685
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1361, metadata !DIExpression()), !dbg !1364
  %1 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 30), align 1, !dbg !1366, !tbaa !1368, !range !1369, !noundef !1370
  %tobool.i.i = trunc nuw i8 %1 to i1, !dbg !1366
  br i1 %tobool.i.i, label %while.cond.preheader.i.i, label %do_slabs_adjust_mem_limit.exit, !dbg !1371

while.cond.preheader.i.i:                         ; preds = %if.end.i.i
  %mem_malloced.promoted.i.i = load i64, ptr @mem_malloced, align 8, !tbaa !685
  %cmp38.i.i = icmp ugt i64 %mem_malloced.promoted.i.i, %new_mem_limit, !dbg !1372
  br i1 %cmp38.i.i, label %land.rhs.i.i.preheader, label %do_slabs_adjust_mem_limit.exit, !dbg !1373

land.rhs.i.i.preheader:                           ; preds = %while.cond.preheader.i.i
  %.promoted = load i32, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 4), align 4, !tbaa !504
  br label %land.rhs.i.i, !dbg !1374

land.rhs.i.i:                                     ; preds = %land.rhs.i.i.preheader, %while.body.i.i
  %sub.i.i.i3 = phi i32 [ %sub.i.i.i, %while.body.i.i ], [ %.promoted, %land.rhs.i.i.preheader ]
  %sub79.i.i = phi i64 [ %sub.i.i, %while.body.i.i ], [ %mem_malloced.promoted.i.i, %land.rhs.i.i.preheader ]
  tail call void @llvm.dbg.value(metadata ptr @slabclass, metadata !1375, metadata !DIExpression()), !dbg !1381
  %cmp.i.i.i = icmp eq i32 %sub.i.i.i3, 0, !dbg !1383
  br i1 %cmp.i.i.i, label %do_slabs_adjust_mem_limit.exit, label %get_page_from_global_pool.exit.i.i, !dbg !1385

get_page_from_global_pool.exit.i.i:               ; preds = %land.rhs.i.i
  %2 = load ptr, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 5), align 8, !dbg !1386, !tbaa !509
  %sub.i.i.i = add i32 %sub.i.i.i3, -1, !dbg !1387
  %idxprom.i.i.i = zext i32 %sub.i.i.i to i64, !dbg !1388
  %arrayidx.i.i.i = getelementptr inbounds ptr, ptr %2, i64 %idxprom.i.i.i, !dbg !1388
  %3 = load ptr, ptr %arrayidx.i.i.i, align 8, !dbg !1388, !tbaa !421
  tail call void @llvm.dbg.value(metadata ptr %3, metadata !1380, metadata !DIExpression()), !dbg !1381
  store i32 %sub.i.i.i, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 4), align 4, !dbg !1389, !tbaa !504
  tail call void @llvm.dbg.value(metadata ptr %3, metadata !1361, metadata !DIExpression()), !dbg !1364
  %cmp4.not.i.i = icmp eq ptr %3, null, !dbg !1390
  br i1 %cmp4.not.i.i, label %do_slabs_adjust_mem_limit.exit, label %while.body.i.i, !dbg !1374

while.body.i.i:                                   ; preds = %get_page_from_global_pool.exit.i.i
  tail call void @free(ptr noundef nonnull %3) #23, !dbg !1391
  %4 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 23), align 4, !dbg !1393, !tbaa !797
  %conv.i.i = sext i32 %4 to i64, !dbg !1394
  %sub.i.i = sub i64 %sub79.i.i, %conv.i.i, !dbg !1395
  store i64 %sub.i.i, ptr @mem_malloced, align 8, !dbg !1395, !tbaa !685
  %cmp3.i.i = icmp ugt i64 %sub.i.i, %new_mem_limit, !dbg !1372
  br i1 %cmp3.i.i, label %land.rhs.i.i, label %do_slabs_adjust_mem_limit.exit, !dbg !1373, !llvm.loop !1396

do_slabs_adjust_mem_limit.exit:                   ; preds = %land.rhs.i.i, %get_page_from_global_pool.exit.i.i, %while.body.i.i, %entry, %if.end.i.i, %while.cond.preheader.i.i
  tail call void @llvm.dbg.value(metadata i1 %cmp.not.i, metadata !1346, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1347
  %call2 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1398
  ret i1 %cmp.not.i, !dbg !1399
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local i32 @slabs_available_chunks(i32 noundef %id, ptr noundef writeonly %mem_flag, ptr noundef writeonly %chunks_perslab) local_unnamed_addr #5 !dbg !1400 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %id, metadata !1405, metadata !DIExpression()), !dbg !1410
  tail call void @llvm.dbg.value(metadata ptr %mem_flag, metadata !1406, metadata !DIExpression()), !dbg !1410
  tail call void @llvm.dbg.value(metadata ptr %chunks_perslab, metadata !1407, metadata !DIExpression()), !dbg !1410
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_lock) #23, !dbg !1411
  %idxprom = zext i32 %id to i64, !dbg !1412
  %arrayidx = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom, !dbg !1412
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !1409, metadata !DIExpression()), !dbg !1410
  %sl_curr = getelementptr inbounds i8, ptr %arrayidx, i64 16, !dbg !1413
  %0 = load i32, ptr %sl_curr, align 8, !dbg !1413, !tbaa !572
  tail call void @llvm.dbg.value(metadata i32 %0, metadata !1408, metadata !DIExpression()), !dbg !1410
  %cmp.not = icmp eq ptr %mem_flag, null, !dbg !1414
  br i1 %cmp.not, label %if.end, label %if.then, !dbg !1416

if.then:                                          ; preds = %entry
  %1 = load i64, ptr @mem_malloced, align 8, !dbg !1417, !tbaa !685
  %2 = load i64, ptr @mem_limit, align 8, !dbg !1418, !tbaa !685
  %cmp1 = icmp uge i64 %1, %2, !dbg !1419
  %frombool = zext i1 %cmp1 to i8, !dbg !1420
  store i8 %frombool, ptr %mem_flag, align 1, !dbg !1420, !tbaa !1019
  br label %if.end, !dbg !1421

if.end:                                           ; preds = %if.then, %entry
  %cmp2.not = icmp eq ptr %chunks_perslab, null, !dbg !1422
  br i1 %cmp2.not, label %if.end4, label %if.then3, !dbg !1424

if.then3:                                         ; preds = %if.end
  %perslab = getelementptr inbounds i8, ptr %arrayidx, i64 4, !dbg !1425
  %3 = load i32, ptr %perslab, align 4, !dbg !1425, !tbaa !801
  store i32 %3, ptr %chunks_perslab, align 4, !dbg !1426, !tbaa !456
  br label %if.end4, !dbg !1427

if.end4:                                          ; preds = %if.then3, %if.end
  %call5 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1428
  ret i32 %0, !dbg !1429
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @slabs_mlock() local_unnamed_addr #5 !dbg !1430 {
entry:
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_lock) #23, !dbg !1431
  ret void, !dbg !1432
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @slabs_munlock() local_unnamed_addr #5 !dbg !1433 {
entry:
  %call = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1434
  ret void, !dbg !1435
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 0, 5) i32 @slabs_reassign(i32 noundef %src, i32 noundef %dst) local_unnamed_addr #5 !dbg !1436 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %src, metadata !1440, metadata !DIExpression()), !dbg !1443
  tail call void @llvm.dbg.value(metadata i32 %dst, metadata !1441, metadata !DIExpression()), !dbg !1443
  %call = tail call i32 @pthread_mutex_trylock(ptr noundef nonnull @slabs_rebalance_lock) #23, !dbg !1444
  %cmp.not = icmp eq i32 %call, 0, !dbg !1446
  br i1 %cmp.not, label %if.end, label %cleanup, !dbg !1447

if.end:                                           ; preds = %entry
  tail call void @llvm.dbg.value(metadata i32 %src, metadata !1448, metadata !DIExpression()), !dbg !1453
  tail call void @llvm.dbg.value(metadata i32 %dst, metadata !1451, metadata !DIExpression()), !dbg !1453
  tail call void @llvm.dbg.value(metadata i8 0, metadata !1452, metadata !DIExpression()), !dbg !1453
  %0 = load volatile i32, ptr @slab_rebalance_signal, align 4, !dbg !1455, !tbaa !456
  %cmp.not.i = icmp eq i32 %0, 0, !dbg !1457
  br i1 %cmp.not.i, label %if.end.i, label %do_slabs_reassign.exit, !dbg !1458

if.end.i:                                         ; preds = %if.end
  %cmp1.i = icmp eq i32 %src, %dst, !dbg !1459
  br i1 %cmp1.i, label %do_slabs_reassign.exit, label %if.end3.i, !dbg !1461

if.end3.i:                                        ; preds = %if.end.i
  %cmp4.i = icmp eq i32 %src, -1, !dbg !1462
  br i1 %cmp4.i, label %if.then5.i, label %if.end6.i, !dbg !1464

if.then5.i:                                       ; preds = %if.end3.i
  tail call void @llvm.dbg.value(metadata i32 %dst, metadata !357, metadata !DIExpression()), !dbg !1465
  %1 = load i32, ptr @power_largest, align 4, !dbg !1468, !tbaa !456
  tail call void @llvm.dbg.value(metadata i32 %1, metadata !358, metadata !DIExpression()), !dbg !1465
  tail call void @llvm.dbg.value(metadata i32 %1, metadata !358, metadata !DIExpression()), !dbg !1465
  %cmp10.i.i = icmp sgt i32 %1, 0, !dbg !1469
  br i1 %cmp10.i.i, label %for.body.preheader.i.i, label %do_slabs_reassign.exit, !dbg !1472

for.body.preheader.i.i:                           ; preds = %if.then5.i
  %slabs_reassign_pick_any.cur.promoted.i.i = load i32, ptr @slabs_reassign_pick_any.cur, align 4
  br label %for.body.i.i, !dbg !1472

for.body.i.i:                                     ; preds = %for.inc.i.i, %for.body.preheader.i.i
  %tries.012.i.i = phi i32 [ %dec.i.i, %for.inc.i.i ], [ %1, %for.body.preheader.i.i ]
  %spec.store.select911.i.i = phi i32 [ %spec.store.select.i.i, %for.inc.i.i ], [ %slabs_reassign_pick_any.cur.promoted.i.i, %for.body.preheader.i.i ]
  tail call void @llvm.dbg.value(metadata i32 %tries.012.i.i, metadata !358, metadata !DIExpression()), !dbg !1465
  %inc.i.i = add nsw i32 %spec.store.select911.i.i, 1, !dbg !1473
  %cmp1.not.i.i = icmp slt i32 %spec.store.select911.i.i, %1, !dbg !1475
  %spec.store.select.i.i = select i1 %cmp1.not.i.i, i32 %inc.i.i, i32 1, !dbg !1477
  %cmp2.i.i = icmp eq i32 %spec.store.select.i.i, %dst, !dbg !1478
  br i1 %cmp2.i.i, label %for.inc.i.i, label %if.end4.i.i, !dbg !1480

if.end4.i.i:                                      ; preds = %for.body.i.i
  %idxprom.i.i = sext i32 %spec.store.select.i.i to i64, !dbg !1481
  %slabs.i.i = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom.i.i, i32 4, !dbg !1483
  %2 = load i32, ptr %slabs.i.i, align 4, !dbg !1483, !tbaa !504
  %cmp5.i.i = icmp ugt i32 %2, 1, !dbg !1484
  br i1 %cmp5.i.i, label %cleanup.sink.split.i.i, label %for.inc.i.i, !dbg !1485

for.inc.i.i:                                      ; preds = %if.end4.i.i, %for.body.i.i
  %dec.i.i = add nsw i32 %tries.012.i.i, -1, !dbg !1486
  tail call void @llvm.dbg.value(metadata i32 %dec.i.i, metadata !358, metadata !DIExpression()), !dbg !1465
  %cmp.i.i = icmp sgt i32 %tries.012.i.i, 1, !dbg !1469
  br i1 %cmp.i.i, label %for.body.i.i, label %cleanup.sink.split.i.i, !dbg !1472, !llvm.loop !1487

cleanup.sink.split.i.i:                           ; preds = %for.inc.i.i, %if.end4.i.i
  %retval.0.ph.i.i = phi i32 [ -1, %for.inc.i.i ], [ %spec.store.select.i.i, %if.end4.i.i ]
  store i32 %spec.store.select.i.i, ptr @slabs_reassign_pick_any.cur, align 4, !dbg !1489
  br label %if.end6.i, !dbg !1490

if.end6.i:                                        ; preds = %cleanup.sink.split.i.i, %if.end3.i
  %src.addr.0.i = phi i32 [ %src, %if.end3.i ], [ %retval.0.ph.i.i, %cleanup.sink.split.i.i ]
  tail call void @llvm.dbg.value(metadata i32 %src.addr.0.i, metadata !1448, metadata !DIExpression()), !dbg !1453
  %cmp7.i = icmp slt i32 %src.addr.0.i, 0, !dbg !1491
  br i1 %cmp7.i, label %do_slabs_reassign.exit, label %lor.lhs.false.i, !dbg !1493

lor.lhs.false.i:                                  ; preds = %if.end6.i
  %3 = load i32, ptr @power_largest, align 4, !dbg !1494, !tbaa !456
  %cmp8.i = icmp sgt i32 %src.addr.0.i, %3, !dbg !1495
  %cmp10.i = icmp slt i32 %dst, 0
  %or.cond.i = or i1 %cmp10.i, %cmp8.i, !dbg !1496
  %cmp12.i = icmp slt i32 %3, %dst
  %or.cond32.i = or i1 %cmp12.i, %or.cond.i, !dbg !1496
  br i1 %or.cond32.i, label %do_slabs_reassign.exit, label %if.end14.i, !dbg !1496

if.end14.i:                                       ; preds = %lor.lhs.false.i
  %call15.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_lock) #23, !dbg !1497
  %idxprom.i = zext nneg i32 %src.addr.0.i to i64
  %slabs.i = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom.i, i32 4, !dbg !1498
  %4 = load i32, ptr %slabs.i, align 4, !dbg !1498, !tbaa !504
  %cmp16.i = icmp ult i32 %4, 2, !dbg !1500
  tail call void @llvm.dbg.value(metadata i8 poison, metadata !1452, metadata !DIExpression()), !dbg !1453
  %call19.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1501
  br i1 %cmp16.i, label %do_slabs_reassign.exit, label %if.end21.i, !dbg !1502

if.end21.i:                                       ; preds = %if.end14.i
  store i32 %src.addr.0.i, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 3), align 8, !dbg !1503, !tbaa !1504
  store i32 %dst, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 4), align 4, !dbg !1506, !tbaa !1507
  store volatile i32 1, ptr @slab_rebalance_signal, align 4, !dbg !1508, !tbaa !456
  %call22.i = tail call i32 @pthread_cond_signal(ptr noundef nonnull @slab_rebalance_cond) #23, !dbg !1509
  br label %do_slabs_reassign.exit, !dbg !1510

do_slabs_reassign.exit:                           ; preds = %if.end, %if.end.i, %if.then5.i, %if.end6.i, %lor.lhs.false.i, %if.end14.i, %if.end21.i
  %retval.0.i = phi i32 [ 0, %if.end21.i ], [ 1, %if.end ], [ 4, %if.end.i ], [ 2, %lor.lhs.false.i ], [ 2, %if.end6.i ], [ 3, %if.end14.i ], [ 2, %if.then5.i ], !dbg !1453
  tail call void @llvm.dbg.value(metadata i32 %retval.0.i, metadata !1442, metadata !DIExpression()), !dbg !1443
  %call2 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_rebalance_lock) #23, !dbg !1511
  br label %cleanup, !dbg !1512

cleanup:                                          ; preds = %entry, %do_slabs_reassign.exit
  %retval.0 = phi i32 [ %retval.0.i, %do_slabs_reassign.exit ], [ 1, %entry ], !dbg !1443
  ret i32 %retval.0, !dbg !1513
}

; Function Attrs: nounwind
declare !dbg !1514 i32 @pthread_mutex_trylock(ptr noundef) local_unnamed_addr #10

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @slabs_rebalancer_pause() local_unnamed_addr #5 !dbg !1515 {
entry:
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_rebalance_lock) #23, !dbg !1516
  ret void, !dbg !1517
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @slabs_rebalancer_resume() local_unnamed_addr #5 !dbg !1518 {
entry:
  %call = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_rebalance_lock) #23, !dbg !1519
  ret void, !dbg !1520
}

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local range(i32 -1, 1) i32 @start_slab_maintenance_thread() local_unnamed_addr #5 !dbg !1521 {
entry:
  store volatile i32 0, ptr @slab_rebalance_signal, align 4, !dbg !1526, !tbaa !456
  store ptr null, ptr @slab_rebal, align 8, !dbg !1527, !tbaa !1528
  %call = tail call i32 @pthread_create(ptr noundef nonnull @rebalance_tid, ptr noundef null, ptr noundef nonnull @slab_rebalance_thread, ptr noundef null) #23, !dbg !1529
  tail call void @llvm.dbg.value(metadata i32 %call, metadata !1525, metadata !DIExpression()), !dbg !1531
  %cmp.not = icmp eq i32 %call, 0, !dbg !1532
  br i1 %cmp.not, label %if.end, label %if.then, !dbg !1533

if.then:                                          ; preds = %entry
  %0 = load ptr, ptr @stderr, align 8, !dbg !1534, !tbaa !421
  %call1 = tail call ptr @strerror(i32 noundef %call) #23, !dbg !1536
  %call2 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %0, ptr noundef nonnull @.str.3, ptr noundef %call1) #26, !dbg !1537
  br label %cleanup, !dbg !1538

if.end:                                           ; preds = %entry
  %1 = load i64, ptr @rebalance_tid, align 8, !dbg !1539, !tbaa !685
  tail call void @thread_setname(i64 noundef %1, ptr noundef nonnull @.str.4) #23, !dbg !1540
  br label %cleanup, !dbg !1541

cleanup:                                          ; preds = %if.end, %if.then
  %retval.0 = phi i32 [ -1, %if.then ], [ 0, %if.end ], !dbg !1531
  ret i32 %retval.0, !dbg !1542
}

; Function Attrs: nounwind
declare !dbg !1543 i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #10

; Function Attrs: nounwind sanitize_thread uwtable
define internal noundef ptr @slab_rebalance_thread(ptr nocapture readnone %arg) #5 !dbg !1560 {
entry:
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1562, metadata !DIExpression()), !dbg !1566
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1563, metadata !DIExpression()), !dbg !1566
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1564, metadata !DIExpression()), !dbg !1566
  tail call void @llvm.dbg.value(metadata i32 1000, metadata !1565, metadata !DIExpression()), !dbg !1566
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_rebalance_lock) #23, !dbg !1567
  br label %while.cond, !dbg !1568

while.cond:                                       ; preds = %while.cond.backedge, %entry
  %backoff_timer.0 = phi i32 [ 1, %entry ], [ %backoff_timer.1, %while.cond.backedge ], !dbg !1569
  %was_busy.0 = phi i32 [ 0, %entry ], [ %was_busy.1, %while.cond.backedge ], !dbg !1566
  tail call void @llvm.dbg.value(metadata i32 %was_busy.0, metadata !1563, metadata !DIExpression()), !dbg !1566
  tail call void @llvm.dbg.value(metadata i32 %backoff_timer.0, metadata !1564, metadata !DIExpression()), !dbg !1566
  %0 = load volatile i32, ptr @slab_rebalance_signal, align 4, !dbg !1570, !tbaa !456
  %tobool.not = icmp eq i32 %0, 0, !dbg !1570
  br i1 %tobool.not, label %lor.rhs, label %while.body, !dbg !1571

lor.rhs:                                          ; preds = %while.cond
  %1 = load volatile i32, ptr @do_run_slab_rebalance_thread, align 4, !dbg !1572, !tbaa !456
  %tobool1.not = icmp eq i32 %1, 0, !dbg !1571
  br i1 %tobool1.not, label %while.end, label %while.body, !dbg !1568

while.body:                                       ; preds = %while.cond, %lor.rhs
  %2 = load volatile i32, ptr @slab_rebalance_signal, align 4, !dbg !1573, !tbaa !456
  %cmp = icmp eq i32 %2, 1, !dbg !1576
  br i1 %cmp, label %if.then, label %if.else, !dbg !1577

if.then:                                          ; preds = %while.body
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1578, metadata !DIExpression()), !dbg !1582
  %call.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_lock) #23, !dbg !1586
  %3 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 3), align 8, !dbg !1587, !tbaa !1504
  %cmp.i = icmp slt i32 %3, 0, !dbg !1589
  br i1 %cmp.i, label %entry.if.then_crit_edge.i, label %lor.lhs.false.i, !dbg !1590

entry.if.then_crit_edge.i:                        ; preds = %if.then
  %.pre.pre.i = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 4), align 4, !dbg !1591, !tbaa !1507
  br label %if.end.i, !dbg !1590

lor.lhs.false.i:                                  ; preds = %if.then
  %4 = load i32, ptr @power_largest, align 4, !dbg !1593, !tbaa !456
  %cmp1.i = icmp sgt i32 %3, %4, !dbg !1594
  %.pre.pre41.i = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 4), align 4, !dbg !1591, !tbaa !1507
  br i1 %cmp1.i, label %if.end.i, label %lor.lhs.false2.i, !dbg !1595

lor.lhs.false2.i:                                 ; preds = %lor.lhs.false.i
  %cmp3.i = icmp slt i32 %.pre.pre41.i, 0, !dbg !1596
  %cmp5.i = icmp sgt i32 %.pre.pre41.i, %4
  %or.cond.i = or i1 %cmp3.i, %cmp5.i, !dbg !1597
  %cmp7.i = icmp eq i32 %3, %.pre.pre41.i
  %or.cond38.i = or i1 %cmp7.i, %or.cond.i, !dbg !1597
  %spec.select.i = select i1 %or.cond38.i, i32 -2, i32 0, !dbg !1597
  br label %if.end.i, !dbg !1597

if.end.i:                                         ; preds = %lor.lhs.false2.i, %lor.lhs.false.i, %entry.if.then_crit_edge.i
  %5 = phi i32 [ %.pre.pre.i, %entry.if.then_crit_edge.i ], [ %.pre.pre41.i, %lor.lhs.false.i ], [ %.pre.pre41.i, %lor.lhs.false2.i ], !dbg !1591
  %no_go.0.i = phi i32 [ -2, %entry.if.then_crit_edge.i ], [ -2, %lor.lhs.false.i ], [ %spec.select.i, %lor.lhs.false2.i ], !dbg !1582
  tail call void @llvm.dbg.value(metadata i32 %no_go.0.i, metadata !1578, metadata !DIExpression()), !dbg !1582
  %idxprom.i = sext i32 %3 to i64, !dbg !1598
  %arrayidx.i = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom.i, !dbg !1598
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i, metadata !1581, metadata !DIExpression()), !dbg !1582
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !489, metadata !DIExpression()), !dbg !1599
  %idxprom.i.i = zext i32 %5 to i64, !dbg !1601
  %arrayidx.i.i = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom.i.i, !dbg !1601
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i.i, metadata !495, metadata !DIExpression()), !dbg !1599
  %slabs.i.i = getelementptr inbounds i8, ptr %arrayidx.i.i, i64 20, !dbg !1602
  %6 = load i32, ptr %slabs.i.i, align 4, !dbg !1602, !tbaa !504
  %list_size.i.i = getelementptr inbounds i8, ptr %arrayidx.i.i, i64 32, !dbg !1603
  %7 = load i32, ptr %list_size.i.i, align 8, !dbg !1603, !tbaa !506
  %cmp.i.i = icmp eq i32 %6, %7, !dbg !1604
  br i1 %cmp.i.i, label %if.then.i.i, label %grow_slab_list.exit.i, !dbg !1605

if.then.i.i:                                      ; preds = %if.end.i
  %cmp2.not.i.i = icmp eq i32 %6, 0, !dbg !1606
  %mul.i.i = shl i32 %6, 1
  %spec.select.i.i = select i1 %cmp2.not.i.i, i32 16, i32 %mul.i.i, !dbg !1607
  %conv.i.i = zext i32 %spec.select.i.i to i64, !dbg !1607
  tail call void @llvm.dbg.value(metadata i64 %conv.i.i, metadata !496, metadata !DIExpression()), !dbg !1608
  %slab_list.i.i = getelementptr inbounds i8, ptr %arrayidx.i.i, i64 24, !dbg !1609
  %8 = load ptr, ptr %slab_list.i.i, align 8, !dbg !1609, !tbaa !509
  %mul4.i.i = shl nuw nsw i64 %conv.i.i, 3, !dbg !1610
  %call.i.i = tail call ptr @realloc(ptr noundef %8, i64 noundef %mul4.i.i) #22, !dbg !1611
  tail call void @llvm.dbg.value(metadata ptr %call.i.i, metadata !499, metadata !DIExpression()), !dbg !1608
  %cmp5.not.i.i = icmp eq ptr %call.i.i, null, !dbg !1612
  br i1 %cmp5.not.i.i, label %if.then4, label %if.end.i.i, !dbg !1613

if.end.i.i:                                       ; preds = %if.then.i.i
  store i32 %spec.select.i.i, ptr %list_size.i.i, align 8, !dbg !1614, !tbaa !506
  store ptr %call.i.i, ptr %slab_list.i.i, align 8, !dbg !1615, !tbaa !509
  br label %grow_slab_list.exit.i

grow_slab_list.exit.i:                            ; preds = %if.end.i.i, %if.end.i
  tail call void @llvm.dbg.value(metadata i32 %no_go.0.i, metadata !1578, metadata !DIExpression()), !dbg !1582
  %slabs.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 20, !dbg !1616
  %9 = load i32, ptr %slabs.i, align 4, !dbg !1616, !tbaa !504
  %cmp11.i = icmp ugt i32 %9, 1, !dbg !1618
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1578, metadata !DIExpression()), !dbg !1582
  %cmp14.not.i63 = icmp eq i32 %no_go.0.i, 0, !dbg !1619
  %cmp14.not.i = select i1 %cmp11.i, i1 %cmp14.not.i63, i1 false, !dbg !1619
  br i1 %cmp14.not.i, label %if.end17.i, label %if.then4, !dbg !1621

if.end17.i:                                       ; preds = %grow_slab_list.exit.i
  %slab_list.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 24, !dbg !1622
  %10 = load ptr, ptr %slab_list.i, align 8, !dbg !1622, !tbaa !509
  %11 = load ptr, ptr %10, align 8, !dbg !1623, !tbaa !421
  store ptr %11, ptr @slab_rebal, align 8, !dbg !1624, !tbaa !1528
  %12 = load i32, ptr %arrayidx.i, align 8, !dbg !1625, !tbaa !449
  %perslab.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 4, !dbg !1626
  %13 = load i32, ptr %perslab.i, align 4, !dbg !1626, !tbaa !801
  %mul.i = mul i32 %13, %12, !dbg !1627
  %idx.ext.i = zext i32 %mul.i to i64, !dbg !1628
  %add.ptr.i = getelementptr inbounds i8, ptr %11, i64 %idx.ext.i, !dbg !1628
  store ptr %add.ptr.i, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 1), align 8, !dbg !1629, !tbaa !1630
  store ptr %11, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 2), align 8, !dbg !1631, !tbaa !1632
  %14 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 3), align 8, !dbg !1633, !tbaa !1504
  %cmp19.i = icmp eq i32 %14, 0, !dbg !1635
  %spec.store.select.i = zext i1 %cmp19.i to i8, !dbg !1636
  store i8 %spec.store.select.i, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 12), align 4, !dbg !1582
  %conv.i = zext i32 %13 to i64, !dbg !1637
  %call23.i = tail call noalias ptr @calloc(i64 noundef %conv.i, i64 noundef 1) #29, !dbg !1638
  store ptr %call23.i, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 13), align 8, !dbg !1639, !tbaa !1640
  store volatile i32 2, ptr @slab_rebalance_signal, align 4, !dbg !1641, !tbaa !456
  %15 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1642, !tbaa !721
  %cmp24.i = icmp sgt i32 %15, 1, !dbg !1644
  br i1 %cmp24.i, label %if.then26.i, label %slab_rebalance_start.exit, !dbg !1645

if.then26.i:                                      ; preds = %if.end17.i
  %16 = load ptr, ptr @stderr, align 8, !dbg !1646, !tbaa !421
  %17 = tail call i64 @fwrite(ptr nonnull @.str.35, i64 25, i64 1, ptr %16) #25, !dbg !1648
  br label %slab_rebalance_start.exit, !dbg !1649

slab_rebalance_start.exit:                        ; preds = %if.end17.i, %if.then26.i
  %call29.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1650
  tail call void @STATS_LOCK() #23, !dbg !1651
  store i8 1, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 10), align 2, !dbg !1652, !tbaa !1653
  tail call void @STATS_UNLOCK() #23, !dbg !1655
  br label %if.end10thread-pre-split, !dbg !1656

if.then4:                                         ; preds = %if.then.i.i, %grow_slab_list.exit.i
  %call16.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1657
  store volatile i32 0, ptr @slab_rebalance_signal, align 4, !dbg !1659, !tbaa !456
  br label %if.end10thread-pre-split, !dbg !1661

if.else:                                          ; preds = %while.body
  %18 = load volatile i32, ptr @slab_rebalance_signal, align 4, !dbg !1662, !tbaa !456
  %tobool5.not = icmp eq i32 %18, 0, !dbg !1662
  br i1 %tobool5.not, label %if.end10thread-pre-split, label %land.lhs.true, !dbg !1664

land.lhs.true:                                    ; preds = %if.else
  %19 = load ptr, ptr @slab_rebal, align 8, !dbg !1665, !tbaa !1528
  %cmp6.not = icmp eq ptr %19, null, !dbg !1666
  br i1 %cmp6.not, label %if.end10thread-pre-split, label %if.then7, !dbg !1667

if.then7:                                         ; preds = %land.lhs.true
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1668, metadata !DIExpression()), !dbg !1702
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1672, metadata !DIExpression()), !dbg !1702
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1675, metadata !DIExpression()), !dbg !1702
  %20 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 3), align 8, !dbg !1705, !tbaa !1504
  %idxprom.i30 = sext i32 %20 to i64, !dbg !1706
  %arrayidx.i31 = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom.i30, !dbg !1706
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i31, metadata !1671, metadata !DIExpression()), !dbg !1702
  %21 = load ptr, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 2), align 8, !dbg !1707, !tbaa !1632
  %sub.ptr.lhs.cast.i = ptrtoint ptr %21 to i64, !dbg !1708
  %sub.ptr.rhs.cast.i = ptrtoint ptr %19 to i64, !dbg !1708
  %sub.ptr.sub.i = sub i64 %sub.ptr.lhs.cast.i, %sub.ptr.rhs.cast.i, !dbg !1708
  %22 = load i32, ptr %arrayidx.i31, align 8, !dbg !1709, !tbaa !449
  %conv.i32 = zext i32 %22 to i64, !dbg !1710
  %div.i = sdiv i64 %sub.ptr.sub.i, %conv.i32, !dbg !1711
  tail call void @llvm.dbg.value(metadata i64 %div.i, metadata !1676, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1702
  %23 = load ptr, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 13), align 8, !dbg !1712, !tbaa !1640
  %sext.i = shl i64 %div.i, 32, !dbg !1713
  %idxprom2.i = ashr exact i64 %sext.i, 32, !dbg !1713
  %arrayidx3.i = getelementptr inbounds i8, ptr %23, i64 %idxprom2.i, !dbg !1713
  %24 = load i8, ptr %arrayidx3.i, align 1, !dbg !1713, !tbaa !485
  %cmp.i33 = icmp eq i8 %24, 0, !dbg !1714
  br i1 %cmp.i33, label %if.then.i, label %if.end269.i, !dbg !1715

if.then.i:                                        ; preds = %if.then7
  %call.i34 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_lock) #23, !dbg !1716
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1673, metadata !DIExpression()), !dbg !1702
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1674, metadata !DIExpression()), !dbg !1702
  %25 = load ptr, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 2), align 8, !dbg !1717, !tbaa !1632
  tail call void @llvm.dbg.value(metadata ptr %25, metadata !1677, metadata !DIExpression()), !dbg !1718
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1680, metadata !DIExpression()), !dbg !1718
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1675, metadata !DIExpression()), !dbg !1702
  %it_flags.i = getelementptr inbounds i8, ptr %25, i64 38, !dbg !1719
  %26 = load i16, ptr %it_flags.i, align 2, !dbg !1719, !tbaa !553
  %27 = and i16 %26, 64, !dbg !1721
  %tobool.not.i = icmp eq i16 %27, 0, !dbg !1721
  br i1 %tobool.not.i, label %if.end.i35, label %if.then7.i, !dbg !1722

if.then7.i:                                       ; preds = %if.then.i
  tail call void @llvm.dbg.value(metadata ptr %25, metadata !1680, metadata !DIExpression()), !dbg !1718
  %head.i = getelementptr inbounds i8, ptr %25, i64 16, !dbg !1723
  %28 = load ptr, ptr %head.i, align 8, !dbg !1723, !tbaa !421
  tail call void @llvm.dbg.value(metadata ptr %28, metadata !1677, metadata !DIExpression()), !dbg !1718
  %it_flags8.phi.trans.insert.i = getelementptr inbounds i8, ptr %28, i64 38
  %.pre.i = load i16, ptr %it_flags8.phi.trans.insert.i, align 2, !dbg !1725, !tbaa !553
  br label %if.end.i35, !dbg !1726

if.end.i35:                                       ; preds = %if.then7.i, %if.then.i
  %29 = phi i16 [ %.pre.i, %if.then7.i ], [ %26, %if.then.i ], !dbg !1725
  %it.0.i = phi ptr [ %28, %if.then7.i ], [ %25, %if.then.i ], !dbg !1718
  %ch.0.i = phi ptr [ %25, %if.then7.i ], [ null, %if.then.i ], !dbg !1718
  tail call void @llvm.dbg.value(metadata ptr %ch.0.i, metadata !1680, metadata !DIExpression()), !dbg !1718
  tail call void @llvm.dbg.value(metadata ptr %it.0.i, metadata !1677, metadata !DIExpression()), !dbg !1718
  %it_flags8.i = getelementptr inbounds i8, ptr %it.0.i, i64 38, !dbg !1725
  %conv9.i = zext i16 %29 to i32, !dbg !1727
  %cmp10.not.i = icmp eq i16 %29, 12, !dbg !1728
  br i1 %cmp10.not.i, label %sw.epilog.i, label %if.then12.i, !dbg !1729

if.then12.i:                                      ; preds = %if.end.i35
  %and15.i = and i32 %conv9.i, 4, !dbg !1730
  %tobool16.not.i = icmp eq i32 %and15.i, 0, !dbg !1730
  br i1 %tobool16.not.i, label %if.else.i, label %if.then17.i, !dbg !1731

if.then17.i:                                      ; preds = %if.then12.i
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i31, metadata !1732, metadata !DIExpression()), !dbg !1738
  tail call void @llvm.dbg.value(metadata ptr %it.0.i, metadata !1737, metadata !DIExpression()), !dbg !1738
  %slots.i.i = getelementptr inbounds i8, ptr %arrayidx.i31, i64 8, !dbg !1741
  %30 = load ptr, ptr %slots.i.i, align 8, !dbg !1741, !tbaa !561
  %cmp.i.i36 = icmp eq ptr %30, %it.0.i, !dbg !1743
  %.pre.i.i = load ptr, ptr %it.0.i, align 8, !dbg !1744, !tbaa !421
  br i1 %cmp.i.i36, label %if.then.i.i38, label %if.end.i.i37, !dbg !1746

if.then.i.i38:                                    ; preds = %if.then17.i
  store ptr %.pre.i.i, ptr %slots.i.i, align 8, !dbg !1747, !tbaa !561
  br label %if.end.i.i37, !dbg !1749

if.end.i.i37:                                     ; preds = %if.then.i.i38, %if.then17.i
  %tobool.not.i.i = icmp eq ptr %.pre.i.i, null, !dbg !1750
  %prev7.phi.trans.insert.i.i = getelementptr inbounds i8, ptr %it.0.i, i64 8
  %.pre24.i.i = load ptr, ptr %prev7.phi.trans.insert.i.i, align 8, !dbg !1738, !tbaa !421
  br i1 %tobool.not.i.i, label %if.end6.i.i, label %if.then3.i.i, !dbg !1751

if.then3.i.i:                                     ; preds = %if.end.i.i37
  %prev5.i.i = getelementptr inbounds i8, ptr %.pre.i.i, i64 8, !dbg !1752
  store ptr %.pre24.i.i, ptr %prev5.i.i, align 8, !dbg !1753, !tbaa !421
  br label %if.end6.i.i, !dbg !1754

if.end6.i.i:                                      ; preds = %if.then3.i.i, %if.end.i.i37
  %tobool8.not.i.i = icmp eq ptr %.pre24.i.i, null, !dbg !1755
  br i1 %tobool8.not.i.i, label %if.end80.thread392.i, label %if.then9.i.i, !dbg !1757

if.then9.i.i:                                     ; preds = %if.end6.i.i
  %31 = load ptr, ptr %it.0.i, align 8, !dbg !1758, !tbaa !421
  store ptr %31, ptr %.pre24.i.i, align 8, !dbg !1759, !tbaa !421
  br label %if.end80.thread392.i, !dbg !1760

if.end80.thread392.i:                             ; preds = %if.then9.i.i, %if.end6.i.i
  %sl_curr.i.i = getelementptr inbounds i8, ptr %arrayidx.i31, i64 16, !dbg !1761
  %32 = load i32, ptr %sl_curr.i.i, align 8, !dbg !1762, !tbaa !572
  %dec.i.i = add i32 %32, -1, !dbg !1762
  store i32 %dec.i.i, ptr %sl_curr.i.i, align 8, !dbg !1762, !tbaa !572
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1673, metadata !DIExpression()), !dbg !1702
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1675, metadata !DIExpression()), !dbg !1702
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1674, metadata !DIExpression()), !dbg !1702
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1689, metadata !DIExpression()), !dbg !1718
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1690, metadata !DIExpression()), !dbg !1718
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1691, metadata !DIExpression()), !dbg !1718
  %33 = load ptr, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 13), align 8, !dbg !1763, !tbaa !1640
  %arrayidx262.i = getelementptr inbounds i8, ptr %33, i64 %idxprom2.i, !dbg !1764
  store i8 1, ptr %arrayidx262.i, align 1, !dbg !1765, !tbaa !485
  %refcount263.i = getelementptr inbounds i8, ptr %it.0.i, i64 36, !dbg !1766
  store i16 0, ptr %refcount263.i, align 4, !dbg !1767, !tbaa !553
  store i16 12, ptr %it_flags8.i, align 2, !dbg !1768, !tbaa !553
  br label %sw.epilog.i, !dbg !1769

if.else.i:                                        ; preds = %if.then12.i
  %and20.i = and i32 %conv9.i, 1, !dbg !1770
  %cmp21.not.i = icmp eq i32 %and20.i, 0, !dbg !1771
  br i1 %cmp21.not.i, label %sw.bb265.i, label %if.then23.i, !dbg !1772

if.then23.i:                                      ; preds = %if.else.i
  %34 = load ptr, ptr @hash, align 8, !dbg !1773, !tbaa !421
  %data.i = getelementptr inbounds i8, ptr %it.0.i, i64 48, !dbg !1774
  %and26.i = shl nuw nsw i32 %conv9.i, 2, !dbg !1774
  %35 = and i32 %and26.i, 8, !dbg !1774
  %cond.i = zext nneg i32 %35 to i64, !dbg !1774
  %add.ptr.i39 = getelementptr inbounds i8, ptr %data.i, i64 %cond.i, !dbg !1774
  %nkey.i = getelementptr inbounds i8, ptr %it.0.i, i64 41, !dbg !1775
  %36 = load i8, ptr %nkey.i, align 1, !dbg !1775, !tbaa !485
  %conv28.i = zext i8 %36 to i64, !dbg !1776
  %call29.i40 = tail call i32 %34(ptr noundef nonnull %add.ptr.i39, i64 noundef %conv28.i) #23, !dbg !1773
  tail call void @llvm.dbg.value(metadata i32 %call29.i40, metadata !1673, metadata !DIExpression()), !dbg !1702
  %call30.i = tail call ptr @item_trylock(i32 noundef %call29.i40) #23, !dbg !1777
  tail call void @llvm.dbg.value(metadata ptr %call30.i, metadata !1674, metadata !DIExpression()), !dbg !1702
  %cmp31.i = icmp eq ptr %call30.i, null, !dbg !1778
  br i1 %cmp31.i, label %sw.bb265.i, label %if.else34.i, !dbg !1779

if.else34.i:                                      ; preds = %if.then23.i
  %37 = load i16, ptr %it_flags8.i, align 2, !dbg !1780, !tbaa !553
  %38 = and i16 %37, 1, !dbg !1781
  %tobool38.not.i = icmp eq i16 %38, 0, !dbg !1782
  tail call void @llvm.dbg.value(metadata i1 %tobool38.not.i, metadata !1681, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1783
  %refcount39.i = getelementptr inbounds i8, ptr %it.0.i, i64 36, !dbg !1784
  %39 = load i16, ptr %refcount39.i, align 4, !dbg !1784, !tbaa !553
  %inc.i = add i16 %39, 1, !dbg !1784
  store i16 %inc.i, ptr %refcount39.i, align 4, !dbg !1784, !tbaa !553
  tail call void @llvm.dbg.value(metadata i16 %inc.i, metadata !1672, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1702
  %cmp41.i = icmp eq i16 %inc.i, 2, !dbg !1785
  br i1 %cmp41.i, label %if.end70.i, label %if.else48.i, !dbg !1787

if.else48.i:                                      ; preds = %if.else34.i
  tail call void @llvm.dbg.value(metadata i16 %inc.i, metadata !1672, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1702
  %cmp49.i = icmp ult i16 %inc.i, 3, !dbg !1788
  %brmerge.i = select i1 %cmp49.i, i1 true, i1 %tobool38.not.i, !dbg !1790
  br i1 %brmerge.i, label %if.else61.i, label %if.then53.i, !dbg !1790

if.then53.i:                                      ; preds = %if.else48.i
  %40 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 11), align 8, !dbg !1791, !tbaa !1794
  %cmp54.i = icmp ugt i32 %40, 1000, !dbg !1795
  br i1 %cmp54.i, label %if.then56.i, label %if.then73.i, !dbg !1796

if.then56.i:                                      ; preds = %if.then53.i
  %41 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 10), align 4, !dbg !1797, !tbaa !1799
  %inc57.i = add i32 %41, 1, !dbg !1797
  store i32 %inc57.i, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 10), align 4, !dbg !1797, !tbaa !1799
  %42 = load ptr, ptr @storage, align 8, !dbg !1800, !tbaa !421
  tail call void @storage_delete(ptr noundef %42, ptr noundef nonnull %it.0.i) #23, !dbg !1800
  %call58.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1802
  tail call void @do_item_unlink(ptr noundef nonnull %it.0.i, i32 noundef %call29.i40) #23, !dbg !1803
  %call59.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_lock) #23, !dbg !1804
  br label %if.then73.i, !dbg !1805

if.else61.i:                                      ; preds = %if.else48.i
  %43 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !1806, !tbaa !721
  %cmp62.i = icmp sgt i32 %43, 2, !dbg !1809
  br i1 %cmp62.i, label %if.then64.i, label %if.then73.i, !dbg !1810

if.then64.i:                                      ; preds = %if.else61.i
  %44 = load ptr, ptr @stderr, align 8, !dbg !1811, !tbaa !421
  %conv66.i = zext i16 %inc.i to i32, !dbg !1813
  %45 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 3), align 8, !dbg !1814, !tbaa !1504
  %46 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 4), align 4, !dbg !1815, !tbaa !1507
  %call67.i = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %44, ptr noundef nonnull @.str.36, i32 noundef %conv66.i, i32 noundef %45, i32 noundef %46) #26, !dbg !1816
  br label %if.then73.i, !dbg !1817

if.end70.i:                                       ; preds = %if.else34.i
  tail call void @llvm.dbg.value(metadata i32 undef, metadata !1675, metadata !DIExpression()), !dbg !1702
  br i1 %tobool38.not.i, label %if.then73.i, label %sw.bb.i, !dbg !1818

if.then73.i:                                      ; preds = %if.end70.i, %if.then64.i, %if.else61.i, %if.then56.i, %if.then53.i
  %47 = load i16, ptr %refcount39.i, align 4, !dbg !1819, !tbaa !553
  %dec.i = add i16 %47, -1, !dbg !1819
  store i16 %dec.i, ptr %refcount39.i, align 4, !dbg !1819, !tbaa !553
  tail call void @item_trylock_unlock(ptr noundef nonnull %call30.i) #23, !dbg !1822
  tail call void @llvm.dbg.value(metadata i32 %call29.i40, metadata !1673, metadata !DIExpression()), !dbg !1702
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1675, metadata !DIExpression()), !dbg !1702
  tail call void @llvm.dbg.value(metadata ptr %call30.i, metadata !1674, metadata !DIExpression()), !dbg !1702
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1689, metadata !DIExpression()), !dbg !1718
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1690, metadata !DIExpression()), !dbg !1718
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1691, metadata !DIExpression()), !dbg !1718
  br label %sw.bb265.i, !dbg !1823

sw.bb.i:                                          ; preds = %if.end70.i
  tail call void @llvm.dbg.value(metadata i32 %call29.i40, metadata !1673, metadata !DIExpression()), !dbg !1702
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1675, metadata !DIExpression()), !dbg !1702
  tail call void @llvm.dbg.value(metadata ptr %call30.i, metadata !1674, metadata !DIExpression()), !dbg !1702
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1689, metadata !DIExpression()), !dbg !1718
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1690, metadata !DIExpression()), !dbg !1718
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1691, metadata !DIExpression()), !dbg !1718
  %48 = load i8, ptr %nkey.i, align 1, !dbg !1824, !tbaa !485
  %conv82.i = zext i8 %48 to i64, !dbg !1824
  %nbytes.i = getelementptr inbounds i8, ptr %it.0.i, i64 32, !dbg !1824
  %49 = load i32, ptr %nbytes.i, align 8, !dbg !1824, !tbaa !456
  %conv87.i = zext i16 %37 to i32, !dbg !1824
  %and88.i = lshr i32 %conv87.i, 6, !dbg !1824
  %50 = and i32 %and88.i, 4, !dbg !1824
  %and94.i = shl nuw nsw i32 %conv87.i, 2, !dbg !1824
  %51 = and i32 %and94.i, 8, !dbg !1824
  %52 = or disjoint i32 %50, %51, !dbg !1824
  %add85.i65 = or disjoint i32 %52, 49, !dbg !1824
  %add85.i = zext nneg i32 %add85.i65 to i64, !dbg !1824
  %add91.i = add nuw nsw i64 %add85.i, %conv82.i, !dbg !1824
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %add91.i, i32 %49), metadata !1691, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_signed, DW_OP_LLVM_convert, 64, DW_ATE_signed, DW_OP_plus, DW_OP_stack_value)), !dbg !1718
  %and100.i = and i32 %conv87.i, 128, !dbg !1825
  %tobool101.not.i = icmp eq i32 %and100.i, 0, !dbg !1825
  %narrow = select i1 %tobool101.not.i, i32 %49, i32 12, !dbg !1827
  %ntotal.0.i.v = sext i32 %narrow to i64, !dbg !1827
  %ntotal.0.i = add nsw i64 %add91.i, %ntotal.0.i.v, !dbg !1827
  tail call void @llvm.dbg.value(metadata i64 %ntotal.0.i, metadata !1691, metadata !DIExpression()), !dbg !1718
  %cmp107.i = icmp ne ptr %ch.0.i, null, !dbg !1828
  %53 = and i16 %37, 32
  %tobool113.not.i = icmp eq i16 %53, 0
  %or.cond.i41 = select i1 %cmp107.i, i1 true, i1 %tobool113.not.i, !dbg !1830
  br i1 %or.cond.i41, label %if.end117.i, label %if.then114.i, !dbg !1830

if.then114.i:                                     ; preds = %sw.bb.i
  %54 = load i32, ptr %arrayidx.i31, align 8, !dbg !1831, !tbaa !449
  %conv116.i = zext i32 %54 to i64, !dbg !1833
  tail call void @llvm.dbg.value(metadata i64 %conv116.i, metadata !1691, metadata !DIExpression()), !dbg !1718
  br label %if.end117.i, !dbg !1834

if.end117.i:                                      ; preds = %if.then114.i, %sw.bb.i
  %ntotal.1.i = phi i64 [ %conv116.i, %if.then114.i ], [ %ntotal.0.i, %sw.bb.i ], !dbg !1835
  tail call void @llvm.dbg.value(metadata i64 %ntotal.1.i, metadata !1691, metadata !DIExpression()), !dbg !1718
  %exptime.i = getelementptr inbounds i8, ptr %it.0.i, i64 28, !dbg !1836
  %55 = load i32, ptr %exptime.i, align 4, !dbg !1836, !tbaa !456
  %cmp118.not.i = icmp eq i32 %55, 0, !dbg !1838
  br i1 %cmp118.not.i, label %lor.lhs.false.i42, label %land.lhs.true120.i, !dbg !1839

land.lhs.true120.i:                               ; preds = %if.end117.i
  %56 = load volatile i32, ptr @current_time, align 4, !dbg !1840, !tbaa !456
  %cmp122.i = icmp ult i32 %55, %56, !dbg !1841
  br i1 %cmp122.i, label %do.body220.i, label %lor.lhs.false.i42, !dbg !1842

lor.lhs.false.i42:                                ; preds = %land.lhs.true120.i, %if.end117.i
  %call124.i = tail call i32 @item_is_flushed(ptr noundef nonnull %it.0.i) #23, !dbg !1843
  %tobool125.not.i = icmp eq i32 %call124.i, 0, !dbg !1843
  br i1 %tobool125.not.i, label %if.else127.i, label %do.body220.i, !dbg !1844

if.else127.i:                                     ; preds = %lor.lhs.false.i42
  %57 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 3), align 8, !dbg !1845, !tbaa !1504
  %call142.i = tail call fastcc ptr @slab_rebalance_alloc(i32 noundef %57), !dbg !1845
  %cmp143.i = icmp eq ptr %call142.i, null, !dbg !1845
  br i1 %cmp107.i, label %land.lhs.true139.i, label %land.lhs.true130.i, !dbg !1847

land.lhs.true130.i:                               ; preds = %if.else127.i
  tail call void @llvm.dbg.value(metadata ptr %call142.i, metadata !1690, metadata !DIExpression()), !dbg !1718
  br i1 %cmp143.i, label %do.body220.sink.split.i, label %if.then156.i, !dbg !1848

land.lhs.true139.i:                               ; preds = %if.else127.i
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1690, metadata !DIExpression()), !dbg !1718
  tail call void @llvm.dbg.value(metadata ptr %call142.i, metadata !1690, metadata !DIExpression()), !dbg !1718
  br i1 %cmp143.i, label %do.body220.sink.split.i, label %if.else200.i, !dbg !1849

if.then156.i:                                     ; preds = %land.lhs.true130.i
  tail call void @llvm.dbg.value(metadata ptr %call142.i, metadata !1690, metadata !DIExpression()), !dbg !1718
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1689, metadata !DIExpression()), !dbg !1718
  %call151401.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1850
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %call142.i, ptr nonnull align 8 %it.0.i, i64 %ntotal.1.i, i1 false), !dbg !1851
  %it_flags157.i = getelementptr inbounds i8, ptr %call142.i, i64 38, !dbg !1852
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %call142.i, i8 0, i64 24, i1 false), !dbg !1853
  %58 = load i16, ptr %it_flags157.i, align 2, !dbg !1854, !tbaa !553
  %59 = and i16 %58, -2, !dbg !1854
  store i16 %59, ptr %it_flags157.i, align 2, !dbg !1854, !tbaa !553
  %refcount161.i = getelementptr inbounds i8, ptr %call142.i, i64 36, !dbg !1855
  store i16 0, ptr %refcount161.i, align 4, !dbg !1856, !tbaa !553
  %60 = load i16, ptr %it_flags8.i, align 2, !dbg !1857, !tbaa !553
  %61 = and i16 %60, 2, !dbg !1857
  %tobool165.not.i = icmp eq i16 %61, 0, !dbg !1857
  br i1 %tobool165.not.i, label %cond.end.i, label %cond.true.i, !dbg !1857

cond.true.i:                                      ; preds = %if.then156.i
  %62 = load i64, ptr %data.i, align 8, !dbg !1857, !tbaa !485
  br label %cond.end.i, !dbg !1857

cond.end.i:                                       ; preds = %cond.true.i, %if.then156.i
  %cond167.i = phi i64 [ %62, %cond.true.i ], [ 0, %if.then156.i ], !dbg !1857
  %call168.i = tail call i32 @do_item_replace(ptr noundef nonnull %it.0.i, ptr noundef nonnull %call142.i, i32 noundef %call29.i40, i64 noundef %cond167.i) #23, !dbg !1858
  %63 = load i16, ptr %it_flags157.i, align 2, !dbg !1859, !tbaa !553
  %conv170.i = zext i16 %63 to i32, !dbg !1860
  %and171.i = and i32 %conv170.i, 32, !dbg !1861
  %tobool172.not.i = icmp eq i32 %and171.i, 0, !dbg !1861
  br i1 %tobool172.not.i, label %if.end196.i, label %if.then173.i, !dbg !1862

if.then173.i:                                     ; preds = %cond.end.i
  %data174.i = getelementptr inbounds i8, ptr %call142.i, i64 48, !dbg !1863
  %nkey175.i = getelementptr inbounds i8, ptr %call142.i, i64 41, !dbg !1863
  %64 = load i8, ptr %nkey175.i, align 1, !dbg !1863, !tbaa !485
  %idx.ext.i44 = zext i8 %64 to i64
  %add.ptr177.i = getelementptr inbounds i8, ptr %data174.i, i64 %idx.ext.i44, !dbg !1863
  %add.ptr178.i = getelementptr inbounds i8, ptr %add.ptr177.i, i64 1, !dbg !1863
  %and181.i = lshr i32 %conv170.i, 6, !dbg !1863
  %65 = and i32 %and181.i, 4, !dbg !1863
  %cond183.i = zext nneg i32 %65 to i64, !dbg !1863
  %add.ptr184.i = getelementptr inbounds i8, ptr %add.ptr178.i, i64 %cond183.i, !dbg !1863
  %and187.i = shl nuw nsw i32 %conv170.i, 2, !dbg !1863
  %66 = and i32 %and187.i, 8, !dbg !1863
  %cond189.i = zext nneg i32 %66 to i64, !dbg !1863
  %add.ptr190.i = getelementptr inbounds i8, ptr %add.ptr184.i, i64 %cond189.i, !dbg !1863
  tail call void @llvm.dbg.value(metadata ptr %add.ptr190.i, metadata !1692, metadata !DIExpression()), !dbg !1864
  %67 = load ptr, ptr %add.ptr190.i, align 8, !dbg !1865, !tbaa !421
  %prev192.i = getelementptr inbounds i8, ptr %67, i64 8, !dbg !1866
  store ptr %add.ptr190.i, ptr %prev192.i, align 8, !dbg !1867, !tbaa !421
  br label %while.body.i, !dbg !1868

while.body.i:                                     ; preds = %while.body.i, %if.then173.i
  %fch.0404.i = phi ptr [ %add.ptr190.i, %if.then173.i ], [ %68, %while.body.i ]
  tail call void @llvm.dbg.value(metadata ptr %fch.0404.i, metadata !1692, metadata !DIExpression()), !dbg !1864
  %head194.i = getelementptr inbounds i8, ptr %fch.0404.i, i64 16, !dbg !1869
  store ptr %call142.i, ptr %head194.i, align 8, !dbg !1871, !tbaa !421
  %68 = load ptr, ptr %fch.0404.i, align 8, !dbg !1872, !tbaa !421
  tail call void @llvm.dbg.value(metadata ptr %68, metadata !1692, metadata !DIExpression()), !dbg !1864
  %tobool193.not.i = icmp eq ptr %68, null, !dbg !1868
  br i1 %tobool193.not.i, label %if.end196.i, label %while.body.i, !dbg !1868, !llvm.loop !1873

if.end196.i:                                      ; preds = %while.body.i, %cond.end.i
  store i16 0, ptr %refcount39.i, align 4, !dbg !1875, !tbaa !553
  store i16 12, ptr %it_flags8.i, align 2, !dbg !1876, !tbaa !553
  %69 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 6), align 4, !dbg !1877, !tbaa !1878
  %inc199.i = add i32 %69, 1, !dbg !1877
  store i32 %inc199.i, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 6), align 4, !dbg !1877, !tbaa !1878
  br label %if.end216.i, !dbg !1879

if.else200.i:                                     ; preds = %land.lhs.true139.i
  tail call void @llvm.dbg.value(metadata ptr %call142.i, metadata !1690, metadata !DIExpression()), !dbg !1718
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1689, metadata !DIExpression()), !dbg !1718
  %call151.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1850
  tail call void @llvm.dbg.value(metadata ptr %call142.i, metadata !1700, metadata !DIExpression()), !dbg !1880
  %prev201.i = getelementptr inbounds i8, ptr %ch.0.i, i64 8, !dbg !1881
  %70 = load ptr, ptr %prev201.i, align 8, !dbg !1881, !tbaa !421
  store ptr %call142.i, ptr %70, align 8, !dbg !1882, !tbaa !421
  %71 = load ptr, ptr %ch.0.i, align 8, !dbg !1883, !tbaa !421
  %tobool204.not.i = icmp eq ptr %71, null, !dbg !1885
  br i1 %tobool204.not.i, label %if.end208.i, label %if.then205.i, !dbg !1886

if.then205.i:                                     ; preds = %if.else200.i
  %prev207.i = getelementptr inbounds i8, ptr %71, i64 8, !dbg !1887
  store ptr %call142.i, ptr %prev207.i, align 8, !dbg !1888, !tbaa !421
  br label %if.end208.i, !dbg !1889

if.end208.i:                                      ; preds = %if.then205.i, %if.else200.i
  %used.i = getelementptr inbounds i8, ptr %ch.0.i, i64 28, !dbg !1890
  %72 = load i32, ptr %used.i, align 4, !dbg !1890, !tbaa !456
  %conv209.i = sext i32 %72 to i64, !dbg !1891
  %add210.i = add nsw i64 %conv209.i, 48, !dbg !1892
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %call142.i, ptr nonnull align 8 %ch.0.i, i64 %add210.i, i1 false), !dbg !1893
  %refcount211.i = getelementptr inbounds i8, ptr %ch.0.i, i64 36, !dbg !1894
  store i16 0, ptr %refcount211.i, align 4, !dbg !1895, !tbaa !553
  %it_flags212.i = getelementptr inbounds i8, ptr %ch.0.i, i64 38, !dbg !1896
  store i16 12, ptr %it_flags212.i, align 2, !dbg !1897, !tbaa !553
  %73 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 9), align 8, !dbg !1898, !tbaa !1899
  %inc213.i = add i32 %73, 1, !dbg !1898
  store i32 %inc213.i, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 9), align 8, !dbg !1898, !tbaa !1899
  %74 = load i16, ptr %refcount39.i, align 4, !dbg !1900, !tbaa !553
  %dec215.i = add i16 %74, -1, !dbg !1900
  store i16 %dec215.i, ptr %refcount39.i, align 4, !dbg !1900, !tbaa !553
  br label %if.end216.i

if.end216.i:                                      ; preds = %if.end208.i, %if.end196.i
  %75 = load ptr, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 13), align 8, !dbg !1901, !tbaa !1640
  %arrayidx218.i = getelementptr inbounds i8, ptr %75, i64 %idxprom2.i, !dbg !1902
  store i8 1, ptr %arrayidx218.i, align 1, !dbg !1903, !tbaa !485
  br label %if.end258.i, !dbg !1904

do.body220.sink.split.i:                          ; preds = %land.lhs.true139.i, %land.lhs.true130.i
  %76 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 7), align 8, !dbg !1845, !tbaa !1905
  %inc135.i = add i32 %76, 1, !dbg !1845
  store i32 %inc135.i, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 7), align 8, !dbg !1845, !tbaa !1905
  br label %do.body220.i, !dbg !1850

do.body220.i:                                     ; preds = %do.body220.sink.split.i, %lor.lhs.false.i42, %land.lhs.true120.i
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !1690, metadata !DIExpression()), !dbg !1718
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1689, metadata !DIExpression()), !dbg !1718
  %call151399.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1850
  %77 = load ptr, ptr @storage, align 8, !dbg !1906, !tbaa !421
  tail call void @storage_delete(ptr noundef %77, ptr noundef nonnull %it.0.i) #23, !dbg !1906
  %.pre405.i = load i16, ptr %it_flags8.i, align 2, !dbg !1909, !tbaa !553
  %78 = and i16 %.pre405.i, 32
  %cmp228.i = icmp ne i16 %78, 0
  %or.cond409.not.i = select i1 %cmp107.i, i1 true, i1 %cmp228.i, !dbg !1912
  tail call void @do_item_unlink(ptr noundef nonnull %it.0.i, i32 noundef %call29.i40) #23, !dbg !1913
  br i1 %or.cond409.not.i, label %if.else235.i, label %if.then230.i, !dbg !1912

if.then230.i:                                     ; preds = %do.body220.i
  store i16 12, ptr %it_flags8.i, align 2, !dbg !1914, !tbaa !553
  store i16 0, ptr %refcount39.i, align 4, !dbg !1916, !tbaa !553
  %79 = load ptr, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 13), align 8, !dbg !1917, !tbaa !1640
  %arrayidx234.i = getelementptr inbounds i8, ptr %79, i64 %idxprom2.i, !dbg !1918
  store i8 1, ptr %arrayidx234.i, align 1, !dbg !1919, !tbaa !485
  br label %if.end258.i, !dbg !1920

if.else235.i:                                     ; preds = %do.body220.i
  tail call void @llvm.dbg.value(metadata !DIArgList(i16 poison, i32 poison, i64 poison, i16 poison), metadata !1691, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 6, DW_OP_shr, DW_OP_constu, 4, DW_OP_and, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_constu, 8, DW_OP_and, DW_OP_or, DW_OP_constu, 49, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_arg, 2, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_signed, DW_OP_LLVM_convert, 64, DW_ATE_signed, DW_OP_plus, DW_OP_stack_value)), !dbg !1718
  %80 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 3), align 8, !dbg !1921, !tbaa !1504
  tail call void @llvm.dbg.value(metadata ptr %it.0.i, metadata !1086, metadata !DIExpression()), !dbg !1922
  tail call void @llvm.dbg.value(metadata !DIArgList(i16 poison, i32 poison, i64 poison, i16 poison), metadata !1087, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 6, DW_OP_shr, DW_OP_constu, 4, DW_OP_and, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_constu, 8, DW_OP_and, DW_OP_or, DW_OP_constu, 49, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_arg, 2, DW_OP_plus, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_signed, DW_OP_LLVM_convert, 64, DW_ATE_signed, DW_OP_plus, DW_OP_stack_value)), !dbg !1922
  tail call void @llvm.dbg.value(metadata i32 %80, metadata !1088, metadata !DIExpression()), !dbg !1922
  %call.i.i43 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_lock) #23, !dbg !1924
  tail call fastcc void @do_slabs_free(ptr noundef nonnull %it.0.i, i32 noundef %80), !dbg !1925
  %call1.i.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1926
  %81 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 5), align 8, !dbg !1927, !tbaa !1928
  %inc255.i = add i32 %81, 1, !dbg !1927
  store i32 %inc255.i, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 5), align 8, !dbg !1927, !tbaa !1928
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1668, metadata !DIExpression()), !dbg !1702
  br label %if.end258.i

if.end258.i:                                      ; preds = %if.else235.i, %if.then230.i, %if.end216.i
  %was_busy.0.i = phi i32 [ 0, %if.end216.i ], [ 1, %if.else235.i ], [ 0, %if.then230.i ], !dbg !1702
  tail call void @llvm.dbg.value(metadata i32 %was_busy.0.i, metadata !1668, metadata !DIExpression()), !dbg !1702
  tail call void @item_trylock_unlock(ptr noundef nonnull %call30.i) #23, !dbg !1929
  %call259.i = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_lock) #23, !dbg !1930
  br label %sw.epilog.i, !dbg !1931

sw.bb265.i:                                       ; preds = %if.then73.i, %if.then23.i, %if.else.i
  %82 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 5), align 8, !dbg !1932, !tbaa !1928
  %inc266.i = add i32 %82, 1, !dbg !1932
  store i32 %inc266.i, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 5), align 8, !dbg !1932, !tbaa !1928
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1668, metadata !DIExpression()), !dbg !1702
  br label %sw.epilog.i, !dbg !1933

sw.epilog.i:                                      ; preds = %sw.bb265.i, %if.end258.i, %if.end80.thread392.i, %if.end.i35
  %was_busy.1.i = phi i32 [ 1, %sw.bb265.i ], [ 0, %if.end80.thread392.i ], [ %was_busy.0.i, %if.end258.i ], [ 0, %if.end.i35 ], !dbg !1702
  tail call void @llvm.dbg.value(metadata i32 %was_busy.1.i, metadata !1668, metadata !DIExpression()), !dbg !1702
  %call268.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !1934
  %.pre406.i = load ptr, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 2), align 8, !dbg !1935, !tbaa !1632
  %.pre407.i = load i32, ptr %arrayidx.i31, align 8, !dbg !1936, !tbaa !449
  %.pre408.i = zext i32 %.pre407.i to i64, !dbg !1937
  br label %if.end269.i, !dbg !1938

if.end269.i:                                      ; preds = %sw.epilog.i, %if.then7
  %idx.ext271.pre-phi.i = phi i64 [ %.pre408.i, %sw.epilog.i ], [ %conv.i32, %if.then7 ], !dbg !1937
  %83 = phi ptr [ %.pre406.i, %sw.epilog.i ], [ %21, %if.then7 ], !dbg !1935
  %was_busy.2.i = phi i32 [ %was_busy.1.i, %sw.epilog.i ], [ 0, %if.then7 ], !dbg !1939
  tail call void @llvm.dbg.value(metadata i32 %was_busy.2.i, metadata !1668, metadata !DIExpression()), !dbg !1702
  %add.ptr272.i = getelementptr inbounds i8, ptr %83, i64 %idx.ext271.pre-phi.i, !dbg !1937
  store ptr %add.ptr272.i, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 2), align 8, !dbg !1940, !tbaa !1632
  %84 = load ptr, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 1), align 8, !dbg !1941, !tbaa !1630
  %cmp273.not.i = icmp ult ptr %add.ptr272.i, %84, !dbg !1943
  br i1 %cmp273.not.i, label %if.end10thread-pre-split, label %if.then275.i, !dbg !1944

if.then275.i:                                     ; preds = %if.end269.i
  %85 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 5), align 8, !dbg !1945, !tbaa !1928
  %tobool276.not.i = icmp eq i32 %85, 0, !dbg !1948
  br i1 %tobool276.not.i, label %if.else281.i, label %if.then277.i, !dbg !1949

if.then277.i:                                     ; preds = %if.then275.i
  %86 = load ptr, ptr @slab_rebal, align 8, !dbg !1950, !tbaa !1528
  store ptr %86, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 2), align 8, !dbg !1952, !tbaa !1632
  tail call void @STATS_LOCK() #23, !dbg !1953
  %87 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 5), align 8, !dbg !1954, !tbaa !1928
  %conv278.i = zext i32 %87 to i64, !dbg !1955
  %88 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 10), align 8, !dbg !1956, !tbaa !1957
  %add279.i = add i64 %88, %conv278.i, !dbg !1956
  store i64 %add279.i, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 10), align 8, !dbg !1956, !tbaa !1957
  tail call void @STATS_UNLOCK() #23, !dbg !1960
  store i32 0, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 5), align 8, !dbg !1961, !tbaa !1928
  %89 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 11), align 8, !dbg !1962, !tbaa !1794
  %inc280.i = add i32 %89, 1, !dbg !1962
  store i32 %inc280.i, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 11), align 8, !dbg !1962, !tbaa !1794
  br label %if.end10thread-pre-split, !dbg !1963

if.else281.i:                                     ; preds = %if.then275.i
  %90 = load i8, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 12), align 4, !dbg !1964, !tbaa !1966
  %inc282.i = add i8 %90, 1, !dbg !1964
  store i8 %inc282.i, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 12), align 4, !dbg !1964, !tbaa !1966
  br label %if.end10

if.end10thread-pre-split:                         ; preds = %land.lhs.true, %if.else, %if.then4, %slab_rebalance_start.exit, %if.end269.i, %if.then277.i
  %was_busy.1.ph = phi i32 [ %was_busy.2.i, %if.then277.i ], [ %was_busy.2.i, %if.end269.i ], [ 0, %slab_rebalance_start.exit ], [ 0, %if.then4 ], [ %was_busy.0, %if.else ], [ %was_busy.0, %land.lhs.true ]
  %.pr = load i8, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 12), align 4, !dbg !1967, !tbaa !1966
  br label %if.end10, !dbg !1967

if.end10:                                         ; preds = %if.end10thread-pre-split, %if.else281.i
  %91 = phi i8 [ %.pr, %if.end10thread-pre-split ], [ %inc282.i, %if.else281.i ], !dbg !1967
  %was_busy.1 = phi i32 [ %was_busy.1.ph, %if.end10thread-pre-split ], [ %was_busy.2.i, %if.else281.i ], !dbg !1566
  tail call void @llvm.dbg.value(metadata i32 %was_busy.1, metadata !1563, metadata !DIExpression()), !dbg !1566
  %tobool11.not = icmp eq i8 %91, 0, !dbg !1969
  br i1 %tobool11.not, label %if.else13, label %if.then12, !dbg !1970

if.then12:                                        ; preds = %if.end10
  %call.i45 = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_lock) #23, !dbg !1971
  %92 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 3), align 8, !dbg !1984, !tbaa !1504
  %idxprom.i46 = sext i32 %92 to i64, !dbg !1985
  %arrayidx.i47 = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom.i46, !dbg !1985
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i47, metadata !1974, metadata !DIExpression()), !dbg !1986
  %93 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 4), align 4, !dbg !1987, !tbaa !1507
  %idxprom1.i = sext i32 %93 to i64, !dbg !1988
  %arrayidx2.i = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom1.i, !dbg !1988
  tail call void @llvm.dbg.value(metadata ptr %arrayidx2.i, metadata !1975, metadata !DIExpression()), !dbg !1986
  %slabs.i48 = getelementptr inbounds i8, ptr %arrayidx.i47, i64 20, !dbg !1989
  %94 = load i32, ptr %slabs.i48, align 4, !dbg !1990, !tbaa !504
  %dec.i49 = add i32 %94, -1, !dbg !1990
  store i32 %dec.i49, ptr %slabs.i48, align 4, !dbg !1990, !tbaa !504
  tail call void @llvm.dbg.value(metadata i32 0, metadata !1976, metadata !DIExpression()), !dbg !1986
  %cmp44.not.i = icmp eq i32 %dec.i49, 0, !dbg !1991
  br i1 %cmp44.not.i, label %for.end.i, label %for.body.lr.ph.i, !dbg !1994

for.body.lr.ph.i:                                 ; preds = %if.then12
  %slab_list.i50 = getelementptr inbounds i8, ptr %arrayidx.i47, i64 24
  %wide.trip.count.i = zext i32 %dec.i49 to i64, !dbg !1991
  %xtraiter = and i64 %wide.trip.count.i, 3, !dbg !1994
  %95 = icmp ult i32 %dec.i49, 4, !dbg !1994
  br i1 %95, label %for.end.i.loopexit.unr-lcssa, label %for.body.lr.ph.i.new, !dbg !1994

for.body.lr.ph.i.new:                             ; preds = %for.body.lr.ph.i
  %unroll_iter = and i64 %wide.trip.count.i, 4294967292, !dbg !1994
  %96 = load ptr, ptr %slab_list.i50, align 8, !tbaa !509
  br label %for.body.i, !dbg !1994

for.body.i:                                       ; preds = %for.body.i, %for.body.lr.ph.i.new
  %indvars.iv.i = phi i64 [ 0, %for.body.lr.ph.i.new ], [ %indvars.iv.next.i.3, %for.body.i ]
  %niter = phi i64 [ 0, %for.body.lr.ph.i.new ], [ %niter.next.3, %for.body.i ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i, metadata !1976, metadata !DIExpression()), !dbg !1986
  %indvars.iv.next.i = or disjoint i64 %indvars.iv.i, 1, !dbg !1995
  %arrayidx5.i = getelementptr inbounds ptr, ptr %96, i64 %indvars.iv.next.i, !dbg !1997
  %97 = load ptr, ptr %arrayidx5.i, align 8, !dbg !1997, !tbaa !421
  %arrayidx8.i = getelementptr inbounds ptr, ptr %96, i64 %indvars.iv.i, !dbg !1998
  store ptr %97, ptr %arrayidx8.i, align 8, !dbg !1999, !tbaa !421
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !1976, metadata !DIExpression()), !dbg !1986
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i, metadata !1976, metadata !DIExpression()), !dbg !1986
  %indvars.iv.next.i.1 = or disjoint i64 %indvars.iv.i, 2, !dbg !1995
  %arrayidx5.i.1 = getelementptr inbounds ptr, ptr %96, i64 %indvars.iv.next.i.1, !dbg !1997
  %98 = load ptr, ptr %arrayidx5.i.1, align 8, !dbg !1997, !tbaa !421
  %arrayidx8.i.1 = getelementptr inbounds ptr, ptr %96, i64 %indvars.iv.next.i, !dbg !1998
  store ptr %98, ptr %arrayidx8.i.1, align 8, !dbg !1999, !tbaa !421
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.1, metadata !1976, metadata !DIExpression()), !dbg !1986
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.1, metadata !1976, metadata !DIExpression()), !dbg !1986
  %indvars.iv.next.i.2 = or disjoint i64 %indvars.iv.i, 3, !dbg !1995
  %arrayidx5.i.2 = getelementptr inbounds ptr, ptr %96, i64 %indvars.iv.next.i.2, !dbg !1997
  %99 = load ptr, ptr %arrayidx5.i.2, align 8, !dbg !1997, !tbaa !421
  %arrayidx8.i.2 = getelementptr inbounds ptr, ptr %96, i64 %indvars.iv.next.i.1, !dbg !1998
  store ptr %99, ptr %arrayidx8.i.2, align 8, !dbg !1999, !tbaa !421
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.2, metadata !1976, metadata !DIExpression()), !dbg !1986
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.2, metadata !1976, metadata !DIExpression()), !dbg !1986
  %indvars.iv.next.i.3 = add nuw nsw i64 %indvars.iv.i, 4, !dbg !1995
  %arrayidx5.i.3 = getelementptr inbounds ptr, ptr %96, i64 %indvars.iv.next.i.3, !dbg !1997
  %100 = load ptr, ptr %arrayidx5.i.3, align 8, !dbg !1997, !tbaa !421
  %arrayidx8.i.3 = getelementptr inbounds ptr, ptr %96, i64 %indvars.iv.next.i.2, !dbg !1998
  store ptr %100, ptr %arrayidx8.i.3, align 8, !dbg !1999, !tbaa !421
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.3, metadata !1976, metadata !DIExpression()), !dbg !1986
  %niter.next.3 = add i64 %niter, 4, !dbg !1994
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter, !dbg !1994
  br i1 %niter.ncmp.3, label %for.end.i.loopexit.unr-lcssa, label %for.body.i, !dbg !1994, !llvm.loop !2000

for.end.i.loopexit.unr-lcssa:                     ; preds = %for.body.i, %for.body.lr.ph.i
  %indvars.iv.i.unr = phi i64 [ 0, %for.body.lr.ph.i ], [ %indvars.iv.next.i.3, %for.body.i ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0, !dbg !1994
  br i1 %lcmp.mod.not, label %for.end.i, label %for.body.i.epil.preheader, !dbg !1994

for.body.i.epil.preheader:                        ; preds = %for.end.i.loopexit.unr-lcssa
  %101 = load ptr, ptr %slab_list.i50, align 8, !tbaa !509
  br label %for.body.i.epil, !dbg !1994

for.body.i.epil:                                  ; preds = %for.body.i.epil, %for.body.i.epil.preheader
  %indvars.iv.i.epil = phi i64 [ %indvars.iv.i.unr, %for.body.i.epil.preheader ], [ %indvars.iv.next.i.epil, %for.body.i.epil ]
  %epil.iter = phi i64 [ 0, %for.body.i.epil.preheader ], [ %epil.iter.next, %for.body.i.epil ]
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.i.epil, metadata !1976, metadata !DIExpression()), !dbg !1986
  %indvars.iv.next.i.epil = add nuw nsw i64 %indvars.iv.i.epil, 1, !dbg !1995
  %arrayidx5.i.epil = getelementptr inbounds ptr, ptr %101, i64 %indvars.iv.next.i.epil, !dbg !1997
  %102 = load ptr, ptr %arrayidx5.i.epil, align 8, !dbg !1997, !tbaa !421
  %arrayidx8.i.epil = getelementptr inbounds ptr, ptr %101, i64 %indvars.iv.i.epil, !dbg !1998
  store ptr %102, ptr %arrayidx8.i.epil, align 8, !dbg !1999, !tbaa !421
  tail call void @llvm.dbg.value(metadata i64 %indvars.iv.next.i.epil, metadata !1976, metadata !DIExpression()), !dbg !1986
  %epil.iter.next = add i64 %epil.iter, 1, !dbg !1994
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter, !dbg !1994
  br i1 %epil.iter.cmp.not, label %for.end.i, label %for.body.i.epil, !dbg !1994, !llvm.loop !2002

for.end.i:                                        ; preds = %for.end.i.loopexit.unr-lcssa, %for.body.i.epil, %if.then12
  %103 = load ptr, ptr @slab_rebal, align 8, !dbg !2004, !tbaa !1528
  %slab_list9.i = getelementptr inbounds i8, ptr %arrayidx2.i, i64 24, !dbg !2005
  %104 = load ptr, ptr %slab_list9.i, align 8, !dbg !2005, !tbaa !509
  %slabs10.i = getelementptr inbounds i8, ptr %arrayidx2.i, i64 20, !dbg !2006
  %105 = load i32, ptr %slabs10.i, align 4, !dbg !2007, !tbaa !504
  %inc11.i = add i32 %105, 1, !dbg !2007
  store i32 %inc11.i, ptr %slabs10.i, align 4, !dbg !2007, !tbaa !504
  %idxprom12.i = zext i32 %105 to i64, !dbg !2008
  %arrayidx13.i = getelementptr inbounds ptr, ptr %104, i64 %idxprom12.i, !dbg !2008
  store ptr %103, ptr %arrayidx13.i, align 8, !dbg !2009, !tbaa !421
  %cmp14.i = icmp sgt i32 %93, 0, !dbg !2010
  br i1 %cmp14.i, label %if.then.i56, label %if.else.i51, !dbg !2012

if.then.i56:                                      ; preds = %for.end.i
  %106 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 23), align 4, !dbg !2013, !tbaa !797
  %conv.i57 = sext i32 %106 to i64, !dbg !2015
  tail call void @llvm.memset.p0.i64(ptr align 1 %103, i8 0, i64 %conv.i57, i1 false), !dbg !2016
  %107 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 4), align 4, !dbg !2017, !tbaa !1507
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !2018, metadata !DIExpression()), !dbg !2026
  tail call void @llvm.dbg.value(metadata i32 %107, metadata !2023, metadata !DIExpression()), !dbg !2026
  %idxprom.i.i58 = zext i32 %107 to i64, !dbg !2028
  %arrayidx.i.i59 = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom.i.i58, !dbg !2028
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i.i59, metadata !2024, metadata !DIExpression()), !dbg !2026
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2025, metadata !DIExpression()), !dbg !2026
  %perslab.i.i = getelementptr inbounds i8, ptr %arrayidx.i.i59, i64 4
  %108 = load i32, ptr %perslab.i.i, align 4, !dbg !2029, !tbaa !801
  %cmp5.not.i.i60 = icmp eq i32 %108, 0, !dbg !2032
  br i1 %cmp5.not.i.i60, label %if.end18.i, label %for.body.i.preheader.i, !dbg !2033

for.body.i.preheader.i:                           ; preds = %if.then.i56
  %109 = load ptr, ptr @slab_rebal, align 8, !dbg !2034, !tbaa !1528
  tail call void @llvm.dbg.value(metadata ptr %109, metadata !2018, metadata !DIExpression()), !dbg !2026
  br label %for.body.i.i, !dbg !2033

for.body.i.i:                                     ; preds = %for.body.i.i, %for.body.i.preheader.i
  %x.07.i.i = phi i32 [ %inc.i.i, %for.body.i.i ], [ 0, %for.body.i.preheader.i ]
  %ptr.addr.06.i.i = phi ptr [ %add.ptr.i.i, %for.body.i.i ], [ %109, %for.body.i.preheader.i ]
  tail call void @llvm.dbg.value(metadata i32 %x.07.i.i, metadata !2025, metadata !DIExpression()), !dbg !2026
  tail call void @llvm.dbg.value(metadata ptr %ptr.addr.06.i.i, metadata !2018, metadata !DIExpression()), !dbg !2026
  tail call fastcc void @do_slabs_free(ptr noundef %ptr.addr.06.i.i, i32 noundef %107), !dbg !2035
  %110 = load i32, ptr %arrayidx.i.i59, align 8, !dbg !2037, !tbaa !449
  %idx.ext.i.i = zext i32 %110 to i64, !dbg !2038
  %add.ptr.i.i = getelementptr inbounds i8, ptr %ptr.addr.06.i.i, i64 %idx.ext.i.i, !dbg !2038
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i.i, metadata !2018, metadata !DIExpression()), !dbg !2026
  %inc.i.i = add nuw nsw i32 %x.07.i.i, 1, !dbg !2039
  tail call void @llvm.dbg.value(metadata i32 %inc.i.i, metadata !2025, metadata !DIExpression()), !dbg !2026
  %111 = load i32, ptr %perslab.i.i, align 4, !dbg !2029, !tbaa !801
  %cmp.i.i61 = icmp ult i32 %inc.i.i, %111, !dbg !2032
  br i1 %cmp.i.i61, label %for.body.i.i, label %if.end18.i, !dbg !2033, !llvm.loop !2040

if.else.i51:                                      ; preds = %for.end.i
  %cmp15.i = icmp eq i32 %93, 0, !dbg !2042
  br i1 %cmp15.i, label %if.then17.i53, label %if.end18.i, !dbg !2044

if.then17.i53:                                    ; preds = %if.else.i51
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(48) %103, i8 0, i64 48, i1 false), !dbg !2045
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1361, metadata !DIExpression()), !dbg !2047
  %112 = load ptr, ptr @mem_base, align 8, !dbg !2049, !tbaa !421
  %cmp.not.i.i = icmp eq ptr %112, null, !dbg !2051
  br i1 %cmp.not.i.i, label %if.end.i.i54, label %if.end18.i, !dbg !2052

if.end.i.i54:                                     ; preds = %if.then17.i53
  %113 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 30), align 1, !dbg !2053, !tbaa !1368, !range !1369, !noundef !1370
  %tobool.i.i = trunc nuw i8 %113 to i1, !dbg !2053
  br i1 %tobool.i.i, label %while.cond.preheader.i.i, label %if.end18.i, !dbg !2054

while.cond.preheader.i.i:                         ; preds = %if.end.i.i54
  %114 = load i64, ptr @mem_limit, align 8, !tbaa !685
  %mem_malloced.promoted.i.i = load i64, ptr @mem_malloced, align 8, !tbaa !685
  %cmp38.i.i = icmp ugt i64 %mem_malloced.promoted.i.i, %114, !dbg !2055
  br i1 %cmp38.i.i, label %land.rhs.i.i.preheader, label %if.end18.i, !dbg !2056

land.rhs.i.i.preheader:                           ; preds = %while.cond.preheader.i.i
  %.promoted = load i32, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 4), align 4, !tbaa !504
  br label %land.rhs.i.i, !dbg !2057

land.rhs.i.i:                                     ; preds = %land.rhs.i.i.preheader, %while.body.i.i
  %sub.i.i.i75 = phi i32 [ %sub.i.i.i, %while.body.i.i ], [ %.promoted, %land.rhs.i.i.preheader ]
  %sub79.i.i = phi i64 [ %sub.i.i, %while.body.i.i ], [ %mem_malloced.promoted.i.i, %land.rhs.i.i.preheader ]
  tail call void @llvm.dbg.value(metadata ptr @slabclass, metadata !1375, metadata !DIExpression()), !dbg !2058
  %cmp.i.i.i = icmp eq i32 %sub.i.i.i75, 0, !dbg !2060
  br i1 %cmp.i.i.i, label %if.end18.i, label %get_page_from_global_pool.exit.i.i, !dbg !2061

get_page_from_global_pool.exit.i.i:               ; preds = %land.rhs.i.i
  %115 = load ptr, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 5), align 8, !dbg !2062, !tbaa !509
  %sub.i.i.i = add i32 %sub.i.i.i75, -1, !dbg !2063
  %idxprom.i.i.i = zext i32 %sub.i.i.i to i64, !dbg !2064
  %arrayidx.i.i.i = getelementptr inbounds ptr, ptr %115, i64 %idxprom.i.i.i, !dbg !2064
  %116 = load ptr, ptr %arrayidx.i.i.i, align 8, !dbg !2064, !tbaa !421
  tail call void @llvm.dbg.value(metadata ptr %116, metadata !1380, metadata !DIExpression()), !dbg !2058
  store i32 %sub.i.i.i, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 4), align 4, !dbg !2065, !tbaa !504
  tail call void @llvm.dbg.value(metadata ptr %116, metadata !1361, metadata !DIExpression()), !dbg !2047
  %cmp4.not.i.i = icmp eq ptr %116, null, !dbg !2066
  br i1 %cmp4.not.i.i, label %if.end18.i, label %while.body.i.i, !dbg !2057

while.body.i.i:                                   ; preds = %get_page_from_global_pool.exit.i.i
  tail call void @free(ptr noundef nonnull %116) #23, !dbg !2067
  %117 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 23), align 4, !dbg !2068, !tbaa !797
  %conv.i.i55 = sext i32 %117 to i64, !dbg !2069
  %sub.i.i = sub i64 %sub79.i.i, %conv.i.i55, !dbg !2070
  store i64 %sub.i.i, ptr @mem_malloced, align 8, !dbg !2070, !tbaa !685
  %cmp3.i.i = icmp ugt i64 %sub.i.i, %114, !dbg !2055
  br i1 %cmp3.i.i, label %land.rhs.i.i, label %if.end18.i, !dbg !2056, !llvm.loop !2071

if.end18.i:                                       ; preds = %while.body.i.i, %get_page_from_global_pool.exit.i.i, %land.rhs.i.i, %for.body.i.i, %while.cond.preheader.i.i, %if.end.i.i54, %if.then17.i53, %if.else.i51, %if.then.i56
  store i32 0, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 11), align 8, !dbg !2073, !tbaa !1794
  store i8 0, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 12), align 4, !dbg !2074, !tbaa !1966
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) @slab_rebal, i8 0, i64 32, i1 false), !dbg !2075
  tail call void @llvm.dbg.value(metadata i32 undef, metadata !1978, metadata !DIExpression()), !dbg !1986
  tail call void @llvm.dbg.value(metadata i32 undef, metadata !1979, metadata !DIExpression()), !dbg !1986
  %118 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 6), align 4, !dbg !2076, !tbaa !1878
  tail call void @llvm.dbg.value(metadata i32 %118, metadata !1977, metadata !DIExpression()), !dbg !1986
  %119 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 9), align 8, !dbg !2077, !tbaa !1899
  tail call void @llvm.dbg.value(metadata i32 %119, metadata !1980, metadata !DIExpression()), !dbg !1986
  %120 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 10), align 4, !dbg !2078, !tbaa !1799
  tail call void @llvm.dbg.value(metadata i32 %120, metadata !1981, metadata !DIExpression()), !dbg !1986
  %conv21.i = zext i32 %118 to i64, !dbg !2079
  %121 = insertelement <2 x i64> <i64 1, i64 poison>, i64 %conv21.i, i64 1, !dbg !2080
  %122 = load <2 x i32>, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 7), align 8, !dbg !2081, !tbaa !456
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(20) getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 6), i8 0, i64 20, i1 false), !dbg !2082
  store volatile i32 0, ptr @slab_rebalance_signal, align 4, !dbg !2083, !tbaa !456
  %123 = load ptr, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 13), align 8, !dbg !2084, !tbaa !1640
  tail call void @free(ptr noundef %123) #23, !dbg !2085
  %call19.i = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_lock) #23, !dbg !2086
  tail call void @STATS_LOCK() #23, !dbg !2087
  %124 = load <2 x i64>, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 5), align 8, !dbg !2080, !tbaa !685
  %125 = add <2 x i64> %124, %121, !dbg !2080
  store <2 x i64> %125, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 5), align 8, !dbg !2080, !tbaa !685
  %126 = zext <2 x i32> %122 to <2 x i64>, !dbg !2088
  %127 = load <2 x i64>, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 7), align 8, !dbg !2089, !tbaa !685
  %128 = add <2 x i64> %127, %126, !dbg !2089
  store <2 x i64> %128, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 7), align 8, !dbg !2089, !tbaa !685
  %conv27.i = zext i32 %119 to i64, !dbg !2090
  %129 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 9), align 8, !dbg !2091, !tbaa !2092
  %add28.i = add i64 %129, %conv27.i, !dbg !2091
  store i64 %add28.i, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 9), align 8, !dbg !2091, !tbaa !2092
  %conv29.i = zext i32 %120 to i64, !dbg !2093
  %130 = load i64, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 11), align 8, !dbg !2094, !tbaa !2095
  %add30.i = add i64 %130, %conv29.i, !dbg !2094
  store i64 %add30.i, ptr getelementptr inbounds (%struct.stats, ptr @stats, i64 0, i32 11), align 8, !dbg !2094, !tbaa !2095
  store i8 0, ptr getelementptr inbounds (%struct.stats_state, ptr @stats_state, i64 0, i32 10), align 2, !dbg !2096, !tbaa !1653
  tail call void @STATS_UNLOCK() #23, !dbg !2097
  %131 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 5), align 8, !dbg !2098, !tbaa !721
  %cmp31.i52 = icmp sgt i32 %131, 1, !dbg !2100
  br i1 %cmp31.i52, label %if.then33.i, label %if.end21, !dbg !2101

if.then33.i:                                      ; preds = %if.end18.i
  %132 = load ptr, ptr @stderr, align 8, !dbg !2102, !tbaa !421
  %133 = tail call i64 @fwrite(ptr nonnull @.str.37, i64 21, i64 1, ptr %132) #25, !dbg !2104
  br label %if.end21, !dbg !2105

if.else13:                                        ; preds = %if.end10
  %tobool14.not = icmp eq i32 %was_busy.1, 0, !dbg !2106
  br i1 %tobool14.not, label %if.end21, label %if.then15, !dbg !2108

if.then15:                                        ; preds = %if.else13
  %call16 = tail call i32 @usleep(i32 noundef %backoff_timer.0) #23, !dbg !2109
  %mul = shl nsw i32 %backoff_timer.0, 1, !dbg !2111
  tail call void @llvm.dbg.value(metadata i32 %mul, metadata !1564, metadata !DIExpression()), !dbg !1566
  %cmp17 = icmp sgt i32 %backoff_timer.0, 500, !dbg !2112
  %spec.select = select i1 %cmp17, i32 1000, i32 %mul, !dbg !2114
  br label %if.end21, !dbg !2114

if.end21:                                         ; preds = %if.then33.i, %if.end18.i, %if.then15, %if.else13
  %backoff_timer.1 = phi i32 [ %backoff_timer.0, %if.else13 ], [ %spec.select, %if.then15 ], [ %backoff_timer.0, %if.end18.i ], [ %backoff_timer.0, %if.then33.i ], !dbg !1566
  tail call void @llvm.dbg.value(metadata i32 %backoff_timer.1, metadata !1564, metadata !DIExpression()), !dbg !1566
  %134 = load volatile i32, ptr @slab_rebalance_signal, align 4, !dbg !2115, !tbaa !456
  %cmp22 = icmp eq i32 %134, 0, !dbg !2117
  br i1 %cmp22, label %if.then23, label %while.cond.backedge, !dbg !2118

if.then23:                                        ; preds = %if.end21
  %call24 = tail call i32 @pthread_cond_wait(ptr noundef nonnull @slab_rebalance_cond, ptr noundef nonnull @slabs_rebalance_lock) #23, !dbg !2119
  br label %while.cond.backedge, !dbg !2121

while.cond.backedge:                              ; preds = %if.then23, %if.end21
  br label %while.cond, !dbg !1570, !llvm.loop !2122

while.end:                                        ; preds = %lor.rhs
  %call26 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_rebalance_lock) #23, !dbg !2124
  ret ptr null, !dbg !2125
}

; Function Attrs: nounwind
declare !dbg !2126 ptr @strerror(i32 noundef) local_unnamed_addr #10

declare !dbg !2130 void @thread_setname(i64 noundef, ptr noundef) local_unnamed_addr #9

; Function Attrs: nounwind sanitize_thread uwtable
define dso_local void @stop_slab_maintenance_thread() local_unnamed_addr #5 !dbg !2133 {
entry:
  %call = tail call i32 @pthread_mutex_lock(ptr noundef nonnull @slabs_rebalance_lock) #23, !dbg !2134
  store volatile i32 0, ptr @do_run_slab_rebalance_thread, align 4, !dbg !2135, !tbaa !456
  %call1 = tail call i32 @pthread_cond_signal(ptr noundef nonnull @slab_rebalance_cond) #23, !dbg !2136
  %call2 = tail call i32 @pthread_mutex_unlock(ptr noundef nonnull @slabs_rebalance_lock) #23, !dbg !2137
  %0 = load i64, ptr @rebalance_tid, align 8, !dbg !2138, !tbaa !685
  %call3 = tail call i32 @pthread_join(i64 noundef %0, ptr noundef null) #23, !dbg !2139
  ret void, !dbg !2140
}

; Function Attrs: nounwind
declare !dbg !2141 i32 @pthread_cond_signal(ptr noundef) local_unnamed_addr #10

declare !dbg !2145 i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #9

; Function Attrs: nofree nounwind
declare !dbg !2148 noalias noundef ptr @fopen(ptr nocapture noundef readonly, ptr nocapture noundef readonly) local_unnamed_addr #6

; Function Attrs: nofree nounwind
declare !dbg !2151 noundef ptr @fgets(ptr noundef, i32 noundef, ptr nocapture noundef) local_unnamed_addr #6

; Function Attrs: nounwind
declare !dbg !2155 i32 @__isoc23_sscanf(ptr noundef, ptr noundef, ...) local_unnamed_addr #10

; Function Attrs: nofree nounwind
declare !dbg !2158 noundef i32 @fclose(ptr nocapture noundef) local_unnamed_addr #6

; Function Attrs: nofree nounwind
declare !dbg !2161 i32 @posix_memalign(ptr noundef, i64 noundef, i64 noundef) local_unnamed_addr #6

; Function Attrs: nounwind
declare !dbg !2164 i32 @madvise(ptr noundef, i64 noundef, i32 noundef) local_unnamed_addr #10

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !2168 void @free(ptr allocptr nocapture noundef) local_unnamed_addr #12

; Function Attrs: nounwind sanitize_thread uwtable
define internal fastcc range(i32 0, 2) i32 @do_slabs_newslab(i32 noundef %id) unnamed_addr #5 !dbg !2169 {
entry:
  tail call void @llvm.dbg.value(metadata i32 %id, metadata !2171, metadata !DIExpression()), !dbg !2176
  %idxprom = zext i32 %id to i64, !dbg !2177
  %arrayidx = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom, !dbg !2177
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !2172, metadata !DIExpression()), !dbg !2176
  tail call void @llvm.dbg.value(metadata ptr @slabclass, metadata !2173, metadata !DIExpression()), !dbg !2176
  %0 = load i8, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 30), align 1, !dbg !2178, !tbaa !1368, !range !1369, !noundef !1370
  %tobool = trunc nuw i8 %0 to i1, !dbg !2178
  %.pre = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 23), align 4, !dbg !2179, !tbaa !797
  br i1 %tobool, label %cond.end, label %lor.lhs.false, !dbg !2180

lor.lhs.false:                                    ; preds = %entry
  %1 = load i32, ptr getelementptr inbounds (%struct.settings, ptr @settings, i64 0, i32 22), align 8, !dbg !2181, !tbaa !788
  %cmp.not = icmp eq i32 %1, %.pre, !dbg !2182
  br i1 %cmp.not, label %cond.false, label %cond.end, !dbg !2183

cond.false:                                       ; preds = %lor.lhs.false
  %2 = load i32, ptr %arrayidx, align 8, !dbg !2184, !tbaa !449
  %perslab = getelementptr inbounds i8, ptr %arrayidx, i64 4, !dbg !2185
  %3 = load i32, ptr %perslab, align 4, !dbg !2185, !tbaa !801
  %mul = mul i32 %3, %2, !dbg !2186
  br label %cond.end, !dbg !2183

cond.end:                                         ; preds = %entry, %lor.lhs.false, %cond.false
  %cond = phi i32 [ %mul, %cond.false ], [ %.pre, %lor.lhs.false ], [ %.pre, %entry ], !dbg !2183
  tail call void @llvm.dbg.value(metadata i32 %cond, metadata !2174, metadata !DIExpression()), !dbg !2176
  %4 = load i64, ptr @mem_limit, align 8, !dbg !2187, !tbaa !685
  %tobool1.not = icmp eq i64 %4, 0, !dbg !2187
  br i1 %tobool1.not, label %if.end, label %land.lhs.true, !dbg !2189

land.lhs.true:                                    ; preds = %cond.end
  %5 = load i64, ptr @mem_malloced, align 8, !dbg !2190, !tbaa !685
  %conv = sext i32 %cond to i64, !dbg !2191
  %add = add i64 %5, %conv, !dbg !2192
  %cmp2 = icmp ugt i64 %add, %4, !dbg !2193
  br i1 %cmp2, label %land.lhs.true4, label %if.end, !dbg !2194

land.lhs.true4:                                   ; preds = %land.lhs.true
  %slabs = getelementptr inbounds i8, ptr %arrayidx, i64 20, !dbg !2195
  %6 = load i32, ptr %slabs, align 4, !dbg !2195, !tbaa !504
  %cmp5.not = icmp eq i32 %6, 0, !dbg !2196
  br i1 %cmp5.not, label %if.end, label %land.lhs.true7, !dbg !2197

land.lhs.true7:                                   ; preds = %land.lhs.true4
  %7 = load i32, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 4), align 4, !dbg !2198, !tbaa !504
  %cmp9 = icmp eq i32 %7, 0, !dbg !2199
  br i1 %cmp9, label %cleanup, label %if.end, !dbg !2200

if.end:                                           ; preds = %land.lhs.true7, %land.lhs.true4, %land.lhs.true, %cond.end
  tail call void @llvm.dbg.value(metadata i32 %id, metadata !489, metadata !DIExpression()), !dbg !2201
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !495, metadata !DIExpression()), !dbg !2201
  %slabs.i = getelementptr inbounds i8, ptr %arrayidx, i64 20, !dbg !2204
  %8 = load i32, ptr %slabs.i, align 4, !dbg !2204, !tbaa !504
  %list_size.i = getelementptr inbounds i8, ptr %arrayidx, i64 32, !dbg !2205
  %9 = load i32, ptr %list_size.i, align 8, !dbg !2205, !tbaa !506
  %cmp.i = icmp eq i32 %8, %9, !dbg !2206
  br i1 %cmp.i, label %if.then.i, label %lor.lhs.false13, !dbg !2207

if.then.i:                                        ; preds = %if.end
  %cmp2.not.i = icmp eq i32 %8, 0, !dbg !2208
  %mul.i = shl i32 %8, 1
  %spec.select.i = select i1 %cmp2.not.i, i32 16, i32 %mul.i, !dbg !2209
  %conv.i = zext i32 %spec.select.i to i64, !dbg !2209
  tail call void @llvm.dbg.value(metadata i64 %conv.i, metadata !496, metadata !DIExpression()), !dbg !2210
  %slab_list.i = getelementptr inbounds i8, ptr %arrayidx, i64 24, !dbg !2211
  %10 = load ptr, ptr %slab_list.i, align 8, !dbg !2211, !tbaa !509
  %mul4.i = shl nuw nsw i64 %conv.i, 3, !dbg !2212
  %call.i = tail call ptr @realloc(ptr noundef %10, i64 noundef %mul4.i) #22, !dbg !2213
  tail call void @llvm.dbg.value(metadata ptr %call.i, metadata !499, metadata !DIExpression()), !dbg !2210
  %cmp5.not.i = icmp eq ptr %call.i, null, !dbg !2214
  br i1 %cmp5.not.i, label %cleanup, label %if.end.i, !dbg !2215

if.end.i:                                         ; preds = %if.then.i
  store i32 %spec.select.i, ptr %list_size.i, align 8, !dbg !2216, !tbaa !506
  store ptr %call.i, ptr %slab_list.i, align 8, !dbg !2217, !tbaa !509
  br label %lor.lhs.false13

lor.lhs.false13:                                  ; preds = %if.end.i, %if.end
  tail call void @llvm.dbg.value(metadata ptr @slabclass, metadata !1375, metadata !DIExpression()), !dbg !2218
  %11 = load i32, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 4), align 4, !dbg !2220, !tbaa !504
  %cmp.i41 = icmp eq i32 %11, 0, !dbg !2221
  br i1 %cmp.i41, label %land.lhs.true17, label %get_page_from_global_pool.exit, !dbg !2222

get_page_from_global_pool.exit:                   ; preds = %lor.lhs.false13
  %12 = load ptr, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 5), align 8, !dbg !2223, !tbaa !509
  %sub.i = add i32 %11, -1, !dbg !2224
  %idxprom.i43 = zext i32 %sub.i to i64, !dbg !2225
  %arrayidx.i44 = getelementptr inbounds ptr, ptr %12, i64 %idxprom.i43, !dbg !2225
  %13 = load ptr, ptr %arrayidx.i44, align 8, !dbg !2225, !tbaa !421
  tail call void @llvm.dbg.value(metadata ptr %13, metadata !1380, metadata !DIExpression()), !dbg !2218
  store i32 %sub.i, ptr getelementptr inbounds ([64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 0, i32 4), align 4, !dbg !2226, !tbaa !504
  tail call void @llvm.dbg.value(metadata ptr %13, metadata !2175, metadata !DIExpression()), !dbg !2176
  %cmp15 = icmp eq ptr %13, null, !dbg !2227
  br i1 %cmp15, label %land.lhs.true17, label %get_page_from_global_pool.exit.if.end23_crit_edge, !dbg !2228

get_page_from_global_pool.exit.if.end23_crit_edge: ; preds = %get_page_from_global_pool.exit
  %.pre61 = sext i32 %cond to i64, !dbg !2229
  br label %if.end23, !dbg !2228

land.lhs.true17:                                  ; preds = %lor.lhs.false13, %get_page_from_global_pool.exit
  %conv18 = sext i32 %cond to i64, !dbg !2230
  tail call void @llvm.dbg.value(metadata i64 %conv18, metadata !908, metadata !DIExpression()), !dbg !2231
  %14 = load ptr, ptr @mem_base, align 8, !dbg !2233, !tbaa !421
  %cmp.i45 = icmp eq ptr %14, null, !dbg !2234
  br i1 %cmp.i45, label %if.then.i48, label %if.else.i, !dbg !2235

if.then.i48:                                      ; preds = %land.lhs.true17
  %call.i49 = tail call noalias ptr @malloc(i64 noundef %conv18) #28, !dbg !2236
  tail call void @llvm.dbg.value(metadata ptr %call.i49, metadata !913, metadata !DIExpression()), !dbg !2231
  br label %memory_allocate.exit, !dbg !2237

if.else.i:                                        ; preds = %land.lhs.true17
  %15 = load ptr, ptr @mem_current, align 8, !dbg !2238, !tbaa !421
  tail call void @llvm.dbg.value(metadata ptr %15, metadata !913, metadata !DIExpression()), !dbg !2231
  %16 = load i64, ptr @mem_avail, align 8, !dbg !2239, !tbaa !685
  %cmp1.i = icmp ult i64 %16, %conv18, !dbg !2240
  br i1 %cmp1.i, label %cleanup, label %if.end.i46, !dbg !2241

if.end.i46:                                       ; preds = %if.else.i
  %size.biased.i = add nsw i64 %conv18, 7, !dbg !2242
  %size.addr.0.i = and i64 %size.biased.i, -8, !dbg !2242
  tail call void @llvm.dbg.value(metadata i64 %size.addr.0.i, metadata !908, metadata !DIExpression()), !dbg !2231
  %add.ptr.i = getelementptr inbounds i8, ptr %15, i64 %size.addr.0.i, !dbg !2243
  store ptr %add.ptr.i, ptr @mem_current, align 8, !dbg !2244, !tbaa !421
  %cmp6.i = icmp ult i64 %size.addr.0.i, %16, !dbg !2245
  br i1 %cmp6.i, label %if.then7.i, label %if.else9.i, !dbg !2246

if.then7.i:                                       ; preds = %if.end.i46
  %sub8.i = sub i64 %16, %size.addr.0.i, !dbg !2247
  store i64 %sub8.i, ptr @mem_avail, align 8, !dbg !2247, !tbaa !685
  br label %memory_allocate.exit, !dbg !2248

if.else9.i:                                       ; preds = %if.end.i46
  store i64 0, ptr @mem_avail, align 8, !dbg !2249, !tbaa !685
  br label %memory_allocate.exit

memory_allocate.exit:                             ; preds = %if.then.i48, %if.then7.i, %if.else9.i
  %size.addr.1.i = phi i64 [ %conv18, %if.then.i48 ], [ %size.addr.0.i, %if.then7.i ], [ %size.addr.0.i, %if.else9.i ]
  %ret.0.i = phi ptr [ %call.i49, %if.then.i48 ], [ %15, %if.then7.i ], [ %15, %if.else9.i ], !dbg !2250
  tail call void @llvm.dbg.value(metadata ptr %ret.0.i, metadata !913, metadata !DIExpression()), !dbg !2231
  tail call void @llvm.dbg.value(metadata i64 %size.addr.1.i, metadata !908, metadata !DIExpression()), !dbg !2231
  %17 = load i64, ptr @mem_malloced, align 8, !dbg !2251, !tbaa !685
  %add12.i = add i64 %17, %size.addr.1.i, !dbg !2251
  store i64 %add12.i, ptr @mem_malloced, align 8, !dbg !2251, !tbaa !685
  tail call void @llvm.dbg.value(metadata ptr %ret.0.i, metadata !2175, metadata !DIExpression()), !dbg !2176
  %cmp20 = icmp eq ptr %ret.0.i, null, !dbg !2252
  br i1 %cmp20, label %cleanup, label %if.end23, !dbg !2253

if.end23:                                         ; preds = %get_page_from_global_pool.exit.if.end23_crit_edge, %memory_allocate.exit
  %conv24.pre-phi = phi i64 [ %.pre61, %get_page_from_global_pool.exit.if.end23_crit_edge ], [ %conv18, %memory_allocate.exit ], !dbg !2229
  %ptr.0 = phi ptr [ %13, %get_page_from_global_pool.exit.if.end23_crit_edge ], [ %ret.0.i, %memory_allocate.exit ], !dbg !2254
  tail call void @llvm.dbg.value(metadata ptr %ptr.0, metadata !2175, metadata !DIExpression()), !dbg !2176
  tail call void @llvm.memset.p0.i64(ptr nonnull align 1 %ptr.0, i8 0, i64 %conv24.pre-phi, i1 false), !dbg !2255
  tail call void @llvm.dbg.value(metadata ptr %ptr.0, metadata !2018, metadata !DIExpression()), !dbg !2256
  tail call void @llvm.dbg.value(metadata i32 %id, metadata !2023, metadata !DIExpression()), !dbg !2256
  tail call void @llvm.dbg.value(metadata ptr %arrayidx, metadata !2024, metadata !DIExpression()), !dbg !2256
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2025, metadata !DIExpression()), !dbg !2256
  %perslab.i = getelementptr inbounds i8, ptr %arrayidx, i64 4
  %18 = load i32, ptr %perslab.i, align 4, !dbg !2258, !tbaa !801
  %cmp5.not.i52 = icmp eq i32 %18, 0, !dbg !2259
  br i1 %cmp5.not.i52, label %split_slab_page_into_freelist.exit, label %for.body.i, !dbg !2260

for.body.i:                                       ; preds = %if.end23, %for.body.i
  %x.07.i = phi i32 [ %inc.i, %for.body.i ], [ 0, %if.end23 ]
  %ptr.addr.06.i = phi ptr [ %add.ptr.i53, %for.body.i ], [ %ptr.0, %if.end23 ]
  tail call void @llvm.dbg.value(metadata i32 %x.07.i, metadata !2025, metadata !DIExpression()), !dbg !2256
  tail call void @llvm.dbg.value(metadata ptr %ptr.addr.06.i, metadata !2018, metadata !DIExpression()), !dbg !2256
  tail call fastcc void @do_slabs_free(ptr noundef %ptr.addr.06.i, i32 noundef %id), !dbg !2261
  %19 = load i32, ptr %arrayidx, align 8, !dbg !2262, !tbaa !449
  %idx.ext.i = zext i32 %19 to i64, !dbg !2263
  %add.ptr.i53 = getelementptr inbounds i8, ptr %ptr.addr.06.i, i64 %idx.ext.i, !dbg !2263
  tail call void @llvm.dbg.value(metadata ptr %add.ptr.i53, metadata !2018, metadata !DIExpression()), !dbg !2256
  %inc.i = add nuw nsw i32 %x.07.i, 1, !dbg !2264
  tail call void @llvm.dbg.value(metadata i32 %inc.i, metadata !2025, metadata !DIExpression()), !dbg !2256
  %20 = load i32, ptr %perslab.i, align 4, !dbg !2258, !tbaa !801
  %cmp.i54 = icmp ult i32 %inc.i, %20, !dbg !2259
  br i1 %cmp.i54, label %for.body.i, label %split_slab_page_into_freelist.exit, !dbg !2260, !llvm.loop !2265

split_slab_page_into_freelist.exit:               ; preds = %for.body.i, %if.end23
  %slab_list = getelementptr inbounds i8, ptr %arrayidx, i64 24, !dbg !2267
  %21 = load ptr, ptr %slab_list, align 8, !dbg !2267, !tbaa !509
  %22 = load i32, ptr %slabs.i, align 4, !dbg !2268, !tbaa !504
  %inc = add i32 %22, 1, !dbg !2268
  store i32 %inc, ptr %slabs.i, align 4, !dbg !2268, !tbaa !504
  %idxprom26 = zext i32 %22 to i64, !dbg !2269
  %arrayidx27 = getelementptr inbounds ptr, ptr %21, i64 %idxprom26, !dbg !2269
  store ptr %ptr.0, ptr %arrayidx27, align 8, !dbg !2270, !tbaa !421
  br label %cleanup, !dbg !2271

cleanup:                                          ; preds = %if.else.i, %if.then.i, %memory_allocate.exit, %land.lhs.true7, %split_slab_page_into_freelist.exit
  %retval.0 = phi i32 [ 1, %split_slab_page_into_freelist.exit ], [ 0, %land.lhs.true7 ], [ 0, %memory_allocate.exit ], [ 0, %if.then.i ], [ 0, %if.else.i ], !dbg !2176
  ret i32 %retval.0, !dbg !2272
}

; Function Attrs: noreturn nounwind
declare !dbg !2273 void @exit(i32 noundef) local_unnamed_addr #13

; Function Attrs: mustprogress nounwind willreturn allockind("realloc") allocsize(1) memory(argmem: readwrite, inaccessiblemem: readwrite)
declare !dbg !2276 noalias noundef ptr @realloc(ptr allocptr nocapture noundef, i64 noundef) local_unnamed_addr #14

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare !dbg !2279 noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #15

declare !dbg !2280 void @threadlocal_stats_aggregate(ptr noundef) local_unnamed_addr #9

; Function Attrs: nofree nounwind
declare !dbg !2284 noundef i32 @snprintf(ptr noalias nocapture noundef writeonly, i64 noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #6

declare !dbg !2287 void @append_stat(ptr noundef, ptr noundef, ptr noundef, ptr noundef, ...) local_unnamed_addr #9

declare !dbg !2716 i32 @usleep(i32 noundef) local_unnamed_addr #9

declare !dbg !2721 i32 @pthread_cond_wait(ptr noundef, ptr noundef) local_unnamed_addr #9

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite)
declare !dbg !2726 noalias noundef ptr @calloc(i64 noundef, i64 noundef) local_unnamed_addr #16

declare !dbg !2729 void @STATS_LOCK() local_unnamed_addr #9

declare !dbg !2730 void @STATS_UNLOCK() local_unnamed_addr #9

declare !dbg !2731 ptr @item_trylock(i32 noundef) local_unnamed_addr #9

declare !dbg !2734 void @storage_delete(ptr noundef, ptr noundef) local_unnamed_addr #9

declare !dbg !2738 void @do_item_unlink(ptr noundef, i32 noundef) local_unnamed_addr #9

declare !dbg !2742 void @item_trylock_unlock(ptr noundef) local_unnamed_addr #9

declare !dbg !2743 i32 @item_is_flushed(ptr noundef) local_unnamed_addr #9

; Function Attrs: nofree norecurse nosync nounwind sanitize_thread memory(readwrite, inaccessiblemem: none) uwtable
define internal fastcc noundef ptr @slab_rebalance_alloc(i32 noundef %id) unnamed_addr #11 !dbg !2746 {
entry:
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2750, metadata !DIExpression()), !dbg !2755
  tail call void @llvm.dbg.value(metadata i32 %id, metadata !2751, metadata !DIExpression()), !dbg !2755
  %0 = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 3), align 8, !dbg !2756, !tbaa !1504
  %idxprom = sext i32 %0 to i64, !dbg !2757
  tail call void @llvm.dbg.value(metadata !DIArgList(ptr @slabclass, i64 %idxprom), metadata !2752, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 40, DW_OP_mul, DW_OP_plus, DW_OP_stack_value)), !dbg !2755
  tail call void @llvm.dbg.value(metadata ptr null, metadata !2754, metadata !DIExpression()), !dbg !2755
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2753, metadata !DIExpression()), !dbg !2755
  %idxprom.i = zext i32 %id to i64, !dbg !2758
  %arrayidx.i = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom.i, !dbg !2758
  %sl_curr.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 16, !dbg !2763
  %perslab = getelementptr inbounds [64 x %struct.slabclass_t], ptr @slabclass, i64 0, i64 %idxprom, i32 1
  %1 = load i32, ptr %perslab, align 4, !tbaa !801
  %cmp.i = icmp eq i32 %id, 0
  %.promoted = load i32, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 8), align 4, !tbaa !2764
  tail call void @llvm.dbg.value(metadata ptr null, metadata !2754, metadata !DIExpression()), !dbg !2755
  tail call void @llvm.dbg.value(metadata i32 0, metadata !2753, metadata !DIExpression()), !dbg !2755
  %cmp16 = icmp eq i32 %1, 0, !dbg !2765
  %or.cond17 = or i1 %cmp.i, %cmp16, !dbg !2766
  br i1 %or.cond17, label %for.end, label %lor.lhs.false.i.lr.ph, !dbg !2766

lor.lhs.false.i.lr.ph:                            ; preds = %entry
  %2 = load i32, ptr @power_largest, align 4, !tbaa !456
  %cmp1.i = icmp ult i32 %2, %id
  %slots.i = getelementptr inbounds i8, ptr %arrayidx.i, i64 8
  br i1 %cmp1.i, label %for.end, label %lor.lhs.false.i.lr.ph.split, !dbg !2767

lor.lhs.false.i.lr.ph.split:                      ; preds = %lor.lhs.false.i.lr.ph
  %sl_curr.i.promoted = load i32, ptr %sl_curr.i, align 8, !tbaa !572
  br label %lor.lhs.false.i, !dbg !2766

lor.lhs.false.i:                                  ; preds = %lor.lhs.false.i.lr.ph.split, %if.then4
  %dec.i24 = phi i32 [ %sl_curr.i.promoted, %lor.lhs.false.i.lr.ph.split ], [ %dec.i, %if.then4 ]
  %x.019 = phi i32 [ 0, %lor.lhs.false.i.lr.ph.split ], [ %inc6, %if.then4 ]
  %inc1518 = phi i32 [ %.promoted, %lor.lhs.false.i.lr.ph.split ], [ %inc, %if.then4 ]
  tail call void @llvm.dbg.value(metadata i32 %x.019, metadata !2753, metadata !DIExpression()), !dbg !2755
  tail call void @llvm.dbg.value(metadata ptr %arrayidx.i, metadata !1041, metadata !DIExpression()), !dbg !2768
  %cmp7.not.i = icmp eq i32 %dec.i24, 0, !dbg !2769
  br i1 %cmp7.not.i, label %for.end, label %if.then8.i, !dbg !2770

if.then8.i:                                       ; preds = %lor.lhs.false.i
  %3 = load ptr, ptr %slots.i, align 8, !dbg !2771, !tbaa !561
  tail call void @llvm.dbg.value(metadata ptr %3, metadata !1043, metadata !DIExpression()), !dbg !2768
  %4 = load ptr, ptr %3, align 8, !dbg !2772, !tbaa !421
  store ptr %4, ptr %slots.i, align 8, !dbg !2773, !tbaa !561
  %tobool.not.i = icmp eq ptr %4, null, !dbg !2774
  br i1 %tobool.not.i, label %if.end, label %if.then11.i, !dbg !2775

if.then11.i:                                      ; preds = %if.then8.i
  %prev.i = getelementptr inbounds i8, ptr %4, i64 8, !dbg !2776
  store ptr null, ptr %prev.i, align 8, !dbg !2777, !tbaa !421
  br label %if.end, !dbg !2778

if.end:                                           ; preds = %if.then11.i, %if.then8.i
  %it_flags.i = getelementptr inbounds i8, ptr %3, i64 38, !dbg !2779
  %5 = load i16, ptr %it_flags.i, align 2, !dbg !2780, !tbaa !553
  %6 = and i16 %5, -5, !dbg !2780
  store i16 %6, ptr %it_flags.i, align 2, !dbg !2780, !tbaa !553
  %refcount.i = getelementptr inbounds i8, ptr %3, i64 36, !dbg !2781
  store i16 1, ptr %refcount.i, align 4, !dbg !2782, !tbaa !553
  %dec.i = add i32 %dec.i24, -1, !dbg !2783
  store i32 %dec.i, ptr %sl_curr.i, align 8, !dbg !2783, !tbaa !572
  tail call void @llvm.dbg.value(metadata ptr %3, metadata !1042, metadata !DIExpression()), !dbg !2768
  tail call void @llvm.dbg.value(metadata ptr %3, metadata !2754, metadata !DIExpression()), !dbg !2755
  %7 = load ptr, ptr @slab_rebal, align 8, !dbg !2784, !tbaa !1528
  %cmp2.not = icmp ult ptr %3, %7, !dbg !2786
  br i1 %cmp2.not, label %for.end, label %land.lhs.true, !dbg !2787

land.lhs.true:                                    ; preds = %if.end
  %8 = load ptr, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 1), align 8, !dbg !2788, !tbaa !1630
  %cmp3 = icmp ult ptr %3, %8, !dbg !2789
  br i1 %cmp3, label %if.then4, label %for.end, !dbg !2790

if.then4:                                         ; preds = %land.lhs.true
  store i16 0, ptr %refcount.i, align 4, !dbg !2791, !tbaa !553
  store i16 12, ptr %it_flags.i, align 2, !dbg !2793, !tbaa !553
  tail call void @llvm.dbg.value(metadata ptr null, metadata !2754, metadata !DIExpression()), !dbg !2755
  %inc = add i32 %inc1518, 1, !dbg !2794
  store i32 %inc, ptr getelementptr inbounds (%struct.slab_rebalance, ptr @slab_rebal, i64 0, i32 8), align 4, !dbg !2794, !tbaa !2764
  %inc6 = add nuw nsw i32 %x.019, 1, !dbg !2795
  tail call void @llvm.dbg.value(metadata i32 %inc6, metadata !2753, metadata !DIExpression()), !dbg !2755
  %cmp.not = icmp ult i32 %inc6, %1, !dbg !2765
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !1034, metadata !DIExpression()), !dbg !2768
  tail call void @llvm.dbg.value(metadata i32 %id, metadata !1039, metadata !DIExpression()), !dbg !2768
  tail call void @llvm.dbg.value(metadata i32 1, metadata !1040, metadata !DIExpression()), !dbg !2768
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1042, metadata !DIExpression()), !dbg !2768
  tail call void @llvm.dbg.value(metadata ptr null, metadata !1043, metadata !DIExpression()), !dbg !2768
  br i1 %cmp.not, label %lor.lhs.false.i, label %for.end, !dbg !2766, !llvm.loop !2796

for.end:                                          ; preds = %if.then4, %land.lhs.true, %if.end, %lor.lhs.false.i, %lor.lhs.false.i.lr.ph, %entry
  %new_it.1 = phi ptr [ null, %entry ], [ null, %lor.lhs.false.i.lr.ph ], [ null, %lor.lhs.false.i ], [ %3, %if.end ], [ %3, %land.lhs.true ], [ null, %if.then4 ], !dbg !2755
  tail call void @llvm.dbg.value(metadata ptr %new_it.1, metadata !2754, metadata !DIExpression()), !dbg !2755
  ret ptr %new_it.1, !dbg !2798
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #17

declare !dbg !2799 i32 @do_item_replace(ptr noundef, ptr noundef, i32 noundef, i64 noundef) local_unnamed_addr #9

; Function Attrs: nofree nounwind
declare noundef i64 @fwrite(ptr nocapture noundef, i64 noundef, i64 noundef, ptr nocapture noundef) local_unnamed_addr #18

; Function Attrs: nofree nounwind willreturn memory(argmem: read)
declare i32 @bcmp(ptr nocapture, ptr nocapture, i64) local_unnamed_addr #19

declare void @__tsan_init()

; Function Attrs: nounwind uwtable
define internal void @tsan.module_ctor() #20 {
  call void @__tsan_init()
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #21

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #21

attributes #0 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree norecurse nosync nounwind sanitize_thread memory(read, argmem: none, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { mustprogress nofree norecurse nosync nounwind sanitize_thread willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { mustprogress nounwind sanitize_thread willreturn uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nounwind sanitize_thread uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #8 = { nofree nounwind memory(read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { nofree norecurse nosync nounwind sanitize_thread memory(readwrite, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { mustprogress nounwind willreturn allockind("realloc") allocsize(1) memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #16 = { mustprogress nofree nounwind willreturn allockind("alloc,zeroed") allocsize(0,1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #17 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #18 = { nofree nounwind }
attributes #19 = { nofree nounwind willreturn memory(argmem: read) }
attributes #20 = { nounwind uwtable }
attributes #21 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #22 = { nounwind allocsize(1) }
attributes #23 = { nounwind }
attributes #24 = { nobuiltin }
attributes #25 = { cold }
attributes #26 = { cold nounwind }
attributes #27 = { noreturn nounwind }
attributes #28 = { nounwind allocsize(0) }
attributes #29 = { nounwind allocsize(0,1) }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!406, !407, !408, !409, !410, !411, !412}
!llvm.ident = !{!413}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "storage", scope: !2, file: !3, line: 54, type: !128, isLocal: true, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !89, globals: !152, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "slabs.c", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "bf3ba8926f20b4af4f902b75ae9b9a48")
!4 = !{!5, !14, !33, !47, !66, !71, !76, !82}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "reassign_result_type", file: !6, line: 55, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "./slabs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "28867aba1f41c79140864d76faedcb32")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12, !13}
!9 = !DIEnumerator(name: "REASSIGN_OK", value: 0)
!10 = !DIEnumerator(name: "REASSIGN_RUNNING", value: 1)
!11 = !DIEnumerator(name: "REASSIGN_BADCLASS", value: 2)
!12 = !DIEnumerator(name: "REASSIGN_NOSPARE", value: 3)
!13 = !DIEnumerator(name: "REASSIGN_SRC_DST_SAME", value: 4)
!14 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "conn_states", file: !15, line: 204, baseType: !7, size: 32, elements: !16)
!15 = !DIFile(filename: "./memcached.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "a52021954a5d6b153b5bc084e2fbff2b")
!16 = !{!17, !18, !19, !20, !21, !22, !23, !24, !25, !26, !27, !28, !29, !30, !31, !32}
!17 = !DIEnumerator(name: "conn_listening", value: 0)
!18 = !DIEnumerator(name: "conn_new_cmd", value: 1)
!19 = !DIEnumerator(name: "conn_waiting", value: 2)
!20 = !DIEnumerator(name: "conn_read", value: 3)
!21 = !DIEnumerator(name: "conn_parse_cmd", value: 4)
!22 = !DIEnumerator(name: "conn_write", value: 5)
!23 = !DIEnumerator(name: "conn_nread", value: 6)
!24 = !DIEnumerator(name: "conn_swallow", value: 7)
!25 = !DIEnumerator(name: "conn_closing", value: 8)
!26 = !DIEnumerator(name: "conn_mwrite", value: 9)
!27 = !DIEnumerator(name: "conn_closed", value: 10)
!28 = !DIEnumerator(name: "conn_watch", value: 11)
!29 = !DIEnumerator(name: "conn_io_queue", value: 12)
!30 = !DIEnumerator(name: "conn_io_resume", value: 13)
!31 = !DIEnumerator(name: "conn_io_pending", value: 14)
!32 = !DIEnumerator(name: "conn_max_state", value: 15)
!33 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "bin_substates", file: !15, line: 223, baseType: !7, size: 32, elements: !34)
!34 = !{!35, !36, !37, !38, !39, !40, !41, !42, !43, !44, !45, !46}
!35 = !DIEnumerator(name: "bin_no_state", value: 0)
!36 = !DIEnumerator(name: "bin_reading_set_header", value: 1)
!37 = !DIEnumerator(name: "bin_reading_cas_header", value: 2)
!38 = !DIEnumerator(name: "bin_read_set_value", value: 3)
!39 = !DIEnumerator(name: "bin_reading_get_key", value: 4)
!40 = !DIEnumerator(name: "bin_reading_stat", value: 5)
!41 = !DIEnumerator(name: "bin_reading_del_header", value: 6)
!42 = !DIEnumerator(name: "bin_reading_incr_header", value: 7)
!43 = !DIEnumerator(name: "bin_read_flush_exptime", value: 8)
!44 = !DIEnumerator(name: "bin_reading_sasl_auth", value: 9)
!45 = !DIEnumerator(name: "bin_reading_sasl_auth_data", value: 10)
!46 = !DIEnumerator(name: "bin_reading_touch_key", value: 11)
!47 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "log_entry_type", file: !48, line: 16, baseType: !7, size: 32, elements: !49)
!48 = !DIFile(filename: "./logger.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "e743c4228b1e0bc1c91bec9cfd28d5ab")
!49 = !{!50, !51, !52, !53, !54, !55, !56, !57, !58, !59, !60, !61, !62, !63, !64, !65}
!50 = !DIEnumerator(name: "LOGGER_ASCII_CMD", value: 0)
!51 = !DIEnumerator(name: "LOGGER_EVICTION", value: 1)
!52 = !DIEnumerator(name: "LOGGER_ITEM_GET", value: 2)
!53 = !DIEnumerator(name: "LOGGER_ITEM_STORE", value: 3)
!54 = !DIEnumerator(name: "LOGGER_CRAWLER_STATUS", value: 4)
!55 = !DIEnumerator(name: "LOGGER_SLAB_MOVE", value: 5)
!56 = !DIEnumerator(name: "LOGGER_CONNECTION_NEW", value: 6)
!57 = !DIEnumerator(name: "LOGGER_CONNECTION_CLOSE", value: 7)
!58 = !DIEnumerator(name: "LOGGER_DELETIONS", value: 8)
!59 = !DIEnumerator(name: "LOGGER_EXTSTORE_WRITE", value: 9)
!60 = !DIEnumerator(name: "LOGGER_COMPACT_START", value: 10)
!61 = !DIEnumerator(name: "LOGGER_COMPACT_ABORT", value: 11)
!62 = !DIEnumerator(name: "LOGGER_COMPACT_READ_START", value: 12)
!63 = !DIEnumerator(name: "LOGGER_COMPACT_READ_END", value: 13)
!64 = !DIEnumerator(name: "LOGGER_COMPACT_END", value: 14)
!65 = !DIEnumerator(name: "LOGGER_COMPACT_FRAGINFO", value: 15)
!66 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "protocol", file: !15, line: 238, baseType: !7, size: 32, elements: !67)
!67 = !{!68, !69, !70}
!68 = !DIEnumerator(name: "ascii_prot", value: 3)
!69 = !DIEnumerator(name: "binary_prot", value: 4)
!70 = !DIEnumerator(name: "negotiating_prot", value: 5)
!71 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "network_transport", file: !15, line: 247, baseType: !7, size: 32, elements: !72)
!72 = !{!73, !74, !75}
!73 = !DIEnumerator(name: "local_transport", value: 0)
!74 = !DIEnumerator(name: "tcp_transport", value: 1)
!75 = !DIEnumerator(name: "udp_transport", value: 2)
!76 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "close_reasons", file: !15, line: 266, baseType: !7, size: 32, elements: !77)
!77 = !{!78, !79, !80, !81}
!78 = !DIEnumerator(name: "ERROR_CLOSE", value: 0)
!79 = !DIEnumerator(name: "NORMAL_CLOSE", value: 1)
!80 = !DIEnumerator(name: "IDLE_TIMEOUT_CLOSE", value: 2)
!81 = !DIEnumerator(name: "SHUTDOWN_CLOSE", value: 3)
!82 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "move_status", file: !3, line: 833, baseType: !7, size: 32, elements: !83)
!83 = !{!84, !85, !86, !87, !88}
!84 = !DIEnumerator(name: "MOVE_PASS", value: 0)
!85 = !DIEnumerator(name: "MOVE_FROM_SLAB", value: 1)
!86 = !DIEnumerator(name: "MOVE_FROM_LRU", value: 2)
!87 = !DIEnumerator(name: "MOVE_BUSY", value: 3)
!88 = !DIEnumerator(name: "MOVE_LOCKED", value: 4)
!89 = !{!90, !127, !128, !129, !131, !133, !150, !151, !120}
!90 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !91, size: 64)
!91 = !DIDerivedType(tag: DW_TAG_typedef, name: "item", file: !15, line: 616, baseType: !92)
!92 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_stritem", file: !15, line: 593, size: 384, elements: !93)
!93 = !{!94, !96, !97, !98, !100, !101, !103, !105, !110, !114, !115}
!94 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !92, file: !15, line: 595, baseType: !95, size: 64)
!95 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !92, size: 64)
!96 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !92, file: !15, line: 596, baseType: !95, size: 64, offset: 64)
!97 = !DIDerivedType(tag: DW_TAG_member, name: "h_next", scope: !92, file: !15, line: 598, baseType: !95, size: 64, offset: 128)
!98 = !DIDerivedType(tag: DW_TAG_member, name: "time", scope: !92, file: !15, line: 599, baseType: !99, size: 32, offset: 192)
!99 = !DIDerivedType(tag: DW_TAG_typedef, name: "rel_time_t", file: !48, line: 14, baseType: !7)
!100 = !DIDerivedType(tag: DW_TAG_member, name: "exptime", scope: !92, file: !15, line: 600, baseType: !99, size: 32, offset: 224)
!101 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !92, file: !15, line: 601, baseType: !102, size: 32, offset: 256)
!102 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!103 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !92, file: !15, line: 602, baseType: !104, size: 16, offset: 288)
!104 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!105 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !92, file: !15, line: 603, baseType: !106, size: 16, offset: 304)
!106 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint16_t", file: !107, line: 25, baseType: !108)
!107 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!108 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint16_t", file: !109, line: 40, baseType: !104)
!109 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!110 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !92, file: !15, line: 604, baseType: !111, size: 8, offset: 320)
!111 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !107, line: 24, baseType: !112)
!112 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !109, line: 38, baseType: !113)
!113 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!114 = !DIDerivedType(tag: DW_TAG_member, name: "nkey", scope: !92, file: !15, line: 605, baseType: !111, size: 8, offset: 328)
!115 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !92, file: !15, line: 611, baseType: !116, offset: 384)
!116 = !DICompositeType(tag: DW_TAG_array_type, baseType: !117, elements: !125)
!117 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !92, file: !15, line: 608, size: 64, elements: !118)
!118 = !{!119, !123}
!119 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !117, file: !15, line: 609, baseType: !120, size: 64)
!120 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !107, line: 27, baseType: !121)
!121 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !109, line: 45, baseType: !122)
!122 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!123 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !117, file: !15, line: 610, baseType: !124, size: 8)
!124 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!125 = !{!126}
!126 = !DISubrange(count: -1)
!127 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !124, size: 64)
!128 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!129 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !130, size: 64)
!130 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !124)
!131 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !132, line: 18, baseType: !122)
!132 = !DIFile(filename: "/extra/alexey/builds/tsan-astats-1391bf330765/lib/clang/19/include/__stddef_size_t.h", directory: "", checksumkind: CSK_MD5, checksum: "2c44e821a2b1951cde2eb0fb2e656867")
!133 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !134, size: 64)
!134 = !DIDerivedType(tag: DW_TAG_typedef, name: "item_chunk", file: !15, line: 653, baseType: !135)
!135 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_strchunk", file: !15, line: 641, size: 384, elements: !136)
!136 = !{!137, !139, !140, !141, !142, !143, !144, !145, !146, !147, !148}
!137 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !135, file: !15, line: 642, baseType: !138, size: 64)
!138 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !135, size: 64)
!139 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !135, file: !15, line: 643, baseType: !138, size: 64, offset: 64)
!140 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !135, file: !15, line: 644, baseType: !95, size: 64, offset: 128)
!141 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !135, file: !15, line: 645, baseType: !102, size: 32, offset: 192)
!142 = !DIDerivedType(tag: DW_TAG_member, name: "used", scope: !135, file: !15, line: 646, baseType: !102, size: 32, offset: 224)
!143 = !DIDerivedType(tag: DW_TAG_member, name: "nbytes", scope: !135, file: !15, line: 647, baseType: !102, size: 32, offset: 256)
!144 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !135, file: !15, line: 648, baseType: !104, size: 16, offset: 288)
!145 = !DIDerivedType(tag: DW_TAG_member, name: "it_flags", scope: !135, file: !15, line: 649, baseType: !106, size: 16, offset: 304)
!146 = !DIDerivedType(tag: DW_TAG_member, name: "slabs_clsid", scope: !135, file: !15, line: 650, baseType: !111, size: 8, offset: 320)
!147 = !DIDerivedType(tag: DW_TAG_member, name: "orig_clsid", scope: !135, file: !15, line: 651, baseType: !111, size: 8, offset: 328)
!148 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !135, file: !15, line: 652, baseType: !149, offset: 336)
!149 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, elements: !125)
!150 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!151 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !111, size: 64)
!152 = !{!153, !158, !163, !168, !173, !178, !194, !196, !0, !200, !202, !207, !212, !214, !219, !224, !229, !231, !236, !238, !240, !242, !244, !247, !252, !280, !285, !290, !295, !300, !305, !307, !309, !311, !313, !318, !320, !325, !327, !332, !334, !336, !338, !340, !342, !344, !349, !351, !359, !364, !369, !371, !374}
!153 = !DIGlobalVariableExpression(var: !154, expr: !DIExpression())
!154 = distinct !DIGlobalVariable(scope: null, file: !3, line: 227, type: !155, isLocal: true, isDefinition: true)
!155 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 784, elements: !156)
!156 = !{!157}
!157 = !DISubrange(count: 98)
!158 = !DIGlobalVariableExpression(var: !159, expr: !DIExpression())
!159 = distinct !DIGlobalVariable(scope: null, file: !3, line: 266, type: !160, isLocal: true, isDefinition: true)
!160 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 352, elements: !161)
!161 = !{!162}
!162 = !DISubrange(count: 44)
!163 = !DIGlobalVariableExpression(var: !164, expr: !DIExpression())
!164 = distinct !DIGlobalVariable(scope: null, file: !3, line: 281, type: !165, isLocal: true, isDefinition: true)
!165 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 176, elements: !166)
!166 = !{!167}
!167 = !DISubrange(count: 22)
!168 = !DIGlobalVariableExpression(var: !169, expr: !DIExpression())
!169 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1326, type: !170, isLocal: true, isDefinition: true)
!170 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 248, elements: !171)
!171 = !{!172}
!172 = !DISubrange(count: 31)
!173 = !DIGlobalVariableExpression(var: !174, expr: !DIExpression())
!174 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1329, type: !175, isLocal: true, isDefinition: true)
!175 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 104, elements: !176)
!176 = !{!177}
!177 = !DISubrange(count: 13)
!178 = !DIGlobalVariableExpression(var: !179, expr: !DIExpression())
!179 = distinct !DIGlobalVariable(name: "slabclass", scope: !2, file: !3, line: 42, type: !180, isLocal: true, isDefinition: true)
!180 = !DICompositeType(tag: DW_TAG_array_type, baseType: !181, size: 20480, elements: !192)
!181 = !DIDerivedType(tag: DW_TAG_typedef, name: "slabclass_t", file: !3, line: 40, baseType: !182)
!182 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 29, size: 320, elements: !183)
!183 = !{!184, !185, !186, !187, !188, !189, !191}
!184 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !182, file: !3, line: 30, baseType: !7, size: 32)
!185 = !DIDerivedType(tag: DW_TAG_member, name: "perslab", scope: !182, file: !3, line: 31, baseType: !7, size: 32, offset: 32)
!186 = !DIDerivedType(tag: DW_TAG_member, name: "slots", scope: !182, file: !3, line: 33, baseType: !128, size: 64, offset: 64)
!187 = !DIDerivedType(tag: DW_TAG_member, name: "sl_curr", scope: !182, file: !3, line: 34, baseType: !7, size: 32, offset: 128)
!188 = !DIDerivedType(tag: DW_TAG_member, name: "slabs", scope: !182, file: !3, line: 36, baseType: !7, size: 32, offset: 160)
!189 = !DIDerivedType(tag: DW_TAG_member, name: "slab_list", scope: !182, file: !3, line: 38, baseType: !190, size: 64, offset: 192)
!190 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !128, size: 64)
!191 = !DIDerivedType(tag: DW_TAG_member, name: "list_size", scope: !182, file: !3, line: 39, baseType: !7, size: 32, offset: 256)
!192 = !{!193}
!193 = !DISubrange(count: 64)
!194 = !DIGlobalVariableExpression(var: !195, expr: !DIExpression())
!195 = distinct !DIGlobalVariable(name: "power_largest", scope: !2, file: !3, line: 48, type: !102, isLocal: true, isDefinition: true)
!196 = !DIGlobalVariableExpression(var: !197, expr: !DIExpression())
!197 = distinct !DIGlobalVariable(name: "rebalance_tid", scope: !2, file: !3, line: 1317, type: !198, isLocal: true, isDefinition: true)
!198 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_t", file: !199, line: 27, baseType: !122)
!199 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h", directory: "", checksumkind: CSK_MD5, checksum: "8a5acdbeec491eca11cf81cb1ef77ea7")
!200 = !DIGlobalVariableExpression(var: !201, expr: !DIExpression())
!201 = distinct !DIGlobalVariable(name: "mem_limit", scope: !2, file: !3, line: 43, type: !131, isLocal: true, isDefinition: true)
!202 = !DIGlobalVariableExpression(var: !203, expr: !DIExpression())
!203 = distinct !DIGlobalVariable(scope: null, file: !3, line: 117, type: !204, isLocal: true, isDefinition: true)
!204 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 112, elements: !205)
!205 = !{!206}
!206 = !DISubrange(count: 14)
!207 = !DIGlobalVariableExpression(var: !208, expr: !DIExpression())
!208 = distinct !DIGlobalVariable(scope: null, file: !3, line: 117, type: !209, isLocal: true, isDefinition: true)
!209 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 16, elements: !210)
!210 = !{!211}
!211 = !DISubrange(count: 2)
!212 = !DIGlobalVariableExpression(var: !213, expr: !DIExpression())
!213 = distinct !DIGlobalVariable(scope: null, file: !3, line: 122, type: !204, isLocal: true, isDefinition: true)
!214 = !DIGlobalVariableExpression(var: !215, expr: !DIExpression())
!215 = distinct !DIGlobalVariable(scope: null, file: !3, line: 123, type: !216, isLocal: true, isDefinition: true)
!216 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 40, elements: !217)
!217 = !{!218}
!218 = !DISubrange(count: 5)
!219 = !DIGlobalVariableExpression(var: !220, expr: !DIExpression())
!220 = distinct !DIGlobalVariable(scope: null, file: !3, line: 132, type: !221, isLocal: true, isDefinition: true)
!221 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 320, elements: !222)
!222 = !{!223}
!223 = !DISubrange(count: 40)
!224 = !DIGlobalVariableExpression(var: !225, expr: !DIExpression())
!225 = distinct !DIGlobalVariable(scope: null, file: !3, line: 137, type: !226, isLocal: true, isDefinition: true)
!226 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 168, elements: !227)
!227 = !{!228}
!228 = !DISubrange(count: 21)
!229 = !DIGlobalVariableExpression(var: !230, expr: !DIExpression())
!230 = distinct !DIGlobalVariable(scope: null, file: !3, line: 143, type: !221, isLocal: true, isDefinition: true)
!231 = !DIGlobalVariableExpression(var: !232, expr: !DIExpression())
!232 = distinct !DIGlobalVariable(scope: null, file: !3, line: 149, type: !233, isLocal: true, isDefinition: true)
!233 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 360, elements: !234)
!234 = !{!235}
!235 = !DISubrange(count: 45)
!236 = !DIGlobalVariableExpression(var: !237, expr: !DIExpression())
!237 = distinct !DIGlobalVariable(name: "mem_base", scope: !2, file: !3, line: 50, type: !128, isLocal: true, isDefinition: true)
!238 = !DIGlobalVariableExpression(var: !239, expr: !DIExpression())
!239 = distinct !DIGlobalVariable(name: "mem_current", scope: !2, file: !3, line: 51, type: !128, isLocal: true, isDefinition: true)
!240 = !DIGlobalVariableExpression(var: !241, expr: !DIExpression())
!241 = distinct !DIGlobalVariable(name: "mem_avail", scope: !2, file: !3, line: 52, type: !131, isLocal: true, isDefinition: true)
!242 = !DIGlobalVariableExpression(var: !243, expr: !DIExpression())
!243 = distinct !DIGlobalVariable(name: "mem_malloced", scope: !2, file: !3, line: 44, type: !131, isLocal: true, isDefinition: true)
!244 = !DIGlobalVariableExpression(var: !245, expr: !DIExpression())
!245 = distinct !DIGlobalVariable(name: "mem_limit_reached", scope: !2, file: !3, line: 47, type: !246, isLocal: true, isDefinition: true)
!246 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!247 = !DIGlobalVariableExpression(var: !248, expr: !DIExpression())
!248 = distinct !DIGlobalVariable(scope: null, file: !3, line: 329, type: !249, isLocal: true, isDefinition: true)
!249 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 968, elements: !250)
!250 = !{!251}
!251 = !DISubrange(count: 121)
!252 = !DIGlobalVariableExpression(var: !253, expr: !DIExpression())
!253 = distinct !DIGlobalVariable(name: "slabs_lock", scope: !2, file: !3, line: 59, type: !254, isLocal: true, isDefinition: true)
!254 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_mutex_t", file: !199, line: 72, baseType: !255)
!255 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !199, line: 67, size: 320, elements: !256)
!256 = !{!257, !277, !278}
!257 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !255, file: !199, line: 69, baseType: !258, size: 320)
!258 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_mutex_s", file: !259, line: 22, size: 320, elements: !260)
!259 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h", directory: "", checksumkind: CSK_MD5, checksum: "6b075eca9ab0e2d761b2afc4ecfab776")
!260 = !{!261, !262, !263, !264, !265, !266, !268, !269}
!261 = !DIDerivedType(tag: DW_TAG_member, name: "__lock", scope: !258, file: !259, line: 24, baseType: !102, size: 32)
!262 = !DIDerivedType(tag: DW_TAG_member, name: "__count", scope: !258, file: !259, line: 25, baseType: !7, size: 32, offset: 32)
!263 = !DIDerivedType(tag: DW_TAG_member, name: "__owner", scope: !258, file: !259, line: 26, baseType: !102, size: 32, offset: 64)
!264 = !DIDerivedType(tag: DW_TAG_member, name: "__nusers", scope: !258, file: !259, line: 28, baseType: !7, size: 32, offset: 96)
!265 = !DIDerivedType(tag: DW_TAG_member, name: "__kind", scope: !258, file: !259, line: 32, baseType: !102, size: 32, offset: 128)
!266 = !DIDerivedType(tag: DW_TAG_member, name: "__spins", scope: !258, file: !259, line: 34, baseType: !267, size: 16, offset: 160)
!267 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!268 = !DIDerivedType(tag: DW_TAG_member, name: "__elision", scope: !258, file: !259, line: 35, baseType: !267, size: 16, offset: 176)
!269 = !DIDerivedType(tag: DW_TAG_member, name: "__list", scope: !258, file: !259, line: 36, baseType: !270, size: 128, offset: 192)
!270 = !DIDerivedType(tag: DW_TAG_typedef, name: "__pthread_list_t", file: !271, line: 55, baseType: !272)
!271 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h", directory: "", checksumkind: CSK_MD5, checksum: "b9a7199822bce372686baacd32a9f4f3")
!272 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_internal_list", file: !271, line: 51, size: 128, elements: !273)
!273 = !{!274, !276}
!274 = !DIDerivedType(tag: DW_TAG_member, name: "__prev", scope: !272, file: !271, line: 53, baseType: !275, size: 64)
!275 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !272, size: 64)
!276 = !DIDerivedType(tag: DW_TAG_member, name: "__next", scope: !272, file: !271, line: 54, baseType: !275, size: 64, offset: 64)
!277 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !255, file: !199, line: 70, baseType: !221, size: 320)
!278 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !255, file: !199, line: 71, baseType: !279, size: 64)
!279 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!280 = !DIGlobalVariableExpression(var: !281, expr: !DIExpression())
!281 = distinct !DIGlobalVariable(scope: null, file: !3, line: 574, type: !282, isLocal: true, isDefinition: true)
!282 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 48, elements: !283)
!283 = !{!284}
!284 = !DISubrange(count: 6)
!285 = !DIGlobalVariableExpression(var: !286, expr: !DIExpression())
!286 = distinct !DIGlobalVariable(scope: null, file: !3, line: 574, type: !287, isLocal: true, isDefinition: true)
!287 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 88, elements: !288)
!288 = !{!289}
!289 = !DISubrange(count: 11)
!290 = !DIGlobalVariableExpression(var: !291, expr: !DIExpression())
!291 = distinct !DIGlobalVariable(scope: null, file: !3, line: 574, type: !292, isLocal: true, isDefinition: true)
!292 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 24, elements: !293)
!293 = !{!294}
!294 = !DISubrange(count: 3)
!295 = !DIGlobalVariableExpression(var: !296, expr: !DIExpression())
!296 = distinct !DIGlobalVariable(scope: null, file: !3, line: 575, type: !297, isLocal: true, isDefinition: true)
!297 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 128, elements: !298)
!298 = !{!299}
!299 = !DISubrange(count: 16)
!300 = !DIGlobalVariableExpression(var: !301, expr: !DIExpression())
!301 = distinct !DIGlobalVariable(scope: null, file: !3, line: 576, type: !302, isLocal: true, isDefinition: true)
!302 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 96, elements: !303)
!303 = !{!304}
!304 = !DISubrange(count: 12)
!305 = !DIGlobalVariableExpression(var: !306, expr: !DIExpression())
!306 = distinct !DIGlobalVariable(scope: null, file: !3, line: 577, type: !175, isLocal: true, isDefinition: true)
!307 = !DIGlobalVariableExpression(var: !308, expr: !DIExpression())
!308 = distinct !DIGlobalVariable(scope: null, file: !3, line: 578, type: !302, isLocal: true, isDefinition: true)
!309 = !DIGlobalVariableExpression(var: !310, expr: !DIExpression())
!310 = distinct !DIGlobalVariable(scope: null, file: !3, line: 580, type: !302, isLocal: true, isDefinition: true)
!311 = !DIGlobalVariableExpression(var: !312, expr: !DIExpression())
!312 = distinct !DIGlobalVariable(scope: null, file: !3, line: 582, type: !297, isLocal: true, isDefinition: true)
!313 = !DIGlobalVariableExpression(var: !314, expr: !DIExpression())
!314 = distinct !DIGlobalVariable(scope: null, file: !3, line: 583, type: !315, isLocal: true, isDefinition: true)
!315 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 72, elements: !316)
!316 = !{!317}
!317 = !DISubrange(count: 9)
!318 = !DIGlobalVariableExpression(var: !319, expr: !DIExpression())
!319 = distinct !DIGlobalVariable(scope: null, file: !3, line: 583, type: !216, isLocal: true, isDefinition: true)
!320 = !DIGlobalVariableExpression(var: !321, expr: !DIExpression())
!321 = distinct !DIGlobalVariable(scope: null, file: !3, line: 585, type: !322, isLocal: true, isDefinition: true)
!322 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 64, elements: !323)
!323 = !{!324}
!324 = !DISubrange(count: 8)
!325 = !DIGlobalVariableExpression(var: !326, expr: !DIExpression())
!326 = distinct !DIGlobalVariable(scope: null, file: !3, line: 587, type: !302, isLocal: true, isDefinition: true)
!327 = !DIGlobalVariableExpression(var: !328, expr: !DIExpression())
!328 = distinct !DIGlobalVariable(scope: null, file: !3, line: 589, type: !329, isLocal: true, isDefinition: true)
!329 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 80, elements: !330)
!330 = !{!331}
!331 = !DISubrange(count: 10)
!332 = !DIGlobalVariableExpression(var: !333, expr: !DIExpression())
!333 = distinct !DIGlobalVariable(scope: null, file: !3, line: 591, type: !329, isLocal: true, isDefinition: true)
!334 = !DIGlobalVariableExpression(var: !335, expr: !DIExpression())
!335 = distinct !DIGlobalVariable(scope: null, file: !3, line: 593, type: !315, isLocal: true, isDefinition: true)
!336 = !DIGlobalVariableExpression(var: !337, expr: !DIExpression())
!337 = distinct !DIGlobalVariable(scope: null, file: !3, line: 595, type: !287, isLocal: true, isDefinition: true)
!338 = !DIGlobalVariableExpression(var: !339, expr: !DIExpression())
!339 = distinct !DIGlobalVariable(scope: null, file: !3, line: 597, type: !287, isLocal: true, isDefinition: true)
!340 = !DIGlobalVariableExpression(var: !341, expr: !DIExpression())
!341 = distinct !DIGlobalVariable(scope: null, file: !3, line: 605, type: !175, isLocal: true, isDefinition: true)
!342 = !DIGlobalVariableExpression(var: !343, expr: !DIExpression())
!343 = distinct !DIGlobalVariable(scope: null, file: !3, line: 605, type: !292, isLocal: true, isDefinition: true)
!344 = !DIGlobalVariableExpression(var: !345, expr: !DIExpression())
!345 = distinct !DIGlobalVariable(scope: null, file: !3, line: 606, type: !346, isLocal: true, isDefinition: true)
!346 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 120, elements: !347)
!347 = !{!348}
!348 = !DISubrange(count: 15)
!349 = !DIGlobalVariableExpression(var: !350, expr: !DIExpression())
!350 = distinct !DIGlobalVariable(name: "slabs_rebalance_lock", scope: !2, file: !3, line: 60, type: !254, isLocal: true, isDefinition: true)
!351 = !DIGlobalVariableExpression(var: !352, expr: !DIExpression())
!352 = distinct !DIGlobalVariable(name: "cur", scope: !353, file: !3, line: 1249, type: !102, isLocal: true, isDefinition: true)
!353 = distinct !DISubprogram(name: "slabs_reassign_pick_any", scope: !3, file: !3, line: 1248, type: !354, scopeLine: 1248, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !356)
!354 = !DISubroutineType(types: !355)
!355 = !{!102, !102}
!356 = !{!357, !358}
!357 = !DILocalVariable(name: "dst", arg: 1, scope: !353, file: !3, line: 1248, type: !102)
!358 = !DILocalVariable(name: "tries", scope: !353, file: !3, line: 1250, type: !102)
!359 = !DIGlobalVariableExpression(var: !360, expr: !DIExpression())
!360 = distinct !DIGlobalVariable(scope: null, file: !3, line: 776, type: !361, isLocal: true, isDefinition: true)
!361 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 208, elements: !362)
!362 = !{!363}
!363 = !DISubrange(count: 26)
!364 = !DIGlobalVariableExpression(var: !365, expr: !DIExpression())
!365 = distinct !DIGlobalVariable(scope: null, file: !3, line: 935, type: !366, isLocal: true, isDefinition: true)
!366 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 448, elements: !367)
!367 = !{!368}
!368 = !DISubrange(count: 56)
!369 = !DIGlobalVariableExpression(var: !370, expr: !DIExpression())
!370 = distinct !DIGlobalVariable(scope: null, file: !3, line: 1195, type: !165, isLocal: true, isDefinition: true)
!371 = !DIGlobalVariableExpression(var: !372, expr: !DIExpression())
!372 = distinct !DIGlobalVariable(name: "do_run_slab_rebalance_thread", scope: !2, file: !3, line: 728, type: !373, isLocal: true, isDefinition: true)
!373 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !102)
!374 = !DIGlobalVariableExpression(var: !375, expr: !DIExpression())
!375 = distinct !DIGlobalVariable(name: "slab_rebalance_cond", scope: !2, file: !3, line: 727, type: !376, isLocal: true, isDefinition: true)
!376 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_cond_t", file: !199, line: 80, baseType: !377)
!377 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !199, line: 75, size: 384, elements: !378)
!378 = !{!379, !400, !404}
!379 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !377, file: !199, line: 77, baseType: !380, size: 384)
!380 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__pthread_cond_s", file: !271, line: 94, size: 384, elements: !381)
!381 = !{!382, !393, !394, !396, !397, !398, !399}
!382 = !DIDerivedType(tag: DW_TAG_member, name: "__wseq", scope: !380, file: !271, line: 96, baseType: !383, size: 64)
!383 = !DIDerivedType(tag: DW_TAG_typedef, name: "__atomic_wide_counter", file: !384, line: 33, baseType: !385)
!384 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h", directory: "", checksumkind: CSK_MD5, checksum: "d1ec99b0f6e36c0a42ac284d459cbd38")
!385 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !384, line: 25, size: 64, elements: !386)
!386 = !{!387, !388}
!387 = !DIDerivedType(tag: DW_TAG_member, name: "__value64", scope: !385, file: !384, line: 27, baseType: !150, size: 64)
!388 = !DIDerivedType(tag: DW_TAG_member, name: "__value32", scope: !385, file: !384, line: 32, baseType: !389, size: 64)
!389 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !385, file: !384, line: 28, size: 64, elements: !390)
!390 = !{!391, !392}
!391 = !DIDerivedType(tag: DW_TAG_member, name: "__low", scope: !389, file: !384, line: 30, baseType: !7, size: 32)
!392 = !DIDerivedType(tag: DW_TAG_member, name: "__high", scope: !389, file: !384, line: 31, baseType: !7, size: 32, offset: 32)
!393 = !DIDerivedType(tag: DW_TAG_member, name: "__g1_start", scope: !380, file: !271, line: 97, baseType: !383, size: 64, offset: 64)
!394 = !DIDerivedType(tag: DW_TAG_member, name: "__g_refs", scope: !380, file: !271, line: 98, baseType: !395, size: 64, offset: 128)
!395 = !DICompositeType(tag: DW_TAG_array_type, baseType: !7, size: 64, elements: !210)
!396 = !DIDerivedType(tag: DW_TAG_member, name: "__g_size", scope: !380, file: !271, line: 99, baseType: !395, size: 64, offset: 192)
!397 = !DIDerivedType(tag: DW_TAG_member, name: "__g1_orig_size", scope: !380, file: !271, line: 100, baseType: !7, size: 32, offset: 256)
!398 = !DIDerivedType(tag: DW_TAG_member, name: "__wrefs", scope: !380, file: !271, line: 101, baseType: !7, size: 32, offset: 288)
!399 = !DIDerivedType(tag: DW_TAG_member, name: "__g_signals", scope: !380, file: !271, line: 102, baseType: !395, size: 64, offset: 320)
!400 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !377, file: !199, line: 78, baseType: !401, size: 384)
!401 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 384, elements: !402)
!402 = !{!403}
!403 = !DISubrange(count: 48)
!404 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !377, file: !199, line: 79, baseType: !405, size: 64)
!405 = !DIBasicType(name: "long long", size: 64, encoding: DW_ATE_signed)
!406 = !{i32 7, !"Dwarf Version", i32 5}
!407 = !{i32 2, !"Debug Info Version", i32 3}
!408 = !{i32 1, !"wchar_size", i32 4}
!409 = !{i32 8, !"PIC Level", i32 2}
!410 = !{i32 7, !"PIE Level", i32 2}
!411 = !{i32 7, !"uwtable", i32 2}
!412 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!413 = !{!"clang version 19.0.0git (https://github.com/focs-lab/llvm-project 1391bf3307650fe138825228e28ae298f4b570df)"}
!414 = distinct !DISubprogram(name: "slabs_set_storage", scope: !3, file: !3, line: 78, type: !415, scopeLine: 78, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !417)
!415 = !DISubroutineType(types: !416)
!416 = !{null, !128}
!417 = !{!418}
!418 = !DILocalVariable(name: "arg", arg: 1, scope: !414, file: !3, line: 78, type: !128)
!419 = !DILocation(line: 0, scope: !414)
!420 = !DILocation(line: 79, column: 13, scope: !414)
!421 = !{!422, !422, i64 0}
!422 = !{!"any pointer", !423, i64 0}
!423 = !{!"omnipotent char", !424, i64 0}
!424 = !{!"Simple C/C++ TBAA"}
!425 = !DILocation(line: 80, column: 1, scope: !414)
!426 = distinct !DISubprogram(name: "slabs_clsid", scope: !3, file: !3, line: 90, type: !427, scopeLine: 90, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !430)
!427 = !DISubroutineType(types: !428)
!428 = !{!7, !429}
!429 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !131)
!430 = !{!431, !432}
!431 = !DILocalVariable(name: "size", arg: 1, scope: !426, file: !3, line: 90, type: !429)
!432 = !DILocalVariable(name: "res", scope: !426, file: !3, line: 91, type: !102)
!433 = !DILocation(line: 0, scope: !426)
!434 = !DILocation(line: 93, column: 14, scope: !435)
!435 = distinct !DILexicalBlock(scope: !426, file: !3, line: 93, column: 9)
!436 = !DILocation(line: 93, column: 19, scope: !435)
!437 = !DILocation(line: 93, column: 38, scope: !435)
!438 = !{!439, !441, i64 116}
!439 = !{!"settings", !440, i64 0, !441, i64 8, !441, i64 12, !441, i64 16, !422, i64 24, !441, i64 32, !441, i64 36, !441, i64 40, !422, i64 48, !422, i64 56, !441, i64 64, !442, i64 72, !441, i64 80, !441, i64 84, !441, i64 88, !423, i64 92, !441, i64 96, !441, i64 100, !443, i64 104, !441, i64 108, !441, i64 112, !441, i64 116, !441, i64 120, !441, i64 124, !441, i64 128, !443, i64 132, !443, i64 133, !443, i64 134, !443, i64 135, !443, i64 136, !443, i64 137, !441, i64 140, !442, i64 144, !441, i64 152, !441, i64 156, !443, i64 160, !441, i64 164, !443, i64 168, !443, i64 169, !422, i64 176, !441, i64 184, !441, i64 188, !441, i64 192, !441, i64 196, !442, i64 200, !442, i64 208, !441, i64 216, !443, i64 220, !441, i64 224, !441, i64 228, !441, i64 232, !441, i64 236, !441, i64 240, !443, i64 244, !443, i64 245, !443, i64 246, !441, i64 248, !441, i64 252, !441, i64 256, !441, i64 260, !441, i64 264, !441, i64 268, !441, i64 272, !441, i64 276, !441, i64 280, !441, i64 284, !442, i64 288, !442, i64 296, !443, i64 304, !441, i64 308, !441, i64 312, !422, i64 320, !441, i64 328}
!440 = !{!"long", !423, i64 0}
!441 = !{!"int", !423, i64 0}
!442 = !{!"double", !423, i64 0}
!443 = !{!"_Bool", !423, i64 0}
!444 = !DILocation(line: 93, column: 29, scope: !435)
!445 = !DILocation(line: 93, column: 27, scope: !435)
!446 = !DILocation(line: 93, column: 9, scope: !426)
!447 = !DILocation(line: 95, column: 19, scope: !426)
!448 = !DILocation(line: 95, column: 34, scope: !426)
!449 = !{!450, !441, i64 0}
!450 = !{!"", !441, i64 0, !441, i64 4, !422, i64 8, !441, i64 16, !441, i64 20, !422, i64 24, !441, i64 32}
!451 = !DILocation(line: 95, column: 17, scope: !426)
!452 = !DILocation(line: 95, column: 5, scope: !426)
!453 = !DILocation(line: 96, column: 16, scope: !454)
!454 = distinct !DILexicalBlock(scope: !426, file: !3, line: 96, column: 13)
!455 = !DILocation(line: 96, column: 22, scope: !454)
!456 = !{!441, !441, i64 0}
!457 = !DILocation(line: 96, column: 19, scope: !454)
!458 = !DILocation(line: 96, column: 13, scope: !426)
!459 = distinct !{!459, !452, !460, !461}
!460 = !DILocation(line: 97, column: 20, scope: !426)
!461 = !{!"llvm.loop.mustprogress"}
!462 = !DILocation(line: 99, column: 1, scope: !426)
!463 = distinct !DISubprogram(name: "slabs_size", scope: !3, file: !3, line: 101, type: !464, scopeLine: 101, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !467)
!464 = !DISubroutineType(types: !465)
!465 = !{!7, !466}
!466 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !102)
!467 = !{!468}
!468 = !DILocalVariable(name: "clsid", arg: 1, scope: !463, file: !3, line: 101, type: !466)
!469 = !DILocation(line: 0, scope: !463)
!470 = !DILocation(line: 102, column: 12, scope: !463)
!471 = !DILocation(line: 102, column: 29, scope: !463)
!472 = !DILocation(line: 102, column: 5, scope: !463)
!473 = distinct !DISubprogram(name: "slabs_fixup", scope: !3, file: !3, line: 166, type: !474, scopeLine: 166, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !476)
!474 = !DISubroutineType(types: !475)
!475 = !{!7, !127, !466}
!476 = !{!477, !478, !479, !481, !482}
!477 = !DILocalVariable(name: "chunk", arg: 1, scope: !473, file: !3, line: 166, type: !127)
!478 = !DILocalVariable(name: "border", arg: 2, scope: !473, file: !3, line: 166, type: !466)
!479 = !DILocalVariable(name: "p", scope: !473, file: !3, line: 167, type: !480)
!480 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !181, size: 64)
!481 = !DILocalVariable(name: "it", scope: !473, file: !3, line: 168, type: !90)
!482 = !DILocalVariable(name: "id", scope: !473, file: !3, line: 169, type: !102)
!483 = !DILocation(line: 0, scope: !473)
!484 = !DILocation(line: 169, column: 14, scope: !473)
!485 = !{!423, !423, i64 0}
!486 = !DILocation(line: 173, column: 12, scope: !487)
!487 = distinct !DILexicalBlock(scope: !473, file: !3, line: 173, column: 9)
!488 = !DILocation(line: 173, column: 9, scope: !473)
!489 = !DILocalVariable(name: "id", arg: 1, scope: !490, file: !3, line: 337, type: !493)
!490 = distinct !DISubprogram(name: "grow_slab_list", scope: !3, file: !3, line: 337, type: !491, scopeLine: 337, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !494)
!491 = !DISubroutineType(types: !492)
!492 = !{!102, !493}
!493 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !7)
!494 = !{!489, !495, !496, !499}
!495 = !DILocalVariable(name: "p", scope: !490, file: !3, line: 338, type: !480)
!496 = !DILocalVariable(name: "new_size", scope: !497, file: !3, line: 340, type: !131)
!497 = distinct !DILexicalBlock(scope: !498, file: !3, line: 339, column: 35)
!498 = distinct !DILexicalBlock(scope: !490, file: !3, line: 339, column: 9)
!499 = !DILocalVariable(name: "new_list", scope: !497, file: !3, line: 341, type: !128)
!500 = !DILocation(line: 0, scope: !490, inlinedAt: !501)
!501 = distinct !DILocation(line: 176, column: 9, scope: !502)
!502 = distinct !DILexicalBlock(scope: !487, file: !3, line: 173, column: 18)
!503 = !DILocation(line: 339, column: 12, scope: !498, inlinedAt: !501)
!504 = !{!450, !441, i64 20}
!505 = !DILocation(line: 339, column: 24, scope: !498, inlinedAt: !501)
!506 = !{!450, !441, i64 32}
!507 = !DILocation(line: 339, column: 18, scope: !498, inlinedAt: !501)
!508 = !DILocation(line: 177, column: 12, scope: !502)
!509 = !{!450, !422, i64 24}
!510 = !DILocation(line: 339, column: 9, scope: !490, inlinedAt: !501)
!511 = !DILocation(line: 340, column: 42, scope: !497, inlinedAt: !501)
!512 = !DILocation(line: 340, column: 28, scope: !497, inlinedAt: !501)
!513 = !DILocation(line: 0, scope: !497, inlinedAt: !501)
!514 = !DILocation(line: 341, column: 57, scope: !497, inlinedAt: !501)
!515 = !DILocation(line: 341, column: 26, scope: !497, inlinedAt: !501)
!516 = !DILocation(line: 342, column: 22, scope: !517, inlinedAt: !501)
!517 = distinct !DILexicalBlock(scope: !497, file: !3, line: 342, column: 13)
!518 = !DILocation(line: 342, column: 13, scope: !497, inlinedAt: !501)
!519 = !DILocation(line: 343, column: 22, scope: !497, inlinedAt: !501)
!520 = !DILocation(line: 344, column: 22, scope: !497, inlinedAt: !501)
!521 = !DILocation(line: 177, column: 30, scope: !502)
!522 = !DILocation(line: 177, column: 9, scope: !502)
!523 = !DILocation(line: 177, column: 34, scope: !502)
!524 = !DILocation(line: 178, column: 9, scope: !502)
!525 = !DILocation(line: 180, column: 10, scope: !473)
!526 = !DILocation(line: 183, column: 16, scope: !527)
!527 = distinct !DILexicalBlock(scope: !473, file: !3, line: 183, column: 9)
!528 = !DILocation(line: 183, column: 9, scope: !473)
!529 = !DILocation(line: 0, scope: !490, inlinedAt: !530)
!530 = distinct !DILocation(line: 184, column: 9, scope: !531)
!531 = distinct !DILexicalBlock(scope: !527, file: !3, line: 183, column: 22)
!532 = !DILocation(line: 339, column: 12, scope: !498, inlinedAt: !530)
!533 = !DILocation(line: 339, column: 24, scope: !498, inlinedAt: !530)
!534 = !DILocation(line: 339, column: 18, scope: !498, inlinedAt: !530)
!535 = !DILocation(line: 339, column: 9, scope: !490, inlinedAt: !530)
!536 = !DILocation(line: 340, column: 42, scope: !497, inlinedAt: !530)
!537 = !DILocation(line: 340, column: 28, scope: !497, inlinedAt: !530)
!538 = !DILocation(line: 0, scope: !497, inlinedAt: !530)
!539 = !DILocation(line: 341, column: 37, scope: !497, inlinedAt: !530)
!540 = !DILocation(line: 341, column: 57, scope: !497, inlinedAt: !530)
!541 = !DILocation(line: 341, column: 26, scope: !497, inlinedAt: !530)
!542 = !DILocation(line: 342, column: 22, scope: !517, inlinedAt: !530)
!543 = !DILocation(line: 342, column: 13, scope: !497, inlinedAt: !530)
!544 = !DILocation(line: 343, column: 22, scope: !497, inlinedAt: !530)
!545 = !DILocation(line: 344, column: 22, scope: !497, inlinedAt: !530)
!546 = !DILocation(line: 185, column: 12, scope: !531)
!547 = !DILocation(line: 185, column: 30, scope: !531)
!548 = !DILocation(line: 185, column: 9, scope: !531)
!549 = !DILocation(line: 185, column: 34, scope: !531)
!550 = !DILocation(line: 186, column: 5, scope: !531)
!551 = !DILocation(line: 189, column: 13, scope: !552)
!552 = distinct !DILexicalBlock(scope: !473, file: !3, line: 189, column: 9)
!553 = !{!554, !554, i64 0}
!554 = !{!"short", !423, i64 0}
!555 = !DILocation(line: 189, column: 22, scope: !552)
!556 = !DILocation(line: 189, column: 9, scope: !473)
!557 = !DILocation(line: 192, column: 13, scope: !558)
!558 = distinct !DILexicalBlock(scope: !552, file: !3, line: 189, column: 39)
!559 = !DILocation(line: 192, column: 18, scope: !558)
!560 = !DILocation(line: 193, column: 23, scope: !558)
!561 = !{!450, !422, i64 8}
!562 = !DILocation(line: 193, column: 18, scope: !558)
!563 = !DILocation(line: 194, column: 13, scope: !564)
!564 = distinct !DILexicalBlock(scope: !558, file: !3, line: 194, column: 13)
!565 = !DILocation(line: 194, column: 13, scope: !558)
!566 = !DILocation(line: 194, column: 33, scope: !564)
!567 = !DILocation(line: 194, column: 38, scope: !564)
!568 = !DILocation(line: 194, column: 23, scope: !564)
!569 = !DILocation(line: 195, column: 18, scope: !558)
!570 = !DILocation(line: 197, column: 12, scope: !558)
!571 = !DILocation(line: 197, column: 19, scope: !558)
!572 = !{!450, !441, i64 16}
!573 = !DILocation(line: 199, column: 5, scope: !558)
!574 = !DILocation(line: 201, column: 15, scope: !473)
!575 = !DILocation(line: 201, column: 5, scope: !473)
!576 = !DILocation(line: 202, column: 1, scope: !473)
!577 = distinct !DISubprogram(name: "slabs_init", scope: !3, file: !3, line: 208, type: !578, scopeLine: 208, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !587)
!578 = !DISubroutineType(types: !579)
!579 = !{null, !429, !580, !582, !583, !128, !246}
!580 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !581)
!581 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!582 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !246)
!583 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !584, size: 64)
!584 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !585)
!585 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !107, line: 26, baseType: !586)
!586 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !109, line: 42, baseType: !7)
!587 = !{!588, !589, !590, !591, !592, !593, !594, !595, !596, !597, !599}
!588 = !DILocalVariable(name: "limit", arg: 1, scope: !577, file: !3, line: 208, type: !429)
!589 = !DILocalVariable(name: "factor", arg: 2, scope: !577, file: !3, line: 208, type: !580)
!590 = !DILocalVariable(name: "prealloc", arg: 3, scope: !577, file: !3, line: 208, type: !582)
!591 = !DILocalVariable(name: "slab_sizes", arg: 4, scope: !577, file: !3, line: 208, type: !583)
!592 = !DILocalVariable(name: "mem_base_external", arg: 5, scope: !577, file: !3, line: 208, type: !128)
!593 = !DILocalVariable(name: "reuse_mem", arg: 6, scope: !577, file: !3, line: 208, type: !246)
!594 = !DILocalVariable(name: "i", scope: !577, file: !3, line: 209, type: !102)
!595 = !DILocalVariable(name: "size", scope: !577, file: !3, line: 210, type: !7)
!596 = !DILocalVariable(name: "do_slab_prealloc", scope: !577, file: !3, line: 216, type: !246)
!597 = !DILocalVariable(name: "t_initial_malloc", scope: !598, file: !3, line: 281, type: !127)
!598 = distinct !DILexicalBlock(scope: !577, file: !3, line: 280, column: 5)
!599 = !DILocalVariable(name: "env_malloced", scope: !600, file: !3, line: 283, type: !602)
!600 = distinct !DILexicalBlock(scope: !601, file: !3, line: 282, column: 31)
!601 = distinct !DILexicalBlock(scope: !598, file: !3, line: 282, column: 13)
!602 = !DIDerivedType(tag: DW_TAG_typedef, name: "int64_t", file: !603, line: 27, baseType: !604)
!603 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h", directory: "", checksumkind: CSK_MD5, checksum: "649b383a60bfa3eb90e85840b2b0be20")
!604 = !DIDerivedType(tag: DW_TAG_typedef, name: "__int64_t", file: !109, line: 44, baseType: !279)
!605 = distinct !DIAssignID()
!606 = !DILocalVariable(name: "ptr", scope: !607, file: !3, line: 110, type: !128)
!607 = distinct !DISubprogram(name: "alloc_large_chunk", scope: !3, file: !3, line: 108, type: !608, scopeLine: 109, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !610)
!608 = !DISubroutineType(types: !609)
!609 = !{!128, !429}
!610 = !{!611, !606, !612, !613, !667, !668}
!611 = !DILocalVariable(name: "limit", arg: 1, scope: !607, file: !3, line: 108, type: !429)
!612 = !DILocalVariable(name: "pagesize", scope: !607, file: !3, line: 112, type: !131)
!613 = !DILocalVariable(name: "fp", scope: !607, file: !3, line: 113, type: !614)
!614 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !615, size: 64)
!615 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !616, line: 7, baseType: !617)
!616 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!617 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !618, line: 49, size: 1728, elements: !619)
!618 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "7a6d4a00a37ee6b9a40cd04bd01f5d00")
!619 = !{!620, !621, !622, !623, !624, !625, !626, !627, !628, !629, !630, !631, !632, !635, !637, !638, !639, !641, !642, !644, !648, !651, !653, !656, !659, !660, !661, !662, !663}
!620 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !617, file: !618, line: 51, baseType: !102, size: 32)
!621 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !617, file: !618, line: 54, baseType: !127, size: 64, offset: 64)
!622 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !617, file: !618, line: 55, baseType: !127, size: 64, offset: 128)
!623 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !617, file: !618, line: 56, baseType: !127, size: 64, offset: 192)
!624 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !617, file: !618, line: 57, baseType: !127, size: 64, offset: 256)
!625 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !617, file: !618, line: 58, baseType: !127, size: 64, offset: 320)
!626 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !617, file: !618, line: 59, baseType: !127, size: 64, offset: 384)
!627 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !617, file: !618, line: 60, baseType: !127, size: 64, offset: 448)
!628 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !617, file: !618, line: 61, baseType: !127, size: 64, offset: 512)
!629 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !617, file: !618, line: 64, baseType: !127, size: 64, offset: 576)
!630 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !617, file: !618, line: 65, baseType: !127, size: 64, offset: 640)
!631 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !617, file: !618, line: 66, baseType: !127, size: 64, offset: 704)
!632 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !617, file: !618, line: 68, baseType: !633, size: 64, offset: 768)
!633 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !634, size: 64)
!634 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !618, line: 36, flags: DIFlagFwdDecl)
!635 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !617, file: !618, line: 70, baseType: !636, size: 64, offset: 832)
!636 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !617, size: 64)
!637 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !617, file: !618, line: 72, baseType: !102, size: 32, offset: 896)
!638 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !617, file: !618, line: 73, baseType: !102, size: 32, offset: 928)
!639 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !617, file: !618, line: 74, baseType: !640, size: 64, offset: 960)
!640 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !109, line: 152, baseType: !279)
!641 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !617, file: !618, line: 77, baseType: !104, size: 16, offset: 1024)
!642 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !617, file: !618, line: 78, baseType: !643, size: 8, offset: 1040)
!643 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!644 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !617, file: !618, line: 79, baseType: !645, size: 8, offset: 1048)
!645 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 8, elements: !646)
!646 = !{!647}
!647 = !DISubrange(count: 1)
!648 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !617, file: !618, line: 81, baseType: !649, size: 64, offset: 1088)
!649 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !650, size: 64)
!650 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !618, line: 43, baseType: null)
!651 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !617, file: !618, line: 89, baseType: !652, size: 64, offset: 1152)
!652 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !109, line: 153, baseType: !279)
!653 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !617, file: !618, line: 91, baseType: !654, size: 64, offset: 1216)
!654 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !655, size: 64)
!655 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !618, line: 37, flags: DIFlagFwdDecl)
!656 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !617, file: !618, line: 92, baseType: !657, size: 64, offset: 1280)
!657 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !658, size: 64)
!658 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !618, line: 38, flags: DIFlagFwdDecl)
!659 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !617, file: !618, line: 93, baseType: !636, size: 64, offset: 1344)
!660 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !617, file: !618, line: 94, baseType: !128, size: 64, offset: 1408)
!661 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !617, file: !618, line: 95, baseType: !131, size: 64, offset: 1472)
!662 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !617, file: !618, line: 96, baseType: !102, size: 32, offset: 1536)
!663 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !617, file: !618, line: 98, baseType: !664, size: 160, offset: 1568)
!664 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 160, elements: !665)
!665 = !{!666}
!666 = !DISubrange(count: 20)
!667 = !DILocalVariable(name: "ret", scope: !607, file: !3, line: 114, type: !102)
!668 = !DILocalVariable(name: "buf", scope: !669, file: !3, line: 119, type: !671)
!669 = distinct !DILexicalBlock(scope: !670, file: !3, line: 118, column: 21)
!670 = distinct !DILexicalBlock(scope: !607, file: !3, line: 118, column: 9)
!671 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 512, elements: !192)
!672 = !DILocation(line: 0, scope: !607, inlinedAt: !673)
!673 = distinct !DILocation(line: 221, column: 20, scope: !674)
!674 = distinct !DILexicalBlock(scope: !675, file: !3, line: 220, column: 48)
!675 = distinct !DILexicalBlock(scope: !577, file: !3, line: 220, column: 9)
!676 = distinct !DIAssignID()
!677 = distinct !DIAssignID()
!678 = distinct !DIAssignID()
!679 = !DILocation(line: 0, scope: !600)
!680 = !DILocation(line: 0, scope: !577)
!681 = !DILocation(line: 210, column: 49, scope: !577)
!682 = !{!439, !441, i64 80}
!683 = !DILocation(line: 210, column: 38, scope: !577)
!684 = !DILocation(line: 218, column: 15, scope: !577)
!685 = !{!440, !440, i64 0}
!686 = !DILocation(line: 220, column: 18, scope: !675)
!687 = !DILocation(line: 0, scope: !669, inlinedAt: !673)
!688 = !DILocation(line: 110, column: 5, scope: !607, inlinedAt: !673)
!689 = !DILocation(line: 110, column: 11, scope: !607, inlinedAt: !673)
!690 = distinct !DIAssignID()
!691 = !DILocation(line: 112, column: 5, scope: !607, inlinedAt: !673)
!692 = !DILocation(line: 112, column: 12, scope: !607, inlinedAt: !673)
!693 = distinct !DIAssignID()
!694 = !DILocation(line: 117, column: 10, scope: !607, inlinedAt: !673)
!695 = !DILocation(line: 118, column: 12, scope: !670, inlinedAt: !673)
!696 = !DILocation(line: 118, column: 9, scope: !607, inlinedAt: !673)
!697 = !DILocation(line: 119, column: 9, scope: !669, inlinedAt: !673)
!698 = !DILocation(line: 121, column: 17, scope: !669, inlinedAt: !673)
!699 = !DILocation(line: 121, column: 9, scope: !669, inlinedAt: !673)
!700 = !DILocation(line: 122, column: 18, scope: !701, inlinedAt: !673)
!701 = distinct !DILexicalBlock(scope: !669, file: !3, line: 122, column: 17)
!702 = !DILocation(line: 122, column: 17, scope: !669, inlinedAt: !673)
!703 = !DILocation(line: 123, column: 23, scope: !704, inlinedAt: !673)
!704 = distinct !DILexicalBlock(scope: !701, file: !3, line: 122, column: 53)
!705 = !DILocation(line: 126, column: 26, scope: !704, inlinedAt: !673)
!706 = distinct !DIAssignID()
!707 = !DILocation(line: 127, column: 13, scope: !704, inlinedAt: !673)
!708 = distinct !{!708, !699, !709, !461}
!709 = !DILocation(line: 127, column: 13, scope: !669, inlinedAt: !673)
!710 = !DILocation(line: 128, column: 9, scope: !669, inlinedAt: !673)
!711 = !DILocation(line: 129, column: 5, scope: !670, inlinedAt: !673)
!712 = !DILocation(line: 131, column: 10, scope: !713, inlinedAt: !673)
!713 = distinct !DILexicalBlock(scope: !607, file: !3, line: 131, column: 9)
!714 = !DILocation(line: 131, column: 9, scope: !607, inlinedAt: !673)
!715 = !DILocation(line: 132, column: 17, scope: !716, inlinedAt: !673)
!716 = distinct !DILexicalBlock(scope: !713, file: !3, line: 131, column: 20)
!717 = !DILocation(line: 132, column: 9, scope: !716, inlinedAt: !673)
!718 = !DILocation(line: 133, column: 9, scope: !716, inlinedAt: !673)
!719 = !DILocation(line: 136, column: 18, scope: !720, inlinedAt: !673)
!720 = distinct !DILexicalBlock(scope: !607, file: !3, line: 136, column: 9)
!721 = !{!439, !441, i64 32}
!722 = !DILocation(line: 136, column: 26, scope: !720, inlinedAt: !673)
!723 = !DILocation(line: 136, column: 9, scope: !607, inlinedAt: !673)
!724 = !DILocation(line: 137, column: 17, scope: !720, inlinedAt: !673)
!725 = !DILocation(line: 137, column: 9, scope: !720, inlinedAt: !673)
!726 = !DILocation(line: 141, column: 32, scope: !607, inlinedAt: !673)
!727 = !DILocation(line: 141, column: 11, scope: !607, inlinedAt: !673)
!728 = !DILocation(line: 142, column: 13, scope: !729, inlinedAt: !673)
!729 = distinct !DILexicalBlock(scope: !607, file: !3, line: 142, column: 9)
!730 = !DILocation(line: 142, column: 9, scope: !607, inlinedAt: !673)
!731 = !DILocation(line: 143, column: 17, scope: !732, inlinedAt: !673)
!732 = distinct !DILexicalBlock(scope: !729, file: !3, line: 142, column: 19)
!733 = !DILocation(line: 143, column: 9, scope: !732, inlinedAt: !673)
!734 = !DILocation(line: 144, column: 9, scope: !732, inlinedAt: !673)
!735 = !DILocation(line: 147, column: 19, scope: !607, inlinedAt: !673)
!736 = !DILocation(line: 147, column: 11, scope: !607, inlinedAt: !673)
!737 = !DILocation(line: 148, column: 13, scope: !738, inlinedAt: !673)
!738 = distinct !DILexicalBlock(scope: !607, file: !3, line: 148, column: 9)
!739 = !DILocation(line: 148, column: 9, scope: !607, inlinedAt: !673)
!740 = !DILocation(line: 149, column: 17, scope: !741, inlinedAt: !673)
!741 = distinct !DILexicalBlock(scope: !738, file: !3, line: 148, column: 18)
!742 = !DILocation(line: 149, column: 9, scope: !741, inlinedAt: !673)
!743 = !DILocation(line: 150, column: 14, scope: !741, inlinedAt: !673)
!744 = !DILocation(line: 150, column: 9, scope: !741, inlinedAt: !673)
!745 = distinct !DIAssignID()
!746 = !DILocation(line: 152, column: 5, scope: !741, inlinedAt: !673)
!747 = !DILocation(line: 164, column: 1, scope: !607, inlinedAt: !673)
!748 = !DILocation(line: 221, column: 18, scope: !674)
!749 = !DILocation(line: 222, column: 13, scope: !674)
!750 = !DILocation(line: 163, column: 12, scope: !607, inlinedAt: !673)
!751 = !DILocation(line: 222, column: 13, scope: !752)
!752 = distinct !DILexicalBlock(scope: !674, file: !3, line: 222, column: 13)
!753 = !DILocation(line: 224, column: 25, scope: !754)
!754 = distinct !DILexicalBlock(scope: !752, file: !3, line: 222, column: 23)
!755 = !DILocation(line: 225, column: 25, scope: !754)
!756 = !DILocation(line: 225, column: 23, scope: !754)
!757 = !DILocation(line: 226, column: 9, scope: !754)
!758 = !DILocation(line: 227, column: 21, scope: !759)
!759 = distinct !DILexicalBlock(scope: !752, file: !3, line: 226, column: 16)
!760 = !DILocation(line: 227, column: 13, scope: !759)
!761 = !DILocation(line: 230, column: 25, scope: !762)
!762 = distinct !DILexicalBlock(scope: !675, file: !3, line: 230, column: 16)
!763 = !DILocation(line: 235, column: 18, scope: !764)
!764 = distinct !DILexicalBlock(scope: !762, file: !3, line: 230, column: 55)
!765 = !DILocation(line: 238, column: 13, scope: !764)
!766 = !DILocation(line: 239, column: 45, scope: !767)
!767 = distinct !DILexicalBlock(scope: !768, file: !3, line: 238, column: 24)
!768 = distinct !DILexicalBlock(scope: !764, file: !3, line: 238, column: 13)
!769 = !DILocation(line: 239, column: 25, scope: !767)
!770 = !DILocation(line: 240, column: 23, scope: !767)
!771 = !DILocation(line: 241, column: 9, scope: !767)
!772 = !DILocation(line: 242, column: 25, scope: !773)
!773 = distinct !DILexicalBlock(scope: !768, file: !3, line: 241, column: 16)
!774 = !DILocation(line: 243, column: 23, scope: !773)
!775 = !DILocation(line: 247, column: 5, scope: !577)
!776 = !DILocation(line: 249, column: 5, scope: !577)
!777 = !DILocation(line: 250, column: 13, scope: !778)
!778 = distinct !DILexicalBlock(scope: !577, file: !3, line: 249, column: 48)
!779 = !DILocation(line: 251, column: 17, scope: !780)
!780 = distinct !DILexicalBlock(scope: !781, file: !3, line: 251, column: 17)
!781 = distinct !DILexicalBlock(scope: !782, file: !3, line: 250, column: 33)
!782 = distinct !DILexicalBlock(scope: !778, file: !3, line: 250, column: 13)
!783 = !DILocation(line: 251, column: 33, scope: !780)
!784 = !DILocation(line: 251, column: 17, scope: !781)
!785 = !DILocation(line: 254, column: 20, scope: !786)
!786 = distinct !DILexicalBlock(scope: !782, file: !3, line: 254, column: 20)
!787 = !DILocation(line: 254, column: 37, scope: !786)
!788 = !{!439, !441, i64 120}
!789 = !DILocation(line: 254, column: 28, scope: !786)
!790 = !DILocation(line: 254, column: 57, scope: !786)
!791 = !DILocation(line: 254, column: 25, scope: !786)
!792 = !DILocation(line: 254, column: 20, scope: !782)
!793 = !DILocation(line: 258, column: 13, scope: !778)
!794 = !DILocation(line: 261, column: 9, scope: !778)
!795 = !DILocation(line: 261, column: 27, scope: !778)
!796 = !DILocation(line: 262, column: 41, scope: !778)
!797 = !{!439, !441, i64 124}
!798 = !DILocation(line: 262, column: 56, scope: !778)
!799 = !DILocation(line: 262, column: 22, scope: !778)
!800 = !DILocation(line: 262, column: 30, scope: !778)
!801 = !{!450, !441, i64 4}
!802 = !DILocation(line: 263, column: 13, scope: !778)
!803 = !DILocation(line: 265, column: 22, scope: !804)
!804 = distinct !DILexicalBlock(scope: !778, file: !3, line: 265, column: 13)
!805 = !DILocation(line: 265, column: 30, scope: !804)
!806 = !DILocation(line: 265, column: 13, scope: !778)
!807 = !DILocation(line: 266, column: 21, scope: !808)
!808 = distinct !DILexicalBlock(scope: !804, file: !3, line: 265, column: 35)
!809 = !DILocation(line: 266, column: 13, scope: !808)
!810 = !DILocation(line: 268, column: 9, scope: !808)
!811 = !DILocation(line: 249, column: 12, scope: !577)
!812 = !DILocation(line: 249, column: 16, scope: !577)
!813 = distinct !{!813, !776, !814, !461}
!814 = !DILocation(line: 269, column: 5, scope: !577)
!815 = !DILocation(line: 271, column: 19, scope: !577)
!816 = !DILocation(line: 272, column: 46, scope: !577)
!817 = !DILocation(line: 272, column: 5, scope: !577)
!818 = !DILocation(line: 272, column: 35, scope: !577)
!819 = !DILocation(line: 273, column: 49, scope: !577)
!820 = !DILocation(line: 273, column: 64, scope: !577)
!821 = !DILocation(line: 273, column: 30, scope: !577)
!822 = !DILocation(line: 273, column: 38, scope: !577)
!823 = !DILocation(line: 274, column: 18, scope: !824)
!824 = distinct !DILexicalBlock(scope: !577, file: !3, line: 274, column: 9)
!825 = !DILocation(line: 274, column: 26, scope: !824)
!826 = !DILocation(line: 274, column: 9, scope: !577)
!827 = !DILocation(line: 275, column: 17, scope: !828)
!828 = distinct !DILexicalBlock(scope: !824, file: !3, line: 274, column: 31)
!829 = !DILocation(line: 275, column: 9, scope: !828)
!830 = !DILocation(line: 277, column: 5, scope: !828)
!831 = !DILocation(line: 281, column: 34, scope: !598)
!832 = !DILocation(line: 0, scope: !598)
!833 = !DILocation(line: 282, column: 13, scope: !601)
!834 = !DILocation(line: 282, column: 13, scope: !598)
!835 = !DILocation(line: 283, column: 13, scope: !600)
!836 = !DILocation(line: 284, column: 17, scope: !837)
!837 = distinct !DILexicalBlock(scope: !600, file: !3, line: 284, column: 17)
!838 = !DILocation(line: 284, column: 17, scope: !600)
!839 = !DILocation(line: 285, column: 40, scope: !840)
!840 = distinct !DILexicalBlock(scope: !837, file: !3, line: 284, column: 78)
!841 = !DILocation(line: 285, column: 30, scope: !840)
!842 = !DILocation(line: 286, column: 13, scope: !840)
!843 = !DILocation(line: 287, column: 9, scope: !601)
!844 = !DILocation(line: 287, column: 9, scope: !600)
!845 = !DILocation(line: 291, column: 9, scope: !577)
!846 = !DILocation(line: 293, column: 31, scope: !847)
!847 = distinct !DILexicalBlock(scope: !848, file: !3, line: 292, column: 25)
!848 = distinct !DILexicalBlock(scope: !849, file: !3, line: 292, column: 13)
!849 = distinct !DILexicalBlock(scope: !850, file: !3, line: 291, column: 27)
!850 = distinct !DILexicalBlock(scope: !577, file: !3, line: 291, column: 9)
!851 = !DILocalVariable(name: "maxslabs", arg: 1, scope: !852, file: !3, line: 315, type: !493)
!852 = distinct !DISubprogram(name: "slabs_preallocate", scope: !3, file: !3, line: 315, type: !853, scopeLine: 315, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !855)
!853 = !DISubroutineType(types: !854)
!854 = !{null, !493}
!855 = !{!851, !856, !857}
!856 = !DILocalVariable(name: "i", scope: !852, file: !3, line: 316, type: !102)
!857 = !DILocalVariable(name: "prealloc", scope: !852, file: !3, line: 317, type: !7)
!858 = !DILocation(line: 0, scope: !852, inlinedAt: !859)
!859 = distinct !DILocation(line: 293, column: 13, scope: !847)
!860 = !DILocation(line: 325, column: 5, scope: !861, inlinedAt: !859)
!861 = distinct !DILexicalBlock(scope: !852, file: !3, line: 325, column: 5)
!862 = !DILocation(line: 325, column: 63, scope: !863, inlinedAt: !859)
!863 = distinct !DILexicalBlock(scope: !861, file: !3, line: 325, column: 5)
!864 = !DILocation(line: 325, column: 32, scope: !863, inlinedAt: !859)
!865 = distinct !{!865, !860, !866, !461}
!866 = !DILocation(line: 334, column: 5, scope: !861, inlinedAt: !859)
!867 = !DILocation(line: 326, column: 13, scope: !868, inlinedAt: !859)
!868 = distinct !DILexicalBlock(scope: !869, file: !3, line: 326, column: 13)
!869 = distinct !DILexicalBlock(scope: !863, file: !3, line: 325, column: 67)
!870 = !DILocation(line: 326, column: 24, scope: !868, inlinedAt: !859)
!871 = !DILocation(line: 326, column: 13, scope: !869, inlinedAt: !859)
!872 = !DILocation(line: 328, column: 13, scope: !873, inlinedAt: !859)
!873 = distinct !DILexicalBlock(scope: !869, file: !3, line: 328, column: 13)
!874 = !DILocation(line: 328, column: 33, scope: !873, inlinedAt: !859)
!875 = !DILocation(line: 328, column: 13, scope: !869, inlinedAt: !859)
!876 = !DILocation(line: 329, column: 21, scope: !877, inlinedAt: !859)
!877 = distinct !DILexicalBlock(scope: !873, file: !3, line: 328, column: 39)
!878 = !DILocation(line: 331, column: 45, scope: !877, inlinedAt: !859)
!879 = !DILocation(line: 329, column: 13, scope: !877, inlinedAt: !859)
!880 = !DILocation(line: 332, column: 13, scope: !877, inlinedAt: !859)
!881 = !DILocation(line: 296, column: 1, scope: !577)
!882 = !DISubprogram(name: "fprintf", scope: !883, file: !883, line: 357, type: !884, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!883 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "1e435c46987a169d9f9186f63a512303")
!884 = !DISubroutineType(types: !885)
!885 = !{!102, !886, !887, null}
!886 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !614)
!887 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !129)
!888 = !DISubprogram(name: "getenv", scope: !889, file: !889, line: 773, type: !890, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!889 = !DIFile(filename: "/usr/include/stdlib.h", directory: "", checksumkind: CSK_MD5, checksum: "7fa2ecb2348a66f8b44ab9a15abd0b72")
!890 = !DISubroutineType(types: !891)
!891 = !{!127, !129}
!892 = !DISubprogram(name: "safe_strtoll", scope: !893, file: !893, line: 18, type: !894, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!893 = !DIFile(filename: "./util.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d1ef68c688867746f50aae7567be079a")
!894 = !DISubroutineType(types: !895)
!895 = !{!246, !129, !896}
!896 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !602, size: 64)
!897 = distinct !DISubprogram(name: "slabs_prefill_global", scope: !3, file: !3, line: 298, type: !898, scopeLine: 298, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !900)
!898 = !DISubroutineType(types: !899)
!899 = !{null}
!900 = !{!901, !902, !903}
!901 = !DILocalVariable(name: "ptr", scope: !897, file: !3, line: 299, type: !128)
!902 = !DILocalVariable(name: "p", scope: !897, file: !3, line: 300, type: !480)
!903 = !DILocalVariable(name: "len", scope: !897, file: !3, line: 301, type: !102)
!904 = !DILocation(line: 0, scope: !897)
!905 = !DILocation(line: 303, column: 25, scope: !897)
!906 = !DILocation(line: 304, column: 13, scope: !897)
!907 = !DILocation(line: 301, column: 24, scope: !897)
!908 = !DILocalVariable(name: "size", arg: 1, scope: !909, file: !3, line: 610, type: !131)
!909 = distinct !DISubprogram(name: "memory_allocate", scope: !3, file: !3, line: 610, type: !910, scopeLine: 610, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !912)
!910 = !DISubroutineType(types: !911)
!911 = !{!128, !131}
!912 = !{!908, !913}
!913 = !DILocalVariable(name: "ret", scope: !909, file: !3, line: 611, type: !128)
!914 = !DILocation(line: 0, scope: !909, inlinedAt: !915)
!915 = distinct !DILocation(line: 304, column: 23, scope: !897)
!916 = !DILocation(line: 613, column: 9, scope: !909, inlinedAt: !915)
!917 = !DILocation(line: 615, column: 15, scope: !918, inlinedAt: !915)
!918 = distinct !DILexicalBlock(scope: !919, file: !3, line: 613, column: 27)
!919 = distinct !DILexicalBlock(scope: !909, file: !3, line: 613, column: 9)
!920 = !DILocation(line: 616, column: 5, scope: !918, inlinedAt: !915)
!921 = !DILocation(line: 619, column: 18, scope: !922, inlinedAt: !915)
!922 = distinct !DILexicalBlock(scope: !923, file: !3, line: 619, column: 13)
!923 = distinct !DILexicalBlock(scope: !919, file: !3, line: 616, column: 12)
!924 = !DILocation(line: 619, column: 13, scope: !923, inlinedAt: !915)
!925 = !DILocation(line: 628, column: 44, scope: !923, inlinedAt: !915)
!926 = !DILocation(line: 628, column: 21, scope: !923, inlinedAt: !915)
!927 = !DILocation(line: 629, column: 18, scope: !928, inlinedAt: !915)
!928 = distinct !DILexicalBlock(scope: !923, file: !3, line: 629, column: 13)
!929 = !DILocation(line: 629, column: 13, scope: !923, inlinedAt: !915)
!930 = !DILocation(line: 630, column: 23, scope: !931, inlinedAt: !915)
!931 = distinct !DILexicalBlock(scope: !928, file: !3, line: 629, column: 31)
!932 = !DILocation(line: 631, column: 9, scope: !931, inlinedAt: !915)
!933 = !DILocation(line: 632, column: 23, scope: !934, inlinedAt: !915)
!934 = distinct !DILexicalBlock(scope: !928, file: !3, line: 631, column: 16)
!935 = !DILocation(line: 0, scope: !919, inlinedAt: !915)
!936 = !DILocation(line: 635, column: 18, scope: !909, inlinedAt: !915)
!937 = !DILocation(line: 304, column: 45, scope: !897)
!938 = !DILocation(line: 303, column: 5, scope: !897)
!939 = !DILocation(line: 0, scope: !490, inlinedAt: !940)
!940 = distinct !DILocation(line: 305, column: 9, scope: !941)
!941 = distinct !DILexicalBlock(scope: !897, file: !3, line: 304, column: 54)
!942 = !DILocation(line: 339, column: 18, scope: !498, inlinedAt: !940)
!943 = !DILocation(line: 339, column: 9, scope: !490, inlinedAt: !940)
!944 = !DILocation(line: 340, column: 42, scope: !497, inlinedAt: !940)
!945 = !DILocation(line: 340, column: 28, scope: !497, inlinedAt: !940)
!946 = !DILocation(line: 0, scope: !497, inlinedAt: !940)
!947 = !DILocation(line: 341, column: 57, scope: !497, inlinedAt: !940)
!948 = !DILocation(line: 341, column: 26, scope: !497, inlinedAt: !940)
!949 = !DILocation(line: 342, column: 22, scope: !517, inlinedAt: !940)
!950 = !DILocation(line: 342, column: 13, scope: !497, inlinedAt: !940)
!951 = !DILocation(line: 343, column: 22, scope: !497, inlinedAt: !940)
!952 = !DILocation(line: 344, column: 22, scope: !497, inlinedAt: !940)
!953 = !DILocation(line: 309, column: 9, scope: !941)
!954 = !DILocation(line: 310, column: 30, scope: !941)
!955 = !DILocation(line: 310, column: 9, scope: !941)
!956 = !DILocation(line: 310, column: 34, scope: !941)
!957 = distinct !{!957, !938, !958, !461}
!958 = !DILocation(line: 311, column: 5, scope: !897)
!959 = !DILocation(line: 313, column: 1, scope: !897)
!960 = distinct !DISubprogram(name: "fill_slab_stats_automove", scope: !3, file: !3, line: 528, type: !961, scopeLine: 528, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !971)
!961 = !DISubroutineType(types: !962)
!962 = !{null, !963}
!963 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !964, size: 64)
!964 = !DIDerivedType(tag: DW_TAG_typedef, name: "slab_stats_automove", file: !6, line: 39, baseType: !965)
!965 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !6, line: 34, size: 192, elements: !966)
!966 = !{!967, !968, !969, !970}
!967 = !DIDerivedType(tag: DW_TAG_member, name: "chunks_per_page", scope: !965, file: !6, line: 35, baseType: !7, size: 32)
!968 = !DIDerivedType(tag: DW_TAG_member, name: "chunk_size", scope: !965, file: !6, line: 36, baseType: !7, size: 32, offset: 32)
!969 = !DIDerivedType(tag: DW_TAG_member, name: "free_chunks", scope: !965, file: !6, line: 37, baseType: !279, size: 64, offset: 64)
!970 = !DIDerivedType(tag: DW_TAG_member, name: "total_pages", scope: !965, file: !6, line: 38, baseType: !279, size: 64, offset: 128)
!971 = !{!972, !973, !974, !978}
!972 = !DILocalVariable(name: "am", arg: 1, scope: !960, file: !3, line: 528, type: !963)
!973 = !DILocalVariable(name: "n", scope: !960, file: !3, line: 529, type: !102)
!974 = !DILocalVariable(name: "p", scope: !975, file: !3, line: 532, type: !480)
!975 = distinct !DILexicalBlock(scope: !976, file: !3, line: 531, column: 54)
!976 = distinct !DILexicalBlock(scope: !977, file: !3, line: 531, column: 5)
!977 = distinct !DILexicalBlock(scope: !960, file: !3, line: 531, column: 5)
!978 = !DILocalVariable(name: "cur", scope: !975, file: !3, line: 533, type: !963)
!979 = !DILocation(line: 0, scope: !960)
!980 = !DILocation(line: 530, column: 5, scope: !960)
!981 = !DILocation(line: 531, column: 5, scope: !977)
!982 = !DILocation(line: 532, column: 27, scope: !975)
!983 = !DILocation(line: 0, scope: !975)
!984 = !DILocation(line: 533, column: 37, scope: !975)
!985 = !DILocation(line: 535, column: 31, scope: !975)
!986 = !DILocation(line: 535, column: 14, scope: !975)
!987 = !DILocation(line: 535, column: 28, scope: !975)
!988 = !DILocation(line: 535, column: 26, scope: !975)
!989 = !DILocation(line: 537, column: 30, scope: !975)
!990 = !DILocation(line: 534, column: 30, scope: !975)
!991 = !DILocation(line: 531, column: 50, scope: !976)
!992 = !DILocation(line: 531, column: 19, scope: !976)
!993 = distinct !{!993, !981, !994, !461}
!994 = !DILocation(line: 538, column: 5, scope: !977)
!995 = !DILocation(line: 539, column: 5, scope: !960)
!996 = !DILocation(line: 540, column: 1, scope: !960)
!997 = !DISubprogram(name: "pthread_mutex_lock", scope: !998, file: !998, line: 794, type: !999, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!998 = !DIFile(filename: "/usr/include/pthread.h", directory: "", checksumkind: CSK_MD5, checksum: "cbcd748b3d3ecaa7356dc2925b45d819")
!999 = !DISubroutineType(types: !1000)
!1000 = !{!102, !1001}
!1001 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !254, size: 64)
!1002 = !DISubprogram(name: "pthread_mutex_unlock", scope: !998, file: !998, line: 835, type: !999, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1003 = distinct !DISubprogram(name: "global_page_pool_size", scope: !3, file: !3, line: 545, type: !1004, scopeLine: 545, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1007)
!1004 = !DISubroutineType(types: !1005)
!1005 = !{!7, !1006}
!1006 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !246, size: 64)
!1007 = !{!1008, !1009}
!1008 = !DILocalVariable(name: "mem_flag", arg: 1, scope: !1003, file: !3, line: 545, type: !1006)
!1009 = !DILocalVariable(name: "ret", scope: !1003, file: !3, line: 546, type: !7)
!1010 = !DILocation(line: 0, scope: !1003)
!1011 = !DILocation(line: 547, column: 5, scope: !1003)
!1012 = !DILocation(line: 548, column: 18, scope: !1013)
!1013 = distinct !DILexicalBlock(scope: !1003, file: !3, line: 548, column: 9)
!1014 = !DILocation(line: 548, column: 9, scope: !1003)
!1015 = !DILocation(line: 549, column: 21, scope: !1013)
!1016 = !DILocation(line: 549, column: 37, scope: !1013)
!1017 = !DILocation(line: 549, column: 34, scope: !1013)
!1018 = !DILocation(line: 549, column: 19, scope: !1013)
!1019 = !{!443, !443, i64 0}
!1020 = !DILocation(line: 549, column: 9, scope: !1013)
!1021 = !DILocation(line: 550, column: 44, scope: !1003)
!1022 = !DILocation(line: 551, column: 5, scope: !1003)
!1023 = !DILocation(line: 552, column: 5, scope: !1003)
!1024 = distinct !DISubprogram(name: "slabs_alloc", scope: !3, file: !3, line: 656, type: !1025, scopeLine: 657, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1027)
!1025 = !DISubroutineType(types: !1026)
!1026 = !{!128, !131, !7, !7}
!1027 = !{!1028, !1029, !1030, !1031}
!1028 = !DILocalVariable(name: "size", arg: 1, scope: !1024, file: !3, line: 656, type: !131)
!1029 = !DILocalVariable(name: "id", arg: 2, scope: !1024, file: !3, line: 656, type: !7)
!1030 = !DILocalVariable(name: "flags", arg: 3, scope: !1024, file: !3, line: 657, type: !7)
!1031 = !DILocalVariable(name: "ret", scope: !1024, file: !3, line: 658, type: !128)
!1032 = !DILocation(line: 0, scope: !1024)
!1033 = !DILocation(line: 660, column: 5, scope: !1024)
!1034 = !DILocalVariable(name: "size", arg: 1, scope: !1035, file: !3, line: 406, type: !429)
!1035 = distinct !DISubprogram(name: "do_slabs_alloc", scope: !3, file: !3, line: 406, type: !1036, scopeLine: 407, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1038)
!1036 = !DISubroutineType(types: !1037)
!1037 = !{!128, !429, !7, !7}
!1038 = !{!1034, !1039, !1040, !1041, !1042, !1043}
!1039 = !DILocalVariable(name: "id", arg: 2, scope: !1035, file: !3, line: 406, type: !7)
!1040 = !DILocalVariable(name: "flags", arg: 3, scope: !1035, file: !3, line: 407, type: !7)
!1041 = !DILocalVariable(name: "p", scope: !1035, file: !3, line: 408, type: !480)
!1042 = !DILocalVariable(name: "ret", scope: !1035, file: !3, line: 409, type: !128)
!1043 = !DILocalVariable(name: "it", scope: !1035, file: !3, line: 410, type: !90)
!1044 = !DILocation(line: 0, scope: !1035, inlinedAt: !1045)
!1045 = distinct !DILocation(line: 661, column: 11, scope: !1024)
!1046 = !DILocation(line: 412, column: 12, scope: !1047, inlinedAt: !1045)
!1047 = distinct !DILexicalBlock(scope: !1035, file: !3, line: 412, column: 9)
!1048 = !DILocation(line: 412, column: 29, scope: !1047, inlinedAt: !1045)
!1049 = !DILocation(line: 412, column: 37, scope: !1047, inlinedAt: !1045)
!1050 = !DILocation(line: 412, column: 35, scope: !1047, inlinedAt: !1045)
!1051 = !DILocation(line: 412, column: 9, scope: !1035, inlinedAt: !1045)
!1052 = !DILocation(line: 416, column: 10, scope: !1035, inlinedAt: !1045)
!1053 = !DILocation(line: 422, column: 12, scope: !1054, inlinedAt: !1045)
!1054 = distinct !DILexicalBlock(scope: !1035, file: !3, line: 422, column: 9)
!1055 = !DILocation(line: 422, column: 20, scope: !1054, inlinedAt: !1045)
!1056 = !DILocation(line: 422, column: 25, scope: !1054, inlinedAt: !1045)
!1057 = !DILocation(line: 423, column: 9, scope: !1058, inlinedAt: !1045)
!1058 = distinct !DILexicalBlock(scope: !1054, file: !3, line: 422, column: 61)
!1059 = !DILocation(line: 426, column: 12, scope: !1060, inlinedAt: !1045)
!1060 = distinct !DILexicalBlock(scope: !1035, file: !3, line: 426, column: 9)
!1061 = !DILocation(line: 424, column: 5, scope: !1058, inlinedAt: !1045)
!1062 = !DILocation(line: 426, column: 20, scope: !1060, inlinedAt: !1045)
!1063 = !DILocation(line: 426, column: 9, scope: !1035, inlinedAt: !1045)
!1064 = !DILocation(line: 428, column: 25, scope: !1065, inlinedAt: !1045)
!1065 = distinct !DILexicalBlock(scope: !1060, file: !3, line: 426, column: 26)
!1066 = !DILocation(line: 429, column: 24, scope: !1065, inlinedAt: !1045)
!1067 = !DILocation(line: 429, column: 18, scope: !1065, inlinedAt: !1045)
!1068 = !DILocation(line: 430, column: 13, scope: !1069, inlinedAt: !1045)
!1069 = distinct !DILexicalBlock(scope: !1065, file: !3, line: 430, column: 13)
!1070 = !DILocation(line: 430, column: 13, scope: !1065, inlinedAt: !1045)
!1071 = !DILocation(line: 430, column: 33, scope: !1069, inlinedAt: !1045)
!1072 = !DILocation(line: 430, column: 38, scope: !1069, inlinedAt: !1045)
!1073 = !DILocation(line: 430, column: 23, scope: !1069, inlinedAt: !1045)
!1074 = !DILocation(line: 433, column: 13, scope: !1065, inlinedAt: !1045)
!1075 = !DILocation(line: 433, column: 22, scope: !1065, inlinedAt: !1045)
!1076 = !DILocation(line: 434, column: 13, scope: !1065, inlinedAt: !1045)
!1077 = !DILocation(line: 434, column: 22, scope: !1065, inlinedAt: !1045)
!1078 = !DILocation(line: 435, column: 19, scope: !1065, inlinedAt: !1045)
!1079 = !DILocation(line: 437, column: 5, scope: !1065, inlinedAt: !1045)
!1080 = !DILocation(line: 662, column: 5, scope: !1024)
!1081 = !DILocation(line: 663, column: 5, scope: !1024)
!1082 = distinct !DISubprogram(name: "slabs_free", scope: !3, file: !3, line: 666, type: !1083, scopeLine: 666, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1085)
!1083 = !DISubroutineType(types: !1084)
!1084 = !{null, !128, !131, !7}
!1085 = !{!1086, !1087, !1088}
!1086 = !DILocalVariable(name: "ptr", arg: 1, scope: !1082, file: !3, line: 666, type: !128)
!1087 = !DILocalVariable(name: "size", arg: 2, scope: !1082, file: !3, line: 666, type: !131)
!1088 = !DILocalVariable(name: "id", arg: 3, scope: !1082, file: !3, line: 666, type: !7)
!1089 = !DILocation(line: 0, scope: !1082)
!1090 = !DILocation(line: 667, column: 5, scope: !1082)
!1091 = !DILocation(line: 668, column: 5, scope: !1082)
!1092 = !DILocation(line: 669, column: 5, scope: !1082)
!1093 = !DILocation(line: 670, column: 1, scope: !1082)
!1094 = distinct !DISubprogram(name: "do_slabs_free", scope: !3, file: !3, line: 498, type: !1095, scopeLine: 498, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1097)
!1095 = !DISubroutineType(cc: DW_CC_nocall, types: !1096)
!1096 = !{null, !128, !429, !7}
!1097 = !{!1098, !1099, !1100, !1101, !1102}
!1098 = !DILocalVariable(name: "ptr", arg: 1, scope: !1094, file: !3, line: 498, type: !128)
!1099 = !DILocalVariable(name: "size", arg: 2, scope: !1094, file: !3, line: 498, type: !429)
!1100 = !DILocalVariable(name: "id", arg: 3, scope: !1094, file: !3, line: 498, type: !7)
!1101 = !DILocalVariable(name: "p", scope: !1094, file: !3, line: 499, type: !480)
!1102 = !DILocalVariable(name: "it", scope: !1094, file: !3, line: 500, type: !90)
!1103 = !DILocation(line: 0, scope: !1094)
!1104 = !DILocation(line: 503, column: 12, scope: !1105)
!1105 = distinct !DILexicalBlock(scope: !1094, file: !3, line: 503, column: 9)
!1106 = !DILocation(line: 503, column: 29, scope: !1105)
!1107 = !DILocation(line: 503, column: 37, scope: !1105)
!1108 = !DILocation(line: 503, column: 35, scope: !1105)
!1109 = !DILocation(line: 503, column: 9, scope: !1094)
!1110 = !DILocation(line: 507, column: 10, scope: !1094)
!1111 = !DILocation(line: 510, column: 14, scope: !1112)
!1112 = distinct !DILexicalBlock(scope: !1094, file: !3, line: 510, column: 9)
!1113 = !DILocation(line: 510, column: 23, scope: !1112)
!1114 = !DILocation(line: 510, column: 39, scope: !1112)
!1115 = !DILocation(line: 510, column: 9, scope: !1094)
!1116 = !DILocation(line: 511, column: 22, scope: !1117)
!1117 = distinct !DILexicalBlock(scope: !1112, file: !3, line: 510, column: 45)
!1118 = !DILocation(line: 512, column: 27, scope: !1117)
!1119 = !DILocation(line: 512, column: 13, scope: !1117)
!1120 = !DILocation(line: 512, column: 25, scope: !1117)
!1121 = !DILocation(line: 513, column: 13, scope: !1117)
!1122 = !DILocation(line: 513, column: 18, scope: !1117)
!1123 = !DILocation(line: 514, column: 23, scope: !1117)
!1124 = !DILocation(line: 514, column: 18, scope: !1117)
!1125 = !DILocation(line: 515, column: 13, scope: !1126)
!1126 = distinct !DILexicalBlock(scope: !1117, file: !3, line: 515, column: 13)
!1127 = !DILocation(line: 515, column: 13, scope: !1117)
!1128 = !DILocation(line: 515, column: 33, scope: !1126)
!1129 = !DILocation(line: 515, column: 38, scope: !1126)
!1130 = !DILocation(line: 515, column: 23, scope: !1126)
!1131 = !DILocation(line: 516, column: 18, scope: !1117)
!1132 = !DILocation(line: 518, column: 12, scope: !1117)
!1133 = !DILocation(line: 518, column: 19, scope: !1117)
!1134 = !DILocation(line: 519, column: 5, scope: !1117)
!1135 = !DILocalVariable(name: "it", arg: 1, scope: !1136, file: !3, line: 450, type: !90)
!1136 = distinct !DISubprogram(name: "do_slabs_free_chunked", scope: !3, file: !3, line: 450, type: !1137, scopeLine: 450, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1139)
!1137 = !DISubroutineType(types: !1138)
!1138 = !{null, !90, !429}
!1139 = !{!1135, !1140, !1141, !1142, !1143}
!1140 = !DILocalVariable(name: "size", arg: 2, scope: !1136, file: !3, line: 450, type: !429)
!1141 = !DILocalVariable(name: "chunk", scope: !1136, file: !3, line: 451, type: !133)
!1142 = !DILocalVariable(name: "p", scope: !1136, file: !3, line: 452, type: !480)
!1143 = !DILocalVariable(name: "next_chunk", scope: !1136, file: !3, line: 478, type: !133)
!1144 = !DILocation(line: 0, scope: !1136, inlinedAt: !1145)
!1145 = distinct !DILocation(line: 520, column: 9, scope: !1146)
!1146 = distinct !DILexicalBlock(scope: !1112, file: !3, line: 519, column: 12)
!1147 = !DILocation(line: 451, column: 40, scope: !1136, inlinedAt: !1145)
!1148 = !DILocation(line: 454, column: 18, scope: !1136, inlinedAt: !1145)
!1149 = !DILocation(line: 457, column: 9, scope: !1136, inlinedAt: !1145)
!1150 = !DILocation(line: 459, column: 27, scope: !1136, inlinedAt: !1145)
!1151 = !DILocation(line: 459, column: 10, scope: !1136, inlinedAt: !1145)
!1152 = !DILocation(line: 461, column: 9, scope: !1136, inlinedAt: !1145)
!1153 = !DILocation(line: 461, column: 21, scope: !1136, inlinedAt: !1145)
!1154 = !DILocation(line: 462, column: 16, scope: !1155, inlinedAt: !1145)
!1155 = distinct !DILexicalBlock(scope: !1136, file: !3, line: 462, column: 9)
!1156 = !DILocation(line: 462, column: 9, scope: !1155, inlinedAt: !1145)
!1157 = !DILocation(line: 462, column: 9, scope: !1136, inlinedAt: !1145)
!1158 = !DILocation(line: 464, column: 16, scope: !1159, inlinedAt: !1145)
!1159 = distinct !DILexicalBlock(scope: !1155, file: !3, line: 462, column: 22)
!1160 = !DILocation(line: 464, column: 21, scope: !1159, inlinedAt: !1145)
!1161 = !DILocation(line: 465, column: 5, scope: !1159, inlinedAt: !1145)
!1162 = !DILocation(line: 472, column: 14, scope: !1136, inlinedAt: !1145)
!1163 = !DILocation(line: 473, column: 19, scope: !1136, inlinedAt: !1145)
!1164 = !DILocation(line: 473, column: 14, scope: !1136, inlinedAt: !1145)
!1165 = !DILocation(line: 474, column: 9, scope: !1166, inlinedAt: !1145)
!1166 = distinct !DILexicalBlock(scope: !1136, file: !3, line: 474, column: 9)
!1167 = !DILocation(line: 474, column: 9, scope: !1136, inlinedAt: !1145)
!1168 = !DILocation(line: 474, column: 29, scope: !1166, inlinedAt: !1145)
!1169 = !DILocation(line: 474, column: 34, scope: !1166, inlinedAt: !1145)
!1170 = !DILocation(line: 474, column: 19, scope: !1166, inlinedAt: !1145)
!1171 = !DILocation(line: 475, column: 14, scope: !1136, inlinedAt: !1145)
!1172 = !DILocation(line: 476, column: 8, scope: !1136, inlinedAt: !1145)
!1173 = !DILocation(line: 476, column: 15, scope: !1136, inlinedAt: !1145)
!1174 = !DILocation(line: 479, column: 5, scope: !1136, inlinedAt: !1145)
!1175 = !DILocation(line: 481, column: 16, scope: !1176, inlinedAt: !1145)
!1176 = distinct !DILexicalBlock(scope: !1136, file: !3, line: 479, column: 19)
!1177 = !DILocation(line: 481, column: 25, scope: !1176, inlinedAt: !1145)
!1178 = !DILocation(line: 482, column: 31, scope: !1176, inlinedAt: !1145)
!1179 = !DILocation(line: 482, column: 14, scope: !1176, inlinedAt: !1145)
!1180 = !DILocation(line: 483, column: 29, scope: !1176, inlinedAt: !1145)
!1181 = !DILocation(line: 485, column: 16, scope: !1176, inlinedAt: !1145)
!1182 = !DILocation(line: 485, column: 21, scope: !1176, inlinedAt: !1145)
!1183 = !DILocation(line: 486, column: 26, scope: !1176, inlinedAt: !1145)
!1184 = !DILocation(line: 486, column: 21, scope: !1176, inlinedAt: !1145)
!1185 = !DILocation(line: 487, column: 13, scope: !1186, inlinedAt: !1145)
!1186 = distinct !DILexicalBlock(scope: !1176, file: !3, line: 487, column: 13)
!1187 = !DILocation(line: 487, column: 13, scope: !1176, inlinedAt: !1145)
!1188 = !DILocation(line: 487, column: 39, scope: !1186, inlinedAt: !1145)
!1189 = !DILocation(line: 487, column: 44, scope: !1186, inlinedAt: !1145)
!1190 = !DILocation(line: 487, column: 26, scope: !1186, inlinedAt: !1145)
!1191 = !DILocation(line: 488, column: 18, scope: !1176, inlinedAt: !1145)
!1192 = !DILocation(line: 489, column: 12, scope: !1176, inlinedAt: !1145)
!1193 = !DILocation(line: 489, column: 19, scope: !1176, inlinedAt: !1145)
!1194 = distinct !{!1194, !1174, !1195, !461}
!1195 = !DILocation(line: 492, column: 5, scope: !1136, inlinedAt: !1145)
!1196 = !DILocation(line: 523, column: 1, scope: !1094)
!1197 = distinct !DISubprogram(name: "slabs_stats", scope: !3, file: !3, line: 672, type: !1198, scopeLine: 672, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1207)
!1198 = !DISubroutineType(types: !1199)
!1199 = !{null, !1200, !128}
!1200 = !DIDerivedType(tag: DW_TAG_typedef, name: "ADD_STAT", file: !15, line: 194, baseType: !1201)
!1201 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1202, size: 64)
!1202 = !DISubroutineType(types: !1203)
!1203 = !{null, !129, !1204, !129, !584, !1205}
!1204 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !106)
!1205 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1206, size: 64)
!1206 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!1207 = !{!1208, !1209}
!1208 = !DILocalVariable(name: "add_stats", arg: 1, scope: !1197, file: !3, line: 672, type: !1200)
!1209 = !DILocalVariable(name: "c", arg: 2, scope: !1197, file: !3, line: 672, type: !128)
!1210 = distinct !DIAssignID()
!1211 = !DILocalVariable(name: "thread_stats", scope: !1212, file: !3, line: 559, type: !1233)
!1212 = distinct !DISubprogram(name: "do_slabs_stats", scope: !3, file: !3, line: 556, type: !1198, scopeLine: 556, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1213)
!1213 = !{!1214, !1215, !1216, !1217, !1211, !1218, !1222, !1225, !1226, !1230, !1231, !1232}
!1214 = !DILocalVariable(name: "add_stats", arg: 1, scope: !1212, file: !3, line: 556, type: !1200)
!1215 = !DILocalVariable(name: "c", arg: 2, scope: !1212, file: !3, line: 556, type: !128)
!1216 = !DILocalVariable(name: "i", scope: !1212, file: !3, line: 557, type: !102)
!1217 = !DILocalVariable(name: "total", scope: !1212, file: !3, line: 557, type: !102)
!1218 = !DILocalVariable(name: "p", scope: !1219, file: !3, line: 564, type: !480)
!1219 = distinct !DILexicalBlock(scope: !1220, file: !3, line: 563, column: 54)
!1220 = distinct !DILexicalBlock(scope: !1221, file: !3, line: 563, column: 5)
!1221 = distinct !DILexicalBlock(scope: !1212, file: !3, line: 563, column: 5)
!1222 = !DILocalVariable(name: "perslab", scope: !1223, file: !3, line: 566, type: !585)
!1223 = distinct !DILexicalBlock(scope: !1224, file: !3, line: 565, column: 28)
!1224 = distinct !DILexicalBlock(scope: !1219, file: !3, line: 565, column: 13)
!1225 = !DILocalVariable(name: "slabs", scope: !1223, file: !3, line: 566, type: !585)
!1226 = !DILocalVariable(name: "key_str", scope: !1223, file: !3, line: 570, type: !1227)
!1227 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 1024, elements: !1228)
!1228 = !{!1229}
!1229 = !DISubrange(count: 128)
!1230 = !DILocalVariable(name: "val_str", scope: !1223, file: !3, line: 571, type: !1227)
!1231 = !DILocalVariable(name: "klen", scope: !1223, file: !3, line: 572, type: !102)
!1232 = !DILocalVariable(name: "vlen", scope: !1223, file: !3, line: 572, type: !102)
!1233 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_stats", file: !15, line: 372, size: 51584, elements: !1234)
!1234 = !{!1235, !1236, !1237, !1238, !1239, !1240, !1241, !1242, !1243, !1244, !1245, !1246, !1247, !1248, !1249, !1250, !1251, !1252, !1253, !1254, !1255, !1256, !1257, !1258, !1259, !1260, !1261, !1262, !1263, !1264, !1265, !1266, !1278, !1282, !1283, !1284}
!1235 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !1233, file: !15, line: 373, baseType: !254, size: 320)
!1236 = !DIDerivedType(tag: DW_TAG_member, name: "get_cmds", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 320)
!1237 = !DIDerivedType(tag: DW_TAG_member, name: "get_misses", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 384)
!1238 = !DIDerivedType(tag: DW_TAG_member, name: "get_expired", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 448)
!1239 = !DIDerivedType(tag: DW_TAG_member, name: "get_flushed", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 512)
!1240 = !DIDerivedType(tag: DW_TAG_member, name: "touch_cmds", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 576)
!1241 = !DIDerivedType(tag: DW_TAG_member, name: "touch_misses", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 640)
!1242 = !DIDerivedType(tag: DW_TAG_member, name: "delete_misses", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 704)
!1243 = !DIDerivedType(tag: DW_TAG_member, name: "incr_misses", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 768)
!1244 = !DIDerivedType(tag: DW_TAG_member, name: "decr_misses", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 832)
!1245 = !DIDerivedType(tag: DW_TAG_member, name: "cas_misses", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 896)
!1246 = !DIDerivedType(tag: DW_TAG_member, name: "meta_cmds", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 960)
!1247 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_read", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 1024)
!1248 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_written", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 1088)
!1249 = !DIDerivedType(tag: DW_TAG_member, name: "flush_cmds", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 1152)
!1250 = !DIDerivedType(tag: DW_TAG_member, name: "conn_yields", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 1216)
!1251 = !DIDerivedType(tag: DW_TAG_member, name: "auth_cmds", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 1280)
!1252 = !DIDerivedType(tag: DW_TAG_member, name: "auth_errors", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 1344)
!1253 = !DIDerivedType(tag: DW_TAG_member, name: "idle_kicks", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 1408)
!1254 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_oom", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 1472)
!1255 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_count", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 1536)
!1256 = !DIDerivedType(tag: DW_TAG_member, name: "response_obj_bytes", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 1600)
!1257 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_oom", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 1664)
!1258 = !DIDerivedType(tag: DW_TAG_member, name: "store_too_large", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 1728)
!1259 = !DIDerivedType(tag: DW_TAG_member, name: "store_no_memory", scope: !1233, file: !15, line: 375, baseType: !120, size: 64, offset: 1792)
!1260 = !DIDerivedType(tag: DW_TAG_member, name: "get_extstore", scope: !1233, file: !15, line: 377, baseType: !120, size: 64, offset: 1856)
!1261 = !DIDerivedType(tag: DW_TAG_member, name: "get_aborted_extstore", scope: !1233, file: !15, line: 377, baseType: !120, size: 64, offset: 1920)
!1262 = !DIDerivedType(tag: DW_TAG_member, name: "get_oom_extstore", scope: !1233, file: !15, line: 377, baseType: !120, size: 64, offset: 1984)
!1263 = !DIDerivedType(tag: DW_TAG_member, name: "recache_from_extstore", scope: !1233, file: !15, line: 377, baseType: !120, size: 64, offset: 2048)
!1264 = !DIDerivedType(tag: DW_TAG_member, name: "miss_from_extstore", scope: !1233, file: !15, line: 377, baseType: !120, size: 64, offset: 2112)
!1265 = !DIDerivedType(tag: DW_TAG_member, name: "badcrc_from_extstore", scope: !1233, file: !15, line: 377, baseType: !120, size: 64, offset: 2176)
!1266 = !DIDerivedType(tag: DW_TAG_member, name: "slab_stats", scope: !1233, file: !15, line: 383, baseType: !1267, size: 32768, offset: 2240)
!1267 = !DICompositeType(tag: DW_TAG_array_type, baseType: !1268, size: 32768, elements: !192)
!1268 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "slab_stats", file: !15, line: 318, size: 512, elements: !1269)
!1269 = !{!1270, !1271, !1272, !1273, !1274, !1275, !1276, !1277}
!1270 = !DIDerivedType(tag: DW_TAG_member, name: "set_cmds", scope: !1268, file: !15, line: 320, baseType: !120, size: 64)
!1271 = !DIDerivedType(tag: DW_TAG_member, name: "get_hits", scope: !1268, file: !15, line: 320, baseType: !120, size: 64, offset: 64)
!1272 = !DIDerivedType(tag: DW_TAG_member, name: "touch_hits", scope: !1268, file: !15, line: 320, baseType: !120, size: 64, offset: 128)
!1273 = !DIDerivedType(tag: DW_TAG_member, name: "delete_hits", scope: !1268, file: !15, line: 320, baseType: !120, size: 64, offset: 192)
!1274 = !DIDerivedType(tag: DW_TAG_member, name: "cas_hits", scope: !1268, file: !15, line: 320, baseType: !120, size: 64, offset: 256)
!1275 = !DIDerivedType(tag: DW_TAG_member, name: "cas_badval", scope: !1268, file: !15, line: 320, baseType: !120, size: 64, offset: 320)
!1276 = !DIDerivedType(tag: DW_TAG_member, name: "incr_hits", scope: !1268, file: !15, line: 320, baseType: !120, size: 64, offset: 384)
!1277 = !DIDerivedType(tag: DW_TAG_member, name: "decr_hits", scope: !1268, file: !15, line: 320, baseType: !120, size: 64, offset: 448)
!1278 = !DIDerivedType(tag: DW_TAG_member, name: "lru_hits", scope: !1233, file: !15, line: 384, baseType: !1279, size: 16384, offset: 35008)
!1279 = !DICompositeType(tag: DW_TAG_array_type, baseType: !120, size: 16384, elements: !1280)
!1280 = !{!1281}
!1281 = !DISubrange(count: 256)
!1282 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_count", scope: !1233, file: !15, line: 385, baseType: !120, size: 64, offset: 51392)
!1283 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes", scope: !1233, file: !15, line: 386, baseType: !120, size: 64, offset: 51456)
!1284 = !DIDerivedType(tag: DW_TAG_member, name: "read_buf_bytes_free", scope: !1233, file: !15, line: 387, baseType: !120, size: 64, offset: 51520)
!1285 = !DILocation(line: 0, scope: !1212, inlinedAt: !1286)
!1286 = distinct !DILocation(line: 674, column: 5, scope: !1197)
!1287 = distinct !DIAssignID()
!1288 = !DILocation(line: 0, scope: !1223, inlinedAt: !1286)
!1289 = distinct !DIAssignID()
!1290 = !DILocation(line: 0, scope: !1197)
!1291 = !DILocation(line: 673, column: 5, scope: !1197)
!1292 = !DILocation(line: 559, column: 5, scope: !1212, inlinedAt: !1286)
!1293 = !DILocation(line: 560, column: 5, scope: !1212, inlinedAt: !1286)
!1294 = !DILocation(line: 563, column: 34, scope: !1220, inlinedAt: !1286)
!1295 = !DILocation(line: 563, column: 31, scope: !1220, inlinedAt: !1286)
!1296 = !DILocation(line: 563, column: 5, scope: !1221, inlinedAt: !1286)
!1297 = !DILocation(line: 564, column: 27, scope: !1219, inlinedAt: !1286)
!1298 = !DILocation(line: 0, scope: !1219, inlinedAt: !1286)
!1299 = !DILocation(line: 565, column: 16, scope: !1224, inlinedAt: !1286)
!1300 = !DILocation(line: 565, column: 22, scope: !1224, inlinedAt: !1286)
!1301 = !DILocation(line: 565, column: 13, scope: !1219, inlinedAt: !1286)
!1302 = !DILocation(line: 568, column: 26, scope: !1223, inlinedAt: !1286)
!1303 = !DILocation(line: 570, column: 13, scope: !1223, inlinedAt: !1286)
!1304 = !DILocation(line: 571, column: 13, scope: !1223, inlinedAt: !1286)
!1305 = !DILocation(line: 574, column: 13, scope: !1223, inlinedAt: !1286)
!1306 = !DILocation(line: 575, column: 13, scope: !1223, inlinedAt: !1286)
!1307 = !DILocation(line: 576, column: 13, scope: !1223, inlinedAt: !1286)
!1308 = !DILocation(line: 577, column: 13, scope: !1223, inlinedAt: !1286)
!1309 = !DILocation(line: 578, column: 13, scope: !1223, inlinedAt: !1286)
!1310 = !DILocation(line: 580, column: 13, scope: !1223, inlinedAt: !1286)
!1311 = !DILocation(line: 582, column: 13, scope: !1223, inlinedAt: !1286)
!1312 = !DILocation(line: 583, column: 13, scope: !1223, inlinedAt: !1286)
!1313 = !{!1314, !440, i64 8}
!1314 = !{!"slab_stats", !440, i64 0, !440, i64 8, !440, i64 16, !440, i64 24, !440, i64 32, !440, i64 40, !440, i64 48, !440, i64 56}
!1315 = !DILocation(line: 585, column: 13, scope: !1223, inlinedAt: !1286)
!1316 = !{!1314, !440, i64 0}
!1317 = !DILocation(line: 587, column: 13, scope: !1223, inlinedAt: !1286)
!1318 = !{!1314, !440, i64 24}
!1319 = !DILocation(line: 589, column: 13, scope: !1223, inlinedAt: !1286)
!1320 = !{!1314, !440, i64 48}
!1321 = !DILocation(line: 591, column: 13, scope: !1223, inlinedAt: !1286)
!1322 = !{!1314, !440, i64 56}
!1323 = !DILocation(line: 593, column: 13, scope: !1223, inlinedAt: !1286)
!1324 = !{!1314, !440, i64 32}
!1325 = !DILocation(line: 595, column: 13, scope: !1223, inlinedAt: !1286)
!1326 = !{!1314, !440, i64 40}
!1327 = !DILocation(line: 597, column: 13, scope: !1223, inlinedAt: !1286)
!1328 = !{!1314, !440, i64 16}
!1329 = !DILocation(line: 599, column: 18, scope: !1223, inlinedAt: !1286)
!1330 = !DILocation(line: 600, column: 9, scope: !1224, inlinedAt: !1286)
!1331 = !DILocation(line: 600, column: 9, scope: !1223, inlinedAt: !1286)
!1332 = !DILocation(line: 563, column: 50, scope: !1220, inlinedAt: !1286)
!1333 = distinct !{!1333, !1296, !1334, !461}
!1334 = !DILocation(line: 601, column: 5, scope: !1221, inlinedAt: !1286)
!1335 = !DILocation(line: 605, column: 5, scope: !1212, inlinedAt: !1286)
!1336 = !DILocation(line: 606, column: 5, scope: !1212, inlinedAt: !1286)
!1337 = !DILocation(line: 607, column: 5, scope: !1212, inlinedAt: !1286)
!1338 = !DILocation(line: 608, column: 1, scope: !1212, inlinedAt: !1286)
!1339 = !DILocation(line: 675, column: 5, scope: !1197)
!1340 = !DILocation(line: 676, column: 1, scope: !1197)
!1341 = distinct !DISubprogram(name: "slabs_adjust_mem_limit", scope: !3, file: !3, line: 689, type: !1342, scopeLine: 689, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1344)
!1342 = !DISubroutineType(types: !1343)
!1343 = !{!246, !131}
!1344 = !{!1345, !1346}
!1345 = !DILocalVariable(name: "new_mem_limit", arg: 1, scope: !1341, file: !3, line: 689, type: !131)
!1346 = !DILocalVariable(name: "ret", scope: !1341, file: !3, line: 690, type: !246)
!1347 = !DILocation(line: 0, scope: !1341)
!1348 = !DILocation(line: 691, column: 5, scope: !1341)
!1349 = !DILocalVariable(name: "new_mem_limit", arg: 1, scope: !1350, file: !3, line: 678, type: !131)
!1350 = distinct !DISubprogram(name: "do_slabs_adjust_mem_limit", scope: !3, file: !3, line: 678, type: !1342, scopeLine: 678, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1351)
!1351 = !{!1349}
!1352 = !DILocation(line: 0, scope: !1350, inlinedAt: !1353)
!1353 = distinct !DILocation(line: 692, column: 11, scope: !1341)
!1354 = !DILocation(line: 680, column: 9, scope: !1355, inlinedAt: !1353)
!1355 = distinct !DILexicalBlock(scope: !1350, file: !3, line: 680, column: 9)
!1356 = !DILocation(line: 680, column: 18, scope: !1355, inlinedAt: !1353)
!1357 = !DILocation(line: 680, column: 9, scope: !1350, inlinedAt: !1353)
!1358 = !DILocation(line: 682, column: 23, scope: !1350, inlinedAt: !1353)
!1359 = !{!439, !440, i64 0}
!1360 = !DILocation(line: 683, column: 15, scope: !1350, inlinedAt: !1353)
!1361 = !DILocalVariable(name: "p", scope: !1362, file: !3, line: 642, type: !128)
!1362 = distinct !DISubprogram(name: "memory_release", scope: !3, file: !3, line: 641, type: !898, scopeLine: 641, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1363)
!1363 = !{!1361}
!1364 = !DILocation(line: 0, scope: !1362, inlinedAt: !1365)
!1365 = distinct !DILocation(line: 685, column: 5, scope: !1350, inlinedAt: !1353)
!1366 = !DILocation(line: 646, column: 19, scope: !1367, inlinedAt: !1365)
!1367 = distinct !DILexicalBlock(scope: !1362, file: !3, line: 646, column: 9)
!1368 = !{!439, !443, i64 137}
!1369 = !{i8 0, i8 2}
!1370 = !{}
!1371 = !DILocation(line: 646, column: 9, scope: !1362, inlinedAt: !1365)
!1372 = !DILocation(line: 649, column: 25, scope: !1362, inlinedAt: !1365)
!1373 = !DILocation(line: 649, column: 37, scope: !1362, inlinedAt: !1365)
!1374 = !DILocation(line: 649, column: 5, scope: !1362, inlinedAt: !1365)
!1375 = !DILocalVariable(name: "p", scope: !1376, file: !3, line: 360, type: !480)
!1376 = distinct !DISubprogram(name: "get_page_from_global_pool", scope: !3, file: !3, line: 359, type: !1377, scopeLine: 359, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1379)
!1377 = !DISubroutineType(types: !1378)
!1378 = !{!128}
!1379 = !{!1375, !1380}
!1380 = !DILocalVariable(name: "ret", scope: !1376, file: !3, line: 364, type: !127)
!1381 = !DILocation(line: 0, scope: !1376, inlinedAt: !1382)
!1382 = distinct !DILocation(line: 650, column: 18, scope: !1362, inlinedAt: !1365)
!1383 = !DILocation(line: 361, column: 18, scope: !1384, inlinedAt: !1382)
!1384 = distinct !DILexicalBlock(scope: !1376, file: !3, line: 361, column: 9)
!1385 = !DILocation(line: 361, column: 9, scope: !1376, inlinedAt: !1382)
!1386 = !DILocation(line: 364, column: 20, scope: !1376, inlinedAt: !1382)
!1387 = !DILocation(line: 364, column: 39, scope: !1376, inlinedAt: !1382)
!1388 = !DILocation(line: 364, column: 17, scope: !1376, inlinedAt: !1382)
!1389 = !DILocation(line: 365, column: 13, scope: !1376, inlinedAt: !1382)
!1390 = !DILocation(line: 650, column: 47, scope: !1362, inlinedAt: !1365)
!1391 = !DILocation(line: 651, column: 9, scope: !1392, inlinedAt: !1365)
!1392 = distinct !DILexicalBlock(scope: !1362, file: !3, line: 650, column: 56)
!1393 = !DILocation(line: 652, column: 34, scope: !1392, inlinedAt: !1365)
!1394 = !DILocation(line: 652, column: 25, scope: !1392, inlinedAt: !1365)
!1395 = !DILocation(line: 652, column: 22, scope: !1392, inlinedAt: !1365)
!1396 = distinct !{!1396, !1374, !1397, !461}
!1397 = !DILocation(line: 653, column: 5, scope: !1362, inlinedAt: !1365)
!1398 = !DILocation(line: 693, column: 5, scope: !1341)
!1399 = !DILocation(line: 694, column: 5, scope: !1341)
!1400 = distinct !DISubprogram(name: "slabs_available_chunks", scope: !3, file: !3, line: 697, type: !1401, scopeLine: 698, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1404)
!1401 = !DISubroutineType(types: !1402)
!1402 = !{!7, !493, !1006, !1403}
!1403 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !7, size: 64)
!1404 = !{!1405, !1406, !1407, !1408, !1409}
!1405 = !DILocalVariable(name: "id", arg: 1, scope: !1400, file: !3, line: 697, type: !493)
!1406 = !DILocalVariable(name: "mem_flag", arg: 2, scope: !1400, file: !3, line: 697, type: !1006)
!1407 = !DILocalVariable(name: "chunks_perslab", arg: 3, scope: !1400, file: !3, line: 698, type: !1403)
!1408 = !DILocalVariable(name: "ret", scope: !1400, file: !3, line: 699, type: !7)
!1409 = !DILocalVariable(name: "p", scope: !1400, file: !3, line: 700, type: !480)
!1410 = !DILocation(line: 0, scope: !1400)
!1411 = !DILocation(line: 702, column: 5, scope: !1400)
!1412 = !DILocation(line: 703, column: 10, scope: !1400)
!1413 = !DILocation(line: 704, column: 14, scope: !1400)
!1414 = !DILocation(line: 705, column: 18, scope: !1415)
!1415 = distinct !DILexicalBlock(scope: !1400, file: !3, line: 705, column: 9)
!1416 = !DILocation(line: 705, column: 9, scope: !1400)
!1417 = !DILocation(line: 706, column: 21, scope: !1415)
!1418 = !DILocation(line: 706, column: 37, scope: !1415)
!1419 = !DILocation(line: 706, column: 34, scope: !1415)
!1420 = !DILocation(line: 706, column: 19, scope: !1415)
!1421 = !DILocation(line: 706, column: 9, scope: !1415)
!1422 = !DILocation(line: 707, column: 24, scope: !1423)
!1423 = distinct !DILexicalBlock(scope: !1400, file: !3, line: 707, column: 9)
!1424 = !DILocation(line: 707, column: 9, scope: !1400)
!1425 = !DILocation(line: 708, column: 30, scope: !1423)
!1426 = !DILocation(line: 708, column: 25, scope: !1423)
!1427 = !DILocation(line: 708, column: 9, scope: !1423)
!1428 = !DILocation(line: 709, column: 5, scope: !1400)
!1429 = !DILocation(line: 710, column: 5, scope: !1400)
!1430 = distinct !DISubprogram(name: "slabs_mlock", scope: !3, file: !3, line: 719, type: !898, scopeLine: 719, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1431 = !DILocation(line: 720, column: 5, scope: !1430)
!1432 = !DILocation(line: 721, column: 1, scope: !1430)
!1433 = distinct !DISubprogram(name: "slabs_munlock", scope: !3, file: !3, line: 723, type: !898, scopeLine: 723, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1434 = !DILocation(line: 724, column: 5, scope: !1433)
!1435 = !DILocation(line: 725, column: 1, scope: !1433)
!1436 = distinct !DISubprogram(name: "slabs_reassign", scope: !3, file: !3, line: 1298, type: !1437, scopeLine: 1298, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1439)
!1437 = !DISubroutineType(types: !1438)
!1438 = !{!5, !102, !102}
!1439 = !{!1440, !1441, !1442}
!1440 = !DILocalVariable(name: "src", arg: 1, scope: !1436, file: !3, line: 1298, type: !102)
!1441 = !DILocalVariable(name: "dst", arg: 2, scope: !1436, file: !3, line: 1298, type: !102)
!1442 = !DILocalVariable(name: "ret", scope: !1436, file: !3, line: 1299, type: !5)
!1443 = !DILocation(line: 0, scope: !1436)
!1444 = !DILocation(line: 1300, column: 9, scope: !1445)
!1445 = distinct !DILexicalBlock(scope: !1436, file: !3, line: 1300, column: 9)
!1446 = !DILocation(line: 1300, column: 54, scope: !1445)
!1447 = !DILocation(line: 1300, column: 9, scope: !1436)
!1448 = !DILocalVariable(name: "src", arg: 1, scope: !1449, file: !3, line: 1264, type: !102)
!1449 = distinct !DISubprogram(name: "do_slabs_reassign", scope: !3, file: !3, line: 1264, type: !1437, scopeLine: 1264, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1450)
!1450 = !{!1448, !1451, !1452}
!1451 = !DILocalVariable(name: "dst", arg: 2, scope: !1449, file: !3, line: 1264, type: !102)
!1452 = !DILocalVariable(name: "nospare", scope: !1449, file: !3, line: 1265, type: !246)
!1453 = !DILocation(line: 0, scope: !1449, inlinedAt: !1454)
!1454 = distinct !DILocation(line: 1303, column: 11, scope: !1436)
!1455 = !DILocation(line: 1266, column: 9, scope: !1456, inlinedAt: !1454)
!1456 = distinct !DILexicalBlock(scope: !1449, file: !3, line: 1266, column: 9)
!1457 = !DILocation(line: 1266, column: 31, scope: !1456, inlinedAt: !1454)
!1458 = !DILocation(line: 1266, column: 9, scope: !1449, inlinedAt: !1454)
!1459 = !DILocation(line: 1269, column: 13, scope: !1460, inlinedAt: !1454)
!1460 = distinct !DILexicalBlock(scope: !1449, file: !3, line: 1269, column: 9)
!1461 = !DILocation(line: 1269, column: 9, scope: !1449, inlinedAt: !1454)
!1462 = !DILocation(line: 1273, column: 13, scope: !1463, inlinedAt: !1454)
!1463 = distinct !DILexicalBlock(scope: !1449, file: !3, line: 1273, column: 9)
!1464 = !DILocation(line: 1273, column: 9, scope: !1449, inlinedAt: !1454)
!1465 = !DILocation(line: 0, scope: !353, inlinedAt: !1466)
!1466 = distinct !DILocation(line: 1274, column: 15, scope: !1467, inlinedAt: !1454)
!1467 = distinct !DILexicalBlock(scope: !1463, file: !3, line: 1273, column: 20)
!1468 = !DILocation(line: 1250, column: 17, scope: !353, inlinedAt: !1466)
!1469 = !DILocation(line: 1251, column: 18, scope: !1470, inlinedAt: !1466)
!1470 = distinct !DILexicalBlock(scope: !1471, file: !3, line: 1251, column: 5)
!1471 = distinct !DILexicalBlock(scope: !353, file: !3, line: 1251, column: 5)
!1472 = !DILocation(line: 1251, column: 5, scope: !1471, inlinedAt: !1466)
!1473 = !DILocation(line: 1252, column: 12, scope: !1474, inlinedAt: !1466)
!1474 = distinct !DILexicalBlock(scope: !1470, file: !3, line: 1251, column: 32)
!1475 = !DILocation(line: 1253, column: 17, scope: !1476, inlinedAt: !1466)
!1476 = distinct !DILexicalBlock(scope: !1474, file: !3, line: 1253, column: 13)
!1477 = !DILocation(line: 1253, column: 13, scope: !1474, inlinedAt: !1466)
!1478 = !DILocation(line: 1255, column: 17, scope: !1479, inlinedAt: !1466)
!1479 = distinct !DILexicalBlock(scope: !1474, file: !3, line: 1255, column: 13)
!1480 = !DILocation(line: 1255, column: 13, scope: !1474, inlinedAt: !1466)
!1481 = !DILocation(line: 1257, column: 13, scope: !1482, inlinedAt: !1466)
!1482 = distinct !DILexicalBlock(scope: !1474, file: !3, line: 1257, column: 13)
!1483 = !DILocation(line: 1257, column: 28, scope: !1482, inlinedAt: !1466)
!1484 = !DILocation(line: 1257, column: 34, scope: !1482, inlinedAt: !1466)
!1485 = !DILocation(line: 1257, column: 13, scope: !1474, inlinedAt: !1466)
!1486 = !DILocation(line: 1251, column: 28, scope: !1470, inlinedAt: !1466)
!1487 = distinct !{!1487, !1472, !1488, !461}
!1488 = !DILocation(line: 1260, column: 5, scope: !1471, inlinedAt: !1466)
!1489 = !DILocation(line: 0, scope: !1474, inlinedAt: !1466)
!1490 = !DILocation(line: 1262, column: 1, scope: !353, inlinedAt: !1466)
!1491 = !DILocation(line: 1278, column: 13, scope: !1492, inlinedAt: !1454)
!1492 = distinct !DILexicalBlock(scope: !1449, file: !3, line: 1278, column: 9)
!1493 = !DILocation(line: 1278, column: 37, scope: !1492, inlinedAt: !1454)
!1494 = !DILocation(line: 1278, column: 46, scope: !1492, inlinedAt: !1454)
!1495 = !DILocation(line: 1278, column: 44, scope: !1492, inlinedAt: !1454)
!1496 = !DILocation(line: 1278, column: 60, scope: !1492, inlinedAt: !1454)
!1497 = !DILocation(line: 1282, column: 5, scope: !1449, inlinedAt: !1454)
!1498 = !DILocation(line: 1283, column: 24, scope: !1499, inlinedAt: !1454)
!1499 = distinct !DILexicalBlock(scope: !1449, file: !3, line: 1283, column: 9)
!1500 = !DILocation(line: 1283, column: 30, scope: !1499, inlinedAt: !1454)
!1501 = !DILocation(line: 1285, column: 5, scope: !1449, inlinedAt: !1454)
!1502 = !DILocation(line: 1286, column: 9, scope: !1449, inlinedAt: !1454)
!1503 = !DILocation(line: 1289, column: 24, scope: !1449, inlinedAt: !1454)
!1504 = !{!1505, !441, i64 24}
!1505 = !{!"slab_rebalance", !422, i64 0, !422, i64 8, !422, i64 16, !441, i64 24, !441, i64 28, !441, i64 32, !441, i64 36, !441, i64 40, !441, i64 44, !441, i64 48, !441, i64 52, !441, i64 56, !423, i64 60, !422, i64 64}
!1506 = !DILocation(line: 1290, column: 24, scope: !1449, inlinedAt: !1454)
!1507 = !{!1505, !441, i64 28}
!1508 = !DILocation(line: 1292, column: 27, scope: !1449, inlinedAt: !1454)
!1509 = !DILocation(line: 1293, column: 5, scope: !1449, inlinedAt: !1454)
!1510 = !DILocation(line: 1295, column: 5, scope: !1449, inlinedAt: !1454)
!1511 = !DILocation(line: 1304, column: 5, scope: !1436)
!1512 = !DILocation(line: 1305, column: 5, scope: !1436)
!1513 = !DILocation(line: 1306, column: 1, scope: !1436)
!1514 = !DISubprogram(name: "pthread_mutex_trylock", scope: !998, file: !998, line: 790, type: !999, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1515 = distinct !DISubprogram(name: "slabs_rebalancer_pause", scope: !3, file: !3, line: 1309, type: !898, scopeLine: 1309, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1516 = !DILocation(line: 1310, column: 5, scope: !1515)
!1517 = !DILocation(line: 1311, column: 1, scope: !1515)
!1518 = distinct !DISubprogram(name: "slabs_rebalancer_resume", scope: !3, file: !3, line: 1313, type: !898, scopeLine: 1313, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1519 = !DILocation(line: 1314, column: 5, scope: !1518)
!1520 = !DILocation(line: 1315, column: 1, scope: !1518)
!1521 = distinct !DISubprogram(name: "start_slab_maintenance_thread", scope: !3, file: !3, line: 1319, type: !1522, scopeLine: 1319, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1524)
!1522 = !DISubroutineType(types: !1523)
!1523 = !{!102}
!1524 = !{!1525}
!1525 = !DILocalVariable(name: "ret", scope: !1521, file: !3, line: 1320, type: !102)
!1526 = !DILocation(line: 1321, column: 27, scope: !1521)
!1527 = !DILocation(line: 1322, column: 27, scope: !1521)
!1528 = !{!1505, !422, i64 0}
!1529 = !DILocation(line: 1324, column: 16, scope: !1530)
!1530 = distinct !DILexicalBlock(scope: !1521, file: !3, line: 1324, column: 9)
!1531 = !DILocation(line: 0, scope: !1521)
!1532 = !DILocation(line: 1325, column: 61, scope: !1530)
!1533 = !DILocation(line: 1324, column: 9, scope: !1521)
!1534 = !DILocation(line: 1326, column: 17, scope: !1535)
!1535 = distinct !DILexicalBlock(scope: !1530, file: !3, line: 1325, column: 67)
!1536 = !DILocation(line: 1326, column: 60, scope: !1535)
!1537 = !DILocation(line: 1326, column: 9, scope: !1535)
!1538 = !DILocation(line: 1327, column: 9, scope: !1535)
!1539 = !DILocation(line: 1329, column: 20, scope: !1521)
!1540 = !DILocation(line: 1329, column: 5, scope: !1521)
!1541 = !DILocation(line: 1330, column: 5, scope: !1521)
!1542 = !DILocation(line: 1331, column: 1, scope: !1521)
!1543 = !DISubprogram(name: "pthread_create", scope: !998, file: !998, line: 202, type: !1544, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!1544 = !DISubroutineType(types: !1545)
!1545 = !{!102, !1546, !1548, !1556, !1559}
!1546 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1547)
!1547 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !198, size: 64)
!1548 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1549)
!1549 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1550, size: 64)
!1550 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !1551)
!1551 = !DIDerivedType(tag: DW_TAG_typedef, name: "pthread_attr_t", file: !199, line: 62, baseType: !1552)
!1552 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "pthread_attr_t", file: !199, line: 56, size: 448, elements: !1553)
!1553 = !{!1554, !1555}
!1554 = !DIDerivedType(tag: DW_TAG_member, name: "__size", scope: !1552, file: !199, line: 58, baseType: !366, size: 448)
!1555 = !DIDerivedType(tag: DW_TAG_member, name: "__align", scope: !1552, file: !199, line: 59, baseType: !279, size: 64)
!1556 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1557, size: 64)
!1557 = !DISubroutineType(types: !1558)
!1558 = !{!128, !128}
!1559 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !128)
!1560 = distinct !DISubprogram(name: "slab_rebalance_thread", scope: !3, file: !3, line: 1202, type: !1557, scopeLine: 1202, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1561)
!1561 = !{!1562, !1563, !1564, !1565}
!1562 = !DILocalVariable(name: "arg", arg: 1, scope: !1560, file: !3, line: 1202, type: !128)
!1563 = !DILocalVariable(name: "was_busy", scope: !1560, file: !3, line: 1203, type: !102)
!1564 = !DILocalVariable(name: "backoff_timer", scope: !1560, file: !3, line: 1204, type: !102)
!1565 = !DILocalVariable(name: "backoff_max", scope: !1560, file: !3, line: 1205, type: !102)
!1566 = !DILocation(line: 0, scope: !1560)
!1567 = !DILocation(line: 1207, column: 5, scope: !1560)
!1568 = !DILocation(line: 1210, column: 5, scope: !1560)
!1569 = !DILocation(line: 1204, column: 9, scope: !1560)
!1570 = !DILocation(line: 1210, column: 12, scope: !1560)
!1571 = !DILocation(line: 1210, column: 34, scope: !1560)
!1572 = !DILocation(line: 1210, column: 37, scope: !1560)
!1573 = !DILocation(line: 1211, column: 13, scope: !1574)
!1574 = distinct !DILexicalBlock(scope: !1575, file: !3, line: 1211, column: 13)
!1575 = distinct !DILexicalBlock(scope: !1560, file: !3, line: 1210, column: 67)
!1576 = !DILocation(line: 1211, column: 35, scope: !1574)
!1577 = !DILocation(line: 1211, column: 13, scope: !1575)
!1578 = !DILocalVariable(name: "no_go", scope: !1579, file: !3, line: 732, type: !102)
!1579 = distinct !DISubprogram(name: "slab_rebalance_start", scope: !3, file: !3, line: 730, type: !1522, scopeLine: 730, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1580)
!1580 = !{!1581, !1578}
!1581 = !DILocalVariable(name: "s_cls", scope: !1579, file: !3, line: 731, type: !480)
!1582 = !DILocation(line: 0, scope: !1579, inlinedAt: !1583)
!1583 = distinct !DILocation(line: 1212, column: 17, scope: !1584)
!1584 = distinct !DILexicalBlock(scope: !1585, file: !3, line: 1212, column: 17)
!1585 = distinct !DILexicalBlock(scope: !1574, file: !3, line: 1211, column: 41)
!1586 = !DILocation(line: 734, column: 5, scope: !1579, inlinedAt: !1583)
!1587 = !DILocation(line: 736, column: 20, scope: !1588, inlinedAt: !1583)
!1588 = distinct !DILexicalBlock(scope: !1579, file: !3, line: 736, column: 9)
!1589 = !DILocation(line: 736, column: 28, scope: !1588, inlinedAt: !1583)
!1590 = !DILocation(line: 736, column: 52, scope: !1588, inlinedAt: !1583)
!1591 = !DILocation(line: 745, column: 36, scope: !1592, inlinedAt: !1583)
!1592 = distinct !DILexicalBlock(scope: !1579, file: !3, line: 745, column: 9)
!1593 = !DILocation(line: 737, column: 30, scope: !1588, inlinedAt: !1583)
!1594 = !DILocation(line: 737, column: 28, scope: !1588, inlinedAt: !1583)
!1595 = !DILocation(line: 737, column: 45, scope: !1588, inlinedAt: !1583)
!1596 = !DILocation(line: 738, column: 28, scope: !1588, inlinedAt: !1583)
!1597 = !DILocation(line: 738, column: 52, scope: !1588, inlinedAt: !1583)
!1598 = !DILocation(line: 743, column: 14, scope: !1579, inlinedAt: !1583)
!1599 = !DILocation(line: 0, scope: !490, inlinedAt: !1600)
!1600 = distinct !DILocation(line: 745, column: 10, scope: !1592, inlinedAt: !1583)
!1601 = !DILocation(line: 338, column: 23, scope: !490, inlinedAt: !1600)
!1602 = !DILocation(line: 339, column: 12, scope: !498, inlinedAt: !1600)
!1603 = !DILocation(line: 339, column: 24, scope: !498, inlinedAt: !1600)
!1604 = !DILocation(line: 339, column: 18, scope: !498, inlinedAt: !1600)
!1605 = !DILocation(line: 339, column: 9, scope: !490, inlinedAt: !1600)
!1606 = !DILocation(line: 340, column: 42, scope: !497, inlinedAt: !1600)
!1607 = !DILocation(line: 340, column: 28, scope: !497, inlinedAt: !1600)
!1608 = !DILocation(line: 0, scope: !497, inlinedAt: !1600)
!1609 = !DILocation(line: 341, column: 37, scope: !497, inlinedAt: !1600)
!1610 = !DILocation(line: 341, column: 57, scope: !497, inlinedAt: !1600)
!1611 = !DILocation(line: 341, column: 26, scope: !497, inlinedAt: !1600)
!1612 = !DILocation(line: 342, column: 22, scope: !517, inlinedAt: !1600)
!1613 = !DILocation(line: 342, column: 13, scope: !497, inlinedAt: !1600)
!1614 = !DILocation(line: 343, column: 22, scope: !497, inlinedAt: !1600)
!1615 = !DILocation(line: 344, column: 22, scope: !497, inlinedAt: !1600)
!1616 = !DILocation(line: 749, column: 16, scope: !1617, inlinedAt: !1583)
!1617 = distinct !DILexicalBlock(scope: !1579, file: !3, line: 749, column: 9)
!1618 = !DILocation(line: 749, column: 22, scope: !1617, inlinedAt: !1583)
!1619 = !DILocation(line: 752, column: 15, scope: !1620, inlinedAt: !1583)
!1620 = distinct !DILexicalBlock(scope: !1579, file: !3, line: 752, column: 9)
!1621 = !DILocation(line: 752, column: 9, scope: !1579, inlinedAt: !1583)
!1622 = !DILocation(line: 760, column: 36, scope: !1579, inlinedAt: !1583)
!1623 = !DILocation(line: 760, column: 29, scope: !1579, inlinedAt: !1583)
!1624 = !DILocation(line: 760, column: 27, scope: !1579, inlinedAt: !1583)
!1625 = !DILocation(line: 762, column: 17, scope: !1579, inlinedAt: !1583)
!1626 = !DILocation(line: 762, column: 31, scope: !1579, inlinedAt: !1583)
!1627 = !DILocation(line: 762, column: 22, scope: !1579, inlinedAt: !1583)
!1628 = !DILocation(line: 761, column: 59, scope: !1579, inlinedAt: !1583)
!1629 = !DILocation(line: 761, column: 27, scope: !1579, inlinedAt: !1583)
!1630 = !{!1505, !422, i64 8}
!1631 = !DILocation(line: 763, column: 27, scope: !1579, inlinedAt: !1583)
!1632 = !{!1505, !422, i64 16}
!1633 = !DILocation(line: 766, column: 20, scope: !1634, inlinedAt: !1583)
!1634 = distinct !DILexicalBlock(scope: !1579, file: !3, line: 766, column: 9)
!1635 = !DILocation(line: 766, column: 28, scope: !1634, inlinedAt: !1583)
!1636 = !DILocation(line: 766, column: 9, scope: !1579, inlinedAt: !1583)
!1637 = !DILocation(line: 771, column: 45, scope: !1579, inlinedAt: !1583)
!1638 = !DILocation(line: 771, column: 38, scope: !1579, inlinedAt: !1583)
!1639 = !DILocation(line: 771, column: 26, scope: !1579, inlinedAt: !1583)
!1640 = !{!1505, !422, i64 64}
!1641 = !DILocation(line: 773, column: 27, scope: !1579, inlinedAt: !1583)
!1642 = !DILocation(line: 775, column: 18, scope: !1643, inlinedAt: !1583)
!1643 = distinct !DILexicalBlock(scope: !1579, file: !3, line: 775, column: 9)
!1644 = !DILocation(line: 775, column: 26, scope: !1643, inlinedAt: !1583)
!1645 = !DILocation(line: 775, column: 9, scope: !1579, inlinedAt: !1583)
!1646 = !DILocation(line: 776, column: 17, scope: !1647, inlinedAt: !1583)
!1647 = distinct !DILexicalBlock(scope: !1643, file: !3, line: 775, column: 31)
!1648 = !DILocation(line: 776, column: 9, scope: !1647, inlinedAt: !1583)
!1649 = !DILocation(line: 777, column: 5, scope: !1647, inlinedAt: !1583)
!1650 = !DILocation(line: 779, column: 5, scope: !1579, inlinedAt: !1583)
!1651 = !DILocation(line: 781, column: 5, scope: !1579, inlinedAt: !1583)
!1652 = !DILocation(line: 782, column: 39, scope: !1579, inlinedAt: !1583)
!1653 = !{!1654, !443, i64 50}
!1654 = !{!"stats_state", !440, i64 0, !440, i64 8, !440, i64 16, !440, i64 24, !441, i64 32, !441, i64 36, !441, i64 40, !441, i64 44, !443, i64 48, !443, i64 49, !443, i64 50, !443, i64 51}
!1655 = !DILocation(line: 783, column: 5, scope: !1579, inlinedAt: !1583)
!1656 = !DILocation(line: 1212, column: 17, scope: !1585)
!1657 = !DILocation(line: 753, column: 9, scope: !1658, inlinedAt: !1583)
!1658 = distinct !DILexicalBlock(scope: !1620, file: !3, line: 752, column: 21)
!1659 = !DILocation(line: 1214, column: 39, scope: !1660)
!1660 = distinct !DILexicalBlock(scope: !1584, file: !3, line: 1212, column: 45)
!1661 = !DILocation(line: 1215, column: 13, scope: !1660)
!1662 = !DILocation(line: 1218, column: 20, scope: !1663)
!1663 = distinct !DILexicalBlock(scope: !1574, file: !3, line: 1218, column: 20)
!1664 = !DILocation(line: 1218, column: 42, scope: !1663)
!1665 = !DILocation(line: 1218, column: 56, scope: !1663)
!1666 = !DILocation(line: 1218, column: 67, scope: !1663)
!1667 = !DILocation(line: 1218, column: 20, scope: !1574)
!1668 = !DILocalVariable(name: "was_busy", scope: !1669, file: !3, line: 858, type: !102)
!1669 = distinct !DISubprogram(name: "slab_rebalance_move", scope: !3, file: !3, line: 856, type: !1522, scopeLine: 856, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1670)
!1670 = !{!1671, !1668, !1672, !1673, !1674, !1675, !1676, !1677, !1680, !1681, !1689, !1690, !1691, !1692, !1700}
!1671 = !DILocalVariable(name: "s_cls", scope: !1669, file: !3, line: 857, type: !480)
!1672 = !DILocalVariable(name: "refcount", scope: !1669, file: !3, line: 859, type: !102)
!1673 = !DILocalVariable(name: "hv", scope: !1669, file: !3, line: 860, type: !585)
!1674 = !DILocalVariable(name: "hold_lock", scope: !1669, file: !3, line: 861, type: !128)
!1675 = !DILocalVariable(name: "status", scope: !1669, file: !3, line: 862, type: !82)
!1676 = !DILocalVariable(name: "offset", scope: !1669, file: !3, line: 866, type: !102)
!1677 = !DILocalVariable(name: "it", scope: !1678, file: !3, line: 873, type: !90)
!1678 = distinct !DILexicalBlock(scope: !1679, file: !3, line: 869, column: 44)
!1679 = distinct !DILexicalBlock(scope: !1669, file: !3, line: 869, column: 9)
!1680 = !DILocalVariable(name: "ch", scope: !1678, file: !3, line: 875, type: !133)
!1681 = !DILocalVariable(name: "is_linked", scope: !1682, file: !3, line: 907, type: !246)
!1682 = distinct !DILexicalBlock(scope: !1683, file: !3, line: 906, column: 24)
!1683 = distinct !DILexicalBlock(scope: !1684, file: !3, line: 904, column: 21)
!1684 = distinct !DILexicalBlock(scope: !1685, file: !3, line: 897, column: 59)
!1685 = distinct !DILexicalBlock(scope: !1686, file: !3, line: 897, column: 24)
!1686 = distinct !DILexicalBlock(scope: !1687, file: !3, line: 893, column: 17)
!1687 = distinct !DILexicalBlock(scope: !1688, file: !3, line: 891, column: 58)
!1688 = distinct !DILexicalBlock(scope: !1678, file: !3, line: 891, column: 13)
!1689 = !DILocalVariable(name: "save_item", scope: !1678, file: !3, line: 953, type: !102)
!1690 = !DILocalVariable(name: "new_it", scope: !1678, file: !3, line: 954, type: !90)
!1691 = !DILocalVariable(name: "ntotal", scope: !1678, file: !3, line: 955, type: !131)
!1692 = !DILocalVariable(name: "fch", scope: !1693, file: !3, line: 1010, type: !133)
!1693 = distinct !DILexicalBlock(scope: !1694, file: !3, line: 1009, column: 62)
!1694 = distinct !DILexicalBlock(scope: !1695, file: !3, line: 1009, column: 29)
!1695 = distinct !DILexicalBlock(scope: !1696, file: !3, line: 997, column: 37)
!1696 = distinct !DILexicalBlock(scope: !1697, file: !3, line: 997, column: 25)
!1697 = distinct !DILexicalBlock(scope: !1698, file: !3, line: 996, column: 32)
!1698 = distinct !DILexicalBlock(scope: !1699, file: !3, line: 996, column: 21)
!1699 = distinct !DILexicalBlock(scope: !1678, file: !3, line: 956, column: 25)
!1700 = !DILocalVariable(name: "nch", scope: !1701, file: !3, line: 1024, type: !133)
!1701 = distinct !DILexicalBlock(scope: !1696, file: !3, line: 1023, column: 28)
!1702 = !DILocation(line: 0, scope: !1669, inlinedAt: !1703)
!1703 = distinct !DILocation(line: 1219, column: 24, scope: !1704)
!1704 = distinct !DILexicalBlock(scope: !1663, file: !3, line: 1218, column: 76)
!1705 = !DILocation(line: 864, column: 35, scope: !1669, inlinedAt: !1703)
!1706 = !DILocation(line: 864, column: 14, scope: !1669, inlinedAt: !1703)
!1707 = !DILocation(line: 866, column: 37, scope: !1669, inlinedAt: !1703)
!1708 = !DILocation(line: 866, column: 45, scope: !1669, inlinedAt: !1703)
!1709 = !DILocation(line: 866, column: 84, scope: !1669, inlinedAt: !1703)
!1710 = !DILocation(line: 866, column: 76, scope: !1669, inlinedAt: !1703)
!1711 = !DILocation(line: 866, column: 75, scope: !1669, inlinedAt: !1703)
!1712 = !DILocation(line: 869, column: 20, scope: !1679, inlinedAt: !1703)
!1713 = !DILocation(line: 869, column: 9, scope: !1679, inlinedAt: !1703)
!1714 = !DILocation(line: 869, column: 38, scope: !1679, inlinedAt: !1703)
!1715 = !DILocation(line: 869, column: 9, scope: !1669, inlinedAt: !1703)
!1716 = !DILocation(line: 870, column: 9, scope: !1678, inlinedAt: !1703)
!1717 = !DILocation(line: 873, column: 31, scope: !1678, inlinedAt: !1703)
!1718 = !DILocation(line: 0, scope: !1678, inlinedAt: !1703)
!1719 = !DILocation(line: 878, column: 17, scope: !1720, inlinedAt: !1703)
!1720 = distinct !DILexicalBlock(scope: !1678, file: !3, line: 878, column: 13)
!1721 = !DILocation(line: 878, column: 26, scope: !1720, inlinedAt: !1703)
!1722 = !DILocation(line: 878, column: 13, scope: !1678, inlinedAt: !1703)
!1723 = !DILocation(line: 884, column: 22, scope: !1724, inlinedAt: !1703)
!1724 = distinct !DILexicalBlock(scope: !1720, file: !3, line: 878, column: 40)
!1725 = !DILocation(line: 891, column: 17, scope: !1688, inlinedAt: !1703)
!1726 = !DILocation(line: 886, column: 9, scope: !1724, inlinedAt: !1703)
!1727 = !DILocation(line: 891, column: 13, scope: !1688, inlinedAt: !1703)
!1728 = !DILocation(line: 891, column: 26, scope: !1688, inlinedAt: !1703)
!1729 = !DILocation(line: 891, column: 13, scope: !1678, inlinedAt: !1703)
!1730 = !DILocation(line: 893, column: 30, scope: !1686, inlinedAt: !1703)
!1731 = !DILocation(line: 893, column: 17, scope: !1687, inlinedAt: !1703)
!1732 = !DILocalVariable(name: "s_cls", arg: 1, scope: !1733, file: !3, line: 822, type: !480)
!1733 = distinct !DISubprogram(name: "slab_rebalance_cut_free", scope: !3, file: !3, line: 822, type: !1734, scopeLine: 822, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1736)
!1734 = !DISubroutineType(types: !1735)
!1735 = !{null, !480, !90}
!1736 = !{!1732, !1737}
!1737 = !DILocalVariable(name: "it", arg: 2, scope: !1733, file: !3, line: 822, type: !90)
!1738 = !DILocation(line: 0, scope: !1733, inlinedAt: !1739)
!1739 = distinct !DILocation(line: 895, column: 17, scope: !1740, inlinedAt: !1703)
!1740 = distinct !DILexicalBlock(scope: !1686, file: !3, line: 893, column: 46)
!1741 = !DILocation(line: 825, column: 16, scope: !1742, inlinedAt: !1739)
!1742 = distinct !DILexicalBlock(scope: !1733, file: !3, line: 825, column: 9)
!1743 = !DILocation(line: 825, column: 22, scope: !1742, inlinedAt: !1739)
!1744 = !DILocation(line: 828, column: 13, scope: !1745, inlinedAt: !1739)
!1745 = distinct !DILexicalBlock(scope: !1733, file: !3, line: 828, column: 9)
!1746 = !DILocation(line: 825, column: 9, scope: !1733, inlinedAt: !1739)
!1747 = !DILocation(line: 826, column: 22, scope: !1748, inlinedAt: !1739)
!1748 = distinct !DILexicalBlock(scope: !1742, file: !3, line: 825, column: 29)
!1749 = !DILocation(line: 827, column: 5, scope: !1748, inlinedAt: !1739)
!1750 = !DILocation(line: 828, column: 9, scope: !1745, inlinedAt: !1739)
!1751 = !DILocation(line: 828, column: 9, scope: !1733, inlinedAt: !1739)
!1752 = !DILocation(line: 828, column: 29, scope: !1745, inlinedAt: !1739)
!1753 = !DILocation(line: 828, column: 34, scope: !1745, inlinedAt: !1739)
!1754 = !DILocation(line: 828, column: 19, scope: !1745, inlinedAt: !1739)
!1755 = !DILocation(line: 829, column: 9, scope: !1756, inlinedAt: !1739)
!1756 = distinct !DILexicalBlock(scope: !1733, file: !3, line: 829, column: 9)
!1757 = !DILocation(line: 829, column: 9, scope: !1733, inlinedAt: !1739)
!1758 = !DILocation(line: 829, column: 40, scope: !1756, inlinedAt: !1739)
!1759 = !DILocation(line: 829, column: 34, scope: !1756, inlinedAt: !1739)
!1760 = !DILocation(line: 829, column: 19, scope: !1756, inlinedAt: !1739)
!1761 = !DILocation(line: 830, column: 12, scope: !1733, inlinedAt: !1739)
!1762 = !DILocation(line: 830, column: 19, scope: !1733, inlinedAt: !1739)
!1763 = !DILocation(line: 1068, column: 28, scope: !1699, inlinedAt: !1703)
!1764 = !DILocation(line: 1068, column: 17, scope: !1699, inlinedAt: !1703)
!1765 = !DILocation(line: 1068, column: 46, scope: !1699, inlinedAt: !1703)
!1766 = !DILocation(line: 1069, column: 21, scope: !1699, inlinedAt: !1703)
!1767 = !DILocation(line: 1069, column: 30, scope: !1699, inlinedAt: !1703)
!1768 = !DILocation(line: 1070, column: 30, scope: !1699, inlinedAt: !1703)
!1769 = !DILocation(line: 1074, column: 17, scope: !1699, inlinedAt: !1703)
!1770 = !DILocation(line: 897, column: 38, scope: !1685, inlinedAt: !1703)
!1771 = !DILocation(line: 897, column: 53, scope: !1685, inlinedAt: !1703)
!1772 = !DILocation(line: 897, column: 24, scope: !1686, inlinedAt: !1703)
!1773 = !DILocation(line: 903, column: 22, scope: !1684, inlinedAt: !1703)
!1774 = !DILocation(line: 903, column: 27, scope: !1684, inlinedAt: !1703)
!1775 = !DILocation(line: 903, column: 45, scope: !1684, inlinedAt: !1703)
!1776 = !DILocation(line: 903, column: 41, scope: !1684, inlinedAt: !1703)
!1777 = !DILocation(line: 904, column: 34, scope: !1683, inlinedAt: !1703)
!1778 = !DILocation(line: 904, column: 52, scope: !1683, inlinedAt: !1703)
!1779 = !DILocation(line: 904, column: 21, scope: !1684, inlinedAt: !1703)
!1780 = !DILocation(line: 907, column: 43, scope: !1682, inlinedAt: !1703)
!1781 = !DILocation(line: 907, column: 52, scope: !1682, inlinedAt: !1703)
!1782 = !DILocation(line: 907, column: 38, scope: !1682, inlinedAt: !1703)
!1783 = !DILocation(line: 0, scope: !1682, inlinedAt: !1703)
!1784 = !DILocation(line: 908, column: 32, scope: !1682, inlinedAt: !1703)
!1785 = !DILocation(line: 909, column: 34, scope: !1786, inlinedAt: !1703)
!1786 = distinct !DILexicalBlock(scope: !1682, file: !3, line: 909, column: 25)
!1787 = !DILocation(line: 909, column: 25, scope: !1682, inlinedAt: !1703)
!1788 = !DILocation(line: 920, column: 41, scope: !1789, inlinedAt: !1703)
!1789 = distinct !DILexicalBlock(scope: !1786, file: !3, line: 920, column: 32)
!1790 = !DILocation(line: 920, column: 45, scope: !1789, inlinedAt: !1703)
!1791 = !DILocation(line: 923, column: 40, scope: !1792, inlinedAt: !1703)
!1792 = distinct !DILexicalBlock(scope: !1793, file: !3, line: 923, column: 29)
!1793 = distinct !DILexicalBlock(scope: !1789, file: !3, line: 920, column: 59)
!1794 = !{!1505, !441, i64 56}
!1795 = !DILocation(line: 923, column: 51, scope: !1792, inlinedAt: !1703)
!1796 = !DILocation(line: 923, column: 29, scope: !1793, inlinedAt: !1703)
!1797 = !DILocation(line: 924, column: 52, scope: !1798, inlinedAt: !1703)
!1798 = distinct !DILexicalBlock(scope: !1792, file: !3, line: 923, column: 74)
!1799 = !{!1505, !441, i64 52}
!1800 = !DILocation(line: 927, column: 29, scope: !1801, inlinedAt: !1703)
!1801 = distinct !DILexicalBlock(scope: !1798, file: !3, line: 927, column: 29)
!1802 = !DILocation(line: 928, column: 29, scope: !1798, inlinedAt: !1703)
!1803 = !DILocation(line: 929, column: 29, scope: !1798, inlinedAt: !1703)
!1804 = !DILocation(line: 930, column: 29, scope: !1798, inlinedAt: !1703)
!1805 = !DILocation(line: 931, column: 25, scope: !1798, inlinedAt: !1703)
!1806 = !DILocation(line: 934, column: 38, scope: !1807, inlinedAt: !1703)
!1807 = distinct !DILexicalBlock(scope: !1808, file: !3, line: 934, column: 29)
!1808 = distinct !DILexicalBlock(scope: !1789, file: !3, line: 933, column: 28)
!1809 = !DILocation(line: 934, column: 46, scope: !1807, inlinedAt: !1703)
!1810 = !DILocation(line: 934, column: 29, scope: !1808, inlinedAt: !1703)
!1811 = !DILocation(line: 935, column: 37, scope: !1812, inlinedAt: !1703)
!1812 = distinct !DILexicalBlock(scope: !1807, file: !3, line: 934, column: 51)
!1813 = !DILocation(line: 936, column: 33, scope: !1812, inlinedAt: !1703)
!1814 = !DILocation(line: 936, column: 58, scope: !1812, inlinedAt: !1703)
!1815 = !DILocation(line: 936, column: 78, scope: !1812, inlinedAt: !1703)
!1816 = !DILocation(line: 935, column: 29, scope: !1812, inlinedAt: !1703)
!1817 = !DILocation(line: 937, column: 25, scope: !1812, inlinedAt: !1703)
!1818 = !DILocation(line: 941, column: 25, scope: !1682, inlinedAt: !1703)
!1819 = !DILocation(line: 942, column: 25, scope: !1820, inlinedAt: !1703)
!1820 = distinct !DILexicalBlock(scope: !1821, file: !3, line: 941, column: 46)
!1821 = distinct !DILexicalBlock(scope: !1682, file: !3, line: 941, column: 25)
!1822 = !DILocation(line: 943, column: 25, scope: !1820, inlinedAt: !1703)
!1823 = !DILocation(line: 956, column: 9, scope: !1678, inlinedAt: !1703)
!1824 = !DILocation(line: 965, column: 26, scope: !1699, inlinedAt: !1703)
!1825 = !DILocation(line: 967, column: 34, scope: !1826, inlinedAt: !1703)
!1826 = distinct !DILexicalBlock(scope: !1699, file: !3, line: 967, column: 21)
!1827 = !DILocation(line: 967, column: 21, scope: !1699, inlinedAt: !1703)
!1828 = !DILocation(line: 972, column: 24, scope: !1829, inlinedAt: !1703)
!1829 = distinct !DILexicalBlock(scope: !1699, file: !3, line: 972, column: 21)
!1830 = !DILocation(line: 972, column: 32, scope: !1829, inlinedAt: !1703)
!1831 = !DILocation(line: 975, column: 37, scope: !1832, inlinedAt: !1703)
!1832 = distinct !DILexicalBlock(scope: !1829, file: !3, line: 972, column: 66)
!1833 = !DILocation(line: 975, column: 30, scope: !1832, inlinedAt: !1703)
!1834 = !DILocation(line: 976, column: 17, scope: !1832, inlinedAt: !1703)
!1835 = !DILocation(line: 0, scope: !1699, inlinedAt: !1703)
!1836 = !DILocation(line: 977, column: 26, scope: !1837, inlinedAt: !1703)
!1837 = distinct !DILexicalBlock(scope: !1699, file: !3, line: 977, column: 21)
!1838 = !DILocation(line: 977, column: 34, scope: !1837, inlinedAt: !1703)
!1839 = !DILocation(line: 977, column: 39, scope: !1837, inlinedAt: !1703)
!1840 = !DILocation(line: 977, column: 56, scope: !1837, inlinedAt: !1703)
!1841 = !DILocation(line: 977, column: 54, scope: !1837, inlinedAt: !1703)
!1842 = !DILocation(line: 978, column: 21, scope: !1837, inlinedAt: !1703)
!1843 = !DILocation(line: 978, column: 24, scope: !1837, inlinedAt: !1703)
!1844 = !DILocation(line: 977, column: 21, scope: !1699, inlinedAt: !1703)
!1845 = !DILocation(line: 0, scope: !1846, inlinedAt: !1703)
!1846 = distinct !DILexicalBlock(scope: !1837, file: !3, line: 981, column: 28)
!1847 = !DILocation(line: 981, column: 39, scope: !1846, inlinedAt: !1703)
!1848 = !DILocation(line: 981, column: 28, scope: !1837, inlinedAt: !1703)
!1849 = !DILocation(line: 986, column: 28, scope: !1846, inlinedAt: !1703)
!1850 = !DILocation(line: 995, column: 17, scope: !1699, inlinedAt: !1703)
!1851 = !DILocation(line: 1000, column: 25, scope: !1695, inlinedAt: !1703)
!1852 = !DILocation(line: 1005, column: 33, scope: !1695, inlinedAt: !1703)
!1853 = !DILocation(line: 1002, column: 38, scope: !1695, inlinedAt: !1703)
!1854 = !DILocation(line: 1005, column: 42, scope: !1695, inlinedAt: !1703)
!1855 = !DILocation(line: 1006, column: 33, scope: !1695, inlinedAt: !1703)
!1856 = !DILocation(line: 1006, column: 42, scope: !1695, inlinedAt: !1703)
!1857 = !DILocation(line: 1007, column: 57, scope: !1695, inlinedAt: !1703)
!1858 = !DILocation(line: 1007, column: 25, scope: !1695, inlinedAt: !1703)
!1859 = !DILocation(line: 1009, column: 37, scope: !1694, inlinedAt: !1703)
!1860 = !DILocation(line: 1009, column: 29, scope: !1694, inlinedAt: !1703)
!1861 = !DILocation(line: 1009, column: 46, scope: !1694, inlinedAt: !1703)
!1862 = !DILocation(line: 1009, column: 29, scope: !1695, inlinedAt: !1703)
!1863 = !DILocation(line: 1010, column: 62, scope: !1693, inlinedAt: !1703)
!1864 = !DILocation(line: 0, scope: !1693, inlinedAt: !1703)
!1865 = !DILocation(line: 1011, column: 34, scope: !1693, inlinedAt: !1703)
!1866 = !DILocation(line: 1011, column: 40, scope: !1693, inlinedAt: !1703)
!1867 = !DILocation(line: 1011, column: 45, scope: !1693, inlinedAt: !1703)
!1868 = !DILocation(line: 1012, column: 29, scope: !1693, inlinedAt: !1703)
!1869 = !DILocation(line: 1013, column: 38, scope: !1870, inlinedAt: !1703)
!1870 = distinct !DILexicalBlock(scope: !1693, file: !3, line: 1012, column: 41)
!1871 = !DILocation(line: 1013, column: 43, scope: !1870, inlinedAt: !1703)
!1872 = !DILocation(line: 1014, column: 44, scope: !1870, inlinedAt: !1703)
!1873 = distinct !{!1873, !1868, !1874, !461}
!1874 = !DILocation(line: 1015, column: 29, scope: !1693, inlinedAt: !1703)
!1875 = !DILocation(line: 1017, column: 38, scope: !1695, inlinedAt: !1703)
!1876 = !DILocation(line: 1018, column: 38, scope: !1695, inlinedAt: !1703)
!1877 = !DILocation(line: 1022, column: 43, scope: !1695, inlinedAt: !1703)
!1878 = !{!1505, !441, i64 36}
!1879 = !DILocation(line: 1023, column: 21, scope: !1695, inlinedAt: !1703)
!1880 = !DILocation(line: 0, scope: !1701, inlinedAt: !1703)
!1881 = !DILocation(line: 1026, column: 29, scope: !1701, inlinedAt: !1703)
!1882 = !DILocation(line: 1026, column: 40, scope: !1701, inlinedAt: !1703)
!1883 = !DILocation(line: 1027, column: 33, scope: !1884, inlinedAt: !1703)
!1884 = distinct !DILexicalBlock(scope: !1701, file: !3, line: 1027, column: 29)
!1885 = !DILocation(line: 1027, column: 29, scope: !1884, inlinedAt: !1703)
!1886 = !DILocation(line: 1027, column: 29, scope: !1701, inlinedAt: !1703)
!1887 = !DILocation(line: 1028, column: 39, scope: !1884, inlinedAt: !1703)
!1888 = !DILocation(line: 1028, column: 44, scope: !1884, inlinedAt: !1703)
!1889 = !DILocation(line: 1028, column: 29, scope: !1884, inlinedAt: !1703)
!1890 = !DILocation(line: 1029, column: 45, scope: !1701, inlinedAt: !1703)
!1891 = !DILocation(line: 1029, column: 41, scope: !1701, inlinedAt: !1703)
!1892 = !DILocation(line: 1029, column: 50, scope: !1701, inlinedAt: !1703)
!1893 = !DILocation(line: 1029, column: 25, scope: !1701, inlinedAt: !1703)
!1894 = !DILocation(line: 1030, column: 29, scope: !1701, inlinedAt: !1703)
!1895 = !DILocation(line: 1030, column: 38, scope: !1701, inlinedAt: !1703)
!1896 = !DILocation(line: 1031, column: 29, scope: !1701, inlinedAt: !1703)
!1897 = !DILocation(line: 1031, column: 38, scope: !1701, inlinedAt: !1703)
!1898 = !DILocation(line: 1032, column: 49, scope: !1701, inlinedAt: !1703)
!1899 = !{!1505, !441, i64 48}
!1900 = !DILocation(line: 1036, column: 25, scope: !1701, inlinedAt: !1703)
!1901 = !DILocation(line: 1038, column: 32, scope: !1697, inlinedAt: !1703)
!1902 = !DILocation(line: 1038, column: 21, scope: !1697, inlinedAt: !1703)
!1903 = !DILocation(line: 1038, column: 50, scope: !1697, inlinedAt: !1703)
!1904 = !DILocation(line: 1039, column: 17, scope: !1697, inlinedAt: !1703)
!1905 = !{!1505, !441, i64 40}
!1906 = !DILocation(line: 1042, column: 21, scope: !1907, inlinedAt: !1703)
!1907 = distinct !DILexicalBlock(scope: !1908, file: !3, line: 1042, column: 21)
!1908 = distinct !DILexicalBlock(scope: !1698, file: !3, line: 1039, column: 24)
!1909 = !DILocation(line: 1052, column: 34, scope: !1910, inlinedAt: !1703)
!1910 = distinct !DILexicalBlock(scope: !1911, file: !3, line: 1051, column: 28)
!1911 = distinct !DILexicalBlock(scope: !1908, file: !3, line: 1043, column: 25)
!1912 = !DILocation(line: 1043, column: 29, scope: !1911, inlinedAt: !1703)
!1913 = !DILocation(line: 0, scope: !1911, inlinedAt: !1703)
!1914 = !DILocation(line: 1045, column: 38, scope: !1915, inlinedAt: !1703)
!1915 = distinct !DILexicalBlock(scope: !1911, file: !3, line: 1043, column: 68)
!1916 = !DILocation(line: 1046, column: 38, scope: !1915, inlinedAt: !1703)
!1917 = !DILocation(line: 1050, column: 36, scope: !1915, inlinedAt: !1703)
!1918 = !DILocation(line: 1050, column: 25, scope: !1915, inlinedAt: !1703)
!1919 = !DILocation(line: 1050, column: 54, scope: !1915, inlinedAt: !1703)
!1920 = !DILocation(line: 1051, column: 21, scope: !1915, inlinedAt: !1703)
!1921 = !DILocation(line: 1054, column: 59, scope: !1910, inlinedAt: !1703)
!1922 = !DILocation(line: 0, scope: !1082, inlinedAt: !1923)
!1923 = distinct !DILocation(line: 1054, column: 25, scope: !1910, inlinedAt: !1703)
!1924 = !DILocation(line: 667, column: 5, scope: !1082, inlinedAt: !1923)
!1925 = !DILocation(line: 668, column: 5, scope: !1082, inlinedAt: !1923)
!1926 = !DILocation(line: 669, column: 5, scope: !1082, inlinedAt: !1923)
!1927 = !DILocation(line: 1056, column: 46, scope: !1910, inlinedAt: !1703)
!1928 = !{!1505, !441, i64 32}
!1929 = !DILocation(line: 1061, column: 17, scope: !1699, inlinedAt: !1703)
!1930 = !DILocation(line: 1062, column: 17, scope: !1699, inlinedAt: !1703)
!1931 = !DILocation(line: 1066, column: 17, scope: !1699, inlinedAt: !1703)
!1932 = !DILocation(line: 1077, column: 38, scope: !1699, inlinedAt: !1703)
!1933 = !DILocation(line: 1079, column: 17, scope: !1699, inlinedAt: !1703)
!1934 = !DILocation(line: 1084, column: 9, scope: !1678, inlinedAt: !1703)
!1935 = !DILocation(line: 1090, column: 46, scope: !1669, inlinedAt: !1703)
!1936 = !DILocation(line: 1090, column: 64, scope: !1669, inlinedAt: !1703)
!1937 = !DILocation(line: 1090, column: 55, scope: !1669, inlinedAt: !1703)
!1938 = !DILocation(line: 1085, column: 5, scope: !1678, inlinedAt: !1703)
!1939 = !DILocation(line: 858, column: 9, scope: !1669, inlinedAt: !1703)
!1940 = !DILocation(line: 1090, column: 25, scope: !1669, inlinedAt: !1703)
!1941 = !DILocation(line: 1092, column: 43, scope: !1942, inlinedAt: !1703)
!1942 = distinct !DILexicalBlock(scope: !1669, file: !3, line: 1092, column: 9)
!1943 = !DILocation(line: 1092, column: 29, scope: !1942, inlinedAt: !1703)
!1944 = !DILocation(line: 1092, column: 9, scope: !1669, inlinedAt: !1703)
!1945 = !DILocation(line: 1094, column: 24, scope: !1946, inlinedAt: !1703)
!1946 = distinct !DILexicalBlock(scope: !1947, file: !3, line: 1094, column: 13)
!1947 = distinct !DILexicalBlock(scope: !1942, file: !3, line: 1092, column: 53)
!1948 = !DILocation(line: 1094, column: 13, scope: !1946, inlinedAt: !1703)
!1949 = !DILocation(line: 1094, column: 13, scope: !1947, inlinedAt: !1703)
!1950 = !DILocation(line: 1095, column: 46, scope: !1951, inlinedAt: !1703)
!1951 = distinct !DILexicalBlock(scope: !1946, file: !3, line: 1094, column: 36)
!1952 = !DILocation(line: 1095, column: 33, scope: !1951, inlinedAt: !1703)
!1953 = !DILocation(line: 1096, column: 13, scope: !1951, inlinedAt: !1703)
!1954 = !DILocation(line: 1097, column: 58, scope: !1951, inlinedAt: !1703)
!1955 = !DILocation(line: 1097, column: 47, scope: !1951, inlinedAt: !1703)
!1956 = !DILocation(line: 1097, column: 44, scope: !1951, inlinedAt: !1703)
!1957 = !{!1958, !440, i64 80}
!1958 = !{!"stats", !440, i64 0, !440, i64 8, !440, i64 16, !440, i64 24, !440, i64 32, !440, i64 40, !440, i64 48, !440, i64 56, !440, i64 64, !440, i64 72, !440, i64 80, !440, i64 88, !440, i64 96, !440, i64 104, !440, i64 112, !440, i64 120, !440, i64 128, !440, i64 136, !440, i64 144, !440, i64 152, !440, i64 160, !440, i64 168, !440, i64 176, !440, i64 184, !1959, i64 192, !440, i64 208, !440, i64 216}
!1959 = !{!"timeval", !440, i64 0, !440, i64 8}
!1960 = !DILocation(line: 1098, column: 13, scope: !1951, inlinedAt: !1703)
!1961 = !DILocation(line: 1099, column: 35, scope: !1951, inlinedAt: !1703)
!1962 = !DILocation(line: 1100, column: 34, scope: !1951, inlinedAt: !1703)
!1963 = !DILocation(line: 1101, column: 9, scope: !1951, inlinedAt: !1703)
!1964 = !DILocation(line: 1102, column: 28, scope: !1965, inlinedAt: !1703)
!1965 = distinct !DILexicalBlock(scope: !1946, file: !3, line: 1101, column: 16)
!1966 = !{!1505, !423, i64 60}
!1967 = !DILocation(line: 1222, column: 24, scope: !1968)
!1968 = distinct !DILexicalBlock(scope: !1575, file: !3, line: 1222, column: 13)
!1969 = !DILocation(line: 1222, column: 13, scope: !1968)
!1970 = !DILocation(line: 1222, column: 13, scope: !1575)
!1971 = !DILocation(line: 1119, column: 5, scope: !1972, inlinedAt: !1982)
!1972 = distinct !DISubprogram(name: "slab_rebalance_finish", scope: !3, file: !3, line: 1109, type: !898, scopeLine: 1109, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1973)
!1973 = !{!1974, !1975, !1976, !1977, !1978, !1979, !1980, !1981}
!1974 = !DILocalVariable(name: "s_cls", scope: !1972, file: !3, line: 1110, type: !480)
!1975 = !DILocalVariable(name: "d_cls", scope: !1972, file: !3, line: 1111, type: !480)
!1976 = !DILocalVariable(name: "x", scope: !1972, file: !3, line: 1112, type: !102)
!1977 = !DILocalVariable(name: "rescues", scope: !1972, file: !3, line: 1113, type: !585)
!1978 = !DILocalVariable(name: "evictions_nomem", scope: !1972, file: !3, line: 1114, type: !585)
!1979 = !DILocalVariable(name: "inline_reclaim", scope: !1972, file: !3, line: 1115, type: !585)
!1980 = !DILocalVariable(name: "chunk_rescues", scope: !1972, file: !3, line: 1116, type: !585)
!1981 = !DILocalVariable(name: "busy_deletes", scope: !1972, file: !3, line: 1117, type: !585)
!1982 = distinct !DILocation(line: 1223, column: 13, scope: !1983)
!1983 = distinct !DILexicalBlock(scope: !1968, file: !3, line: 1222, column: 30)
!1984 = !DILocation(line: 1121, column: 35, scope: !1972, inlinedAt: !1982)
!1985 = !DILocation(line: 1121, column: 14, scope: !1972, inlinedAt: !1982)
!1986 = !DILocation(line: 0, scope: !1972, inlinedAt: !1982)
!1987 = !DILocation(line: 1122, column: 35, scope: !1972, inlinedAt: !1982)
!1988 = !DILocation(line: 1122, column: 14, scope: !1972, inlinedAt: !1982)
!1989 = !DILocation(line: 1142, column: 12, scope: !1972, inlinedAt: !1982)
!1990 = !DILocation(line: 1142, column: 17, scope: !1972, inlinedAt: !1982)
!1991 = !DILocation(line: 1143, column: 19, scope: !1992, inlinedAt: !1982)
!1992 = distinct !DILexicalBlock(scope: !1993, file: !3, line: 1143, column: 5)
!1993 = distinct !DILexicalBlock(scope: !1972, file: !3, line: 1143, column: 5)
!1994 = !DILocation(line: 1143, column: 5, scope: !1993, inlinedAt: !1982)
!1995 = !DILocation(line: 1144, column: 49, scope: !1996, inlinedAt: !1982)
!1996 = distinct !DILexicalBlock(scope: !1992, file: !3, line: 1143, column: 40)
!1997 = !DILocation(line: 1144, column: 31, scope: !1996, inlinedAt: !1982)
!1998 = !DILocation(line: 1144, column: 9, scope: !1996, inlinedAt: !1982)
!1999 = !DILocation(line: 1144, column: 29, scope: !1996, inlinedAt: !1982)
!2000 = distinct !{!2000, !1994, !2001, !461}
!2001 = !DILocation(line: 1145, column: 5, scope: !1993, inlinedAt: !1982)
!2002 = distinct !{!2002, !2003}
!2003 = !{!"llvm.loop.unroll.disable"}
!2004 = !DILocation(line: 1147, column: 51, scope: !1972, inlinedAt: !1982)
!2005 = !DILocation(line: 1147, column: 12, scope: !1972, inlinedAt: !1982)
!2006 = !DILocation(line: 1147, column: 29, scope: !1972, inlinedAt: !1982)
!2007 = !DILocation(line: 1147, column: 34, scope: !1972, inlinedAt: !1982)
!2008 = !DILocation(line: 1147, column: 5, scope: !1972, inlinedAt: !1982)
!2009 = !DILocation(line: 1147, column: 38, scope: !1972, inlinedAt: !1982)
!2010 = !DILocation(line: 1149, column: 28, scope: !2011, inlinedAt: !1982)
!2011 = distinct !DILexicalBlock(scope: !1972, file: !3, line: 1149, column: 9)
!2012 = !DILocation(line: 1149, column: 9, scope: !1972, inlinedAt: !1982)
!2013 = !DILocation(line: 1150, column: 59, scope: !2014, inlinedAt: !1982)
!2014 = distinct !DILexicalBlock(scope: !2011, file: !3, line: 1149, column: 53)
!2015 = !DILocation(line: 1150, column: 42, scope: !2014, inlinedAt: !1982)
!2016 = !DILocation(line: 1150, column: 9, scope: !2014, inlinedAt: !1982)
!2017 = !DILocation(line: 1152, column: 24, scope: !2014, inlinedAt: !1982)
!2018 = !DILocalVariable(name: "ptr", arg: 1, scope: !2019, file: !3, line: 349, type: !127)
!2019 = distinct !DISubprogram(name: "split_slab_page_into_freelist", scope: !3, file: !3, line: 349, type: !2020, scopeLine: 349, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2022)
!2020 = !DISubroutineType(types: !2021)
!2021 = !{null, !127, !493}
!2022 = !{!2018, !2023, !2024, !2025}
!2023 = !DILocalVariable(name: "id", arg: 2, scope: !2019, file: !3, line: 349, type: !493)
!2024 = !DILocalVariable(name: "p", scope: !2019, file: !3, line: 350, type: !480)
!2025 = !DILocalVariable(name: "x", scope: !2019, file: !3, line: 351, type: !102)
!2026 = !DILocation(line: 0, scope: !2019, inlinedAt: !2027)
!2027 = distinct !DILocation(line: 1151, column: 9, scope: !2014, inlinedAt: !1982)
!2028 = !DILocation(line: 350, column: 23, scope: !2019, inlinedAt: !2027)
!2029 = !DILocation(line: 352, column: 24, scope: !2030, inlinedAt: !2027)
!2030 = distinct !DILexicalBlock(scope: !2031, file: !3, line: 352, column: 5)
!2031 = distinct !DILexicalBlock(scope: !2019, file: !3, line: 352, column: 5)
!2032 = !DILocation(line: 352, column: 19, scope: !2030, inlinedAt: !2027)
!2033 = !DILocation(line: 352, column: 5, scope: !2031, inlinedAt: !2027)
!2034 = !DILocation(line: 1151, column: 50, scope: !2014, inlinedAt: !1982)
!2035 = !DILocation(line: 353, column: 9, scope: !2036, inlinedAt: !2027)
!2036 = distinct !DILexicalBlock(scope: !2030, file: !3, line: 352, column: 38)
!2037 = !DILocation(line: 354, column: 19, scope: !2036, inlinedAt: !2027)
!2038 = !DILocation(line: 354, column: 13, scope: !2036, inlinedAt: !2027)
!2039 = !DILocation(line: 352, column: 34, scope: !2030, inlinedAt: !2027)
!2040 = distinct !{!2040, !2033, !2041, !461}
!2041 = !DILocation(line: 355, column: 5, scope: !2031, inlinedAt: !2027)
!2042 = !DILocation(line: 1153, column: 35, scope: !2043, inlinedAt: !1982)
!2043 = distinct !DILexicalBlock(scope: !2011, file: !3, line: 1153, column: 16)
!2044 = !DILocation(line: 1153, column: 16, scope: !2011, inlinedAt: !1982)
!2045 = !DILocation(line: 1155, column: 9, scope: !2046, inlinedAt: !1982)
!2046 = distinct !DILexicalBlock(scope: !2043, file: !3, line: 1153, column: 61)
!2047 = !DILocation(line: 0, scope: !1362, inlinedAt: !2048)
!2048 = distinct !DILocation(line: 1158, column: 9, scope: !2046, inlinedAt: !1982)
!2049 = !DILocation(line: 643, column: 9, scope: !2050, inlinedAt: !2048)
!2050 = distinct !DILexicalBlock(scope: !1362, file: !3, line: 643, column: 9)
!2051 = !DILocation(line: 643, column: 18, scope: !2050, inlinedAt: !2048)
!2052 = !DILocation(line: 643, column: 9, scope: !1362, inlinedAt: !2048)
!2053 = !DILocation(line: 646, column: 19, scope: !1367, inlinedAt: !2048)
!2054 = !DILocation(line: 646, column: 9, scope: !1362, inlinedAt: !2048)
!2055 = !DILocation(line: 649, column: 25, scope: !1362, inlinedAt: !2048)
!2056 = !DILocation(line: 649, column: 37, scope: !1362, inlinedAt: !2048)
!2057 = !DILocation(line: 649, column: 5, scope: !1362, inlinedAt: !2048)
!2058 = !DILocation(line: 0, scope: !1376, inlinedAt: !2059)
!2059 = distinct !DILocation(line: 650, column: 18, scope: !1362, inlinedAt: !2048)
!2060 = !DILocation(line: 361, column: 18, scope: !1384, inlinedAt: !2059)
!2061 = !DILocation(line: 361, column: 9, scope: !1376, inlinedAt: !2059)
!2062 = !DILocation(line: 364, column: 20, scope: !1376, inlinedAt: !2059)
!2063 = !DILocation(line: 364, column: 39, scope: !1376, inlinedAt: !2059)
!2064 = !DILocation(line: 364, column: 17, scope: !1376, inlinedAt: !2059)
!2065 = !DILocation(line: 365, column: 13, scope: !1376, inlinedAt: !2059)
!2066 = !DILocation(line: 650, column: 47, scope: !1362, inlinedAt: !2048)
!2067 = !DILocation(line: 651, column: 9, scope: !1392, inlinedAt: !2048)
!2068 = !DILocation(line: 652, column: 34, scope: !1392, inlinedAt: !2048)
!2069 = !DILocation(line: 652, column: 25, scope: !1392, inlinedAt: !2048)
!2070 = !DILocation(line: 652, column: 22, scope: !1392, inlinedAt: !2048)
!2071 = distinct !{!2071, !2057, !2072, !461}
!2072 = !DILocation(line: 653, column: 5, scope: !1362, inlinedAt: !2048)
!2073 = !DILocation(line: 1161, column: 27, scope: !1972, inlinedAt: !1982)
!2074 = !DILocation(line: 1162, column: 27, scope: !1972, inlinedAt: !1982)
!2075 = !DILocation(line: 1165, column: 27, scope: !1972, inlinedAt: !1982)
!2076 = !DILocation(line: 1170, column: 28, scope: !1972, inlinedAt: !1982)
!2077 = !DILocation(line: 1171, column: 32, scope: !1972, inlinedAt: !1982)
!2078 = !DILocation(line: 1172, column: 31, scope: !1972, inlinedAt: !1982)
!2079 = !DILocation(line: 1186, column: 36, scope: !1972, inlinedAt: !1982)
!2080 = !DILocation(line: 1185, column: 22, scope: !1972, inlinedAt: !1982)
!2081 = !DILocation(line: 1168, column: 37, scope: !1972, inlinedAt: !1982)
!2082 = !DILocation(line: 1175, column: 25, scope: !1972, inlinedAt: !1982)
!2083 = !DILocation(line: 1179, column: 27, scope: !1972, inlinedAt: !1982)
!2084 = !DILocation(line: 1181, column: 21, scope: !1972, inlinedAt: !1982)
!2085 = !DILocation(line: 1181, column: 5, scope: !1972, inlinedAt: !1982)
!2086 = !DILocation(line: 1182, column: 5, scope: !1972, inlinedAt: !1982)
!2087 = !DILocation(line: 1184, column: 5, scope: !1972, inlinedAt: !1982)
!2088 = !DILocation(line: 1187, column: 44, scope: !1972, inlinedAt: !1982)
!2089 = !DILocation(line: 1187, column: 41, scope: !1972, inlinedAt: !1982)
!2090 = !DILocation(line: 1189, column: 42, scope: !1972, inlinedAt: !1982)
!2091 = !DILocation(line: 1189, column: 39, scope: !1972, inlinedAt: !1982)
!2092 = !{!1958, !440, i64 72}
!2093 = !DILocation(line: 1190, column: 41, scope: !1972, inlinedAt: !1982)
!2094 = !DILocation(line: 1190, column: 38, scope: !1972, inlinedAt: !1982)
!2095 = !{!1958, !440, i64 88}
!2096 = !DILocation(line: 1191, column: 39, scope: !1972, inlinedAt: !1982)
!2097 = !DILocation(line: 1192, column: 5, scope: !1972, inlinedAt: !1982)
!2098 = !DILocation(line: 1194, column: 18, scope: !2099, inlinedAt: !1982)
!2099 = distinct !DILexicalBlock(scope: !1972, file: !3, line: 1194, column: 9)
!2100 = !DILocation(line: 1194, column: 26, scope: !2099, inlinedAt: !1982)
!2101 = !DILocation(line: 1194, column: 9, scope: !1972, inlinedAt: !1982)
!2102 = !DILocation(line: 1195, column: 17, scope: !2103, inlinedAt: !1982)
!2103 = distinct !DILexicalBlock(scope: !2099, file: !3, line: 1194, column: 31)
!2104 = !DILocation(line: 1195, column: 9, scope: !2103, inlinedAt: !1982)
!2105 = !DILocation(line: 1196, column: 5, scope: !2103, inlinedAt: !1982)
!2106 = !DILocation(line: 1224, column: 20, scope: !2107)
!2107 = distinct !DILexicalBlock(scope: !1968, file: !3, line: 1224, column: 20)
!2108 = !DILocation(line: 1224, column: 20, scope: !1968)
!2109 = !DILocation(line: 1227, column: 13, scope: !2110)
!2110 = distinct !DILexicalBlock(scope: !2107, file: !3, line: 1224, column: 30)
!2111 = !DILocation(line: 1228, column: 43, scope: !2110)
!2112 = !DILocation(line: 1229, column: 31, scope: !2113)
!2113 = distinct !DILexicalBlock(scope: !2110, file: !3, line: 1229, column: 17)
!2114 = !DILocation(line: 1229, column: 17, scope: !2110)
!2115 = !DILocation(line: 1233, column: 13, scope: !2116)
!2116 = distinct !DILexicalBlock(scope: !1575, file: !3, line: 1233, column: 13)
!2117 = !DILocation(line: 1233, column: 35, scope: !2116)
!2118 = !DILocation(line: 1233, column: 13, scope: !1575)
!2119 = !DILocation(line: 1235, column: 13, scope: !2120)
!2120 = distinct !DILexicalBlock(scope: !2116, file: !3, line: 1233, column: 41)
!2121 = !DILocation(line: 1236, column: 9, scope: !2120)
!2122 = distinct !{!2122, !1568, !2123, !461}
!2123 = !DILocation(line: 1237, column: 5, scope: !1560)
!2124 = !DILocation(line: 1240, column: 5, scope: !1560)
!2125 = !DILocation(line: 1241, column: 5, scope: !1560)
!2126 = !DISubprogram(name: "strerror", scope: !2127, file: !2127, line: 419, type: !2128, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2127 = !DIFile(filename: "/usr/include/string.h", directory: "", checksumkind: CSK_MD5, checksum: "165db1185644f68894fa9e0d17055d70")
!2128 = !DISubroutineType(types: !2129)
!2129 = !{!127, !102}
!2130 = !DISubprogram(name: "thread_setname", scope: !15, file: !15, line: 1033, type: !2131, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2131 = !DISubroutineType(types: !2132)
!2132 = !{null, !198, !129}
!2133 = distinct !DISubprogram(name: "stop_slab_maintenance_thread", scope: !3, file: !3, line: 1335, type: !898, scopeLine: 1335, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!2134 = !DILocation(line: 1336, column: 5, scope: !2133)
!2135 = !DILocation(line: 1337, column: 34, scope: !2133)
!2136 = !DILocation(line: 1338, column: 5, scope: !2133)
!2137 = !DILocation(line: 1339, column: 5, scope: !2133)
!2138 = !DILocation(line: 1342, column: 18, scope: !2133)
!2139 = !DILocation(line: 1342, column: 5, scope: !2133)
!2140 = !DILocation(line: 1343, column: 1, scope: !2133)
!2141 = !DISubprogram(name: "pthread_cond_signal", scope: !998, file: !998, line: 1121, type: !2142, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2142 = !DISubroutineType(types: !2143)
!2143 = !{!102, !2144}
!2144 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !376, size: 64)
!2145 = !DISubprogram(name: "pthread_join", scope: !998, file: !998, line: 219, type: !2146, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2146 = !DISubroutineType(types: !2147)
!2147 = !{!102, !198, !190}
!2148 = !DISubprogram(name: "fopen", scope: !883, file: !883, line: 264, type: !2149, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2149 = !DISubroutineType(types: !2150)
!2150 = !{!614, !887, !887}
!2151 = !DISubprogram(name: "fgets", scope: !883, file: !883, line: 654, type: !2152, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2152 = !DISubroutineType(types: !2153)
!2153 = !{!127, !2154, !102, !886}
!2154 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !127)
!2155 = !DISubprogram(name: "sscanf", linkageName: "__isoc23_sscanf", scope: !883, file: !883, line: 447, type: !2156, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2156 = !DISubroutineType(types: !2157)
!2157 = !{!102, !887, !887, null}
!2158 = !DISubprogram(name: "fclose", scope: !883, file: !883, line: 184, type: !2159, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2159 = !DISubroutineType(types: !2160)
!2160 = !{!102, !614}
!2161 = !DISubprogram(name: "posix_memalign", scope: !889, file: !889, line: 718, type: !2162, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2162 = !DISubroutineType(types: !2163)
!2163 = !{!102, !190, !131, !131}
!2164 = !DISubprogram(name: "madvise", scope: !2165, file: !2165, line: 94, type: !2166, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2165 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/mman.h", directory: "", checksumkind: CSK_MD5, checksum: "64e45994f192915f7be4ea1b04420e3e")
!2166 = !DISubroutineType(types: !2167)
!2167 = !{!102, !128, !131, !102}
!2168 = !DISubprogram(name: "free", scope: !889, file: !889, line: 687, type: !415, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2169 = distinct !DISubprogram(name: "do_slabs_newslab", scope: !3, file: !3, line: 369, type: !491, scopeLine: 369, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2170)
!2170 = !{!2171, !2172, !2173, !2174, !2175}
!2171 = !DILocalVariable(name: "id", arg: 1, scope: !2169, file: !3, line: 369, type: !493)
!2172 = !DILocalVariable(name: "p", scope: !2169, file: !3, line: 370, type: !480)
!2173 = !DILocalVariable(name: "g", scope: !2169, file: !3, line: 371, type: !480)
!2174 = !DILocalVariable(name: "len", scope: !2169, file: !3, line: 372, type: !102)
!2175 = !DILocalVariable(name: "ptr", scope: !2169, file: !3, line: 375, type: !127)
!2176 = !DILocation(line: 0, scope: !2169)
!2177 = !DILocation(line: 370, column: 23, scope: !2169)
!2178 = !DILocation(line: 372, column: 25, scope: !2169)
!2179 = !DILocation(line: 373, column: 20, scope: !2169)
!2180 = !DILocation(line: 372, column: 39, scope: !2169)
!2181 = !DILocation(line: 372, column: 51, scope: !2169)
!2182 = !DILocation(line: 372, column: 71, scope: !2169)
!2183 = !DILocation(line: 372, column: 15, scope: !2169)
!2184 = !DILocation(line: 374, column: 14, scope: !2169)
!2185 = !DILocation(line: 374, column: 24, scope: !2169)
!2186 = !DILocation(line: 374, column: 19, scope: !2169)
!2187 = !DILocation(line: 377, column: 10, scope: !2188)
!2188 = distinct !DILexicalBlock(scope: !2169, file: !3, line: 377, column: 9)
!2189 = !DILocation(line: 377, column: 20, scope: !2188)
!2190 = !DILocation(line: 377, column: 23, scope: !2188)
!2191 = !DILocation(line: 377, column: 38, scope: !2188)
!2192 = !DILocation(line: 377, column: 36, scope: !2188)
!2193 = !DILocation(line: 377, column: 42, scope: !2188)
!2194 = !DILocation(line: 377, column: 54, scope: !2188)
!2195 = !DILocation(line: 377, column: 60, scope: !2188)
!2196 = !DILocation(line: 377, column: 66, scope: !2188)
!2197 = !DILocation(line: 378, column: 10, scope: !2188)
!2198 = !DILocation(line: 378, column: 16, scope: !2188)
!2199 = !DILocation(line: 378, column: 22, scope: !2188)
!2200 = !DILocation(line: 377, column: 9, scope: !2169)
!2201 = !DILocation(line: 0, scope: !490, inlinedAt: !2202)
!2202 = distinct !DILocation(line: 384, column: 10, scope: !2203)
!2203 = distinct !DILexicalBlock(scope: !2169, file: !3, line: 384, column: 9)
!2204 = !DILocation(line: 339, column: 12, scope: !498, inlinedAt: !2202)
!2205 = !DILocation(line: 339, column: 24, scope: !498, inlinedAt: !2202)
!2206 = !DILocation(line: 339, column: 18, scope: !498, inlinedAt: !2202)
!2207 = !DILocation(line: 339, column: 9, scope: !490, inlinedAt: !2202)
!2208 = !DILocation(line: 340, column: 42, scope: !497, inlinedAt: !2202)
!2209 = !DILocation(line: 340, column: 28, scope: !497, inlinedAt: !2202)
!2210 = !DILocation(line: 0, scope: !497, inlinedAt: !2202)
!2211 = !DILocation(line: 341, column: 37, scope: !497, inlinedAt: !2202)
!2212 = !DILocation(line: 341, column: 57, scope: !497, inlinedAt: !2202)
!2213 = !DILocation(line: 341, column: 26, scope: !497, inlinedAt: !2202)
!2214 = !DILocation(line: 342, column: 22, scope: !517, inlinedAt: !2202)
!2215 = !DILocation(line: 342, column: 13, scope: !497, inlinedAt: !2202)
!2216 = !DILocation(line: 343, column: 22, scope: !497, inlinedAt: !2202)
!2217 = !DILocation(line: 344, column: 22, scope: !497, inlinedAt: !2202)
!2218 = !DILocation(line: 0, scope: !1376, inlinedAt: !2219)
!2219 = distinct !DILocation(line: 385, column: 18, scope: !2203)
!2220 = !DILocation(line: 361, column: 12, scope: !1384, inlinedAt: !2219)
!2221 = !DILocation(line: 361, column: 18, scope: !1384, inlinedAt: !2219)
!2222 = !DILocation(line: 361, column: 9, scope: !1376, inlinedAt: !2219)
!2223 = !DILocation(line: 364, column: 20, scope: !1376, inlinedAt: !2219)
!2224 = !DILocation(line: 364, column: 39, scope: !1376, inlinedAt: !2219)
!2225 = !DILocation(line: 364, column: 17, scope: !1376, inlinedAt: !2219)
!2226 = !DILocation(line: 365, column: 13, scope: !1376, inlinedAt: !2219)
!2227 = !DILocation(line: 385, column: 47, scope: !2203)
!2228 = !DILocation(line: 385, column: 56, scope: !2203)
!2229 = !DILocation(line: 396, column: 20, scope: !2169)
!2230 = !DILocation(line: 386, column: 33, scope: !2203)
!2231 = !DILocation(line: 0, scope: !909, inlinedAt: !2232)
!2232 = distinct !DILocation(line: 386, column: 17, scope: !2203)
!2233 = !DILocation(line: 613, column: 9, scope: !919, inlinedAt: !2232)
!2234 = !DILocation(line: 613, column: 18, scope: !919, inlinedAt: !2232)
!2235 = !DILocation(line: 613, column: 9, scope: !909, inlinedAt: !2232)
!2236 = !DILocation(line: 615, column: 15, scope: !918, inlinedAt: !2232)
!2237 = !DILocation(line: 616, column: 5, scope: !918, inlinedAt: !2232)
!2238 = !DILocation(line: 617, column: 15, scope: !923, inlinedAt: !2232)
!2239 = !DILocation(line: 619, column: 20, scope: !922, inlinedAt: !2232)
!2240 = !DILocation(line: 619, column: 18, scope: !922, inlinedAt: !2232)
!2241 = !DILocation(line: 619, column: 13, scope: !923, inlinedAt: !2232)
!2242 = !DILocation(line: 624, column: 13, scope: !923, inlinedAt: !2232)
!2243 = !DILocation(line: 628, column: 44, scope: !923, inlinedAt: !2232)
!2244 = !DILocation(line: 628, column: 21, scope: !923, inlinedAt: !2232)
!2245 = !DILocation(line: 629, column: 18, scope: !928, inlinedAt: !2232)
!2246 = !DILocation(line: 629, column: 13, scope: !923, inlinedAt: !2232)
!2247 = !DILocation(line: 630, column: 23, scope: !931, inlinedAt: !2232)
!2248 = !DILocation(line: 631, column: 9, scope: !931, inlinedAt: !2232)
!2249 = !DILocation(line: 632, column: 23, scope: !934, inlinedAt: !2232)
!2250 = !DILocation(line: 0, scope: !919, inlinedAt: !2232)
!2251 = !DILocation(line: 635, column: 18, scope: !909, inlinedAt: !2232)
!2252 = !DILocation(line: 386, column: 47, scope: !2203)
!2253 = !DILocation(line: 384, column: 9, scope: !2169)
!2254 = !DILocation(line: 0, scope: !2203)
!2255 = !DILocation(line: 396, column: 5, scope: !2169)
!2256 = !DILocation(line: 0, scope: !2019, inlinedAt: !2257)
!2257 = distinct !DILocation(line: 397, column: 5, scope: !2169)
!2258 = !DILocation(line: 352, column: 24, scope: !2030, inlinedAt: !2257)
!2259 = !DILocation(line: 352, column: 19, scope: !2030, inlinedAt: !2257)
!2260 = !DILocation(line: 352, column: 5, scope: !2031, inlinedAt: !2257)
!2261 = !DILocation(line: 353, column: 9, scope: !2036, inlinedAt: !2257)
!2262 = !DILocation(line: 354, column: 19, scope: !2036, inlinedAt: !2257)
!2263 = !DILocation(line: 354, column: 13, scope: !2036, inlinedAt: !2257)
!2264 = !DILocation(line: 352, column: 34, scope: !2030, inlinedAt: !2257)
!2265 = distinct !{!2265, !2260, !2266, !461}
!2266 = !DILocation(line: 355, column: 5, scope: !2031, inlinedAt: !2257)
!2267 = !DILocation(line: 399, column: 8, scope: !2169)
!2268 = !DILocation(line: 399, column: 26, scope: !2169)
!2269 = !DILocation(line: 399, column: 5, scope: !2169)
!2270 = !DILocation(line: 399, column: 30, scope: !2169)
!2271 = !DILocation(line: 402, column: 5, scope: !2169)
!2272 = !DILocation(line: 403, column: 1, scope: !2169)
!2273 = !DISubprogram(name: "exit", scope: !889, file: !889, line: 756, type: !2274, flags: DIFlagPrototyped | DIFlagNoReturn, spFlags: DISPFlagOptimized)
!2274 = !DISubroutineType(types: !2275)
!2275 = !{null, !102}
!2276 = !DISubprogram(name: "realloc", scope: !889, file: !889, line: 683, type: !2277, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2277 = !DISubroutineType(types: !2278)
!2278 = !{!128, !128, !131}
!2279 = !DISubprogram(name: "malloc", scope: !889, file: !889, line: 672, type: !910, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2280 = !DISubprogram(name: "threadlocal_stats_aggregate", scope: !15, file: !15, line: 1031, type: !2281, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2281 = !DISubroutineType(types: !2282)
!2282 = !{null, !2283}
!2283 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1233, size: 64)
!2284 = !DISubprogram(name: "snprintf", scope: !883, file: !883, line: 385, type: !2285, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2285 = !DISubroutineType(types: !2286)
!2286 = !{!102, !2154, !131, !887, null}
!2287 = !DISubprogram(name: "append_stat", scope: !15, file: !15, line: 1037, type: !2288, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2288 = !DISubroutineType(types: !2289)
!2289 = !{null, !129, !1200, !2290, !129, null}
!2290 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2291, size: 64)
!2291 = !DIDerivedType(tag: DW_TAG_typedef, name: "conn", file: !15, line: 813, baseType: !2292)
!2292 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "conn", file: !15, line: 829, size: 3968, elements: !2293)
!2293 = !{!2294, !2298, !2299, !2300, !2301, !2302, !2303, !2304, !2305, !2306, !2307, !2308, !2309, !2391, !2392, !2393, !2394, !2395, !2396, !2397, !2639, !2640, !2641, !2642, !2643, !2644, !2645, !2647, !2648, !2649, !2650, !2651, !2652, !2653, !2654, !2655, !2661, !2682, !2683, !2684, !2685, !2686, !2687, !2688, !2689, !2693, !2700, !2715}
!2294 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_conn", scope: !2292, file: !15, line: 830, baseType: !2295, size: 64)
!2295 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2296, size: 64)
!2296 = !DIDerivedType(tag: DW_TAG_typedef, name: "sasl_conn_t", file: !2297, line: 16, baseType: !128)
!2297 = !DIFile(filename: "./sasl_defs.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "3a8678a43d09d8e311388b26eedc7a3e")
!2298 = !DIDerivedType(tag: DW_TAG_member, name: "sfd", scope: !2292, file: !15, line: 831, baseType: !102, size: 32, offset: 64)
!2299 = !DIDerivedType(tag: DW_TAG_member, name: "sasl_started", scope: !2292, file: !15, line: 832, baseType: !246, size: 8, offset: 96)
!2300 = !DIDerivedType(tag: DW_TAG_member, name: "authenticated", scope: !2292, file: !15, line: 833, baseType: !246, size: 8, offset: 104)
!2301 = !DIDerivedType(tag: DW_TAG_member, name: "set_stale", scope: !2292, file: !15, line: 834, baseType: !246, size: 8, offset: 112)
!2302 = !DIDerivedType(tag: DW_TAG_member, name: "mset_res", scope: !2292, file: !15, line: 835, baseType: !246, size: 8, offset: 120)
!2303 = !DIDerivedType(tag: DW_TAG_member, name: "close_after_write", scope: !2292, file: !15, line: 836, baseType: !246, size: 8, offset: 128)
!2304 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_malloced", scope: !2292, file: !15, line: 837, baseType: !246, size: 8, offset: 136)
!2305 = !DIDerivedType(tag: DW_TAG_member, name: "item_malloced", scope: !2292, file: !15, line: 838, baseType: !246, size: 8, offset: 144)
!2306 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !2292, file: !15, line: 844, baseType: !14, size: 32, offset: 160)
!2307 = !DIDerivedType(tag: DW_TAG_member, name: "substate", scope: !2292, file: !15, line: 845, baseType: !33, size: 32, offset: 192)
!2308 = !DIDerivedType(tag: DW_TAG_member, name: "last_cmd_time", scope: !2292, file: !15, line: 846, baseType: !99, size: 32, offset: 224)
!2309 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !2292, file: !15, line: 847, baseType: !2310, size: 1024, offset: 256)
!2310 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event", file: !2311, line: 123, size: 1024, elements: !2312)
!2311 = !DIFile(filename: "/usr/include/event2/event_struct.h", directory: "", checksumkind: CSK_MD5, checksum: "005d89b34bed2ed9e30b0cc3160619c1")
!2312 = !{!2313, !2344, !2354, !2355, !2358, !2388, !2389, !2390}
!2313 = !DIDerivedType(tag: DW_TAG_member, name: "ev_evcallback", scope: !2310, file: !2311, line: 124, baseType: !2314, size: 320)
!2314 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event_callback", file: !2311, line: 107, size: 320, elements: !2315)
!2315 = !{!2316, !2323, !2324, !2325, !2326, !2343}
!2316 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_active_next", scope: !2314, file: !2311, line: 108, baseType: !2317, size: 128)
!2317 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2314, file: !2311, line: 108, size: 128, elements: !2318)
!2318 = !{!2319, !2321}
!2319 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !2317, file: !2311, line: 108, baseType: !2320, size: 64)
!2320 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2314, size: 64)
!2321 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !2317, file: !2311, line: 108, baseType: !2322, size: 64, offset: 64)
!2322 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2320, size: 64)
!2323 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_flags", scope: !2314, file: !2311, line: 109, baseType: !267, size: 16, offset: 128)
!2324 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_pri", scope: !2314, file: !2311, line: 110, baseType: !111, size: 8, offset: 144)
!2325 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_closure", scope: !2314, file: !2311, line: 111, baseType: !111, size: 8, offset: 152)
!2326 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cb_union", scope: !2314, file: !2311, line: 118, baseType: !2327, size: 64, offset: 192)
!2327 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !2314, file: !2311, line: 113, size: 64, elements: !2328)
!2328 = !{!2329, !2333, !2337, !2342}
!2329 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_callback", scope: !2327, file: !2311, line: 114, baseType: !2330, size: 64)
!2330 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2331, size: 64)
!2331 = !DISubroutineType(types: !2332)
!2332 = !{null, !102, !267, !128}
!2333 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_selfcb", scope: !2327, file: !2311, line: 115, baseType: !2334, size: 64)
!2334 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2335, size: 64)
!2335 = !DISubroutineType(types: !2336)
!2336 = !{null, !2320, !128}
!2337 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_evfinalize", scope: !2327, file: !2311, line: 116, baseType: !2338, size: 64)
!2338 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2339, size: 64)
!2339 = !DISubroutineType(types: !2340)
!2340 = !{null, !2341, !128}
!2341 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2310, size: 64)
!2342 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_cbfinalize", scope: !2327, file: !2311, line: 117, baseType: !2334, size: 64)
!2343 = !DIDerivedType(tag: DW_TAG_member, name: "evcb_arg", scope: !2314, file: !2311, line: 119, baseType: !128, size: 64, offset: 256)
!2344 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout_pos", scope: !2310, file: !2311, line: 130, baseType: !2345, size: 128, offset: 320)
!2345 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !2310, file: !2311, line: 127, size: 128, elements: !2346)
!2346 = !{!2347, !2353}
!2347 = !DIDerivedType(tag: DW_TAG_member, name: "ev_next_with_common_timeout", scope: !2345, file: !2311, line: 128, baseType: !2348, size: 128)
!2348 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2345, file: !2311, line: 128, size: 128, elements: !2349)
!2349 = !{!2350, !2351}
!2350 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_next", scope: !2348, file: !2311, line: 128, baseType: !2341, size: 64)
!2351 = !DIDerivedType(tag: DW_TAG_member, name: "tqe_prev", scope: !2348, file: !2311, line: 128, baseType: !2352, size: 64, offset: 64)
!2352 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2341, size: 64)
!2353 = !DIDerivedType(tag: DW_TAG_member, name: "min_heap_idx", scope: !2345, file: !2311, line: 129, baseType: !102, size: 32)
!2354 = !DIDerivedType(tag: DW_TAG_member, name: "ev_fd", scope: !2310, file: !2311, line: 131, baseType: !102, size: 32, offset: 448)
!2355 = !DIDerivedType(tag: DW_TAG_member, name: "ev_base", scope: !2310, file: !2311, line: 133, baseType: !2356, size: 64, offset: 512)
!2356 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2357, size: 64)
!2357 = !DICompositeType(tag: DW_TAG_structure_type, name: "event_base", file: !2311, line: 122, flags: DIFlagFwdDecl)
!2358 = !DIDerivedType(tag: DW_TAG_member, name: "ev_", scope: !2310, file: !2311, line: 149, baseType: !2359, size: 256, offset: 576)
!2359 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !2310, file: !2311, line: 135, size: 256, elements: !2360)
!2360 = !{!2361, !2377}
!2361 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io", scope: !2359, file: !2311, line: 140, baseType: !2362, size: 256)
!2362 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2359, file: !2311, line: 137, size: 256, elements: !2363)
!2363 = !{!2364, !2369}
!2364 = !DIDerivedType(tag: DW_TAG_member, name: "ev_io_next", scope: !2362, file: !2311, line: 138, baseType: !2365, size: 128)
!2365 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2362, file: !2311, line: 138, size: 128, elements: !2366)
!2366 = !{!2367, !2368}
!2367 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !2365, file: !2311, line: 138, baseType: !2341, size: 64)
!2368 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !2365, file: !2311, line: 138, baseType: !2352, size: 64, offset: 64)
!2369 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !2362, file: !2311, line: 139, baseType: !2370, size: 128, offset: 128)
!2370 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "timeval", file: !2371, line: 8, size: 128, elements: !2372)
!2371 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h", directory: "", checksumkind: CSK_MD5, checksum: "9b45d950050c215f216850b27bd1e8f3")
!2372 = !{!2373, !2375}
!2373 = !DIDerivedType(tag: DW_TAG_member, name: "tv_sec", scope: !2370, file: !2371, line: 14, baseType: !2374, size: 64)
!2374 = !DIDerivedType(tag: DW_TAG_typedef, name: "__time_t", file: !109, line: 160, baseType: !279)
!2375 = !DIDerivedType(tag: DW_TAG_member, name: "tv_usec", scope: !2370, file: !2371, line: 15, baseType: !2376, size: 64, offset: 64)
!2376 = !DIDerivedType(tag: DW_TAG_typedef, name: "__suseconds_t", file: !109, line: 162, baseType: !279)
!2377 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal", scope: !2359, file: !2311, line: 148, baseType: !2378, size: 256)
!2378 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2359, file: !2311, line: 143, size: 256, elements: !2379)
!2379 = !{!2380, !2385, !2386}
!2380 = !DIDerivedType(tag: DW_TAG_member, name: "ev_signal_next", scope: !2378, file: !2311, line: 144, baseType: !2381, size: 128)
!2381 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2378, file: !2311, line: 144, size: 128, elements: !2382)
!2382 = !{!2383, !2384}
!2383 = !DIDerivedType(tag: DW_TAG_member, name: "le_next", scope: !2381, file: !2311, line: 144, baseType: !2341, size: 64)
!2384 = !DIDerivedType(tag: DW_TAG_member, name: "le_prev", scope: !2381, file: !2311, line: 144, baseType: !2352, size: 64, offset: 64)
!2385 = !DIDerivedType(tag: DW_TAG_member, name: "ev_ncalls", scope: !2378, file: !2311, line: 145, baseType: !267, size: 16, offset: 128)
!2386 = !DIDerivedType(tag: DW_TAG_member, name: "ev_pncalls", scope: !2378, file: !2311, line: 147, baseType: !2387, size: 64, offset: 192)
!2387 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !267, size: 64)
!2388 = !DIDerivedType(tag: DW_TAG_member, name: "ev_events", scope: !2310, file: !2311, line: 151, baseType: !267, size: 16, offset: 832)
!2389 = !DIDerivedType(tag: DW_TAG_member, name: "ev_res", scope: !2310, file: !2311, line: 152, baseType: !267, size: 16, offset: 848)
!2390 = !DIDerivedType(tag: DW_TAG_member, name: "ev_timeout", scope: !2310, file: !2311, line: 153, baseType: !2370, size: 128, offset: 896)
!2391 = !DIDerivedType(tag: DW_TAG_member, name: "ev_flags", scope: !2292, file: !15, line: 848, baseType: !267, size: 16, offset: 1280)
!2392 = !DIDerivedType(tag: DW_TAG_member, name: "which", scope: !2292, file: !15, line: 849, baseType: !267, size: 16, offset: 1296)
!2393 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf", scope: !2292, file: !15, line: 851, baseType: !127, size: 64, offset: 1344)
!2394 = !DIDerivedType(tag: DW_TAG_member, name: "rcurr", scope: !2292, file: !15, line: 852, baseType: !127, size: 64, offset: 1408)
!2395 = !DIDerivedType(tag: DW_TAG_member, name: "rsize", scope: !2292, file: !15, line: 853, baseType: !102, size: 32, offset: 1472)
!2396 = !DIDerivedType(tag: DW_TAG_member, name: "rbytes", scope: !2292, file: !15, line: 854, baseType: !102, size: 32, offset: 1504)
!2397 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !2292, file: !15, line: 856, baseType: !2398, size: 64, offset: 1536)
!2398 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2399, size: 64)
!2399 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp", file: !15, line: 801, baseType: !2400)
!2400 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp", file: !15, line: 771, size: 9472, elements: !2401)
!2401 = !{!2402, !2584, !2586, !2587, !2588, !2589, !2590, !2591, !2600, !2601, !2602, !2603, !2604, !2605, !2606, !2607, !2608, !2631, !2635}
!2402 = !DIDerivedType(tag: DW_TAG_member, name: "bundle", scope: !2400, file: !15, line: 772, baseType: !2403, size: 64)
!2403 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2404, size: 64)
!2404 = !DIDerivedType(tag: DW_TAG_typedef, name: "mc_resp_bundle", file: !15, line: 720, baseType: !2405)
!2405 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_mc_resp_bundle", file: !15, line: 804, size: 256, elements: !2406)
!2406 = !{!2407, !2408, !2409, !2579, !2581, !2582}
!2407 = !DIDerivedType(tag: DW_TAG_member, name: "refcount", scope: !2405, file: !15, line: 805, baseType: !111, size: 8)
!2408 = !DIDerivedType(tag: DW_TAG_member, name: "next_check", scope: !2405, file: !15, line: 806, baseType: !111, size: 8, offset: 8)
!2409 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !2405, file: !15, line: 807, baseType: !2410, size: 64, offset: 64)
!2410 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2411, size: 64)
!2411 = !DIDerivedType(tag: DW_TAG_typedef, name: "LIBEVENT_THREAD", file: !15, line: 765, baseType: !2412)
!2412 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !15, line: 721, size: 55488, elements: !2413)
!2413 = !{!2414, !2415, !2416, !2421, !2422, !2423, !2453, !2454, !2455, !2456, !2476, !2479, !2505, !2506, !2507, !2508, !2577, !2578}
!2414 = !DIDerivedType(tag: DW_TAG_member, name: "thread_id", scope: !2412, file: !15, line: 722, baseType: !198, size: 64)
!2415 = !DIDerivedType(tag: DW_TAG_member, name: "base", scope: !2412, file: !15, line: 723, baseType: !2356, size: 64, offset: 64)
!2416 = !DIDerivedType(tag: DW_TAG_member, name: "n", scope: !2412, file: !15, line: 724, baseType: !2417, size: 1088, offset: 128)
!2417 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "thread_notify", file: !15, line: 710, size: 1088, elements: !2418)
!2418 = !{!2419, !2420}
!2419 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event", scope: !2417, file: !15, line: 711, baseType: !2310, size: 1024)
!2420 = !DIDerivedType(tag: DW_TAG_member, name: "notify_event_fd", scope: !2417, file: !15, line: 713, baseType: !102, size: 32, offset: 1024)
!2421 = !DIDerivedType(tag: DW_TAG_member, name: "ion", scope: !2412, file: !15, line: 725, baseType: !2417, size: 1088, offset: 1216)
!2422 = !DIDerivedType(tag: DW_TAG_member, name: "ion_lock", scope: !2412, file: !15, line: 726, baseType: !254, size: 320, offset: 2304)
!2423 = !DIDerivedType(tag: DW_TAG_member, name: "ion_head", scope: !2412, file: !15, line: 727, baseType: !2424, size: 128, offset: 2624)
!2424 = !DIDerivedType(tag: DW_TAG_typedef, name: "iop_head_t", file: !15, line: 686, baseType: !2425)
!2425 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iop_head_s", file: !15, line: 686, size: 128, elements: !2426)
!2426 = !{!2427, !2451}
!2427 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !2425, file: !15, line: 686, baseType: !2428, size: 64)
!2428 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2429, size: 64)
!2429 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_io_pending_t", file: !15, line: 815, size: 1408, elements: !2430)
!2430 = !{!2431, !2432, !2433, !2434, !2435, !2442, !2443, !2447}
!2431 = !DIDerivedType(tag: DW_TAG_member, name: "io_queue_type", scope: !2429, file: !15, line: 816, baseType: !102, size: 32)
!2432 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !2429, file: !15, line: 817, baseType: !2410, size: 64, offset: 64)
!2433 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !2429, file: !15, line: 818, baseType: !2290, size: 64, offset: 128)
!2434 = !DIDerivedType(tag: DW_TAG_member, name: "resp", scope: !2429, file: !15, line: 819, baseType: !2398, size: 64, offset: 192)
!2435 = !DIDerivedType(tag: DW_TAG_member, name: "return_cb", scope: !2429, file: !15, line: 820, baseType: !2436, size: 64, offset: 256)
!2436 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb", file: !15, line: 690, baseType: !2437)
!2437 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2438, size: 64)
!2438 = !DISubroutineType(types: !2439)
!2439 = !{null, !2440}
!2440 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2441, size: 64)
!2441 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_pending_t", file: !15, line: 687, baseType: !2429)
!2442 = !DIDerivedType(tag: DW_TAG_member, name: "finalize_cb", scope: !2429, file: !15, line: 821, baseType: !2436, size: 64, offset: 320)
!2443 = !DIDerivedType(tag: DW_TAG_member, name: "iop_next", scope: !2429, file: !15, line: 822, baseType: !2444, size: 64, offset: 384)
!2444 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2429, file: !15, line: 822, size: 64, elements: !2445)
!2445 = !{!2446}
!2446 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !2444, file: !15, line: 822, baseType: !2428, size: 64)
!2447 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !2429, file: !15, line: 823, baseType: !2448, size: 960, offset: 448)
!2448 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 960, elements: !2449)
!2449 = !{!2450}
!2450 = !DISubrange(count: 120)
!2451 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !2425, file: !15, line: 686, baseType: !2452, size: 64, offset: 64)
!2452 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2428, size: 64)
!2453 = !DIDerivedType(tag: DW_TAG_member, name: "cur_sfd", scope: !2412, file: !15, line: 728, baseType: !102, size: 32, offset: 2752)
!2454 = !DIDerivedType(tag: DW_TAG_member, name: "thread_baseid", scope: !2412, file: !15, line: 729, baseType: !102, size: 32, offset: 2784)
!2455 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !2412, file: !15, line: 730, baseType: !1233, size: 51584, offset: 2816)
!2456 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !2412, file: !15, line: 731, baseType: !2457, size: 576, offset: 54400)
!2457 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2458, size: 576, elements: !293)
!2458 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_cb_t", file: !15, line: 708, baseType: !2459)
!2459 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_cb_s", file: !15, line: 704, size: 192, elements: !2460)
!2460 = !{!2461, !2462, !2475}
!2461 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !2459, file: !15, line: 705, baseType: !128, size: 64)
!2462 = !DIDerivedType(tag: DW_TAG_member, name: "submit_cb", scope: !2459, file: !15, line: 706, baseType: !2463, size: 64, offset: 64)
!2463 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_stack_cb", file: !15, line: 689, baseType: !2464)
!2464 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2465, size: 64)
!2465 = !DISubroutineType(types: !2466)
!2466 = !{null, !2467}
!2467 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2468, size: 64)
!2468 = !DIDerivedType(tag: DW_TAG_typedef, name: "io_queue_t", file: !15, line: 688, baseType: !2469)
!2469 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "io_queue_s", file: !15, line: 697, size: 192, elements: !2470)
!2470 = !{!2471, !2472, !2473, !2474}
!2471 = !DIDerivedType(tag: DW_TAG_member, name: "ctx", scope: !2469, file: !15, line: 698, baseType: !128, size: 64)
!2472 = !DIDerivedType(tag: DW_TAG_member, name: "stack_ctx", scope: !2469, file: !15, line: 699, baseType: !128, size: 64, offset: 64)
!2473 = !DIDerivedType(tag: DW_TAG_member, name: "count", scope: !2469, file: !15, line: 700, baseType: !102, size: 32, offset: 128)
!2474 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !2469, file: !15, line: 701, baseType: !102, size: 32, offset: 160)
!2475 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !2459, file: !15, line: 707, baseType: !102, size: 32, offset: 128)
!2476 = !DIDerivedType(tag: DW_TAG_member, name: "ev_queue", scope: !2412, file: !15, line: 732, baseType: !2477, size: 64, offset: 54976)
!2477 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2478, size: 64)
!2478 = !DICompositeType(tag: DW_TAG_structure_type, name: "conn_queue", file: !15, line: 732, flags: DIFlagFwdDecl)
!2479 = !DIDerivedType(tag: DW_TAG_member, name: "rbuf_cache", scope: !2412, file: !15, line: 733, baseType: !2480, size: 64, offset: 55040)
!2480 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2481, size: 64)
!2481 = !DIDerivedType(tag: DW_TAG_typedef, name: "cache_t", file: !2482, line: 39, baseType: !2483)
!2482 = !DIFile(filename: "./cache.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d97639c8540587a19d8550d7d7156448")
!2483 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !2482, line: 22, size: 704, elements: !2484)
!2484 = !{!2485, !2486, !2487, !2500, !2501, !2502, !2503, !2504}
!2485 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !2483, file: !2482, line: 24, baseType: !254, size: 320)
!2486 = !DIDerivedType(tag: DW_TAG_member, name: "name", scope: !2483, file: !2482, line: 26, baseType: !127, size: 64, offset: 320)
!2487 = !DIDerivedType(tag: DW_TAG_member, name: "head", scope: !2483, file: !2482, line: 28, baseType: !2488, size: 128, offset: 384)
!2488 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_head", file: !2482, line: 28, size: 128, elements: !2489)
!2489 = !{!2490, !2498}
!2490 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_first", scope: !2488, file: !2482, line: 28, baseType: !2491, size: 64)
!2491 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2492, size: 64)
!2492 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "cache_free_s", file: !2482, line: 12, size: 64, elements: !2493)
!2493 = !{!2494}
!2494 = !DIDerivedType(tag: DW_TAG_member, name: "c_next", scope: !2492, file: !2482, line: 13, baseType: !2495, size: 64)
!2495 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2492, file: !2482, line: 13, size: 64, elements: !2496)
!2496 = !{!2497}
!2497 = !DIDerivedType(tag: DW_TAG_member, name: "stqe_next", scope: !2495, file: !2482, line: 13, baseType: !2491, size: 64)
!2498 = !DIDerivedType(tag: DW_TAG_member, name: "stqh_last", scope: !2488, file: !2482, line: 28, baseType: !2499, size: 64, offset: 64)
!2499 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2491, size: 64)
!2500 = !DIDerivedType(tag: DW_TAG_member, name: "bufsize", scope: !2483, file: !2482, line: 30, baseType: !131, size: 64, offset: 512)
!2501 = !DIDerivedType(tag: DW_TAG_member, name: "freetotal", scope: !2483, file: !2482, line: 32, baseType: !102, size: 32, offset: 576)
!2502 = !DIDerivedType(tag: DW_TAG_member, name: "total", scope: !2483, file: !2482, line: 34, baseType: !102, size: 32, offset: 608)
!2503 = !DIDerivedType(tag: DW_TAG_member, name: "freecurr", scope: !2483, file: !2482, line: 36, baseType: !102, size: 32, offset: 640)
!2504 = !DIDerivedType(tag: DW_TAG_member, name: "limit", scope: !2483, file: !2482, line: 38, baseType: !102, size: 32, offset: 672)
!2505 = !DIDerivedType(tag: DW_TAG_member, name: "open_bundle", scope: !2412, file: !15, line: 734, baseType: !2403, size: 64, offset: 55104)
!2506 = !DIDerivedType(tag: DW_TAG_member, name: "io_cache", scope: !2412, file: !15, line: 735, baseType: !2480, size: 64, offset: 55168)
!2507 = !DIDerivedType(tag: DW_TAG_member, name: "storage", scope: !2412, file: !15, line: 737, baseType: !128, size: 64, offset: 55232)
!2508 = !DIDerivedType(tag: DW_TAG_member, name: "l", scope: !2412, file: !15, line: 739, baseType: !2509, size: 64, offset: 55296)
!2509 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2510, size: 64)
!2510 = !DIDerivedType(tag: DW_TAG_typedef, name: "logger", file: !48, line: 193, baseType: !2511)
!2511 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logger", file: !48, line: 181, size: 832, elements: !2512)
!2512 = !{!2513, !2515, !2516, !2517, !2518, !2519, !2520, !2521, !2522, !2523, !2536}
!2513 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !2511, file: !48, line: 182, baseType: !2514, size: 64)
!2514 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2511, size: 64)
!2515 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !2511, file: !48, line: 183, baseType: !2514, size: 64, offset: 64)
!2516 = !DIDerivedType(tag: DW_TAG_member, name: "mutex", scope: !2511, file: !48, line: 184, baseType: !254, size: 320, offset: 128)
!2517 = !DIDerivedType(tag: DW_TAG_member, name: "written", scope: !2511, file: !48, line: 185, baseType: !120, size: 64, offset: 448)
!2518 = !DIDerivedType(tag: DW_TAG_member, name: "dropped", scope: !2511, file: !48, line: 186, baseType: !120, size: 64, offset: 512)
!2519 = !DIDerivedType(tag: DW_TAG_member, name: "blocked", scope: !2511, file: !48, line: 187, baseType: !120, size: 64, offset: 576)
!2520 = !DIDerivedType(tag: DW_TAG_member, name: "fetcher_ratio", scope: !2511, file: !48, line: 188, baseType: !106, size: 16, offset: 640)
!2521 = !DIDerivedType(tag: DW_TAG_member, name: "mutation_ratio", scope: !2511, file: !48, line: 189, baseType: !106, size: 16, offset: 656)
!2522 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !2511, file: !48, line: 190, baseType: !106, size: 16, offset: 672)
!2523 = !DIDerivedType(tag: DW_TAG_member, name: "buf", scope: !2511, file: !48, line: 191, baseType: !2524, size: 64, offset: 704)
!2524 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2525, size: 64)
!2525 = !DIDerivedType(tag: DW_TAG_typedef, name: "bipbuf_t", file: !2526, line: 18, baseType: !2527)
!2526 = !DIFile(filename: "./bipbuffer.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "99606bcb8393045e6bc9eef40115066f")
!2527 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !2526, line: 4, size: 192, elements: !2528)
!2528 = !{!2529, !2530, !2531, !2532, !2533, !2534}
!2529 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !2527, file: !2526, line: 6, baseType: !122, size: 64)
!2530 = !DIDerivedType(tag: DW_TAG_member, name: "a_start", scope: !2527, file: !2526, line: 9, baseType: !7, size: 32, offset: 64)
!2531 = !DIDerivedType(tag: DW_TAG_member, name: "a_end", scope: !2527, file: !2526, line: 9, baseType: !7, size: 32, offset: 96)
!2532 = !DIDerivedType(tag: DW_TAG_member, name: "b_end", scope: !2527, file: !2526, line: 12, baseType: !7, size: 32, offset: 128)
!2533 = !DIDerivedType(tag: DW_TAG_member, name: "b_inuse", scope: !2527, file: !2526, line: 15, baseType: !102, size: 32, offset: 160)
!2534 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !2527, file: !2526, line: 17, baseType: !2535, offset: 192)
!2535 = !DICompositeType(tag: DW_TAG_array_type, baseType: !113, elements: !125)
!2536 = !DIDerivedType(tag: DW_TAG_member, name: "entry_map", scope: !2511, file: !48, line: 192, baseType: !2537, size: 64, offset: 768)
!2537 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2538, size: 64)
!2538 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !2539)
!2539 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_details", file: !48, line: 58, baseType: !2540)
!2540 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_entry_details", file: !48, line: 63, size: 256, elements: !2541)
!2541 = !{!2542, !2543, !2544, !2571, !2576}
!2542 = !DIDerivedType(tag: DW_TAG_member, name: "reqlen", scope: !2540, file: !48, line: 64, baseType: !102, size: 32)
!2543 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !2540, file: !48, line: 65, baseType: !106, size: 16, offset: 32)
!2544 = !DIDerivedType(tag: DW_TAG_member, name: "log_cb", scope: !2540, file: !48, line: 66, baseType: !2545, size: 64, offset: 64)
!2545 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_log_cb", file: !48, line: 60, baseType: !2546)
!2546 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2547, size: 64)
!2547 = !DISubroutineType(types: !2548)
!2548 = !{null, !2549, !2537, !1205, !2564}
!2549 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2550, size: 64)
!2550 = !DIDerivedType(tag: DW_TAG_typedef, name: "logentry", file: !48, line: 57, baseType: !2551)
!2551 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_logentry", file: !48, line: 156, size: 320, elements: !2552)
!2552 = !{!2553, !2554, !2555, !2556, !2557, !2558, !2559}
!2553 = !DIDerivedType(tag: DW_TAG_member, name: "event", scope: !2551, file: !48, line: 157, baseType: !47, size: 32)
!2554 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !2551, file: !48, line: 158, baseType: !111, size: 8, offset: 32)
!2555 = !DIDerivedType(tag: DW_TAG_member, name: "eflags", scope: !2551, file: !48, line: 159, baseType: !106, size: 16, offset: 48)
!2556 = !DIDerivedType(tag: DW_TAG_member, name: "gid", scope: !2551, file: !48, line: 160, baseType: !120, size: 64, offset: 64)
!2557 = !DIDerivedType(tag: DW_TAG_member, name: "tv", scope: !2551, file: !48, line: 161, baseType: !2370, size: 128, offset: 128)
!2558 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !2551, file: !48, line: 162, baseType: !102, size: 32, offset: 256)
!2559 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !2551, file: !48, line: 165, baseType: !2560, offset: 288)
!2560 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2561, elements: !125)
!2561 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !2551, file: !48, line: 163, size: 8, elements: !2562)
!2562 = !{!2563}
!2563 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !2561, file: !48, line: 164, baseType: !124, size: 8)
!2564 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2565, size: 64)
!2565 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !2566)
!2566 = !{!2567, !2568, !2569, !2570}
!2567 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !2565, file: !3, line: 605, baseType: !7, size: 32)
!2568 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !2565, file: !3, line: 605, baseType: !7, size: 32, offset: 32)
!2569 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !2565, file: !3, line: 605, baseType: !128, size: 64, offset: 64)
!2570 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !2565, file: !3, line: 605, baseType: !128, size: 64, offset: 128)
!2571 = !DIDerivedType(tag: DW_TAG_member, name: "parse_cb", scope: !2540, file: !48, line: 67, baseType: !2572, size: 64, offset: 128)
!2572 = !DIDerivedType(tag: DW_TAG_typedef, name: "entry_parse_cb", file: !48, line: 61, baseType: !2573)
!2573 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2574, size: 64)
!2574 = !DISubroutineType(types: !2575)
!2575 = !{!102, !2549, !127}
!2576 = !DIDerivedType(tag: DW_TAG_member, name: "format", scope: !2540, file: !48, line: 68, baseType: !127, size: 64, offset: 192)
!2577 = !DIDerivedType(tag: DW_TAG_member, name: "lru_bump_buf", scope: !2412, file: !15, line: 740, baseType: !128, size: 64, offset: 55360)
!2578 = !DIDerivedType(tag: DW_TAG_member, name: "napi_id", scope: !2412, file: !15, line: 744, baseType: !102, size: 32, offset: 55424)
!2579 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !2405, file: !15, line: 808, baseType: !2580, size: 64, offset: 128)
!2580 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2405, size: 64)
!2581 = !DIDerivedType(tag: DW_TAG_member, name: "prev", scope: !2405, file: !15, line: 809, baseType: !2580, size: 64, offset: 192)
!2582 = !DIDerivedType(tag: DW_TAG_member, name: "r", scope: !2405, file: !15, line: 810, baseType: !2583, offset: 256)
!2583 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2399, elements: !125)
!2584 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !2400, file: !15, line: 773, baseType: !2585, size: 64, offset: 64)
!2585 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2400, size: 64)
!2586 = !DIDerivedType(tag: DW_TAG_member, name: "wbytes", scope: !2400, file: !15, line: 774, baseType: !102, size: 32, offset: 128)
!2587 = !DIDerivedType(tag: DW_TAG_member, name: "tosend", scope: !2400, file: !15, line: 775, baseType: !102, size: 32, offset: 160)
!2588 = !DIDerivedType(tag: DW_TAG_member, name: "write_and_free", scope: !2400, file: !15, line: 776, baseType: !128, size: 64, offset: 192)
!2589 = !DIDerivedType(tag: DW_TAG_member, name: "io_pending", scope: !2400, file: !15, line: 777, baseType: !2440, size: 64, offset: 256)
!2590 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !2400, file: !15, line: 779, baseType: !90, size: 64, offset: 320)
!2591 = !DIDerivedType(tag: DW_TAG_member, name: "iov", scope: !2400, file: !15, line: 780, baseType: !2592, size: 512, offset: 384)
!2592 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2593, size: 512, elements: !2598)
!2593 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "iovec", file: !2594, line: 26, size: 128, elements: !2595)
!2594 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_iovec.h", directory: "", checksumkind: CSK_MD5, checksum: "a53f2c2488bb0e21e47850624c16538a")
!2595 = !{!2596, !2597}
!2596 = !DIDerivedType(tag: DW_TAG_member, name: "iov_base", scope: !2593, file: !2594, line: 28, baseType: !128, size: 64)
!2597 = !DIDerivedType(tag: DW_TAG_member, name: "iov_len", scope: !2593, file: !2594, line: 29, baseType: !131, size: 64, offset: 64)
!2598 = !{!2599}
!2599 = !DISubrange(count: 4)
!2600 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_total", scope: !2400, file: !15, line: 781, baseType: !102, size: 32, offset: 896)
!2601 = !DIDerivedType(tag: DW_TAG_member, name: "iovcnt", scope: !2400, file: !15, line: 782, baseType: !111, size: 8, offset: 928)
!2602 = !DIDerivedType(tag: DW_TAG_member, name: "chunked_data_iov", scope: !2400, file: !15, line: 783, baseType: !111, size: 8, offset: 936)
!2603 = !DIDerivedType(tag: DW_TAG_member, name: "skip", scope: !2400, file: !15, line: 788, baseType: !246, size: 8, offset: 944)
!2604 = !DIDerivedType(tag: DW_TAG_member, name: "free", scope: !2400, file: !15, line: 789, baseType: !246, size: 8, offset: 952)
!2605 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !2400, file: !15, line: 794, baseType: !106, size: 16, offset: 960)
!2606 = !DIDerivedType(tag: DW_TAG_member, name: "udp_sequence", scope: !2400, file: !15, line: 795, baseType: !106, size: 16, offset: 976)
!2607 = !DIDerivedType(tag: DW_TAG_member, name: "udp_total", scope: !2400, file: !15, line: 796, baseType: !106, size: 16, offset: 992)
!2608 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !2400, file: !15, line: 797, baseType: !2609, size: 224, offset: 1024)
!2609 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "sockaddr_in6", file: !2610, line: 262, size: 224, elements: !2611)
!2610 = !DIFile(filename: "/usr/include/netinet/in.h", directory: "", checksumkind: CSK_MD5, checksum: "fbd766480c8cb9a8fe07ee7aa568ee60")
!2611 = !{!2612, !2615, !2617, !2618, !2630}
!2612 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_family", scope: !2609, file: !2610, line: 264, baseType: !2613, size: 16)
!2613 = !DIDerivedType(tag: DW_TAG_typedef, name: "sa_family_t", file: !2614, line: 28, baseType: !104)
!2614 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/sockaddr.h", directory: "", checksumkind: CSK_MD5, checksum: "5066b774f0f3cdb5cbbb5467306060db")
!2615 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_port", scope: !2609, file: !2610, line: 265, baseType: !2616, size: 16, offset: 16)
!2616 = !DIDerivedType(tag: DW_TAG_typedef, name: "in_port_t", file: !2610, line: 125, baseType: !106)
!2617 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_flowinfo", scope: !2609, file: !2610, line: 266, baseType: !585, size: 32, offset: 32)
!2618 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_addr", scope: !2609, file: !2610, line: 267, baseType: !2619, size: 128, offset: 64)
!2619 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "in6_addr", file: !2610, line: 221, size: 128, elements: !2620)
!2620 = !{!2621}
!2621 = !DIDerivedType(tag: DW_TAG_member, name: "__in6_u", scope: !2619, file: !2610, line: 228, baseType: !2622, size: 128)
!2622 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !2619, file: !2610, line: 223, size: 128, elements: !2623)
!2623 = !{!2624, !2626, !2628}
!2624 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr8", scope: !2622, file: !2610, line: 225, baseType: !2625, size: 128)
!2625 = !DICompositeType(tag: DW_TAG_array_type, baseType: !111, size: 128, elements: !298)
!2626 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr16", scope: !2622, file: !2610, line: 226, baseType: !2627, size: 128)
!2627 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 128, elements: !323)
!2628 = !DIDerivedType(tag: DW_TAG_member, name: "__u6_addr32", scope: !2622, file: !2610, line: 227, baseType: !2629, size: 128)
!2629 = !DICompositeType(tag: DW_TAG_array_type, baseType: !585, size: 128, elements: !2598)
!2630 = !DIDerivedType(tag: DW_TAG_member, name: "sin6_scope_id", scope: !2609, file: !2610, line: 268, baseType: !585, size: 32, offset: 192)
!2631 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !2400, file: !15, line: 798, baseType: !2632, size: 32, offset: 1248)
!2632 = !DIDerivedType(tag: DW_TAG_typedef, name: "socklen_t", file: !2633, line: 33, baseType: !2634)
!2633 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/socket.h", directory: "", checksumkind: CSK_MD5, checksum: "71a09f67661e8e55cf505c19b5ddbb85")
!2634 = !DIDerivedType(tag: DW_TAG_typedef, name: "__socklen_t", file: !109, line: 210, baseType: !7)
!2635 = !DIDerivedType(tag: DW_TAG_member, name: "wbuf", scope: !2400, file: !15, line: 800, baseType: !2636, size: 8192, offset: 1280)
!2636 = !DICompositeType(tag: DW_TAG_array_type, baseType: !124, size: 8192, elements: !2637)
!2637 = !{!2638}
!2638 = !DISubrange(count: 1024)
!2639 = !DIDerivedType(tag: DW_TAG_member, name: "resp_head", scope: !2292, file: !15, line: 857, baseType: !2398, size: 64, offset: 1600)
!2640 = !DIDerivedType(tag: DW_TAG_member, name: "ritem", scope: !2292, file: !15, line: 858, baseType: !127, size: 64, offset: 1664)
!2641 = !DIDerivedType(tag: DW_TAG_member, name: "rlbytes", scope: !2292, file: !15, line: 859, baseType: !102, size: 32, offset: 1728)
!2642 = !DIDerivedType(tag: DW_TAG_member, name: "item", scope: !2292, file: !15, line: 867, baseType: !128, size: 64, offset: 1792)
!2643 = !DIDerivedType(tag: DW_TAG_member, name: "sbytes", scope: !2292, file: !15, line: 870, baseType: !102, size: 32, offset: 1856)
!2644 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues_submitted", scope: !2292, file: !15, line: 872, baseType: !102, size: 32, offset: 1888)
!2645 = !DIDerivedType(tag: DW_TAG_member, name: "io_queues", scope: !2292, file: !15, line: 873, baseType: !2646, size: 576, offset: 1920)
!2646 = !DICompositeType(tag: DW_TAG_array_type, baseType: !2468, size: 576, elements: !293)
!2647 = !DIDerivedType(tag: DW_TAG_member, name: "recache_counter", scope: !2292, file: !15, line: 878, baseType: !7, size: 32, offset: 2496)
!2648 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !2292, file: !15, line: 880, baseType: !66, size: 32, offset: 2528)
!2649 = !DIDerivedType(tag: DW_TAG_member, name: "transport", scope: !2292, file: !15, line: 881, baseType: !71, size: 32, offset: 2560)
!2650 = !DIDerivedType(tag: DW_TAG_member, name: "close_reason", scope: !2292, file: !15, line: 882, baseType: !76, size: 32, offset: 2592)
!2651 = !DIDerivedType(tag: DW_TAG_member, name: "request_id", scope: !2292, file: !15, line: 885, baseType: !102, size: 32, offset: 2624)
!2652 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr", scope: !2292, file: !15, line: 886, baseType: !2609, size: 224, offset: 2656)
!2653 = !DIDerivedType(tag: DW_TAG_member, name: "request_addr_size", scope: !2292, file: !15, line: 887, baseType: !2632, size: 32, offset: 2880)
!2654 = !DIDerivedType(tag: DW_TAG_member, name: "noreply", scope: !2292, file: !15, line: 889, baseType: !246, size: 8, offset: 2912)
!2655 = !DIDerivedType(tag: DW_TAG_member, name: "stats", scope: !2292, file: !15, line: 895, baseType: !2656, size: 192, offset: 2944)
!2656 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2292, file: !15, line: 891, size: 192, elements: !2657)
!2657 = !{!2658, !2659, !2660}
!2658 = !DIDerivedType(tag: DW_TAG_member, name: "buffer", scope: !2656, file: !15, line: 892, baseType: !127, size: 64)
!2659 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !2656, file: !15, line: 893, baseType: !131, size: 64, offset: 64)
!2660 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !2656, file: !15, line: 894, baseType: !131, size: 64, offset: 128)
!2661 = !DIDerivedType(tag: DW_TAG_member, name: "binary_header", scope: !2292, file: !15, line: 899, baseType: !2662, size: 192, offset: 3136)
!2662 = !DIDerivedType(tag: DW_TAG_typedef, name: "protocol_binary_request_header", file: !2663, line: 164, baseType: !2664)
!2663 = !DIFile(filename: "./protocol_binary.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "7a322a65fa8661e9a597acbeeeb23107")
!2664 = distinct !DICompositeType(tag: DW_TAG_union_type, file: !2663, line: 151, size: 192, elements: !2665)
!2665 = !{!2666, !2678}
!2666 = !DIDerivedType(tag: DW_TAG_member, name: "request", scope: !2664, file: !2663, line: 162, baseType: !2667, size: 192)
!2667 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !2664, file: !2663, line: 152, size: 192, elements: !2668)
!2668 = !{!2669, !2670, !2671, !2672, !2673, !2674, !2675, !2676, !2677}
!2669 = !DIDerivedType(tag: DW_TAG_member, name: "magic", scope: !2667, file: !2663, line: 153, baseType: !111, size: 8)
!2670 = !DIDerivedType(tag: DW_TAG_member, name: "opcode", scope: !2667, file: !2663, line: 154, baseType: !111, size: 8, offset: 8)
!2671 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !2667, file: !2663, line: 155, baseType: !106, size: 16, offset: 16)
!2672 = !DIDerivedType(tag: DW_TAG_member, name: "extlen", scope: !2667, file: !2663, line: 156, baseType: !111, size: 8, offset: 32)
!2673 = !DIDerivedType(tag: DW_TAG_member, name: "datatype", scope: !2667, file: !2663, line: 157, baseType: !111, size: 8, offset: 40)
!2674 = !DIDerivedType(tag: DW_TAG_member, name: "reserved", scope: !2667, file: !2663, line: 158, baseType: !106, size: 16, offset: 48)
!2675 = !DIDerivedType(tag: DW_TAG_member, name: "bodylen", scope: !2667, file: !2663, line: 159, baseType: !585, size: 32, offset: 64)
!2676 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !2667, file: !2663, line: 160, baseType: !585, size: 32, offset: 96)
!2677 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !2667, file: !2663, line: 161, baseType: !120, size: 64, offset: 128)
!2678 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !2664, file: !2663, line: 163, baseType: !2679, size: 192)
!2679 = !DICompositeType(tag: DW_TAG_array_type, baseType: !111, size: 192, elements: !2680)
!2680 = !{!2681}
!2681 = !DISubrange(count: 24)
!2682 = !DIDerivedType(tag: DW_TAG_member, name: "cas", scope: !2292, file: !15, line: 900, baseType: !120, size: 64, offset: 3328)
!2683 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !2292, file: !15, line: 901, baseType: !120, size: 64, offset: 3392)
!2684 = !DIDerivedType(tag: DW_TAG_member, name: "cmd", scope: !2292, file: !15, line: 902, baseType: !267, size: 16, offset: 3456)
!2685 = !DIDerivedType(tag: DW_TAG_member, name: "opaque", scope: !2292, file: !15, line: 903, baseType: !102, size: 32, offset: 3488)
!2686 = !DIDerivedType(tag: DW_TAG_member, name: "keylen", scope: !2292, file: !15, line: 904, baseType: !102, size: 32, offset: 3520)
!2687 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !2292, file: !15, line: 905, baseType: !2290, size: 64, offset: 3584)
!2688 = !DIDerivedType(tag: DW_TAG_member, name: "thread", scope: !2292, file: !15, line: 906, baseType: !2410, size: 64, offset: 3648)
!2689 = !DIDerivedType(tag: DW_TAG_member, name: "try_read_command", scope: !2292, file: !15, line: 907, baseType: !2690, size: 64, offset: 3712)
!2690 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2691, size: 64)
!2691 = !DISubroutineType(types: !2692)
!2692 = !{!102, !2290}
!2693 = !DIDerivedType(tag: DW_TAG_member, name: "read", scope: !2292, file: !15, line: 908, baseType: !2694, size: 64, offset: 3776)
!2694 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2695, size: 64)
!2695 = !DISubroutineType(types: !2696)
!2696 = !{!2697, !2290, !128, !131}
!2697 = !DIDerivedType(tag: DW_TAG_typedef, name: "ssize_t", file: !2698, line: 108, baseType: !2699)
!2698 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/sys/types.h", directory: "", checksumkind: CSK_MD5, checksum: "7fb02a803b0c9b11cb5276b77d21e9d8")
!2699 = !DIDerivedType(tag: DW_TAG_typedef, name: "__ssize_t", file: !109, line: 194, baseType: !279)
!2700 = !DIDerivedType(tag: DW_TAG_member, name: "sendmsg", scope: !2292, file: !15, line: 909, baseType: !2701, size: 64, offset: 3840)
!2701 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2702, size: 64)
!2702 = !DISubroutineType(types: !2703)
!2703 = !{!2697, !2290, !2704, !102}
!2704 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2705, size: 64)
!2705 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "msghdr", file: !2633, line: 262, size: 448, elements: !2706)
!2706 = !{!2707, !2708, !2709, !2711, !2712, !2713, !2714}
!2707 = !DIDerivedType(tag: DW_TAG_member, name: "msg_name", scope: !2705, file: !2633, line: 264, baseType: !128, size: 64)
!2708 = !DIDerivedType(tag: DW_TAG_member, name: "msg_namelen", scope: !2705, file: !2633, line: 265, baseType: !2632, size: 32, offset: 64)
!2709 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iov", scope: !2705, file: !2633, line: 267, baseType: !2710, size: 64, offset: 128)
!2710 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2593, size: 64)
!2711 = !DIDerivedType(tag: DW_TAG_member, name: "msg_iovlen", scope: !2705, file: !2633, line: 268, baseType: !131, size: 64, offset: 192)
!2712 = !DIDerivedType(tag: DW_TAG_member, name: "msg_control", scope: !2705, file: !2633, line: 270, baseType: !128, size: 64, offset: 256)
!2713 = !DIDerivedType(tag: DW_TAG_member, name: "msg_controllen", scope: !2705, file: !2633, line: 271, baseType: !131, size: 64, offset: 320)
!2714 = !DIDerivedType(tag: DW_TAG_member, name: "msg_flags", scope: !2705, file: !2633, line: 276, baseType: !102, size: 32, offset: 384)
!2715 = !DIDerivedType(tag: DW_TAG_member, name: "write", scope: !2292, file: !15, line: 910, baseType: !2694, size: 64, offset: 3904)
!2716 = !DISubprogram(name: "usleep", scope: !2717, file: !2717, line: 480, type: !2718, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2717 = !DIFile(filename: "/usr/include/unistd.h", directory: "", checksumkind: CSK_MD5, checksum: "877e832a8bb8424f9180387a13787475")
!2718 = !DISubroutineType(types: !2719)
!2719 = !{!102, !2720}
!2720 = !DIDerivedType(tag: DW_TAG_typedef, name: "__useconds_t", file: !109, line: 161, baseType: !7)
!2721 = !DISubprogram(name: "pthread_cond_wait", scope: !998, file: !998, line: 1133, type: !2722, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2722 = !DISubroutineType(types: !2723)
!2723 = !{!102, !2724, !2725}
!2724 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !2144)
!2725 = !DIDerivedType(tag: DW_TAG_restrict_type, baseType: !1001)
!2726 = !DISubprogram(name: "calloc", scope: !889, file: !889, line: 675, type: !2727, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2727 = !DISubroutineType(types: !2728)
!2728 = !{!128, !131, !131}
!2729 = !DISubprogram(name: "STATS_LOCK", scope: !15, file: !15, line: 1026, type: !898, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2730 = !DISubprogram(name: "STATS_UNLOCK", scope: !15, file: !15, line: 1027, type: !898, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2731 = !DISubprogram(name: "item_trylock", scope: !15, file: !15, line: 1018, type: !2732, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2732 = !DISubroutineType(types: !2733)
!2733 = !{!128, !585}
!2734 = !DISubprogram(name: "storage_delete", scope: !2735, file: !2735, line: 4, type: !2736, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2735 = !DIFile(filename: "./storage.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "d18dbd8a1337d7561522237d8930ae7f")
!2736 = !DISubroutineType(types: !2737)
!2737 = !{null, !128, !90}
!2738 = !DISubprogram(name: "do_item_unlink", scope: !2739, file: !2739, line: 21, type: !2740, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2739 = !DIFile(filename: "./items.h", directory: "/home/alexey/tsan-experiments/nosql/memcached/memcached-summaries-work", checksumkind: CSK_MD5, checksum: "5548db7354621bc680fd5812e10230ba")
!2740 = !DISubroutineType(types: !2741)
!2741 = !{null, !90, !584}
!2742 = !DISubprogram(name: "item_trylock_unlock", scope: !15, file: !15, line: 1019, type: !415, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2743 = !DISubprogram(name: "item_is_flushed", scope: !2739, file: !2739, line: 29, type: !2744, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2744 = !DISubroutineType(types: !2745)
!2745 = !{!102, !90}
!2746 = distinct !DISubprogram(name: "slab_rebalance_alloc", scope: !3, file: !3, line: 789, type: !2747, scopeLine: 789, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2749)
!2747 = !DISubroutineType(cc: DW_CC_nocall, types: !2748)
!2748 = !{!128, !429, !7}
!2749 = !{!2750, !2751, !2752, !2753, !2754}
!2750 = !DILocalVariable(name: "size", arg: 1, scope: !2746, file: !3, line: 789, type: !429)
!2751 = !DILocalVariable(name: "id", arg: 2, scope: !2746, file: !3, line: 789, type: !7)
!2752 = !DILocalVariable(name: "s_cls", scope: !2746, file: !3, line: 790, type: !480)
!2753 = !DILocalVariable(name: "x", scope: !2746, file: !3, line: 792, type: !102)
!2754 = !DILocalVariable(name: "new_it", scope: !2746, file: !3, line: 793, type: !90)
!2755 = !DILocation(line: 0, scope: !2746)
!2756 = !DILocation(line: 791, column: 35, scope: !2746)
!2757 = !DILocation(line: 791, column: 14, scope: !2746)
!2758 = !DILocation(line: 416, column: 10, scope: !1035, inlinedAt: !2759)
!2759 = distinct !DILocation(line: 796, column: 18, scope: !2760)
!2760 = distinct !DILexicalBlock(scope: !2761, file: !3, line: 795, column: 42)
!2761 = distinct !DILexicalBlock(scope: !2762, file: !3, line: 795, column: 5)
!2762 = distinct !DILexicalBlock(scope: !2746, file: !3, line: 795, column: 5)
!2763 = !DILocation(line: 422, column: 12, scope: !1054, inlinedAt: !2759)
!2764 = !{!1505, !441, i64 44}
!2765 = !DILocation(line: 795, column: 19, scope: !2761)
!2766 = !DILocation(line: 795, column: 5, scope: !2762)
!2767 = !DILocation(line: 412, column: 9, scope: !1035, inlinedAt: !2759)
!2768 = !DILocation(line: 0, scope: !1035, inlinedAt: !2759)
!2769 = !DILocation(line: 426, column: 20, scope: !1060, inlinedAt: !2759)
!2770 = !DILocation(line: 426, column: 9, scope: !1035, inlinedAt: !2759)
!2771 = !DILocation(line: 428, column: 25, scope: !1065, inlinedAt: !2759)
!2772 = !DILocation(line: 429, column: 24, scope: !1065, inlinedAt: !2759)
!2773 = !DILocation(line: 429, column: 18, scope: !1065, inlinedAt: !2759)
!2774 = !DILocation(line: 430, column: 13, scope: !1069, inlinedAt: !2759)
!2775 = !DILocation(line: 430, column: 13, scope: !1065, inlinedAt: !2759)
!2776 = !DILocation(line: 430, column: 33, scope: !1069, inlinedAt: !2759)
!2777 = !DILocation(line: 430, column: 38, scope: !1069, inlinedAt: !2759)
!2778 = !DILocation(line: 430, column: 23, scope: !1069, inlinedAt: !2759)
!2779 = !DILocation(line: 433, column: 13, scope: !1065, inlinedAt: !2759)
!2780 = !DILocation(line: 433, column: 22, scope: !1065, inlinedAt: !2759)
!2781 = !DILocation(line: 434, column: 13, scope: !1065, inlinedAt: !2759)
!2782 = !DILocation(line: 434, column: 22, scope: !1065, inlinedAt: !2759)
!2783 = !DILocation(line: 435, column: 19, scope: !1065, inlinedAt: !2759)
!2784 = !DILocation(line: 801, column: 42, scope: !2785)
!2785 = distinct !DILexicalBlock(scope: !2760, file: !3, line: 801, column: 13)
!2786 = !DILocation(line: 801, column: 28, scope: !2785)
!2787 = !DILocation(line: 802, column: 13, scope: !2785)
!2788 = !DILocation(line: 802, column: 44, scope: !2785)
!2789 = !DILocation(line: 802, column: 31, scope: !2785)
!2790 = !DILocation(line: 801, column: 13, scope: !2760)
!2791 = !DILocation(line: 806, column: 30, scope: !2792)
!2792 = distinct !DILexicalBlock(scope: !2785, file: !3, line: 802, column: 54)
!2793 = !DILocation(line: 807, column: 30, scope: !2792)
!2794 = !DILocation(line: 812, column: 38, scope: !2792)
!2795 = !DILocation(line: 795, column: 38, scope: !2761)
!2796 = distinct !{!2796, !2766, !2797, !461}
!2797 = !DILocation(line: 816, column: 5, scope: !2762)
!2798 = !DILocation(line: 817, column: 5, scope: !2746)
!2799 = !DISubprogram(name: "do_item_replace", scope: !2739, file: !2739, line: 26, type: !2800, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!2800 = !DISubroutineType(types: !2801)
!2801 = !{!102, !90, !90, !584, !2802}
!2802 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !120)
